const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const c=await b.newContext({viewport:{width:1366,height:900}});const p=await c.newPage();await p.goto('https://www.freedailypro.com/tool/roman-numeral-converter',{waitUntil:'domcontentloaded'});await p.waitForTimeout(3500);
const ty=async(s,v)=>{const l=p.locator(s);await l.click();await l.fill('');await l.pressSequentially(v);await p.waitForTimeout(600)};
const blk=()=>p.evaluate(()=>{const d=document.querySelector('input[aria-label=Day]');let c=d;for(let i=0;i<3;i++)c=c.parentElement;const t=document.querySelector('main').innerText;const s=t.indexOf('Date →');const e=t.indexOf('Plain letters cover');return t.slice(s,e).replace(/\n+/g,' | ').replace(/ \| Day\.Month.*?a slash\./,'')});
for(const v of ['4000','3999999']){await ty('input[aria-label=Number]',v);const h=await p.evaluate(()=>{const e=document.querySelector('main p.text-2xl.font-bold.text-primary');return {html:e.innerHTML.slice(0,300),text:e.innerText,deco:getComputedStyle(e.querySelector('*')||e).textDecorationLine}});console.log(v,JSON.stringify(h));await p.locator('main p.text-2xl.font-bold.text-primary').first().screenshot({path:`/workspace/deep/01-roman-numeral-converter/edge/result-${v}.png`})}
console.log('date labels/placeholders',await p.evaluate(()=>[...document.querySelectorAll('input[aria-label=Day],input[aria-label=Month],input[aria-label=Year]')].map(i=>({aria:i.getAttribute('aria-label'),ph:i.placeholder,label:i.labels&&[...i.labels].map(l=>l.innerText).join('/'),inputmode:i.inputMode}))));
const r=p.locator('input[name=rn-order]');
await r.nth(0).check();await ty('input[aria-label=Day]','31');await ty('input[aria-label=Month]','02');await ty('input[aria-label=Year]','2026');console.log('DMY 31/02/2026 ::',await blk());
await ty('input[aria-label=Year]','4000');console.log('DMY year 4000 ::',await blk());
await r.nth(1).check();await ty('input[aria-label=Day]','11');await ty('input[aria-label=Month]','19');await ty('input[aria-label=Year]','2026');console.log('US 11|19|2026 ::',await blk());
await p.locator('input[aria-label=Day]').scrollIntoViewIfNeeded();await p.screenshot({path:'/workspace/deep/01-roman-numeral-converter/edge/us-order-11-19-error.png'});
await ty('input[aria-label=Day]','7');await ty('input[aria-label=Month]','4');await ty('input[aria-label=Year]','1776');console.log('US 7|4|1776 ::',await blk());
await ty('input[aria-label=Day]','4');await ty('input[aria-label=Month]','7');console.log('US 4|7|1776 ::',await blk());
await b.close()})()
