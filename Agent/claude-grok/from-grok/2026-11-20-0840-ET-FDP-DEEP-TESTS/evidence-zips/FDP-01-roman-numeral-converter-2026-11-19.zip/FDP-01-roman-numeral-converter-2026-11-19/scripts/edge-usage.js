#!/usr/bin/env node
// FDP Step A: edge inputs, usage counting, downloads/FAQ/links/video for Roman Numeral Converter.
// Usage: node edge-usage.js [url] [outDir]
// Guest only, fresh Chromium context per run. Never clicks ads, pass/checkout buttons or sign-in. window.print is stubbed.
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path');
const URL = process.argv[2] || 'https://www.freedailypro.com/tool/roman-numeral-converter';
const OUT = process.argv[3] || '/workspace/deep/01-roman-numeral-converter/edge';
fs.mkdirSync(OUT, { recursive: true });
const now = () => require('child_process').execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
const NUM = 'input[aria-label=Number]', ROM = "input[aria-label='Roman numeral']";
async function fresh(b) {
  const ctx = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true });
  await ctx.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://www.freedailypro.com' });
  await ctx.addInitScript(() => { window.__prints = 0; window.print = () => { window.__prints++; }; });
  const p = await ctx.newPage(); const errs = [];
  p.on('pageerror', e => errs.push(e.message.slice(0, 150)));
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {}); await p.waitForTimeout(2500);
  return { ctx, p, errs };
}
// text of the card that holds a given input (walks up until the block also contains a result/error)
const cardText = (p, sel) => p.evaluate(s => { let e = document.querySelector(s); for (let i = 0; i < 6 && e; i++) { e = e.parentElement; if (e && e.innerText.split('\n').filter(Boolean).length >= 3) break; } return (e ? e.innerText : '').replace(/\n+/g, ' | ').slice(0, 400); }, sel);
async function type(p, sel, v) { const l = p.locator(sel).first(); await l.click(); await l.fill(''); if (v !== '') await l.pressSequentially(v, { delay: 20 }); await p.waitForTimeout(700); }
const usage = async (p) => p.evaluate(() => {
  const t = document.body.innerText; const m = t.match(/[^\n]*(uses\/day|remaining today|trial uses? (are )?used up)[^\n]*/i);
  return { strip: m ? m[0].trim() : null, ls: localStorage.getItem('fdp-usage-v1'), prints: window.__prints };
});
(async () => {
  const b = await chromium.launch(); const R = { started: now(), url: URL, edgeNumber: [], edgeRoman: [], date: [], separators: [], usage: [], meta: {} };
  // ---------- 1. edge inputs ----------
  { const { ctx, p, errs } = await fresh(b);
    R.edgeInitialUsage = await usage(p);
    for (const v of ['1', '3999', '4000', '3999999', '4000000', '0', '-5', '12.5', '', 'mmxxvi', 'IIII', 'VX', 'MMMM', ' XIV ', 'ABC']) {
      await type(p, NUM, v); R.edgeNumber.push({ input: JSON.stringify(v), box: 'Number', value: await p.locator(NUM).inputValue(), card: await cardText(p, NUM) });
    }
    for (const v of ['1', '3999', '4000', '3999999', '4000000', '0', '-5', '12.5', '', 'mmxxvi', 'IIII', 'VX', 'MMMM', ' XIV ', 'ABC', 'IIX', 'IC', '(V)', '(XII)CCCXLV', 'I̅V̅']) {
      await type(p, ROM, v); R.edgeRoman.push({ input: JSON.stringify(v), box: 'Roman', value: await p.locator(ROM).inputValue(), card: await cardText(p, ROM) });
    }
    // date mode
    const D = 'input[aria-label=Day]', M = 'input[aria-label=Month]', Y = 'input[aria-label=Year]';
    const dateBlock = () => p.evaluate(() => { const e = document.querySelector('[data-testid=rn-date]') || document.querySelector('input[aria-label=Day]'); let c = e; for (let i = 0; i < 4; i++) c = c.parentElement; const lab = [...document.querySelectorAll('input[aria-label=Day],input[aria-label=Month],input[aria-label=Year]')].map(i => i.getAttribute('aria-label') + '=' + i.value).join(', '); return { block: c.innerText.replace(/\n+/g, ' | ').slice(0, 400), fields: lab, heading: [...document.querySelectorAll('main *')].find(x => x.children.length === 0 && /^Date\s*→/.test(x.textContent.trim()))?.textContent.trim() }; });
    const setDate = async (d, m, y) => { await type(p, D, d); await type(p, M, m); await type(p, Y, y); };
    const radios = p.locator('input[name=rn-order]');
    await radios.nth(0).check(); await setDate('31', '02', '2026'); R.date.push({ case: 'DMY 31/02/2026 (Day=31, Month=02)', ...(await dateBlock()) });
    await setDate('29', '02', '2024'); R.date.push({ case: 'DMY 29/02/2024 leap', ...(await dateBlock()) });
    await setDate('19', '11', '2026'); R.date.push({ case: 'DMY 19/11/2026', ...(await dateBlock()) });
    await radios.nth(1).check(); await p.waitForTimeout(500); R.date.push({ case: 'Switch to Month.Day.Year (US), boxes still 19 | 11 | 2026', ...(await dateBlock()) });
    // US user types 11 then 19 into the first two boxes in visual order
    await setDate('11', '19', '2026'); R.date.push({ case: 'US order: first box 11, second box 19, year 2026 (user means Nov 19)', ...(await dateBlock()) });
    await setDate('7', '4', '1776'); R.date.push({ case: 'US order: first box 7, second box 4, 1776 (FAQ example 7.4.1776)', ...(await dateBlock()) });
    await setDate('19', '11', '2026'); R.date.push({ case: 'US order: first box 19, second box 11, 2026', ...(await dateBlock()) });
    R.dateFieldOrderDOM = await p.evaluate(() => [...document.querySelectorAll('input[aria-label=Day],input[aria-label=Month],input[aria-label=Year]')].map(i => i.getAttribute('aria-label') + '@x' + Math.round(i.getBoundingClientRect().x)));
    await radios.nth(0).check(); await setDate('19', '11', '2026');
    const opts = await p.locator('#rn-sep option').evaluateAll(o => o.map(x => ({ v: x.value, t: x.textContent })));
    for (const o of opts) { await p.selectOption('#rn-sep', o.v); await p.waitForTimeout(400); R.separators.push({ option: o.t, value: JSON.stringify(o.v), result: await p.locator('[data-testid=rn-date]').innerText().catch(() => null) }); }
    await p.screenshot({ path: path.join(OUT, 'edge-final.png'), fullPage: false });
    R.edgeUsageAfterTyping = await usage(p); R.edgeErrors = errs; await ctx.close(); }
  // ---------- 2. usage counting, two fresh contexts ----------
  for (const run of [1, 2]) {
    const { ctx, p, errs } = await fresh(b); const U = { run, steps: [] };
    const step = async (name) => { await p.waitForTimeout(1200); const u = await usage(p); U.steps.push({ step: name, time: now(), ...u }); };
    await step('on load (no action)');
    await type(p, NUM, '1994'); await p.waitForTimeout(1200); await step('after typing 1994');
    U.history = await p.evaluate(() => { const h = [...document.querySelectorAll('main *')].find(e => /Recent calculations/i.test(e.textContent) && e.children.length < 3); let c = h; for (let i = 0; i < 3 && c; i++) c = c.parentElement; return c ? c.innerText.replace(/\n+/g, ' | ').slice(0, 300) : null; });
    await p.locator("button[aria-label='Copy Roman numeral']").first().click(); await p.waitForTimeout(600);
    U.clipboard = await p.evaluate(() => navigator.clipboard.readText().catch(e => 'ERR ' + e.message));
    U.toastAfterCopy = await p.evaluate(() => [...document.querySelectorAll('[role=status],[data-sonner-toast],li[data-type],[role=alert]')].map(e => e.innerText.trim()).filter(Boolean).join(' | ').slice(0, 200));
    await step('after Copy Roman numeral');
    let dl = null;
    try { const [d] = await Promise.all([p.waitForEvent('download', { timeout: 8000 }), p.getByRole('button', { name: 'Download CSV' }).click()]);
      const f = path.join(OUT, `run${run}-` + d.suggestedFilename()); await d.saveAs(f); const txt = fs.readFileSync(f, 'utf8'); dl = { filename: d.suggestedFilename(), bytes: fs.statSync(f).size, lines: txt.split(/\r?\n/).filter(Boolean).length, head: txt.split(/\r?\n/).slice(0, 4), tail: txt.split(/\r?\n/).filter(Boolean).slice(-2), saved: f };
    } catch (e) { dl = { error: e.message.split('\n')[0] }; }
    U.download = dl; await step('after Download CSV (1 to 100 tab)');
    await p.getByRole('button', { name: 'Print or save as PDF' }).click(); await p.waitForTimeout(800);
    U.newPages = ctx.pages().length; await step('after Print or save as PDF (window.print stubbed)');
    if (run === 2) { // years tab CSV + copy table, second context only
      await p.getByRole('button', { name: 'Years 1950 to 2050' }).click(); await p.waitForTimeout(500);
      try { const [d] = await Promise.all([p.waitForEvent('download', { timeout: 8000 }), p.getByRole('button', { name: 'Download CSV' }).click()]); const f = path.join(OUT, 'run2-' + d.suggestedFilename()); await d.saveAs(f); const txt = fs.readFileSync(f, 'utf8'); U.downloadYears = { filename: d.suggestedFilename(), lines: txt.split(/\r?\n/).filter(Boolean).length, head: txt.split(/\r?\n/).slice(0, 3), tail: txt.split(/\r?\n/).filter(Boolean).slice(-1) }; } catch (e) { U.downloadYears = { error: e.message.split('\n')[0] }; }
      await step('after Download CSV (Years tab)');
      await p.getByRole('button', { name: 'Copy table' }).click(); await p.waitForTimeout(600);
      U.clipboardTable = (await p.evaluate(() => navigator.clipboard.readText().catch(e => 'ERR ' + e.message))).slice(0, 160);
      await step('after Copy table');
    }
    await p.screenshot({ path: path.join(OUT, `usage-run${run}-before-reload.png`) });
    await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); await step('after reload');
    U.valuesAfterReload = { number: await p.locator(NUM).inputValue(), roman: await p.locator(ROM).inputValue() };
    U.errors = errs; R.usage.push(U); await ctx.close();
  }
  // ---------- 3. FAQ, links, video, share ----------
  { const { ctx, p } = await fresh(b);
    R.meta = await p.evaluate(() => {
      const t = s => (s || '').trim().replace(/\s+/g, ' ');
      const sec = h => { const H = [...document.querySelectorAll('h2')].find(x => new RegExp(h, 'i').test(x.textContent)); return H ? H.closest('section') || H.parentElement : null; };
      const faqSec = sec('Common questions');
      const faq = faqSec ? [...faqSec.querySelectorAll('button,summary,h3,dt')].map(e => t(e.innerText)).filter(s => s.endsWith('?')) : [];
      const guides = sec('Guides and next steps'); const links = guides ? [...guides.querySelectorAll('a[href]')].map(a => ({ text: t(a.innerText), href: a.href })) : [];
      const related = [...document.querySelectorAll('main a[href*="/tool/"]')].map(a => ({ text: t(a.innerText).slice(0, 60), href: a.href })).filter(a => !a.href.endsWith('/roman-numeral-converter'));
      const html = document.documentElement.outerHTML; const yt = [...new Set((html.match(/(?:youtube(?:-nocookie)?\.com\/(?:embed\/|watch\?v=)|i\.ytimg\.com\/vi\/|youtu\.be\/)([\w-]{11})/g) || []))];
      const blog = [...document.querySelectorAll('main a[href*="/blog/"]')].map(a => ({ text: t(a.innerText).slice(0, 80), href: a.href }));
      return { faq, guides: links, relatedToolLinks: related.slice(0, 20), blogLinks: blog, youtubeRefs: yt, videoButton: document.querySelector('[aria-label^="Play video"]')?.getAttribute('aria-label') };
    });
    for (const bl of [...new Set(R.meta.blogLinks.map(x => x.href))]) { const r = await fetch(bl, { redirect: 'manual' }); (R.meta.blogStatus = R.meta.blogStatus || []).push({ href: bl, status: r.status }); }
    for (const tl of [...new Set(R.meta.relatedToolLinks.map(x => x.href))].slice(0, 15)) { const r = await fetch(tl, { redirect: 'manual' }); (R.meta.toolLinkStatus = R.meta.toolLinkStatus || []).push({ href: tl, status: r.status }); }
    // share: click the in-page "Share this tool" (guides section) once; read what appears
    try { await p.evaluate(() => { navigator.share = undefined; }); const sb = p.getByRole('button', { name: 'Share this tool' }).last(); await sb.scrollIntoViewIfNeeded(); await sb.click(); await p.waitForTimeout(1200);
      R.meta.share = { dialog: await p.evaluate(() => [...document.querySelectorAll('[role=dialog],[role=menu],[data-radix-popper-content-wrapper]')].map(e => e.innerText.replace(/\n+/g, ' | ')).join(' || ').slice(0, 400)), clipboard: await p.evaluate(() => navigator.clipboard.readText().catch(() => '')), usage: await usage(p) };
      await p.screenshot({ path: path.join(OUT, 'share-click.png') }); await p.keyboard.press('Escape');
    } catch (e) { R.meta.share = { error: e.message.split('\n')[0] }; }
    await ctx.close(); }
  R.finished = now(); await b.close();
  fs.writeFileSync(path.join(OUT, 'edge-usage-results.json'), JSON.stringify(R, null, 1)); console.log('done', R.finished);
})();
