// a11y on the result view + keyboard operability of drop zones and result controls (guest, fresh context)
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/02-audio-comparer/live/'; const T = '/workspace/deep/02-audio-comparer/testfiles/';
const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
(async () => {
  const b = await chromium.launch(); const R = { started: now() }; let ctx, p;
  for (let a = 0; a < 6; a++) { ctx = await b.newContext({ viewport: { width: 1366, height: 768 } }); p = await ctx.newPage();
    await p.goto('https://www.freedailypro.com/tool/audio-comparer', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
    const s = await p.evaluate(() => (document.body.innerText.match(/[^\n]*remaining today[^\n]*/) || [''])[0]); R['load' + a] = s;
    if (!/(^|[^0-9])0 remaining today/.test(s)) break; await ctx.close(); }
  const zones = p.locator('main div[role=button].rounded-xl'); R.zoneCount = await zones.count();
  R.zoneAttrs = await zones.evaluateAll(z => z.map(e => ({ tabindex: e.getAttribute('tabindex'), aria: e.getAttribute('aria-label'), text: e.innerText.slice(0, 60) })));
  await zones.first().focus(); R.focusVisible = await p.evaluate(() => { const e = document.activeElement; const cs = getComputedStyle(e); return { tag: e.tagName, outline: cs.outlineStyle + ' ' + cs.outlineWidth, ring: cs.boxShadow.slice(0, 80) }; });
  try { const [fc] = await Promise.all([p.waitForEvent('filechooser', { timeout: 4000 }), p.keyboard.press('Enter')]); R.enterOpensChooser = true; await fc.setFiles(T + 'melody_12s.wav'); } catch { R.enterOpensChooser = false; await p.locator('input[type=file]').first().setInputFiles(T + 'melody_12s.wav'); }
  await zones.last().focus().catch(() => {});
  try { const [fc] = await Promise.all([p.waitForEvent('filechooser', { timeout: 4000 }), p.keyboard.press('Space')]); R.spaceOpensChooser = true; await fc.setFiles(T + 'melody_12s_edit5to7.wav'); } catch { R.spaceOpensChooser = false; await p.locator('input[type=file]').last().setInputFiles(T + 'melody_12s_edit5to7.wav'); }
  await p.waitForTimeout(800);
  await p.getByRole('button', { name: 'Compare Audio' }).focus(); await p.keyboard.press('Enter');
  await p.waitForSelector('text=/Differs at|Identical|Different audio|Partly/', { timeout: 20000 }).catch(() => {}); await p.waitForTimeout(1500);
  R.afterCompare = await p.evaluate(() => (document.body.innerText.match(/[^\n]*remaining today[^\n]*/) || [''])[0]);
  R.focusAfterCompare = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.innerText || e.getAttribute('aria-label') || '').slice(0, 40); });
  R.live = await p.evaluate(() => [...document.querySelectorAll('[aria-live],[role=status],[role=alert]')].map(e => e.getAttribute('aria-live') + ':' + e.innerText.slice(0, 80)));
  R.stripCells = await p.evaluate(() => { const s = document.querySelector('[data-testid=compare-strip]'); if (!s) return null; const c = [...s.children]; return { n: c.length, role: s.getAttribute('role'), label: s.getAttribute('aria-label'), sampleTitles: c.slice(0, 3).map(e => e.getAttribute('title')), cellRoles: c[0]?.getAttribute('role') }; });
  R.waveforms = await p.evaluate(() => [...document.querySelectorAll('main canvas')].map(e => ({ role: e.getAttribute('role'), label: e.getAttribute('aria-label') })));
  const order = []; for (let i = 0; i < 14; i++) { await p.keyboard.press('Tab'); order.push(await p.evaluate(() => { const e = document.activeElement; return e.tagName + ':' + (e.innerText || e.getAttribute('aria-label') || '').trim().slice(0, 35); })); } R.tabOrder = order;
  await p.addScriptTag({ path: require.resolve('axe-core/axe.min.js') });
  R.axeResultView = await p.evaluate(async () => (await axe.run(document.querySelector('main') || document, { resultTypes: ['violations'] })).violations.map(v => ({ id: v.id, impact: v.impact, count: v.nodes.length, help: v.help, sample: v.nodes.slice(0, 3).map(n => n.target.join(' ') + ' :: ' + (n.failureSummary || '').split('\n')[1]) })));
  await p.screenshot({ path: OUT + 'a11y-result-view.png', fullPage: true });
  R.finished = now(); fs.writeFileSync(OUT + 'a11y-result.json', JSON.stringify(R, null, 1)); console.log('wrote a11y-result.json', R.finished); await b.close();
})();
