// Flow when trial uses are used up (fresh guest): blocked Compare, paywall text, input kept?, share, reload, Quick Buy paths (stop at email prompt / Stripe; nothing typed). Usage: node ac-capped-flow.js
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const URL = 'https://www.freedailypro.com/tool/audio-comparer', T = '/workspace/deep/02-audio-comparer/testfiles/', OUT = '/workspace/deep/02-audio-comparer/live/';
const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
const dlg = p => p.evaluate(() => [...document.querySelectorAll('[role=dialog],[role=alertdialog]')].map(e => e.innerText.replace(/\n+/g, ' | ')).join(' || ').slice(0, 1500));
(async () => { const b = await chromium.launch(); const R = { started: now() };
  const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); await ctx.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://www.freedailypro.com' });
  const p = await ctx.newPage(); await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  R.onLoad = { strip: await p.evaluate(() => document.body.innerText.match(/Trial:[^\n]*(\n[^\n]*){0,6}/)?.[0]), ls: await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) };
  await p.locator('input[type=file]').first().setInputFiles(T + 'melody_12s.wav'); await p.waitForTimeout(500); await p.locator('input[type=file]').last().setInputFiles(T + 'melody_12s.mp3'); await p.waitForTimeout(500);
  R.compareDisabled = await p.getByRole('button', { name: 'Compare Audio' }).isDisabled();
  await p.getByRole('button', { name: 'Compare Audio' }).click(); await p.waitForTimeout(1500);
  R.afterCompare = { dialog: await dlg(p), inlineNote: await p.evaluate(() => (document.body.innerText.match(/Today's trial uses are used up[^\n]*/) || [null])[0]), filesStillShown: await p.evaluate(() => document.querySelector('main').innerText.match(/Audio File 1\n+([^\n]+)[\s\S]*?Audio File 2\n+([^\n]+)/)?.slice(1)) };
  await p.screenshot({ path: OUT + 'capped-paywall-dialog.png' });
  R.dialogButtons = await p.evaluate(() => [...document.querySelectorAll('[role=dialog] a,[role=dialog] button')].map(e => (e.innerText.trim() || e.getAttribute('aria-label')) + ' -> ' + (e.href || 'button')));
  await p.keyboard.press('Escape'); await p.waitForTimeout(500);
  // Share (page share)
  await p.evaluate(() => { navigator.share = undefined; }); await p.getByRole('button', { name: 'Share this tool' }).first().click(); await p.waitForTimeout(800);
  R.share = { clipboard: await p.evaluate(() => navigator.clipboard.readText().catch(() => '')), dialog: await dlg(p), toast: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText).join(' | ')) };
  await p.keyboard.press('Escape');
  // reload: are files kept?
  await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500);
  R.afterReload = await p.evaluate(() => document.querySelector('main').innerText.match(/Audio File 1[\s\S]{0,160}/)?.[0].replace(/\n+/g, ' | '));
  // Quick Buy day pass (first) -> observe, stop
  const qb = p.getByRole('button', { name: 'Quick Buy' });
  R.quickBuyCount = await qb.count();
  if (R.quickBuyCount) { await qb.first().click(); await p.waitForTimeout(2500); R.quickBuyDay = { url: p.url(), dialog: await dlg(p), inputs: await p.evaluate(() => [...document.querySelectorAll('[role=dialog] input')].map(i => i.type + ':' + (i.placeholder || i.name))) }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await p.keyboard.press('Escape'); await p.waitForTimeout(800);
    if (!/freedailypro\.com\/tool/.test(p.url())) { await p.goto(URL); await p.waitForTimeout(3000); }
    const [np] = await Promise.all([ctx.waitForEvent('page', { timeout: 8000 }).catch(() => null), p.getByRole('button', { name: 'Quick Buy' }).nth(1).click()]);
    await p.waitForTimeout(5000); const tgt = np || p; await tgt.waitForLoadState('domcontentloaded').catch(() => {});
    R.quickBuyMonthly = { url: tgt.url().replace(/#.*/, '').slice(0, 120), title: await tgt.title().catch(() => ''), dialog: await dlg(p), stripeVisibleText: (await tgt.evaluate(() => document.body.innerText.slice(0, 400)).catch(() => '')).replace(/\n+/g, ' | ') };
    await tgt.screenshot({ path: OUT + 'quickbuy-monthly.png' }).catch(() => {});
  }
  R.finished = now(); fs.writeFileSync(OUT + 'capped-flow.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1).slice(0, 5000)); await b.close(); })();
