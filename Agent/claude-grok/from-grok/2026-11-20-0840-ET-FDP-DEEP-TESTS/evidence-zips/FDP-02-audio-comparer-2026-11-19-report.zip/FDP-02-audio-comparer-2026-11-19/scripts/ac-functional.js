#!/usr/bin/env node
// FDP-02 Compare Two Audio Files: pair matrix + usage flow + paywall. Guest only; never clicks ads, never enters payment data.
// Usage: node ac-functional.js [pairs|usage|all]   (outputs to /workspace/deep/02-audio-comparer/live)
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path'); const cp = require('child_process');
const URL = 'https://www.freedailypro.com/tool/audio-comparer';
const T = '/workspace/deep/02-audio-comparer/testfiles/'; const OUT = '/workspace/deep/02-audio-comparer/live/';
fs.mkdirSync(OUT, { recursive: true });
const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
const mode = process.argv[2] || 'all';
const usage = p => p.evaluate(() => ({ strip: ((document.body.innerText.match(/[^\n]*(uses\/day|remaining today|used up|trial use)[^\n]*/ig) || []).slice(0, 3).join(' || ')) || null, ls: localStorage.getItem('fdp-usage-v1') }));
const toasts = p => p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast],[role=status],[role=alert]')].map(e => e.innerText.trim()).filter(Boolean).join(' | ').slice(0, 300));
const dialogs = p => p.evaluate(() => [...document.querySelectorAll('[role=dialog],[role=alertdialog]')].map(e => e.innerText.replace(/\n+/g, ' | ')).join(' || ').slice(0, 1200));
async function fresh(b) {
  const ctx = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true });
  await ctx.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://www.freedailypro.com' });
  const p = await ctx.newPage(); const errs = [];
  p.on('pageerror', e => errs.push('pageerror: ' + e.message.slice(0, 160)));
  p.on('console', m => { if (m.type() === 'error' && !/googlesyndication|doubleclick|adsbygoogle|no_div/.test(m.text())) errs.push(m.text().slice(0, 160)); });
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500);
  return { ctx, p, errs };
}
async function load2(p, f1, f2) {
  await p.locator('input[type=file]').first().setInputFiles(T + f1); await p.waitForTimeout(700);
  const after1 = await p.evaluate(() => document.querySelector('main').innerText.match(/Audio File 1\n+([^\n]+)\n+([^\n]+)/)?.slice(1).join(' / ') || null);
  await p.locator('input[type=file]').last().setInputFiles(T + f2); await p.waitForTimeout(700);
  return after1;
}
async function compare(p) {
  const t0 = Date.now(); const btn = p.getByRole('button', { name: 'Compare Audio' });
  const disabled = await btn.isDisabled().catch(() => null);
  if (disabled) return { disabled: true };
  await btn.click();
  let res = null;
  for (let i = 0; i < 120; i++) {
    await p.waitForTimeout(500);
    res = await p.evaluate(() => {
      const t = document.querySelector('main').innerText;
      const m = t.match(/\nMatch\n+([\d.]+%)\n+([^\n]+)/);
      const toast = [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim()).join(' | ');
      const dlg = [...document.querySelectorAll('[role=dialog],[role=alertdialog]')].map(e => e.innerText.replace(/\n+/g, ' | ')).join(' || ');
      if (!m && !/Couldn't|could not|error/i.test(toast) && !dlg && !/used up|Upgrade|pass/i.test(toast)) return null;
      const grab = re => (t.match(re) || [])[0] || null;
      const tbl = [...document.querySelectorAll('[data-testid=compare-view] table tr')].map(r => [...r.children].map(c => c.innerText.trim()).join(' | '));
      return { score: m ? m[1] : null, verdict: m ? m[2] : null, differs: grab(/Differs at [^\n]+/), noDiff: grab(/[^\n]*no second is flagged[^\n]*/), aligned: grab(/[^\n]*aligned by[^\n]*/i), fourMin: grab(/Only the first 4 minutes[^\n]*/), loudNote: grab(/Loudness match turns[^\n]*/), table: tbl, toast, dialog: dlg.slice(0, 1200) };
    });
    if (res) break;
  }
  return { ...(res || { timeout: true }), ms: Date.now() - t0 };
}
const PAIRS = [
  ['a440_10s.wav', 'a440_10s_copy.wav', 'identical bytes, different name'],
  ['a440_10s.wav', 'a440_10s.mp3', 'same audio WAV vs MP3 128k'],
  ['a440_10s.wav', 'a440_10s.ogg', 'WAV vs OGG Vorbis'],
  ['a440_10s.wav', 'a440_10s.m4a', 'WAV vs M4A AAC'],
  ['a440_10s.wav', 'a440_10s.flac', 'WAV vs FLAC (lossless)'],
  ['a440_10s.wav', 'a440_10s_48k_stereo.wav', '44.1k mono vs 48k stereo'],
  ['a440_10s.wav', 'a440_10s_quiet.wav', 'same, -12 dB'],
  ['a440_10s.wav', 'a440_8s_trim.wav', '10 s vs first 8 s'],
  ['a440_10s.wav', 'a440_offset05.wav', '0.5 s leading silence'],
  ['a440_10s.wav', 'b880_10s.wav', '440 Hz vs 880 Hz (different)'],
  ['melody_12s.wav', 'melody_12s.mp3', 'melody WAV vs MP3 96k'],
  ['melody_12s.wav', 'melody_12s_edit5to7.wav', 'melody vs 5-7 s replaced by noise'],
  ['melody_12s.wav', 'noise_pink_10s.wav', 'melody vs pink noise (unrelated)'],
  ['a440_10s.wav', 'mix_440then880_10s.wav', '440 vs first half 440 then 880'],
  ['melody_12s.wav', 'a440_10s.wav', 'melody vs steady sine (different)'],
  ['a440_10s.wav', 'long_300s.mp3', '10 s vs 300 s MP3 (4-minute cap note)'],
  ['a440_10s.wav', 'corrupt.mp3', 'random bytes named .mp3'],
  ['a440_10s.wav', 'notaudio.wav', 'text file named .wav'],
  ['a440_10s.wav', 'empty.wav', '0-byte .wav'],
  ['a440_10s.wav', 'oversized_380s_stereo.wav', '67 MB 380 s stereo WAV (over 50 MB note)'],
];
(async () => {
  const b = await chromium.launch(); const R = { started: now(), pairs: [], usageRuns: [], paywall: null };
  if (mode === 'pairs' || mode === 'all') {
    let { ctx, p, errs } = await fresh(b); let ctxN = 1;
    for (let i = 0; i < PAIRS.length; i++) {
      const [f1, f2, label] = PAIRS[i];
      await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(2500);
      const before = await usage(p);
      const f1shown = await load2(p, f1, f2);
      const f2shown = await p.evaluate(() => document.querySelector('main').innerText.match(/Audio File 2\n+([^\n]+)\n+([^\n]+)/)?.slice(1).join(' / ') || null);
      const r = await compare(p); const after = await usage(p);
      const blocked = !r.score && (/used up|upgrade|pass|limit/i.test((r.toast || '') + (r.dialog || '')));
      const row = { n: i + 1, ctx: ctxN, f1, f2, label, f1shown, f2shown, ...r, usageBefore: before, usageAfter: after, errs: errs.splice(0) };
      if (blocked && !R.paywall) { R.paywall = { atPair: i + 1, toast: r.toast, dialog: r.dialog, strip: after.strip, ls: after.ls }; await p.screenshot({ path: OUT + 'paywall.png', fullPage: false });
        // record where upgrade links point, without clicking them
        R.paywall.links = await p.evaluate(() => [...document.querySelectorAll('[role=dialog] a, [role=dialog] button')].map(e => (e.innerText.trim() || e.getAttribute('aria-label')) + ' -> ' + (e.href || '(button)')));
      }
      if (blocked) { await ctx.close(); ({ ctx, p, errs } = await fresh(b)); ctxN++; i--; R.pairs.push({ ...row, note: 'blocked by trial limit; retried in fresh context' }); continue; }
      if (r.score) await p.screenshot({ path: OUT + `pair${String(i + 1).padStart(2, '0')}.png`, fullPage: false, clip: undefined }).catch(() => {});
      R.pairs.push(row); console.log(i + 1, label, '=>', r.score, r.verdict, r.toast || '', r.ms + 'ms');
      fs.writeFileSync(OUT + 'pairs-results.json', JSON.stringify(R, null, 1));
    }
    await ctx.close();
  }
  if (mode === 'usage' || mode === 'all') for (const run of [1, 2]) {
    let ctx, p, errs, U = { run, steps: [], exhaustedOnLoad: [] };
    for (let a = 0; a < 10; a++) { ({ ctx, p, errs } = await fresh(b)); const u0 = await usage(p); if (!/(^|[^0-9])0 remaining today/.test(u0.strip || '')) break; U.exhaustedOnLoad.push({ attempt: a + 1, time: now(), ...u0 }); await ctx.close(); }
    if (U.exhaustedOnLoad.length === 10) { U.blocked = 'all 10 fresh contexts loaded with 0 remaining today'; R.usageRuns.push(U); continue; }
    const step = async n => { await p.waitForTimeout(900); U.steps.push({ step: n, time: now(), ...(await usage(p)), toast: await toasts(p) }); };
    await step('on load');
    await p.locator('input[type=file]').first().setInputFiles(T + 'melody_12s.wav'); await step('after file 1 added');
    await p.locator('input[type=file]').last().setInputFiles(T + 'melody_12s_edit5to7.wav'); await step('after file 2 added');
    const r = await compare(p); U.result = { score: r.score, verdict: r.verdict, differs: r.differs }; await step('after Compare Audio');
    await p.getByRole('button', { name: 'Play file 1' }).click(); await p.waitForTimeout(1200); U.playLabel = await p.evaluate(() => [...document.querySelectorAll('[data-testid=compare-view] button')].map(b => b.innerText.trim()).filter(Boolean).slice(0, 4).join(' | '));
    await step('after Play file 1');
    await p.getByRole('button', { name: /Play file 2|Playing file 2|file 2/ }).first().click().catch(() => {}); await p.waitForTimeout(800); await step('after Play file 2 (switch)');
    const stopBtn = p.getByRole('button', { name: /^Stop$/ }); if (await stopBtn.count()) await stopBtn.first().click();
    const ml = p.getByLabel(/Match loudness/); if (await ml.count()) { U.matchLoudnessBefore = await ml.isChecked(); await ml.click(); U.matchLoudnessAfter = await ml.isChecked(); }
    await step('after toggling Match loudness');
    try { const [d] = await Promise.all([p.waitForEvent('download', { timeout: 15000 }), p.getByRole('button', { name: 'Download the difference (WAV)' }).click()]);
      const f = OUT + `run${run}-` + d.suggestedFilename(); await d.saveAs(f);
      U.download = { filename: d.suggestedFilename(), bytes: fs.statSync(f).size, ffprobe: cp.execSync(`ffprobe -v error -show_entries format=duration:stream=codec_name,sample_rate,channels -of compact "${f}"`).toString().trim(), volumedetect: cp.execSync(`ffmpeg -hide_banner -i "${f}" -af volumedetect -f null - 2>&1 | grep -E "mean_volume|max_volume"`).toString().trim(), toast: await toasts(p) };
      // energy per second of the difference file, to verify the 5-7 s edit is where the difference is
      U.download.perSecondRmsDb = cp.execSync(`ffmpeg -hide_banner -i "${f}" -af "asetnsamples=n=44100,astats=metadata=1:reset=1,ametadata=print:key=lavfi.astats.Overall.RMS_level" -f null - 2>&1 | grep RMS_level | sed 's/.*=//' | head -14 | tr '\\n' ' '`).toString().trim();
    } catch (e) { U.download = { error: e.message.split('\n')[0] }; }
    await step('after Download the difference (WAV)');
    await p.getByRole('button', { name: 'Copy result summary' }).click(); await p.waitForTimeout(600);
    U.summary = await p.evaluate(() => navigator.clipboard.readText().catch(e => 'ERR ' + e.message)); await step('after Copy result summary');
    await p.getByRole('button', { name: 'Share this tool' }).last().scrollIntoViewIfNeeded(); await p.evaluate(() => { navigator.share = undefined; });
    await p.getByRole('button', { name: 'Share this tool' }).last().click(); await p.waitForTimeout(800);
    U.share = { clipboard: await p.evaluate(() => navigator.clipboard.readText().catch(() => '')), dialog: await dialogs(p) }; await p.keyboard.press('Escape'); await step('after Share this tool');
    await p.screenshot({ path: OUT + `usage-run${run}-result.png`, fullPage: true });
    await p.getByRole('button', { name: 'Compare another pair' }).click(); await p.waitForTimeout(800);
    U.afterAnotherPair = await p.evaluate(() => document.querySelector('main').innerText.match(/Audio File 1[\s\S]{0,200}/)?.[0].replace(/\n+/g, ' | '));
    await step('after Compare another pair');
    await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500);
    U.afterReload = await p.evaluate(() => document.querySelector('main').innerText.match(/Audio File 1[\s\S]{0,200}/)?.[0].replace(/\n+/g, ' | '));
    await step('after reload');
    U.errors = errs; R.usageRuns.push(U); await ctx.close();
  }
  R.finished = now(); await b.close();
  const f = OUT + (mode === 'usage' ? 'usage-results.json' : mode === 'pairs' ? 'pairs-results.json' : 'functional-results.json');
  fs.writeFileSync(f, JSON.stringify(R, null, 1)); console.log('wrote', f, R.finished);
})();
