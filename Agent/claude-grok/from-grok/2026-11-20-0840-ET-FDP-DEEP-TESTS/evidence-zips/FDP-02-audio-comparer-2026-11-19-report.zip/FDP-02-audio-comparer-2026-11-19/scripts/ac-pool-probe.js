// Opens N fresh guest contexts (no actions) and records the trial strip, fdp-usage-v1 and the page's own usage.check responses (passive). Usage: node ac-pool-probe.js [N]
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const URL = 'https://www.freedailypro.com/tool/audio-comparer'; const N = +process.argv[2] || 4; const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const R = [];
  for (let i = 0; i < N; i++) { const ctx = await b.newContext(); const p = await ctx.newPage(); const bodies = [];
    p.on('response', async r => { if (/usage\.check/.test(r.url())) { try { bodies.push((await r.text()).slice(0, 400)); } catch {} } });
    await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
    const row = { i: i + 1, time: now(), strip: await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [null])[0]), ls: await p.evaluate(() => localStorage.getItem('fdp-usage-v1')), usageCheck: bodies };
    R.push(row); console.log(JSON.stringify(row).slice(0, 600)); await ctx.close(); }
  fs.writeFileSync('/workspace/deep/02-audio-comparer/live/pool-probe-' + Date.now() + '.json', JSON.stringify(R, null, 1)); await b.close(); })();
