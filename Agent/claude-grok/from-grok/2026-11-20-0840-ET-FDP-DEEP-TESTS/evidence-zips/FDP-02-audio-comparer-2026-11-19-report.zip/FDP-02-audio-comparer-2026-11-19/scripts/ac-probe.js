const {chromium}=require('playwright');const T='/workspace/deep/02-audio-comparer/testfiles/';(async()=>{const b=await chromium.launch();const c=await b.newContext({viewport:{width:1366,height:900}});const p=await c.newPage();p.on('console',m=>{if(m.type()==='error')console.log('CONSOLE',m.text().slice(0,150))});
await p.goto('https://www.freedailypro.com/tool/audio-comparer',{waitUntil:'domcontentloaded'});await p.waitForTimeout(4000);
console.log('inputs',await p.evaluate(()=>[...document.querySelectorAll('input[type=file]')].map(i=>({accept:i.accept,multiple:i.multiple,id:i.id,aria:i.getAttribute('aria-label')}))));
console.log('LS0',await p.evaluate(()=>localStorage.getItem('fdp-usage-v1')));
console.log('strip0',await p.evaluate(()=>(document.body.innerText.match(/[^\n]*(uses\/day|remaining today|trial use)[^\n]*/ig)||[]).slice(0,5)));
const fi=p.locator('input[type=file]');await fi.nth(0).setInputFiles(T+'melody_12s.wav');await p.waitForTimeout(800);
const fi2=p.locator('input[type=file]');console.log('n inputs after 1',await fi2.count());await fi2.last().setInputFiles(T+'melody_12s_edit5to7.wav');await p.waitForTimeout(800);
console.log('LS1',await p.evaluate(()=>localStorage.getItem('fdp-usage-v1')));
await p.getByRole('button',{name:/Compare Audio/}).click();await p.waitForTimeout(6000);
console.log('LS2',await p.evaluate(()=>localStorage.getItem('fdp-usage-v1')));
const main=await p.evaluate(()=>{const t=document.querySelector('main').innerText;const s=t.indexOf('Audio File 1');return t.slice(s,s+3500)});console.log(main);
console.log('buttons',await p.evaluate(()=>[...document.querySelectorAll('main button')].filter(e=>e.offsetParent).map(e=>(e.innerText.trim()||e.getAttribute('aria-label')||'').slice(0,50))));
await p.screenshot({path:'/workspace/deep/02-audio-comparer/live/probe-result.png',fullPage:true});await b.close()})()
