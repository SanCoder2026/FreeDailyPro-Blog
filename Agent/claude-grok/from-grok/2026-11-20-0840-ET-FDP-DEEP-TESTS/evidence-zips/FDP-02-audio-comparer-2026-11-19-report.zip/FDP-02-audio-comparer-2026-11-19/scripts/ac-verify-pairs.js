// Re-verify selected pairs, one fresh guest context per pair, full result text + usage trace. Usage: node ac-verify-pairs.js
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const URL = 'https://www.freedailypro.com/tool/audio-comparer', T = '/workspace/deep/02-audio-comparer/testfiles/', OUT = '/workspace/deep/02-audio-comparer/live/';
const PAIRS = JSON.parse(process.argv[2] || '[["a440_10s.wav","mix_440then880_10s.wav","v14b"],["mix_440then880_10s.wav","a440_10s.wav","v14c"]]');
(async () => { const b = await chromium.launch(); const R = [];
  for (const [f1, f2, tag] of PAIRS) {
    const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); const net = [];
    p.on('response', r => { if (/usage|trpc|logTool|track/i.test(r.url())) net.push(r.request().method() + ' ' + r.url().replace(/\?.*/, '').slice(0, 90) + ' ' + r.status()); });
    await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500);
    const ls0 = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
    await p.locator('input[type=file]').first().setInputFiles(T + f1); await p.waitForTimeout(600); await p.locator('input[type=file]').last().setInputFiles(T + f2); await p.waitForTimeout(600);
    const trace = []; await p.getByRole('button', { name: 'Compare Audio' }).click();
    for (let i = 0; i < 30; i++) { await p.waitForTimeout(300); trace.push(JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday); }
    const text = await p.evaluate(() => { const t = document.querySelector('main').innerText; const s = t.indexOf('Compare another pair'); return (s > 0 ? t.slice(s, s + 1400) : t.slice(0, 1500)).replace(/\n+/g, ' | '); });
    const strip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [null])[0]);
    await p.screenshot({ path: OUT + tag + '-full.png', fullPage: true });
    R.push({ tag, f1, f2, ls0, trace, strip, text: text.slice(0, 2500), net: net.slice(0, 12) }); await ctx.close();
    console.log(tag, f2, 'trace', trace.join(','), strip); }
  fs.writeFileSync(OUT + 'verify-pairs-' + Date.now() + '.json', JSON.stringify(R, null, 1)); await b.close(); })();
