#!/usr/bin/env bash
# Regenerates the audio-comparer test files with ffmpeg.
# The shipped files in evidence/testfiles/ are the exact ones used on 2026-11-19. These commands make
# equivalent files (same durations, rates and content types). They were rebuilt for this package
# because the original shell history was lost in a box restore, so exact byte equality is not guaranteed.
set -e
out=${1:-./testfiles}; mkdir -p "$out"; cd "$out"
F="ffmpeg -hide_banner -loglevel error -y"
$F -f lavfi -i "sine=frequency=440:duration=10:sample_rate=44100" -ac 1 a440_10s.wav           # amplitude 1/8, peak about -18 dBFS
cp a440_10s.wav a440_10s_copy.wav
$F -i a440_10s.wav a440_10s.mp3; $F -i a440_10s.wav a440_10s.ogg; $F -i a440_10s.wav a440_10s.m4a; $F -i a440_10s.wav a440_10s.flac
$F -i a440_10s.wav -ar 48000 -ac 2 a440_10s_48k_stereo.wav
$F -i a440_10s.wav -af volume=-12dB a440_10s_quiet.wav
$F -i a440_10s.wav -t 8 a440_8s_trim.wav
$F -i a440_10s.wav -af adelay=500 a440_offset05.wav                                              # 10.5 s, 0.5 s silent lead-in
$F -f lavfi -i "sine=frequency=880:duration=10:sample_rate=44100" -ac 1 b880_10s.wav
$F -f lavfi -i "sine=frequency=440:duration=5:sample_rate=44100" -f lavfi -i "sine=frequency=880:duration=5:sample_rate=44100" -filter_complex "[0][1]concat=n=2:v=0:a=1" -ac 1 mix_440then880_10s.wav
$F -f lavfi -i "anoisesrc=color=pink:duration=10:sample_rate=44100:amplitude=0.3" -ac 1 noise_pink_10s.wav
# melody: 12 one-second notes (C major scale up and back), louder than the sine files
$F -f lavfi -i "aevalsrc='0.35*sin(2*PI*t*(261.63*pow(2,floor(mod(t,12))/12*2)))':s=44100:d=12" -ac 1 melody_12s.wav
$F -i melody_12s.wav melody_12s.mp3
# melody with 0:05-0:07 replaced by pink noise
$F -i melody_12s.wav -f lavfi -i "anoisesrc=color=pink:duration=12:sample_rate=44100:amplitude=0.3" -filter_complex "[0]volume=enable='between(t,5,7)':volume=0[m];[1]volume=enable='not(between(t,5,7))':volume=0[n];[m][n]amix=inputs=2:normalize=0" -ac 1 melody_12s_edit5to7.wav
$F -f lavfi -i "sine=frequency=440:duration=300:sample_rate=44100" -ac 1 long_300s.mp3
$F -f lavfi -i "anoisesrc=color=pink:duration=60:sample_rate=44100:amplitude=0.3" -ac 1 noise60.wav
$F -i melody_12s.wav -i noise60.wav -filter_complex "[0][1]concat=n=2:v=0:a=1" melody_then_noise_72s.wav
$F -i noise60.wav -i melody_12s.wav -filter_complex "[0]atrim=0:20[a];[a][1]concat=n=2:v=0:a=1" noise20_then_melody_32s.wav
rm noise60.wav
$F -f lavfi -i "sine=frequency=330:duration=380:sample_rate=44100" -ac 2 oversized_380s_stereo.wav   # about 67 MB, triggers the >50 MB warning
head -c 200000 /dev/urandom > corrupt.mp3
printf 'this is not audio\n' > notaudio.wav
: > empty.wav
ls -la
