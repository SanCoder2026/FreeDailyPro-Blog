cd /workspace/deep/tools-env
node ac-functional.js usage
node ac-a11y-result.js
for t in 1 2 3 4; do node ac-verify-pairs.js '[["melody_12s.wav","melody_then_noise_72s.wav","v21r'$t'"],["melody_12s.wav","noise20_then_melody_32s.wav","v22r'$t'"],["melody_then_noise_72s.wav","melody_12s.wav","v23r'$t'"]]'; done
echo ALLDONE
