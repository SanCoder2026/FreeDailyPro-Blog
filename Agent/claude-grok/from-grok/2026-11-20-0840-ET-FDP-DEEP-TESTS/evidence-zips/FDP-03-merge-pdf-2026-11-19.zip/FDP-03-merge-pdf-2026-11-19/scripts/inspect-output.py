#!/usr/bin/env python3
"""Inspect merged PDFs: page count, order markers (pdftotext), size/rotation per page, metadata, outline, AcroForm, encryption, watermark text."""
import sys, subprocess, json, re, pikepdf
def inspect(path):
    R = {'file': path.split('/')[-1]}
    with pikepdf.open(path) as pdf:
        R['pages'] = len(pdf.pages); R['encrypted'] = pdf.is_encrypted; R['pdf_version'] = pdf.pdf_version
        R['docinfo'] = {str(k): str(v) for k, v in pdf.docinfo.items()}
        R['acroform_fields'] = len(pdf.Root.AcroForm.Fields) if '/AcroForm' in pdf.Root and '/Fields' in pdf.Root.AcroForm else 0
        R['widget_annots'] = sum(1 for pg in pdf.pages for a in (pg.get('/Annots') or []) if a.get('/Subtype') == '/Widget')
        sizes = []
        for pg in pdf.pages:
            mb = [float(x) for x in pg.mediabox]; sizes.append(f"{round(mb[2]-mb[0])}x{round(mb[3]-mb[1])}" + (f" r{int(pg.get('/Rotate', 0))}" if int(pg.get('/Rotate', 0)) else ''))
        R['page_sizes'] = sizes
        def walk(items, lvl=0, out=None):
            out = [] if out is None else out
            for it in items:
                out.append('  ' * lvl + str(it.title)); walk(it.children, lvl + 1, out)
            return out
        with pdf.open_outline() as ol: R['outline'] = walk(ol.root)
    markers = []
    for i in range(1, R['pages'] + 1):
        t = subprocess.run(['pdftotext', '-f', str(i), '-l', str(i), '-layout', path, '-'], capture_output=True, text=True).stdout
        m = re.search(r'FILE (\w+) P(\d+)', t); markers.append(f"{m.group(1)}{m.group(2)}" if m else ('blank' if not t.strip() else 'other:' + t.strip()[:30]))
        if i == 1: R['p1_text'] = t.strip()[:300]
    R['order'] = markers
    alltext = subprocess.run(['pdftotext', path, '-'], capture_output=True, text=True).stdout
    R['watermark_text_found'] = bool(re.search(r'Created with|FreeDailyPro', alltext, re.I))
    R['nonlatin_sample'] = [l for l in alltext.splitlines() if re.search(r'[\u3040-\u30ff\u4e00-\u9fff\u0400-\u04ff\u0600-\u06ff]', l)][:3]
    R['pdfinfo'] = subprocess.run(['pdfinfo', path], capture_output=True, text=True).stdout
    return R
if __name__ == '__main__':
    out = [inspect(p) for p in sys.argv[1:]]
    for r in out:
        r2 = dict(r); r2.pop('pdfinfo'); print(json.dumps(r2, ensure_ascii=False))
    json.dump(out, open('/workspace/deep/03-merge-pdf/live/output-inspection.json', 'w'), ensure_ascii=False, indent=1)
