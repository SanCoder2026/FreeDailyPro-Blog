#!/usr/bin/env python3
"""Generates the merge-pdf test files. Run with a Python that has reportlab, pypdf, pikepdf, Pillow.
Every page prints a unique marker 'FILE <id> P<n>' so page order in a merged output can be checked with pdftotext."""
import os, sys, io, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, letter, A3, landscape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import pikepdf
out = sys.argv[1] if len(sys.argv) > 1 else './testfiles'; os.makedirs(out, exist_ok=True); os.chdir(out)
pdfmetrics.registerFont(TTFont('JP', '/usr/share/fonts/truetype/sand-box/google/BIZ UDPMincho/BIZUDPMincho-Regular.ttf'))
pdfmetrics.registerFont(TTFont('DV', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))

def make(name, fid, pages, size=A4, title=None, author='FDP QA', outline=False, sizes=None, extra=None):
    c = canvas.Canvas(name, pagesize=size)
    c.setTitle(title or f'Test file {fid}'); c.setAuthor(author); c.setSubject('merge-pdf QA'); c.setKeywords('fdp qa')
    for i in range(1, pages + 1):
        if sizes: c.setPageSize(sizes[(i - 1) % len(sizes)])
        w, h = c._pagesize
        c.setFont('Helvetica-Bold', 28); c.drawString(50, h - 80, f'FILE {fid} P{i}')
        c.setFont('Helvetica', 12); c.drawString(50, h - 110, f'{name} page {i} of {pages}  size {int(w)}x{int(h)} pt')
        if extra: extra(c, i, w, h)
        if outline:
            c.bookmarkPage(f'{fid}p{i}'); c.addOutlineEntry(f'{fid} chapter {i}', f'{fid}p{i}', level=0)
        c.showPage()
    c.save()

make('A_a4_3p.pdf', 'A', 3, A4, title='Alpha A4 three pages')
make('B_letter_2p.pdf', 'B', 2, letter, title='Bravo Letter two pages')
make('C_landscape_a4_2p.pdf', 'C', 2, landscape(A4), title='Charlie landscape')
make('D_mixed_sizes_4p.pdf', 'D', 4, sizes=[A4, landscape(letter), A3, (300, 300)], title='Delta mixed sizes')
make('E_bookmarks_5p.pdf', 'E', 5, A4, title='Echo with bookmarks', outline=True)
make('F_large_500p.pdf', 'F', 500, A4, title='Foxtrot 500 pages')
def nonlatin(c, i, w, h):
    c.setFont('JP', 20); c.drawString(50, h - 160, '日本語のテキスト 請求書 第%d頁' % i)
    c.setFont('DV', 18); c.drawString(50, h - 200, 'Русский текст · Ελληνικά · العربية · Türkçe çğış')
make('G_nonlatin_2p.pdf', 'G', 2, A4, title='日本語 タイトル – Ünïcødé', author='山田 太郎', extra=nonlatin)
# rotated page via /Rotate (page 2 rotated 90)
make('H_rotate_src.pdf', 'H', 3, A4, title='Hotel rotated page 2')
with pikepdf.open('H_rotate_src.pdf') as p:
    p.pages[1].Rotate = 90; p.save('H_rotated_p2_3p.pdf')
os.remove('H_rotate_src.pdf')
# AcroForm
c = canvas.Canvas('I_form_1p.pdf', pagesize=A4); c.setTitle('India form')
c.setFont('Helvetica-Bold', 28); c.drawString(50, 760, 'FILE I P1'); c.setFont('Helvetica', 12); c.drawString(50, 720, 'Name:')
c.acroForm.textfield(name='fullname', x=100, y=700, width=250, height=24, value='Jane Example')
c.acroForm.checkbox(name='agree', x=100, y=660, checked=True); c.drawString(130, 665, 'I agree')
c.showPage(); c.save()
# Encrypted: user password (needs password to open)
make('J_src.pdf', 'J', 2, A4, title='Juliet encrypted')
with pikepdf.open('J_src.pdf') as p:
    p.save('J_password_user123_2p.pdf', encryption=pikepdf.Encryption(user='user123', owner='owner456', R=6))
    p.save('K_owner_only_restricted_2p.pdf', encryption=pikepdf.Encryption(user='', owner='owner456', R=6, allow=pikepdf.Permissions(extract=False, modify_assembly=False, modify_other=False, print_highres=False)))
os.remove('J_src.pdf')
# Corrupt: truncated real PDF, and header-only garbage
data = open('A_a4_3p.pdf', 'rb').read(); open('L_truncated.pdf', 'wb').write(data[: len(data) // 2])
open('M_garbage_header.pdf', 'wb').write(b'%PDF-1.7\n' + bytes(random.Random(1).getrandbits(8) for _ in range(5000)))
# Non-PDF renamed to .pdf
open('N_text_renamed.pdf', 'w').write('This is a plain text file, not a PDF.\n')
from PIL import Image
img = Image.new('RGB', (800, 600), (30, 120, 200)); img.save('O_png_renamed.pdf', format='PNG')
open('P_empty.pdf', 'wb').close()
# Real images (the tool accepts JPG/PNG)
img.save('Q_image.jpg', quality=85); Image.new('RGB', (600, 900), (200, 60, 60)).save('R_image_portrait.png')
# Same file twice is done at upload time; one-page tiny file
make('S_one_page.pdf', 'S', 1, A4, title='Sierra one page')
print('\n'.join(sorted(os.listdir('.'))))
