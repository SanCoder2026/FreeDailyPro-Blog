const { chromium } = require('playwright'); const fs = require('fs');
const OUT = '/workspace/deep/03-merge-pdf/live/'; const T = '/workspace/deep/03-merge-pdf/testfiles/';
(async () => {
  const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); const R = {};
  await p.goto('https://www.freedailypro.com/tool/merge-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  await p.locator('input[type=file]').first().setInputFiles([T + 'A_a4_3p.pdf', T + 'B_letter_2p.pdf']); await p.waitForTimeout(3000);
  const before = await p.evaluate(() => [...document.querySelectorAll('main button')].map(e => e.getAttribute('aria-label') || e.innerText.trim()));
  await p.getByRole('button', { name: /^Arrange all pages/ }).click(); await p.waitForTimeout(4000);
  const after = await p.evaluate(() => [...document.querySelectorAll('main button, main [role=listitem], main [aria-label]')].map(e => e.getAttribute('aria-label') || e.innerText.trim()).filter(Boolean));
  R.arrangeNew = after.filter(x => !before.includes(x)).slice(0, 60);
  R.arrangeText = await p.evaluate(() => { const m = document.querySelector('main').innerText; const i = m.indexOf('Arrange all pages'); return m.slice(i, i + 1200); });
  await p.screenshot({ path: OUT + 'ui-arrange.png', fullPage: true });
  // do arrange ops: move B p1 earlier twice, rotate A p1 right, delete? find delete
  R.ops = [];
  for (const name of ['Move B_letter_2p.pdf page 1 earlier', 'Rotate A_a4_3p.pdf page 1 right']) { const l = p.getByRole('button', { name }); R.ops.push(name + ':' + await l.count()); }
  R.deleteLike = after.filter(x => /delete|remove|leave out|trash/i.test(x)).slice(0, 10);
  R.startOver = after.filter(x => /start over|reset|done|apply/i.test(x)).slice(0, 10);
  // choose pages
  await p.getByRole('button', { name: /^Choose pages/ }).first().click(); await p.waitForTimeout(3000);
  R.chooseText = await p.evaluate(() => { const d = document.querySelector('[role=dialog]'); return d ? 'DIALOG: ' + d.innerText.slice(0, 1000) : document.querySelector('main').innerText.slice(0, 0); });
  R.chooseBtns = await p.evaluate(() => { const d = document.querySelector('[role=dialog]') || document.querySelector('main'); return [...d.querySelectorAll('button')].map(e => e.getAttribute('aria-label') || e.innerText.trim()).filter(x => /page|rotate|leave|include|done|apply|cancel/i.test(x)).slice(0, 30); });
  await p.screenshot({ path: OUT + 'ui-choose-pages.png' });
  fs.writeFileSync(OUT + 'arrange-probe.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close();
})();
