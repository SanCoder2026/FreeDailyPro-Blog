// merge-pdf download battery in ONE uncapped fresh context (each download may spend a trial use). Records strip before/after every step.
// Usage: node mp-battery.js [maxContextsToTry=6] [onlyScenarios comma list]
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/03-merge-pdf/live/'; const DL = OUT + 'downloads/'; const T = '/workspace/deep/03-merge-pdf/testfiles/'; fs.mkdirSync(DL, { recursive: true });
const URL = 'https://www.freedailypro.com/tool/merge-pdf';
const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
const maxTry = +(process.argv[2] || 6); const only = (process.argv[3] || '').split(',').filter(Boolean);
(async () => {
  const b = await chromium.launch(); const R = { started: now(), loads: [], scenarios: [] }; let ctx, p;
  const strip = () => p.evaluate(() => (document.body.innerText.match(/[^\n]*remaining today[^\n]*/) || [''])[0]);
  const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || 'null')?.usageToday;
  const toasts = () => p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(t => t.innerText.replace(/\n/g, ' ')).join(' | '));
  const dialogs = () => p.evaluate(() => [...document.querySelectorAll('[role=dialog],[role=alertdialog]')].map(t => t.innerText.replace(/\n+/g, ' | ').slice(0, 300)).join(' || '));
  for (let a = 0; a < maxTry; a++) {
    ctx = await b.newContext({ acceptDownloads: true, viewport: { width: 1366, height: 900 }, permissions: ['clipboard-read', 'clipboard-write'] }); p = await ctx.newPage();
    await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); const s = await strip(); R.loads.push({ attempt: a + 1, t: now(), strip: s, used: await used() });
    if (!/(^|[^0-9])0 remaining today/.test(s)) break; await ctx.close(); ctx = null;
  }
  if (!ctx) { R.blocked = `all ${maxTry} fresh contexts loaded at 0 remaining today`; fs.writeFileSync(OUT + `battery-${Date.now()}.json`, JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); return; }
  const add = async files => { await p.locator('input[type=file]').first().setInputFiles(files.map(f => T + f)); await p.waitForTimeout(3000); };
  const S = {
    S1_order_reorder: async L => { await add(['A_a4_3p.pdf', 'B_letter_2p.pdf', 'C_landscape_a4_2p.pdf', 'D_mixed_sizes_4p.pdf']); await p.getByRole('button', { name: 'Move down' }).first().click(); await p.waitForTimeout(800); L.list = await p.evaluate(() => (document.querySelector('main').innerText.match(/\d+ files · \d+ pages[\s\S]{0,400}/) || [''])[0]); L.expect = 'B1 B2 A1 A2 A3 C1 C2 D1 D2 D3 D4'; },
    S2_bookmarks_meta_nonlatin_form_rotate: async L => { await add(['E_bookmarks_5p.pdf', 'G_nonlatin_2p.pdf', 'I_form_1p.pdf', 'H_rotated_p2_3p.pdf']); L.expect = 'E1-5 G1-2 I1 H1-3; H2 /Rotate 90 kept; bookmarks: per-file top level + E chapters'; },
    S3_ranges_blankpage: async L => { await add(['A_a4_3p.pdf', 'B_letter_2p.pdf', 'S_one_page.pdf']); await p.getByLabel('Pages to use from A_a4_3p.pdf').fill('2-3'); await p.getByLabel('Pages to use from B_letter_2p.pdf').fill('1'); await p.getByLabel(/Add a blank page after any file/).check(); await p.waitForTimeout(800); L.expect = 'A2 A3 | B1 blank | S1 (blank?)'; },
    S4_arrange_move_rotate_delete: async L => { await add(['A_a4_3p.pdf', 'B_letter_2p.pdf']); await p.getByRole('button', { name: /^Arrange all pages/ }).click(); await p.waitForTimeout(3500);
      await p.getByRole('button', { name: 'Move Page 4, B_letter_2p.pdf page 1 earlier' }).click(); await p.waitForTimeout(500);
      const lab = await p.evaluate(() => [...document.querySelectorAll('button[aria-label^="Move Page 3,"]')].map(e => e.getAttribute('aria-label'))); L.afterMove1 = lab;
      await p.getByRole('button', { name: /^Move Page 3, B_letter_2p.pdf page 1 earlier$/ }).click(); await p.waitForTimeout(500);
      await p.getByRole('button', { name: /^Rotate Page 1, A_a4_3p.pdf page 1 right$/ }).click(); await p.waitForTimeout(500);
      await p.getByRole('button', { name: /^Delete Page 5, B_letter_2p.pdf page 2$/ }).click(); await p.waitForTimeout(500);
      L.arranged = await p.evaluate(() => { const m = document.querySelector('main').innerText; const i = m.indexOf('Arrange all pages —'); return m.slice(i, i + 300); });
      await p.getByRole('button', { name: 'Done' }).first().click(); await p.waitForTimeout(800); L.expect = 'A1(rotated 90) B1 A2 A3'; },
    S5_images: async L => { await add(['Q_image.jpg', 'R_image_portrait.png', 'S_one_page.pdf']); L.expect = 'Q on Letter landscape, R on Letter portrait, S1'; },
    S6_password_restricted: async L => { await p.locator('input[type=file]').first().setInputFiles([T + 'A_a4_3p.pdf', T + 'J_password_user123_2p.pdf', T + 'K_owner_only_restricted_2p.pdf']); await p.waitForTimeout(2500);
      const pw = p.locator('input[type=password]'); if (await pw.count()) { await pw.first().fill('user123'); await p.keyboard.press('Enter'); } await p.waitForTimeout(3000); L.toast = await toasts(); L.expect = 'A1-3 J1-2 K1-2, output not encrypted'; },
    S7_large_500: async L => { const t0 = Date.now(); await add(['F_large_500p.pdf', 'A_a4_3p.pdf']); L.addMs = Date.now() - t0; L.expect = 'F1-500 A1-3 = 503 pages'; },
    S8_choose_pages: async L => { await add(['A_a4_3p.pdf', 'B_letter_2p.pdf']); await p.getByRole('button', { name: /^Choose pages/ }).first().click(); await p.waitForTimeout(3000);
      await p.getByRole('button', { name: 'Page 2, included' }).first().click(); await p.waitForTimeout(400); await p.getByRole('button', { name: 'Rotate page 3 right' }).first().click(); await p.waitForTimeout(400);
      await p.getByRole('button', { name: 'Done' }).first().click(); await p.waitForTimeout(800); L.list = await p.evaluate(() => (document.querySelector('main').innerText.match(/\d+ files · \d+ pages[\s\S]{0,300}/) || [''])[0]); L.expect = 'A1 A3(rot 90) B1 B2'; },
  };
  for (const [name, fn] of Object.entries(S)) {
    if (only.length && !only.includes(name)) continue;
    const L = { name, t0: now() };
    try {
      await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); L.before = await strip(); L.usedBefore = await used();
      await fn(L); L.afterSetup = await strip();
      const t1 = Date.now(); await p.getByRole('button', { name: /^Merge \d+ PDFs$/ }).click(); await p.getByRole('button', { name: /Download Merged PDF|Get a Day Pass/ }).first().waitFor({ timeout: 120000 }).catch(() => {}); L.mergeMs = Date.now() - t1;
      L.afterMerge = await strip(); L.usedAfterMerge = await used(); L.toast = (L.toast ? L.toast + ' // ' : '') + await toasts();
      L.resultArea = await p.evaluate(() => { const m = document.querySelector('main').innerText; const i = m.indexOf('Merged PDF'); return i >= 0 ? m.slice(i, i + 400) : ''; });
      const dl = p.getByRole('button', { name: /Download Merged PDF/ });
      if (await dl.count()) { try { const [d] = await Promise.all([p.waitForEvent('download', { timeout: 15000 }), dl.first().click()]); const f = DL + name + '__' + d.suggestedFilename(); await d.saveAs(f); L.download = { name: d.suggestedFilename(), file: f, bytes: fs.statSync(f).size }; } catch (e) { L.download = 'no download: ' + e.message.split('\n')[0]; } }
      else L.download = 'no Download button';
      await p.waitForTimeout(1500); L.afterDownload = await strip(); L.usedAfterDownload = await used(); L.dialog = await dialogs(); L.toastAfterDl = await toasts();
      await p.screenshot({ path: OUT + 'bat-' + name + '.png', fullPage: false });
    } catch (e) { L.error = e.message.split('\n')[0]; await p.screenshot({ path: OUT + 'bat-' + name + '-error.png' }).catch(() => {}); }
    L.t1 = now(); R.scenarios.push(L); console.log(name, '|', L.before, '->', L.afterDownload, '|', JSON.stringify(L.download), L.error || '');
    if (/0 remaining today/.test(L.afterDownload || '') && !/(^|[^0-9])[1-9]\d* remaining/.test(L.afterDownload)) { if (/(^|[^0-9])0 remaining today/.test(L.afterDownload)) { R.stoppedAt = name + ' (0 remaining)'; break; } }
  }
  // post: share + reload + cloud save buttons (no sign-in)
  try { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); R.afterReload = { strip: await strip(), used: await used() };
    await p.evaluate(() => { navigator.share = undefined; }); await p.getByRole('button', { name: 'Share this tool' }).last().click(); await p.waitForTimeout(900); R.share = { clip: await p.evaluate(() => navigator.clipboard.readText().catch(() => '')), toast: await toasts(), strip: await strip() }; } catch (e) { R.postErr = e.message.split('\n')[0]; }
  R.finished = now(); const f = OUT + `battery-${Date.now()}.json`; fs.writeFileSync(f, JSON.stringify(R, null, 1)); console.log('wrote', f); await b.close();
})();
