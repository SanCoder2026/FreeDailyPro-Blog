// keyboard operability + sign-in-gated buttons (records where they lead; never signs in)
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/03-merge-pdf/live/'; const T = '/workspace/deep/03-merge-pdf/testfiles/';
const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); const R = { t: now() };
  await p.goto('https://www.freedailypro.com/tool/merge-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  R.strip = await p.evaluate(() => (document.body.innerText.match(/[^\n]*remaining today[^\n]*/) || [''])[0]);
  const dz = p.locator('main [role=button]').filter({ hasText: 'Drop PDF files' }).first(); R.dzCount = await dz.count();
  R.dz = await dz.evaluate(e => ({ tabindex: e.getAttribute('tabindex'), label: e.getAttribute('aria-label') })).catch(() => null);
  await dz.focus().catch(() => {}); try { const [fc] = await Promise.all([p.waitForEvent('filechooser', { timeout: 4000 }), p.keyboard.press('Enter')]); R.enterOpensChooser = true; await fc.setFiles([T + 'A_a4_3p.pdf', T + 'B_letter_2p.pdf']); } catch { R.enterOpensChooser = false; await p.locator('input[type=file]').first().setInputFiles([T + 'A_a4_3p.pdf', T + 'B_letter_2p.pdf']); }
  await p.waitForTimeout(3000);
  await p.getByRole('button', { name: 'Move down' }).first().focus(); await p.keyboard.press('Enter'); await p.waitForTimeout(600);
  R.orderAfterKbdMove = await p.evaluate(() => (document.querySelector('main').innerText.match(/\d+ files · \d+ pages[\s\S]{0,120}/) || [''])[0].replace(/\n/g, ' '));
  R.focusAfterMove = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('aria-label') || e.innerText || '').slice(0, 40); });
  R.liveRegions = await p.evaluate(() => [...document.querySelectorAll('[aria-live],[role=status]')].map(e => e.getAttribute('aria-live') + ':' + e.innerText.slice(0, 100)).filter(x => x.length > 7));
  R.dragHandle = await p.evaluate(() => { const h = document.querySelector('button[aria-label^="Drag to reorder"]'); return h ? { label: h.getAttribute('aria-label'), roledesc: h.getAttribute('aria-roledescription'), describedby: h.getAttribute('aria-describedby') } : null; });
  await p.getByRole('button', { name: /^Merge \d+ PDFs$/ }).click(); await p.waitForTimeout(3000);
  R.focusAfterMerge = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('aria-label') || e.innerText || '').slice(0, 40); });
  R.resultButtons = await p.evaluate(() => [...document.querySelectorAll('main button, main a')].map(e => e.getAttribute('aria-label') || e.innerText.trim()).filter(x => /drive|cloud|download|continue|day pass/i.test(x)));
  await p.addScriptTag({ path: require.resolve('axe-core/axe.min.js') });
  R.axeResult = await p.evaluate(async () => (await axe.run(document.querySelector('main'), { resultTypes: ['violations'] })).violations.map(v => ({ id: v.id, impact: v.impact, count: v.nodes.length, sample: v.nodes.slice(0, 2).map(n => n.target.join(' ') + ' :: ' + (n.failureSummary || '').split('\n')[1]) })));
  await p.screenshot({ path: OUT + 'kbd-result-view.png', fullPage: true });
  // sign-in gated buttons: record what opens, close it
  for (const name of [/Save to my cloud storage/, /Save to Google Drive/]) {
    const btn = p.getByRole('button', { name }); if (!(await btn.count())) { R[String(name)] = 'not present'; continue; }
    const pop = ctx.waitForEvent('page', { timeout: 5000 }).catch(() => null); const urlBefore = p.url();
    await btn.first().click(); await p.waitForTimeout(2500); const np = await pop;
    R[String(name)] = { popup: np ? np.url().slice(0, 160) : null, sameTabUrl: p.url() !== urlBefore ? p.url() : null, dialog: await p.evaluate(() => [...document.querySelectorAll('[role=dialog]')].map(d => d.innerText.replace(/\n+/g, ' | ').slice(0, 400)).join(' || ')), toast: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(t => t.innerText.replace(/\n/g, ' ')).join(' | ')) };
    if (np) await np.close(); await p.keyboard.press('Escape'); if (p.url() !== urlBefore) await p.goBack();
  }
  fs.writeFileSync(OUT + 'kbd-cloud.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close();
})();
