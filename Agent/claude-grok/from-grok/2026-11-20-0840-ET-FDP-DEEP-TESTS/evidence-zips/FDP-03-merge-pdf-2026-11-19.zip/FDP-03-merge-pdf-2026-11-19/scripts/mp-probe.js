// merge-pdf: one fresh context, no merge. Records strip, controls after adding 2 files.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/03-merge-pdf/live/'; const T = '/workspace/deep/03-merge-pdf/testfiles/';
const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); const R = { t: now() };
  const js = new Set(); p.on('response', r => { const u = r.url(); if (/\/assets\/.*\.js/.test(u)) js.add(u); });
  await p.goto('https://www.freedailypro.com/tool/merge-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
  R.strip = await p.evaluate(() => (document.body.innerText.match(/[^\n]*(remaining today|uses\/day)[^\n]*/g) || []).join(' || '));
  R.ls = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
  R.inputs = await p.evaluate(() => [...document.querySelectorAll('input[type=file]')].map(i => ({ accept: i.accept, multiple: i.multiple, capture: i.getAttribute('capture') })));
  await p.locator('input[type=file]').first().setInputFiles([T + 'A_a4_3p.pdf', T + 'B_letter_2p.pdf', T + 'E_bookmarks_5p.pdf']); await p.waitForTimeout(3000);
  R.main = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 4000));
  R.buttons = await p.evaluate(() => [...document.querySelectorAll('main button, main input, main [role=button], main label')].map(e => (e.tagName + ':' + (e.getAttribute('aria-label') || e.innerText || e.placeholder || e.type || '').trim().slice(0, 50))).filter((x, i, a) => a.indexOf(x) === i));
  await p.screenshot({ path: OUT + 'probe-3files.png', fullPage: true });
  R.js = [...js]; fs.writeFileSync(OUT + 'probe.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1).slice(0, 9000)); await b.close();
})();
