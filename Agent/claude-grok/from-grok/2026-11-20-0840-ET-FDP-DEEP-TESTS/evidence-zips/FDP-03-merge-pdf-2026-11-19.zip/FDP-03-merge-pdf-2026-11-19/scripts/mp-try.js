const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/03-merge-pdf/live/'; const T = '/workspace/deep/03-merge-pdf/testfiles/';
const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ acceptDownloads: true, viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); const R = { t: now(), steps: [] };
  const net = []; p.on('request', r => { if (/trpc\/usage|upload/i.test(r.url())) net.push(r.method() + ' ' + r.url().replace(/\?.*/, '')); });
  const st = async n => R.steps.push({ n, t: now(), strip: await p.evaluate(() => (document.body.innerText.match(/[^\n]*remaining today[^\n]*/) || [''])[0]), ls: JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || 'null')?.usageToday, toast: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(t => t.innerText.replace(/\n/g, ' ')).join(' | ')), dialog: await p.evaluate(() => [...document.querySelectorAll('[role=dialog],[role=alertdialog]')].map(t => t.innerText.replace(/\n+/g, ' | ').slice(0, 600)).join(' || ')) });
  await p.goto('https://www.freedailypro.com/tool/merge-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); await st('load');
  await p.locator('input[type=file]').first().setInputFiles([T + 'A_a4_3p.pdf', T + 'B_letter_2p.pdf']); await p.waitForTimeout(2500); await st('added A,B');
  await p.getByRole('button', { name: /^Merge \d+ PDFs$/ }).click(); await p.waitForTimeout(4000); await st('after Merge');
  R.afterMerge = await p.evaluate(() => document.querySelector('main').innerText.match(/Merge[\s\S]{0,600}/g)?.slice(-2));
  const dl = p.getByRole('button', { name: /Download Merged PDF/ });
  if (await dl.count()) { try { const [d] = await Promise.all([p.waitForEvent('download', { timeout: 8000 }), dl.first().click()]); const f = OUT + 'try-' + d.suggestedFilename(); await d.saveAs(f); R.download = { name: d.suggestedFilename(), bytes: fs.statSync(f).size }; } catch (e) { R.download = 'no download: ' + e.message.split('\n')[0]; } await p.waitForTimeout(1500); await st('after Download click'); }
  await p.screenshot({ path: OUT + 'try-after.png', fullPage: false });
  R.net = net; fs.writeFileSync(OUT + 'try.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close();
})();
