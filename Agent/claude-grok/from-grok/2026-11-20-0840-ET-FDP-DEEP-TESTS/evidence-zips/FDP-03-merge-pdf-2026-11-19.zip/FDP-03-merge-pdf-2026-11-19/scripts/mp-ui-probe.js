// merge-pdf UI probe that needs no download (works in a capped context): errors, password, duplicate, forms, ranges, arrange, choose pages
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/03-merge-pdf/live/'; const T = '/workspace/deep/03-merge-pdf/testfiles/';
const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); const R = { t: now(), cases: [] };
  const cons = []; p.on('console', m => { if (m.type() === 'error') cons.push(m.text().slice(0, 200)); }); p.on('pageerror', e => cons.push('pageerror ' + e.message.slice(0, 200)));
  const toasts = () => p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(t => t.innerText.replace(/\n/g, ' ')).join(' | '));
  const dialogs = () => p.evaluate(() => [...document.querySelectorAll('[role=dialog],[role=alertdialog]')].map(t => t.innerText.replace(/\n+/g, ' | ').slice(0, 700)).join(' || '));
  const list = () => p.evaluate(() => { const m = document.querySelector('main').innerText; const i = m.indexOf(' files ·'); const j = m.search(/files? · \d+ pages?/); return m.slice(Math.max(0, j - 10), j + 900); });
  const go = async () => { await p.goto('https://www.freedailypro.com/tool/merge-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); };
  const add = async files => { await p.locator('input[type=file]').first().setInputFiles(files.map(f => T + f)); await p.waitForTimeout(3000); };
  const rec = async (name, extra = {}) => { R.cases.push({ name, t: now(), toast: await toasts(), dialog: await dialogs(), list: await list(), ...extra }); };
  await go(); R.strip = await p.evaluate(() => (document.body.innerText.match(/[^\n]*remaining today[^\n]*/) || [''])[0]);
  // 1 errors
  await add(['A_a4_3p.pdf', 'L_truncated.pdf', 'M_garbage_header.pdf', 'N_text_renamed.pdf', 'O_png_renamed.pdf', 'P_empty.pdf']); await rec('A + corrupt/renamed/empty');
  await p.screenshot({ path: OUT + 'ui-errors.png', fullPage: false });
  const mb = p.getByRole('button', { name: /^Merge/ }); R.mergeBtnWithErrors = await mb.first().innerText().catch(() => null); R.mergeDisabled = await mb.first().isDisabled().catch(() => null);
  await mb.first().click().catch(() => {}); await p.waitForTimeout(3000); await rec('click Merge with 1 valid + 5 bad');
  // 2 docx-like & txt with other extension
  await go(); fs.writeFileSync('/tmp/notes.txt', 'hello'); await p.locator('input[type=file]').first().setInputFiles(['/tmp/notes.txt']).catch(e => R.txtErr = e.message.slice(0, 100)); await p.waitForTimeout(1500); await rec('.txt file (wrong extension)');
  // 3 password
  await go(); await add(['A_a4_3p.pdf', 'J_password_user123_2p.pdf']); await rec('password file added'); await p.screenshot({ path: OUT + 'ui-password-prompt.png' });
  const pw = p.locator('[role=dialog] input[type=password], input[type=password]');
  if (await pw.count()) { await pw.first().fill('wrong'); await p.keyboard.press('Enter'); await p.waitForTimeout(1500); await rec('wrong password'); await p.screenshot({ path: OUT + 'ui-password-wrong.png' });
    if (await pw.count()) { await pw.first().fill('user123'); await p.keyboard.press('Enter'); await p.waitForTimeout(2500); await rec('right password'); } }
  // 4 owner-only restricted
  await go(); await add(['A_a4_3p.pdf', 'K_owner_only_restricted_2p.pdf']); await rec('owner-only restricted'); 
  // 5 duplicate + form
  await go(); await add(['A_a4_3p.pdf', 'I_form_1p.pdf']); await add(['A_a4_3p.pdf']); await rec('duplicate A + form I'); await p.screenshot({ path: OUT + 'ui-duplicate-form.png' });
  // 6 page range validation
  const rng = p.getByLabel(/Pages to use from A_a4_3p.pdf/).first(); for (const v of ['2-3', '5', '3-1', 'abc', '1,1,2', '0']) { await rng.fill(v); await p.waitForTimeout(700); R.cases.push({ name: 'range ' + v, list: (await list()).slice(0, 400), invalid: await rng.evaluate(e => e.className.includes('border-red') || e.getAttribute('aria-invalid')), msg: await p.evaluate(() => [...document.querySelectorAll('main [id*=error], main .text-red-500, main .text-destructive')].map(e => e.innerText).join(' | ')) }); }
  await rng.fill('');
  // 7 Arrange all pages UI
  await go(); await add(['A_a4_3p.pdf', 'B_letter_2p.pdf']); await p.getByRole('button', { name: /^Arrange all pages/ }).click(); await p.waitForTimeout(3500);
  R.arrange = await p.evaluate(() => [...document.querySelectorAll('[role=dialog] button, [role=dialog] [aria-label]')].map(e => e.getAttribute('aria-label') || e.innerText.trim()).filter(Boolean).slice(0, 40));
  R.arrangeText = await dialogs(); await p.screenshot({ path: OUT + 'ui-arrange.png' });
  await p.keyboard.press('Escape'); await p.waitForTimeout(500);
  // 8 Choose pages UI
  await p.getByRole('button', { name: /^Choose pages/ }).first().click(); await p.waitForTimeout(3000); R.choose = await dialogs(); R.chooseBtns = await p.evaluate(() => [...document.querySelectorAll('[role=dialog] button')].map(e => e.getAttribute('aria-label') || e.innerText.trim()).filter(Boolean).slice(0, 30)); await p.screenshot({ path: OUT + 'ui-choose-pages.png' }); await p.keyboard.press('Escape');
  // 9 Clear all + reload persistence
  await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); R.afterReload = (await list()).slice(0, 200) || 'empty';
  R.console = cons.slice(0, 20); fs.writeFileSync(OUT + 'ui-probe.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close();
})();
