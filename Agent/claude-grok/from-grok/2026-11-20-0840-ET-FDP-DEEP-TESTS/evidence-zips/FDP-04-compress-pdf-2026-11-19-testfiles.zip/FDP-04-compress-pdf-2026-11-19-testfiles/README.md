# FDP-04 Compress PDF: test inputs

These are the inputs used on 2026-11-19. A_photos_6p (18 MB), I_cmyk_2p (10 MB) and J_big_24p (72 MB) are left out for size. Regenerate all 17 with `scripts/make-testpdfs.py` from the main zip; it is seeded, so it produces the same files.

- E_password_user123_2p.pdf: open password `user123`, owner password `owner456`.
- F_owner_restricted_2p.pdf: no open password; owner restrictions only.
