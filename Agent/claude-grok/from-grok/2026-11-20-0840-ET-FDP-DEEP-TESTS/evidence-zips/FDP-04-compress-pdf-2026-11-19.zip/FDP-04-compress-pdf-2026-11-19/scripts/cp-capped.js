// compress-pdf: in a (likely capped) fresh context, run Balanced on A and record what is gated where. Never types email/card.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/04-compress-pdf/live/'; const T = '/workspace/deep/04-compress-pdf/testfiles/';
const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ acceptDownloads: true, viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); const R = { t: now() };
  const strip = () => p.evaluate(() => (document.body.innerText.match(/[^\n]*remaining today[^\n]*/) || [''])[0]);
  const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || 'null')?.usageToday;
  const toasts = () => p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(t => t.innerText.replace(/\n/g, ' ')).join(' | '));
  const dialogs = () => p.evaluate(() => [...document.querySelectorAll('[role=dialog],[role=alertdialog]')].map(t => t.innerText.replace(/\n+/g, ' | ').slice(0, 700)).join(' || '));
  const usageReq = []; p.on('request', r => { if (/usage|trpc/i.test(r.url())) usageReq.push(now().slice(11) + ' ' + r.method() + ' ' + r.url().replace(/^https:\/\/www\.freedailypro\.com/, '').slice(0, 120)); });
  await p.goto('https://www.freedailypro.com/tool/compress-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
  R.load = { strip: await strip(), used: await used() };
  await p.locator('input[type=file]').first().setInputFiles(T + 'A_photos_6p.pdf'); await p.waitForTimeout(3000);
  const t1 = Date.now(); await p.getByRole('button', { name: 'Compress PDF', exact: true }).click();
  await p.waitForTimeout(3000); R.afterClick = { dialog: await dialogs(), toast: await toasts(), strip: await strip() };
  // wait until levels done or blocked
  for (let i = 0; i < 150; i++) { await p.waitForTimeout(2000); if (!(await p.getByRole('button', { name: 'Stop', exact: true }).count())) break; }
  R.compressMs = Date.now() - t1;
  R.main = await p.evaluate(() => { const m = document.querySelector('main').innerText; const i = m.indexOf('A_photos_6p.pdf'); return m.slice(i, i + 3500); });
  R.buttons = await p.evaluate(() => [...document.querySelectorAll('main button')].map(e => (e.getAttribute('aria-label') || e.innerText).trim().replace(/\n/g, ' ').slice(0, 70) + (e.disabled ? ' [disabled]' : '')).filter((x, i, a) => a.indexOf(x) === i));
  R.afterCompress = { strip: await strip(), used: await used(), dialog: await dialogs(), toast: await toasts() };
  await p.screenshot({ path: OUT + 'capped-after-compress.png', fullPage: true });
  const dl = p.getByRole('button', { name: /^Download/ }).first();
  if (await dl.count()) { let d = null; p.once('download', x => d = x); await dl.click().catch(e => R.dlErr = e.message.split('\n')[0]); await p.waitForTimeout(3000);
    R.afterDownloadClick = { download: d ? d.suggestedFilename() : null, dialog: await dialogs(), strip: await strip(), used: await used() };
    await p.screenshot({ path: OUT + 'capped-download-click.png' }); }
  R.usageReq = usageReq; R.t2 = now(); fs.writeFileSync(OUT + 'capped.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close();
})();
