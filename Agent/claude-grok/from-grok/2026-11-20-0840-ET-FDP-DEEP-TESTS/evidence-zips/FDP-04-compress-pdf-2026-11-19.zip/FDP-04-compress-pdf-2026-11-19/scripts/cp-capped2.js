// compress-pdf, ONE fresh (capped) context: batch of 5, Compare view, Run anyway on Extreme/Aggressive, Quick Buy paths (stop at email prompt / Stripe, type nothing).
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/04-compress-pdf/live/'; const T = '/workspace/deep/04-compress-pdf/testfiles/'; const URL = 'https://www.freedailypro.com/tool/compress-pdf';
const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); const R = { t: now() };
  const strip = () => p.evaluate(() => (document.body.innerText.match(/[^\n]*remaining today[^\n]*/) || [''])[0]);
  const dialogs = () => p.evaluate(() => [...document.querySelectorAll('[role=dialog],[role=alertdialog]')].map(t => t.innerText.replace(/\n+/g, ' | ').slice(0, 600)).join(' || '));
  const waitDone = async () => { for (let i = 0; i < 300; i++) { await p.waitForTimeout(1500); const busy = await p.evaluate(() => [...document.querySelectorAll('main button')].some(b => /^(Stop|Stop now)$/.test(b.innerText.trim()))); if (!busy) break; } };
  const levels = () => p.evaluate(() => (document.querySelector('main').innerText.match(/Level \d+:[^\n]*/g) || []));
  const go = async () => { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); };
  await go(); R.load = await strip();
  // batch
  await p.getByRole('button', { name: 'Several files', exact: true }).click(); await p.waitForTimeout(600);
  await p.locator('input[type=file]').first().setInputFiles(['A_photos_6p.pdf', 'B_text_only_5p.pdf', 'C_scan_grey_4p.pdf', 'I_cmyk_2p.pdf', 'G_nonlatin_2p.pdf'].map(f => T + f)); await p.waitForTimeout(3500);
  let t1 = Date.now(); await p.getByRole('button', { name: /^Compress all/ }).click(); await waitDone(); R.batchMs = Date.now() - t1;
  R.batch = await p.evaluate(() => (document.querySelector('main').innerText.split('Each file gets the smallest result for this setting. Files that cannot be made smaller are returned as they were.')[1] || '').split('Watch: Compress')[0]);
  R.batchButtons = await p.evaluate(() => [...document.querySelectorAll('main button')].map(b => b.innerText.trim()).filter(Boolean).filter((x, i, a) => a.indexOf(x) === i));
  await p.screenshot({ path: OUT + 'capped-batch.png', fullPage: true });
  // run anyway extreme
  await go(); await p.locator('input[type=file]').first().setInputFiles(T + 'A_photos_6p.pdf'); await p.waitForTimeout(3000);
  await p.getByRole('button', { name: 'Extreme', exact: true }).click(); t1 = Date.now(); await p.getByRole('button', { name: 'Compress PDF', exact: true }).click(); await waitDone();
  await p.getByRole('button', { name: 'Run anyway' }).click(); await waitDone(); R.extremeMs = Date.now() - t1; R.extremeLevels = await levels();
  R.extremeSummary = await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*(→|Stopped|smallest)[^\n]*/g) || []).slice(0, 6));
  await p.screenshot({ path: OUT + 'capped-extreme-runanyway.png', fullPage: true });
  // Compare the last level
  const cmp = p.getByRole('button', { name: 'Compare', exact: true }).last(); await cmp.click(); await p.waitForTimeout(3500);
  await p.getByText('Compare page').first().scrollIntoViewIfNeeded().catch(() => {}); await p.waitForTimeout(1500);
  R.compareText = await p.evaluate(() => { const m = document.querySelector('main').innerText; const i = m.indexOf('Compare page'); return m.slice(i, i + 300); });
  await p.screenshot({ path: OUT + 'capped-compare-extreme.png' });
  // Quick buy paths
  await go();
  const qb = p.getByRole('button', { name: 'Quick Buy' });
  await qb.first().click(); await p.waitForTimeout(3000); R.dayPass = { url: p.url(), dialog: await dialogs() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' });
  await p.keyboard.press('Escape'); await go();
  await p.getByRole('button', { name: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); R.monthly = { url: p.url().slice(0, 60), dialog: await dialogs(), title: await p.title() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' });
  R.t2 = now(); fs.writeFileSync(OUT + 'capped2.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close();
})();
