// compress-pdf: compress-only scenarios in ONE fresh context (Compress is free; nothing is downloaded).
// Usage: node cp-explore.js [scenario,...]
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/04-compress-pdf/live/'; const T = '/workspace/deep/04-compress-pdf/testfiles/'; const URL = 'https://www.freedailypro.com/tool/compress-pdf';
const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
const only = (process.argv[2] || '').split(',').filter(Boolean);
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); const R = { started: now(), runs: [] };
  const strip = () => p.evaluate(() => (document.body.innerText.match(/[^\n]*remaining today[^\n]*/) || [''])[0]);
  const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || 'null')?.usageToday;
  const toasts = () => p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(t => t.innerText.replace(/\n/g, ' ')).join(' | '));
  const dialogs = () => p.evaluate(() => [...document.querySelectorAll('[role=dialog],[role=alertdialog]')].map(t => t.innerText.replace(/\n+/g, ' | ').slice(0, 500)).join(' || '));
  const S = [
    ['A_balanced', ['A_photos_6p.pdf'], 'Balanced'], ['A_aggressive', ['A_photos_6p.pdf'], 'Aggressive'], ['A_extreme', ['A_photos_6p.pdf'], 'Extreme'],
    ['A_target_1MB', ['A_photos_6p.pdf'], 'Target', { v: '1', u: 'MB' }], ['A_target_200KB', ['A_photos_6p.pdf'], 'Target', { v: '200', u: 'KB' }],
    ['A_target_20KB_balancedOnly', ['A_photos_6p.pdf'], 'Target', { v: '20', u: 'KB', depth: 'balanced' }],
    ['B_text_balanced', ['B_text_only_5p.pdf'], 'Balanced'], ['B_text_aggressive', ['B_text_only_5p.pdf'], 'Aggressive'], ['B_target_2KB', ['B_text_only_5p.pdf'], 'Target', { v: '2', u: 'KB' }],
    ['C_scan_balanced', ['C_scan_grey_4p.pdf'], 'Balanced'], ['C_scan_extreme', ['C_scan_grey_4p.pdf'], 'Extreme'],
    ['D_struct_balanced', ['D_links_bookmarks_form_3p.pdf'], 'Balanced'], ['D_struct_aggressive', ['D_links_bookmarks_form_3p.pdf'], 'Aggressive'],
    ['F_owner_restricted', ['F_owner_restricted_2p.pdf'], 'Balanced'], ['G_nonlatin_balanced', ['G_nonlatin_2p.pdf'], 'Balanced'],
    ['H_mixed_rotated', ['H_mixed_rotated_3p.pdf'], 'Balanced'], ['I_cmyk_balanced', ['I_cmyk_2p.pdf'], 'Balanced'], ['K_already_small', ['K_already_small_3p.pdf'], 'Balanced'],
    ['J_big_75MB', ['J_big_24p.pdf'], 'Balanced'],
    ['T_invalid_0', ['A_photos_6p.pdf'], 'TargetInvalid', { v: '0' }], ['T_invalid_neg', ['A_photos_6p.pdf'], 'TargetInvalid', { v: '-5' }], ['T_invalid_empty', ['A_photos_6p.pdf'], 'TargetInvalid', { v: '' }],
    ['BAD_truncated', ['L_truncated.pdf']], ['BAD_garbage', ['M_garbage.pdf']], ['BAD_text', ['N_text_renamed.pdf']], ['BAD_png', ['O_png_renamed.pdf']], ['BAD_empty', ['P_empty.pdf']], ['BAD_jpg', ['Q_image.jpg']],
    ['SEV_5', ['A_photos_6p.pdf', 'B_text_only_5p.pdf', 'C_scan_grey_4p.pdf', 'D_links_bookmarks_form_3p.pdf', 'G_nonlatin_2p.pdf'], 'Several'],
    ['SEV_6', ['A_photos_6p.pdf', 'B_text_only_5p.pdf', 'C_scan_grey_4p.pdf', 'D_links_bookmarks_form_3p.pdf', 'G_nonlatin_2p.pdf', 'H_mixed_rotated_3p.pdf'], 'SeveralAdd'],
    ['SEV_bad_mix', ['A_photos_6p.pdf', 'L_truncated.pdf', 'E_password_user123_2p.pdf'], 'SeveralAdd'],
  ];
  R.load = { strip: (await (async () => { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); return strip(); })()), used: await used() };
  for (const [name, files, mode, opt = {}] of S) {
    if (only.length && !only.includes(name)) continue;
    const L = { name, files, mode, opt, t0: now() };
    try {
      await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500);
      if (/^Several/.test(mode || '')) { await p.getByRole('button', { name: 'Several files', exact: true }).click(); await p.waitForTimeout(800); }
      await p.locator('input[type=file]').first().setInputFiles(files.map(f => T + f)); await p.waitForTimeout(name.startsWith('J_') ? 12000 : 3500);
      L.afterAdd = { toast: await toasts(), dialog: await dialogs() };
      if (!mode) { L.main = await p.evaluate(() => (document.querySelector('main').innerText.split('Nothing you enter or open is uploaded.')[1] || '').slice(0, 900)); await p.screenshot({ path: OUT + 'x-' + name + '.png' }); R.runs.push(L); console.log(name, JSON.stringify(L.afterAdd)); continue; }
      if (mode === 'SeveralAdd') { L.main = await p.evaluate(() => (document.querySelector('main').innerText.split('Several files')[1] || '').slice(0, 1800)); await p.screenshot({ path: OUT + 'x-' + name + '.png', fullPage: true }); R.runs.push(L); console.log(name, JSON.stringify(L.afterAdd)); continue; }
      const m = mode.startsWith('Target') ? 'Target size' : mode === 'Several' ? 'Balanced' : mode;
      await p.getByRole('button', { name: m, exact: true }).click(); await p.waitForTimeout(500);
      if (mode.startsWith('Target')) {
        await p.locator('main input[type=number]').first().fill(opt.v);
        if (opt.u) await p.getByLabel('Target size unit').selectOption(opt.u);
        if (opt.depth) await p.locator('main select').nth(1).selectOption(opt.depth).catch(async () => { await p.locator('main select').nth(1).selectOption({ index: 0 }); });
        await p.waitForTimeout(500); L.targetNote = await p.evaluate(() => { const t = document.querySelector('main').innerText; const i = t.indexOf('Go as far as'); return t.slice(i, i + 500); });
      }
      if (mode === 'TargetInvalid') { L.compressDisabled = await p.getByRole('button', { name: 'Compress PDF', exact: true }).isDisabled().catch(() => 'n/a'); await p.screenshot({ path: OUT + 'x-' + name + '.png' }); R.runs.push(L); console.log(name, L.compressDisabled, L.targetNote.slice(0, 200)); continue; }
      const btn = mode === 'Several' ? p.getByRole('button', { name: /^Compress all/ }) : p.getByRole('button', { name: 'Compress PDF', exact: true });
      const t1 = Date.now(); await btn.click();
      for (let i = 0; i < 200; i++) { await p.waitForTimeout(1500); if (!(await p.getByRole('button', { name: 'Stop', exact: true }).count()) && !(await p.evaluate(() => /Compressing|Working on|Preparing/.test(document.querySelector('main').innerText)))) break; }
      L.ms = Date.now() - t1;
      L.levels = await p.evaluate(() => (document.querySelector('main').innerText.match(/Level \d+:[^\n]*/g) || []));
      L.summary = await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*(→|smaller|bigger|already|Nothing changed|Couldn't|couldn't|target|passes through|tidied)[^\n]*/g) || []).filter((x, i, a) => a.indexOf(x) === i).slice(0, 25));
      L.toast = await toasts(); L.dialog = await dialogs(); L.strip = await strip(); L.used = await used();
      if (mode === 'Several') L.main = await p.evaluate(() => (document.querySelector('main').innerText.split('Several files')[1] || '').slice(0, 2500));
      await p.screenshot({ path: OUT + 'x-' + name + '.png', fullPage: true });
    } catch (e) { L.error = e.message.split('\n')[0]; await p.screenshot({ path: OUT + 'x-' + name + '-error.png' }).catch(() => {}); }
    L.t1 = now(); R.runs.push(L); console.log(name, L.ms, '|', (L.levels || []).join(' / ').slice(0, 400), '|', L.toast, L.error || '');
  }
  R.finished = now(); const f = OUT + `explore-${Date.now()}.json`; fs.writeFileSync(f, JSON.stringify(R, null, 1)); console.log('wrote', f, JSON.stringify(R.load)); await b.close();
})();
