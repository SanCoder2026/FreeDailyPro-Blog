// compress-pdf: keyboard operability, focus, live regions, axe on the result view, level-row layout (desktop + phone), cloud-storage dialog (closed with Not now). Never signs in; Google Drive not clicked.
const { chromium, devices } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/04-compress-pdf/live/'; const T = '/workspace/deep/04-compress-pdf/testfiles/'; const URL = 'https://www.freedailypro.com/tool/compress-pdf';
const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); const R = { t: now() };
  const waitDone = async () => { for (let i = 0; i < 200; i++) { await p.waitForTimeout(1500); const busy = await p.evaluate(() => [...document.querySelectorAll('main button')].some(b => /^(Stop|Stop now)$/.test(b.innerText.trim()))); if (!busy) break; } };
  const focused = () => p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50); });
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  R.strip = await p.evaluate(() => (document.body.innerText.match(/[^\n]*remaining today[^\n]*/) || [''])[0]);
  const dz = p.locator('main [role=button]').filter({ hasText: 'Drop a PDF' }).first(); R.dz = await dz.evaluate(e => ({ tabindex: e.getAttribute('tabindex'), label: e.getAttribute('aria-label') })).catch(() => null);
  await dz.focus().catch(() => {}); try { const [fc] = await Promise.all([p.waitForEvent('filechooser', { timeout: 4000 }), p.keyboard.press('Enter')]); R.enterOpensChooser = true; await fc.setFiles(T + 'A_photos_6p.pdf'); } catch { R.enterOpensChooser = false; await p.locator('input[type=file]').first().setInputFiles(T + 'A_photos_6p.pdf'); }
  await p.waitForTimeout(3000); R.focusAfterAdd = await focused();
  await p.getByRole('button', { name: 'Target size', exact: true }).click(); await p.waitForTimeout(500);
  R.targetInput = await p.evaluate(() => { const i = document.querySelector('main input[type=number]'); if (!i) return null; const lab = i.id && document.querySelector(`label[for="${i.id}"]`); return { ariaLabel: i.getAttribute('aria-label'), labelledby: i.getAttribute('aria-labelledby'), labelFor: lab ? lab.innerText : null, min: i.min, step: i.step }; });
  R.presetChips = await p.evaluate(() => [...document.querySelectorAll('main button')].map(b => b.innerText.trim()).filter(t => /^\d+ (KB|MB)$/.test(t)));
  await p.getByRole('button', { name: 'Balanced', exact: true }).focus(); await p.keyboard.press('Enter'); await p.waitForTimeout(400);
  R.balancedPressedViaKbd = await p.getByRole('button', { name: 'Balanced', exact: true }).getAttribute('aria-pressed');
  await p.getByRole('button', { name: 'Compress PDF', exact: true }).focus(); await p.keyboard.press('Enter'); await waitDone(); await p.waitForTimeout(1000);
  R.focusAfterCompress = await focused();
  R.liveRegions = await p.evaluate(() => [...document.querySelectorAll('[aria-live],[role=status],[role=alert]')].map(e => (e.getAttribute('aria-live') || e.getAttribute('role')) + ':' + e.innerText.replace(/\n/g, ' ').slice(0, 120)).filter(x => x.length > 9));
  R.levelRowWidths = await p.evaluate(() => [...document.querySelectorAll('main *')].filter(e => /^Level \d+:/.test(e.innerText || '') && e.children.length === 0).map(e => ({ text: e.innerText.slice(0, 30), w: Math.round(e.getBoundingClientRect().width), h: Math.round(e.getBoundingClientRect().height) })));
  R.compareImgs = await p.evaluate(() => [...document.querySelectorAll('main img')].map(i => ({ alt: i.alt, w: i.width })).filter(x => /page|original|compressed/i.test(x.alt)).slice(0, 4));
  await p.addScriptTag({ path: require.resolve('axe-core/axe.min.js') });
  R.axeResult = await p.evaluate(async () => (await axe.run(document.querySelector('main'), { resultTypes: ['violations'] })).violations.map(v => ({ id: v.id, impact: v.impact, count: v.nodes.length, sample: v.nodes.slice(0, 2).map(n => n.target.join(' ') + ' :: ' + (n.failureSummary || '').split('\n')[1]) })));
  await p.screenshot({ path: OUT + 'kbd-result-view.png', fullPage: true });
  const btn = p.getByRole('button', { name: /Save to my cloud storage/ }).first();
  if (await btn.count()) { await btn.click(); await p.waitForTimeout(2000); R.cloudDialog = await p.evaluate(() => [...document.querySelectorAll('[role=dialog]')].map(d => d.innerText.replace(/\n+/g, ' | ').slice(0, 400)).join(' || ')); await p.screenshot({ path: OUT + 'cloud-dialog.png' }); const nn = p.getByRole('button', { name: 'Not now' }); if (await nn.count()) await nn.first().click(); else await p.keyboard.press('Escape'); }
  await ctx.close();
  // phone result view
  const c2 = await b.newContext({ ...devices['Pixel 7'] }); const q = await c2.newPage();
  await q.goto(URL, { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4000); await q.locator('input[type=file]').first().setInputFiles(T + 'A_photos_6p.pdf'); await q.waitForTimeout(3000);
  await q.getByRole('button', { name: 'Compress PDF', exact: true }).click();
  for (let i = 0; i < 100; i++) { await q.waitForTimeout(1500); if (!(await q.evaluate(() => [...document.querySelectorAll('main button')].some(b => /^Stop/.test(b.innerText.trim()))))) break; }
  R.phone = await q.evaluate(() => ({ sw: document.documentElement.scrollWidth, vw: innerWidth }));
  await q.screenshot({ path: OUT + 'phone-result-view.png', fullPage: true });
  R.t2 = now(); fs.writeFileSync(OUT + 'kbd.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close();
})();
