// compress-pdf: what happens when Compress is pressed with an invalid target (0, -5, empty). Compress only.
const { chromium } = require('playwright'); const fs = require('fs');
const OUT = '/workspace/deep/04-compress-pdf/live/'; const T = '/workspace/deep/04-compress-pdf/testfiles/';
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); const R = {};
  await p.goto('https://www.freedailypro.com/tool/compress-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  await p.locator('input[type=file]').first().setInputFiles(T + 'K_already_small_3p.pdf'); await p.waitForTimeout(3000);
  await p.getByRole('button', { name: 'Target size', exact: true }).click();
  for (const v of ['0', '-5', '', 'abc']) { await p.locator('main input[type=number]').first().fill(v).catch(() => {}); await p.waitForTimeout(300);
    const before = await p.evaluate(() => document.querySelector('main').innerText.match(/[^\n]*(valid|already under|Enter)[^\n]*/g));
    await p.waitForTimeout(700); const dis = await p.getByRole('button', { name: 'Compress PDF', exact: true }).isDisabled(); if (!dis) { await p.getByRole('button', { name: 'Compress PDF', exact: true }).click(); await p.waitForTimeout(2500); }
    R[v || 'empty'] = { disabled: dis, before, aria: await p.locator('main input[type=number]').first().evaluate(e => ({ invalid: e.getAttribute('aria-invalid'), describedby: e.getAttribute('aria-describedby') && document.getElementById(e.getAttribute('aria-describedby'))?.innerText })).catch(() => null), toast: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(t => t.innerText.replace(/\n/g, ' ')).join(' | ')), msgs: await p.evaluate(() => document.querySelector('main').innerText.match(/[^\n]*(valid|→|Couldn't|already)[^\n]*/g)) };
    await p.screenshot({ path: OUT + 'target-invalid-' + (v || 'empty') + '.png' }); }
  fs.writeFileSync(OUT + 'target-invalid.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
