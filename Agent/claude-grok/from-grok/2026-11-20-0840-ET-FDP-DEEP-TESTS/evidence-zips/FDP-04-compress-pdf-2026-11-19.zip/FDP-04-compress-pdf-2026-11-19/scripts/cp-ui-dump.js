// compress-pdf: dump controls for Target size, Several files and the password flow (no compress, no download).
const { chromium } = require('playwright'); const fs = require('fs');
const OUT = '/workspace/deep/04-compress-pdf/live/'; const T = '/workspace/deep/04-compress-pdf/testfiles/';
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); const R = {};
  const ctrls = () => p.evaluate(() => [...document.querySelectorAll('main button, main input, main select, main [role=combobox], main [role=radio], main [role=option]')].map(e => ({ tag: e.tagName, type: e.type, name: (e.getAttribute('aria-label') || e.innerText || e.placeholder || '').trim().replace(/\n/g, ' ').slice(0, 60), value: e.value, opts: e.tagName === 'SELECT' ? [...e.options].map(o => o.text) : undefined, on: e.getAttribute('aria-pressed') || e.getAttribute('aria-checked') || e.getAttribute('data-state') })).filter(x => !/favorites|Share this|Quick Buy|Play video|About|How to use|Common|Details|Guides|Shortcut/.test(x.name)));
  await p.goto('https://www.freedailypro.com/tool/compress-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  await p.locator('input[type=file]').first().setInputFiles(T + 'B_text_only_5p.pdf'); await p.waitForTimeout(2500);
  R.textFileMain = await p.evaluate(() => { const m = document.querySelector('main').innerText; const i = m.indexOf('B_text_only'); return m.slice(i, i + 900); });
  await p.getByRole('button', { name: 'Target size', exact: true }).click(); await p.waitForTimeout(800);
  R.target = await ctrls(); R.targetText = await p.evaluate(() => { const m = document.querySelector('main').innerText; const i = m.indexOf('Target size\n'); return m.slice(i, i + 900); });
  await p.screenshot({ path: OUT + 'ui-target.png', fullPage: false });
  for (const m of ['Aggressive', 'Extreme']) { await p.getByRole('button', { name: m, exact: true }).click(); await p.waitForTimeout(500); R['desc_' + m] = await p.evaluate(() => { const t = document.querySelector('main').innerText; const i = t.indexOf('Target size\n'); return t.slice(i + 12, i + 700); }); }
  await p.getByRole('button', { name: 'Several files', exact: true }).click(); await p.waitForTimeout(1500);
  R.several = await ctrls(); R.severalText = await p.evaluate(() => { const m = document.querySelector('main').innerText; const i = m.indexOf('Several files'); return m.slice(i, i + 1500); });
  R.severalInputs = await p.evaluate(() => [...document.querySelectorAll('input[type=file]')].map(i => ({ accept: i.accept, multiple: i.multiple })));
  await p.screenshot({ path: OUT + 'ui-several.png', fullPage: false });
  await p.getByRole('button', { name: 'One file', exact: true }).click(); await p.waitForTimeout(1500);
  await p.goto('https://www.freedailypro.com/tool/compress-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  await p.locator('input[type=file]').first().setInputFiles(T + 'E_password_user123_2p.pdf'); await p.waitForTimeout(2500);
  R.pwMain = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 3000).split('Everything is done')[1] || '');
  R.pwDialog = await p.evaluate(() => [...document.querySelectorAll('[role=dialog],[role=alertdialog]')].map(t => t.innerText).join(' || '));
  R.pwToast = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(t => t.innerText).join(' | '));
  R.pwCtrls = await ctrls(); await p.screenshot({ path: OUT + 'ui-password.png', fullPage: false });
  fs.writeFileSync(OUT + 'ui-dump.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close();
})();
