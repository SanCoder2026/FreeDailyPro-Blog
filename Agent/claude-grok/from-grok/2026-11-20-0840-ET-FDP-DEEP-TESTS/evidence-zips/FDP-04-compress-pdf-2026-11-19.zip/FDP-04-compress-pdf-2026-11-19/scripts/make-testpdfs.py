#!/usr/bin/env python3
"""Generate Compress PDF test inputs. Usage: make-testpdfs.py [outdir]. Needs reportlab, pikepdf, pillow, numpy-free."""
import sys, os, io, random, math
from PIL import Image, ImageDraw, ImageFilter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, letter, landscape
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import pikepdf
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..', 'testfiles')
os.makedirs(OUT, exist_ok=True); random.seed(7)
def photo(w, h, seed, mode='RGB'):
    r = random.Random(seed); im = Image.new('RGB', (w, h)); d = ImageDraw.Draw(im)
    for y in range(0, h, 4):
        c = (int(127+120*math.sin(y/97+seed)), int(127+120*math.sin(y/53+seed*2)), int(127+120*math.cos(y/71+seed)))
        d.rectangle([0, y, w, y+4], fill=c)
    for _ in range(400):
        x, y, s = r.randrange(w), r.randrange(h), r.randrange(10, max(11, w//6))
        d.ellipse([x, y, x+s, y+s], fill=(r.randrange(256), r.randrange(256), r.randrange(256)))
    im = im.filter(ImageFilter.GaussianBlur(2))
    px = im.load()
    for _ in range(w*h//6):  # grain so JPEG can't trivially shrink it
        x, y = r.randrange(w), r.randrange(h); p = px[x, y]; n = r.randrange(-40, 40)
        px[x, y] = tuple(max(0, min(255, v+n)) for v in p)
    return im.convert(mode)
def jpg(im, q=95):
    b = io.BytesIO(); im.save(b, 'JPEG', quality=q); b.seek(0); return ImageReader(b)
def mark(c, fid, n, total, size):
    c.setFont('Helvetica-Bold', 22); c.drawString(40, size[1]-50, f'FILE {fid} P{n}')
    c.setFont('Helvetica', 10); c.drawString(40, size[1]-68, f'{fid} page {n} of {total}  selectable text line for checks')
def photos_pdf(name, fid, pages, px=(2400, 1800), q=95, size=A4, seed=1, title=None):
    c = canvas.Canvas(os.path.join(OUT, name), pagesize=size); c.setTitle(title or name); c.setAuthor('FDP QA')
    for i in range(pages):
        mark(c, fid, i+1, pages, size); c.drawImage(jpg(photo(*px, seed+i), q), 40, 80, size[0]-80, size[1]-180); c.showPage()
    c.save()
# A: photo-heavy 6 pages, about 8-10 MB
photos_pdf('A_photos_6p.pdf', 'A', 6, (2600, 1950), 95, A4, 1, 'Photo report')
# B: text only 5 pages
c = canvas.Canvas(os.path.join(OUT, 'B_text_only_5p.pdf'), pagesize=letter); c.setTitle('Text contract')
for i in range(5):
    mark(c, 'B', i+1, 5, letter); c.setFont('Times-Roman', 11)
    for l in range(50): c.drawString(50, 700-l*12, f'Clause {i+1}.{l+1}: The parties agree that this sentence is plain selectable text for compression testing.')
    c.showPage()
c.save()
# C: scan-like greyscale, 4 pages, PNG (lossless) heavy
c = canvas.Canvas(os.path.join(OUT, 'C_scan_grey_4p.pdf'), pagesize=letter); c.setTitle('Scanned letter')
for i in range(4):
    im = Image.new('L', (2550, 3300), 235); d = ImageDraw.Draw(im)
    for l in range(60): d.text((150, 200+l*48), f'FILE C P{i+1} scanned line {l+1} lorem ipsum dolor sit amet consectetur', fill=30)
    r = random.Random(i); px = im.load()
    for _ in range(300000): x, y = r.randrange(2550), r.randrange(3300); px[x, y] = max(0, min(255, px[x, y]+r.randrange(-25, 25)))
    b = io.BytesIO(); im.save(b, 'PNG'); b.seek(0)
    c.drawImage(ImageReader(b), 0, 0, letter[0], letter[1]); c.setFont('Helvetica', 1); c.showPage()
c.save()
# D: links + bookmarks + form + photos (Balanced should keep them)
p = os.path.join(OUT, 'D_links_bookmarks_form_3p.pdf'); c = canvas.Canvas(p, pagesize=A4); c.setTitle('Structure test')
for i in range(3):
    mark(c, 'D', i+1, 3, A4); c.bookmarkPage(f'p{i}'); c.addOutlineEntry(f'D chapter {i+1}', f'p{i}', 0)
    c.drawImage(jpg(photo(1800, 1200, 50+i)), 40, 300, 500, 330)
    c.linkURL('https://www.freedailypro.com/', (40, 200, 300, 220)); c.drawString(40, 205, 'Link to freedailypro.com')
    if i == 0:
        c.acroForm.textfield(name='client_name', value='Jane Example', x=40, y=120, width=200, height=20)
        c.acroForm.checkbox(name='agree', x=260, y=120, checked=True)
    c.showPage()
c.save()
# E: user password (pw user123), photo content
photos_pdf('_e_src.pdf', 'E', 2, (1800, 1350), 95, A4, 70)
with pikepdf.open(os.path.join(OUT, '_e_src.pdf')) as pdf:
    pdf.save(os.path.join(OUT, 'E_password_user123_2p.pdf'), encryption=pikepdf.Encryption(user='user123', owner='owner456', R=6))
    pdf.save(os.path.join(OUT, 'F_owner_restricted_2p.pdf'), encryption=pikepdf.Encryption(user='', owner='owner456', R=6, allow=pikepdf.Permissions(extract=False, modify_other=False, modify_assembly=False)))
os.remove(os.path.join(OUT, '_e_src.pdf'))
# G: non-Latin text + photo
c = canvas.Canvas(os.path.join(OUT, 'G_nonlatin_2p.pdf'), pagesize=A4); c.setTitle('日本語テスト 資料'); c.setAuthor('山田 太郎')
fonts = {'jp': '/usr/share/fonts/truetype/fonts-japanese-mincho.ttf', 'dv': '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'}
import glob
jp = (glob.glob('/usr/share/fonts/**/BIZUDPMincho*.ttf', recursive=True) + glob.glob('/usr/share/fonts/**/*Mincho*.tt*', recursive=True) + [fonts['jp']])[0]
try: pdfmetrics.registerFont(TTFont('JP', jp)); jpok = True
except Exception: jpok = False
pdfmetrics.registerFont(TTFont('DV', fonts['dv']))
for i in range(2):
    mark(c, 'G', i+1, 2, A4)
    if jpok: c.setFont('JP', 16); c.drawString(40, 720, '日本語のテキストを圧縮後も選択できるか確認します。')
    c.setFont('DV', 14); c.drawString(40, 690, 'Русский текст · Ελληνικά · العربية')
    c.drawImage(jpg(photo(2000, 1500, 90+i)), 40, 150, 515, 386); c.showPage()
c.save()
# H: mixed sizes / landscape / rotated page
p = os.path.join(OUT, 'H_mixed_rotated_3p.pdf'); c = canvas.Canvas(p)
for i, sz in enumerate([A4, landscape(letter), (300, 300)]):
    c.setPageSize(sz); mark(c, 'H', i+1, 3, sz); c.drawImage(jpg(photo(1600, 1200, 120+i)), 20, 20, sz[0]-40, sz[1]-90); c.showPage()
c.save()
with pikepdf.open(p, allow_overwriting_input=True) as pdf: pdf.pages[1].Rotate = 90; pdf.save(p)
# I: CMYK photos (FAQ says Balanced leaves CMYK as is)
c = canvas.Canvas(os.path.join(OUT, 'I_cmyk_2p.pdf'), pagesize=A4); c.setTitle('CMYK')
for i in range(2):
    mark(c, 'I', i+1, 2, A4); b = io.BytesIO(); photo(2000, 1500, 150+i).convert('CMYK').save(b, 'JPEG', quality=95); b.seek(0)
    c.drawImage(ImageReader(b), 40, 200, 515, 386); c.showPage()
c.save()
# J: big, 24 pages of photos (about 75 MB) for performance and the 50 MB note
photos_pdf('J_big_24p.pdf', 'J', 24, (2600, 1950), 95, A4, 200, 'Big photo pack')
# K: already-compressed (low quality small images)
photos_pdf('K_already_small_3p.pdf', 'K', 3, (600, 450), 40, A4, 300, 'Already small')
# Bad files
src = open(os.path.join(OUT, 'B_text_only_5p.pdf'), 'rb').read()
open(os.path.join(OUT, 'L_truncated.pdf'), 'wb').write(src[:len(src)//2])
open(os.path.join(OUT, 'M_garbage.pdf'), 'wb').write(b'%PDF-1.7\n' + bytes(random.randrange(256) for _ in range(5000)))
open(os.path.join(OUT, 'N_text_renamed.pdf'), 'w').write('This is a plain text file renamed to .pdf\n')
b = io.BytesIO(); photo(400, 300, 9).save(b, 'PNG'); open(os.path.join(OUT, 'O_png_renamed.pdf'), 'wb').write(b.getvalue())
open(os.path.join(OUT, 'P_empty.pdf'), 'wb').close()
photo(800, 600, 11).save(os.path.join(OUT, 'Q_image.jpg'), quality=90)
for f in sorted(os.listdir(OUT)): print(f'{f:40s} {os.path.getsize(os.path.join(OUT, f)):>12,d}')
