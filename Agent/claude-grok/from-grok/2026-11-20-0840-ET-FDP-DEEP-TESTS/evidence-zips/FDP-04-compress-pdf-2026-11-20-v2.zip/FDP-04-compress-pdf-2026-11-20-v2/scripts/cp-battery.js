// compress-pdf download battery in ONE uncapped fresh context (each download may spend a trial use). Records strip + localStorage before/after each step.
// Usage: node cp-battery.js [maxContextsToTry=6] [onlyScenarios comma list]
const pw = require('playwright'); const chromium = pw[process.env.ENGINE || 'chromium']; if (process.env.ENGINE === 'webkit') process.env.GIO_EXTRA_MODULES = process.env.GIO_EXTRA_MODULES || (__dirname + '/giomods'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/04-compress-pdf/live/'; const DL = OUT + 'downloads/'; const T = '/workspace/deep/04-compress-pdf/testfiles/'; fs.mkdirSync(DL, { recursive: true });
const URL = 'https://www.freedailypro.com/tool/compress-pdf';
const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
const maxTry = +(process.argv[2] || 6); const only = (process.argv[3] || '').split(',').filter(Boolean);
(async () => {
  const b = await chromium.launch(); const R = { started: now(), loads: [], scenarios: [] }; let ctx, p;
  const strip = () => p.evaluate(() => (document.body.innerText.match(/[^\n]*remaining today[^\n]*/) || [''])[0]);
  const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || 'null')?.usageToday;
  const toasts = () => p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(t => t.innerText.replace(/\n/g, ' ')).join(' | '));
  const dialogs = () => p.evaluate(() => [...document.querySelectorAll('[role=dialog],[role=alertdialog]')].map(t => t.innerText.replace(/\n+/g, ' | ').slice(0, 400)).join(' || '));
  for (let a = 0; a < maxTry; a++) {
    ctx = await b.newContext({ acceptDownloads: true, viewport: { width: 1366, height: 900 }, ...(process.env.ENGINE === 'webkit' ? {} : { permissions: ['clipboard-read', 'clipboard-write'] }) }); p = await ctx.newPage();
    await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); const s = await strip(); R.loads.push({ attempt: a + 1, t: now(), strip: s, used: await used() });
    console.log('load', a + 1, s);
    if (!/(^|[^0-9])0 remaining today/.test(s)) break; await ctx.close(); ctx = null;
  }
  if (!ctx) { R.blocked = `all ${maxTry} fresh contexts loaded at 0 remaining today`; const f = OUT + `battery-${Date.now()}.json`; fs.writeFileSync(f, JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); return; }
  const add = async files => { await p.locator('input[type=file]').first().setInputFiles(files.map(f => T + f)); await p.waitForTimeout(3500); };
  const waitDone = async () => { for (let i = 0; i < 200; i++) { await p.waitForTimeout(1500); const busy = await p.evaluate(() => [...document.querySelectorAll('main button')].some(b => /^(Stop|Stop now)$/.test(b.innerText.trim()))); if (!busy) break; } };
  const mode = async m => { await p.getByRole('button', { name: m, exact: true }).click(); await p.waitForTimeout(400); };
  const compress = async () => { await p.getByRole('button', { name: 'Compress PDF', exact: true }).click(); await waitDone(); };
  const save = async (name, locator) => {
    try { const [d] = await Promise.all([p.waitForEvent('download', { timeout: 20000 }), locator.click()]); const f = DL + name + '__' + d.suggestedFilename(); await d.saveAs(f); return { name: d.suggestedFilename(), file: f, bytes: fs.statSync(f).size }; }
    catch (e) { return 'no download: ' + e.message.split('\n')[0]; } };
  const levels = () => p.evaluate(() => (document.querySelector('main').innerText.match(/Level \d+:[^\n]*/g) || []));
  const S = {
    S1_A_balanced_final: async L => { await add(['A_photos_6p.pdf']); await compress(); L.levels = await levels(); L.dl = await save('S1', p.getByRole('button', { name: 'Download Compressed PDF' })); L.mid = { strip: await strip(), used: await used() };
      L.dl2_level1 = await save('S1b_level1', p.getByRole('button', { name: 'Download', exact: true }).first()); },
    S2_D_struct_balanced: async L => { await add(['D_links_bookmarks_form_3p.pdf']); await compress(); L.levels = await levels(); L.dl = await save('S2', p.getByRole('button', { name: 'Download Compressed PDF' })); },
    S3_G_nonlatin: async L => { await add(['G_nonlatin_2p.pdf']); await compress(); L.levels = await levels(); L.dl = await save('S3', p.getByRole('button', { name: 'Download Compressed PDF' })); },
    S4_H_mixed_rotated: async L => { await add(['H_mixed_rotated_3p.pdf']); await compress(); L.levels = await levels(); L.dl = await save('S4', p.getByRole('button', { name: 'Download Compressed PDF' })); },
    S5_A_target_200KB: async L => { await add(['A_photos_6p.pdf']); await mode('Target size'); await p.locator('main input[type=number]').first().fill('200'); await p.getByLabel('Target size unit').selectOption('KB'); await compress(); L.levels = await levels(); L.dl = await save('S5', p.getByRole('button', { name: 'Download Compressed PDF' })); },
    S6_A_extreme_runanyway: async L => { await add(['A_photos_6p.pdf']); await mode('Extreme'); await compress(); const ra = p.getByRole('button', { name: 'Run anyway' }); if (await ra.count()) { await ra.click(); await waitDone(); } L.levels = await levels(); L.dl = await save('S6', p.getByRole('button', { name: 'Download Compressed PDF' })); },
    S7_E_password: async L => { await p.locator('input[type=file]').first().setInputFiles(T + 'E_password_user123_2p.pdf'); await p.waitForTimeout(2500); await p.getByRole('dialog').locator('input').first().fill('wrong'); await p.getByRole('button', { name: 'Unlock' }).click(); await p.waitForTimeout(1500); L.wrong = await dialogs(); await p.getByRole('dialog').locator('input').first().fill('user123'); await p.getByRole('button', { name: 'Unlock' }).click(); await p.waitForTimeout(3500); L.toastUnlock = await toasts(); await compress(); L.levels = await levels(); L.dl = await save('S7', p.getByRole('button', { name: 'Download Compressed PDF' })); },
    S8_several_5: async L => { await mode('Several files'); await add(['A_photos_6p.pdf', 'B_text_only_5p.pdf', 'C_scan_grey_4p.pdf', 'D_links_bookmarks_form_3p.pdf', 'G_nonlatin_2p.pdf']); await p.getByRole('button', { name: /^Compress all/ }).click(); await waitDone(); await p.waitForTimeout(2000);
      L.main = await p.evaluate(() => (document.querySelector('main').innerText.split('Each file gets the smallest')[1] || '').slice(0, 1500)); L.buttons = await p.evaluate(() => [...document.querySelectorAll('main button')].map(b => b.innerText.trim()).filter(Boolean).filter((x, i, a) => a.indexOf(x) === i));
      const all = p.getByRole('button', { name: /Download all|Download ZIP|Download \(|Download/ }).first(); L.dl = await save('S8', all); },
    S9_B_text: async L => { await add(['B_text_only_5p.pdf']); await compress(); L.levels = await levels(); L.dl = await save('S9', p.getByRole('button', { name: 'Download Compressed PDF' })); },
  };
  for (const [name, fn] of Object.entries(S)) {
    if (only.length && !only.includes(name)) continue;
    const L = { name, t0: now() };
    try {
      await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); L.before = await strip(); L.usedBefore = await used();
      await fn(L); await p.waitForTimeout(1500); L.after = await strip(); L.usedAfter = await used(); L.dialog = await dialogs(); L.toast = await toasts();
      await p.screenshot({ path: OUT + 'bat-' + name + '.png', fullPage: false });
      if (name === 'S1_A_balanced_final') await p.screenshot({ path: OUT + 'bat-' + name + '-full.png', fullPage: true });
    } catch (e) { L.error = e.message.split('\n')[0]; await p.screenshot({ path: OUT + 'bat-' + name + '-error.png' }).catch(() => {}); }
    L.t1 = now(); R.scenarios.push(L); console.log(name, '|', L.before, '->', L.after, '| used', L.usedBefore, '->', L.usedAfter, '|', JSON.stringify(L.dl), JSON.stringify(L.dl2_level1 || ''), L.error || '');
    if (/(^|[^0-9])0 remaining today/.test(L.after || '')) { R.stoppedAt = name + ' (0 remaining)'; break; }
  }
  try { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); R.afterReload = { strip: await strip(), used: await used() };
    await p.evaluate(() => { navigator.share = undefined; }); await p.getByRole('button', { name: 'Share this tool' }).last().click(); await p.waitForTimeout(900); R.share = { clip: await p.evaluate(() => navigator.clipboard.readText().catch(() => '')), toast: await toasts(), strip: await strip() }; } catch (e) { R.postErr = e.message.split('\n')[0]; }
  R.finished = now(); const f = OUT + `battery-${Date.now()}.json`; fs.writeFileSync(f, JSON.stringify(R, null, 1)); console.log('wrote', f); await b.close();
})();
