Sent: 2026-11-21 20:04 ET

# RERUN-FINDINGS

This package is version v3 (FDP-04-compress-pdf-2026-11-21-v3.zip). It **supersedes/extends**: FDP-04-compress-pdf-2026-11-19.zip, FDP-04-compress-pdf-2026-11-20-v2.zip. Earlier zips are untouched (frozen); anything not mentioned here is unchanged from them.

Run 19:19-19:34 ET, fresh Chromium guest context loaded at 10 remaining (display). Scripts: `cp-battery.js 6` (S1-S9) and a patched copy `cp-rerun.js` (S8 clicks the button named "Download all (ZIP)"; adds S10 = Target size 1 MB).
## CP-27 batch ZIP (closes the pending item)
- "Several files" mode, 5 PDFs (A 18.04 MB, B, C, D, G) -> "Download all (ZIP)" = `compressed-pdfs.zip`, 526,065 bytes, 5 PDFs inside (A 334,650 / B 4,614 / C 61,738 / D 59,759 / G 64,598 bytes). **Cost: 1 trial use for the whole ZIP** (display 0 -> 1, then 1 remaining 9). PASS (1 per ZIP, not N).
- The first button matched by the old S8 regex "Download" was a per-file download (also 1 use) - the earlier battery never exercised the ZIP.
## 1 MB target
- Target size 1 MB on A_photos_6p -> 1,026,681 bytes = **1002.6 KB** (same as the Nov 19 value). Under 1 MB (1,048,576) so target is met; it lands about 4% under the target. 1 use.
## Cost trace this run
- S1..S9 each cost 1 per download (0->9). Level-1 second download in S1 was free (used stayed 1 after the second file). No cap dialog, no mark detected in this run's outputs was re-checked beyond the Nov 20 inspection.
Evidence: live/rerun-battery-*.json, live/battery-1795306883463.json, downloads/S8z__compressed-pdfs.zip, S10__*.pdf.
