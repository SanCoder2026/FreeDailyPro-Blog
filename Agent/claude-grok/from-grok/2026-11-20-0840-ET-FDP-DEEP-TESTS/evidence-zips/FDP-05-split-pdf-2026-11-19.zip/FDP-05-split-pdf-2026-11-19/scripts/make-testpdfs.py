#!/usr/bin/env python3
"""Generate Split PDF test inputs. Usage: make-testpdfs.py [outdir]. Needs reportlab, pikepdf, pillow. Every page shows 'FILE <id> P<n>'."""
import sys, os, io, glob, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, letter, landscape, A3
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from PIL import Image
import pikepdf
OUT = sys.argv[1] if len(sys.argv) > 1 else 'testfiles'; os.makedirs(OUT, exist_ok=True); random.seed(5)
def mark(c, fid, n, total, size):
    c.setFont('Helvetica-Bold', 26); c.drawString(40, size[1]-60, f'FILE {fid} P{n}')
    c.setFont('Helvetica', 10); c.drawString(40, size[1]-80, f'{fid} page {n} of {total}  size {round(size[0])}x{round(size[1])} pt')
def simple(name, fid, n, size=letter, title=None, outline=False, links=False):
    c = canvas.Canvas(os.path.join(OUT, name), pagesize=size); c.setTitle(title or name[:-4]); c.setAuthor('FDP QA')
    for i in range(n):
        mark(c, fid, i+1, n, size)
        if outline: c.bookmarkPage(f'p{i}'); c.addOutlineEntry(f'{fid} section {i+1}', f'p{i}', 0)
        if links: c.linkURL('https://www.freedailypro.com/', (40, 100, 300, 120)); c.drawString(40, 105, 'Link to freedailypro.com')
        c.showPage()
    c.save()
simple('A_10p_bookmarks_links.pdf', 'A', 10, letter, 'Ten page report', outline=True, links=True)
p = os.path.join(OUT, 'B_mixed_rotated_5p.pdf'); c = canvas.Canvas(p)
for i, sz in enumerate([A4, landscape(letter), A3, (300, 300), letter]): c.setPageSize(sz); mark(c, 'B', i+1, 5, sz); c.showPage()
c.save()
with pikepdf.open(p, allow_overwriting_input=True) as pdf: pdf.pages[1].Rotate = 90; pdf.pages[4].Rotate = 180; pdf.save(p)
simple('C_single_page.pdf', 'C', 1)
simple('_d.pdf', 'D', 6)
with pikepdf.open(os.path.join(OUT, '_d.pdf')) as pdf:
    pdf.save(os.path.join(OUT, 'D_password_user123_6p.pdf'), encryption=pikepdf.Encryption(user='user123', owner='owner456', R=6))
    pdf.save(os.path.join(OUT, 'E_owner_restricted_6p.pdf'), encryption=pikepdf.Encryption(user='', owner='owner456', R=6, allow=pikepdf.Permissions(extract=False, modify_other=False, modify_assembly=False)))
os.remove(os.path.join(OUT, '_d.pdf'))
simple('F_large_300p.pdf', 'F', 300, A4, 'Three hundred pages')
c = canvas.Canvas(os.path.join(OUT, 'G_nonlatin_4p.pdf'), pagesize=A4); c.setTitle('日本語テスト 資料'); c.setAuthor('山田 太郎')
jp = (glob.glob('/usr/share/fonts/**/BIZUDPMincho*.ttf', recursive=True) + glob.glob('/usr/share/fonts/**/*Mincho*.tt*', recursive=True))
jpok = False
if jp:
    try: pdfmetrics.registerFont(TTFont('JP', jp[0])); jpok = True
    except Exception: pass
pdfmetrics.registerFont(TTFont('DV', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
for i in range(4):
    mark(c, 'G', i+1, 4, A4)
    if jpok: c.setFont('JP', 16); c.drawString(40, 700, '日本語のテキストが分割後も残るか確認します。')
    c.setFont('DV', 14); c.drawString(40, 670, 'Русский текст · Ελληνικά · العربية'); c.showPage()
c.save()
p = os.path.join(OUT, 'H_form_3p.pdf'); c = canvas.Canvas(p, pagesize=letter); c.setTitle('Form')
for i in range(3):
    mark(c, 'H', i+1, 3, letter)
    if i == 1: c.acroForm.textfield(name='client_name', value='Jane Example', x=40, y=500, width=200, height=20); c.acroForm.checkbox(name='agree', x=260, y=500, checked=True)
    c.showPage()
c.save()
src = open(os.path.join(OUT, 'A_10p_bookmarks_links.pdf'), 'rb').read()
open(os.path.join(OUT, 'L_truncated.pdf'), 'wb').write(src[:len(src)//2])
open(os.path.join(OUT, 'M_garbage.pdf'), 'wb').write(b'%PDF-1.7\n' + bytes(random.randrange(256) for _ in range(5000)))
open(os.path.join(OUT, 'N_text_renamed.pdf'), 'w').write('This is a plain text file renamed to .pdf\n')
b = io.BytesIO(); Image.new('RGB', (300, 200), (200, 50, 50)).save(b, 'PNG'); open(os.path.join(OUT, 'O_png_renamed.pdf'), 'wb').write(b.getvalue())
open(os.path.join(OUT, 'P_empty.pdf'), 'wb').close()
Image.new('RGB', (800, 600), (30, 120, 200)).save(os.path.join(OUT, 'Q_image.jpg'), quality=90)
for f in sorted(os.listdir(OUT)): print(f'{f:36s} {os.path.getsize(os.path.join(OUT, f)):>10,d}')
