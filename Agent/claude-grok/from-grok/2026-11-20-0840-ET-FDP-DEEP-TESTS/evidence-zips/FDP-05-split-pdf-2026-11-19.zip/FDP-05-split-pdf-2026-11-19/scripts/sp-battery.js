// split-pdf DOWNLOAD battery in ONE uncapped fresh context (each download may spend a trial use). Run after midnight UTC (7:00 PM ET).
// Records the trial strip + localStorage fdp-usage-v1 before/after every download, so per-file vs ZIP cost is visible (display-only evidence).
// Usage: node sp-battery.js [maxContextsToTry=6] [onlyScenarios comma list]     ENGINE=webkit|firefox optional
// Afterwards: unzip ZIPs in live/downloads and run  OUT_JSON=live/output-inspection.json python3 scripts-extra/inspect-output.py live/downloads/*.pdf live/downloads/unz/*/*.pdf
const pw = require('playwright'); const chromium = pw[process.env.ENGINE || 'chromium']; if (process.env.ENGINE === 'webkit') process.env.GIO_EXTRA_MODULES = process.env.GIO_EXTRA_MODULES || (__dirname + '/giomods');
const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/05-split-pdf/live/'; const DL = OUT + 'downloads/'; const T = '/workspace/deep/05-split-pdf/testfiles/'; fs.mkdirSync(DL, { recursive: true });
const URL = 'https://www.freedailypro.com/tool/split-pdf';
const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
const maxTry = +(process.argv[2] || 6); const only = (process.argv[3] || '').split(',').filter(Boolean);
(async () => {
  const b = await chromium.launch(); const R = { started: now(), loads: [], scenarios: [] }; let ctx, p;
  const strip = () => p.evaluate(() => (document.body.innerText.match(/[^\n]*remaining today[^\n]*/) || [''])[0]);
  const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || 'null')?.usageToday;
  const toasts = () => p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(t => t.innerText.replace(/\n/g, ' ')).join(' | '));
  const dialogs = () => p.evaluate(() => [...document.querySelectorAll('[role=dialog],[role=alertdialog]')].map(t => t.innerText.replace(/\n+/g, ' | ').slice(0, 400)).join(' || '));
  for (let a = 0; a < maxTry; a++) {
    ctx = await b.newContext({ acceptDownloads: true, viewport: { width: 1366, height: 900 } }); p = await ctx.newPage();
    await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); const s = await strip(); R.loads.push({ attempt: a + 1, t: now(), strip: s, used: await used() });
    console.log('load', a + 1, s);
    if (!/(^|[^0-9])0 remaining today/.test(s)) break; await ctx.close(); ctx = null;
  }
  if (!ctx) { R.blocked = `all ${maxTry} fresh contexts loaded at 0 remaining today`; const f = OUT + `battery-${Date.now()}.json`; fs.writeFileSync(f, JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); return; }
  const add = async f => { p.once('dialog', d => d.dismiss()); await p.locator('input[type=file]').first().setInputFiles(T + f); await p.waitForTimeout(3500); };
  const ranges = async r => { await p.getByPlaceholder('1-3, 4-6').fill(r); await p.waitForTimeout(300); };
  const split = async () => { await p.getByRole('button', { name: /^Split (PDF|into \d+ files?)$/ }).first().click(); await p.waitForTimeout(3000); };
  const rows = () => p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*\.pdf\n[^\n]*/g) || []).slice(0, 12));
  const save = async (name, locator) => {
    const u0 = await used();
    try { const [d] = await Promise.all([p.waitForEvent('download', { timeout: 30000 }), locator.click()]); const f = DL + name + '__' + d.suggestedFilename(); await d.saveAs(f); await p.waitForTimeout(1200);
      return { name: d.suggestedFilename(), file: f, bytes: fs.statSync(f).size, usedBefore: u0, usedAfter: await used(), strip: await strip() }; }
    catch (e) { return { err: 'no download: ' + e.message.split('\n')[0], dialog: await dialogs(), usedBefore: u0, usedAfter: await used() }; } };
  const dlN = n => p.getByRole('button', { name: 'Download', exact: true }).nth(n);
  const zip = () => p.getByRole('button', { name: /^Download all \d+ files as ZIP$/ });
  const S = {
    // 1st file, then the same file again (does a repeat cost a use?), then 2nd file, then the ZIP of all 3
    S1_A_ranges_files_then_zip: async L => { await add('A_10p_bookmarks_links.pdf'); await ranges('1-3, 4-6, 7'); await split(); L.rows = await rows();
      L.dl1 = await save('S1_f1', dlN(0)); L.dl1again = await save('S1_f1again', dlN(0)); L.dl2 = await save('S1_f2', dlN(1)); L.zip = await save('S1_zip', zip()); },
    S2_A_combine_reorder: async L => { await add('A_10p_bookmarks_links.pdf'); await ranges('7, 1-2, 9-10'); await p.getByLabel(/Combine all ranges/).check(); await split(); L.rows = await rows(); L.dl = await save('S2', dlN(0)); },
    S3_A_open_ended_1dash: async L => { await add('A_10p_bookmarks_links.pdf'); await ranges('8-'); await split(); L.rows = await rows(); L.dl = await save('S3', dlN(0)); },
    S4_B_mixed_rotated_every_page_zip: async L => { await add('B_mixed_rotated_5p.pdf'); await p.getByRole('button', { name: 'Every page' }).click(); await split(); L.rows = await rows(); L.zip = await save('S4_zip', zip()); },
    S5_G_nonlatin: async L => { await add('G_nonlatin_4p.pdf'); await ranges('1-2, 3-4'); await split(); L.dl = await save('S5', dlN(0)); },
    S6_H_form: async L => { await add('H_form_3p.pdf'); await ranges('1, 2-3'); await split(); L.dl = await save('S6', dlN(1)); },
    S7_D_password_unlocked: async L => { await p.locator('input[type=file]').first().setInputFiles(T + 'D_password_user123_6p.pdf'); await p.waitForTimeout(2500); await p.getByRole('dialog').locator('input').first().fill('user123'); await p.getByRole('button', { name: 'Unlock' }).click(); await p.waitForTimeout(3500); await ranges('1-3, 4-6'); await split(); L.dl = await save('S7', dlN(0)); },
    S8_E_owner_restricted: async L => { await add('E_owner_restricted_6p.pdf'); await ranges('1-3, 4-6'); await split(); L.toast = await toasts(); L.dl = await save('S8', dlN(0)); },
    S9_F_300_every_page_zip: async L => { await add('F_large_300p.pdf'); await p.getByRole('button', { name: 'Every page' }).click(); await split(); await p.waitForTimeout(3000); const t0 = Date.now(); L.zip = await save('S9_zip', zip()); L.zipMs = Date.now() - t0; },
  };
  for (const [name, fn] of Object.entries(S)) {
    if (only.length && !only.includes(name)) continue;
    const L = { name, t0: now() };
    try {
      await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); L.before = await strip(); L.usedBefore = await used();
      await fn(L); await p.waitForTimeout(1500); L.after = await strip(); L.usedAfter = await used(); L.dialog = await dialogs(); L.toast = (L.toast || '') + await toasts();
      await p.screenshot({ path: OUT + 'bat-' + name + '.png', fullPage: false });
    } catch (e) { L.error = e.message.split('\n')[0]; await p.screenshot({ path: OUT + 'bat-' + name + '-error.png' }).catch(() => {}); }
    L.t1 = now(); R.scenarios.push(L); console.log(name, '|', L.before, '->', L.after, '| used', L.usedBefore, '->', L.usedAfter, L.error || '');
    if (/(^|[^0-9])0 remaining today/.test(L.after || '')) { R.stoppedAt = name + ' (0 remaining)'; break; }
  }
  try { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); R.afterReload = { strip: await strip(), used: await used() }; } catch (e) { R.postErr = e.message.split('\n')[0]; }
  // unzip ZIPs for inspection (never executes anything from the archives)
  for (const z of fs.readdirSync(DL).filter(f => f.endsWith('.zip'))) { const d = DL + 'unz/' + z.replace(/\.zip$/, ''); fs.mkdirSync(d, { recursive: true }); try { cp.execSync(`python3 -c "import zipfile,sys;zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])" "${DL + z}" "${d}"`); } catch (e) { R.unzipErr = e.message; } }
  R.finished = now(); const f = OUT + `battery-${Date.now()}.json`; fs.writeFileSync(f, JSON.stringify(R, null, 1)); console.log('wrote', f); await b.close();
})();
