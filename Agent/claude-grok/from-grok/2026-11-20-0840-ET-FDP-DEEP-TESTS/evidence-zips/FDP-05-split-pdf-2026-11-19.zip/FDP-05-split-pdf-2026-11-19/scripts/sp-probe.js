// split-pdf: one fresh context. Records strip on load, adds A_photos_6p, records the UI (no compress).
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/05-split-pdf/live/'; const T = '/workspace/deep/05-split-pdf/testfiles/';
const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); const R = { t: now() };
  await p.goto('https://www.freedailypro.com/tool/split-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
  R.strip = await p.evaluate(() => (document.body.innerText.match(/[^\n]*(remaining today|uses\/day)[^\n]*/g) || []).join(' || '));
  R.ls = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
  R.inputs = await p.evaluate(() => [...document.querySelectorAll('input[type=file]')].map(i => ({ accept: i.accept, multiple: i.multiple, capture: i.getAttribute('capture') })));
  R.mainBefore = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 2500));
  await p.locator('input[type=file]').first().setInputFiles([T + 'A_10p_bookmarks_links.pdf']); await p.waitForTimeout(5000);
  R.main = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 5000));
  R.buttons = await p.evaluate(() => [...document.querySelectorAll('main button, main input, main [role=button], main [role=radio], main [role=switch], main select, main label')].map(e => (e.tagName + ':' + (e.getAttribute('aria-label') || e.innerText || e.placeholder || e.type || '').trim().replace(/\n/g,' ').slice(0, 60) + (e.disabled ? ' [disabled]' : '') + (e.getAttribute('aria-checked')==='true'||e.getAttribute('aria-pressed')==='true'||e.getAttribute('data-state')==='checked' ? ' [on]' : ''))).filter((x, i, a) => a.indexOf(x) === i));
  await p.screenshot({ path: OUT + 'probe-A.png', fullPage: true });
  fs.writeFileSync(OUT + 'probe.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close();
})();
