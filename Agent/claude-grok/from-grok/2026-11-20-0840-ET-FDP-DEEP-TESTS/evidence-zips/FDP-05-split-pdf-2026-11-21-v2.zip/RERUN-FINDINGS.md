Sent: 2026-11-21 20:04 ET

# RERUN-FINDINGS

This package is version v2 (FDP-05-split-pdf-2026-11-21-v2.zip). It **supersedes/extends**: FDP-05-split-pdf-2026-11-19.zip. Earlier zips are untouched (frozen); anything not mentioned here is unchanged from them.

Run 19:21-19:34 ET, ONE fresh Chromium context loaded at 10 remaining (display). Script: `split05/sp-battery.js 6` (NOTE: `tools-env/sp-battery.js` is the sign-pdf battery - the row's command `node sp-battery.js 6` runs the wrong tool and does nothing; correct path is `node split05/sp-battery.js 6`). Inspection: `inspect-output.py` -> live/output-inspection-v2.json.
## Cost per download (display counter)
- S1 (A, 3 ranges): file 1-3 download, same file again, file 4-6 download, then the ZIP = **1 use total** (0 -> 1). Same-file repeat and ZIP were free within that result set.
- S2 combine (7,1,2,9,10), S3 open-ended "8-", S4 (B, every page, ZIP of 5), S5 (G), S6 (H), S7 (D unlocked): each new upload/result costs 1 (1->2 ... 6->7).
- S8 (E owner-restricted): display went 7 -> **10** (0 remaining) for one download: the known +3 jump.
- S4 ZIP of 5 single-page files cost 1 (not N).
## Output content (all PASS unless noted)
- Order markers: S1 parts A1-3 / A4-6 / A7; S2 combined = A7,A1,A2,A9,A10 (typed order kept); S3 "8-" = A8,A9,A10 (runs to p10).
- B (mixed rotated): sizes 595x842, 792x612 /Rotate 90 (p2), 842x1191, 300x300, 612x792 /Rotate 180 (p5) kept.
- Bookmarks/links: A parts keep 3 bookmarks and 6 links each; combined has 5 bookmarks, 10 links. H keeps 2 form fields. G keeps Japanese, Cyrillic, Greek, Arabic text (extractable).
- D (unlocked) output is not encrypted. E (owner restrictions) output also unencrypted = restrictions dropped (parts are 3,671 bytes, same as D). Note: the E parts' text says "FILE D P1" - the page label in the E test file is D (test-file labelling, not a tool issue; unverified).
- Badge text "Created with FreeDailyPro.com" present on every page of every output (watermark_text_found true for all 17 files).
- 300-file ZIP and 46.6 KB per-part size for G: not re-run (G here has 2 parts of 49,396 bytes for 2 pages).
Evidence: live/battery-1795307675888.json, live/output-inspection-v2.json, live/downloads/*.
