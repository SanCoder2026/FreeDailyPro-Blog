import{g as o}from"./index-CNq0XwLX.js";import{u as s}from"./useAdminAccess-yruBH9-V.js";function r(){const i=o(),e=s();return i?{open:!0,preview:!1,loading:!1}:{open:e.allowed,preview:e.allowed,loading:e.loading}}export{r as u};
//# sourceMappingURL=access-BjhR02O6.js.map
