// qr-generator: every content type, EC levels, colours, logos, limits. Reads the on-page preview canvas (no download, no trial use) and saves it as PNG for decoding.
// Usage: node qr-explore.js [names]   then: python3 scripts/decode-previews.py
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/06-qr-generator/live/'; const PV = OUT + 'previews/'; const T = '/workspace/deep/06-qr-generator/testfiles/'; fs.mkdirSync(PV, { recursive: true });
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const only = (process.argv[2] || '').split(',').filter(Boolean);
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); const R = { t: now(), runs: [] };
  const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || 'null')?.usageToday;
  const fresh = async () => { await p.goto('https://www.freedailypro.com/tool/qr-generator', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); };
  const tab = async n => { await p.getByRole('tab', { name: n, exact: true }).click(); await p.waitForTimeout(300); };
  const fill = async (label, v) => { await p.getByLabel(label, { exact: true }).first().fill(v); };
  const sel = async (cur, opt) => { await p.locator('main [role=combobox]').filter({ hasText: cur }).first().click(); await p.waitForTimeout(250); await p.getByRole('option', { name: opt }).first().click(); await p.waitForTimeout(300); };
  const state = async name => { await p.waitForTimeout(900);
    const s = await p.evaluate(() => { const c = document.querySelector('main canvas'); const r = c ? c.getBoundingClientRect() : null;
      const t = document.querySelector('main').innerText; const toasts = [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.replace(/\n/g, ' ')).join(' | ');
      return { canvas: c ? { w: c.width, h: c.height, cssW: Math.round(r.width), aria: c.getAttribute('aria-label'), role: c.getAttribute('role') } : null, data: c ? c.toDataURL('image/png') : null,
        bytes: (t.match(/[^\n]*bytes used at level[^\n]*/) || [''])[0], warn: (t.match(/[^\n]*(contrast|inverted|Too long|Shorten|Fill in the details|Logo added|upload an image)[^\n]*/gi) || []).join(' | '), ec: [...document.querySelectorAll('main [role=combobox]')].map(x => x.innerText).join(' / '), toasts }; });
    if (s.data) { fs.writeFileSync(PV + name + '.png', Buffer.from(s.data.split(',')[1], 'base64')); } delete s.data; s.used = await used(); return s; };
  const S = {
    Q01_link_default: async () => {},
    Q02_link_query_unicode: async () => { await fill('Web address', 'https://example.com/café?q=a b&x=1#frag'); },
    Q03_link_no_scheme: async () => { await fill('Web address', 'example.com/menu'); },
    Q04_link_shortener: async () => { await fill('Web address', 'https://bit.ly/3abcXYZ'); },
    Q05_text_multiline_unicode: async () => { await tab('Text'); await fill('Text', 'Line 1\nZeile 2 – Grüße\n日本語テスト 👍'); },
    Q06_wifi_wpa_special: async () => { await tab('WiFi'); await fill('Network name (SSID)', 'Café;Net,"5G":\\'); await fill('Password', 'p@ss;w,rd:"x"\\'); },
    Q07_wifi_hidden: async () => { await tab('WiFi'); await fill('Network name (SSID)', 'HiddenNet'); await fill('Password', 'secret123'); await p.getByLabel('Hidden network').check(); },
    Q08_wifi_open: async () => { await tab('WiFi'); await fill('Network name (SSID)', 'GuestOpen'); await sel('WPA', /None/); },
    Q09_wifi_wep: async () => { await tab('WiFi'); await fill('Network name (SSID)', 'OldNet'); await fill('Password', 'abcde'); await sel('WPA', /WEP/).catch(e => 'no WEP'); },
    Q10_contact_semicolon: async () => { await tab('Contact'); await fill('First name', 'José'); await fill('Last name', "O'Brien-Müller"); await fill('Phone', '+1 (555) 010-2030'); await fill('Email', 'jose@example.com'); await fill('Company', 'Smith; Jones & Co, LLC'); await fill('Website', 'https://example.com'); },
    Q11_contact_minimal: async () => { await tab('Contact'); await fill('First name', 'Ann'); },
    Q12_email: async () => { await tab('Email'); await fill('To', 'sales@example.com'); await fill('Subject (optional)', 'Order #12 & more?'); await fill('Message (optional)', 'Hi,\nline two = ok'); },
    Q13_sms: async () => { await tab('SMS'); await fill('Phone number', '+15550102030'); await fill('Message (optional)', 'Reply YES: confirm'); },
    Q14_phone: async () => { await tab('Phone'); await fill('Phone number', '+44 20 7946 0958'); },
    Q15_ec_L: async () => { await sel('M (15%)', /^L/); },
    Q16_ec_H: async () => { await sel('M (15%)', /^H/); },
    Q17_size_2000: async () => { await sel('1000 px', '2000 px'); },
    Q18_inverted: async () => { await p.getByLabel('Code colour').fill('#ffffff'); await p.getByLabel('Background colour').fill('#000000'); },
    Q19_low_contrast: async () => { await p.getByLabel('Code colour').fill('#9ca3af'); await p.getByLabel('Background colour').fill('#ffffff'); },
    Q20_brand_ok: async () => { await p.getByLabel('Code colour').fill('#0d4f4a'); await p.getByLabel('Background colour').fill('#fff7e6'); },
    Q21_logo_png: async () => { await p.locator('main input[type=file]').setInputFiles(T + 'logo_small_transparent.png'); },
    Q22_logo_photo_busy: async () => { await p.locator('main input[type=file]').setInputFiles(T + 'logo_photo_busy_2400x1600.jpg'); },
    Q23_logo_svg: async () => { await p.locator('main input[type=file]').setInputFiles(T + 'logo.svg'); },
    Q24_logo_pdf: async () => { await p.locator('main input[type=file]').setInputFiles(T + 'not_an_image.pdf'); },
    Q25_logo_fake_png: async () => { await p.locator('main input[type=file]').setInputFiles(T + 'text_renamed.png'); },
    Q26_logo_longurl: async () => { await fill('Web address', 'https://example.com/' + 'a'.repeat(600)); await p.locator('main input[type=file]').setInputFiles(T + 'logo_small_transparent.png'); },
    Q27_empty_link: async () => { await fill('Web address', ''); },
    Q28_too_long_M: async () => { await tab('Text'); await fill('Text', 'x'.repeat(2400)); },
    Q29_max_L: async () => { await sel('M (15%)', /^L/); await tab('Text'); await fill('Text', 'y'.repeat(2900)); },
    Q30_javascript_scheme: async () => { await fill('Web address', 'javascript:alert(1)'); },
  };
  R.startUsed = await (async () => { await fresh(); return { used: await used(), strip: await p.evaluate(() => (document.body.innerText.match(/[^\n]*remaining today[^\n]*/) || [''])[0]) }; })();
  for (const [name, fn] of Object.entries(S)) {
    if (only.length && !only.includes(name)) continue; const L = { name };
    try { await fresh(); await fn(); Object.assign(L, await state(name)); } catch (e) { L.error = e.message.split('\n')[0]; }
    if (['Q06_wifi_wpa_special', 'Q18_inverted', 'Q22_logo_photo_busy', 'Q28_too_long_M', 'Q10_contact_semicolon'].includes(name)) await p.screenshot({ path: OUT + 'x-' + name + '.png' });
    R.runs.push(L); console.log(name, JSON.stringify(L).slice(0, 330));
  }
  R.t2 = now(); const f = OUT + `explore-${Date.now()}.json`; fs.writeFileSync(f, JSON.stringify(R, null, 1)); console.log('wrote', f); await b.close();
})();
