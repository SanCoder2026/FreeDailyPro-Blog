// qr-generator: keyboard on tabs/selects, canvas a11y, axe, capped Download PNG/SVG dialogs, upsell link, phone layout (Pixel 7 + iPhone SE: is the preview visible near the input?). No download, no sign-in.
const { chromium, webkit, devices } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/06-qr-generator/live/'; const URL = 'https://www.freedailypro.com/tool/qr-generator';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); const R = { t: now() };
  const focused = () => p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('role') || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 40); });
  const dialogs = () => p.evaluate(() => [...document.querySelectorAll('[role=dialog],[role=alertdialog]')].map(t => t.innerText.replace(/\n+/g, ' | ').slice(0, 700)).join(' || '));
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  R.strip = await p.evaluate(() => (document.body.innerText.match(/[^\n]*remaining today[^\n]*/) || [''])[0]);
  await p.getByRole('tab', { name: 'Link' }).focus(); await p.keyboard.press('ArrowRight'); await p.waitForTimeout(300);
  R.arrowOnTabs = { focus: await focused(), selected: await p.evaluate(() => [...document.querySelectorAll('[role=tab]')].filter(t => t.getAttribute('aria-selected') === 'true' || t.dataset.state === 'active').map(t => t.innerText)) };
  R.tablist = await p.evaluate(() => { const t = document.querySelector('[role=tab]'); return { tablist: !!t.closest('[role=tablist]'), ariaSelected: t.getAttribute('aria-selected'), controls: t.getAttribute('aria-controls'), tabindex: [...document.querySelectorAll('[role=tab]')].map(x => x.tabIndex) }; });
  await p.getByRole('tab', { name: 'Text' }).focus(); await p.keyboard.press('Enter'); await p.waitForTimeout(300); R.enterOnTab = await p.evaluate(() => !!document.querySelector('main textarea'));
  await p.getByLabel('Text', { exact: true }).fill('Hello'); await p.waitForTimeout(500);
  R.canvasA11y = await p.evaluate(() => { const c = document.querySelector('main canvas'); return { aria: c.getAttribute('aria-label'), role: c.getAttribute('role'), title: c.title, inner: c.innerHTML, liveText: [...document.querySelectorAll('[aria-live],[role=status]')].map(e => e.innerText.slice(0, 80)).filter(Boolean) }; });
  await p.locator('main [role=combobox]').filter({ hasText: '1000 px' }).focus(); await p.keyboard.press('Enter'); await p.waitForTimeout(300); await p.keyboard.press('ArrowDown'); await p.keyboard.press('Enter'); await p.waitForTimeout(300);
  R.selectByKeyboard = await p.evaluate(() => [...document.querySelectorAll('main [role=combobox]')].map(x => x.innerText).join(' / '));
  await p.addScriptTag({ path: require.resolve('axe-core/axe.min.js') });
  R.axeMain = await p.evaluate(async () => (await axe.run(document.querySelector('main'), { resultTypes: ['violations'] })).violations.map(v => ({ id: v.id, impact: v.impact, count: v.nodes.length, sample: v.nodes.slice(0, 2).map(n => n.target.join(' ') + ' :: ' + (n.failureSummary || '').split('\n')[1]) })));
  for (const fmt of ['PNG', 'SVG']) { let d = null; p.once('download', x => d = x); await p.getByRole('button', { name: 'Download ' + fmt }).click(); await p.waitForTimeout(2000);
    R['capped' + fmt] = { download: d ? d.suggestedFilename() : null, dialog: await dialogs() }; if (fmt === 'PNG') await p.screenshot({ path: OUT + 'capped-png-click.png' }); await p.keyboard.press('Escape'); await p.waitForTimeout(400); }
  R.upsell = await p.evaluate(() => { const a = [...document.querySelectorAll('main a')].find(x => /Open QR Code Generator with Logo/.test(x.innerText)); return a ? a.href : null; });
  R.markDisclosed = await p.evaluate(() => /Created with FreeDailyPro|badge|mark/i.test(document.querySelector('main').innerText.split('NEXT STEP')[0]));
  await p.screenshot({ path: OUT + 'desktop-tool.png', fullPage: false }); await ctx.close();
  for (const [dn, eng] of [['Pixel 7', b], ['iPhone SE', null]]) { const br = eng || await webkit.launch(); const c2 = await br.newContext({ ...devices[dn] }); const q = await c2.newPage();
    await q.goto(URL, { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4500); if (eng) {} 
    const m = await q.evaluate(() => { const i = document.querySelector('main input[type=text]'); const c = document.querySelector('main canvas'); const d = [...document.querySelectorAll('main button')].find(x => x.innerText.trim() === 'Download PNG'); const r = e => e ? Math.round(e.getBoundingClientRect().top + scrollY) : null;
      return { vh: innerHeight, sw: document.documentElement.scrollWidth, vw: innerWidth, inputY: r(i), canvasY: r(c), canvasW: c ? Math.round(c.getBoundingClientRect().width) : null, downloadY: r(d), strip: (document.body.innerText.match(/[^\n]*remaining today[^\n]*/) || [''])[0] }; });
    R['phone_' + dn] = m; await q.screenshot({ path: OUT + 'phone-' + dn.replace(/ /g, '-').toLowerCase() + '-full.png', fullPage: true }); await c2.close(); if (!eng) await br.close(); }
  R.t2 = now(); fs.writeFileSync(OUT + 'kbd.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
