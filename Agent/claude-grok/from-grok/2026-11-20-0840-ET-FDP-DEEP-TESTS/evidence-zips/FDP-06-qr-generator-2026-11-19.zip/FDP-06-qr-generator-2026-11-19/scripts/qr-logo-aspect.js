// qr-generator: does a non-square logo keep its aspect ratio in the preview canvas? (no download)
const { chromium } = require('playwright'); const fs = require('fs');
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage();
  await p.goto('https://www.freedailypro.com/tool/qr-generator', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500);
  await p.locator('main input[type=file]').setInputFiles('/workspace/deep/06-qr-generator/testfiles/logo_wide_800x200_circle.png'); await p.waitForTimeout(1200);
  const d = await p.evaluate(() => document.querySelector('main canvas').toDataURL()); fs.writeFileSync('/workspace/deep/06-qr-generator/live/previews/Q31_logo_wide.png', Buffer.from(d.split(',')[1], 'base64'));
  await p.locator('main canvas').screenshot({ path: '/workspace/deep/06-qr-generator/live/x-Q31_logo_wide.png' }); await b.close(); })();
