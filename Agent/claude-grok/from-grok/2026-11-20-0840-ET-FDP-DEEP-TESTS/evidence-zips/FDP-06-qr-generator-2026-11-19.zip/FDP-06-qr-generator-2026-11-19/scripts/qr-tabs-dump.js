const { chromium } = require('playwright');
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage();
  await p.goto('https://www.freedailypro.com/tool/qr-generator', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  for (const tab of ['Link', 'Text', 'WiFi', 'Contact', 'Email', 'SMS', 'Phone']) {
    await p.getByRole('tab', { name: tab, exact: true }).click(); await p.waitForTimeout(500);
    const f = await p.evaluate(() => [...document.querySelectorAll('main input:not([type=color]):not([type=file]), main textarea, main [role=combobox], main input[type=file]')].map(e => { const lab = e.labels && e.labels[0] ? e.labels[0].innerText : (e.closest('div')?.parentElement?.querySelector('label')?.innerText || ''); return `${e.tagName}/${e.type || e.getAttribute('role')} label="${lab.trim()}" aria="${e.getAttribute('aria-label') || ''}" ph="${e.placeholder || ''}" val="${(e.value || e.innerText || '').slice(0, 30)}" acc="${e.accept || ''}"`; }));
    console.log('==', tab); f.forEach(x => console.log('  ', x)); }
  await b.close(); })();
