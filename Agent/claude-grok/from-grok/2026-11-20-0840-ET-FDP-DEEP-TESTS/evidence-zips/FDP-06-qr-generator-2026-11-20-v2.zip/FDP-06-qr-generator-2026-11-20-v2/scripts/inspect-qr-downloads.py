#!/usr/bin/env python3
"""Inspect downloaded QR files: pixel size, quiet zone (modules), colours, any extra marks (e.g. a 'Created with FreeDailyPro.com' badge: non-QR pixels in the corners / text in SVG), and decode with zxing-cpp + OpenCV. SVGs are rasterised with cairosvg.
Usage: inspect-qr-downloads.py <downloads dir> [out.json]"""
import sys, glob, os, io, json, re, zxingcpp, cv2, numpy as np
from PIL import Image
def decode(im):
    big = im.convert('RGB'); big = big.resize((big.width * 2, big.height * 2), Image.NEAREST) if big.width < 600 else big
    r = zxingcpp.read_barcodes(big); a = np.array(big)[:, :, ::-1]; t, _, _ = cv2.QRCodeDetector().detectAndDecode(a)
    return {'zxing': [x.text for x in r], 'ec': [str(getattr(x, 'ec_level', '')) for x in r], 'opencv': t, 'position': [str(x.position) for x in r]}
out = {}
for f in sorted(glob.glob(sys.argv[1] + '/*')):
    if os.path.isdir(f): continue
    rec = {'bytes': os.path.getsize(f)}
    if f.lower().endswith('.svg'):
        s = open(f, encoding='utf8', errors='ignore').read(); rec['svg_viewBox'] = (re.search(r'viewBox="([^"]+)"', s) or [None, None])[1]; rec['svg_has_image'] = '<image' in s; rec['svg_text'] = re.findall(r'<text[^>]*>([^<]*)', s)[:5]; rec['mentions_freedailypro'] = 'FreeDailyPro' in s or 'freedailypro' in s
        import cairosvg; im = Image.open(io.BytesIO(cairosvg.svg2png(bytestring=s.encode(), output_width=1000, output_height=1000)))
        bg = Image.new('RGBA', im.size, 'white'); bg.alpha_composite(im.convert('RGBA')); im = bg
    elif f.lower().endswith('.png'):
        im = Image.open(f); rec['png_size'] = im.size; rec['mode'] = im.mode
    else: out[os.path.basename(f)] = rec; continue
    rgb = np.array(im.convert('RGB')); h, w, _ = rgb.shape; bgc = rgb[2, 2]; mask = np.any(np.abs(rgb.astype(int) - bgc.astype(int)) > 40, axis=2)
    ys, xs = np.where(mask); rec['bg_colour'] = '#%02x%02x%02x' % tuple(bgc)
    if len(xs): rec['dark_bbox'] = [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())]; rec['margin_px'] = [int(xs.min()), int(ys.min()), int(w - 1 - xs.max()), int(h - 1 - ys.max())]
    q = int(min(w, h) * 0.12); rec['corner_br_nonbg_pixels'] = int(mask[h - q:, w - q:].sum()) if q else 0
    rec.update(decode(im)); out[os.path.basename(f)] = rec; print(os.path.basename(f), json.dumps(rec, ensure_ascii=False)[:420])
json.dump(out, open(sys.argv[2] if len(sys.argv) > 2 else sys.argv[1] + '/inspection.json', 'w'), ensure_ascii=False, indent=1)
