// qr-generator DOWNLOAD battery in ONE uncapped fresh context (each download may spend a trial use). Run after midnight UTC (7:00 PM ET).
// Records strip + localStorage fdp-usage-v1 before/after each download (display-only evidence): does PNG + SVG of the same code cost 2? does a repeat cost again?
// Usage: node qr-battery.js [maxContextsToTry=6] [onlyScenarios]   ENGINE=webkit|firefox optional
// Afterwards: python3 scripts/inspect-qr-downloads.py /workspace/deep/06-qr-generator/live/downloads
const pw = require('playwright'); const chromium = pw[process.env.ENGINE || 'chromium']; if (process.env.ENGINE === 'webkit') process.env.GIO_EXTRA_MODULES = process.env.GIO_EXTRA_MODULES || (__dirname + '/giomods');
const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/06-qr-generator/live/'; const DL = OUT + 'downloads/'; const T = '/workspace/deep/06-qr-generator/testfiles/'; fs.mkdirSync(DL, { recursive: true });
const URL = 'https://www.freedailypro.com/tool/qr-generator';
const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
const maxTry = +(process.argv[2] || 6); const only = (process.argv[3] || '').split(',').filter(Boolean);
(async () => {
  const b = await chromium.launch(); const R = { started: now(), loads: [], scenarios: [] }; let ctx, p;
  const strip = () => p.evaluate(() => (document.body.innerText.match(/[^\n]*remaining today[^\n]*/) || [''])[0]);
  const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || 'null')?.usageToday;
  const dialogs = () => p.evaluate(() => [...document.querySelectorAll('[role=dialog],[role=alertdialog]')].map(t => t.innerText.replace(/\n+/g, ' | ').slice(0, 400)).join(' || '));
  for (let a = 0; a < maxTry; a++) {
    ctx = await b.newContext({ acceptDownloads: true, viewport: { width: 1366, height: 900 } }); p = await ctx.newPage();
    await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); const s = await strip(); R.loads.push({ attempt: a + 1, t: now(), strip: s, used: await used() }); console.log('load', a + 1, s);
    if (!/(^|[^0-9])0 remaining today/.test(s)) break; await ctx.close(); ctx = null;
  }
  if (!ctx) { R.blocked = `all ${maxTry} fresh contexts loaded at 0 remaining today`; const f = OUT + `battery-${Date.now()}.json`; fs.writeFileSync(f, JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); return; }
  const tab = async n => { await p.getByRole('tab', { name: n, exact: true }).click(); await p.waitForTimeout(300); };
  const fill = async (l, v) => p.getByLabel(l, { exact: true }).first().fill(v);
  const sel = async (cur, opt) => { await p.locator('main [role=combobox]').filter({ hasText: cur }).first().click(); await p.waitForTimeout(250); await p.getByRole('option', { name: opt }).first().click(); await p.waitForTimeout(300); };
  const save = async (name, fmt) => { const u0 = await used();
    try { const [d] = await Promise.all([p.waitForEvent('download', { timeout: 20000 }), p.getByRole('button', { name: 'Download ' + fmt }).click()]); const f = DL + name + '__' + d.suggestedFilename(); await d.saveAs(f); await p.waitForTimeout(1200);
      return { name: d.suggestedFilename(), file: f, bytes: fs.statSync(f).size, usedBefore: u0, usedAfter: await used(), strip: await strip() }; }
    catch (e) { return { err: 'no download: ' + e.message.split('\n')[0], dialog: await dialogs(), usedBefore: u0, usedAfter: await used() }; } };
  const S = {
    B1_link_png_1000_then_svg_then_png_again: async L => { L.png = await save('B1_png1000', 'PNG'); L.svg = await save('B1_svg', 'SVG'); L.pngAgain = await save('B1_png1000_again', 'PNG'); },
    B2_link_png_2000: async L => { await sel('1000 px', '2000 px'); L.png = await save('B2_png2000', 'PNG'); },
    B3_link_png_200: async L => { await sel('1000 px', '200 px'); L.png = await save('B3_png200', 'PNG'); },
    B4_wifi_special_png: async L => { await tab('WiFi'); await fill('Network name (SSID)', 'Café;Net,"5G":\\'); await fill('Password', 'p@ss;w,rd:"x"\\'); L.png = await save('B4_wifi', 'PNG'); },
    B5_contact_semicolon_png: async L => { await tab('Contact'); await fill('First name', 'José'); await fill('Last name', "O'Brien-Müller"); await fill('Company', 'Smith; Jones & Co, LLC'); await fill('Phone', '+1 555 010 2030'); L.png = await save('B5_vcard', 'PNG'); },
    B6_logo_png_and_svg: async L => { await p.locator('main input[type=file]').setInputFiles(T + 'logo_small_transparent.png'); await p.waitForTimeout(800); L.png = await save('B6_logo', 'PNG'); L.svg = await save('B6_logo', 'SVG'); },
    B7_brand_colours_png_svg: async L => { await p.getByLabel('Code colour').fill('#0d4f4a'); await p.getByLabel('Background colour').fill('#fff7e6'); L.png = await save('B7_colour', 'PNG'); L.svg = await save('B7_colour', 'SVG'); },
    B8_long_text_L_png: async L => { await sel('M (15%)', /^L/); await tab('Text'); await fill('Text', 'y'.repeat(2900)); L.png = await save('B8_long', 'PNG'); },
  };
  for (const [name, fn] of Object.entries(S)) {
    if (only.length && !only.includes(name)) continue; const L = { name, t0: now() };
    try { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); L.before = await strip(); L.usedBefore = await used(); await fn(L); L.after = await strip(); L.usedAfter = await used(); L.dialog = await dialogs(); }
    catch (e) { L.error = e.message.split('\n')[0]; }
    R.scenarios.push(L); console.log(name, '|', L.before, '->', L.after, '| used', L.usedBefore, '->', L.usedAfter, L.error || '');
    if (/(^|[^0-9])0 remaining today/.test(L.after || '')) { R.stoppedAt = name + ' (0 remaining)'; break; }
  }
  try { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); R.afterReload = { strip: await strip(), used: await used() }; } catch (e) {}
  R.finished = now(); const f = OUT + `battery-${Date.now()}.json`; fs.writeFileSync(f, JSON.stringify(R, null, 1)); console.log('wrote', f); await b.close();
})();
