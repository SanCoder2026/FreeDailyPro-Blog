// custom-qr (Premium, 2 trial uses/day) DOWNLOAD battery. Each "context" is a fresh guest context (its own 2 trial uses). Records the strip + fdp-usage-v1 before/after every download (display-only).
// Usage: node cq-battery.js [contexts comma list, default all]   Afterwards: python3 scripts/inspect-qr-downloads.py live/downloads  (+ pdf/zip checks in scripts/inspect-cq-extra.py)
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/07-custom-qr/live/'; const DL = OUT + 'downloads/'; const T = '/workspace/deep/07-custom-qr/testfiles/'; fs.mkdirSync(DL, { recursive: true });
const URL = 'https://www.freedailypro.com/tool/custom-qr'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const only = (process.argv[2] || '').split(',').filter(Boolean);
(async () => { const b = await chromium.launch(); const R = { started: now(), contexts: [] };
  const CTX = {
    A_png_svg_then_pdf_capped: [['dl', 'A1_png1000', 'Download PNG'], ['dl', 'A2_svg', 'Download SVG'], ['dl', 'A3_pdf_should_be_capped', 'Download vector PDF']],
    B_pdf_frame_logo_then_zip2000: [['frame', 'Escanéame 扫码'], ['logo', 'logo_small_transparent.png'], ['dl', 'B1_pdf_frame_logo', 'Download vector PDF'], ['size', '2000 px'], ['bulk', 'https://a.example\nhttps://b.example\nname3,https://c.example'], ['dl', 'B2_zip_2000', /^Download ZIP of/]],
    C_unicode_text_png_vcard_png: [['text', 'Line 1\nGrüße 日本 👍'], ['dl', 'C1_unicode_png', 'Download PNG'], ['contact', 'Smith; Jones & Co, LLC'], ['dl', 'C2_vcard_png', 'Download PNG']],
    E_count_trace_4_downloads_new_content: [['dl', 'E1_png_default', 'Download PNG'], ['url', 'https://e2.example/'], ['dl', 'E2_png_new_url', 'Download PNG'], ['url', 'https://e3.example/'], ['dl', 'E3_svg_new_url', 'Download SVG'], ['url', 'https://e4.example/'], ['dl', 'E4_png_at_zero', 'Download PNG']],
    F_zip_2000_then_png2000: [['size', '2000 px'], ['bulk', 'https://a.example\nhttps://b.example\nname3,https://c.example'], ['dl', 'F1_zip_2000', /^Download ZIP of/], ['dl', 'F2_png2000', 'Download PNG']],
    H_reload_between_downloads: [['dl', 'H1_png', 'Download PNG'], ['reload'], ['dl', 'H2_png_after_reload', 'Download PNG'], ['reload'], ['dl', 'H3_png_after_reload_at_zero', 'Download PNG']],
    D_widelogo_svg_extra_gradient_png2000: [['logo', 'logo_wide_800x200_circle.png'], ['dl', 'D1_widelogo_svg', 'Download SVG'], ['grad', ''], ['size', '2000 px'], ['dl', 'D2_gradient_png2000', 'Download PNG']],
  };
  for (const [cname, steps] of Object.entries(CTX)) { if (only.length && !only.includes(cname)) continue;
    const ctx = await b.newContext({ acceptDownloads: true, viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); const C = { name: cname, t0: now(), steps: [] };
    const strip = () => p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*remaining today/) || [''])[0]);
    const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || 'null')?.usageToday;
    const dialogs = () => p.evaluate(() => [...document.querySelectorAll('[role=dialog],[role=alertdialog]')].map(t => t.innerText.replace(/\n+/g, ' | ').slice(0, 500)).join(' || '));
    await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); C.startStrip = await strip(); C.startUsed = await used();
    for (const [k, a, v] of steps) { const S = { k, a };
      try {
        if (k === 'frame') { await p.locator('main label').filter({ hasText: /label frame/ }).first().click(); await p.getByLabel('Frame text').fill(a); }
        if (k === 'logo') { await p.locator('main input[type=file]').setInputFiles(T + a); await p.waitForTimeout(800); }
        if (k === 'size') { await p.locator('main [role=combobox]').filter({ hasText: /px$/ }).first().click(); await p.waitForTimeout(250); await p.getByRole('option', { name: a, exact: true }).click(); }
        if (k === 'bulk') await p.getByLabel('Entries, one per line').fill(a);
        if (k === 'text') { await p.getByRole('tab', { name: 'Text', exact: true }).click(); await p.locator('main textarea').first().fill(a); }
        if (k === 'contact') { await p.getByRole('tab', { name: 'Contact', exact: true }).click(); await p.getByLabel('First name', { exact: true }).fill('José'); await p.getByLabel('Company', { exact: true }).first().fill(a); }
        if (k === 'reload') { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); S.strip = await strip(); S.used = await used(); }
        if (k === 'url') await p.getByLabel('Web address', { exact: true }).fill(a);
        if (k === 'grad') { await p.locator('main label').filter({ hasText: /two-colour gradient/ }).first().click(); await p.locator('main [role=combobox]').nth(0).click(); await p.getByRole('option', { name: 'Extra rounded', exact: true }).click(); }
        if (k === 'dl') { const u0 = await used(); const s0 = await strip();
          try { const [d] = await Promise.all([p.waitForEvent('download', { timeout: 60000 }), p.getByRole('button', { name: v }).first().click()]); const f = DL + a + '__' + d.suggestedFilename(); await d.saveAs(f); await p.waitForTimeout(1500);
            Object.assign(S, { file: d.suggestedFilename(), bytes: fs.statSync(f).size }); }
          catch (e) { S.err = 'no download: ' + e.message.split('\n')[0]; S.dialog = await dialogs(); await p.screenshot({ path: OUT + 'bat-' + a + '.png' }); await p.keyboard.press('Escape'); }
          Object.assign(S, { usedBefore: u0, usedAfter: await used(), stripBefore: s0, stripAfter: await strip(), toast: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.replace(/\n/g, ' ')).join(' | ')) }); }
        await p.waitForTimeout(500);
      } catch (e) { S.error = e.message.split('\n')[0]; }
      C.steps.push(S); console.log(cname, JSON.stringify(S).slice(0, 300)); }
    await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); C.afterReload = { strip: await strip(), used: await used() }; C.t1 = now(); R.contexts.push(C); await ctx.close(); }
  R.finished = now(); const f = OUT + `battery-${Date.now()}.json`; fs.writeFileSync(f, JSON.stringify(R, null, 1)); console.log('wrote', f); await b.close(); })();
