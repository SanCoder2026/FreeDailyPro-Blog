// custom-qr (Premium): types, dot/corner styles, gradient, frame, logos, limits, quiet zone. Reads the preview canvas only (no download, no trial use).
// Usage: node cq-explore.js [names]   then: python3 scripts/decode-previews.py live/previews
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/07-custom-qr/live/'; const PV = OUT + 'previews/'; const T = '/workspace/deep/07-custom-qr/testfiles/'; fs.mkdirSync(PV, { recursive: true });
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const only = (process.argv[2] || '').split(',').filter(Boolean);
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); const R = { t: now(), runs: [] };
  const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || 'null');
  const strip = () => p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*remaining today/) || [''])[0]);
  const fresh = async () => { await p.goto('https://www.freedailypro.com/tool/custom-qr', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); };
  const tab = async n => { await p.getByRole('tab', { name: n, exact: true }).click(); await p.waitForTimeout(300); };
  const fill = async (label, v) => { await p.getByLabel(label, { exact: true }).first().fill(v); };
  const sel = async (label, opt) => { const cb = p.locator('main div').filter({ has: p.locator(`label:text-is("${label}")`) }).locator('[role=combobox]').first(); await cb.click(); await p.waitForTimeout(250); await p.getByRole('option', { name: opt, exact: true }).first().click(); await p.waitForTimeout(400); };
  const check = async re => { await p.locator('main label').filter({ hasText: re }).first().click(); await p.waitForTimeout(400); };
  const state = async name => { await p.waitForTimeout(1000);
    const s = await p.evaluate(() => { const cs = [...document.querySelectorAll('main canvas')]; const c = cs[0]; const t = document.querySelector('main').innerText;
      const toasts = [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.replace(/\n/g, ' ')).join(' | ');
      return { canvases: cs.map(x => [x.width, x.height]), data: c ? c.toDataURL('image/png') : null, svgs: document.querySelectorAll('main svg[viewBox] rect, main .frame').length,
        warn: (t.match(/[^\n]*(contrast|inverted|Too long|Shorten|Enter some content|Logo added|upload an image|lighter)[^\n]*/gi) || []).join(' | '), combos: [...document.querySelectorAll('main [role=combobox]')].map(x => x.innerText).join(' / '), frameText: (t.match(/Scan me[^\n]*/) || [''])[0], toasts }; });
    if (s.data) fs.writeFileSync(PV + name + '.png', Buffer.from(s.data.split(',')[1], 'base64')); delete s.data; const u = await used(); s.used = u && u.usageToday; s.limit = u && u.limit; return s; };
  const S = {
    C01_default: async () => {},
    C02_dot_square: async () => { await sel('Dot style', 'Square'); await sel('Corner style', 'Square'); await sel('Corner centre', 'Square'); },
    C03_dot_dots: async () => { await sel('Dot style', 'Dots'); },
    C04_dot_classy: async () => { await sel('Dot style', 'Classy'); },
    C05_dot_classy_rounded: async () => { await sel('Dot style', 'Classy rounded'); },
    C06_dot_extra_rounded: async () => { await sel('Dot style', 'Extra rounded'); await p.locator('main [role=combobox]').nth(1).click(); await p.waitForTimeout(250); await p.getByRole('option', { name: 'Circle', exact: true }).click(); await p.waitForTimeout(400); },
    C07_gradient_dark: async () => { await check(/two-colour gradient/); await p.getByLabel('Gradient start').fill('#0d4f4a').catch(() => {}); await p.getByLabel(/Gradient end/).first().fill('#1e3a8a').catch(() => {}); },
    C08_gradient_light_end: async () => { await check(/two-colour gradient/); await p.getByLabel(/Gradient end/).first().fill('#d1d5db').catch(() => {}); },
    C09_inverted: async () => { await p.getByLabel('Code colour').fill('#ffffff'); await p.getByLabel('Background colour').fill('#111111'); },
    C10_frame_default: async () => { await check(/label frame/); },
    C11_frame_nonascii: async () => { await check(/label frame/); await p.getByLabel('Frame text').fill('Escanéame · 扫码 👍 long label text over 24'); },
    C12_logo_png: async () => { await p.locator('main input[type=file]').setInputFiles(T + 'logo_small_transparent.png'); },
    C13_logo_wide: async () => { await p.locator('main input[type=file]').setInputFiles(T + 'logo_wide_800x200_circle.png'); },
    C14_logo_svg: async () => { await p.locator('main input[type=file]').setInputFiles(T + 'logo.svg'); },
    C15_logo_fake: async () => { await p.locator('main input[type=file]').setInputFiles(T + 'text_renamed.png'); },
    C16_logo_pdf: async () => { await p.locator('main input[type=file]').setInputFiles(T + 'not_an_image.pdf'); },
    C17_logo_dots_style: async () => { await sel('Dot style', 'Dots'); await p.locator('main input[type=file]').setInputFiles(T + 'logo_photo_busy_2400x1600.jpg'); },
    C18_wifi_special: async () => { await tab('WiFi'); await fill('Network name (SSID)', 'Café;Net,"5G":\\'); await fill('Password', 'p@ss;w,rd:"x"\\'); },
    C19_contact_semicolon: async () => { await tab('Contact'); await fill('First name', 'José'); await fill('Company', 'Smith; Jones & Co, LLC'); },
    C20_email: async () => { await tab('Email'); await fill('To', 'a@example.com'); await fill('Subject (optional)', 'Hi & bye?'); },
    C21_sms: async () => { await tab('SMS'); await fill('Phone number', '+15550100'); await fill('Message (optional)', 'YES: ok'); },
    C22_phone: async () => { await tab('Phone'); await fill('Phone number', '+15550100'); },
    C23_text_multiline: async () => { await tab('Text'); await p.locator('main textarea').first().fill('Line 1\nGrüße 日本 👍'); },
    C24_no_scheme: async () => { await fill('Web address', 'example.com/menu'); },
    C25_empty: async () => { await fill('Web address', ''); },
    C26_long_2400: async () => { await tab('Text'); await p.locator('main textarea').first().fill('x'.repeat(2400)); },
    C27_long_3000: async () => { await tab('Text'); await p.locator('main textarea').first().fill('x'.repeat(3000)); },
    C28_long_url_logo_dots: async () => { await fill('Web address', 'https://example.com/' + 'a'.repeat(300)); await sel('Dot style', 'Dots'); await p.locator('main input[type=file]').setInputFiles(T + 'logo_small_transparent.png'); },
    C29_bulk_lines: async () => { await p.getByLabel('Entries, one per line').fill('https://a.example\nhttps://b.example\nhttps://a.example\n\n' + Array.from({ length: 205 }, (_, i) => 'https://x.example/' + i).join('\n')); },
  };
  await fresh(); R.start = { strip: await strip(), ls: await used() };
  for (const [name, fn] of Object.entries(S)) {
    if (only.length && !only.includes(name)) continue; const L = { name };
    try { await fresh(); await fn(); Object.assign(L, await state(name)); if (name === 'C29_bulk_lines') L.bulk = await p.evaluate(() => (document.querySelector('main').innerText.match(/Download ZIP of[^\n]*|Only the first[^\n]*/g) || []).join(' | ')); } catch (e) { L.error = e.message.split('\n')[0]; }
    if (['C10_frame_default', 'C11_frame_nonascii', 'C13_logo_wide', 'C08_gradient_light_end', 'C27_long_3000', 'C17_logo_dots_style'].includes(name)) await p.screenshot({ path: OUT + 'x-' + name + '.png' });
    R.runs.push(L); console.log(name, JSON.stringify(L).slice(0, 300));
  }
  R.end = { strip: await strip(), ls: await used() }; R.t2 = now(); const f = OUT + `explore-${Date.now()}.json`; fs.writeFileSync(f, JSON.stringify(R, null, 1)); console.log('START', JSON.stringify(R.start), 'END', JSON.stringify(R.end)); await b.close();
})();
