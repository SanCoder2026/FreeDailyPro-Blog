// custom-qr: what happens with long content (crash?), frame text field, Extra rounded + Circle. No download.
const { chromium } = require('playwright'); const fs = require('fs');
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); const R = {}; const errs = [];
  p.on('pageerror', e => errs.push(e.message.slice(0, 200))); p.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text().slice(0, 200)); });
  const go = async () => { await p.goto('https://www.freedailypro.com/tool/custom-qr', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); };
  for (const n of [1000, 2000, 2300, 2400, 3000]) { await go(); errs.length = 0; await p.getByRole('tab', { name: 'Text', exact: true }).click(); await p.locator('main textarea').first().fill('x'.repeat(n)); await p.waitForTimeout(1500);
    R['len' + n] = await p.evaluate(() => ({ main: !!document.querySelector('main'), body: document.body.innerText.slice(0, 300).replace(/\n/g, ' | '), canvas: !!document.querySelector('canvas') })); R['len' + n].errors = errs.slice(0, 4);
    if (n === 2400) await p.screenshot({ path: '/workspace/deep/07-custom-qr/live/x-long-2400-crash.png' }); }
  await go(); await p.locator('main label').filter({ hasText: /label frame/ }).first().click(); await p.waitForTimeout(500);
  R.frameInputs = await p.evaluate(() => [...document.querySelectorAll('main input')].map(i => `${i.type}|${i.getAttribute('aria-label')}|${i.value}|${i.maxLength}`));
  const ti = p.locator('main input[type=text]').nth(1); await ti.fill('Escanéame · 扫码 👍 long label text over 24').catch(e => R.frameFillErr = e.message.split('\n')[0]); await p.waitForTimeout(800);
  R.frameVal = await ti.inputValue().catch(() => null); R.framePreview = await p.evaluate(() => [...document.querySelectorAll('main *')].filter(e => e.children.length === 0 && /Escan|Scan me/.test(e.textContent)).map(e => e.tagName + ':' + e.textContent).slice(0, 4));
  await p.screenshot({ path: '/workspace/deep/07-custom-qr/live/x-C11_frame_nonascii.png' });
  await go(); const cb = p.locator('main [role=combobox]').nth(1); await cb.click(); await p.waitForTimeout(300); R.cornerOptions = await p.getByRole('option').allInnerTexts(); await p.keyboard.press('Escape');
  await p.locator('main [role=combobox]').nth(0).click(); await p.waitForTimeout(300); R.dotOptions = await p.getByRole('option').allInnerTexts(); await p.keyboard.press('Escape');
  await go(); await p.getByLabel('Web address', { exact: true }).fill(''); await p.waitForTimeout(800); R.emptyCanvas = await p.evaluate(() => document.querySelector('main canvas')?.toDataURL()); fs.writeFileSync('/workspace/deep/07-custom-qr/live/previews/C25b_empty.png', Buffer.from(R.emptyCanvas.split(',')[1], 'base64')); delete R.emptyCanvas;
  fs.writeFileSync('/workspace/deep/07-custom-qr/live/long-frame.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
