#!/usr/bin/env python3
"""Decode every QR PNG in a folder with zxing-cpp (and OpenCV as a 2nd opinion). Usage: decode-previews.py <dir> [out.json]"""
import sys, glob, json, os, zxingcpp, cv2
from PIL import Image, ImageOps
d = sys.argv[1]; out = {}
for f in sorted(glob.glob(d + '/*.png')):
    im = Image.open(f).convert('RGBA'); bg = Image.new('RGBA', im.size, 'white'); bg.alpha_composite(im); im = bg.convert('RGB')
    big = im.resize((im.width * 3, im.height * 3), Image.NEAREST)
    r = zxingcpp.read_barcodes(big); rec = {'zxing': [x.text for x in r], 'zxing_ec': [getattr(x, 'ec_level', '') for x in r], 'version': [getattr(x, 'version', '') for x in r]}
    if not r:
        inv = zxingcpp.read_barcodes(ImageOps.invert(big)); rec['zxing_inverted_only'] = [x.text for x in inv]
    cvimg = cv2.imread(f); txt, pts, _ = cv2.QRCodeDetector().detectAndDecode(cv2.resize(cvimg, None, fx=3, fy=3, interpolation=cv2.INTER_NEAREST)) if cvimg is not None else ('', None, None); rec['opencv'] = txt
    out[os.path.basename(f)] = rec; print(os.path.basename(f), json.dumps(rec, ensure_ascii=False)[:400])
json.dump(out, open(sys.argv[2] if len(sys.argv) > 2 else d + '/decoded.json', 'w'), ensure_ascii=False, indent=1)
