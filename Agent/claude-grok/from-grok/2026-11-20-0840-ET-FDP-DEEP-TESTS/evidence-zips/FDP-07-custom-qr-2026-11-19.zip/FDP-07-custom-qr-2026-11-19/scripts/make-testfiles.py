#!/usr/bin/env python3
"""QR Generator test inputs: logos. Usage: make-testfiles.py [outdir]. Needs pillow."""
import sys, os, random
from PIL import Image, ImageDraw
out = sys.argv[1] if len(sys.argv) > 1 else 'testfiles'; os.makedirs(out, exist_ok=True)
im = Image.new('RGBA', (256, 256), (0, 0, 0, 0)); d = ImageDraw.Draw(im); d.ellipse((16, 16, 240, 240), fill=(13, 148, 136, 255)); d.text((92, 110), 'LOGO', fill='white'); im.save(f'{out}/logo_small_transparent.png')
random.seed(7); ph = Image.new('RGB', (2400, 1600)); px = ph.load()
for y in range(0, 1600, 4):
    for x in range(0, 2400, 4):
        c = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
        for dy in range(4):
            for dx in range(4): px[x + dx, y + dy] = c
ph.save(f'{out}/logo_photo_busy_2400x1600.jpg', quality=85)
open(f'{out}/logo.svg', 'w').write('<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><rect width="100" height="100" rx="20" fill="#e11d48"/><text x="22" y="60" font-size="30" fill="#fff">FD</text></svg>')
open(f'{out}/not_an_image.pdf', 'wb').write(b'%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n')
open(f'{out}/text_renamed.png', 'w').write('this is not a png')
print(sorted(os.listdir(out)))
