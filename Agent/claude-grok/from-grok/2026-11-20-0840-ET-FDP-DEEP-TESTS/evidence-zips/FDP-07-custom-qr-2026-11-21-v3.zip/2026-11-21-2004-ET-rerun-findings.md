Sent: 2026-11-21 20:04 ET

# FDP-07 custom-qr: rerun after the 7:00 PM ET reset (Nov 21 2026)

Run 19:21 ET, `cq-battery.js B_pdf_frame_logo_then_zip2000,D_widelogo_svg_extra_gradient_png2000`, two fresh Chromium contexts each loaded at 2/2.
## New results (the two pending steps)
- **B2 bulk ZIP at 2000 px after a framed + logo PDF**: B1 PDF `custom-qr.pdf` 8,185 bytes cost 1 (2/2 -> 1/2); B2 `styled-qr-codes.zip` (3 lines incl. `name3,https://c.example`) 314,999 bytes downloaded with **0 further cost** (1 -> 1).
- **D1 wide-logo SVG**: one click cost **2** (strip 2 remaining -> 0), `custom-qr.svg` 34,944 bytes: the known "one click costs 2" re-confirmed on SVG.
- **D2 gradient PNG at 2000 px**: `custom-qr.png` 1,526,303 bytes **downloaded at 0 remaining** with no dialog (2 -> 2): the gate leak re-confirmed.
- Not run: CQ-25 (ticking "Lines are name,value"), WebKit context, real-phone scan (no phone on the box), unlocked PDF badge (no payment).
Evidence: live/battery-1795306915468.json, downloads.

(Rows run in order: 4,5,7,8,11,14,20 then 28-33,40,56,57,69,73. No sign-in, no payment, no ads clicked, no admin, no API/MCP. Counters are display-only evidence.)
