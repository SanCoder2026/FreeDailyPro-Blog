function n(c){const e=(c??"").replace(/\s+/g," ").trim(),t=/^(?:table\s*#?\s*)?#?(\d{1,4})$/i.exec(e);return t?`Table ${Number(t[1])}`:e}export{n as c};
//# sourceMappingURL=tableName-DsXKRx8V.js.map
