// bulk-qr download battery (COSTS trial uses). Run after midnight UTC (7:00 PM ET) in fresh contexts.
// Usage: node bq-battery.js [ctxNames,comma]     DRY=1 node bq-battery.js  -> fills everything, never clicks Generate/Save (free selector check)
// Each context skips itself if the strip shows 0 remaining. Downloads -> /workspace/deep/08-bulk-qr/live/downloads/<step>__<file>
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/08-bulk-qr/live/'; const URL = 'https://www.freedailypro.com/tool/bulk-qr'; const DRY = !!process.env.DRY;
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const lines = (n, base = 'https://example.com/item/') => Array.from({ length: n }, (_, i) => base + (i + 1)).join('\n');
const C = {
  A_count_trace: [['list', 'https://a.example\nhttps://b.example\nHello World'], ['gen', 'A1_png600'], ['gen', 'A2_same_again'], ['fmt', 'SVG (vector)'], ['gen', 'A3_svg']],
  B_names_unicode_csv: [['names', true], ['list', 'Shop,https://example.com/shop\n,https://example.com/nocomma\nCafé Grüße,https://example.com/x,y\nTable 1,https://example.com/menu\nTable 2,https://example.com/menu\n日本,Grüße 日本 👍\nFormula,=HYPERLINK("http://evil.example","x")\nNeg,-5+3'], ['size', '2000 px'], ['ec', 'H (30%)'], ['gen', 'B1_png2000_names']],
  C_500_at_300: [['list', lines(510)], ['size', '300 px'], ['gen', 'C1_500_png300']],
  D_passes_and_save: [['sample'], ['passes'], ['gen', 'D1_passes_zip'], ['save', 'D2_save_project']],
  E_too_long_entry: [['list', 'https://ok.example\nhttps://example.com/' + 'a'.repeat(3000)], ['gen', 'E1_too_long']],
};
(async () => {
  const pick = process.argv[2] ? process.argv[2].split(',') : Object.keys(C);
  fs.mkdirSync(OUT + 'downloads', { recursive: true }); const b = await chromium.launch(); const R = { dry: DRY, contexts: [] };
  for (const name of pick) {
    const ctx = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await ctx.newPage(); p.setDefaultTimeout(15000);
    await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
    const strip = async () => (await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]));
    const used = async () => p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
    const dlg = async () => (await p.locator('[role=dialog],[role=alertdialog]').count()) ? (await p.locator('[role=dialog],[role=alertdialog]').first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null;
    const X = { name, t0: now(), startStrip: await strip(), startUsed: await used(), steps: [] };
    if (/· 0 remaining/.test(X.startStrip) && !DRY) { X.skipped = 'capped at start'; R.contexts.push(X); console.log(name, 'SKIPPED (0 remaining)'); await ctx.close(); continue; }
    const combos = p.locator('main [role=combobox]');
    for (const [k, a] of C[name]) {
      const S = { k, a: typeof a === 'string' ? a.slice(0, 60) : a };
      try {
        if (k === 'list') await p.getByLabel('Enter URLs/text (one per line)').fill(a);
        if (k === 'names') { const cb = p.locator('label:has-text("Lines are") input[type=checkbox]'); if (!(await cb.isChecked())) await cb.click(); }
        if (k === 'fmt') { await combos.nth(0).click(); await p.getByRole('option', { name: a }).click(); }
        if (k === 'size') { await combos.nth(1).click(); await p.getByRole('option', { name: a }).click(); }
        if (k === 'ec') { await combos.nth(2).click(); await p.getByRole('option', { name: a }).click(); }
        if (k === 'sample') { await p.getByRole('button', { name: 'Try a sample' }).click(); await p.waitForTimeout(1500); }
        if (k === 'passes') { await p.getByTestId('bulk-mode-passes').click(); await p.waitForTimeout(2500); }
        await p.waitForTimeout(800); S.count = await p.getByTestId('bulk-count').innerText().catch(() => null);
        if (k === 'gen' || k === 'save') {
          S.usedBefore = await used(); S.stripBefore = await strip();
          if (!DRY) {
            const t = Date.now(); const dl = p.waitForEvent('download', { timeout: 120000 }).catch(e => null);
            await p.getByRole('button', { name: k === 'gen' ? 'Generate ZIP' : 'Save project' }).click();
            const d = await Promise.race([dl, (async () => { await p.waitForTimeout(8000); return (await dlg()) ? 'DIALOG' : dl; })()]);
            if (d && d !== 'DIALOG') { const fn = `${a}__${d.suggestedFilename()}`; await d.saveAs(OUT + 'downloads/' + fn); S.file = fn; S.bytes = fs.statSync(OUT + 'downloads/' + fn).size; S.ms = Date.now() - t; }
            else { S.dialog = await dlg(); if (S.dialog) await p.keyboard.press('Escape'); }
            await p.waitForTimeout(1500); S.toast = await p.locator('[data-sonner-toast]').allInnerTexts().catch(() => []);
            S.usedAfter = await used(); S.stripAfter = await strip();
          }
        }
      } catch (e) { S.err = String(e).slice(0, 200); }
      X.steps.push(S); console.log(name, JSON.stringify(S).slice(0, 400));
    }
    await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); X.afterReload = { strip: await strip(), used: await used() };
    R.contexts.push(X); await ctx.close();
  }
  const f = OUT + `battery-${DRY ? 'dry-' : ''}${Date.now()}.json`; fs.writeFileSync(f, JSON.stringify(R, null, 1)); console.log('wrote', f); await b.close();
})();
