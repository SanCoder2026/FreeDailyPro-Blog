// bulk-qr: free checks only (preview, counts, warnings, cap dialog at 0, sample project, save/open project). Never signs in, never pays.
// Usage: node bq-explore.js [scenarioNames,comma]   -> writes /workspace/deep/08-bulk-qr/live/explore-<ts>.json + previews/*.png
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/08-bulk-qr/live/'; const URL = 'https://www.freedailypro.com/tool/bulk-qr';
fs.mkdirSync(OUT + 'previews', { recursive: true }); fs.mkdirSync(OUT + 'downloads', { recursive: true });
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const long = n => 'https://example.com/' + 'a'.repeat(n - 20);
const lines = n => Array.from({ length: n }, (_, i) => `https://example.com/item/${i + 1}`).join('\n');
const S = {
  S01_empty: { text: '' },
  S02_three_urls: { text: 'https://example.com\nhttps://google.com\nHello World' },
  S03_dupes_blanks: { text: 'https://a.example\n\nhttps://a.example\n  https://a.example  \nhttps://b.example\n\n' },
  S04_name_value: { names: true, text: 'Shop,https://example.com/shop\n,https://example.com/nocomma\nOnlyName,\nTable 1,https://example.com/menu\nTable 2,https://example.com/menu\nCafé Grüße,https://example.com/x,y' },
  S05_unicode: { text: 'Grüße 日本 👍\nمرحبا بالعالم\nПривет' },
  S06_cap_510: { text: lines(510) },
  S07_long_301: { text: long(301) + '\nhttps://ok.example' },
  S08_long_3000: { text: long(3000) + '\nhttps://ok.example' },
  S09_light_code: { text: 'https://example.com', fg: '#cccccc' },
  S10_inverted: { text: 'https://example.com', fg: '#ffffff', bg: '#000000' },
  S11_svg_disables_size: { text: 'https://example.com', svg: true },
  S12_payloads: { text: 'WIFI:T:WPA;S:Cafe\\;Net;P:pa\\,ss;;\nBEGIN:VCARD\nmailto:a@example.com\n=HYPERLINK("http://evil.example","x")\n-5+3' },
  S13_twenty_lines: { text: lines(20) },
  S14_ec_H: { text: 'https://example.com', ec: 'H (30%)' },
};
(async () => {
  const pick = process.argv[2] ? process.argv[2].split(',') : Object.keys(S);
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await ctx.newPage();
  p.setDefaultTimeout(12000); const errs = []; p.on('pageerror', e => errs.push(String(e).slice(0, 200)));
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
  const R = { t0: now(), ls0: await p.evaluate(() => localStorage.getItem('fdp-usage-v1')), scen: {} };
  const txt = async sel => (await p.locator(sel).count()) ? (await p.locator(sel).first().innerText()) : null;
  const ta = p.getByLabel('Enter URLs/text (one per line)');
  for (const k of pick) {
    const s = S[k]; const r = {};
    try {
      if (await p.getByTestId('bulk-mode-list').count()) await p.getByTestId('bulk-mode-list').click();
      const cb = p.locator('label:has-text("Lines are") input[type=checkbox]'); if ((await cb.isChecked()) !== !!s.names) await cb.click();
      await p.locator('input[aria-label="Code colour"]').fill(s.fg || '#000000'); await p.locator('input[aria-label="Background colour"]').fill(s.bg || '#ffffff');
      const combos = p.locator('main [role=combobox]');
      await combos.nth(0).click(); await p.getByRole('option', { name: s.svg ? 'SVG (vector)' : 'PNG' }).click();
      if (!s.svg) { /* leave size */ }
      await combos.nth(2).click(); await p.getByRole('option', { name: s.ec || 'M (15%)' }).click();
      await ta.fill(s.text); await p.waitForTimeout(1800);
      r.count = await txt('[data-testid=bulk-count]');
      r.cap = await txt('[data-testid=bulk-cap]');
      r.longWarn = await txt('[data-testid=bulk-long-warning]');
      r.contrast = await txt('[data-testid=bulk-contrast-warning]');
      r.sizeDisabled = await combos.nth(1).isDisabled();
      r.generateDisabled = await p.getByRole('button', { name: /Generate ZIP|Generating/ }).isDisabled();
      r.more = await txt('[data-testid=bulk-preview] span');
      const imgs = await p.locator('[data-testid=bulk-preview] img').evaluateAll(es => es.map(e => ({ alt: e.alt, src: e.src })));
      r.previewCount = imgs.length; r.alts = imgs.map(i => i.alt.slice(0, 80));
      imgs.forEach((im, i) => fs.writeFileSync(`${OUT}previews/${k}_${String(i + 1).padStart(2, '0')}.png`, Buffer.from(im.src.split(',')[1], 'base64')));
    } catch (e) { r.err = String(e).slice(0, 300); }
    r.usage = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
    R.scen[k] = r; console.log(k, JSON.stringify({ ...r, alts: undefined }));
  }
  R.errors = errs; R.t1 = now();
  fs.writeFileSync(OUT + `explore-${Date.now()}.json`, JSON.stringify(R, null, 1)); await b.close();
})();
