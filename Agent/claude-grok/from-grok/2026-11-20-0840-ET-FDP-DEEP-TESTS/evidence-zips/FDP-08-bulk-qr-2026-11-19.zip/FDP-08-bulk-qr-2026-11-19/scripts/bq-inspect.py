#!/usr/bin/env python3
"""Inspect bulk-qr downloads without executing anything.
Usage: python3 bq-inspect.py <qr-codes.zip> [project.fdp-project.json] [out.json]
- Extracts the ZIP safely (rejects '..' and absolute names) next to the zip (<zip>-x/).
- For every PNG: pixel size, margin in px and in modules (finder width / 7), zxing-cpp decode + EC, non-white pixels in the bottom-right corner (mark check).
- For every SVG: rasterizes with cairosvg and does the same.
- Prints index.csv (BOM shown) and checks that each row's file exists and decodes to its value.
- With a project file: verifies FDP1 pass signatures (HMAC-SHA256, 14 chars) and the tag. The key is never printed.
Needs: pillow, numpy, zxing-cpp, cairosvg (all in /workspace/deep/venv-pdf).
"""
import sys, os, io, json, zipfile, csv, hmac, hashlib, base64
import numpy as np, zxingcpp
from PIL import Image
zp = sys.argv[1]; proj = sys.argv[2] if len(sys.argv) > 2 and sys.argv[2].endswith('.json') and 'project' in sys.argv[2] else None
out = sys.argv[-1] if sys.argv[-1].endswith('.json') and sys.argv[-1] != proj and len(sys.argv) > 2 else None
z = zipfile.ZipFile(zp)
for n in z.namelist():
    if '..' in n or n.startswith('/'): sys.exit('unsafe name in zip: ' + n)
xd = zp + '-x'; z.extractall(xd)
def img_info(im):
    im = im.convert('RGB'); a = np.array(im.convert('L')) < 128
    ys, xs = np.where(a)
    if not len(xs): return {'size': im.size, 'decode': [], 'note': 'no dark pixels'}
    top, left = ys.min(), xs.min(); run = 0
    while left + run < a.shape[1] and a[top, left + run]: run += 1
    mod = run / 7; r = zxingcpp.read_barcodes(im)
    corner = int((np.array(im)[-im.size[1] // 6:, -im.size[0] // 3:] != 255).any(axis=2).sum())
    return {'size': im.size, 'margin_px': int(left), 'module_px': round(mod, 2), 'margin_modules': round(float(left / mod), 2) if mod else None,
            'decode': [x.text for x in r], 'ec': [str(x.ec_level) for x in r], 'corner_nonwhite_px': corner}
res = {'zip': zp, 'bytes': os.path.getsize(zp), 'files': {}}
for i in z.infolist():
    if i.filename.endswith('.png'): res['files'][i.filename] = img_info(Image.open(io.BytesIO(z.read(i.filename))))
    elif i.filename.endswith('.svg'):
        import cairosvg
        png = cairosvg.svg2png(bytestring=z.read(i.filename), output_width=1000)
        info = img_info(Image.open(io.BytesIO(png))); info['svg_text_tags'] = z.read(i.filename).count(b'<text'); res['files'][i.filename] = info
raw = z.read('index.csv') if 'index.csv' in z.namelist() else b''
res['index_bom'] = raw.startswith(b'\xef\xbb\xbf'); res['index_rows'] = []
for row in csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))):
    f = res['files'].get(row['file'], {}); row['decodes_to_value'] = row['value'].lstrip("'") in f.get('decode', []) or row['value'] in f.get('decode', [])
    res['index_rows'].append(row)
if proj:
    k = json.load(open(proj))['project']['passKey']; b = lambda x: base64.urlsafe_b64encode(x).decode().rstrip('=')
    tag = b(hashlib.sha256(('tag:' + k).encode()).digest())[:6]; res['passes'] = []
    for row in res['index_rows']:
        p = row['value'].split('.')
        if len(p) == 4 and p[0] == 'FDP1':
            exp = b(hmac.new(k.encode(), f'FDP1.{p[1]}.{p[2]}'.encode(), hashlib.sha256).digest())[:14]
            res['passes'].append({'file': row['file'], 'tag_ok': p[1] == tag, 'sig_ok': p[3] == exp})
print(json.dumps(res, indent=1, ensure_ascii=False, default=str))
if out: json.dump(res, open(out, 'w'), indent=1, ensure_ascii=False, default=str)
