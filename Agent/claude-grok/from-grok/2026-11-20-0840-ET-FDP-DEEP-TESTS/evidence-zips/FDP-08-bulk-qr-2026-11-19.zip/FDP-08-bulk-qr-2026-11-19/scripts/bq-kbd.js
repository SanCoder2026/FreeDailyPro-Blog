// bulk-qr: cap dialog on Generate at 0, Try a sample -> guest passes, Save/Open project, keyboard, axe, phone layout. No sign-in, no payment.
const { chromium, devices } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/08-bulk-qr/live/'; const URL = 'https://www.freedailypro.com/tool/bulk-qr'; const TF = '/workspace/deep/08-bulk-qr/testfiles/';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const usage = p => p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
(async () => {
  const b = await chromium.launch(); const R = { t: now() };
  const ctx = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await ctx.newPage(); p.setDefaultTimeout(12000);
  const errs = []; p.on('pageerror', e => errs.push(String(e).slice(0, 200)));
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
  R.ls0 = await usage(p); R.strip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]);
  const dlg = async () => (await p.locator('[role=dialog], [role=alertdialog]').count()) ? (await p.locator('[role=dialog], [role=alertdialog]').first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 900) : null;
  const closeDlg = async () => { await p.keyboard.press('Escape'); await p.waitForTimeout(500); };
  // 1. Generate at 0
  await p.getByLabel('Enter URLs/text (one per line)').fill('https://a.example\nhttps://b.example');
  let d = null; p.once('download', x => d = x); await p.getByRole('button', { name: 'Generate ZIP' }).click(); await p.waitForTimeout(2500);
  R.generate = { download: d ? d.suggestedFilename() : null, dialog: await dlg(), toast: await p.locator('[data-sonner-toast]').allInnerTexts().catch(() => []), ls: await usage(p) };
  await p.screenshot({ path: OUT + 'capped-generate.png' }); await closeDlg();
  // 2. Try a sample
  await p.getByRole('button', { name: 'Try a sample' }).click(); await p.waitForTimeout(2000);
  R.sampleDialog = await dlg(); if (R.sampleDialog) { await p.screenshot({ path: OUT + 'sample-dialog.png' }); const ok = p.locator('[role=dialog] button').filter({ hasText: /sample|load|replace|yes|ok|continue/i }); if (await ok.count()) await ok.first().click(); await p.waitForTimeout(1500); }
  R.passesBtn = await p.getByTestId('bulk-mode-passes').innerText();
  await p.getByTestId('bulk-mode-passes').click(); await p.waitForTimeout(2500);
  R.whichGuests = await p.locator('select[aria-label="Which guests"] option').allInnerTexts().catch(() => []);
  R.passCount = await p.getByTestId('bulk-count').innerText().catch(() => null);
  const imgs = await p.locator('[data-testid=bulk-preview] img').evaluateAll(es => es.map(e => ({ alt: e.alt, src: e.src })));
  R.passAlts = imgs.map(i => i.alt); fs.mkdirSync(OUT + 'previews', { recursive: true });
  imgs.forEach((im, i) => fs.writeFileSync(`${OUT}previews/P_pass_${String(i + 1).padStart(2, '0')}.png`, Buffer.from(im.src.split(',')[1], 'base64')));
  await p.screenshot({ path: OUT + 'passes-mode.png', fullPage: false });
  // 3. Save project (a local file download)
  d = null; p.once('download', x => d = x); await p.getByRole('button', { name: 'Save project' }).click(); await p.waitForTimeout(3000);
  R.save = { download: d ? d.suggestedFilename() : null, dialog: await dlg(), ls: await usage(p) };
  if (d) { await d.saveAs(OUT + 'downloads/' + d.suggestedFilename()); } else if (R.save.dialog) await closeDlg();
  // 4. Open project with broken files
  R.open = {};
  for (const f of ['broken-project.json', 'text.txt', 'guessed-shape.json']) {
    try { const [fc] = await Promise.all([p.waitForEvent('filechooser', { timeout: 6000 }), p.getByRole('button', { name: 'Open project' }).click()]); await fc.setFiles(TF + f); await p.waitForTimeout(1800);
      R.open[f] = { toast: await p.locator('[data-sonner-toast]').allInnerTexts().catch(() => []), dialog: await dlg() }; if (R.open[f].dialog) await closeDlg();
    } catch (e) { R.open[f] = { err: String(e).slice(0, 160), dialog: await dlg() }; if (R.open[f].dialog) await closeDlg(); }
  }
  // 5. Keyboard: Tab order reaches textarea, checkbox, selects, generate
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  await p.getByLabel('Enter URLs/text (one per line)').focus(); const seq = [];
  for (let i = 0; i < 9; i++) { await p.keyboard.press('Tab'); seq.push(await p.evaluate(() => { const e = document.activeElement; return `${e.tagName}${e.type ? ':' + e.type : ''} ${(e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 30)}`; })); }
  R.tabSeq = seq;
  R.unlabelled = await p.evaluate(() => [...document.querySelectorAll('main input, main textarea, main select, main button')].filter(e => !(e.getAttribute('aria-label') || e.labels?.length || e.innerText?.trim() || e.getAttribute('aria-labelledby'))).map(e => e.outerHTML.slice(0, 120)));
  try { const axe = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8'); await p.addScriptTag({ content: axe });
    R.axe = await p.evaluate(async () => (await axe.run(document.querySelector('main'))).violations.map(v => ({ id: v.id, impact: v.impact, count: v.nodes.length, sample: v.nodes.slice(0, 2).map(n => n.target.join(' ') + ' :: ' + (n.failureSummary || '').slice(0, 90)) }))); } catch (e) { R.axe = String(e); }
  // 6. Phones: where is preview vs Generate
  for (const dn of ['Pixel 7', 'iPhone SE']) {
    const c = await b.newContext({ ...devices[dn], browserName: undefined }); const q = await c.newPage(); q.setDefaultTimeout(12000);
    await q.goto(URL, { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4000);
    await q.getByLabel('Enter URLs/text (one per line)').fill('https://a.example\nhttps://b.example\nhttps://c.example'); await q.waitForTimeout(1500);
    R['phone_' + dn] = await q.evaluate(() => { const r = e => e ? Math.round(e.getBoundingClientRect().top + scrollY) : null; const g = [...document.querySelectorAll('main button')].find(x => x.innerText.trim() === 'Generate ZIP');
      return { vw: innerWidth, sw: document.documentElement.scrollWidth, textareaY: r(document.querySelector('main textarea')), previewY: r(document.querySelector('[data-testid=bulk-preview]')), generateY: r(g), strip: (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0] }; });
    await q.screenshot({ path: OUT + `phone-${dn.replace(/\s/g, '-').toLowerCase()}-full.png`, fullPage: true }); await c.close();
  }
  R.errors = errs; R.t2 = now(); fs.writeFileSync(OUT + 'kbd.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close();
})();
