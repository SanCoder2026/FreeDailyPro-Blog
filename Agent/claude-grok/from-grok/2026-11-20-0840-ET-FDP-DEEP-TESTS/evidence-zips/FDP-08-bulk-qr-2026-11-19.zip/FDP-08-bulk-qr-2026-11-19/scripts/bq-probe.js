// bulk-qr: starting trial count + DOM inventory (no download)
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/08-bulk-qr/live/';
(async () => { const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); const JS=[]; p.on('response', r => { if (/\.js(\?|$)/.test(r.url()) && r.url().includes('freedailypro')) JS.push(r.url()); });
  await p.goto('https://www.freedailypro.com/tool/bulk-qr', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
  const R = { t: cp.execSync('date "+%F %T %Z"').toString().trim() };
  R.strip = await p.evaluate(() => (document.body.innerText.match(/[^\n]*(remaining today|trial uses? (a|per) day|uses left)[^\n]*/) || [''])[0]);
  R.ls = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
  R.inputs = await p.evaluate(() => [...document.querySelectorAll('main input, main textarea, main select, main [role=combobox], main [role=tab], main button')].map(e => ({ tag: e.tagName, type: e.type, role: e.getAttribute('role'), name: e.getAttribute('aria-label') || e.placeholder || e.innerText.trim().slice(0, 40), id: e.id, val: e.value })).filter(x => x.name || x.id));
  R.preview = await p.evaluate(() => [...document.querySelectorAll('main canvas, main img, main svg')].map(e => { const r = e.getBoundingClientRect(); return { tag: e.tagName, alt: e.getAttribute('alt'), cls: (e.getAttribute('class') || '').slice(0, 60), w: Math.round(r.width), h: Math.round(r.height), x: Math.round(r.x), y: Math.round(r.y) }; }).filter(x => x.w > 60));
  R.js = JS; R.mainText = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 1500));
  await p.screenshot({ path: OUT + 'probe.png', fullPage: false });
  fs.writeFileSync(OUT + 'probe.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
