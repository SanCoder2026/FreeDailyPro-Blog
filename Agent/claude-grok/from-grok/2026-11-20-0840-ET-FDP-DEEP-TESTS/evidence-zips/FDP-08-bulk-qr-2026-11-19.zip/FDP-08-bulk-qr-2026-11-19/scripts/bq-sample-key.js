// bulk-qr: is the "Try a sample" pass key the same in every fresh context? Reads the first pass preview alt text only.
const { chromium } = require('playwright'); const fs = require('fs');
(async () => { const b = await chromium.launch(); const out = [];
  for (let i = 0; i < 2; i++) { const c = await b.newContext(); const p = await c.newPage(); p.setDefaultTimeout(12000);
    await p.goto('https://www.freedailypro.com/tool/bulk-qr', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
    await p.getByRole('button', { name: 'Try a sample' }).click(); await p.waitForTimeout(1500);
    await p.getByTestId('bulk-mode-passes').click(); await p.waitForTimeout(2000);
    const a1 = await p.locator('[data-testid=bulk-preview] img').first().getAttribute('alt');
    await p.getByRole('button', { name: 'New project' }).click(); await p.waitForTimeout(1200);
    const dlg = (await p.locator('[role=dialog],[role=alertdialog]').count()) ? await p.locator('[role=dialog],[role=alertdialog]').first().innerText() : null;
    out.push({ ctx: i, sampleFirstPass: a1, newProjectDialog: dlg && dlg.slice(0, 300), passesBtnAfterNew: await p.getByTestId('bulk-mode-passes').innerText() }); await c.close(); }
  fs.writeFileSync('/workspace/deep/08-bulk-qr/live/sample-key.json', JSON.stringify(out, null, 1)); console.log(JSON.stringify(out, null, 1)); await b.close(); })();
