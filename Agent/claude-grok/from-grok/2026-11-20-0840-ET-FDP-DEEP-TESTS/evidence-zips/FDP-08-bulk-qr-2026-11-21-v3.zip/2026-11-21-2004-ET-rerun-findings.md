Sent: 2026-11-21 20:04 ET

# FDP-08 bulk-qr: rerun after the 7:00 PM ET reset (Nov 21 2026)

Run 19:21 ET, `bq-battery.js A_count_trace,B_names_unicode_csv`; both contexts loaded at 10 remaining. Inspection with `bq-inspect.py`.
## A - count trace (PASS)
- A1 generate 3 codes PNG 600: 0 -> 1. A2 same list again: **free** (1 -> 1). A3 switch to SVG: **free** (1 -> 1). So repeat generations and format changes in the same page load do not cost again. A1 ZIP 32,569 bytes: 600x600 PNGs, margin 3.99-4.01 modules, all decode to input, EC M, index.csv has BOM.
## B - names / Unicode / CSV (PASS with one note)
- 7 codes (1 duplicate skipped) at 2000 px, EC H: 0 -> 1, ZIP 610,817 bytes. All files 2000x2000, quiet zone 4.0-4.02 modules, all decode (including `Grüße 日本 👍`) with EC H.
- File names: accents are transliterated (`003-Cafe-Gru-e.png` for "Café Grüße"); a name made only of CJK falls back to the generic word **`005-code.png`** (the CJK name is kept in index.csv). Note for Claude: CJK-only names all collapse to the same "code" slug; the numeric prefix keeps files unique.
- index.csv: UTF-8 BOM present; **formula guard works**: `'=HYPERLINK(...)` and `'-5+3` are prefixed with an apostrophe in the value column (the QR itself still decodes to the raw value, which is intended).
Evidence: live/battery-1795306949266.json, downloads/A*.zip B*.zip, inspection JSON.

(Rows run in order: 4,5,7,8,11,14,20 then 28-33,40,56,57,69,73. No sign-in, no payment, no ads clicked, no admin, no API/MCP. Counters are display-only evidence.)
