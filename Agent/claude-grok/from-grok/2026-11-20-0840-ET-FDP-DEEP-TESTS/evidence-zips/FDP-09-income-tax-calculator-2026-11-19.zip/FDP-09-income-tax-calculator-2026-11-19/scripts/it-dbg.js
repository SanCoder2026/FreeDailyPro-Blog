const { chromium } = require('playwright');
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(10000);
 await p.goto('https://www.freedailypro.com/tool/income-tax-calculator', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 console.log(await p.evaluate(() => ({ strip: (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0], ls: localStorage.getItem('fdp-usage-v1'), btns: [...document.querySelectorAll('main button')].map(x => x.innerText.trim()).filter(Boolean), net: document.querySelector('[data-testid=it-net]')?.innerText, title: document.title, url: location.href })));
 await p.screenshot({ path: '/workspace/deep/09-income-tax-calculator/live/dbg-zero.png' }); await b.close(); })();
