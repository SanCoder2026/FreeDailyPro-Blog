// Custom Flat Rate mode: inputs, currencies, edge values. Read-only (no copy/save/print, so no trial use).
const { chromium } = require('playwright'); const fs = require('fs');
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(10000);
 await p.goto('https://www.freedailypro.com/tool/income-tax-calculator', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 await p.getByRole('button', { name: 'Custom Flat Rate' }).click(); await p.waitForTimeout(800);
 const R = { controls: await p.evaluate(() => [...document.querySelectorAll('main input, main select')].filter(e => e.offsetParent).map(e => ({ tag: e.tagName, label: e.getAttribute('aria-label') || (e.labels && e.labels[0] ? e.labels[0].innerText : ''), value: e.value, opts: e.tagName === 'SELECT' ? [...e.options].map(o => o.text).slice(0, 30) : undefined }))) };
 const inputs = p.locator('main input:visible'); const res = async () => (await p.locator('main').innerText()).match(/Estimated[\s\S]{0,400}/)?.[0].replace(/\n+/g, ' | ');
 R.default = await res(); const cases = [['100000', '30'], ['100000', '0'], ['100000', '100'], ['100000', '150'], ['100000', '-5'], ['100000', '12.5'], ['0', '20']];
 R.cases = []; for (const [i, r] of cases) { await inputs.nth(0).fill(i); await inputs.nth(1).fill(r); await p.waitForTimeout(500); R.cases.push({ i, r, out: (await res())?.slice(0, 300), alert: await p.locator('main [role=alert]').allInnerTexts() }); }
 await p.screenshot({ path: '/workspace/deep/09-income-tax-calculator/live/flat-rate.png' });
 fs.writeFileSync('/workspace/deep/09-income-tax-calculator/live/flat.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
