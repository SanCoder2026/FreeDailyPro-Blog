// income-tax-calculator: are Copy result / Save as text / Print / Ctrl+C gated at 0 trial uses? + axe, keyboard, phone. No sign-in, no payment.
const { chromium, devices } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/09-income-tax-calculator/live/'; const URL = 'https://www.freedailypro.com/tool/income-tax-calculator';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => {
  const b = await chromium.launch(); const R = { t: now() };
  const ctx = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true, permissions: ['clipboard-read', 'clipboard-write'] });
  await ctx.addInitScript(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
  const p = await ctx.newPage(); p.setDefaultTimeout(10000); await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
  const ls = () => p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
  const dlg = async () => (await p.locator('[role=dialog],[role=alertdialog]').count()) ? (await p.locator('[role=dialog],[role=alertdialog]').first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 400) : null;
  const esc = async () => { await p.keyboard.press('Escape'); await p.waitForTimeout(400); };
  R.ls0 = await ls(); R.strip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]);
  R.resultVisibleAtZero = await p.locator('[data-testid=it-net]').innerText().catch(() => null);
  await p.evaluate(() => navigator.clipboard.writeText('SENTINEL')).catch(() => {});
  await p.getByRole('button', { name: 'Copy result' }).click(); await p.waitForTimeout(1500);
  R.copyButton = { dialog: await dlg(), clipboard: await p.evaluate(() => navigator.clipboard.readText()).catch(e => 'ERR ' + e), toast: await p.locator('[data-sonner-toast]').allInnerTexts().catch(() => []), ls: await ls() };
  if (R.copyButton.dialog) { await p.screenshot({ path: OUT + 'gate-copy.png' }); await esc(); }
  let d = null; p.once('download', x => d = x); await p.getByRole('button', { name: 'Save as text' }).click(); await p.waitForTimeout(2000);
  R.saveText = { download: d ? d.suggestedFilename() : null, dialog: await dlg(), ls: await ls() };
  if (d) { await d.saveAs(OUT + 'saved-' + d.suggestedFilename()); R.saveText.content = fs.readFileSync(OUT + 'saved-' + d.suggestedFilename(), 'utf8').slice(0, 1500); }
  if (R.saveText.dialog) { await p.screenshot({ path: OUT + 'gate-save.png' }); await esc(); }
  await p.getByRole('button', { name: 'Print' }).click(); await p.waitForTimeout(1500);
  R.print = { printed: await p.evaluate(() => window.__printed), dialog: await dlg(), ls: await ls() }; if (R.print.dialog) await esc();
  // select result text and Ctrl+C
  await p.evaluate(() => navigator.clipboard.writeText('SENTINEL2')).catch(() => {});
  await p.locator('[data-testid=it-net]').selectText(); await p.keyboard.press('Control+C'); await p.waitForTimeout(1500);
  R.ctrlC = { dialog: await dlg(), clipboard: await p.evaluate(() => navigator.clipboard.readText()).catch(e => 'ERR ' + e), ls: await ls() }; if (R.ctrlC.dialog) await esc();
  // keyboard + axe
  await p.getByLabel('Annual income').focus(); const seq = [];
  for (let i = 0; i < 10; i++) { await p.keyboard.press('Tab'); seq.push(await p.evaluate(() => { const e = document.activeElement; return `${e.tagName} ${(e.getAttribute('aria-label') || e.id || e.innerText || '').trim().slice(0, 30)}`; })); }
  R.tabSeq = seq;
  R.live = await p.evaluate(() => ({ ariaLive: [...document.querySelectorAll('main [aria-live]')].map(e => e.getAttribute('aria-live')), statusRoles: document.querySelectorAll('main [role=status]').length }));
  try { const axe = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8'); await p.addScriptTag({ content: axe });
    R.axe = await p.evaluate(async () => (await axe.run(document.querySelector('main'))).violations.map(v => ({ id: v.id, impact: v.impact, count: v.nodes.length, sample: v.nodes.slice(0, 2).map(n => n.target.join(' ').slice(0, 120)) }))); } catch (e) { R.axe = String(e); }
  await p.screenshot({ path: OUT + 'desktop-tool.png' });
  for (const dn of ['Pixel 7', 'iPhone SE']) {
    const c = await b.newContext({ ...devices[dn] }); const q = await c.newPage(); await q.goto(URL, { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4000);
    R['phone_' + dn] = await q.evaluate(() => { const r = s => { const e = document.querySelector(s); return e ? Math.round(e.getBoundingClientRect().top + scrollY) : null; };
      return { vw: innerWidth, sw: document.documentElement.scrollWidth, incomeY: r('main input[aria-label="Annual income"]'), netY: r('[data-testid=it-net]'), vh: innerHeight, inputMode: document.querySelector('main input[aria-label="Annual income"]').inputMode }; });
    await q.screenshot({ path: OUT + `phone-${dn.replace(/\s/g, '-').toLowerCase()}-full.png`, fullPage: true }); await c.close(); }
  R.t2 = now(); fs.writeFileSync(OUT + 'gate.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close();
})();
