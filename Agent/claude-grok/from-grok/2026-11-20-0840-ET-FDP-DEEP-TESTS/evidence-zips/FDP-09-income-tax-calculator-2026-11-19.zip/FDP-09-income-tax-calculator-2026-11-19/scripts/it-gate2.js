// NOTE: no sentinel clipboard writes (page wraps navigator.clipboard.writeText with the trial gate).
// Copy-result trial cost: repeated copies in one load, and behaviour in a context that starts at 0 remaining. Records how many fresh contexts were used.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/09-income-tax-calculator/live/'; const URL = 'https://www.freedailypro.com/tool/income-tax-calculator';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const R = { t: now(), contexts: [] }; let zeroDone = false, repeatDone = false;
  for (let i = 0; i < 6 && !(zeroDone && repeatDone); i++) {
    const ctx = await b.newContext({ viewport: { width: 1366, height: 900 }, permissions: ['clipboard-read', 'clipboard-write'] });
    const p = await ctx.newPage(); p.setDefaultTimeout(10000); await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
    const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
    const strip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]);
    const row = { i, strip, startUsed: await used(), steps: [] }; R.contexts.push(row);
    const atZero = /· 0 remaining/.test(strip);
    if ((atZero && !zeroDone) || (!atZero && !repeatDone)) {
      for (let k = 0; k < 3; k++) {

        await p.getByRole('button', { name: 'Copy result' }).click(); await p.waitForTimeout(1500);
        const dl = p.locator('[role=dialog],[role=alertdialog]'); const dtext = (await dl.count()) ? (await dl.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null;
        row.steps.push({ k, used: await used(), dialog: dtext, clip: (await p.evaluate(() => navigator.clipboard.readText()).catch(() => 'ERR')).slice(0, 40), strip: await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]) });
        if (dtext) { if (atZero) await p.screenshot({ path: OUT + 'gate-copy-at-zero.png' }); await p.keyboard.press('Escape'); await p.waitForTimeout(400); }
      }
      // also Save as text at zero
      if (atZero) { let d = null; p.once('download', x => d = x); await p.getByRole('button', { name: 'Save as text' }).click(); await p.waitForTimeout(2000);
        const dl = p.locator('[role=dialog],[role=alertdialog]'); row.saveAtZero = { download: d ? d.suggestedFilename() : null, dialog: (await dl.count()) ? (await dl.first().innerText()).slice(0, 200) : null }; }
      if (atZero) zeroDone = true; else repeatDone = true;
    }
    await ctx.close(); }
  R.t2 = now(); fs.writeFileSync(OUT + 'gate2.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
