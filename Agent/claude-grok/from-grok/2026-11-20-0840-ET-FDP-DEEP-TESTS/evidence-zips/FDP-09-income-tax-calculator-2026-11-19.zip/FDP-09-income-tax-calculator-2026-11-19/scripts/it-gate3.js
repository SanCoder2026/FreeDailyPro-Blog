// At 0 remaining: Print button and Ctrl+C on selected result text (no clipboard sentinel writes).
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/09-income-tax-calculator/live/';
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 }, permissions: ['clipboard-read', 'clipboard-write'] });
 await c.addInitScript(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
 const p = await c.newPage(); p.setDefaultTimeout(10000); await p.goto('https://www.freedailypro.com/tool/income-tax-calculator', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 const R = { t: cp.execSync('date "+%F %T %Z"').toString().trim(), strip: await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]) };
 const dlg = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 160) : null; };
 await p.getByRole('button', { name: 'Print' }).click(); await p.waitForTimeout(1500); R.print = { printed: await p.evaluate(() => window.__printed), dialog: await dlg() };
 if (R.print.dialog) { await p.screenshot({ path: OUT + 'gate-print-at-zero.png' }); await p.keyboard.press('Escape'); await p.waitForTimeout(400); }
 await p.locator('[data-testid=it-net]').selectText(); await p.keyboard.press('Control+C'); await p.waitForTimeout(1500);
 R.ctrlC = { dialog: await dlg(), clip: await p.evaluate(() => navigator.clipboard.readText()).catch(e => 'ERR') };
 if (R.ctrlC.dialog) await p.screenshot({ path: OUT + 'gate-ctrlc-at-zero.png' });
 fs.writeFileSync(OUT + 'gate3.json', JSON.stringify(R, null, 1)); console.log(R); await b.close(); })();
