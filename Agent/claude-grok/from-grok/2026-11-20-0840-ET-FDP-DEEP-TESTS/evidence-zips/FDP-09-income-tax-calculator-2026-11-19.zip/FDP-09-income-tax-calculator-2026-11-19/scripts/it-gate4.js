// With uses left: does Save as text alone, or Print alone, cost a use? (first action of a visit). Skips contexts at 0. Max 6 fresh contexts.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/09-income-tax-calculator/live/';
(async () => { const b = await chromium.launch(); const R = { t: cp.execSync('date "+%F %T %Z"').toString().trim(), contexts: [] }; const todo = ['save', 'print'];
 for (let i = 0; i < 6 && todo.length; i++) {
  const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); await c.addInitScript(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
  const p = await c.newPage(); p.setDefaultTimeout(10000); await p.goto('https://www.freedailypro.com/tool/income-tax-calculator', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
  const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
  const row = { i, start: await used() }; R.contexts.push(row);
  if (row.start < 10) { const a = todo.shift(); row.action = a;
    if (a === 'save') { let d = null; p.once('download', x => d = x); await p.getByRole('button', { name: 'Save as text' }).click(); await p.waitForTimeout(2000); row.download = d ? d.suggestedFilename() : null; }
    else { await p.getByRole('button', { name: 'Print' }).click(); await p.waitForTimeout(1500); row.printed = await p.evaluate(() => window.__printed); }
    row.after = await used();
    await p.getByRole('button', { name: a === 'save' ? 'Save as text' : 'Print' }).click(); await p.waitForTimeout(1500); row.afterSecond = await used(); }
  await c.close(); }
 fs.writeFileSync(OUT + 'gate4.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R)); await b.close(); })();
