// income-tax-calculator: reads the live results for a case table (free; nothing downloaded). Writes live/cases-<ts>.json
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/09-income-tax-calculator/live/'; const URL = 'https://www.freedailypro.com/tool/income-tax-calculator';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const C = [
  ['T01_default', '85000', 'single', 'NONE', '0'], ['T02_zero', '0', 'single', 'NONE', '0'], ['T03_at_std', '16100', 'single', 'NONE', '0'],
  ['T04_hoh_50k', '50000', 'hoh', 'NONE', '0'], ['T05_mfj_120k_401k', '120000', 'mfj', 'NONE', '24500'], ['T06_single_250k', '250000', 'single', 'NONE', '0'],
  ['T07_mfj_300k', '300000', 'mfj', 'NONE', '0'], ['T08_single_800k', '800000', 'single', 'NONE', '0'], ['T09_mfs_400k', '400000', 'mfs', 'NONE', '0'],
  ['T10_se_100k', '100000', 'single', 'NONE', '0', true], ['T11_se_230k', '230000', 'single', 'NONE', '0', true], ['T12_se_232k', '232000', 'single', 'NONE', '0', true],
  ['T13_se_300', '300', 'single', 'NONE', '0', true], ['T14_se_250k_mfj', '250000', 'mfj', 'NONE', '0', true],
  ['T15_CA_85k', '85000', 'single', 'CA', '0'], ['T16_NY_85k', '85000', 'single', 'NY', '0'], ['T17_MD_85k', '85000', 'single', 'MD', '0'],
  ['T18_PA_85k_401k10k', '85000', 'single', 'PA', '10000'], ['T19_CA_hoh_85k', '85000', 'hoh', 'CA', '0'], ['T20_TX_85k', '85000', 'single', 'TX', '0'],
  ['T21_text_abc', 'abc', 'single', 'NONE', '0'], ['T22_negative', '-5', 'single', 'NONE', '0'], ['T23_commas', '1,000,000', 'single', 'NONE', '0'], ['T24_85k_suffix', '85k', 'single', 'NONE', '0'],
  ['T25_401k_over_limit', '120000', 'single', 'NONE', '30000'], ['T26_401k_60to63', '120000', 'single', 'NONE', '35750', false, '60to63'], ['T27_pre_gt_income', '20000', 'single', 'NONE', '25000'],
  ['T28_biweekly', '85000', 'single', 'NONE', '0', false, 'under50', 'biweekly'], ['T29_SC_60k', '60000', 'single', 'SC', '0'], ['T30_NJ_85k', '85000', 'single', 'NJ', '0'],
  ['T31_huge', '1e12', 'single', 'NONE', '0'], ['T32_decimal', '85000.75', 'single', 'NONE', '0'], ['T33_IN_85k', '85000', 'single', 'IN', '0'], ['T34_OH_85k', '85000', 'single', 'OH', '0'], ['T35_se_240k', '240000', 'single', 'NONE', '0', true], ['T36_se_245k', '245000', 'single', 'NONE', '0', true], ['T37_se_246k', '246000', 'single', 'NONE', '0', true], ['T38_se_260k', '260000', 'single', 'NONE', '0', true], ['T39_se_300k', '300000', 'single', 'NONE', '0', true], ['T40_se_100k_401k20k', '100000', 'single', 'NONE', '20000', true],
];
(async () => {
  const pick = process.argv[2] ? process.argv[2].split(',') : null;
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); p.setDefaultTimeout(10000);
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
  const R = { t0: now(), ls0: await p.evaluate(() => localStorage.getItem('fdp-usage-v1')), cases: {} };
  for (const [id, inc, fs, st, pre, se = false, age = 'under50', per = 'year'] of C) {
    if (pick && !pick.includes(id)) continue;
    const cb = p.locator('#self-employed'); if ((await cb.isChecked()) !== se) await cb.click();
    await p.getByLabel('Filing status').selectOption(fs); await p.getByLabel('State', { exact: true }).selectOption(st);
    await p.getByLabel('Show amounts per').selectOption(per);
    if (!se) await p.getByLabel('Age group for the 401(k) limit').selectOption(age);
    await p.getByLabel('Pre-tax contributions').fill(pre); await p.getByLabel('Annual income').fill(inc); await p.waitForTimeout(500);
    const r = await p.evaluate(() => {
      const m = document.querySelector('main'); const g = id => document.querySelector(`[data-testid=${id}]`)?.innerText ?? null;
      const boxes = [...m.querySelectorAll('.text-center.p-3')].map(e => e.innerText.replace(/\n/g, ': '));
      const notes = [...m.querySelectorAll('p.text-xs')].map(e => e.innerText).filter(t => /Taxable income|rates:|SDI|disability|local|city|county|Self-Employment Tax Calculator|Roth|not applied/i.test(t));
      const alerts = [...m.querySelectorAll('[role=alert]')].map(e => e.innerText);
      return { net: g('it-net'), fed: g('it-fed'), payroll: g('it-payroll'), state: g('it-state'), sdi: g('it-sdi'), total: g('it-total'), boxes, notes, alerts };
    });
    R.cases[id] = { input: { inc, fs, st, pre, se, age, per }, ...r }; console.log(id, JSON.stringify(r).slice(0, 330));
  }
  R.lsEnd = await p.evaluate(() => localStorage.getItem('fdp-usage-v1')); R.t1 = now();
  fs.writeFileSync(OUT + `cases-${Date.now()}.json`, JSON.stringify(R, null, 1)); await b.close();
})();
