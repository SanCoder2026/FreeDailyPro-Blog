#!/usr/bin/env python3
"""Independent 2026 US federal reference (IRS Rev. Proc. 2025-32, SSA wage base, IRS Notice 2025-67).
Employee: federal income tax + employee FICA. Self-employed: SE tax (92.35%, 12.4% to wage base, 2.9%, 0.9% addl),
half-SE deduction, QBI per §199A for a sole proprietor with NO W-2 wages / property (phase-out over $75k/$150k),
$400 minimum when QBI >= $1,000. Standard deduction only, no credits. Prints JSON.
"""
import json, sys
BR = {'single': [12400, 50400, 105700, 201775, 256225, 640600], 'mfj': [24800, 100800, 211400, 403550, 512450, 768700],
      'mfs': [12400, 50400, 105700, 201775, 256225, 384350], 'hoh': [17700, 67450, 105700, 201750, 256200, 640600]}
RATES = [.10, .12, .22, .24, .32, .35, .37]
STD = {'single': 16100, 'mfj': 32200, 'mfs': 16100, 'hoh': 24150}
WB = 184500; AMT = {'single': 200000, 'mfj': 250000, 'mfs': 125000, 'hoh': 200000}
QBI_T = {'single': 201750, 'hoh': 201750, 'mfs': 201775, 'mfj': 403500}; QBI_R = {'single': 75000, 'hoh': 75000, 'mfs': 75000, 'mfj': 150000}
def fed(ti, fs):
    t, lo = 0.0, 0
    for up, r in zip(BR[fs] + [float('inf')], RATES):
        if ti <= lo: break
        t += (min(ti, up) - lo) * r; lo = up
    return t
def calc(gross, fs='single', pre=0, se=False):
    pre = min(max(0, pre), gross); out = {}
    if se:
        ne = gross * .9235
        if ne < 400: ss = med = addl = 0
        else: ss = min(ne, WB) * .124; med = ne * .029; addl = max(0, ne - AMT[fs]) * .009
        payroll = ss + med + addl; half = (ss + med) / 2
        agi = max(0, gross - pre - half); ti_before = max(0, agi - STD[fs])
        qbi_inc = max(0, gross - half - pre)  # SE retirement contributions reduce QBI
        tent = .2 * qbi_inc
        # no W-2 wages/UBIA: wage limit = 0, so the deduction phases out across the range
        if ti_before <= QBI_T[fs]: q = tent
        elif ti_before >= QBI_T[fs] + QBI_R[fs]: q = 0
        else: q = tent * (1 - (ti_before - QBI_T[fs]) / QBI_R[fs])
        if qbi_inc >= 1000: q = max(q, 400) if ti_before <= QBI_T[fs] + QBI_R[fs] else q
        q = min(q, .2 * ti_before)
        ti = max(0, ti_before - q); out.update(qbi=round(q, 2), half_se=round(half, 2))
    else:
        payroll = min(gross, WB) * .062 + gross * .0145 + max(0, gross - AMT[fs]) * .009
        ti = max(0, gross - pre - STD[fs])
    f = fed(ti, fs); total = f + payroll
    out.update(taxable=round(ti, 2), fed=round(f, 2), payroll=round(payroll, 2), total_fed_payroll=round(total, 2), net_no_state=round(gross - total - pre, 2))
    return out
if __name__ == '__main__':
    print(json.dumps(calc(float(sys.argv[1]), sys.argv[2] if len(sys.argv) > 2 else 'single', float(sys.argv[3]) if len(sys.argv) > 3 else 0, len(sys.argv) > 4 and sys.argv[4] == 'se')))
