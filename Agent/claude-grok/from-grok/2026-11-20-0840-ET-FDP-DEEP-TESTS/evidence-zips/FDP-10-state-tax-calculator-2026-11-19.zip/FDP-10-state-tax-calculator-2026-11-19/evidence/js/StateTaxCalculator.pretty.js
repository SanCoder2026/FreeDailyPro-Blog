const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/CalcReport-DYILoD5G.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/CalcSteps-CMhW1YVy.js",
      "assets/ResultsTable-CpxaKI_z.js",
      "assets/history-BFlPLQri.js",
      "assets/index-D2ZT81un.js",
      "assets/index-BJxTAPRn.css",
      "assets/csv-DBvSFDe9.js",
      "assets/copy-DxyF2bO9.js",
      "assets/share-2-wJ7OG3q6.js",
      "assets/CalcHistory--fZP0yot.js",
      "assets/report-BSjR2Wxf.js",
      "assets/steps-X1Sejec4.js",
      "assets/table-CJAX3ymv.js",
    ]),
) => i.map((i) => d[i]);
import { e as L, I as oe, N as se, ap as ne } from "./index-D2ZT81un.js";
import { r as g, j as e } from "./vendor-react-D01g8YgM.js";
import { T as re } from "./ToolPage-DS5jbfzr.js";
import { R as le } from "./RatesNote-CuxdiVHq.js";
import { T as ie } from "./ToolInfoSection-M0kcUBq8.js";
import { u as ce } from "./useLogToolUsage-Z9wjl3dw.js";
import { p as de } from "./numberInput-5hjoxJ5z.js";
import {
  j as E,
  s as O,
  c as H,
  S as me,
  F as U,
  U as ue,
  k as G,
} from "./stateTaxData-BkbKzEdQ.js";
import { r as xe } from "./report-BSjR2Wxf.js";
import "./useUploadApi-CeBVbB2U.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-mA9gIB_c.js";
import "./share-2-wJ7OG3q6.js";
import "./copy-DxyF2bO9.js";
import "./workflowCta-QcLjv4ms.js";
import "./UsageAndUpgradeStrip-Ckl_cEoN.js";
import "./access-BBg1iIm1.js";
import "./useAdminAccess-D2xxeUJv.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-BaZhqv4P.js";
import "./map-pin-DiPhQKiV.js";
import "./FaqSection-DgbFc-d2.js";
import "./ToolVideoEmbed-DltoCXpM.js";
import "./GuideLinks-BsEl-oB0.js";
import "./blog-Cqpj3gtZ.js";
import "./info-BGlOhDp4.js";
import "./productCards-CAZfINO_.js";
import "./layers-B7zHnkyf.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-CmqWEytu.js";
import "./chevron-up-Bx33pgGu.js";
import "./copyText-Bf-LRJbj.js";
import "./steps-X1Sejec4.js";
import "./csv-DBvSFDe9.js";
import "./table-CJAX3ymv.js";
function pe(a, l) {
  return !a || a.kind === "none" || !a.localNote
    ? { status: "none", text: "" }
    : a.localAvg
      ? l
        ? {
            status: "included",
            avg: a.localAvg,
            text: `Includes an estimated local income tax of ${a.localAvg}% of state taxable income (a typical average; your city or county may be higher or lower). ${a.localNote}`,
          }
        : {
            status: "excluded",
            avg: a.localAvg,
            text: `State tax only: local income tax is not included, so your total is likely higher. ${a.localNote} Tick the local-tax box to add a typical ${a.localAvg}%.`,
          }
      : {
          status: "excluded",
          text: `Local income tax is not included. ${a.localNote} There is no average to apply, so add your city's tax yourself.`,
        };
}
function he(a, l) {
  return a.kind === "none" || !a.localNote
    ? "none"
    : a.localAvg
      ? l
        ? `included ${a.localAvg}%`
        : "not included"
      : "no average";
}
function fe(a) {
  return a
    ? "Includes an average local income tax for the states that have one (IN, MD, NY, OH, PA). Other local taxes (such as Michigan cities) are not included."
    : "State tax only: local income taxes are not included in any row. Tick the local-tax box to add an average for IN, MD, NY, OH and PA.";
}
function ge(a, l, o, m, i) {
  const d = E[a],
    c = O(a, l, o, m, { local: i });
  if (!d || d.kind === "none")
    return [
      {
        label: "Total estimated state income tax",
        from: null,
        to: null,
        ratePct: null,
        amount: 0,
      },
    ];
  const s = c.rows.map((y) => ({
      label: "Bracket",
      from: y.from,
      to: y.to,
      ratePct: y.rate,
      amount: y.tax,
    })),
    f = c.rows.reduce((y, w) => y + w.tax, 0);
  return (
    Math.abs(f - c.stateOnly) > 0.005 &&
      s.push({
        label: "Credits (personal exemption credit)",
        from: null,
        to: null,
        ratePct: null,
        amount: c.stateOnly - f,
      }),
    c.local > 0 &&
      s.push({
        label: `Local income tax (estimate, ${c.localRate}% average)`,
        from: null,
        to: null,
        ratePct: c.localRate,
        amount: c.local,
      }),
    s.push({
      label: "Total estimated state income tax",
      from: null,
      to: null,
      ratePct: null,
      amount: c.tax,
    }),
    s
  );
}
function ye(a, l, o, m, i, d) {
  const c = E[a];
  if (!c) return [];
  const s = O(a, l, o, m, { local: i });
  if (c.kind === "none")
    return [
      {
        label: "No state income tax",
        formula: `${c.name} does not tax wages`,
        inputs: { Income: d(l) },
        result: d(0),
      },
    ];
  const f = [
    {
      label: "Taxable income",
      formula:
        "Income - state standard deduction - personal exemptions (never below 0)",
      inputs: {
        Income: d(l),
        "Deduction and exemptions": d(Math.min(l, l - s.taxable)),
      },
      result: d(s.taxable),
    },
    {
      label: "Tax by bracket",
      formula:
        "For each bracket: taxable income inside the bracket x its rate; add the brackets (less any credit)",
      inputs: Object.fromEntries(
        s.rows.map((y, w) => [`Bracket ${w + 1} (${y.rate}%)`, d(y.tax)]),
      ),
      result: d(s.stateOnly),
    },
  ];
  return (
    s.local > 0
      ? (f.push({
          label: "Local income tax (estimate)",
          formula: "State taxable income x typical local average rate",
          inputs: {
            "State taxable income": d(s.taxable),
            "Local average": `${s.localRate}%`,
          },
          result: d(s.local),
        }),
        f.push({
          label: "Total",
          formula: "State tax + local tax",
          inputs: { "State tax": d(s.stateOnly), "Local tax": d(s.local) },
          result: d(s.tax),
        }))
      : f.push({
          label: "Total",
          formula: "State tax (local income tax not included)",
          inputs: { "State tax": d(s.stateOnly) },
          result: d(s.tax),
        }),
    f
  );
}
const I = [3.078, 3.762, 3.819, 3.876],
  be = {
    single: [12e3, 25e3, 5e4],
    mfj: [21600, 45e3, 9e4],
    hoh: [14400, 3e4, 6e4],
  },
  we =
    "Comptroller of Maryland, 2026 Maryland State and Local Income Tax Withholding Information (rates for payments on or after 1 Jan 2026)",
  ve =
    "https://www.marylandcomptroller.gov/content/dam/mdcomp/md/state-payroll/memos/2026/2026-maryland-state-and-local-withholding-information.pdf",
  D = (a, l, o, m = {}) => ({
    id: `md-${a}`,
    state: "MD",
    name: l,
    basis: "stateTaxable",
    residentRatePct: o,
    note: "Resident county tax on Maryland taxable income. Non-residents pay the special non-resident rate instead; not modelled.",
    source: we,
    sourceUrl: ve,
    asOf: "2026-11-01",
    ...m,
  }),
  Ne = [
    ["allegany", "Allegany County", 3.2],
    ["baltimore-county", "Baltimore County", 3.2],
    ["baltimore-city", "Baltimore City", 3.2],
    ["calvert", "Calvert County", 3.2],
    ["caroline", "Caroline County", 3.2],
    ["carroll", "Carroll County", 3.03],
    ["cecil", "Cecil County", 2.74],
    ["charles", "Charles County", 3.03],
    ["dorchester", "Dorchester County", 3.3],
    ["garrett", "Garrett County", 2.65],
    ["harford", "Harford County", 3.06],
    ["howard", "Howard County", 3.2],
    ["kent", "Kent County", 3.3],
    ["montgomery", "Montgomery County", 3.2],
    ["prince-georges", "Prince George's County", 3.2],
    ["queen-annes", "Queen Anne's County", 3.2],
    ["st-marys", "St. Mary's County", 3.2],
    ["somerset", "Somerset County", 3.2],
    ["talbot", "Talbot County", 2.4],
    ["washington", "Washington County", 2.95],
    ["wicomico", "Wicomico County", 3.2],
    ["worcester", "Worcester County", 2.25],
  ],
  F = [
    {
      id: "ny-nyc",
      state: "NY",
      name: "New York City (resident)",
      basis: "stateTaxable",
      note: "Resident tax by band on New York taxable income (3.078% to 3.876%). Before the NYC school tax credit and other credits, which are not modelled. Non-residents who work in the city do not pay it.",
      source:
        "NYC Department of Finance, Form NYC-1127 liability tables (tax year 2025), the same resident rate schedule",
      sourceUrl:
        "https://www.nyc.gov/assets/finance/downloads/pdf/25pdf/business_tax_forms/nyc-1127_2025.pdf",
      asOf: "2026-11-01",
    },
    {
      id: "ny-yonkers",
      state: "NY",
      name: "Yonkers (resident)",
      basis: "stateTax",
      pctOfStateTax: 16.75,
      note: "Resident surcharge: 16.75% of the New York State tax. The non-resident earnings tax is not modelled.",
      source:
        "NY State Tax Department, 2025 Form IT-201-I instructions (Yonkers resident tax rate 16.75%)",
      sourceUrl: "https://www.tax.ny.gov/pdf/2025/inc/it201i_2025.pdf",
      asOf: "2026-11-01",
    },
    ...Ne.map(([a, l, o]) => D(a, l, o)),
    D("anne-arundel", "Anne Arundel County", 2.7, {
      residentRatePct: void 0,
      tiers: {
        single: [
          { upTo: 5e4, ratePct: 2.7 },
          { upTo: 4e5, ratePct: 2.94 },
          { upTo: 1 / 0, ratePct: 3.2 },
        ],
        joint: [
          { upTo: 75e3, ratePct: 2.7 },
          { upTo: 48e4, ratePct: 2.94 },
          { upTo: 1 / 0, ratePct: 3.2 },
        ],
      },
      note: "Resident county tax in three bands on Maryland taxable income (single, married filing separately: 2.70% to $50,000, 2.94% to $400,000, 3.20% above; joint and head of household: $75,000 and $480,000).",
    }),
    D("frederick", "Frederick County", 2.25, {
      residentRatePct: void 0,
      tiers: {
        single: [
          { upTo: 25e3, ratePct: 2.25 },
          { upTo: 5e4, ratePct: 2.75 },
          { upTo: 15e4, ratePct: 2.96 },
          { upTo: 1 / 0, ratePct: 3.2 },
        ],
        joint: [
          { upTo: 25e3, ratePct: 2.25 },
          { upTo: 1e5, ratePct: 2.75 },
          { upTo: 25e4, ratePct: 2.96 },
          { upTo: 1 / 0, ratePct: 3.2 },
        ],
      },
      note: "Resident county tax in four bands on Maryland taxable income (single, married filing separately: 2.25% to $25,000, 2.75% to $50,000, 2.96% to $150,000, 3.20% above; joint and head of household: $25,000, $100,000 and $250,000).",
    }),
    {
      id: "pa-philadelphia",
      state: "PA",
      name: "Philadelphia (wage tax)",
      basis: "wages",
      residentRatePct: 3.735,
      workerRatePct: 3.425,
      note: "Wage (earnings) tax on pay: 3.735% for residents and 3.425% for non-residents who work in the city, from 1 July 2026. Low-income forgiveness (1.5%) is not modelled.",
      source:
        "City of Philadelphia, Earnings Tax (employees) page: rates from July 1, 2026",
      sourceUrl:
        "https://www.phila.gov/services/payments-assistance-taxes/taxes/income-taxes/earnings-tax-employees/",
      asOf: "2026-11-01",
    },
    {
      id: "mi-detroit",
      state: "MI",
      name: "Detroit",
      basis: "wages",
      residentRatePct: 2.4,
      workerRatePct: 1.2,
      note: "City income tax on taxable income, treated here as your pay: 2.4% for residents, 1.2% for non-residents who work in Detroit. The city's page is dated; confirm with the Detroit Income Tax Division.",
      source: "City of Detroit, Income Tax Information page",
      sourceUrl:
        "https://detroitmi.gov/departments/office-chief-financial-officer/ocfo-divisions/office-treasury/income-tax/income-tax-information",
      asOf: "2026-11-01",
    },
    {
      id: "mo-kansas-city",
      state: "MO",
      name: "Kansas City",
      basis: "wages",
      residentRatePct: 1,
      workerRatePct: 1,
      note: "1% earnings tax on pay: residents pay on all earnings, non-residents only on earnings inside the city.",
      source: "City of Kansas City, Missouri, Earnings Tax page",
      sourceUrl:
        "https://www.kcmo.gov/city-hall/departments/finance/earnings-tax",
      asOf: "2026-11-01",
    },
    {
      id: "mo-st-louis",
      state: "MO",
      name: "St. Louis",
      basis: "wages",
      residentRatePct: 1,
      workerRatePct: 1,
      note: "1% earnings tax on pay, for residents and for people who work inside the city.",
      source:
        "City of St. Louis Collector of Revenue, Personal Earnings Tax page",
      sourceUrl: "https://www.stlouis-mo.gov/collector/earnings-tax-home.cfm",
      asOf: "2026-11-01",
    },
    {
      id: "oh-columbus",
      state: "OH",
      name: "Columbus",
      basis: "wages",
      residentRatePct: 2.5,
      note: "2.5% city income tax on qualifying wages for residents. Non-residents who work in Columbus and credits for tax paid elsewhere are not modelled.",
      source: "City of Columbus Income Tax Division page (2.5% income tax)",
      sourceUrl:
        "https://www.columbus.gov/Government/City-Auditor/Income-Tax-Division",
      asOf: "2026-11-01",
    },
  ],
  K = Object.fromEntries(F.map((a) => [a.id, a]));
function je(a) {
  return F.filter((l) => l.state === a);
}
Array.from(new Set(F.map((a) => a.state)));
const q = (a, l) => {
  let o = 0,
    m = 0;
  for (const i of l) {
    if (a <= o) break;
    ((m += ((Math.min(a, i.upTo) - o) * i.ratePct) / 100), (o = i.upTo));
  }
  return m;
};
function Pe(a, l, o) {
  const m = (s) => Math.round(s * 100) / 100;
  if (l === "worker") {
    if (a.workerRatePct === void 0)
      throw new Error(
        `${a.name}: a rate for people who work there but live elsewhere is not available.`,
      );
    const s = (o.income * a.workerRatePct) / 100;
    return {
      amount: m(s),
      ratePct: a.workerRatePct,
      base: o.income,
      baseLabel: "pay",
      lines: [
        {
          label: `${a.name}: non-resident rate ${a.workerRatePct}% of pay`,
          amount: m(s),
        },
      ],
    };
  }
  if (a.id === "ny-nyc") {
    const s =
        o.filing === "mfj" ? "mfj" : o.filing === "hoh" ? "hoh" : "single",
      [f, y, w] = be[s],
      S = [
        { upTo: f, ratePct: I[0] },
        { upTo: y, ratePct: I[1] },
        { upTo: w, ratePct: I[2] },
        { upTo: 1 / 0, ratePct: I[3] },
      ],
      k = q(o.taxable, S);
    return {
      amount: m(k),
      ratePct: o.taxable > 0 ? (k / o.taxable) * 100 : 0,
      base: o.taxable,
      baseLabel: "New York taxable income",
      lines: [
        {
          label: "New York City resident tax (bands of 3.078% to 3.876%)",
          amount: m(k),
        },
      ],
    };
  }
  if (a.pctOfStateTax !== void 0) {
    const s = (o.stateTax * a.pctOfStateTax) / 100;
    return {
      amount: m(s),
      ratePct: o.taxable > 0 ? (s / o.taxable) * 100 : 0,
      base: o.stateTax,
      baseLabel: "New York State tax",
      lines: [
        {
          label: `${a.name}: ${a.pctOfStateTax}% of New York State tax`,
          amount: m(s),
        },
      ],
    };
  }
  const i = a.basis === "wages" ? o.income : o.taxable,
    d = a.basis === "wages" ? "pay" : "state taxable income";
  if (a.tiers) {
    const s = q(
      i,
      o.filing === "mfj" || o.filing === "hoh" ? a.tiers.joint : a.tiers.single,
    );
    return {
      amount: m(s),
      ratePct: i > 0 ? (s / i) * 100 : 0,
      base: i,
      baseLabel: d,
      lines: [{ label: `${a.name} resident tax (bands)`, amount: m(s) }],
    };
  }
  const c = (i * (a.residentRatePct ?? 0)) / 100;
  return {
    amount: m(c),
    ratePct: a.residentRatePct ?? 0,
    base: i,
    baseLabel: d,
    lines: [
      { label: `${a.name}: ${a.residentRatePct}% of ${d}`, amount: m(c) },
    ],
  };
}
const _ = 184500,
  ke = [
    {
      id: "ca-sdi",
      state: "CA",
      name: "California State Disability Insurance (SDI)",
      ratePct: 1.3,
      capUsd: null,
      note: "1.3% of all 2026 wages, no wage limit.",
      source:
        "California EDD, contribution rates and withholding schedules (2026 SDI 1.3%, no taxable wage limit)",
      sourceUrl: "https://edd.ca.gov/en/payroll_taxes/rates_and_withholding/",
      asOf: "2026-11-01",
    },
    {
      id: "ny-pfl",
      state: "NY",
      name: "New York Paid Family Leave (PFL)",
      ratePct: 0.432,
      capUsd: 95348.76,
      note: "0.432% of gross wages up to $95,348.76 (a maximum of $411.91 for 2026). New York's disability (SDI) deduction is not modelled.",
      source:
        "NY Paid Family Leave, 2026 updates (rate 0.432%, maximum $411.91, wage cap $95,348.76)",
      sourceUrl: "https://paidfamilyleave.ny.gov/2026",
      asOf: "2026-11-01",
    },
    {
      id: "nj-tdi",
      state: "NJ",
      name: "New Jersey Temporary Disability Insurance (TDI)",
      ratePct: 0.19,
      capUsd: 171100,
      note: "0.19% of wages up to $171,100 (worker rate, 2026). Unemployment and workforce contributions are not included.",
      source:
        "NJ Department of Labor, 2026 worker contribution rates and taxable wage bases",
      sourceUrl: "https://www.nj.gov/labor/ea/employer-services/rate-info/",
      asOf: "2026-11-01",
    },
    {
      id: "nj-fli",
      state: "NJ",
      name: "New Jersey Family Leave Insurance (FLI)",
      ratePct: 0.23,
      capUsd: 171100,
      note: "0.23% of wages up to $171,100 (worker rate, 2026).",
      source:
        "NJ Department of Labor, 2026 worker contribution rates and taxable wage bases",
      sourceUrl: "https://www.nj.gov/labor/ea/employer-services/rate-info/",
      asOf: "2026-11-01",
    },
    {
      id: "wa-pfml",
      state: "WA",
      name: "Washington Paid Family and Medical Leave (employee share)",
      ratePct: 0.8072,
      capUsd: _,
      note: "Premium 1.13% of wages up to the $184,500 Social Security cap; employees pay 71.43% of it (0.8072%) where the employer has 50 or more employees.",
      source:
        "WA Employment Security Department, 2026 premium rate 1.13%, employee share 71.43%; Paid Leave: wage cap $184,500",
      sourceUrl: "https://paidleave.wa.gov/estimate-your-paid-leave-payments/",
      asOf: "2026-11-01",
    },
    {
      id: "wa-cares",
      state: "WA",
      name: "Washington WA Cares (long-term care)",
      ratePct: 0.58,
      capUsd: null,
      note: "0.58% of all wages, no cap, paid by the employee.",
      source:
        "WA Paid Leave, estimate your payments page (WA Cares premium 0.58%, no wage cap)",
      sourceUrl: "https://paidleave.wa.gov/estimate-your-paid-leave-payments/",
      asOf: "2026-11-01",
    },
    {
      id: "ma-pfml",
      state: "MA",
      name: "Massachusetts Paid Family and Medical Leave (employee share)",
      ratePct: 0.46,
      capUsd: _,
      note: "Total rate 0.88% for employers with 25 or more covered workers; employees can be charged up to 0.46% (0.18% family leave plus 40% of the 0.70% medical leave), up to the Social Security wage cap.",
      source:
        "Mass.gov, PFML employer contribution rates and calculator (2026)",
      sourceUrl:
        "https://www.mass.gov/info-details/paid-family-and-medical-leave-employer-contribution-rates-and-calculator",
      asOf: "2026-11-01",
    },
    {
      id: "or-pl",
      state: "OR",
      name: "Paid Leave Oregon (employee share)",
      ratePct: 0.6,
      capUsd: _,
      note: "Total 1% of wages; employees pay 60% (0.6%) on wages up to $184,500 per employer.",
      source:
        "Paid Leave Oregon, employees overview (2026: 1% total, employee share 60%, wage cap $184,500)",
      sourceUrl: "https://paidleave.oregon.gov/employees/overview.html",
      asOf: "2026-11-01",
    },
  ];
function z(a) {
  return ke.filter((l) => l.state === a);
}
function Te(a, l) {
  return z(a).map((o) => ({
    id: o.id,
    label: o.name,
    ratePct: o.ratePct,
    capUsd: o.capUsd,
    amount:
      Math.round(Math.min(Math.max(l, 0), o.capUsd ?? 1 / 0) * o.ratePct) / 100,
  }));
}
const Ce = g.lazy(() =>
    ne(
      () => import("./CalcReport-DYILoD5G.js"),
      __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]),
    ),
  ),
  Y = {
    what: "Estimates US state income tax for all 50 states and Washington DC using each state's bracket structure, standard deduction and exemptions, for single, married and head-of-household filers. A comparison view ranks every state for the same income.",
    how: 'Pick your state, filing status and income. You get the estimated tax, your effective and marginal rate, and a bracket-by-bracket breakdown. Where a state has local income taxes, tick the local-tax box for a typical average or pick your city or county for its own line; California, New York, New Jersey, Washington, Massachusetts and Oregon also show their payroll programs (SDI, paid leave) as separate lines. Use "Compare all states" to see where the same income is taxed least.',
    tip: "This is a planning estimate: credits, federal-tax deductions, phase-outs and local taxes beyond the typical average are not modelled. Check your state's revenue department before filing.",
  },
  n = (a, l = 0) =>
    `$${a.toLocaleString("en-US", { minimumFractionDigits: l, maximumFractionDigits: l })}`;
function ct() {
  const [a, l] = g.useState("75000"),
    [o, m] = g.useState("CA"),
    [i, d] = g.useState("single"),
    [c, s] = g.useState(!1),
    [f, y] = g.useState(!1),
    [w, S] = g.useState(""),
    [k, R] = g.useState("resident"),
    A = de(a),
    W = A !== null && A < 0,
    b = Math.max(0, A ?? 0),
    v = me[i],
    x = E[o],
    B = je(o),
    h = w && K[w]?.state === o ? K[w] : void 0,
    M =
      h && k === "worker" && h.workerRatePct !== void 0 ? "worker" : "resident",
    N = c && !h,
    p = O(o, b, i, v, { local: N }),
    u = h
      ? Pe(h, M, {
          income: b,
          taxable: p.taxable,
          stateTax: p.stateOnly,
          filing: i,
        })
      : null,
    T = z(o),
    j = Te(o, b),
    C = j.reduce((t, r) => t + r.amount, 0),
    $ = p.tax + (u?.amount ?? 0) + C,
    Q = (t) => {
      (m(t), S(""), R("resident"));
    },
    V = g.useMemo(
      () =>
        f
          ? H.map((t) => ({ st: t, r: O(t.code, b, i, v, { local: c }) })).sort(
              (t, r) => t.r.tax - r.r.tax || t.st.name.localeCompare(r.st.name),
            )
          : [],
      [f, b, i, v, c],
    ),
    { gate: X } = ce(!0),
    P = pe(x, N),
    J = g.useMemo(() => ge(o, b, i, v, N), [o, b, i, v, N]),
    Z = g.useMemo(() => {
      const t = [];
      u &&
        t.push({
          label: `Local income tax: ${u.lines[0].label}`,
          from: null,
          to: null,
          ratePct: null,
          amount: u.amount,
        });
      for (const r of j)
        t.push({
          label: `Payroll program: ${r.label} (${r.ratePct}%${r.capUsd ? `, wages up to ${n(r.capUsd)}` : ", no wage cap"})`,
          from: null,
          to: null,
          ratePct: r.ratePct,
          amount: r.amount,
        });
      return (
        t.length &&
          t.push({
            label: "Total with local tax and payroll programs",
            from: null,
            to: null,
            ratePct: null,
            amount: $,
          }),
        [...J, ...t]
      );
    }, [J, u, j, $]),
    ee = g.useMemo(() => {
      const t = ye(o, b, i, v, N, (r) => n(r, 2));
      u &&
        t.push({
          label: "Local income tax",
          formula: `${h.name}: ${M === "worker" ? "non-resident rate" : "resident rate"} on ${u.baseLabel}`,
          inputs: {
            [u.baseLabel]: n(u.base, 2),
            "Effective rate": `${u.ratePct.toFixed(3)}%`,
          },
          result: n(u.amount, 2),
        });
      for (const r of j)
        t.push({
          label: r.label,
          formula: `Wages${r.capUsd ? ` up to ${n(r.capUsd)}` : ""} x ${r.ratePct}%`,
          inputs: {
            Wages: n(Math.min(b, r.capUsd ?? 1 / 0), 2),
            Rate: `${r.ratePct}%`,
          },
          result: n(r.amount, 2),
        });
      return (
        (u || j.length) &&
          t.push({
            label: "Total with local tax and payroll programs",
            formula: "State income tax + local income tax + payroll programs",
            inputs: {
              "State income tax": n(p.tax, 2),
              "Local income tax": n(u?.amount ?? 0, 2),
              "Payroll programs": n(C, 2),
            },
            result: n($, 2),
          }),
        t
      );
    }, [o, b, i, v, N, u, j, $, p.tax, C, h, M]),
    te = g.useMemo(
      () => [
        { key: "line", header: "Line", get: (t) => t.label },
        {
          key: "from",
          header: "Taxable income from",
          get: (t) => t.from,
          format: (t) => (t.from === null ? "" : n(t.from)),
          align: "right",
        },
        {
          key: "to",
          header: "to",
          get: (t) => t.to,
          format: (t) => (t.to === null ? "" : n(t.to)),
          align: "right",
        },
        {
          key: "rate",
          header: "Rate %",
          get: (t) => t.ratePct,
          format: (t) => (t.ratePct === null ? "" : `${t.ratePct}%`),
          align: "right",
        },
        {
          key: "amount",
          header: "Tax",
          get: (t) => Math.round(t.amount * 100) / 100,
          format: (t) => n(t.amount, 2),
          align: "right",
        },
      ],
      [],
    ),
    ae = `${x.name} ${U[i]} ${n(b)}: ${n(p.tax, 2)} state income tax${u ? ` plus ${n(u.amount, 2)} ${h.name} tax` : ""}${C > 0 ? ` plus ${n(C, 2)} payroll programs` : ""}${P.status === "included" ? " incl. estimated local tax" : P.status === "excluded" ? " (state only, local not included)" : ""}`;
  return e.jsxs(re, {
    children: [
      e.jsxs("div", {
        className: "max-w-md mx-auto space-y-6",
        children: [
          e.jsxs("div", {
            children: [
              e.jsx(L, { children: "Annual Income ($)" }),
              e.jsx(oe, {
                inputMode: "decimal",
                "aria-label": "Annual income",
                "aria-invalid": W || void 0,
                value: a,
                onChange: (t) => l(t.target.value),
              }),
              W &&
                e.jsx("p", {
                  role: "alert",
                  className: "text-xs text-destructive mt-1",
                  children: "Income cannot be negative. Enter 0 or more.",
                }),
            ],
          }),
          e.jsxs("div", {
            className: "grid grid-cols-2 gap-3",
            children: [
              e.jsxs("div", {
                children: [
                  e.jsx(L, { className: "text-xs", children: "State" }),
                  e.jsx("select", {
                    className:
                      "border rounded px-2 py-2 w-full bg-background text-sm",
                    "aria-label": "State",
                    value: o,
                    onChange: (t) => Q(t.target.value),
                    children: H.map((t) =>
                      e.jsxs(
                        "option",
                        {
                          value: t.code,
                          children: [
                            t.name,
                            t.kind === "none" ? " (no income tax)" : "",
                          ],
                        },
                        t.code,
                      ),
                    ),
                  }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx(L, { className: "text-xs", children: "Filing status" }),
                  e.jsx("select", {
                    className:
                      "border rounded px-2 py-2 w-full bg-background text-sm",
                    "aria-label": "Filing status",
                    value: i,
                    onChange: (t) => d(t.target.value),
                    children: Object.keys(U).map((t) =>
                      e.jsx("option", { value: t, children: U[t] }, t),
                    ),
                  }),
                ],
              }),
            ],
          }),
          x.localAvg
            ? e.jsxs("label", {
                className: "flex items-start gap-2 text-sm",
                "data-testid": "st-local-box",
                children: [
                  e.jsx("input", {
                    type: "checkbox",
                    className: "h-4 w-4 mt-0.5 shrink-0",
                    checked: c,
                    onChange: (t) => s(t.target.checked),
                  }),
                  e.jsxs("span", {
                    children: [
                      "Include typical local income tax (estimate: about ",
                      x.localAvg,
                      "% of state taxable income",
                      x.localNote ? `. ${x.localNote}` : "",
                      ")",
                    ],
                  }),
                ],
              })
            : null,
          B.length > 0 &&
            e.jsxs("div", {
              "data-testid": "st-locality-box",
              children: [
                e.jsx(L, {
                  className: "text-xs",
                  children:
                    "City or county (adds its own local income tax line)",
                }),
                e.jsxs("select", {
                  className:
                    "border rounded px-2 py-2 w-full bg-background text-sm",
                  "aria-label": "City or county",
                  value: h ? h.id : "",
                  onChange: (t) => {
                    (S(t.target.value), R("resident"));
                  },
                  children: [
                    e.jsxs("option", {
                      value: "",
                      children: [
                        "None: state tax only",
                        x.localAvg ? " (or the typical average above)" : "",
                      ],
                    }),
                    B.map((t) =>
                      e.jsxs(
                        "option",
                        {
                          value: t.id,
                          children: [
                            t.name,
                            t.residentRatePct !== void 0
                              ? ` (${t.residentRatePct}%)`
                              : "",
                          ],
                        },
                        t.id,
                      ),
                    ),
                  ],
                }),
                h &&
                  h.workerRatePct !== void 0 &&
                  e.jsxs("select", {
                    className:
                      "border rounded px-2 py-2 w-full bg-background text-sm mt-2",
                    "aria-label": "Live or work there",
                    value: k,
                    onChange: (t) => R(t.target.value),
                    children: [
                      e.jsx("option", {
                        value: "resident",
                        children: "I live there",
                      }),
                      e.jsx("option", {
                        value: "worker",
                        children: "I work there but live elsewhere",
                      }),
                    ],
                  }),
                h &&
                  e.jsxs("p", {
                    className: "text-xs text-muted-foreground mt-1",
                    "data-testid": "st-locality-note",
                    children: [
                      h.note,
                      " Source: ",
                      e.jsx("a", {
                        href: h.sourceUrl,
                        target: "_blank",
                        rel: "noopener noreferrer",
                        className: "underline text-primary",
                        children: h.source,
                      }),
                      ", read ",
                      h.asOf,
                      ".",
                      c
                        ? " The typical-average box is ignored while a city or county is chosen."
                        : "",
                    ],
                  }),
              ],
            }),
          e.jsxs(e.Fragment, {
            children: [
              e.jsxs("div", {
                className: "p-4 rounded-xl border bg-primary/5 text-center",
                children: [
                  e.jsxs("p", {
                    className: "text-xs text-muted-foreground",
                    children: [
                      "Estimated ",
                      x.name,
                      " State Income Tax (",
                      ue,
                      ")",
                    ],
                  }),
                  e.jsx("p", {
                    className: "text-2xl font-bold text-primary",
                    "data-testid": "st-tax",
                    children: n(p.tax, 2),
                  }),
                  x.kind === "none" &&
                    e.jsxs("p", {
                      className: "text-xs text-muted-foreground mt-1",
                      children: [
                        x.name,
                        " has no state tax on wages",
                        x.note ? ` — ${x.note}` : "",
                        ".",
                      ],
                    }),
                  P.status === "included" &&
                    e.jsxs("p", {
                      className: "text-xs text-muted-foreground mt-1",
                      "data-testid": "st-local-included",
                      children: [
                        "Includes ",
                        n(p.local, 2),
                        " estimated local income tax (",
                        P.avg,
                        "% average) on top of ",
                        n(p.stateOnly, 2),
                        " state tax.",
                      ],
                    }),
                ],
              }),
              P.status !== "none" &&
                e.jsx(se, {
                  className: "text-xs",
                  testId: "st-local-notice",
                  children: P.text,
                }),
              (u || T.length > 0) &&
                e.jsxs("div", {
                  className: "rounded-lg border p-3 text-sm space-y-1",
                  "data-testid": "st-extras",
                  children: [
                    e.jsxs("div", {
                      className: "flex justify-between",
                      children: [
                        e.jsxs("span", {
                          children: [
                            "State income tax",
                            N ? " (incl. typical local average)" : "",
                          ],
                        }),
                        e.jsx("span", { children: n(p.tax, 2) }),
                      ],
                    }),
                    u &&
                      e.jsxs("div", {
                        className: "flex justify-between",
                        "data-testid": "st-local-line",
                        children: [
                          e.jsx("span", { children: u.lines[0].label }),
                          e.jsx("span", { children: n(u.amount, 2) }),
                        ],
                      }),
                    j.map((t) =>
                      e.jsxs(
                        "div",
                        {
                          className: "flex justify-between",
                          "data-testid": `st-payroll-${t.id}`,
                          children: [
                            e.jsxs("span", {
                              children: [
                                t.label,
                                " (",
                                t.ratePct,
                                "%",
                                t.capUsd
                                  ? `, wages up to ${n(t.capUsd)}`
                                  : ", no wage cap",
                                ")",
                              ],
                            }),
                            e.jsx("span", { children: n(t.amount, 2) }),
                          ],
                        },
                        t.id,
                      ),
                    ),
                    e.jsxs("div", {
                      className:
                        "flex justify-between font-medium border-t pt-1",
                      "data-testid": "st-total-all",
                      children: [
                        e.jsx("span", {
                          children: "Total with local tax and payroll programs",
                        }),
                        e.jsx("span", { children: n($, 2) }),
                      ],
                    }),
                    T.length > 0 &&
                      e.jsxs("p", {
                        className: "text-xs text-muted-foreground",
                        children: [
                          "Payroll programs are charged on wages and are not income tax; they are shown apart from the state income tax above. ",
                          T.map((t) => t.note).join(" "),
                          " Sources: ",
                          T.map((t, r) =>
                            e.jsxs(
                              "span",
                              {
                                children: [
                                  r ? "; " : "",
                                  e.jsx("a", {
                                    href: t.sourceUrl,
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "underline text-primary",
                                    children: t.source,
                                  }),
                                ],
                              },
                              t.id,
                            ),
                          ),
                          ", read ",
                          T[0].asOf,
                          ".",
                        ],
                      }),
                  ],
                }),
              x.kind !== "none" &&
                e.jsxs(e.Fragment, {
                  children: [
                    e.jsxs("div", {
                      className: "grid grid-cols-3 gap-3",
                      children: [
                        e.jsxs("div", {
                          className:
                            "text-center p-3 rounded-lg border bg-card",
                          children: [
                            e.jsx("p", {
                              className: "text-xs text-muted-foreground",
                              children: "Effective rate",
                            }),
                            e.jsxs("p", {
                              className: "text-sm font-bold",
                              "data-testid": "st-eff",
                              children: [p.effectiveRate.toFixed(2), "%"],
                            }),
                          ],
                        }),
                        e.jsxs("div", {
                          className:
                            "text-center p-3 rounded-lg border bg-card",
                          children: [
                            e.jsx("p", {
                              className: "text-xs text-muted-foreground",
                              children: "Marginal rate",
                            }),
                            e.jsxs("p", {
                              className: "text-sm font-bold",
                              children: [p.marginalRate.toFixed(2), "%"],
                            }),
                          ],
                        }),
                        e.jsxs("div", {
                          className:
                            "text-center p-3 rounded-lg border bg-card",
                          children: [
                            e.jsx("p", {
                              className: "text-xs text-muted-foreground",
                              children: "Taxable income",
                            }),
                            e.jsx("p", {
                              className: "text-sm font-bold",
                              children: n(p.taxable),
                            }),
                          ],
                        }),
                      ],
                    }),
                    p.rows.length > 0 &&
                      e.jsxs("table", {
                        className:
                          "w-full text-xs border rounded-lg overflow-hidden",
                        children: [
                          e.jsx("thead", {
                            className: "bg-muted/50",
                            children: e.jsxs("tr", {
                              children: [
                                e.jsx("th", {
                                  className: "text-left p-2",
                                  children: "Bracket",
                                }),
                                e.jsx("th", {
                                  className: "text-right p-2",
                                  children: "Rate",
                                }),
                                e.jsx("th", {
                                  className: "text-right p-2",
                                  children: "Tax",
                                }),
                              ],
                            }),
                          }),
                          e.jsx("tbody", {
                            children: p.rows.map((t, r) =>
                              e.jsxs(
                                "tr",
                                {
                                  className: "border-t",
                                  children: [
                                    e.jsxs("td", {
                                      className: "p-2",
                                      children: [n(t.from), " – ", n(t.to)],
                                    }),
                                    e.jsxs("td", {
                                      className: "p-2 text-right",
                                      children: [t.rate, "%"],
                                    }),
                                    e.jsx("td", {
                                      className: "p-2 text-right",
                                      children: n(t.tax, 2),
                                    }),
                                  ],
                                },
                                r,
                              ),
                            ),
                          }),
                        ],
                      }),
                    x.note &&
                      e.jsx("p", {
                        className: "text-xs text-muted-foreground",
                        children: x.note,
                      }),
                  ],
                }),
              e.jsx("button", {
                type: "button",
                onClick: () => y(!f),
                className:
                  "text-sm px-3 py-1.5 rounded-md border bg-card w-full",
                children: f ? "Hide" : "Compare all states",
              }),
              f &&
                e.jsxs("div", {
                  className: "max-h-96 overflow-auto border rounded-lg",
                  "data-testid": "st-compare",
                  children: [
                    e.jsxs("p", {
                      className: "text-xs text-muted-foreground p-2 border-b",
                      "data-testid": "st-compare-local",
                      children: [
                        fe(c),
                        ' Sorted by lowest tax, which is also the highest amount left after state tax. "vs ',
                        x.name,
                        `" is each state's tax minus yours: a minus means you would pay less there. State income tax only, before federal tax.`,
                      ],
                    }),
                    e.jsxs("table", {
                      className: "w-full text-xs",
                      children: [
                        e.jsx("thead", {
                          className: "bg-muted/50 sticky top-0",
                          children: e.jsxs("tr", {
                            children: [
                              e.jsx("th", {
                                className: "text-left p-2",
                                children: "State",
                              }),
                              e.jsx("th", {
                                className: "text-right p-2",
                                children: "Tax",
                              }),
                              e.jsx("th", {
                                className: "text-right p-2",
                                children: "Effective",
                              }),
                              e.jsx("th", {
                                className: "text-right p-2",
                                children: "Local tax",
                              }),
                              e.jsx("th", {
                                className: "text-right p-2",
                                children: "After state tax",
                              }),
                              e.jsxs("th", {
                                className: "text-right p-2",
                                children: ["vs ", x.name],
                              }),
                            ],
                          }),
                        }),
                        e.jsx("tbody", {
                          children: V.map(({ st: t, r }) =>
                            e.jsxs(
                              "tr",
                              {
                                className: `border-t cursor-pointer ${t.code === o ? "bg-primary/10 font-medium" : ""}`,
                                onClick: () => m(t.code),
                                children: [
                                  e.jsx("td", {
                                    className: "p-2",
                                    children: t.name,
                                  }),
                                  e.jsx("td", {
                                    className: "p-2 text-right",
                                    children: n(r.tax),
                                  }),
                                  e.jsxs("td", {
                                    className: "p-2 text-right",
                                    children: [r.effectiveRate.toFixed(2), "%"],
                                  }),
                                  e.jsx("td", {
                                    className:
                                      "p-2 text-right text-muted-foreground",
                                    children: he(t, c),
                                  }),
                                  e.jsx("td", {
                                    className: "p-2 text-right",
                                    children: n(b - r.tax),
                                  }),
                                  e.jsx("td", {
                                    className: "p-2 text-right",
                                    "data-testid": `st-vs-${t.code}`,
                                    children:
                                      t.code === o
                                        ? "your state"
                                        : r.tax - p.tax === 0
                                          ? "same"
                                          : `${r.tax < p.tax ? "−" : "+"}${n(Math.abs(r.tax - p.tax))}`,
                                  }),
                                ],
                              },
                              t.code,
                            ),
                          ),
                        }),
                      ],
                    }),
                  ],
                }),
              e.jsx(g.Suspense, {
                fallback: null,
                children: e.jsx(Ce, {
                  title: "State income tax estimate",
                  tool: "state-tax",
                  summary: ae,
                  steps: ee,
                  gate: X,
                  filename: `state-tax-${o.toLowerCase()}.csv`,
                  notes: [P.text, G].filter(Boolean),
                  tables: [
                    xe({
                      caption: `${x.name} state income tax by bracket`,
                      heading: "Tax by bracket",
                      rows: Z,
                      columns: te,
                      rowKey: (t) =>
                        `${t.label}-${t.from ?? ""}-${t.ratePct ?? ""}`,
                    }),
                  ],
                }),
              }),
            ],
          }),
          e.jsxs("p", {
            className: "text-xs text-muted-foreground text-center",
            children: [
              G,
              " Uses each state's standard deduction and exemptions; credits and federal-tax deductions are not modelled. Local income taxes: the typical-average box appears only for Indiana, Maryland, New York, Ohio and Pennsylvania and uses that average only. A City or county list gives a named local tax as its own line for New York City and Yonkers, every Maryland county and Baltimore City, Philadelphia, Detroit, Kansas City, St. Louis and Columbus; all other cities and counties (including Indiana counties and other Ohio and Pennsylvania cities) are not included, so add them yourself. Michigan cities other than Detroit have no average here and are never included. Payroll programs shown for California, New York, New Jersey, Washington, Massachusetts and Oregon are employee shares on wages and are listed apart from income tax; other states' programs are not included. California includes the 1% Mental Health Services Tax over $1,000,000 of taxable income (source: ftb.ca.gov). Not tax advice.",
            ],
          }),
        ],
      }),
      e.jsx(le, { id: "usState" }),
      e.jsx(ie, { whatIsIt: Y.what, howToUse: Y.how, tip: Y.tip }),
    ],
  });
}
export { ct as default };
//# sourceMappingURL=StateTaxCalculator-Cpt8tozS.js.map
