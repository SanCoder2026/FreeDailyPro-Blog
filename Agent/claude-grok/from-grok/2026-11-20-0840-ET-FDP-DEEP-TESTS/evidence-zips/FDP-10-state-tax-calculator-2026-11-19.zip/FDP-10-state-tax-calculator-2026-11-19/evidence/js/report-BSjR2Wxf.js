import{s as n}from"./steps-X1Sejec4.js";import{c as r}from"./csv-DBvSFDe9.js";import{t as s,a}from"./table-CJAX3ymv.js";function u(o){return o}function m(o){return[o.title,o.summary,"",...o.steps.length?["How this was calculated",n(o.steps),""]:[],...o.tables.flatMap(e=>[e.heading,a(e.rows,e.columns),""]),...o.notes?.length?[...o.notes,""]:[],"Calculated with FreeDailyPro.com"].join(`
`)}function p(o){if(o.length===1)return s(o[0].rows,o[0].columns);const e="\uFEFF";return e+o.map(t=>`${r(t.heading)}\r
${s(t.rows,t.columns).replace(e,"")}`).join(`\r
`)}export{p as a,m as b,u as r};
//# sourceMappingURL=report-BSjR2Wxf.js.map
