const V = 2026,
  G = {
    single: "Single",
    mfj: "Married filing jointly",
    mfs: "Married filing separately",
    hoh: "Head of household",
  },
  A = (t) =>
    [0.1, 0.12, 0.22, 0.24, 0.32, 0.35, 0.37].map((a, e) => ({
      upTo: t[e] ?? 1 / 0,
      rate: a,
    })),
  _ = {
    single: A([12400, 50400, 105700, 201775, 256225, 640600]),
    mfj: A([24800, 100800, 211400, 403550, 512450, 768700]),
    mfs: A([12400, 50400, 105700, 201775, 256225, 384350]),
    hoh: A([17700, 67450, 105700, 201750, 256200, 640600]),
  },
  U = { single: 16100, mfj: 32200, mfs: 16100, hoh: 24150 },
  E = 184500,
  w = 0.124,
  v = 0.029,
  C = 0.009,
  D = { single: 2e5, mfj: 25e4, mfs: 125e3, hoh: 2e5 },
  O = 400,
  $ = 0.9235;
function K(t, a) {
  let e = 0,
    i = 0;
  for (const s of a) {
    if (t <= i) break;
    ((e += (Math.min(t, s.upTo) - i) * s.rate), (i = s.upTo));
  }
  return e;
}
function J(t, a) {
  for (const e of a) if (t <= e.upTo) return e.rate;
  return a[a.length - 1].rate;
}
function q(t, a = "single", e = 0) {
  const i = Math.max(0, t) * $;
  if (i < O)
    return {
      netEarnings: i,
      socialSecurity: 0,
      medicare: 0,
      additionalMedicare: 0,
      total: 0,
      deductibleHalf: 0,
      belowMinimum: t > 0,
    };
  const s = Math.max(0, E - Math.max(0, e)),
    n = Math.min(i, s) * w,
    f = i * v,
    m = Math.max(0, i - Math.max(0, D[a] - Math.max(0, e))) * C;
  return {
    netEarnings: i,
    socialSecurity: n,
    medicare: f,
    additionalMedicare: m,
    total: n + f + m,
    deductibleHalf: (n + f) / 2,
    belowMinimum: !1,
  };
}
function X(t, a = "single") {
  const e = Math.max(0, t),
    i = Math.min(e, E) * (w / 2),
    s = e * (v / 2),
    n = Math.max(0, e - D[a]) * C;
  return {
    socialSecurity: i,
    medicare: s,
    additionalMedicare: n,
    total: i + s + n,
  };
}
function z(t, a, e, i) {
  const s = Math.max(0, t - a),
    n = _[i][3].upTo,
    f = Math.max(0, e);
  return s <= 0 || f <= 0
    ? { amount: 0, qualifiedIncome: s, applied: !1, overThreshold: !1 }
    : f > n
      ? { amount: 0, qualifiedIncome: s, applied: !1, overThreshold: !0 }
      : {
          amount: Math.min(s * 0.2, f * 0.2),
          qualifiedIncome: s,
          applied: !0,
          overThreshold: !1,
        };
}
const Z =
    "Estimated rates, mostly tax year 2026 (California uses the 2025 schedule; see the per-state note). Check your state's revenue department for exact figures.",
  d = (t, a, e) => ({
    code: t,
    name: a,
    kind: "none",
    brackets: [],
    std: [0, 0],
    note: e,
  }),
  c = (t, a, e, i = ["fed", "fed"], s = {}, n = 0) => ({
    code: t,
    name: a,
    kind: "flat",
    brackets: n
      ? [
          { upTo: n, rate: 0 },
          { upTo: 1 / 0, rate: e },
        ]
      : [{ upTo: 1 / 0, rate: e }],
    std: i,
    ...s,
  }),
  o = (t, a, e, i, s = {}) => ({
    code: t,
    name: a,
    kind: "progressive",
    brackets: e.map(([n, f]) => ({ upTo: n, rate: f })),
    std: i,
    ...s,
  }),
  l = (t) => t.map(([a, e]) => ({ upTo: a, rate: e })),
  L = [
    o(
      "AL",
      "Alabama",
      [
        [500, 2],
        [3e3, 4],
        [1 / 0, 5],
      ],
      [3e3, 8500],
      {
        exemption: 1500,
        note: "Alabama lets you deduct federal income tax paid; not modelled, so this is a high estimate.",
      },
    ),
    d("AK", "Alaska"),
    c("AZ", "Arizona", 2.5),
    o(
      "AR",
      "Arkansas",
      [
        [4600, 2],
        [1 / 0, 3.9],
      ],
      [2470, 4940],
    ),
    o(
      "CA",
      "California",
      [
        [11079, 1],
        [26264, 2],
        [41452, 4],
        [57542, 6],
        [72724, 8],
        [371479, 9.3],
        [445771, 10.3],
        [742953, 11.3],
        [1 / 0, 12.3],
      ],
      [5706, 11412],
      {
        mhst: !0,
        credit: 153,
        note: "Uses the 2025 California Franchise Tax Board schedule (the 2026 schedule is not published yet), the $153 per person exemption credit, and the 1% Mental Health Services Tax on taxable income above $1,000,000 (Rev. & Tax. Code 17043; ftb.ca.gov).",
      },
    ),
    c("CO", "Colorado", 4.4),
    o(
      "CT",
      "Connecticut",
      [
        [1e4, 2],
        [5e4, 4.5],
        [1e5, 5.5],
        [2e5, 6],
        [25e4, 6.5],
        [5e5, 6.9],
        [1 / 0, 6.99],
      ],
      [0, 0],
      {
        note: "Connecticut's personal exemption phases out with income; not modelled.",
      },
    ),
    o(
      "DE",
      "Delaware",
      [
        [2e3, 0],
        [5e3, 2.2],
        [1e4, 3.9],
        [2e4, 4.8],
        [25e3, 5.2],
        [6e4, 5.55],
        [1 / 0, 6.6],
      ],
      [3250, 6500],
    ),
    o(
      "DC",
      "District of Columbia",
      [
        [1e4, 4],
        [4e4, 6],
        [6e4, 6.5],
        [25e4, 8.5],
        [5e5, 9.25],
        [1e6, 9.75],
        [1 / 0, 10.75],
      ],
      ["fed", "fed"],
    ),
    d("FL", "Florida"),
    c("GA", "Georgia", 4.99, [12e3, 24e3], {
      note: "Georgia's 2026 rate is 4.99% (HB 463, 2026). The law also raises the standard deduction; that increase is not applied here until the amounts are confirmed.",
    }),
    o(
      "HI",
      "Hawaii",
      [
        [9600, 1.4],
        [14400, 3.2],
        [19200, 5.5],
        [24e3, 6.4],
        [36e3, 6.8],
        [48e3, 7.2],
        [125e3, 7.6],
        [175e3, 7.9],
        [225e3, 8.25],
        [275e3, 9],
        [325e3, 10],
        [1 / 0, 11],
      ],
      [4400, 8800],
      { exemption: 1144 },
    ),
    c("ID", "Idaho", 5.3, ["fed", "fed"], {}, 4811),
    c("IL", "Illinois", 4.95, [0, 0], { exemption: 2925 }),
    c("IN", "Indiana", 2.95, [0, 0], {
      exemption: 1e3,
      localNote: "Indiana counties add local income tax (about 1% to 3%).",
      localAvg: 1.6,
    }),
    c("IA", "Iowa", 3.8),
    o(
      "KS",
      "Kansas",
      [
        [23e3, 5.2],
        [1 / 0, 5.58],
      ],
      [3605, 8240],
      {
        exemption: 9160,
        jointBrackets: l([
          [46e3, 5.2],
          [1 / 0, 5.58],
        ]),
      },
    ),
    c("KY", "Kentucky", 3.5, [3360, 6720]),
    c("LA", "Louisiana", 3, [12875, 25750]),
    o(
      "ME",
      "Maine",
      [
        [27399, 5.8],
        [64849, 6.75],
        [1 / 0, 7.15],
      ],
      [15e3, 3e4],
      {
        exemption: 5150,
        jointBrackets: l([
          [54849, 5.8],
          [129749, 6.75],
          [1 / 0, 7.15],
        ]),
      },
    ),
    o(
      "MD",
      "Maryland",
      [
        [1e3, 2],
        [2e3, 3],
        [3e3, 4],
        [1e5, 4.75],
        [125e3, 5],
        [15e4, 5.25],
        [25e4, 5.5],
        [5e5, 5.75],
        [1e6, 6.25],
        [1 / 0, 6.5],
      ],
      [3350, 6700],
      {
        exemption: 3200,
        jointBrackets: l([
          [1e3, 2],
          [2e3, 3],
          [3e3, 4],
          [15e4, 4.75],
          [175e3, 5],
          [225e3, 5.25],
          [3e5, 5.5],
          [6e5, 5.75],
          [12e5, 6.25],
          [1 / 0, 6.5],
        ]),
        localNote:
          "Maryland counties and Baltimore add local income tax (2.25% to 3.3%).",
        localAvg: 3.2,
      },
    ),
    o(
      "MA",
      "Massachusetts",
      [
        [1083150, 5],
        [1 / 0, 9],
      ],
      [0, 0],
      {
        exemption: 4400,
        jointBrackets: l([
          [1083150, 5],
          [1 / 0, 9],
        ]),
        note: "Includes the 4% surtax on taxable income above $1,083,150 (9% total).",
      },
    ),
    c("MI", "Michigan", 4.25, [0, 0], {
      exemption: 5900,
      localNote:
        "Some Michigan cities (Detroit, Grand Rapids and others) add 1% to 2.4%.",
    }),
    o(
      "MN",
      "Minnesota",
      [
        [33310, 5.35],
        [109430, 6.8],
        [203150, 7.85],
        [1 / 0, 9.85],
      ],
      [15300, 30600],
      {
        jointBrackets: l([
          [48700, 5.35],
          [193480, 6.8],
          [337930, 7.85],
          [1 / 0, 9.85],
        ]),
      },
    ),
    c("MS", "Mississippi", 4, [2300, 4600], { exemption: 6e3 }, 1e4),
    o(
      "MO",
      "Missouri",
      [
        [1348, 0],
        [2696, 2],
        [4044, 2.5],
        [5392, 3],
        [6740, 3.5],
        [8088, 4],
        [9436, 4.5],
        [1 / 0, 4.7],
      ],
      ["fed", "fed"],
      {
        note: "Missouri allows a partial federal tax deduction; not modelled.",
      },
    ),
    o(
      "MT",
      "Montana",
      [
        [47500, 4.7],
        [1 / 0, 5.65],
      ],
      [5540, 11080],
      {
        jointBrackets: l([
          [95e3, 4.7],
          [1 / 0, 5.65],
        ]),
      },
    ),
    o(
      "NE",
      "Nebraska",
      [
        [4130, 2.46],
        [24760, 3.51],
        [1 / 0, 4.55],
      ],
      [8850, 17700],
      {
        jointBrackets: l([
          [8250, 2.46],
          [49530, 3.51],
          [1 / 0, 4.55],
        ]),
      },
    ),
    d("NV", "Nevada"),
    d(
      "NH",
      "New Hampshire",
      "New Hampshire no longer taxes interest and dividends.",
    ),
    o(
      "NJ",
      "New Jersey",
      [
        [2e4, 1.4],
        [35e3, 1.75],
        [4e4, 3.5],
        [75e3, 5.525],
        [5e5, 6.37],
        [1e6, 8.97],
        [1 / 0, 10.75],
      ],
      [0, 0],
      {
        exemption: 1e3,
        jointBrackets: l([
          [2e4, 1.4],
          [5e4, 1.75],
          [7e4, 2.45],
          [8e4, 3.5],
          [15e4, 5.525],
          [5e5, 6.37],
          [1e6, 8.97],
          [1 / 0, 10.75],
        ]),
      },
    ),
    o(
      "NM",
      "New Mexico",
      [
        [5500, 1.5],
        [16500, 3.2],
        [33500, 4.3],
        [66500, 4.7],
        [21e4, 4.9],
        [1 / 0, 5.9],
      ],
      ["fed", "fed"],
      {
        jointBrackets: l([
          [8e3, 1.5],
          [25e3, 3.2],
          [5e4, 4.3],
          [1e5, 4.7],
          [315e3, 4.9],
          [1 / 0, 5.9],
        ]),
      },
    ),
    o(
      "NY",
      "New York",
      [
        [8500, 3.9],
        [11700, 4.4],
        [13900, 5.15],
        [80650, 5.4],
        [215400, 5.9],
        [1077550, 6.85],
        [5e6, 9.65],
        [25e6, 10.3],
        [1 / 0, 10.9],
      ],
      [8e3, 16050],
      {
        jointBrackets: l([
          [17150, 3.9],
          [23600, 4.4],
          [27900, 5.15],
          [161550, 5.4],
          [323200, 5.9],
          [2155350, 6.85],
          [5e6, 9.65],
          [25e6, 10.3],
          [1 / 0, 10.9],
        ]),
        localNote:
          "New York City residents also pay city income tax of about 3.1% to 3.9%.",
        localAvg: 3.5,
      },
    ),
    c("NC", "North Carolina", 3.99, [12750, 25500]),
    o(
      "ND",
      "North Dakota",
      [
        [48475, 0],
        [244825, 1.95],
        [1 / 0, 2.5],
      ],
      ["fed", "fed"],
      {
        jointBrackets: l([
          [80975, 0],
          [298075, 1.95],
          [1 / 0, 2.5],
        ]),
      },
    ),
    c(
      "OH",
      "Ohio",
      2.75,
      [0, 0],
      {
        exemption: 2400,
        localNote: "Most Ohio cities add 1% to 3% municipal income tax.",
        localAvg: 2,
      },
      26050,
    ),
    o(
      "OK",
      "Oklahoma",
      [
        [3750, 0],
        [4900, 2.5],
        [7200, 3.5],
        [1 / 0, 4.5],
      ],
      [6350, 12700],
      {
        exemption: 1e3,
        jointBrackets: l([
          [7500, 0],
          [9800, 2.5],
          [14400, 3.5],
          [1 / 0, 4.5],
        ]),
      },
    ),
    o(
      "OR",
      "Oregon",
      [
        [4550, 4.75],
        [11400, 6.75],
        [125e3, 8.75],
        [1 / 0, 9.9],
      ],
      [2910, 5820],
      {
        jointBrackets: l([
          [9100, 4.75],
          [22800, 6.75],
          [25e4, 8.75],
          [1 / 0, 9.9],
        ]),
        note: "Oregon lets you subtract part of your federal tax; not modelled, so this is a high estimate.",
      },
    ),
    c("PA", "Pennsylvania", 3.07, [0, 0], {
      localNote:
        "Most Pennsylvania localities add earned income tax (often 1% to 3.9%; Philadelphia about 3.75%).",
      localAvg: 1.5,
    }),
    o(
      "RI",
      "Rhode Island",
      [
        [82050, 3.75],
        [186450, 4.75],
        [1 / 0, 5.99],
      ],
      [11200, 22400],
      {
        jointBrackets: l([
          [82050, 3.75],
          [186450, 4.75],
          [1 / 0, 5.99],
        ]),
      },
    ),
    o(
      "SC",
      "South Carolina",
      [
        [3e4, 1.99],
        [1 / 0, 5.21],
      ],
      [0, 0],
      {
        jointBrackets: l([
          [3e4, 1.99],
          [1 / 0, 5.21],
        ]),
        phaseDeduction: {
          amount: [15e3, 22500, 3e4],
          from: [4e4, 6e4, 8e4],
          to: [95e3, 142500, 19e4],
        },
        note: "South Carolina's 2026 law (H. 4216) uses 1.99% up to $30,000 and 5.21% above, and replaces the federal standard deduction with a deduction that phases out between $40,000 and $95,000 of income (single).",
      },
    ),
    d("SD", "South Dakota"),
    d("TN", "Tennessee"),
    d("TX", "Texas"),
    c("UT", "Utah", 4.45),
    o(
      "VT",
      "Vermont",
      [
        [49400, 3.35],
        [119700, 6.6],
        [249700, 7.6],
        [1 / 0, 8.75],
      ],
      [7650, 15300],
      {
        exemption: 5300,
        jointBrackets: l([
          [82500, 3.35],
          [199450, 6.6],
          [304e3, 7.6],
          [1 / 0, 8.75],
        ]),
      },
    ),
    o(
      "VA",
      "Virginia",
      [
        [3e3, 2],
        [5e3, 3],
        [17e3, 5],
        [1 / 0, 5.75],
      ],
      [8750, 17500],
      { exemption: 930 },
    ),
    d(
      "WA",
      "Washington",
      "Washington taxes long-term capital gains above about $270,000 (7%, 9.9% above $1 million) but not wages.",
    ),
    o(
      "WV",
      "West Virginia",
      [
        [1e4, 2.11],
        [25e3, 2.81],
        [4e4, 3.16],
        [6e4, 4.22],
        [1 / 0, 4.58],
      ],
      [0, 0],
      { exemption: 2e3 },
    ),
    o(
      "WI",
      "Wisconsin",
      [
        [15110, 3.5],
        [51950, 4.4],
        [332720, 5.3],
        [1 / 0, 7.65],
      ],
      [13960, 25840],
      {
        jointBrackets: l([
          [20150, 3.5],
          [69260, 4.4],
          [443630, 5.3],
          [1 / 0, 7.65],
        ]),
      },
    ),
    d("WY", "Wyoming"),
  ],
  M = Object.fromEntries(L.map((t) => [t.code, t]));
function Q(t, a, e, i, s = {}) {
  const n = M[t],
    f = {
      tax: 0,
      taxable: 0,
      effectiveRate: 0,
      marginalRate: 0,
      rows: [],
      stateOnly: 0,
      local: 0,
      localRate: 0,
    };
  if (!n || n.kind === "none" || a <= 0) return f;
  const m = e === "mfj",
    b = n.std[m ? 1 : 0];
  let k = b === "fed" ? i : b;
  if (n.phaseDeduction) {
    const r = m ? 2 : e === "hoh" ? 1 : 0,
      { amount: I, from: x, to: N } = n.phaseDeduction,
      j = Math.min(1, Math.max(0, (N[r] - a) / (N[r] - x[r])));
    k = Math.round(I[r] * j);
  }
  const S = m ? 2 : 1,
    h = Math.max(0, a - k - (n.exemption ?? 0) * S),
    R = m
      ? (n.jointBrackets ??
        n.brackets.map((r) => ({ upTo: r.upTo * 2, rate: r.rate })))
      : n.brackets,
    T = [];
  let y = 0,
    u = 0,
    g = 0;
  for (const r of R) {
    if (h <= y) break;
    const I = Math.min(h, r.upTo),
      x = ((I - y) * r.rate) / 100;
    (T.push({ from: y, to: I, rate: r.rate, tax: x }),
      (u += x),
      (g = r.rate),
      (y = r.upTo));
  }
  if (n.mhst && h > 1e6) {
    const r = (h - 1e6) / 100;
    (T.push({ from: 1e6, to: h, rate: 1, tax: r }), (u += r), (g += 1));
  }
  if (n.credit) {
    const r = Math.min(u, n.credit * S);
    u -= r;
  }
  const B = u;
  let p = 0;
  return (
    s.local && n.localAvg && ((p = (h * n.localAvg) / 100), (u += p)),
    {
      tax: u,
      taxable: h,
      effectiveRate: (u / a) * 100,
      marginalRate: g + (s.local && n.localAvg ? n.localAvg : 0),
      rows: T,
      stateOnly: B,
      local: p,
      localRate: p ? n.localAvg : 0,
    }
  );
}
const H = {
    year: "2026",
    official: !1,
    source:
      "Tax Foundation, State Individual Income Tax Rates and Brackets 2026 (1 Jan 2026); not yet compared with the state's own page",
  },
  Y = {
    NY: {
      year: "2026",
      official: !0,
      source:
        "tax.ny.gov, NYS-50-T-NYS and NYS-50-T-Y (1/26) annual rate schedule: 3.9%, 4.4%, 5.15%, 5.4%, 5.9%",
    },
    CA: {
      year: "2025",
      official: !0,
      source:
        "ftb.ca.gov 2025 Form 540 tax rate schedules, 2025 standard deduction $5,706 and $153 exemption credit; the 2026 schedule is not published yet",
    },
    WV: {
      year: "2026",
      official: !0,
      source: "tax.wv.gov, SB 392 (2026) rate table, retroactive to 1 Jan 2026",
    },
    SC: {
      year: "2026",
      official: !0,
      source:
        "SC Statehouse fiscal impact statement for H. 4216 as signed (1.99% to $30,000, 5.21% above)",
    },
    GA: {
      year: "2026",
      official: !1,
      source:
        "HB 463 (2026), 4.99%, as reported by BDO and the Georgia governor's office",
    },
    UT: {
      year: "2026",
      official: !1,
      source: "SB 60 (2026), 4.45%, as reported by EY Tax News",
    },
    VT: {
      year: "2025",
      official: !1,
      source:
        "Tax Foundation: 2026 Vermont bracket widths not published, 2025 widths used",
    },
    ND: {
      year: "2025",
      official: !1,
      source:
        "Tax Foundation: 2026 North Dakota bracket widths not published, 2025 widths used",
    },
  };
function P(t) {
  return Y[t] ?? H;
}
function ee(t) {
  const a = M[t];
  if (!a || a.kind === "none") return "";
  const e = P(t);
  return `${a.name} rates: tax year ${e.year}, ${e.official ? "from an official source" : "from a secondary source"} (${e.source}).`;
}
const F = {
    CA: {
      label: "California SDI",
      ratePct: 1.3,
      wageCapAnnual: null,
      year: "2026",
      official: !1,
      source:
        "California EDD: State Disability Insurance withholding 1.3% of all wages in 2026, no wage ceiling",
    },
  },
  W = ["NY", "NJ", "HI", "RI", "WA", "MA"];
function te(t, a) {
  const e = F[t];
  if (!e || !(a > 0)) return null;
  const i = e.wageCapAnnual === null ? a : Math.min(a, e.wageCapAnnual);
  return {
    label: e.label,
    ratePct: e.ratePct,
    amount: (i * e.ratePct) / 100,
    note: `${e.label} is ${e.ratePct}% of ${e.wageCapAnnual === null ? "all wages, with no wage cap" : "wages up to the cap"} in ${e.year} (${e.source}).`,
  };
}
function ae(t) {
  return W.includes(t)
    ? `${M[t]?.name ?? t} also takes state disability or paid family leave contributions from pay. They are not included here, so your pay stub will show a little less than this estimate.`
    : "";
}
export {
  _ as B,
  G as F,
  U as S,
  V as U,
  te as a,
  K as b,
  L as c,
  q as d,
  X as e,
  O as f,
  E as g,
  ee as h,
  ae as i,
  M as j,
  Z as k,
  J as m,
  z as q,
  Q as s,
};
//# sourceMappingURL=stateTaxData-BkbKzEdQ.js.map
