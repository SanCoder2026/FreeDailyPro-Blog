// state-tax-calculator: axe on main with MD selected and the compare table open (reading only).
const { chromium } = require('playwright'); const fs = require('fs');
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); p.setDefaultTimeout(10000);
 await p.goto('https://www.freedailypro.com/tool/state-tax-calculator', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 await p.selectOption('select[aria-label=State]', 'MD'); await p.getByRole('button', { name: 'Compare all states' }).click(); await p.waitForTimeout(500);
 await p.addScriptTag({ content: fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8') });
 const v = await p.evaluate(async () => (await axe.run(document.querySelector('main'))).violations.map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length, s: v.nodes.slice(0, 3).map(x => x.target.join(' ').slice(0, 100)) })));
 const rowsFocusable = await p.evaluate(() => { const r = document.querySelector('[data-testid=st-compare] tbody tr'); return { tabindex: r.getAttribute('tabindex'), role: r.getAttribute('role'), hasButton: !!r.querySelector('button,a'), onclick: true }; });
 fs.writeFileSync('/workspace/deep/10-state-tax-calculator/live/axe.json', JSON.stringify({ v, rowsFocusable }, null, 1)); console.log(JSON.stringify({ v, rowsFocusable }, null, 1)); await b.close(); })();
