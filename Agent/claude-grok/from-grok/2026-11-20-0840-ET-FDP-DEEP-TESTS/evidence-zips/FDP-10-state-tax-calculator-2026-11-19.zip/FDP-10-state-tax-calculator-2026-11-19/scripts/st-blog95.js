// state-tax-calculator: re-check the blog's $95,000 single-filer table against the live tool (reading only).
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); p.setDefaultTimeout(10000);
 await p.goto('https://www.freedailypro.com/tool/state-tax-calculator', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 const blog = { TX: '$0', NC: '$3,282', CO: '$3,472', NY: '$4,652', CA: '$4,847', OR: '$7,763' }; const R = { t: cp.execSync('date "+%F %T %Z"').toString().trim(), rows: [] };
 await p.getByLabel('Annual income').fill('95000');
 for (const st of Object.keys(blog)) { await p.selectOption('select[aria-label=State]', st); await p.waitForTimeout(400);
  R.rows.push({ st, blog: blog[st], tool: await p.locator('[data-testid=st-tax]').innerText(), eff: await p.locator('[data-testid=st-eff]').innerText().catch(() => null) }); }
 await p.selectOption('select[aria-label=State]', 'NY'); const box = p.locator('[data-testid=st-local-box] input'); await box.check(); await p.waitForTimeout(300); R.nyWithBox = await p.locator('[data-testid=st-tax]').innerText();
 fs.writeFileSync('/workspace/deep/10-state-tax-calculator/live/blog95.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R)); await b.close(); })();
