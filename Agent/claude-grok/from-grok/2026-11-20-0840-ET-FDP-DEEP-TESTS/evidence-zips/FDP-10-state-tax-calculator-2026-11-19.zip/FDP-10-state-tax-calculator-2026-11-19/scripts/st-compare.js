// state-tax-calculator: dump the full "Compare all states" table for a given income/status (reading only). Usage: node st-compare.js 75000 single
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
(async () => { const [inc = '75000', fs_ = 'single'] = process.argv.slice(2); const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); p.setDefaultTimeout(10000);
 await p.goto('https://www.freedailypro.com/tool/state-tax-calculator', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 await p.getByLabel('Annual income').fill(inc); await p.selectOption('select[aria-label="Filing status"]', fs_); await p.getByRole('button', { name: 'Compare all states' }).click(); await p.waitForTimeout(600);
 const rows = await p.evaluate(() => [...document.querySelectorAll('[data-testid=st-compare] tbody tr')].map(r => [...r.querySelectorAll('td')].map(td => td.innerText.trim())));
 const R = { t: cp.execSync('date "+%F %T %Z"').toString().trim(), inc, fs: fs_, rows }; fs.writeFileSync(`/workspace/deep/10-state-tax-calculator/live/compare-${inc}-${fs_}.json`, JSON.stringify(R, null, 1)); console.log(rows.map(r => r.slice(0, 2).join(':')).join('; ')); await b.close(); })();
