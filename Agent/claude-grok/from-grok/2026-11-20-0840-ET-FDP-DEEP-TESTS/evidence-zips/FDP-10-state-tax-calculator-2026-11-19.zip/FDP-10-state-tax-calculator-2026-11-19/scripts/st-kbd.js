// state-tax-calculator: Compare all states, "85k" input, keyboard order, axe, aria-live, phones. Reading only (no trial use).
const { chromium, devices } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/10-state-tax-calculator/live/'; const URL = 'https://www.freedailypro.com/tool/state-tax-calculator';
(async () => { const b = await chromium.launch(); const R = { t: cp.execSync('date "+%F %T %Z"').toString().trim() };
 const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(10000); await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday; R.used0 = await used();
 await p.getByRole('button', { name: 'Compare all states' }).click(); await p.waitForTimeout(800);
 R.compare = await p.evaluate(() => { const t = document.querySelector('[data-testid=st-compare]'); const rows = [...t.querySelectorAll('tbody tr')].map(r => r.innerText.replace(/\t/g, ' | ').replace(/\n/g, ' ')); return { n: rows.length, first: rows.slice(0, 4), last: rows.slice(-4), head: t.innerText.slice(0, 300), localToggle: !!document.querySelector('[data-testid=st-compare-local]') }; });
 R.compareRowsHoh = null; await p.selectOption('select[aria-label="Filing status"]', 'hoh'); await p.waitForTimeout(400);
 R.compareHohFirst = await p.evaluate(() => [...document.querySelectorAll('[data-testid=st-compare] tbody tr')].slice(0, 3).map(r => r.innerText.replace(/\s+/g, ' ')));
 await p.selectOption('select[aria-label="Filing status"]', 'single');
 await p.locator('[data-testid=st-compare] tbody tr').nth(5).click().catch(e => R.rowClickErr = String(e)); await p.waitForTimeout(400); R.stateAfterRowClick = await p.locator('select[aria-label=State]').inputValue();
 await p.screenshot({ path: OUT + 'compare.png', fullPage: false }); R.usedAfterCompare = await used();
 await p.selectOption('select[aria-label=State]', 'CA'); await p.getByLabel('Annual income').fill('85k'); await p.waitForTimeout(400);
 R.k85 = await p.evaluate(() => ({ tax: document.querySelector('[data-testid=st-tax]')?.innerText, alerts: [...document.querySelectorAll('main [role=alert]')].map(e => e.innerText), invalid: document.querySelector('input[aria-label="Annual income"]').getAttribute('aria-invalid') }));
 await p.locator('[data-testid=tool-area]').screenshot({ path: OUT + 'input-85k-shows-zero.png' });
 await p.getByLabel('Annual income').fill('75000'); await p.getByLabel('Annual income').focus(); const seq = [];
 for (let i = 0; i < 14; i++) { await p.keyboard.press('Tab'); seq.push(await p.evaluate(() => { const e = document.activeElement; return `${e.tagName} ${(e.getAttribute('aria-label') || e.innerText || e.id || '').trim().slice(0, 34)}`; })); }
 R.tabSeq = seq; R.live = await p.evaluate(() => ({ ariaLive: [...document.querySelectorAll('main [aria-live]')].map(e => e.getAttribute('aria-live') + ':' + e.innerText.slice(0, 40)), status: document.querySelectorAll('main [role=status]').length }));
 try { await p.addScriptTag({ content: fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8') }); await p.selectOption('select[aria-label=State]', 'MD'); await p.getByRole('button', { name: 'Compare all states' }).click();
  R.axe = await p.evaluate(async () => (await axe.run(document.querySelector('main'))).violations.map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length, s: v.nodes.slice(0, 2).map(x => x.target.join(' ').slice(0, 100)) }))); } catch (e) { R.axe = String(e); }
 for (const dn of ['iPhone SE', 'Pixel 7']) { const cc = await b.newContext({ ...devices[dn] }); const q = await cc.newPage(); await q.goto(URL, { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4000);
  await q.getByRole('button', { name: 'Compare all states' }).click(); await q.waitForTimeout(500);
  R['phone_' + dn] = await q.evaluate(() => { const y = s => { const e = document.querySelector(s); return e ? Math.round(e.getBoundingClientRect().top + scrollY) : null; }; const t = document.querySelector('[data-testid=st-compare] table'); return { vw: innerWidth, sw: document.documentElement.scrollWidth, incomeY: y('input[aria-label="Annual income"]'), taxY: y('[data-testid=st-tax]'), compareTableW: t ? Math.round(t.getBoundingClientRect().width) : null, compareWrapScroll: t ? t.parentElement.scrollWidth + '/' + t.parentElement.clientWidth : null }; });
  await q.screenshot({ path: OUT + `phone-${dn.replace(/\s/g, '-').toLowerCase()}-full.png`, fullPage: true }); await cc.close(); }
 R.usedEnd = await used(); fs.writeFileSync(OUT + 'kbd.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
