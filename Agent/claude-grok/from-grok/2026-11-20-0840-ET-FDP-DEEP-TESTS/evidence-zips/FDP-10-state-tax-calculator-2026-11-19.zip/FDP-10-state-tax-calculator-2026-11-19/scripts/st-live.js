// state-tax-calculator: calculation cases (reading only; never copy/save/print, so no trial use). Usage: node st-live.js [ids]
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/10-state-tax-calculator/live/';
const C = {
 S01_CA_single_75k: { inc: '75000', st: 'CA', fs: 'single' }, S02_CA_hoh_75k: { inc: '75000', st: 'CA', fs: 'hoh' }, S03_CA_mfj_150k: { inc: '150000', st: 'CA', fs: 'mfj' },
 S04_NY_single_85k: { inc: '85000', st: 'NY', fs: 'single' }, S05_NY_hoh_85k: { inc: '85000', st: 'NY', fs: 'hoh' }, S06_NY_NYC_single_85k: { inc: '85000', st: 'NY', fs: 'single', loc: 'ny-nyc' },
 S07_MD_montgomery_85k: { inc: '85000', st: 'MD', fs: 'single', loc: 'md-montgomery' }, S08_MD_anne_arundel_85k: { inc: '85000', st: 'MD', fs: 'single', loc: 'md-anne-arundel' },
 S09_MD_typical_box_85k: { inc: '85000', st: 'MD', fs: 'single', box: true }, S10_PA_phila_res_85k: { inc: '85000', st: 'PA', fs: 'single', loc: 'pa-philadelphia' },
 S10b_PA_phila_worker_85k: { inc: '85000', st: 'PA', fs: 'single', loc: 'pa-philadelphia', worker: true }, S11_NY_yonkers_85k: { inc: '85000', st: 'NY', fs: 'single', loc: 'ny-yonkers' },
 S12_IL_75k: { inc: '75000', st: 'IL', fs: 'single' }, S13_TX_75k: { inc: '75000', st: 'TX', fs: 'single' }, S14_WA_75k: { inc: '75000', st: 'WA', fs: 'single' }, S21_MA_75k: { inc: '75000', st: 'MA', fs: 'single' },
 S15_text_abc: { inc: 'abc', st: 'CA', fs: 'single' }, S16_negative: { inc: '-5000', st: 'CA', fs: 'single' }, S17_85k_suffix: { inc: '85k', st: 'CA', fs: 'single' }, S18_zero: { inc: '0', st: 'CA', fs: 'single' },
 S19_CA_10M: { inc: '10000000', st: 'CA', fs: 'single' }, S22_NJ_75k: { inc: '75000', st: 'NJ', fs: 'single' }, S24_PA_box_85k: { inc: '85000', st: 'PA', fs: 'single', box: true },
 S25_GA_hoh_75k: { inc: '75000', st: 'GA', fs: 'hoh' }, S26_GA_single_75k: { inc: '75000', st: 'GA', fs: 'single' }, S27_NC_hoh_75k: { inc: '75000', st: 'NC', fs: 'hoh' }, S28_NC_single_75k: { inc: '75000', st: 'NC', fs: 'single' },
 S29_MD_frederick_mfs_85k: { inc: '85000', st: 'MD', fs: 'mfs', loc: 'md-frederick' }, S30_OR_75k: { inc: '75000', st: 'OR', fs: 'single' },
};
(async () => { const ids = process.argv[2] ? process.argv[2].split(',') : Object.keys(C); const b = await chromium.launch();
 const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); p.setDefaultTimeout(12000);
 await p.goto('https://www.freedailypro.com/tool/state-tax-calculator', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 const R = { t0: cp.execSync('date "+%F %T %Z"').toString().trim(), ls0: await p.evaluate(() => localStorage.getItem('fdp-usage-v1')), cases: {} };
 for (const id of ids) { const c = C[id];
  await p.selectOption('select[aria-label=State]', c.st); await p.selectOption('select[aria-label="Filing status"]', c.fs); await p.waitForTimeout(200);
  const box = p.locator('[data-testid=st-local-box] input[type=checkbox]'); if (await box.count()) { if ((await box.isChecked()) !== !!c.box) await box.click(); }
  const loc = p.locator('select[aria-label="City or county"]'); if (await loc.count()) await loc.selectOption(c.loc || '');
  if (c.worker) await p.selectOption('select[aria-label="Live or work there"]', 'worker');
  await p.getByLabel('Annual income').fill(c.inc); await p.waitForTimeout(500);
  R.cases[id] = { input: c, ...(await p.evaluate(() => { const g = s => { const e = document.querySelector(`[data-testid=${s}]`); return e ? e.innerText.replace(/\s+/g, ' ').trim() : null; };
   return { tax: g('st-tax'), eff: g('st-eff'), localLine: g('st-local-line'), localIncluded: g('st-local-included'), localNotice: g('st-local-notice'), localityNote: g('st-locality-note'), extras: g('st-extras'), totalAll: g('st-total-all'),
     payroll: [...document.querySelectorAll('[data-testid^=st-payroll-]')].map(e => e.innerText.replace(/\s+/g, ' ')), alerts: [...document.querySelectorAll('main [role=alert]')].map(e => e.innerText),
     table: (document.querySelector('[data-testid=calc-table]')?.innerText || '').replace(/\t/g, ' | ').split('\n').slice(0, 14), summaryBox: (document.querySelector('[data-testid=tool-area]')?.innerText.match(/Marginal rate[\s\S]{0,40}|Taxable income[\s\S]{0,30}/g) || []) }; })) };
 }
 R.lsEnd = await p.evaluate(() => localStorage.getItem('fdp-usage-v1')); R.t1 = cp.execSync('date "+%F %T %Z"').toString().trim();
 fs.writeFileSync(OUT + `cases-${Date.now()}.json`, JSON.stringify(R, null, 1));
 for (const [k, v] of Object.entries(R.cases)) console.log(k, '|', v.tax, '|', v.eff, '|', v.localLine, '|', v.totalAll, '|', v.payroll.join(' ; ').slice(0, 120), '|', v.alerts.join(' ').slice(0, 100), '|', (v.localNotice || '').slice(0, 60));
 await b.close(); })();
