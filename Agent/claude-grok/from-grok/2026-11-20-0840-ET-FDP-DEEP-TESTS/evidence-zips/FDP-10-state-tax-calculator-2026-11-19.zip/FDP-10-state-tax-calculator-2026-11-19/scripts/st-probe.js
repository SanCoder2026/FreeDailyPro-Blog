// state-tax-calculator: starting count, controls, testids, buttons (no trial use).
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(12000);
 const js = []; p.on('response', r => { if (/\/assets\/.*\.js$/.test(r.url())) js.push(r.url().split('/').pop()); });
 await p.goto('https://www.freedailypro.com/tool/state-tax-calculator', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 await p.selectOption('select[aria-label=State]', 'MD'); await p.waitForTimeout(500);
 const R = await p.evaluate(() => ({ t: null, strip: (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0], ls: localStorage.getItem('fdp-usage-v1'),
   controls: [...document.querySelectorAll('main input, main select, main button')].map(e => ({ tag: e.tagName, type: e.type, label: e.getAttribute('aria-label') || (e.labels && e.labels[0] ? e.labels[0].innerText : '') || e.innerText.trim().slice(0, 40), testid: e.closest('[data-testid]')?.getAttribute('data-testid') })),
   testids: [...document.querySelectorAll('[data-testid]')].map(e => e.getAttribute('data-testid') + ' = ' + e.innerText.replace(/\s+/g, ' ').slice(0, 120)) }));
 R.t = cp.execSync('date "+%F %T %Z"').toString().trim(); R.js = [...new Set(js)];
 await p.screenshot({ path: '/workspace/deep/10-state-tax-calculator/live/probe.png', fullPage: true });
 fs.writeFileSync('/workspace/deep/10-state-tax-calculator/live/probe.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify({ ...R, js: R.js.length }, null, 1)); await b.close(); })();
