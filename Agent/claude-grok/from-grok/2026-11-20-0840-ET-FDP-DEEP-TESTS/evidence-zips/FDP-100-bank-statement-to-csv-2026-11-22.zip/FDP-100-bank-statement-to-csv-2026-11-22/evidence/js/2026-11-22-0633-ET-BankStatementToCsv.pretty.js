import { r as N, j as s } from "./vendor-react-D01g8YgM.js";
import { utils as j, write as K } from "./xlsx-CNerDvZX.js";
import {
  e as $,
  T as Q,
  I as S,
  N as X,
  B as F,
  D as I,
  f as L,
} from "./index-DagluEtV.js";
import { b as ee, T as te, F as ne, d as U } from "./ToolPage-B4roIUf_.js";
import { T as se } from "./ToolInfoSection-C0Lbi6Qb.js";
import { b as ae } from "./utils-s8ucLyj8.js";
import { s as oe } from "./csvParse-eP1CzDn2.js";
import { T as le } from "./trash-2-DpHY4NWT.js";
import "./useUploadApi-Cwp1vwlT.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-CL8JsD0s.js";
import "./share-2-B34wyobX.js";
import "./copy-CQptMDp5.js";
import "./workflowCta-oWYKzOWD.js";
import "./UsageAndUpgradeStrip-BiAdGTIF.js";
import "./access-BSSUf40u.js";
import "./useAdminAccess-CYp3AlSq.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CgocG3qD.js";
import "./map-pin-DvVDRebE.js";
import "./FaqSection-DsOLPaJ0.js";
import "./ToolVideoEmbed-CZwBIyFf.js";
import "./GuideLinks-BVE0aHrc.js";
import "./blog-BPnsEI_q.js";
import "./info-56I4OKVq.js";
import "./productCards-CUOqxId0.js";
import "./layers-BVDCe9zx.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-DmEVOuX4.js";
import "./chevron-up-B0wsCoBg.js";
const P = { year: new Date().getFullYear() },
  G = [
    "jan",
    "feb",
    "mar",
    "apr",
    "may",
    "jun",
    "jul",
    "aug",
    "sep",
    "oct",
    "nov",
    "dec",
  ],
  q = "(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\\.?",
  re = new RegExp("^(\\d{4})-(\\d{2})-(\\d{2})\\b"),
  ie = new RegExp(
    "^(\\d{1,2})[/.-](\\d{1,2})(?:[/.-](\\d{2,4}))?(?![\\d/.-]*\\d{3})",
  ),
  ce = new RegExp("^(" + q + ")\\s+(\\d{1,2})(?:,?\\s+(\\d{4}))?\\b", "i"),
  ue = new RegExp("^(\\d{1,2})\\s+(" + q + ")(?:\\s+(\\d{4}))?\\b", "i");
function A(n) {
  let e = re.exec(n);
  if (e)
    return {
      kind: "iso",
      a: Number(e[1]),
      b: Number(e[2]),
      c: Number(e[3]),
      len: e[0].length,
    };
  if (((e = ce.exec(n)), e))
    return {
      kind: "monfirst",
      a: G.indexOf(e[1].slice(0, 3).toLowerCase()) + 1,
      b: Number(e[2]),
      c: e[3] ? Number(e[3]) : null,
      len: e[0].length,
    };
  if (((e = ue.exec(n)), e))
    return {
      kind: "dayfirst",
      a: Number(e[1]),
      b: G.indexOf(e[2].slice(0, 3).toLowerCase()) + 1,
      c: e[3] ? Number(e[3]) : null,
      len: e[0].length,
    };
  if (((e = ie.exec(n)), e)) {
    const t = e[3] ? Number(e[3]) : null;
    return {
      kind: "slash",
      a: Number(e[1]),
      b: Number(e[2]),
      c: t === null ? null : t < 100 ? 2e3 + t : t,
      len: e[0].length,
    };
  }
  return null;
}
function z(n) {
  return n < 10 ? "0" + n : String(n);
}
function de(n, e, t) {
  if (e < 1 || e > 12 || t < 1) return !1;
  const i = [
    31,
    (n % 4 === 0 && n % 100 !== 0) || n % 400 === 0 ? 29 : 28,
    31,
    30,
    31,
    30,
    31,
    31,
    30,
    31,
    30,
    31,
  ][e - 1];
  return t <= i;
}
function me(n) {
  let e = 0,
    t = 0;
  for (const i of n) {
    const l = A(i.trim());
    !l ||
      l.kind !== "slash" ||
      (l.a > 12 && l.b <= 12 ? e++ : l.b > 12 && l.a <= 12 && t++);
  }
  return e > t ? "dmy" : "mdy";
}
function Y(n, e, t) {
  let i, l, r;
  return (
    n.kind === "iso"
      ? ((i = n.a), (l = n.b), (r = n.c))
      : n.kind === "monfirst"
        ? ((i = n.c ?? t), (l = n.a), (r = n.b))
        : n.kind === "dayfirst"
          ? ((i = n.c ?? t), (l = n.b), (r = n.a))
          : ((i = n.c ?? t),
            e === "mdy" ? ((l = n.a), (r = n.b)) : ((l = n.b), (r = n.a))),
    de(i, l, r) ? `${i}-${z(l)}-${z(r)}` : null
  );
}
const he =
    "\\(?[-+]?[$€£₹]?\\s?[-+]?\\d{1,3}(?:,\\d{3})*\\.\\d{2}\\)?-?(?:\\s?(?:CR|DR))?",
  fe = "\\(?[-+]?[$€£₹]?\\s?[-+]?\\d+\\.\\d{2}\\)?-?(?:\\s?(?:CR|DR))?",
  pe =
    "\\(?[-+]?[$€£₹]?\\s?[-+]?\\d{1,3}(?:\\.\\d{3})*,\\d{2}\\)?-?(?:\\s?(?:CR|DR))?",
  be = "\\(?[-+]?[$€£₹]?\\s?[-+]?\\d+,\\d{2}\\)?-?(?:\\s?(?:CR|DR))?";
function ge(n) {
  const e = n === "us" ? `(?:${he}|${fe})` : `(?:${pe}|${be})`;
  return new RegExp(`(?:^|\\s)(${e})$`, "i");
}
function xe(n) {
  let e = 0,
    t = 0;
  const i = new RegExp("\\d\\.\\d{2}\\s*(?:CR|DR)?$", "i"),
    l = new RegExp("\\d,\\d{2}\\s*(?:CR|DR)?$", "i");
  for (const r of n) {
    const h = r.trim();
    i.test(h) ? e++ : l.test(h) && t++;
  }
  return t > e ? "eu" : "us";
}
function we(n, e) {
  let t = n.trim(),
    i = !1;
  if (
    (/^\(.*\)$/.test(t) && ((i = !0), (t = t.slice(1, -1))),
    /(?:^|\s)DR$/i.test(t)
      ? ((i = !0), (t = t.replace(/\s?DR$/i, "")))
      : /(?:^|\s)CR$/i.test(t) && (t = t.replace(/\s?CR$/i, "")),
    /-$/.test(t) && ((i = !0), (t = t.slice(0, -1))),
    (t = t.replace(/[$€£₹\s]/g, "")),
    t.charAt(0) === "-"
      ? ((i = !i), (t = t.slice(1)))
      : t.charAt(0) === "+" && (t = t.slice(1)),
    (t =
      e === "us"
        ? t.replace(/,/g, "")
        : t.replace(/\./g, "").replace(",", ".")),
    !/^\d+(\.\d+)?$/.test(t))
  )
    return null;
  const l = Math.round(Number(t) * 100) / 100;
  return i ? -l : l;
}
const W = new RegExp(
    "^(?:alter kontostand|anfangssaldo|anfangsbestand|ancien solde|solde pr[eé]c[eé]dent|solde initial|saldo anterior|saldo inicial|saldo iniziale|saldo precedente)\\b|^(?:beginning|opening|previous|brought forward|balance brought forward|starting)\\b.*\\bbalance\\b|^balance\\s+(?:brought\\s+forward|forward|b/f)|^(?:previous|opening|beginning)\\s+balance",
    "i",
  ),
  V = new RegExp(
    "^(?:neuer kontostand|endsaldo|endbestand|nouveau solde|solde final|solde de cl[oô]ture|saldo final|saldo actual|saldo finale)\\b|^(?:ending|closing|new|statement|balance\\s+carried|balance\\s+c/f)\\b.*\\bbalance\\b|^(?:ending|closing|new)\\s+balance",
    "i",
  ),
  ye = /^(?:balance\s+)?(?:b\/f|brought\s+forward)\b/i,
  ve = /^(?:balance\s+)?(?:c\/f|carried\s+forward)\b/i,
  H = new RegExp(
    "^(?:page\\s+\\d|account\\s+(?:number|summary)|statement\\s+(?:period|date)|total\\b|continued|customer service|date\\s+description|daily\\s+balance)",
    "i",
  ),
  Ne = new RegExp(
    "\\b(?:deposit|credit|refund|reversal|interest paid|interest earned|payroll|salary|direct dep|transfer from|payment received|cashback|cash back|gehalt|lohn|erstattung|gutschrift|rückerstattung|remboursement|salaire|virement re[cç]u|n[oó]mina|abono|ingreso|reembolso|stipendio|accredito|rimborso)\\b",
    "i",
  ),
  je =
    /\b(?:payment|thank you|autopay|auto pay|credit|refund|reversal|cashback|cash back|adjustment)\b/i;
function M(n) {
  return Ne.test(n);
}
function E(n, e) {
  const t = ge(e),
    i = [];
  let l = n.trim();
  for (let r = 0; r < 3; r++) {
    const h = t.exec(l);
    if (!h) break;
    const m = we(h[1], e);
    if (m === null) break;
    (i.unshift(m), (l = l.slice(0, l.length - h[1].length).trim()));
  }
  return { amounts: i, text: l };
}
function T(n, e) {
  const t = E(n, e);
  return t.amounts.length ? t.amounts[t.amounts.length - 1] : null;
}
function ke(n, e) {
  const t = n
      .map((a) =>
        a
          .replace(/[\u2212\u2012](?=\s*[$€£₹]?\d)/g, "-")
          .replace(/\s+/g, " ")
          .trim(),
      )
      .filter(Boolean),
    i = e.dateOrder === "auto" ? me(t) : e.dateOrder,
    l = e.numberFormat === "auto" ? xe(t) : e.numberFormat,
    r = [],
    h = [];
  let m = null,
    g = null;
  const w = [];
  let f = null;
  const k = (a, o, d, u) => {
    let x,
      v = null;
    (d.length === 1
      ? (x = d[0])
      : d.length === 2
        ? ((x = d[0]), (v = d[1]))
        : ((v = d[2]), (x = d[0] !== 0 ? d[0] : d[1])),
      r.push({ date: a, description: o, amount: x, balance: v, signGuess: !1 }),
      w.push(/^\(|^-|-$|\bDR\b|\bCR\b/i.test(u) || x < 0));
  };
  for (const a of t) {
    if (W.test(a)) {
      const u = T(a, l);
      u !== null && m === null && (m = u);
      continue;
    }
    if (V.test(a)) {
      const u = T(a, l);
      u !== null && (g = u);
      continue;
    }
    const o = A(a),
      d = o ? Y(o, i, e.year) : null;
    if (o && d) {
      let u = a.slice(o.len).trim();
      const x = A(u);
      if (
        (x && Y(x, i, e.year) && (u = u.slice(x.len).trim()),
        W.test(u) || ye.test(u))
      ) {
        const c = T(u, l);
        (c !== null && m === null && (m = c), (f = null));
        continue;
      }
      if (V.test(u) || ve.test(u)) {
        const c = T(u, l);
        (c !== null && (g = c), (f = null));
        continue;
      }
      f = null;
      const { amounts: v, text: D } = E(u, l);
      if (!v.length) {
        f = { date: d, text: u, raw: a };
        continue;
      }
      if (!D) {
        h.push(a);
        continue;
      }
      k(d, D, v, u.slice(D.length).trim());
      continue;
    }
    if (f) {
      const { amounts: u, text: x } = E(a, l);
      if (u.length) {
        (k(f.date, (f.text + " " + x).trim(), u, a.slice(x.length).trim()),
          (f = null));
        continue;
      }
      if (!H.test(a) && a.length <= 80) {
        f.text += " " + a;
        continue;
      }
      (h.push(f.raw), (f = null));
    }
    r.length &&
      !H.test(a) &&
      !E(a, l).amounts.length &&
      a.length <= 80 &&
      !/^\d+$/.test(a) &&
      (r[r.length - 1].description += " " + a);
  }
  for (let a = 0; a < r.length; a++) {
    const o = r[a],
      d = a > 0 ? r[a - 1].balance : m;
    if (o.balance !== null && d !== null && d !== void 0) {
      const u = Math.round((o.balance - d) * 100) / 100;
      if (Math.abs(Math.abs(o.amount) - Math.abs(u)) < 0.006) {
        o.amount = u;
        continue;
      }
    }
  }
  const R =
    !r.some((a) => a.balance !== null) &&
    m === null &&
    g === null &&
    r.length >= 2 &&
    r.some((a, o) => w[o] && a.amount < 0) &&
    r.some((a, o) => !w[o] && a.amount > 0) &&
    r.every(
      (a, o) =>
        !(w[o] && a.amount < 0) || je.test(a.description) || M(a.description),
    );
  if (R)
    for (let a = 0; a < r.length; a++) {
      const o = r[a];
      w[a] && o.amount < 0
        ? ((o.amount = -o.amount), (o.signGuess = !1))
        : w[a] ||
          ((o.amount = M(o.description)
            ? Math.abs(o.amount)
            : -Math.abs(o.amount)),
          (o.signGuess = !1));
    }
  for (let a = 0; a < r.length; a++) {
    const o = r[a],
      d = a > 0 ? r[a - 1].balance : m,
      u =
        o.balance !== null &&
        d !== null &&
        d !== void 0 &&
        Math.abs(o.balance - d - o.amount) < 0.006;
    R ||
      u ||
      w[a] ||
      o.amount < 0 ||
      ((o.balance === null || d === null || d === void 0) &&
        (M(o.description) || (o.amount = -o.amount), (o.signGuess = !0)));
  }
  if (e.flipSigns)
    for (const a of r) ((a.amount = -a.amount), (a.signGuess = !1));
  return {
    txns: r,
    openingBalance: m,
    closingBalance: g,
    dateOrder: i,
    numberFormat: l,
    skipped: h,
    cardLayout: R,
  };
}
const _ = (n) => Math.round(n * 100) / 100;
function Re(n, e, t) {
  const i = _(n.reduce((m, g) => m + g.amount, 0)),
    l = [];
  let r = 0;
  for (let m = 0; m < n.length; m++) {
    const g = m > 0 ? n[m - 1].balance : e,
      w = n[m];
    w.balance !== null &&
      g !== null &&
      g !== void 0 &&
      (r++, Math.abs(_(g + w.amount) - w.balance) > 0.006 && l.push(m + 1));
  }
  const h = e !== null && t !== null ? _(e + i - t) : null;
  if (r > 0) {
    const m = l.length === 0 && (h === null || Math.abs(h) < 0.006);
    return {
      basis: "balances",
      ok: m,
      total: i,
      mismatchedRows: l,
      difference: h,
      message: m
        ? `All ${r} running balances follow from the rows.`
        : l.length
          ? `${l.length} row${l.length > 1 ? "s do" : " does"} not match the printed balance. Check rows ${l.slice(0, 8).join(", ")}.`
          : `The rows are ${Math.abs(h).toFixed(2)} away from the closing balance.`,
    };
  }
  if (h !== null) {
    const m = Math.abs(h) < 0.006;
    return {
      basis: "totals",
      ok: m,
      total: i,
      mismatchedRows: [],
      difference: h,
      message: m
        ? "Opening balance plus the rows equals the closing balance."
        : `Opening balance plus the rows is ${Math.abs(h).toFixed(2)} ${h > 0 ? "above" : "below"} the closing balance. A row may be missing, doubled or have the wrong sign.`,
    };
  }
  return {
    basis: "none",
    ok: !1,
    total: i,
    mismatchedRows: [],
    difference: null,
    message:
      "The statement text has no opening and closing balance, so the rows cannot be checked. Compare the total yourself.",
  };
}
function De(n) {
  return [
    ["Date", "Description", "Amount", "Balance"],
    ...n.map((e) => [
      e.date,
      e.description,
      e.amount.toFixed(2),
      e.balance === null ? "" : e.balance.toFixed(2),
    ]),
  ];
}
function Ce(n) {
  const e = /^(\d{4})-(\d{2})-(\d{2})$/.exec(n);
  if (!e) return null;
  const t = Date.UTC(+e[1], +e[2] - 1, +e[3]),
    i = new Date(t);
  return i.getUTCFullYear() !== +e[1] ||
    i.getUTCMonth() !== +e[2] - 1 ||
    i.getUTCDate() !== +e[3]
    ? null
    : Math.round(t / 864e5) + 25569;
}
function $e(n) {
  const e = j.aoa_to_sheet([["Date", "Description", "Amount", "Balance"]]);
  return (
    n.forEach((t, i) => {
      const l = i + 1,
        r = Ce(t.date);
      ((e[j.encode_cell({ r: l, c: 0 })] =
        r === null ? { t: "s", v: t.date } : { t: "n", v: r, z: "yyyy-mm-dd" }),
        (e[j.encode_cell({ r: l, c: 1 })] = { t: "s", v: t.description }),
        (e[j.encode_cell({ r: l, c: 2 })] = {
          t: "n",
          v: t.amount,
          z: "#,##0.00",
        }),
        t.balance !== null &&
          (e[j.encode_cell({ r: l, c: 3 })] = {
            t: "n",
            v: t.balance,
            z: "#,##0.00",
          }));
    }),
    (e["!ref"] = j.encode_range({
      s: { r: 0, c: 0 },
      e: { r: Math.max(n.length, 1), c: 3 },
    })),
    (e["!cols"] = [{ wch: 12 }, { wch: 50 }, { wch: 14 }, { wch: 14 }]),
    e
  );
}
const O = {
  what: "Turns the transaction list in a bank or card statement PDF into a table you can check, fix and save as CSV or Excel. It reads the dates, descriptions, amounts and running balances, then checks that the opening balance plus the rows matches the closing balance. It runs in your browser, so the statement is not uploaded.",
  how: "Drop a statement PDF that has real text, or paste the transaction lines. Set the year if the dates do not print one. Look at the check under the table, correct any cell that is wrong, then download.",
  tip: "Banks lay statements out in many ways, so read the check line before you trust the numbers. If it shows a gap, the row list under it points to the lines to look at first. Scanned statements have no text to read; run them through OCR first.",
};
function ot() {
  const [n, e] = N.useState(""),
    [t, i] = N.useState(String(P.year)),
    [l, r] = N.useState("auto"),
    [h, m] = N.useState("auto"),
    [g, w] = N.useState(!1),
    [f, k] = N.useState([]),
    [B, R] = N.useState(!1),
    { logUsageNow: a } = ee(),
    o = N.useMemo(() => {
      if (!n.trim()) return null;
      const c = Number(t);
      return ke(n.split(/\r?\n/), {
        year: Number.isFinite(c) && c > 1900 ? c : P.year,
        dateOrder: l,
        numberFormat: h,
        flipSigns: g,
      });
    }, [n, t, l, h, g]);
  N.useEffect(() => {
    k(o ? o.txns.map((c) => ({ ...c })) : []);
  }, [o]);
  const d = N.useMemo(
      () => (o ? Re(f, o.openingBalance, o.closingBalance) : null),
      [f, o],
    ),
    u = f.filter((c) => c.signGuess).length,
    x = async (c) => {
      const p = c[0];
      if (p) {
        R(!0);
        try {
          const y = (await ae(p)).reduce(
            (C, Z) => C.concat(Z.map((J) => J.text)),
            [],
          );
          if (y.join("").trim().length < 20) {
            L.error(
              "This PDF has no readable text. It may be a scan; run it through OCR first.",
            );
            return;
          }
          e(
            y.join(`
`),
          );
        } catch (b) {
          (console.error(b), L.error("Could not read that PDF."));
        } finally {
          R(!1);
        }
      }
    },
    v = (c, p) =>
      k((b) => b.map((y, C) => (C === c ? { ...y, ...p, signGuess: !1 } : y))),
    D = async (c) => {
      if (f.length && (await a()))
        if (c === "csv")
          U(
            new Blob([oe(De(f))], { type: "text/csv;charset=utf-8" }),
            "statement.csv",
          );
        else {
          const p = $e(f),
            b = j.book_new();
          j.book_append_sheet(b, p, "Transactions");
          const y = K(b, { type: "array", bookType: "xlsx" });
          U(
            new Blob([y], {
              type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            }),
            "statement.xlsx",
          );
        }
    };
  return s.jsxs(te, {
    children: [
      s.jsxs("div", {
        className: "max-w-4xl mx-auto min-w-0 w-full space-y-6",
        children: [
          s.jsxs("section", {
            className: "space-y-2",
            children: [
              s.jsx(ne, {
                accept: ".pdf",
                maxSize: 30,
                onFiles: x,
                deferUsageLog: !0,
                label: B ? "Reading..." : "Drop a statement PDF",
                description: "Text PDFs only, not scans",
              }),
              s.jsx($, {
                htmlFor: "bs-text",
                className: "text-xs",
                children: "Or paste the transaction lines",
              }),
              s.jsx(Q, {
                id: "bs-text",
                rows: 5,
                value: n,
                onChange: (c) => e(c.target.value),
                className: "font-mono text-xs",
                placeholder: "03/01 Coffee Shop 4.50 995.50",
              }),
            ],
          }),
          s.jsxs("section", {
            className: "grid gap-3 sm:grid-cols-4",
            children: [
              s.jsxs("div", {
                className: "space-y-1",
                children: [
                  s.jsx($, {
                    htmlFor: "bs-year",
                    className: "text-xs",
                    children: "Year (for dates without one)",
                  }),
                  s.jsx(S, {
                    id: "bs-year",
                    inputMode: "numeric",
                    value: t,
                    onChange: (c) => i(c.target.value),
                  }),
                ],
              }),
              s.jsxs("div", {
                className: "space-y-1",
                children: [
                  s.jsx($, {
                    htmlFor: "bs-order",
                    className: "text-xs",
                    children: "Date order",
                  }),
                  s.jsxs("select", {
                    id: "bs-order",
                    className:
                      "h-9 w-full rounded-md border bg-background px-2 text-sm",
                    value: l,
                    onChange: (c) => r(c.target.value),
                    children: [
                      s.jsxs("option", {
                        value: "auto",
                        children: [
                          "Detect",
                          o
                            ? ` (${o.dateOrder === "dmy" ? "day first" : "month first"})`
                            : "",
                        ],
                      }),
                      s.jsx("option", {
                        value: "mdy",
                        children: "Month first",
                      }),
                      s.jsx("option", { value: "dmy", children: "Day first" }),
                    ],
                  }),
                ],
              }),
              s.jsxs("div", {
                className: "space-y-1",
                children: [
                  s.jsx($, {
                    htmlFor: "bs-num",
                    className: "text-xs",
                    children: "Number style",
                  }),
                  s.jsxs("select", {
                    id: "bs-num",
                    className:
                      "h-9 w-full rounded-md border bg-background px-2 text-sm",
                    value: h,
                    onChange: (c) => m(c.target.value),
                    children: [
                      s.jsxs("option", {
                        value: "auto",
                        children: [
                          "Detect",
                          o
                            ? ` (${o.numberFormat === "eu" ? "1.234,56" : "1,234.56"})`
                            : "",
                        ],
                      }),
                      s.jsx("option", { value: "us", children: "1,234.56" }),
                      s.jsx("option", { value: "eu", children: "1.234,56" }),
                    ],
                  }),
                ],
              }),
              s.jsxs("label", {
                className: "flex items-end gap-2 text-sm pb-2",
                children: [
                  s.jsx("input", {
                    type: "checkbox",
                    checked: g,
                    onChange: (c) => w(c.target.checked),
                  }),
                  "Card statement: flip signs",
                ],
              }),
            ],
          }),
          o &&
            s.jsxs("section", {
              className: "space-y-3",
              "aria-live": "polite",
              children: [
                d &&
                  s.jsxs("p", {
                    className: `text-sm ${d.ok ? "text-green-700" : "text-amber-700"}`,
                    "data-testid": "bs-check",
                    role: d.ok ? "status" : "alert",
                    children: [d.ok ? "Check passed. " : "Check: ", d.message],
                  }),
                o.cardLayout &&
                  s.jsx("p", {
                    className: "text-sm text-muted-foreground",
                    children:
                      'This looks like a card statement. Amounts without a sign were treated as charges (money out) and amounts with a minus as payments (money in). Tick "flip signs" if you want it the other way round.',
                  }),
                u > 0 &&
                  s.jsxs(X, {
                    className: "text-sm",
                    children: [
                      u,
                      " amount",
                      u > 1 ? "s have" : " has",
                      " no sign or balance to go on, so the sign was guessed from the words. Review them.",
                    ],
                  }),
                o.skipped.length > 0 &&
                  s.jsxs("p", {
                    className: "text-xs text-muted-foreground",
                    children: [
                      o.skipped.length,
                      " line",
                      o.skipped.length > 1 ? "s" : "",
                      " started with a date but had no amount and were left out.",
                    ],
                  }),
                f.length === 0
                  ? s.jsx("p", {
                      className: "text-sm text-muted-foreground",
                      children:
                        "No transaction lines found. Each line needs a date at the start and an amount at the end.",
                    })
                  : s.jsx("div", {
                      className:
                        "overflow-x-auto max-w-full min-w-0 rounded border",
                      children: s.jsxs("table", {
                        className: "w-full min-w-[30rem] text-sm",
                        "data-testid": "bs-table",
                        children: [
                          s.jsx("thead", {
                            className: "bg-muted/50 text-left",
                            children: s.jsxs("tr", {
                              children: [
                                s.jsx("th", {
                                  className: "p-2",
                                  children: "Date",
                                }),
                                s.jsx("th", {
                                  className: "p-2",
                                  children: "Description",
                                }),
                                s.jsx("th", {
                                  className: "p-2 text-right",
                                  children: "Amount",
                                }),
                                s.jsx("th", {
                                  className: "p-2 text-right",
                                  children: "Balance",
                                }),
                                s.jsx("th", {
                                  className: "p-2",
                                  children: s.jsx("span", {
                                    className: "sr-only",
                                    children: "Remove",
                                  }),
                                }),
                              ],
                            }),
                          }),
                          s.jsx("tbody", {
                            children: f.map((c, p) =>
                              s.jsxs(
                                "tr",
                                {
                                  className: `border-t ${d?.mismatchedRows.indexOf(p + 1) !== void 0 && d.mismatchedRows.indexOf(p + 1) >= 0 ? "bg-amber-50" : ""}`,
                                  children: [
                                    s.jsx("td", {
                                      className: "p-1",
                                      children: s.jsx(S, {
                                        "aria-label": `Date, row ${p + 1}`,
                                        className: "h-8 w-32",
                                        value: c.date,
                                        onChange: (b) =>
                                          v(p, { date: b.target.value }),
                                      }),
                                    }),
                                    s.jsx("td", {
                                      className: "p-1",
                                      children: s.jsx(S, {
                                        "aria-label": `Description, row ${p + 1}`,
                                        className: "h-8",
                                        value: c.description,
                                        onChange: (b) =>
                                          v(p, { description: b.target.value }),
                                      }),
                                    }),
                                    s.jsx("td", {
                                      className: "p-1",
                                      children: s.jsx(
                                        S,
                                        {
                                          "aria-label": `Amount, row ${p + 1}`,
                                          className: `h-8 w-28 text-right ${c.signGuess ? "border-amber-500" : ""}`,
                                          inputMode: "decimal",
                                          defaultValue: c.amount.toFixed(2),
                                          onBlur: (b) => {
                                            const y = Number(
                                              b.target.value.replace(/,/g, ""),
                                            );
                                            Number.isFinite(y) &&
                                              v(p, {
                                                amount:
                                                  Math.round(y * 100) / 100,
                                              });
                                          },
                                        },
                                        `a${p}-${c.amount}`,
                                      ),
                                    }),
                                    s.jsx("td", {
                                      className: "p-2 text-right tabular-nums",
                                      children:
                                        c.balance === null
                                          ? ""
                                          : c.balance.toFixed(2),
                                    }),
                                    s.jsx("td", {
                                      className: "p-1",
                                      children: s.jsx(F, {
                                        size: "icon",
                                        variant: "ghost",
                                        "aria-label": `Remove row ${p + 1}`,
                                        onClick: () =>
                                          k((b) => b.filter((y, C) => C !== p)),
                                        children: s.jsx(le, {
                                          className: "h-4 w-4",
                                        }),
                                      }),
                                    }),
                                  ],
                                },
                                p,
                              ),
                            ),
                          }),
                        ],
                      }),
                    }),
                s.jsxs("p", {
                  className: "text-xs text-muted-foreground",
                  children: [
                    f.length,
                    " row",
                    f.length === 1 ? "" : "s",
                    ". Money in is positive, money out is negative.",
                  ],
                }),
                s.jsxs("div", {
                  className: "flex flex-wrap gap-3",
                  children: [
                    s.jsxs(F, {
                      className: "gap-2",
                      disabled: !f.length,
                      onClick: () => D("csv"),
                      children: [
                        s.jsx(I, { className: "h-4 w-4" }),
                        "Download CSV",
                      ],
                    }),
                    s.jsxs(F, {
                      variant: "outline",
                      className: "gap-2",
                      disabled: !f.length,
                      onClick: () => D("xlsx"),
                      children: [
                        s.jsx(I, { className: "h-4 w-4" }),
                        "Download Excel",
                      ],
                    }),
                  ],
                }),
              ],
            }),
        ],
      }),
      s.jsx(se, { whatIsIt: O.what, howToUse: O.how, tip: O.tip }),
    ],
  });
}
export { ot as default };
//# sourceMappingURL=BankStatementToCsv-DbLffQo0.js.map
