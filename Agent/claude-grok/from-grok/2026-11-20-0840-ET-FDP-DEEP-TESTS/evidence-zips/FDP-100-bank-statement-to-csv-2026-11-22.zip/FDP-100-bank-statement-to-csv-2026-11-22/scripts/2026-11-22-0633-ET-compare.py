# FDP-100: compare the live parse (live/parse/*.json) with testfiles/expected.json. Usage: python3 compare.py
import json, glob, os, re
W='/var/tmp/deep-work/100-bstc/'; E=json.load(open(W+'testfiles/expected.json')); OUT={}
for f in sorted(x for x in glob.glob(W+'live/parse/*.json') if not re.search(r'-(firefox|webkit)\.json$',x)):
    k=os.path.basename(f)[0]
    if k not in E: continue
    s=json.load(open(f)); exp=E[k]['rows']; got=[[r[0],r[1],float(r[2]) if r[2] not in (None,'') else None,float(r[3]) if r[3] else None] for r in s['rows']]
    used=[False]*len(got); res={'expected':len(exp),'parsed':len(got),'exact':0,'wrong_sign':0,'wrong_date':0,'wrong_amount_or_missing':0,'examples':[]}
    for e in exp:
        hit=None
        for i,g in enumerate(got):
            if not used[i] and g[2] is not None and abs(g[2]-e[2])<0.006 and g[0]==e[0]: hit=('exact',i);break
        if not hit:
            for i,g in enumerate(got):
                if not used[i] and g[2] is not None and abs(g[2]+e[2])<0.006 and g[0]==e[0]: hit=('wrong_sign',i);break
        if not hit:
            for i,g in enumerate(got):
                if not used[i] and g[2] is not None and abs(abs(g[2])-abs(e[2]))<0.006: hit=('wrong_date',i);break
        if hit:
            used[hit[1]]=True; res[hit[0]]+=1
            if hit[0]!='exact' and len(res['examples'])<6: res['examples'].append({'kind':hit[0],'expected':e,'got':got[hit[1]]})
        else:
            res['wrong_amount_or_missing']+=1
            if len(res['examples'])<6: res['examples'].append({'kind':'missing/wrong amount','expected':e})
    res['extra']=[g for i,g in enumerate(got) if not used[i]][:6]; res['extra_n']=sum(1 for u in used if not u)
    res['sum_expected']=round(sum(e[2] for e in exp),2); res['sum_parsed']=round(sum(g[2] or 0 for g in got),2)
    res['check']=s['check']; res['detect']=[s['order'],s['num']]
    res['bad_desc']=[g[1] for g in got if re.search(r'Page \d|Member FDIC|through March|Account Number|Total|Kontostand|solde',g[1] or '',re.I)][:4]
    OUT[k]=res
    print(k, f"exp {res['expected']} got {res['parsed']} exact {res['exact']} sign {res['wrong_sign']} date {res['wrong_date']} miss {res['wrong_amount_or_missing']} extra {res['extra_n']} sum {res['sum_expected']}/{res['sum_parsed']} | {s['check'][:90] if s['check'] else None}")
json.dump(OUT,open(W+'analysis/accuracy.json','w'),indent=1,ensure_ascii=False)
