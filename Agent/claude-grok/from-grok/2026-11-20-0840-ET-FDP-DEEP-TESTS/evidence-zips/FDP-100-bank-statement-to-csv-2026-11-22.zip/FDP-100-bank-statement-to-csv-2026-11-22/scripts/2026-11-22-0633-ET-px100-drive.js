// FDP-100: what "Open from Google Drive" does for a guest (popup URL host only, OAuth params redacted); closes it. Never signs in.
const pw = require('playwright');
(async () => { const b = await pw.chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage();
 await p.goto('https://www.freedailypro.com/tool/bank-statement-to-csv', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500);
 const pop = p.waitForEvent('popup', { timeout: 10000 }).catch(() => null); await p.locator('main button', { hasText: 'Open from Google Drive' }).click(); const w = await pop; await p.waitForTimeout(2500);
 const d = p.locator('[role=dialog]'); const dlg = (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 250) : null;
 let u = null; if (w) { await w.waitForLoadState('domcontentloaded').catch(() => { }); u = w.url().replace(/\?.*$/, '?REDACTED'); await w.close(); }
 await p.screenshot({ path: '/workspace/deep/100-bank-statement-to-csv/live/cases/drive-click.png' }); console.log(JSON.stringify({ popup: u, dialog: dlg })); await b.close(); })();
