// FDP-100 Bank Statement to CSV (Professional Tool), guest only. node px100-live.js <mode>
// Never signs in, never types an email or card, never clicks ads. Test files are synthetic (fake data).
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const W = '/var/tmp/deep-work/100-bstc/'; const OUT = W + 'live/'; const TF = W + 'testfiles/'; const TOOL = 'https://www.freedailypro.com/tool/bank-statement-to-csv';
const mode = process.argv[2] || 'parse'; const sfx = process.env.SUF || '';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
fs.mkdirSync(OUT + 'dl', { recursive: true }); fs.mkdirSync(OUT + 'cases', { recursive: true }); fs.mkdirSync(OUT + 'parse', { recursive: true });
(async () => { const b = await (process.env.WK ? pw.webkit : process.env.FF ? pw.firefox : pw.chromium).launch(); const R = { t: now(), mode, tries: [], cases: {} }; let c, p, net = [], allreq = [], dls = [];
 const open = async (opts = {}) => { c = await b.newContext({ viewport: { width: 1366, height: 1200 }, locale: 'en-US', timezoneId: 'America/New_York', acceptDownloads: true, ...opts }); p = await c.newPage(); p.setDefaultTimeout(15000); net = []; allreq = []; dls = [];
  p.on('request', r => { const u = r.url(); allreq.push({ m: r.method(), host: new URL(u).host, path: new URL(u).pathname.slice(0, 60), len: (r.postData() || '').length, leak: /Specimen|Mustermann|Exemple|Payroll|Starbucks|Kontostand|ALEX SAMPLE/i.test(r.postData() || '') });
   if (r.method() === 'POST' && /freedailypro\.com\/api/.test(u) && !/insight\.hit|funnel\.hit/.test(u)) net.push({ t: now(), u: u.slice(0, 70) }); });
  p.on('download', async d => { const n = d.suggestedFilename(); const path = OUT + 'dl/' + mode + sfx + '-' + dls.length + '-' + n; dls.push({ name: n, path }); await d.saveAs(path).catch(() => { }); });
  await p.goto(TOOL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const strip = () => p.locator('main').innerText().then(t => (t.match(/Trial:[^\n]*/) || [''])[0]);
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(200); } };
 const shot = (n, full = true) => p.screenshot({ path: OUT + 'cases/' + n + sfx + '.png', fullPage: full });
 const toasts = async () => (await p.locator('[data-sonner-toast]').allInnerTexts()).map(s => s.replace(/\s*\n\s*/g, ' '));
 const state = async () => p.evaluate(() => { const q = s => document.querySelector(s); const rows = [...document.querySelectorAll('[data-testid=bs-table] tbody tr')].map(tr => { const i = tr.querySelectorAll('input'); const td = tr.querySelectorAll('td'); return [i[0]?.value, i[1]?.value, i[2]?.value, td[3]?.innerText.trim(), tr.className.includes('amber') ? 'MISMATCH' : '', i[2]?.className.includes('border-amber') ? 'SIGNGUESS' : '']; });
  const sec = q('section[aria-live]'); let msgs = []; if (sec) { const cl = sec.cloneNode(true); cl.querySelectorAll('table,button').forEach(e => e.remove()); msgs = cl.innerText.split('\n').map(x => x.trim()).filter(Boolean); }
  return { check: q('[data-testid=bs-check]')?.innerText || null, msgs, rows, order: q('#bs-order')?.selectedOptions[0]?.innerText, num: q('#bs-num')?.selectedOptions[0]?.innerText, textLen: q('#bs-text')?.value.length, text: q('#bs-text')?.value }; });
 const drop = async (f) => { await p.locator('input[type=file]').first().setInputFiles(TF + f); const ts = new Set(); for (let i = 0; i < 24; i++) { for (const t of await toasts()) ts.add(t); await p.waitForTimeout(250); } return [...ts]; };
 const C = async (id, fn) => { try { R.cases[id] = await fn(); } catch (e) { R.cases[id] = { error: String(e).slice(0, 300) }; } console.log(id, JSON.stringify(R.cases[id]).slice(0, 300)); };
 const files = (process.env.FILES || fs.readdirSync(TF).filter(f => f.endsWith('.pdf')).join(',')).split(',');
 if (mode === 'parse') { // P-series: parse every synthetic statement in a fresh guest context; no download (parsing itself is not charged)
  for (const f of files) { await open(); const u0 = await used(); await C('P-' + f, async () => { const t = await drop(f); const s = await state(); fs.writeFileSync(OUT + 'parse/' + f.replace('.pdf', sfx + '.json'), JSON.stringify(s, null, 1)); await shot('P-' + f.replace('.pdf', ''), true); return { toasts: t, used0: u0, used1: await used(), check: s.check, msgs: s.msgs, rows: s.rows.length, order: s.order, num: s.num, posts: net.length, leaks: allreq.filter(x => x.leak).length, hosts: [...new Set(allreq.map(x => x.host))].length }; }); await c.close(); }
 }
 if (mode === 'variants') { // settings the page tells users to use: flip signs (card), Year box (year-end), Number style, amount edit with European input
  await open(); R.start = await used();
  await C('V01-card-flip', async () => { await drop('J-us-card-style.pdf'); const a = await state(); await p.locator('label', { hasText: 'Card statement: flip signs' }).locator('input').check(); await p.waitForTimeout(600); const b2 = await state(); await shot('V01-card-flip'); return { before: { check: a.check, msgs: a.msgs, amts: a.rows.map(r => r[2]) }, flipped: { check: b2.check, msgs: b2.msgs, amts: b2.rows.map(r => r[2]) } }; });
  await p.reload(); await p.waitForTimeout(4000);
  await C('V02-year-end-2025', async () => { await drop('K-us-card-year-end.pdf'); const a = await state(); await p.fill('#bs-year', '2025'); await p.waitForTimeout(600); const b2 = await state(); await shot('V02-year-end'); return { default: a.rows.map(r => r[0]), year2025: b2.rows.map(r => r[0]), check: b2.check }; });
  await p.reload(); await p.waitForTimeout(4000);
  await C('V03-eu-edit', async () => { await drop('F-de-signed-saldo.pdf'); const a = await state(); const i = a.rows.findIndex(r => /Miete/.test(r[1])); const inp = p.locator(`input[aria-label="Amount, row ${i + 1}"]`); const res = { row: i + 1, before: a.rows[i], checkBefore: a.check };
   for (const v of ['-1.200,00', '-1200,00', '-1.200,50', '-1200.00']) { await inp.fill(v); await inp.blur(); await p.waitForTimeout(500); const s = await state(); res[v] = { shown: s.rows[i][2], check: s.check }; }
   await inp.fill('-1.200,00'); await inp.blur(); await p.waitForTimeout(500); await shot('V03-eu-edit'); return res; });
  await p.reload(); await p.waitForTimeout(4000);
  await C('V04-H-numstyle-eu', async () => { await drop('H-fr-debit-credit-space-thousands.pdf'); await p.selectOption('#bs-num', 'eu'); await p.selectOption('#bs-order', 'dmy'); await p.waitForTimeout(500); const s = await state(); return { check: s.check, msgs: s.msgs, rows: s.rows.map(r => r.slice(0, 3).join(' | ')) }; });
  await C('V05-add-row-ui', async () => { const t = await p.locator('main').innerText(); return { addRowButton: /add (a )?row/i.test(t), buttons: (await p.locator('main button').allInnerTexts()).filter(Boolean).slice(0, 40) }; });
 }
 if (mode === 'paste') { // P-series via the paste box (same parser): German 1.200,00, trailing EUR, explicit "+" without keywords, Swiss / Indian groupings
  await open(); R.start = await used();
  const cases = { 'T01-de-1200': 'Alter Kontostand 3.000,00\n02.03.2026 Miete Müller -1.200,00 1.800,00\n03.03.2026 Gutschrift Gehalt +2.450,00 4.250,00\nNeuer Kontostand 4.250,00',
   'T02-de-1200-no-balance': 'Anfangssaldo 3.000,00\n02.03.2026 Miete -1.200,00\n03.03.2026 Rückzahlung Freund 1.200,00\nEndsaldo 3.000,00',
   'T03-trailing-eur': '02.03.2026 Miete -1.200,00 EUR\n03.03.2026 REWE -45,20 €\n04.03.2026 Gehalt +2.450,00 €',
   'T04-plus-sign-no-keyword': '03/02 Zelle Jordan Example +150.00\n03/03 Coffee 4.50\n03/04 Venmo from Sam +20.00',
   'T05-fr-space-thousands': 'Ancien solde 2 345,67\n05/03/2026 Loyer -1 234,56\n06/03/2026 Salaire +2 310,00\nNouveau solde 3 421,11',
   'T06-dd-mon-yy': '15 Dec 25 TESCO STORES 4.50 995.50\n16 Dec 25 SALARY ACME 100.00 1,095.50',
   'T07-iso-slash': '2026/03/05 Konbini -1,200\n2026-03-06 Example Shop -12.30',
   'T08-1.200-no-cents': '02.03.2026 Miete -1.200\n03.03.2026 Kaffee -3,50' };
  for (const [k, v] of Object.entries(cases)) await C(k, async () => { await p.fill('#bs-text', v); await p.waitForTimeout(500); const s = await state(); return { check: s.check, msgs: s.msgs, order: s.order, num: s.num, rows: s.rows.map(r => r.slice(0, 4).join(' | ')) }; });
  await shot('T-paste-last');
 }
 if (mode === 'download') { // D-series: CSV + Excel from L (formula names, non-Latin), count per download, second statement in the same load, reload
  const find = async () => { for (let i = 0; i < +(process.env.TRIES || 20); i++) { await open(); const u = await used(); R.tries.push(u); if (parseInt(u) <= 7) return true; if (i < +(process.env.TRIES || 20) - 1) await c.close(); } return false; };
  if (!(await find())) { R.nofind = true; fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('blocked: all contexts at cap', R.tries.join(' ')); await b.close(); return; } R.start = await used(); R.strip0 = await strip();
  await C('D01-csv', async () => { await drop('L-us-intl-and-formula-names.pdf'); const u0 = await used(); await p.getByRole('button', { name: 'Download CSV' }).click(); await p.waitForTimeout(3500); return { u0, u1: await used(), dialog: await dialog(), posts: net.length, dl: dls.map(d => d.name) }; });
  await esc();
  await C('D02-xlsx-same-load', async () => { const u0 = await used(); await p.getByRole('button', { name: 'Download Excel' }).click(); await p.waitForTimeout(3500); return { u0, u1: await used(), dialog: await dialog(), posts: net.length, dl: dls.map(d => d.name) }; });
  await esc();
  await C('D03-other-statement-same-load', async () => { await drop('F-de-signed-saldo.pdf'); const u0 = await used(); await p.getByRole('button', { name: 'Download CSV' }).click(); await p.waitForTimeout(3000); await drop('A-us-chase-style-checking.pdf'); await p.getByRole('button', { name: 'Download Excel' }).click(); await p.waitForTimeout(3000); return { u0, u1: await used(), dialog: await dialog(), posts: net.length, dl: dls.map(d => d.name) }; });
  await esc();
  await C('D04-reload', async () => { await p.reload(); await p.waitForTimeout(4500); await drop('E-uk-barclays-style.pdf'); const u0 = await used(); await p.getByRole('button', { name: 'Download CSV' }).click(); await p.waitForTimeout(3500); return { u0, u1: await used(), dialog: await dialog(), posts: net.length, dl: dls.map(d => d.name), strip: await strip() }; });
  R.privacy = { hosts: [...new Set(allreq.map(x => x.host))], leaks: allreq.filter(x => x.leak), storage: await p.evaluate(() => ({ ls: Object.keys(localStorage), ss: Object.keys(sessionStorage), lsHit: JSON.stringify(localStorage).match(/Specimen|Barclays|Start balance|Received From/g), ssHit: JSON.stringify(sessionStorage).match(/Specimen|Barclays|Start balance|Received From/g) })) };
 }
 if (mode === 'zero') { // Z-series: what a guest at 0 trial uses sees: full table? download?
  const find0 = async () => { for (let i = 0; i < +(process.env.TRIES || 20); i++) { await open(); const u = await used(); R.tries.push(u); if (/^(\d+)\/(\d+)$/.test(u) && +u.split('/')[0] >= +u.split('/')[1]) return true; await c.close(); } return false; };
  R.found0 = await find0(); R.start = await used(); R.strip0 = await strip();
  await C('Z01-zero-parse', async () => { await drop('A-us-chase-style-checking.pdf'); const s = await state(); await shot('Z01-zero-table'); return { rows: s.rows.length, check: s.check, dialog: await dialog() }; });
  await C('Z02-zero-download', async () => { await p.getByRole('button', { name: 'Download CSV' }).click(); await p.waitForTimeout(3000); const d = await dialog(); await shot('Z02-zero-download', false); return { dialog: d, dl: dls.map(x => x.name), posts: net.length, used: await used() }; });
  await esc();
  await C('Z03-zero-copy-text', async () => { const t = (await state()).text; return { textareaHasFullText: (t || '').length, note: 'statement text sits in the paste box, selectable' }; });
 }
 if (mode === 'mobile') { const dev = pw.devices[process.env.DEV || 'iPhone 13']; await open({ ...dev, viewport: dev.viewport }); R.start = await used();
  await C('M01', async () => { const t = await drop('A-us-chase-style-checking.pdf'); const s = await state(); const sw = await p.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth]); const wide = await p.evaluate(() => [...document.querySelectorAll('main *')].filter(e => e.getBoundingClientRect().right > window.innerWidth + 2).slice(0, 6).map(e => e.tagName + '.' + String(e.className).slice(0, 60) + ' r=' + Math.round(e.getBoundingClientRect().right))); await p.locator('[data-testid=bs-table]').scrollIntoViewIfNeeded().catch(() => { }); await shot('M01-' + (process.env.DEV || 'iPhone 13').replace(/\s/g, '-'), false); return { toasts: t, rows: s.rows.length, check: s.check, sw, wide }; });
 }
 if (mode === 'scan') { await open(); await C('S01-scan', async () => { const t = await drop('M-scan-image-only.pdf'); await shot('S01-scan', false); return { toasts: t, state: (await state()).rows.length }; }); }
 R.end = await used().catch(() => null); fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', JSON.stringify(R.tries), R.start, R.end); await b.close(); })();
