// FDP-100: how pdf.js itself reports the text items of L (does the CJK/Arabic damage come from the PDF or from the tool's line join?)
const pw = require('playwright'); (async () => { const b = await pw.chromium.launch(); const p = await b.newPage(); await p.goto('https://mozilla.github.io/pdf.js/web/viewer.html'); await p.waitForTimeout(3000);
 const buf = require('fs').readFileSync('/var/tmp/deep-work/100-bstc/testfiles/L-us-intl-and-formula-names.pdf').toString('base64');
 const r = await p.evaluate(async (b64) => { const d = await pdfjsLib.getDocument({ data: Uint8Array.from(atob(b64), c => c.charCodeAt(0)) }).promise; const pg = await d.getPage(1); const tc = await pg.getTextContent(); return tc.items.filter(i => /[\u0600-\u06FF\uFE70-\uFEFF\u3040-\u30FF\u4E00-\u9FFF]/.test(i.str)).map(i => [i.str, Math.round(i.transform[4]), Math.round(i.transform[5])]); }, buf);
 console.log(JSON.stringify(r)); await b.close(); })();
