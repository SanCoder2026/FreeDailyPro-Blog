// FDP-100: "Share this tool" for a guest (reads the dialog/menu, sends nothing), keyboard tab count to the drop zone
const pw = require('playwright'); (async () => { const b = await pw.chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); await c.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://www.freedailypro.com' }); const p = await c.newPage();
 await p.goto('https://www.freedailypro.com/tool/bank-statement-to-csv', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); const R = {};
 await p.locator('main button', { hasText: 'Share this tool' }).click(); await p.waitForTimeout(1500);
 const d = p.locator('[role=dialog],[role=menu]'); R.share = (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null;
 await p.screenshot({ path: '/var/tmp/deep-work/100-bstc/live/cases/G06-share.png' }); await p.keyboard.press('Escape');
 await p.goto('https://www.freedailypro.com/tool/bank-statement-to-csv', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); await p.locator('body').click({ position: { x: 5, y: 300 } });
 let n = 0, seen = []; for (; n < 60; n++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return (e.tagName + ' ' + (e.getAttribute('aria-label') || e.innerText || e.id || '').trim().slice(0, 40)) + (e.closest('ins,.adsbygoogle,iframe') ? ' [AD]' : ''); }); seen.push(a); if (/bs-text|TEXTAREA/.test(a)) break; }
 R.tabsToPasteBox = n + 1; R.tabPath = seen; console.log(JSON.stringify(R, null, 1)); require('fs').writeFileSync('/var/tmp/deep-work/100-bstc/live/share-kbd.json', JSON.stringify(R, null, 1)); await b.close(); })();
