Legend: js=pdf.js, pdfium=PDFium (Chrome engine), mu=MuPDF; Np/Mt = pages / pages with their PAGE-n text marker; U = shows the rev2 incremental update; img/ol/frm = images, outline entries, form value kept; qpdfN = qpdf --check exit (0 clean, 3 warnings, 2 error). ✗ = does not open.

| input | input | qpdf | mutool |
|---|---|---|---|
| C00-control-valid.pdf | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0 | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0 | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0 |
| E01-rc4-emptyuser-bad-startxref.pdf | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf3 | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0 | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0 |
| E02-aes256-emptyuser-no-trailer.pdf | js ✗ · pdfium ✗ · mu 5p/0t img1 ol5 frm✗ · qpdf2 | js 5p/0t · pdfium 5p/0t · mu 5p/0t img1 ol5 frm✗ · qpdf2 | js 5p/0t · pdfium 5p/0t · mu 5p/0t img1 ol5 frm✗ · qpdf2 |
| E03-aes256-userpw-bad-startxref.pdf | js ✗ · pdfium ✗ · mu ✗ · qpdf2 | js ✗ · pdfium ✗ · mu ✗ · qpdf2 | js ✗ · pdfium ✗ · mu ✗ · qpdf2 |
| I00-incremental-valid.pdf | js 4p/4t · pdfium 4p/4t · mu 4p/4tU img1 ol5 frm✓ · qpdf0 | js 4p/4t · pdfium 4p/4t · mu 4p/4tU img1 ol5 frm✓ · qpdf0 | js 4p/4t · pdfium 4p/4t · mu 4p/4tU img1 ol5 frm✓ · qpdf0 |
| I01-incremental-bad-offsets.pdf | js 4p/4t · pdfium 4p/4t · mu 4p/4tU img1 ol5 frm✓ · qpdf3 | js 4p/4t · pdfium 4p/4t · mu 4p/4tU img1 ol5 frm✓ · qpdf0 | js 4p/4t · pdfium 4p/4t · mu 4p/4tU img1 ol5 frm✓ · qpdf0 |
| I02-incremental-interrupted.pdf | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0 | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0 | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0 |
| I03-incremental-bad-prev.pdf | js 4p/4t · pdfium 4p/4t · mu 4p/4tU img1 ol5 frm✓ · qpdf3 | js 4p/4t · pdfium 4p/4t · mu 4p/4tU img1 ol5 frm✓ · qpdf0 | js 4p/4t · pdfium 4p/4t · mu 4p/4tU img1 ol5 frm✓ · qpdf0 |
| J01-junk-512-before-header.pdf | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0 | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0 | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0 |
| J02-junk-2048-before-header.pdf | js 5p/5t · pdfium ✗ · mu 5p/5t img1 ol5 frm✓ · qpdf3 | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0 | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0 |
| N01-docx-renamed.pdf | js ✗ · pdfium ✗ · mu ✗ · qpdf2 | no output | no output |
| N02-jpeg-renamed.pdf | js ✗ · pdfium ✗ · mu 1p/0t img0 ol0 frm✗ · qpdf2 | no output | no output |
| N03-html-error-page.pdf | js ✗ · pdfium ✗ · mu 1p/0t img0 ol1 frm✗ · qpdf2 | no output | no output |
| N04-plain-text.pdf | js ✗ · pdfium ✗ · mu ✗ · qpdf2 | no output | no output |
| O01-broken-object-stream.pdf | js ✗ · pdfium ✗ · mu 0p/0t img0 ol0 frm✗ · qpdf2 | no output | js ✗ · pdfium ✗ · mu 0p/0t img0 ol0 frm✗ · qpdf2 |
| P01-pagetree-missing-kid.pdf | js 3p/2t · pdfium ✗ · mu 5p/4t img1 ol5 frm✗ · qpdf0 | js 4p/4t · pdfium 4p/4t · mu 4p/4t img1 ol5 frm✗ · qpdf0 | js 3p/2t · pdfium ✗ · mu 5p/4t img1 ol5 frm✗ · qpdf0 |
| P02-catalog-pages-missing.pdf | js ✗ · pdfium ✗ · mu 0p/0t img0 ol5 frm✗ · qpdf2 | no output | js ✗ · pdfium ✗ · mu 0p/0t img0 ol5 frm✗ · qpdf2 |
| T01-truncated-after-p3.pdf | js ✗ · pdfium ✗ · mu 5p/3t img1 ol5 frm✓ · qpdf3 | js 5p/2t · pdfium 5p/2t · mu 5p/2t img1 ol5 frm✓ · qpdf3 | js 5p/3t · pdfium 5p/3t · mu 5p/3t img1 ol5 frm✓ · qpdf0 |
| T02-linearized-cut-60pct.pdf | js ✗ · pdfium ✗ · mu 0p/0t img0 ol0 frm✗ · qpdf2 | no output | js ✗ · pdfium ✗ · mu 0p/0t img0 ol0 frm✗ · qpdf2 |
| X01-bad-startxref.pdf | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf3 | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0 | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0 |
| X02-bad-xref-offsets.pdf | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf3 | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0 | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0 |
| X03-missing-trailer.pdf | js ✗ · pdfium ✗ · mu 5p/5t img1 ol5 frm✓ · qpdf3 | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf3 | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0 |
| X04-no-xref-trailer-eof.pdf | js ✗ · pdfium ✗ · mu 5p/5t img1 ol5 frm✓ · qpdf3 | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf3 | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0 |
| Z01-zero-byte.pdf | empty | no output | no output |
| base.pdf | js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0 | no output | no output |
