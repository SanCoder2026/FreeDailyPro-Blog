import { r as a, j as e } from "./vendor-react-D01g8YgM.js";
import { T as S, F as C, P as $, D as A, R as I } from "./ToolPage-B4roIUf_.js";
import { z as O, B as f, f as v } from "./index-DagluEtV.js";
import { T as W } from "./ToolInfoSection-C0Lbi6Qb.js";
import { b as E, R as j } from "./operations-BlL6iX51.js";
import "./useUploadApi-Cwp1vwlT.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-CL8JsD0s.js";
import "./share-2-B34wyobX.js";
import "./copy-CQptMDp5.js";
import "./workflowCta-oWYKzOWD.js";
import "./UsageAndUpgradeStrip-BiAdGTIF.js";
import "./access-BSSUf40u.js";
import "./useAdminAccess-CYp3AlSq.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CgocG3qD.js";
import "./map-pin-DvVDRebE.js";
import "./FaqSection-DsOLPaJ0.js";
import "./ToolVideoEmbed-CZwBIyFf.js";
import "./GuideLinks-BVE0aHrc.js";
import "./blog-BPnsEI_q.js";
import "./info-56I4OKVq.js";
import "./productCards-CUOqxId0.js";
import "./layers-BVDCe9zx.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-DmEVOuX4.js";
import "./chevron-up-B0wsCoBg.js";
import "./pdfFonts-CIqHAJiw.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./pdfMetadata-CcxIhQF2.js";
import "./pageView-BQIwVYOi.js";
import "./formAppearance-TraefmEd.js";
import "./drawTextAnywhere-Dl7l_xfJ.js";
import "./ocrText-C_9cxcFa.js";
import "./ocrImage-DAAOwTV-.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./utils-s8ucLyj8.js";
import "./imageRecompress-eXQFDUm-.js";
import "./formatFileSize-B-JRDfN5.js";
import "./plural-FIChqbp4.js";
import "./textDiff-DxE9AzvO.js";
import "./utils-BvcV7ep8.js";
import "./decode-CE2kW_I3.js";
import "./formFill-xgtRnF-K.js";
import "./redactSearch-DQpyyh_t.js";
import "./nameDetect-DvHCRM0m.js";
const h = {
  what: "Attempts to fix a PDF that won't open correctly or shows as corrupted — by parsing it in a lenient recovery mode that tolerates the kind of broken internal structure that trips up strict PDF readers, then rebuilding it as a clean file.",
  how: `Upload the PDF that's giving you trouble and download the repaired version. A "What was fixed" line says what was done, for example that the cross-reference table (the file's index) was rebuilt and how many pages were recovered. If the file can't be recovered at all, you'll get a clear message rather than a broken download. If the file isn't a PDF at all, the message says what it looks like (plain text, a picture, a Word file) so you can open it in the right program.`,
  tip: "This fixes structural corruption — broken cross-reference tables, malformed objects, the kind of damage that happens from an interrupted save or a bad transfer. A file that was cut off part-way (an interrupted download) is rebuilt from the pages that were saved before the cut; the pages after it were never written and cannot be recovered.",
};
function We() {
  const [s, p] = a.useState(null),
    [y, x] = a.useState(!1),
    [o, n] = a.useState(null),
    [i, P] = a.useState(0),
    [l, g] = a.useState(null),
    [F, d] = a.useState(null),
    [N, c] = a.useState(!1),
    [D, m] = a.useState(!1),
    { localizedHref: w } = O(),
    R = a.useCallback((t) => {
      (p(t[0] || null), n(null), m(!1), g(null), d(null), c(!1));
    }, []),
    T = async () => {
      if (s) {
        (x(!0), n(null), m(!1));
        try {
          (d(null), c(!1));
          const {
            blob: t,
            pageCount: r,
            totalPages: u,
            partial: b,
            summary: k,
          } = await E(s);
          (n(t),
            P(r),
            g({ totalPages: u, partial: b, summary: k }),
            v.success(
              b
                ? `Recovered ${u ? `${r} of ${u}` : r} page${r === 1 ? "" : "s"} — the file was cut off`
                : `Recovered ${r} page${r === 1 ? "" : "s"}`,
            ));
        } catch (t) {
          (console.error("PDF repair failed:", t), m(!0));
          const r =
            t instanceof j
              ? t.message
              : "This PDF couldn't be repaired — the damage may be too severe to recover from.";
          (d(r), c(t instanceof j && t.kind === "not-pdf"), v.error(r));
        } finally {
          x(!1);
        }
      }
    };
  return e.jsxs(S, {
    children: [
      e.jsxs("div", {
        className:
          "mb-4 p-3 rounded-lg border bg-muted/50 text-xs text-muted-foreground flex flex-wrap gap-x-4 gap-y-1",
        children: [
          e.jsx("span", {
            children: "🔒 Runs entirely in your browser — never uploaded",
          }),
          e.jsx("span", {
            children:
              "🛠️ Fixes structural damage; can't recover content that was never actually saved",
          }),
        ],
      }),
      s
        ? e.jsxs("div", {
            className: "space-y-4",
            children: [
              e.jsx("div", {
                className: "p-4 rounded-lg border bg-card",
                children: e.jsx("p", {
                  className: "text-sm font-medium",
                  children: s.name,
                }),
              }),
              o &&
                e.jsxs("p", {
                  className: "text-sm font-medium",
                  "data-testid": "repair-fixed",
                  children: ["What was fixed: ", l?.summary, "."],
                }),
              o &&
                e.jsxs("p", {
                  className: "text-sm text-muted-foreground",
                  children: [
                    l?.partial
                      ? e.jsxs(e.Fragment, {
                          children: [
                            "Recovered ",
                            l.totalPages ? `${i} of ${l.totalPages}` : i,
                            " page",
                            i === 1 ? "" : "s",
                            ". The file was cut off (an interrupted download or attachment), so the pages after the cut are missing. ",
                          ],
                        })
                      : e.jsxs(e.Fragment, {
                          children: [
                            "Recovered ",
                            i,
                            " page",
                            i === 1 ? "" : "s",
                            ". ",
                          ],
                        }),
                    "Worth checking the repaired file's content matches what you expect — recovery is best-effort, not guaranteed complete.",
                  ],
                }),
              D &&
                e.jsxs("div", {
                  className:
                    "p-3 rounded-lg border bg-muted/30 text-sm space-y-2",
                  children: [
                    e.jsx("p", {
                      className: "text-muted-foreground",
                      children: F ?? "This file couldn't be recovered.",
                    }),
                    !N &&
                      e.jsxs(e.Fragment, {
                        children: [
                          e.jsx("p", {
                            className: "text-muted-foreground",
                            children:
                              "Other tools read files differently and can sometimes still pull out some content:",
                          }),
                          e.jsxs("div", {
                            className: "flex flex-wrap gap-2",
                            children: [
                              e.jsx("a", {
                                href: w("/tool/pdf-to-word"),
                                className:
                                  "text-primary hover:underline text-sm",
                                children: "Try PDF to Word →",
                              }),
                              e.jsx("a", {
                                href: w("/tool/pdf-to-jpg"),
                                className:
                                  "text-primary hover:underline text-sm",
                                children: "Try PDF to JPG →",
                              }),
                            ],
                          }),
                        ],
                      }),
                  ],
                }),
              e.jsx("div", {
                className: "flex gap-3",
                children: y
                  ? e.jsx($, { message: "Attempting recovery..." })
                  : o
                    ? e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(A, { blob: o, fileName: `repaired_${s.name}` }),
                          e.jsx(f, {
                            variant: "outline",
                            onClick: () => {
                              (p(null), n(null));
                            },
                            children: "New",
                          }),
                        ],
                      })
                    : e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(f, { onClick: T, children: "Attempt Repair" }),
                          e.jsx(f, {
                            variant: "ghost",
                            onClick: () => p(null),
                            children: "Reset",
                          }),
                        ],
                      }),
              }),
              o && e.jsx(I, { blob: o, mimeType: "application/pdf" }),
            ],
          })
        : e.jsx(C, {
            gateAtDownload: !0,
            accept: ".pdf",
            onFiles: R,
            acceptDamagedPdf: !0,
            label: "Drop a damaged PDF",
            description: "Attempt to recover and rebuild it as a clean file",
          }),
      e.jsx(W, { whatIsIt: h.what, howToUse: h.how, tip: h.tip }),
    ],
  });
}
export { We as default };
//# sourceMappingURL=RepairPdf-7jnTbIWV.js.map
