const t="This file isn't a readable PDF";function o(e){return`“${e}” could not be opened as a PDF. It may be damaged, cut short, or not a PDF at all. Try Repair PDF, or choose a different file.`}function s(e){const a=e;return a?.name==="PasswordException"||/password|encrypted/i.test(a?.message??"")}export{t as N,s as i,o as n};
//# sourceMappingURL=pdfLoadError-Bi-AAFkg.js.map
