import {
  v as j,
  P as a,
  a as y,
  f as x,
  c as m,
  w as B,
  x as R,
  k as N,
  b,
  y as O,
} from "./index-BRvxULIc.js";
import { sniffNotPdf as q } from "./repairDiagnose-Csq-PeZE.js";
import "./index-CnXdQaNG.js";
import "./vendor-react-D01g8YgM.js";
import "./index-DMQTJy3b.js";
const D = (n) => Uint8Array.from(Array.from(n).map((r) => r.charCodeAt(0)));
function M(n, r, i = 0) {
  t: for (let t = i; t <= n.length - r.length; t++) {
    for (let o = 0; o < r.length; o++) if (n[t + o] !== r[o]) continue t;
    return t;
  }
  return -1;
}
function k(n, r, i = n.length) {
  t: for (let t = Math.min(i, n.length) - r.length; t >= 0; t--) {
    for (let o = 0; o < r.length; o++) if (n[t + o] !== r[o]) continue t;
    return t;
  }
  return -1;
}
const F = (n, r) =>
  n instanceof b && n.get(a.of("Type"))?.asString() === `/${r}`;
function I(n, r) {
  const i = new Set(),
    t = [r];
  let o = 0;
  for (; t.length && o++ < 2e4;) {
    const e = t.pop();
    if (e instanceof m) {
      const s = e.toString();
      if (i.has(s)) continue;
      i.add(s);
      const u = n.lookup(e);
      if (!u) return !1;
      t.push(u);
    } else
      e instanceof b
        ? e.entries().forEach(([s, u]) => {
            s !== a.of("Parent") && s !== a.of("P") && t.push(u);
          })
        : e instanceof x
          ? e.asArray().forEach((s) => t.push(s))
          : e instanceof O && t.push(e.dict);
  }
  return !0;
}
function K(n, r, i) {
  let t = r;
  for (let o = 0; t && o < 30; o++) {
    const e = t.get(a.of(i));
    if (e) return e;
    const s = t.get(a.of("Parent"));
    if (((t = s instanceof m ? n.lookup(s) : s), t && !(t instanceof b))) break;
  }
}
async function J(n) {
  const r = M(n, D("%PDF-"));
  if (r < 0) throw new Error("no-header");
  const i = n.subarray(r),
    t = D("endobj");
  let o = k(i, t) + t.length;
  if (o < t.length) throw new Error("no-objects");
  let e = null;
  for (let c = 0; c < 8 && o > t.length; c++)
    try {
      e = await j
        .forBytesWithOptions(i.subarray(0, o), 100, !1)
        .parseDocument();
      break;
    } catch {
      o = k(i, t, o - 1) + t.length;
    }
  if (!e) throw new Error("unparseable");
  const s = [];
  let u = null;
  const d = new Map();
  (e.enumerateIndirectObjects().forEach(([c, f]) => {
    if (F(f, "Page")) s.push({ ref: c, dict: f });
    else if (F(f, "Pages")) {
      const l = f,
        g = l.get(a.of("Count"));
      (g instanceof y && !l.get(a.of("Parent")) && (u = g.asNumber()),
        l
          .lookupMaybe(a.of("Kids"), x)
          ?.asArray()
          .forEach((P, C) => {
            P instanceof m && !d.has(P.toString()) && d.set(P.toString(), C);
          }));
    }
  }),
    s.sort((c, f) => {
      const l = d.get(c.ref.toString()),
        g = d.get(f.ref.toString());
      return l !== void 0 && g !== void 0 && l !== g
        ? l - g
        : c.ref.objectNumber - f.ref.objectNumber;
    }));
  const h = [];
  for (const { ref: c, dict: f } of s) {
    for (const l of ["MediaBox", "Resources", "CropBox", "Rotate"]) {
      const g = K(e, f, l);
      g && !f.has(a.of(l)) && f.set(a.of(l), g);
    }
    f.has(a.of("MediaBox")) && I(e, f) && h.push(c);
  }
  if (h.length === 0) throw new Error("no-pages");
  const p = B.withContext(e),
    w = e.register(p);
  (h.forEach((c) => e.lookup(c).set(a.of("Parent"), w)),
    p.set(a.of("Kids"), e.obj(h)),
    p.set(a.of("Count"), y.of(h.length)));
  const S = e.register(R.withContextAndPages(e, w));
  e.trailerInfo.Root = S;
  const v = N,
    E = await new v(e, !0, !1).save({ useObjectStreams: !1 }),
    A = u !== null && u >= h.length ? u : null;
  return { bytes: E, recovered: h.length, total: A };
}
export { J as recoverPagesByScan, q as sniffNotPdf };
//# sourceMappingURL=pdfRecover-PVH02fpy.js.map
