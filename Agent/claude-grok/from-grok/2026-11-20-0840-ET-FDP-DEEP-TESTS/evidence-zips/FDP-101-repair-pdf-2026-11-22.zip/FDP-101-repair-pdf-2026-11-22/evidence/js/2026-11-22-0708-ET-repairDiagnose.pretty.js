const h = (t) => Array.from(t).map((e) => e.charCodeAt(0)),
  n = (t, e, s = 0) => e.every((r, i) => t[s + i] === r),
  p = (t) => new TextDecoder("latin1").decode(t),
  g = "unknown",
  x = "empty";
function P(t) {
  if (t.length === 0) return !1;
  let e = 0;
  for (let s = 0; s < t.length; s++) {
    const r = t[s];
    if (r === 0) return !1;
    r < 32 && r !== 9 && r !== 10 && r !== 13 && r !== 12 && e++;
  }
  return e / t.length < 0.02;
}
function w(t) {
  const e = t.subarray(0, 1024);
  if (p(e).includes("%PDF-")) return null;
  if (e.length === 0) return x;
  if (n(e, [80, 75, 3, 4])) return "a Word, Excel, PowerPoint or ZIP file";
  if (n(e, [255, 216, 255])) return "a JPEG picture";
  if (n(e, [137, 80, 78, 71])) return "a PNG picture";
  if (n(e, [208, 207, 17, 224])) return "an older Word or Excel file";
  if (n(e, [71, 73, 70, 56])) return "a GIF picture";
  if (n(e, h("RIFF")) && n(e, h("WEBP"), 8)) return "a WebP picture";
  if (n(e, [73, 73, 42, 0]) || n(e, [77, 77, 0, 42])) return "a TIFF picture";
  if (n(e, h("{\\rtf"))) return "a Rich Text (RTF) document";
  if (n(e, h("%!PS"))) return "a PostScript file";
  if (P(e)) {
    const s = p(e)
      .replace(/^﻿|^\xEF\xBB\xBF/, "")
      .trimStart()
      .toLowerCase();
    return s.startsWith("<!doctype html") || s.startsWith("<html")
      ? "a web page (HTML)"
      : s.startsWith("<?xml") || s.startsWith("<svg")
        ? "an XML or SVG file"
        : "plain text";
  }
  return g;
}
function v(t) {
  return t === x
    ? "This file is empty (0 bytes), so there is nothing to repair. Try downloading or attaching it again."
    : t === g
      ? "This file isn't a PDF, and we couldn't tell what kind of file it is. Open it in the program it came from, or use a converter such as Word to PDF."
      : `This file isn't a PDF (it looks like ${t}). Open it in the matching program, or use a converter such as Word to PDF.`;
}
function m(t, e, s) {
  let r = e + 4,
    i = 0;
  for (let l = 0; l < 2e3; l++) {
    const a = /^\s*(\d+)\s+(\d+)\s*\r?\n?/.exec(t.slice(r, r + 40));
    if (!a)
      return (
        t
          .slice(r, r + 40)
          .trimStart()
          .startsWith("trailer") && i > 0
      );
    const f = Number(a[1]),
      d = Number(a[2]);
    r += a[0].length;
    for (let o = 0; o < d; o++) {
      const c = /^(\d{10}) (\d{5}) ([nf])/.exec(t.slice(r, r + 20));
      if (!c) return !1;
      if (c[3] === "n" && i < 5e3) {
        const u = Number(c[1]) + s,
          b = t.slice(u, u + 30);
        if (!new RegExp(`^\\s*${f + o}\\s+${Number(c[2])}\\s+obj`).test(b))
          return !1;
        i++;
      }
      r += 20;
    }
  }
  return !0;
}
function $(t) {
  const e = p(t),
    s = e.indexOf("%PDF-"),
    r = s > 0 ? s : 0,
    l = !e.slice(Math.max(0, e.length - 2048)).includes("%%EOF"),
    a = e.lastIndexOf("startxref");
  let f = "missing";
  if (a >= 0) {
    const d = /^startxref\s+(\d+)/.exec(e.slice(a, a + 40)),
      o = d ? Number(d[1]) + r : -1;
    if (o < 0 || o >= e.length) f = "bad";
    else {
      const c = e.slice(o, o + 40).trimStart();
      if (c.startsWith("xref")) {
        const u = e.indexOf("xref", o);
        f = u >= 0 && (m(e, u, 0) || (r > 0 && m(e, u, r))) ? "ok" : "bad";
      } else /^\d+\s+\d+\s+obj/.test(c) ? (f = "stream") : (f = "bad");
    }
  }
  return { junkBeforeHeader: r, missingEof: l, xref: f };
}
function F(t) {
  const e = [],
    s = t.diagnosis;
  if (
    ((s.xref === "bad" || s.xref === "missing") &&
      e.push("Rebuilt the cross-reference table"),
    s.junkBeforeHeader > 0 &&
      e.push(
        `Removed ${s.junkBeforeHeader} byte${s.junkBeforeHeader === 1 ? "" : "s"} of data in front of the PDF header`,
      ),
    s.missingEof && e.push("Added the missing end-of-file marker"),
    t.method === "scan" &&
      (e.push("Rebuilt the page list from the pages that were saved"),
      t.total !== null && t.total > t.recovered))
  ) {
    const r = t.total - t.recovered;
    e.push(
      `dropped ${r} page${r === 1 ? "" : "s"} that ${r === 1 ? "was" : "were"} cut off or missing parts`,
    );
  }
  return e;
}
function E(t) {
  const e = F(t),
    s =
      t.total !== null && t.total > t.recovered
        ? `recovered ${t.recovered} of ${t.total} pages`
        : `recovered ${t.recovered} page${t.recovered === 1 ? "" : "s"}`;
  return e.length === 0
    ? `No structural damage was found; the file was rewritten as a clean copy (${t.recovered} page${t.recovered === 1 ? "" : "s"})`
    : `${e.map((i, l) => (l === 0 ? i : i.charAt(0).toLowerCase() + i.slice(1))).join("; ")}; ${s}`;
}
export {
  x as EMPTY_FILE_TYPE,
  g as UNKNOWN_FILE_TYPE,
  $ as diagnoseStructure,
  v as notPdfMessage,
  F as repairFixes,
  E as repairSummary,
  w as sniffNotPdf,
};
//# sourceMappingURL=repairDiagnose-Csq-PeZE.js.map
