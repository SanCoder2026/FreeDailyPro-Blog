# Opens PDFs in MuPDF (PyMuPDF) and PDFium (pypdfium2), runs qpdf --check, and measures what survived.
# usage: check101.py out.json file...   (env PW = password)
import sys, json, re, subprocess, os, warnings
import fitz, pypdfium2 as pdfium
fitz.TOOLS.mupdf_display_errors(False)
PW=os.environ.get('PW') or None
def mu(f):
    r={}; fitz.TOOLS.reset_mupdf_warnings()
    try:
        d=fitz.open(f, filetype='pdf')
        if d.needs_pass: r['needs_pass']=True; d.authenticate(PW or '')
        r['repaired_on_open']=bool(d.is_repaired); r['pages']=d.page_count; mk=[]; im=0; ln=0
        for p in d:
            s=p.get_text(); m=re.search(r'PAGE-\d-(TEXT|UPDATED)',s); mk.append(m.group(0) if m else '-')
            im+=len(p.get_images()); ln+=len([l for l in p.get_links() if l.get('uri')])
        r['markers']=','.join(mk); r['images']=im; r['uri_links']=ln; r['outline']=len(d.get_toc())
        fl=[]
        for p in d:
            for w in p.widgets() or []: fl.append(f'{w.field_name}={w.field_value}')
        r['fields']=';'.join(fl)[:120]; r['ok']=True
        r['warn']=fitz.TOOLS.mupdf_warnings()[:160].replace('\n',' | ')
    except Exception as e: r['ok']=False; r['err']=str(e)[:100]
    return r
def pd(f):
    r={}
    try:
        d=pdfium.PdfDocument(f, password=PW); r['pages']=len(d); mk=[]
        for i in range(len(d)):
            s=d[i].get_textpage().get_text_range(); m=re.search(r'PAGE-\d-(TEXT|UPDATED)',s); mk.append(m.group(0) if m else '-')
            d[i].render(scale=0.3)
        r['markers']=','.join(mk); r['ok']=True
    except Exception as e: r['ok']=False; r['err']=str(e)[:100]
    return r
def qc(f):
    a=['qpdf','--check']+(['--password='+PW] if PW else [])+[f]
    p=subprocess.run(a,capture_output=True,text=True)
    out=(p.stdout+p.stderr); w=[l for l in out.splitlines() if 'WARNING' in l or 'error' in l.lower()]
    return {'exit':p.returncode,'warnings':len(w),'first':(w[0][-120:] if w else '')}
res={}
for f in sys.argv[2:]:
    n=os.path.basename(f)
    if os.path.getsize(f)==0: res[n]={'size':0}; continue
    res[n]={'size':os.path.getsize(f),'mupdf':mu(f),'pdfium':pd(f),'qpdf_check':qc(f)}
    print(n, json.dumps(res[n])[:400])
json.dump(res,open(sys.argv[1],'w'),indent=1)
