import json,re
R={}
for f in ['corpus-A','corpus-B','corpus-C','corpus-D','pw-pw']:
    try: R.update(json.load(open(f'/var/tmp/deep-work/101-repair/live/{f}.json'))['cases'])
    except FileNotFoundError: pass
R['E03-aes256-userpw-bad-startxref.pdf (password test101)']=R.pop('E03-with-password')
cmp={}
for l in open('/var/tmp/deep-work/101-repair/analysis/compare-all.md'):
    if l.startswith('| ') and '.pdf' in l:
        c=[x.strip() for x in l.strip().strip('|').split('|')]; cmp[c[0]]=c
D={'C00':'valid control','E01':'RC4-128, empty user pw, startxref → 999','E02':'AES-256, empty user pw, trailer dict removed','E03':'AES-256, user pw test101, startxref → 999',
'I00':'valid incremental update (p1 replaced, p5 removed, new Title)','I01':'update xref offsets +7','I02':'update objects written, no xref/trailer (interrupted save)','I03':'update /Prev +333',
'J01':'512 random bytes before %PDF-','J02':'2048 random bytes before %PDF-','N01':'DOCX/ZIP renamed','N02':'JPEG renamed','N03':'HTML 403 page renamed','N04':'plain text renamed',
'O01':'object streams; 40 bytes randomised in the 23-object ObjStm','P01':'Kids: 19 0 R → 99 0 R (missing)','P02':'Catalog /Pages → 98 0 R (missing)',
'T01':'cut after p3 content (p4–p5 content, AcroForm, xref, trailer lost)','T02':'linearized copy cut at 60 %','T03':'cut at 40 % (no complete page)','T04':'qpdf-ordered copy cut at 70 % (p1–p2 complete)',
'X01':'startxref → 12345','X02':'40 bytes inserted after header (all offsets shifted)','X03':'trailer dict removed','X04':'xref, trailer, startxref, %%EOF removed','Z01':'0 bytes'}
EXP={'C00':'5/5 everything','E01':'5/5','E02':'content needs key; honest failure or warning','E03':'5/5 after password','I00':'4 pages rev2 (as viewers)','I01':'4 pages rev2 (as viewers)','I02':'5 pages rev1 (last saved, as viewers)','I03':'4 pages rev2 (as viewers)','J01':'5/5','J02':'5/5','N01':'named, refused','N02':'named, refused','N03':'named, refused','N04':'named, refused','O01':'what survives, flagged partial','P01':'4–5 pages, opens everywhere, says page list rebuilt','P02':'5/5 via scan','T01':'3 of 5, cut off','T02':'what survives, cut off','T03':'honest failure','T04':'2–3 of 5, cut off','X01':'5/5','X02':'5/5','X03':'5/5','X04':'5/5','Z01':'empty message'}
V={'T01':'**FAIL P1 #1**','T04':'**FAIL P1 #1**','P01':'**FAIL P1 #2**','I02':'**FAIL P2 #3**','E02':'**FAIL P2 #4**','J02':'**FAIL P2 #5**','E01':'PASS (summary P3 #8)','O01':'PASS (better than baselines; P3 #8)','P02':'PASS (better than baselines)','T02':'PASS (better than baselines)','I03':'PASS (summary says no damage)','N02':'PASS (P3 #8 converter)','N03':'PASS (P3 #8 converter)'}
out=['Sent: @@TS@@ ET','','# FDP-101 repair-pdf: test cases','','Corpus: `make101.py` (base.pdf) + `make101b.py` (damage) + T03/T04 (scripts/README). Live: `node px101-live.js corpus` (and `pw` for E03), Chromium guest, 2026-11-22 ET. Viewers: `check101.py` (MuPDF, PDFium) + `pdfjs-check.mjs`. Cell legend in findings/recovery-matrix.md (Np/Mt = pages / pages with their text marker; ✗ = does not open).','',
'| ID | Damage | Expected | FDP message (toast · What was fixed) | FDP output (js · pdfium · MuPDF) | qpdf | mutool | Verdict |','|---|---|---|---|---|---|---|---|']
for k in sorted(R):
    v=R[k]; i=k[:3]; f=k.split(' ')[0]; pn=v.get('panel') or {}
    msg=' / '.join(v.get('toasts') or []) or 'password dialog' 
    if pn.get('fixed'): msg+=' · '+pn['fixed'].replace('What was fixed: ','')
    c=cmp.get(f,['']*5); c+=['']*5
    if 'password' in k: c=[f,'', 'js 5p/5t · pdfium 5p/5t · mu 5p/5t img1 ol5 frm✓ · qpdf0','(with password) 5p/5t','(with password) 5p/5t']
    out.append(f"| {i} | {D.get(i,'')} | {EXP.get(i,'')} | {msg[:260]} | {c[2]} | {c[3]} | {c[4]} | {V.get(i,'PASS')} |")
out+=['','Downloads (D-series, context with uses, `TRIES=45 node px101-live.js download`): D01 T01 Download 0→1 (repaired_T01-truncated-after-p3.pdf, = blob); D02 same result again 1→1; D03 X03 1→2; D04 repair X01 without download 2→2.','',
'Zero uses (Z-series): Z01 repair T01 at 10/10 → full sentence; Z02 preview iframes present ("5 pages"); Z03 Download → cap dialog, no file.','',
'Links (L-series, `px101-links.js`): T02 on merge, compress, split, add-page-numbers, pdf-to-word → toast + Repair PDF → /tool/repair-pdf (en); rotate-pdf, pdf-to-jpg → own message, no link; es/merge, de/compress, fr/pdf-to-word → English page; T03 on pdf-to-word → "Try the Repair PDF tool" (loop), pdf-to-jpg → "couldn\'t be read"; X03 on merge → accepted, no toast.','',
'Privacy (PV01): file ZZ-PRIVNAME-Quokka7.pdf (copy of X01): 107 requests, 0 containing the name or "Alex Sample"/"PAGE-1-TEXT"; GA only page_view; storage keys fdp-*, google_* only; IndexedDB none.','',
'Cross-browser: Firefox (T01, P01, T04) and WebKit (T01, P01): same messages, outputs byte-identical to Chromium.']
open('/var/tmp/deep-work/101-repair/docs/test-cases.md','w').write('\n'.join(out)+'\n'); print(len(out))
