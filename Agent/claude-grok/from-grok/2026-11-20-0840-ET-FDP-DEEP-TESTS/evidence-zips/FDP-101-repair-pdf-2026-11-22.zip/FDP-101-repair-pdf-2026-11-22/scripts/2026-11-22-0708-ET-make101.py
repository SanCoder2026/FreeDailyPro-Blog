# FDP-101 step 1: base PDFs (made-up content). 5 pages, text markers, a JPEG on p2, AcroForm on p3, outline, a link.
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.lib.colors import HexColor
from PIL import Image, ImageDraw
import io, os
T='/var/tmp/deep-work/101-repair/testfiles/'
img=Image.new('RGB',(400,240),'#2a6f97'); d=ImageDraw.Draw(img); d.rectangle((40,40,360,200),fill='#f4a261'); d.text((60,100),'IMAGE-P2 synthetic',fill='black'); img.save('/tmp/p2.jpg',quality=85)
c=canvas.Canvas(T+'base.pdf',pagesize=letter,pageCompression=1)
c.setTitle('FDP-101 base (synthetic)'); c.setAuthor('Test Author')
for n in range(1,6):
    c.bookmarkPage(f'p{n}'); c.addOutlineEntry(f'Chapter {n}',f'p{n}',level=0)
    c.setFont('Helvetica-Bold',20); c.drawString(72,700,f'PAGE-{n}-TEXT Repair corpus page {n} of 5')
    c.setFont('Helvetica',11)
    for i in range(30): c.drawString(72,660-i*18,f'Line {i+1} on page {n}: the quick brown fox jumps over the lazy dog {n*100+i}')
    if n==1: c.linkURL('https://example.invalid/fdp101',(72,690,400,720),relative=0)
    if n==2: c.drawImage('/tmp/p2.jpg',150,120,width=300,height=180)
    if n==3:
        f=c.acroForm; f.textfield(name='full_name',value='Alex Sample',x=300,y=120,width=200,height=20); f.checkbox(name='agree',checked=True,x=300,y=90,size=16)
    c.showPage()
c.save()
print(os.path.getsize(T+'base.pdf'))
