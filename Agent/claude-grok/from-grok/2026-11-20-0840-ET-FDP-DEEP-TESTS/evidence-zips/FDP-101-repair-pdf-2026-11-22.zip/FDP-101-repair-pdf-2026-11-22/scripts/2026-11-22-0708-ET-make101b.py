# FDP-101 step 2: damaged variants of base.pdf (all made-up content). Each file name says what was broken.
import os, re, subprocess, random, zipfile, io
T='/var/tmp/deep-work/101-repair/testfiles/'
B=open(T+'base.pdf','rb').read(); random.seed(101)
def w(n,b): open(T+n,'wb').write(b); print(n,len(b))
sx=lambda b: int(re.search(rb'startxref\s+(\d+)',b[b.rfind(b'startxref'):]).group(1))
# truncation: after page 3's content stream (pages 4-5 content, AcroForm, xref, trailer lost)
w('T01-truncated-after-p3.pdf', B[:B.index(b'34 0 obj')])
# linearized copy cut at 60 % (first-page-first layout, like a web-optimised download)
subprocess.run(['qpdf','--linearize',T+'base.pdf',T+'_lin.pdf'],check=True); L=open(T+'_lin.pdf','rb').read(); os.remove(T+'_lin.pdf')
w('T02-linearized-cut-60pct.pdf', L[:int(len(L)*0.6)])
# startxref points into the middle of an object
w('C00-control-valid.pdf', B)
w('X01-bad-startxref.pdf', B[:B.rfind(b'startxref')]+b'startxref\n12345\n%%EOF\n')
# every xref offset wrong: 40 bytes inserted after the header line without updating the table
i=B.index(b'\n')+1; w('X02-bad-xref-offsets.pdf', B[:i]+b'%'+b'x'*38+b'\n'+B[i:])
# trailer dictionary removed (xref table, startxref and %%EOF kept)
t0=B.rindex(b'trailer'); t1=B.rindex(b'startxref'); w('X03-missing-trailer.pdf', B[:t0]+B[t1:])
# xref, trailer, startxref and %%EOF all missing (file ends after the last object)
w('X04-no-xref-trailer-eof.pdf', B[:B.rindex(b'xref\n0 ')])
# object streams: qpdf puts dictionaries in ObjStm; corrupt the compressed data of the first ObjStm
subprocess.run(['qpdf','--object-streams=generate','--compress-streams=y',T+'base.pdf',T+'_os.pdf'],check=True); O=bytearray(open(T+'_os.pdf','rb').read()); os.remove(T+'_os.pdf')
m=re.search(rb'/Type\s*/ObjStm',O); s=O.index(b'stream',m.end())+7; L0=int(re.search(rb'/Length\s+(\d+)',O[max(0,m.start()-50):m.end()+80]).group(1))
for k in range(s+2*L0//3, s+2*L0//3+40): O[k]=random.randrange(256)
w('O01-broken-object-stream.pdf', bytes(O)); open(T+'O01.objstm-note.txt','w').write(f'first ObjStm at {m.start()}, stream bytes {s}..{s+L0}, 40 bytes randomised at {s+2*L0//3}\n')
# page tree: Kids entry for page 3 (19 0 R) replaced by a missing object (99 0 R), same byte length
w('P01-pagetree-missing-kid.pdf', B.replace(b'/Kids [ 5 0 R 7 0 R 19 0 R 20 0 R 21 0 R ]', b'/Kids [ 5 0 R 7 0 R 99 0 R 20 0 R 21 0 R ]'))
# page tree root lost: Catalog /Pages points at a missing object
w('P02-catalog-pages-missing.pdf', B.replace(b'/Pages 30 0 R /Type /Catalog', b'/Pages 98 0 R /Type /Catalog'))
# junk in front of the header (email gateway / bad transfer)
w('J01-junk-512-before-header.pdf', bytes(random.randrange(256) for _ in range(512))+B)
w('J02-junk-2048-before-header.pdf', bytes(random.randrange(256) for _ in range(2048))+B)
# incremental update: page 1 content replaced ("PAGE-1-UPDATED rev2"), page 5 removed from the tree, new Title
import zlib
def upd(base, broken):
    off=len(base); objs=[]; cs=b'BT /F2 20 Tf 72 700 Td (PAGE-1-UPDATED rev2 replaces page 1) Tj ET'
    objs.append((31, b'<< /Length %d >>\nstream\n'%len(cs)+cs+b'\nendstream'))
    objs.append((30, b'<< /Count 4 /Kids [ 5 0 R 7 0 R 19 0 R 20 0 R ] /Type /Pages >>'))
    objs.append((23, b"<< /Author (Test Author) /Title (FDP-101 rev2 page 5 deleted) /Producer (hand-made update) >>"))
    body=b'\n'; offs={}
    for n,o in objs: offs[n]=off+len(body); body+=b'%d 0 obj\n'%n+o+b'\nendobj\n'
    if broken=='no-xref': return base+body           # interrupted save: objects written, no xref/trailer
    xo=off+len(body); x=b'xref\n0 1\n0000000000 65535 f \n'
    for n in sorted(offs): x+=b'%d 1\n%010d 00000 n \n'%(n, offs[n]+(7 if broken=='bad-offsets' else 0))
    x+=b'trailer\n<< /Size 37 /Root 22 0 R /Info 23 0 R /Prev %d >>\nstartxref\n%d\n%%%%EOF\n'%(sx(base), xo+(0 if broken!='bad-prev' else 0))
    out=base+body+x
    if broken=='bad-prev': out=out.replace(b'/Prev %d'%sx(base), b'/Prev %d'%(sx(base)+333))
    return out
w('I00-incremental-valid.pdf', upd(B,None))
w('I01-incremental-bad-offsets.pdf', upd(B,'bad-offsets'))
w('I02-incremental-interrupted.pdf', upd(B,'no-xref'))
w('I03-incremental-bad-prev.pdf', upd(B,'bad-prev'))
# encrypted + damaged trailer
subprocess.run(['qpdf','--allow-weak-crypto','--encrypt','','own101','128','--use-aes=n','--',T+'base.pdf',T+'_e1.pdf'],check=True)
E1=open(T+'_e1.pdf','rb').read(); w('E01-rc4-emptyuser-bad-startxref.pdf', E1[:E1.rfind(b'startxref')]+b'startxref\n999\n%%EOF\n')
subprocess.run(['qpdf','--encrypt','','own101','256','--',T+'base.pdf',T+'_e2.pdf'],check=True)
E2=open(T+'_e2.pdf','rb').read(); t0=E2.rindex(b'trailer'); t1=E2.rindex(b'startxref')
if t0>0 and t0<t1: w('E02-aes256-emptyuser-no-trailer.pdf', E2[:t0]+E2[t1:])
else: w('E02-aes256-emptyuser-no-trailer.pdf', E2[:E2.rindex(b'startxref')]+b'startxref\n999\n%%EOF\n'); print('E02: xref stream file, used bad startxref instead')
subprocess.run(['qpdf','--encrypt','test101','own101','256','--',T+'base.pdf',T+'_e3.pdf'],check=True)
E3=open(T+'_e3.pdf','rb').read(); w('E03-aes256-userpw-bad-startxref.pdf', E3[:E3.rfind(b'startxref')]+b'startxref\n999\n%%EOF\n')
for f in ['_e1.pdf','_e2.pdf','_e3.pdf']: os.remove(T+f)
w('Z01-zero-byte.pdf', b'')
z=io.BytesIO(); zf=zipfile.ZipFile(z,'w'); zf.writestr('[Content_Types].xml','<?xml version="1.0"?><Types/>'); zf.writestr('word/document.xml','<w:document/>'); zf.close(); w('N01-docx-renamed.pdf', z.getvalue())
w('N02-jpeg-renamed.pdf', open('/tmp/p2.jpg','rb').read())
w('N03-html-error-page.pdf', b'<!DOCTYPE html><html><head><title>403 Forbidden</title></head><body><h1>Access denied</h1></body></html>\n')
w('N04-plain-text.pdf', b'This is not a PDF. Invoice 1234, total 56.78\n'*5)
