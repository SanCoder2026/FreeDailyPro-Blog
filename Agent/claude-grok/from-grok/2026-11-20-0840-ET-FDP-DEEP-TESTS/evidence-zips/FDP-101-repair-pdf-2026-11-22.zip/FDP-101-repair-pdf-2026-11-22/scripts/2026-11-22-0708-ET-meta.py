import fitz,glob,os
fitz.TOOLS.mupdf_display_errors(False)
for n in ['X03-missing-trailer.pdf','X04-no-xref-trailer-eof.pdf','T01-truncated-after-p3.pdf','P02-catalog-pages-missing.pdf','O01-broken-object-stream.pdf','J01-junk-512-before-header.pdf']:
  row=[n]
  for src in ['analysis/toolout/repaired_','baseline/qpdf/','baseline/mutool/']:
    f=src+n
    if os.path.exists(f):
      d=fitz.open(f); row.append(src.split('/')[1][:7]+':'+repr((d.metadata.get('title') or '')[:20]))
  print(' | '.join(row))
