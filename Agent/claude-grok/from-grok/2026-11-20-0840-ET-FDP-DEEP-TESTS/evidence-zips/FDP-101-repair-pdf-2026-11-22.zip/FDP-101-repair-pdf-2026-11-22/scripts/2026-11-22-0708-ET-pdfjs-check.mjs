// usage: node pdfjs-check.mjs file... -> JSON lines {file, ok, pages, markers, outline, fields, err, warnings}
import fs from 'fs';
import * as pdfjs from 'pdfjs-dist/legacy/build/pdf.mjs';
const pw = process.env.PW || undefined;
for (const f of process.argv.slice(2)) {
  const r = { file: f.split('/').pop(), ok: false };
  const warns = []; const ow = console.log; 
  try {
    const data = new Uint8Array(fs.readFileSync(f));
    const doc = await pdfjs.getDocument({ data, password: pw, verbosity: 0, stopAtErrors: false }).promise;
    r.pages = doc.numPages; const mk = [];
    for (let i = 1; i <= doc.numPages; i++) {
      try { const p = await doc.getPage(i); const t = await p.getTextContent(); const s = t.items.map(x => x.str).join(' ');
        const m = s.match(/PAGE-\d-(TEXT|UPDATED)/g); mk.push(m ? m[0] : '-');
        await p.getOperatorList(); } catch (e) { mk.push('ERR:' + String(e.message).slice(0, 40)); }
    }
    r.markers = mk.join(',');
    const ol = await doc.getOutline(); r.outline = ol ? ol.length : 0;
    const fo = await doc.getFieldObjects(); r.fields = fo ? Object.keys(fo).map(k => k + '=' + (fo[k][0].value ?? '')).join(';') : '';
    r.ok = true;
  } catch (e) { r.err = (e.name || '') + ': ' + String(e.message).slice(0, 80); }
  process.stdout.write(JSON.stringify(r) + '\n');
}
