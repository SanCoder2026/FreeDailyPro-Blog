// FDP-101 extras, guest only: Quick Buy (redirect host only, stops at the email field / Stripe, types nothing),
// Drive buttons (popup host only, OAuth params redacted, never signs in), Share dialog (reads only, sends nothing),
// keyboard path, mobile overflow. Never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const W = '/var/tmp/deep-work/101-repair/live/'; const TF = '/var/tmp/deep-work/101-repair/testfiles/'; const TOOL = 'https://www.freedailypro.com/tool/repair-pdf';
const red = u => (u || '').replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').slice(0, 160);
const dlg = async p => { const d = p.locator('[role=dialog],[role=menu],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null; };
(async () => { const b = await pw.chromium.launch(); const R = { t: cp.execSync('date "+%F %T %Z"').toString().trim() };
 const ctx = async (o = {}) => { const c = await b.newContext({ viewport: { width: 1366, height: 1000 }, locale: 'en-US', ...o }); const p = await c.newPage(); p.setDefaultTimeout(12000); await p.goto(TOOL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); return [c, p]; };
 // Quick Buy x2
 for (const [i, label] of [[0, 'day'], [1, 'monthly']]) { const [c, p] = await ctx(); const r = {};
  try { const pop = c.waitForEvent('page', { timeout: 8000 }).catch(() => null); await p.getByRole('button', { name: 'Quick Buy' }).nth(i).click(); await p.waitForTimeout(5000); const np = await pop;
   r.dialog = await dlg(p); r.url = red(p.url()); r.popup = np ? red(np.url()) : null; r.emailField = await p.locator('input[type=email]').count(); await p.screenshot({ path: W + 'cases/QB-' + label + '.png' }); } catch (e) { r.error = String(e).slice(0, 150); }
  R['quickbuy_' + label] = r; await c.close(); }
 // Drive buttons: on drop zone and on result
 { const [c, p] = await ctx(); const r = {}; r.dropZoneButtons = (await p.locator('main button').allInnerTexts()).filter(Boolean).slice(0, 20);
  const od = p.locator('main button', { hasText: /Google Drive/ }); if (await od.count()) { const pop = p.waitForEvent('popup', { timeout: 8000 }).catch(() => null); await od.first().click(); const w = await pop; await p.waitForTimeout(2500); r.openDrive = { dialog: await dlg(p), popup: w ? red(w.url().replace(/\?.*$/, '?REDACTED')) : null }; if (w) await w.close(); await p.keyboard.press('Escape'); }
  await p.goto(TOOL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); await p.locator('input[type=file]').first().setInputFiles(TF + 'X01-bad-startxref.pdf'); await p.getByRole('button', { name: 'Attempt Repair' }).click(); await p.waitForTimeout(4000);
  const sd = p.getByRole('button', { name: 'Save to Google Drive' }); if (await sd.count()) { const pop = p.waitForEvent('popup', { timeout: 8000 }).catch(() => null); await sd.click(); const w = await pop; await p.waitForTimeout(2500); r.saveDrive = { dialog: await dlg(p), popup: w ? red(w.url().replace(/\?.*$/, '?REDACTED')) : null }; await p.screenshot({ path: W + 'cases/drive-save.png' }); if (w) await w.close(); await p.keyboard.press('Escape'); }
  const sc = p.getByRole('button', { name: 'Save to my cloud storage' }); if (await sc.count()) { await sc.click(); await p.waitForTimeout(2500); r.saveCloud = { dialog: await dlg(p), url: red(p.url()) }; await p.screenshot({ path: W + 'cases/cloud-save.png' }); await p.keyboard.press('Escape'); }
  const pv = p.getByRole('button', { name: 'Preview first page' }); if (await pv.count()) { await pv.click(); await p.waitForTimeout(3000); await p.screenshot({ path: W + 'cases/preview.png', fullPage: false }); r.preview = await dlg(p); }
  R.drive = r; await c.close(); }
 // Share + keyboard
 { const [c, p] = await ctx(); const r = {}; const sh = p.locator('button[aria-label*="hare"]').first(); if (await sh.count()) { await sh.click(); await p.waitForTimeout(1500); r.share = await dlg(p); await p.screenshot({ path: W + 'cases/share.png' }); await p.keyboard.press('Escape'); }
  await p.locator('body').click({ position: { x: 5, y: 300 } }); let n = 0, seen = [];
  for (; n < 70; n++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return (e.tagName + ' ' + (e.getAttribute('aria-label') || e.innerText || e.id || e.type || '').trim().slice(0, 40)) + (e.closest('ins,.adsbygoogle,iframe') ? ' [AD]' : ''); }); seen.push(a); if (/Drop a damaged|INPUT file|choose|Browse/i.test(a)) break; }
  r.tabsToDropZone = n + 1; r.tabPath = seen; r.fileInputLabel = await p.evaluate(() => { const i = document.querySelector('input[type=file]'); return i ? { aria: i.getAttribute('aria-label'), id: i.id, hidden: getComputedStyle(i).display, parentRole: i.closest('[role]')?.getAttribute('role'), parentLabel: i.closest('[role]')?.getAttribute('aria-label') } : null; });
  await p.locator('input[type=file]').first().setInputFiles(TF + 'T03-truncated-at-40pct.pdf'); await p.getByRole('button', { name: 'Attempt Repair' }).focus(); await p.keyboard.press('Enter'); await p.waitForTimeout(4000);
  r.liveRegions = await p.evaluate(() => [...document.querySelectorAll('[aria-live],[role=status],[role=alert]')].map(e => (e.getAttribute('aria-live') || e.getAttribute('role')) + ':' + e.innerText.slice(0, 80))); r.errorFocus = await p.evaluate(() => document.activeElement.tagName + ' ' + document.activeElement.innerText.slice(0, 40));
  R.kbd = r; await c.close(); }
 // mobile
 for (const dn of ['iPhone 13', 'Pixel 7']) { const dev = pw.devices[dn]; const [c, p] = await ctx({ ...dev }); await p.locator('input[type=file]').first().setInputFiles(TF + 'T02-linearized-cut-60pct.pdf'); await p.getByRole('button', { name: 'Attempt Repair' }).click(); await p.waitForTimeout(4000);
  R['mobile_' + dn] = await p.evaluate(() => ({ sw: document.documentElement.scrollWidth, iw: window.innerWidth, wide: [...document.querySelectorAll('main *')].filter(e => e.getBoundingClientRect().right > window.innerWidth + 2).slice(0, 5).map(e => e.tagName + '.' + String(e.className).slice(0, 50)) }));
  await p.locator('[data-testid=repair-fixed]').scrollIntoViewIfNeeded().catch(() => { }); await p.screenshot({ path: W + 'cases/mobile-' + dn.replace(/\s/g, '-') + '.png' }); await c.close(); }
 fs.writeFileSync(W + 'extras.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1).slice(0, 5000)); await b.close(); })();
