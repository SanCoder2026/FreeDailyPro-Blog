// FDP-101: other tools' "looks damaged" messages -> Repair PDF link. Guest only, no sign-in, no ads clicked.
// Drops a damaged synthetic PDF on other tools (en + locale pages), records the toast/message and where the Repair PDF action lands.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const W = '/var/tmp/deep-work/101-repair/'; const OUT = W + 'live/links/'; const TF = W + 'testfiles/'; fs.mkdirSync(OUT, { recursive: true });
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const pages = (process.env.PAGES || 'tool/merge-pdf,tool/compress-pdf,tool/split-pdf,tool/rotate-pdf,tool/pdf-to-word,tool/pdf-to-jpg,tool/pdf-to-text,tool/add-page-numbers,es/tool/merge-pdf,de/tool/compress-pdf,fr/tool/pdf-to-word').split(',');
const file = process.env.FILE || 'T02-linearized-cut-60pct.pdf';
(async () => { const b = await pw.chromium.launch(); const R = { t: now(), file, cases: {} };
 for (const pg of pages) { const c = await b.newContext({ viewport: { width: 1366, height: 1000 }, locale: 'en-US', timezoneId: 'America/New_York' }); const p = await c.newPage(); p.setDefaultTimeout(12000); const r = {};
  try { await p.goto('https://www.freedailypro.com/' + pg, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4000);
   r.used = await p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
   const inp = p.locator('input[type=file]'); r.inputs = await inp.count(); await inp.first().setInputFiles(TF + file); const ts = new Set();
   for (let i = 0; i < 24; i++) { for (const t of (await p.locator('[data-sonner-toast]').allInnerTexts())) ts.add(t.replace(/\s*\n\s*/g, ' | ')); await p.waitForTimeout(250); }
   r.toasts = [...ts]; r.dialog = await p.locator('[role=dialog]').count() ? (await p.locator('[role=dialog]').first().innerText()).slice(0, 200) : null;
   const body = await p.locator('main').innerText(); r.mainMsgs = body.split('\n').filter(l => /damag|repair|could not be opened|readable PDF|cut short|corrupt/i.test(l)).slice(0, 5);
   r.repairLinks = await p.locator('main a[href*="repair-pdf"]').evaluateAll(a => a.map(x => x.innerText.trim() + ' -> ' + x.getAttribute('href')));
   await p.screenshot({ path: OUT + pg.replace(/\//g, '_') + '.png' });
   const act = p.locator('[data-sonner-toast] button', { hasText: 'Repair PDF' });
   if (await act.count()) { await Promise.all([p.waitForURL(/repair-pdf/, { timeout: 15000 }).catch(() => { }), act.first().click()]); await p.waitForTimeout(2500); r.landed = p.url(); r.landedH1 = await p.locator('h1').first().innerText().catch(() => null); r.landedLang = await p.evaluate(() => document.documentElement.lang); r.fileCarried = (await p.locator('main').innerText()).includes(file); }
   else if (r.repairLinks.length) { await p.locator('main a[href*="repair-pdf"]').first().click(); await p.waitForTimeout(3000); r.landed = p.url(); r.landedH1 = await p.locator('h1').first().innerText().catch(() => null); r.landedLang = await p.evaluate(() => document.documentElement.lang); }
  } catch (e) { r.error = String(e).slice(0, 200); }
  R.cases[pg] = r; console.log(pg, JSON.stringify(r).slice(0, 500)); await c.close(); }
 fs.writeFileSync(OUT + 'links-' + file.replace('.pdf', '') + '.json', JSON.stringify(R, null, 1)); await b.close(); })();
