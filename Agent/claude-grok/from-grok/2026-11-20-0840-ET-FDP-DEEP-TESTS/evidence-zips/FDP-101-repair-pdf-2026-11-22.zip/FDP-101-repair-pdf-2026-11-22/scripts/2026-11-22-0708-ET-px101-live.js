// FDP-101 Repair PDF (Professional Tool), guest only. node px101-live.js <mode>
// Never signs in, never types an email or card, never clicks ads. Test files are synthetic (made-up content).
// The repaired blob is captured by wrapping URL.createObjectURL (test-harness read of what the page built), so outputs
// can be checked even when the download itself is gated at 0 trial uses. Real downloads are tested in mode "download".
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const W = '/var/tmp/deep-work/101-repair/'; const OUT = W + 'live/'; const TF = W + 'testfiles/'; const TOOL = process.env.URL || 'https://www.freedailypro.com/tool/repair-pdf';
const mode = process.argv[2] || 'corpus'; const sfx = process.env.SUF || '';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
for (const d of ['dl', 'cases', 'out' + sfx]) fs.mkdirSync(OUT + d, { recursive: true });
const AD = /doubleclick|googlesyndication|adservice|adtrafficquality|googletagmanager|google-analytics|gstatic|fundingchoices|pagead|ads\.|criteo|amazon-adsystem|pubmatic|rubicon|openx|casalemedia|adnxs|taboola|outbrain|youtube|ytimg|ggpht/i;
(async () => { const b = await (process.env.WK ? pw.webkit : process.env.FF ? pw.firefox : pw.chromium).launch(); const R = { t: now(), mode, tool: TOOL, tries: [], cases: {} }; let c, p, allreq = [], dls = [];
 const open = async (opts = {}) => { c = await b.newContext({ viewport: { width: 1366, height: 1100 }, locale: 'en-US', timezoneId: 'America/New_York', acceptDownloads: true, ...opts }); 
  await c.addInitScript(() => { const o = URL.createObjectURL; window.__blobs = []; URL.createObjectURL = function (x) { try { if (x instanceof Blob) window.__blobs.push(x); } catch (e) { } return o.apply(this, arguments); }; });
  p = await c.newPage(); p.setDefaultTimeout(15000); allreq = []; dls = [];
  p.on('request', r => { const u = new URL(r.url()); allreq.push({ ts: Date.now(), m: r.method(), host: u.host, path: u.pathname.slice(0, 70), ad: AD.test(u.host + u.pathname), len: (r.postData() || '').length }); });
  p.on('download', async d => { const n = d.suggestedFilename(); const path = OUT + 'dl/' + mode + sfx + '-' + dls.length + '-' + n; dls.push({ name: n, path }); await d.saveAs(path).catch(() => { }); });
  await p.goto(TOOL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(200); } };
 const shot = (n, full = false) => p.screenshot({ path: OUT + 'cases/' + n + sfx + '.png', fullPage: full });
 const toasts = async () => (await p.locator('[data-sonner-toast]').allInnerTexts()).map(s => s.replace(/\s*\n\s*/g, ' '));
 const panel = () => p.evaluate(() => { const fx = document.querySelector('[data-testid=repair-fixed]'); const sp = fx?.parentElement || document.querySelector('.space-y-4');
   const txt = sp ? sp.innerText.split('\n').map(x => x.trim()).filter(Boolean) : []; const links = sp ? [...sp.querySelectorAll('a')].map(a => a.innerText.trim() + ' -> ' + a.getAttribute('href')) : [];
   const btns = sp ? [...sp.querySelectorAll('button')].map(x => x.innerText.trim()).filter(Boolean) : []; return { fixed: fx?.innerText || null, lines: txt.slice(0, 12), links, btns }; });
 const grabBlob = async (name) => { const r = await p.evaluate(async () => { const bl = (window.__blobs || []).filter(x => x.type === 'application/pdf' || x.size > 0); if (!bl.length) return null; const x = bl[bl.length - 1]; const ab = new Uint8Array(await x.arrayBuffer()); let s = ''; for (let i = 0; i < ab.length; i += 32768) s += String.fromCharCode.apply(null, ab.subarray(i, i + 32768)); return { type: x.type, size: x.size, n: bl.length, b64: btoa(s) }; });
   if (!r) return null; fs.writeFileSync(OUT + 'out' + sfx + '/repaired_' + name, Buffer.from(r.b64, 'base64')); return { type: r.type, size: r.size, blobs: r.n }; };
 const repair = async (f, pwd) => { // reload, drop, Attempt Repair, record everything
   await p.goto(TOOL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(3000); await p.evaluate(() => { window.__blobs = []; });
   const u0 = await used(); const ts = new Set(); await p.locator('input[type=file]').first().setInputFiles(TF + f); await p.waitForTimeout(1200); if (pwd) { const d = p.locator('[role=dialog] input[type=password], [role=dialog] input').first(); await d.fill(pwd); await p.locator('[role=dialog] button', { hasText: 'Unlock' }).click(); await p.waitForTimeout(2500); } for (const t of await toasts()) ts.add('drop: ' + t);
   const btn = p.getByRole('button', { name: 'Attempt Repair' }); const hasBtn = await btn.count() > 0; const res = { u0, dropToasts: [...ts], attemptButton: hasBtn };
   if (!hasBtn) { res.afterDrop = (await p.locator('main').innerText()).split('\n').filter(l => /pdf|file|empty|byte|damag|recogn/i.test(l)).slice(0, 8); await shot('R-' + f.replace('.pdf', '')); return res; }
   const t0 = Date.now(); await btn.click(); const ts2 = new Set();
   for (let i = 0; i < 60; i++) { for (const t of await toasts()) ts2.add(t); const busy = await p.getByText('Attempting recovery...').count(); if (!busy && i > 3) break; await p.waitForTimeout(250); }
   await p.waitForTimeout(1500); for (const t of await toasts()) ts2.add(t); const t1 = Date.now();
   res.ms = t1 - t0; res.toasts = [...ts2]; res.panel = await panel(); res.u1 = await used(); res.dialog = await dialog();
   const during = allreq.filter(r => r.ts >= t0 && r.ts <= t1); res.netDuring = { total: during.length, nonAd: during.filter(r => !r.ad).map(r => r.m + ' ' + r.host + r.path), posts: during.filter(r => r.m === 'POST').map(r => r.host + r.path + ' len' + r.len) };
   res.blob = await grabBlob(f); await shot('R-' + f.replace('.pdf', '')); return res; };
 const C = async (id, fn) => { try { R.cases[id] = await fn(); } catch (e) { R.cases[id] = { error: String(e).slice(0, 300) }; } console.log(id, JSON.stringify(R.cases[id]).slice(0, 420)); };
 const files = (process.env.FILES || fs.readdirSync(TF).filter(f => f.endsWith('.pdf') && f !== 'base.pdf').sort().join(',')).split(',');
 if (mode === 'corpus') { await open(); R.start = await used(); R.buttonsInitial = (await p.locator('main button').allInnerTexts()).filter(Boolean).slice(0, 30);
  for (const f of files) await C(f, () => repair(f)); }
 if (mode === 'pw') { await open(); R.start = await used(); await C('E03-with-password', () => repair('E03-aes256-userpw-bad-startxref.pdf', process.env.PDFPW || 'test101')); }
 if (mode === 'privacy') { await open(); const full = []; p.on('request', r => full.push({ u: r.url(), m: r.method(), body: r.postData() || '' })); R.start = await used();
  await C('PV01-repair-distinct-name', () => repair('ZZ-PRIVNAME-Quokka7.pdf')); await p.getByRole('button', { name: 'Preview first page' }).click().catch(() => { }); await p.waitForTimeout(3000);
  R.privacy = { requests: full.length, hits: full.filter(x => /Quokka7|PRIVNAME|Alex%20Sample|Alex Sample|PAGE-1-TEXT|FDP-101/i.test(decodeURIComponent(x.u) + x.body)).map(x => x.m + ' ' + x.u.slice(0, 160)), ga: full.filter(x => /collect/.test(x.u)).map(x => decodeURIComponent(x.u).match(/[?&](en|ep\.[a-z_]+|dl|dt|dp)=[^&]*/g)),
   storage: await p.evaluate(async () => ({ ls: Object.keys(localStorage), ss: Object.keys(sessionStorage), hit: /Quokka7|Alex Sample/.test(JSON.stringify(localStorage) + JSON.stringify(sessionStorage)), idb: (indexedDB.databases ? (await indexedDB.databases()).map(d => d.name) : 'n/a') })) }; }
 if (mode === 'download') { // real download with trial uses left: count per repair and per page load
  const find = async () => { for (let i = 0; i < +(process.env.TRIES || 45); i++) { await open(); const u = await used(); R.tries.push(u); if (/^\d+\/\d+$/.test(u) && +u.split('/')[0] <= +u.split('/')[1] - 3) return true; if (i < +(process.env.TRIES || 45) - 1) await c.close(); } return false; };
  if (!(await find())) { R.nofind = true; fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('blocked: all contexts at cap', R.tries.join(' ')); await b.close(); return; } R.start = await used();
  const dl = async (f) => { const r = await repair(f); const u0 = await used(); const db = p.getByRole('button', { name: /^Download/ }).first(); r.dlButton = await db.innerText().catch(() => null); await db.click(); await p.waitForTimeout(3500); r.dlu0 = u0; r.dlu1 = await used(); r.dlDialog = await dialog(); r.dls = dls.map(d => d.name); await esc(); return r; };
  await C('D01-T01-download', () => dl('T01-truncated-after-p3.pdf'));
  await C('D02-same-file-second-download', async () => { const u0 = await used(); await p.getByRole('button', { name: /^Download/ }).first().click(); await p.waitForTimeout(3000); return { u0, u1: await used(), dls: dls.map(d => d.name), dialog: await dialog() }; });
  await esc();
  await C('D03-X03-download', () => dl('X03-missing-trailer.pdf'));
  await C('D04-repair-only-no-download', async () => { const r = await repair('X01-bad-startxref.pdf'); return { u0: r.u0, u1: r.u1 }; });
 }
 if (mode === 'zero') { // what a guest at 0 trial uses can do: repair + preview + captured blob; does Download save?
  const find0 = async () => { for (let i = 0; i < +(process.env.TRIES || 20); i++) { await open(); const u = await used(); R.tries.push(u); if (/^(\d+)\/(\d+)$/.test(u) && +u.split('/')[0] >= +u.split('/')[1]) return true; await c.close(); } return false; };
  R.found0 = await find0(); R.start = await used();
  await C('Z01-zero-repair', () => repair('T01-truncated-after-p3.pdf'));
  await C('Z02-zero-preview', async () => { const m = await p.locator('main').innerText(); return { previewIframes: await p.locator('main iframe, main embed, main object, main canvas').count(), pageWord: (m.match(/Page \d+ of \d+|\d+ pages?/g) || []).slice(0, 4) }; });
  await C('Z03-zero-download', async () => { const db = p.getByRole('button', { name: /^Download/ }).first(); const label = await db.innerText(); await db.click(); await p.waitForTimeout(3000); const d = await dialog(); await shot('Z03-zero-download'); return { label, dialog: d, dls: dls.map(x => x.name), used: await used() }; });
 }
 R.hosts = [...new Set(allreq.map(x => x.host))]; R.end = await used().catch(() => null); fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', R.start, R.end, R.tries.join(' ')); await b.close(); })();
