// FDP-101: "Share this tool" for a guest: reads the toast/dialog only, sends nothing.
const pw = require('playwright');
(async () => { const b = await pw.chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 1000 }, permissions: ['clipboard-read', 'clipboard-write'] }); const p = await c.newPage();
 await p.goto('https://www.freedailypro.com/tool/repair-pdf', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500);
 await p.getByRole('button', { name: 'Share this tool' }).first().click(); await p.waitForTimeout(1500);
 const t = await p.locator('[data-sonner-toast]').allInnerTexts(); const d = await p.locator('[role=dialog],[role=menu]').count() ? await p.locator('[role=dialog],[role=menu]').first().innerText() : null;
 const clip = await p.evaluate(() => navigator.clipboard.readText().catch(() => null));
 await p.screenshot({ path: '/var/tmp/deep-work/101-repair/live/cases/share.png' }); console.log(JSON.stringify({ toasts: t, dialog: d, clipboard: clip })); await b.close(); })();
