# Renders each page of a PDF with PDFium (Chrome's engine) into one strip; failed pages are drawn as a red box.
import sys, pypdfium2 as pdfium
from PIL import Image, ImageDraw
def strip(f, out, label):
    d = pdfium.PdfDocument(f); ims = []
    for i in range(len(d)):
        try: im = d[i].render(scale=0.35).to_pil().convert('RGB')
        except Exception as e:
            im = Image.new('RGB', (214, 277), 'white'); dr = ImageDraw.Draw(im); dr.rectangle([2, 2, 211, 274], outline='red', width=4); dr.text((20, 120), 'PDFium: ' + str(e)[:22], fill='red')
        ims.append(im)
    W = sum(i.width for i in ims) + 10 * len(ims); H = max(i.height for i in ims) + 30
    s = Image.new('RGB', (W, H), (235, 235, 235)); ImageDraw.Draw(s).text((5, 5), label, fill='black'); x = 5
    for i, im in enumerate(ims): s.paste(im, (x, 25)); ImageDraw.Draw(s).text((x + 3, 28), f'p{i+1}', fill='blue'); x += im.width + 10
    s.save(out)
for f, o, l in [('toolout/repaired_T01-truncated-after-p3.pdf', 'render-T01-fdp.png', 'FDP repaired_T01 (tool said "Recovered 5 pages", no cut-off note) - PDFium'),
                ('toolout/repaired_P01-pagetree-missing-kid.pdf', 'render-P01-fdp.png', 'FDP repaired_P01 (tool said "No structural damage ... (4 pages)") - PDFium'),
                ('../baseline/qpdf/P01-pagetree-missing-kid.pdf', 'render-P01-qpdf.png', 'qpdf baseline P01 - PDFium'),
                ('../baseline/mutool/T04-interleaved-cut-70pct.pdf', 'render-T04-mutool.png', 'mutool clean T04 (FDP said "no complete page could be found") - PDFium'),
                ('toolout/repaired_E02-aes256-emptyuser-no-trailer.pdf', 'render-E02-fdp.png', 'FDP repaired_E02 (tool said "Recovered 5 pages") - PDFium'),
                ('toolout/repaired_I02-incremental-interrupted.pdf', 'render-I02-fdp.png', 'FDP repaired_I02 (viewers show 5 original pages; tool output 4, rev2) - PDFium')]:
    strip(f, o, l); print(o)
