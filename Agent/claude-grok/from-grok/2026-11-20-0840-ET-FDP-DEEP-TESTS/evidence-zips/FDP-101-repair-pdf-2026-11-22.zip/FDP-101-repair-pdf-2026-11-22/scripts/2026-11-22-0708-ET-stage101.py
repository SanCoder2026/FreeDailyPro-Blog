import os,shutil,glob,subprocess,zipfile,re
from PIL import Image
W='/var/tmp/deep-work/101-repair/'; TE='/workspace/deep/tools-env/'; M='/var/tmp/deep-work/fdp101matrix/'
pre=subprocess.check_output(['date','+%F-%H%M']).decode().strip()+'-ET-'
ts=subprocess.check_output(['date','+%F %H:%M']).decode().strip()
S='/var/tmp/deep-work/stage101'; R=S+'/FDP-101-repair-pdf-2026-11-22/'
shutil.rmtree(S,ignore_errors=True); os.makedirs(R)
def put(src,sub,name=None):
    d=R+sub; os.makedirs(d,exist_ok=True); shutil.copy(src,d+'/'+pre+(name or os.path.basename(src)))
def puttext(src,sub,name=None):
    d=R+sub; os.makedirs(d,exist_ok=True); open(d+'/'+pre+(name or os.path.basename(src)),'w').write(open(src).read().replace('@@TS@@',ts))
def putimg(src,sub,name=None):
    d=R+sub; os.makedirs(d,exist_ok=True); n=os.path.splitext(name or os.path.basename(src))[0]+'.jpg'
    im=Image.open(src).convert('RGB')
    if im.width>1400: im=im.resize((1400,round(im.height*1400/im.width)),Image.LANCZOS)
    if im.height>6000: im=im.crop((0,0,im.width,6000))
    im.save(d+'/'+pre+n,'JPEG',quality=70,optimize=True)
for f in ['REPORT','PRIORITIES','REPRODUCE','test-cases','INSTRUCTIONS']: puttext(W+'docs/'+f+'.md','')
for f in glob.glob(W+'docs/findings/*.md'): puttext(f,'findings')
puttext(W+'docs/scripts-README.md','scripts','README.md')
for f in sorted(glob.glob(TE+'px101-*.js'))+[TE+'run-matrix.js']: put(f,'scripts')
for f in ['make101.py','make101b.py','check101.py','summarize101.py','config.json','node/pdfjs-check.mjs','analysis/render101.py','analysis/meta.py','analysis/make-testcases.py']: put(W+f,'scripts')
put('/var/tmp/deep-work/stage101.py','scripts')
for f in glob.glob(W+'live/*.json'):
    if os.path.basename(f) in ('corpus.json','corpus-partA.json'): continue
    put(f,'evidence/json')
for f in glob.glob(W+'live/links/*.json'): put(f,'evidence/json/links')
put(M+'matrix-results.json','evidence/json')
for f in glob.glob(W+'live/dl/*'): put(f,'evidence/downloads')
for f in glob.glob(W+'testfiles/*'): put(f,'evidence/testfiles')
for f in glob.glob(W+'analysis/toolout/*.pdf'): put(f,'evidence/outputs/fdp')
for t in ['qpdf','mutool']:
    for f in glob.glob(W+'baseline/'+t+'/*'): put(f,'evidence/outputs/'+t)
put(W+'baseline/exit-codes.txt','evidence/outputs')
for f in glob.glob(W+'analysis/*'):
    if os.path.isdir(f) or f.endswith('.py'): continue
    if f.endswith('.png'): putimg(f,'evidence/analysis')
    else: put(f,'evidence/analysis')
for f in ['headers-tool.txt','tool-expanded.txt','tool-expanded.txt.jsonld.json','tool-links.txt','tool.html','robots.txt']: put(W+f,'evidence/html')
for f in ['RepairPdf-7jnTbIWV.js','RepairPdf.pretty.js','operations.pretty.js','pdfRecover-PVH02fpy.js','pdfRecover.pretty.js','repairDiagnose-Csq-PeZE.js','repairDiagnose.pretty.js','chunks.txt','all/pdfLoadError-Bi-AAFkg.js','all/ToolPage-B4roIUf_.js']: put(W+'js/'+f,'evidence/js')
for f in glob.glob(W+'blog/*.txt'): put(f,'evidence/blog')
put(W+'video/v.mp4.info.json','evidence/video','video-info.json'); putimg(W+'video/sheet.png','evidence/video')
for f in ['f01','f05','f07','f12']: putimg(W+'video/'+f+'.png','evidence/video')
suf=re.compile(r'-(A|B|C|D|pw|z|pv|firefox|webkit)\.png$')
for f in glob.glob(W+'live/cases/*.png'):
    b=os.path.basename(f)
    if b.startswith('R-') and not suf.search(b): continue
    putimg(f,'evidence/screens')
for f in glob.glob(W+'live/links/*.png'): putimg(f,'evidence/screens','links-'+os.path.basename(f))
if os.path.exists(W+'live/initial.png'): putimg(W+'live/initial.png','evidence/screens')
for sub in ['devices','locales','geo','a11y']:
    for f in [x for x in glob.glob(M+sub+'/*.png') if '-fold' in x or 'iphone-se-full' in x]: putimg(f,'evidence/screens','matrix-'+os.path.basename(f))
z='/workspace/deep/zips/FDP-101-repair-pdf-2026-11-22.zip'
if os.path.exists(z): os.remove(z)
os.chdir(S)
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as zf:
    for r,_,fs in os.walk('.'):
        for f in sorted(fs): p=os.path.join(r,f); zf.write(p,p[2:])
zf=zipfile.ZipFile(z); n=zf.namelist()
bad=[x for x in n if not os.path.basename(x).startswith(pre)]
rep=[x for x in n if x.endswith('REPORT.md')][0]
print(pre, round(os.path.getsize(z)/1e6,2),'MB',len(n),'bad',bad, zf.read(rep).decode().splitlines()[0], zf.testzip())
