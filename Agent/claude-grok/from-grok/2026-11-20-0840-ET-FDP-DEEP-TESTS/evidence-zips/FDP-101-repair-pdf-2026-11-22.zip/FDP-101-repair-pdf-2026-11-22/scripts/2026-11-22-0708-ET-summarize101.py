# Builds a comparison table: for each input, what each source (input as-is, qpdf, mutool, FDP tool) gives in each viewer.
# usage: summarize101.py out.md label=viewers.json,pdfjs.jsonl ...
import sys, json, os
def cell(v, j):
    if v is None: return 'no output'
    if v.get('size')==0: return 'empty'
    def s(d):
        if not d or not d.get('ok'): return '✗'
        m=d.get('markers') or ''; t=sum(1 for x in m.split(',') if x.startswith('PAGE'))
        return f"{d.get('pages')}p/{t}t"
    mu=v['mupdf']; extra=''
    if mu.get('ok'):
        f=mu.get('fields') or ''
        extra=f" img{mu.get('images')} ol{mu.get('outline')} frm{'✓' if 'Alex Sample' in f else '✗'}"
    upd='U' if 'UPDATED' in (mu.get('markers') or '') else ''
    return f"js {s(j)} · pdfium {s(v['pdfium'])} · mu {s(mu)}{upd}{extra} · qpdf{v['qpdf_check']['exit']}"
srcs=[]
for a in sys.argv[2:]:
    lab,fs=a.split('=',1); vj,jj=fs.split(','); V=json.load(open(vj)); J={}
    if os.path.exists(jj):
        for l in open(jj):
            d=json.loads(l); J[d['file'].replace('repaired_','')]=d
    V={k.replace('repaired_',''):x for k,x in V.items()}
    srcs.append((lab,V,J))
names=sorted(set(n for _,V,_ in srcs for n in V) | set(os.listdir('/var/tmp/deep-work/101-repair/testfiles')) - {'base.pdf'})
names=[n for n in names if n.endswith('.pdf')]
out=['| input | '+' | '.join(l for l,_,_ in srcs)+' |','|'+'---|'*(len(srcs)+1)]
for n in names: out.append(f'| {n} | '+' | '.join(cell(V.get(n), J.get(n)) for _,V,J in srcs)+' |')
open(sys.argv[1],'w').write('Legend: js=pdf.js, pdfium=PDFium (Chrome engine), mu=MuPDF; Np/Mt = pages / pages with their PAGE-n text marker; U = shows the rev2 incremental update; img/ol/frm = images, outline entries, form value kept; qpdfN = qpdf --check exit (0 clean, 3 warnings, 2 error). ✗ = does not open.\n\n'+'\n'.join(out)+'\n')
print('\n'.join(out))
