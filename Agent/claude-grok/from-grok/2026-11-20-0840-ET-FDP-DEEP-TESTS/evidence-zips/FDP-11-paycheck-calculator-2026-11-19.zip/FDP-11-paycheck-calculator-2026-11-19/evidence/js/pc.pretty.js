import { r as l, j as e } from "./vendor-react-D01g8YgM.js";
import { e as i, I as u, b as Y } from "./index-D2ZT81un.js";
import { T as W } from "./ToolPage-DS5jbfzr.js";
import { T as $, a as G, b as F } from "./tabs-FD1HDlYV.js";
import { T as K } from "./ToolInfoSection-M0kcUBq8.js";
import { u as J } from "./useLogToolUsage-Z9wjl3dw.js";
import { p as x } from "./numberInput-5hjoxJ5z.js";
import { f as V } from "./money-Dkxewa8a.js";
import {
  b as X,
  s as z,
  a as Q,
  e as Z,
  B as ee,
  S as ae,
  F as I,
  c as te,
  U as O,
} from "./stateTaxData-BkbKzEdQ.js";
import { a as k } from "./calcChecks-BMsAp5Al.js";
import "./useUploadApi-CeBVbB2U.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-mA9gIB_c.js";
import "./share-2-wJ7OG3q6.js";
import "./copy-DxyF2bO9.js";
import "./workflowCta-QcLjv4ms.js";
import "./UsageAndUpgradeStrip-Ckl_cEoN.js";
import "./access-BBg1iIm1.js";
import "./useAdminAccess-D2xxeUJv.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-BaZhqv4P.js";
import "./map-pin-DiPhQKiV.js";
import "./FaqSection-DgbFc-d2.js";
import "./ToolVideoEmbed-DltoCXpM.js";
import "./GuideLinks-BsEl-oB0.js";
import "./blog-Cqpj3gtZ.js";
import "./info-BGlOhDp4.js";
import "./productCards-CAZfINO_.js";
import "./layers-B7zHnkyf.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-CmqWEytu.js";
import "./chevron-up-Bx33pgGu.js";
import "./copyText-Bf-LRJbj.js";
import "./k401-BfwyVeBg.js";
const se = { weekly: 52, biweekly: 26, semimonthly: 24, monthly: 12 };
function re(t) {
  const s = Math.max(0, t.gross),
    o = Math.min(s, (s * Math.max(0, t.retirementPct)) / 100),
    n = Math.min(s, Math.max(0, t.section125Annual)),
    c = ae[t.filing],
    f = Math.max(0, s - o - n - c),
    h = X(f, ee[t.filing]),
    M = s - n,
    d = Z(M, t.filing),
    v = Math.max(0, s - o - n),
    p =
      t.state === "CUSTOM"
        ? (v * Math.max(0, t.customStatePct)) / 100
        : z(t.state, v, t.filing, c).tax,
    S = t.state === "CUSTOM" ? null : Q(t.state, s),
    y = S?.amount ?? 0,
    b = s - h - p - y - d.total - o - n;
  return {
    fed: h,
    state: p,
    statePayroll: y,
    statePayrollLabel: S?.label ?? "",
    socialSecurity: d.socialSecurity,
    medicare: d.medicare,
    additionalMedicare: d.additionalMedicare,
    fica: d.total,
    retirement: o,
    section125: n,
    netAnnual: b,
    netPerPeriod: b / t.periods,
    grossPerPeriod: s / t.periods,
    taxable: f,
  };
}
function le(t, s, o = 52) {
  const n = Math.min(s, 40),
    c = Math.max(0, s - 40);
  return (t * n + t * 1.5 * c) * o;
}
const w = {
    what: `Estimates your US take-home pay per paycheck after federal income tax (${O} brackets for your filing status), Social Security, Medicare, state tax and pre-tax deductions, from a yearly salary or an hourly rate with overtime.`,
    how: "Enter your salary (or hourly rate and hours), choose filing status, state and pay frequency, then add pre-tax deductions: a 401(k) percentage, and health premiums or HSA/FSA contributions. The result shows your net pay per check and a full breakdown.",
    tip: "Traditional 401(k) contributions lower your income tax but are still subject to Social Security and Medicare tax; health premiums and HSA/FSA through payroll lower both. Your real paycheck also depends on your W-4, local taxes and employer-specific deductions.",
  },
  T = "border rounded px-2 py-2 w-full bg-background text-sm",
  j = (t, s = 2) => V(t, "USD", s);
function Re() {
  const [t, s] = l.useState("salary"),
    [o, n] = l.useState("75000"),
    [c, f] = l.useState("25"),
    [h, M] = l.useState("40"),
    [d, v] = l.useState("single"),
    [p, S] = l.useState("CUSTOM"),
    [y, b] = l.useState("0"),
    [N, U] = l.useState("biweekly"),
    [A, L] = l.useState("0"),
    [C, B] = l.useState("0"),
    [P, D] = l.useState("0"),
    H = se[N] ?? 26,
    E =
      t === "salary"
        ? Math.max(0, x(o) ?? 0)
        : le(Math.max(0, x(c) ?? 0), Math.max(0, x(h) ?? 0)),
    r = re({
      gross: E,
      filing: d,
      state: p,
      customStatePct: x(y) ?? 0,
      retirementPct: Math.min(100, Math.max(0, x(A) ?? 0)),
      section125Annual: Math.max(0, x(C) ?? 0) * H + Math.max(0, x(P) ?? 0),
      periods: H,
    }),
    g =
      t === "salary"
        ? k(o, "an annual salary")
        : k(c, "an hourly rate") || k(h, "hours per week");
  J(!g);
  const m = ({ label: a, v: _, id: q }) =>
      e.jsxs("div", {
        className: "text-center p-3 rounded-lg border bg-card",
        children: [
          e.jsx("p", {
            className: "text-xs text-muted-foreground",
            children: a,
          }),
          e.jsx("p", {
            className: "text-sm font-bold",
            "data-testid": q,
            children: j(_, 0),
          }),
        ],
      }),
    R = {
      weekly: "weekly",
      biweekly: "bi-weekly",
      semimonthly: "semi-monthly",
      monthly: "monthly",
    }[N];
  return e.jsxs(W, {
    children: [
      e.jsxs("div", {
        className: "max-w-md mx-auto space-y-6",
        children: [
          e.jsx($, {
            value: t,
            onValueChange: (a) => s(a),
            children: e.jsxs(G, {
              className: "w-full",
              children: [
                e.jsx(F, {
                  value: "salary",
                  className: "flex-1",
                  children: "Salary",
                }),
                e.jsx(F, {
                  value: "hourly",
                  className: "flex-1",
                  children: "Hourly",
                }),
              ],
            }),
          }),
          t === "salary"
            ? e.jsxs("div", {
                children: [
                  e.jsx(i, { children: "Annual Gross Salary ($)" }),
                  e.jsx(u, {
                    inputMode: "decimal",
                    "aria-label": "Annual salary",
                    "aria-invalid": !!g,
                    value: o,
                    onChange: (a) => n(a.target.value),
                  }),
                ],
              })
            : e.jsxs("div", {
                className: "grid grid-cols-2 gap-3",
                children: [
                  e.jsxs("div", {
                    children: [
                      e.jsx(i, { children: "Hourly rate ($)" }),
                      e.jsx(u, {
                        inputMode: "decimal",
                        "aria-label": "Hourly rate",
                        "aria-invalid": !!g,
                        value: c,
                        onChange: (a) => f(a.target.value),
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx(i, { children: "Hours per week" }),
                      e.jsx(u, {
                        inputMode: "decimal",
                        "aria-label": "Hours per week",
                        value: h,
                        onChange: (a) => M(a.target.value),
                      }),
                    ],
                  }),
                  e.jsxs("p", {
                    className: "col-span-2 text-xs text-muted-foreground",
                    children: [
                      "Hours over 40 a week are paid at 1.5×. That is about ",
                      j(E, 0),
                      " a year.",
                    ],
                  }),
                ],
              }),
          e.jsxs("div", {
            className: "grid grid-cols-2 gap-3",
            children: [
              e.jsxs("div", {
                children: [
                  e.jsx(i, { className: "text-xs", children: "Filing status" }),
                  e.jsx("select", {
                    className: T,
                    "aria-label": "Filing status",
                    value: d,
                    onChange: (a) => v(a.target.value),
                    children: Object.keys(I).map((a) =>
                      e.jsx("option", { value: a, children: I[a] }, a),
                    ),
                  }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx(i, { className: "text-xs", children: "Pay frequency" }),
                  e.jsxs("select", {
                    className: T,
                    "aria-label": "Pay frequency",
                    value: N,
                    onChange: (a) => U(a.target.value),
                    children: [
                      e.jsx("option", { value: "weekly", children: "Weekly" }),
                      e.jsx("option", {
                        value: "biweekly",
                        children: "Bi-weekly",
                      }),
                      e.jsx("option", {
                        value: "semimonthly",
                        children: "Semi-monthly",
                      }),
                      e.jsx("option", {
                        value: "monthly",
                        children: "Monthly",
                      }),
                    ],
                  }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx(i, { className: "text-xs", children: "State" }),
                  e.jsxs("select", {
                    className: T,
                    "aria-label": "State",
                    value: p,
                    onChange: (a) => S(a.target.value),
                    children: [
                      e.jsx("option", {
                        value: "CUSTOM",
                        children: "Custom rate…",
                      }),
                      te.map((a) =>
                        e.jsxs(
                          "option",
                          {
                            value: a.code,
                            children: [
                              a.name,
                              a.kind === "none" ? " (no tax)" : "",
                            ],
                          },
                          a.code,
                        ),
                      ),
                    ],
                  }),
                ],
              }),
              p === "CUSTOM" &&
                e.jsxs("div", {
                  children: [
                    e.jsx(i, {
                      className: "text-xs",
                      children: "State tax rate (%)",
                    }),
                    e.jsx(u, {
                      inputMode: "decimal",
                      "aria-label": "State tax rate",
                      value: y,
                      onChange: (a) => b(a.target.value),
                    }),
                  ],
                }),
            ],
          }),
          e.jsxs("div", {
            className: "grid grid-cols-3 gap-3",
            children: [
              e.jsxs("div", {
                children: [
                  e.jsx(i, { className: "text-xs", children: "401(k) %" }),
                  e.jsx(u, {
                    inputMode: "decimal",
                    "aria-label": "401k percent",
                    value: A,
                    onChange: (a) => L(a.target.value),
                  }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx(i, {
                    className: "text-xs",
                    children: "Health premium / check",
                  }),
                  e.jsx(u, {
                    inputMode: "decimal",
                    "aria-label": "Health premium",
                    value: C,
                    onChange: (a) => B(a.target.value),
                  }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx(i, {
                    className: "text-xs",
                    children: "HSA/FSA / year",
                  }),
                  e.jsx(u, {
                    inputMode: "decimal",
                    "aria-label": "HSA",
                    value: P,
                    onChange: (a) => D(a.target.value),
                  }),
                ],
              }),
            ],
          }),
          g
            ? e.jsx("p", {
                role: "alert",
                className: "text-xs text-destructive",
                "data-testid": "pc-error",
                children: g,
              })
            : e.jsxs(e.Fragment, {
                children: [
                  e.jsxs("div", {
                    className: "p-4 rounded-xl border bg-primary/5 text-center",
                    children: [
                      e.jsxs("p", {
                        className: "text-xs text-muted-foreground",
                        children: ["Estimated Take-Home Pay (", R, ")"],
                      }),
                      e.jsx("p", {
                        className: "text-2xl font-bold text-primary",
                        "data-testid": "pc-net",
                        children: j(r.netPerPeriod),
                      }),
                      e.jsxs("p", {
                        className: "text-xs text-muted-foreground mt-1",
                        children: [
                          "of ",
                          j(r.grossPerPeriod),
                          " gross · ",
                          j(r.netAnnual, 0),
                          " a year",
                        ],
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className: "grid grid-cols-2 gap-3",
                    children: [
                      e.jsx(m, {
                        label: "Federal income tax (yr)",
                        v: r.fed,
                        id: "pc-fed",
                      }),
                      e.jsx(m, {
                        label: "State tax (yr)",
                        v: r.state,
                        id: "pc-state",
                      }),
                      r.statePayroll > 0 &&
                        e.jsx(m, {
                          label: `${r.statePayrollLabel} (yr)`,
                          v: r.statePayroll,
                          id: "pc-sdi",
                        }),
                      e.jsx(m, {
                        label: "Social Security (yr)",
                        v: r.socialSecurity,
                        id: "pc-ss",
                      }),
                      e.jsx(m, {
                        label:
                          r.additionalMedicare > 0
                            ? "Medicare + 0.9% extra (yr)"
                            : "Medicare (yr)",
                        v: r.medicare + r.additionalMedicare,
                        id: "pc-med",
                      }),
                      r.retirement > 0 &&
                        e.jsx(m, {
                          label: "401(k) (yr)",
                          v: r.retirement,
                          id: "pc-401k",
                        }),
                      r.section125 > 0 &&
                        e.jsx(m, {
                          label: "Health / HSA (yr)",
                          v: r.section125,
                          id: "pc-125",
                        }),
                    ],
                  }),
                ],
              }),
          e.jsxs("p", {
            className: "text-xs text-muted-foreground text-center",
            children: [
              "Estimate using ",
              O,
              " federal brackets and the standard deduction for your filing status. State figures are estimates. California SDI (1.3% of all wages) is included as its own line; the disability and paid-leave contributions of NJ, NY, HI, RI, WA and MA, and city or local income taxes (for example New York City) are not included, so take-home pay in those places will be lower than shown. Not tax advice — withholding depends on your W-4. See also the ",
              e.jsx(Y, {
                href: "/tool/income-tax-calculator",
                className: "underline text-primary",
                children: "Income Tax Calculator",
              }),
              ".",
            ],
          }),
        ],
      }),
      e.jsx(K, { whatIsIt: w.what, howToUse: w.how, tip: w.tip }),
    ],
  });
}
export { Re as default };
//# sourceMappingURL=PaycheckCalculator-DI6pHi9q.js.map
