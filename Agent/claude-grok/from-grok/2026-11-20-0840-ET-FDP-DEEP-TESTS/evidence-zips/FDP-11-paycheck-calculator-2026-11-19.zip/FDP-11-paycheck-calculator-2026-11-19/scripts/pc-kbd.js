// paycheck-calculator: keyboard order, aria-live, axe on main (Salary and Hourly tabs), page note text, phones. Reading only (no trial use).
const { chromium, devices } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/11-paycheck-calculator/live/'; const URL = 'https://www.freedailypro.com/tool/paycheck-calculator';
(async () => { const b = await chromium.launch(); const R = { t: cp.execSync('date "+%F %T %Z"').toString().trim() };
 const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(10000); await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday; R.used0 = await used();
 R.notes = await p.evaluate(() => [...document.querySelectorAll('main p, main small')].map(e => e.innerText.trim()).filter(t => /trial|estimate|not included|withhold|W-4/i.test(t)).slice(0, 12));
 R.defaultState = await p.evaluate(() => { const s = document.querySelector('select[aria-label=State]'); return s ? s.options[s.selectedIndex].text : null; });
 R.stateOptions = await p.evaluate(() => { const s = document.querySelector('select[aria-label=State]'); return s ? s.options.length : null; });
 await p.getByLabel('Annual salary').focus(); const seq = [];
 for (let i = 0; i < 18; i++) { await p.keyboard.press('Tab'); seq.push(await p.evaluate(() => { const e = document.activeElement; return `${e.tagName} ${(e.getAttribute('aria-label') || e.innerText || e.id || '').trim().slice(0, 34)}`; })); }
 R.tabSeq = seq; R.live = await p.evaluate(() => ({ ariaLive: [...document.querySelectorAll('main [aria-live]')].map(e => e.getAttribute('aria-live') + ':' + e.innerText.slice(0, 40)), status: document.querySelectorAll('main [role=status]').length, tablist: document.querySelectorAll('main [role=tab]').length }));
 await p.addScriptTag({ content: fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8') });
 const ax = () => p.evaluate(async () => (await axe.run(document.querySelector('main'))).violations.map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length, s: v.nodes.slice(0, 2).map(x => x.target.join(' ').slice(0, 100)) })));
 R.axeSalary = await ax(); await p.locator('[data-testid=tool-area]').screenshot({ path: OUT + 'tool-salary.png' }).catch(e => R.shotErr = String(e));
 await p.getByRole('tab', { name: 'Hourly' }).click().catch(async () => p.getByRole('button', { name: 'Hourly' }).click()); await p.waitForTimeout(400);
 R.axeHourly = await ax(); await p.locator('[data-testid=tool-area]').screenshot({ path: OUT + 'tool-hourly.png' }).catch(() => {});
 R.hourly = await p.evaluate(() => ({ net: document.querySelector('[data-testid=pc-net]')?.innerText, labels: [...document.querySelectorAll('main label')].map(l => l.innerText.trim()).slice(0, 20) }));
 for (const dn of ['iPhone SE', 'Pixel 7']) { const cc = await b.newContext({ ...devices[dn] }); const q = await cc.newPage(); await q.goto(URL, { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4000);
  R['phone_' + dn] = await q.evaluate(() => { const y = s => { const e = document.querySelector(s); return e ? Math.round(e.getBoundingClientRect().top + scrollY) : null; }; return { vw: innerWidth, sw: document.documentElement.scrollWidth, salaryY: y('input[aria-label="Annual salary"]'), netY: y('[data-testid=pc-net]'), vh: innerHeight }; });
  await q.screenshot({ path: OUT + `phone-${dn.replace(/\s/g, '-').toLowerCase()}-full.png`, fullPage: true }); await cc.close(); }
 R.usedEnd = await used(); fs.writeFileSync(OUT + 'kbd.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
