// paycheck-calculator: calculation cases (reading only; no copy/save/print, so no trial use). Usage: node pc-live.js [ids] [outfile]
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/11-paycheck-calculator/live/';
const C = {
 P01_default: {}, P02_single_75k_none: { st: 'TX' }, P03_mfj_150k_bw: { sal: '150000', fs: 'mfj', st: 'TX' }, P04_hoh_60k: { sal: '60000', fs: 'hoh', st: 'TX' },
 P05_250k_single: { sal: '250000', st: 'TX' }, P06_CA_85k: { sal: '85000', st: 'CA' }, P07_CA_hoh_85k: { sal: '85000', fs: 'hoh', st: 'CA' },
 P08_NY_85k: { sal: '85000', st: 'NY' }, P09_PA_85k_401k10: { sal: '85000', st: 'PA', k: '10' }, P10_UT_75k: { sal: '75000', st: 'UT' },
 P11_401k_30pct_200k: { sal: '200000', st: 'TX', k: '30' }, P12_401k_150pct: { sal: '75000', st: 'TX', k: '150' }, P13_hsa_50000: { sal: '75000', st: 'TX', hsa: '50000' },
 P14_health_200_bw: { sal: '75000', st: 'TX', hp: '200' }, P15_CA_hsa_4400: { sal: '85000', st: 'CA', hsa: '4400' }, P16_custom_5pct: { sal: '75000', st: 'CUSTOM', cr: '5' },
 P17_custom_150pct: { sal: '75000', st: 'CUSTOM', cr: '150' }, P18_text_abc: { sal: 'abc', st: 'TX' }, P19_85k_suffix: { sal: '85k', st: 'TX' }, P20_negative: { sal: '-5', st: 'TX' },
 P21_401k_abc: { sal: '75000', st: 'TX', k: 'abc' }, P22_weekly: { sal: '75000', st: 'TX', per: 'weekly' }, P23_monthly: { sal: '75000', st: 'TX', per: 'monthly' },
 P24_hourly_25x40: { mode: 'hourly', rate: '25', hrs: '40', st: 'TX' }, P25_hourly_25x50: { mode: 'hourly', rate: '25', hrs: '50', st: 'TX' }, P26_hourly_25x200: { mode: 'hourly', rate: '25', hrs: '200', st: 'TX' },
 P27_hourly_hrs_abc: { mode: 'hourly', rate: '25', hrs: 'abc', st: 'TX' }, P28_mfs_400k: { sal: '400000', fs: 'mfs', st: 'TX' }, P29_NJ_85k: { sal: '85000', st: 'NJ' }, P30_WA_85k: { sal: '85000', st: 'WA' },
 // Blog /blog/paycheck-calculator figures (Oct 24, 2026 post)
 B01_TX_90k: { sal: '90000', st: 'TX' }, B02_CA_90k: { sal: '90000', st: 'CA' }, B03_TX_90k_k6: { sal: '90000', st: 'TX', k: '6' }, B04_TX_90k_hp150: { sal: '90000', st: 'TX', hp: '150' },
 B05_TX_90k_k6_hp150: { sal: '90000', st: 'TX', k: '6', hp: '150' }, B06_TX_hourly_28x45: { mode: 'hourly', rate: '28', hrs: '45', st: 'TX' }, B07_TX_90k_semimonthly: { sal: '90000', st: 'TX', per: 'semimonthly' }, B08_TX_90k_monthly: { sal: '90000', st: 'TX', per: 'monthly' }, V01_video_750k_custom0: { sal: '750000', st: 'CUSTOM', cr: '0' },
};
(async () => { const ids = process.argv[2] ? process.argv[2].split(',') : Object.keys(C); const b = await chromium.launch();
 const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); p.setDefaultTimeout(12000);
 await p.goto('https://www.freedailypro.com/tool/paycheck-calculator', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 const R = { t0: cp.execSync('date "+%F %T %Z"').toString().trim(), ls0: await p.evaluate(() => localStorage.getItem('fdp-usage-v1')), cases: {} };
 for (const id of ids) { const c = { mode: 'salary', sal: '75000', fs: 'single', st: 'CUSTOM', cr: '0', per: 'biweekly', k: '0', hp: '0', hsa: '0', ...C[id] };
  if (id === 'P01_default') { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); }
  else {
   await p.getByRole('tab', { name: c.mode === 'salary' ? 'Salary' : 'Hourly' }).click(); await p.waitForTimeout(150);
   if (c.mode === 'salary') await p.getByLabel('Annual salary').fill(c.sal); else { await p.getByLabel('Hourly rate').fill(c.rate); await p.getByLabel('Hours per week').fill(c.hrs); }
   await p.selectOption('select[aria-label="Filing status"]', c.fs); await p.selectOption('select[aria-label="Pay frequency"]', c.per); await p.selectOption('select[aria-label=State]', c.st);
   if (c.st === 'CUSTOM') await p.getByLabel('State tax rate').fill(c.cr);
   await p.getByLabel('401k percent').fill(c.k); await p.getByLabel('Health premium').fill(c.hp); await p.getByLabel('HSA').fill(c.hsa); await p.waitForTimeout(350); }
  R.cases[id] = { input: c, ...(await p.evaluate(() => { const g = s => { const e = document.querySelector(`[data-testid=${s}]`); return e ? e.innerText.trim() : null; };
   const area = document.querySelector('main').innerText; return { net: g('pc-net'), fed: g('pc-fed'), state: g('pc-state'), sdi: g('pc-sdi'), ss: g('pc-ss'), med: g('pc-med'), k401: g('pc-401k'), s125: g('pc-125'), err: g('pc-error'),
     sub: (area.match(/of \$[\d,.]+ gross[^\n]*/) || [''])[0], hourlyNote: (area.match(/Hours over 40[^\n]*/) || [''])[0], alerts: [...document.querySelectorAll('main [role=alert]')].map(e => e.innerText) }; })) };
 }
 R.lsEnd = await p.evaluate(() => localStorage.getItem('fdp-usage-v1')); R.t1 = cp.execSync('date "+%F %T %Z"').toString().trim();
 fs.writeFileSync(OUT + (process.argv[3] || 'cases.json'), JSON.stringify(R, null, 1));
 for (const [k, v] of Object.entries(R.cases)) console.log(k, '| net', v.net, '| fed', v.fed, '| st', v.state, '| sdi', v.sdi, '| ss', v.ss, '| med', v.med, '| 401k', v.k401, '| 125', v.s125, '|', v.sub, '|', v.err || '', v.hourlyNote ? '| ' + v.hourlyNote : '');
 await b.close(); })();
