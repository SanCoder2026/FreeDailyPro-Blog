// paycheck-calculator: does the saved .txt carry state, SDI, 401(k) and section 125 lines? One fresh context (rerun row 11).
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/11-paycheck-calculator/live/'; const D = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true });
 const p = await c.newPage(); p.setDefaultTimeout(12000); await p.goto('https://www.freedailypro.com/tool/paycheck-calculator', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
 const R = { t: D(), start: await used() };
 await p.getByLabel('Annual salary').fill('85000'); await p.selectOption('select[aria-label=State]', 'CA');
 await p.getByLabel('401k percent').fill('6'); await p.getByLabel('Health premium').fill('150'); await p.waitForTimeout(500);
 R.screen = await p.evaluate(() => Object.fromEntries(['pc-net','pc-fed','pc-state','pc-sdi','pc-ss','pc-med','pc-401k','pc-125'].map(s => [s, (document.querySelector(`[data-testid=${s}]`)||{}).innerText || null])));
 let d = null; p.on('download', x => d = x); await p.getByRole('button', { name: 'Save as text', exact: true }).click(); await p.waitForTimeout(2000);
 const dl = p.locator('[role=dialog],[role=alertdialog]'); R.dialog = (await dl.count()) ? (await dl.first().innerText()).slice(0, 200) : null;
 if (d) { const f = OUT + 'downloads/content-CA-401k6-hp150.txt'; await d.saveAs(f); R.file = f; R.content = fs.readFileSync(f, 'utf8'); }
 R.after = await used(); R.t2 = D(); fs.writeFileSync(OUT + 'content-1120.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
