Sent: 2026-11-21 20:04 ET

# RERUN-FINDINGS

This package is version v3 (FDP-11-paycheck-calculator-2026-11-21-v3.zip). It **supersedes/extends**: FDP-11-paycheck-calculator-2026-11-19.zip, FDP-11-paycheck-calculator-2026-11-20-v2.zip. Earlier zips are untouched (frozen); anything not mentioned here is unchanged from them.

Run 19:22-19:38 ET. `pc-gate.js` (fresh context at 10 remaining) and `pc-content.js` (output renamed to content-rerun-1121.json so the Nov 20 file stays).
## Cost
- pc-gate: first action Copy result 0 -> 1, Save as text and Print free after (stay 1). Matches the Nov 20 v2 result.
- pc-content (second fresh context): Save as text as the FIRST action: **0 -> 1**.
## Content with CA + 401(k) + section 125 (closes the pending item)
Inputs: salary 85,000, CA, 401k 6 %, health premium 150. Screen and file agree:
`Estimated Take-Home Pay (bi-weekly) $2,228.70 of $3,269.23 gross - $57,946 a year`; Federal $7,890; State $2,855; **California SDI $1,105**; Social Security $5,028; Medicare $1,176; **401(k) $5,100**; **Health / HSA (yr) $3,900** (the section 125 line is labelled "Health / HSA", not "section 125"). File name `paycheck-calculator-result.txt`; note text includes the "Calculated with FreeDailyPro.com" footer and "Copying, saving or printing uses 1 per visit."
Evidence: live/gate.json, live/content-rerun-1121.json, downloads/content-CA-401k6-hp150-1121.txt.
