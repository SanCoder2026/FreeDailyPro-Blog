import { r as d, j as e } from "./vendor-react-D01g8YgM.js";
import { E as G, e as T, I as q, B as D, b as K } from "./index-D2ZT81un.js";
import {
  N as v,
  O as y,
  Q as R,
  V as B,
  X as k,
  Y as w,
  T as z,
  Z as H,
  _ as Z,
  $ as M,
  a0 as Q,
} from "./ToolPage-DS5jbfzr.js";
import { S as C, a as I, b as U, c as E, d as F } from "./select-DC0cHVOZ.js";
import { T as X, a as Y, b as J } from "./tabs-FD1HDlYV.js";
import { T as W } from "./ToolInfoSection-M0kcUBq8.js";
import { u as ee } from "./useLogToolUsage-Z9wjl3dw.js";
import { A as te } from "./arrow-left-right-CUHW6zbL.js";
import "./useUploadApi-CeBVbB2U.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-mA9gIB_c.js";
import "./share-2-wJ7OG3q6.js";
import "./copy-DxyF2bO9.js";
import "./workflowCta-QcLjv4ms.js";
import "./UsageAndUpgradeStrip-Ckl_cEoN.js";
import "./access-BBg1iIm1.js";
import "./useAdminAccess-D2xxeUJv.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-BaZhqv4P.js";
import "./map-pin-DiPhQKiV.js";
import "./FaqSection-DgbFc-d2.js";
import "./ToolVideoEmbed-DltoCXpM.js";
import "./GuideLinks-BsEl-oB0.js";
import "./blog-Cqpj3gtZ.js";
import "./info-BGlOhDp4.js";
import "./productCards-CAZfINO_.js";
import "./layers-B7zHnkyf.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./chevron-up-Bx33pgGu.js";
import "./CollapsibleText-CmqWEytu.js";
import "./copyText-Bf-LRJbj.js";
const _ = y[0].id;
function se(s, a) {
  return s === "cooking"
    ? R(a).units.map((r) => r.name)
    : (v.find((r) => r.id === s)?.units.map((r) => r.name) ?? null);
}
function ae(s) {
  const a = new URLSearchParams(s),
    r = {},
    n = a.get("c");
  if (!n || !v.some((o) => o.id === n)) return r;
  r.category = n;
  const g = a.get("ing");
  n === "cooking" && g && y.some((o) => o.id === g) && (r.ingredient = g);
  const u = se(n, r.ingredient ?? _) ?? [],
    p = a.get("from"),
    l = a.get("to");
  (p && u.includes(p) && (r.from = p), l && u.includes(l) && (r.to = l));
  const m = a.get("v");
  return (
    m !== null &&
      m.trim() !== "" &&
      Number.isFinite(Number(m)) &&
      (r.value = m.trim()),
    r
  );
}
function re(s) {
  const a = new URLSearchParams();
  (a.set("c", s.category),
    s.category === "cooking" &&
      s.ingredient !== _ &&
      a.set("ing", s.ingredient));
  const r = s.fromUnit ?? s.from,
    n = s.toUnit ?? s.to;
  return (
    r && a.set("from", r),
    n && a.set("to", n),
    s.value.trim() !== "" &&
      Number.isFinite(Number(s.value)) &&
      a.set("v", s.value.trim()),
    `?${a.toString()}`
  );
}
const L = {
  what: "Converts values between different units of measurement — length, weight, volume, area, temperature, speed, time, data, pressure, energy, power, angle, frequency, fuel economy and approximate cooking measures (cups, tablespoons and teaspoons to grams for common ingredients) — across metric, US and UK systems.",
  how: "Choose the category of unit you're converting (length, weight, and so on), enter your value, and select the units to convert from and to. The result updates instantly.",
  tip: "Double-check which specific unit variant you need for things like fluid ounces or tons — US and UK definitions differ for several common units, and picking the wrong one gives a subtly wrong answer. Cooking conversions between volume and grams are approximate, because a cup of flour weighs different amounts depending on how it is scooped.",
};
function Pe() {
  const s = B(G().pair),
    [a] = d.useState(() =>
      typeof window > "u" ? {} : ae(window.location.search),
    ),
    r = !s || a.category === s.category,
    [n, g] = d.useState(s?.category ?? a.category ?? "length"),
    [u, p] = d.useState(s?.from ?? a.from ?? ""),
    [l, m] = d.useState(s?.to ?? a.to ?? ""),
    [o, A] = d.useState((r ? a.value : void 0) ?? "1"),
    [N, P] = d.useState(a.ingredient ?? y[0].id),
    h = n === "cooking" ? R(N) : (v.find((t) => t.id === n) ?? v[0]),
    c = h.units.map((t) => t.name),
    i = c.includes(u) ? u : c[0],
    f = c.includes(l) ? l : (c[1] ?? c[0]),
    x = Number(o),
    S = o.trim() !== "" && Number.isFinite(x),
    b =
      S &&
      n === "temperature" &&
      c.includes("kelvin") &&
      k(h, i, "kelvin", x) < -1e-9,
    V = S && !b ? k(h, i, f, x) : NaN,
    j = Number.isFinite(V) ? w(V) : "";
  ee(j && !b ? j : null);
  const O = d.useRef(!1);
  d.useEffect(() => {
    if (!O.current) {
      O.current = !0;
      return;
    }
    try {
      const t = re({
        category: n,
        from: u,
        to: l,
        value: o,
        ingredient: N,
        fromUnit: i,
        toUnit: f,
      });
      window.location.search !== t &&
        window.history.replaceState(
          window.history.state,
          "",
          `${window.location.pathname}${t}${window.location.hash}`,
        );
    } catch {}
  }, [n, u, l, o, N, i, f]);
  const $ = () => {
    (p(f), m(i));
  };
  return e.jsxs(z, {
    children: [
      e.jsx(X, {
        value: n,
        onValueChange: (t) => {
          (g(t), p(""), m(""));
        },
        children: e.jsx(Y, {
          className: "mb-4 flex-wrap h-auto justify-start",
          children: v.map((t) =>
            e.jsx(J, { value: t.id, children: t.label }, t.id),
          ),
        }),
      }),
      n === "cooking" &&
        e.jsxs("div", {
          className: "mb-4 max-w-sm",
          children: [
            e.jsx(T, { children: "Ingredient" }),
            e.jsxs(C, {
              value: N,
              onValueChange: P,
              children: [
                e.jsx(I, {
                  "aria-label": "Ingredient",
                  children: e.jsx(U, {}),
                }),
                e.jsx(E, {
                  children: y.map((t) =>
                    e.jsx(F, { value: t.id, children: t.name }, t.id),
                  ),
                }),
              ],
            }),
            e.jsx("p", {
              className: "mt-1 text-xs text-muted-foreground",
              "data-testid": "cooking-note",
              children:
                "Approximate. Grams per cup change with the brand and with how the cup is filled (spooned, scooped, sifted or packed).",
            }),
          ],
        }),
      e.jsxs("div", {
        className:
          "grid grid-cols-1 md:grid-cols-[1fr_auto_1fr] gap-4 items-end",
        children: [
          e.jsxs("div", {
            children: [
              e.jsx(T, { children: "From" }),
              e.jsxs(C, {
                value: i,
                onValueChange: p,
                children: [
                  e.jsx(I, {
                    "aria-label": "From unit",
                    children: e.jsx(U, {}),
                  }),
                  e.jsx(E, {
                    children: c.map((t) =>
                      e.jsx(F, { value: t, children: t }, t),
                    ),
                  }),
                ],
              }),
              e.jsx(q, {
                type: "number",
                inputMode: h.negative ? void 0 : "decimal",
                value: o,
                onChange: (t) => A(t.target.value),
                placeholder: "Enter value",
                className: "mt-2",
                "aria-label": "Value",
              }),
            ],
          }),
          e.jsx(D, {
            variant: "ghost",
            size: "icon",
            onClick: $,
            "aria-label": "Swap units",
            className: "mb-1",
            children: e.jsx(te, { className: "h-4 w-4" }),
          }),
          e.jsxs("div", {
            children: [
              e.jsx(T, { children: "To" }),
              e.jsxs(C, {
                value: f,
                onValueChange: m,
                children: [
                  e.jsx(I, { "aria-label": "To unit", children: e.jsx(U, {}) }),
                  e.jsx(E, {
                    children: c.map((t) =>
                      e.jsx(F, { value: t, children: t }, t),
                    ),
                  }),
                ],
              }),
              e.jsx("div", {
                className:
                  "mt-2 p-2.5 rounded-md border bg-muted/50 text-lg font-medium min-h-[42px]",
                "data-testid": "unit-result",
                children: j || "—",
              }),
              j &&
                !b &&
                e.jsxs("p", {
                  "data-result": !0,
                  className: "sr-only",
                  children: [w(x), " ", i, " = ", j, " ", f],
                }),
            ],
          }),
        ],
      }),
      b &&
        e.jsx("p", {
          role: "alert",
          className: "mt-3 text-sm text-destructive",
          children:
            "That is below absolute zero (0 K, −273.15 °C, −459.67 °F), the lowest temperature possible.",
        }),
      S &&
        !b &&
        e.jsxs("div", {
          className: "mt-6",
          "data-testid": "unit-all",
          "data-result": !0,
          children: [
            e.jsxs("p", {
              className: "text-sm font-medium mb-2",
              children: [w(x), " ", i, " equals"],
            }),
            e.jsx("ul", {
              className:
                "grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1 text-sm",
              children: h.units
                .filter((t) => t.name !== i)
                .map((t) =>
                  e.jsxs(
                    "li",
                    {
                      className:
                        "flex justify-between border-b border-border/50 py-1",
                      children: [
                        e.jsx("span", {
                          className: "text-muted-foreground",
                          children: t.name,
                        }),
                        e.jsx("span", {
                          className: "font-mono",
                          children: w(k(h, i, t.name, x)),
                        }),
                      ],
                    },
                    t.name,
                  ),
                ),
            }),
          ],
        }),
      s &&
        e.jsxs("section", {
          className: "mt-8",
          "data-testid": "unit-pair-info",
          children: [
            e.jsxs("h2", {
              className: "text-lg font-semibold mb-2",
              children: ["How to convert ", s.label.toLowerCase()],
            }),
            e.jsx("p", {
              className: "text-sm text-muted-foreground mb-4",
              "data-testid": "unit-pair-formula",
              children: H(s),
            }),
            e.jsxs("table", {
              className: "text-sm border-collapse w-full max-w-md",
              "data-testid": "unit-pair-table",
              children: [
                e.jsxs("caption", {
                  className: "text-left text-sm font-medium mb-1",
                  children: [Z(s).replace(" Converter", ""), ": common values"],
                }),
                e.jsx("thead", {
                  children: e.jsxs("tr", {
                    className: "text-left text-xs text-muted-foreground",
                    children: [
                      e.jsx("th", {
                        className: "py-1 font-medium",
                        children: s.from,
                      }),
                      e.jsx("th", { className: "font-medium", children: s.to }),
                    ],
                  }),
                }),
                e.jsx("tbody", {
                  children: M(s).map((t) =>
                    e.jsxs(
                      "tr",
                      {
                        className: "border-t",
                        children: [
                          e.jsx("td", {
                            className: "py-1 tabular-nums",
                            children: t.from,
                          }),
                          e.jsx("td", {
                            className: "tabular-nums",
                            children: t.to,
                          }),
                        ],
                      },
                      t.from,
                    ),
                  ),
                }),
              ],
            }),
          ],
        }),
      e.jsxs("nav", {
        className: "mt-8",
        "aria-label": "Popular conversions",
        "data-testid": "unit-pair-links",
        children: [
          e.jsx("h2", {
            className: "text-lg font-semibold mb-2",
            children: "Popular conversions",
          }),
          e.jsx("ul", {
            className: "flex flex-wrap gap-x-4 gap-y-1 text-sm",
            children: Q.filter((t) => t.slug !== s?.slug).map((t) =>
              e.jsx(
                "li",
                {
                  children: e.jsx(K, {
                    href: `/tool/unit-converter/${t.slug}`,
                    className: "text-primary hover:underline",
                    children: t.label,
                  }),
                },
                t.slug,
              ),
            ),
          }),
        ],
      }),
      e.jsx(W, { whatIsIt: L.what, howToUse: L.how, tip: L.tip }),
    ],
  });
}
export { Pe as default };
//# sourceMappingURL=UnitConverter-D-FDQwuf.js.map
