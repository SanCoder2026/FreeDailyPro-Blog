import { r as n } from "./vendor-react-D01g8YgM.js";
import { aK as E, b0 as b, b1 as h } from "./index-D2ZT81un.js";
import { C as x } from "./copyText-Bf-LRJbj.js";
import { h as C, t as L, v as R } from "./ToolPage-DS5jbfzr.js";
function D(s, S, v) {
  const { known: o, tryUse: p, paid: a, toolId: w, scope: y } = C(),
    c = n.useRef({
      known: o,
      tryUse: p,
      toolId: w,
      scope: y,
      paid: a,
      hasResult: !!s,
    });
  c.current = {
    known: o,
    tryUse: p,
    toolId: w,
    scope: y,
    paid: a,
    hasResult: !!s,
  };
  const r = n.useCallback(async (e = "download") => {
      const t = c.current;
      return !t.known || !t.hasResult || (await t.tryUse()) === "allowed"
        ? !0
        : (E(t.toolId, e), !1);
    }, []),
    g = !!v?.ownActions;
  return (
    n.useEffect(() => {
      L({ active: o, hasResult: !!s, ownActions: g, paid: a, gate: r });
    }, [o, s, g, a, r]),
    n.useEffect(() => () => R(), []),
    n.useEffect(() => {
      if (!o) return;
      const e = typeof navigator < "u" ? navigator.clipboard : void 0,
        t = e?.writeText?.bind(e);
      if (e && t)
        try {
          e.writeText = async (i) => {
            if (!(await r("copy")))
              throw new DOMException(x, "NotAllowedError");
            return t(i);
          };
        } catch {}
      const l = (i) => {
        const f = i.target;
        if (!f?.closest || !f.closest("main")) return;
        const m = f.closest("input, textarea");
        if (
          (m && !m.readOnly) ||
          !c.current.hasResult ||
          !window.getSelection()?.toString()
        )
          return;
        const u = c.current,
          d = b();
        if (!u.paid && !h(u.toolId) && d && d.scope === u.scope && !d.allowed) {
          (i.preventDefault(), E(u.toolId, "copy"));
          return;
        }
        r("copy");
      };
      return (
        document.addEventListener("copy", l, !0),
        () => {
          if ((document.removeEventListener("copy", l, !0), e && t))
            try {
              e.writeText = t;
            } catch {}
        }
      );
    }, [o, r]),
    { blocked: !1, gate: r }
  );
}
export { D as u };
//# sourceMappingURL=useLogToolUsage-Z9wjl3dw.js.map
