      "inch",
      "Centimeters to Inches",
      "cm to in",
    ],
    [
      "inches-to-cm",
      "length",
      "inch",
      "centimeter",
      "Inches to Centimeters",
      "in to cm",
    ],
    ["feet-to-meters", "length", "foot", "meter", "Feet to Meters", "ft to m"],
    ["meters-to-feet", "length", "meter", "foot", "Meters to Feet", "m to ft"],
    [
      "mm-to-inches",
      "length",
      "millimeter",
      "inch",
      "Millimeters to Inches",
      "mm to in",
    ],
    [
      "miles-to-km",
      "length",
      "mile",
      "kilometer",
      "Miles to Kilometers",
      "mi to km",
    ],
    [
      "km-to-miles",
      "length",
      "kilometer",
      "mile",
      "Kilometers to Miles",
      "km to mi",
    ],
    [
      "kg-to-lbs",
      "weight",
      "kilogram",
      "pound",
      "Kilograms to Pounds",
      "kg to lb",
    ],
    [
      "lbs-to-kg",
      "weight",
      "pound",
      "kilogram",
      "Pounds to Kilograms",
      "lb to kg",
    ],
    [
      "ounces-to-grams",
      "weight",
      "ounce",
      "gram",
      "Ounces to Grams",
      "oz to g",
    ],
    [
      "grams-to-ounces",
      "weight",
      "gram",
      "ounce",
      "Grams to Ounces",
      "g to oz",
    ],
    [
      "celsius-to-fahrenheit",
      "temperature",
      "celsius",
      "fahrenheit",
      "Celsius to Fahrenheit",
      "°C to °F",
    ],
    [
      "fahrenheit-to-celsius",
      "temperature",
      "fahrenheit",
      "celsius",
      "Fahrenheit to Celsius",
      "°F to °C",
    ],
    [
      "liters-to-gallons",
      "volume",
      "liter",
      "US gallon",
      "Liters to US Gallons",
      "L to gal",
    ],
    [
      "gallons-to-liters",
      "volume",
      "US gallon",
      "liter",
      "US Gallons to Liters",
      "gal to L",
    ],
    [
      "cups-to-ml",
      "volume",
      "US cup",
      "milliliter",
      "US Cups to Milliliters",
      "cup to ml",
    ],
    [
      "mph-to-kmh",
      "speed",
      "mile/hour",
      "kilometer/hour",
      "Miles per Hour to Kilometers per Hour",
      "mph to km/h",
    ],
    [
      "kmh-to-mph",
      "speed",
      "kilometer/hour",
      "mile/hour",
      "Kilometers per Hour to Miles per Hour",
      "km/h to mph",
    ],
    [
      "sq-ft-to-sq-m",
      "area",
      "sq foot",
      "sq meter",
      "Square Feet to Square Meters",
      "sq ft to m²",
    ],
    [
      "acres-to-hectares",
      "area",
      "acre",
      "hectare",
      "Acres to Hectares",
      "ac to ha",
    ],
  ],
  ga = (e, t) => ({ name: e, toBase: (n) => n * t, fromBase: (n) => n / t }),
  oe = (e, t, n) => ({ id: e, label: t, units: n.map(([a, i]) => ga(a, i)) }),
  wa = [
    oe("length", "Length", [
      ["meter", 1],
      ["kilometer", 1e3],
      ["centimeter", 0.01],
      ["millimeter", 0.001],
      ["micrometer", 1e-6],
      ["nanometer", 1e-9],
      ["mile", 1609.344],
      ["yard", 0.9144],
      ["foot", 0.3048],
      ["inch", 0.0254],
      ["nautical mile", 1852],
    ]),
    oe("weight", "Weight", [
      ["kilogram", 1],
      ["gram", 0.001],
      ["milligram", 1e-6],
      ["microgram", 1e-9],
      ["tonne (metric, 1000 kg)", 1e3],
      ["pound", 0.45359237],
      ["ounce", 0.028349523125],
      ["stone (UK)", 6.35029318],
      ["US ton (short, 2000 lb)", 907.18474],
      ["UK ton (long, 2240 lb)", 1016.0469088],
    ]),
    oe("volume", "Volume", [
      ["liter", 1],
      ["milliliter", 0.001],
      ["cubic meter", 1e3],
      ["cubic centimeter", 0.001],
      ["US gallon", 3.785411784],
      ["US quart", 0.946352946],
      ["US pint", 0.473176473],
      ["US cup", 0.2365882365],
      ["US fluid ounce", 0.0295735295625],
      ["US tablespoon", 0.01478676478125],
      ["US teaspoon", 0.00492892159375],
      ["UK gallon", 4.54609],
      ["UK quart", 1.1365225],
      ["UK pint", 0.56826125],
      ["UK fluid ounce", 0.0284130625],
      ["cubic foot", 28.316846592],
      ["cubic inch", 0.016387064],
    ]),
    oe("area", "Area", [
      ["sq meter", 1],
      ["sq kilometer", 1e6],
      ["sq centimeter", 1e-4],
      ["sq millimeter", 1e-6],
      ["hectare", 1e4],
      ["acre", 4046.8564224],
      ["sq mile", 2589988110336e-6],
      ["sq yard", 0.83612736],
      ["sq foot", 0.09290304],
      ["sq inch", 64516e-8],
    ]),
    {
      id: "temperature",
      label: "Temperature",
      negative: !0,
      units: [
        { name: "celsius", toBase: (e) => e, fromBase: (e) => e },
        {
          name: "fahrenheit",
          toBase: (e) => ((e - 32) * 5) / 9,
          fromBase: (e) => (e * 9) / 5 + 32,
        },
        {
          name: "kelvin",
          toBase: (e) => e - 273.15,
          fromBase: (e) => e + 273.15,
        },
        {
          name: "rankine",
          toBase: (e) => ((e - 491.67) * 5) / 9,
          fromBase: (e) => ((e + 273.15) * 9) / 5,
        },
      ],
    },
    oe("speed", "Speed", [
      ["meter/second", 1],
      ["kilometer/hour", 1 / 3.6],
      ["mile/hour", 0.44704],
      ["knot", 1852 / 3600],
      ["foot/second", 0.3048],
    ]),
    oe("time", "Time", [
      ["second", 1],
      ["millisecond", 0.001],
      ["minute", 60],
      ["hour", 3600],
      ["day", 86400],
      ["week", 604800],
      ["year (365.25 days)", 31557600],
    ]),
    oe("data", "Data", [
      ["bit", 0.125],
      ["byte", 1],
      ["kilobyte (1000 B)", 1e3],
      ["megabyte (1000² B)", 1e6],
      ["gigabyte (1000³ B)", 1e9],
      ["terabyte (1000⁴ B)", 1e12],
      ["kibibyte (1024 B)", 1024],
      ["mebibyte (1024² B)", 1048576],
      ["gibibyte (1024³ B)", 1073741824],
      ["tebibyte (1024⁴ B)", 1099511627776],
    ]),
    oe("pressure", "Pressure", [
      ["pascal", 1],
      ["kilopascal", 1e3],
      ["bar", 1e5],
      ["psi", 6894.757293168],
      ["atmosphere", 101325],
      ["mmHg", 133.322387415],
    ]),
    oe("energy", "Energy", [
      ["joule", 1],
      ["kilojoule", 1e3],
      ["calorie (small)", 4.184],
      ["kilocalorie (food Calorie)", 4184],
      ["watt-hour", 3600],
      ["kilowatt-hour", 36e5],
      ["BTU", 1055.05585262],
      ["foot-pound", 1.3558179483314003],
    ]),
    oe("power", "Power", [
      ["watt", 1],
      ["kilowatt", 1e3],
      ["megawatt", 1e6],
      ["horsepower (mechanical)", (33e3 * 0.3048 * 0.45359237 * 9.80665) / 60],
      ["horsepower (metric)", 75 * 9.80665],
      ["BTU/hour", 1055.05585262 / 3600],
    ]),
    {
      ...oe("angle", "Angle", [
        ["degree", 1],
        ["radian", 180 / Math.PI],
        ["gradian", 0.9],
        ["arcminute", 1 / 60],
        ["arcsecond", 1 / 3600],
        ["turn (revolution)", 360],
      ]),
      negative: !0,
    },
    oe("frequency", "Frequency", [
      ["hertz", 1],
      ["kilohertz", 1e3],
      ["megahertz", 1e6],
      ["gigahertz", 1e9],
      ["revolutions/minute (rpm)", 1 / 60],
    ]),
    {
      id: "fuel",
      label: "Fuel economy",
      units: [
        { name: "liters/100 km", toBase: (e) => e, fromBase: (e) => e },
        { name: "km/liter", toBase: (e) => 100 / e, fromBase: (e) => 100 / e },
        {
          name: "miles/gallon (US)",
          toBase: (e) => 235.214583333 / e,
          fromBase: (e) => 235.214583333 / e,
        },
        {
          name: "miles/gallon (UK)",
          toBase: (e) => 282.480936331 / e,
          fromBase: (e) => 282.480936331 / e,
        },
      ],
    },
  ],
  It = [
    { id: "flour", name: "all-purpose flour", gramsPerCup: 120 },
    { id: "sugar", name: "granulated sugar", gramsPerCup: 200 },
    { id: "brown-sugar", name: "brown sugar (packed)", gramsPerCup: 213 },
    { id: "powdered-sugar", name: "powdered sugar", gramsPerCup: 120 },
    { id: "butter", name: "butter", gramsPerCup: 227 },
    { id: "honey", name: "honey", gramsPerCup: 339 },
    { id: "milk", name: "whole milk", gramsPerCup: 244 },
    { id: "oil", name: "vegetable oil", gramsPerCup: 218 },
    { id: "water", name: "water", gramsPerCup: 236.5882365 },
  ],
  Ke = 236.5882365;
function ci(e = It[0].id) {
  const n = (It.find((d) => d.id === e) ?? It[0]).gramsPerCup / Ke,
    a = (d, h) => ga(d, h),
    i = (d, h) => ({
      name: d,
      toBase: (l) => (l * h) / n,
      fromBase: (l) => (l * n) / h,
    });
  return {
    id: "cooking",
    label: "Cooking (approx.)",
    units: [
      a("US cup", Ke),
      a("US tablespoon", Ke / 16),
      a("US teaspoon", Ke / 48),
      a("milliliter", 1),
      i("gram", 1),
      i("ounce (weight)", 28.349523125),
    ],
  };
}
wa.push(ci());
function ui(e, t, n, a) {
  const i = e.units.find((h) => h.name === t),
    d = e.units.find((h) => h.name === n);
  return !i || !d ? NaN : d.fromBase(i.toBase(a));
}
function Se(e, t) {
  if (!Number.isFinite(e)) return "—";
  if (e === 0) return "0";
  const n = Math.abs(e);
  return n < 1e-6 || n >= 1e15
    ? e
        .toExponential(6)
        .replace(/\.?0+e/, "e")
        .replace("e+", "e")
    : new Intl.NumberFormat(t, { maximumSignificantDigits: 10 }).format(
        Number(e.toPrecision(10)),
      );
}
const pi = hi.map(([e, t, n, a, i, d]) => ({
  slug: e,
  category: t,
  from: n,
  to: a,
  label: i,
  abbr: d,
}));
function mi(e) {
  return e ? pi.find((t) => t.slug === e) : void 0;
}
const gi = (e) => wa.find((t) => t.id === e.category),
  Qt = (e, t) => ui(gi(e), e.from, e.to, t);
function wi(e) {
  return `${e.label} Converter`;
}
function fi(e) {
  const t = `${e.label} Converter (${e.abbr})`;
  return t.length <= 60 ? t : `${e.label} Converter`;
}
function yi(e) {
  const t = `${e.label}: 1 ${e.from} = ${Se(Qt(e, 1))} ${e.to}. Enter any value for an instant answer, with the formula and a table of common values. Runs in your browser.`;
  return t.length <= 160
    ? t
    : `${e.label}: enter any value for an instant answer, with the formula and a table of common values. Runs in your browser.`;
}
function bi(e) {
  return e.category === "temperature"
    ? e.from === "celsius"
      ? [-40, -10, 0, 20, 37, 100, 180, 200]
      : [-40, 0, 32, 68, 98.6, 212, 350, 400]
    : e.from === "US cup"
      ? [0.25, 0.33, 0.5, 0.75, 1, 1.5, 2, 4]
      : e.from === "acre"
        ? [0.25, 0.5, 1, 2, 5, 10, 50, 100]
        : [1, 2, 5, 10, 20, 25, 50, 100, 500, 1e3];
}
function Bl(e) {
  return bi(e).map((t) => ({ from: Se(t), to: Se(Qt(e, t)) }));
}
function Vl(e) {
  if (e.category === "temperature")
    return e.from === "celsius"
      ? "°F = °C × 9/5 + 32. Multiply the Celsius value by 1.8 and add 32."
      : "°C = (°F − 32) × 5/9. Subtract 32 from the Fahrenheit value, then multiply by 5/9 (about 0.5556).";
  const t = Qt(e, 1),
    n = 1 / t;
  return `Multiply the ${e.from} value by ${Se(t)} to get ${e.to}, or divide by ${Se(Number(n.toPrecision(10)))}. So 1 ${e.from} = ${Se(t)} ${e.to}.`;
}
const vi = JSON.parse(
    `[{"slug":"png-to-jpg","tool":"convert-image","from":"png","to":"jpg","summary":"Turn a PNG into a small JPG, with a fill colour for see-through areas.","why":"People convert PNG to JPG when a site, form or email rejects PNG or when a screenshot or photo saved as PNG is too heavy to upload. JPG stores photographs in a fraction of the space, but it cannot be see-through, so any transparent part of the PNG is painted with a colour you choose (white by default) before saving.","size":"A photographic PNG commonly shrinks to a fifth or less of its size as a JPG. A flat graphic or screenshot with big blocks of one colour shrinks less and can even grow, because PNG already handles flat colour well.","faq":["Why does my transparent PNG get a white background as JPG?","JPG has no transparency at all, so something has to fill the see-through pixels. The fill colour picker appears as soon as the PNG has transparency; pick the colour of the page the picture will sit on, or keep PNG if you need the transparency."]},{"slug":"jpg-to-png","tool":"convert-image","from":"jpg","to":"png","summary":"Save a JPG as a lossless PNG that opens anywhere and can be edited without further loss.","why":"JPG to PNG is for a picture you are about to edit again and again, or a program or print shop that wants PNG. PNG never throws detail away when it is saved, so each re-save keeps exactly what you started with. It cannot bring back detail the JPG already lost, and it cannot add a transparent background by itself.","size":"Expect the PNG to be several times larger than the JPG, often three to ten times for a photo, because PNG stores every pixel without the JPG's lossy shortcuts.","faq":["Will converting JPG to PNG make my photo sharper?","No. The blocky softness JPG compression added is already in the pixels, and PNG keeps those pixels exactly. Converting only stops further loss from future saves; to improve a blurry JPG you need an enhancer, not a format change."]},{"slug":"webp-to-jpg","tool":"convert-image","from":"webp","to":"jpg","summary":"Open a WebP that your program refuses by saving it as a normal JPG.","why":"Many images saved from the web arrive as WebP, which some editors, printers, marketplaces and upload forms still reject. Converting to JPG gives a file every program accepts. Because JPG cannot be see-through, a WebP with a transparent background is filled with a colour you pick, white by default.","size":"At high quality a JPG made from a WebP is usually somewhat larger than the WebP, since WebP is the more efficient format. Lower the quality slider if the size matters.","faq":["What happens to an animated WebP?","Only the first frame is converted, and the page tells you so when it detects an animation. A JPG cannot move; for an animation use Convert Video on a video version of the clip or keep the WebP."]},{"slug":"webp-to-png","tool":"convert-image","from":"webp","to":"png","summary":"Convert a WebP to PNG and keep its transparent background intact.","why":"WebP to PNG is the right choice over JPG when the WebP is a logo, sticker or cut-out with a see-through background, because PNG keeps transparency while JPG cannot. It is also the safe format for editing software that has no WebP support, since PNG is lossless and opens everywhere.","size":"PNG is usually larger than the WebP it came from, sometimes two to five times for photographs. For a flat logo the difference is small.","faq":["Will the PNG be identical to the WebP?","The pixels are the same as the WebP shows. If the WebP was saved lossy, its compression artefacts are part of those pixels and PNG keeps them exactly; if it was lossless, the PNG is a perfect copy."]},{"slug":"png-to-webp","tool":"convert-image","from":"png","to":"webp","summary":"Shrink a PNG into a WebP for faster web pages, keeping transparency.","why":"Converting PNG to WebP is mostly done for websites: smaller images load faster, especially on phones. WebP keeps the transparent background that makes PNG useful for logos and cut-outs, and at the default quality the result looks the same to the eye.","size":"Screenshots and graphics often drop by half or more; photographs saved as PNG can shrink dramatically, often to a fifth or less at a good quality setting.","faq":["Does this need a special browser?","Writing WebP needs a browser that can encode it, which Chrome, Edge and Firefox do. If yours cannot, the page says so before you convert rather than saving a PNG under a .webp name."]},{"slug":"jpg-to-webp","tool":"convert-image","from":"jpg","to":"webp","summary":"Make a JPG photo smaller as WebP for quicker websites.","why":"JPG to WebP is a web-speed conversion: the same photo at a similar look in a smaller file. Because the JPG is already compressed, converting adds a second round of lossy compression, so keep quality high (90 or above) for photos you care about and keep your original JPG as the master.","size":"Most photos come out around a quarter to a third smaller at matching quality. Pushing the slider lower saves more but the second compression starts to show in smooth areas such as skies.","faq":["Is it worth converting a JPG that is already small?","Often not. The saving is a percentage of the file, so a 40 KB JPG gains little and still pays the cost of a second lossy pass. Convert the big hero and gallery images first."]},{"slug":"avif-to-jpg","tool":"convert-image","from":"avif","to":"jpg","summary":"Turn an AVIF into a JPG that any program, printer or form will accept.","why":"AVIF files give the smallest web images, but most desktop software, printers and upload forms cannot open them yet. Converting to JPG gives you a file that works everywhere. Reading an AVIF needs a browser that supports it; if yours does not, the page says so instead of failing silently.","size":"The JPG will be larger than the AVIF, commonly by half again to twice as much at similar looks, because AVIF is currently the most efficient format.","faq":["Why is my AVIF not opening here?","Reading AVIF depends on your browser, not on this page. Current Chrome, Edge, Firefox and Safari open it; older versions do not. Try another browser and the same file converts."]},{"slug":"svg-to-png","tool":"convert-image","from":"svg","to":"png","summary":"Render an SVG logo or icon as a PNG, with its transparent background kept.","why":"SVG to PNG turns a vector logo or icon into pixels for places that cannot take SVG, such as most social networks, email signatures, slide decks and marketplaces. The SVG is drawn at the width and height it declares, and the PNG keeps the empty background transparent.","size":"A small icon becomes a PNG of a few kilobytes. Large illustrations with gradients can be bigger than the SVG, because the PNG stores every pixel instead of a few shapes.","faq":["How do I get a bigger, sharp PNG from an SVG?","The picture is drawn at the size written inside the SVG (300 by 150 when it declares none), and the resize options scale those pixels afterwards. For a large sharp PNG, raise the width and height in the SVG file first, then convert."]},{"slug":"bmp-to-png","tool":"convert-image","from":"bmp","to":"png","summary":"Convert a huge BMP to a lossless PNG that looks identical and takes far less space.","why":"BMP stores every pixel with no compression at all, so files are enormous. PNG compresses without losing a single pixel, so a BMP to PNG conversion gives exactly the same picture in a much smaller file that every modern program, website and email accepts.","size":"A BMP typically shrinks to between a tenth and a half of its size as a PNG, with no change in appearance; screenshots and drawings with flat colour shrink the most.","faq":["Is any quality lost converting BMP to PNG?","No. Both formats are lossless, so the pixels come out identical. The picture is read as the browser shows it and written pixel for pixel."]},{"slug":"tiff-to-jpg","tool":"convert-image","from":"tiff","to":"jpg","summary":"Turn a TIFF scan or print file into a small JPG for sharing and uploading.","why":"TIFF is made for scanners and print production, and browsers, phones and most online forms cannot show it. Converting to JPG makes the picture shareable and a fraction of the size. The first page of a multi-page TIFF is converted, and any transparency is filled with the colour you choose.","size":"TIFF files are often tens of megabytes; as a JPG at high quality they are typically a tenth or less of that.","faq":["What about a TIFF with several pages?","Only the first page is converted. For a multi-page scan, split it into single pages in your scanning software first, or convert the document to PDF there."]},{"slug":"heic-to-png","tool":"convert-image","from":"heic","to":"png","summary":"Convert iPhone HEIC photos to lossless PNG files.","why":"HEIC is what iPhones and iPads save by default, and Windows programs and many websites cannot read it. HEIC to JPG is the usual answer, but PNG is the better pick when you will edit the photo further or need a lossless copy. The photo is turned upright using the orientation the camera stored.","size":"A PNG made from a HEIC photo is very large, often five to ten times the HEIC, because PNG stores the whole photo without any lossy saving. Choose JPG when you just need something small to send.","faq":["Are location and camera details kept?","No. PNG does not carry the camera and GPS data a HEIC holds, and the page removes metadata by default, which is also handy before you post a photo online."]},{"slug":"gif-to-png","tool":"convert-image","from":"gif","to":"png","summary":"Split an animated GIF into one PNG per frame, or save a still as PNG.","why":"GIF to PNG on this page does two jobs. For a still GIF it gives one lossless PNG. For an animated GIF it can save every frame as its own numbered PNG inside a ZIP, with each frame composed the way the animation shows it, which is the quickest way to pull stills or sprites out of a loop.","size":"One PNG per frame adds up: a 60-frame GIF becomes 60 files whose combined size is usually several times the GIF's, because the GIF shares colours across frames and compresses them together.","faq":["Does it keep the animation?","No, a PNG cannot animate. You choose between all frames as separate numbered PNGs in a ZIP or only the first frame. To keep it moving, convert the GIF to a video instead."]},{"slug":"png-to-ico","tool":"convert-image","from":"png","to":"ico","summary":"Make a multi-size ICO favicon or Windows icon from a PNG.","why":"PNG to ICO builds the icon file websites use as a favicon and Windows uses for programs. One ICO can hold several sizes at once (16, 32 and 48 pixels by default) so the right one is picked everywhere from browser tabs to the taskbar. Start from a square PNG at least as large as your biggest size.","size":"An ICO with three small sizes is only a few kilobytes. Adding 128 or 256 pixel sizes makes the file larger because each size is stored separately.","faq":["Which sizes should I include for a website favicon?","16, 32 and 48 pixels cover browser tabs, bookmarks and shortcuts, and are ticked by default. Add 64 or larger only for desktop shortcuts; most sites also add a separate 180 pixel PNG for iPhones."]},{"slug":"wav-to-mp3","tool":"audio-converter","from":"wav","to":"mp3","summary":"Shrink a WAV recording to an MP3 a tenth of the size.","why":"WAV to MP3 is how a recording, voice memo or exported mix becomes small enough to email, upload or put on a phone. WAV holds every sample uncompressed; MP3 discards what the ear notices least. Because a WAV is lossless, the converter uses 192 kbps by default, with higher and lower presets.","size":"One minute of CD-quality WAV is about 10 MB; at 192 kbps the MP3 is about 1.4 MB, roughly a seventh of the size.","faq":["Can I get the WAV back later?","Not exactly. MP3 permanently drops some audio detail, so keep the WAV if it is a master. Converting the MP3 back to WAV gives a big file that sounds like the MP3, not like the original."]},{"slug":"mp3-to-wav","tool":"audio-converter","from":"mp3","to":"wav","summary":"Decode an MP3 to uncompressed WAV for editors, DJ software and samplers.","why":"MP3 to WAV is for software that wants uncompressed audio: sample editors, some DJ and video programs, and hardware samplers. The WAV holds exactly what the MP3 decodes to, so it will not sound better than the MP3, but editing and re-saving it no longer adds new MP3 compression.","size":"Expect about ten times the size: a 1 MB MP3 becomes a WAV of roughly 10 MB, because WAV stores every sample without compression.","faq":["Does converting to WAV improve MP3 quality?","No. The detail MP3 threw away is gone for good. WAV only stops further loss while you edit; if you have the original recording, convert that instead."]},{"slug":"flac-to-mp3","tool":"audio-converter","from":"flac","to":"mp3","summary":"Convert lossless FLAC music to MP3 for phones, cars and players that lack FLAC.","why":"FLAC to MP3 makes a portable copy of a lossless library for devices that do not play FLAC or have little storage. Since FLAC is lossless the converter uses 192 kbps by default; choose a higher setting for demanding listening. Your FLAC tags and cover picture are carried into the MP3.","size":"A FLAC is roughly half the size of the WAV it came from. At 192 kbps the MP3 is about a quarter to a fifth of the FLAC.","faq":["Should I delete my FLAC files after converting?","Keep them. FLAC is the master and MP3 is a lossy copy; you can always make a new MP3 from the FLAC, but never the reverse."]},{"slug":"m4a-to-mp3","tool":"audio-converter","from":"m4a","to":"mp3","summary":"Convert M4A audio from iPhones and iTunes to the universal MP3.","why":"M4A is what iPhone voice memos, iTunes purchases and many downloaded videos use, and plenty of car stereos, older players and upload forms accept only MP3. The conversion decodes the AAC audio and re-encodes it as MP3 at the original's own bitrate, with title, artist, album and cover art carried across.","size":"M4A and MP3 at the same bitrate are close in size; the MP3 may be a little larger because AAC is the more efficient codec.","faq":["Is there a quality loss from M4A to MP3?","Yes, a small one: both formats are lossy, so the audio is compressed a second time. Keep the bitrate at or above the M4A's (the default does) and the difference is hard to hear for most material."]},{"slug":"ogg-to-mp3","tool":"audio-converter","from":"ogg","to":"mp3","summary":"Turn OGG Vorbis files into MP3 for players and phones that cannot open OGG.","why":"OGG is common in games, Linux software and some Android recordings, but iPhones, many car stereos and plenty of editors do not play it. OGG to MP3 gives a file that works everywhere. Both formats are lossy, so the conversion keeps the original's bitrate to limit extra loss.","size":"At a matching bitrate the MP3 is about the same size as the OGG, sometimes slightly larger since Vorbis is a little more efficient.","faq":["Are the tags kept?","Yes. Title, artist and album are copied across into the MP3's tags. Anything unusual in the OGG comments that MP3 has no field for is dropped."]},{"slug":"aac-to-mp3","tool":"audio-converter","from":"aac","to":"mp3","summary":"Convert raw AAC audio files to MP3 so every player can open them.","why":"A .aac file is a bare AAC stream with no container around it, typically from a voice recorder, a radio capture or an old phone. Many players, editors and upload forms do not recognise it. AAC to MP3 wraps the sound in the most compatible format there is, decoding the stream and encoding MP3 at its own bitrate.","size":"Close to the AAC's size. A 64 kbps recording gives a small MP3 of about 0.5 MB per minute of speech, and slightly larger at the same bitrate since AAC is the more efficient codec.","faq":["Why is there no cover art or title?","Raw AAC streams carry almost no tags to begin with, so there is nothing to copy. Add title and artist in a tag editor after converting."]},{"slug":"wma-to-mp3","tool":"audio-converter","from":"wma","to":"mp3","summary":"Rescue old WMA music and recordings by converting them to MP3.","why":"WMA was Windows Media Player's format and little else plays it: phones, cars and most web players refuse it. WMA to MP3 frees an old library. The audio is decoded in your browser and re-encoded as MP3, and songs protected with Windows DRM cannot be converted by any tool.","size":"Roughly the same as the WMA at a matching bitrate. WMA was often ripped at low bitrates, so a 64 or 96 kbps WMA gives a small MP3 that sounds no better than the source.","faq":["Why does my WMA fail to convert?","Files bought with copy protection are encrypted, and no converter can open them. If an unprotected WMA fails, it may be damaged; the page shows an error without using any of your daily tries."]},{"slug":"mp3-to-m4a","tool":"audio-converter","from":"mp3","to":"m4a","summary":"Convert MP3 to M4A (AAC) for iPhone ringtones, Apple Music and smaller files.","why":"MP3 to M4A is used for Apple software that prefers AAC, for ringtone workflows and for audiobook apps. M4A files hold chapters and bookmarks better than MP3. Both are lossy, so choose the same or a higher quality than the MP3 to avoid hearing a second round of compression.","size":"At the same bitrate the sizes are about equal. AAC sounds slightly better, so you can sometimes drop one bitrate step and still match the MP3.","faq":["Will my cover art and tags carry over?","Yes. Title, artist, album and the cover picture are copied into the M4A, so the file looks the same in your music app as the MP3 did."]},{"slug":"wav-to-flac","tool":"audio-converter","from":"wav","to":"flac","summary":"Compress WAV to FLAC and save about half the space with zero audio loss.","why":"WAV to FLAC is the archiving move: the sound is bit-for-bit identical when you play it back, but the file is roughly half the size and, unlike WAV, can store full tags and a cover picture. It is the format to choose for masters and music collections you may convert again later.","size":"FLAC is typically 50 to 60 percent of the WAV's size. Quiet or simple recordings compress more; dense noisy music compresses less.","faq":["Is FLAC really lossless?","Yes. Decoding a FLAC gives back exactly the samples that went in, which is why it can safely be your archive format and still be converted to MP3 or WAV later."]},{"slug":"flac-to-wav","tool":"audio-converter","from":"flac","to":"wav","summary":"Decode FLAC to WAV for editors, CD burning and hardware that wants uncompressed audio.","why":"FLAC to WAV unpacks lossless audio for software and devices that do not read FLAC, such as older editors, CD authoring tools and some hardware. Nothing is lost: the WAV holds exactly the samples in the FLAC. The cover picture is left behind and tags are limited, because WAV has little room for them.","size":"The WAV is about twice the size of the FLAC, typically 1.7 to 2 times, since it stores the samples without compression.","faq":["Is the sound the same?","Identical. Both are lossless, so the WAV plays back exactly as the FLAC did. Only extras such as the embedded cover art are not carried into a WAV, and tags are limited."]},{"slug":"mov-to-mp4","tool":"convert-video","from":"mov","to":"mp4","summary":"Convert an iPhone or Mac MOV to MP4, often in seconds with no quality loss.","why":"MOV is what iPhones and Macs record, and Windows players, editors and many sites struggle with it. When the MOV holds standard H.264 video with AAC sound, it is repackaged into an MP4 in seconds without re-encoding, so quality is unchanged. HEVC (H.265) clips are re-encoded to H.264 so they play everywhere.","size":"A repackaged MOV gives an MP4 of almost exactly the same size. A re-encoded HEVC clip may come out larger, because H.264 needs more data than HEVC for the same quality.","faq":["Why did my MP4 get bigger than the MOV?","iPhones often record HEVC, which is more compact than the H.264 inside most MP4s. Converting to widely playable H.264 can grow the file. The result line on the page tells you whether the video was repackaged or re-encoded."]},{"slug":"avi-to-mp4","tool":"convert-video","from":"avi","to":"mp4","summary":"Convert old AVI videos to MP4 so phones, TVs and websites play them.","why":"AVI is a 1990s container that phones, tablets and web uploads often reject. Converting to MP4 re-encodes the video to H.264 and the sound to AAC, which brings it to every device. AVI files are usually old codecs such as DivX or Xvid, so the video is re-encoded rather than just repackaged.","size":"Often smaller, since H.264 is more efficient than the DivX or Xvid typically inside AVI; an uncompressed or low-compression AVI shrinks dramatically.","faq":["Will the picture quality drop?","The video is re-encoded, which is lossy, but the encoder runs at a high-quality setting (CRF 23) that is visually close to the source for typical AVI footage."]},{"slug":"mkv-to-mp4","tool":"convert-video","from":"mkv","to":"mp4","summary":"Convert MKV to MP4 for QuickTime, phones and editors, often without re-encoding.","why":"MKV holds almost anything, but iPhones, QuickTime and most editors will not open it. If the MKV contains H.264 video and AAC sound, the streams are copied into an MP4 in seconds with no quality loss. Other codecs are re-encoded. MP4 holds one audio track here, so extra languages and subtitle tracks are not carried over.","size":"A repackaged file is about the same size as the MKV. A re-encoded file depends on the original codec: a HEVC MKV usually grows, an older Xvid one shrinks.","faq":["What happens to extra audio tracks and subtitles?","The first video and audio tracks are used. Additional language tracks and subtitles in the MKV are not copied to the MP4, so keep the MKV if you need them."]},{"slug":"webm-to-mp4","tool":"convert-video","from":"webm","to":"mp4","summary":"Convert WebM screen recordings and web videos to MP4 for any device.","why":"WebM comes from browser screen recorders and web downloads, and many phones, editors and social uploads do not accept it. Converting to MP4 re-encodes the VP8/VP9 video to H.264 with AAC sound, so it plays in every app. Re-encoding always costs a little quality, which the encoder keeps small.","size":"MP4 (H.264) is often larger than WebM for the same quality, sometimes by a third or more, which is normal and noted on the result.","faq":["Why is conversion slower than for MOV files?","WebM cannot just be repackaged into MP4 because its codecs are different, so every frame is re-encoded in your browser. A short clip takes seconds; a long recording takes much longer."]},{"slug":"wmv-to-mp4","tool":"convert-video","from":"wmv","to":"mp4","summary":"Convert Windows Media WMV videos to MP4 for Macs, phones and the web.","why":"WMV is Microsoft's Windows Media Video format, found in old PowerPoint exports, camcorder clips and corporate training files. Macs, iPhones and most websites will not play it. Converting to MP4 rewrites the picture as H.264 and the sound as AAC so the clip opens on any device and can be uploaded anywhere.","size":"Often a third smaller or more, since H.264 is far more efficient than the WMV codecs; a high-bitrate WMV from a camcorder shrinks the most.","faq":["Can a WMV with copy protection be converted?","No. A WMV protected with Windows DRM is encrypted and no converter, in the browser or elsewhere, can open it. Ordinary unprotected WMV files convert normally."]},{"slug":"flv-to-mp4","tool":"convert-video","from":"flv","to":"mp4","summary":"Convert Flash FLV videos to MP4 so they play again.","why":"FLV was the format of Flash-era web players, and no current browser plays it. Old downloaded clips, early YouTube-style archives and screen-capture files are the usual sources. Converting to MP4 gives a modern H.264 file that plays in any browser or phone, without needing Flash or special software.","size":"FLV clips were made small and low-resolution, so the MP4 is similar in size, and can be slightly larger when the original used a very low bitrate.","faq":["Can the converter make an old low-resolution FLV look better?","No. It converts what is in the file, so a 320 by 240 clip stays 320 by 240 and will look soft when played full screen."]},{"slug":"mp4-to-webm","tool":"convert-video","from":"mp4","to":"webm","summary":"Convert MP4 to WebM for web pages that need a .webm file.","why":"Convert MP4 to WebM when a website, CMS or embed specifically asks for WebM or when you want an open format that browsers play without patent concerns. This is always a re-encode to VP8 video and Vorbis sound, capped at 1280 pixels wide, so it takes noticeably longer than an MP4 conversion.","size":"Short clips often come out bigger as WebM because the encoder is tuned for speed in your browser. For plain websites an MP4 is usually smaller and plays everywhere.","faq":["Should I use WebM or MP4 for my website?","MP4 plays in every browser and on every phone, so it is the safer default. Use WebM only if a platform requires it or you want an open format with no licence fees."]},{"slug":"mp4-to-mov","tool":"convert-video","from":"mp4","to":"mov","summary":"Convert MP4 to MOV for Final Cut, iMovie and QuickTime.","why":"MP4 to MOV is for Apple editing apps and workflows that ask for QuickTime files. If the MP4 holds H.264 video with AAC sound it is simply repackaged as MOV in seconds with no quality change. It does not turn the video into ProRes or another editing codec.","size":"A repackaged file is essentially the same size as the MP4, within a fraction of a percent.","faq":["Does MOV give better quality than MP4?","No. MOV and MP4 are containers; the quality comes from the codec inside. A repackaged MOV is the same picture as the MP4."]},{"slug":"mp4-to-mkv","tool":"convert-video","from":"mp4","to":"mkv","summary":"Repackage MP4 as MKV with no re-encoding when the video is H.264.","why":"MP4 to MKV is used for media servers, players and archives that prefer Matroska, or to prepare a file for tools that expect it. For H.264 video with AAC sound the streams are copied unchanged into the MKV in seconds, so there is no quality loss. Other codecs are re-encoded to H.264.","size":"Practically the same as the MP4 when repackaged; MKV adds a tiny amount of container overhead and sometimes saves a little.","faq":["Will the MKV play on my TV or phone?","Not always. MKV is supported by VLC and many TVs, but iPhones and QuickTime will not play it. If the target is a phone, stay with MP4."]},{"slug":"mp4-to-avi","tool":"convert-video","from":"mp4","to":"avi","summary":"Convert MP4 to AVI for older players and legacy software.","why":"MP4 to AVI is for old DVD players, car entertainment systems and legacy programs that only read AVI. The video is re-encoded to MPEG-4 and the sound to MP3, which is the combination those older devices handle best. It is a conversion of last resort, because AVI files are larger than MP4 for the same quality.","size":"Expect an AVI about one and a half to three times the size of the MP4, as MPEG-4 Part 2 is less efficient than H.264.","faq":["Why is my AVI so much bigger?","Compatibility with old devices is what AVI is chosen for, and the older MPEG-4 codec needs more data per second than H.264. If size matters more than the old player, keep the MP4."]},{"slug":"gif-to-mp4","tool":"convert-video","from":"gif","to":"mp4","summary":"Turn an animated GIF into an MP4 that is many times smaller and plays smoothly.","why":"GIF to MP4 replaces a heavy looping GIF with a normal video. Websites and apps play the MP4 more smoothly and use far less data, which is why large platforms convert GIFs to video themselves. The output has no sound because a GIF has none, and the picture size is rounded to even numbers as video requires.","size":"A GIF often becomes an MP4 one tenth to one twentieth of its size, since video compression shares information between frames far better than GIF can.","faq":["Will the MP4 loop like the GIF?","The file contains one play-through. Most players, social posts and website video tags have a loop option; the video format itself does not loop forever the way a GIF does."]},{"slug":"mp4-to-mp3","tool":"extract-audio","from":"mp4","to":"mp3","summary":"Pull the sound from an MP4 video and save it as an MP3.","why":"MP4 to MP3 keeps just the sound of a video: a lecture, interview, concert recording or music video. The picture is dropped and the audio is encoded as MP3, so a video file of hundreds of megabytes becomes a few megabytes. You can take the whole video or just a time range.","size":"An hour of speech is roughly 40 to 60 MB as variable-quality MP3 and about 55 MB at 128 kbps, regardless of how large the video was.","faq":["Can I extract only part of the video?","Yes. Tick the time range option and drag the slider or type exact start and end times; only that section is saved."]},{"slug":"mov-to-mp3","tool":"extract-audio","from":"mov","to":"mp3","summary":"Extract the audio of an iPhone or Mac MOV recording as an MP3.","why":"MOV to MP3 turns an iPhone video, screen recording or Zoom-style capture into a plain audio file you can listen to or share as a podcast or voice note. The sound track is taken out and encoded as MP3 in your browser. If a MOV uses an unusual codec and fails, re-exporting from your phone first helps.","size":"The MP3 is tiny compared with the MOV: a one-minute iPhone video of 100 MB or more gives about 1 MB of audio.","faq":["Why do I get 'no audio track' on a MOV?","The video genuinely has no sound, for example a muted screen recording. The page checks the file as it loads and tells you immediately, and no daily try is used."]},{"slug":"mkv-to-mp3","tool":"extract-audio","from":"mkv","to":"mp3","summary":"Save the audio track of an MKV as an MP3, for films, concerts and downloads.","why":"MKV to MP3 extracts the sound of a concert recording, lecture or ripped video as a small MP3. Matroska files often carry several audio tracks, and the first track is the one used. If it is the wrong language, use a player to check the track order before converting.","size":"A small fraction of the MKV. A two-hour film audio track at 192 kbps is roughly 170 MB; at 128 kbps about 115 MB.","faq":["Can I choose a different audio track?","The first audio track in the file is used. Files with commentary or other languages as track one need a media player to reorder them first."]},{"slug":"webm-to-mp3","tool":"extract-audio","from":"webm","to":"mp3","summary":"Convert the audio of a WebM recording or web video to MP3.","why":"WebM to MP3 is common for browser recordings and web downloads, where the sound is wanted without the picture. WebM audio is Opus or Vorbis, which many players cannot open, so it is decoded and saved as an MP3 that opens anywhere.","size":"Small. WebM audio is already compact, and the MP3 is generally of similar size, roughly 1 MB per minute at 128 kbps.","faq":["Is there a way to keep the original audio without converting?","Yes. The Original audio option copies the sound exactly as it is, instantly, without re-encoding. If its codec has no plain file type, it saves an MP3 and says so."]},{"slug":"avi-to-mp3","tool":"extract-audio","from":"avi","to":"mp3","summary":"Extract the sound from an AVI video as an MP3.","why":"AVI to MP3 pulls the audio from old camcorder footage, home videos and downloaded clips. AVI files often use an MP3 or AC3 sound track already, but it is wrapped inside the video, and this separates it into a standalone MP3. The sound is checked when the conversion runs.","size":"The MP3 is small compared with the AVI, which is large by nature. A 700 MB AVI film typically gives about 80 to 130 MB of MP3.","faq":["Why does it check for sound only when I convert?","AVI files cannot be inspected quickly in the browser the way MP4 and MKV can, so a silent AVI is found out when the conversion runs. The message is the same and nothing is charged."]},{"slug":"mp4-to-wav","tool":"extract-audio","from":"mp4","to":"wav","summary":"Extract the sound from an MP4 as uncompressed WAV for editing.","why":"MP4 to WAV pulls the audio out as uncompressed samples for sound editors, transcription tools and anything that does not accept compressed audio. Video sound is lossy to begin with, so the WAV will not sound better than the video did, but it will not lose anything further when edited.","size":"WAV is big: about 10 MB per minute for stereo at CD quality. A 30-minute video produces roughly a 300 MB WAV, so choose MP3 if you only want to listen.","faq":["Why is the WAV so much larger than the sound in my MP4?","The MP4 stored the sound compressed as AAC, while WAV stores every sample. The sound itself is the same."]},{"slug":"png-to-pdf","tool":"image-to-pdf","from":"png","to":"pdf","summary":"Turn PNG screenshots and graphics into a PDF, one image per page.","why":"PNG to PDF is for screenshots, scans saved as PNG and graphics that need to be sent or printed as a document. PNG pictures are embedded without re-compressing them, so text and line art stay perfectly crisp, and you can put several PNGs into one PDF and set the page size and margins.","size":"The PDF is about the size of the PNGs together, because they are embedded unchanged. Use Compress PDF afterwards if the result is too large to email.","faq":["Are transparent PNGs supported?","Yes. A PNG with a see-through background is placed on the page as it is, so the paper colour behind it shows through where the picture is clear."]},{"slug":"jpg-to-pdf","tool":"image-to-pdf","from":"jpg","to":"pdf","summary":"Combine JPG photos and scans into one PDF without re-compressing them.","why":"JPG to PDF turns phone photos of documents, receipts and scans into a single PDF for forms, applications and email. JPG pictures are embedded exactly as they are, so there is no second round of compression, and photos are rotated upright using the orientation the camera stored.","size":"Almost exactly the sum of the JPG files, plus a few kilobytes. If the PDF has to be under an upload limit, compress the JPGs first or run the PDF through Compress PDF.","faq":["Can I reorder the pages?","Yes. Drag the thumbnails into order, rotate any sideways photo, and delete ones you do not want before creating the PDF."]},{"slug":"heic-to-pdf","tool":"image-to-pdf","from":"heic","to":"pdf","summary":"Put iPhone HEIC photos straight into a PDF.","why":"HEIC to PDF skips the extra step of first converting iPhone photos to JPG. HEIC photos are converted and placed straight onto PDF pages, upright, in the order you set. It is a quick way to turn photos of paperwork into one document without installing anything.","size":"Because HEIC is converted to JPG inside the PDF, the file is larger than the HEIC originals, often around double, but comparable to the same photos saved as JPG.","faq":["Does a Live Photo or burst work?","Only the main still of each HEIC is used. Live Photo motion is not included in a PDF."]},{"slug":"webp-to-pdf","tool":"image-to-pdf","from":"webp","to":"pdf","summary":"Convert WebP images into a PDF that every program opens.","why":"WebP images saved from websites often cannot be attached to forms or printed by some print shops. WebP to PDF places them on PDF pages so they open anywhere. WebP pictures are converted losslessly to PNG for embedding, so the PDF does not add another lossy step.","size":"Bigger than the WebP files, since WebP's small size is lost when they are embedded as PNG; a photo WebP can grow several times. Use Compress PDF if size matters.","faq":["What about animated WebP?","A PDF page cannot move, so only the first frame of an animated WebP is placed on the page. To keep every frame, save them as separate images first."]},{"slug":"gif-to-pdf","tool":"image-to-pdf","from":"gif","to":"pdf","summary":"Convert a GIF into a PDF page (the first frame of an animation).","why":"GIF to PDF suits still GIFs: diagrams, logos and old scanned graphics that need to go into a document. A PDF page cannot animate, so an animated GIF contributes only its first frame, and the page tells you when it spots an animation.","size":"Small for flat graphics, since GIFs are small to begin with; the PDF is roughly the GIF's size once converted.","faq":["How can I put every frame of a GIF into a PDF?","Use GIF to PNG to save each frame as an image in a ZIP, then add those PNGs to Image to PDF in order."]},{"slug":"pdf-to-png","tool":"pdf-to-jpg","from":"pdf","to":"png","summary":"Save PDF pages as sharp PNG images, one per page.","why":"PDF to PNG renders each page as an image that keeps text and line art crisp, which is why it suits slides, diagrams and documents better than JPG. Choose a resolution up to 300 dpi for print. A single page downloads as one PNG; several pages arrive as one ZIP.","size":"PNG pages are bigger than JPG, often two to four times for pages with photographs but similar for black-and-white text pages at the same resolution.","faq":["Which resolution should I choose?","Standard (108 dpi) is fine for screens and chat, High (144) for sharper screens, and Print (300) when the image is going to paper."]},{"slug":"mp4-to-gif","tool":"video-to-gif","from":"mp4","to":"gif","summary":"Turn a short MP4 clip into a looping GIF for chat, email and docs.","why":"MP4 to GIF makes a silent looping animation from a clip, to share where video does not autoplay: chat apps, email and documents. A GIF is limited to 256 colours and has no sound, so keep it to a few seconds at a modest size or the file becomes enormous.","size":"GIFs are much larger than the video they come from: a few seconds can be several megabytes. Lower the frame rate or width to cut the size.","faq":["Why is my GIF so large?","GIF stores frames far less efficiently than video does. Shorten the clip, reduce the width and the frame rate; each cut multiplies the savings."]},{"slug":"mov-to-gif","tool":"video-to-gif","from":"mov","to":"gif","summary":"Make a looping GIF from an iPhone or Mac MOV recording.","why":"MOV to GIF turns a screen recording or iPhone clip into a GIF you can drop into a bug report, a help article or a message. Phone recordings are high resolution, so scale the GIF down; most uses look right at 480 pixels wide or less and keep the file shareable.","size":"A 5 second iPhone clip at full size can produce a GIF of tens of megabytes. At 480 pixels wide and a lower frame rate, the same clip is typically a couple of megabytes.","faq":["Will the GIF include sound?","No. GIF cannot carry sound. If you need the audio too, share the video itself or extract the sound separately."]}]`,
  ),
  dt = {
    "convert-image": {
      id: "convert-image",
      name: "Convert Image",
      inputs: [
        "png",
        "jpg",
        "webp",
        "avif",
        "svg",
        "bmp",
        "tiff",
        "heic",
        "gif",
      ],
      outputs: {
        png: "png",
        jpg: "jpeg",
        webp: "webp",
        avif: "avif",
        gif: "gif",
        bmp: "bmp",
        ico: "ico",
        tiff: "tiff",
      },
      notes: [
        "Several images at once (one ZIP back) or one at a time, with resize, rotate, flip, black and white, print resolution and metadata options.",
        "An animated GIF can be saved as one image per frame (a ZIP) or as its first frame; animated WebP gives its first frame.",
        "A TIFF with several pages gives its first page; SVG is drawn at the size the file declares.",
      ],
      alsoTry: [
