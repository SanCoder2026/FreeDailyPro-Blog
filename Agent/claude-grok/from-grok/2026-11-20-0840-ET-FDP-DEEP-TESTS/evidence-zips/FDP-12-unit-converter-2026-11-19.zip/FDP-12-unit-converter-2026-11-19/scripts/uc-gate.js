// unit-converter: export actions (Copy result, Save as text, Print, Copy again; then a reload and Copy) at 0 and with uses left. Also records typing-only cost.
// No clipboard sentinel writes (the page's clipboard wrapper is itself gated). window.print is stubbed. Max 6 fresh contexts.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/12-unit-converter/live/'; fs.mkdirSync(OUT + 'downloads', { recursive: true });
const ACTS = ['Copy result', 'Save as text', 'Print'];
(async () => { const b = await chromium.launch(); const R = { t: cp.execSync('date "+%F %T %Z"').toString().trim(), contexts: [] }; let zeroDone = false, liveDone = false;
 for (let i = 0; i < 6 && !(zeroDone && liveDone); i++) {
  const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true, permissions: ['clipboard-read', 'clipboard-write'] });
  await c.addInitScript(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
  const p = await c.newPage(); p.setDefaultTimeout(10000); await p.goto('https://www.freedailypro.com/tool/unit-converter', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
  const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
  const row = { i, start: await used(), steps: [], strip: await p.evaluate(() => (document.body.innerText.match(/(Trial|trial use)[^\n]*/g) || []).slice(0, 4)) }; R.contexts.push(row); const atZero = row.start >= 10;
  if ((atZero && zeroDone) || (!atZero && liveDone)) { await c.close(); continue; }
  if (!atZero) { await p.getByLabel('Value').fill('12.5'); await p.waitForTimeout(800); await p.getByLabel('Value').fill('100'); await p.waitForTimeout(800); row.afterTyping = await used(); }
  for (const a of [...ACTS, ...(atZero ? [] : ['Copy result'])]) { let d = null; const h = x => d = x; p.on('download', h);
   await p.getByRole('button', { name: a, exact: true }).click(); await p.waitForTimeout(1800); p.off('download', h);
   const dl = p.locator('[role=dialog],[role=alertdialog]'); const dialog = (await dl.count()) ? (await dl.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 220) : null;
   const st = { a, used: await used(), dialog, download: d ? d.suggestedFilename() : null, printed: await p.evaluate(() => window.__printed), clip: (await p.evaluate(() => navigator.clipboard.readText()).catch(() => '')).slice(0, 160) };
   if (d) { const f = OUT + 'downloads/' + (atZero ? 'zero-' : 'live-') + d.suggestedFilename(); await d.saveAs(f); st.content = fs.readFileSync(f, 'utf8').slice(0, 600); }
   row.steps.push(st);
   if (dialog) { if (atZero && a === 'Copy result') await p.screenshot({ path: OUT + 'gate-copy-at-zero.png' }); await p.keyboard.press('Escape'); await p.waitForTimeout(400); } }
  if (!atZero) { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); row.afterReload = await used(); await p.getByRole('button', { name: 'Copy result', exact: true }).click(); await p.waitForTimeout(1800); row.afterReloadCopy = await used(); row.reloadDialog = (await p.locator('[role=dialog],[role=alertdialog]').count()) > 0; }
  row.storageKeys = await p.evaluate(() => Object.keys(localStorage)); row.history = await p.evaluate(() => Object.entries(localStorage).filter(([k]) => /hist|recent|calc/i.test(k)).map(([k, v]) => [k, v.slice(0, 300)]));
  if (atZero) zeroDone = true; else liveDone = true; await c.close(); }
 R.t2 = cp.execSync('date "+%F %T %Z"').toString().trim(); fs.writeFileSync(OUT + 'gate.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
