// unit-converter: UI typing, swap, keyboard tabs/selects, live regions, axe, de-DE formatting, phones. Exports here are free (the tool is not trial-gated; see gate.json).
const { chromium, devices } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/12-unit-converter/live/'; const URL = 'https://www.freedailypro.com/tool/unit-converter';
(async () => { const b = await chromium.launch(); const R = { t: cp.execSync('date "+%F %T %Z"').toString().trim() };
 const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(10000); await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 const res = () => p.evaluate(() => document.querySelector('[data-testid=unit-result]')?.innerText);
 R.used0 = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 await p.getByLabel('Value').fill('2.5'); await p.waitForTimeout(300); R.typed = await res(); R.urlAfterType = await p.evaluate(() => location.search);
 await p.getByLabel('Value').fill(''); await p.waitForTimeout(300); R.empty = { r: await res(), all: await p.locator('[data-testid=unit-all]').count(), actions: await p.locator('[data-testid=result-actions]').isVisible().catch(() => false) };
 await p.getByLabel('Value').fill('1'); await p.getByRole('button', { name: 'Swap units' }).click(); await p.waitForTimeout(300);
 R.swap = { r: await res(), from: await p.locator('[aria-label="From unit"]').innerText(), to: await p.locator('[aria-label="To unit"]').innerText() };
 // keyboard: tabs
 await p.getByRole('tab', { name: 'Length' }).focus(); await p.keyboard.press('ArrowRight'); await p.waitForTimeout(300); await p.keyboard.press('Enter'); await p.waitForTimeout(300);
 R.kbdTab = { selected: await p.evaluate(() => document.querySelector('main [role=tab][aria-selected=true]')?.innerText), from: await p.locator('[aria-label="From unit"]').innerText(), to: await p.locator('[aria-label="To unit"]').innerText(), r: await res(), value: await p.getByLabel('Value').inputValue() };
 // keyboard: From select
 await p.locator('[aria-label="From unit"]').focus(); await p.keyboard.press('Enter'); await p.waitForTimeout(300); R.listboxOpen = await p.locator('[role=listbox]').count();
 await p.keyboard.press('ArrowDown'); await p.keyboard.press('ArrowDown'); await p.keyboard.press('Enter'); await p.waitForTimeout(300); R.kbdSelect = { from: await p.locator('[aria-label="From unit"]').innerText(), r: await res() };
 // tab order
 await p.getByLabel('Value').focus(); const seq = []; for (let i = 0; i < 10; i++) { await p.keyboard.press('Tab'); seq.push(await p.evaluate(() => { const e = document.activeElement; return `${e.tagName} ${(e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 30)}`; })); } R.tabSeq = seq;
 R.live = await p.evaluate(() => ({ ariaLive: [...document.querySelectorAll('main [aria-live]')].map(e => e.getAttribute('aria-live') + ':' + e.innerText.slice(0, 40)), status: document.querySelectorAll('main [role=status]').length, srOnly: [...document.querySelectorAll('main .sr-only[data-result]')].map(e => e.innerText) }));
 // number input oddities
 await p.getByLabel('Value').fill(''); await p.getByLabel('Value').pressSequentially('1e5'); await p.waitForTimeout(300); R.sci = await res();
 await p.getByLabel('Value').fill(''); await p.getByLabel('Value').pressSequentially('12abc'); await p.waitForTimeout(300); R.letters = { v: await p.getByLabel('Value').inputValue(), r: await res() };
 // axe
 await p.addScriptTag({ content: fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8') });
 const ax = () => p.evaluate(async () => (await axe.run(document.querySelector('main'))).violations.map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length, s: v.nodes.slice(0, 2).map(x => x.target.join(' ').slice(0, 100)) })));
 R.axeDefault = await ax(); await p.getByRole('tab', { name: 'Cooking (approx.)' }).click(); await p.waitForTimeout(400); R.axeCooking = await ax();
 await p.locator('[data-testid=tool-area]').screenshot({ path: OUT + 'tool-cooking.png' });
 // FAQ text
 R.faqLd = await p.evaluate(() => { for (const s of document.querySelectorAll('script[type="application/ld+json"]')) { try { const j = JSON.parse(s.textContent); const arr = Array.isArray(j) ? j : (j['@graph'] || [j]); for (const x of arr) if (x['@type'] === 'FAQPage') return x.mainEntity.map(q => ({ q: q.name, a: q.acceptedAnswer.text })); } catch (e) {} } return null; });
 R.usedEnd = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday); await c.close();
 // de-DE formatting + Save as text (free here)
 const d = await b.newContext({ viewport: { width: 1366, height: 900 }, locale: 'de-DE', acceptDownloads: true }); const q = await d.newPage(); q.setDefaultTimeout(10000);
 await q.goto(URL + '?c=length&from=inch&to=centimeter&v=1234.5', { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4000);
 R.de = await q.evaluate(() => ({ r: document.querySelector('[data-testid=unit-result]')?.innerText, value: document.querySelector('input[aria-label=Value]').value, sr: document.querySelector('.sr-only[data-result]')?.innerText, all: document.querySelector('[data-testid=unit-all]')?.innerText.slice(0, 160) }));
 const [dl] = await Promise.all([q.waitForEvent('download', { timeout: 8000 }).catch(() => null), q.getByRole('button', { name: 'Save as text', exact: true }).click()]);
 if (dl) { const f = OUT + 'downloads/de-' + dl.suggestedFilename(); fs.mkdirSync(OUT + 'downloads', { recursive: true }); await dl.saveAs(f); R.deSave = fs.readFileSync(f, 'utf8').slice(0, 300); }
 await q.screenshot({ path: OUT + 'de-DE-result.png' }); await d.close();
 for (const dn of ['iPhone SE', 'Pixel 7']) { const cc = await b.newContext({ ...devices[dn] }); const m = await cc.newPage(); await m.goto(URL, { waitUntil: 'domcontentloaded' }); await m.waitForTimeout(4000);
  R['phone_' + dn] = await m.evaluate(() => { const y = s => { const e = document.querySelector(s); return e ? Math.round(e.getBoundingClientRect().top + scrollY) : null; }; const tl = document.querySelector('main [role=tablist]'); return { vw: innerWidth, vh: innerHeight, sw: document.documentElement.scrollWidth, tablistH: tl ? Math.round(tl.getBoundingClientRect().height) : null, valueY: y('input[aria-label=Value]'), resultY: y('[data-testid=unit-result]') }; });
  await m.screenshot({ path: OUT + `phone-${dn.replace(/\s/g, '-').toLowerCase()}-full.png`, fullPage: true }); await cc.close(); }
 fs.writeFileSync(OUT + 'kbd.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
