// unit-converter: conversion cases via URL state (?c=&from=&to=&v=), checked against independent NIST SP 811 / exact-definition references.
// Reading only (no copy/save/print). Usage: node uc-live.js [ids]
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/12-unit-converter/live/'; const BASE = 'https://www.freedailypro.com/tool/unit-converter';
// [id, category, from, to, value, expected (number) or special]
const C = [
 ['U01', 'length', 'inch', 'centimeter', '1', 2.54], ['U02', 'length', 'mile', 'kilometer', '26.2', 42.1648128], ['U03', 'length', 'foot', 'inch', '1', 12],
 ['U04', 'length', 'nautical mile', 'mile', '1', 1852 / 1609.344], ['U05', 'length', 'nanometer', 'mile', '1', 1e-9 / 1609.344], ['U06', 'length', 'kilometer', 'nanometer', '1000000', 1e15],
 ['U07', 'weight', 'pound', 'kilogram', '1', 0.45359237], ['U08', 'weight', 'stone (UK)', 'pound', '1', 14], ['U09', 'weight', 'US ton (short, 2000 lb)', 'tonne (metric, 1000 kg)', '1', 0.90718474],
 ['U10', 'weight', 'UK ton (long, 2240 lb)', 'pound', '1', 2240], ['U11', 'weight', 'ounce', 'gram', '1', 28.349523125],
 ['U12', 'volume', 'US gallon', 'liter', '1', 3.785411784], ['U13', 'volume', 'UK gallon', 'US gallon', '1', 4.54609 / 3.785411784], ['U14', 'volume', 'US cup', 'US tablespoon', '1', 16],
 ['U15', 'volume', 'UK pint', 'UK fluid ounce', '1', 20], ['U16', 'volume', 'US pint', 'US fluid ounce', '1', 16], ['U17', 'volume', 'cubic foot', 'US gallon', '1', 28.316846592 / 3.785411784],
 ['U18', 'area', 'acre', 'sq foot', '1', 43560], ['U19', 'area', 'sq mile', 'acre', '1', 640], ['U20', 'area', 'hectare', 'acre', '1', 1e4 / 4046.8564224],
 ['U21', 'temperature', 'fahrenheit', 'celsius', '98.6', 37], ['U22', 'temperature', 'celsius', 'fahrenheit', '-40', -40], ['U23', 'temperature', 'celsius', 'kelvin', '-273.15', 0],
 ['U24', 'temperature', 'celsius', 'kelvin', '-300', 'alert'], ['U25', 'temperature', 'fahrenheit', 'rankine', '0', 459.67], ['U26', 'temperature', 'kelvin', 'fahrenheit', '-1', 'alert'],
 ['U27', 'speed', 'knot', 'kilometer/hour', '1', 1.852], ['U28', 'speed', 'mile/hour', 'kilometer/hour', '60', 96.56064],
 ['U29', 'time', 'year (365.25 days)', 'day', '1', 365.25], ['U30', 'data', 'gibibyte (1024³ B)', 'gigabyte (1000³ B)', '1', 1.073741824], ['U31', 'data', 'byte', 'bit', '1', 8],
 ['U32', 'pressure', 'psi', 'bar', '1', 0.0689475729], ['U33', 'pressure', 'atmosphere', 'mmHg', '1', 760], ['U34', 'energy', 'kilocalorie (food Calorie)', 'kilojoule', '1', 4.184],
 ['U35', 'energy', 'kilowatt-hour', 'BTU', '1', 3412.141633], ['U36', 'power', 'horsepower (mechanical)', 'kilowatt', '1', 0.7456998716], ['U37', 'power', 'horsepower (metric)', 'watt', '1', 735.49875],
 ['U38', 'angle', 'radian', 'degree', '1', 180 / Math.PI], ['U39', 'frequency', 'revolutions/minute (rpm)', 'hertz', '60', 1],
 ['U40', 'fuel', 'miles/gallon (US)', 'liters/100 km', '30', 7.840486111], ['U41', 'fuel', 'miles/gallon (UK)', 'miles/gallon (US)', '30', 24.98057], ['U42', 'fuel', 'liters/100 km', 'km/liter', '0', 'dash'],
 ['U43', 'length', 'meter', 'foot', '-5', 'negative?'], ['U44', 'fuel', 'miles/gallon (US)', 'liters/100 km', '-30', 'negative?'], ['U45', 'weight', 'kilogram', 'pound', '1e3', 2204.622622],
 ['U46', 'length', 'meter', 'kilometer', '1e400', 'dash'], ['U47', 'length', 'meter', 'centimeter', '0.1', 10], ['U48', 'volume', 'liter', 'milliliter', '0.3', 300],
];
const COOK = [['K01', 'flour', 'US cup', 'gram', '1', 120], ['K02', 'butter', 'US cup', 'gram', '0.5', 113.5], ['K03', 'sugar', 'gram', 'US cup', '100', 0.5], ['K04', 'water', 'US cup', 'gram', '1', 236.5882365],
 ['K05', 'flour', 'US tablespoon', 'gram', '1', 7.5], ['K06', 'honey', 'ounce (weight)', 'US cup', '12', 12 * 28.349523125 / 339], ['K07', 'milk', 'milliliter', 'gram', '100', 244 / 236.5882365 * 100]];
(async () => { const ids = process.argv[2] ? process.argv[2].split(',') : null; const b = await chromium.launch();
 const p = await (await b.newContext({ viewport: { width: 1366, height: 900 }, locale: 'en-US' })).newPage(); p.setDefaultTimeout(12000);
 await p.goto(BASE, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
 const R = { t0: cp.execSync('date "+%F %T %Z"').toString().trim(), ls0: await p.evaluate(() => localStorage.getItem('fdp-usage-v1')), cases: {} };
 const run = async (id, url, exp) => { await p.goto(url, { waitUntil: 'domcontentloaded' }); await p.waitForSelector('[data-testid=unit-result]'); await p.waitForTimeout(600);
  const r = await p.evaluate(() => ({ result: document.querySelector('[data-testid=unit-result]')?.innerText, from: document.querySelector('[aria-label="From unit"]')?.innerText, to: document.querySelector('[aria-label="To unit"]')?.innerText, value: document.querySelector('input[aria-label=Value]')?.value, alert: [...document.querySelectorAll('main [role=alert]')].map(e => e.innerText).join(' '), allFirst: document.querySelector('[data-testid=unit-all] li')?.innerText.replace(/\n/g, ' '), url: location.search }));
  const num = Number((r.result || '').replace(/,/g, '')); let verdict;
  if (typeof exp === 'number') { const rel = Math.abs(num - exp) / Math.max(Math.abs(exp), 1e-300); verdict = rel < 5e-9 || (exp === 0 && Math.abs(num) < 1e-9) ? 'PASS' : 'FAIL'; r.relErr = rel; }
  else verdict = exp; r.expected = exp; r.verdict = verdict; R.cases[id] = r; console.log(id, '|', r.from, '→', r.to, '|', r.value, '=>', r.result, '| exp', exp, '|', verdict, r.alert ? '| ALERT ' + r.alert.slice(0, 60) : ''); };
 for (const [id, c, f, t, v, exp] of C) { if (ids && !ids.includes(id)) continue; await run(id, `${BASE}?c=${c}&from=${encodeURIComponent(f)}&to=${encodeURIComponent(t)}&v=${encodeURIComponent(v)}`, exp); }
 for (const [id, ing, f, t, v, exp] of COOK) { if (ids && !ids.includes(id)) continue; await run(id, `${BASE}?c=cooking&ing=${ing}&from=${encodeURIComponent(f)}&to=${encodeURIComponent(t)}&v=${encodeURIComponent(v)}`, exp); }
 R.lsEnd = await p.evaluate(() => localStorage.getItem('fdp-usage-v1')); R.t1 = cp.execSync('date "+%F %T %Z"').toString().trim();
 fs.writeFileSync(OUT + 'cases.json', JSON.stringify(R, null, 1)); await b.close(); })();
