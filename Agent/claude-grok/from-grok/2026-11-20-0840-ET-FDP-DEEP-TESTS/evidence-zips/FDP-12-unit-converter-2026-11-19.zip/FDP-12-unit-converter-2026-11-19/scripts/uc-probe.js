// unit-converter: starting count, controls, notes, categories, result actions, URL state, pair pages. Reading only (no copy/save/print).
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/12-unit-converter/live/'; const BASE = 'https://www.freedailypro.com/tool/unit-converter';
(async () => { const b = await chromium.launch(); const R = { t: cp.execSync('date "+%F %T %Z"').toString().trim() };
 const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(10000);
 await p.goto(BASE, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 R.ls0 = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
 R.trialStrip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]);
 R.tabs = await p.evaluate(() => [...document.querySelectorAll('main [role=tab]')].map(e => e.innerText.trim()));
 R.buttons = await p.evaluate(() => [...document.querySelectorAll('main button')].map(e => (e.getAttribute('aria-label') || e.innerText).trim()).filter(Boolean).slice(0, 60));
 R.testids = await p.evaluate(() => [...new Set([...document.querySelectorAll('[data-testid]')].map(e => e.dataset.testid))]);
 R.notes = await p.evaluate(() => [...document.querySelectorAll('main p, main small')].map(e => e.innerText.trim()).filter(t => /trial|use|approx|absolute/i.test(t)).slice(0, 15));
 R.result = await p.evaluate(() => ({ r: document.querySelector('[data-testid=unit-result]')?.innerText, all: document.querySelector('[data-testid=unit-all]')?.innerText.slice(0, 400) }));
 R.faq = await p.evaluate(() => [...document.querySelectorAll('main summary, main [data-state] button, main h3')].map(e => e.innerText.trim()).filter(t => t.endsWith('?')).slice(0, 30));
 await p.screenshot({ path: OUT + 'tool-default.png' });
 // URL state
 await p.goto(BASE + '?c=temperature&from=fahrenheit&to=celsius&v=98.6', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3000);
 R.urlState = await p.evaluate(() => document.querySelector('[data-testid=unit-result]')?.innerText);
 await p.goto(BASE + '?c=cooking&ing=butter&from=US%20cup&to=gram&v=0.5', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3000);
 R.urlCooking = await p.evaluate(() => ({ r: document.querySelector('[data-testid=unit-result]')?.innerText, note: document.querySelector('[data-testid=cooking-note]')?.innerText }));
 // pair pages
 R.pairs = {};
 for (const s of ['cm-to-inches', 'kg-to-lbs', 'celsius-to-fahrenheit', 'cups-to-ml', 'acres-to-hectares', 'not-a-pair']) {
  const resp = await p.goto(BASE + '/' + s, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(2500);
  R.pairs[s] = await p.evaluate(() => ({ title: document.title, h1: document.querySelector('h1')?.innerText, canon: document.querySelector('link[rel=canonical]')?.href, desc: document.querySelector('meta[name=description]')?.content, formula: document.querySelector('[data-testid=unit-pair-formula]')?.innerText, table: document.querySelector('[data-testid=unit-pair-table]')?.innerText.replace(/\s+/g, ' ').slice(0, 300), result: document.querySelector('[data-testid=unit-result]')?.innerText, robots: document.querySelector('meta[name=robots]')?.content }));
  R.pairs[s].status = resp.status(); }
 R.lsEnd = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
 fs.writeFileSync(OUT + 'probe.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
