function J(i) {
  const s = new Map();
  for (const a of i) {
    const r = s.get(a.message);
    r ? r.count++ : s.set(a.message, { message: a.message, count: 1 });
  }
  return Array.from(s.values());
}
const B = {
    colour: "color",
    flavour: "flavor",
    honour: "honor",
    favour: "favor",
    favourite: "favorite",
    behaviour: "behavior",
    neighbour: "neighbor",
    labour: "labor",
    harbour: "harbor",
    humour: "humor",
    rumour: "rumor",
    savour: "savor",
    vapour: "vapor",
    centre: "center",
    theatre: "theater",
    metre: "meter",
    litre: "liter",
    fibre: "fiber",
    calibre: "caliber",
    sombre: "somber",
    defence: "defense",
    licence: "license",
    offence: "offense",
    pretence: "pretense",
    cheque: "check",
    tyre: "tire",
    programme: "program",
    jewellery: "jewelry",
    travelled: "traveled",
    travelling: "traveling",
    traveller: "traveler",
    cancelled: "canceled",
    cancelling: "canceling",
    labelled: "labeled",
    labelling: "labeling",
    modelled: "modeled",
    modelling: "modeling",
    counselling: "counseling",
    counsellor: "counselor",
    fuelled: "fueled",
    fuelling: "fueling",
    levelled: "leveled",
    levelling: "leveling",
    signalled: "signaled",
    signalling: "signaling",
    marvellous: "marvelous",
    enrolment: "enrollment",
    fulfil: "fulfill",
    skilful: "skillful",
    judgement: "judgment",
    ageing: "aging",
    aluminium: "aluminum",
    paediatric: "pediatric",
    anaemia: "anemia",
    oestrogen: "estrogen",
    foetus: "fetus",
    manoeuvre: "maneuver",
    sceptic: "skeptic",
    sceptical: "skeptical",
    speciality: "specialty",
    plough: "plow",
    pyjamas: "pajamas",
    kerb: "curb",
    practise: "practice",
    grey: "gray",
    mum: "mom",
    mould: "mold",
    moustache: "mustache",
    storey: "story",
    cosy: "cozy",
    draught: "draft",
  },
  Q = new Set([
    "program",
    "check",
    "tire",
    "license",
    "practice",
    "story",
    "draft",
    "gray",
    "mom",
    "mold",
    "curb",
    "plow",
    "fetus",
    "estrogen",
  ]),
  ee = new Set(Object.values(B).filter((i) => !Q.has(i)));
function K(i, s) {
  const a = i.toLowerCase(),
    r = B[a];
  if (r) return r;
  if (!s || a.length < 6 || s.correct(a) || s.correct(i)) return null;
  const l = [];
  return (
    /our(s|ed|ing|ful|able|less|ite|ist|ists)?$/.test(a) &&
      l.push(a.replace(/our(s|ed|ing|ful|able|less|ite|ist|ists)?$/, "or$1")),
    /is(e|es|ed|ing|ation|ations|er|ers)$/.test(a) &&
      l.push(a.replace(/is(e|es|ed|ing|ation|ations|er|ers)$/, "iz$1")),
    /ys(e|es|ed|ing)$/.test(a) && l.push(a.replace(/ys(e|es|ed|ing)$/, "yz$1")),
    l.find((c) => s.correct(c)) ?? null
  );
}
const te = /^en[-_](gb|uk|au|nz|ie|in|za|sg|hk|my|pk|ng|ke)\b/i;
function se(i, s, a) {
  const r = a.variant ?? "auto";
  if (r === "us" || r === "uk") return r;
  let l = 0,
    c = 0;
  for (const b of i) K(b, s) ? l++ : ee.has(b.toLowerCase()) && c++;
  return l !== c
    ? l > c
      ? "uk"
      : "us"
    : a.localeHint && te.test(a.localeHint)
      ? "uk"
      : "us";
}
const re = {
    teh: "the",
    recieve: "receive",
    seperate: "separate",
    definately: "definitely",
    occured: "occurred",
    untill: "until",
    wich: "which",
    alot: "a lot",
    becuase: "because",
    begining: "beginning",
    beleive: "believe",
    calender: "calendar",
    concious: "conscious",
    enviroment: "environment",
    goverment: "government",
    neccessary: "necessary",
    noticable: "noticeable",
    occassion: "occasion",
    publically: "publicly",
    recomend: "recommend",
    similiar: "similar",
    thier: "their",
    accomodate: "accommodate",
    tomorow: "tomorrow",
    tommorow: "tomorrow",
    tommorrow: "tomorrow",
    wierd: "weird",
    freind: "friend",
    adress: "address",
    sucess: "success",
    succesful: "successful",
    embarass: "embarrass",
    existance: "existence",
    foriegn: "foreign",
    grammer: "grammar",
    harrass: "harass",
    independant: "independent",
    knowlege: "knowledge",
    liason: "liaison",
    millenium: "millennium",
    mispell: "misspell",
    pursue: "pursue",
    refered: "referred",
    relevent: "relevant",
    resturant: "restaurant",
    rythm: "rhythm",
    scedule: "schedule",
    suprise: "surprise",
    truely: "truly",
    twelth: "twelfth",
    vaccum: "vacuum",
    writting: "writing",
    acheive: "achieve",
    agressive: "aggressive",
    apparantly: "apparently",
    basicly: "basically",
    buisness: "business",
    comming: "coming",
    completly: "completely",
    dissapoint: "disappoint",
    excersise: "exercise",
    finaly: "finally",
    gaurd: "guard",
    happend: "happened",
    immediatly: "immediately",
    intresting: "interesting",
    lenght: "length",
    peice: "piece",
    persue: "pursue",
    posession: "possession",
    prefered: "preferred",
    probaly: "probably",
    realy: "really",
    reccomend: "recommend",
    responsability: "responsibility",
    tounge: "tongue",
    usefull: "useful",
    wether: "whether",
    whereever: "wherever",
    yeild: "yield",
  },
  ne = {
    dont: "don't",
    doesnt: "doesn't",
    didnt: "didn't",
    isnt: "isn't",
    arent: "aren't",
    wasnt: "wasn't",
    werent: "weren't",
    cant: "can't",
    couldnt: "couldn't",
    wouldnt: "wouldn't",
    shouldnt: "shouldn't",
    wont: "won't",
    hasnt: "hasn't",
    havent: "haven't",
    hadnt: "hadn't",
    youre: "you're",
    theyre: "they're",
    thats: "that's",
    whats: "what's",
    ive: "I've",
    youve: "you've",
    weve: "we've",
    theyve: "they've",
    ill: "I'll",
    hes: "he's",
    shes: "she's",
  },
  ae = new Set(["ill", "wont", "hes", "shes", "cant", "ive"]),
  oe = {
    buyed: "bought",
    goed: "went",
    runned: "ran",
    eated: "ate",
    taked: "took",
    maked: "made",
    thinked: "thought",
    bringed: "brought",
    teached: "taught",
    catched: "caught",
    knowed: "knew",
    growed: "grew",
    writed: "wrote",
    speaked: "spoke",
    breaked: "broke",
    choosed: "chose",
    drived: "drove",
    gived: "gave",
    seeed: "saw",
    sleeped: "slept",
  },
  R =
    "information|advice|equipment|furniture|knowledge|luggage|homework|feedback|software|news|research|evidence|traffic|weather|money",
  ie =
    /\b(?:e\.g|i\.e|etc|vs|mr|mrs|ms|dr|prof|sr|jr|st|inc|ltd|co|no|approx|a\.m|p\.m|u\.s|u\.k|u\.n|ph\.d)\./gi,
  le = new RegExp(
    [
      "`[^`\\n]*`",
      `\\b(?:https?:\\/\\/|ftp:\\/\\/|www\\.)[^\\s<>"')]+`,
      "[\\w.+-]+@[\\w-]+(?:\\.[\\w-]+)+",
      `\\b[\\w-]+(?:\\.[\\w-]+)*\\.(?:com|org|net|io|co|edu|gov|app|dev|ai|us|uk|in|html?|php|js|jsx|ts|tsx|json|pdf|docx?|xlsx?|pptx?|png|jpe?g|gif|svg|webp|txt|csv|md|zip|exe|mp3|mp4|css|py)\\b(?:[/?#][^\\s<>"')]*)?`,
      "\\bv?\\d+(?:\\.\\d+)+[A-Za-z0-9.]*",
      "[@#][\\w-]+",
    ].join("|"),
    "gi",
  );
function ce(i) {
  const s = [],
    a = (l) => (s.push(l), `${s.length - 1}`);
  let r = i.replace(le, a);
  return ((r = r.replace(ie, a)), { masked: r, tokens: s });
}
const ue = (i, s) => i.replace(/(\d+)/g, (a, r) => s[Number(r)]);
function O(i, s) {
  const a = Array.from({ length: i.length + 1 }, (r, l) => [
    l,
    ...Array(s.length).fill(0),
  ]);
  for (let r = 1; r <= s.length; r++) a[0][r] = r;
  for (let r = 1; r <= i.length; r++)
    for (let l = 1; l <= s.length; l++)
      a[r][l] = Math.min(
        a[r - 1][l] + 1,
        a[r][l - 1] + 1,
        a[r - 1][l - 1] + (i[r - 1] === s[l - 1] ? 0 : 1),
      );
  return a[i.length][s.length];
}
const f = (i, s) =>
    i === i.toUpperCase() && i.length > 1
      ? s.toUpperCase()
      : i[0] === i[0].toUpperCase()
        ? s.charAt(0).toUpperCase() + s.slice(1)
        : s,
  he = [
    "go",
    "do",
    "want",
    "need",
    "like",
    "love",
    "take",
    "work",
    "play",
    "live",
    "know",
    "think",
    "say",
    "get",
    "come",
    "look",
    "use",
    "eat",
    "run",
    "walk",
    "talk",
    "speak",
    "write",
    "give",
    "tell",
    "ask",
    "try",
    "help",
    "start",
    "watch",
    "teach",
    "buy",
    "sell",
    "study",
    "cry",
    "enjoy",
    "hate",
    "feel",
    "seem",
    "become",
    "bring",
    "call",
    "keep",
    "leave",
    "meet",
    "move",
    "open",
    "pay",
    "show",
    "stay",
    "wear",
    "wait",
    "drive",
    "sleep",
    "sing",
    "swim",
    "fly",
    "pass",
    "fix",
    "finish",
    "carry",
  ];
function de(i) {
  const s = i.toLowerCase();
  let a;
  return (
    /(s|sh|ch|x|z|o)$/.test(s)
      ? (a = s + "es")
      : /[^aeiou]y$/.test(s)
        ? (a = s.slice(0, -1) + "ies")
        : (a = s + "s"),
    f(i, a)
  );
}
function me(i, s, a = {}) {
  const r = [],
    l = [],
    c = (e, t) => r.push({ type: e, message: t }),
    { masked: b, tokens: w } = ce(i);
  let o = b;
  const k = se(b.match(/\b[A-Za-z]{4,}\b/g) ?? [], s, a);
  (/[ \t]{2,}/.test(o) &&
    (c("spacing", "Removed extra spaces."), (o = o.replace(/[ \t]{2,}/g, " "))),
    /[ \t]+[,.!?;:](?!\.)/.test(o.replace(/\.\.\./g, "")) &&
      (c("spacing", "Removed spaces before punctuation."),
      (o = o.replace(/[ \t]+([,.!?;:])(?!\.)/g, "$1"))),
    /[a-z][.,!?;:][A-Za-z]/i.test(o) &&
      (c("spacing", "Added missing space after punctuation."),
      (o = o.replace(/([A-Za-z])([.,!?;:])([A-Za-z])/g, "$1$2 $3"))),
    (o = o.replace(/\b([A-Za-z']+)\s+\1\b/gi, (e, t) =>
      /^(had|that|is|can)$/i.test(t)
        ? e
        : (c("repetition", `Removed repeated word "${t}".`), t),
    )),
    (o = o.replace(/\b[A-Za-z]+\b/g, (e) => {
      const t = e.toLowerCase();
      if (e !== t && e !== e[0].toUpperCase() + e.slice(1).toLowerCase())
        return e;
      const n = ne[t];
      if (n && !ae.has(t))
        return (c("grammar", `"${e}" → "${f(e, n)}"`), f(e, n));
      const h = oe[t];
      return h ? (c("grammar", `"${e}" → "${f(e, h)}"`), f(e, h)) : e;
    })),
    (o = o.replace(
      new RegExp(
        `\\b(${R.split("|")
          .filter(
            (e) =>
              e !== "news" &&
              e !== "traffic" &&
              e !== "weather" &&
              e !== "money",
          )
          .join("|")})s\\b`,
        "gi",
      ),
      (e, t) => (c("grammar", `"${e}" → "${t}" (not used in the plural)`), t),
    )));
  const A = new RegExp(`\\b(he|she|it)\\s+(${he.join("|")})\\b`, "gi");
  ((o = o.replace(A, (e, t, n, h, d) => {
    if (
      /\b(that|if|suggest|suggests|insist|demand|recommend|require|wish|lest|so|let|make|made|help)\s+$/i.test(
        d.slice(Math.max(0, h - 12), h),
      )
    )
      return e;
    const y = `${t} ${de(n)}`;
    return (c("grammar", `"${e}" → "${y}": verb agreement with "${t}"`), y);
  })),
    (o = o.replace(
      /\b(every|each)\s+(day|week|month|year|morning|afternoon|evening|night|weekend|hour|minute|time|person|student|customer|user)s\b/gi,
      (e, t, n) => (
        c(
          "grammar",
          `"${e}" → "${t} ${n}": "${t}" is followed by a singular noun`,
        ),
        `${t} ${n}`
      ),
    )));
  const U = [
    [
      /\b(has|have|had)\s+went\b/gi,
      (e, t) => `${t} gone`,
      '"went" → "gone" after has/have/had',
    ],
    [
      /\b(should|could|would|must|might)\s+of\b/gi,
      (e, t) => `${t} have`,
      '"of" → "have"',
    ],
    [
      /\b(he|she|it)\s+don't\b/gi,
      (e, t) => `${t} doesn't`,
      `"don't" → "doesn't"`,
    ],
    [/\b(i)\s+has\b/gi, () => "I have", '"I has" → "I have"'],
    [/\b(you|we|they)\s+has\b/gi, (e, t) => `${t} have`, '"has" → "have"'],
    [
      /\b(he|she|it)\s+have\b(?!\s+to\b)/gi,
      (e, t) => `${t} has`,
      '"have" → "has"',
    ],
    [
      new RegExp(`\\b(${R})\\s+are\\b`, "gi"),
      (e, t) => `${t} is`,
      '"are" → "is" (uncountable noun)',
    ],
    [
      /\b(their)\s+(going|is|are|not|here|there|always|being|coming|trying|doing|late|now|just|all|still|very|really)\b/gi,
      (e, t, n) =>
        `${/^[A-Z]/.test(e) ? "They're" : "they're"} ${n}`
          .replace("they're is", "there is")
          .replace("They're is", "There is")
          .replace("they're are", "there are")
          .replace("They're are", "There are"),
      `"their" → "they're"`,
    ],
    [
      /\b(its)\s+(a|an|been|not|going|time|about|very|really|just|so|too|also|okay|ok|true|fine|nice|good|bad|hard|easy|clear|possible|my|your|the)\b/gi,
      (e, t, n) => `${t[0] === "I" ? "It's" : "it's"} ${n}`,
      `"its" → "it's"`,
    ],
    [
      /\b(your)\s+(welcome|going|not|doing|being|right|wrong|so|very|really|late|here|there)\b/gi,
      (e, t, n) => `${t[0] === "Y" ? "You're" : "you're"} ${n}`,
      `"your" → "you're"`,
    ],
    [
      /\b(it's)\s+(own|tail|name|owner|color|colour|shape|size|wings|head|paws|nest|purpose|surface)\b/gi,
      (e, t, n) => `${t[0] === "I" ? "Its" : "its"} ${n}`,
      `"it's" → "its" (possessive)`,
    ],
    [
      /\b(you're)\s+(message|email|name|account|order|house|car|phone|family|job|mother|father|team|company|website|own|friends?)\b/gi,
      (e, t, n) => `${t[0] === "Y" ? "Your" : "your"} ${n}`,
      `"you're" → "your" (possessive)`,
    ],
    [
      /\b(an)\s+(?![hx]|[A-Z]{2})([bcdfgjklmnpqrstvwyz]\w*)/g,
      (e, t, n) => `a ${n}`,
      '"an" → "a" before a consonant sound',
    ],
    [
      /\b(An)\s+(?![hx]|[A-Z]{2})([bcdfgjklmnpqrstvwyz]\w*)/g,
      (e, t, n) => `A ${n}`,
      '"An" → "A" before a consonant sound',
    ],
    [
      /\b(a)\s+(?!(?:uni|use|usu|eu|one|once|ubiq|uran|util|ukr|unanim|unif)\w*)([aeiou]\w*)/gi,
      (e, t, n) => `${t === "A" ? "An" : "an"} ${n}`,
      '"a" → "an" before a vowel sound',
    ],
  ];
  for (const [e, t, n] of U)
    o = o.replace(e, (...h) => {
      const d = h[0],
        y = typeof t == "function" ? t(...h) : t;
      return (y !== d && c("grammar", `"${d}" → "${y}": ${n}`), y);
    });
  const v = new Set();
  let x = 0;
  ((o = o.replace(/\b[A-Za-z][A-Za-z']*[A-Za-z]\b/g, (e, t, n) => {
    const h = e.toLowerCase(),
      d = re[h];
    if (d) return (c("spelling", `"${e}" → "${f(e, d)}"`), f(e, d));
    const y =
      !/[A-Z]/.test(e.slice(1)) && e !== e.toUpperCase() ? K(e, s) : null;
    if (y)
      return (
        k === "us" &&
          !v.has(h) &&
          !s?.correct(h) &&
          (v.add(h),
          l.push({
            type: "spelling",
            message: `"${e}" is a UK spelling (US: "${f(e, y)}"). Left as written; choose UK English above if you are writing British English.`,
          })),
        e
      );
    if (!s || e.length < 4 || /[A-Z]/.test(e.slice(1)) || e === e.toUpperCase())
      return e;
    const P = /(^|[.!?]\s+|\n)$/.test(n.slice(0, t));
    if ((/^[A-Z]/.test(e) && !P) || s.correct(e) || s.correct(h) || ++x > 60)
      return e;
    const j = s.suggest(e).slice(0, 4),
      m = j[0],
      N = m ? O(h, m.toLowerCase()) : 99,
      G = j.filter((C) => !/\s/.test(C) && O(h, C.toLowerCase()) <= N).length,
      V =
        !!m &&
        m.length === e.length &&
        m.slice(0, -1).toLowerCase() === h.slice(0, -1) &&
        /[ds]$/.test(h + m.toLowerCase());
    return m &&
      G === 1 &&
      !V &&
      !/\s/.test(m) &&
      N <= 2 &&
      m.length >= 3 &&
      Math.abs(m.length - e.length) <= 2
      ? (c("spelling", `"${e}" → "${f(e, m)}"`), f(e, m))
      : (v.has(h) ||
          (v.add(h),
          l.push({
            type: "spelling",
            message: j.length
              ? `"${e}" may be misspelled. Did you mean ${j.map((C) => `"${C}"`).join(", ")}?`
              : `"${e}" is not in the dictionary. Check the spelling.`,
          })),
        e);
  })),
    /\bi\b/.test(o) &&
      (c("capitalization", 'Capitalized standalone "i".'),
      (o = o.replace(/\bi\b/g, "I"))),
    (o = o.replace(
      /(^|[.!?]\s+|\n\s*)([a-z])/g,
      (e, t, n) => (
        c("capitalization", "Capitalized start of sentence."),
        t + n.toUpperCase()
      ),
    )),
    /([!?])\1{1,}/.test(o) &&
      (c("punctuation", "Simplified repeated punctuation."),
      (o = o.replace(/([!?])\1+/g, "$1"))));
  const $ = (e, t) => {
    const n = o.match(e);
    n && l.push({ type: "grammar", message: t(n) });
  };
  ($(
    /\b(me and (?:him|her|them|\w+)) (was|were)\b/i,
    (e) =>
      `"${e[0]}": consider "${e[1].replace(/^me and /i, "")} and I ${e[2].toLowerCase() === "was" ? "were" : e[2]}".`,
  ),
    $(
      /\b(he|she|it|this|that)\s+(are|were)\b/i,
      (e) => `"${e[0]}": check subject-verb agreement.`,
    ),
    $(
      /\b(they|we|you)\s+(is|was)\b/i,
      (e) => `"${e[0]}": check subject-verb agreement.`,
    ),
    $(
      /\b(two|three|four|five|six|seven|eight|nine|ten|several|many|few|\d+)\s+(?:big |small |new |old |red |green |blue |good |bad )?(apple|car|book|day|week|month|year|person|child|man|woman|house|dog|cat|friend|student|problem)\b/i,
      (e) => `"${e[0]}": should the noun be plural?`,
    ));
  const g = (e, t, n) => {
      for (const h of Array.from(o.matchAll(e))) {
        const d = t(h);
        d && l.push({ type: "grammar", message: `"${h[0]}" → "${d}"? ${n}` });
      }
    },
    I =
      "taller|shorter|bigger|smaller|larger|better|worse|more|less|fewer|greater|higher|lower|older|younger|faster|slower|easier|harder|cheaper|longer|stronger|smarter|rather|other";
  return (
    g(
      new RegExp(`\\b(${I})\\s+then\\b`, "gi"),
      (e) => `${e[1]} than`,
      'Use "than" to compare ("taller than me"); "then" is about time.',
    ),
    g(
      /\b(will|would|could|can|may|might|not|didn't|doesn't|don't|won't|can't|shouldn't|wouldn't|couldn't)\s+effect\s+(the|my|your|our|their|his|her|its|this|that|how|what|whether|us|me|you|them|him|everyone|everything)\b/gi,
      (e) => `${e[1]} affect ${e[2]}`,
      '"Affect" is the verb ("it will affect the game"); "effect" is usually the noun.',
    ),
    g(
      /\b(the|an|no|any|side|negative|positive|major|big|great|little|lasting)\s+affect\s+(on)\b/gi,
      (e) => `${e[1]} effect ${e[2]}`,
      '"Effect" is the noun ("the effect on sales").',
    ),
    g(
      /\bless\s+(people|children|items|cars|books|students|users|customers|friends|days|hours|minutes|employees|options|things|mistakes|errors|calories|words|pages|points|times|problems|questions|visitors|members|participants|apples|men|women)\b/gi,
      (e) => `fewer ${e[1]}`,
      'Use "fewer" with things you can count ("fewer people"), "less" with amounts ("less water").',
    ),
    g(
      /\b(will|would|could|can|may|might|to|not|didn't|doesn't|don't|won't|can't|shouldn't|wouldn't|couldn't|gonna)\s+loose\s+(the|my|your|our|their|his|her|its|a|an|weight|money|time|control|hope|track|sight|faith|touch|everything|all|it|them|you|us|me)\b/gi,
      (e) => `${e[1]} lose ${e[2]}`,
      '"Lose" means to misplace or fail to win; "loose" means not tight.',
    ),
    g(
      /\b(to|can't|cannot|couldn't|can|could|will|would|must|let|help)\s+breath\b/gi,
      (e) => `${e[1]} breathe`,
      '"Breathe" is the verb; "breath" is the noun.',
    ),
    g(
      /\b(a|deep|short|last|fresh|every)\s+breathe\b/gi,
      (e) => `${e[1]} breath`,
      '"Breath" is the noun ("a deep breath").',
    ),
    { corrected: ue(o, w), issues: r, suggestions: l, variant: k }
  );
}
module.exports = { me };
