// grammar-checker: keyboard path, focus, aria-live, axe on main before/after Check, and narrow-phone layout. Tool is ungated (Check/Copy cost no use), so this costs nothing.
const { chromium, devices } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const AXE = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8');
const OUT = '/workspace/deep/13-grammar-checker/live/'; const URL = 'https://www.freedailypro.com/tool/grammar-checker';
const used = async p => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
const axe = async p => { await p.addScriptTag({ content: AXE }); return p.evaluate(async () => (await axe.run(document.querySelector('main'), { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'best-practice'] }, resultTypes: ['violations'] })).violations.map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length, t: v.nodes.slice(0, 3).map(n => n.target.join(' ')) }))); };
(async () => { const b = await chromium.launch(); const R = { t: cp.execSync('date "+%F %T %Z"').toString().trim() };
 const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(10000);
 await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); R.start = await used(p);
 R.axeBefore = await axe(p);
 await p.locator('main textarea').first().focus();
 await p.keyboard.type('Does she have time? Their going home. I has a apple.');
 const seq = [];
 for (let i = 0; i < 6; i++) { await p.keyboard.press('Tab'); seq.push(await p.evaluate(() => { const e = document.activeElement; const s = getComputedStyle(e); return { tag: e.tagName, name: (e.getAttribute('aria-label') || e.innerText || e.value || '').trim().slice(0, 40), outline: s.outlineStyle + ' ' + s.outlineWidth, ring: s.boxShadow !== 'none' }; })); }
 R.tabFromTextarea = seq;
 await p.locator('main textarea').first().focus(); await p.keyboard.press('Tab');
 R.firstTabTarget = await p.evaluate(() => (document.activeElement.innerText || document.activeElement.getAttribute('aria-label') || '').trim());
 if (/Check Grammar/.test(R.firstTabTarget)) await p.keyboard.press('Enter'); else await p.getByRole('button', { name: 'Check Grammar', exact: true }).click();
 await p.waitForTimeout(2000);
 R.focusAfterCheck = await p.evaluate(() => document.activeElement.tagName + ' ' + (document.activeElement.innerText || '').trim().slice(0, 40));
 R.liveRegions = await p.evaluate(() => [...document.querySelectorAll('main [aria-live],main [role=status],main [role=alert]')].map(e => ({ live: e.getAttribute('aria-live'), role: e.getAttribute('role'), text: e.innerText.slice(0, 80) })));
 R.corrected = await p.evaluate(() => document.querySelectorAll('main textarea')[1]?.value);
 R.outputTextarea = await p.evaluate(() => { const t = document.querySelectorAll('main textarea')[1]; return t ? { readOnly: t.readOnly, label: t.getAttribute('aria-label'), labelledby: t.getAttribute('aria-labelledby') } : null; });
 R.axeAfter = await axe(p); R.after = await used(p);
 await p.screenshot({ path: OUT + 'kbd-after-check.png' });
 for (const [nm, d] of [['iphone-se', devices['iPhone SE']], ['pixel-7', devices['Pixel 7']]]) {
  const c2 = await b.newContext({ ...d, defaultBrowserType: undefined }); const q = await c2.newPage(); q.setDefaultTimeout(10000);
  await q.goto(URL, { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4000);
  const s0 = await used(q);
  await q.locator('main textarea').first().fill('Does she have time to meet tomorrow? Their going home.');
  await q.getByRole('button', { name: 'Check Grammar', exact: true }).click(); await q.waitForTimeout(1500);
  const lay = await q.evaluate(() => { const r = e => e ? Math.round(e.getBoundingClientRect().top + scrollY) : null; const ta = document.querySelectorAll('main textarea'); const btn = [...document.querySelectorAll('main button')].find(x => x.innerText.trim() === 'Check Grammar'); return { vh: innerHeight, inputTop: r(ta[0]), btnTop: r(btn), outputTop: r(ta[1]), overflowX: document.documentElement.scrollWidth > innerWidth + 1, btnH: btn && Math.round(btn.getBoundingClientRect().height) }; });
  R[nm] = { start: s0, ...lay };
  await q.screenshot({ path: OUT + `layout-${nm}.png` }); await c2.close(); }
 R.t2 = cp.execSync('date "+%F %T %Z"').toString().trim();
 fs.writeFileSync(OUT + 'kbd.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
