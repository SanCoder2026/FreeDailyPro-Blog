// grammar-checker: runs every gc-cases.json sentence through the live page (Check Grammar), compares with gc-offline output; then Copy at the starting count, UK variant, a long text timing.
// Check Grammar did not change fdp-usage-v1 at 0 remaining (probe.json); counts are recorded before/after anyway (display-only).
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const path = require('path');
const OUT = '/workspace/deep/13-grammar-checker/live/'; const URL = 'https://www.freedailypro.com/tool/grammar-checker';
const cases = JSON.parse(fs.readFileSync(path.join(__dirname, 'gc-cases.json'), 'utf8'));
(async () => { const b = await chromium.launch(); const R = { t: cp.execSync('date "+%F %T %Z"').toString().trim(), cases: {} };
 const c = await b.newContext({ viewport: { width: 1366, height: 900 }, permissions: ['clipboard-read', 'clipboard-write'] }); const p = await c.newPage(); p.setDefaultTimeout(15000);
 await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday; R.start = await used();
 const check = async (t) => { await p.locator('main textarea').first().fill(t); await p.getByRole('button', { name: 'Check Grammar', exact: true }).click(); await p.waitForTimeout(700);
  return p.evaluate(() => { const t = document.querySelectorAll('main textarea'); return { corrected: t[1]?.value ?? null, fixes: document.querySelector('[data-testid=gc-fixes]')?.innerText.replace(/\n+/g, ' ') ?? null, sugg: document.querySelector('[data-testid=gc-suggestions]')?.innerText.replace(/\n+/g, ' ') ?? null }; }); };
 for (const [id, t] of cases.fp) { const r = await check(t); r.changed = r.corrected !== t; R.cases[id] = { input: t, ...r }; console.log(id, r.changed ? 'CHANGED' : 'ok     ', '|', r.changed ? r.corrected : t); }
 for (const [id, t, exp] of cases.fix) { const r = await check(t); r.ok = r.corrected === exp; R.cases[id] = { input: t, expected: exp, ...r }; console.log(id, r.ok ? 'FIXED ' : 'MISSED', '|', r.corrected, r.sugg ? '| ' + r.sugg.slice(0, 120) : ''); }
 R.afterCases = await used();
 // UK variant
 await p.selectOption('[data-testid=gc-variant]', 'uk'); R.uk = await check('The colour of the center is gray and I organized it.'); await p.selectOption('[data-testid=gc-variant]', 'auto');
 // Copy at the starting count
 await check('i dont know.'); const before = await used(); await p.getByRole('button', { name: 'Copy', exact: true }).click(); await p.waitForTimeout(1500);
 const dl = p.locator('[role=dialog],[role=alertdialog]'); R.copy = { before, after: await used(), dialog: (await dl.count()) ? (await dl.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 260) : null, clip: (await p.evaluate(() => navigator.clipboard.readText()).catch(e => 'ERR ' + e)).slice(0, 80), toast: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText).join(' | ')) };
 if (R.copy.dialog) { await p.screenshot({ path: OUT + 'copy-dialog.png' }); await p.keyboard.press('Escape'); }
 // long text
 const para = 'Their going to the store and i dont know why. The colour is nice. Does she have time? '; const long = para.repeat(600);
 const t0 = Date.now(); const lr = await check(long); R.long = { words: long.split(/\s+/).length, ms: Date.now() - t0, correctedLen: lr.corrected?.length, fixes: lr.fixes?.slice(0, 200) };
 await p.locator('[data-testid=tool-area]').screenshot({ path: OUT + 'result-long.png' }).catch(() => {});
 R.end = await used(); R.t2 = cp.execSync('date "+%F %T %Z"').toString().trim();
 fs.writeFileSync(OUT + 'live-cases.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify({ start: R.start, afterCases: R.afterCases, uk: R.uk, copy: R.copy, long: R.long, end: R.end }, null, 1)); await b.close(); })();
