// grammar-checker: runs the page's own rule engine (me(), extracted verbatim from GrammarChecker-C8oR9yRI.js) with nspell 2.1.5 and the site's /dict/en_US files.
// No browser, no trial use. Live spot-checks: gc-live.js. Usage: node gc-offline.js [variant auto|us|uk]
const fs = require('fs'); const path = require('path'); const nspell = require('nspell');
const D = '/workspace/deep/13-grammar-checker/js/'; const { me } = require(D + 'me-engine.js');
const sp = nspell(fs.readFileSync(D + 'dict/en_US.aff', 'utf8'), fs.readFileSync(D + 'dict/en_US.dic', 'utf8'));
const cases = JSON.parse(fs.readFileSync(path.join(__dirname, 'gc-cases.json'), 'utf8')); const variant = process.argv[2] || 'auto'; const R = { variant, fp: [], fix: [] };
for (const [id, t] of cases.fp) { const r = me(t, sp, { variant, localeHint: 'en-US' }); const changed = r.corrected !== t; R.fp.push({ id, input: t, corrected: r.corrected, changed, issues: r.issues.map(i => i.message), suggestions: r.suggestions.map(i => i.message) }); console.log(id, changed ? 'CHANGED' : 'ok     ', '|', t, changed ? '=> ' + r.corrected : ''); }
for (const [id, t, exp] of cases.fix) { const r = me(t, sp, { variant, localeHint: 'en-US' }); const ok = r.corrected === exp; R.fix.push({ id, input: t, expected: exp, corrected: r.corrected, ok, issues: r.issues.map(i => i.message), suggestions: r.suggestions.map(i => i.message) }); console.log(id, ok ? 'FIXED  ' : 'MISSED ', '|', t, '=>', r.corrected, ok ? '' : '| exp ' + exp, r.suggestions.length ? '| sugg: ' + r.suggestions.map(s => s.message).join(' / ').slice(0, 140) : ''); }
fs.writeFileSync('/workspace/deep/13-grammar-checker/live/offline-' + variant + '.json', JSON.stringify(R, null, 1));
