import { r as n, j as a } from "./vendor-react-D01g8YgM.js";
import { u as ie } from "./useShareGate-BKOKt_4Z.js";
import { T as le, D as Y, d as de } from "./ToolPage-DS5jbfzr.js";
import { B as m, aJ as me, f as $ } from "./index-D2ZT81un.js";
import {
  S as ue,
  a as pe,
  b as he,
  c as ge,
  d as xe,
} from "./select-DC0cHVOZ.js";
import { C as fe } from "./CameraNotice-jDAmBE_d.js";
import { T as we } from "./ToolInfoSection-M0kcUBq8.js";
import { g as A } from "./mediaPermissions-Bds5TGtW.js";
import { M as ve } from "./MediaPermissionAlert-C-2kBgB_.js";
import { T as ye } from "./ToolSteps-DtiMymsE.js";
import { u as je } from "./useDownloadedResult-C1FfMpBH.js";
import { C as E } from "./camera-mA9gIB_c.js";
import { C as Ce } from "./crop-BNhT7cjd.js";
import { C as be } from "./copy-DxyF2bO9.js";
import "./useExportGate-CcXGEF0S.js";
import "./useUploadApi-CeBVbB2U.js";
import "./cloudStorage-BzUdFuQl.js";
import "./share-2-wJ7OG3q6.js";
import "./workflowCta-QcLjv4ms.js";
import "./UsageAndUpgradeStrip-Ckl_cEoN.js";
import "./access-BBg1iIm1.js";
import "./useAdminAccess-D2xxeUJv.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-BaZhqv4P.js";
import "./map-pin-DiPhQKiV.js";
import "./FaqSection-DgbFc-d2.js";
import "./ToolVideoEmbed-DltoCXpM.js";
import "./GuideLinks-BsEl-oB0.js";
import "./blog-Cqpj3gtZ.js";
import "./info-BGlOhDp4.js";
import "./productCards-CAZfINO_.js";
import "./layers-B7zHnkyf.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./chevron-up-Bx33pgGu.js";
import "./CollapsibleText-CmqWEytu.js";
const B = {
  what: "Takes a photo using your device's camera (webcam, front, or rear camera) directly in your browser — no separate camera app or upload step needed. Optionally crop the photo down to just the region you want after capturing. Runs entirely in your browser — nothing is uploaded anywhere.",
  how: "Grant camera access, choose a camera if more than one is available, and click Capture. Drag a rectangle over the photo to crop it if you only need part of the frame, then download or copy the result.",
  tip: "If your device has multiple cameras (front and rear on a phone, or an external webcam alongside a built-in one on a laptop), a dropdown to switch between them appears once camera access is granted — the first camera your browser lists isn't always the one you want.",
};
function ct() {
  const { gateShare: G } = ie(),
    [x, j] = n.useState(!1),
    [H, f] = n.useState(null),
    [W, J] = n.useState([]),
    [N, M] = n.useState(""),
    [o, I] = n.useState(null),
    [s, w] = n.useState(null),
    [l, k] = n.useState(null),
    [v, u] = n.useState(null),
    [V, O] = n.useState(0),
    [F, X] = n.useState("user"),
    [p, K] = n.useState(!1),
    [U, _] = n.useState(""),
    C = n.useRef(null),
    b = n.useRef(null),
    P = n.useRef(null),
    y = n.useRef(null),
    z = je(o),
    h = n.useCallback(() => {
      (b.current?.getTracks().forEach((e) => e.stop()),
        (b.current = null),
        j(!1));
    }, []);
  n.useEffect(() => () => h(), [h]);
  const T = async (e) => {
    f(null);
    try {
      const t = {
          video: e
            ? {
                deviceId: { exact: e },
                width: { ideal: 4096 },
                height: { ideal: 2160 },
              }
            : {
                facingMode: F,
                width: { ideal: 4096 },
                height: { ideal: 2160 },
              },
        },
        r = await navigator.mediaDevices.getUserMedia(t);
      ((b.current = r),
        (y.current = r),
        j(!0),
        O((i) => i + 1),
        I(null),
        u(null));
      const d = (await navigator.mediaDevices.enumerateDevices())
        .filter((i) => i.kind === "videoinput")
        .map((i, g) => ({
          deviceId: i.deviceId,
          label: i.label || `Camera ${g + 1}`,
        }));
      if ((J(d), !N && d.length > 0)) {
        const g = r.getVideoTracks()[0].getSettings().deviceId;
        M(g || d[0].deviceId);
      }
    } catch (t) {
      f(A(t, "camera"));
    }
  };
  n.useEffect(() => {
    if (!x || !y.current || !C.current) return;
    const e = C.current,
      t = y.current;
    ((y.current = null),
      (e.srcObject = t),
      (e.onloadedmetadata = () => _(`${e.videoWidth} x ${e.videoHeight}`)),
      e.play().catch((r) => {
        (console.error("Video playback failed:", r),
          f(
            "Got camera access, but the preview couldn't start playing. Try again.",
          ),
          t.getTracks().forEach((c) => c.stop()),
          j(!1));
      }));
  }, [x, V]);
  const q = (e) => {
      (M(e), h(), T(e));
    },
    Q = () => {
      const e = F === "user" ? "environment" : "user";
      (X(e), h(), M(""), setTimeout(() => Z(e), 0));
    },
    Z = async (e) => {
      f(null);
      try {
        const t = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: e },
            width: { ideal: 4096 },
            height: { ideal: 2160 },
          },
        });
        ((b.current = t),
          (y.current = t),
          j(!0),
          O((r) => r + 1),
          I(null),
          u(null));
      } catch (t) {
        f(A(t, "camera"));
      }
    },
    D = () => {
      const e = new Date(),
        t = (r) => String(r).padStart(2, "0");
      return `camera-${e.getFullYear()}${t(e.getMonth() + 1)}${t(e.getDate())}-${t(e.getHours())}${t(e.getMinutes())}${t(e.getSeconds())}`;
    },
    ee = () => {
      const e = C.current;
      if (!e) return;
      if (e.videoWidth === 0 || e.videoHeight === 0) {
        $.error(
          "The camera preview isn't ready yet — wait a moment for the live feed to appear, then try again.",
        );
        return;
      }
      const t = document.createElement("canvas");
      ((t.width = e.videoWidth),
        (t.height = e.videoHeight),
        t.getContext("2d").drawImage(e, 0, 0));
      const r = new Image();
      ((r.onload = () => {
        (I(r), w(null), u(null));
      }),
        (r.src = t.toDataURL("image/png")),
        h());
    },
    R = (e, t) => {
      const r = P.current;
      if (!r || !o) return null;
      const c = r.getBoundingClientRect(),
        d = o.naturalWidth / c.width,
        i = o.naturalHeight / c.height;
      return {
        x: Math.max(0, Math.min(o.naturalWidth, (e - c.left) * d)),
        y: Math.max(0, Math.min(o.naturalHeight, (t - c.top) * i)),
      };
    },
    L = (e) => R(e.clientX, e.clientY),
    te = (e) => {
      const t = L(e);
      t && (k(t), w({ x: t.x, y: t.y, w: 0, h: 0 }), u(null));
    },
    ae = (e) => {
      if (!l) return;
      const t = L(e);
      t &&
        w({
          x: Math.min(l.x, t.x),
          y: Math.min(l.y, t.y),
          w: Math.abs(t.x - l.x),
          h: Math.abs(t.y - l.y),
        });
    },
    S = () => k(null),
    re = (e) => {
      if (e.touches.length === 0) return;
      const t = e.touches[0],
        r = R(t.clientX, t.clientY);
      r && (k(r), w({ x: r.x, y: r.y, w: 0, h: 0 }), u(null));
    },
    oe = (e) => {
      if (!l || e.touches.length === 0) return;
      e.preventDefault();
      const t = e.touches[0],
        r = R(t.clientX, t.clientY);
      r &&
        w({
          x: Math.min(l.x, r.x),
          y: Math.min(l.y, r.y),
          w: Math.abs(r.x - l.x),
          h: Math.abs(r.y - l.y),
        });
    },
    se = () => {
      if (!o || !s || s.w < 2 || s.h < 2) return;
      const e = document.createElement("canvas");
      ((e.width = s.w),
        (e.height = s.h),
        e.getContext("2d").drawImage(o, s.x, s.y, s.w, s.h, 0, 0, s.w, s.h),
        e.toBlob(
          (t) => {
            t && u(t);
          },
          p ? "image/jpeg" : "image/png",
          0.92,
        ));
    },
    ne = () => {
      if (!o) return;
      const e = document.createElement("canvas");
      ((e.width = o.naturalWidth),
        (e.height = o.naturalHeight),
        e.getContext("2d").drawImage(o, 0, 0),
        e.toBlob(
          (t) => {
            t && de(t, `${D()}.${p ? "jpg" : "png"}`);
          },
          p ? "image/jpeg" : "image/png",
          0.92,
        ));
    },
    ce = (e) =>
      G(async () => {
        try {
          let t = e;
          if (e.type !== "image/png") {
            const r = await createImageBitmap(e),
              c = document.createElement("canvas");
            ((c.width = r.width),
              (c.height = r.height),
              c.getContext("2d").drawImage(r, 0, 0),
              (t = await new Promise((d, i) =>
                c.toBlob(
                  (g) => (g ? d(g) : i(new Error("encode"))),
                  "image/png",
                ),
              )));
          }
          return (
            await navigator.clipboard.write([
              new ClipboardItem({ "image/png": t }),
            ]),
            $.success("Copied to clipboard!"),
            !0
          );
        } catch {
          return (
            $.error(
              "Couldn't copy to clipboard in this browser — try downloading instead.",
            ),
            !1
          );
        }
      });
  return a.jsxs(le, {
    children: [
      a.jsx(ye, {
        toolId: "camera-capture",
        state: {
          cameraOn: x || !!o,
          captured: !!o,
          cropped: !!o && !!v,
          downloaded: z,
        },
      }),
      !x &&
        !o &&
        a.jsxs("div", {
          className:
            "py-16 border-2 border-dashed rounded-xl text-center space-y-3",
          children: [
            a.jsx(E, { className: "h-12 w-12 mx-auto text-muted-foreground" }),
            a.jsx(fe, { purpose: "photo" }),
            a.jsxs(m, {
              onClick: () => T(),
              className: "gap-2",
              children: [a.jsx(E, { className: "h-4 w-4" }), " Start Camera"],
            }),
            H &&
              a.jsx("div", {
                className: "px-4 max-w-md mx-auto text-left",
                children: a.jsx(ve, { message: H }),
              }),
          ],
        }),
      x &&
        a.jsxs("div", {
          className: "space-y-4 text-center",
          children: [
            W.length > 1 &&
              a.jsx("div", {
                className: "max-w-xs mx-auto text-left",
                children: a.jsxs(ue, {
                  value: N,
                  onValueChange: q,
                  children: [
                    a.jsx(pe, {
                      children: a.jsx(he, { placeholder: "Choose a camera" }),
                    }),
                    a.jsx(ge, {
                      children: W.map((e) =>
                        a.jsx(
                          xe,
                          { value: e.deviceId, children: e.label },
                          e.deviceId,
                        ),
                      ),
                    }),
                  ],
                }),
              }),
            U &&
              a.jsxs("p", {
                className: "text-xs text-muted-foreground",
                children: ["Camera resolution: ", U],
              }),
            a.jsx("video", {
              ref: C,
              autoPlay: !0,
              playsInline: !0,
              muted: !0,
              className: "w-full max-h-96 rounded-lg border mx-auto",
            }),
            a.jsxs("div", {
              className: "flex gap-3 justify-center",
              children: [
                a.jsxs(m, {
                  onClick: ee,
                  className: "gap-2",
                  children: [a.jsx(E, { className: "h-4 w-4" }), " Capture"],
                }),
                a.jsx(m, {
                  variant: "outline",
                  onClick: Q,
                  children: "Front / rear camera",
                }),
                a.jsxs("label", {
                  className: "flex items-center gap-1 text-sm",
                  children: [
                    a.jsx("input", {
                      type: "checkbox",
                      checked: p,
                      onChange: (e) => K(e.target.checked),
                    }),
                    " Save as JPG",
                  ],
                }),
                a.jsx(m, {
                  variant: "outline",
                  onClick: h,
                  children: "Cancel",
                }),
              ],
            }),
          ],
        }),
      o &&
        a.jsxs("div", {
          className: "space-y-4",
          children: [
            a.jsx("p", {
              className: "text-sm text-muted-foreground text-center",
              children:
                "Drag a rectangle to crop, or download the full photo as-is",
            }),
            a.jsxs("div", {
              className:
                "relative inline-block mx-auto max-w-full cursor-crosshair select-none",
              onMouseDown: te,
              onMouseMove: ae,
              onMouseUp: S,
              onMouseLeave: S,
              onTouchStart: re,
              onTouchMove: oe,
              onTouchEnd: S,
              onTouchCancel: S,
              style: { touchAction: "none" },
              children: [
                a.jsx("img", {
                  ref: P,
                  src: o.src,
                  className: "max-w-full max-h-[60vh] rounded-lg border block",
                  draggable: !1,
                }),
                s &&
                  s.w > 0 &&
                  a.jsx("div", {
                    className:
                      "absolute border-2 border-primary bg-primary/20 pointer-events-none",
                    style: {
                      left: `${(s.x / o.naturalWidth) * 100}%`,
                      top: `${(s.y / o.naturalHeight) * 100}%`,
                      width: `${(s.w / o.naturalWidth) * 100}%`,
                      height: `${(s.h / o.naturalHeight) * 100}%`,
                    },
                  }),
              ],
            }),
            a.jsxs("div", {
              className: "flex gap-3 justify-center flex-wrap",
              children: [
                a.jsx(Y, {
                  onClick: ne,
                  markHint: `${D()}.${p ? "jpg" : "png"}`,
                  label: "Download Full Photo",
                }),
                a.jsxs(m, {
                  variant: "outline",
                  onClick: se,
                  disabled: !s || s.w < 2,
                  className: "gap-2",
                  children: [
                    a.jsx(Ce, { className: "h-3.5 w-3.5" }),
                    " Crop Selection",
                  ],
                }),
                a.jsxs(m, {
                  variant: "outline",
                  onClick: () => T(N),
                  className: "gap-2",
                  children: [
                    a.jsx(me, { className: "h-3.5 w-3.5" }),
                    " Retake",
                  ],
                }),
              ],
            }),
            v &&
              a.jsxs("div", {
                className:
                  "p-4 rounded-lg border bg-card space-y-3 text-center max-w-sm mx-auto",
                children: [
                  a.jsx("img", {
                    src: URL.createObjectURL(v),
                    className: "max-w-full rounded border mx-auto",
                  }),
                  a.jsxs("div", {
                    className: "flex gap-3 justify-center",
                    children: [
                      a.jsx(Y, {
                        blob: v,
                        fileName: `${D()}-cropped.${p ? "jpg" : "png"}`,
                        label: "Download Crop",
                      }),
                      a.jsxs(m, {
                        variant: "outline",
                        onClick: () => ce(v),
                        className: "gap-2",
                        children: [
                          a.jsx(be, { className: "h-3.5 w-3.5" }),
                          " Copy",
                        ],
                      }),
                    ],
                  }),
                ],
              }),
          ],
        }),
      a.jsx(we, { whatIsIt: B.what, howToUse: B.how, tip: B.tip }),
    ],
  });
}
export { ct as default };
//# sourceMappingURL=CameraCapture-0Z_gFqDj.js.map
