import { j as e } from "./vendor-react-D01g8YgM.js";
import { N as a } from "./index-D2ZT81un.js";
import { C as o } from "./camera-mA9gIB_c.js";
const s =
    "The camera is needed to read the code. Frames stay on your device and nothing is uploaded.",
  r =
    "The camera is needed to take the photo. Frames stay on your device and nothing is uploaded.";
function n({ purpose: t = "code" }) {
  return e.jsx("div", {
    className: "px-4 max-w-md mx-auto text-left",
    children: e.jsxs(a, {
      className: "flex gap-2 items-start text-sm",
      testId: "camera-notice",
      children: [
        e.jsx(o, { className: "h-4 w-4 shrink-0 mt-0.5 text-primary" }),
        e.jsx("p", { children: t === "photo" ? r : s }),
      ],
    }),
  });
}
export { n as C };
//# sourceMappingURL=CameraNotice-jDAmBE_d.js.map
