// camera-capture: what "Save to Google Drive" and "Save to my cloud storage" do for a guest at the starting count (no sign-in; popups are recorded and closed).
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/14-camera-capture/live/'; const URL = 'https://www.freedailypro.com/tool/camera-capture'; const Y4M = '/workspace/deep/14-camera-capture/fake/quad.y4m';
const used = async p => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
(async () => { const R = { t: cp.execSync('date "+%F %T %Z"').toString().trim() };
 const b = await chromium.launch({ args: ['--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', `--use-file-for-fake-video-capture=${Y4M}`] });
 const c = await b.newContext({ viewport: { width: 1366, height: 900 }, permissions: ['camera'] }); const p = await c.newPage(); p.setDefaultTimeout(10000);
 const pops = []; c.on('page', x => pops.push(x));
 await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); R.start = await used(p);
 const prep = async () => { await p.getByRole('button', { name: 'Start Camera', exact: true }).click(); await p.waitForTimeout(2500); await p.getByRole('button', { name: 'Capture', exact: true }).click(); await p.waitForTimeout(1200);
  const bb = await p.locator('main img[draggable=false]').boundingBox(); await p.mouse.move(bb.x + bb.width * .2, bb.y + bb.height * .2); await p.mouse.down(); await p.mouse.move(bb.x + bb.width * .6, bb.y + bb.height * .6, { steps: 4 }); await p.mouse.up();
  await p.getByRole('button', { name: 'Crop Selection' }).click(); await p.waitForTimeout(800); return bb; };
 const bb = await prep();
 for (const lbl of ['Save to Google Drive', 'Save to my cloud storage']) {
  await p.getByRole('button', { name: lbl }).first().click(); await p.waitForTimeout(3000);
  const d = p.locator('[role=dialog],[role=alertdialog]');
  R[lbl] = { dialog: (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 400) : null, url: p.url(), popups: pops.map(x => x.url().replace(/(client_id|state|code_challenge)=[^&]+/g, '$1=REDACTED').slice(0, 200)), toast: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText).join(' | ').slice(0, 300)), count: await used(p) };
  await p.screenshot({ path: OUT + `cloud-${lbl.replace(/\W+/g, '-').toLowerCase()}.png` });
  for (const x of pops.splice(0)) await x.close(); if (await d.count()) { await p.keyboard.press('Escape'); await p.waitForTimeout(600); }
  if (p.url() !== URL) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); await prep(); } }
 // tap on the photo after cropping: is the crop result discarded?
 const b2 = await p.locator('main img[draggable=false]').boundingBox(); const before = await p.locator('main img[src^="blob:"]').count();
 await p.mouse.click(b2.x + 30, b2.y + 30); await p.waitForTimeout(500); R.clickAfterCrop = { cropShownBefore: before, cropShownAfter: await p.locator('main img[src^="blob:"]').count() };
 R.end = await used(p); R.t2 = cp.execSync('date "+%F %T %Z"').toString().trim();
 fs.writeFileSync(OUT + 'cloud.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
