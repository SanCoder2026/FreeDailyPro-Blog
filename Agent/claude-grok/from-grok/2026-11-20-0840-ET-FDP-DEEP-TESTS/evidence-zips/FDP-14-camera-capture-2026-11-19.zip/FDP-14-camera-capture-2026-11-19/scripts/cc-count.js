// read-only: starting trial count for several fresh guest contexts (no clicks).
const { chromium, devices } = require('playwright');
(async () => { const b = await chromium.launch({ args: ['--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream=device-count=2'] });
 for (const [n, o] of [['desktop', { viewport: { width: 1366, height: 900 } }], ['pixel7', devices['Pixel 7']], ['galaxy', devices['Galaxy S9+']], ['desktop-de', { viewport: { width: 1366, height: 900 }, locale: 'de-DE' }]]) {
  const c = await b.newContext({ ...o, permissions: ['camera'] }); const p = await c.newPage();
  await p.goto('https://www.freedailypro.com/tool/camera-capture', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
  const u = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
  const cams = await p.evaluate(async () => { await navigator.mediaDevices.getUserMedia({ video: true }).then(s => s.getTracks().forEach(t => t.stop())).catch(() => { }); return (await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === 'videoinput').map(d => d.label); });
  console.log(n, u, JSON.stringify(cams), await p.evaluate(() => (document.body.innerText.match(/Trial: [^\n]*/) || [''])[0])); await c.close(); }
 await b.close(); })();
