const { firefox } = require('/workspace/deep/tools-env/node_modules/playwright');
(async () => { const b = await firefox.launch({ firefoxUserPrefs: { 'permissions.default.camera': 2, 'media.navigator.streams.fake': true } });
 const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); await p.goto('https://www.freedailypro.com/tool/camera-capture', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
 const e = await p.evaluate(async () => { try { await navigator.mediaDevices.getUserMedia({ video: true }); return 'ok'; } catch (e) { return e.name; } });
 await p.getByRole('button', { name: 'Start Camera', exact: true }).click(); await p.waitForTimeout(2500);
 const m = await p.evaluate(() => document.querySelector('main [role=alert]')?.innerText);
 console.log(e, '|', m); await p.locator('main [role=alert]').scrollIntoViewIfNeeded().catch(()=>{}); await p.screenshot({ path: '/workspace/deep/14-camera-capture/live/ui-denied-firefox.png' }); await b.close(); })();
