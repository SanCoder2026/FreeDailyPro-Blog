# Inspect camera-capture downloads made from the fake quad camera (red TL, lime TR, blue BL, yellow BR; text top-left).
# Reports format, size, and how many pixels in the top-right and bottom-right corner boxes differ from the expected quadrant colour (a badge shows up as non-zero).
import sys, json
from PIL import Image
exp = {'tr': (0, 255, 0), 'br': (255, 255, 0)}
out = []
for f in sys.argv[1:]:
    im = Image.open(f); fmt = im.format; im = im.convert('RGB'); w, h = im.size
    r = {'file': f, 'format': fmt, 'size': [w, h]}
    for k, box in {'tr': (int(w*.6), 0, w, int(h*.15)), 'br': (int(w*.6), int(h*.85), w, h)}.items():
        c = im.crop(box); px = list(c.getdata()); e = exp[k]
        r[k + '_off_pixels'] = sum(1 for p in px if max(abs(p[i]-e[i]) for i in range(3)) > 40)
        r[k + '_total'] = len(px)
    out.append(r)
print(json.dumps(out, indent=1))
