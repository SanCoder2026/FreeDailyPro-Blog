// camera-capture: keyboard path, axe on main (idle, live, captured), aria-live, mark notice text, phone layout with a fake camera. No exports clicked.
const { chromium, devices } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/14-camera-capture/live/'; const URL = 'https://www.freedailypro.com/tool/camera-capture';
const Y4M = '/workspace/deep/14-camera-capture/fake/quad.y4m';
const AXE = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8');
const used = async p => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
const axe = async p => { await p.addScriptTag({ content: AXE }); return p.evaluate(async () => (await axe.run(document.querySelector('main'), { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'best-practice'] }, resultTypes: ['violations'] })).violations.map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length, t: v.nodes.slice(0, 3).map(n => n.target.join(' ')) }))); };
const focusInfo = p => p.evaluate(() => { const e = document.activeElement; const s = getComputedStyle(e); return { tag: e.tagName, name: (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 40), ring: s.boxShadow !== 'none' || s.outlineStyle !== 'none' }; });
(async () => { const R = { t: cp.execSync('date "+%F %T %Z"').toString().trim() };
 const b = await chromium.launch({ args: ['--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', `--use-file-for-fake-video-capture=${Y4M}`] });
 const c = await b.newContext({ viewport: { width: 1366, height: 900 }, permissions: ['camera'] }); const p = await c.newPage(); p.setDefaultTimeout(10000);
 await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); R.start = await used(p);
 R.axeIdle = await axe(p);
 await p.getByRole('button', { name: 'Start Camera', exact: true }).focus(); R.focusStart = await focusInfo(p);
 await p.keyboard.press('Enter'); await p.waitForTimeout(2500);
 R.focusAfterStart = await focusInfo(p);
 R.liveRegions = await p.evaluate(() => [...document.querySelectorAll('main [aria-live],main [role=status],main [role=alert]')].map(e => ({ live: e.getAttribute('aria-live'), role: e.getAttribute('role'), text: e.innerText.slice(0, 90) })));
 R.axeLive = await axe(p);
 const seq = []; await p.getByRole('button', { name: 'Capture', exact: true }).focus(); seq.push(await focusInfo(p)); for (let i = 0; i < 4; i++) { await p.keyboard.press('Tab'); seq.push(await focusInfo(p)); } R.tabLive = seq;
 await p.getByRole('button', { name: 'Capture', exact: true }).focus(); await p.keyboard.press('Enter'); await p.waitForTimeout(1500);
 R.focusAfterCapture = await focusInfo(p);
 R.axeCaptured = await axe(p);
 R.notices = await p.evaluate(() => [...document.querySelectorAll('[data-testid=trial-mark-notice],[data-testid=export-remaining]')].map(e => e.innerText.replace(/\s+/g, ' ').trim()));
 R.cropKeyboard = 'crop area has no tabindex/role; Crop Selection stays disabled without a mouse/touch drag';
 R.cropDisabledKeyboardOnly = await p.getByRole('button', { name: 'Crop Selection' }).isDisabled();
 await p.screenshot({ path: OUT + 'kbd-captured.png' }); await c.close();
 for (const [nm, d] of [['iphone-se', devices['iPhone SE']], ['pixel-7', devices['Pixel 7']]]) {
  const { defaultBrowserType, ...dd } = d; const c2 = await b.newContext({ ...dd, permissions: ['camera'] }); const q = await c2.newPage(); q.setDefaultTimeout(10000);
  await q.goto(URL, { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4000); const s0 = await used(q);
  const top = async sel => q.evaluate(s => { const e = typeof s === 'string' ? [...document.querySelectorAll('main button')].find(b => b.innerText.trim() === s) : null; return e ? Math.round(e.getBoundingClientRect().top + scrollY) : null; }, sel);
  const startTop = await top('Start Camera');
  await q.getByRole('button', { name: 'Start Camera', exact: true }).click(); await q.waitForTimeout(2500);
  const live = await q.evaluate(() => { const v = document.querySelector('main video'); const r = v.getBoundingClientRect(); const bt = [...document.querySelectorAll('main button')].filter(b => /Capture|Front|Cancel/.test(b.innerText)).map(b => { const x = b.getBoundingClientRect(); return [b.innerText.trim(), Math.round(x.top + scrollY), Math.round(x.right), Math.round(x.height)]; }); return { vh: innerHeight, vw: innerWidth, videoTop: Math.round(r.top + scrollY), videoH: Math.round(r.height), buttons: bt, overflowX: document.documentElement.scrollWidth > innerWidth + 1 }; });
  await q.screenshot({ path: OUT + `layout-${nm}-live.png` });
  await q.getByRole('button', { name: 'Capture', exact: true }).click(); await q.waitForTimeout(1500);
  // touch-drag crop
  const bb = await q.locator('main img[draggable=false]').boundingBox(); let touchCrop = null;
  try { const cdp = await c2.newCDPSession(q); const pt = (x, y) => [{ x, y }];
   await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: pt(bb.x + bb.width * .55, bb.y + bb.height * .55) });
   await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: pt(bb.x + bb.width * .75, bb.y + bb.height * .75) });
   await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: pt(bb.x + bb.width * .95, bb.y + bb.height * .95) });
   await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
   await q.getByRole('button', { name: 'Crop Selection' }).click(); await q.waitForTimeout(800);
   touchCrop = await q.evaluate(() => { const i = document.querySelector('main img[src^="blob:"]'); return i ? [i.naturalWidth, i.naturalHeight] : null; }); } catch (e) { touchCrop = 'err ' + e.message.slice(0, 80); }
  const cap = await q.evaluate(() => { const i = document.querySelector('main img[draggable=false]'); const r = i.getBoundingClientRect(); const bt = [...document.querySelectorAll('main button')].filter(b => /Download|Crop|Retake|Copy/.test(b.innerText)).map(b => [b.innerText.trim().slice(0, 30), Math.round(b.getBoundingClientRect().top + scrollY)]); return { imgTop: Math.round(r.top + scrollY), imgH: Math.round(r.height), buttons: bt, overflowX: document.documentElement.scrollWidth > innerWidth + 1 }; });
  await q.screenshot({ path: OUT + `layout-${nm}-captured.png`, fullPage: true });
  R[nm] = { start: s0, startTop, live, touchCrop, cap }; await c2.close(); }
 R.t2 = cp.execSync('date "+%F %T %Z"').toString().trim();
 fs.writeFileSync(OUT + 'kbd.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
