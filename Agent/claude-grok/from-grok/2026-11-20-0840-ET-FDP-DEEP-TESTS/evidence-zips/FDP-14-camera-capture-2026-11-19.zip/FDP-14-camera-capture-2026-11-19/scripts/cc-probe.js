// camera-capture: guest probe with a known fake camera (1280x720 quadrants: red TL, lime TR, blue BL, yellow BR, text top-left).
// Phase 1 (no export): start, resolution, cameras, front/rear, capture, crop. Phase 2: Download Full, Download Crop, Copy at the starting count.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/14-camera-capture/live/'; const URL = 'https://www.freedailypro.com/tool/camera-capture';
const Y4M = '/workspace/deep/14-camera-capture/fake/quad.y4m';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => {
 const tag = process.argv[2] || 'desk'; const devCount = process.argv[3] || '1';
 const b = await chromium.launch({ args: ['--use-fake-ui-for-media-stream', `--use-fake-device-for-media-stream=device-count=${devCount}`, `--use-file-for-fake-video-capture=${Y4M}`] });
 const R = { t: now(), tag };
 const c = await b.newContext({ viewport: { width: 1366, height: 900 }, permissions: ['camera', 'clipboard-read', 'clipboard-write'], acceptDownloads: true });
 await c.addInitScript(() => { window.print = () => { window.__printed = (window.__printed || 0) + 1; }; });
 const p = await c.newPage(); p.setDefaultTimeout(10000);
 const cons = []; p.on('console', m => { if (m.type() === 'error') cons.push(m.text().slice(0, 160)); });
 const net = []; p.on('request', r => { if (/usage|trpc|upload|api\//i.test(r.url()) && r.method() !== 'GET') net.push(r.method() + ' ' + r.url().replace(/deviceId[^&]*/, 'deviceId=REDACTED').slice(0, 140) + ' ' + ((r.postData() || '').length)); });
 await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
 const steps = async () => p.evaluate(() => (document.body.innerText.match(/\d of 4 steps done[^\n]*/) || [null])[0]);
 const btns = async () => p.evaluate(() => [...document.querySelectorAll('main button, main label, main [role=combobox]')].map(e => (e.getAttribute('aria-label') || e.innerText).trim()).filter(Boolean).filter(t => t.length < 40).slice(0, 30));
 R.start = await used(); R.strip = await p.evaluate(() => (document.body.innerText.match(/[^\n]*(trial use|Trial)[^\n]*/g) || []).slice(0, 5));
 R.steps0 = await steps(); R.buttons0 = await btns();
 await p.getByRole('button', { name: 'Start Camera', exact: true }).click(); await p.waitForTimeout(2500);
 R.resolution = await p.evaluate(() => (document.body.innerText.match(/Camera resolution: [^\n]*/) || [null])[0]);
 R.steps1 = await steps(); R.buttons1 = await btns();
 R.combobox = await p.locator('main [role=combobox]').count();
 R.video = await p.evaluate(() => { const v = document.querySelector('main video'); return v && { w: v.videoWidth, h: v.videoHeight, transform: getComputedStyle(v).transform, label: v.getAttribute('aria-label') }; });
 await p.screenshot({ path: OUT + `${tag}-live-preview.png` });
 // front/rear toggle
 await p.getByRole('button', { name: 'Front / rear camera' }).click(); await p.waitForTimeout(2000);
 R.afterToggle = { resolution: await p.evaluate(() => (document.body.innerText.match(/Camera resolution: [^\n]*/) || [null])[0]), video: await p.evaluate(() => !!document.querySelector('main video')?.videoWidth), combobox: await p.locator('main [role=combobox]').count(), comboText: (await p.locator('main [role=combobox]').count()) ? await p.locator('main [role=combobox]').first().innerText() : null };
 // capture
 await p.getByRole('button', { name: 'Capture', exact: true }).click(); await p.waitForTimeout(1500);
 R.steps2 = await steps(); R.buttons2 = await btns();
 R.trackLive = await p.evaluate(() => !!document.querySelector('main video'));
 R.jpgBoxAfterCapture = await p.getByText('Save as JPG').count();
 const img = p.locator('main img[draggable=false]'); const bb = await img.boundingBox(); R.imgBox = bb;
 R.natural = await img.evaluate(e => [e.naturalWidth, e.naturalHeight]);
 // drag the bottom-right quadrant (yellow): from 55%,55% to 95%,95%
 await p.mouse.move(bb.x + bb.width * 0.55, bb.y + bb.height * 0.55); await p.mouse.down();
 await p.mouse.move(bb.x + bb.width * 0.95, bb.y + bb.height * 0.95, { steps: 5 }); await p.mouse.up();
 await p.getByRole('button', { name: 'Crop Selection' }).click(); await p.waitForTimeout(1000);
 R.steps3 = await steps(); R.buttons3 = await btns();
 await p.screenshot({ path: OUT + `${tag}-captured-cropped.png`, fullPage: false });
 // crop pixel check from the preview <img> of the crop
 R.cropPreview = await p.evaluate(async () => { const im = [...document.querySelectorAll('main img')].find(i => i.src.startsWith('blob:')); if (!im) return null; await im.decode().catch(() => { }); const c = document.createElement('canvas'); c.width = im.naturalWidth; c.height = im.naturalHeight; const x = c.getContext('2d'); x.drawImage(im, 0, 0); const px = (a, b) => [...x.getImageData(Math.floor(a * c.width), Math.floor(b * c.height), 1, 1).data].slice(0, 3); return { w: c.width, h: c.height, center: px(0.5, 0.5), tl: px(0.02, 0.02) }; });
 R.blobImgs = await p.evaluate(() => document.querySelectorAll('main img[src^="blob:"]').length);
 R.beforeExports = await used();
 // Phase 2: exports at the starting count
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 400) : null; };
 const closeDialog = async () => { if (await p.locator('[role=dialog],[role=alertdialog]').count()) { await p.keyboard.press('Escape'); await p.waitForTimeout(500); } };
 const tryDl = async (name, label) => { const r = { label }; const dlP = p.waitForEvent('download', { timeout: 6000 }).catch(() => null);
  await p.getByRole('button', { name: label, exact: true }).first().click(); await p.waitForTimeout(1500);
  r.dialog = await dialog(); const dl = await dlP; if (dl) { r.file = dl.suggestedFilename(); const f = OUT + `${tag}-${r.file}`; await dl.saveAs(f); r.bytes = fs.statSync(f).size; try { r.ident = cp.execSync(`identify -format "%m %wx%h" "${f}"`).toString(); } catch (e) { } }
  r.count = await used(); if (r.dialog) await p.screenshot({ path: OUT + `${tag}-${name}-dialog.png` }); await closeDialog(); return r; };
 R.dlFull = await tryDl('full', 'Download Full Photo');
 R.dlCrop = await tryDl('crop', 'Download Crop');
 const before = await used(); await p.getByRole('button', { name: 'Copy', exact: true }).click(); await p.waitForTimeout(1500);
 R.copy = { before, dialog: await dialog(), toast: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast],[role=status]')].map(e => e.innerText).join(' | ').slice(0, 200)), after: await used(), clipTypes: await p.evaluate(async () => { try { const it = await navigator.clipboard.read(); return it.flatMap(i => i.types); } catch (e) { return 'err ' + e.message; } }) };
 if (R.copy.dialog) await p.screenshot({ path: OUT + `${tag}-copy-dialog.png` }); await closeDialog();
 R.end = await used(); R.console = cons.slice(0, 10); R.net = net.slice(0, 20); R.t2 = now();
 fs.writeFileSync(OUT + `${tag}-probe.json`, JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
