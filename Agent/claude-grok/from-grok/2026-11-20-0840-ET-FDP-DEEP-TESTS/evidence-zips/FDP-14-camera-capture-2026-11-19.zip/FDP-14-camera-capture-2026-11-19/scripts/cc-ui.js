// camera-capture: no-export UI checks. Camera list, mirror/pixel check of the capture, JPG crop type, Cancel/Retake, denied and no-camera errors, cloud buttons, keyboard.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/14-camera-capture/live/'; const URL = 'https://www.freedailypro.com/tool/camera-capture';
const Y4M = '/workspace/deep/14-camera-capture/fake/quad.y4m'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const used = async p => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
(async () => { const R = { t: now() };
 const b = await chromium.launch({ args: ['--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream=device-count=2', `--use-file-for-fake-video-capture=${Y4M}`] });
 const c = await b.newContext({ viewport: { width: 1366, height: 900 }, permissions: ['camera'] }); const p = await c.newPage(); p.setDefaultTimeout(10000);
 const popups = []; c.on('page', pg => popups.push(pg));
 await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); R.start = await used(p);
 await p.getByRole('button', { name: 'Start Camera', exact: true }).click(); await p.waitForTimeout(2500);
 R.cameraUi = await p.evaluate(() => ({ combos: document.querySelectorAll('[role=combobox]').length, chooseText: /Choose a camera|fake_device/.test(document.body.innerText), selects: document.querySelectorAll('select').length, comboTexts: [...document.querySelectorAll('[role=combobox]')].map(e => e.innerText.trim()) }));
 await p.screenshot({ path: OUT + 'ui-two-cameras.png' });
 // Cancel
 await p.getByRole('button', { name: 'Cancel', exact: true }).click(); await p.waitForTimeout(800);
 R.afterCancel = await p.evaluate(() => ({ video: !!document.querySelector('main video'), start: [...document.querySelectorAll('button')].some(b => b.innerText.trim() === 'Start Camera'), steps: (document.body.innerText.match(/\d of 4 steps done[^\n]*/) || [null])[0] }));
 await p.getByRole('button', { name: 'Start Camera', exact: true }).click(); await p.waitForTimeout(2500);
 // JPG on, capture, check pixels and mirror
 await p.getByLabel('Save as JPG').check().catch(async () => { await p.getByText('Save as JPG', { exact: false }).last().click(); });
 R.jpgChecked = await p.evaluate(() => [...document.querySelectorAll('main input[type=checkbox]')].map(i => i.checked));
 await p.getByRole('button', { name: 'Capture', exact: true }).click(); await p.waitForTimeout(1500);
 R.capturePixels = await p.evaluate(async () => { const im = document.querySelector('main img[draggable=false]'); await im.decode().catch(() => { }); const c = document.createElement('canvas'); c.width = im.naturalWidth; c.height = im.naturalHeight; const x = c.getContext('2d'); x.drawImage(im, 0, 0); const px = (a, b) => [...x.getImageData(Math.floor(a * c.width), Math.floor(b * c.height), 1, 1).data].slice(0, 3); return { w: c.width, h: c.height, tl: px(.25, .25), tr: px(.75, .25), bl: px(.25, .75), br: px(.75, .75), srcType: im.src.slice(0, 22) }; });
 R.checkboxAfterCapture = await p.locator('main input[type=checkbox]').count();
 const bb = await p.locator('main img[draggable=false]').boundingBox();
 await p.mouse.move(bb.x + bb.width * 0.1, bb.y + bb.height * 0.1); await p.mouse.down(); await p.mouse.move(bb.x + bb.width * 0.4, bb.y + bb.height * 0.4, { steps: 4 }); await p.mouse.up();
 await p.getByRole('button', { name: 'Crop Selection' }).click(); await p.waitForTimeout(1000);
 R.cropBlob = await p.evaluate(async () => { const im = document.querySelector('main img[src^="blob:"]'); const bl = await (await fetch(im.src)).blob(); return { type: bl.type, size: bl.size, w: im.naturalWidth, h: im.naturalHeight }; });
 // tiny drag -> crop button state
 await p.mouse.move(bb.x + 50, bb.y + 50); await p.mouse.down(); await p.mouse.up();
 R.cropDisabledAfterClick = await p.getByRole('button', { name: 'Crop Selection' }).isDisabled();
 R.cropResultStillShown = await p.locator('main img[src^="blob:"]').count();
 // keyboard: can the crop area be reached?
 R.cropAreaFocusable = await p.evaluate(() => { const d = document.querySelector('main .cursor-crosshair'); return d ? { tabindex: d.getAttribute('tabindex'), role: d.getAttribute('role'), label: d.getAttribute('aria-label') } : null; });
 R.capturedImgAlt = await p.evaluate(() => [...document.querySelectorAll('main img[draggable=false], main img[src^="blob:"]')].map(i => i.getAttribute('alt')));
 // cloud buttons at the starting count
 for (const lbl of ['Save to Google Drive', 'Save to my cloud storage']) { const btn = p.getByRole('button', { name: lbl }); if (await btn.count()) { await btn.first().click(); await p.waitForTimeout(2500); const d = p.locator('[role=dialog],[role=alertdialog]'); R[lbl] = { dialog: (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null, url: p.url(), popups: popups.map(x => x.url().slice(0, 120)), count: await used(p) }; if (await d.count()) { await p.screenshot({ path: OUT + `ui-${lbl.replace(/\W+/g, '-').toLowerCase()}.png` }); await p.keyboard.press('Escape'); await p.waitForTimeout(500); } for (const pp of popups.splice(0)) await pp.close(); } }
 // Retake
 await p.getByRole('button', { name: 'Retake' }).click(); await p.waitForTimeout(2000);
 R.afterRetake = await p.evaluate(() => ({ video: !!document.querySelector('main video')?.videoWidth, captured: !!document.querySelector('main img[draggable=false]'), checkbox: [...document.querySelectorAll('main input[type=checkbox]')].map(i => i.checked) }));
 R.end = await used(p); await c.close(); await b.close();
 // denied permission
 const b2 = await chromium.launch({ args: ['--use-fake-device-for-media-stream'] });
 const c2 = await b2.newContext({ viewport: { width: 1366, height: 900 } }); const p2 = await c2.newPage();
 await p2.goto(URL, { waitUntil: 'domcontentloaded' }); await p2.waitForTimeout(4000);
 await p2.getByRole('button', { name: 'Start Camera', exact: true }).click(); await p2.waitForTimeout(3000);
 R.denied = await p2.evaluate(() => { const m = document.querySelector('main [role=alert]'); return { alert: m ? m.innerText.replace(/\s*\n\s*/g, ' | ').slice(0, 400) : null, text: (document.body.innerText.match(/[^\n]*(camera|Camera)[^\n]*(block|denied|allow|permission|refus)[^\n]*/gi) || []).slice(0, 4) }; });
 await p2.screenshot({ path: OUT + 'ui-denied.png' }); await b2.close();
 // no camera
 const b3 = await chromium.launch({ args: ['--use-fake-ui-for-media-stream'] });
 const c3 = await b3.newContext({ viewport: { width: 1366, height: 900 }, permissions: ['camera'] }); const p3 = await c3.newPage();
 await p3.goto(URL, { waitUntil: 'domcontentloaded' }); await p3.waitForTimeout(4000);
 await p3.getByRole('button', { name: 'Start Camera', exact: true }).click(); await p3.waitForTimeout(3000);
 R.noCamera = await p3.evaluate(() => { const m = document.querySelector('main [role=alert]'); return m ? m.innerText.replace(/\s*\n\s*/g, ' | ').slice(0, 400) : (document.body.innerText.match(/[^\n]*(No camera|not found|couldn't|could not)[^\n]*/gi) || []).slice(0, 4); });
 await p3.screenshot({ path: OUT + 'ui-no-camera.png' }); await b3.close();
 R.t2 = now(); fs.writeFileSync(OUT + 'ui.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); })();
