Sent: 2026-11-21 20:04 ET

# FDP-14 camera-capture: rerun after the 7:00 PM ET reset (Nov 21 2026)

Run 19:23-19:41 ET. `cc-probe.js reset 1` (no JPG) and a copy `cc-jpg.js` (ticks "Save as JPG" while the preview is live, before Capture - the checkbox is only shown during the live preview). The first jpg run loaded at 0 (cap dialog on both downloads, 10 -> 10); runs 2 and 3 started at 0 used.
## Save as JPG (closes the pending item)
- Download Full Photo with JPG ticked: `camera-20261121-194036.jpg`, 26,191 bytes, JPEG 1280x720; Download Crop: `camera-20261121-194036-cropped.jpg`, 8,296 bytes, JPEG 512x286 (names `camera-YYYYMMDD-HHMMSS[-cropped].jpg`). PASS.
- Cost: Full 0 -> 1, Crop free, Copy free (clipboard type image/png even with JPG ticked). Same as the PNG trace.
- Badges: `tr_off_pixels` 8610/8610 and `br_off_pixels` 3980/8815 in the cropped JPG: top-right and bottom-right badges present on JPG output (cc-inspect.py on jpg-camera-*.jpg).
Evidence: live/jpg-probe.json, jpg-camera-*.jpg, rr/14jpg.log.

(Rows run in order: 4,5,7,8,11,14,20 then 28-33,40,56,57,69,73. No sign-in, no payment, no ads clicked, no admin, no API/MCP. Counters are display-only evidence.)
