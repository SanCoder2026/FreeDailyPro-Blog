const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/WordCounterExtras-CS5kAwSF.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/index-D2ZT81un.js",
      "assets/index-BJxTAPRn.css",
      "assets/CalcSteps-CMhW1YVy.js",
      "assets/ToolPage-DS5jbfzr.js",
      "assets/useUploadApi-CeBVbB2U.js",
      "assets/cloudStorage-BzUdFuQl.js",
      "assets/camera-mA9gIB_c.js",
      "assets/share-2-wJ7OG3q6.js",
      "assets/copy-DxyF2bO9.js",
      "assets/workflowCta-QcLjv4ms.js",
      "assets/UsageAndUpgradeStrip-Ckl_cEoN.js",
      "assets/access-BBg1iIm1.js",
      "assets/useAdminAccess-D2xxeUJv.js",
      "assets/tool-name-translations-d1j9ms8v.js",
      "assets/InstallToolButton-BaZhqv4P.js",
      "assets/map-pin-DiPhQKiV.js",
      "assets/FaqSection-DgbFc-d2.js",
      "assets/ToolVideoEmbed-DltoCXpM.js",
      "assets/GuideLinks-BsEl-oB0.js",
      "assets/blog-Cqpj3gtZ.js",
      "assets/info-BGlOhDp4.js",
      "assets/productCards-CAZfINO_.js",
      "assets/layers-B7zHnkyf.js",
      "assets/usePwaManifest-D8HDEEPW.js",
      "assets/ToolInfoSection-M0kcUBq8.js",
      "assets/CollapsibleText-CmqWEytu.js",
      "assets/chevron-up-Bx33pgGu.js",
      "assets/readability-Cnx01uIT.js",
    ]),
) => i.map((i) => d[i]);
import { T as B, B as C, f as I, ap as G } from "./index-D2ZT81un.js";
import { r as m, j as l } from "./vendor-react-D01g8YgM.js";
import { b as U, T as F } from "./ToolPage-DS5jbfzr.js";
import { T as H } from "./ToolInfoSection-M0kcUBq8.js";
import { c as J, g as K, e as z } from "./readability-Cnx01uIT.js";
const A = typeof Intl < "u" && typeof Intl.Segmenter == "function",
  S = new RegExp("[\\p{L}\\p{N}]", "u"),
  Y = /[\u3040-\u30ff\u3400-\u9fff\uac00-\ud7af\u0e00-\u0e7f]/,
  T = new RegExp(
    "[\\u3040-\\u30ff\\u3400-\\u9fff\\uf900-\\ufaff\\u{20000}-\\u{2fa1f}]",
    "u",
  ),
  E = new RegExp(T.source, "gu");
let L = null;
function V() {
  return L ?? (L = new Intl.Segmenter(void 0, { granularity: "word" }));
}
function y(e) {
  const n = e.trim();
  if (!n) return 0;
  const o = n.split(/\s+/);
  if (!A)
    return o.reduce(
      (r, i) => r + (T.test(i) ? (i.match(E)?.length ?? 0) : S.test(i) ? 1 : 0),
      0,
    );
  const t = V();
  let s = 0;
  for (const r of o)
    if (Y.test(r) || T.test(r)) {
      const i = r.match(E)?.length ?? 0,
        a = i ? r.replace(E, " ") : r;
      s += i + Array.from(t.segment(a)).filter((d) => d.isWordLike).length;
    } else S.test(r) && (s += 1);
  return s;
}
const q = new RegExp("^(?:\\p{L}|Ph)(?:\\.\\p{L})+$", "u"),
  X =
    /^(Dr|Mr|Mrs|Ms|Prof|Jr|Sr|Mt|Gen|Gov|Col|Lt|Capt|Rev|St|vs|etc|e\.g|i\.e|a\.m|p\.m|U\.S|No|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)$/i,
  Z = new RegExp("^\\p{Lu}$", "u"),
  Q = new RegExp("^\\p{N}+$", "u"),
  _ = new RegExp("^\\s+\\p{Lu}", "u"),
  ee =
    /^\s+(It|He|She|They|We|You|I|The|This|That|These|Those|There|Then|But|And|So|Our|My|His|Her|Their|In|On|At|After|Before|When|If|As|A|An)\b/,
  v = ".!?。！？",
  te = "。！？";
function P(e) {
  const n = [];
  if (!e) return n;
  let o = 0;
  for (let t = 0; t < e.length; t++) {
    if (!v.includes(e[t])) continue;
    let s = t;
    for (; s + 1 < e.length && v.includes(e[s + 1]);) s++;
    const r = e[t - 1],
      i = e[s + 1];
    if (e[t] === "." && r && i && S.test(r) && S.test(i)) {
      t = s;
      continue;
    }
    const d = e.slice(o, t).trim().split(/\s+/).pop() ?? "",
      u = e.slice(s + 1),
      h = d.replace(/\.$/, ""),
      p = q.test(h),
      g = (/^(a\.m|p\.m|etc)$/i.test(h) && _.test(u)) || (p && ee.test(u));
    if (e[t] === "." && s === t && Z.test(h) && h !== "I" && _.test(u)) {
      t = s;
      continue;
    }
    if (e[t] === "." && (X.test(h) || p) && !g) {
      t = s;
      continue;
    }
    const f = te.includes(e[t]);
    (u.length === 0 || /^\s/.test(u) || f) &&
      (n.push([o, s + 1]), (o = s + 1), (t = s));
  }
  return (e.slice(o).trim().length > 0 && n.push([o, e.length]), n);
}
function W(e) {
  return P(e.trim()).length;
}
function se(e) {
  const n = e.trim();
  return P(n).map(([o, t]) => {
    const s = n.slice(o, t).trim();
    return { text: s, words: y(s) };
  });
}
function M(e) {
  if (!A) return e.length;
  const n = new Intl.Segmenter(void 0, { granularity: "grapheme" });
  return Array.from(n.segment(e)).length;
}
function N(e) {
  if (e === 0) return "0 sec";
  if (e < 200) return "< 1 min";
  const n = Math.round(e / 200);
  if (n < 60) return `${n} min`;
  const o = Math.floor(n / 60),
    t = n % 60;
  return t === 0 ? `${o} h` : `${o} h ${t} min`;
}
function ne(e) {
  return {
    words: y(e),
    chars: M(e),
    charsNoSpace: M(e.replace(/\s/g, "")),
    sentences: W(e),
    paragraphs: e.trim() ? e.split(/\n\n+/).filter((o) => o.trim()).length : 0,
  };
}
const x = 2e5,
  oe = 130;
function k(e) {
  if (e === 0) return "0 sec";
  const n = Math.round((e / oe) * 60);
  if (n < 60) return `${n} sec`;
  const o = Math.floor(n / 60),
    t = n % 60;
  if (o < 60) return t === 0 ? `${o} min` : `${o} min ${t} sec`;
  const s = Math.floor(o / 60),
    r = o % 60;
  return r === 0 ? `${s} h` : `${s} h ${r} min`;
}
const re = new Set(
  "a an and are as at be but by for from had has have he her his i if in into is it its me my no not of on or our she so than that the their them then there these they this to was we were what when which who will with you your".split(
    " ",
  ),
);
function ae(e, n = 10, o = !1) {
  const t = y(e);
  if (!t) return [];
  const s = new Map(),
    r = new RegExp(
      "[\\p{L}\\p{M}\\p{N}]+(?:['’-][\\p{L}\\p{M}\\p{N}]+)*",
      "gu",
    );
  for (const i of Array.from(e.toLowerCase().matchAll(r))) {
    const a = i[0];
    a.length < 2 ||
      (!o && re.has(a)) ||
      Q.test(a) ||
      T.test(a) ||
      s.set(a, (s.get(a) ?? 0) + 1);
  }
  return Array.from(s, ([i, a]) => ({
    word: i,
    count: a,
    percent: Math.round((a / t) * 1e3) / 10,
  }))
    .sort((i, a) => a.count - i.count || (i.word < a.word ? -1 : 1))
    .slice(0, n);
}
const ie = [
  { id: "x", label: "X (Twitter) post", limit: 280, unit: "chars" },
  { id: "bluesky", label: "Bluesky post", limit: 300, unit: "chars" },
  { id: "threads", label: "Threads post", limit: 500, unit: "chars" },
  { id: "instagram", label: "Instagram caption", limit: 2200, unit: "chars" },
  { id: "linkedin", label: "LinkedIn post", limit: 3e3, unit: "chars" },
  {
    id: "pinterest",
    label: "Pinterest pin description",
    limit: 500,
    unit: "chars",
  },
  { id: "yt-title", label: "YouTube title", limit: 100, unit: "chars" },
  { id: "yt-desc", label: "YouTube description", limit: 5e3, unit: "chars" },
  {
    id: "meta-title",
    label: "SEO title (about)",
    limit: 60,
    unit: "chars",
    soft: !0,
  },
  {
    id: "meta-desc",
    label: "Meta description (about)",
    limit: 160,
    unit: "chars",
    soft: !0,
  },
  {
    id: "sms",
    label: "SMS (one segment)",
    limit: 160,
    unit: "chars",
    soft: !0,
  },
];
function Se(e, n = ie) {
  return n.map((o) => {
    const t = o.limit - e,
      s = t < 0;
    return {
      id: o.id,
      label: o.label,
      limit: o.limit,
      used: e,
      over: s,
      remaining: t,
      soft: !!o.soft,
      text: s ? `${-t} over` : `${t} left`,
    };
  });
}
function le(e, n) {
  if (!Number.isFinite(n) || n < 1) return null;
  const o = Math.floor(n),
    t = Math.min(100, Math.round((e / o) * 100)),
    s = o - e;
  return {
    target: o,
    words: e,
    percent: t,
    remaining: s,
    reached: e >= o,
    text:
      s > 0
        ? `${s} words to go`
        : s === 0
          ? "Goal reached"
          : `${-s} words over the goal`,
  };
}
const O = [
  { id: "b1", label: "1 word", min: 1, max: 1 },
  { id: "b2", label: "2 to 6 words", min: 2, max: 6 },
  { id: "b3", label: "7 to 15 words", min: 7, max: 15 },
  { id: "b4", label: "16 to 25 words", min: 16, max: 25 },
  { id: "b5", label: "26 to 39 words", min: 26, max: 39 },
  { id: "b6", label: "40 or more words", min: 40, max: 1 / 0 },
];
function ce(e) {
  return O.findIndex((n) => e >= n.min && e <= n.max);
}
function Te(e) {
  const n = se(e)
      .filter((s) => s.words > 0)
      .map((s) => ({ ...s, bucket: ce(s.words) })),
    o = O.map(() => 0);
  for (const s of n) o[s.bucket]++;
  const t = n.reduce((s, r) => s + r.words, 0);
  return {
    sentences: n,
    counts: o,
    average: n.length ? Math.round((t / n.length) * 10) / 10 : 0,
    longest: n.reduce((s, r) => Math.max(s, r.words), 0),
  };
}
const b = (e) => Math.round(e * 10) / 10;
function ue(e, n) {
  const o = {
      applicable: !1,
      flesch: 0,
      label: "",
      grade: 0,
      gradeLabel: "",
      steps: [],
    },
    t = e.replace(/https?:\/\/\S+|www\.\S+/g, " "),
    s = t.match(new RegExp("\\p{L}[\\p{L}'’-]*", "gu")) ?? [],
    r = (t.match(new RegExp("\\p{L}", "gu")) ?? []).length,
    i = (t.match(/[A-Za-zÀ-ɏ]/g) ?? []).length;
  if (s.length < 5 || n < 1)
    return {
      ...o,
      reason:
        "Add at least a full sentence (about 5 words) for a reading score.",
    };
  if (r > 0 && i / r < 0.7)
    return {
      ...o,
      reason:
        "The reading score is built for English and similar Latin-script text, so it is hidden for this text.",
    };
  const a = s.reduce((f, w) => f + J(w), 0),
    d = s.length / n,
    u = a / s.length,
    h = 206.835 - 1.015 * d - 84.6 * u,
    p = Math.max(0, Math.min(100, b(h))),
    g = Math.max(0, b(0.39 * d + 11.8 * u - 15.59)),
    c = [
      {
        label: "Words per sentence",
        formula: "Words (letters only, links left out) / sentences",
        inputs: { words: s.length, sentences: n },
        result: b(d),
      },
      {
        label: "Syllables per word",
        formula:
          "Estimated syllables / words (a rule-based estimate, so a few words are off)",
        inputs: { syllables: a, words: s.length },
        result: Math.round(u * 100) / 100,
      },
      {
        label: "Flesch Reading Ease",
        formula:
          "206.835 - 1.015 x words per sentence - 84.6 x syllables per word, kept between 0 and 100",
        inputs: {
          "words per sentence": b(d),
          "syllables per word": Math.round(u * 100) / 100,
        },
        result: p,
      },
      {
        label: "Flesch-Kincaid grade",
        formula:
          "0.39 x words per sentence + 11.8 x syllables per word - 15.59, not below 0",
        inputs: {
          "words per sentence": b(d),
          "syllables per word": Math.round(u * 100) / 100,
        },
        result: g,
      },
    ];
  return {
    applicable: !0,
    flesch: p,
    label: z(p),
    grade: g,
    gradeLabel: K(g),
    steps: c,
  };
}
const R = {
    what: "Counts the words, characters, sentences, and paragraphs in a piece of text, with reading and speaking time and the words you use most — useful for meeting a word count requirement, checking if a social media post fits a character limit, or gauging how long a piece of writing actually is before submitting or publishing it.",
    how: "Paste or type your text into the box, and the counts update automatically as you type or edit. Chinese and Japanese characters are counted one by one, the way Word and Google Docs count them. Speaking time assumes about 130 words a minute.",
    tip: "Character counts usually matter more than word counts for social media posts specifically, since most platforms limit by character, not word count — a short sentence full of long words can hit a character limit well before it hits any reasonable word-count concern.",
  },
  de = m.lazy(() =>
    G(
      () => import("./WordCounterExtras-CS5kAwSF.js"),
      __vite__mapDeps([
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
        20, 21, 22, 23, 24, 25, 26, 27, 28, 29,
      ]),
    ),
  );
function he(e, n) {
  const [o, t] = m.useState(e);
  return (
    m.useEffect(() => {
      const s = setTimeout(() => t(e), n);
      return () => clearTimeout(s);
    }, [e, n]),
    o
  );
}
const j = { words: 0, chars: 0, charsNoSpace: 0, sentences: 0, paragraphs: 0 };
function pe(e) {
  const n = e.length > x,
    o = m.useMemo(() => (n ? null : ne(e)), [e, n]),
    [t, s] = m.useState(null),
    r = m.useRef(null);
  if (
    (m.useEffect(() => {
      if (!n) return;
      r.current ||
        (r.current = new Worker(
          new URL("/assets/wordCounter.worker-CVAb3JwE.js", import.meta.url),
          { type: "module" },
        ));
      const a = r.current;
      let d = !0;
      const u = (h) => {
        d && s({ forText: e, stats: h.data.stats });
      };
      return (
        a.addEventListener("message", u),
        a.postMessage({ text: e }),
        () => {
          ((d = !1), a.removeEventListener("message", u));
        }
      );
    }, [e, n]),
    m.useEffect(
      () => () => {
        (r.current?.terminate(), (r.current = null));
      },
      [],
    ),
    !n)
  )
    return { stats: o ?? j, counting: !1 };
  const i = t && t.forText === e;
  return { stats: i ? t.stats : j, counting: !i };
}
function me() {
  const [e, n] = m.useState(""),
    o = he(e, 200),
    { stats: t, counting: s } = pe(o),
    [r, i] = m.useState(""),
    [a, d] = m.useState(!1),
    { logUsageNow: u } = U(),
    h = m.useMemo(() => (o.length > x ? [] : ae(o, 10, a)), [o, a]),
    p = (c) => (s ? "…" : c),
    g = async () => {
      if (!(await u("download"))) return;
      const f = o.length > x ? null : ue(o, t.sentences),
        w = le(t.words, Number(r)),
        D = [
          `Words: ${t.words}`,
          `Characters: ${t.chars}`,
          `Characters (no spaces): ${t.charsNoSpace}`,
          `Sentences: ${t.sentences}`,
          `Paragraphs: ${t.paragraphs}`,
          `Reading time: ${N(t.words)}`,
          `Speaking time: ${k(t.words)}`,
          ...(f?.applicable
            ? [
                `Reading ease: ${f.flesch} (${f.label}), Flesch-Kincaid grade ${f.grade}`,
              ]
            : []),
          ...(w
            ? [
                `Word goal: ${w.words} of ${w.target} (${w.percent}%) - ${w.text}`,
              ]
            : []),
          ...(h.length
            ? [
                `Top keywords: ${h.map(($) => `${$.word} (${$.count})`).join(", ")}`,
              ]
            : []),
        ];
      try {
        (await navigator.clipboard.writeText(
          D.join(`
`),
        ),
          I.success("Stats copied"));
      } catch {
        I.error("Couldn't copy. Select the numbers and copy them by hand.");
      }
    };
  return l.jsxs(F, {
    children: [
      l.jsx(B, {
        "aria-label": "Text to count",
        placeholder: "Type or paste your text here...",
        value: e,
        onChange: (c) => n(c.target.value),
        className: "min-h-[200px] text-base",
      }),
      l.jsxs("div", {
        className: "flex gap-2 mt-3",
        children: [
          l.jsx(C, {
            type: "button",
            variant: "outline",
            size: "sm",
            onClick: () => n(""),
            disabled: !e,
            children: "Clear",
          }),
          l.jsx(C, {
            type: "button",
            variant: "outline",
            size: "sm",
            onClick: g,
            disabled: !e.trim(),
            children: "Copy stats",
          }),
        ],
      }),
      s &&
        l.jsx("p", {
          className: "text-xs text-muted-foreground mt-3",
          role: "status",
          children: "Counting…",
        }),
      l.jsx("div", {
        className: "grid grid-cols-2 md:grid-cols-3 gap-4 mt-6",
        children: [
          { label: "Words", value: p(t.words) },
          { label: "Characters", value: p(t.chars) },
          { label: "Characters (no spaces)", value: p(t.charsNoSpace) },
          { label: "Sentences", value: p(t.sentences) },
          { label: "Paragraphs", value: p(t.paragraphs) },
          { label: "Reading Time", value: p(N(t.words)) },
          { label: "Speaking Time", value: p(k(t.words)) },
        ].map((c) =>
          l.jsxs(
            "div",
            {
              className: "p-4 rounded-lg border bg-card text-center",
              children: [
                l.jsx("p", {
                  className: "text-2xl font-bold text-primary",
                  children: c.value,
                }),
                l.jsx("p", {
                  className: "text-xs text-muted-foreground mt-1",
                  children: c.label,
                }),
              ],
            },
            c.label,
          ),
        ),
      }),
      (h.length > 0 || a) &&
        !s &&
        l.jsxs("div", {
          className: "mt-6",
          "data-testid": "keyword-density",
          children: [
            l.jsx("h2", {
              className: "text-sm font-semibold",
              children: "Top keywords",
            }),
            l.jsxs("p", {
              className: "text-xs text-muted-foreground mt-1",
              children: [
                a
                  ? 'Most used words, including common ones like "the" and "and".'
                  : 'Most used words, leaving out common ones like "the" and "and".',
                " Percent is the share of all words.",
              ],
            }),
            l.jsxs("label", {
              className: "mt-2 flex items-center gap-2 text-sm",
              children: [
                l.jsx("input", {
                  type: "checkbox",
                  checked: a,
                  onChange: (c) => d(c.target.checked),
                }),
                " Include common words",
              ],
            }),
            l.jsx("ul", {
              className:
                "mt-3 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1 text-sm",
              children: h.map((c) =>
                l.jsxs(
                  "li",
                  {
                    className: "flex justify-between border-b py-1",
                    children: [
                      l.jsx("span", {
                        className: "font-medium break-all",
                        children: c.word,
                      }),
                      l.jsxs("span", {
                        className: "text-muted-foreground",
                        children: [c.count, " · ", c.percent, "%"],
                      }),
                    ],
                  },
                  c.word,
                ),
              ),
            }),
          ],
        }),
      l.jsx(m.Suspense, {
        fallback: null,
        children: l.jsx(de, {
          text: o,
          words: t.words,
          chars: t.chars,
          sentences: t.sentences,
          counting: s,
          tooBig: o.length > x,
          goal: r,
          onGoalChange: i,
        }),
      }),
      l.jsx(H, { whatIsIt: R.what, howToUse: R.how, tip: R.tip }),
    ],
  });
}
const ye = Object.freeze(
  Object.defineProperty(
    {
      __proto__: null,
      countGraphemes: M,
      countSentences: W,
      countWords: y,
      default: me,
      formatReadingTime: N,
    },
    Symbol.toStringTag,
    { value: "Module" },
  ),
);
export { O as L, ye as W, le as g, Se as l, ue as r, Te as s };
//# sourceMappingURL=WordCounter-Bg7h0vss.js.map
