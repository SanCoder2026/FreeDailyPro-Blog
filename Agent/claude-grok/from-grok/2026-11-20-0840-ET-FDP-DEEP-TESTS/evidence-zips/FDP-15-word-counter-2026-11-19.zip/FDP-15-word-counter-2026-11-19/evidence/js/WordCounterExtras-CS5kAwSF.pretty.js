import { r as d, j as e } from "./vendor-react-D01g8YgM.js";
import { e as N, I as v } from "./index-D2ZT81un.js";
import { C as y } from "./CalcSteps-CMhW1YVy.js";
import {
  l as k,
  s as C,
  r as E,
  L as g,
  g as S,
} from "./WordCounter-Bg7h0vss.js";
import "./ToolPage-DS5jbfzr.js";
import "./useUploadApi-CeBVbB2U.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-mA9gIB_c.js";
import "./share-2-wJ7OG3q6.js";
import "./copy-DxyF2bO9.js";
import "./workflowCta-QcLjv4ms.js";
import "./UsageAndUpgradeStrip-Ckl_cEoN.js";
import "./access-BBg1iIm1.js";
import "./useAdminAccess-D2xxeUJv.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-BaZhqv4P.js";
import "./map-pin-DiPhQKiV.js";
import "./FaqSection-DgbFc-d2.js";
import "./ToolVideoEmbed-DltoCXpM.js";
import "./GuideLinks-BsEl-oB0.js";
import "./blog-Cqpj3gtZ.js";
import "./info-BGlOhDp4.js";
import "./productCards-CAZfINO_.js";
import "./layers-B7zHnkyf.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./ToolInfoSection-M0kcUBq8.js";
import "./CollapsibleText-CmqWEytu.js";
import "./chevron-up-Bx33pgGu.js";
import "./readability-Cnx01uIT.js";
const u = [
  "bg-primary/5",
  "bg-primary/10",
  "bg-primary/15",
  "bg-primary/25",
  "bg-primary/35",
  "bg-primary/45",
];
function re({
  text: a,
  words: b,
  chars: m,
  sentences: h,
  counting: n,
  tooBig: l,
  goal: p,
  onGoalChange: j,
}) {
  const [x, f] = d.useState(!1),
    w = d.useMemo(() => k(m), [m]),
    t = S(b, Number(p)),
    i = d.useMemo(() => (l || !a.trim() ? null : C(a)), [a, l]),
    r = d.useMemo(() => (l || !a.trim() ? null : E(a, h)), [a, h, l]),
    c = a.trim().length > 0;
  return e.jsxs("div", {
    className: "mt-8 space-y-8",
    "data-testid": "wc-extras",
    children: [
      e.jsxs("section", {
        "aria-labelledby": "wc-goal-h",
        children: [
          e.jsx("h2", {
            id: "wc-goal-h",
            className: "text-sm font-semibold",
            children: "Word goal",
          }),
          e.jsxs("div", {
            className: "mt-2 flex items-center gap-3",
            children: [
              e.jsx(N, {
                htmlFor: "wc-goal",
                className: "text-sm",
                children: "Target words",
              }),
              e.jsx(v, {
                id: "wc-goal",
                type: "number",
                inputMode: "numeric",
                min: 1,
                max: 1e7,
                className: "w-32",
                value: p,
                onChange: (s) => j(s.target.value),
                placeholder: "e.g. 500",
              }),
            ],
          }),
          t &&
            !n &&
            e.jsxs("div", {
              className: "mt-3",
              "data-testid": "wc-goal-progress",
              children: [
                e.jsx("div", {
                  role: "progressbar",
                  "aria-label": "Progress to word goal",
                  "aria-valuemin": 0,
                  "aria-valuemax": 100,
                  "aria-valuenow": t.percent,
                  className: "h-2 w-full rounded bg-muted overflow-hidden",
                  children: e.jsx("div", {
                    className: `h-full ${t.reached ? "bg-green-600" : "bg-primary"}`,
                    style: { width: `${t.percent}%` },
                  }),
                }),
                e.jsxs("p", {
                  className: "mt-1 text-sm",
                  children: [
                    t.words,
                    " of ",
                    t.target,
                    " words (",
                    t.percent,
                    "%). ",
                    e.jsx("strong", { children: t.text }),
                  ],
                }),
              ],
            }),
          e.jsx("p", {
            className: "mt-1 text-xs text-muted-foreground",
            children:
              "Your goal lives only on this page and is forgotten when you close or reload it.",
          }),
        ],
      }),
      e.jsxs("section", {
        "aria-labelledby": "wc-limits-h",
        children: [
          e.jsx("h2", {
            id: "wc-limits-h",
            className: "text-sm font-semibold",
            children: "Platform limits",
          }),
          e.jsxs("p", {
            className: "text-xs text-muted-foreground mt-1",
            children: [
              "Characters used: ",
              n ? "…" : m,
              ". Platforms change their limits, so confirm on the platform. X counts every link as 23 characters; this counts plain characters.",
            ],
          }),
          e.jsx("ul", {
            className:
              "mt-3 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1 text-sm",
            "data-testid": "wc-limits",
            children: w.map((s) =>
              e.jsxs(
                "li",
                {
                  className: "flex justify-between gap-3 border-b py-1",
                  "data-over": s.over ? "true" : "false",
                  children: [
                    e.jsxs("span", {
                      children: [
                        s.label,
                        " ",
                        e.jsxs("span", {
                          className: "text-muted-foreground",
                          children: [
                            "(",
                            s.limit,
                            s.soft ? ", guide" : "",
                            ")",
                          ],
                        }),
                      ],
                    }),
                    e.jsx("span", {
                      className:
                        n || !c
                          ? "text-muted-foreground"
                          : s.over
                            ? "font-semibold text-red-700 dark:text-red-400"
                            : "text-green-700 dark:text-green-400",
                      children:
                        n || !c
                          ? "-"
                          : s.over
                            ? `Over: ${s.text}`
                            : `OK: ${s.text}`,
                    }),
                  ],
                },
                s.id,
              ),
            ),
          }),
        ],
      }),
      l &&
        c &&
        e.jsx("p", {
          className: "text-xs text-muted-foreground",
          role: "status",
          children:
            "The sentence-length view and reading score are skipped for very long text. Counts, goal and limits above still work.",
        }),
      r &&
        e.jsxs("section", {
          "aria-labelledby": "wc-ease-h",
          "data-testid": "wc-ease",
          children: [
            e.jsx("h2", {
              id: "wc-ease-h",
              className: "text-sm font-semibold",
              children: "Reading ease",
            }),
            r.applicable
              ? e.jsxs(e.Fragment, {
                  children: [
                    e.jsxs("p", {
                      className: "mt-2 text-sm",
                      children: [
                        e.jsx("strong", {
                          "data-testid": "wc-flesch",
                          children: r.flesch,
                        }),
                        " Flesch Reading Ease (",
                        r.label,
                        ") · Flesch-Kincaid ",
                        r.grade,
                        " (",
                        r.gradeLabel,
                        ")",
                      ],
                    }),
                    e.jsx("div", {
                      className: "mt-2",
                      children: e.jsx(y, { steps: r.steps }),
                    }),
                  ],
                })
              : e.jsx("p", {
                  className: "mt-2 text-xs text-muted-foreground",
                  children: r.reason,
                }),
          ],
        }),
      i &&
        i.sentences.length > 0 &&
        e.jsxs("section", {
          "aria-labelledby": "wc-len-h",
          "data-testid": "wc-sentence-lengths",
          children: [
            e.jsx("h2", {
              id: "wc-len-h",
              className: "text-sm font-semibold",
              children: "Sentence lengths",
            }),
            e.jsxs("p", {
              className: "text-xs text-muted-foreground mt-1",
              children: [
                "Average ",
                i.average,
                " words, longest ",
                i.longest,
                ". Mixing short and long sentences reads best. The shading gets stronger as sentences get longer.",
              ],
            }),
            e.jsx("ul", {
              className: "mt-3 grid grid-cols-2 sm:grid-cols-3 gap-2 text-sm",
              children: g.map((s, o) =>
                e.jsxs(
                  "li",
                  {
                    className: `rounded border px-2 py-1 ${u[o]}`,
                    children: [
                      e.jsx("span", {
                        className: "font-medium",
                        children: i.counts[o],
                      }),
                      " ",
                      e.jsxs("span", {
                        className: "text-muted-foreground",
                        children: ["sentences of ", s.label],
                      }),
                    ],
                  },
                  s.id,
                ),
              ),
            }),
            e.jsxs("label", {
              className: "mt-3 flex items-center gap-2 text-sm",
              children: [
                e.jsx("input", {
                  type: "checkbox",
                  checked: x,
                  onChange: (s) => f(s.target.checked),
                }),
                " Highlight sentences by length in my text",
              ],
            }),
            x &&
              e.jsx("p", {
                className:
                  "mt-2 rounded border p-3 text-sm leading-relaxed whitespace-pre-wrap",
                "data-testid": "wc-highlight",
                children: i.sentences.map((s, o) =>
                  e.jsxs(
                    "span",
                    {
                      title: `${s.words} words (${g[s.bucket].label})`,
                      className: `${u[s.bucket]} rounded px-0.5`,
                      children: [s.text, " "],
                    },
                    o,
                  ),
                ),
              }),
          ],
        }),
    ],
  });
}
export { re as default };
//# sourceMappingURL=WordCounterExtras-CS5kAwSF.js.map
