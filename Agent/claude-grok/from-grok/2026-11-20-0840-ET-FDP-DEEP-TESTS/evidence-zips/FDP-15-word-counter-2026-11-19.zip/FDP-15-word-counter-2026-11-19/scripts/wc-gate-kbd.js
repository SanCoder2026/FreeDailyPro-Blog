// word-counter: starting count, Copy stats at the starting count, Ctrl+C in the box, Clear, word goal, keyboard, aria-live, axe, phones. Copy stats may cost a trial use when uses are left.
const { chromium, devices } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/15-word-counter/live/'; const URL = 'https://www.freedailypro.com/tool/word-counter';
const AXE = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8'); const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const axe = async p => { await p.addScriptTag({ content: AXE }); return p.evaluate(async () => (await axe.run(document.querySelector('main'), { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'best-practice'] }, resultTypes: ['violations'] })).violations.map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length, t: v.nodes.slice(0, 3).map(n => n.target.join(' ')) }))); };
const SAMPLE = 'The quick brown fox jumps over the lazy dog. It was a sunny day, and the fox felt happy.\n\nA second paragraph starts here. It has two sentences.';
(async () => { const b = await chromium.launch(); const R = { t: now() };
 const c = await b.newContext({ viewport: { width: 1366, height: 900 }, permissions: ['clipboard-read', 'clipboard-write'] }); const p = await c.newPage(); p.setDefaultTimeout(10000);
 const net = []; p.on('request', r => { if (r.method() === 'POST' && /trpc|usage|api\//.test(r.url())) net.push(r.url().replace(/deviceId[^&]*/, 'deviceId=REDACTED').slice(0, 120) + ' ' + (r.postData() || '').length); });
 await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 400) : null; };
 R.start = await used(); R.strip = await p.evaluate(() => (document.body.innerText.match(/[^\n]*(Trial|trial use)[^\n]*/g) || []).slice(0, 4));
 R.axeIdle = await axe(p);
 const ta = p.getByLabel('Text to count'); await ta.focus(); await p.keyboard.insertText(SAMPLE); await p.waitForTimeout(600);
 R.liveRegions = await p.evaluate(() => [...document.querySelectorAll('main [aria-live],main [role=status],main [role=alert]')].map(e => ({ live: e.getAttribute('aria-live'), role: e.getAttribute('role'), text: e.innerText.slice(0, 60) })));
 R.axeTyped = await axe(p);
 // Tab order from the box
 const seq = []; for (let i = 0; i < 6; i++) { await p.keyboard.press('Tab'); seq.push(await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('aria-label') || e.innerText || e.placeholder || '').trim().slice(0, 40); })); } R.tab = seq;
 // word goal
 const goal = p.getByPlaceholder(/Target words/i); if (await goal.count()) { await goal.fill('50'); await p.waitForTimeout(400); R.goal = await p.evaluate(() => (document.body.innerText.match(/\d+ words to go|Goal reached|\d+ words over the goal/) || [null])[0]); R.goalBar = await p.evaluate(() => { const g = document.querySelector('[aria-label="Progress to word goal"]'); return g && { role: g.getAttribute('role'), now: g.getAttribute('aria-valuenow') }; }); }
 await p.screenshot({ path: OUT + 'typed-stats.png', fullPage: true });
 // Ctrl+C of own text in the box
 await ta.focus(); await p.keyboard.press('Control+A'); await p.keyboard.press('Control+C'); await p.waitForTimeout(800);
 R.ctrlC = { dialog: await dialog(), count: await used(), clipLen: await p.evaluate(async () => (await navigator.clipboard.readText()).length).catch(() => null) };
 if (R.ctrlC.dialog) await p.keyboard.press('Escape');
 // Copy stats
 const before = await used(); await p.evaluate(() => navigator.clipboard.writeText('')); await p.getByRole('button', { name: 'Copy stats' }).click(); await p.waitForTimeout(1500);
 R.copyStats = { before, dialog: await dialog(), after: await used(), clip: await p.evaluate(async () => await navigator.clipboard.readText()).catch(() => null), toast: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText).join(' | ').slice(0, 250)) };
 if (R.copyStats.dialog) { await p.screenshot({ path: OUT + 'copy-stats-dialog.png' }); await p.keyboard.press('Escape'); await p.waitForTimeout(500); }
 // Clear
 await p.getByRole('button', { name: 'Clear', exact: true }).click(); await p.waitForTimeout(500); R.afterClear = { value: await ta.inputValue(), words: await p.evaluate(() => document.querySelector('main .grid > div p')?.innerText), goalKept: await p.getByPlaceholder(/Target words/i).inputValue().catch(() => null), focus: await p.evaluate(() => document.activeElement.tagName) };
 R.net = net.slice(0, 15); R.end = await used(); await c.close();
 for (const [nm, d] of [['iphone-se', devices['iPhone SE']], ['pixel-7', devices['Pixel 7']]]) { const { defaultBrowserType, ...dd } = d; const c2 = await b.newContext(dd); const q = await c2.newPage(); q.setDefaultTimeout(10000);
  await q.goto(URL, { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4000); const s0 = JSON.parse(await q.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
  await q.getByLabel('Text to count').fill(SAMPLE); await q.waitForTimeout(500);
  const lay = await q.evaluate(() => { const ta = document.querySelector('main textarea'); const g = document.querySelector('main .grid'); const r = e => e ? Math.round(e.getBoundingClientRect().top + scrollY) : null; return { vh: innerHeight, vw: innerWidth, taTop: r(ta), taH: ta && Math.round(ta.getBoundingClientRect().height), statsTop: r(g), wordsCardTop: r(g?.firstElementChild), overflowX: document.documentElement.scrollWidth > innerWidth + 1 }; });
  await q.screenshot({ path: OUT + `layout-${nm}.png` }); R[nm] = { start: s0, ...lay }; await c2.close(); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate-kbd.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
