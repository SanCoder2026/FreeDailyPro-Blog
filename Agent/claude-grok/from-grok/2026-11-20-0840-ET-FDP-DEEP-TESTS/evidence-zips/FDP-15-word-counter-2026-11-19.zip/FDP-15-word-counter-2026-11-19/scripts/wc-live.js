// word-counter: type each case into the live page and read the stat cards (counting costs no trial use). Also platform-limit rows, keywords, reading/speaking time, long text.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/15-word-counter/live/'; const URL = 'https://www.freedailypro.com/tool/word-counter';
const cases = JSON.parse(fs.readFileSync(__dirname + '/wc-cases.json', 'utf8'));
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const R = { t: now(), cases: {} };
 const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(15000);
 await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
 R.start = await used();
 const ta = p.getByLabel('Text to count');
 const read = async () => p.evaluate(() => { const o = {}; document.querySelectorAll('main .grid > div').forEach(d => { const ps = d.querySelectorAll('p'); if (ps.length >= 2) o[ps[1].innerText.trim()] = ps[0].innerText.trim(); }); const kw = [...document.querySelectorAll('[data-testid=keyword-density] li')].map(li => li.innerText.replace(/\s+/g, ' ').trim()); const lim = (document.body.innerText.match(/Characters used: [^\n]*/) || [null])[0]; return { o, kw, lim }; });
 const set = async (txt) => { await ta.fill(txt); await p.waitForTimeout(450); };
 const map = { words: 'Words', chars: 'Characters', nospace: 'Characters (no spaces)', sentences: 'Sentences', paragraphs: 'Paragraphs' };
 let pass = 0, fail = 0;
 for (const [id, txt, exp, note] of cases) { await set(txt); const r = await read(); const got = {}; const bad = [];
  for (const k of Object.keys(exp)) { got[k] = Number(r.o[map[k]]); if (got[k] !== exp[k]) bad.push(`${k}: got ${got[k]} expected ${exp[k]}`); }
  const value = await ta.inputValue(); R.cases[id] = { note, got, exp, ok: !bad.length, bad, kw: r.kw.slice(0, 3), valueLen: value.length, all: r.o };
  bad.length ? fail++ : pass++; console.log(id, bad.length ? 'FAIL ' + bad.join('; ') : 'ok', '|', note); }
 R.summary = { pass, fail };
 // reading/speaking time
 const words = n => Array.from({ length: n }, (_, i) => 'word' + (i % 50)).join(' ') + '.';
 R.times = {}; for (const n of [150, 250, 299, 300, 1000, 13000]) { await set(words(n)); const r = await read(); R.times[n] = { words: r.o['Words'], reading: r.o['Reading Time'], speaking: r.o['Speaking Time'] }; }
 // platform limits
 const plat = async (txt) => { await set(txt); return p.evaluate(() => { const t = document.body.innerText; const i = t.indexOf('Platform limits'); return t.slice(i, i + 900).split('\n').filter(Boolean).slice(0, 26); }); };
 R.platform = { latin281: await plat('a'.repeat(281)), japanese150: await plat('\u3042'.repeat(150)), sms_emoji: await plat('Hi \ud83d\ude00 ' + 'x'.repeat(100)), url_x: await plat('See https://example.com/' + 'p'.repeat(200) + ' ok') };
 await p.screenshot({ path: OUT + 'platform-limits.png', fullPage: false });
 // long text: > 200,000 chars uses the worker
 const big = ('lorem ipsum dolor sit amet. ').repeat(8000); const t0 = Date.now(); await ta.fill(big);
 await p.waitForFunction(() => !document.body.innerText.includes('Counting…'), null, { timeout: 30000 }).catch(() => { }); await p.waitForTimeout(600);
 R.long = { chars: big.length, ms: Date.now() - t0, stats: (await read()).o, note: await p.evaluate(() => (document.body.innerText.match(/The sentence-length view[^\n]*/) || [null])[0]) };
 R.end = await used(); R.t2 = now(); fs.writeFileSync(OUT + 'live-cases.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify({ summary: R.summary, times: R.times, platform: R.platform, long: R.long, start: R.start, end: R.end }, null, 1)); await b.close(); })();
