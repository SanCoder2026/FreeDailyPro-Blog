const { chromium } = require('playwright');
(async () => { const b = await chromium.launch({ args: ['--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream'] });
 const c = await b.newContext({ permissions: ['camera'] }); const p = await c.newPage(); const js = [];
 p.on('response', r => { if (/\/assets\/.*\.js/.test(r.url())) js.push(r.url()); });
 await p.goto('https://www.freedailypro.com/tool/word-counter', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(6000);
 console.log(js.filter(u => /Word|word|Count|Tool|text/i.test(u)).join('\n')); console.log(js.length); await b.close(); })();
