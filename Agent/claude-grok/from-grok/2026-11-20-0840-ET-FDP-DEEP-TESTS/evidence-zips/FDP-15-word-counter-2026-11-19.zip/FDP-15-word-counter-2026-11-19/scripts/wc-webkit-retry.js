// word-counter: retry the iPhone 14 Pro Max WebKit profile that crashed in the matrix (3 attempts), load + type + read counts.
const { webkit, devices } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
(async () => { const R = { t: cp.execSync('date "+%F %T %Z"').toString().trim(), tries: [] };
 for (let i = 0; i < 3; i++) { const b = await webkit.launch(); const { defaultBrowserType, ...d } = devices['iPhone 14 Pro Max']; const c = await b.newContext(d); const p = await c.newPage(); const r = {};
  p.on('crash', () => r.crash = true);
  try { const t0 = Date.now(); const resp = await p.goto('https://www.freedailypro.com/tool/word-counter', { waitUntil: 'domcontentloaded', timeout: 30000 }); r.status = resp.status(); await p.waitForTimeout(5000);
   await p.getByLabel('Text to count').fill('Hello world. Second sentence here.'); await p.waitForTimeout(600);
   r.words = await p.evaluate(() => document.querySelector('main .grid > div p')?.innerText); r.ms = Date.now() - t0;
   if (i === 0) await p.screenshot({ path: '/workspace/deep/15-word-counter/live/iphone14promax-webkit-retry.png' }); } catch (e) { r.error = e.message.split('\n')[0]; }
  R.tries.push(r); await b.close(); }
 fs.writeFileSync('/workspace/deep/15-word-counter/live/webkit-retry.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R)); })();
