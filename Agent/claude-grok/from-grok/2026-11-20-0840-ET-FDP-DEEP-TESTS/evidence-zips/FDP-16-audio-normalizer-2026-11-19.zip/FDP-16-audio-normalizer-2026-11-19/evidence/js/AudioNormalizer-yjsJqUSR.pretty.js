import { r as o, j as e } from "./vendor-react-D01g8YgM.js";
import { T as J, F as K, R as Q, D as W } from "./ToolPage-DS5jbfzr.js";
import { B as h, f as X } from "./index-D2ZT81un.js";
import { T as Y } from "./ToolInfoSection-M0kcUBq8.js";
import { u as ee } from "./UsageAndUpgradeStrip-Ckl_cEoN.js";
import {
  checkFileSize as te,
  resetFFmpegEngine as C,
  loadFFmpeg as se,
  fetchFile as oe,
  ffmpegOutputToBlob as ie,
} from "./ffmpegEngine-DH91Xnxx.js";
import { b as ae, D as g, F as P, G as re } from "./operations-DLxdtd8A.js";
import { u as ne, F as le, A as ue, s as de } from "./uiHelpers-CchiPBlR.js";
import { T as me } from "./ToolSteps-DtiMymsE.js";
import { u as ce } from "./useDownloadedResult-C1FfMpBH.js";
import "./useUploadApi-CeBVbB2U.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-mA9gIB_c.js";
import "./share-2-wJ7OG3q6.js";
import "./copy-DxyF2bO9.js";
import "./workflowCta-QcLjv4ms.js";
import "./access-BBg1iIm1.js";
import "./useAdminAccess-D2xxeUJv.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-BaZhqv4P.js";
import "./map-pin-DiPhQKiV.js";
import "./FaqSection-DgbFc-d2.js";
import "./ToolVideoEmbed-DltoCXpM.js";
import "./GuideLinks-BsEl-oB0.js";
import "./blog-Cqpj3gtZ.js";
import "./info-BGlOhDp4.js";
import "./productCards-CAZfINO_.js";
import "./layers-B7zHnkyf.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-CmqWEytu.js";
import "./chevron-up-Bx33pgGu.js";
import "./timeFormat-Va_Xba1f.js";
import "./progress-N6eOMBez.js";
import "./square-TSyXkWwu.js";
const k = {
  what: "Raises or lowers the whole file by one constant amount so its overall loudness reaches a target, using the same loudness standard (EBU R128) broadcasters and streaming platforms target. Useful for a recording where volume drifts up and down, or before uploading to a platform with its own loudness target. Runs entirely in your browser — the audio never leaves your device.",
  how: "Upload your audio file and click Normalize — it analyzes the file and evens out the loudness automatically.",
  tip: `This targets a broadcast-standard loudness level, which is a bit different from simply "making everything as loud as possible" (peak normalization) — it's built to make speech and music sound consistently loud without clipping or feeling overly compressed.`,
};
function He() {
  const { inPipeline: F, intermediate: v } = ne(),
    [i, x] = o.useState(null),
    [l, y] = o.useState(!1),
    [B, N] = o.useState(0),
    [E, p] = o.useState(""),
    [r, m] = o.useState(null),
    [u, I] = o.useState("podcast"),
    [S, O] = o.useState(""),
    [$, T] = o.useState(null),
    [b, U] = o.useState(F),
    { isPro: z, isLoading: M, isAdmin: _ } = ee(),
    c = o.useRef(null),
    R = o.useRef(null),
    G = o.useCallback((t) => {
      const a = t[0];
      a && (x(a), m(null), T(null), ae(a).then(T));
    }, []),
    V = ce(r),
    w = i ? te([i], z || M, _) : null,
    Z = () => {
      (R.current?.abort(), c.current && C(c.current));
    },
    q = async () => {
      if (!i) return;
      (y(!0), N(0));
      const t = new AbortController();
      R.current = t;
      try {
        p("Loading audio engine...");
        const a = await se((j) => p(j));
        ((c.current = a), p("Reading audio file..."));
        const L = i.name.match(/\.([^.]+)$/)?.[1] || "mp3";
        await a.writeFile(`input.${L}`, await oe(i));
        const n = g.find((j) => j.id === u) ?? g[0];
        p("Measuring and normalizing volume...");
        const f = P(i, v, u, $),
          D = f.format,
          s = await re(
            a,
            `input.${L}`,
            `output.${D.value}`,
            n,
            N,
            t.signal,
            f.codec,
            b,
          ),
          H = s.data,
          A = `${s.gainDb >= 0 ? "+" : ""}${s.gainDb.toFixed(1)} dB`;
        let d;
        (n.lufs === null
          ? (d = `Loudest point ${s.inputPeak?.toFixed(1)} dB → ${s.outputPeak !== null ? s.outputPeak.toFixed(1) : n.peak} dB (${A}).`)
          : ((d = `Loudness ${s.inputLufs.toFixed(1)} LUFS → ${s.outputLufs !== null ? s.outputLufs.toFixed(1) : n.lufs} LUFS (${A}), measured on the saved file.`),
            s.limited &&
              (d += b
                ? ` Even with the peak limiter on, the recording could not reach ${n.lufs} LUFS.`
                : ` The target is ${n.lufs}, but the loud peaks stop it going louder without passing ${n.peak} dB.`)),
          s.gainDb > 12 &&
            (d += ` This boosts a quiet recording by ${s.gainDb.toFixed(0)} dB, so background noise gets louder too.`),
          f.note && (d += ` ${f.note}`),
          O(d),
          m(ie(H, D.mime)),
          X.success("Volume normalized!"));
      } catch (a) {
        de(a);
      } finally {
        (c.current && C(c.current), y(!1));
      }
    };
  return e.jsxs(J, {
    children: [
      !F &&
        e.jsx(me, {
          toolId: "audio-normalizer",
          state: {
            hasFile: !!i,
            targetChosen: u !== "podcast",
            processing: l,
            resultReady: !!r && !l,
            downloaded: V,
          },
        }),
      i
        ? e.jsxs("div", {
            className: "space-y-4",
            children: [
              e.jsx("div", {
                className: "p-4 rounded-lg border bg-card",
                children: e.jsx("p", {
                  className: "text-sm font-medium",
                  children: i.name,
                }),
              }),
              w && e.jsx(le, { check: w, isPro: z }),
              e.jsxs("div", {
                className: "space-y-2",
                children: [
                  e.jsx("p", {
                    className: "text-sm font-medium",
                    children: "Target",
                  }),
                  e.jsx("div", {
                    className: "flex flex-wrap gap-2",
                    children: g.map((t) =>
                      e.jsx(
                        h,
                        {
                          size: "sm",
                          variant: u === t.id ? "default" : "outline",
                          onClick: () => {
                            (I(t.id), m(null));
                          },
                          title: t.hint,
                          children: t.label,
                        },
                        t.id,
                      ),
                    ),
                  }),
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground",
                    children: g.find((t) => t.id === u)?.hint,
                  }),
                  e.jsxs("label", {
                    className:
                      "flex min-h-[44px] cursor-pointer items-start gap-3 py-2 text-sm",
                    children: [
                      e.jsx("input", {
                        type: "checkbox",
                        className: "mt-0.5 h-6 w-6 shrink-0 cursor-pointer",
                        checked: b,
                        onChange: (t) => {
                          (U(t.target.checked), m(null));
                        },
                        "data-testid": "norm-limiter",
                      }),
                      e.jsxs("span", {
                        children: [
                          "Limit loud peaks so the loudness target can be reached",
                          e.jsx("span", {
                            className: "block text-xs text-muted-foreground",
                            children:
                              "Turns the volume up as far as the target needs and catches the few peaks that would clip. Not used for the peak target.",
                          }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              l && e.jsx(ue, { progress: B, statusMessage: E, onStop: Z }),
              r &&
                S &&
                e.jsx("p", {
                  className: "text-sm text-muted-foreground",
                  "data-testid": "norm-summary",
                  children: S,
                }),
              r && e.jsx(Q, { blob: r }),
              e.jsx("div", {
                className: "flex flex-wrap gap-3",
                children: r
                  ? e.jsxs(e.Fragment, {
                      children: [
                        e.jsx(W, {
                          blob: r,
                          fileName: `normalized_${i.name.replace(/\.[^.]+$/, `.${P(i, v, u, $).format.value}`)}`,
                        }),
                        e.jsx(h, {
                          variant: "outline",
                          onClick: () => {
                            (x(null), m(null));
                          },
                          children: "New",
                        }),
                      ],
                    })
                  : e.jsxs(e.Fragment, {
                      children: [
                        e.jsx(h, {
                          onClick: q,
                          disabled: l || w?.severity !== "ok",
                          children: l ? "Normalizing..." : "Normalize Volume",
                        }),
                        e.jsx(h, {
                          variant: "outline",
                          onClick: () => x(null),
                          disabled: l,
                          children: "Reset",
                        }),
                      ],
                    }),
              }),
            ],
          })
        : e.jsx(K, {
            gateAtDownload: !0,
            accept: "audio/*",
            maxSize: 500,
            onFiles: G,
            label: "Drop an audio file",
            description: "Even out volume levels",
          }),
      e.jsx(Y, { whatIsIt: k.what, howToUse: k.how, tip: k.tip }),
    ],
  });
}
export { He as default };
//# sourceMappingURL=AudioNormalizer-yjsJqUSR.js.map
