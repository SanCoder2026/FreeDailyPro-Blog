// audio-normalizer battery: one fresh context, cases from an-cases.json. Normalize costs no trial use (gate is at Download); no download is made.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/16-audio-normalizer/live/'; const T = '/workspace/deep/16-audio-normalizer/testfiles/';
const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
const cases = JSON.parse(fs.readFileSync(__dirname + '/an-cases.json')).filter(c => !process.argv[2] || process.argv[2].split(',').includes(c.id));
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage();
  const R = { t: now(), cases: [], console: [] }; p.on('console', m => { if (m.type() === 'error' || /fail|error|abort/i.test(m.text())) R.console.push(m.type() + ': ' + m.text().slice(0, 300)); });
  await p.goto('https://www.freedailypro.com/tool/audio-normalizer', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
  R.ls0 = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
  for (const c of cases) {
    const r = { ...c, t: now() };
    try {
      for (const n of ['New', 'Reset']) { const btn = p.getByRole('button', { name: n, exact: true }); if (await btn.count() && await btn.first().isEnabled()) { await btn.first().click(); await p.waitForTimeout(500); } }
      await p.locator('input[type=file]').first().setInputFiles(T + c.file); await p.waitForTimeout(1500);
      r.preNote = await p.evaluate(() => { const m = document.querySelector('main').innerText; const i = m.indexOf('Target'); return m.slice(Math.max(0, i - 400), i).split('\n').filter(Boolean).slice(-4).join(' | '); });
      const tb = p.getByRole('button', { name: c.target, exact: true }); if (await tb.count()) await tb.click();
      const cb = p.locator('[data-testid=norm-limiter]'); if (await cb.count()) { if (!!c.limiter !== await cb.isChecked()) await cb.click(); }
      const nb = p.getByRole('button', { name: 'Normalize Volume', exact: true });
      r.normalizeEnabled = await nb.count() ? await nb.isEnabled() : null;
      if (!r.normalizeEnabled) { await p.screenshot({ path: OUT + 'bat-' + c.id + '.png' }); R.cases.push(r); console.log(c.id, 'disabled', r.preNote); continue; }
      const t0 = Date.now(); await nb.click();
      const toast = []; const iv = setInterval(async () => { try { const tt = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast],[role=status],[role=alert]')].map(x => x.innerText.trim()).filter(Boolean).join(' || ')); if (tt && !toast.includes(tt)) toast.push(tt); } catch (e) {} }, 400);
      await Promise.race([p.locator('[data-testid=norm-summary]').waitFor({ timeout: 150000 }), p.waitForFunction(() => !/Normalizing\.\.\./.test(document.querySelector('main').innerText) && document.querySelector('main').innerText.includes('Normalize Volume'), null, { timeout: 150000, polling: 500 }).then(() => p.waitForTimeout(800))]).catch(e => r.err = String(e).slice(0, 150));
      clearInterval(iv); r.secs = (Date.now() - t0) / 1000; r.toasts = toast;
      r.summary = await p.locator('[data-testid=norm-summary]').innerText().catch(() => null);
      if (r.summary) {
        const blob = await p.evaluate(async () => { const a = document.querySelector('main audio'); if (!a) return null; const rr = await fetch(a.src); const bb = new Uint8Array(await rr.arrayBuffer()); let s = ''; for (let i = 0; i < bb.length; i += 8192) s += String.fromCharCode.apply(null, bb.subarray(i, i + 8192)); return { type: rr.headers.get('content-type'), b64: btoa(s) }; });
        if (blob) { const buf = Buffer.from(blob.b64, 'base64'); const fn = OUT + 'out-' + c.id + '.bin'; fs.writeFileSync(fn, buf); r.blob = { type: blob.type, bytes: buf.length, path: fn }; }
      } else { await p.screenshot({ path: OUT + 'bat-' + c.id + '.png' }); r.mainErr = await p.evaluate(() => { const m = document.querySelector('main').innerText; const i = m.indexOf('Limit loud peaks'); return m.slice(i, i + 500); }); }
    } catch (e) { r.err = String(e).slice(0, 200); }
    R.cases.push(r); console.log(r.id, r.secs, r.summary || r.err || r.toasts.join('/'));
    fs.writeFileSync(OUT + 'battery' + (process.argv[2] ? '-' + process.argv[2].replace(/,/g, '_') : '') + '.json', JSON.stringify(R, null, 1));
  }
  R.ls1 = await p.evaluate(() => localStorage.getItem('fdp-usage-v1')); R.t1 = now();
  fs.writeFileSync(OUT + 'battery' + (process.argv[2] ? '-' + process.argv[2].replace(/,/g, '_') : '') + '.json', JSON.stringify(R, null, 1)); await b.close();
})();
