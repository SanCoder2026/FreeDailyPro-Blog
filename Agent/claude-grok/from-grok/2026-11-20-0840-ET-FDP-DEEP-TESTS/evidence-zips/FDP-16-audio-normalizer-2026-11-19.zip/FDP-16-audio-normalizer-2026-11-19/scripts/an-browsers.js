// audio-normalizer: Normalize quiet.wav (Podcast) in Firefox and WebKit (desktop + iPhone 14 WebKit); Chromium keyboard path to the drop zone.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/16-audio-normalizer/live/'; const T = '/workspace/deep/16-audio-normalizer/testfiles/'; const URL = 'https://www.freedailypro.com/tool/audio-normalizer';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const R = { t: now() };
(async () => {
 for (const [nm, bt, opt] of [['firefox', 'firefox', { viewport: { width: 1440, height: 900 } }], ['webkit', 'webkit', { viewport: { width: 1440, height: 900 } }], ['iphone14-webkit', 'webkit', (({ defaultBrowserType, ...d }) => d)(pw.devices['iPhone 14'])]]) {
  const b = await pw[bt].launch(); const c = await b.newContext(opt); const p = await c.newPage(); const r = { t: now() };
  try { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); r.start = JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
   await p.locator('input[type=file]').first().setInputFiles(T + 'quiet.mp3'); await p.waitForTimeout(1500); const t0 = Date.now();
   await p.getByRole('button', { name: 'Normalize Volume', exact: true }).click();
   await Promise.race([p.locator('[data-testid=norm-summary]').waitFor({ timeout: 150000 }), p.waitForFunction(() => /Something went wrong/.test(document.body.innerText), null, { timeout: 150000 })]).catch(e => r.err = String(e).slice(0, 120));
   r.secs = (Date.now() - t0) / 1000; r.summary = await p.locator('[data-testid=norm-summary]').innerText().catch(() => null); r.toast = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText).join(' | ').slice(0, 200));
   r.playerDur = await p.evaluate(() => document.querySelector('main audio')?.duration);
   await p.screenshot({ path: OUT + 'browser-' + nm + '.png' }); } catch (e) { r.err = String(e).slice(0, 200); }
  R[nm] = r; console.log(nm, JSON.stringify(r)); await b.close(); }
 const b = await pw.chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage();
 await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); let chooser = false; p.on('filechooser', () => { chooser = true; });
 const seq = []; for (let i = 0; i < 70; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('role') || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || e.type || '').trim().slice(0, 50).replace(/\n/g, ' '); }); seq.push(a); if (/Drop an audio|choose an audio|browse|INPUT\s+file/i.test(a)) { await p.keyboard.press('Enter'); await p.waitForTimeout(1200); seq.push('ENTER -> chooser=' + chooser); if (!chooser) { await p.keyboard.press(' '); await p.waitForTimeout(1000); seq.push('SPACE -> chooser=' + chooser); } break; } }
 R.kbd = { tabs: seq.length, last: seq.slice(-4), chooser }; R.focusRing = await p.evaluate(() => getComputedStyle(document.activeElement).outlineStyle + ' ' + getComputedStyle(document.activeElement).boxShadow.slice(0, 60));
 await p.screenshot({ path: OUT + 'kbd-dropzone-focus.png' }); await b.close();
 R.t2 = now(); fs.writeFileSync(OUT + 'browsers-kbd.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R.kbd), R.focusRing);
})();
