// audio-normalizer: starting count; Save to Google Drive / my cloud storage / Continue with / Share / Quick Buy at the starting count (stops at the first dialog; types nothing);
// keyboard (dropzone Enter opens chooser, target buttons state), live regions, axe, phone layout. Normalize itself costs no trial use.
const { chromium, devices } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/16-audio-normalizer/live/'; const T = '/workspace/deep/16-audio-normalizer/testfiles/'; const URL = 'https://www.freedailypro.com/tool/audio-normalizer';
const AXE = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8'); const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const axe = async p => { await p.addScriptTag({ content: AXE }); return p.evaluate(async () => (await axe.run(document.querySelector('main'), { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'best-practice'] }, resultTypes: ['violations'] })).violations.map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length, t: v.nodes.slice(0, 3).map(n => n.target.join(' ')) }))); };
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce)=[^&]*/g, '$1=REDACTED').slice(0, 200);
(async () => { const b = await chromium.launch(); const R = { t: now() };
 const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(15000);
 await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 2; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(400); } };
 R.start = await used(); R.axeIdle = await axe(p);
 // keyboard: Tab to the dropzone, Enter opens the chooser?
 const seq = []; let chooser = null; p.on('filechooser', fc => { chooser = fc; });
 for (let i = 0; i < 25 && !chooser; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('aria-label') || e.innerText || e.type || '').trim().slice(0, 40).replace(/\n/g, ' '); }); seq.push(a); if (/Drop an audio|choose an audio|browse/i.test(a)) { await p.keyboard.press('Enter'); await p.waitForTimeout(1200); seq.push('ENTER -> chooser=' + !!chooser); break; } }
 R.tabToDrop = seq;
 if (chooser) await chooser.setFiles(T + 'quiet.wav'); else await p.locator('input[type=file]').first().setInputFiles(T + 'quiet.wav');
 await p.waitForTimeout(1500);
 R.targetBtnState = await p.evaluate(() => [...document.querySelectorAll('main button')].filter(b => /LUFS|EBU|ACX|Peak to|YouTube/.test(b.innerText)).map(b => ({ t: b.innerText.slice(0, 30), pressed: b.getAttribute('aria-pressed'), checked: b.getAttribute('aria-checked'), role: b.getAttribute('role'), cls: /bg-primary/.test(b.className) })));
 R.checkboxLabel = await p.evaluate(() => { const c = document.querySelector('[data-testid=norm-limiter]'); return c && (c.labels?.[0]?.innerText || '').slice(0, 80); });
 await p.getByRole('button', { name: 'Normalize Volume', exact: true }).click();
 await p.locator('[data-testid=norm-summary]').waitFor({ timeout: 150000 });
 R.liveRegions = await p.evaluate(() => [...document.querySelectorAll('main [aria-live],main [role=status],main [role=alert],main [role=progressbar]')].map(e => ({ live: e.getAttribute('aria-live'), role: e.getAttribute('role'), text: e.innerText.slice(0, 80) })));
 R.summaryLive = await p.evaluate(() => { let e = document.querySelector('[data-testid=norm-summary]'); while (e && e !== document.body) { if (e.getAttribute('aria-live') || /status|alert/.test(e.getAttribute('role') || '')) return true; e = e.parentElement; } return false; });
 R.focusAfter = await p.evaluate(() => document.activeElement.tagName + ' ' + (document.activeElement.innerText || '').slice(0, 30));
 R.player = await p.evaluate(() => { const a = document.querySelector('main audio'); return a && { controls: a.controls, label: a.getAttribute('aria-label'), dur: a.duration }; });
 R.resultButtons = await p.evaluate(() => [...document.querySelectorAll('main button, main a')].map(e => (e.tagName + ':' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50).replace(/\n/g, ' '))).filter(x => /Download|Drive|cloud|Continue|New|Share|Pass/i.test(x)));
 R.axeResult = await axe(p);
 await p.screenshot({ path: OUT + 'result-desktop.png', fullPage: true });
 const act = async (name, rx) => { const r = { before: await used() }; const loc = p.getByRole('button', { name: rx }).first(); if (!(await loc.count())) { r.missing = true; return r; }
   const pop = c.waitForEvent('page', { timeout: 5000 }).catch(() => null); const url0 = p.url(); await loc.click(); const pg = await pop; await p.waitForTimeout(2500);
   r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null; if (pg) { await pg.waitForLoadState('domcontentloaded').catch(() => {}); r.popup = red(pg.url()); r.popupTitle = await pg.title().catch(() => null); await pg.close(); }
   r.toast = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText).join(' | ').slice(0, 250));
   if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + '.png' }); await esc(); if (r.url) { await p.goBack().catch(() => {}); await p.waitForTimeout(2000); } return r; };
 R.saveDrive = await act('drive', /Save to Google Drive/);
 R.saveCloud = await act('cloud', /Save to my cloud storage/);
 R.share = await act('share', /^Share this tool$/);
 R.quickBuy = await act('quickbuy', /^Quick Buy$/);
 R.downloadKbd = await (async () => { const d = p.getByRole('button', { name: /^Download/ }).first(); if (!(await d.count())) return 'no download button'; await d.focus(); await p.keyboard.press('Enter'); await p.waitForTimeout(2000); const r = { dialog: await dialog(), focusInDialog: await p.evaluate(() => !!document.activeElement.closest('[role=dialog],[role=alertdialog]')) }; if (r.dialog) { await p.screenshot({ path: OUT + 'dlg-download.png' }); const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.click(); await p.waitForTimeout(3000); r.dayPass = { dialog: await dialog(), url: red(p.url()) }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); } } await esc(); return r; })();
 R.continueWith = await (async () => { const l = p.getByRole('button', { name: /Continue with/ }).or(p.getByRole('link', { name: /Continue with/ })).first(); if (!(await l.count())) return 'missing'; const u0 = p.url(); await l.click(); await p.waitForTimeout(5000); const r = { url: p.url() !== u0 ? p.url() : null, dialog: await dialog(), main: await p.evaluate(() => document.querySelector('main')?.innerText.slice(0, 600)) }; await p.screenshot({ path: OUT + 'continue-with.png' }); return r; })();
 R.end = await used(); await c.close();
 for (const [nm, d, bt] of [['iphone-se', devices['iPhone SE'], 'chromium'], ['pixel-7', devices['Pixel 7'], 'chromium']]) { const { defaultBrowserType, ...dd } = d; const c2 = await b.newContext(dd); const q = await c2.newPage(); q.setDefaultTimeout(15000);
  await q.goto(URL, { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4000); const s0 = JSON.parse(await q.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
  const r = e => e ? Math.round(e.getBoundingClientRect().top + scrollY) : null;
  const idle = await q.evaluate(() => { const z = [...document.querySelectorAll('main *')].find(e => /^Drop an audio file|^Tap to choose/.test(e.innerText || '') && e.children.length < 4); return { vh: innerHeight, dropTop: z ? Math.round(z.getBoundingClientRect().top + scrollY) : null }; });
  await q.screenshot({ path: OUT + `layout-${nm}-idle.png` });
  await q.locator('input[type=file]').first().setInputFiles(T + 'quiet.wav'); await q.waitForTimeout(1500);
  const lay = await q.evaluate(() => { const f = s => [...document.querySelectorAll('main button')].find(b => b.innerText.trim() === s); const t = e => e ? Math.round(e.getBoundingClientRect().top + scrollY) : null; return { normTop: t(f('Normalize Volume')), targetTop: t(f('Podcast (-16 LUFS)')), overflowX: document.documentElement.scrollWidth > innerWidth + 1 }; });
  await q.screenshot({ path: OUT + `layout-${nm}-file.png` }); R[nm] = { start: s0, ...idle, ...lay }; await c2.close(); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate-kbd.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
