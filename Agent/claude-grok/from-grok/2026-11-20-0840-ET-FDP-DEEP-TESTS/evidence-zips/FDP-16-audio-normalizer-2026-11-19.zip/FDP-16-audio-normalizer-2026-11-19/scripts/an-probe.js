// audio-normalizer: one fresh context. Starting count, UI after file, Normalize (podcast), summary, output blob, Download click (gate), network.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/16-audio-normalizer/live/'; const T = '/workspace/deep/16-audio-normalizer/testfiles/';
const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await ctx.newPage(); const R = { t: now(), net: [] };
  p.on('request', r => { const u = r.url(); if (!/freedailypro\.com\/(assets|api\/trpc\/(?!usage))/.test(u) && !/google|doubleclick|gstatic|ytimg|youtube/.test(u)) R.net.push(r.method() + ' ' + u.slice(0, 140) + ' ' + ((r.postData() || '').length)); });
  await p.goto('https://www.freedailypro.com/tool/audio-normalizer', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
  R.strip = await p.evaluate(() => (document.body.innerText.match(/[^\n]*(remaining today|uses\/day|trial use)[^\n]*/gi) || []).join(' || '));
  R.ls0 = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
  R.inputs = await p.evaluate(() => [...document.querySelectorAll('input[type=file]')].map(i => ({ accept: i.accept, multiple: i.multiple })));
  await p.locator('input[type=file]').first().setInputFiles(T + 'quiet.wav'); await p.waitForTimeout(1500);
  R.mainAfterFile = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 2500));
  R.buttons = await p.evaluate(() => [...document.querySelectorAll('main button, main input')].map(e => (e.tagName + ':' + (e.getAttribute('aria-label') || e.innerText || e.type || '').trim().slice(0, 60) + (e.getAttribute('aria-pressed') ? ' pressed=' + e.getAttribute('aria-pressed') : '') + (e.title ? ' title=' + e.title.slice(0, 40) : ''))));
  await p.screenshot({ path: OUT + 'probe-file-loaded.png' });
  const t0 = Date.now(); await p.getByRole('button', { name: 'Normalize Volume', exact: true }).click();
  const stat = []; const iv = setInterval(async () => { try { stat.push(((Date.now() - t0) / 1000).toFixed(0) + 's ' + (await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*(engine|Reading|Measuring|%)[^\n]*/g) || []).join(' | ')))); } catch (e) {} }, 2000);
  try { await p.locator('[data-testid=norm-summary]').waitFor({ timeout: 180000 }); } catch (e) { R.err = String(e).slice(0, 200); }
  clearInterval(iv); R.status = stat; R.secs = (Date.now() - t0) / 1000;
  R.summary = await p.locator('[data-testid=norm-summary]').innerText().catch(() => null);
  R.mainAfter = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 3000));
  R.ls1 = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
  const blob = await p.evaluate(async () => { const a = document.querySelector('main audio'); if (!a) return null; const r = await fetch(a.src); const bb = new Uint8Array(await r.arrayBuffer()); let s = ''; for (let i = 0; i < bb.length; i += 8192) s += String.fromCharCode.apply(null, bb.subarray(i, i + 8192)); return { src: a.src.slice(0, 30), type: r.headers.get('content-type'), b64: btoa(s) }; });
  if (blob) { fs.writeFileSync(OUT + 'out-probe-quiet.wav', Buffer.from(blob.b64, 'base64')); R.blob = { src: blob.src, type: blob.type, bytes: Buffer.from(blob.b64, 'base64').length }; }
  await p.screenshot({ path: OUT + 'probe-result.png', fullPage: false });
  const dl = p.waitForEvent('download', { timeout: 8000 }).catch(() => null);
  await p.getByRole('button', { name: /download/i }).first().click();
  const d = await dl; await p.waitForTimeout(2500);
  R.download = d ? { name: d.suggestedFilename() } : null;
  if (d) await d.saveAs(OUT + 'dl-' + d.suggestedFilename());
  R.dialog = await p.evaluate(() => [...document.querySelectorAll('[role=dialog],[role=alertdialog]')].map(x => x.innerText.slice(0, 800)));
  R.ls2 = await p.evaluate(() => localStorage.getItem('fdp-usage-v1')); R.t2 = now();
  await p.screenshot({ path: OUT + 'probe-download-click.png' });
  fs.writeFileSync(OUT + 'probe.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1).slice(0, 9000)); await b.close();
})();
