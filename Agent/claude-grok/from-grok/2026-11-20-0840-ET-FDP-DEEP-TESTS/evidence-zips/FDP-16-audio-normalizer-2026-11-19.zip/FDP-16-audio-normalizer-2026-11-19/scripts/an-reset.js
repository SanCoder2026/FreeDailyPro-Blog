// audio-normalizer RERUN after the daily reset (7:00 PM ET). Fresh contexts (max 4). A context that loads at 0 only records that.
// With uses left: Normalize quiet.wav (Podcast) -> count (expect unchanged) -> Download -> count, file name, bytes vs preview blob -> Download again (same visit) -> count
// -> Save to Google Drive: record count and where it goes; STOP at any Google sign-in page (never sign in).
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const crypto = require('crypto');
const OUT = '/workspace/deep/16-audio-normalizer/live/'; const T = '/workspace/deep/16-audio-normalizer/testfiles/'; const URL = 'https://www.freedailypro.com/tool/audio-normalizer';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const R = { t: now(), runs: [] };
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|login_hint)=[^&]*/g, '$1=REDACTED').slice(0, 160);
(async () => { const b = await chromium.launch();
 for (let i = 0; i < 4; i++) { const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await c.newPage(); const r = { i, t: now() };
  const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
  const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null; };
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); r.start = await used(); r.strip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]);
  if (r.start >= 10) { r.note = 'loaded at 0 remaining; nothing to observe'; R.runs.push(r); await c.close(); continue; }
  await p.locator('input[type=file]').first().setInputFiles(T + 'quiet.wav'); await p.waitForTimeout(1500);
  await p.getByRole('button', { name: 'Normalize Volume', exact: true }).click(); await p.locator('[data-testid=norm-summary]').waitFor({ timeout: 150000 }); r.afterNormalize = await used();
  const prev = await p.evaluate(async () => { const a = document.querySelector('main audio'); const bb = new Uint8Array(await (await fetch(a.src)).arrayBuffer()); let h = 0; return bb.length; });
  for (const k of ['dl1', 'dl2']) { const ev = p.waitForEvent('download', { timeout: 8000 }).catch(() => null); await p.getByRole('button', { name: /^Download$/ }).first().click(); const d = await ev; await p.waitForTimeout(2000);
   r[k] = { dialog: await dialog(), count: await used() }; if (d) { const fp = OUT + 'reset-' + i + '-' + k + '-' + d.suggestedFilename(); await d.saveAs(fp); r[k].name = d.suggestedFilename(); r[k].bytes = fs.statSync(fp).size; r[k].sameSizeAsPreview = r[k].bytes === prev; } if (r[k].dialog) { await p.keyboard.press('Escape'); break; } }
  const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); await p.getByRole('button', { name: /Save to Google Drive/ }).click(); const pg = await pop; await p.waitForTimeout(2500);
  r.drive = { dialog: await dialog(), count: await used(), popup: pg ? red(pg.url()) : null }; if (pg) await pg.close();
  r.t2 = now(); R.runs.push(r); console.log(JSON.stringify(r)); await c.close(); if (r.dl1) break; }
 fs.writeFileSync(OUT + 'reset.json', JSON.stringify(R, null, 1)); await b.close(); })();
