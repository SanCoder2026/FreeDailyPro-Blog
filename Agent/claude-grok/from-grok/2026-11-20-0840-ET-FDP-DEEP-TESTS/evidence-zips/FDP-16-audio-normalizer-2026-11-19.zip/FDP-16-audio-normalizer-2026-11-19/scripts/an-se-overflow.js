// iPhone SE (WebKit): which element sticks out past the 320 px viewport on the idle page?
const pw = require('playwright');
(async () => { const b = await pw.webkit.launch(); const { defaultBrowserType, ...d } = pw.devices['iPhone SE']; const p = await (await b.newContext(d)).newPage();
 await p.goto('https://www.freedailypro.com/tool/audio-normalizer', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 console.log(JSON.stringify(await p.evaluate(() => ({ vw: innerWidth, sw: document.documentElement.scrollWidth, wide: [...document.querySelectorAll('button,a')].filter(e => e.getBoundingClientRect().right > innerWidth + 1).map(e => ({ t: (e.innerText || e.getAttribute('aria-label') || '').trim().slice(0, 60), right: Math.round(e.getBoundingClientRect().right), top: Math.round(e.getBoundingClientRect().top + scrollY) })).slice(0, 6) }))));
 await b.close(); })();
