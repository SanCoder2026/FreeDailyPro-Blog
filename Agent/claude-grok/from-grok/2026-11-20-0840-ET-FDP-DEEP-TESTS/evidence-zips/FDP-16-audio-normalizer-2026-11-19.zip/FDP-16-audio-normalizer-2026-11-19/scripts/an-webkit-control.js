// Control: does Playwright WebKit on this box crash when ANY page loads an MP3/WAV blob into <audio> (no FreeDailyPro code)?
const { webkit } = require('playwright'); const fs = require('fs');
(async () => { for (const f of ['quiet.mp3', 'quiet.wav']) { const b = await webkit.launch(); const p = await (await b.newContext()).newPage(); let crashed = false; p.on('crash', () => crashed = true);
 await p.setContent('<input type=file id=f>'); await p.locator('#f').setInputFiles('/workspace/deep/16-audio-normalizer/testfiles/' + f);
 const r = await p.evaluate(() => new Promise(res => { const a = document.createElement('audio'); a.preload = 'metadata'; a.onloadedmetadata = () => res('dur ' + a.duration); a.onerror = () => res('error ' + (a.error && a.error.code)); setTimeout(() => res('timeout'), 8000); a.src = URL.createObjectURL(document.getElementById('f').files[0]); })).catch(e => 'EXC ' + String(e).slice(0, 80));
 console.log(f, r, 'crashed=' + crashed); await b.close().catch(() => {}); } })();
