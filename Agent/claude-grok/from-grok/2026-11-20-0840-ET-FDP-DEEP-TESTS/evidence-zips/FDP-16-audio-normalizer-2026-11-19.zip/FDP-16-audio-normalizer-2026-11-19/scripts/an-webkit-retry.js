// audio-normalizer: WebKit (desktop 1440 + iPhone 14) Normalize quiet.mp3 (Podcast), up to 3 attempts each; records crashes separately.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/16-audio-normalizer/live/'; const T = '/workspace/deep/16-audio-normalizer/testfiles/'; const URL = 'https://www.freedailypro.com/tool/audio-normalizer';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const R = { t: now(), runs: [] };
(async () => { for (const [nm, opt] of [['desktop-webkit', { viewport: { width: 1440, height: 900 } }], ['iphone14-webkit', (({ defaultBrowserType, ...d }) => d)(pw.devices['iPhone 14'])]]) for (let a = 1; a <= 3; a++) {
  const b = await pw.webkit.launch(); const c = await b.newContext(opt); const p = await c.newPage(); const r = { nm, a, t: now(), console: [] }; let crashed = false; p.on('crash', () => crashed = true); p.on('console', m => { if (/ffmpeg|SharedArray|wasm|memory|fail/i.test(m.text())) r.console.push(m.text().slice(0, 200)); });
  try { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); r.loaded = true;
   await p.locator('input[type=file]').first().setInputFiles(T + 'quiet.mp3'); await p.waitForTimeout(1500); const t0 = Date.now();
   await p.getByRole('button', { name: 'Normalize Volume', exact: true }).click(); r.clicked = true;
   await Promise.race([p.locator('[data-testid=norm-summary]').waitFor({ timeout: 150000 }), p.waitForFunction(() => /Something went wrong/.test(document.body.innerText), null, { timeout: 150000 })]);
   r.secs = (Date.now() - t0) / 1000; r.summary = await p.locator('[data-testid=norm-summary]').innerText().catch(() => null); r.toast = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText).join(' | ').slice(0, 200));
   await p.screenshot({ path: OUT + `webkit-${nm}-a${a}.png` }); } catch (e) { r.err = String(e).slice(0, 160); }
  r.crashed = crashed; r.console = r.console.slice(0, 6); R.runs.push(r); console.log(JSON.stringify(r).slice(0, 400)); await b.close().catch(() => {}); if (r.summary) break; }
 R.t2 = now(); fs.writeFileSync(OUT + 'webkit-retry.json', JSON.stringify(R, null, 1)); })();
