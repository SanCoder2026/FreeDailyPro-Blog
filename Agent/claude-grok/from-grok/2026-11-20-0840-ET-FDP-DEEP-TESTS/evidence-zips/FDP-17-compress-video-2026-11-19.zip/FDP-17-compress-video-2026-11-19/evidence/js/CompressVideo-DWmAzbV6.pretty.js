import { r as a, j as e } from "./vendor-react-D01g8YgM.js";
import { T as ae, F as oe, R as le, D as L } from "./ToolPage-DS5jbfzr.js";
import { f as w, ax as ne, B as x, e as E, I as V } from "./index-D2ZT81un.js";
import { S as de } from "./slider-m2UfhN9O.js";
import { T as ce } from "./ToolInfoSection-M0kcUBq8.js";
import { u as me } from "./UsageAndUpgradeStrip-Ckl_cEoN.js";
import {
  checkFileSize as ue,
  stopProcessing as pe,
  loadFFmpeg as he,
  fetchFile as ge,
  probeMedia as fe,
  execWithProgress as xe,
  ffmpegOutputToBlob as be,
  resetFFmpegEngine as ve,
} from "./ffmpegEngine-DH91Xnxx.js";
import { l as ye, c as we } from "./utils-qgqMjnRG.js";
import { t as b, B as G } from "./megabytes-DWJJlZGf.js";
import { F as je, V as ze, s as Te } from "./uiHelpers-b-OPLOlA.js";
import { p as W } from "./timeParse-8r2SbiBd.js";
import { T as Ne } from "./ToolSteps-DtiMymsE.js";
import { u as Me } from "./useDownloadedResult-C1FfMpBH.js";
import { T as Se } from "./target-BRRbTfiK.js";
import "./useUploadApi-CeBVbB2U.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-mA9gIB_c.js";
import "./share-2-wJ7OG3q6.js";
import "./copy-DxyF2bO9.js";
import "./workflowCta-QcLjv4ms.js";
import "./access-BBg1iIm1.js";
import "./useAdminAccess-D2xxeUJv.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-BaZhqv4P.js";
import "./map-pin-DiPhQKiV.js";
import "./FaqSection-DgbFc-d2.js";
import "./ToolVideoEmbed-DltoCXpM.js";
import "./GuideLinks-BsEl-oB0.js";
import "./blog-Cqpj3gtZ.js";
import "./info-BGlOhDp4.js";
import "./productCards-CAZfINO_.js";
import "./layers-B7zHnkyf.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./CollapsibleText-CmqWEytu.js";
import "./chevron-up-Bx33pgGu.js";
import "./progress-N6eOMBez.js";
import "./square-TSyXkWwu.js";
const H = (t, d) => String.fromCharCode(t[d], t[d + 1], t[d + 2], t[d + 3]);
async function Ce(t) {
  const d = async (l, v) =>
    new Uint8Array(await t.slice(l, Math.min(t.size, l + v)).arrayBuffer());
  if (t.size < 16) return "This file is too small to be a video.";
  const r = await d(0, 12);
  if (H(r, 4) !== "ftyp") return null;
  let u = 0,
    f = !1,
    N = 0;
  for (; u < t.size && N++ < 2e3;) {
    const l = await d(u, 16);
    if (l.length < 8) break;
    const v = new DataView(l.buffer, l.byteOffset, l.byteLength);
    let p = v.getUint32(0);
    const k = H(l, 4);
    if (p === 1) {
      if (l.length < 16) break;
      p = v.getUint32(8) * 2 ** 32 + v.getUint32(12);
    } else p === 0 && (p = t.size - u);
    if (p < 8)
      return "This video file is damaged (its structure can't be read).";
    if ((k === "moov" && (f = !0), u + p > t.size))
      return f
        ? null
        : "This video file looks incomplete or damaged (it was cut off before the end).";
    u += p;
  }
  return f
    ? null
    : "This video file looks incomplete or damaged (it has no index, so it can't be played).";
}
const O = {
  what: `Reduces a video file's size, typically to fit an upload limit or speed up sharing, by re-encoding it at a lower quality level. Medium/Strong aim for at least a 25%/50% smaller file using the same size-targeting encode as Custom Target, instead of a vague quality label. Some videos are already compressed so well that they cannot be made smaller; the tool tells you and offers your original back. "Manual Quality" gives direct slider control if you'd rather not use a percentage target. Runs entirely in your browser — the video never leaves your device.`,
  how: "Upload your video. Pick Medium or Strong for a percentage reduction, use Manual Quality for direct slider control, or switch to Custom Target and enter an exact size limit (like 25MB for a Discord upload).",
  tip: "Compression re-encodes every frame of the video, which is the most processing-intensive thing any video tool here does — Medium/Strong and Custom Target aim at an exact size and may need a second encode to land under it, so expect them to take real time, especially for longer or higher-resolution videos. There's no automatic cutoff, so let it run — use Stop if you'd rather not wait. Some phone-recorded videos (particularly .mov files) use a codec this tool can't read — if processing fails right away, try re-exporting the video from your phone's own share options first.",
};
function ke(t) {
  return Math.round(18 + (t / 100) * 14);
}
const Be = { medium: 0.75, strong: 0.5 },
  Fe = [
    { label: "8 MB (Discord)", bytes: 8 * 1e6 },
    { label: "16 MB (WhatsApp)", bytes: 16 * 1e6 },
    { label: "25 MB (email)", bytes: 25 * 1e6 },
    { label: "50 MB", bytes: 50 * 1e6 },
    { label: "100 MB", bytes: 100 * 1e6 },
  ];
function xt() {
  const [t, d] = a.useState(null),
    [r, u] = a.useState("medium"),
    [f, N] = a.useState(null),
    [l, v] = a.useState([50]),
    [p, k] = a.useState("25"),
    [j, B] = a.useState(!1),
    [Y, P] = a.useState(0),
    [Z, z] = a.useState(""),
    [s, n] = a.useState(null),
    { isPro: U, isLoading: J, isAdmin: X } = me(),
    M = a.useRef(null),
    A = a.useRef(null),
    [_, q] = a.useState(!1),
    [F, I] = a.useState(""),
    [R, K] = a.useState(""),
    Q = a.useRef(0),
    ee = a.useMemo(() => (t ? URL.createObjectURL(t) : ""), [t]),
    te = a.useCallback(async (i) => {
      const o = i[0];
      if (!o) return;
      if (!ye(o)) {
        w.error(`"${o.name}" isn't a video file`, {
          description: "Drop an MP4, MOV, WebM, MKV or similar video.",
        });
        return;
      }
      let h = null;
      try {
        h = await Ce(o);
      } catch {}
      (h &&
        w.error(`"${o.name}" can't be compressed`, {
          description: h,
          duration: 1e4,
        }),
        N(h),
        d(o),
        n(null));
    }, []),
    se = Me(s),
    D = t ? ue([t], U || J, X) : null,
    ie = () => {
      (A.current?.abort(), M.current && pe(M.current));
    },
    re = async () => {
      if (!t) return;
      (B(!0), P(0));
      const i = new AbortController();
      A.current = i;
      try {
        z("Loading video engine...");
        const o = await he((g) => z(g));
        ((M.current = o), z("Reading video file..."));
        const h = t.name.match(/\.([^.]+)$/)?.[1] || "mp4";
        if (
          (await o.writeFile(`input.${h}`, await ge(t)),
          r === "target" || r === "medium" || r === "strong")
        ) {
          let g;
          if (r === "target") {
            if (((g = Math.round(parseFloat(p || "0") * G)), !g || g <= 0)) {
              (w.error("Enter a valid target size"), B(!1));
              return;
            }
          } else g = Math.round(t.size * Be[r]);
          let S;
          if (r === "target" && (F.trim() || R.trim())) {
            const c = F.trim() ? W(F) : 0,
              m = R.trim() ? W(R) : void 0;
            if (
              Number.isNaN(c) ||
              (m !== void 0 && Number.isNaN(m)) ||
              c < 0 ||
              (m !== void 0 && m <= c)
            ) {
              (w.error("Check the trim times", {
                description:
                  "Use seconds or m:ss, for example 0:30 and 2:15, with End later than Start.",
              }),
                B(!1));
              return;
            }
            S = { start: c, end: m };
          }
          ((Q.current = Date.now()), z("Encoding (0%)..."));
          const y = await we(
            o,
            `input.${h}`,
            "output.mp4",
            g,
            (c, m) => {
              P(c);
              const C = (Date.now() - Q.current) / 1e3,
                $ = c > 0.03 && m === 1 ? Math.max(0, C / c - C) : null;
              z(
                `${m === 2 ? "Fine-tuning to reach the target size" : "Encoding"}${$ ? ` - about ${$ > 90 ? Math.round($ / 60) + " min" : Math.round($) + " s"} left` : ""}`,
              );
            },
            i.signal,
            _ ? 720 : void 0,
            S,
          );
          n(y);
          const T = ((1 - y.size / t.size) * 100).toFixed(1);
          y.metTarget
            ? w.success(`Compressed to ${b(y.size, 1)} MB (${T}% smaller).`)
            : w.warning(
                `Got it to ${b(y.size, 1)} MB (${T}% smaller) - this missed the target. Try a stronger setting or "Lower resolution to 720p".`,
              );
        } else {
          z("Compressing (this is the slowest video operation)...");
          const g = ke(l[0]);
          let S = [];
          try {
            const m = await fe(o, `input.${h}`);
            if (m.duration > 0) {
              const C = Math.max(
                300,
                Math.round(((t.size * 8) / m.duration / 1e3) * 0.9 - 128),
              );
              S = ["-maxrate", `${C}k`, "-bufsize", `${C * 2}k`];
            }
          } catch {}
          await xe(
            o,
            [
              "-i",
              `input.${h}`,
              "-c:v",
              "libx264",
              "-crf",
              String(g),
              ...S,
              "-preset",
              "superfast",
              "-pix_fmt",
              "yuv420p",
              "-c:a",
              "aac",
              "-movflags",
              "+faststart",
              "output.mp4",
            ],
            P,
            i.signal,
          );
          const y = await o.readFile("output.mp4"),
            T = be(y, "video/mp4");
          n({ blob: T, size: T.size });
          const c = ((1 - T.size / t.size) * 100).toFixed(0);
          w.success(
            Number(c) > 0
              ? `Compressed! Reduced by ${c}%`
              : "This video was already efficiently encoded, so the result is not smaller. Keep your original.",
          );
        }
      } catch (o) {
        Te(o);
      } finally {
        (M.current && ve(M.current), B(!1));
      }
    };
  return e.jsxs(ae, {
    children: [
      e.jsx(Ne, {
        toolId: "compress-video",
        state: {
          hasFile: !!t && !f,
          levelChosen: r !== "medium",
          processing: j,
          resultReady: !!s && !j,
          downloaded: se,
        },
      }),
      t
        ? e.jsxs("div", {
            className: "space-y-4",
            children: [
              e.jsxs("div", {
                className: "p-4 rounded-lg border bg-card flex justify-between",
                children: [
                  e.jsxs("div", {
                    children: [
                      e.jsx("p", {
                        className: "text-sm font-medium",
                        children: t.name,
                      }),
                      e.jsxs("p", {
                        className: "text-xs text-muted-foreground",
                        children: ["Original: ", b(t.size, 1), " MB"],
                      }),
                    ],
                  }),
                  s &&
                    e.jsxs("p", {
                      className: "text-sm font-medium text-green-600",
                      children: [b(s.size, 1), " MB"],
                    }),
                ],
              }),
              D && e.jsx(je, { check: D, isPro: U }),
              f &&
                e.jsxs("div", {
                  role: "alert",
                  className:
                    "flex gap-2 p-3 rounded-lg border border-destructive/30 bg-destructive/5",
                  "data-testid": "video-file-problem",
                  children: [
                    e.jsx(ne, {
                      className: "h-4 w-4 text-destructive shrink-0 mt-0.5",
                    }),
                    e.jsxs("p", {
                      className: "text-sm text-destructive",
                      children: [
                        f,
                        " Choose a complete copy of the video, or press Reset to pick another file.",
                      ],
                    }),
                  ],
                }),
              e.jsxs("div", {
                className: "flex gap-2 flex-wrap",
                children: [
                  e.jsx(x, {
                    size: "sm",
                    variant: r === "medium" ? "default" : "outline",
                    onClick: () => {
                      (u("medium"), n(null));
                    },
                    children: "Medium (25% smaller)",
                  }),
                  e.jsx(x, {
                    size: "sm",
                    variant: r === "strong" ? "default" : "outline",
                    onClick: () => {
                      (u("strong"), n(null));
                    },
                    children: "Strong (50% smaller)",
                  }),
                  e.jsx(x, {
                    size: "sm",
                    variant: r === "quality" ? "default" : "outline",
                    onClick: () => {
                      (u("quality"), n(null));
                    },
                    children: "Manual Quality",
                  }),
                  e.jsxs(x, {
                    size: "sm",
                    variant: r === "target" ? "default" : "outline",
                    onClick: () => {
                      (u("target"), n(null));
                    },
                    className: "gap-1.5",
                    children: [
                      e.jsx(Se, { className: "h-3.5 w-3.5" }),
                      " Custom Target",
                    ],
                  }),
                ],
              }),
              r === "quality"
                ? e.jsxs("div", {
                    className: "space-y-2",
                    children: [
                      e.jsxs(E, {
                        children: ["Compression amount: ", l[0], "%"],
                      }),
                      e.jsx(de, {
                        value: l,
                        onValueChange: (i) => {
                          (v(i), n(null));
                        },
                        min: 0,
                        max: 100,
                        step: 5,
                      }),
                      l[0] >= 67 &&
                        e.jsx("p", {
                          className: "text-xs text-muted-foreground",
                          children:
                            "Higher compression takes noticeably longer to process.",
                        }),
                    ],
                  })
                : r === "medium" || r === "strong"
                  ? e.jsxs("p", {
                      className: "text-xs text-muted-foreground",
                      children: [
                        "Targets a real ",
                        r === "medium" ? "25%" : "50%",
                        " smaller file than the original (the encoder aims at the size, and adjusts once if it lands over) — click Compress below.",
                      ],
                    })
                  : e.jsxs("div", {
                      className: "space-y-2",
                      children: [
                        e.jsxs("div", {
                          className: "flex items-end gap-2",
                          children: [
                            e.jsxs("div", {
                              children: [
                                e.jsx(E, {
                                  className: "text-xs",
                                  children: "Target size (MB)",
                                }),
                                e.jsx(V, {
                                  "aria-label": "Target size (MB)",
                                  type: "number",
                                  min: "1",
                                  step: "1",
                                  value: p,
                                  onChange: (i) => {
                                    (k(i.target.value), n(null));
                                  },
                                  className: "w-28",
                                }),
                              ],
                            }),
                            e.jsx("div", {
                              className: "flex gap-1.5 flex-wrap pb-0.5",
                              children: Fe.map((i) =>
                                e.jsx(
                                  x,
                                  {
                                    size: "sm",
                                    variant: "ghost",
                                    className: "h-8 text-xs",
                                    onClick: () => {
                                      (k(String(i.bytes / G)), n(null));
                                    },
                                    children: i.label,
                                  },
                                  i.label,
                                ),
                              ),
                            }),
                          ],
                        }),
                        e.jsxs("div", {
                          className: "flex items-end gap-2 flex-wrap",
                          "data-testid": "compress-trim",
                          children: [
                            e.jsxs("div", {
                              children: [
                                e.jsx(E, {
                                  className: "text-xs",
                                  children: "Trim start (optional)",
                                }),
                                e.jsx(V, {
                                  "aria-label": "Trim start",
                                  placeholder: "0:00",
                                  value: F,
                                  onChange: (i) => {
                                    (I(i.target.value), n(null));
                                  },
                                  className: "w-24",
                                }),
                              ],
                            }),
                            e.jsxs("div", {
                              children: [
                                e.jsx(E, {
                                  className: "text-xs",
                                  children: "Trim end (optional)",
                                }),
                                e.jsx(V, {
                                  "aria-label": "Trim end",
                                  placeholder: "end",
                                  value: R,
                                  onChange: (i) => {
                                    (K(i.target.value), n(null));
                                  },
                                  className: "w-24",
                                }),
                              ],
                            }),
                            e.jsx("p", {
                              className: "text-xs text-muted-foreground pb-2",
                              children:
                                "File size is bitrate times length, so a shorter clip keeps more quality at the same size.",
                            }),
                          ],
                        }),
                      ],
                    }),
              r !== "quality" &&
                e.jsxs("label", {
                  className: "flex items-center gap-2 text-sm",
                  children: [
                    e.jsx("input", {
                      type: "checkbox",
                      checked: _,
                      onChange: (i) => {
                        (q(i.target.checked), n(null));
                      },
                    }),
                    "Lower resolution to 720p (much faster, and smaller)",
                  ],
                }),
              s &&
                e.jsxs("p", {
                  className: `text-xs font-medium ${s.metTarget === !1 || s.size >= t.size ? "text-amber-600" : "text-green-600"}`,
                  "data-testid": "video-result",
                  children: [
                    b(s.size, 2),
                    " MB - ",
                    s.size <= t.size
                      ? `${((1 - s.size / t.size) * 100).toFixed(1)}% smaller than`
                      : `${((s.size / t.size - 1) * 100).toFixed(1)}% larger than`,
                    " the original (",
                    b(t.size, 2),
                    " MB).",
                    s.targetBytes !== void 0 &&
                      (s.metTarget
                        ? ` Target reached (${b(s.targetBytes, 2)} MB).`
                        : ` Target of ${b(s.targetBytes, 2)} MB not reached - this is as small as it got. Try Strong or "Lower resolution to 720p".`),
                    " ",
                    "Saved as MP4.",
                    s.size >= t.size &&
                      " This video was already compressed well, so re-encoding made it bigger. Keep your original; it costs no trial use.",
                  ],
                }),
              j &&
                e.jsx(ze, {
                  heavyNote: !0,
                  progress: Y,
                  statusMessage: Z,
                  onStop: ie,
                }),
              s &&
                e.jsxs("div", {
                  className: "grid sm:grid-cols-2 gap-3",
                  children: [
                    e.jsxs("div", {
                      children: [
                        e.jsx("p", {
                          className: "text-xs text-muted-foreground mb-1",
                          children: "Original",
                        }),
                        e.jsx("video", {
                          src: ee,
                          controls: !0,
                          className: "w-full rounded-lg border max-h-56",
                        }),
                      ],
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsx("p", {
                          className: "text-xs text-muted-foreground mb-1",
                          children: "Compressed",
                        }),
                        e.jsx(le, { blob: s.blob }),
                      ],
                    }),
                  ],
                }),
              e.jsx("div", {
                className: "flex gap-3",
                children: s
                  ? e.jsxs(e.Fragment, {
                      children: [
                        s.size >= t.size
                          ? e.jsxs(e.Fragment, {
                              children: [
                                e.jsx(L, {
                                  blob: t,
                                  fileName: t.name,
                                  label: "Keep original (download)",
                                  freeDownload: !0,
                                }),
                                e.jsx(L, {
                                  blob: s.blob,
                                  fileName: `compressed_${t.name.replace(/\.[^.]+$/, ".mp4")}`,
                                  label: "Download the larger MP4 anyway",
                                  enableShare: !1,
                                }),
                              ],
                            })
                          : e.jsx(L, {
                              blob: s.blob,
                              fileName: `compressed_${t.name.replace(/\.[^.]+$/, ".mp4")}`,
                            }),
                        e.jsx(x, {
                          variant: "outline",
                          onClick: () => {
                            (d(null), n(null), q(!1), N(null), I(""), K(""));
                          },
                          children: "New",
                        }),
                      ],
                    })
                  : e.jsxs(e.Fragment, {
                      children: [
                        e.jsx(x, {
                          onClick: re,
                          disabled: j || !!f || D?.severity !== "ok",
                          children: j ? "Compressing..." : "Compress Video",
                        }),
                        e.jsx(x, {
                          variant: "outline",
                          onClick: () => {
                            (d(null), N(null));
                          },
                          disabled: j,
                          children: "Reset",
                        }),
                      ],
                    }),
              }),
            ],
          })
        : e.jsx(oe, {
            accept: "video/*",
            maxSize: 200,
            onFiles: te,
            label: "Drop a video to compress",
            description: "Reduce video file size",
            gateAtDownload: !0,
          }),
      e.jsx(ce, { whatIsIt: O.what, howToUse: O.how, tip: O.tip }),
    ],
  });
}
export { xt as default };
//# sourceMappingURL=CompressVideo-DWmAzbV6.js.map
