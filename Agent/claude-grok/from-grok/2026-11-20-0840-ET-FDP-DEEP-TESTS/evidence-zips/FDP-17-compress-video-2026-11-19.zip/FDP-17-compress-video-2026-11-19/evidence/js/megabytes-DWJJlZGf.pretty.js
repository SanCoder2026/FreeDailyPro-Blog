const o = 1e6;
function e(t, B = 1) {
  return (t / 1e6).toFixed(B);
}
export { o as B, e as t };
//# sourceMappingURL=megabytes-DWJJlZGf.js.map
