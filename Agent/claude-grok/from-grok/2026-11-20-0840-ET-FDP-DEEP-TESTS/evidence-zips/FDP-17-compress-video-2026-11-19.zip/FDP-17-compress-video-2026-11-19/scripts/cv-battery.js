// compress-video battery: one fresh context; cases from cv-cases.json (argv[2] = comma IDs). Compress costs no trial use (gate is at Download); no download is made.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/17-compress-video/live/'; const T = '/workspace/deep/17-compress-video/testfiles/';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const ids = process.argv[2] ? process.argv[2].split(',') : null; const tag = ids ? '-' + ids.join('_') : '';
const cases = JSON.parse(fs.readFileSync(__dirname + '/cv-cases.json')).filter(c => !ids || ids.includes(c.id));
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); p.setDefaultTimeout(15000);
  const R = { t: now(), cases: [], console: [] }; p.on('console', m => { const x = m.text(); if (!/ads|google|doubleclick|media\.net|gpt/i.test(x) && (m.type() === 'error' || /fail|error|abort|ffmpeg.*(Error|Invalid)/i.test(x))) R.console.push(m.type() + ': ' + x.slice(0, 300)); });
  await p.goto('https://www.freedailypro.com/tool/compress-video', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
  R.ls0 = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
  const save = () => fs.writeFileSync(OUT + 'battery' + tag + '.json', JSON.stringify(R, null, 1));
  for (const c of cases) {
    const r = { ...c, t: now() };
    try {
      for (const n of ['New', 'Reset']) { const btn = p.getByRole('button', { name: n, exact: true }); if (await btn.count() && await btn.first().isEnabled()) { await btn.first().click(); await p.waitForTimeout(600); } }
      await p.locator('input[type=file]').first().setInputFiles(T + c.file); await p.waitForTimeout(2500);
      r.alert = await p.locator('[data-testid=video-file-problem]').innerText().catch(() => null);
      r.limitNote = await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*(over \d+(\.\d+)? MB|trial use supports)[^\n]*/) || [null])[0]);
      r.toastsPre = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim()).join(' || '));
      const mb = p.getByRole('button', { name: c.mode, exact: true }); if (await mb.count()) await mb.click(); else r.modeMissing = true;
      if (c.slider !== undefined) { const s = p.getByRole('slider').first(); await s.focus(); await p.keyboard.press('Home'); for (let i = 0; i < c.slider / 5; i++) await p.keyboard.press('ArrowRight'); r.sliderLabel = await p.evaluate(() => (document.querySelector('main').innerText.match(/Compression amount: \d+%/) || [null])[0]); }
      if (c.preset) await p.getByRole('button', { name: c.preset }).click();
      if (c.target !== undefined) await p.getByLabel('Target size (MB)').fill(c.target);
      if (c.trim) { await p.getByLabel('Trim start').fill(c.trim[0]); await p.getByLabel('Trim end').fill(c.trim[1]); }
      if (c.p720) await p.locator('main label', { hasText: 'Lower resolution to 720p' }).locator('input').check();
      r.targetValue = await p.getByLabel('Target size (MB)').inputValue().catch(() => null);
      const cb = p.getByRole('button', { name: 'Compress Video', exact: true });
      r.compressEnabled = (await cb.count()) ? await cb.isEnabled() : null;
      if (!r.compressEnabled) { await p.screenshot({ path: OUT + 'bat-' + c.id + '.png' }); R.cases.push(r); save(); console.log(c.id, 'disabled', r.alert || r.limitNote || r.toastsPre); continue; }
      const t0 = Date.now(); await cb.click(); const toasts = []; const stat = [];
      const iv = setInterval(async () => { try { const tt = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim()).filter(Boolean)); tt.forEach(x => { if (!toasts.includes(x)) toasts.push(x); }); const st = await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*(Encoding|Fine-tuning|Compressing \(|Loading video|Reading video)[^\n]*/) || [''])[0]); if (st && stat[stat.length - 1] !== st) stat.push(((Date.now() - t0) / 1000).toFixed(0) + 's ' + st); } catch (e) {} }, 1000);
      await p.waitForFunction(() => document.querySelector('[data-testid=video-result]') || ([...document.querySelectorAll('main button')].some(b => b.innerText.trim() === 'Compress Video' && !b.disabled)), null, { timeout: 900000, polling: 1000 }).catch(e => r.err = 'timeout');
      await p.waitForTimeout(1500); clearInterval(iv); r.secs = (Date.now() - t0) / 1000; r.toasts = toasts; r.status = stat.slice(0, 12);
      r.result = await p.locator('[data-testid=video-result]').innerText().catch(() => null);
      r.buttons = await p.evaluate(() => [...document.querySelectorAll('main button')].map(b => b.innerText.trim()).filter(x => /Download|Keep|New|Drive|cloud|Continue/i.test(x)));
      if (r.result) {
        const blob = await p.evaluate(async () => { const vs = [...document.querySelectorAll('main video')].filter(v => v.src.startsWith('blob:')); const v = vs[vs.length - 1]; if (!v) return null; const rr = await fetch(v.src); const bb = new Uint8Array(await rr.arrayBuffer()); let s = ''; for (let i = 0; i < bb.length; i += 8192) s += String.fromCharCode.apply(null, bb.subarray(i, i + 8192)); return btoa(s); });
        if (blob) { const buf = Buffer.from(blob, 'base64'); const fn = OUT + 'out-' + c.id + '.mp4'; fs.writeFileSync(fn, buf); r.blobBytes = buf.length; }
        await p.screenshot({ path: OUT + 'res-' + c.id + '.png' });
      } else await p.screenshot({ path: OUT + 'bat-' + c.id + '.png' });
    } catch (e) { r.err = String(e).slice(0, 200); }
    R.cases.push(r); save(); console.log(r.id, r.secs, r.result || r.err || (r.toasts || []).join(' / '));
  }
  R.ls1 = await p.evaluate(() => localStorage.getItem('fdp-usage-v1')); R.t1 = now(); save(); await b.close();
})();
