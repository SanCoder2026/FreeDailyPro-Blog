// compress-video: starting count; mode buttons; Compress noaudio.mp4 (Medium) then Download / Drive / cloud / Share / Continue at the starting count (stops at the first dialog; types nothing);
// "Keep original (download)" on an already-efficient file at 0 remaining; keyboard, live regions, axe, phones. Compress itself costs no trial use.
const { chromium, devices } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/17-compress-video/live/'; const T = '/workspace/deep/17-compress-video/testfiles/'; const URL = 'https://www.freedailypro.com/tool/compress-video';
const AXE = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8'); const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const axe = async p => { await p.addScriptTag({ content: AXE }); return p.evaluate(async () => (await axe.run(document.querySelector('main'), { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'best-practice'] }, resultTypes: ['violations'] })).violations.map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length, t: v.nodes.slice(0, 3).map(n => n.target.join(' ')) }))); };
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce)=[^&]*/g, '$1=REDACTED').slice(0, 200);
const done = p => p.waitForFunction(() => document.querySelector('[data-testid=video-result]') || [...document.querySelectorAll('main button')].some(b => b.innerText.trim() === 'Compress Video' && !b.disabled), null, { timeout: 600000, polling: 1000 });
(async () => { const b = await chromium.launch(); const R = { t: now() };
 const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await c.newPage(); p.setDefaultTimeout(15000);
 await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 2; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(400); } };
 R.start = await used(); R.strip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]); R.axeIdle = await axe(p);
 let chooser = false; p.on('filechooser', () => { chooser = true; }); const seq = [];
 for (let i = 0; i < 60; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('role') || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50).replace(/\n/g, ' '); }); seq.push(a); if (/Drop a video/i.test(a)) { await p.keyboard.press('Enter'); await p.waitForTimeout(1200); seq.push('ENTER -> chooser=' + chooser); break; } }
 R.kbd = { tabs: seq.length, last: seq.slice(-3), chooser };
 await p.locator('input[type=file]').first().setInputFiles(T + 'noaudio.mp4'); await p.waitForTimeout(2000);
 R.modeButtons = await p.evaluate(() => [...document.querySelectorAll('main button')].map(b => ({ t: b.innerText.trim(), pressed: b.getAttribute('aria-pressed'), on: /bg-primary/.test(b.className) })).filter(x => /smaller|Manual|Custom|Light/.test(x.t)));
 R.modeHint = await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*click Compress below[^\n]*/) || [null])[0]);
 R.steps = await p.evaluate(() => (document.querySelector('main').innerText.match(/\d of 4 steps done[^\n]*/) || [null])[0]);
 await p.screenshot({ path: OUT + 'file-loaded.png' });
 await p.getByRole('button', { name: 'Compress Video', exact: true }).click(); await done(p); await p.waitForTimeout(1500);
 R.result = await p.locator('[data-testid=video-result]').innerText().catch(() => null);
 R.liveRegions = await p.evaluate(() => [...document.querySelectorAll('main [aria-live],main [role=status],main [role=alert],main [role=progressbar]')].map(e => ({ live: e.getAttribute('aria-live'), role: e.getAttribute('role'), text: e.innerText.slice(0, 80) })));
 R.resultLive = await p.evaluate(() => { let e = document.querySelector('[data-testid=video-result]'); while (e && e !== document.body) { if (e.getAttribute('aria-live') || /status|alert/.test(e.getAttribute('role') || '')) return true; e = e.parentElement; } return false; });
 R.focusAfter = await p.evaluate(() => document.activeElement.tagName);
 R.steps2 = await p.evaluate(() => (document.querySelector('main').innerText.match(/\d of 4 steps done[^\n]*/) || [null])[0]);
 R.resultButtons = await p.evaluate(() => [...document.querySelectorAll('main button')].map(b => b.innerText.trim()).filter(x => /Download|Drive|cloud|Continue|New|Pass|Keep/i.test(x)));
 R.axeResult = await axe(p); await p.screenshot({ path: OUT + 'result-desktop.png', fullPage: true });
 const act = async (name, rx) => { const r = { before: await used() }; const loc = p.getByRole('button', { name: rx }).first(); if (!(await loc.count())) { r.missing = true; return r; }
   const pop = c.waitForEvent('page', { timeout: 5000 }).catch(() => null); const dl = p.waitForEvent('download', { timeout: 5000 }).catch(() => null); const url0 = p.url(); await loc.click(); const [pg, d] = await Promise.all([pop, dl]); await p.waitForTimeout(2000);
   r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null; r.download = d ? d.suggestedFilename() : null; if (pg) { r.popup = red(pg.url()); await pg.close(); }
   if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + '.png' }); await esc(); if (r.url) { await p.goBack().catch(() => {}); await p.waitForTimeout(2500); } return r; };
 R.download = await act('download', /^Download$/);
 R.drive = await act('drive', /Save to Google Drive/);
 R.cloud = await act('cloud', /Save to my cloud storage/);
 R.dayPass = await (async () => { await p.getByRole('button', { name: /^Download$/ }).first().click(); await p.waitForTimeout(1500); const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (!(await bp.count())) return null; await bp.click(); await p.waitForTimeout(2500); const r = { dialog: await dialog(), url: red(p.url()) }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); await esc(); return r; })();
 R.continueWith = await p.evaluate(() => [...document.querySelectorAll('main button, main a')].map(b => b.innerText.trim()).filter(x => /Continue with/.test(x)));
 // Keep original on an already-efficient file
 await p.getByRole('button', { name: 'New', exact: true }).click(); await p.waitForTimeout(800);
 await p.locator('input[type=file]').first().setInputFiles(T + 'efficient.mp4'); await p.waitForTimeout(1500);
 await p.getByRole('button', { name: 'Manual Quality', exact: true }).click(); const s = p.getByRole('slider').first(); await s.focus(); await p.keyboard.press('Home');
 R.sliderAria = await s.evaluate(e => ({ label: e.getAttribute('aria-label'), labelledby: e.getAttribute('aria-labelledby'), now: e.getAttribute('aria-valuenow') }));
 await p.getByRole('button', { name: 'Compress Video', exact: true }).click(); await done(p); await p.waitForTimeout(1500);
 R.efficient = { result: await p.locator('[data-testid=video-result]').innerText().catch(() => null), buttons: await p.evaluate(() => [...document.querySelectorAll('main button')].map(b => b.innerText.trim()).filter(x => /Download|Keep|anyway/i.test(x))) };
 R.keepOriginal = await act('keep', /Keep original/); R.largerAnyway = await act('larger', /larger MP4 anyway/);
 await p.screenshot({ path: OUT + 'efficient-result.png' });
 R.end = await used(); await c.close();
 for (const [nm, d] of [['iphone-se', devices['iPhone SE']], ['pixel-7', devices['Pixel 7']]]) { const { defaultBrowserType, ...dd } = d; const c2 = await b.newContext(dd); const q = await c2.newPage(); q.setDefaultTimeout(15000);
  await q.goto(URL, { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4000);
  const idle = await q.evaluate(() => { const z = [...document.querySelectorAll('main [role=button]')].find(e => /Drop a video|choose a video/i.test(e.innerText)); return { vh: innerHeight, dropTop: z ? Math.round(z.getBoundingClientRect().top + scrollY) : null }; });
  await q.screenshot({ path: OUT + `layout-${nm}-idle.png` }); await q.locator('input[type=file]').first().setInputFiles(T + 'noaudio.mp4'); await q.waitForTimeout(2000);
  const lay = await q.evaluate(() => { const f = s => [...document.querySelectorAll('main button')].find(b => b.innerText.trim() === s); const t = e => e ? Math.round(e.getBoundingClientRect().top + scrollY) : null; return { compressTop: t(f('Compress Video')), modeTop: t(f('Medium (25% smaller)')), overflowX: document.documentElement.scrollWidth > innerWidth + 1 }; });
  await q.screenshot({ path: OUT + `layout-${nm}-file.png` }); R[nm] = { ...idle, ...lay }; await c2.close(); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate-kbd.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
