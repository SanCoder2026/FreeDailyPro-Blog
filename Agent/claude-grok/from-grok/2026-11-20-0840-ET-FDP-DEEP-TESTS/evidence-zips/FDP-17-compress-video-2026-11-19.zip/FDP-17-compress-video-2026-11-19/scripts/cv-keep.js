// compress-video: larger-result path at 0 remaining. hd1080.mp4, Manual Quality 50% (grows this noisy file); click "Keep original (download)" and "Download the larger MP4 anyway"; record dialog/download/count.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/17-compress-video/live/'; const T = '/workspace/deep/17-compress-video/testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await c.newPage(); const R = { t: now() };
 await p.goto('https://www.freedailypro.com/tool/compress-video', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday; R.start = await used();
 await p.locator('input[type=file]').first().setInputFiles(T + 'hd1080.mp4'); await p.waitForTimeout(1500);
 await p.getByRole('button', { name: 'Manual Quality', exact: true }).click(); await p.getByRole('button', { name: 'Compress Video', exact: true }).click();
 await p.locator('[data-testid=video-result]').waitFor({ timeout: 600000 }); R.result = await p.locator('[data-testid=video-result]').innerText();
 R.buttons = await p.evaluate(() => [...document.querySelectorAll('main button')].map(b => b.innerText.trim()).filter(x => /Download|Keep|anyway|Pass/i.test(x)));
 for (const [k, rx] of [['keep', /Keep original/], ['larger', /larger MP4 anyway/]]) { const dl = p.waitForEvent('download', { timeout: 6000 }).catch(() => null); await p.getByRole('button', { name: rx }).first().click(); const d = await dl; await p.waitForTimeout(2000);
  const dg = p.locator('[role=dialog],[role=alertdialog]'); R[k] = { download: d ? d.suggestedFilename() : null, dialog: (await dg.count()) ? (await dg.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 200) : null, count: await used() };
  if (d) { const fp = OUT + 'keep-' + d.suggestedFilename(); await d.saveAs(fp); R[k].bytes = fs.statSync(fp).size; fs.unlinkSync(fp); } if (R[k].dialog) { await p.screenshot({ path: OUT + 'dlg-' + k + '.png' }); await p.keyboard.press('Escape'); await p.waitForTimeout(500); } }
 await p.screenshot({ path: OUT + 'larger-result.png' }); R.t2 = now(); fs.writeFileSync(OUT + 'keep.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
