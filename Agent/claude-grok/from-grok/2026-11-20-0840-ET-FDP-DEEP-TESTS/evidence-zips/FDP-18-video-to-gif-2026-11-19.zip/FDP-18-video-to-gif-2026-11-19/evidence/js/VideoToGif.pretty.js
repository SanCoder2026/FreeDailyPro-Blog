import { r as i, j as e } from "./vendor-react-D01g8YgM.js";
import { l as ue } from "./utils-qgqMjnRG.js";
import { T as me, F as pe, R as he, D as fe } from "./ToolPage-DS5jbfzr.js";
import { f as U, N as xe, ax as ge, B as W } from "./index-D2ZT81un.js";
import { T as be } from "./ToolInfoSection-M0kcUBq8.js";
import { u as ve } from "./UsageAndUpgradeStrip-Ckl_cEoN.js";
import { v as Z } from "./operations-P8Ty5WBe.js";
import { t as we, B as H } from "./megabytes-DWJJlZGf.js";
import { F as Ne, V as je, s as Fe } from "./uiHelpers-b-OPLOlA.js";
import {
  checkFileSize as Me,
  stopProcessing as Se,
  loadFFmpeg as ke,
  fetchFile as ye,
  ffmpegOutputToBlob as $e,
  resetFFmpegEngine as Ge,
} from "./ffmpegEngine-DH91Xnxx.js";
import "./useUploadApi-CeBVbB2U.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-mA9gIB_c.js";
import "./share-2-wJ7OG3q6.js";
import "./copy-DxyF2bO9.js";
import "./workflowCta-QcLjv4ms.js";
import "./access-BBg1iIm1.js";
import "./useAdminAccess-D2xxeUJv.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-BaZhqv4P.js";
import "./map-pin-DiPhQKiV.js";
import "./FaqSection-DgbFc-d2.js";
import "./ToolVideoEmbed-DltoCXpM.js";
import "./GuideLinks-BsEl-oB0.js";
import "./blog-Cqpj3gtZ.js";
import "./info-BGlOhDp4.js";
import "./productCards-CAZfINO_.js";
import "./layers-B7zHnkyf.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-CmqWEytu.js";
import "./chevron-up-Bx33pgGu.js";
import "./scriptFonts-B9baRZsf.js";
import "./progress-N6eOMBez.js";
import "./square-TSyXkWwu.js";
function J(r, o) {
  return o > 8
    ? { width: r, fps: o > 12 ? 12 : 8 }
    : r > 200
      ? {
          width: Math.max(160, Math.round((r * 0.75) / 10) * 10),
          fps: o > 6 ? 6 : o,
        }
      : o > 5
        ? { width: r, fps: 5 }
        : null;
}
async function Ce(r, o, c, n, s, G = 8) {
  let l = o,
    p = 0;
  for (let b = 0; b < G; b++) {
    if (((p = ((await r(l)) * c) / Math.max(0.1, n)), p * 1.1 <= s)) {
      const h = (0.92 * s) / (p * 1.1);
      if (b > 0 && h > 1.15) {
        const f = Math.min(
          o.width,
          Math.round((l.width * Math.sqrt(h)) / 10) * 10,
        );
        if (f > l.width) {
          const d = { width: f, fps: l.fps },
            N = ((await r(d)) * c) / Math.max(0.1, n);
          if (N * 1.1 <= s)
            return { ...d, estimate: N, fits: !0, fitSeconds: c };
        }
      }
      return { ...l, estimate: p, fits: !0, fitSeconds: c };
    }
    const C = J(l.width, l.fps);
    if (!C) break;
    l = C;
  }
  const P = Math.max(0.5, Math.floor(((c * s) / (p * 1.1)) * 2) / 2);
  return { ...l, estimate: p, fits: !1, fitSeconds: P };
}
function E(r, o, c) {
  let n = Number.isFinite(r) ? Math.max(0, r) : 0,
    s = Number.isFinite(o) && o > 0 ? o : 5;
  return (
    (s = Math.max(0.5, s)),
    c &&
      Number.isFinite(c) &&
      ((n = Math.min(n, Math.max(0, c - 0.5))),
      (s = Math.max(Math.min(s, c - n), Math.min(0.5, c)))),
    (n = Math.round(n * 10) / 10),
    (s = Math.round(s * 10) / 10),
    { start: n, length: s, changed: n !== r || s !== o }
  );
}
const q = {
    what: "Converts a short video clip into an animated GIF, useful for sharing a quick clip somewhere GIFs are supported but video files aren't, like certain chat apps or forum posts. Runs entirely in your browser — the video never leaves your device.",
    how: "Upload your video and download the resulting animated GIF. Longer clips take more time and produce larger files — this works best on short clips.",
    tip: "Keep the source clip under about 10 seconds — GIFs don't compress as efficiently as video, so longer clips can produce surprisingly large file sizes and take a while to generate. This is one of the slower video operations here since it has to re-encode every frame into GIF's own format. Some phone-recorded videos (particularly .mov files) use a codec this tool can't read — if processing fails right away, try re-exporting the video from your phone's own share options first.",
  },
  Ie = 20;
function pt() {
  const [r, o] = i.useState(null),
    [c, n] = i.useState(""),
    [s, G] = i.useState(null),
    [l, p] = i.useState(!1),
    [P, b] = i.useState(0),
    [C, h] = i.useState(""),
    [f, d] = i.useState(null),
    { isPro: N, isLoading: Q, isAdmin: X } = ve(),
    j = i.useRef(null),
    K = i.useRef(null),
    [v, I] = i.useState("0"),
    [F, T] = i.useState("5"),
    [z, ee] = i.useState("480"),
    [O, te] = i.useState("12"),
    [D, se] = i.useState("1"),
    [V, re] = i.useState(!1),
    [M, ie] = i.useState("0"),
    [S, k] = i.useState(null),
    oe = i.useCallback((t) => {
      const a = t[0];
      if (a) {
        if (!ue(a)) {
          U.error(`"${a.name}" isn't a video file`);
          return;
        }
        (k(null), o(a), n(URL.createObjectURL(a)), d(null), G(null));
      }
    }, []),
    _ = r ? Me([r], N || Q, X) : null,
    ae = () => {
      (K.current?.abort(), j.current && Se(j.current));
    },
    ne = async () => {
      if (!r || S) return;
      (p(!0), b(0));
      const t = new AbortController();
      K.current = t;
      try {
        h("Loading video engine...");
        const a = await ke((g) => h(g));
        ((j.current = a), h("Reading video file..."));
        const w = r.name.match(/\.([^.]+)$/)?.[1] || "mp4";
        (await a.writeFile(`input.${w}`, await ye(r)),
          h("Generating color palette..."));
        const { start: Y, length: B } = E(Number(v), Number(F), s);
        let u = Number(z),
          m = Number(O);
        const x = Number(M) * H;
        let y,
          le = "";
        if (x) {
          const g = Math.min(B, 1.5),
            $ = Y + Math.max(0, (B - g) / 2),
            R = await Ce(
              async (L) => (
                h(`Estimating the size at ${L.width} px, ${L.fps} fps...`),
                (
                  await Z(
                    a,
                    `input.${w}`,
                    () => {},
                    t.signal,
                    () => {},
                    {
                      startSeconds: $,
                      lengthSeconds: g,
                      width: L.width,
                      fps: L.fps,
                      speed: Number(D),
                      playOnce: V,
                    },
                  )
                ).length
              ),
              { width: u, fps: m },
              B,
              g,
              x,
            );
          ((u = R.width),
            (m = R.fps),
            R.fits ||
              (le = `A clip of about ${R.fitSeconds} s would fit in ${M} MB at ${u} px and ${m} fps.`));
        }
        let ce = 0;
        for (;;) {
          h(`Creating the GIF at ${u} px, ${m} fps...`);
          const g = await Z(a, `input.${w}`, b, t.signal, () => {}, {
            startSeconds: Y,
            lengthSeconds: B,
            width: u,
            fps: m,
            speed: Number(D),
            playOnce: V,
          });
          if (((y = $e(g, "image/gif")), !x || y.size <= x)) break;
          const $ = J(u, m);
          if (!$ || ++ce > 2) break;
          ((u = $.width), (m = $.fps));
        }
        d(y);
        const A = y.size / H,
          de = u !== Number(z) || m !== Number(O);
        x && y.size > x
          ? U.warning(
              `GIF is ${A.toFixed(1)} MB, still over ${M} MB at ${u} px and ${m} fps. Use a shorter clip to make it smaller.`,
            )
          : U.success(
              `GIF created: ${A.toFixed(1)} MB` +
                (de ? ` (reduced to ${u} px, ${m} fps to fit ${M} MB)` : "") +
                (!x && A > 8
                  ? " - large; lower the width or frame rate, or use a shorter clip, to shrink it"
                  : ""),
            );
      } catch (a) {
        Fe(a);
      } finally {
        (j.current && Ge(j.current), p(!1));
      }
    };
  return e.jsxs(me, {
    children: [
      r
        ? e.jsxs("div", {
            className: "space-y-4",
            children: [
              e.jsx("video", {
                src: c,
                controls: !0,
                className: "w-full max-h-48 rounded-lg border",
                onLoadedMetadata: (t) => {
                  const a = t.currentTarget.duration;
                  if (!Number.isFinite(a) || a <= 0) {
                    k(
                      `"${r.name}" has no readable video length. Try re-exporting it as MP4.`,
                    );
                    return;
                  }
                  G(a);
                  const w = E(Number(v), Number(F), a);
                  (I(String(w.start)), T(String(w.length)));
                },
                onError: () =>
                  k(
                    `"${r.name}" couldn't be read as a video; it may be damaged or use a codec this browser can't open. Try re-exporting it as MP4.`,
                  ),
              }),
              S &&
                e.jsx("p", {
                  role: "alert",
                  className: "text-xs text-destructive",
                  "data-testid": "gif-file-error",
                  children: S,
                }),
              s !== null &&
                !S &&
                e.jsxs("p", {
                  className: "text-xs text-muted-foreground",
                  "data-testid": "gif-duration",
                  children: [
                    "Clip is ",
                    s.toFixed(1),
                    " s long. Start and Length are kept inside it.",
                  ],
                }),
              s !== null &&
                s > Ie &&
                e.jsxs(xe, {
                  className: "flex gap-2",
                  children: [
                    e.jsx(ge, {
                      className: "h-4 w-4 text-primary shrink-0 mt-0.5",
                    }),
                    e.jsxs("p", {
                      className: "text-xs",
                      children: [
                        "This clip is about ",
                        Math.round(s),
                        " seconds long — GIF works best on short clips (under ~10s). Longer source videos take real time to convert and often produce a surprisingly large GIF file. Trim it down first with the Trim Video tool if you only need part of it.",
                      ],
                    }),
                  ],
                }),
              _ && e.jsx(Ne, { check: _, isPro: N }),
              e.jsxs("div", {
                className: "grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm",
                children: [
                  e.jsxs("div", {
                    children: [
                      e.jsx("label", {
                        htmlFor: "gif-start",
                        className: "text-xs block mb-1",
                        children: "Start (seconds)",
                      }),
                      e.jsx("input", {
                        id: "gif-start",
                        type: "number",
                        min: "0",
                        step: "0.1",
                        className:
                          "border rounded px-2 py-1 w-full bg-background",
                        value: v,
                        onChange: (t) => {
                          (I(t.target.value), d(null));
                        },
                        onBlur: () => {
                          const t = E(Number(v), Number(F), s);
                          (I(String(t.start)), T(String(t.length)));
                        },
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx("label", {
                        htmlFor: "gif-length",
                        className: "text-xs block mb-1",
                        children: "Length (seconds)",
                      }),
                      e.jsx("input", {
                        id: "gif-length",
                        type: "number",
                        min: "0.5",
                        step: "0.1",
                        max: s ? Math.max(0.5, s - (Number(v) || 0)) : void 0,
                        className:
                          "border rounded px-2 py-1 w-full bg-background",
                        value: F,
                        onChange: (t) => {
                          (T(t.target.value), d(null));
                        },
                        onBlur: () => {
                          const t = E(Number(v), Number(F), s);
                          (I(String(t.start)), T(String(t.length)));
                        },
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx("label", {
                        className: "text-xs block mb-1",
                        children: "Width",
                      }),
                      e.jsx("select", {
                        className:
                          "border rounded px-2 py-1 w-full bg-background",
                        value: z,
                        onChange: (t) => {
                          (ee(t.target.value), d(null));
                        },
                        children: ["240", "320", "480", "640", "800"].map((t) =>
                          e.jsxs(
                            "option",
                            { value: t, children: [t, " px"] },
                            t,
                          ),
                        ),
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx("label", {
                        className: "text-xs block mb-1",
                        children: "Frames per second",
                      }),
                      e.jsx("select", {
                        className:
                          "border rounded px-2 py-1 w-full bg-background",
                        value: O,
                        onChange: (t) => {
                          (te(t.target.value), d(null));
                        },
                        children: ["5", "8", "10", "12", "15", "20"].map((t) =>
                          e.jsxs(
                            "option",
                            { value: t, children: [t, " fps"] },
                            t,
                          ),
                        ),
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx("label", {
                        className: "text-xs block mb-1",
                        children: "Speed",
                      }),
                      e.jsx("select", {
                        className:
                          "border rounded px-2 py-1 w-full bg-background",
                        value: D,
                        onChange: (t) => {
                          (se(t.target.value), d(null));
                        },
                        children: ["0.5", "0.75", "1", "1.5", "2"].map((t) =>
                          e.jsx(
                            "option",
                            {
                              value: t,
                              children: t === "1" ? "Normal speed" : `${t}x`,
                            },
                            t,
                          ),
                        ),
                      }),
                    ],
                  }),
                  e.jsx("div", {
                    className: "flex items-end",
                    children: e.jsxs("label", {
                      className: "flex items-center gap-2 text-sm pb-1",
                      children: [
                        e.jsx("input", {
                          type: "checkbox",
                          checked: V,
                          onChange: (t) => {
                            (re(t.target.checked), d(null));
                          },
                        }),
                        " Play once (no loop)",
                      ],
                    }),
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx("label", {
                        className: "text-xs block mb-1",
                        children: "Largest file",
                      }),
                      e.jsxs("select", {
                        className:
                          "border rounded px-2 py-1 w-full bg-background",
                        value: M,
                        onChange: (t) => {
                          (ie(t.target.value), d(null));
                        },
                        children: [
                          e.jsx("option", { value: "0", children: "No limit" }),
                          e.jsx("option", { value: "2", children: "2 MB" }),
                          e.jsx("option", { value: "5", children: "5 MB" }),
                          e.jsx("option", {
                            value: "8",
                            children: "8 MB (chat apps)",
                          }),
                          e.jsx("option", { value: "10", children: "10 MB" }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              f &&
                e.jsxs("p", {
                  className: "text-xs font-medium text-green-600",
                  children: ["GIF size: ", we(f.size, 2), " MB"],
                }),
              f && e.jsx(he, { blob: f }),
              l && e.jsx(je, { progress: P, statusMessage: C, onStop: ae }),
              e.jsx("div", {
                className: "flex gap-3",
                children: f
                  ? e.jsxs(e.Fragment, {
                      children: [
                        e.jsx(fe, {
                          blob: f,
                          fileName: r.name.replace(/\.[^.]+$/, ".gif"),
                        }),
                        e.jsx(W, {
                          variant: "outline",
                          onClick: () => {
                            (o(null), n(""), d(null), k(null));
                          },
                          children: "New",
                        }),
                      ],
                    })
                  : e.jsxs(e.Fragment, {
                      children: [
                        e.jsx(W, {
                          onClick: ne,
                          disabled: l || !!S || _?.severity !== "ok",
                          children: l ? "Creating GIF..." : "Create GIF",
                        }),
                        e.jsx(W, {
                          variant: "outline",
                          onClick: () => {
                            (o(null), n(""), k(null));
                          },
                          disabled: l,
                          children: "Reset",
                        }),
                      ],
                    }),
              }),
            ],
          })
        : e.jsx(pe, {
            gateAtDownload: !0,
            accept: "video/*",
            maxSize: 200,
            onFiles: oe,
            label: "Drop a video to convert to GIF",
            description: "Create animated GIFs from video clips",
          }),
      e.jsx(be, { whatIsIt: q.what, howToUse: q.how, tip: q.tip }),
    ],
  });
}
export { pt as default };
//# sourceMappingURL=VideoToGif-lYW1EHUM.js.map
