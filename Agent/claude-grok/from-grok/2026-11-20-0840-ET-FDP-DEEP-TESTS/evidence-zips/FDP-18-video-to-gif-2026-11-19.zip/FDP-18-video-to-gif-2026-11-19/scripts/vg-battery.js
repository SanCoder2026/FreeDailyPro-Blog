// video-to-gif battery: one fresh context; every case sets all controls (settings carry over between files, recorded as r.carried); cases from vg-cases.json (argv[2] = comma IDs). Create GIF costs no trial use (gate is at Download); no download is made.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/18-video-to-gif/live/'; const T = '/workspace/deep/18-video-to-gif/testfiles/';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const ids = process.argv[2] ? process.argv[2].split(',') : null; const tag = ids ? '-' + ids.join('_') : '';
const cases = JSON.parse(fs.readFileSync(__dirname + '/vg-cases.json')).filter(c => !ids || ids.includes(c.id));
const sel = (p, i) => p.locator('main select').nth(i);
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); p.setDefaultTimeout(15000);
  const R = { t: now(), cases: [], console: [] }; p.on('console', m => { const x = m.text(); if (!/ads|google|doubleclick|media\.net|gpt/i.test(x) && (m.type() === 'error' || /fail|error|abort/i.test(x))) R.console.push(m.type() + ': ' + x.slice(0, 300)); });
  await p.goto('https://www.freedailypro.com/tool/video-to-gif', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
  R.ls0 = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
  const save = () => fs.writeFileSync(OUT + 'battery' + tag + '.json', JSON.stringify(R, null, 1));
  for (const c of cases) {
    const r = { ...c, t: now() };
    try {
      for (const n of ['New', 'Reset']) { const btn = p.getByRole('button', { name: n, exact: true }); if (await btn.count() && await btn.first().isEnabled()) { await btn.first().click(); await p.waitForTimeout(600); } }
      await p.locator('input[type=file]').first().setInputFiles(T + c.file); await p.waitForTimeout(3000);
      r.pre = await p.evaluate(() => { const m = document.querySelector('main').innerText; return (m.match(/[^\n]*(Clip is|couldn.t be read|no readable|isn.t a video|trial use supports|over \d+ MB|seconds long|MB)[^\n]*/g) || []).slice(0, 8); });
      r.toastsPre = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim()).join(' || '));
      await p.locator('#gif-start').fill(c.start || '0').catch(() => {});
      await p.locator('#gif-length').fill(c.length || '5').catch(() => {});
      { await p.locator('#gif-length').blur().catch(() => {}); await p.locator('#gif-start').focus().catch(() => {}); await p.locator('#gif-start').blur().catch(() => {}); }
      r.startLen = await p.evaluate(() => [document.querySelector('#gif-start')?.value, document.querySelector('#gif-length')?.value]);
      r.carried = await p.evaluate(() => [...document.querySelectorAll('main select')].map(s => s.value).join('/'));
      await sel(p, 0).selectOption(c.width || '480').catch(e => r.selErr = 'width'); await sel(p, 1).selectOption(c.fps || '12').catch(e => r.selErr = 'fps');
      await sel(p, 2).selectOption(c.speed || '1').catch(e => r.selErr = 'speed'); await sel(p, 3).selectOption(c.cap || '0').catch(e => r.selErr = 'cap');
      await p.getByLabel('Play once (no loop)').setChecked(!!c.once).catch(() => {});
      const cb = p.getByRole('button', { name: 'Create GIF', exact: true });
      r.createEnabled = (await cb.count()) ? await cb.isEnabled() : null;
      if (!r.createEnabled) { await p.screenshot({ path: OUT + 'bat-' + c.id + '.png' }); R.cases.push(r); save(); console.log(c.id, 'disabled', JSON.stringify(r.pre), r.toastsPre); continue; }
      const t0 = Date.now(); await cb.click(); const toasts = []; const stat = [];
      const iv = setInterval(async () => { try { const tt = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim()).filter(Boolean)); tt.forEach(x => { if (!toasts.includes(x)) toasts.push(x); }); const st = await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*(Estimating|Creating the GIF|Generating|Encoding|Loading video|Reading video)[^\n]*/) || [''])[0]); if (st && stat[stat.length - 1] !== st) stat.push(((Date.now() - t0) / 1000).toFixed(0) + 's ' + st); } catch (e) {} }, 700);
      await p.waitForFunction(() => /GIF size:/.test(document.querySelector('main').innerText) || ([...document.querySelectorAll('main button')].some(b => b.innerText.trim() === 'Create GIF' && !b.disabled)), null, { timeout: 900000, polling: 1000 }).catch(e => r.err = 'timeout');
      await p.waitForTimeout(1500); clearInterval(iv); r.secs = (Date.now() - t0) / 1000; r.toasts = toasts; r.status = stat.slice(0, 14);
      r.result = await p.evaluate(() => (document.querySelector('main').innerText.match(/GIF size:[^\n]*/) || [null])[0]);
      r.buttons = await p.evaluate(() => [...document.querySelectorAll('main button')].map(b => b.innerText.trim()).filter(x => /Download|Day Pass|New|Drive|cloud|Continue|Share|Copy/i.test(x)));
      if (r.result) {
        const blob = await p.evaluate(async () => { const im = [...document.querySelectorAll('main img')].filter(v => v.src.startsWith('blob:')); const v = im[im.length - 1]; if (!v) return null; const rr = await fetch(v.src); const bb = new Uint8Array(await rr.arrayBuffer()); let s = ''; for (let i = 0; i < bb.length; i += 8192) s += String.fromCharCode.apply(null, bb.subarray(i, i + 8192)); return btoa(s); });
        if (blob) { const buf = Buffer.from(blob, 'base64'); const fn = OUT + 'out-' + c.id + '.gif'; fs.writeFileSync(fn, buf); r.blobBytes = buf.length; }
        await p.screenshot({ path: OUT + 'res-' + c.id + '.png' });
      } else await p.screenshot({ path: OUT + 'bat-' + c.id + '.png' });
    } catch (e) { r.err = String(e).slice(0, 200); }
    R.cases.push(r); save(); console.log(r.id, r.secs, r.result || r.err, (r.toasts || []).join(' / '));
  }
  R.ls1 = await p.evaluate(() => localStorage.getItem('fdp-usage-v1')); R.t1 = now(); save(); await b.close();
})();
