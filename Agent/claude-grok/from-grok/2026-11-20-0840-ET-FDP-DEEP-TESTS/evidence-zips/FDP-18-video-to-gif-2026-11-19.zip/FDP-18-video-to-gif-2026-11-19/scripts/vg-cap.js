// video-to-gif at 0 remaining: Create GIF (free), then Download -> cap dialog -> Buy Day Pass -> stop at the email prompt (types nothing); Drive at 0. No use spent.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/18-video-to-gif/live/'; const T = '/workspace/deep/18-video-to-gif/testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await c.newPage(); p.setDefaultTimeout(15000); const R = { t: now() };
 const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 await p.goto('https://www.freedailypro.com/tool/video-to-gif', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); R.start = await used();
 if (R.start < 10) { R.note = 'loaded with uses left; skipped so no use is spent'; fs.writeFileSync(OUT + 'cap.json', JSON.stringify(R, null, 1)); await b.close(); return; }
 await p.locator('input[type=file]').first().setInputFiles(T + 'noaudio.mp4'); await p.waitForTimeout(2000); await p.locator('#gif-length').fill('3');
 await p.getByRole('button', { name: 'Create GIF', exact: true }).click(); await p.waitForFunction(() => /GIF size:/.test(document.querySelector('main').innerText), null, { timeout: 150000 });
 R.rowText = await p.evaluate(() => (document.querySelector('main').innerText.match(/GIF size:[\s\S]{0,200}/) || [''])[0]);
 const dl = p.waitForEvent('download', { timeout: 5000 }).catch(() => null); await p.getByRole('button', { name: /^Download$/ }).first().click(); R.download = !!(await dl); await p.waitForTimeout(1500);
 R.capDialog = await dialog(); await p.screenshot({ path: OUT + 'dlg-cap.png' });
 const bp = p.getByRole('button', { name: /Buy Day Pass|Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.afterDayPass = { dialog: await dialog(), url: p.url().slice(0, 80), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); }
 for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); }
 const pop = c.waitForEvent('page', { timeout: 5000 }).catch(() => null); await p.getByRole('button', { name: /Save to Google Drive/ }).click(); const pg = await pop; await p.waitForTimeout(1500);
 R.drive = { dialog: await dialog(), popup: pg ? pg.url().slice(0, 40) : null }; if (pg) await pg.close();
 R.end = await used(); R.t2 = now(); fs.writeFileSync(OUT + 'cap.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
