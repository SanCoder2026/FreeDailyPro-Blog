// video-to-gif: starting count; keyboard to the drop zone; Create GIF on noaudio.mp4 (3 s) then Download / Drive / cloud / Day Pass at the starting count (stops at the first dialog or the email prompt; types nothing);
// live regions, labels, focus, axe, Stop button, Continue-with; phones layout. Create GIF itself costs no trial use.
const { chromium, devices } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/18-video-to-gif/live/'; const T = '/workspace/deep/18-video-to-gif/testfiles/'; const URL = 'https://www.freedailypro.com/tool/video-to-gif';
const AXE = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8'); const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const axe = async p => { await p.addScriptTag({ content: AXE }); return p.evaluate(async () => (await axe.run(document.querySelector('main'), { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'best-practice'] }, resultTypes: ['violations'] })).violations.map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length, t: v.nodes.slice(0, 4).map(n => n.target.join(' ')) }))); };
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams)=[^&]*/g, '$1=REDACTED').slice(0, 200);
const done = p => p.waitForFunction(() => /GIF size:/.test(document.querySelector('main').innerText) || [...document.querySelectorAll('main button')].some(b => b.innerText.trim() === 'Create GIF' && !b.disabled), null, { timeout: 600000, polling: 700 });
(async () => { const b = await chromium.launch(); const R = { t: now() };
 const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await c.newPage(); p.setDefaultTimeout(15000);
 await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 2; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(400); } };
 R.start = await used(); R.strip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]); R.axeIdle = await axe(p);
 R.dropText = await p.evaluate(() => { const z = [...document.querySelectorAll('main [role=button], main label, main div')].find(e => /Drop a video to convert/i.test(e.innerText) && e.innerText.length < 400); return z ? z.innerText : null; });
 let chooser = false; p.on('filechooser', () => { chooser = true; }); const seq = [];
 for (let i = 0; i < 60; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('role') || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50).replace(/\n/g, ' '); }); seq.push(a); if (/Drop a video/i.test(a)) { await p.keyboard.press('Enter'); await p.waitForTimeout(1200); seq.push('ENTER -> chooser=' + chooser); break; } }
 R.kbd = { tabs: seq.length, last: seq.slice(-3), chooser };
 await p.locator('input[type=file]').first().setInputFiles(T + 'hd1080.mp4'); await p.waitForTimeout(2500);
 R.axeFile = await axe(p);
 // Stop button mid-run
 await p.locator('#gif-length').fill('10'); await p.locator('main select').nth(0).selectOption('800'); await p.locator('main select').nth(1).selectOption('20');
 await p.getByRole('button', { name: 'Create GIF', exact: true }).click(); await p.waitForTimeout(3500);
 R.progress = await p.evaluate(() => [...document.querySelectorAll('main [role=progressbar],main [aria-live],main [role=status]')].map(e => ({ role: e.getAttribute('role'), live: e.getAttribute('aria-live'), text: e.innerText.slice(0, 80) })));
 const stop = p.getByRole('button', { name: /Stop/ }); R.stopPresent = await stop.count(); if (R.stopPresent) { await stop.first().click(); await p.waitForTimeout(2500); }
 R.afterStop = { toasts: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim())), createEnabled: await p.getByRole('button', { name: 'Create GIF', exact: true }).isEnabled().catch(() => null) };
 await p.screenshot({ path: OUT + 'after-stop.png' });
 await p.getByRole('button', { name: 'Reset', exact: true }).click(); await p.waitForTimeout(800);
 await p.locator('input[type=file]').first().setInputFiles(T + 'noaudio.mp4'); await p.waitForTimeout(2000); await p.locator('#gif-length').fill('3');
 await p.getByRole('button', { name: 'Create GIF', exact: true }).click(); await done(p); await p.waitForTimeout(1500);
 R.result = await p.evaluate(() => (document.querySelector('main').innerText.match(/GIF size:[^\n]*/) || [null])[0]);
 R.liveRegions = await p.evaluate(() => [...document.querySelectorAll('main [aria-live],main [role=status],main [role=alert]')].map(e => ({ live: e.getAttribute('aria-live'), role: e.getAttribute('role'), text: e.innerText.slice(0, 80) })));
 R.resultLive = await p.evaluate(() => { let e = [...document.querySelectorAll('main p')].find(x => /GIF size:/.test(x.innerText)); while (e && e !== document.body) { if (e.getAttribute('aria-live') || /status|alert/.test(e.getAttribute('role') || '')) return true; e = e.parentElement; } return false; });
 R.resultImg = await p.evaluate(() => [...document.querySelectorAll('main img')].filter(i => i.src.startsWith('blob:')).map(i => ({ alt: i.alt, w: i.naturalWidth })));
 R.focusAfter = await p.evaluate(() => document.activeElement.tagName);
 R.resultButtons = await p.evaluate(() => [...document.querySelectorAll('main button, main a')].map(b => b.innerText.trim()).filter(x => /Download|Drive|cloud|Continue|New|Pass|Share|Copy|Next/i.test(x)));
 R.axeResult = await axe(p); await p.screenshot({ path: OUT + 'result-desktop.png', fullPage: true });
 const act = async (name, rx) => { const r = { before: await used() }; const loc = p.getByRole('button', { name: rx }).first(); if (!(await loc.count())) { r.missing = true; return r; }
   const pop = c.waitForEvent('page', { timeout: 5000 }).catch(() => null); const dl = p.waitForEvent('download', { timeout: 5000 }).catch(() => null); const url0 = p.url(); await loc.click(); const [pg, d] = await Promise.all([pop, dl]); await p.waitForTimeout(2000);
   r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null; r.download = d ? d.suggestedFilename() : null; if (pg) { r.popup = red(pg.url()); await pg.close(); }
   if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + '.png' }); await esc(); if (r.url) { await p.goBack().catch(() => {}); await p.waitForTimeout(2500); } return r; };
 R.download = await act('download', /^Download$/);
 R.dayPassText = await act('daypass-text', /Get a Day Pass to download/);
 R.drive = await act('drive', /Save to Google Drive/);
 R.cloud = await act('cloud', /Save to my cloud storage/);
 R.dayPass = await (async () => { await p.getByRole('button', { name: /^Download$/ }).first().click(); await p.waitForTimeout(1500); const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (!(await bp.count())) return null; await bp.click(); await p.waitForTimeout(2500); const r = { dialog: await dialog(), url: red(p.url()) }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); await esc(); return r; })();
 R.end = await used(); await c.close();
 for (const [nm, d] of [['iphone-se', devices['iPhone SE']], ['pixel-7', devices['Pixel 7']]]) { const { defaultBrowserType, ...dd } = d; const c2 = await b.newContext(dd); const q = await c2.newPage(); q.setDefaultTimeout(15000);
  await q.goto(URL, { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4000);
  const idle = await q.evaluate(() => { const z = [...document.querySelectorAll('main [role=button]')].find(e => /Drop a video/i.test(e.innerText)); return { vh: innerHeight, dropTop: z ? Math.round(z.getBoundingClientRect().top + scrollY) : null }; });
  await q.screenshot({ path: OUT + `layout-${nm}-idle.png` }); await q.locator('input[type=file]').first().setInputFiles(T + 'noaudio.mp4'); await q.waitForTimeout(2000);
  const lay = await q.evaluate(() => { const f = s => [...document.querySelectorAll('main button')].find(b => b.innerText.trim() === s); const t = e => e ? Math.round(e.getBoundingClientRect().top + scrollY) : null; return { createTop: t(f('Create GIF')), overflowX: document.documentElement.scrollWidth > innerWidth + 1 }; });
  await q.screenshot({ path: OUT + `layout-${nm}-file.png`, fullPage: true }); R[nm] = { ...idle, ...lay }; await c2.close(); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate-kbd.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
