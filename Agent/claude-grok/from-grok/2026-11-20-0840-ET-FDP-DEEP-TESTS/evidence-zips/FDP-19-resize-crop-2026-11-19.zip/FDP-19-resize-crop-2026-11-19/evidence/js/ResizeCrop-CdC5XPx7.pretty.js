import { r as a, j as t } from "./vendor-react-D01g8YgM.js";
import { T as mt, F as pt, P as xt, D as gt } from "./ToolPage-DS5jbfzr.js";
import { f as j, B as M, e as z, I as K } from "./index-D2ZT81un.js";
import { T as ft } from "./ToolInfoSection-M0kcUBq8.js";
import { a as Pe, c as wt, f as bt } from "./decode-D7I8Qajh.js";
import { c as yt, a as jt, r as vt } from "./operations-ISiPxXUp.js";
import {
  rotateFlip as Nt,
  fitCanvas as Mt,
  toGrayscale as Ct,
} from "./convertBrowser-gUyoAgIp.js";
import { FIT_MODES as St, parseColor as Rt } from "./convertCore-pdjQ6UTb.js";
import { t as de, F as zt } from "./convertForm-Bkb1Ezx2.js";
import { C as _, a as kt } from "./ConvertOptionsPanel-DT0l7GpN.js";
import {
  S as Ue,
  a as Ie,
  b as De,
  c as Ee,
  d as $e,
} from "./select-DC0cHVOZ.js";
import { g as Oe, w as Tt } from "./utils-BCX55KBw.js";
import { M as Ft } from "./maximize-2-j9VCawlT.js";
import { C as Pt } from "./crop-BNhT7cjd.js";
import "./useUploadApi-CeBVbB2U.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-mA9gIB_c.js";
import "./share-2-wJ7OG3q6.js";
import "./copy-DxyF2bO9.js";
import "./workflowCta-QcLjv4ms.js";
import "./UsageAndUpgradeStrip-Ckl_cEoN.js";
import "./access-BBg1iIm1.js";
import "./useAdminAccess-D2xxeUJv.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-BaZhqv4P.js";
import "./map-pin-DiPhQKiV.js";
import "./FaqSection-DgbFc-d2.js";
import "./ToolVideoEmbed-DltoCXpM.js";
import "./GuideLinks-BsEl-oB0.js";
import "./blog-Cqpj3gtZ.js";
import "./info-BGlOhDp4.js";
import "./productCards-CAZfINO_.js";
import "./layers-B7zHnkyf.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-CmqWEytu.js";
import "./chevron-up-Bx33pgGu.js";
import "./jpegDpi-c8DPdZxl.js";
import "./slider-m2UfhN9O.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./checkbox-Du8eLd-S.js";
const me = {
    what: "Changes an image's dimensions, either by resizing it to a specific width and height, or by cropping it down to just the area you want to keep. Resizing offers the same five fit modes as the FreeDailyPro API (inside, contain, cover, fill and outside), and can also turn or mirror the picture and make it black and white.",
    how: `Upload your image, pick Resize or Crop. For Resize, enter your target width and height — with "Maintain aspect ratio" on (the default), changing one dimension automatically adjusts the other so the image never distorts; turn it off if you specifically want independent width and height, then pick how the picture fits the box: cover crops the overflow, contain pads the leftover space, fill stretches, inside and outside keep the shape. A live preview updates as you type. For Crop, click and drag directly on the image to select the area to keep — you'll see the selection take shape as you drag, then apply it. Download the result when you're done.`,
    tip: "With aspect ratio locked, you can't stretch or squash the image — that's the point, but it also means you can't force an exact width AND height unless they already match the original proportions. Turn the lock off if you genuinely need specific, independent dimensions and are fine with some distortion.",
  },
  We = 0.02,
  E = 16384,
  Ae = 1e8;
function Le(o, v) {
  if (v.trim() === "") return `Enter a ${o}`;
  const l = Number(v);
  return Number.isFinite(l)
    ? Number.isInteger(l)
      ? l < 1
        ? `${o[0].toUpperCase()}${o.slice(1)} must be at least 1 px`
        : l > E
          ? `${o[0].toUpperCase()}${o.slice(1)} can be at most ${E.toLocaleString("en-US")} px`
          : null
      : `${o[0].toUpperCase()}${o.slice(1)} must be a whole number of pixels`
    : `${o[0].toUpperCase()}${o.slice(1)} must be a number`;
}
const Ut = [
  { label: "Freeform", ratio: null },
  { label: "1:1", ratio: 1 },
  { label: "16:9", ratio: 16 / 9 },
  { label: "4:3", ratio: 4 / 3 },
  { label: "3:2", ratio: 3 / 2 },
  { label: "3:4", ratio: 3 / 4 },
  { label: "2:3", ratio: 2 / 3 },
  { label: "4:5", ratio: 4 / 5 },
  { label: "9:16", ratio: 9 / 16 },
];
function js() {
  const [o, v] = a.useState(null),
    [l, Q] = a.useState("resize"),
    [k, He] = a.useState("%"),
    [pe, Xe] = a.useState(""),
    [xe, _e] = a.useState("300"),
    [x, T] = a.useState(""),
    [b, F] = a.useState(""),
    [P, Be] = a.useState(!0),
    [$, Ye] = a.useState("fill"),
    [ee, Ge] = a.useState(!1),
    [te, Ve] = a.useState("#ffffff"),
    [B, qe] = a.useState(!1),
    [U, se] = a.useState("0"),
    [ne, ae] = a.useState(!1),
    [re, ie] = a.useState(!1),
    [oe, ge] = a.useState(!1),
    [fe, O] = a.useState(null),
    [we, m] = a.useState(null),
    [Je, I] = a.useState(!1),
    [C, u] = a.useState(null),
    [i, le] = a.useState({ w: 0, h: 0 }),
    [be, ye] = a.useState(null),
    [p, ce] = a.useState(null),
    [g, Y] = a.useState(null),
    [d, y] = a.useState(null),
    [ue, Ze] = a.useState(null),
    [je, Ke] = a.useState(""),
    [f, G] = a.useState(null),
    V = a.useRef(null),
    ve = a.useRef(null),
    Ne = a.useRef(null),
    W = a.useRef(null),
    Qe = a.useCallback((e) => {
      const s = e[0];
      s &&
        (v(s),
        u(null),
        m(null),
        se("0"),
        ae(!1),
        ie(!1),
        ge(!1),
        le({ w: 0, h: 0 }),
        T(""),
        F(""),
        y(null),
        O(null),
        Pe(s)
          .then(async ({ canvas: n }) => {
            ((Ne.current = n),
              ye(URL.createObjectURL(await wt(n, "image/png"))),
              le({ w: n.width, h: n.height }),
              T(String(n.width)),
              F(String(n.height)));
          })
          .catch((n) => {
            (j.error(n?.message || "This file could not be opened as an image"),
              v(null));
          }));
    }, []),
    N = de(i.w, i.h, U),
    Me = (e) => {
      if ((T(e), u(null), m(null), P && N.w > 0)) {
        const s = Number(e);
        s > 0 && F(String(Math.round(s * (N.h / N.w))));
      }
    },
    et = (e) => {
      if ((F(e), u(null), m(null), P && N.h > 0)) {
        const s = Number(e);
        s > 0 && T(String(Math.round(s * (N.w / N.h))));
      }
    },
    tt = (e) => {
      const s = de(1, 2, e).w !== de(1, 2, U).w;
      (se(e), s && (T(b), F(x)), u(null), m(null));
    },
    Ce = (e, s, n, h) => {
      let r = Nt(e, Number(U), ne, re);
      const c = B ? (Rt(te) ?? void 0) : void 0;
      if (
        ((r = Mt(r, s, n, P ? "fill" : $, ee, c && c.a > 0 ? c : void 0)), oe)
      ) {
        if (r === e) {
          const w = document.createElement("canvas");
          ((w.width = r.width),
            (w.height = r.height),
            w.getContext("2d").drawImage(r, 0, 0),
            (r = w));
        }
        Ct(r);
      }
      return h === "image/jpeg" ? bt(r, "#ffffff") : r;
    };
  a.useEffect(() => {
    if (!(!o || l !== "resize"))
      return (
        W.current && clearTimeout(W.current),
        (W.current = setTimeout(async () => {
          const e = Number(x),
            s = Number(b);
          if (!e || !s || e <= 0 || s <= 0) {
            O(null);
            return;
          }
          const n = Ne.current;
          if (!n || e * s > 4e6) {
            O(null);
            return;
          }
          Ce(n, e, s, "image/png").toBlob((r) => {
            r && O(URL.createObjectURL(r));
          });
        }, 250)),
        () => {
          W.current && clearTimeout(W.current);
        }
      );
  }, [o, l, x, b, $, ee, te, B, U, ne, re, oe, P]);
  const st = async () => {
      if (o) {
        I(!0);
        try {
          const e = Math.round(Number(x)),
            s = Math.round(Number(b));
          if (!(e >= 1) || !(s >= 1)) {
            (j.error("Width and height must each be at least 1 px"), I(!1));
            return;
          }
          if (e > E || s > E || e * s > Ae) {
            (j.error("That size is too large for the browser to make"), I(!1));
            return;
          }
          e * s > 16e6 &&
            j.warning(
              "This is very large (over 16 megapixels) and may fail on phones",
            );
          const { canvas: n } = await Pe(o),
            { blob: h } = await yt(Ce(n, e, s, Oe(o).mimeType), o);
          (u(h), j.success(`Resized to ${e}x${s}`));
        } catch {
          j.error("Failed to resize");
        } finally {
          I(!1);
        }
      }
    },
    nt = async () => {
      if (!(!o || !d)) {
        I(!0);
        try {
          let { blob: e, width: s, height: n } = await jt(o, d);
          const h = Math.round(Number(je));
          if (h >= 1 && h !== s) {
            const r = Math.max(1, Math.round(n * (h / s)));
            ((e = (await vt(new File([e], o.name, { type: e.type }), h, r))
              .blob),
              (s = h),
              (n = r));
          }
          (u(e), m(URL.createObjectURL(e)), j.success(`Cropped to ${s}x${n}`));
        } catch {
          j.error("Failed to crop");
        } finally {
          I(!1);
        }
      }
    },
    A = (e, s) => {
      const n = ve.current.getBoundingClientRect();
      return {
        x: Math.min(1, Math.max(0, (e - n.left) / n.width)),
        y: Math.min(1, Math.max(0, (s - n.top) / n.height)),
      };
    },
    q = (e) => A(e.clientX, e.clientY),
    Se = (e, s) => {
      if (ue === null || !i.w || !i.h)
        return {
          x: Math.min(e.x, s.x),
          y: Math.min(e.y, s.y),
          w: Math.abs(s.x - e.x),
          h: Math.abs(s.y - e.y),
        };
      const n = ue * (i.h / i.w),
        h = s.x >= e.x ? 1 : -1,
        r = s.y >= e.y ? 1 : -1,
        c = Math.abs(s.x - e.x),
        w = Math.abs(s.y - e.y);
      let S = c,
        R = c / n;
      w * n > c && ((R = w), (S = w * n));
      const Te = h > 0 ? 1 - e.x : e.x,
        Fe = r > 0 ? 1 - e.y : e.y;
      (S > Te && ((S = Te), (R = S / n)), R > Fe && ((R = Fe), (S = R * n)));
      const ht = e.x + h * S,
        dt = e.y + r * R;
      return { x: Math.min(e.x, ht), y: Math.min(e.y, dt), w: S, h: R };
    },
    Re = (e) => {
      l === "crop" && (G("create"), ce(e), Y(e));
    },
    J = (e, s) => {
      d && (G(e), (V.current = { selection: d, point: s }));
    },
    ze = (e) => {
      if (l !== "crop") return;
      if (f === "create") {
        if (!p) return;
        const n = Se(p, e);
        Y({
          x: n.x === p.x ? n.x + n.w : n.x,
          y: n.y === p.y ? n.y + n.h : n.y,
        });
        return;
      }
      const s = V.current;
      if (s) {
        if (f === "move") {
          const n = e.x - s.point.x,
            h = e.y - s.point.y,
            r = s.selection,
            c = Math.max(0, Math.min(1 - r.w, r.x + n)),
            w = Math.max(0, Math.min(1 - r.h, r.y + h));
          (y({ x: c, y: w, w: r.w, h: r.h }), u(null), m(null));
          return;
        }
        if (f === "nw" || f === "ne" || f === "sw" || f === "se") {
          const n = s.selection,
            h = {
              x: f.includes("w") ? n.x + n.w : n.x,
              y: f.includes("n") ? n.y + n.h : n.y,
            };
          (y(Se(h, e)), u(null), m(null));
        }
      }
    },
    at = (e) => Re(q(e)),
    rt = (e) => ze(q(e)),
    it = (e) => {
      if (l !== "crop" || e.touches.length === 0) return;
      const s = e.touches[0];
      Re(A(s.clientX, s.clientY));
    },
    ot = (e) => {
      if (l !== "crop" || !f || e.touches.length === 0) return;
      e.preventDefault();
      const s = e.touches[0];
      ze(A(s.clientX, s.clientY));
    },
    Z = () => {
      if (l !== "crop") {
        (ce(null), Y(null), G(null), (V.current = null));
        return;
      }
      if (f === "create" && p && g) {
        const e = Math.abs(g.x - p.x),
          s = Math.abs(g.y - p.y);
        e >= We &&
          s >= We &&
          (y({ x: Math.min(p.x, g.x), y: Math.min(p.y, g.y), w: e, h: s }),
          u(null),
          m(null));
      }
      (ce(null), Y(null), G(null), (V.current = null));
    },
    L =
      p && g
        ? {
            x: Math.min(p.x, g.x),
            y: Math.min(p.y, g.y),
            w: Math.abs(g.x - p.x),
            h: Math.abs(g.y - p.y),
          }
        : d,
    lt = (() => {
      const e = C?.type;
      return e === "image/jpeg"
        ? "jpg"
        : e === "image/png" ||
            e === "image/webp" ||
            e === "image/gif" ||
            e === "image/bmp"
          ? e.split("/")[1]
          : o
            ? Oe(o).extension
            : "png";
    })(),
    ct = () =>
      Tt(`${l === "crop" ? "cropped" : "resized"}_${o?.name || "image"}`, lt),
    D = !!o && i.w === 0,
    H = l === "resize" && !D ? Le("width", x) : null,
    X = l === "resize" && !D ? Le("height", b) : null,
    he =
      !H && !X && l === "resize" && !D && Number(x) * Number(b) > Ae
        ? `That is ${Math.round((Number(x) * Number(b)) / 1e6)} megapixels; the limit is 100 megapixels`
        : null,
    ke = !!(H || X || he),
    ut = o?.type === "image/gif";
  return t.jsxs(mt, {
    children: [
      o
        ? t.jsxs("div", {
            className: "space-y-4",
            children: [
              t.jsxs("div", {
                className: "p-4 rounded-lg border bg-card",
                children: [
                  t.jsx("p", {
                    className: "text-sm font-medium",
                    children: o.name,
                  }),
                  t.jsxs("p", {
                    className: "text-xs text-muted-foreground",
                    children: ["Original: ", i.w, " x ", i.h, "px"],
                  }),
                ],
              }),
              t.jsxs("div", {
                className: "flex gap-2",
                children: [
                  t.jsxs(M, {
                    size: "sm",
                    variant: l === "resize" ? "default" : "outline",
                    onClick: () => {
                      (Q("resize"), u(null), m(null));
                    },
                    className: "gap-1.5",
                    children: [
                      t.jsx(Ft, { className: "h-3.5 w-3.5" }),
                      " Resize",
                    ],
                  }),
                  t.jsxs(M, {
                    size: "sm",
                    variant: l === "crop" ? "default" : "outline",
                    onClick: () => {
                      (Q("crop"), u(null), m(null));
                    },
                    className: "gap-1.5",
                    children: [
                      t.jsx(Pt, { className: "h-3.5 w-3.5" }),
                      " Crop",
                    ],
                  }),
                ],
              }),
              l === "resize"
                ? t.jsxs("div", {
                    className: "space-y-3",
                    children: [
                      t.jsxs("label", {
                        className:
                          "flex items-center gap-2 text-sm cursor-pointer w-fit",
                        children: [
                          t.jsx("input", {
                            type: "checkbox",
                            checked: P,
                            onChange: (e) => {
                              (Be(e.target.checked), u(null));
                            },
                          }),
                          "Maintain aspect ratio",
                        ],
                      }),
                      t.jsxs("div", {
                        className: "grid grid-cols-2 gap-4",
                        children: [
                          t.jsxs("div", {
                            children: [
                              t.jsx(z, {
                                htmlFor: "rc-width",
                                children: "Width (px)",
                              }),
                              t.jsx(K, {
                                id: "rc-width",
                                type: "number",
                                min: 1,
                                max: E,
                                step: 1,
                                inputMode: "numeric",
                                disabled: D,
                                "aria-invalid": H ? !0 : void 0,
                                value: x,
                                onChange: (e) => Me(e.target.value),
                              }),
                              H &&
                                t.jsx("p", {
                                  role: "alert",
                                  className: "text-xs text-destructive mt-1",
                                  children: H,
                                }),
                            ],
                          }),
                          t.jsxs("div", {
                            children: [
                              t.jsx(z, {
                                htmlFor: "rc-height",
                                children: "Height (px)",
                              }),
                              t.jsx(K, {
                                id: "rc-height",
                                type: "number",
                                min: 1,
                                max: E,
                                step: 1,
                                inputMode: "numeric",
                                disabled: D,
                                "aria-invalid": X ? !0 : void 0,
                                value: b,
                                onChange: (e) => et(e.target.value),
                              }),
                              X &&
                                t.jsx("p", {
                                  role: "alert",
                                  className: "text-xs text-destructive mt-1",
                                  children: X,
                                }),
                            ],
                          }),
                        ],
                      }),
                      he &&
                        t.jsx("p", {
                          role: "alert",
                          className: "text-xs text-destructive",
                          children: he,
                        }),
                      !ke &&
                        N.w > 0 &&
                        Number(x) > N.w * 2 &&
                        t.jsx("p", {
                          className: "text-xs text-muted-foreground",
                          children:
                            "Enlarging an image more than twice its size makes it look soft or blurry.",
                        }),
                      ut &&
                        t.jsx("p", {
                          className: "text-xs text-muted-foreground",
                          children:
                            "Animated GIFs come out as a still PNG (first frame); the animation is not kept.",
                        }),
                      t.jsxs("div", {
                        className: "flex flex-wrap items-end gap-2 text-sm",
                        children: [
                          t.jsxs("div", {
                            children: [
                              t.jsx(z, { children: "Or set the width in" }),
                              t.jsxs("select", {
                                "aria-label": "Unit",
                                value: k,
                                onChange: (e) => He(e.target.value),
                                className:
                                  "border rounded px-2 py-2 bg-background block",
                                children: [
                                  t.jsx("option", {
                                    value: "%",
                                    children: "percent of original",
                                  }),
                                  t.jsx("option", {
                                    value: "cm",
                                    children: "centimetres (print)",
                                  }),
                                  t.jsx("option", {
                                    value: "in",
                                    children: "inches (print)",
                                  }),
                                ],
                              }),
                            ],
                          }),
                          t.jsxs("div", {
                            children: [
                              t.jsx(z, {
                                children:
                                  k === "%"
                                    ? "Percent"
                                    : k === "cm"
                                      ? "Width (cm)"
                                      : "Width (in)",
                              }),
                              t.jsx(K, {
                                className: "w-24",
                                type: "number",
                                min: 0,
                                value: pe,
                                onChange: (e) => Xe(e.target.value),
                              }),
                            ],
                          }),
                          k !== "%" &&
                            t.jsxs("div", {
                              children: [
                                t.jsx(z, { children: "DPI" }),
                                t.jsx(K, {
                                  "aria-label": "DPI",
                                  className: "w-20",
                                  type: "number",
                                  min: 1,
                                  value: xe,
                                  onChange: (e) => _e(e.target.value),
                                }),
                              ],
                            }),
                          t.jsx(M, {
                            type: "button",
                            variant: "outline",
                            size: "sm",
                            onClick: () => {
                              const e = Number(pe);
                              if (!(e > 0) || !i.w) {
                                j.error("Enter a number above 0");
                                return;
                              }
                              const s =
                                k === "%"
                                  ? (i.w * e) / 100
                                  : e *
                                    (k === "cm" ? 1 / 2.54 : 1) *
                                    (Number(xe) || 300);
                              Me(String(Math.max(1, Math.round(s))));
                            },
                            children: "Set width",
                          }),
                        ],
                      }),
                      !P &&
                        t.jsxs("div", {
                          className: "space-y-2",
                          children: [
                            t.jsxs("div", {
                              className: "space-y-1",
                              children: [
                                t.jsx(z, {
                                  className: "text-xs",
                                  children:
                                    "How the picture fits the width and height",
                                }),
                                t.jsxs(Ue, {
                                  value: $,
                                  onValueChange: (e) => {
                                    (Ye(e), u(null));
                                  },
                                  children: [
                                    t.jsx(Ie, {
                                      className: "w-40",
                                      "aria-label":
                                        "How the picture fits the size",
                                      children: t.jsx(De, {}),
                                    }),
                                    t.jsx(Ee, {
                                      children: St.map((e) =>
                                        t.jsx(
                                          $e,
                                          {
                                            value: e,
                                            children:
                                              e.charAt(0).toUpperCase() +
                                              e.slice(1),
                                          },
                                          e,
                                        ),
                                      ),
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            t.jsxs("p", {
                              className: "text-xs text-muted-foreground",
                              children: [
                                zt[$],
                                " With Inside or Outside the result may not be exactly the width and height you typed.",
                              ],
                            }),
                            $ === "contain" &&
                              t.jsxs("div", {
                                className: "space-y-2",
                                children: [
                                  t.jsx(_, {
                                    id: "rc-usepad",
                                    checked: B,
                                    onChange: (e) => {
                                      (qe(e), u(null));
                                    },
                                    label:
                                      "Fill the leftover space with a color",
                                    help: "Off leaves it see-through (white for JPEG).",
                                  }),
                                  B &&
                                    t.jsx(kt, {
                                      id: "rc-pad",
                                      form: { bgColor: te },
                                      onChange: (e) => {
                                        (Ve(e.bgColor), u(null));
                                      },
                                    }),
                                ],
                              }),
                          ],
                        }),
                      t.jsx(_, {
                        id: "rc-noenlarge",
                        checked: ee,
                        onChange: (e) => {
                          (Ge(e), u(null));
                        },
                        label: "Never make it bigger than the original",
                      }),
                      t.jsxs("fieldset", {
                        className: "space-y-2",
                        children: [
                          t.jsx("legend", {
                            className: "text-sm font-medium",
                            children: "Turn, mirror and color (optional)",
                          }),
                          t.jsxs("div", {
                            className: "flex flex-wrap items-center gap-4",
                            children: [
                              t.jsxs("div", {
                                className: "space-y-1",
                                children: [
                                  t.jsx(z, {
                                    className: "text-xs",
                                    children: "Rotate clockwise",
                                  }),
                                  t.jsxs(Ue, {
                                    value: U,
                                    onValueChange: tt,
                                    children: [
                                      t.jsx(Ie, {
                                        className: "w-32",
                                        "aria-label": "Rotate",
                                        children: t.jsx(De, {}),
                                      }),
                                      t.jsx(Ee, {
                                        children: ["0", "90", "180", "270"].map(
                                          (e) =>
                                            t.jsx(
                                              $e,
                                              {
                                                value: e,
                                                children:
                                                  e === "0"
                                                    ? "Not at all"
                                                    : `${e} degrees`,
                                              },
                                              e,
                                            ),
                                        ),
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                              t.jsx(_, {
                                id: "rc-flop",
                                checked: re,
                                onChange: (e) => {
                                  (ie(e), u(null));
                                },
                                label: "Mirror left to right",
                              }),
                              t.jsx(_, {
                                id: "rc-flip",
                                checked: ne,
                                onChange: (e) => {
                                  (ae(e), u(null));
                                },
                                label: "Mirror top to bottom",
                              }),
                              t.jsx(_, {
                                id: "rc-gray",
                                checked: oe,
                                onChange: (e) => {
                                  (ge(e), u(null));
                                },
                                label: "Black and white",
                              }),
                            ],
                          }),
                          U !== "0" &&
                            t.jsx("p", {
                              className: "text-xs text-muted-foreground",
                              children:
                                "The picture is turned first, so the width and height above are for the turned picture.",
                            }),
                        ],
                      }),
                      fe &&
                        t.jsxs("div", {
                          children: [
                            t.jsxs("p", {
                              className: "text-xs text-muted-foreground mb-1",
                              children: ["Preview at ", x, " x ", b, "px"],
                            }),
                            t.jsx("div", {
                              className:
                                "border rounded-lg overflow-hidden bg-muted/20 mx-auto",
                              style: { maxWidth: "400px" },
                              children: t.jsx("img", {
                                src: fe,
                                alt: "Resize preview",
                                className: "w-full h-auto block",
                              }),
                            }),
                          ],
                        }),
                    ],
                  })
                : t.jsxs("div", {
                    className: "space-y-2",
                    children: [
                      t.jsx("div", {
                        className: "flex gap-2 flex-wrap",
                        children: Ut.map((e) =>
                          t.jsx(
                            M,
                            {
                              size: "sm",
                              variant: ue === e.ratio ? "default" : "outline",
                              onClick: () => {
                                if (
                                  (Ze(e.ratio),
                                  u(null),
                                  m(null),
                                  e.ratio === null || i.w === 0)
                                ) {
                                  y(null);
                                  return;
                                }
                                const s = i.w,
                                  n = i.h,
                                  h = s / n > e.ratio ? e.ratio * n : s,
                                  r = s / n > e.ratio ? n : s / e.ratio;
                                y({
                                  x: (s - h) / 2 / s,
                                  y: (n - r) / 2 / n,
                                  w: h / s,
                                  h: r / n,
                                });
                              },
                              children: e.label,
                            },
                            e.label,
                          ),
                        ),
                      }),
                      i.w > 0 &&
                        (() => {
                          const e = d
                              ? {
                                  x: Math.round(d.x * i.w),
                                  y: Math.round(d.y * i.h),
                                  w:
                                    Math.round((d.x + d.w) * i.w) -
                                    Math.round(d.x * i.w),
                                  h:
                                    Math.round((d.y + d.h) * i.h) -
                                    Math.round(d.y * i.h),
                                }
                              : { x: 0, y: 0, w: i.w, h: i.h },
                            s = (n, h) => {
                              const r = Math.round(Number(h));
                              if (!Number.isFinite(r)) return;
                              const c = { ...e, [n]: r };
                              ((c.w = Math.max(1, Math.min(c.w, i.w))),
                                (c.h = Math.max(1, Math.min(c.h, i.h))),
                                (c.x = Math.max(0, Math.min(c.x, i.w - c.w))),
                                (c.y = Math.max(0, Math.min(c.y, i.h - c.h))),
                                y({
                                  x: c.x / i.w,
                                  y: c.y / i.h,
                                  w: c.w / i.w,
                                  h: c.h / i.h,
                                }),
                                u(null),
                                m(null));
                            };
                          return t.jsxs("div", {
                            className:
                              "grid grid-cols-2 sm:grid-cols-5 gap-2 text-sm items-end",
                            children: [
                              ["x", "y", "w", "h"].map((n) =>
                                t.jsxs(
                                  "label",
                                  {
                                    className: "text-xs",
                                    children: [
                                      {
                                        x: "X (px from left)",
                                        y: "Y (px from top)",
                                        w: "Width (px)",
                                        h: "Height (px)",
                                      }[n],
                                      t.jsx("input", {
                                        type: "number",
                                        min: 0,
                                        className:
                                          "border rounded px-2 py-1 w-full bg-background text-sm",
                                        value: e[n],
                                        onChange: (h) => s(n, h.target.value),
                                      }),
                                    ],
                                  },
                                  n,
                                ),
                              ),
                              t.jsxs("label", {
                                className: "text-xs",
                                children: [
                                  "Then scale to width (px, optional)",
                                  t.jsx("input", {
                                    type: "number",
                                    min: 1,
                                    placeholder: "same",
                                    className:
                                      "border rounded px-2 py-1 w-full bg-background text-sm",
                                    value: je,
                                    onChange: (n) => {
                                      (Ke(n.target.value), u(null), m(null));
                                    },
                                  }),
                                ],
                              }),
                            ],
                          });
                        })(),
                      be &&
                        t.jsxs("div", {
                          ref: ve,
                          onMouseDown: at,
                          onMouseMove: rt,
                          onMouseUp: Z,
                          onMouseLeave: Z,
                          onTouchStart: it,
                          onTouchMove: ot,
                          onTouchEnd: Z,
                          onTouchCancel: Z,
                          className:
                            "relative border rounded-lg overflow-hidden bg-white mx-auto",
                          style: {
                            maxWidth: "500px",
                            cursor: "crosshair",
                            touchAction: "none",
                          },
                          children: [
                            t.jsx("img", {
                              src: be,
                              alt: "Preview",
                              className:
                                "w-full h-auto block pointer-events-none select-none",
                            }),
                            L &&
                              t.jsx("div", {
                                onMouseDown: (e) => {
                                  d && (e.stopPropagation(), J("move", q(e)));
                                },
                                onTouchStart: (e) => {
                                  if (d && e.touches.length > 0) {
                                    e.stopPropagation();
                                    const s = e.touches[0];
                                    J("move", A(s.clientX, s.clientY));
                                  }
                                },
                                className: `absolute border-2 border-primary bg-primary/20 ${d ? "cursor-move" : "pointer-events-none"}`,
                                style: {
                                  left: `${L.x * 100}%`,
                                  top: `${L.y * 100}%`,
                                  width: `${L.w * 100}%`,
                                  height: `${L.h * 100}%`,
                                  touchAction: "none",
                                },
                                children:
                                  d &&
                                  ["nw", "ne", "sw", "se"].map((e) =>
                                    t.jsx(
                                      "div",
                                      {
                                        onMouseDown: (s) => {
                                          (s.stopPropagation(), J(e, q(s)));
                                        },
                                        onTouchStart: (s) => {
                                          if (
                                            (s.stopPropagation(),
                                            s.touches.length === 0)
                                          )
                                            return;
                                          const n = s.touches[0];
                                          J(e, A(n.clientX, n.clientY));
                                        },
                                        className:
                                          "absolute h-6 w-6 -m-3 flex items-center justify-center",
                                        style: {
                                          top: e.includes("n") ? 0 : "100%",
                                          left: e.includes("w") ? 0 : "100%",
                                          cursor:
                                            e === "nw" || e === "se"
                                              ? "nwse-resize"
                                              : "nesw-resize",
                                          touchAction: "none",
                                        },
                                        children: t.jsx("div", {
                                          className:
                                            "h-3.5 w-3.5 rounded-full bg-primary border-2 border-white shadow",
                                        }),
                                      },
                                      e,
                                    ),
                                  ),
                              }),
                          ],
                        }),
                      t.jsx("p", {
                        className: "text-xs text-muted-foreground",
                        children: d
                          ? "Drag a corner to resize, drag inside the box to move it, or draw a new selection elsewhere."
                          : "Drag on the image to select the area to keep.",
                      }),
                    ],
                  }),
              l === "crop" &&
                we &&
                t.jsxs("div", {
                  children: [
                    t.jsx("p", {
                      className: "text-xs text-muted-foreground mb-1",
                      children: "Cropped result — this is what you'll get",
                    }),
                    t.jsx("div", {
                      className:
                        "border rounded-lg overflow-hidden bg-muted/20 mx-auto",
                      style: { maxWidth: "400px" },
                      children: t.jsx("img", {
                        src: we,
                        alt: "Cropped result preview",
                        className: "w-full h-auto block",
                      }),
                    }),
                  ],
                }),
              t.jsx("div", {
                className: "flex gap-3",
                children: Je
                  ? t.jsx(xt, {})
                  : C
                    ? t.jsxs(t.Fragment, {
                        children: [
                          t.jsx(gt, { blob: C, fileName: ct() }),
                          l === "crop" &&
                            t.jsx(M, {
                              variant: "outline",
                              onClick: () => {
                                const e = new File([C], o.name, {
                                  type: C.type,
                                });
                                (v(e),
                                  ye(URL.createObjectURL(C)),
                                  O(null),
                                  u(null),
                                  m(null),
                                  y(null),
                                  se("0"),
                                  ae(!1),
                                  ie(!1),
                                  Q("resize"));
                                const s = new Image();
                                ((s.onload = () => {
                                  (le({
                                    w: s.naturalWidth,
                                    h: s.naturalHeight,
                                  }),
                                    T(String(s.naturalWidth)),
                                    F(String(s.naturalHeight)));
                                }),
                                  (s.src = URL.createObjectURL(C)));
                              },
                              children: "Resize this crop",
                            }),
                          t.jsx(M, {
                            variant: "outline",
                            onClick: () => {
                              (v(null), u(null), m(null), y(null));
                            },
                            children: "New",
                          }),
                        ],
                      })
                    : t.jsxs(t.Fragment, {
                        children: [
                          t.jsx(M, {
                            onClick: l === "resize" ? st : nt,
                            disabled:
                              (l === "crop" && !d) ||
                              (l === "resize" && (D || ke)),
                            children:
                              l === "resize" ? "Resize Image" : "Apply Crop",
                          }),
                          t.jsx(M, {
                            variant: "outline",
                            onClick: () => v(null),
                            children: "Reset",
                          }),
                        ],
                      }),
              }),
            ],
          })
        : t.jsx(pt, {
            gateAtDownload: !0,
            accept: "image/*",
            onFiles: Qe,
            label: "Drop an image to resize or crop",
            description:
              "Resize to exact dimensions, or crop to a selected area",
          }),
      t.jsx(ft, { whatIsIt: me.what, howToUse: me.how, tip: me.tip }),
    ],
  });
}
export { js as default };
//# sourceMappingURL=ResizeCrop-CdC5XPx7.js.map
