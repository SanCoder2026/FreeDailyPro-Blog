const q = [
    {
      id: "png",
      mime: "image/png",
      ext: "png",
      label: "PNG",
      alpha: !0,
      lossy: !1,
      hint: "Sharp edges and see-through backgrounds. Best for logos, icons and screenshots.",
    },
    {
      id: "jpeg",
      mime: "image/jpeg",
      ext: "jpg",
      label: "JPEG",
      alpha: !1,
      lossy: !0,
      hint: "Small files for photos. No see-through background, so a fill colour is used.",
    },
    {
      id: "webp",
      mime: "image/webp",
      ext: "webp",
      label: "WebP",
      alpha: !0,
      lossy: !0,
      hint: "Smaller than JPEG or PNG at similar looks. Accepted by most websites.",
    },
    {
      id: "avif",
      mime: "image/avif",
      ext: "avif",
      label: "AVIF",
      alpha: !0,
      lossy: !0,
      hint: "Smallest files of all. Newer, so some older programs cannot open it.",
    },
    {
      id: "gif",
      mime: "image/gif",
      ext: "gif",
      label: "GIF",
      alpha: !0,
      lossy: !1,
      hint: "Limited to 256 colours. Fine for simple graphics.",
    },
    {
      id: "bmp",
      mime: "image/bmp",
      ext: "bmp",
      label: "BMP",
      alpha: !1,
      lossy: !1,
      hint: "Plain uncompressed picture for old programs. Files are large.",
    },
    {
      id: "ico",
      mime: "image/x-icon",
      ext: "ico",
      label: "ICO",
      alpha: !0,
      lossy: !1,
      hint: "Website and Windows icon with several sizes packed into one file.",
    },
    {
      id: "tiff",
      mime: "image/tiff",
      ext: "tiff",
      label: "TIFF",
      alpha: !0,
      lossy: !1,
      hint: "Uncompressed print and archive format. Files are large.",
    },
  ],
  j = q.map((e) => e.id);
function K(e) {
  return q.find((t) => t.id === e);
}
const T = {
  png: "png",
  jpeg: "jpeg",
  jpg: "jpeg",
  jpe: "jpeg",
  jfif: "jpeg",
  webp: "webp",
  avif: "avif",
  gif: "gif",
  tiff: "tiff",
  tif: "tiff",
  bmp: "bmp",
  ico: "ico",
  icon: "ico",
};
function B(e) {
  if (typeof e != "string") return null;
  let t = e.trim().toLowerCase().replace(/^\./, "");
  return (
    t.startsWith("image/") && (t = t.slice(6)),
    t === "x-icon" || t === "vnd.microsoft.icon"
      ? "ico"
      : t === "x-ms-bmp" || t === "x-bmp"
        ? "bmp"
        : t === "pjpeg"
          ? "jpeg"
          : (T[t] ?? null)
  );
}
const R =
    "aliceblue:f0f8ff,antiquewhite:faebd7,aqua:00ffff,aquamarine:7fffd4,azure:f0ffff,beige:f5f5dc,bisque:ffe4c4,black:000000,blanchedalmond:ffebcd,blue:0000ff,blueviolet:8a2be2,brown:a52a2a,burlywood:deb887,cadetblue:5f9ea0,chartreuse:7fff00,chocolate:d2691e,coral:ff7f50,cornflowerblue:6495ed,cornsilk:fff8dc,crimson:dc143c,cyan:00ffff,darkblue:00008b,darkcyan:008b8b,darkgoldenrod:b8860b,darkgray:a9a9a9,darkgreen:006400,darkgrey:a9a9a9,darkkhaki:bdb76b,darkmagenta:8b008b,darkolivegreen:556b2f,darkorange:ff8c00,darkorchid:9932cc,darkred:8b0000,darksalmon:e9967a,darkseagreen:8fbc8f,darkslateblue:483d8b,darkslategray:2f4f4f,darkslategrey:2f4f4f,darkturquoise:00ced1,darkviolet:9400d3,deeppink:ff1493,deepskyblue:00bfff,dimgray:696969,dimgrey:696969,dodgerblue:1e90ff,firebrick:b22222,floralwhite:fffaf0,forestgreen:228b22,fuchsia:ff00ff,gainsboro:dcdcdc,ghostwhite:f8f8ff,gold:ffd700,goldenrod:daa520,gray:808080,green:008000,greenyellow:adff2f,grey:808080,honeydew:f0fff0,hotpink:ff69b4,indianred:cd5c5c,indigo:4b0082,ivory:fffff0,khaki:f0e68c,lavender:e6e6fa,lavenderblush:fff0f5,lawngreen:7cfc00,lemonchiffon:fffacd,lightblue:add8e6,lightcoral:f08080,lightcyan:e0ffff,lightgoldenrodyellow:fafad2,lightgray:d3d3d3,lightgreen:90ee90,lightgrey:d3d3d3,lightpink:ffb6c1,lightsalmon:ffa07a,lightseagreen:20b2aa,lightskyblue:87cefa,lightslategray:778899,lightslategrey:778899,lightsteelblue:b0c4de,lightyellow:ffffe0,lime:00ff00,limegreen:32cd32,linen:faf0e6,magenta:ff00ff,maroon:800000,mediumaquamarine:66cdaa,mediumblue:0000cd,mediumorchid:ba55d3,mediumpurple:9370db,mediumseagreen:3cb371,mediumslateblue:7b68ee,mediumspringgreen:00fa9a,mediumturquoise:48d1cc,mediumvioletred:c71585,midnightblue:191970,mintcream:f5fffa,mistyrose:ffe4e1,moccasin:ffe4b5,navajowhite:ffdead,navy:000080,oldlace:fdf5e6,olive:808000,olivedrab:6b8e23,orange:ffa500,orangered:ff4500,orchid:da70d6,palegoldenrod:eee8aa,palegreen:98fb98,paleturquoise:afeeee,palevioletred:db7093,papayawhip:ffefd5,peachpuff:ffdab9,peru:cd853f,pink:ffc0cb,plum:dda0dd,powderblue:b0e0e6,purple:800080,rebeccapurple:663399,red:ff0000,rosybrown:bc8f8f,royalblue:4169e1,saddlebrown:8b4513,salmon:fa8072,sandybrown:f4a460,seagreen:2e8b57,seashell:fff5ee,sienna:a0522d,silver:c0c0c0,skyblue:87ceeb,slateblue:6a5acd,slategray:708090,slategrey:708090,snow:fffafa,springgreen:00ff7f,steelblue:4682b4,tan:d2b48c,teal:008080,thistle:d8bfd8,tomato:ff6347,turquoise:40e0d0,violet:ee82ee,wheat:f5deb3,white:ffffff,whitesmoke:f5f5f5,yellow:ffff00,yellowgreen:9acd32",
  V = Object.fromEntries(R.split(",").map((e) => e.split(":"))),
  _ =
    "Use a hex value such as #ffffff, ffffff or #fff (8 digits add transparency), or a CSS colour name such as white.";
function G(e) {
  if (typeof e != "string") return null;
  const t = e.trim().replace(/^%23/i, "#");
  if (!t) return null;
  if (/^#?([0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(t)) {
    let r = t.replace(/^#/, "");
    r.length <= 4 &&
      (r = r
        .split("")
        .map((a) => a + a)
        .join(""));
    const u = (a) => parseInt(r.slice(a, a + 2), 16);
    return { r: u(0), g: u(2), b: u(4), a: r.length === 8 ? u(6) / 255 : 1 };
  }
  const s = t.toLowerCase();
  if (s === "transparent") return { r: 0, g: 0, b: 0, a: 0 };
  const i = V[s];
  return i
    ? {
        r: parseInt(i.slice(0, 2), 16),
        g: parseInt(i.slice(2, 4), 16),
        b: parseInt(i.slice(4, 6), 16),
        a: 1,
      }
    : null;
}
function H(e) {
  const t = (s) =>
    Math.round(Math.min(255, Math.max(0, s)))
      .toString(16)
      .padStart(2, "0");
  return `#${t(e.r)}${t(e.g)}${t(e.b)}`;
}
const v = ["cover", "contain", "fill", "inside", "outside"],
  P = [16, 32, 48, 64, 128, 256],
  E = 16384,
  I = (e) => e == null || (typeof e == "string" && e.trim() === "");
function J(e) {
  const t =
    typeof e == "number"
      ? e
      : typeof e == "string" && e.trim() !== ""
        ? Number(e)
        : NaN;
  return !Number.isFinite(t) || t < 0 || t > 100
    ? null
    : t <= 1
      ? Math.max(1, Math.round(t * 100))
      : Math.round(t);
}
function D(e) {
  if (typeof e == "boolean") return e;
  if (typeof e == "number") return e === 1 ? !0 : e === 0 ? !1 : null;
  if (typeof e == "string") {
    const t = e.trim().toLowerCase();
    if (["true", "1", "yes", "on"].includes(t)) return !0;
    if (["false", "0", "no", "off"].includes(t)) return !1;
  }
  return null;
}
function S(e) {
  const t =
    typeof e == "number"
      ? e
      : typeof e == "string" && e.trim() !== ""
        ? Number(e)
        : NaN;
  return Number.isFinite(t) ? t : null;
}
function Q(e) {
  const t = Array.isArray(e)
    ? e
    : typeof e == "string"
      ? e.split(/[\s,;x]+/).filter(Boolean)
      : typeof e == "number"
        ? [e]
        : [];
  if (!t.length) return null;
  const s = new Set();
  for (const i of t) {
    const r = S(i);
    if (r === null || !P.includes(r)) return null;
    s.add(r);
  }
  return Array.from(s).sort((i, r) => i - r);
}
function W(e) {
  const t = (n) => ({ ok: !1, error: n }),
    s = B(e.format);
  if (!s)
    return t(
      `'format' must be one of ${j.join(", ")} (an image/... type such as image/webp also works).`,
    );
  const i = {
      format: s,
      fit: "inside",
      withoutEnlargement: !1,
      autoOrient: !0,
      stripMetadata: !0,
      grayscale: !1,
      rotate: 0,
      flip: !1,
      flop: !1,
      sizes: [16, 32, 48],
      bitDepth: 24,
      tiffCompression: "lzw",
      animated: !0,
    },
    r = (n, d) => {
      const c = e[n];
      if (I(c)) return null;
      const b = D(c);
      return b === null ? `'${n}' must be true or false.` : (d(b), null);
    },
    u = (n, d, c, b) => {
      const h = e[n];
      if (I(h)) return null;
      const f = S(h);
      return f === null || !Number.isInteger(f) || f < d || f > c
        ? `'${n}' must be a whole number from ${d} to ${c}.`
        : (b(f), null);
    };
  if (!I(e.quality)) {
    const n = J(e.quality);
    if (n === null)
      return t(
        "'quality' must be between 0 and 1 (for example 0.8) or between 1 and 100 (for example 80).",
      );
    i.quality = n;
  }
  const a = e.backgroundColor ?? e.background;
  if (!I(a)) {
    const n = G(a);
    if (!n) return t(`'backgroundColor' "${String(a)}" is not a colour. ${_}`);
    i.backgroundColor = n;
  }
  const p = [
      r("lossless", (n) => (i.lossless = n)),
      r("progressive", (n) => (i.progressive = n)),
      r("pngPalette", (n) => (i.pngPalette = n)),
      r("withoutEnlargement", (n) => (i.withoutEnlargement = n)),
      r("autoOrient", (n) => (i.autoOrient = n)),
      r("stripMetadata", (n) => (i.stripMetadata = n)),
      r("grayscale", (n) => (i.grayscale = n)),
      r("flip", (n) => (i.flip = n)),
      r("flop", (n) => (i.flop = n)),
      r("animated", (n) => (i.animated = n)),
      u("pngCompressionLevel", 0, 9, (n) => (i.pngCompressionLevel = n)),
      u("width", 1, E, (n) => (i.width = n)),
      u("height", 1, E, (n) => (i.height = n)),
      u("dpi", 1, 2400, (n) => (i.dpi = n)),
    ],
    m = e.effort ?? e.speed;
  if (!I(m)) {
    const n = S(m);
    n === null || !Number.isInteger(n) || n < 0 || n > 10
      ? p.push(
          "'effort' must be a whole number from 0 (fastest) to 10 (smallest file). 'speed' is accepted as the same setting.",
        )
      : (i.effort = n);
  }
  const g = p.find((n) => n);
  if (g) return t(g);
  if (!I(e.chromaSubsampling)) {
    const n = String(e.chromaSubsampling).trim();
    if (n !== "4:4:4" && n !== "4:2:0")
      return t(
        "'chromaSubsampling' must be 4:4:4 (sharpest colour edges) or 4:2:0 (smaller file).",
      );
    i.chromaSubsampling = n;
  }
  if (!I(e.fit)) {
    const n = String(e.fit).trim().toLowerCase();
    if (!v.includes(n)) return t(`'fit' must be one of ${v.join(", ")}.`);
    i.fit = n;
  }
  if (!I(e.rotate)) {
    const n = S(e.rotate);
    if (n === null || !Number.isInteger(n) || n % 90 !== 0)
      return t(
        "'rotate' must be a multiple of 90 degrees (90, 180, 270, or -90).",
      );
    i.rotate = ((n % 360) + 360) % 360;
  }
  for (const n of ["sharpen", "blur"]) {
    const d = e[n];
    if (I(d)) continue;
    const c = D(d);
    if (c === !1) continue;
    const b = c === !0 ? (n === "blur" ? 2 : 1) : S(d);
    if (b === null || b < 0.3 || b > 100)
      return t(
        `'${n}' must be true, or an amount (sigma) between 0.3 and 100.`,
      );
    i[n] = b;
  }
  if (!I(e.sizes)) {
    const n = Q(e.sizes);
    if (!n)
      return t(
        `'sizes' must list ICO sizes from ${P.join(", ")}, for example "16,32,48".`,
      );
    i.sizes = n;
  }
  if (!I(e.bitDepth)) {
    const n = S(e.bitDepth);
    if (n !== 24 && n !== 32)
      return t(
        "'bitDepth' must be 24 (BMP without transparency) or 32 (BMP with transparency).",
      );
    i.bitDepth = n;
  }
  if (!I(e.tiffCompression ?? e.compression)) {
    const n = String(e.tiffCompression ?? e.compression)
      .trim()
      .toLowerCase();
    if (!["none", "lzw", "deflate", "jpeg"].includes(n))
      return t("'tiffCompression' must be none, lzw, deflate or jpeg.");
    i.tiffCompression = n;
  }
  return { ok: !0, options: i };
}
function ee(e, t, s, i, r, u = !1) {
  const a = (f, o) => ({
    outW: f,
    outH: o,
    sx: 0,
    sy: 0,
    sw: e,
    sh: t,
    dx: 0,
    dy: 0,
    dw: f,
    dh: o,
  });
  if (!s && !i) return a(e, t);
  const p = (f) => Math.max(1, Math.round(f));
  if (!s || !i) {
    let f = s ? s / e : i / t;
    return (u && (f = Math.min(1, f)), a(p(e * f), p(t * f)));
  }
  let m = s,
    g = i;
  if (r === "fill")
    return (u && ((m = Math.min(m, e)), (g = Math.min(g, t))), a(m, g));
  const n = Math.min(m / e, g / t),
    d = Math.max(m / e, g / t);
  if (r === "inside" || r === "outside") {
    let f = r === "inside" ? n : d;
    return (u && (f = Math.min(1, f)), a(p(e * f), p(t * f)));
  }
  if (r === "contain") {
    let f = n;
    u && f > 1 && ((f = 1), (m = e), (g = t));
    const o = p(e * f),
      l = p(t * f);
    return {
      outW: m,
      outH: g,
      sx: 0,
      sy: 0,
      sw: e,
      sh: t,
      dx: Math.round((m - o) / 2),
      dy: Math.round((g - l) / 2),
      dw: o,
      dh: l,
    };
  }
  let c = d;
  u && c > 1 && ((c = 1), (m = Math.min(m, e)), (g = Math.min(g, t)));
  const b = Math.min(e, m / c),
    h = Math.min(t, g / c);
  return {
    outW: m,
    outH: g,
    sx: (e - b) / 2,
    sy: (t - h) / 2,
    sw: b,
    sh: h,
    dx: 0,
    dy: 0,
    dw: m,
    dh: g,
  };
}
function C(e, t, s) {
  if (!Number.isInteger(t) || !Number.isInteger(s) || t < 1 || s < 1)
    throw new Error("The image has no size.");
  if (e.length < t * s * 4)
    throw new Error("Pixel data is shorter than the image size.");
}
function N(e, t, s, i, r) {
  if (i >= 255) return [e, t, s];
  const u = i / 255;
  return [
    Math.round(e * u + r.r * (1 - u)),
    Math.round(t * u + r.g * (1 - u)),
    Math.round(s * u + r.b * (1 - u)),
  ];
}
const F = { r: 255, g: 255, b: 255 };
function te(e, t, s, i = {}) {
  C(e, t, s);
  const r = i.bits ?? 24,
    u = i.background ?? F,
    a = Math.round(((i.dpi ?? 72) * 1e3) / 25.4),
    p = r === 32 ? 108 : 40,
    m = r === 32 ? t * 4 : Math.ceil((t * 3) / 4) * 4,
    g = m * s,
    n = 14 + p,
    d = new Uint8Array(n + g),
    c = new DataView(d.buffer);
  ((d[0] = 66),
    (d[1] = 77),
    c.setUint32(2, d.length, !0),
    c.setUint32(10, n, !0),
    c.setUint32(14, p, !0),
    c.setInt32(18, t, !0),
    c.setInt32(22, s, !0),
    c.setUint16(26, 1, !0),
    c.setUint16(28, r, !0),
    c.setUint32(30, r === 32 ? 3 : 0, !0),
    c.setUint32(34, g, !0),
    c.setInt32(38, a, !0),
    c.setInt32(42, a, !0),
    r === 32 &&
      (c.setUint32(54, 16711680, !0),
      c.setUint32(58, 65280, !0),
      c.setUint32(62, 255, !0),
      c.setUint32(66, 4278190080, !0),
      c.setUint32(70, 1934772034, !0)));
  for (let b = 0; b < s; b++) {
    let h = n + (s - 1 - b) * m;
    for (let f = 0; f < t; f++) {
      const o = (b * t + f) * 4;
      if (r === 32)
        ((d[h++] = e[o + 2]),
          (d[h++] = e[o + 1]),
          (d[h++] = e[o]),
          (d[h++] = e[o + 3]));
      else {
        const [l, k, y] = N(e[o], e[o + 1], e[o + 2], e[o + 3], u);
        ((d[h++] = y), (d[h++] = k), (d[h++] = l));
      }
    }
  }
  return d;
}
function ne(e) {
  if (!e.length) throw new Error("An icon needs at least one size.");
  const t = 6 + e.length * 16,
    s = t + e.reduce((a, p) => a + p.png.length, 0),
    i = new Uint8Array(s),
    r = new DataView(i.buffer);
  (r.setUint16(2, 1, !0), r.setUint16(4, e.length, !0));
  let u = t;
  return (
    e.forEach((a, p) => {
      const m = 6 + p * 16;
      ((i[m] = a.size >= 256 ? 0 : a.size),
        (i[m + 1] = a.size >= 256 ? 0 : a.size),
        r.setUint16(m + 4, 1, !0),
        r.setUint16(m + 6, 32, !0),
        r.setUint32(m + 8, a.png.length, !0),
        r.setUint32(m + 12, u, !0),
        i.set(a.png, u),
        (u += a.png.length));
    }),
    i
  );
}
function ie(e, t, s, i = {}) {
  C(e, t, s);
  const r = i.alpha ? 4 : 3,
    u = i.background ?? F,
    a = i.dpi ?? 72,
    p = i.alpha ? 13 : 12,
    g = 8 + (2 + p * 12 + 4),
    n = g + r * 2,
    d = n + 16,
    c = t * s * r,
    b = new Uint8Array(d + c),
    h = new DataView(b.buffer);
  ((b[0] = 73), (b[1] = 73), h.setUint16(2, 42, !0), h.setUint32(4, 8, !0));
  let f = 8;
  (h.setUint16(f, p, !0), (f += 2));
  const o = (k, y, w, M) => {
    (h.setUint16(f, k, !0),
      h.setUint16(f + 2, y, !0),
      h.setUint32(f + 4, w, !0),
      y === 3 && w === 1
        ? h.setUint16(f + 8, M, !0)
        : h.setUint32(f + 8, M, !0),
      (f += 12));
  };
  (o(256, 4, 1, t),
    o(257, 4, 1, s),
    o(258, 3, r, g),
    o(259, 3, 1, 1),
    o(262, 3, 1, 2),
    o(273, 4, 1, d),
    o(277, 3, 1, r),
    o(278, 4, 1, s),
    o(279, 4, 1, c),
    o(282, 5, 1, n),
    o(283, 5, 1, n + 8),
    o(296, 3, 1, 2),
    i.alpha && o(338, 3, 1, 2),
    h.setUint32(f, 0, !0));
  for (let k = 0; k < r; k++) h.setUint16(g + k * 2, 8, !0);
  (h.setUint32(n, a, !0),
    h.setUint32(n + 4, 1, !0),
    h.setUint32(n + 8, a, !0),
    h.setUint32(n + 12, 1, !0));
  let l = d;
  for (let k = 0; k < t * s; k++) {
    const y = k * 4;
    if (i.alpha)
      ((b[l++] = e[y]),
        (b[l++] = e[y + 1]),
        (b[l++] = e[y + 2]),
        (b[l++] = e[y + 3]));
    else {
      const [w, M, x] = N(e[y], e[y + 1], e[y + 2], e[y + 3], u);
      ((b[l++] = w), (b[l++] = M), (b[l++] = x));
    }
  }
  return b;
}
function X(e, t, s, i) {
  const r = new Map(),
    u = new Int32Array(t);
  for (let o = 0; o < t; o++) {
    if (!i(o)) {
      u[o] = -1;
      continue;
    }
    const l = e[o * 4],
      k = e[o * 4 + 1],
      y = e[o * 4 + 2],
      w = ((l >> 3) << 10) | ((k >> 3) << 5) | (y >> 3);
    u[o] = w;
    const M = r.get(w);
    M
      ? (M.n++, (M.r += l), (M.g += k), (M.b += y))
      : r.set(w, { n: 1, r: l, g: k, b: y });
  }
  const a = (o) => {
      const l = r.get(o);
      return [l.r / l.n, l.g / l.n, l.b / l.n];
    },
    p = [{ keys: Array.from(r.keys()) }],
    m = (o) => {
      let l = [255, 255, 255],
        k = [0, 0, 0];
      for (const M of o.keys) {
        const x = a(M);
        for (let U = 0; U < 3; U++)
          (x[U] < l[U] && (l[U] = x[U]), x[U] > k[U] && (k[U] = x[U]));
      }
      const y = [k[0] - l[0], k[1] - l[1], k[2] - l[2]],
        w = y[0] >= y[1] && y[0] >= y[2] ? 0 : y[1] >= y[2] ? 1 : 2;
      return { axis: w, span: y[w] };
    },
    g = (o) => o.keys.reduce((l, k) => l + r.get(k).n, 0);
  for (; p.length < s;) {
    let o = -1,
      l = 0,
      k = 0;
    if (
      (p.forEach((U, A) => {
        if (U.keys.length < 2) return;
        const { axis: $, span: L } = m(U),
          O = L * Math.sqrt(g(U));
        O > l && ((o = A), (l = O), (k = $));
      }),
      o < 0)
    )
      break;
    const y = p[o];
    y.keys.sort((U, A) => a(U)[k] - a(A)[k]);
    const w = g(y) / 2;
    let M = 0,
      x = 1;
    for (
      let U = 0;
      U < y.keys.length - 1 &&
      ((M += r.get(y.keys[U]).n), (x = U + 1), !(M >= w));
      U++
    );
    p.splice(o, 1, { keys: y.keys.slice(0, x) }, { keys: y.keys.slice(x) });
  }
  const n = p.map((o) => {
      let l = 0,
        k = 0,
        y = 0,
        w = 0;
      for (const M of o.keys) {
        const x = r.get(M);
        ((l += x.n), (k += x.r), (y += x.g), (w += x.b));
      }
      return l
        ? [Math.round(k / l), Math.round(y / l), Math.round(w / l)]
        : [0, 0, 0];
    }),
    d = new Map(),
    c = (o) => {
      let l = d.get(o);
      if (l !== void 0) return l;
      const k = a(o);
      let y = 1 / 0;
      l = 0;
      for (let w = 0; w < n.length; w++) {
        const M =
          (n[w][0] - k[0]) ** 2 + (n[w][1] - k[1]) ** 2 + (n[w][2] - k[2]) ** 2;
        M < y && ((y = M), (l = w));
      }
      return (d.set(o, l), l);
    },
    b = -1,
    h = new Uint8Array(t);
  let f = !1;
  for (let o = 0; o < t; o++)
    u[o] < 0 ? ((f = !0), (h[o] = 255)) : (h[o] = c(u[o]));
  if (f) {
    const o = n.length;
    n.push([0, 0, 0]);
    for (let l = 0; l < t; l++) u[l] < 0 && (h[l] = o);
    return { palette: n, indices: h, transparentIndex: o };
  }
  return { palette: n, indices: h, transparentIndex: b };
}
function Y(e, t) {
  const s = 1 << t,
    i = s + 1,
    r = [];
  let u = 0,
    a = 0,
    p = t + 1,
    m = i + 1,
    g = new Map();
  const n = (c) => {
    for (u |= c << a, a += p; a >= 8;) (r.push(u & 255), (u >>>= 8), (a -= 8));
  };
  n(s);
  let d = e[0];
  for (let c = 1; c < e.length; c++) {
    const b = e[c],
      h = (d << 8) | b,
      f = g.get(h);
    f === void 0
      ? (n(d),
        m === 4096
          ? (n(s), (g = new Map()), (m = i + 1), (p = t + 1))
          : (m >= 1 << p && p++, g.set(h, m++)),
        (d = b))
      : (d = f);
  }
  return (n(d), n(i), a > 0 && r.push(u & 255), r);
}
function re(e, t, s, i = {}) {
  C(e, t, s);
  const r = t * s,
    u = i.background,
    a = u ? new Uint8Array(r * 4) : e;
  if (u)
    for (let f = 0; f < r; f++) {
      const [o, l, k] = N(
        e[f * 4],
        e[f * 4 + 1],
        e[f * 4 + 2],
        e[f * 4 + 3],
        u,
      );
      ((a[f * 4] = o),
        (a[f * 4 + 1] = l),
        (a[f * 4 + 2] = k),
        (a[f * 4 + 3] = 255));
    }
  const {
    palette: p,
    indices: m,
    transparentIndex: g,
  } = X(a, r, 255, (f) => a[f * 4 + 3] >= 128);
  let n = 1;
  for (; 1 << n < p.length;) n++;
  const d = 1 << n,
    c = Math.max(2, n),
    b = Y(m, c),
    h = [
      71,
      73,
      70,
      56,
      57,
      97,
      t & 255,
      t >> 8,
      s & 255,
      s >> 8,
      240 | (n - 1),
      0,
      0,
    ];
  for (let f = 0; f < d; f++) h.push(...(p[f] ?? [0, 0, 0]));
  (g >= 0 && h.push(33, 249, 4, 1, 0, 0, g, 0),
    h.push(44, 0, 0, 0, 0, t & 255, t >> 8, s & 255, s >> 8, 0, c));
  for (let f = 0; f < b.length; f += 255) {
    const o = b.slice(f, f + 255);
    h.push(o.length, ...o);
  }
  return (h.push(0, 59), Uint8Array.from(h));
}
let z = null;
function Z(e) {
  if (!z) {
    z = new Uint32Array(256);
    for (let s = 0; s < 256; s++) {
      let i = s;
      for (let r = 0; r < 8; r++) i = i & 1 ? 3988292384 ^ (i >>> 1) : i >>> 1;
      z[s] = i >>> 0;
    }
  }
  let t = 4294967295;
  for (let s = 0; s < e.length; s++) t = z[(t ^ e[s]) & 255] ^ (t >>> 8);
  return (t ^ 4294967295) >>> 0;
}
function se(e, t) {
  const s = [137, 80, 78, 71, 13, 10, 26, 10];
  if (e.length < 33 || s.some((d, c) => e[c] !== d)) return e;
  const i = Math.round(t / 0.0254),
    r = new Uint8Array(21),
    u = new DataView(r.buffer);
  (u.setUint32(0, 9),
    r.set([112, 72, 89, 115], 4),
    u.setUint32(8, i),
    u.setUint32(12, i),
    (r[16] = 1),
    u.setUint32(17, Z(r.subarray(4, 17))));
  const a = [e.subarray(0, 8)];
  let p = 8,
    m = !1;
  for (; p + 8 <= e.length;) {
    const d = new DataView(e.buffer, e.byteOffset + p, 4).getUint32(0),
      c = String.fromCharCode(e[p + 4], e[p + 5], e[p + 6], e[p + 7]),
      b = p + 12 + d;
    (c !== "pHYs" && a.push(e.subarray(p, b)),
      c === "IHDR" && !m && (a.push(r), (m = !0)),
      (p = b));
  }
  const g = new Uint8Array(a.reduce((d, c) => d + c.length, 0));
  let n = 0;
  for (const d of a) (g.set(d, n), (n += d.length));
  return g;
}
function oe(e) {
  if (e.length < 4 || e[0] !== 255 || e[1] !== 216) return null;
  let t = 2;
  for (; t + 4 < e.length && e[t] === 255;) {
    const s = e[t + 1];
    if (s === 218 || s === 217) break;
    const i = (e[t + 2] << 8) | e[t + 3];
    if (
      s === 225 &&
      e[t + 4] === 69 &&
      e[t + 5] === 120 &&
      e[t + 6] === 105 &&
      e[t + 7] === 102
    )
      return e.slice(t, t + 2 + i);
    t += 2 + i;
  }
  return null;
}
function fe(e) {
  const t = new Uint8Array(e),
    s = 10;
  if (t.length < s + 8) return t;
  const i = t[s] === 73,
    r = new DataView(t.buffer),
    u = (m) => r.getUint16(m, i),
    a = s + r.getUint32(s + 4, i);
  if (a + 2 > t.length) return t;
  const p = u(a);
  for (let m = 0; m < p; m++) {
    const g = a + 2 + m * 12;
    if (g + 12 > t.length) break;
    if (u(g) === 274) {
      r.setUint16(g + 8, 1, i);
      break;
    }
  }
  return t;
}
function ae(e, t) {
  if (e.length < 4 || e[0] !== 255 || e[1] !== 216) return e;
  let s = 2;
  e[2] === 255 && e[3] === 224 && (s = 4 + ((e[4] << 8) | e[5]));
  const i = new Uint8Array(e.length + t.length);
  return (
    i.set(e.subarray(0, s), 0),
    i.set(t, s),
    i.set(e.subarray(s), s + t.length),
    i
  );
}
export {
  _ as COLOR_HELP,
  v as FIT_MODES,
  q as FORMATS,
  j as FORMAT_IDS,
  P as ICO_SIZES,
  E as MAX_DIMENSION,
  V as NAMED_COLORS,
  ee as computeFit,
  Z as crc32,
  te as encodeBmp,
  re as encodeGif,
  ne as encodeIco,
  ie as encodeTiff,
  oe as extractJpegExif,
  K as formatInfo,
  ae as insertJpegExif,
  J as normalizeQuality,
  G as parseColor,
  W as parseConvertOptions,
  B as parseFormat,
  Q as parseIcoSizes,
  X as quantize,
  fe as resetExifOrientation,
  H as rgbaToHex,
  se as setPngDpi,
};
//# sourceMappingURL=convertCore-pdjQ6UTb.js.map
