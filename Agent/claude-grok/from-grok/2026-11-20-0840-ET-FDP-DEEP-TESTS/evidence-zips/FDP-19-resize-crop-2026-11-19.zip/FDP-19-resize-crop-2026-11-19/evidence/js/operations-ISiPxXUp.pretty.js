import { g as tt, w as nt } from "./utils-BCX55KBw.js";
import { a as k, f as et, c as ot } from "./decode-D7I8Qajh.js";
function at(t) {
  const e = new Array(256).fill(0);
  for (let s = 0; s < t.length; s++) e[t[s]]++;
  const a = t.length;
  let n = 0;
  for (let s = 0; s < 256; s++) n += s * e[s];
  let o = 0,
    r = 0,
    i = 0,
    h = 128;
  for (let s = 0; s < 256; s++) {
    if (((r += e[s]), !r)) continue;
    const c = a - r;
    if (!c) break;
    o += s * e[s];
    const u = o / r,
      l = (n - o) / c,
      f = r * c * (u - l) ** 2;
    f > i && ((i = f), (h = s));
  }
  return h;
}
function Z(t, e, a, n) {
  const o = new Float32Array(e * a),
    r = new Uint8Array(e * a);
  for (let i = 0; i < a; i++) {
    let h = 0,
      s = 0;
    for (let c = -n; c < e; c++) {
      const u = c + n,
        l = c - n - 1;
      (u < e && ((h += t[i * e + u]), s++),
        l >= 0 && ((h -= t[i * e + l]), s--),
        c >= 0 && (o[i * e + c] = h / s));
    }
  }
  for (let i = 0; i < e; i++) {
    let h = 0,
      s = 0;
    for (let c = -n; c < a; c++) {
      const u = c + n,
        l = c - n - 1;
      (u < a && ((h += o[u * e + i]), s++),
        l >= 0 && ((h -= o[l * e + i]), s--),
        c >= 0 && (r[c * e + i] = h / s));
    }
  }
  return r;
}
function wt(t, e = 320) {
  const a = Math.min(1, e / Math.max(t.width, t.height)),
    n = Math.max(8, Math.round(t.width * a)),
    o = Math.max(8, Math.round(t.height * a)),
    r = new Uint8Array(n * o);
  for (let g = 0; g < o; g++)
    for (let p = 0; p < n; p++) {
      const x = Math.min(t.width - 1, Math.floor(p / a)),
        R = (Math.min(t.height - 1, Math.floor(g / a)) * t.width + x) * 4;
      r[g * n + p] =
        0.299 * t.data[R] + 0.587 * t.data[R + 1] + 0.114 * t.data[R + 2];
    }
  const i = Z(r, n, o, Math.max(2, Math.round(Math.min(n, o) / 60))),
    h = at(i),
    s = new Uint8Array(n * o);
  for (let g = 0; g < s.length; g++) s[g] = i[g] > h ? 1 : 0;
  const c = new Int32Array(n * o);
  let u = 0,
    l = 0,
    f = 0;
  const m = [];
  for (let g = 0; g < s.length; g++) {
    if (!s[g] || c[g]) continue;
    f++;
    let p = 0;
    for (m.push(g), c[g] = f; m.length;) {
      const x = m.pop();
      p++;
      const E = x % n,
        R = (x - E) / n;
      (E > 0 && s[x - 1] && !c[x - 1] && ((c[x - 1] = f), m.push(x - 1)),
        E < n - 1 && s[x + 1] && !c[x + 1] && ((c[x + 1] = f), m.push(x + 1)),
        R > 0 && s[x - n] && !c[x - n] && ((c[x - n] = f), m.push(x - n)),
        R < o - 1 && s[x + n] && !c[x + n] && ((c[x + n] = f), m.push(x + n)));
    }
    p > l && ((l = p), (u = f));
  }
  const d = l / (n * o);
  if (d < 0.15 || d > 0.97) return null;
  let y = 1 / 0,
    M = -1 / 0,
    b = -1 / 0,
    C = 1 / 0,
    w = [0, 0],
    I = [0, 0],
    A = [0, 0],
    _ = [0, 0];
  for (let g = 0; g < c.length; g++) {
    if (c[g] !== u) continue;
    const p = g % n,
      x = (g - p) / n,
      E = p + x,
      R = p - x;
    (E < y && ((y = E), (w = [p, x])),
      E > M && ((M = E), (I = [p, x])),
      R > b && ((b = R), (A = [p, x])),
      R < C && ((C = R), (_ = [p, x])));
  }
  const F = (g) => ({
    x: Math.min(t.width, (g[0] + 0.5) / a),
    y: Math.min(t.height, (g[1] + 0.5) / a),
  });
  return { topLeft: F(w), topRight: F(A), bottomRight: F(I), bottomLeft: F(_) };
}
function pt(t, e = 24) {
  const { data: a, width: n, height: o } = t;
  if ($(a).lowContrast) return !1;
  const r = Math.ceil(n / e),
    i = Math.ceil(o / e),
    h = [0, 1, 2].map(() => new Uint8Array(r * i));
  for (let c = 0; c < i; c++)
    for (let u = 0; u < r; u++)
      for (let l = 0; l < 3; l++) {
        const f = [];
        for (let m = c * e; m < Math.min(o, (c + 1) * e); m += 2)
          for (let d = u * e; d < Math.min(n, (u + 1) * e); d += 2)
            f.push(a[(m * n + d) * 4 + l]);
        (f.sort((m, d) => m - d),
          (h[l][c * r + u] = f[Math.floor(f.length * 0.92)] ?? 255));
      }
  const s = h.map((c) => Z(c, r, i, 1));
  for (let c = 0; c < o; c++) {
    const u = Math.min(i - 1, Math.max(0, c / e - 0.5)),
      l = Math.floor(u),
      f = Math.min(i - 1, l + 1),
      m = u - l;
    for (let d = 0; d < n; d++) {
      const y = Math.min(r - 1, Math.max(0, d / e - 0.5)),
        M = Math.floor(y),
        b = Math.min(r - 1, M + 1),
        C = y - M,
        w = (c * n + d) * 4;
      for (let I = 0; I < 3; I++) {
        const A = s[I],
          _ =
            (A[l * r + M] * (1 - C) + A[l * r + b] * C) * (1 - m) +
            (A[f * r + M] * (1 - C) + A[f * r + b] * C) * m;
        a[w + I] = Math.min(255, (a[w + I] * 255) / Math.max(st, _));
      }
    }
  }
  return !0;
}
const st = 64,
  rt = 24,
  H = 170;
function $(t) {
  const e = new Array(256).fill(0);
  let a = 0;
  for (let i = 0; i < t.length; i += 4)
    (e[Math.round(0.299 * t[i] + 0.587 * t[i + 1] + 0.114 * t[i + 2])]++, a++);
  const n = (i) => {
      let h = 0;
      for (let s = 0; s < 256; s++) if (((h += e[s]), h >= i * a)) return s;
      return 255;
    },
    o = n(0.9),
    r = n(0.995) - n(0.005);
  return { paper: o, spread: r, lowContrast: r < rt, darkPage: o < 128 };
}
const B = (t) => (t < 0 ? 0 : t > 255 ? 255 : t);
function it(t, e, a) {
  const n = $(t),
    o = (259 * (e + 255)) / (255 * (259 - e)),
    r = !n.lowContrast && !n.darkPage,
    i = n.lowContrast ? 1 : o,
    h = Math.min(2.5, H / Math.max(1, n.paper));
  for (let s = 0; s < t.length; s += 4)
    if (a) {
      const c = 0.299 * t[s] + 0.587 * t[s + 1] + 0.114 * t[s + 2],
        u = r ? o * (c - 128) + 128 : i * (c - n.paper) + Math.max(n.paper, H);
      t[s] = t[s + 1] = t[s + 2] = B(u);
    } else
      r
        ? ((t[s] = B(o * (t[s] - 128) + 128)),
          (t[s + 1] = B(o * (t[s + 1] - 128) + 128)),
          (t[s + 2] = B(o * (t[s + 2] - 128) + 128)))
        : n.paper < H &&
          ((t[s] = B(t[s] * h)),
          (t[s + 1] = B(t[s + 1] * h)),
          (t[s + 2] = B(t[s + 2] * h)));
  return n;
}
const J = { a4: [595.28, 841.89], letter: [612, 792] };
function yt(t, e, a) {
  if (a === "fit")
    return {
      pageW: t * 0.48,
      pageH: e * 0.48,
      drawW: t * 0.48,
      drawH: e * 0.48,
    };
  const [n, o] = J[a],
    r = ht(t, e) === "landscape",
    i = r ? o : n,
    h = r ? n : o,
    s = 18,
    c = Math.min((i - s * 2) / t, (h - s * 2) / e);
  return { pageW: i, pageH: h, drawW: t * c, drawH: e * c };
}
function Mt(t) {
  const e = new DataView(t);
  if (e.byteLength < 4 || e.getUint16(0) !== 65496) return 1;
  let a = 2;
  for (; a + 4 <= e.byteLength;) {
    const n = e.getUint16(a);
    if (n === 65505) {
      const o = a + 4;
      if (o + 10 > e.byteLength || e.getUint32(o) !== 1165519206) return 1;
      const r = o + 6,
        i = e.getUint16(r) === 18761,
        h = r + e.getUint32(r + 4, i);
      if (h + 2 > e.byteLength) return 1;
      const s = e.getUint16(h, i);
      for (let c = 0; c < s; c++) {
        const u = h + 2 + c * 12;
        if (u + 10 > e.byteLength) return 1;
        if (e.getUint16(u, i) === 274) {
          const l = e.getUint16(u + 8, i);
          return l >= 1 && l <= 8 ? l : 1;
        }
      }
      return 1;
    }
    if ((n & 65280) !== 65280 || n === 65498) return 1;
    a += 2 + e.getUint16(a + 2);
  }
  return 1;
}
function It(t, e, a) {
  switch (t) {
    case 2:
      return { m: [-1, 0, 0, 1, e, 0], width: e, height: a };
    case 3:
      return { m: [-1, 0, 0, -1, e, a], width: e, height: a };
    case 4:
      return { m: [1, 0, 0, -1, 0, a], width: e, height: a };
    case 5:
      return { m: [0, 1, 1, 0, 0, 0], width: a, height: e };
    case 6:
      return { m: [0, 1, -1, 0, a, 0], width: a, height: e };
    case 7:
      return { m: [0, -1, -1, 0, a, e], width: a, height: e };
    case 8:
      return { m: [0, -1, 1, 0, 0, e], width: a, height: e };
    default:
      return { m: [1, 0, 0, 1, 0, 0], width: e, height: a };
  }
}
const ct = 600;
function bt(t, e) {
  return Math.min(t, e) < ct;
}
function Ct(t) {
  const e = (t || "").replace("_", "-").toLowerCase();
  return e === "en-us" || e === "en-ca" ? "letter" : "a4";
}
function ht(t, e) {
  return t > e ? "landscape" : "portrait";
}
function At(t) {
  let e = 0,
    a = 0;
  for (let n = 0; n < t.length; n += 4)
    ((e += 0.299 * t[n] + 0.587 * t[n + 1] + 0.114 * t[n + 2]), a++);
  return a > 0 && e / a < 30;
}
function Et(t, e, a) {
  const n = Math.max(0, Math.min(t.length - 1, e + a));
  if (e < 0 || e >= t.length || n === e) return t.slice();
  const o = t.slice(),
    [r] = o.splice(e, 1);
  return (o.splice(n, 0, r), o);
}
const q = { w: (85.6 / 25.4) * 72, h: (53.98 / 25.4) * 72 };
function Rt(t, e) {
  const o = t.slice(0, 2).map((l) => {
      const f = l.h > l.w,
        m = f ? q.h : q.w,
        d = f ? q.w : q.h,
        y = Math.min(m / Math.max(1, l.w), d / Math.max(1, l.h));
      return { width: l.w * y, height: l.h * y };
    }),
    r = o.reduce((l, f) => l + f.height, 0) + 24 * Math.max(0, o.length - 1),
    i = o.reduce((l, f) => Math.max(l, f.width), 0);
  let h, s;
  e === "fit" ? ((h = i + 72), (s = r + 72)) : ([h, s] = J[e]);
  let c = e === "fit" ? s - 36 : s - Math.max(36, (s - r) / 3);
  const u = o.map((l) => {
    c -= l.height;
    const f = { x: (h - l.width) / 2, y: c, width: l.width, height: l.height };
    return ((c -= 24), f);
  });
  return { pageW: h, pageH: s, boxes: u };
}
const Lt = {
    preset: "none",
    intensity: 100,
    brightness: 100,
    contrast: 100,
    saturation: 100,
  },
  V = (t) => (t < 0 ? 0 : t > 255 ? 255 : t);
function lt(t, e, a, n) {
  const o = Math.round(n);
  if (o < 1) return;
  const r = new Uint8ClampedArray(t.length),
    i = (h, s, c) => {
      const u = c ? e : a,
        l = c ? a : e,
        f = c ? 4 : e * 4,
        m = c ? e * 4 : 4,
        d = 2 * o + 1;
      for (let y = 0; y < l; y++) {
        const M = y * m;
        for (let b = 0; b < 4; b++) {
          let C = 0;
          for (let w = -o; w <= o; w++) {
            const I = Math.min(u - 1, Math.max(0, w));
            C += h[M + I * f + b];
          }
          for (let w = 0; w < u; w++) {
            s[M + w * f + b] = C / d;
            const I = Math.min(u - 1, Math.max(0, w - o)),
              A = Math.min(u - 1, Math.max(0, w + o + 1));
            C += h[M + A * f + b] - h[M + I * f + b];
          }
        }
      }
    };
  for (let h = 0; h < 2; h++) (i(t, r, !0), i(r, t, !1));
}
function ft(t, e, a, n) {
  const o = Math.max(0, Math.min(1, n.intensity / 100)),
    r = n.brightness / 100,
    i = n.contrast / 100,
    h = n.saturation / 100;
  if (
    (n.preset === "blur" &&
      lt(t, e, a, (n.intensity / 100) * 6 * (e / 1e3) + 0),
    n.preset === "grayscale" ||
      n.preset === "sepia" ||
      n.preset === "invert" ||
      r !== 1 ||
      i !== 1 ||
      h !== 1)
  )
    for (let u = 0; u < t.length; u += 4) {
      let l = t[u],
        f = t[u + 1],
        m = t[u + 2];
      if (n.preset === "grayscale") {
        const d = 0.2126 * l + 0.7152 * f + 0.0722 * m;
        ((l += (d - l) * o), (f += (d - f) * o), (m += (d - m) * o));
      } else if (n.preset === "sepia") {
        const d = 0.393 * l + 0.769 * f + 0.189 * m,
          y = 0.349 * l + 0.686 * f + 0.168 * m,
          M = 0.272 * l + 0.534 * f + 0.131 * m;
        ((l += (d - l) * o), (f += (y - f) * o), (m += (M - m) * o));
      } else
        n.preset === "invert" &&
          ((l += (255 - l - l) * o),
          (f += (255 - f - f) * o),
          (m += (255 - m - m) * o));
      if (
        (r !== 1 && ((l *= r), (f *= r), (m *= r)),
        i !== 1 &&
          ((l = (l - 127.5) * i + 127.5),
          (f = (f - 127.5) * i + 127.5),
          (m = (m - 127.5) * i + 127.5)),
        h !== 1)
      ) {
        const d = 0.2126 * l + 0.7152 * f + 0.0722 * m;
        ((l = d + (l - d) * h), (f = d + (f - d) * h), (m = d + (m - d) * h));
      }
      ((t[u] = V(l)), (t[u + 1] = V(f)), (t[u + 2] = V(m)));
    }
}
function ut(t, e, a) {
  const n = a ? Math.min(1, a / Math.max(t.width, t.height)) : 1,
    o = document.createElement("canvas");
  ((o.width = Math.max(1, Math.round(t.width * n))),
    (o.height = Math.max(1, Math.round(t.height * n))));
  const r = o.getContext("2d");
  r.drawImage(t, 0, 0, o.width, o.height);
  const i = r.getImageData(0, 0, o.width, o.height);
  return (ft(i.data, o.width, o.height, e), r.putImageData(i, 0, 0), o);
}
async function Dt(t, e, a = 0.92, n = "#ffffff") {
  const { canvas: o } = await k(t),
    r = e === "image/jpeg" ? et(o, n) : o;
  return ot(r, e, a);
}
function Pt(t, e, a = !0, n) {
  const o = document.createElement("canvas");
  ((o.width = t instanceof HTMLCanvasElement ? t.width : t.naturalWidth),
    (o.height = t instanceof HTMLCanvasElement ? t.height : t.naturalHeight));
  const r = o.getContext("2d");
  r.drawImage(t, 0, 0);
  const i = r.getImageData(0, 0, o.width, o.height),
    h = i.data,
    s = it(h, e, a);
  return (n && Object.assign(n, s), r.putImageData(i, 0, 0), o);
}
function vt(t, e, a, n) {
  const { topLeft: o, topRight: r, bottomRight: i, bottomLeft: h } = e,
    s = r.x - i.x,
    c = h.x - i.x,
    u = o.x - r.x + i.x - h.x,
    l = r.y - i.y,
    f = h.y - i.y,
    m = o.y - r.y + i.y - h.y;
  let d, y, M, b, C, w, I, A;
  const _ = 1e-10;
  if (Math.abs(u) < _ && Math.abs(m) < _)
    ((d = r.x - o.x),
      (y = h.x - o.x),
      (M = o.x),
      (b = r.y - o.y),
      (C = h.y - o.y),
      (w = o.y),
      (I = 0),
      (A = 0));
  else {
    const L = s * f - c * l;
    ((I = (u * f - c * m) / L),
      (A = (s * m - u * l) / L),
      (d = r.x - o.x + I * r.x),
      (y = h.x - o.x + A * h.x),
      (M = o.x),
      (b = r.y - o.y + I * r.y),
      (C = h.y - o.y + A * h.y),
      (w = o.y));
  }
  const F = (L, D) => {
      const P = I * L + A * D + 1;
      return { x: (d * L + y * D + M) / P, y: (b * L + C * D + w) / P };
    },
    g = document.createElement("canvas");
  ((g.width = t.naturalWidth), (g.height = t.naturalHeight));
  const p = g.getContext("2d");
  p.drawImage(t, 0, 0);
  const x = p.getImageData(0, 0, g.width, g.height).data,
    E = document.createElement("canvas");
  ((E.width = a), (E.height = n));
  const R = E.getContext("2d"),
    Y = R.createImageData(a, n),
    O = Y.data,
    K = (L, D) => {
      const P = Math.floor(L),
        S = Math.floor(D),
        v = Math.min(P + 1, g.width - 1),
        U = Math.min(S + 1, g.height - 1),
        N = L - P,
        j = D - S,
        G = (T, z) => (z * g.width + T) * 4,
        Q = [0, 0, 0, 0];
      for (let T = 0; T < 4; T++) {
        const z = x[G(P, S) + T] * (1 - N) + x[G(v, S) + T] * N,
          W = x[G(P, U) + T] * (1 - N) + x[G(v, U) + T] * N;
        Q[T] = z * (1 - j) + W * j;
      }
      return Q;
    };
  for (let L = 0; L < n; L++)
    for (let D = 0; D < a; D++) {
      const P = D / a,
        S = L / n,
        v = F(P, S),
        U = (L * a + D) * 4;
      if (v.x < 0 || v.x >= g.width - 1 || v.y < 0 || v.y >= g.height - 1) {
        O[U + 3] = 0;
        continue;
      }
      const [N, j, G, Q] = K(v.x, v.y);
      ((O[U] = N), (O[U + 1] = j), (O[U + 2] = G), (O[U + 3] = Q));
    }
  return (R.putImageData(Y, 0, 0), E);
}
function mt(t, e, a) {
  let n = t;
  for (; n.width / 2 >= e && n.height / 2 >= a;) {
    const i = document.createElement("canvas");
    ((i.width = Math.max(1, Math.floor(n.width / 2))),
      (i.height = Math.max(1, Math.floor(n.height / 2))));
    const h = i.getContext("2d");
    ((h.imageSmoothingQuality = "high"),
      h.drawImage(n, 0, 0, i.width, i.height),
      (n = i));
  }
  const o = document.createElement("canvas");
  ((o.width = e), (o.height = a));
  const r = o.getContext("2d");
  return ((r.imageSmoothingQuality = "high"), r.drawImage(n, 0, 0, e, a), o);
}
async function Tt(t, e, a) {
  const { canvas: n } = await k(t);
  return X(mt(n, e, a), t);
}
function gt(t, e, a) {
  const n = Math.max(0, Math.round(t.x * e)),
    o = Math.max(0, Math.round(t.y * a)),
    r = Math.min(e, Math.round((t.x + t.w) * e)),
    i = Math.min(a, Math.round((t.y + t.h) * a));
  return { x: n, y: o, w: Math.max(1, r - n), h: Math.max(1, i - o) };
}
async function Ut(t, e) {
  const { canvas: a } = await k(t),
    n = gt(e, a.width, a.height),
    o = document.createElement("canvas");
  return (
    (o.width = n.w),
    (o.height = n.h),
    o.getContext("2d").drawImage(a, n.x, n.y, n.w, n.h, 0, 0, n.w, n.h),
    { ...(await X(o, t)), width: n.w, height: n.h }
  );
}
function _t(t, e) {
  const a = t.getContext("2d"),
    n = document.createElement("canvas");
  ((n.width = t.width), (n.height = t.height));
  const o = n.getContext("2d");
  return (
    o.translate(
      e === "horizontal" ? t.width : 0,
      e === "vertical" ? t.height : 0,
    ),
    o.scale(e === "horizontal" ? -1 : 1, e === "vertical" ? -1 : 1),
    o.drawImage(t, 0, 0),
    a.clearRect(0, 0, t.width, t.height),
    a.drawImage(n, 0, 0),
    t
  );
}
function Bt(t) {
  const e = t.getContext("2d"),
    a = document.createElement("canvas");
  ((a.width = t.height), (a.height = t.width));
  const n = a.getContext("2d");
  return (
    n.translate(a.width / 2, a.height / 2),
    n.rotate(Math.PI / 2),
    n.drawImage(t, -t.width / 2, -t.height / 2),
    (t.width = a.width),
    (t.height = a.height),
    e.drawImage(a, 0, 0),
    t
  );
}
async function Ft(t) {
  return (await k(t)).canvas;
}
async function X(t, e) {
  const { mimeType: a, extension: n } = tt(e),
    o = a === "image/jpeg" ? 0.92 : void 0,
    r = await new Promise((s) => t.toBlob((c) => s(c), a, o)),
    i = r.type && r.type !== a,
    h = nt(e.name, i ? "png" : n);
  return { blob: r, filename: h };
}
async function St(t, e) {
  const { canvas: a } = await k(t);
  return X(ut(a, e), t);
}
export {
  Lt as D,
  Ut as a,
  Bt as b,
  X as c,
  mt as d,
  ut as e,
  _t as f,
  St as g,
  lt as h,
  Ct as i,
  Mt as j,
  It as k,
  Ft as l,
  bt as m,
  pt as n,
  At as o,
  Et as p,
  wt as q,
  Tt as r,
  Pt as s,
  vt as t,
  Rt as u,
  yt as v,
  Dt as w,
};
//# sourceMappingURL=operations-ISiPxXUp.js.map
