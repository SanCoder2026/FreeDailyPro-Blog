import { d as I, a as y, c, h as O } from "./decode-D7I8Qajh.js";
function G(e) {
  const t = new Set([
    "image/jpeg",
    "image/png",
    "image/webp",
    "image/gif",
    "image/bmp",
  ]);
  if (e.type && t.has(e.type)) {
    const s = e.type === "image/jpeg" ? "jpg" : e.type.split("/")[1];
    return { mimeType: e.type, extension: s };
  }
  if (
    e.type === "image/heic" ||
    e.type === "image/heif" ||
    /\.(heic|heif)$/i.test(e.name)
  )
    return { mimeType: "image/jpeg", extension: "jpg" };
  const n = e.name.match(/\.([a-zA-Z0-9]+)$/),
    a = n ? n[1].toLowerCase() : "",
    i = {
      jpg: "image/jpeg",
      jpeg: "image/jpeg",
      jfif: "image/jpeg",
      png: "image/png",
      webp: "image/webp",
      gif: "image/gif",
      bmp: "image/bmp",
    };
  return a in i
    ? { mimeType: i[a], extension: a === "jpeg" || a === "jfif" ? "jpg" : a }
    : { mimeType: "image/png", extension: "png" };
}
async function H(e) {
  if (I(e) === "native")
    try {
      return await new Promise((i, s) => {
        const o = new Image();
        ((o.onload = () => i(o)),
          (o.onerror = s),
          (o.src = URL.createObjectURL(e)));
      });
    } catch {}
  const { canvas: n } = await y(e),
    a = await c(n, "image/png");
  return await new Promise((i, s) => {
    const o = new Image();
    ((o.onload = () => i(o)),
      (o.onerror = s),
      (o.src = URL.createObjectURL(a)));
  });
}
const l = 0.1,
  C = 0.95,
  v = 8,
  _ = 0.97;
function A(e) {
  return (
    (e.type || "").toLowerCase() === "image/svg+xml" || /\.svgz?$/i.test(e.name)
  );
}
function M(e, t) {
  return {
    blob: e,
    size: e.size,
    metTarget: !0,
    targetBytes: t,
    width: 0,
    height: 0,
    originalWidth: 0,
    originalHeight: 0,
    mimeType: "image/svg+xml",
    extension: "svg",
    resized: !1,
    alreadyUnder: !1,
    hadTransparency: !0,
    keptOriginal: "vector",
  };
}
const P = () => new Promise((e) => setTimeout(e, 0));
async function Q() {
  const e = document.createElement("canvas");
  e.width = e.height = 1;
  const t = await new Promise((n) => e.toBlob(n, "image/webp", 0.5));
  return !!t && t.type === "image/webp";
}
async function U(e) {
  const t = O(e);
  return t && (await Q())
    ? { mimeType: "image/webp", extension: "webp", transparent: t }
    : { mimeType: "image/jpeg", extension: "jpg", transparent: t };
}
function u(e, t, n) {
  const a = document.createElement("canvas");
  ((a.width = Math.max(1, Math.round(e.width * t))),
    (a.height = Math.max(1, Math.round(e.height * t))));
  const i = a.getContext("2d");
  return (
    (i.imageSmoothingQuality = "high"),
    n && ((i.fillStyle = "#ffffff"), i.fillRect(0, 0, a.width, a.height)),
    i.drawImage(e, 0, 0, a.width, a.height),
    a
  );
}
async function W(e, t, n = {}) {
  if (A(e)) return M(e, t);
  const a = await $(e, t, n);
  return E(e, a);
}
function E(e, t) {
  return t.alreadyUnder || t.keptOriginal || t.size < e.size
    ? t
    : {
        ...t,
        blob: e,
        size: e.size,
        mimeType: e.type || t.mimeType,
        extension: (
          e.name.match(/\.([a-z0-9]+)$/i)?.[1] ?? t.extension
        ).toLowerCase(),
        width: t.originalWidth,
        height: t.originalHeight,
        resized: !1,
        keptOriginal: "not-smaller",
      };
}
async function $(e, t, n) {
  const a = Date.now(),
    i = n.maxMs ?? 2e4,
    { canvas: s } = await y(e),
    o = await U(s),
    S = Math.max(1, Math.floor(t * _)),
    g = {
      originalWidth: s.width,
      originalHeight: s.height,
      mimeType: o.mimeType,
      extension: o.extension,
      hadTransparency: o.transparent,
    };
  if (e.size <= t && I(e) === "native")
    return {
      blob: e,
      size: e.size,
      metTarget: !0,
      targetBytes: t,
      width: s.width,
      height: s.height,
      resized: !1,
      alreadyUnder: !0,
      ...g,
      mimeType: e.type || g.mimeType,
      extension: (
        e.name.match(/\.([a-z0-9]+)$/i)?.[1] ?? g.extension
      ).toLowerCase(),
    };
  const T = n.keepDimensions ? [1] : [1, 0.85, 0.7, 0.55, 0.4, 0.3, 0.2, 0.12],
    b = o.mimeType === "image/jpeg",
    L = T.length * v;
  let R = 0,
    h = null;
  for (const r of T) {
    if (Date.now() - a > i) break;
    const m = u(s, r, b);
    let f = l,
      z = C,
      d = null;
    for (let x = 0; x < v; x++) {
      if (n.signal?.aborted) throw new DOMException("Cancelled", "AbortError");
      const w = (f + z) / 2,
        j = await c(m, o.mimeType, w);
      (j.size <= S ? ((d = j), (f = w)) : (z = w),
        n.onProgress?.(Math.min(0.99, ++R / L)),
        await P());
    }
    if (d)
      return {
        blob: d,
        size: d.size,
        metTarget: !0,
        targetBytes: t,
        width: m.width,
        height: m.height,
        resized: r !== 1,
        alreadyUnder: !1,
        ...g,
      };
    const k = await c(m, o.mimeType, l);
    r === 1 && (h = { blob: k, w: m.width, h: m.height });
  }
  if (!h) {
    const r = u(s, 1, b);
    h = { blob: await c(r, o.mimeType, l), w: r.width, h: r.height };
  }
  const p = h;
  return {
    blob: p.blob,
    size: p.blob.size,
    metTarget: !1,
    targetBytes: t,
    width: p.w,
    height: p.h,
    resized: !1,
    alreadyUnder: !1,
    ...g,
  };
}
async function Y(e, t) {
  return A(e) ? M(e, e.size) : E(e, await F(e, t));
}
async function F(e, t) {
  const { canvas: n } = await y(e),
    a = await U(n),
    i = u(n, 1, a.mimeType === "image/jpeg"),
    s = await c(i, a.mimeType, t);
  return {
    blob: s,
    size: s.size,
    metTarget: !0,
    targetBytes: s.size,
    width: i.width,
    height: i.height,
    originalWidth: n.width,
    originalHeight: n.height,
    mimeType: a.mimeType,
    extension: a.extension,
    resized: !1,
    alreadyUnder: !1,
    hadTransparency: a.transparent,
  };
}
function q(e, t) {
  return e.replace(/\.[a-zA-Z0-9]+$/, "") + "." + t;
}
export { W as a, Y as c, G as g, H as l, q as w };
//# sourceMappingURL=utils-BCX55KBw.js.map
