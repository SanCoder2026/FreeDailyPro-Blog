# Test images for FDP-19 resize-crop (Pillow).
from PIL import Image, ImageDraw, ImageFont
import random
def scene(w,h,alpha=False):
    im=Image.new('RGBA' if alpha else 'RGB',(w,h),(0,0,0,0) if alpha else (230,230,230))
    d=ImageDraw.Draw(im)
    for i in range(0,w,max(1,w//8)): d.rectangle([i,0,i+w//16,h],fill=(200,60,60,255))
    d.ellipse([w*0.3,h*0.3,w*0.7,h*0.7],fill=(40,90,200,255))
    d.text((10,10),'TOP-LEFT',fill=(0,0,0,255)); d.text((w-80,h-20),'BOTTOM-RIGHT',fill=(0,0,0,255))
    d.rectangle([0,0,w-1,h-1],outline=(0,160,0,255),width=max(2,w//200))
    return im
# 4000x3000 photo with EXIF orientation 6, GPS, DPI 300
im=scene(4000,3000)
ex=Image.Exif(); ex[0x0112]=6; ex[0x010F]='TestCam'; ex[0x0110]='FDP-19'
gps={1:'N',2:(40.0,44.0,54.36),3:'W',4:(73.0,59.0,8.36)}; ex[0x8825]=gps
im.save('photo.jpg',quality=92,exif=ex,dpi=(300,300))
scene(4000,3000).save('plain.jpg',quality=92,dpi=(72,72))
scene(800,600,alpha=True).save('alpha.png')
scene(1200,800).save('img.webp',quality=90)
scene(640,480).save('img.bmp')
scene(50,50).save('tiny.png')
fr=[scene(300,200).rotate(i*30) for i in range(6)]; fr[0].save('anim.gif',save_all=True,append_images=fr[1:],duration=150,loop=0)
scene(1000,1000).save('img.tiff')
open('vector.svg','w').write('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300"><rect width="400" height="300" fill="#c33"/><circle cx="200" cy="150" r="80" fill="#36c"/></svg>')
open('notimage.jpg','w').write('this is not an image\n')
Image.new('RGB',(12000,9000),(120,120,120)).save('huge108mp.jpg',quality=50)
