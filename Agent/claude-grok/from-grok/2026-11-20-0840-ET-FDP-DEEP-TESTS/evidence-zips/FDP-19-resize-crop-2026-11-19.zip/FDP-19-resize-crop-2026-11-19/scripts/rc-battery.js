// resize-crop battery: one fresh context per case; cases from rc-cases.json (argv[2] = comma IDs). Resize Image / Apply Crop cost no trial use (gate is at Download); no download is made.
// The output blob is captured with an init script that records canvas.toBlob / convertToBlob results (the tool keeps the result in memory until Download).
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/19-resize-crop/live/'; const T = '/workspace/deep/19-resize-crop/testfiles/';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const ids = process.argv[2] ? process.argv[2].split(',') : null; const tag = ids ? '-' + ids.join('_') : '';
const cases = JSON.parse(fs.readFileSync(__dirname + '/rc-cases.json')).filter(c => !ids || ids.includes(c.id));
const HOOK = `(() => { window.__blobs = []; const o = HTMLCanvasElement.prototype.toBlob; HTMLCanvasElement.prototype.toBlob = function (cb, ...a) { const w = this.width, h = this.height; return o.call(this, b => { if (b) window.__blobs.push({ b, w, h, t: Date.now(), req: a[0] || 'image/png' }); cb(b); }, ...a); };
 if (window.OffscreenCanvas) { const oc = OffscreenCanvas.prototype.convertToBlob; OffscreenCanvas.prototype.convertToBlob = async function (...a) { const b = await oc.apply(this, a); window.__blobs.push({ b, w: this.width, h: this.height, t: Date.now(), req: (a[0] && a[0].type) || 'image/png' }); return b; }; } })();`;
(async () => {
  const b = await chromium.launch(); const R = { t: now(), cases: [] }; const save = () => fs.writeFileSync(OUT + 'battery' + tag + '.json', JSON.stringify(R, null, 1));
  for (const c of cases) {
    const r = { ...c, t: now() }; const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); await ctx.addInitScript(HOOK); const p = await ctx.newPage(); p.setDefaultTimeout(10000);
    const toasts = []; const grab = async () => { const tt = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim())).catch(() => []); tt.forEach(x => { if (!toasts.includes(x)) toasts.push(x); }); };
    try {
      await p.goto('https://www.freedailypro.com/tool/resize-crop', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
      if (!R.ls0) R.ls0 = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
      await p.locator('input[type=file]').first().setInputFiles(T + c.file); await p.waitForTimeout(3500); await grab();
      r.original = await p.evaluate(() => (document.querySelector('main').innerText.match(/Original: [^\n]*/) || [null])[0]);
      if (c.mode === 'crop') {
        await p.getByRole('button', { name: 'Crop', exact: true }).click(); await p.waitForTimeout(800);
        r.cropInputsBeforeDrag = await p.getByLabel('X (px from left)').count();
        await p.getByRole('button', { name: c.ratio, exact: true }).click();
        const img = p.locator('main img[alt=Preview]').first(); const bb = await img.boundingBox();
        await p.mouse.move(bb.x + bb.width * 0.1, bb.y + bb.height * 0.1); await p.mouse.down(); await p.mouse.move(bb.x + bb.width * 0.4, bb.y + bb.height * 0.4, { steps: 8 }); await p.mouse.up(); await p.waitForTimeout(500);
        r.afterDrag = await p.evaluate(() => ['X (px from left)', 'Y (px from top)', 'Width (px)', 'Height (px)'].map(l => { const lab = [...document.querySelectorAll('main label')].find(x => x.innerText.trim().startsWith(l)); const i = lab && lab.querySelector('input'); return i ? i.value : null; }));
        const labs = ['X (px from left)', 'Y (px from top)', 'Width (px)', 'Height (px)'];
        for (let i = 0; i < 4; i++) { const inp = p.locator('main label', { hasText: labs[i] }).locator('input').first(); await inp.fill(c.sel[i]); await inp.press('Tab'); await p.waitForTimeout(200); }
        r.selAfterType = await p.evaluate(() => ['X (px from left)', 'Y (px from top)', 'Width (px)', 'Height (px)'].map(l => { const lab = [...document.querySelectorAll('main label')].find(x => x.innerText.trim().startsWith(l)); const i = lab && lab.querySelector('input'); return i ? i.value : null; }));
        if (c.scaleW) await p.locator('main label', { hasText: 'Then scale to width' }).locator('input').fill(c.scaleW);
        const n0 = await p.evaluate(() => window.__blobs.length);
        await p.getByRole('button', { name: /Apply Crop/ }).click(); await p.waitForTimeout(2500); await grab();
        r.result = await p.evaluate(() => (document.querySelector('main').innerText.match(/Cropped result[^\n]*\n?[^\n]*/) || [null])[0]);
        const out = await p.evaluate(async () => { const im = [...document.querySelectorAll('main img')].filter(i => i.src.startsWith('blob:')).pop(); if (!im) return null; const bl = await (await fetch(im.src)).blob(); const bb = new Uint8Array(await bl.arrayBuffer()); let s = ''; for (let i = 0; i < bb.length; i += 8192) s += String.fromCharCode.apply(null, bb.subarray(i, i + 8192)); return { type: bl.type, b64: btoa(s) }; });
        if (out) { const ext = (out.type.split('/')[1] || 'bin').replace('jpeg', 'jpg'); fs.writeFileSync(OUT + 'out-' + c.id + '.' + ext, Buffer.from(out.b64, 'base64')); r.outType = out.type; r.outFile = 'out-' + c.id + '.' + ext; }
        r.buttons = await p.evaluate(() => [...document.querySelectorAll('main button')].map(b => b.innerText.trim()).filter(x => /Download|Day Pass|Drive|cloud|Resize this|New|Share|Copy|Print/i.test(x)));
        if (c.resizeAfter) { await p.getByRole('button', { name: 'Resize this crop' }).click(); await p.waitForTimeout(1500); r.afterHandoff = { original: await p.evaluate(() => (document.querySelector('main').innerText.match(/Original: [^\n]*/) || [null])[0]), w: await p.locator('#rc-width').inputValue().catch(() => null) }; await p.locator('#rc-width').fill(c.resizeAfter); await p.waitForTimeout(400); const k0 = await p.evaluate(() => window.__blobs.length); await p.getByRole('button', { name: 'Resize Image', exact: true }).click(); await p.waitForTimeout(2500); await grab(); r.afterHandoff.blobs = await p.evaluate(k => window.__blobs.slice(k).map(x => ({ w: x.w, h: x.h, type: x.b.type, size: x.b.size })), k0); }
      } else {
        if (c.lock === false) await p.getByLabel('Maintain aspect ratio').uncheck();
        if (c.fit) { await p.getByRole('combobox', { name: 'How the picture fits the size' }).click(); await p.getByRole('option', { name: c.fit, exact: true }).click(); await p.waitForTimeout(300); r.fitHelp = await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*With Inside or Outside[^\n]*/) || [null])[0]); }
        if (c.rotate) { await p.getByRole('combobox', { name: 'Rotate' }).click(); const opts = await p.getByRole('option').allInnerTexts(); r.rotateOptions = opts; await p.getByRole('option', { name: new RegExp(c.rotate) }).first().click(); }
        if (c.flop) await p.locator('#rc-flop').click(); if (c.flip) await p.locator('#rc-flip').click(); if (c.gray) await p.locator('#rc-gray').click(); if (c.noenlarge) await p.locator('#rc-noenlarge').click();
        if (c.unit) { const sel = p.locator('main select[aria-label=Unit]').first(); r.unitCount = await p.locator('[aria-label=Unit]').count(); const vals = await sel.evaluate(s => [...s.options].map(o => o.value + '=' + o.text)); r.unitOptions = vals; const v = vals.find(x => x.toLowerCase().includes(c.unit === '%' ? 'percent' : c.unit === 'cm' ? 'centim' : 'inch')).split('=')[0]; await sel.selectOption(v); await p.waitForTimeout(200); if (c.dpi) await p.locator('main [aria-label=DPI]').first().fill(c.dpi); const ni = p.locator('main input[type=number]:not(#rc-width):not(#rc-height)').filter({ hasNot: p.locator('[aria-label=DPI]') }); const all = await p.locator('main input[type=number]').evaluateAll(es => es.map(e => (e.id || '') + '|' + (e.getAttribute('aria-label') || ''))); r.numInputs = all; const idx = all.findIndex(x => x === '|'); await p.locator('main input[type=number]').nth(idx).fill(c.unitVal); await p.getByRole('button', { name: 'Set width' }).click(); await p.waitForTimeout(400); }
        if (c.w) { await p.locator('#rc-width').fill(c.w); } if (c.h) { await p.locator('#rc-height').fill(c.h); } await p.waitForTimeout(800);
        r.wh = [await p.locator('#rc-width').inputValue().catch(() => null), await p.locator('#rc-height').inputValue().catch(() => null)];
        r.inlineErrors = await p.evaluate(() => [...document.querySelectorAll('main p, main [role=alert]')].map(e => e.innerText.trim()).filter(t => t.length < 200 && /must|at most|megapixels|Enter a/i.test(t)).slice(0, 4));
        r.previewLine = await p.evaluate(() => (document.querySelector('main').innerText.match(/Preview at [^\n]*/) || [null])[0]);
        const btn = p.getByRole('button', { name: 'Resize Image', exact: true }); r.resizeEnabled = (await btn.count()) ? await btn.isEnabled() : null;
        if (r.resizeEnabled) { const n0 = await p.evaluate(() => window.__blobs.length); await btn.click(); await p.waitForTimeout(3000); await grab();
          const out = await p.evaluate(async n0 => { const L = window.__blobs.slice(n0); const x = L[L.length - 1]; if (!x) return null; const bb = new Uint8Array(await x.b.arrayBuffer()); let s = ''; for (let i = 0; i < bb.length; i += 8192) s += String.fromCharCode.apply(null, bb.subarray(i, i + 8192)); return { type: x.b.type, req: x.req, w: x.w, h: x.h, n: L.length, b64: btoa(s) }; }, n0);
          if (out) { const ext = (out.type.split('/')[1] || 'bin').replace('jpeg', 'jpg'); fs.writeFileSync(OUT + 'out-' + c.id + '.' + ext, Buffer.from(out.b64, 'base64')); r.outType = out.type; r.requested = out.req; r.canvas = [out.w, out.h]; r.outFile = 'out-' + c.id + '.' + ext; }
          r.buttons = await p.evaluate(() => [...document.querySelectorAll('main button')].map(b => b.innerText.trim()).filter(x => /Download|Day Pass|Drive|cloud|New|Share|Copy|Print/i.test(x)));
          r.dlName = await p.evaluate(() => [...document.querySelectorAll('main a[download]')].map(a => a.getAttribute('download')));
        }
      }
      await grab(); r.toasts = toasts; await p.screenshot({ path: OUT + 'res-' + c.id + '.png' });
      r.ls1 = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
    } catch (e) { r.err = String(e).slice(0, 220); await p.screenshot({ path: OUT + 'err-' + c.id + '.png' }).catch(() => {}); }
    R.cases.push(r); save(); console.log(r.id, r.original, r.outType || '', r.canvas || '', r.err || '', toasts.join(' / ')); await ctx.close();
  }
  R.t1 = now(); save(); await b.close();
})();
