// resize-crop: Firefox and WebKit desktop: Resize plain.jpg to 1200 wide, then Crop 1:1 (auto square) + Apply. No use spent.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/19-resize-crop/live/'; const T = '/workspace/deep/19-resize-crop/testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const R = { t: now() };
(async () => { for (const eng of ['firefox', 'webkit']) { const b = await pw[eng].launch(); const p = await (await b.newContext({ viewport: { width: 1440, height: 900 } })).newPage(); p.setDefaultTimeout(15000); const r = {}; let crashed = false; p.on('crash', () => crashed = true);
  try { await p.goto('https://www.freedailypro.com/tool/resize-crop', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
   await p.locator('input[type=file]').first().setInputFiles(T + 'plain.jpg'); await p.waitForTimeout(3000); r.original = await p.evaluate(() => (document.querySelector('main').innerText.match(/Original: [^\n]*/) || [null])[0]);
   await p.locator('#rc-width').fill('1200'); await p.waitForTimeout(800); r.preview = await p.evaluate(() => (document.querySelector('main').innerText.match(/Preview at [^\n]*/) || [null])[0]);
   await p.getByRole('button', { name: 'Resize Image', exact: true }).click(); await p.waitForTimeout(2500); r.toasts1 = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim()));
   await p.getByRole('button', { name: 'New', exact: true }).click().catch(() => {}); await p.waitForTimeout(800); await p.locator('input[type=file]').first().setInputFiles(T + 'photo.heic'); await p.waitForTimeout(5000); r.heic = await p.evaluate(() => (document.querySelector('main').innerText.match(/Original: [^\n]*|could not be read[^\n]*/) || [null])[0]);
   await p.getByRole('button', { name: 'Crop', exact: true }).click(); await p.waitForTimeout(600); await p.getByRole('button', { name: '1:1', exact: true }).click(); await p.waitForTimeout(600);
   await p.getByRole('button', { name: /Apply Crop/ }).click(); await p.waitForTimeout(2500); r.toasts2 = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim()));
   await p.screenshot({ path: OUT + 'browser-' + eng + '.png' }); } catch (e) { r.err = String(e).slice(0, 150); }
  r.crashed = crashed; R[eng] = r; await b.close().catch(() => {}); }
 R.t2 = now(); fs.writeFileSync(OUT + 'browsers.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); })();
