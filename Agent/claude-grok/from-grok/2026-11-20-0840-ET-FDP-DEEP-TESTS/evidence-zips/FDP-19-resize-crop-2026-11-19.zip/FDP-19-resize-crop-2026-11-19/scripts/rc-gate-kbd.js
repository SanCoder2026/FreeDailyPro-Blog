// resize-crop: starting count; keyboard to the drop zone; 1:1 preset auto-selection; keyboard-only crop; enlarge warning text; axe; result live region/focus;
// Download / Drive / cloud at the starting count (stops at the first dialog; at 0: cap dialog -> Buy Day Pass -> email prompt, types nothing); phones. Resize/Crop themselves cost no trial use.
const { chromium, devices } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/19-resize-crop/live/'; const T = '/workspace/deep/19-resize-crop/testfiles/'; const URL = 'https://www.freedailypro.com/tool/resize-crop';
const AXE = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8'); const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const axe = async p => { await p.addScriptTag({ content: AXE }); return p.evaluate(async () => (await axe.run(document.querySelector('main'), { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'best-practice'] }, resultTypes: ['violations'] })).violations.map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length, t: v.nodes.slice(0, 4).map(n => n.target.join(' ')) }))); };
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams)=[^&]*/g, '$1=REDACTED').slice(0, 160);
const selVals = p => p.evaluate(() => ['X (px from left)', 'Y (px from top)', 'Width (px)', 'Height (px)'].map(l => { const lab = [...document.querySelectorAll('main label')].filter(x => x.innerText.trim().startsWith(l)).pop(); const i = lab && lab.querySelector('input'); return i ? i.value : null; }));
(async () => { const b = await chromium.launch(); const R = { t: now() };
 const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await c.newPage(); p.setDefaultTimeout(12000);
 await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 R.start = await used(); R.strip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]); R.axeIdle = await axe(p);
 let chooser = false; p.on('filechooser', () => { chooser = true; }); const seq = [];
 for (let i = 0; i < 60; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('role') || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50).replace(/\n/g, ' '); }); seq.push(a); if (/Drop an image/i.test(a)) { await p.keyboard.press('Enter'); await p.waitForTimeout(1200); seq.push('ENTER -> chooser=' + chooser); break; } }
 R.kbd = { tabs: seq.length, last: seq.slice(-3), chooser };
 // enlarge warning
 await p.locator('input[type=file]').first().setInputFiles(T + 'tiny.png'); await p.waitForTimeout(2500); await p.locator('#rc-width').fill('500'); await p.waitForTimeout(800);
 R.enlargeText = await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*(soft|twice|enlarg|blurr|bigger than)[^\n]*/gi) || []).filter(x => x.length < 250));
 R.axeResize = await axe(p);
 await p.getByRole('button', { name: 'Reset', exact: true }).click().catch(() => {}); await p.waitForTimeout(800);
 // crop: 1:1 preset auto selection and keyboard crop
 await p.locator('input[type=file]').first().setInputFiles(T + 'plain.jpg'); await p.waitForTimeout(3000);
 await p.getByRole('button', { name: 'Crop', exact: true }).click(); await p.waitForTimeout(800);
 R.cropBefore = { sel: await selVals(p), applyEnabled: await p.getByRole('button', { name: /Apply Crop/ }).isEnabled().catch(() => null), hint: await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*(drag|select the area)[^\n]*/i) || [null])[0]) };
 await p.getByRole('button', { name: '1:1', exact: true }).click(); await p.waitForTimeout(800);
 R.after11 = { sel: await selVals(p), applyEnabled: await p.getByRole('button', { name: /Apply Crop/ }).isEnabled().catch(() => null) };
 R.ratioButtons = await p.evaluate(() => [...document.querySelectorAll('main button')].map(b => ({ t: b.innerText.trim(), pressed: b.getAttribute('aria-pressed') })).filter(x => /^(Freeform|\d+:\d+)$/.test(x.t)));
 R.axeCrop = await axe(p);
 // keyboard-only: type numbers without dragging
 const labs = ['X (px from left)', 'Y (px from top)', 'Width (px)', 'Height (px)']; const vals = ['500', '0', '3000', '3000'];
 for (let i = 0; i < 4; i++) { const inp = p.locator('main label', { hasText: labs[i] }).locator('input').last(); if (await inp.count()) { await inp.fill(vals[i]); await inp.press('Tab'); } }
 R.kbdCrop = { sel: await selVals(p), applyEnabled: await p.getByRole('button', { name: /Apply Crop/ }).isEnabled().catch(() => null) };
 if (R.kbdCrop.applyEnabled) { await p.getByRole('button', { name: /Apply Crop/ }).focus(); await p.keyboard.press('Enter'); await p.waitForTimeout(2500); }
 R.cropResult = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim()));
 R.liveRegions = await p.evaluate(() => [...document.querySelectorAll('main [aria-live],main [role=status],main [role=alert]')].map(e => ({ live: e.getAttribute('aria-live'), role: e.getAttribute('role'), text: e.innerText.slice(0, 80) })));
 R.focusAfter = await p.evaluate(() => document.activeElement.tagName + ' ' + document.activeElement.innerText.slice(0, 30));
 R.resultImgAlt = await p.evaluate(() => [...document.querySelectorAll('main img')].filter(i => i.src.startsWith('blob:')).map(i => i.alt));
 R.resultButtons = await p.evaluate(() => [...document.querySelectorAll('main button, main a')].map(b => b.innerText.trim()).filter(x => /Download|Drive|cloud|Continue|New|Pass|Share|Copy|Print|Resize this|Next/i.test(x) && x.length < 80));
 R.axeResult = await axe(p); await p.screenshot({ path: OUT + 'result-desktop.png', fullPage: true });
 const act = async (name, rx) => { const r = { before: await used() }; const loc = p.getByRole('button', { name: rx }).first(); if (!(await loc.count())) { r.missing = true; return r; }
   const pop = c.waitForEvent('page', { timeout: 5000 }).catch(() => null); const dl = p.waitForEvent('download', { timeout: 5000 }).catch(() => null); const url0 = p.url(); await loc.click(); const [pg, d] = await Promise.all([pop, dl]); await p.waitForTimeout(2000);
   r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null; r.download = d ? d.suggestedFilename() : null; if (pg) { r.popup = red(pg.url()); await pg.close(); }
   if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + '.png' });
   if (name === 'download' && r.dialog) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); r.dayPass = { dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); } }
   await esc(); if (r.url) { await p.goBack().catch(() => {}); await p.waitForTimeout(2500); } return r; };
 R.download = await act('download', /^Download$/);
 R.drive = await act('drive', /Save to Google Drive/);
 R.cloud = await act('cloud', /Save to my cloud storage/);
 R.end = await used(); await c.close();
 for (const [nm, d] of [['iphone-se', devices['iPhone SE']], ['pixel-7', devices['Pixel 7']]]) { const { defaultBrowserType, ...dd } = d; const c2 = await b.newContext(dd); const q = await c2.newPage(); q.setDefaultTimeout(12000);
  await q.goto(URL, { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4000);
  const idle = await q.evaluate(() => { const z = [...document.querySelectorAll('main [role=button]')].find(e => /Drop an image/i.test(e.innerText)); return { vh: innerHeight, dropTop: z ? Math.round(z.getBoundingClientRect().top + scrollY) : null }; });
  await q.locator('input[type=file]').first().setInputFiles(T + 'plain.jpg'); await q.waitForTimeout(2500);
  await q.getByRole('button', { name: 'Crop', exact: true }).click(); await q.waitForTimeout(600); await q.getByRole('button', { name: '1:1', exact: true }).click().catch(() => {}); await q.waitForTimeout(600);
  const img = q.locator('main img[alt=Preview]').first(); const bb = await img.boundingBox().catch(() => null); let touch = null;
  if (bb) { const cdp = await c2.newCDPSession(q); const pt = (x, y) => [{ x: bb.x + bb.width * x, y: bb.y + bb.height * y - 0 }];
   await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: pt(0.2, 0.2) }); for (let k = 1; k <= 6; k++) await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: pt(0.2 + k * 0.05, 0.2 + k * 0.05) }); await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] }); await q.waitForTimeout(500); touch = await selVals(q); }
  const lay = await q.evaluate(() => { const f = s => [...document.querySelectorAll('main button')].find(b => b.innerText.trim().startsWith(s)); const t = e => e ? Math.round(e.getBoundingClientRect().top + scrollY) : null; return { applyTop: t(f('Apply Crop')), overflowX: document.documentElement.scrollWidth > innerWidth + 1 }; });
  await q.screenshot({ path: OUT + `layout-${nm}-crop.png`, fullPage: true }); R[nm] = { ...idle, ...lay, touchSel: touch }; await c2.close(); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate-kbd.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
