# Inspect resize-crop outputs: format, size, mode, EXIF (orientation, GPS), DPI, corner colours.
import sys, glob, json, os
from PIL import Image
res = {}
for f in sorted(glob.glob(sys.argv[1] + '/out-*')):
    try:
        im = Image.open(f); ex = im.getexif()
        d = {'fmt': im.format, 'size': im.size, 'mode': im.mode, 'bytes': os.path.getsize(f), 'exifTags': len(ex), 'orientation': ex.get(0x0112), 'gps': bool(ex.get(0x8825)), 'dpi': im.info.get('dpi'), 'frames': getattr(im, 'n_frames', 1)}
        px = im.convert('RGBA'); w, h = px.size
        d['corners'] = [px.getpixel((2, 2)), px.getpixel((w - 3, 2)), px.getpixel((2, h - 3)), px.getpixel((w - 3, h - 3)), px.getpixel((w // 2, h // 2))]
        res[os.path.basename(f)] = d
    except Exception as e:
        res[os.path.basename(f)] = {'err': str(e)}
json.dump(res, open(sys.argv[1] + '/inspect.json', 'w'), indent=1, default=str)
for k, v in res.items(): print(k, json.dumps(v, default=str)[:260])
