// resize-crop probe: guest page text, count, UI after a file is chosen. No GIF made, no use spent.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/19-resize-crop/live/'; const T = '/workspace/deep/19-resize-crop/testfiles/';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage();
  const R = { t: now() };
  await p.goto('https://www.freedailypro.com/tool/resize-crop', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(6000);
  R.ls0 = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
  R.text0 = await p.evaluate(() => document.querySelector('main').innerText);
  fs.writeFileSync('/workspace/deep/19-resize-crop/tool-visible.txt', await p.evaluate(() => document.body.innerText));
  await p.screenshot({ path: OUT + 'probe-0.png' });
  await p.locator('input[type=file]').first().setInputFiles(T + 'photo.jpg'); await p.waitForTimeout(3000);
  R.text1 = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 2500));
  R.controls = await p.evaluate(() => [...document.querySelectorAll('main input, main select, main button')].map(e => ({ tag: e.tagName, type: e.type, id: e.id, label: e.labels && e.labels[0] ? e.labels[0].innerText.trim() : null, aria: e.getAttribute('aria-label'), text: e.innerText ? e.innerText.trim().slice(0, 40) : null, value: e.value })));
  await p.screenshot({ path: OUT + 'probe-1.png', fullPage: true });
  R.t1 = now(); fs.writeFileSync(OUT + 'probe.json', JSON.stringify(R, null, 1)); await b.close();
})();
