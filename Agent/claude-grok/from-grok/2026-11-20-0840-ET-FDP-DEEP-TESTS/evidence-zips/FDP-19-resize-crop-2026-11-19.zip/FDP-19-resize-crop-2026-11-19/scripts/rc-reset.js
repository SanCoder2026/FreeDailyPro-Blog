// resize-crop, run when uses are left (after the 7:00 PM ET reset, or a fresh context that loads with uses): Resize plain.jpg to 1200 wide, Download twice (count each, file name, bytes vs the in-memory result), then Drive (stops at Google sign-in). Costs trial uses.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/19-resize-crop/live/'; const T = '/workspace/deep/19-resize-crop/testfiles/'; const URL = 'https://www.freedailypro.com/tool/resize-crop';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams)=[^&]*/g, '$1=REDACTED').slice(0, 160);
const HOOK = `(() => { window.__blobs = []; const o = HTMLCanvasElement.prototype.toBlob; HTMLCanvasElement.prototype.toBlob = function (cb, ...a) { return o.call(this, b => { if (b) window.__blobs.push(b); cb(b); }, ...a); }; })();`;
(async () => { const b = await chromium.launch(); const R = { t: now(), runs: [] };
 for (let i = 0; i < 2; i++) { const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); await c.addInitScript(HOOK); const p = await c.newPage(); p.setDefaultTimeout(15000); const r = { t: now() };
  const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
  const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null; };
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); r.start = await used(); r.strip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]);
  if (r.start >= 10) { r.note = 'loaded at 0 remaining; nothing to observe'; R.runs.push(r); await c.close(); continue; }
  await p.locator('input[type=file]').first().setInputFiles(T + 'plain.jpg'); await p.waitForTimeout(2500); await p.locator('#rc-width').fill('1200'); await p.waitForTimeout(800);
  const n0 = await p.evaluate(() => window.__blobs.length); await p.getByRole('button', { name: 'Resize Image', exact: true }).click(); await p.waitForTimeout(2500); r.afterResize = await used();
  r.resultBytes = await p.evaluate(n0 => { const L = window.__blobs.slice(n0); return L.length ? L[L.length - 1].size : null; }, n0);
  for (const k of ['dl1', 'dl2']) { const ev = p.waitForEvent('download', { timeout: 8000 }).catch(() => null); await p.getByRole('button', { name: /^Download$/ }).first().click(); const d = await ev; await p.waitForTimeout(2000);
   r[k] = { dialog: await dialog(), count: await used() }; if (d) { const fp = OUT + 'reset-' + k + '-' + d.suggestedFilename(); await d.saveAs(fp); r[k].name = d.suggestedFilename(); r[k].bytes = fs.statSync(fp).size; r[k].sameAsResult = r[k].bytes === r.resultBytes; } if (r[k].dialog) { await p.keyboard.press('Escape'); break; } }
  const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); await p.getByRole('button', { name: /Save to Google Drive/ }).click(); const pg = await pop; await p.waitForTimeout(2500);
  r.drive = { dialog: await dialog(), count: await used(), popup: pg ? red(pg.url()) : null }; if (pg) await pg.close();
  r.t2 = now(); R.runs.push(r); console.log(JSON.stringify(r)); await c.close(); if (r.dl1) break; }
 fs.writeFileSync(OUT + 'reset.json', JSON.stringify(R, null, 1)); await b.close(); })();
