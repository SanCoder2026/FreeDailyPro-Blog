import { r as o, j as e } from "./vendor-react-D01g8YgM.js";
import {
  T as $,
  F as Y,
  R as Z,
  P as X,
  D as ee,
} from "./ToolPage-DS5jbfzr.js";
import { B as p, e as k, I, f as d } from "./index-D2ZT81un.js";
import { S as D } from "./slider-m2UfhN9O.js";
import { T as F } from "./ToolInfoSection-M0kcUBq8.js";
import { c as R, a as z } from "./utils-BCX55KBw.js";
import { r as q, a as te, c as se } from "./decode-D7I8Qajh.js";
import { B as ae, a as ie } from "./BatchRunner-BifTeP0Y.js";
import { T as re } from "./ToolSteps-DtiMymsE.js";
import { u as ne } from "./useDownloadedResult-C1FfMpBH.js";
import { T as oe } from "./target-BRRbTfiK.js";
import "./useUploadApi-CeBVbB2U.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-mA9gIB_c.js";
import "./share-2-wJ7OG3q6.js";
import "./copy-DxyF2bO9.js";
import "./workflowCta-QcLjv4ms.js";
import "./UsageAndUpgradeStrip-Ckl_cEoN.js";
import "./access-BBg1iIm1.js";
import "./useAdminAccess-D2xxeUJv.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-BaZhqv4P.js";
import "./map-pin-DiPhQKiV.js";
import "./FaqSection-DgbFc-d2.js";
import "./ToolVideoEmbed-DltoCXpM.js";
import "./GuideLinks-BsEl-oB0.js";
import "./blog-Cqpj3gtZ.js";
import "./info-BGlOhDp4.js";
import "./productCards-CAZfINO_.js";
import "./layers-B7zHnkyf.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./CollapsibleText-CmqWEytu.js";
import "./chevron-up-Bx33pgGu.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./formatFileSize-B-JRDfN5.js";
import "./batch-Bbh00IAr.js";
import "./trash-2-BJfoOy34.js";
import "./square-TSyXkWwu.js";
const K = !1;
function B(t, r) {
  return t === "target" ? r : !0;
}
function j(t) {
  return `${(t / 1024).toFixed(t < 10240 ? 1 : 0)} KB (${t.toLocaleString("en-US")} bytes)`;
}
function le(t, r, c) {
  const i =
      t.extension.toUpperCase() +
      (t.hadTransparency ? ", transparency kept" : ""),
    m = `${t.width} x ${t.height} px`;
  if (r === "quality")
    return `${j(t.size)} - ${m} (same size as the original) - ${i}.`;
  if (t.metTarget && t.resized)
    return `Reached ${j(t.size)} by resizing to ${m} (from ${t.originalWidth} x ${t.originalHeight} px) - ${i}. Tick "Don't change dimensions" to keep the pixel size instead.`;
  if (t.metTarget)
    return `${j(t.size)} - ${m} (same size as the original) - ${i}. Target reached.`;
  const h = r === "target" && c ? " without changing dimensions" : "";
  return `${j(t.size)} - ${m} - ${i}. Target not reached${h} - this is the smallest possible${r === "target" && c ? `; untick "Don't change dimensions" to let the picture be made smaller in pixels` : ""}.`;
}
const x = {
    what: `Reduces an image's file size while keeping it looking as close to the original as possible, useful for speeding up a website, fitting an email attachment limit, or saving storage space. Medium/Strong aim for at least a 25%/50% smaller file instead of a vague quality label. "Custom Target" lets you set any exact size limit instead.`,
    how: "Upload your image, pick Medium or Strong for a percentage reduction, or switch to Custom Target and enter your own size limit. Compare the file size before and after, and use the quality slider if you want manual control instead. To shrink many pictures with the same setting, switch to Several files (up to 5 at a time on the trial, counted as one use).",
    tip: "JPG images generally compress much further than PNGs before quality loss becomes noticeable — if you don't need transparency, converting a PNG to JPG first often gets you a smaller file overall.",
  },
  E = { medium: 0.75, strong: 0.5 },
  ce = [
    { label: "50 KB", bytes: 50 * 1024 },
    { label: "100 KB", bytes: 100 * 1024 },
    { label: "200 KB", bytes: 200 * 1024 },
    { label: "500 KB", bytes: 500 * 1024 },
    { label: "1 MB", bytes: 1024 * 1024 },
  ];
function me() {
  const [t, r] = o.useState("medium"),
    [c, i] = o.useState([75]),
    [m, h] = o.useState("200"),
    [v, w] = o.useState("KB"),
    [f, T] = o.useState(K),
    y = () =>
      Math.round(parseFloat(m || "0") * (v === "MB" ? 1024 * 1024 : 1024));
  return e.jsx(ie, {
    accept: "image/*",
    noun: "image",
    zipName: "compressed-images.zip",
    runLabel: "Compress all",
    check: () =>
      t === "target" && !(y() > 0) ? "Enter a valid target size" : null,
    includeOriginals: !0,
    process: async (s, b) => {
      const a =
        t === "quality"
          ? await R(s, c[0] / 100)
          : await z(s, t === "target" ? y() : Math.round(s.size * E[t]), {
              keepDimensions: B(t, f),
              signal: b,
            });
      return a.alreadyUnder || a.keptOriginal || a.size >= s.size
        ? { blob: s, fileName: s.name }
        : { blob: a.blob, fileName: q(s.name, a.extension, "compressed_") };
    },
    children: e.jsxs("div", {
      className: "space-y-3",
      children: [
        e.jsx("div", {
          className: "flex gap-2 flex-wrap",
          role: "group",
          "aria-label": "Compression mode",
          children: ["medium", "strong", "quality", "target"].map((s) =>
            e.jsx(
              p,
              {
                size: "sm",
                variant: t === s ? "default" : "outline",
                "aria-pressed": t === s,
                onClick: () => r(s),
                "data-testid": `ci-mode-${s}`,
                children:
                  s === "medium"
                    ? "Medium (25% smaller)"
                    : s === "strong"
                      ? "Strong (50% smaller)"
                      : s === "quality"
                        ? "Manual quality"
                        : "Custom target",
              },
              s,
            ),
          ),
        }),
        t === "quality" &&
          e.jsxs("div", {
            className: "space-y-2 max-w-xs",
            children: [
              e.jsxs(k, { children: ["Quality: ", c[0], "%"] }),
              e.jsx(D, {
                value: c,
                onValueChange: i,
                min: 10,
                max: 100,
                step: 5,
              }),
            ],
          }),
        t === "target" &&
          e.jsx("div", {
            className: "flex gap-2 items-end",
            children: e.jsxs("div", {
              children: [
                e.jsx(k, {
                  className: "text-xs",
                  children: "Target size for each picture",
                }),
                e.jsxs("div", {
                  className: "flex gap-2",
                  children: [
                    e.jsx(I, {
                      type: "number",
                      min: "0",
                      step: "1",
                      value: m,
                      onChange: (s) => h(s.target.value),
                      className: "w-24",
                      "data-testid": "ci-target",
                    }),
                    e.jsxs("select", {
                      value: v,
                      "aria-label": "Target size unit",
                      onChange: (s) => w(s.target.value),
                      className: "border rounded-md px-2 text-sm bg-background",
                      children: [
                        e.jsx("option", { value: "KB", children: "KB" }),
                        e.jsx("option", { value: "MB", children: "MB" }),
                      ],
                    }),
                  ],
                }),
              ],
            }),
          }),
        t === "target" &&
          e.jsxs("label", {
            className: "flex items-center gap-2 text-sm",
            children: [
              e.jsx("input", {
                type: "checkbox",
                checked: f,
                onChange: (s) => T(s.target.checked),
                "data-testid": "ci-keep-dimensions",
              }),
              " Don't change dimensions (the size limit may then be missed)",
            ],
          }),
        e.jsxs("p", {
          className: "text-xs text-muted-foreground",
          children: [
            t === "target"
              ? "Quality is lowered first; a picture is made smaller in pixels only if quality alone cannot reach the limit. "
              : "Medium, Strong and Manual quality never change pixel size. ",
            "Pictures that cannot be made smaller, and SVG files (already small vector art), are returned as they were. Stop ends the current picture at once and keeps the finished ones. Photos are saved as JPG; pictures with transparency as WebP. Metadata such as location is removed from every picture that is compressed.",
          ],
        }),
      ],
    }),
  });
}
function et() {
  const [t, r] = o.useState(!1),
    c = e.jsx(ae, { batch: t, onChange: r });
  return t
    ? e.jsxs($, {
        children: [
          c,
          e.jsx(me, {}),
          e.jsx(F, { whatIsIt: x.what, howToUse: x.how, tip: x.tip }),
        ],
      })
    : e.jsx(de, { header: c });
}
function de({ header: t }) {
  const [r, c] = o.useState(null),
    [i, m] = o.useState("medium"),
    [h, v] = o.useState([75]),
    [w, f] = o.useState("200"),
    [T, y] = o.useState("KB"),
    [s, b] = o.useState(!1),
    [a, g] = o.useState(null),
    [N, U] = o.useState(K),
    [O, C] = o.useState(0),
    P = o.useRef(null),
    [M, G] = o.useState(""),
    A = ne(a),
    Q = o.useCallback((l) => {
      const n = l[0];
      n &&
        (g(null),
        te(n)
          .then(async ({ canvas: u, width: W, height: H }) => {
            (c(n),
              _({ w: W, h: H }),
              G(URL.createObjectURL(await se(u, "image/png"))));
          })
          .catch((u) =>
            d.error(u?.message || "This file could not be opened as an image"),
          ));
    }, []),
    [S, _] = o.useState(null),
    L = () => P.current?.abort(),
    J = async () => {
      if (!r) return;
      (b(!0), C(0));
      const l = new AbortController();
      P.current = l;
      try {
        let n;
        if (i === "quality") n = await R(r, h[0] / 100);
        else if (i === "medium" || i === "strong") {
          const u = Math.round(r.size * E[i]);
          n = await z(r, u, {
            keepDimensions: B(i, N),
            onProgress: C,
            signal: l.signal,
          });
        } else {
          const u = Math.round(
            parseFloat(w || "0") * (T === "MB" ? 1048576 : 1024),
          );
          if (!u || u <= 0) {
            (d.error("Enter a valid target size"), b(!1));
            return;
          }
          n = await z(r, u, {
            keepDimensions: B(i, N),
            onProgress: C,
            signal: l.signal,
          });
        }
        (g(n),
          n.keptOriginal
            ? d.info(
                n.keptOriginal === "vector"
                  ? "SVG is already a small vector file - returned unchanged"
                  : "Couldn't make it smaller - the original is returned",
              )
            : n.alreadyUnder
              ? d.info("Already under your target - no compression needed")
              : i === "quality"
                ? d.success(
                    `Compressed! Reduced by ${((1 - n.size / r.size) * 100).toFixed(1)}%`,
                  )
                : n.metTarget && n.resized
                  ? d.success(
                      `Reached your target by resizing to ${n.width} x ${n.height} px`,
                    )
                  : n.metTarget
                    ? d.success("Compressed to your target")
                    : d.error(
                        "Couldn't fully hit the target - here's the smallest we could achieve",
                      ));
      } catch (n) {
        n?.name === "AbortError"
          ? d.info("Stopped")
          : d.error(n?.message || "Failed to compress image");
      } finally {
        b(!1);
      }
    },
    V = j;
  return e.jsxs($, {
    children: [
      t,
      e.jsx(re, {
        toolId: "compress-image",
        state: {
          hasFile: !!r,
          levelChosen: i !== "medium",
          processing: s,
          resultReady: !!a && !s,
          downloaded: A,
        },
      }),
      r
        ? e.jsxs("div", {
            className: "space-y-4",
            children: [
              M &&
                e.jsx("img", {
                  src: M,
                  alt: "Preview",
                  className: "max-h-64 mx-auto rounded-lg border",
                }),
              e.jsxs("div", {
                className: "p-4 rounded-lg border bg-card flex justify-between",
                children: [
                  e.jsxs("div", {
                    children: [
                      e.jsx("p", {
                        className: "text-sm font-medium",
                        children: r.name,
                      }),
                      e.jsxs("p", {
                        className: "text-xs text-muted-foreground",
                        children: [
                          "Original: ",
                          (r.size / 1024).toFixed(0),
                          " KB",
                        ],
                      }),
                    ],
                  }),
                  a &&
                    e.jsxs("p", {
                      className: "text-sm font-medium text-green-600",
                      children: [
                        (a.size / 1024).toFixed(a.size < 10240 ? 1 : 0),
                        " KB",
                      ],
                    }),
                ],
              }),
              e.jsx("p", {
                className: "text-xs text-muted-foreground -mt-2",
                children:
                  "Photos are saved as JPG. Pictures with a transparent background are saved as WebP so the transparency is kept. For a Custom Target, quality is lowered first and the picture is made smaller in pixels only if quality alone cannot reach your size limit. Medium, Strong and Manual Quality never change pixel size. Metadata such as location is removed.",
              }),
              i === "target" &&
                e.jsxs("label", {
                  className: "flex items-center gap-2 text-sm",
                  children: [
                    e.jsx("input", {
                      type: "checkbox",
                      checked: N,
                      onChange: (l) => {
                        (U(l.target.checked), g(null));
                      },
                      "data-testid": "ci-keep-dimensions",
                    }),
                    "Don't change dimensions",
                    S ? ` (${S.w} x ${S.h} px)` : "",
                    " - the size limit may then be missed",
                  ],
                }),
              e.jsxs("div", {
                className: "flex gap-2 flex-wrap",
                children: [
                  e.jsx(p, {
                    size: "sm",
                    variant: i === "medium" ? "default" : "outline",
                    onClick: () => {
                      (m("medium"), g(null));
                    },
                    children: "Medium (25% smaller)",
                  }),
                  e.jsx(p, {
                    size: "sm",
                    variant: i === "strong" ? "default" : "outline",
                    onClick: () => {
                      (m("strong"), g(null));
                    },
                    children: "Strong (50% smaller)",
                  }),
                  e.jsx(p, {
                    size: "sm",
                    variant: i === "quality" ? "default" : "outline",
                    onClick: () => {
                      (m("quality"), g(null));
                    },
                    children: "Manual Quality",
                  }),
                  e.jsxs(p, {
                    size: "sm",
                    variant: i === "target" ? "default" : "outline",
                    onClick: () => {
                      (m("target"), g(null));
                    },
                    className: "gap-1.5",
                    children: [
                      e.jsx(oe, { className: "h-3.5 w-3.5" }),
                      " Custom Target",
                    ],
                  }),
                ],
              }),
              i === "quality"
                ? e.jsxs("div", {
                    className: "space-y-2",
                    children: [
                      e.jsxs(k, { children: ["Quality: ", h[0], "%"] }),
                      e.jsx(D, {
                        value: h,
                        onValueChange: v,
                        min: 10,
                        max: 100,
                        step: 5,
                      }),
                    ],
                  })
                : i === "medium" || i === "strong"
                  ? e.jsxs("p", {
                      className: "text-xs text-muted-foreground",
                      children: [
                        "Targets a real ",
                        i === "medium" ? "25%" : "50%",
                        " smaller file than the original — click Compress below.",
                      ],
                    })
                  : e.jsx("div", {
                      className: "space-y-2",
                      children: e.jsxs("div", {
                        className: "flex items-end gap-2",
                        children: [
                          e.jsxs("div", {
                            children: [
                              e.jsx(k, {
                                className: "text-xs",
                                children: "Target size",
                              }),
                              e.jsxs("div", {
                                className: "flex gap-2",
                                children: [
                                  e.jsx(I, {
                                    type: "number",
                                    min: "0",
                                    step: "1",
                                    value: w,
                                    onChange: (l) => f(l.target.value),
                                    className: "w-24",
                                  }),
                                  e.jsxs("select", {
                                    value: T,
                                    onChange: (l) => y(l.target.value),
                                    className:
                                      "border rounded-md px-2 text-sm bg-background",
                                    children: [
                                      e.jsx("option", {
                                        value: "KB",
                                        children: "KB",
                                      }),
                                      e.jsx("option", {
                                        value: "MB",
                                        children: "MB",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                            ],
                          }),
                          e.jsx("div", {
                            className: "flex gap-1.5 flex-wrap pb-0.5",
                            children: ce.map((l) =>
                              e.jsx(
                                p,
                                {
                                  size: "sm",
                                  variant: "ghost",
                                  className: "h-8 text-xs",
                                  onClick: () => {
                                    (f(
                                      String(
                                        l.bytes /
                                          (l.bytes >= 1024 * 1024
                                            ? 1024 * 1024
                                            : 1024),
                                      ),
                                    ),
                                      y(l.bytes >= 1024 * 1024 ? "MB" : "KB"));
                                  },
                                  children: l.label,
                                },
                                l.label,
                              ),
                            ),
                          }),
                        ],
                      }),
                    }),
              a &&
                e.jsx("p", {
                  className: `text-xs font-medium ${a.metTarget ? "text-green-600" : "text-amber-600"}`,
                  "data-testid": "compress-result",
                  children:
                    a.keptOriginal === "vector"
                      ? "An SVG is already a small vector file, so it is returned unchanged. Turning it into a JPG would make it bigger and lose the sharp edges."
                      : a.keptOriginal === "not-smaller"
                        ? "No setting could make this picture smaller than the original, so the original is returned unchanged."
                        : a.alreadyUnder
                          ? `Your image is already under the target (${V(r.size)}) - no compression needed. The original is returned unchanged.`
                          : le(a, i, N),
                }),
              a && e.jsx(Z, { blob: a.blob }),
              e.jsx("div", {
                className: "flex gap-3",
                children: s
                  ? e.jsx(X, {
                      message: "Compressing...",
                      progress: O * 100,
                      onStop: L,
                    })
                  : a
                    ? e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(ee, {
                            blob: a.blob,
                            freeDownload: !!(a.alreadyUnder || a.keptOriginal),
                            fileName:
                              a.alreadyUnder || a.keptOriginal
                                ? r.name
                                : q(r.name, a.extension, "compressed_"),
                          }),
                          e.jsx(p, {
                            variant: "outline",
                            onClick: () => {
                              (c(null), g(null));
                            },
                            children: "New",
                          }),
                        ],
                      })
                    : e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(p, { onClick: J, children: "Compress" }),
                          e.jsx(p, {
                            variant: "outline",
                            onClick: () => c(null),
                            children: "Reset",
                          }),
                        ],
                      }),
              }),
            ],
          })
        : e.jsx(Y, {
            accept: "image/*",
            onFiles: Q,
            label: "Drop an image to compress",
            description: "JPG, PNG, WebP, HEIC (iPhone), AVIF, TIFF",
            gateAtDownload: !0,
          }),
      e.jsx(F, { whatIsIt: x.what, howToUse: x.how, tip: x.tip }),
    ],
  });
}
export { et as default };
//# sourceMappingURL=CompressImage-DzFL15aD.js.map
