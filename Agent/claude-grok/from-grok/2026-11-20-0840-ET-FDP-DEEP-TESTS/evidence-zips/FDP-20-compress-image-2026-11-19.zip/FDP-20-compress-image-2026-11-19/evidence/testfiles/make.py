# Test images for FDP-20 compress-image (Pillow + numpy-free noise).
from PIL import Image, ImageDraw, ImageFilter
import random, os
random.seed(1)
def photo(w,h):
    im=Image.effect_noise((w,h),60).convert('RGB')
    grad=Image.linear_gradient('L').resize((w,h)).convert('RGB')
    im=Image.blend(im,grad,0.5).filter(ImageFilter.GaussianBlur(1.2))
    d=ImageDraw.Draw(im); d.ellipse([w*.3,h*.3,w*.7,h*.7],fill=(200,80,60))
    return im
p=photo(4000,3000)
ex=Image.Exif(); ex[0x0112]=6; ex[0x010F]='TestCam'; ex[0x8825]={1:'N',2:(40.0,44.0,54.36),3:'W',4:(73.0,59.0,8.36)}
p.save('photo.jpg',quality=95,exif=ex)
p.save('lowq.jpg',quality=40)
p.save('photo.png')
s=Image.new('RGB',(1600,1000),(250,250,250)); d=ImageDraw.Draw(s)
for i in range(40): d.text((20,20+i*24),'Settings > Account > Billing  invoice #%05d  status: paid  $%d.00'%(i,i*7),fill=(20,20,20))
d.rectangle([900,100,1500,600],fill=(30,120,220)); s.save('screenshot.png')
l=Image.new('RGBA',(1200,1200),(0,0,0,0)); d=ImageDraw.Draw(l); d.ellipse([100,100,1100,1100],fill=(220,40,40,255)); d.text((500,580),'LOGO',fill=(255,255,255,255)); l=Image.alpha_composite(l, Image.effect_noise((1200,1200),40).convert('RGBA').point(lambda v: v) if False else l); l.save('logo.png')
fr=[photo(400,300).rotate(i*20) for i in range(8)]; fr[0].save('anim.gif',save_all=True,append_images=fr[1:],duration=120,loop=0)
p.resize((1600,1200)).save('img.webp',quality=90)
p.resize((800,600)).save('img.bmp')
p.resize((300,200)).save('small.jpg',quality=80)
open('vector.svg','w').write('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300"><rect width="400" height="300" fill="#c33"/></svg>')
open('notimage.jpg','w').write('not an image\n')
try:
    from pillow_heif import register_heif_opener; register_heif_opener(); p.resize((2000,1500)).save('photo.heic',quality=85)
except Exception as e: print('heic', e)
for f in sorted(os.listdir('.')): print(f, os.path.getsize(f))
