// compress-image: Several files with Custom target 200 KB on [photo.jpg (GPS), small_gps.jpg (GPS, already under 200 KB), logo.png]; Compress all;
// then (only if the fresh context loads with uses) one single-file Download and the ZIP; counts each; saves the files and lists ZIP entries (reads bytes only, never opens/executes them). Costs trial uses.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/20-compress-image/live/'; const T = '/workspace/deep/20-compress-image/testfiles/'; const URL = 'https://www.freedailypro.com/tool/compress-image';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const R = { t: now(), runs: [] };
 for (let i = 0; i < 8; i++) { const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await c.newPage(); p.setDefaultTimeout(15000); const r = { t: now() };
  const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
  const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 200) : null; };
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); r.start = await used();
  if (r.start >= 10) { r.note = 'loaded at 0 remaining'; R.runs.push(r); await c.close(); continue; }
  await p.getByRole('button', { name: 'Several files', exact: true }).click(); await p.waitForTimeout(800);
  await p.locator('main input[type=file]').first().setInputFiles(['photo.jpg', 'small_gps.jpg', 'logo.png'].map(f => T + f)); await p.waitForTimeout(2500);
  await p.getByRole('button', { name: 'Custom target', exact: true }).click(); await p.waitForTimeout(400);
  r.targetVal = await p.locator('main input[type=number]').first().inputValue().catch(() => null);
  await p.getByRole('button', { name: /Compress all/ }).click(); await p.waitForTimeout(20000);
  r.rows = await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*\.(jpg|png|webp)[^\n]*\n[^\n]*/g) || []).slice(0, 8));
  r.summary = await p.evaluate(() => (document.querySelector('main').innerText.match(/\d of \d done[^\n]*/) || [null])[0]);
  const one = async (rx, k) => { const ev = p.waitForEvent('download', { timeout: 8000 }).catch(() => null); await p.getByRole('button', { name: rx }).first().click(); const d = await ev; await p.waitForTimeout(1500); r[k] = { dialog: await dialog(), count: await used() }; if (d) { const fp = OUT + 'bdl-' + d.suggestedFilename(); await d.saveAs(fp); r[k].name = d.suggestedFilename(); r[k].bytes = fs.statSync(fp).size; r[k].path = fp; } if (r[k].dialog) await p.keyboard.press('Escape'); };
  await one(/^Download compressed_small_gps/, 'single'); await one(/Download all \(ZIP\)/, 'zip'); await one(/Download all \(ZIP\)/, 'zip2');
  r.t2 = now(); R.runs.push(r); console.log(JSON.stringify(r)); await c.close(); break; }
 fs.writeFileSync(OUT + 'batchdl.json', JSON.stringify(R, null, 1)); await b.close(); })();
