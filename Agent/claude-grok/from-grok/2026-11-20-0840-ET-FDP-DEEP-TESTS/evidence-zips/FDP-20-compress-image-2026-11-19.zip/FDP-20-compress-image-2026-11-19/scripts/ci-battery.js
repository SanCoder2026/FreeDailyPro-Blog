// compress-image battery: one fresh context per case from ci-cases.json (argv[2] = comma IDs). Compress costs no trial use (gate is at Download); no download is made.
// Output captured via an init script hooking canvas.toBlob; the blob whose size equals the result line's byte count is saved.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/20-compress-image/live/'; const T = '/workspace/deep/20-compress-image/testfiles/';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const ids = process.argv[2] ? process.argv[2].split(',') : null; const tag = ids ? '-' + ids.join('_') : '';
const cases = JSON.parse(fs.readFileSync(__dirname + '/ci-cases.json')).filter(c => !ids || ids.includes(c.id));
const HOOK = `(() => { window.__blobs = []; const o = HTMLCanvasElement.prototype.toBlob; HTMLCanvasElement.prototype.toBlob = function (cb, ...a) { const w = this.width, h = this.height; return o.call(this, b => { if (b) window.__blobs.push({ b, w, h, t: Date.now(), req: a[0] || 'image/png', q: a[1] }); cb(b); }, ...a); }; })();`;
(async () => {
  const b = await chromium.launch(); const R = { t: now(), cases: [] }; const save = () => fs.writeFileSync(OUT + 'battery' + tag + '.json', JSON.stringify(R, null, 1));
  for (const c of cases) {
    const r = { ...c, t: now() }; const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); await ctx.addInitScript(HOOK); const p = await ctx.newPage(); p.setDefaultTimeout(10000);
    const toasts = []; const grab = async () => { const tt = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim())).catch(() => []); tt.forEach(x => { if (!toasts.includes(x)) toasts.push(x); }); };
    try {
      await p.goto('https://www.freedailypro.com/tool/compress-image', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
      if (!R.ls0) R.ls0 = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
      r.ls0 = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
      await p.locator('main input[type=file]').first().setInputFiles(T + c.file); await p.waitForTimeout(3500); await grab();
      r.original = await p.evaluate(() => (document.querySelector('main').innerText.match(/Original: [^\n]*/) || [null])[0]);
      r.errText = await p.evaluate(() => [...document.querySelectorAll('main p, main [role=alert]')].map(e => e.innerText.trim()).filter(t => t.length < 220 && /could not|can't|cannot|not supported|damaged|unusual|Unsupported|error/i.test(t)).slice(0, 3));
      const mb = { medium: 'Medium (25% smaller)', strong: 'Strong (50% smaller)', quality: 'Manual Quality', target: 'Custom Target' }[c.mode];
      const mbtn = p.getByRole('button', { name: mb, exact: true }); r.modeButton = await mbtn.count();
      if (!r.modeButton) throw new Error('no mode buttons: ' + (r.errText || []).join(' | '));
      await mbtn.click(); await p.waitForTimeout(300);
      r.ariaPressed = await mbtn.getAttribute('aria-pressed');
      if (c.mode === 'quality') { const s = p.locator('main [role=slider]').first(); await s.focus(); await s.press(c.q); await p.waitForTimeout(200); r.qLabel = await p.evaluate(() => (document.querySelector('main').innerText.match(/Quality: \d+%/) || [null])[0]); }
      if (c.mode === 'target') {
        r.keepBox = await p.locator('[data-testid=ci-keep-dimensions]').count();
        if (c.keep) await p.locator('[data-testid=ci-keep-dimensions]').click();
        if (c.preset) await p.getByRole('button', { name: c.preset, exact: true }).click();
        else { const inp = p.locator('main input[type=number]').first(); await inp.fill(c.target); await p.locator('main select').first().selectOption(c.unit); }
        await p.waitForTimeout(300);
        r.targetField = [await p.locator('main input[type=number]').first().inputValue(), await p.locator('main select').first().inputValue()];
        r.targetA11y = await p.locator('main input[type=number]').first().evaluate(e => ({ label: e.labels && e.labels.length ? e.labels[0].innerText : null, aria: e.getAttribute('aria-label'), id: e.id }));
      }
      const cbtn = p.getByRole('button', { name: 'Compress', exact: true }); r.compressEnabled = await cbtn.isEnabled();
      const t0 = Date.now();
      if (r.compressEnabled) {
        await cbtn.click();
        if (c.stop) { await p.waitForTimeout(700); const sb = p.getByRole('button', { name: /^Stop/ }); r.stopVisible = await sb.count(); if (r.stopVisible) await sb.first().click(); await p.waitForTimeout(1500); }
        else await p.locator('[data-testid=compress-result]').waitFor({ timeout: 60000 }).catch(() => {});
        r.ms = Date.now() - t0; await p.waitForTimeout(800); await grab();
        r.result = await p.locator('[data-testid=compress-result]').innerText().catch(() => null);
        r.resultBlock = await p.evaluate(() => { const t = document.querySelector('main').innerText; const i = t.indexOf('Original:'); return t.slice(i, i + 900); });
        const m = r.result && r.result.replace(/,/g, '').match(/\((\d+) bytes\)|(\d{3,}) bytes/); r.bytes = m ? +(m[1] || m[2]) : null;
        const out = await p.evaluate(async bytes => { const L = window.__blobs; const x = (bytes && L.find(z => z.b.size === bytes)) || null; const info = { n: L.length, sizes: L.map(z => [z.w, z.h, z.b.type, z.b.size, z.q]).slice(-40) }; if (!x) return { info }; const bb = new Uint8Array(await x.b.arrayBuffer()); let s = ''; for (let i = 0; i < bb.length; i += 8192) s += String.fromCharCode.apply(null, bb.subarray(i, i + 8192)); return { info, type: x.b.type, w: x.w, h: x.h, q: x.q, b64: btoa(s) }; }, r.bytes);
        r.blobInfo = out.info; if (out.b64) { const ext = (out.type.split('/')[1] || 'bin').replace('jpeg', 'jpg'); fs.writeFileSync(OUT + 'out-' + c.id + '.' + ext, Buffer.from(out.b64, 'base64')); r.outType = out.type; r.canvas = [out.w, out.h]; r.quality = out.q; r.outFile = 'out-' + c.id + '.' + ext; }
        if (!out.b64) { const pv = await p.evaluate(async () => { const ims = [...document.querySelectorAll('main img')].filter(i => i.src.startsWith('blob:')); const res = []; for (const im of ims) { const bl = await (await fetch(im.src)).blob(); const bb = new Uint8Array(await bl.arrayBuffer()); let s = ''; for (let i = 0; i < bb.length; i += 8192) s += String.fromCharCode.apply(null, bb.subarray(i, i + 8192)); res.push({ type: bl.type, size: bl.size, alt: im.alt, b64: btoa(s) }); } return res; }); r.previewBlobs = pv.map((x, i) => { const f = 'preview-' + c.id + '-' + i + '.' + ((x.type.split('/')[1] || 'bin').replace('jpeg', 'jpg')); fs.writeFileSync(OUT + f, Buffer.from(x.b64, 'base64')); return { type: x.type, size: x.size, alt: x.alt, file: f }; }); }
        r.buttons = await p.evaluate(() => [...document.querySelectorAll('main button, main a')].map(b => b.innerText.trim()).filter(x => /Download|Day Pass|Drive|cloud|New|Share|Copy|Print|Save/i.test(x)));
        r.dlName = await p.evaluate(() => [...document.querySelectorAll('main a[download]')].map(a => a.getAttribute('download')));
      }
      await grab(); r.toasts = toasts; await p.screenshot({ path: OUT + 'res-' + c.id + '.png', fullPage: false });
      r.ls1 = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
    } catch (e) { r.err = String(e).slice(0, 220); r.toasts = toasts; await p.screenshot({ path: OUT + 'err-' + c.id + '.png' }).catch(() => {}); }
    R.cases.push(r); save(); console.log(r.id, r.original, '|', r.result, '|', r.outType || '', r.canvas || '', r.quality ?? '', r.ms || '', r.err || '', toasts.join(' / ')); await ctx.close();
  }
  R.t1 = now(); save(); await b.close();
})();
