// compress-image: Firefox and WebKit desktop: Medium on photo.jpg, Custom Target 100 KB on logo.png (WebP support differs), HEIC open. No use spent.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/20-compress-image/live/'; const T = '/workspace/deep/20-compress-image/testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const R = { t: now() };
(async () => { for (const eng of ['firefox', 'webkit']) { const b = await pw[eng].launch(); const p = await (await b.newContext({ viewport: { width: 1440, height: 900 } })).newPage(); p.setDefaultTimeout(15000); const r = {}; let crashed = false; p.on('crash', () => crashed = true);
  const res = async () => { await p.locator('[data-testid=compress-result]').waitFor({ timeout: 60000 }).catch(() => {}); await p.waitForTimeout(800); return p.locator('[data-testid=compress-result]').innerText().catch(() => null); };
  try { await p.goto('https://www.freedailypro.com/tool/compress-image', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
   await p.locator('main input[type=file]').first().setInputFiles(T + 'photo.jpg'); await p.waitForTimeout(3000); r.original = await p.evaluate(() => (document.querySelector('main').innerText.match(/Original: [^\n]*/) || [null])[0]);
   await p.getByRole('button', { name: 'Compress', exact: true }).click(); r.medium = await res();
   await p.getByRole('button', { name: 'New', exact: true }).click().catch(() => {}); await p.waitForTimeout(800);
   await p.locator('main input[type=file]').first().setInputFiles(T + 'logo.png'); await p.waitForTimeout(3000);
   await p.getByRole('button', { name: 'Custom Target', exact: true }).click(); await p.locator('main input[type=number]').first().fill('5'); await p.getByRole('button', { name: 'Compress', exact: true }).click(); r.logo = await res();
   await p.getByRole('button', { name: 'New', exact: true }).click().catch(() => {}); await p.waitForTimeout(800);
   await p.locator('main input[type=file]').first().setInputFiles(T + 'photo.heic'); await p.waitForTimeout(6000); r.heic = await p.evaluate(() => (document.querySelector('main').innerText.match(/Original: [^\n]*|[^\n]*(damaged|could not|cannot)[^\n]*/i) || [null])[0]);
   await p.screenshot({ path: OUT + 'browser-' + eng + '.png' }); } catch (e) { r.err = String(e).slice(0, 150); }
  r.crashed = crashed; R[eng] = r; await b.close().catch(() => {}); }
 R.t2 = now(); fs.writeFileSync(OUT + 'browsers.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); })();
