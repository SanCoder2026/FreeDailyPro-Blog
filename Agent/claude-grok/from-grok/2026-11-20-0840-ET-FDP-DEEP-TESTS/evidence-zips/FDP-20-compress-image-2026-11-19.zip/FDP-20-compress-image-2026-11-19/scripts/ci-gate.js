// compress-image: starting count; keyboard to drop zone; mode buttons by keyboard + state exposure; target field labels; axe idle/result; live regions;
// Download / Drive / cloud at the starting count (stops at the first dialog; at 0: cap dialog -> Buy Day Pass -> email prompt, types nothing);
// Several files: 6 files (trial says up to 5), Compress all, buttons, ZIP download gate; phones. Compress itself costs no trial use.
const { chromium, devices } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/20-compress-image/live/'; const T = '/workspace/deep/20-compress-image/testfiles/'; const URL = 'https://www.freedailypro.com/tool/compress-image';
const AXE = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8'); const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const axe = async p => { await p.addScriptTag({ content: AXE }); return p.evaluate(async () => (await axe.run(document.querySelector('main'), { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'best-practice'] }, resultTypes: ['violations'] })).violations.map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length, t: v.nodes.slice(0, 4).map(n => n.target.join(' ')) }))); };
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams)=[^&]*/g, '$1=REDACTED').slice(0, 160);
(async () => { const b = await chromium.launch(); const R = { t: now() };
 const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await c.newPage(); p.setDefaultTimeout(12000);
 await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 R.start = await used(); R.strip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]); R.axeIdle = await axe(p);
 let chooser = false; p.on('filechooser', () => { chooser = true; }); const seq = [];
 for (let i = 0; i < 60; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('role') || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50).replace(/\n/g, ' '); }); seq.push(a); if (/Drop an image/i.test(a)) { await p.keyboard.press('Enter'); await p.waitForTimeout(1200); seq.push('ENTER -> chooser=' + chooser); break; } }
 R.kbd = { tabs: seq.length, last: seq.slice(-3), chooser };
 await p.locator('main input[type=file]').first().setInputFiles(T + 'photo.jpg'); await p.waitForTimeout(3000);
 R.modeState = await p.evaluate(() => [...document.querySelectorAll('main button')].filter(b => /smaller|Manual Quality|Custom Target/.test(b.innerText)).map(b => ({ t: b.innerText.trim(), pressed: b.getAttribute('aria-pressed'), checked: b.getAttribute('aria-checked'), role: b.getAttribute('role'), cls: /bg-primary/.test(b.className) })));
 // keyboard: focus Strong, press Enter, then Custom Target via keyboard
 await p.getByRole('button', { name: 'Strong (50% smaller)', exact: true }).focus(); await p.keyboard.press('Enter'); await p.waitForTimeout(300);
 R.kbdStrong = await p.evaluate(() => (document.querySelector('main').innerText.match(/Targets a real [^\n]*/) || [null])[0]);
 await p.getByRole('button', { name: 'Custom Target', exact: true }).focus(); await p.keyboard.press('Space'); await p.waitForTimeout(300);
 R.targetFields = await p.evaluate(() => [...document.querySelectorAll('main input, main select')].filter(e => e.type !== 'file').map(e => ({ tag: e.tagName, type: e.type, testid: e.dataset.testid || null, id: e.id, label: e.labels && e.labels.length ? e.labels[0].innerText.trim().slice(0, 60) : null, aria: e.getAttribute('aria-label'), value: e.value })));
 R.keepText = await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*change dimensions[^\n]*/) || [null])[0]);
 R.axeTarget = await axe(p);
 await p.getByRole('button', { name: 'Medium (25% smaller)', exact: true }).click(); await p.getByRole('button', { name: 'Compress', exact: true }).click();
 await p.locator('[data-testid=compress-result]').waitFor({ timeout: 60000 }); await p.waitForTimeout(1000);
 R.result = await p.locator('[data-testid=compress-result]').innerText();
 R.liveRegions = await p.evaluate(() => [...document.querySelectorAll('main [aria-live],main [role=status],main [role=alert]')].map(e => ({ live: e.getAttribute('aria-live'), role: e.getAttribute('role'), text: e.innerText.slice(0, 80) })));
 R.resultInLive = await p.evaluate(() => !!document.querySelector('[data-testid=compress-result]').closest('[aria-live],[role=status],[role=alert]'));
 R.focusAfter = await p.evaluate(() => document.activeElement.tagName + ' ' + document.activeElement.innerText.slice(0, 30));
 R.resultImgAlt = await p.evaluate(() => [...document.querySelectorAll('main img')].filter(i => i.src.startsWith('blob:')).map(i => i.alt));
 R.resultBlock = await p.evaluate(() => { const t = document.querySelector('main').innerText; const i = t.indexOf('Original:'); return t.slice(i, i + 1200); });
 R.resultButtons = await p.evaluate(() => [...document.querySelectorAll('main button, main a')].map(b => b.innerText.trim()).filter(x => /Download|Drive|cloud|Continue|New|Pass|Share|Copy|Print|Next/i.test(x) && x.length < 80));
 R.axeResult = await axe(p); await p.screenshot({ path: OUT + 'result-desktop.png', fullPage: true });
 const act = async (name, rx) => { const r = { before: await used() }; const loc = p.getByRole('button', { name: rx }).first(); if (!(await loc.count())) { r.missing = true; return r; }
   const pop = c.waitForEvent('page', { timeout: 5000 }).catch(() => null); const dl = p.waitForEvent('download', { timeout: 5000 }).catch(() => null); const url0 = p.url(); await loc.click(); const [pg, d] = await Promise.all([pop, dl]); await p.waitForTimeout(2000);
   r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null; r.download = d ? d.suggestedFilename() : null; if (pg) { r.popup = red(pg.url()); await pg.close(); }
   if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + '.png' });
   if (name === 'download' && r.dialog) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); r.dayPass = { dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); } }
   await esc(); if (r.url) { await p.goBack().catch(() => {}); await p.waitForTimeout(2500); } return r; };
 R.download = await act('download', /^Download/);
 R.drive = await act('drive', /Save to Google Drive/);
 R.cloud = await act('cloud', /Save to my cloud storage/);
 R.end = await used(); await c.close();
 // Several files
 { const c3 = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const q = await c3.newPage(); q.setDefaultTimeout(12000); const r = {};
  try { await q.goto(URL, { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4500); await q.getByRole('button', { name: 'Several files', exact: true }).click(); await q.waitForTimeout(800);
   r.idle = await q.evaluate(() => document.querySelector('main').innerText.slice(0, 1500));
   const files = ['photo.jpg', 'lowq.jpg', 'logo.png', 'screenshot.png', 'img.webp', 'small.jpg'].map(f => T + f);
   const inp = q.locator('main input[type=file]').first(); r.multiple = await inp.getAttribute('multiple'); await inp.setInputFiles(files); await q.waitForTimeout(3000);
   r.toasts = await q.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim()));
   r.listed = await q.evaluate(() => document.querySelector('main').innerText.match(/[^\n]*\.(jpg|png|webp)[^\n]*/g));
   const all = q.getByRole('button', { name: /Compress all/ }); r.compressAll = await all.count();
   if (r.compressAll) { await all.first().click(); await q.waitForTimeout(25000); }
   r.after = await q.evaluate(() => { const t = document.querySelector('main').innerText; return t.slice(0, 3000); });
   r.buttons = await q.evaluate(() => [...document.querySelectorAll('main button, main a')].map(b => (b.innerText.trim() || b.getAttribute('aria-label') || '')).filter(x => /Download|ZIP|Drive|cloud|New|original|Stop|Clear|Remove/i.test(x) && x.length < 80));
   r.includeOriginals = await q.evaluate(() => [...document.querySelectorAll('main label')].map(l => l.innerText.trim()).filter(x => /original/i.test(x)));
   await q.screenshot({ path: OUT + 'batch-result.png', fullPage: true });
   const zb = q.getByRole('button', { name: /ZIP/ }).first(); if (await zb.count()) { const dl = q.waitForEvent('download', { timeout: 5000 }).catch(() => null); await zb.click(); const d = await dl; await q.waitForTimeout(1500); const dd = q.locator('[role=dialog],[role=alertdialog]'); r.zip = { download: d ? d.suggestedFilename() : null, dialog: (await dd.count()) ? (await dd.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 400) : null, used: JSON.parse(await q.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday }; await q.screenshot({ path: OUT + 'batch-zip-gate.png' }); }
  } catch (e) { r.err = String(e).slice(0, 200); }
  R.batch = r; await c3.close(); }
 for (const [nm, d] of [['iphone-se', devices['iPhone SE']], ['pixel-7', devices['Pixel 7']]]) { const { defaultBrowserType, ...dd } = d; const c2 = await b.newContext(dd); const q = await c2.newPage(); q.setDefaultTimeout(12000);
  await q.goto(URL, { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4000);
  const idle = await q.evaluate(() => { const z = [...document.querySelectorAll('main [role=button]')].find(e => /Drop an image/i.test(e.innerText)); return { vh: innerHeight, dropTop: z ? Math.round(z.getBoundingClientRect().top + scrollY) : null }; });
  await q.locator('main input[type=file]').first().setInputFiles(T + 'photo.jpg'); await q.waitForTimeout(2500); await q.getByRole('button', { name: 'Custom Target', exact: true }).click(); await q.waitForTimeout(500);
  const lay = await q.evaluate(() => { const f = s => [...document.querySelectorAll('main button')].find(b => b.innerText.trim().startsWith(s)); const t = e => e ? Math.round(e.getBoundingClientRect().top + scrollY) : null; const mb = [...document.querySelectorAll('main button')].filter(b => /smaller|Manual Quality|Custom Target|KB|MB/.test(b.innerText)).map(b => { const r = b.getBoundingClientRect(); return [b.innerText.trim(), Math.round(r.width), Math.round(r.height)]; }); return { compressTop: t(f('Compress')), overflowX: document.documentElement.scrollWidth > innerWidth + 1, buttons: mb }; });
  await q.getByRole('button', { name: 'Compress', exact: true }).click(); await q.locator('[data-testid=compress-result]').waitFor({ timeout: 60000 }).catch(() => {}); await q.waitForTimeout(800);
  await q.screenshot({ path: OUT + `layout-${nm}-result.png`, fullPage: true }); R[nm] = { ...idle, ...lay, result: await q.locator('[data-testid=compress-result]').innerText().catch(() => null) }; await c2.close(); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate-kbd.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
