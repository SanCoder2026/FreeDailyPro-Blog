// compress-image: invalid Custom Target values (0, -5, empty, 0.4 KB): toast captured right after Compress; inline error / aria-invalid checked. No use spent.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/20-compress-image/live/'; const T = '/workspace/deep/20-compress-image/testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); p.setDefaultTimeout(12000); const R = { t: now(), cases: [] };
 await p.goto('https://www.freedailypro.com/tool/compress-image', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 await p.locator('main input[type=file]').first().setInputFiles(T + 'photo.jpg'); await p.waitForTimeout(2500); await p.getByRole('button', { name: 'Custom Target', exact: true }).click();
 for (const v of ['0', '-5', '', '0.4', '99999']) { const inp = p.locator('main input[type=number]').first(); await inp.fill(v); await p.waitForTimeout(200);
  await p.getByRole('button', { name: 'Compress', exact: true }).click(); await p.waitForTimeout(700);
  const r = { v, toast: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim())), toastLive: await p.evaluate(() => { const t = document.querySelector('[data-sonner-toaster]'); const s = t && t.closest('[aria-live]'); return s ? s.getAttribute('aria-live') : (t ? t.getAttribute('aria-live') : null); }), ariaInvalid: await inp.getAttribute('aria-invalid'), inline: await p.evaluate(() => [...document.querySelectorAll('main p')].map(e => e.innerText).filter(t => /valid|must|greater/i.test(t) && t.length < 150)) };
  await p.locator('[data-testid=compress-result]').waitFor({ timeout: 20000 }).catch(() => {}); r.result = await p.locator('[data-testid=compress-result]').innerText().catch(() => null); if (v === '0') await p.screenshot({ path: OUT + 'invalid-0.png' });
  R.cases.push(r); console.log(JSON.stringify(r)); await p.waitForTimeout(4500); }
 fs.writeFileSync(OUT + 'invalid.json', JSON.stringify(R, null, 1)); await b.close(); })();
