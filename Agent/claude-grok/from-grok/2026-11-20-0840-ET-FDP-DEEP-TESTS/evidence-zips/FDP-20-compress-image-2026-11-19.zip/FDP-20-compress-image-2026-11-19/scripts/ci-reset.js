// compress-image, run when uses are left (after the 7:00 PM ET reset, or a fresh context that loads with uses): Medium on photo.jpg with EXIF/GPS, Download twice (count each, file name, bytes vs the in-memory result),
// then Drive (stops at Google sign-in); then Several files x3 -> ZIP (count). Costs trial uses. Never opens or executes the downloaded files beyond reading bytes.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/20-compress-image/live/'; const T = '/workspace/deep/20-compress-image/testfiles/'; const URL = 'https://www.freedailypro.com/tool/compress-image';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams)=[^&]*/g, '$1=REDACTED').slice(0, 160);
(async () => { const b = await chromium.launch(); const R = { t: now(), runs: [] };
 for (let i = 0; i < 2; i++) { const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await c.newPage(); p.setDefaultTimeout(15000); const r = { t: now() };
  const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
  const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null; };
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); r.start = await used(); r.strip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]);
  if (r.start >= 10) { r.note = 'loaded at 0 remaining; nothing to observe'; R.runs.push(r); await c.close(); continue; }
  await p.locator('main input[type=file]').first().setInputFiles(T + 'photo.jpg'); await p.waitForTimeout(2500);
  await p.getByRole('button', { name: 'Compress', exact: true }).click(); await p.locator('[data-testid=compress-result]').waitFor({ timeout: 60000 }); r.afterCompress = await used();
  r.result = await p.locator('[data-testid=compress-result]').innerText(); const m = r.result.replace(/,/g, '').match(/\((\d+) bytes\)/); r.resultBytes = m ? +m[1] : null;
  for (const k of ['dl1', 'dl2']) { const ev = p.waitForEvent('download', { timeout: 8000 }).catch(() => null); await p.getByRole('button', { name: /^Download/ }).first().click(); const d = await ev; await p.waitForTimeout(2000);
   r[k] = { dialog: await dialog(), count: await used() }; if (d) { const fp = OUT + 'reset-' + k + '-' + d.suggestedFilename(); await d.saveAs(fp); r[k].name = d.suggestedFilename(); r[k].bytes = fs.statSync(fp).size; r[k].sameAsResult = r[k].bytes === r.resultBytes; } if (r[k].dialog) { await p.keyboard.press('Escape'); break; } }
  const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); await p.getByRole('button', { name: /Save to Google Drive/ }).click().catch(() => {}); const pg = await pop; await p.waitForTimeout(2500);
  r.drive = { dialog: await dialog(), count: await used(), popup: pg ? red(pg.url()) : null }; if (pg) await pg.close(); await p.keyboard.press('Escape');
  // unchanged original with GPS: does the downloaded compressed_small_gps.jpg still carry GPS? (read bytes only)
  try { await p.getByRole('button', { name: 'New', exact: true }).click(); await p.waitForTimeout(800); await p.locator('main input[type=file]').first().setInputFiles(T + 'small_gps.jpg'); await p.waitForTimeout(2500);
   await p.getByRole('button', { name: 'Custom Target', exact: true }).click(); await p.locator('main input[type=number]').first().fill('200'); await p.getByRole('button', { name: 'Compress', exact: true }).click(); await p.locator('[data-testid=compress-result]').waitFor({ timeout: 30000 });
   const ev = p.waitForEvent('download', { timeout: 8000 }).catch(() => null); await p.getByRole('button', { name: /^Download/ }).first().click(); const d = await ev; await p.waitForTimeout(1500);
   r.gps = { dialog: await dialog(), count: await used() }; if (d) { const fp = OUT + 'reset-gps-' + d.suggestedFilename(); await d.saveAs(fp); r.gps.name = d.suggestedFilename(); r.gps.identicalToInput = Buffer.compare(fs.readFileSync(fp), fs.readFileSync(T + 'small_gps.jpg')) === 0; { const bb = fs.readFileSync(fp); r.gps.hasGpsTag = bb.includes(Buffer.from([0x88, 0x25])) || bb.includes(Buffer.from([0x25, 0x88])); } } } catch (e) { r.gpsErr = String(e).slice(0, 150); }
  r.t2 = now(); R.runs.push(r); console.log(JSON.stringify(r)); await c.close(); if (r.dl1) break; }
 fs.writeFileSync(OUT + 'reset.json', JSON.stringify(R, null, 1)); await b.close(); })();
