Sent: 2026-11-21 20:04 ET

# RERUN-FINDINGS

This package is version v2 (FDP-20-compress-image-2026-11-21-v2.zip). It **supersedes/extends**: FDP-20-compress-image-2026-11-19.zip. Earlier zips are untouched (frozen); anything not mentioned here is unchanged from them.

Run 19:23 ET, `ci-reset.js`, fresh Chromium context loaded at 10 remaining (display).
- Compress itself free (count 0 after compress).
- **First single-file Download** `compressed_photo.jpg`: 1,888,315 bytes = result line (`sameAsResult` true). The display counter went 0 -> **10** after this one download (the known +10 jump; not 0 -> 1).
- **Second Download of same result: no dialog, no further change** (10 -> 10, but the counter is already at the cap so a charge cannot be distinguished here; unverified).
- Save to Google Drive: opens Google sign-in popup, no dialog, no charge (stopped there).
- `small_gps.jpg` (already under target): downloaded file is **byte-identical to the input** (`identicalToInput` true) and **still has the GPS tag** (`hasGpsTag` true). Needs Claude's decision: the original is returned unchanged, GPS included.
- Mark check on the saved JPG not performed (not re-verified in this run).
Evidence: live/reset.json.
