import { r as m, j as e } from "./vendor-react-D01g8YgM.js";
import {
  k as Ue,
  P as ze,
  f as Ct,
  S as Pt,
  t as kt,
  d as Tt,
  u as Se,
} from "./index-BRvxULIc.js";
import { p as Ye } from "./pageView-BQIwVYOi.js";
import { s as Dt, a as Mt, m as It } from "./pdfMetadata-CcxIhQF2.js";
import { T as $t, F as At, f as Rt, d as Et } from "./ToolPage-DS5jbfzr.js";
import { t as Ot } from "./fileHandoff-RQJcoDih.js";
import {
  f as R,
  e as U,
  I as ne,
  B as z,
  aq as Lt,
  D as _t,
  aJ as Bt,
} from "./index-D2ZT81un.js";
import {
  S as He,
  a as Ve,
  b as We,
  c as Ze,
  d as se,
} from "./select-DC0cHVOZ.js";
import { l as Ge } from "./utils-s8ucLyj8.js";
import { drawTextAnywhere as q } from "./drawTextAnywhere-DcuP6lHH.js";
import { T as Ut } from "./ToolInfoSection-M0kcUBq8.js";
import { M as zt } from "./map-pin-DiPhQKiV.js";
import { T as Yt } from "./trash-2-BJfoOy34.js";
import { C as Ht } from "./copy-DxyF2bO9.js";
import { E as Vt } from "./eraser-CnNzkt7q.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./useUploadApi-CeBVbB2U.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-mA9gIB_c.js";
import "./share-2-wJ7OG3q6.js";
import "./workflowCta-QcLjv4ms.js";
import "./UsageAndUpgradeStrip-Ckl_cEoN.js";
import "./access-BBg1iIm1.js";
import "./useAdminAccess-D2xxeUJv.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-BaZhqv4P.js";
import "./FaqSection-DgbFc-d2.js";
import "./ToolVideoEmbed-DltoCXpM.js";
import "./GuideLinks-BsEl-oB0.js";
import "./blog-Cqpj3gtZ.js";
import "./info-BGlOhDp4.js";
import "./productCards-CAZfINO_.js";
import "./layers-B7zHnkyf.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./chevron-up-Bx33pgGu.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./fontkit.es-DA-3qwB1.js";
import "./CollapsibleText-CmqWEytu.js";
const Wt = ["signature", "initial", "date", "fullName", "initialsText"],
  Zt = /^fdp_(signature|initial|date|fullName|initialsText)_(\d+)_other$/,
  Gt = (n, i) => `fdp_${n}_${i}_other`;
function Xe(n) {
  const i = Zt.exec(n);
  return i && Wt.includes(i[1]) ? { type: i[1], n: Number(i[2]) } : null;
}
const Xt = {
  signature: "Sign here",
  initial: "Initial here",
  date: "Date",
  fullName: "Full name",
  initialsText: "Initials",
};
function Jt(n, i, l) {
  if (!(n > 0) || !(i > 0) || !(l > 0))
    return { width: Math.max(0, n), height: Math.max(0, i) };
  let h = n,
    c = h * l;
  return (c > i && ((c = i), (h = c / l)), { width: h, height: c });
}
function Ce(n, i, l, h) {
  return { x: n - l / 2, y: i - h / 2 };
}
function Qt(n) {
  if (n.length === 0)
    return "Tap where you want to sign: add a Signature field above, then click the page.";
  const i = n.filter((l) => l.xFrac === null).length;
  return i > 0
    ? `Place all fields on the page first (${i} not yet placed).`
    : null;
}
const qt = {
  signature: "Signature",
  initial: "Initials",
  date: "Date",
  fullName: "Printed name",
  initialsText: "Typed initials",
};
async function Kt(n) {
  const i = await globalThis.crypto.subtle.digest(
    "SHA-256",
    n.buffer.slice(n.byteOffset, n.byteOffset + n.byteLength),
  );
  return Array.from(new Uint8Array(i))
    .map((l) => l.toString(16).padStart(2, "0"))
    .join("");
}
const ie = (n) => String(n).padStart(2, "0");
function ea(n) {
  return `${n.getUTCFullYear()}-${ie(n.getUTCMonth() + 1)}-${ie(n.getUTCDate())} ${ie(n.getUTCHours())}:${ie(n.getUTCMinutes())}:${ie(n.getUTCSeconds())} UTC`;
}
function ta(n) {
  const i = new Map();
  for (const c of n.marks) {
    const x = qt[c.type];
    i.set(x, [...(i.get(x) ?? []), c.page]);
  }
  const l = Array.from(i.entries())
      .map(
        ([c, x]) =>
          `${c} x${x.length} (page${new Set(x).size === 1 ? "" : "s"} ${Array.from(
            new Set(x),
          )
            .sort((f, N) => f - N)
            .join(", ")})`,
      )
      .join("; "),
    h = [
      { label: "Document", value: n.documentName },
      { label: "Pages when opened", value: String(n.pageCount) },
      {
        label: "Fingerprint (SHA-256) of the document as opened",
        value: n.originalSha256,
      },
      {
        label: "Signed by",
        value: n.signerName.trim() || "(name not entered)",
      },
      {
        label: "Signed at",
        value: `${ea(n.signedAt)}${n.timeZone ? ` (device time zone ${n.timeZone})` : ""}`,
      },
      { label: "Marks added", value: l || "none" },
    ];
  return (
    n.fieldsForOthers > 0 &&
      h.push({
        label: "Left for other people",
        value: `${n.fieldsForOthers} empty field${n.fieldsForOthers === 1 ? "" : "s"}`,
      }),
    h.push({
      label: "Where it was signed",
      value:
        "On this device, in the web browser. The document was not uploaded to any server.",
    }),
    {
      title: "Signing record",
      rows: h,
      notes: [
        "This page records what was done when the file was signed. The fingerprint lets anyone check that the document they were given is the one that was opened here: the same file always gives the same fingerprint.",
        "The marks are stamped images and text. This is not a certified digital signature and it does not prove the signer's identity. Where the law or a contract asks for a qualified or certified signature, use a service that provides one.",
      ],
    }
  );
}
function Je(n, i) {
  const l = [];
  for (const h of n.split(`
`)) {
    let c = "";
    for (const x of h.split(/\s+/).filter(Boolean)) {
      let f = x;
      for (; f.length > i;)
        (c && (l.push(c), (c = "")), l.push(f.slice(0, i)), (f = f.slice(i)));
      c
        ? (c + " " + f).length <= i
          ? (c += " " + f)
          : (l.push(c), (c = f))
        : (c = f);
    }
    l.push(c);
  }
  return l;
}
async function aa(n, i) {
  const l = n.getPage(0),
    { width: h, height: c } = l.getSize(),
    x = Math.max(300, Math.min(h, 900)),
    f = Math.max(400, Math.min(c, 1200)),
    { title: N, rows: Y, notes: H } = ta(i),
    M = 54,
    C = 14,
    re = Math.max(40, Math.floor((x - M * 2) / 5.4));
  let I = n.addPage([x, f]),
    K = 1,
    j = f - M;
  const oe = (E) => {
    j - E < M && ((I = n.addPage([x, f])), K++, (j = f - M));
  };
  (await q(n, I, N, {
    x: M,
    y: j - 16,
    size: 18,
    bold: !0,
    color: { r: 0.1, g: 0.1, b: 0.15 },
    env: null,
  }),
    (j -= 40));
  for (const E of Y) {
    const O = Je(E.value, re);
    (oe(C * (O.length + 1) + 8),
      await q(n, I, E.label, {
        x: M,
        y: j - 10,
        size: 9,
        bold: !0,
        color: { r: 0.35, g: 0.35, b: 0.4 },
        env: null,
      }),
      (j -= C));
    for (const V of O)
      (await q(n, I, V, {
        x: M,
        y: j - 10,
        size: 10,
        color: { r: 0.1, g: 0.1, b: 0.1 },
        env: null,
      }),
        (j -= C));
    j -= 8;
  }
  j -= 8;
  for (const E of H) {
    const O = Je(E, re + 4);
    oe(C * O.length + 8);
    for (const V of O)
      (await q(n, I, V, {
        x: M,
        y: j - 10,
        size: 9,
        color: { r: 0.3, g: 0.3, b: 0.35 },
        env: null,
      }),
        (j -= 12));
    j -= 8;
  }
  return K;
}
const na = 1.5,
  Qe = [
    { family: "Dancing Script", label: "Flowing" },
    { family: "Caveat", label: "Quick pen" },
    { family: "Homemade Apple", label: "Handwritten" },
    { family: "Great Vibes", label: "Formal" },
    { family: "Sacramento", label: "Slim script" },
    { family: "Reenie Beanie", label: "Scribble" },
  ],
  sa = {
    "Dancing Script": "dancing-script-latin-600",
    Caveat: "caveat-latin-600",
    "Homemade Apple": "homemade-apple-latin-400",
    "Great Vibes": "great-vibes-latin-400",
    Sacramento: "sacramento-latin-400",
    "Reenie Beanie": "reenie-beanie-latin-400",
  },
  ia = Object.entries(sa)
    .map(
      ([n, i]) =>
        `@font-face{font-family:'${n}';src:url(/fonts/signature/${i}-normal.woff2) format('woff2');font-display:swap}`,
    )
    .join(""),
  Pe = {
    what: "Adds one or more signature, initial, date, or name fields to a PDF — for your own signature, embedded directly into the document, or for someone else's, left as empty form fields for them to fill in, in any PDF reader or in this same tool.",
    how: "Enter your name and initials, set up how your signature and initials should look (drawn, typed in a signature-style font, or an image you already have), then add fields to the list: pick a type, who it's for, and which page. Click the page preview to place each field, then generate the PDF. If any fields are marked for someone else, send them the downloaded file (and the Sign PDF link if you like) — their fields are found automatically when they open it here.",
    tip: "Fields you assign to yourself get embedded permanently into the page. Tick Add a signing record page to append a page that lists the signer, the time, the marks and a fingerprint (SHA-256) of the original file, so anyone can check they hold the same document; it is a record, not a certified signature. Fields marked for the other party are left as empty form fields at that spot. When they open the file in this tool, those fields are found and placed for them automatically, so they get the same signature options (draw, type, or import) you used.",
  };
function tt(n, i) {
  const l = new Set();
  for (const h of n.split(",")) {
    const c = h.trim();
    if (!c) continue;
    const x = c.match(/^(\d+)\s*-\s*(\d+)$/);
    if (x) {
      const f = Math.max(1, parseInt(x[1], 10)),
        N = Math.min(i, parseInt(x[2], 10));
      for (let Y = f; Y <= N; Y++) l.add(Y);
    } else if (/^\d+$/.test(c)) {
      const f = parseInt(c, 10);
      f >= 1 && f <= i && l.add(f);
    }
  }
  return Array.from(l).sort((h, c) => h - c);
}
function ke(n, i) {
  if (n.pageMode === "all") return Array.from({ length: i }, (l, h) => h + 1);
  if (n.pageMode === "range") {
    const l = tt(n.pageRange, i);
    return l.length > 0 ? l : [n.page];
  }
  return [n.page];
}
const Q = {
    signature: "Signature",
    initial: "Initial",
    date: "Date",
    fullName: "Full Name",
    initialsText: "Initials (text)",
  },
  qe = {
    signature: { width: 0.22, height: 0.06 },
    initial: { width: 0.08, height: 0.05 },
    date: { width: 0.14, height: 0.035 },
    fullName: { width: 0.2, height: 0.035 },
    initialsText: { width: 0.08, height: 0.035 },
  };
function Ke(n) {
  const i = new Date(),
    l = String(i.getMonth() + 1).padStart(2, "0"),
    h = String(i.getDate()).padStart(2, "0"),
    c = i.getFullYear();
  return n === "mm/dd/yyyy" ? `${l}/${h}/${c}` : `${h}/${l}/${c}`;
}
function et() {
  return Math.random().toString(36).slice(2, 10);
}
function Ga() {
  const [n] = m.useState(
      () =>
        typeof window < "u" &&
        typeof window.matchMedia == "function" &&
        window.matchMedia("(pointer: coarse)").matches,
    ),
    [i, l] = m.useState(null),
    [h, c] = m.useState(1),
    [x, f] = m.useState(1),
    [N, Y] = m.useState(""),
    [H, M] = m.useState(Qe[0].family),
    [C, re] = m.useState(""),
    [I, K] = m.useState("mm/dd/yyyy"),
    [j, oe] = m.useState("auto"),
    [E, O] = m.useState(null),
    [V, at] = m.useState("auto"),
    [Te, me] = m.useState(null),
    [L, ee] = m.useState([]),
    [W, te] = m.useState(null),
    [De, Me] = m.useState(!1),
    [Ie, he] = m.useState(""),
    [$e, nt] = m.useState(!1),
    le = m.useRef(null),
    st = m.useRef(null),
    it = m.useRef(null),
    rt = m.useRef(!1),
    ot = m.useRef(!1),
    lt = m.useRef(null),
    ct = m.useRef(null);
  m.useEffect(() => {
    if (document.getElementById("fdp-signature-fonts")) return;
    const t = document.createElement("style");
    ((t.id = "fdp-signature-fonts"),
      (t.textContent = ia),
      document.head.appendChild(t));
  }, []);
  const ue = m.useRef(new Set()),
    dt = async (t) => {
      try {
        const s = await Ue.load(await t.arrayBuffer(), {
            ignoreEncryption: !0,
          }),
          a = s.getPages(),
          r = [];
        for (const o of s.getForm().getFields()) {
          const d = Xe(o.getName());
          if (!d) continue;
          const u = o.acroField.getWidgets()[0];
          if (!u) continue;
          const P = s.context.getObjectRef(u.dict),
            k = a.findIndex(($) =>
              $.node
                .lookupMaybe(ze.of("Annots"), Ct)
                ?.asArray()
                .some((B) => B === P),
            );
          if (k < 0) continue;
          const g = u.getRectangle(),
            b = Ye(a[k]),
            _ = b.toViewed(g.x + g.width / 2, g.y + g.height / 2);
          (r.push({
            id: et(),
            type: d.type,
            assignedTo: "me",
            page: k + 1,
            pageMode: "single",
            pageRange: "",
            xFrac: _.x / b.width,
            yFrac: 1 - _.y / b.height,
          }),
            ue.current.add(o.getName()));
        }
        r.length > 0 &&
          (ee(r),
          R.info(
            `${r.length} field${r.length === 1 ? " is" : "s are"} waiting for you — they're already placed. Set up your signature, then download.`,
          ));
      } catch {}
    },
    ge = m.useCallback(async (t) => {
      const s = t[0];
      if (s) {
        (l(s), (ue.current = new Set()));
        try {
          const a = await Ge(s);
          (c(a.numPages), f(1), await dt(s));
        } catch {
          (R.error(
            "Couldn't read that PDF. It may be corrupted or password-protected.",
          ),
            l(null));
        }
      }
    }, []);
  (m.useEffect(() => {
    const t = Ot("sign-pdf");
    t.length && ge(t);
  }, [ge]),
    m.useEffect(() => {
      if (!i) return;
      let t = !1;
      return (
        (async () => {
          const a = await (await Ge(i)).getPage(x),
            r = a.getViewport({ scale: na }),
            o = le.current;
          if (!o || t) return;
          ((o.width = r.width), (o.height = r.height));
          const d = o.getContext("2d");
          d &&
            (await a.render({
              canvasContext: d,
              viewport: r,
              canvas: o,
              intent: "print",
            }).promise);
        })(),
        () => {
          t = !0;
        }
      );
    }, [i, x]));
  const pe = m.useCallback(
      (t, s) => {
        const a = t.trim();
        if (!a) return null;
        const r = (y) => `${y}px '${H}', cursive`,
          o = document.createElement("canvas").getContext("2d");
        o.font = r(s);
        const d = 900;
        let u = s,
          P = o.measureText(a).width;
        P > d &&
          ((u = Math.max(12, Math.floor((s * d) / P))),
          (o.font = r(u)),
          (P = o.measureText(a).width));
        const k = Math.ceil(u * 0.35),
          g = document.createElement("canvas");
        ((g.width = Math.ceil(P) + k * 2), (g.height = Math.ceil(u * 1.8) + k));
        const b = g.getContext("2d");
        (b.clearRect(0, 0, g.width, g.height),
          (b.fillStyle = "#1e293b"),
          (b.font = r(u)),
          (b.textAlign = "left"),
          (b.textBaseline = "middle"),
          b.fillText(a, k, g.height / 2));
        const _ = b.getImageData(0, 0, g.width, g.height).data;
        let $ = g.width,
          B = -1,
          T = g.height,
          G = -1;
        for (let y = 0; y < g.height; y++)
          for (let D = 0; D < g.width; D++)
            _[(y * g.width + D) * 4 + 3] > 8 &&
              (D < $ && ($ = D),
              D > B && (B = D),
              y < T && (T = y),
              y > G && (G = y));
        if (B < 0) return g.toDataURL("image/png");
        const X = 4,
          p = B - $ + 1 + X * 2,
          A = G - T + 1 + X * 2,
          F = document.createElement("canvas");
        return (
          (F.width = p),
          (F.height = A),
          F.getContext("2d").drawImage(g, $ - X, T - X, p, A, 0, 0, p, A),
          F.toDataURL("image/png")
        );
      },
      [H],
    ),
    [Ae, mt] = m.useState(null),
    [Re, ht] = m.useState(null);
  m.useEffect(() => {
    let t = !0;
    return (
      Promise.race([
        document.fonts.load(`56px '${H}'`, N + C + "Aa"),
        new Promise((s) => setTimeout(s, 3e3)),
      ])
        .catch(() => {})
        .then(() => {
          t && (mt(pe(N, 56)), ht(pe(C, 56)));
        }),
      () => {
        t = !1;
      }
    );
  }, [N, C, pe]);
  const Ee = (t, s) => {
      const a = t.current,
        r = a.getBoundingClientRect(),
        o = a.width / r.width,
        d = a.height / r.height;
      return { x: (s.clientX - r.left) * o, y: (s.clientY - r.top) * d };
    },
    ut = (t, s, a) => ({
      onPointerDown: (r) => {
        s.current = !0;
        const o = t.current?.getContext("2d"),
          d = Ee(t, r);
        o && (o.beginPath(), o.moveTo(d.x, d.y));
      },
      onPointerMove: (r) => {
        if (!s.current) return;
        const o = t.current?.getContext("2d"),
          d = Ee(t, r);
        o &&
          ((o.lineWidth = 3),
          (o.lineCap = "round"),
          (o.strokeStyle = "#1e293b"),
          o.lineTo(d.x, d.y),
          o.stroke(),
          a());
      },
      onPointerUp: () => {
        s.current = !1;
      },
      onPointerLeave: () => {
        s.current = !1;
      },
    }),
    gt = (t, s) => {
      const a = t.current,
        r = a?.getContext("2d");
      (a && r && r.clearRect(0, 0, a.width, a.height), s(null));
    },
    pt = (t, s) => {
      const a = t.current;
      a && s(a.toDataURL("image/png"));
    },
    ft = (t) =>
      new Promise((s, a) => {
        const r = new Image();
        ((r.onload = () => {
          const o = document.createElement("canvas");
          ((o.width = r.naturalWidth), (o.height = r.naturalHeight));
          const d = o.getContext("2d");
          if (!d) {
            a(new Error("Couldn't read this image"));
            return;
          }
          (d.drawImage(r, 0, 0), s(o.toDataURL("image/png")));
        }),
          (r.onerror = () => a(new Error("Couldn't read this image"))),
          (r.src = t));
      }),
    xt = (t, s) => (a) => {
      const r = a.target.files?.[0];
      if (!r) return;
      const o = new FileReader();
      ((o.onload = () => {
        ft(o.result)
          .then((d) => {
            (t(d), s("import"));
          })
          .catch(() =>
            R.error("Couldn't read that image — try a different file."),
          );
      }),
        o.readAsDataURL(r));
    },
    Oe = (t, s, a) => (t === "auto" ? a : s),
    fe = Oe(j, E, Ae),
    xe = Oe(V, Te, Re),
    yt = (t) => {
      const s = {
        id: et(),
        type: t,
        assignedTo: "me",
        page: x,
        pageMode: "single",
        pageRange: "",
        xFrac: null,
        yFrac: null,
      };
      (ee((a) => [...a, s]),
        te(s.id),
        R.info("Click the page preview to place this field"));
    },
    Z = (t, s) => {
      ee((a) => a.map((r) => (r.id === t ? { ...r, ...s } : r)));
    },
    wt = (t) => {
      (ee((s) => s.filter((a) => a.id !== t)), W === t && te(null));
    },
    bt = (t) => {
      if (!W) return;
      const a = le.current.getBoundingClientRect(),
        r = (t.clientX - a.left) / a.width,
        o = (t.clientY - a.top) / a.height;
      (Z(W, { xFrac: r, yFrac: o, page: x }), te(null));
    },
    ae = m.useRef(null),
    vt = (t, s) => {
      (t.stopPropagation(),
        (ae.current = s),
        t.currentTarget.setPointerCapture(t.pointerId));
    },
    jt = (t) => {
      if (!ae.current) return;
      const s = le.current;
      if (!s) return;
      const a = s.getBoundingClientRect(),
        r = Math.min(1, Math.max(0, (t.clientX - a.left) / a.width)),
        o = Math.min(1, Math.max(0, (t.clientY - a.top) / a.height));
      Z(ae.current, { xFrac: r, yFrac: o });
    },
    Nt = (t) => {
      ae.current &&
        ((ae.current = null),
        t.currentTarget.hasPointerCapture(t.pointerId) &&
          t.currentTarget.releasePointerCapture(t.pointerId));
    },
    Ft = async () => {
      if (!i) return;
      const t = Qt(L);
      if (t) {
        (he(t), R.error(t));
        return;
      }
      he("");
      const s = L.some((d) => d.assignedTo === "me" && d.type === "signature"),
        a = L.some((d) => d.assignedTo === "me" && d.type === "initial"),
        r = fe,
        o = xe;
      if (s && !r) {
        (he("Set up your signature first (above the field list)."),
          R.error("Set up your signature first (above the field list)"));
        return;
      }
      if (a && !o) {
        R.error("Set up your initials first (above the field list)");
        return;
      }
      try {
        const d = await i.arrayBuffer(),
          u = await Ue.load(d, { updateMetadata: !1 }),
          P = u.getTitle(),
          k = u.getAuthor(),
          g = u.getSubject(),
          b = u.getPages(),
          _ = await u.embedFont(Pt.Helvetica),
          $ = new Map(),
          B = async (p) => {
            if ($.has(p)) return $.get(p);
            const A = await (await fetch(p)).arrayBuffer(),
              F = await u.embedPng(A);
            return ($.set(p, F), F);
          };
        let T = 0;
        for (const p of L) {
          const A = qe[p.type];
          for (const F of ke(p, b.length)) {
            const y = b[F - 1],
              D = Ye(y),
              { width: _e, height: ye } = D,
              we = D.rotation,
              be = kt(we),
              J = (v, w) => D.toStored(v, w),
              ve = _e * A.width,
              je = ye * A.height,
              Ne = p.xFrac * _e,
              Fe = ye - p.yFrac * ye,
              { x: ce, y: de } = Ce(Ne, Fe, ve, je),
              Be = (v) => {
                const w = Jt(ve, je, v.height / v.width),
                  S = Ce(Ne, Fe, w.width, w.height);
                return { p0: J(S.x, S.y), fit: w };
              };
            if (p.assignedTo === "other") {
              T += 1;
              const v = J(ce, de),
                w = J(ce + ve, de + je),
                S = u.getForm().createTextField(Gt(p.type, T));
              (S.acroField.dict.set(ze.of("TU"), Tt.fromText(Xt[p.type])),
                S.addToPage(y, {
                  x: Math.min(v.x, w.x),
                  y: Math.min(v.y, w.y),
                  width: Math.abs(w.x - v.x),
                  height: Math.abs(w.y - v.y),
                  borderColor: Se(0.11, 0.6, 0.55),
                  borderWidth: 1,
                  backgroundColor: Se(0.93, 0.98, 0.97),
                }));
              continue;
            }
            if (p.type === "signature" && r) {
              const v = await B(r),
                { p0: w, fit: S } = Be(v);
              y.drawImage(v, {
                x: w.x,
                y: w.y,
                width: S.width,
                height: S.height,
                rotate: be,
              });
            } else if (p.type === "initial" && o) {
              const v = await B(o),
                { p0: w, fit: S } = Be(v);
              y.drawImage(v, {
                x: w.x,
                y: w.y,
                width: S.width,
                height: S.height,
                rotate: be,
              });
            } else if (p.type === "date") {
              const v = Ke(I),
                w = Ce(Ne, Fe, _.widthOfTextAtSize(v, 11), 8),
                S = J(w.x, w.y);
              y.drawText(v, {
                x: S.x,
                y: S.y,
                size: 11,
                font: _,
                color: Se(0.1, 0.1, 0.1),
                rotate: be,
              });
            } else
              p.type === "fullName"
                ? await q(u, y, N.trim() || "(name not entered)", {
                    ...J(ce, de),
                    size: 11,
                    color: { r: 0.1, g: 0.1, b: 0.1 },
                    rotateDegrees: we,
                  })
                : p.type === "initialsText" &&
                  (await q(u, y, C.trim() || "(initials not entered)", {
                    ...J(ce, de),
                    size: 11,
                    color: { r: 0.1, g: 0.1, b: 0.1 },
                    rotateDegrees: we,
                  }));
          }
        }
        for (const p of u.getForm().getFields())
          Xe(p.getName()) &&
            ue.current.has(p.getName()) &&
            u.getForm().removeField(p);
        Dt(u, { title: P, author: k, fallbackTitle: `Signed ${Mt(i.name)}` });
        const G = It(g) && !/^unspecified$/i.test(g ?? "") ? g : void 0;
        if ((G && u.setSubject(G), $e)) {
          const A = L.filter(
            (F) => F.assignedTo === "me" && F.xFrac !== null,
          ).flatMap((F) =>
            ke(F, b.length).map((y) => ({ type: F.type, page: y })),
          );
          await aa(u, {
            documentName: i.name,
            pageCount: b.length,
            originalSha256: await Kt(new Uint8Array(d)),
            signerName: N,
            signedAt: new Date(),
            timeZone: (() => {
              try {
                return Intl.DateTimeFormat().resolvedOptions().timeZone || "";
              } catch {
                return "";
              }
            })(),
            marks: A,
            fieldsForOthers: T,
          });
        }
        const X = await u.save();
        (Et(
          new Blob([new Uint8Array(X)], { type: "application/pdf" }),
          `signed-${i.name}`,
        ),
          R.success(
            T > 0
              ? `Signed and downloaded! ${T} field${T === 1 ? "" : "s"} marked for the other party — send them the file — they can sign it in any PDF reader, or here in Sign PDF.`
              : "Signed PDF downloaded!",
          ));
      } catch (d) {
        (console.error("Signing failed:", d),
          R.error(
            "Something went wrong generating the signed PDF — try again",
          ));
      }
    },
    St = () => {
      (l(null), ee([]), te(null), O(null), me(null));
    },
    Le = (t, s, a, r, o, d, u, P, k, g, b) =>
      e.jsxs("div", {
        className: "space-y-2 border rounded-lg p-3",
        children: [
          e.jsx(U, { className: "block font-medium", children: t }),
          e.jsxs("div", {
            className: "grid grid-cols-1 sm:grid-cols-3 gap-3",
            children: [
              e.jsxs("label", {
                className:
                  "flex items-start gap-2 border rounded-lg p-2 cursor-pointer hover:bg-muted/40",
                children: [
                  e.jsx("input", {
                    type: "radio",
                    checked: s === "import",
                    onChange: () => {
                      (a("import"), u(null));
                    },
                    className: "mt-1",
                  }),
                  e.jsxs("div", {
                    className: "flex-1 min-w-0",
                    children: [
                      e.jsx("div", {
                        className: "text-sm font-medium mb-1",
                        children: "Import / Paste",
                      }),
                      P
                        ? e.jsx("div", {
                            className: "bg-white rounded p-1 inline-block",
                            children: e.jsx("img", {
                              src: P,
                              alt: "Imported",
                              className: "h-10 object-contain",
                            }),
                          })
                        : e.jsx(z, {
                            type: "button",
                            variant: "outline",
                            size: "sm",
                            onClick: () => g.current?.click(),
                            children: "Choose image",
                          }),
                      e.jsx("input", {
                        ref: g,
                        type: "file",
                        accept: "image/*",
                        className: "hidden",
                        onChange: xt(k, a),
                      }),
                    ],
                  }),
                ],
              }),
              e.jsxs("label", {
                className:
                  "flex items-start gap-2 border rounded-lg p-2 cursor-pointer hover:bg-muted/40",
                children: [
                  e.jsx("input", {
                    type: "radio",
                    checked: s === "auto",
                    onChange: () => a("auto"),
                    className: "mt-1",
                  }),
                  e.jsxs("div", {
                    className: "flex-1 min-w-0",
                    children: [
                      e.jsx("div", {
                        className: "text-sm font-medium mb-1",
                        children: "Auto-generated",
                      }),
                      r
                        ? e.jsx("div", {
                            className: "bg-white rounded p-1 inline-block",
                            children: e.jsx("img", {
                              src: r,
                              alt: "Auto-generated",
                              className: "h-10 object-contain",
                            }),
                          })
                        : e.jsx("span", {
                            className: "text-xs text-muted-foreground",
                            children: b ? "..." : "Type a value above first",
                          }),
                    ],
                  }),
                ],
              }),
              e.jsxs("label", {
                className:
                  "flex items-start gap-2 border rounded-lg p-2 cursor-pointer hover:bg-muted/40",
                children: [
                  e.jsx("input", {
                    type: "radio",
                    checked: s === "custom",
                    onChange: () => {
                      (a("custom"), u(null));
                    },
                    className: "mt-1",
                  }),
                  e.jsxs("div", {
                    className: "flex-1 min-w-0",
                    children: [
                      e.jsx("div", {
                        className: "text-sm font-medium mb-1",
                        children: "Draw manually",
                      }),
                      e.jsxs("div", {
                        className: "flex items-center gap-2",
                        children: [
                          e.jsx("canvas", {
                            ref: o,
                            width: 300,
                            height: 90,
                            ...ut(o, d, () => pt(o, (_) => u(_))),
                            className:
                              "border border-dashed rounded bg-white touch-none cursor-crosshair w-full max-w-[180px] h-[54px]",
                          }),
                          e.jsx(z, {
                            type: "button",
                            variant: "outline",
                            size: "icon",
                            className: "shrink-0 h-7 w-7",
                            onClick: () => gt(o, u),
                            title: "Clear",
                            children: e.jsx(Vt, { className: "h-3 w-3" }),
                          }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
        ],
      });
  return e.jsxs($t, {
    children: [
      e.jsxs("div", {
        className:
          "mb-4 p-3 rounded-lg border bg-muted/50 text-xs text-muted-foreground flex flex-wrap gap-x-4 gap-y-1",
        children: [
          e.jsx("span", {
            children: "🔒 Runs entirely in your browser — never uploaded",
          }),
          e.jsx("span", {
            children:
              "✍️ A stamped signature image, not a certified digital signature",
          }),
        ],
      }),
      e.jsxs("div", {
        className: "space-y-6",
        children: [
          !i &&
            e.jsxs("div", {
              "data-testid": "sign-step-upload",
              className: "space-y-2",
              children: [
                e.jsx("p", {
                  className: "font-medium text-sm",
                  children: "Step 1: Add the PDF you want to sign",
                }),
                e.jsx(At, {
                  gateAtDownload: !0,
                  accept: "application/pdf",
                  onFiles: ge,
                  label: "Drop a PDF to sign",
                  description:
                    "Add your signature, initials, dates, or fields for someone else to fill in",
                }),
                e.jsx("p", {
                  className: "font-medium text-sm pt-2",
                  children: "Step 2: Create your signature",
                }),
              ],
            }),
          e.jsxs("div", {
            className: "space-y-3 max-w-sm",
            children: [
              e.jsxs("div", {
                children: [
                  e.jsx(U, {
                    htmlFor: "sign-full-name",
                    className: "mb-1 block",
                    children: "Full Name",
                  }),
                  e.jsx(ne, {
                    id: "sign-full-name",
                    autoComplete: "name",
                    value: N,
                    onChange: (t) => Y(t.target.value),
                    placeholder: "Jane Q. Public",
                  }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx(U, {
                    htmlFor: "sign-initials",
                    className: "mb-1 block",
                    children: "Initials",
                  }),
                  e.jsx(ne, {
                    id: "sign-initials",
                    value: C,
                    onChange: (t) => re(t.target.value),
                    placeholder: "JQP",
                  }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx(U, {
                    className: "mb-1 block",
                    children: "Signature style",
                  }),
                  e.jsx("div", {
                    className: "flex flex-wrap gap-2",
                    children: Qe.map((t) =>
                      e.jsx(
                        "button",
                        {
                          type: "button",
                          onClick: () => M(t.family),
                          "aria-pressed": H === t.family,
                          className: `border rounded-md px-3 py-1 text-lg leading-tight ${H === t.family ? "border-primary bg-primary/10" : "hover:bg-muted/40"}`,
                          style: { fontFamily: `'${t.family}', cursive` },
                          title: t.label,
                          children: (N.trim() || "Signature").slice(0, 14),
                        },
                        t.family,
                      ),
                    ),
                  }),
                ],
              }),
            ],
          }),
          Le("Your Signature", j, oe, Ae, st, rt, O, E, O, lt, N),
          Le("Your Initials", V, at, Re, it, ot, me, Te, me, ct, C),
          e.jsxs("div", {
            className: "border rounded-lg p-3",
            children: [
              e.jsx(U, {
                className: "block font-medium mb-2",
                children: "Date Format",
              }),
              e.jsxs("div", {
                className: "flex gap-4",
                children: [
                  e.jsxs("label", {
                    className: "flex items-center gap-2 cursor-pointer",
                    children: [
                      e.jsx("input", {
                        type: "radio",
                        checked: I === "mm/dd/yyyy",
                        onChange: () => K("mm/dd/yyyy"),
                      }),
                      e.jsxs("span", {
                        className: "text-sm",
                        children: [
                          "MM/DD/YYYY ",
                          e.jsx("span", {
                            className: "text-muted-foreground",
                            children: "(US)",
                          }),
                        ],
                      }),
                    ],
                  }),
                  e.jsxs("label", {
                    className: "flex items-center gap-2 cursor-pointer",
                    children: [
                      e.jsx("input", {
                        type: "radio",
                        checked: I === "dd/mm/yyyy",
                        onChange: () => K("dd/mm/yyyy"),
                      }),
                      e.jsxs("span", {
                        className: "text-sm",
                        children: [
                          "DD/MM/YYYY ",
                          e.jsx("span", {
                            className: "text-muted-foreground",
                            children: "(most other countries)",
                          }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          i &&
            h > 1 &&
            e.jsxs("div", {
              className: "flex items-center gap-3",
              children: [
                e.jsx(U, {
                  htmlFor: "sign-page-num",
                  className: "shrink-0",
                  children: "Page",
                }),
                e.jsx(ne, {
                  id: "sign-page-num",
                  type: "number",
                  min: 1,
                  max: h,
                  value: x,
                  onChange: (t) =>
                    f(Math.min(h, Math.max(1, Number(t.target.value) || 1))),
                  className: "w-24",
                }),
                e.jsxs("span", {
                  className: "text-sm text-muted-foreground",
                  children: ["of ", h],
                }),
              ],
            }),
          e.jsxs("div", {
            children: [
              e.jsxs("div", {
                className: "flex items-center justify-between mb-2",
                children: [
                  e.jsx(U, { className: "font-medium", children: "Fields" }),
                  e.jsx("div", {
                    className: "flex flex-wrap gap-2",
                    children: Object.keys(Q).map((t) =>
                      e.jsxs(
                        z,
                        {
                          type: "button",
                          variant: "outline",
                          size: "sm",
                          className: "gap-1",
                          onClick: () => {
                            if (!i) {
                              R.info(
                                "Drop a PDF below first, then add fields to place them on it",
                              );
                              return;
                            }
                            yt(t);
                          },
                          children: [
                            e.jsx(Rt, { className: "h-3 w-3" }),
                            " ",
                            Q[t],
                          ],
                        },
                        t,
                      ),
                    ),
                  }),
                ],
              }),
              L.length > 0
                ? e.jsx("div", {
                    className: "border rounded-lg overflow-x-auto",
                    children: e.jsxs("table", {
                      className: "w-full text-sm",
                      children: [
                        e.jsx("thead", {
                          className: "bg-muted/50",
                          children: e.jsxs("tr", {
                            children: [
                              e.jsx("th", {
                                className: "text-left p-2 font-medium",
                                children: "#",
                              }),
                              e.jsx("th", {
                                className: "text-left p-2 font-medium",
                                children: "Type",
                              }),
                              e.jsx("th", {
                                className: "text-left p-2 font-medium",
                                children: "Assigned to",
                              }),
                              e.jsx("th", {
                                className: "text-left p-2 font-medium",
                                children: "Page",
                              }),
                              e.jsx("th", {
                                className: "text-left p-2 font-medium",
                                children: "Placed",
                              }),
                              e.jsx("th", { className: "p-2" }),
                            ],
                          }),
                        }),
                        e.jsx("tbody", {
                          children: L.map((t, s) =>
                            e.jsxs(
                              "tr",
                              {
                                className: `border-t ${W === t.id ? "bg-primary/5" : ""}`,
                                children: [
                                  e.jsx("td", {
                                    className: "p-2",
                                    children: s + 1,
                                  }),
                                  e.jsx("td", {
                                    className: "p-2",
                                    children: Q[t.type],
                                  }),
                                  e.jsx("td", {
                                    className: "p-2",
                                    children: e.jsxs(He, {
                                      value: t.assignedTo,
                                      onValueChange: (a) =>
                                        Z(t.id, { assignedTo: a }),
                                      children: [
                                        e.jsx(Ve, {
                                          "aria-label": `Field ${s + 1} assigned to`,
                                          className: "h-8 w-32",
                                          children: e.jsx(We, {}),
                                        }),
                                        e.jsxs(Ze, {
                                          children: [
                                            e.jsx(se, {
                                              value: "me",
                                              children: "Me",
                                            }),
                                            e.jsx(se, {
                                              value: "other",
                                              children: "Other party",
                                            }),
                                          ],
                                        }),
                                      ],
                                    }),
                                  }),
                                  e.jsx("td", {
                                    className: "p-2",
                                    children: e.jsxs("div", {
                                      className:
                                        "flex flex-col gap-1 min-w-[140px]",
                                      children: [
                                        e.jsxs("div", {
                                          className: "flex items-center gap-1",
                                          children: [
                                            e.jsx(ne, {
                                              type: "number",
                                              min: 1,
                                              max: h,
                                              value: t.page,
                                              onChange: (a) => {
                                                const r = Math.min(
                                                  h,
                                                  Math.max(
                                                    1,
                                                    Number(a.target.value) || 1,
                                                  ),
                                                );
                                                Z(t.id, {
                                                  page: r,
                                                  xFrac: null,
                                                  yFrac: null,
                                                });
                                              },
                                              className: "h-8 w-16",
                                              "aria-label": `Field ${s + 1} reference page`,
                                              title:
                                                "Reference page — where you click to place this field",
                                            }),
                                            e.jsxs(He, {
                                              value: t.pageMode,
                                              onValueChange: (a) =>
                                                Z(t.id, { pageMode: a }),
                                              children: [
                                                e.jsx(Ve, {
                                                  "aria-label": `Field ${s + 1} pages`,
                                                  className: "h-8 w-24",
                                                  children: e.jsx(We, {}),
                                                }),
                                                e.jsxs(Ze, {
                                                  children: [
                                                    e.jsx(se, {
                                                      value: "single",
                                                      children: "This page",
                                                    }),
                                                    e.jsx(se, {
                                                      value: "all",
                                                      children: "All pages",
                                                    }),
                                                    e.jsx(se, {
                                                      value: "range",
                                                      children: "Range...",
                                                    }),
                                                  ],
                                                }),
                                              ],
                                            }),
                                          ],
                                        }),
                                        t.pageMode === "range" &&
                                          e.jsx(ne, {
                                            value: t.pageRange,
                                            onChange: (a) =>
                                              Z(t.id, {
                                                pageRange: a.target.value,
                                              }),
                                            "aria-label": `Field ${s + 1} page range`,
                                            placeholder: "e.g. 1-3, 5, 6, 8-11",
                                            className: "h-8 text-xs",
                                          }),
                                        (t.pageMode === "all" ||
                                          t.pageMode === "range") &&
                                          e.jsxs("p", {
                                            className:
                                              "text-[10px] text-muted-foreground leading-tight",
                                            children: [
                                              "Placed once, on the page above — the same spot repeats on",
                                              t.pageMode === "all"
                                                ? ` all ${h} pages`
                                                : ` page${tt(t.pageRange, h).length === 1 ? "" : "s"} ${t.pageRange || "(enter a range)"}`,
                                              ".",
                                            ],
                                          }),
                                      ],
                                    }),
                                  }),
                                  e.jsx("td", {
                                    className: "p-2",
                                    children:
                                      t.xFrac !== null
                                        ? e.jsx("span", {
                                            className: "text-green-600 text-xs",
                                            children: "✓ placed",
                                          })
                                        : e.jsxs(z, {
                                            type: "button",
                                            size: "sm",
                                            variant: "ghost",
                                            className: "h-7 gap-1 text-xs",
                                            onClick: () => {
                                              (f(t.page), te(t.id));
                                            },
                                            children: [
                                              e.jsx(zt, {
                                                className: "h-3 w-3",
                                              }),
                                              " Click page to place",
                                            ],
                                          }),
                                  }),
                                  e.jsx("td", {
                                    className: "p-2",
                                    children: e.jsx(z, {
                                      type: "button",
                                      size: "icon",
                                      variant: "ghost",
                                      className: "h-7 w-7",
                                      "aria-label": `Remove field ${s + 1}`,
                                      onClick: () => wt(t.id),
                                      children: e.jsx(Yt, {
                                        className: "h-3 w-3",
                                      }),
                                    }),
                                  }),
                                ],
                              },
                              t.id,
                            ),
                          ),
                        }),
                      ],
                    }),
                  })
                : e.jsx("p", {
                    className:
                      "border border-dashed rounded-lg p-4 text-sm text-muted-foreground text-center",
                    children: i
                      ? `${n ? "Tap" : "Click"} where you want to sign: add a Signature field above, then ${n ? "tap" : "click"} the page.`
                      : "No fields yet. Add your PDF first, then add a Signature field and click the page to place it.",
                  }),
              W &&
                e.jsx("p", {
                  className: "text-sm text-primary mt-2",
                  children: "Click the page preview below to place this field.",
                }),
            ],
          }),
          e.jsxs("div", {
            children: [
              e.jsx(U, { className: "mb-2 block", children: "Page preview" }),
              i
                ? e.jsxs("div", {
                    className:
                      "relative inline-block border rounded-lg overflow-hidden bg-muted/30 max-w-full",
                    children: [
                      e.jsx("canvas", {
                        ref: le,
                        onClick: bt,
                        className: `max-w-full h-auto block ${W ? "cursor-crosshair" : ""}`,
                      }),
                      L.filter(
                        (t) => t.xFrac !== null && ke(t, h).includes(x),
                      ).map((t) => {
                        const s = qe[t.type];
                        let a = Q[t.type];
                        return (
                          t.assignedTo === "me" &&
                            (t.type === "signature" && fe
                              ? (a = e.jsx("img", {
                                  src: fe,
                                  alt: "",
                                  className:
                                    "max-w-full max-h-full object-contain",
                                }))
                              : t.type === "initial" && xe
                                ? (a = e.jsx("img", {
                                    src: xe,
                                    alt: "",
                                    className:
                                      "max-w-full max-h-full object-contain",
                                  }))
                                : t.type === "date"
                                  ? (a = Ke(I))
                                  : t.type === "fullName"
                                    ? (a = N || Q[t.type])
                                    : t.type === "initialsText" &&
                                      (a = C || Q[t.type])),
                          e.jsx(
                            "div",
                            {
                              onPointerDown: (r) => vt(r, t.id),
                              onPointerMove: jt,
                              onPointerUp: Nt,
                              className: `absolute border-2 rounded flex items-center justify-center text-[9px] font-medium overflow-hidden cursor-move touch-none ${t.assignedTo === "me" ? "border-primary bg-primary/10" : "border-blue-500 bg-blue-500/10"}`,
                              style: {
                                left: `${t.xFrac * 100}%`,
                                top: `${t.yFrac * 100}%`,
                                width: `${s.width * 100}%`,
                                aspectRatio: `${s.width} / ${s.height}`,
                                transform: "translate(-50%, -50%)",
                              },
                              children: a,
                            },
                            t.id,
                          )
                        );
                      }),
                    ],
                  })
                : e.jsx("p", {
                    className:
                      "text-sm text-muted-foreground border border-dashed rounded-lg p-4 text-center",
                    children:
                      "Add your PDF in step 1 above. It appears here so you can place your signature.",
                  }),
            ],
          }),
          i &&
            L.some((t) => t.assignedTo === "other") &&
            e.jsxs("div", {
              className:
                "border border-teal-500/40 bg-teal-500/5 rounded-lg p-3 text-sm space-y-2",
              children: [
                e.jsx("p", {
                  className: "font-medium",
                  children: "Before you send this",
                }),
                e.jsx("p", {
                  className: "text-muted-foreground",
                  children:
                    "Fields marked for the other party become real, empty form fields in the PDF. They can fill them in any PDF reader, or open the file in Sign PDF (link below): the fields are found automatically, already placed, and they sign with the draw / type / import tools, then download their own copy.",
                }),
                e.jsxs("div", {
                  className: "flex items-center gap-2 pt-1",
                  children: [
                    e.jsx("a", {
                      href: "https://www.freedailypro.com/tool/sign-pdf",
                      target: "_blank",
                      rel: "noopener noreferrer",
                      className:
                        "font-bold text-teal-400 hover:text-teal-300 underline underline-offset-2 break-all",
                      children: "freedailypro.com/tool/sign-pdf",
                    }),
                    e.jsxs(z, {
                      type: "button",
                      size: "sm",
                      variant: "outline",
                      className: "shrink-0 gap-1.5",
                      onClick: () => {
                        (navigator.clipboard.writeText(
                          "https://www.freedailypro.com/tool/sign-pdf",
                        ),
                          Me(!0),
                          setTimeout(() => Me(!1), 2e3));
                      },
                      children: [
                        De
                          ? e.jsx(Lt, { className: "h-3.5 w-3.5" })
                          : e.jsx(Ht, { className: "h-3.5 w-3.5" }),
                        De ? "Copied" : "Copy Link",
                      ],
                    }),
                  ],
                }),
                e.jsx("p", {
                  className: "text-xs text-muted-foreground",
                  children:
                    "Put this link in your message or e-mail — nothing about it is printed on the document itself.",
                }),
              ],
            }),
          i &&
            e.jsxs(e.Fragment, {
              children: [
                Ie &&
                  e.jsx("p", {
                    role: "alert",
                    className: "text-sm text-destructive",
                    children: Ie,
                  }),
                e.jsxs("label", {
                  className:
                    "flex items-start gap-2 text-sm cursor-pointer w-fit",
                  htmlFor: "sign-audit",
                  children: [
                    e.jsx("input", {
                      id: "sign-audit",
                      type: "checkbox",
                      className: "mt-1",
                      checked: $e,
                      onChange: (t) => nt(t.target.checked),
                    }),
                    e.jsxs("span", {
                      children: [
                        "Add a signing record page at the end",
                        e.jsx("span", {
                          className: "block text-xs text-muted-foreground",
                          children:
                            "Lists who signed, when, which marks were added and a fingerprint of the original file. Made on this device; nothing is uploaded.",
                        }),
                      ],
                    }),
                  ],
                }),
                e.jsxs("div", {
                  className: "flex gap-3",
                  children: [
                    e.jsxs(z, {
                      onClick: Ft,
                      className: "gap-2",
                      children: [
                        e.jsx(_t, { className: "h-4 w-4" }),
                        " Download Signed PDF",
                      ],
                    }),
                    e.jsxs(z, {
                      variant: "outline",
                      onClick: St,
                      className: "gap-2",
                      children: [
                        e.jsx(Bt, { className: "h-4 w-4" }),
                        " Start Over",
                      ],
                    }),
                  ],
                }),
                e.jsx("p", {
                  className: "text-xs text-muted-foreground",
                  children:
                    "Processed entirely in your browser — your file is never uploaded anywhere. Fields assigned to yourself are embedded permanently into the page. Fields marked for the other party are left as real, empty form fields (nothing is printed on the page). Signatures here are stamped images, not certified digital signatures.",
                }),
              ],
            }),
        ],
      }),
      e.jsx(Ut, { whatIsIt: Pe.what, howToUse: Pe.how, tip: Pe.tip }),
    ],
  });
}
export { Ga as default };
//# sourceMappingURL=SignPdf-HYsVjGoA.js.map
