// sign-pdf battery: one fresh context per case (sp-cases.json; argv[2] = comma IDs). Signing builds the PDF in memory, then the gated download runs (cap dialog at 0).
// The signed PDF is captured from the in-memory Blob (init-script hook on Blob/URL.createObjectURL); nothing is downloaded when the context is at 0. A context with uses left is skipped unless argv[3]=='spend'.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/21-sign-pdf/live/'; const T = '/workspace/deep/21-sign-pdf/testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const ids = process.argv[2] && process.argv[2] !== 'all' ? process.argv[2].split(',') : null; const tag = ids ? '-' + ids.join('_') : '';
const cases = JSON.parse(fs.readFileSync(__dirname + '/sp-cases.json')).filter(c => !ids || ids.includes(c.id));
const HOOK = `(() => { window.__pdfs = []; const OB = window.Blob; window.Blob = class extends OB { constructor(parts, opts) { super(parts, opts); if (opts && /pdf/.test(opts.type || '')) window.__pdfs.push(this); } }; })();`;
(async () => { const b = await chromium.launch(); const R = { t: now(), cases: [] }; const save = () => fs.writeFileSync(OUT + 'battery' + tag + '.json', JSON.stringify(R, null, 1));
 for (const c of cases) { const r = { ...c, t: now() }; const ctx = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); await ctx.addInitScript(HOOK); const p = await ctx.newPage(); p.setDefaultTimeout(10000);
  const toasts = []; const grab = async () => { const tt = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim())).catch(() => []); tt.forEach(x => { if (!toasts.includes(x)) toasts.push(x); }); };
  let dl = null; p.on('download', d => { dl = d; });
  try { await p.goto('https://www.freedailypro.com/tool/sign-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
   r.used0 = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday); r.limit = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').limit);
   if (r.used0 < r.limit && process.argv[3] !== 'spend') { r.note = 'context has uses left; skipped to keep them for the gate script'; R.cases.push(r); save(); console.log(r.id, r.note); await ctx.close(); continue; }
   await p.locator('main input[type=file]').first().setInputFiles(T + c.file); await p.waitForTimeout(4000); await grab();
   r.afterUpload = await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*(Couldn't|password|corrupt|could not)[^\n]*/i) || [null])[0]);
   if (!c.noName) { await p.locator('#sign-full-name').fill(c.name || 'Jane Q. Public'); await p.locator('#sign-initials').fill('JQP'); }
   await p.waitForTimeout(600);
   if (c.sig === 'draw') { await p.getByText('Draw manually').first().click(); await p.waitForTimeout(400); const cv = p.locator('main canvas').first(); const bb = await cv.boundingBox(); await p.mouse.move(bb.x + 20, bb.y + bb.height * 0.7); await p.mouse.down(); for (let k = 1; k <= 12; k++) await p.mouse.move(bb.x + 20 + k * (bb.width - 40) / 12, bb.y + bb.height * (k % 2 ? 0.3 : 0.7), { steps: 3 }); await p.mouse.up(); }
   if (c.sig === 'import') { await p.getByText('Import / Paste').first().click().catch(() => {}); await p.locator('main input[type=file]').nth(1).setInputFiles(T + c.img); await p.waitForTimeout(1500); }
   if (c.sig === 'none') { await p.getByText('Draw manually').first().click(); }
   if (c.ddmm) await p.getByText('DD/MM/YYYY').first().click();
   if (c.page) { await p.locator('#sign-page-num').fill(String(c.page)); await p.waitForTimeout(1500); }
   const prev = async () => { const cs = p.locator('main canvas'); const n = await cs.count(); let best = null, area = 0; for (let i = 0; i < n; i++) { const bb = await cs.nth(i).boundingBox(); if (bb && bb.width * bb.height > area) { area = bb.width * bb.height; best = bb; } } return best; };
   for (let i = 0; i < c.fields.length; i++) { const f = c.fields[i]; await p.locator('main').getByRole('button', { name: f.t, exact: true }).last().click(); await p.waitForTimeout(400);
    if (f.other) { await p.getByRole('combobox', { name: `Field ${i + 1} assigned to` }).click(); await p.getByRole('option', { name: 'Other party' }).click(); await p.waitForTimeout(300); }
    if (f.pages) { await p.getByRole('combobox', { name: `Field ${i + 1} pages` }).click(); await p.getByRole('option', { name: f.pages }).click(); await p.waitForTimeout(300); if (f.range) await p.getByLabel(`Field ${i + 1} page range`).fill(f.range); }
    if (!f.noPlace) { const cv = p.locator('main canvas.h-auto').first(); await cv.scrollIntoViewIfNeeded(); const bb = await cv.boundingBox(); await cv.click({ position: { x: bb.width * f.x, y: bb.height * f.y } }); await p.waitForTimeout(500); } }
   if (c.audit) await p.locator('#sign-audit').check();
   await grab(); r.fieldTable = await p.evaluate(() => (document.querySelector('main').innerText.match(/#\nType[\s\S]{0,600}/) || [null])[0]);
   await p.screenshot({ path: OUT + 'pre-' + c.id + '.png', fullPage: false });
   const n0 = await p.evaluate(() => window.__pdfs.length);
   const dbtn = p.getByRole('button', { name: 'Download Signed PDF' }); r.dlButton = await dbtn.count();
   if (r.dlButton) { await dbtn.click(); await p.waitForTimeout(5000); await grab();
    const dlg = p.locator('[role=dialog],[role=alertdialog]'); r.dialog = (await dlg.count()) ? (await dlg.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null;
    r.inlineError = await p.evaluate(() => [...document.querySelectorAll('main p, main [role=alert]')].map(e => e.innerText.trim()).filter(t => t.length < 200 && /first|not yet placed|Set up|Place all/i.test(t)).slice(0, 3));
    const out = await p.evaluate(async n0 => { const L = window.__pdfs.slice(n0); const x = L[L.length - 1]; if (!x) return null; const bb = new Uint8Array(await x.arrayBuffer()); let s = ''; for (let i = 0; i < bb.length; i += 8192) s += String.fromCharCode.apply(null, bb.subarray(i, i + 8192)); return { n: L.length, b64: btoa(s) }; }, n0);
    if (out) { fs.writeFileSync(OUT + 'out-' + c.id + '.pdf', Buffer.from(out.b64, 'base64')); r.outFile = 'out-' + c.id + '.pdf'; r.outBytes = Buffer.from(out.b64, 'base64').length; }
    if (dl) { r.download = dl.suggestedFilename(); const fp = OUT + 'dl-' + c.id + '-' + r.download; await dl.saveAs(fp); r.dlBytes = fs.statSync(fp).size; r.dlSameAsMemory = r.dlBytes === r.outBytes; r.usedAfterDl1 = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
      dl = null; await p.waitForTimeout(1500); await dbtn.click(); await p.waitForTimeout(5000); await grab(); r.dl2 = { download: dl ? dl.suggestedFilename() : null, dialog: (await dlg.count()) ? (await dlg.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null, used: await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday) }; if (r.dl2.dialog) await p.screenshot({ path: OUT + 'dlg2-' + c.id + '.png' }); }
    if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + c.id + '.png' }); await p.keyboard.press('Escape'); }
   r.toasts = toasts; r.used1 = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
  } catch (e) { r.err = String(e).slice(0, 220); r.toasts = toasts; await p.screenshot({ path: OUT + 'err-' + c.id + '.png' }).catch(() => {}); }
  R.cases.push(r); save(); console.log(r.id, r.used0 + '/' + r.limit, r.afterUpload || '', r.outFile || '', r.outBytes || '', (r.dialog || '').slice(0, 60), r.err || '', toasts.join(' / ').slice(0, 200)); await ctx.close(); }
 R.t1 = now(); save(); await b.close(); })();
