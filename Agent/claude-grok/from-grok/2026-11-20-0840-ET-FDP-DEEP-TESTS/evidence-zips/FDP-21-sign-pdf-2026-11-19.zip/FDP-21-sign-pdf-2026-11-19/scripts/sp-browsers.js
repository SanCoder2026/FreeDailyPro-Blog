// sign-pdf: Firefox and WebKit desktop: upload contract.pdf, auto signature, place Signature + Date, Download -> cap dialog (at 0) or the download (with uses; counted). Captures the in-memory PDF.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/21-sign-pdf/live/'; const T = '/workspace/deep/21-sign-pdf/testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const R = { t: now() };
const HOOK = `(() => { window.__pdfs = []; const OB = window.Blob; window.Blob = class extends OB { constructor(parts, opts) { super(parts, opts); if (opts && /pdf/.test(opts.type || '')) window.__pdfs.push(this); } }; })();`;
(async () => { for (const eng of ['firefox', 'webkit']) { const b = await pw[eng].launch(); const ctx = await b.newContext({ viewport: { width: 1440, height: 900 } }); await ctx.addInitScript(HOOK); const p = await ctx.newPage(); p.setDefaultTimeout(15000); const r = {}; let crashed = false; p.on('crash', () => crashed = true);
  try { await p.goto('https://www.freedailypro.com/tool/sign-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); r.used0 = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
   await p.locator('main input[type=file]').first().setInputFiles(T + 'contract.pdf'); await p.waitForTimeout(4000); await p.locator('#sign-full-name').fill('Jane Q. Public'); await p.waitForTimeout(800);
   for (const [t, x] of [['Signature', 0.35], ['Date', 0.75]]) { await p.locator('main').getByRole('button', { name: t, exact: true }).last().click(); const cv = p.locator('main canvas.h-auto').first(); await cv.scrollIntoViewIfNeeded(); const bb = await cv.boundingBox(); await cv.click({ position: { x: bb.width * x, y: bb.height * 0.8 } }); await p.waitForTimeout(500); }
   r.placed = await p.evaluate(() => (document.querySelector('main').innerText.match(/✓ placed/g) || []).length);
   await p.getByRole('button', { name: 'Download Signed PDF' }).click(); await p.waitForTimeout(4000);
   r.dialog = await p.evaluate(() => { const d = document.querySelector('[role=dialog]'); return d ? d.innerText.slice(0, 60) : null; }); r.pdfs = await p.evaluate(() => window.__pdfs.map(x => x.size)); r.used1 = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
   await p.screenshot({ path: OUT + 'browser-' + eng + '.png' }); } catch (e) { r.err = String(e).slice(0, 150); }
  r.crashed = crashed; R[eng] = r; await b.close().catch(() => {}); }
 R.t2 = now(); fs.writeFileSync(OUT + 'browsers.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); })();
