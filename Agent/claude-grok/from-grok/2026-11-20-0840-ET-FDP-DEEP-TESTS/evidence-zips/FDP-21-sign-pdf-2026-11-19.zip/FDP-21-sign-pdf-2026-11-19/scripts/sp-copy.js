// sign-pdf: expand About / How to use / FAQ / Details / Guides and dump the copy, plus JSON-LD. No use spent.
const { chromium } = require('playwright'); const fs = require('fs');
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage();
 await p.goto(process.argv[2] || 'https://www.freedailypro.com/tool/sign-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 for (const n of ['About Sign PDF', 'How to use it', 'Common questions', 'Details: when to use it, limits, privacy', 'Guides and next steps']) { const x = p.getByRole('button', { name: n }); if (await x.count()) { await x.first().click(); await p.waitForTimeout(700); } }
 for (const x of await p.getByRole('button', { name: /Read more|Show more/ }).all()) await x.click().catch(() => {});
 for (const x of await p.locator('main details:not([open]) summary, main [aria-expanded=false]').all()) await x.click().catch(() => {});
 await p.waitForTimeout(800);
 fs.writeFileSync(process.argv[3] || '/workspace/deep/21-sign-pdf/tool-expanded.txt', await p.evaluate(() => document.querySelector('main').innerText));
 fs.writeFileSync((process.argv[3] || '/workspace/deep/21-sign-pdf/tool-expanded.txt') + '.jsonld.json', await p.evaluate(() => JSON.stringify([...document.querySelectorAll('script[type="application/ld+json"]')].map(s => JSON.parse(s.textContent)), null, 1)));
 await b.close(); })();
