// split-pdf: split-only scenarios in ONE fresh context (nothing is downloaded unless the context is uncapped AND DL=1). Records result list, toasts, dialogs, strip.
// Usage: node sp-explore.js [scenario,...]
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/05-split-pdf/live/'; const T = '/workspace/deep/05-split-pdf/testfiles/'; const URL = 'https://www.freedailypro.com/tool/split-pdf';
const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
const only = (process.argv[2] || '').split(',').filter(Boolean);
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); const R = { started: now(), runs: [] };
  const strip = () => p.evaluate(() => (document.body.innerText.match(/[^\n]*remaining today[^\n]*/) || [''])[0]);
  const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || 'null')?.usageToday;
  const toasts = () => p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(t => t.innerText.replace(/\n/g, ' ')).join(' | '));
  const dialogs = () => p.evaluate(() => [...document.querySelectorAll('[role=dialog],[role=alertdialog]')].map(t => t.innerText.replace(/\n+/g, ' | ').slice(0, 600)).join(' || '));
  const area = () => p.evaluate(() => { const m = document.querySelector('main').innerText; const a = m.indexOf('Nothing you enter or open is uploaded.'); const z = m.indexOf('Watch: Split PDF'); return m.slice(a + 39, z > a ? z : a + 3000).replace(/\n{2,}/g, '\n').slice(0, 3000); });
  const rangeBox = () => p.getByPlaceholder('1-3, 4-6');
  const S = [
    ['S01_ranges_separate', 'A_10p_bookmarks_links.pdf', async () => { await rangeBox().fill('1-3, 4-6, 7'); }],
    ['S02_every_page', 'A_10p_bookmarks_links.pdf', async () => { await p.getByRole('button', { name: 'Every page' }).click(); }],
    ['S03_every_3', 'A_10p_bookmarks_links.pdf', async L => { await p.getByLabel('Split every this many pages').fill('3'); await p.getByRole('button', { name: 'Apply' }).click(); await p.waitForTimeout(400); L.rangeAfterApply = await rangeBox().inputValue(); }],
    ['S04_combine_reorder', 'A_10p_bookmarks_links.pdf', async () => { await rangeBox().fill('7, 1-2, 9-10'); await p.getByRole('checkbox').first().check(); }],
    ['S05_overlap_dupes', 'A_10p_bookmarks_links.pdf', async () => { await rangeBox().fill('1-3, 2-4, 5, 5'); }],
    ['S06_mixed_sizes', 'B_mixed_rotated_5p.pdf', async () => { await rangeBox().fill('1-2, 3-5'); }],
    ['S07_nonlatin', 'G_nonlatin_4p.pdf', async () => { await rangeBox().fill('1-2, 3-4'); }],
    ['S08_form', 'H_form_3p.pdf', async () => { await rangeBox().fill('1, 2-3'); }],
    ['S09_owner_restricted', 'E_owner_restricted_6p.pdf', async () => { await rangeBox().fill('1-3, 4-6'); }],
    ['S10_300_every_page', 'F_large_300p.pdf', async () => { await p.getByRole('button', { name: 'Every page' }).click(); }],
    ['S11_single_page', 'C_single_page.pdf', null],
    ['S12_password', 'D_password_user123_6p.pdf', 'pw'],
  ];
  const BAD = ['L_truncated.pdf', 'M_garbage.pdf', 'N_text_renamed.pdf', 'O_png_renamed.pdf', 'P_empty.pdf', 'Q_image.jpg'];
  const INVALID = ['3-1', '11', '0', 'abc', '', '1-3,,5', '2-2', '1-', '-3', '1–3'];
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); R.load = { strip: await strip(), used: await used() };
  for (const [name, file, fn] of S) {
    if (only.length && !only.includes(name)) continue;
    const L = { name, file, t0: now() };
    try {
      await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500);
      await p.locator('input[type=file]').first().setInputFiles(T + file); await p.waitForTimeout(name.startsWith('S10') ? 6000 : 3000);
      L.afterAdd = { toast: await toasts(), dialog: await dialogs() };
      if (fn === 'pw') {
        const inp = p.getByRole('dialog').locator('input').first(); await inp.fill('wrong'); await p.getByRole('button', { name: 'Unlock' }).click(); await p.waitForTimeout(1500); L.wrong = await dialogs();
        await inp.fill('user123'); await p.getByRole('button', { name: 'Unlock' }).click(); await p.waitForTimeout(3000); L.unlocked = { toast: await toasts(), area: (await area()).slice(0, 300) };
        await rangeBox().fill('1-2, 3-6');
      } else if (fn) await fn(L);
      else { L.area = await area(); await p.screenshot({ path: OUT + 'x-' + name + '.png' }); R.runs.push(L); console.log(name, L.area.slice(0, 300)); continue; }
      L.splitButton = await p.evaluate(() => [...document.querySelectorAll('main button')].map(b => b.innerText.trim()).filter(t => /^Split/.test(t)));
      const t1 = Date.now(); await p.getByRole('button', { name: /^Split (PDF|into)/ }).first().click();
      for (let i = 0; i < 120; i++) { await p.waitForTimeout(1000); if (await p.evaluate(() => /Download|Get a Day Pass/.test(document.querySelector('main').innerText.split('Watch: Split PDF')[0].split('Combine all ranges')[1] || ''))) break; }
      L.ms = Date.now() - t1; await p.waitForTimeout(800);
      L.area = await area(); L.toast = await toasts(); L.dialog = await dialogs(); L.strip = await strip(); L.used = await used();
      L.downloadButtons = await p.evaluate(() => [...document.querySelectorAll('main button, main a')].map(b => (b.getAttribute('aria-label') || b.innerText).trim()).filter(t => /download|zip|day pass|drive|cloud/i.test(t)).slice(0, 12));
      L.renameInputs = await p.evaluate(() => [...document.querySelectorAll('main input[type=text]')].map(i => i.placeholder || i.value).slice(0, 5));
      await p.screenshot({ path: OUT + 'x-' + name + '.png', fullPage: true });
    } catch (e) { L.error = e.message.split('\n')[0]; await p.screenshot({ path: OUT + 'x-' + name + '-error.png' }).catch(() => {}); }
    L.t1 = now(); R.runs.push(L); console.log(name, L.ms, '|', (L.area || '').replace(/\n/g, ' / ').slice(-500), '|', L.toast, L.error || '');
  }
  if (!only.length || only.includes('BAD')) for (const f of BAD) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3000); await p.locator('input[type=file]').first().setInputFiles(T + f); await p.waitForTimeout(2500); const r = { name: 'BAD_' + f, toast: await toasts(), dialog: await dialogs() }; R.runs.push(r); console.log(r.name, r.toast); }
  if (!only.length || only.includes('INVALID')) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3000); await p.locator('input[type=file]').first().setInputFiles(T + 'A_10p_bookmarks_links.pdf'); await p.waitForTimeout(2500);
    for (const v of INVALID) { await rangeBox().fill(v); await p.waitForTimeout(500); const r = { name: 'INVALID_' + (v || 'empty'), splitBtn: await p.evaluate(() => [...document.querySelectorAll('main button')].filter(b => /^Split/.test(b.innerText.trim())).map(b => b.innerText.trim() + (b.disabled ? ' [disabled]' : ''))), msg: await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*(outside|isn't|starts after|Enter|invalid|only has|valid|no page)[^\n]*/gi) || []).slice(0, 4)), aria: await rangeBox().getAttribute('aria-invalid') };
      const btn = p.getByRole('button', { name: /^Split (PDF|into)/ }).first(); if (await btn.isEnabled()) { await btn.click(); await p.waitForTimeout(1500); r.afterClick = { toast: await toasts(), area: (await area()).slice(-250) }; }
      R.runs.push(r); console.log(r.name, JSON.stringify(r).slice(0, 400)); await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(2500); await p.locator('input[type=file]').first().setInputFiles(T + 'A_10p_bookmarks_links.pdf'); await p.waitForTimeout(2000); } }
  R.finished = now(); const f = OUT + `explore-${Date.now()}.json`; fs.writeFileSync(f, JSON.stringify(R, null, 1)); console.log('wrote', f, JSON.stringify(R.load)); await b.close();
})();
