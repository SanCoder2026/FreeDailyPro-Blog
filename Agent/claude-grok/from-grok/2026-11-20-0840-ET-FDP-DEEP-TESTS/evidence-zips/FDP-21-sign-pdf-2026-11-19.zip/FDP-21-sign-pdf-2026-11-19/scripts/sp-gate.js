// sign-pdf: starting count; axe idle / after upload / with fields; keyboard: reach drop zone, can a field be placed without a mouse?; names of style buttons, draw pads, radios;
// Download at the starting count (at 0: cap dialog -> Buy Day Pass -> email prompt, types nothing); result-side buttons; phones (touch placement). Never signs in; "Open from Google Drive" is not clicked.
const { chromium, devices } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/21-sign-pdf/live/'; const T = '/workspace/deep/21-sign-pdf/testfiles/'; const URL = 'https://www.freedailypro.com/tool/sign-pdf';
const AXE = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8'); const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const axe = async p => { await p.addScriptTag({ content: AXE }); return p.evaluate(async () => (await axe.run(document.querySelector('main'), { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'best-practice'] }, resultTypes: ['violations'] })).violations.map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length, t: v.nodes.slice(0, 4).map(n => n.target.join(' ')) }))); };
(async () => { const b = await chromium.launch(); const R = { t: now() };
 const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(12000);
 await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 R.start = await used(); R.limit = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').limit); R.strip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]); R.axeIdle = await axe(p);
 let chooser = false; p.on('filechooser', () => { chooser = true; }); const seq = [];
 for (let i = 0; i < 60; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('role') || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50).replace(/\n/g, ' '); }); seq.push(a); if (/Drop a PDF/i.test(a)) { await p.keyboard.press('Enter'); await p.waitForTimeout(1200); seq.push('ENTER -> chooser=' + chooser); break; } }
 R.kbd = { tabs: seq.length, last: seq.slice(-3), chooser };
 await p.locator('main input[type=file]').first().setInputFiles(T + 'contract.pdf'); await p.waitForTimeout(3500);
 await p.locator('#sign-full-name').fill('Jane Q. Public'); await p.locator('#sign-initials').fill('JQP'); await p.waitForTimeout(600);
 R.names = await p.evaluate(() => ({ styleButtons: [...document.querySelectorAll('main button[aria-pressed]')].map(b => b.getAttribute('aria-label') || b.innerText.trim()).slice(0, 8), canvases: [...document.querySelectorAll('main canvas')].map(c => ({ aria: c.getAttribute('aria-label'), role: c.getAttribute('role'), tab: c.tabIndex, w: c.width, h: c.height })), radios: [...document.querySelectorAll('main input[type=radio]')].map(r => (r.labels && r.labels[0] ? r.labels[0].innerText.trim().slice(0, 40) : null) + ' name=' + r.name) }));
 R.axeUpload = await axe(p);
 // keyboard placement: add a Signature field with the keyboard, then try Enter/Space on the preview and Tab around
 await p.locator('main').getByRole('button', { name: 'Signature', exact: true }).last().focus(); await p.keyboard.press('Enter'); await p.waitForTimeout(600);
 const kseq = []; for (let i = 0; i < 25; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 40).replace(/\n/g, ' '); }); kseq.push(a); if (/Download Signed/.test(a)) break; }
 R.kbdPlace = { seq: kseq, canvasFocusable: kseq.some(x => x.startsWith('CANVAS')), placedText: await p.evaluate(() => (document.querySelector('main').innerText.match(/Click to place|placed|Not placed/gi) || []).slice(0, 4)) };
 const cv = p.locator('main canvas.h-auto').first(); await cv.scrollIntoViewIfNeeded(); const bb = await cv.boundingBox(); await cv.click({ position: { x: bb.width * 0.35, y: bb.height * 0.8 } }); await p.waitForTimeout(600);
 R.fieldTable = await p.evaluate(() => (document.querySelector('main').innerText.match(/Fields\n[\s\S]{0,500}/) || [null])[0]);
 R.axeFields = await axe(p); R.liveRegions = await p.evaluate(() => [...document.querySelectorAll('main [aria-live],main [role=status],main [role=alert]')].map(e => ({ live: e.getAttribute('aria-live'), role: e.getAttribute('role'), text: e.innerText.slice(0, 80) })));
 R.resultButtons = await p.evaluate(() => [...document.querySelectorAll('main button, main a')].map(b => b.innerText.trim()).filter(x => /Download|Drive|cloud|Pass|Share|Copy|Print|Start Over|Flatten|Compress/i.test(x) && x.length < 80));
 await p.screenshot({ path: OUT + 'fields-desktop.png', fullPage: true });
 R.download = { before: await used() }; await p.getByRole('button', { name: 'Download Signed PDF' }).click(); await p.waitForTimeout(3000); R.download.dialog = await dialog(); R.download.after = await used();
 if (R.download.dialog) { await p.screenshot({ path: OUT + 'dlg-download.png' }); const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.download.dayPass = { dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); } }
 for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); }
 R.afterEsc = { fieldsKept: await p.evaluate(() => /Jane Q\. Public/.test(document.querySelector('#sign-full-name').value)), used: await used() };
 R.end = await used(); await c.close();
 for (const [nm, d] of [['iphone-se', devices['iPhone SE']], ['pixel-7', devices['Pixel 7']]]) { const { defaultBrowserType, ...dd } = d; const c2 = await b.newContext(dd); const q = await c2.newPage(); q.setDefaultTimeout(12000); const r = {};
  try { await q.goto(URL, { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4000); await q.locator('main input[type=file]').first().setInputFiles(T + 'contract.pdf'); await q.waitForTimeout(3500);
   await q.locator('#sign-full-name').fill('Jane Q. Public'); await q.locator('main').getByRole('button', { name: 'Signature', exact: true }).last().tap(); await q.waitForTimeout(500);
   const cv2 = q.locator('main canvas.h-auto').first(); await cv2.scrollIntoViewIfNeeded(); const b2 = await cv2.boundingBox(); await cv2.tap({ position: { x: b2.width * 0.35, y: b2.height * 0.8 } }); await q.waitForTimeout(600);
   r.placed = await q.evaluate(() => (document.querySelector('main').innerText.match(/Fields\n[\s\S]{0,300}/) || [null])[0]);
   r.layout = await q.evaluate(() => { const t = s => { const e = [...document.querySelectorAll('main button')].find(b => b.innerText.trim().startsWith(s)); return e ? Math.round(e.getBoundingClientRect().top + scrollY) : null; }; return { vh: innerHeight, previewW: Math.round(document.querySelector('main canvas.h-auto').getBoundingClientRect().width), downloadTop: t('Download Signed'), overflowX: document.documentElement.scrollWidth > innerWidth + 1, tableOverflow: [...document.querySelectorAll('main table')].map(tb => tb.scrollWidth > tb.parentElement.clientWidth + 1) }; });
   await q.screenshot({ path: OUT + `layout-${nm}.png`, fullPage: true }); } catch (e) { r.err = String(e).slice(0, 200); }
  R[nm] = r; await c2.close(); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate-kbd.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
