// sign-pdf: import a signature image (transparent PNG, white JPG) and check whether it is accepted (preview image appears / Download proceeds to the gate). No use spent at 0.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/21-sign-pdf/live/'; const T = '/workspace/deep/21-sign-pdf/testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const R = { t: now(), runs: [] };
 for (const img of ['sig.png', 'sig-white.jpg']) { const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); p.setDefaultTimeout(10000); const r = { img };
  await p.goto('https://www.freedailypro.com/tool/sign-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
  r.used0 = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
  await p.locator('main input[type=file]').first().setInputFiles(T + 'contract.pdf'); await p.waitForTimeout(3000);
  await p.locator('#sign-full-name').fill('Jane Q. Public');
  r.fileInputs = await p.locator('main input[type=file]').evaluateAll(es => es.map(e => e.accept));
  const radio = p.locator('main input[type=radio]').first(); await radio.check().catch(e => r.radioErr = String(e).slice(0, 100)); r.radioChecked = await radio.isChecked();
  const ch = p.waitForEvent('filechooser', { timeout: 5000 }).catch(() => null); await p.getByRole('button', { name: 'Choose image' }).first().click(); const fc = await ch; r.chooser = !!fc; if (fc) await fc.setFiles(T + img); await p.waitForTimeout(2500);
  r.toasts = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim()));
  r.sigPreviewImgs = await p.evaluate(() => [...document.querySelectorAll('main img')].filter(i => /^(blob|data):/.test(i.src)).length);
  await p.locator('main').getByRole('button', { name: 'Signature', exact: true }).last().click(); const cv = p.locator('main canvas.h-auto').first(); await cv.scrollIntoViewIfNeeded(); const bb = await cv.boundingBox(); await cv.click({ position: { x: bb.width * 0.35, y: bb.height * 0.8 } }); await p.waitForTimeout(500);
  await p.getByRole('button', { name: 'Download Signed PDF' }).click(); await p.waitForTimeout(3000);
  r.after = await p.evaluate(() => ({ dialog: !!document.querySelector('[role=dialog]'), err: [...document.querySelectorAll('main p')].map(e => e.innerText).filter(t => /Set up|first/.test(t) && t.length < 150) }));
  await p.screenshot({ path: OUT + 'import-' + img.replace('.', '_') + '.png' }); R.runs.push(r); console.log(JSON.stringify(r)); await p.context().close(); }
 fs.writeFileSync(OUT + 'import.json', JSON.stringify(R, null, 1)); await b.close(); })();
