// split-pdf: thumbnails as selectors?, capped Download / ZIP click (dialog only), keyboard + focus, axe on the result view, result-row layout desktop + Pixel 7, "1-" range result, cloud dialog (Not now). No sign-in; Google Drive not clicked.
const { chromium, devices } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/05-split-pdf/live/'; const T = '/workspace/deep/05-split-pdf/testfiles/'; const URL = 'https://www.freedailypro.com/tool/split-pdf';
const now = () => cp.execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); const R = { t: now() };
  const focused = () => p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50); });
  const dialogs = () => p.evaluate(() => [...document.querySelectorAll('[role=dialog],[role=alertdialog]')].map(t => t.innerText.replace(/\n+/g, ' | ').slice(0, 600)).join(' || '));
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  R.strip = await p.evaluate(() => (document.body.innerText.match(/[^\n]*remaining today[^\n]*/) || [''])[0]);
  const dz = p.locator('main [role=button]').filter({ hasText: 'Drop a PDF' }).first();
  await dz.focus().catch(() => {}); try { const [fc] = await Promise.all([p.waitForEvent('filechooser', { timeout: 4000 }), p.keyboard.press('Enter')]); R.enterOpensChooser = true; await fc.setFiles(T + 'A_10p_bookmarks_links.pdf'); } catch { R.enterOpensChooser = false; await p.locator('input[type=file]').first().setInputFiles(T + 'A_10p_bookmarks_links.pdf'); }
  await p.waitForTimeout(3000); R.focusAfterAdd = await focused();
  R.thumbs = await p.evaluate(() => [...document.querySelectorAll('main img, main canvas')].slice(0, 3).map(e => ({ tag: e.tagName, alt: e.alt || e.getAttribute('aria-label'), role: e.closest('button,[role=button],[role=checkbox]') ? e.closest('button,[role=button],[role=checkbox]').getAttribute('aria-label') || 'clickable' : null })));
  const before = await p.getByPlaceholder('1-3, 4-6').inputValue(); await p.locator('main img, main canvas').nth(2).click({ trial: false }).catch(() => {}); await p.waitForTimeout(800);
  R.thumbClick = { rangeBefore: before, rangeAfter: await p.getByPlaceholder('1-3, 4-6').inputValue(), dialog: await dialogs() }; await p.keyboard.press('Escape');
  await p.getByPlaceholder('1-3, 4-6').fill('1-'); await p.getByRole('button', { name: /^Split (PDF|into \d+ files?)$/ }).first().focus(); await p.keyboard.press('Enter'); await p.waitForTimeout(2500);
  R.openEndedRange = await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*-pages?-[^\n]*\.pdf\n[^\n]*/g) || []).slice(0, 3));
  R.focusAfterSplit = await focused();
  await p.getByPlaceholder('1-3, 4-6').fill('1-3, 4-6, 7'); await p.getByRole('button', { name: /^Split (PDF|into \d+ files?)$/ }).first().click(); await p.waitForTimeout(2500);
  R.liveRegions = await p.evaluate(() => [...document.querySelectorAll('[aria-live],[role=status],[role=alert]')].map(e => (e.getAttribute('aria-live') || e.getAttribute('role')) + ':' + e.innerText.replace(/\n/g, ' ').slice(0, 120)).filter(x => x.length > 9));
  R.zipButtons = await p.evaluate(() => [...document.querySelectorAll('main button')].filter(b => /ZIP/.test(b.innerText)).map(b => { const r = b.getBoundingClientRect(); return { text: b.innerText.trim(), x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width) }; }));
  R.rowLabelWidths = await p.evaluate(() => [...document.querySelectorAll('main *')].filter(e => /\.pdf$/.test((e.innerText || '').trim()) && e.children.length === 0).map(e => ({ t: e.innerText.slice(0, 40), w: Math.round(e.getBoundingClientRect().width) })).slice(0, 4));
  await p.addScriptTag({ path: require.resolve('axe-core/axe.min.js') });
  R.axeResult = await p.evaluate(async () => (await axe.run(document.querySelector('main'), { resultTypes: ['violations'] })).violations.map(v => ({ id: v.id, impact: v.impact, count: v.nodes.length, sample: v.nodes.slice(0, 2).map(n => n.target.join(' ') + ' :: ' + (n.failureSummary || '').split('\n')[1]) })));
  await p.screenshot({ path: OUT + 'kbd-result-view.png', fullPage: true });
  let d = null; p.once('download', x => d = x); await p.getByRole('button', { name: /^Download all \d+ files as ZIP$/ }).click().catch(e => R.zipErr = e.message.split('\n')[0]); await p.waitForTimeout(2500);
  R.zipClick = { download: d ? d.suggestedFilename() : null, dialog: await dialogs() }; await p.screenshot({ path: OUT + 'capped-zip-click.png' }); await p.keyboard.press('Escape'); await p.waitForTimeout(500);
  d = null; p.once('download', x => d = x); await p.getByRole('button', { name: 'Download', exact: true }).first().click().catch(e => R.dlErr = e.message.split('\n')[0]); await p.waitForTimeout(2500);
  R.dlClick = { download: d ? d.suggestedFilename() : null, dialog: await dialogs() }; await p.keyboard.press('Escape'); await p.waitForTimeout(500);
  const btn = p.getByRole('button', { name: /Save to my cloud storage/ }).first();
  if (await btn.count()) { await btn.click(); await p.waitForTimeout(2000); R.cloudDialog = await dialogs(); const nn = p.getByRole('button', { name: 'Not now' }); if (await nn.count()) await nn.first().click(); else await p.keyboard.press('Escape'); }
  await ctx.close();
  const c2 = await b.newContext({ ...devices['Pixel 7'] }); const q = await c2.newPage();
  await q.goto(URL, { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4000); q.on('dialog', x => x.dismiss());
  await q.locator('input[type=file]').first().setInputFiles(T + 'A_10p_bookmarks_links.pdf'); await q.waitForTimeout(3000);
  await q.getByPlaceholder('1-3, 4-6').fill('1-3, 4-6, 7'); await q.getByRole('button', { name: /^Split (PDF|into \d+ files?)$/ }).first().click(); await q.waitForTimeout(3000);
  R.phone = await q.evaluate(() => ({ sw: document.documentElement.scrollWidth, vw: innerWidth })); R.phoneStrip = await q.evaluate(() => (document.body.innerText.match(/[^\n]*remaining today[^\n]*/) || [''])[0]);
  await q.screenshot({ path: OUT + 'phone-result-view.png', fullPage: true });
  R.t2 = now(); fs.writeFileSync(OUT + 'kbd.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close();
})();
