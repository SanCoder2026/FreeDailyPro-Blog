// sign-pdf: the other party's turn: open out-S02.pdf (2 empty fields left for the other party) and see whether the fields are found and placed automatically; sign them; capture the in-memory PDF (gate at 0).
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/21-sign-pdf/live/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const HOOK = `(() => { window.__pdfs = []; const OB = window.Blob; window.Blob = class extends OB { constructor(parts, opts) { super(parts, opts); if (opts && /pdf/.test(opts.type || '')) window.__pdfs.push(this); } }; })();`;
(async () => { const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); await ctx.addInitScript(HOOK); const p = await ctx.newPage(); p.setDefaultTimeout(10000); const r = { t: now() };
 await p.goto('https://www.freedailypro.com/tool/sign-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); r.used0 = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 await p.locator('main input[type=file]').first().setInputFiles(OUT + 'out-S02.pdf'); await p.waitForTimeout(4000);
 r.toasts = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim()));
 r.fieldTable = await p.evaluate(() => (document.querySelector('main').innerText.match(/#\tType[\s\S]{0,400}/) || [null])[0]);
 await p.locator('#sign-full-name').fill('John Client'); await p.locator('#sign-initials').fill('JC'); await p.waitForTimeout(800);
 await p.screenshot({ path: OUT + 'otherparty-loaded.png', fullPage: false });
 if (r.used0 >= 2) { await p.getByRole('button', { name: 'Download Signed PDF' }).click(); await p.waitForTimeout(4000); r.inlineErr = await p.evaluate(() => [...document.querySelectorAll('main p')].map(e => e.innerText).filter(t => /first|placed/.test(t) && t.length < 150));
  const out = await p.evaluate(async () => { const x = window.__pdfs[window.__pdfs.length - 1]; if (!x) return null; const bb = new Uint8Array(await x.arrayBuffer()); let s = ''; for (let i = 0; i < bb.length; i += 8192) s += String.fromCharCode.apply(null, bb.subarray(i, i + 8192)); return btoa(s); });
  if (out) { fs.writeFileSync(OUT + 'out-S02-otherparty.pdf', Buffer.from(out, 'base64')); r.out = 'out-S02-otherparty.pdf'; } } else r.note = 'context had uses; Download not clicked';
 r.t2 = now(); fs.writeFileSync(OUT + 'otherparty.json', JSON.stringify(r, null, 1)); console.log(JSON.stringify(r, null, 1)); await b.close(); })();
