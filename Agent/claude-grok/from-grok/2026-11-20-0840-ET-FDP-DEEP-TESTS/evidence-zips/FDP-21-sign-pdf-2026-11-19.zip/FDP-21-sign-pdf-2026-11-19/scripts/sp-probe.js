// sign-pdf probe: starting counts (all localStorage keys), controls after upload, fields flow up to (not including) Download. No use spent.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/21-sign-pdf/live/'; const T = '/workspace/deep/21-sign-pdf/testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(10000); const R = { t: now() };
 await p.goto('https://www.freedailypro.com/tool/sign-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 R.ls = await p.evaluate(() => Object.fromEntries(Object.keys(localStorage).filter(k => /usage|trial|fdp/i.test(k)).map(k => [k, localStorage.getItem(k).slice(0, 300)])));
 R.strip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]);
 await p.locator('main input[type=file]').first().setInputFiles(T + 'contract.pdf'); await p.waitForTimeout(3500);
 await p.locator('#sign-full-name').fill('Jane Q. Public'); await p.locator('#sign-initials').fill('JQP'); await p.waitForTimeout(800);
 R.controls = await p.evaluate(() => [...document.querySelectorAll('main button, main input, main select, main [role=radio], main [role=tab], main canvas')].map(e => ({ tag: e.tagName, type: e.type || '', id: e.id, aria: e.getAttribute('aria-label'), pressed: e.getAttribute('aria-pressed'), title: e.title || '', text: (e.innerText || e.value || '').trim().slice(0, 50), testid: e.dataset.testid || null })).filter(x => !/^(About|Common|Details|Guides|Share|Create Shortcut|Subscribe)/.test(x.text)));
 R.text = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 5000));
 await p.screenshot({ path: OUT + 'probe-after-upload.png', fullPage: true });
 fs.writeFileSync(OUT + 'probe.json', JSON.stringify(R, null, 1)); await b.close(); })();
