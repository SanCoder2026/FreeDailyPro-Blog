// split-pdf: what lenient range inputs actually produce (row labels, no download). One capped/guest context.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const T = '/workspace/deep/05-split-pdf/testfiles/'; const R = { t: cp.execSync('date "+%F %T %Z"').toString().trim(), cases: [] };
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage();
  await p.goto('https://www.freedailypro.com/tool/split-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); R.strip = await p.evaluate(() => (document.body.innerText.match(/[^\n]*remaining today[^\n]*/) || [''])[0]);
  await p.locator('input[type=file]').first().setInputFiles(T + 'A_10p_bookmarks_links.pdf'); await p.waitForTimeout(3000);
  for (const r of ['1–3', '8-', '1-3,,5', '1-3 4-6', '1-3;4-6', ' 2 , 4 ', '1-10']) {
    await p.getByPlaceholder('1-3, 4-6').fill(r); await p.waitForTimeout(400); const btn = p.getByRole('button', { name: /^Split (PDF|into \d+ files?)$/ }).first(); const dis = await btn.isDisabled();
    const inline = await p.evaluate(() => [...document.querySelectorAll('main [id*=error],main [role=alert],main p')].map(e => e.innerText).filter(t => /valid|outside|ends|Enter at least/.test(t)).join(' | '));
    if (!dis) { await btn.click(); await p.waitForTimeout(2000); }
    const rows = await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*-pages?-[^\n]*\.pdf\n[^\n]*\n?[^\n]*/g) || []).map(s => s.replace(/\n/g, ' ¦ ')).slice(0, 6));
    R.cases.push({ input: r, disabled: dis, inline, rows }); }
  fs.writeFileSync('/workspace/deep/05-split-pdf/live/ranges-rows.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
