const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/jszip.min-CT0ZA6V1.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/jszip.min-C-FLQHAz.js",
      "assets/_commonjs-dynamic-modules-TDtrdbi3.js",
    ]),
) => i.map((i) => d[i]);
import { r as n, j as e } from "./vendor-react-D01g8YgM.js";
import { u as jt } from "./useShareGate-BKOKt_4Z.js";
import {
  b as yt,
  T as Nt,
  F as Xe,
  P as le,
  d as He,
  R as Be,
  D as Gt,
} from "./ToolPage-DS5jbfzr.js";
import {
  v as Ct,
  f as p,
  e as V,
  B as f,
  aJ as kt,
  N as Jt,
  aA as Zt,
  W as et,
  D as rt,
  ar as qt,
  as as Yt,
  at as Qt,
  au as Xt,
  av as es,
  ap as St,
  aF as ts,
  aL as ss,
  T as as,
  b as Ge,
  k as Je,
  a0 as rs,
  be as os,
  aP as ns,
  I as Ue,
  bh as is,
} from "./index-D2ZT81un.js";
import { T as Pt } from "./ToolInfoSection-M0kcUBq8.js";
import { T as ls } from "./TrialFooterNotice-CAAe1Tug.js";
import {
  S as re,
  a as oe,
  b as ne,
  c as ie,
  d as I,
} from "./select-DC0cHVOZ.js";
import {
  x as Ft,
  U as Dt,
  X as Ze,
  Y as cs,
  z as ds,
  V as ms,
  n as ps,
  e as us,
  a as fs,
  g as hs,
  A as xs,
} from "./operations-DhLfXHFN.js";
import {
  detectKind as Oe,
  TARGETS_BY_KIND as X,
  KIND_LABEL as fe,
  extOf as Pe,
  stripExt as We,
  ALL_KINDS as gs,
  KIND_EXT as bs,
  conversionTable as ws,
  showStageDownload as vs,
} from "./universalCore-mY4FT3mW.js";
import { f as js, d as ys, r as Ns, a as Cs } from "./reorderMath-CVj9Q6Gj.js";
import { G as ks } from "./grip-vertical-DByVgYfD.js";
import { A as Ss } from "./arrow-down-CLm47Ets.js";
import { T as Ps } from "./trash-2-BJfoOy34.js";
import { F as Tt } from "./file-archive-6p4RQv0N.js";
import { S as ot } from "./share-2-wJ7OG3q6.js";
import { P as Fs } from "./pencil-D3kmaJ3E.js";
import { C as zt } from "./copy-DxyF2bO9.js";
import { C as Ds } from "./checkbox-Du8eLd-S.js";
import { D as nt } from "./DragCropSelector-uGcm88aI.js";
import { l as it, r as lt } from "./utils-s8ucLyj8.js";
import {
  r as Ts,
  a as zs,
  l as Is,
  b as $s,
  c as Rs,
} from "./operations-ISiPxXUp.js";
import {
  s as ct,
  b as dt,
  a as mt,
  l as pt,
  u as As,
} from "./qualityOperations-BSS9nv6A.js";
import { C as Ms } from "./chevron-up-Bx33pgGu.js";
import { M as ut } from "./maximize-2-j9VCawlT.js";
import { C as ft } from "./crop-BNhT7cjd.js";
import { R as ht } from "./rotate-cw-BeEjcc-w.js";
import { l as Es } from "./utils-BCX55KBw.js";
import "./useExportGate-CcXGEF0S.js";
import "./useUploadApi-CeBVbB2U.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-mA9gIB_c.js";
import "./workflowCta-QcLjv4ms.js";
import "./UsageAndUpgradeStrip-Ckl_cEoN.js";
import "./access-BBg1iIm1.js";
import "./useAdminAccess-D2xxeUJv.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-BaZhqv4P.js";
import "./map-pin-DiPhQKiV.js";
import "./FaqSection-DgbFc-d2.js";
import "./ToolVideoEmbed-DltoCXpM.js";
import "./GuideLinks-BsEl-oB0.js";
import "./blog-Cqpj3gtZ.js";
import "./info-BGlOhDp4.js";
import "./productCards-CAZfINO_.js";
import "./layers-B7zHnkyf.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-CmqWEytu.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./pdfMetadata-CcxIhQF2.js";
import "./pageView-BQIwVYOi.js";
import "./formAppearance-CdNbuISd.js";
import "./drawTextAnywhere-DcuP6lHH.js";
import "./ocrText-C_9cxcFa.js";
import "./ocrImage-CmXFNUud.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./imageRecompress-eXQFDUm-.js";
import "./formatFileSize-B-JRDfN5.js";
import "./plural-FIChqbp4.js";
import "./textDiff-DxE9AzvO.js";
import "./formFill-Dg9Myfyq.js";
import "./redactSearch-DQpyyh_t.js";
import "./nameDetect-DvHCRM0m.js";
import "./legacyDeck-DRWwmRY1.js";
import "./trpcVanilla-DLV8pXkC.js";
import "./textToPdf-BuGdG5vq.js";
import "./mdConvert-ChWDCiEy.js";
import "./index-CHifq31M.js";
import "./decode-D7I8Qajh.js";
const tt = Ct("Combine", [
  ["path", { d: "M10 18H5a3 3 0 0 1-3-3v-1", key: "ru65g8" }],
  ["path", { d: "M14 2a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2", key: "e30een" }],
  ["path", { d: "M20 2a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2", key: "2ahx8o" }],
  ["path", { d: "m7 21 3-3-3-3", key: "127cv2" }],
  [
    "rect",
    { x: "14", y: "14", width: "8", height: "8", rx: "2", key: "1b0bso" },
  ],
  ["rect", { x: "2", y: "2", width: "8", height: "8", rx: "2", key: "1x09vl" }],
]);
const Ls = Ct("Hash", [
    ["line", { x1: "4", x2: "20", y1: "9", y2: "9", key: "4lhtct" }],
    ["line", { x1: "4", x2: "20", y1: "15", y2: "15", key: "vyu0kd" }],
    ["line", { x1: "10", x2: "8", y1: "3", y2: "21", key: "1ggp8o" }],
    ["line", { x1: "16", x2: "14", y1: "3", y2: "21", key: "weycgp" }],
  ]),
  st = 20,
  Fe = (r) => {
    const c = r.toLowerCase().match(/\.([^./]+)$/);
    return c ? c[1] : "";
  },
  It = (r) => r.type === "application/pdf" || Fe(r.name) === "pdf",
  $t = (r) =>
    /^image\/(png|jpeg|webp)$/.test(r.type ?? "") ||
    ["png", "jpg", "jpeg", "webp"].includes(Fe(r.name)),
  Rt = (r) => ["txt", "md", "html", "htm", "csv", "json"].includes(Fe(r.name));
function xt(r) {
  return It(r) ? "pdf" : $t(r) ? "image" : Rt(r) ? "text" : null;
}
function gt(r) {
  return r.length < 2
    ? null
    : r.every((c) => It(c) || $t(c))
      ? "pdf"
      : r.every((c) => Fe(c.name) === "txt")
        ? "text"
        : null;
}
function bt(r) {
  return /^image\/(png)$/.test(r.type ?? "") || Fe(r.name) === "png"
    ? "image"
    : Rt(r)
      ? "text"
      : null;
}
function Us(r, c) {
  if (!c.has(r)) return (c.add(r), r);
  const d = r.lastIndexOf("."),
    D = d > 0 ? r.slice(0, d) : r,
    h = d > 0 ? r.slice(d) : "";
  for (let j = 2; ; j++) {
    const g = `${D} (${j})${h}`;
    if (!c.has(g)) return (c.add(g), g);
  }
}
function Bs(r, c) {
  const d = Math.max(0, st - r);
  return { accepted: c.slice(0, d), dropped: Math.max(0, c.length - d) };
}
const Os =
    ".jpg,.jpeg,.png,.webp,.heic,.pdf,.txt,.html,.htm,.md,.xlsx,.xls,.csv,.ppt,.pptx,.doc,.docx",
  at = () =>
    typeof crypto < "u" && "randomUUID" in crypto
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.random()}`,
  qe = (r) =>
    r < 1024 * 1024
      ? `${Math.max(1, Math.round(r / 1024))} KB`
      : `${(r / 1024 / 1024).toFixed(1)} MB`,
  ue = (r, c) =>
    new File([r], c, { type: r.type || "application/octet-stream" });
async function Ws(r, c, d) {
  if (/-images\.zip$/i.test(c)) {
    const { default: h } = await St(
        async () => {
          const { default: T } = await import("./jszip.min-CT0ZA6V1.js").then(
            (b) => b.j,
          );
          return { default: T };
        },
        __vite__mapDeps([0, 1, 2, 3]),
      ),
      j = await h.loadAsync(r),
      g = Object.values(j.files)
        .filter((T) => !T.dir)
        .sort((T, b) => T.name.localeCompare(b.name)),
      S = [];
    for (const T of g) {
      const b = T.name.split("/").pop() ?? T.name,
        O =
          (b.toLowerCase().match(/\.([^.]+)$/) ?? [])[1] === "png"
            ? "image/png"
            : "image/jpeg";
      S.push({
        id: at(),
        blob: new Blob([await T.async("arraybuffer")], { type: O }),
        fileName: b,
      });
    }
    if (S.length > 0) return S;
  }
  const D = Pe(c).toLowerCase() === Pe(d).toLowerCase();
  return [
    { id: at(), blob: r, fileName: D ? `${We(c)}-converted${Pe(c)}` : c },
  ];
}
function wt(r) {
  try {
    return (
      typeof navigator < "u" &&
      typeof navigator.share == "function" &&
      (typeof navigator.canShare != "function" ||
        navigator.canShare({ files: r }))
    );
  } catch {
    return !1;
  }
}
function _s(r, c) {
  const d = (r.toLowerCase().match(/\.([^./]+)$/) ?? [])[1] ?? "";
  return ["txt", "md", "html", "htm", "csv", "json"].includes(d)
    ? "text"
    : c.startsWith("image/") ||
        c === "application/pdf" ||
        [
          "pdf",
          "png",
          "jpg",
          "jpeg",
          "webp",
          "ico",
          "xlsx",
          "xls",
          "pptx",
          "ppt",
        ].includes(d)
      ? "media"
      : "none";
}
function Vs(r, c) {
  if (c) return c;
  const d = (r.toLowerCase().match(/\.([^./]+)$/) ?? [])[1] ?? "";
  return (
    {
      pdf: "application/pdf",
      png: "image/png",
      jpg: "image/jpeg",
      jpeg: "image/jpeg",
      webp: "image/webp",
      ico: "image/x-icon",
      xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    }[d] ?? "application/octet-stream"
  );
}
function Ye({ blob: r, name: c }) {
  const d = _s(c, r.type),
    [D, h] = n.useState(null);
  return (
    n.useEffect(() => {
      if (d !== "text") return;
      let j = !0;
      return (
        r
          .slice(0, 6e3)
          .text()
          .then(
            (g) =>
              j &&
              h(
                g +
                  (r.size > 6e3
                    ? `
…`
                    : ""),
              ),
          ),
        () => {
          j = !1;
        }
      );
    }, [r, d]),
    d === "text"
      ? e.jsx("pre", {
          className:
            "max-h-64 overflow-auto rounded-lg border bg-muted/30 p-3 text-xs whitespace-pre-wrap break-words",
          children: D ?? "Loading…",
        })
      : d === "media"
        ? e.jsx(Be, { blob: r, mimeType: Vs(c, r.type) })
        : e.jsx("p", {
            className: "text-sm text-muted-foreground",
            children:
              "A preview isn't available for this file type. It will still convert.",
          })
  );
}
function Ks({ file: r, onUse: c, onCancel: d }) {
  const [D, h] = n.useState(null);
  return (
    n.useEffect(() => {
      let j = !0;
      return (
        r.text().then((g) => j && h(g)),
        () => {
          j = !1;
        }
      );
    }, [r]),
    D === null
      ? e.jsx(le, { message: "Opening..." })
      : e.jsxs("div", {
          className: "space-y-3",
          children: [
            e.jsx(as, {
              value: D,
              onChange: (j) => h(j.target.value),
              rows: 14,
              className: "font-mono text-xs",
              spellCheck: !1,
            }),
            e.jsxs("div", {
              className: "flex flex-wrap gap-2 justify-end",
              children: [
                e.jsx(f, {
                  variant: "outline",
                  onClick: d,
                  children: "Cancel",
                }),
                e.jsx(f, {
                  onClick: () =>
                    c(new File([D], r.name, { type: r.type || "text/plain" })),
                  children: "Use the edited file",
                }),
              ],
            }),
          ],
        })
  );
}
function Hs({ topSlot: r, renderEditor: c }) {
  const { logUsageNow: d } = yt(),
    { gateShare: D } = jt(),
    [h, j] = n.useState([]),
    [g, S] = n.useState(null),
    [T, b] = n.useState(new Set()),
    [E, O] = n.useState(null),
    [P, N] = n.useState(null),
    [L, A] = n.useState(null),
    [H, De] = n.useState(null),
    ee = n.useRef(!1),
    G = n.useCallback((t, a) => {
      j((o) => o.map((u) => (u.id === t ? { ...u, ...a } : u)));
    }, []),
    Te = (t) =>
      b((a) => {
        const o = new Set(a);
        return (o.has(t) ? o.delete(t) : o.add(t), o);
      }),
    U = n.useRef([]);
  U.current = h;
  const te = n.useCallback(
      (t) => {
        const a = U.current,
          o = [],
          u = [];
        for (const C of t) {
          const Y = Oe(C);
          Y
            ? o.push({
                id: at(),
                file: C,
                origName: C.name,
                origSize: C.size,
                kind: Y,
                targetId: null,
                status: "idle",
              })
            : u.push(C.name);
        }
        u.length &&
          p.error(
            `Not supported yet: ${u.slice(0, 3).join(", ")}${u.length > 3 ? ` and ${u.length - 3} more` : ""}.`,
          );
        const { accepted: w, dropped: k } = Bs(a.length, o);
        k > 0 &&
          p.warning(
            `A batch holds up to ${st} files — ${k} were left out. Convert this batch, then add the rest.`,
          );
        const K = js(
          a.map((C) => ({ name: C.origName, size: C.origSize })),
          w.map((C) => ({ name: C.origName, size: C.origSize })),
        );
        if (K.length > 0) {
          const C = K.slice(0, 2)
            .map((Y) => `"${Y.name}"`)
            .join(", ");
          p.info(
            K.length === 1
              ? `${C} is already in your list — added again. Remove it below if that wasn't intended.`
              : `${C}${K.length > 2 ? ` and ${K.length - 2} more are` : " are"} already in your list — added again. Remove any you don't want below.`,
          );
        }
        const Le = w.map((C) => {
          const Y = H ? X[C.kind].find((Ke) => Ke.label === H) : void 0;
          return Y ? { ...C, targetId: Y.id } : C;
        });
        (j((C) => [...C, ...Le]), S(null));
      },
      [H],
    ),
    [F, y] = n.useState(null),
    [M, v] = n.useState(null),
    [ze, he] = n.useState(!1),
    ve = n.useRef([]),
    se = n.useRef(null),
    _ = (t, a) => {
      t !== a && (j((o) => Ns(o, t, a)), S(null));
    },
    ce = (t) =>
      Cs(
        ve.current
          .slice(0, U.current.length)
          .map((a) => a?.getBoundingClientRect() ?? { top: 0, bottom: 0 }),
        t,
      ),
    Ie = (t) => (a) => {
      if (a.pointerType !== "mouse") {
        try {
          a.currentTarget.setPointerCapture(a.pointerId);
        } catch {}
        ((se.current = t), he(!0), y(t), v(t));
      }
    },
    je = (t) => {
      if (se.current === null) return;
      const a = ce(t.clientY);
      a !== M && v(a);
    },
    $e = (t) => {
      const a = se.current;
      ((se.current = null),
        he(!1),
        y(null),
        v(null),
        !(a === null || !t) && _(a, ce(t.clientY)));
    },
    xe = () => {
      (y(null), v(null));
    },
    W = (t) => {
      (j((a) => a.filter((o) => o.id !== t)), S(null));
    },
    Re = n.useMemo(() => {
      const t = [];
      for (const a of h)
        for (const o of X[a.kind]) t.includes(o.label) || t.push(o.label);
      return t;
    }, [h]),
    ge = (t) => {
      (De(t),
        j((o) =>
          o.map((u) => {
            const w = X[u.kind].find((k) => k.label === t);
            return w
              ? {
                  ...u,
                  targetId: w.id,
                  status: "idle",
                  outputs: void 0,
                  message: void 0,
                }
              : u;
          }),
        ));
      const a = h.filter((o) => !X[o.kind].some((u) => u.label === t)).length;
      a > 0 &&
        p.info(
          `${a} file${a === 1 ? " can't" : "s can't"} become ${t} — choose a format for ${a === 1 ? "it" : "them"} in the list.`,
        );
    },
    be = h.filter((t) => t.targetId).length,
    we = ys(h.map((t) => ({ name: t.origName, size: t.origSize }))),
    Ae = async () => {
      const t = h.filter((o) => o.targetId);
      if (t.length === 0) {
        p.error("Pick a format to convert to first.");
        return;
      }
      if (!(await d())) return;
      ((ee.current = !1), S(null), N({ done: 0, total: t.length }));
      let a = 0;
      for (let o = 0; o < t.length && !ee.current; o++) {
        const u = t[o],
          w = X[u.kind].find((k) => k.id === u.targetId);
        if (w) {
          G(u.id, { status: "working", message: void 0, outputs: void 0 });
          try {
            const k = await w.run(u.file);
            "skipped" in k
              ? (a++, G(u.id, { status: "error", message: k.reason }))
              : G(u.id, {
                  status: "done",
                  outputs: await Ws(k.blob, k.fileName, u.file.name),
                });
          } catch (k) {
            (console.error("Conversion failed:", k),
              a++,
              G(u.id, {
                status: "error",
                message: "This conversion didn't work on this file.",
              }));
          }
          N({ done: o + 1, total: t.length });
        }
      }
      (N(null),
        ee.current
          ? p.info("Stopped. Files already converted are kept below.")
          : a > 0
            ? p.warning(
                `${t.length - a} of ${t.length} converted. ${a} didn't — see the list.`,
              )
            : p.success(
                `${t.length} file${t.length === 1 ? "" : "s"} converted.`,
              ));
    },
    J = n.useMemo(
      () =>
        h.flatMap((t) =>
          (t.outputs ?? []).map((a) => ({ ...a, source: t.file.name })),
        ),
      [h],
    ),
    de = gt(J.map((t) => ({ name: t.fileName, type: t.blob.type }))),
    Me = (t) => {
      if (t.scope === "merged") return g ? ue(g.blob, g.fileName) : null;
      if (t.scope === "result") {
        const o = J.find((u) => u.id === t.id);
        return o ? ue(o.blob, o.fileName) : null;
      }
      const a = h.find((o) => o.id === t.id);
      return a ? a.file : null;
    },
    ye = (t, a) => {
      (t.scope === "merged"
        ? S({ blob: a, fileName: a.name })
        : t.scope === "source"
          ? (G(t.id, { file: a }),
            p.success("Edited file will be used for the conversion."))
          : (j((o) =>
              o.map((u) => ({
                ...u,
                outputs: u.outputs?.map((w) =>
                  w.id === t.id ? { ...w, blob: a } : w,
                ),
              })),
            ),
            p.success("Converted file updated.")),
        O(null));
    },
    Ne = (t, a) =>
      D(async () => {
        const o = bt({ name: a, type: t.type });
        try {
          return o === "image"
            ? (await navigator.clipboard.write([
                new ClipboardItem({ [t.type || "image/png"]: t }),
              ]),
              p.success("Image copied."),
              !0)
            : o === "text"
              ? t.size > 2 * 1024 * 1024
                ? (p.error(
                    "That file is too large to copy as text — download it instead.",
                  ),
                  !1)
                : (await navigator.clipboard.writeText(await t.text()),
                  p.success("Text copied."),
                  !0)
              : !1;
        } catch {
          return (
            p.error("Couldn't copy — your browser may not allow it here."),
            !1
          );
        }
      }),
    Ce = (t) =>
      D(async () => {
        try {
          return (
            await navigator.share({
              files: t,
              title: t.length === 1 ? t[0].name : `${t.length} files`,
              text: "Shared from FreeDailyPro",
            }),
            !0
          );
        } catch (a) {
          return (
            (a instanceof DOMException && a.name === "AbortError") ||
              p.error(
                "Sharing isn't available here — download the files instead.",
              ),
            !1
          );
        }
      }),
    Z = () => {
      const t = J.map((a) => ({ blob: a.blob, name: a.fileName }));
      return (g && t.push({ blob: g.blob, name: g.fileName }), t);
    },
    ke = async () => {
      A("zip");
      try {
        const { default: t } = await St(
            async () => {
              const { default: w } =
                await import("./jszip.min-CT0ZA6V1.js").then((k) => k.j);
              return { default: w };
            },
            __vite__mapDeps([0, 1, 2, 3]),
          ),
          a = new t(),
          o = new Set();
        for (const w of Z()) a.file(Us(w.name, o), w.blob);
        const u = await a.generateAsync({ type: "blob" });
        He(u, "converted-files.zip");
      } catch (t) {
        (console.error("Zip failed:", t),
          p.error("Couldn't build the zip file."));
      } finally {
        A(null);
      }
    },
    Ee = async () => {
      const t = Z();
      A("each");
      for (let a = 0; a < t.length; a++)
        (He(t[a].blob, t[a].name),
          await new Promise((o) => setTimeout(o, 350)));
      (A(null),
        t.length > 1 &&
          p.info(
            "If only some files arrived, allow multiple downloads for this site in your browser, or use the zip.",
          ));
    },
    Se = async (t, a) => {
      A("merge");
      try {
        if (a === "pdf") {
          const o = [];
          for (const w of t) {
            const k = w.type === "application/pdf" || /\.pdf$/i.test(w.name);
            o.push(
              k
                ? w
                : new File([await Ft([w], "a4")], `${We(w.name)}.pdf`, {
                    type: "application/pdf",
                  }),
            );
          }
          const u = await Dt(o);
          S({
            blob: new Blob([new Uint8Array(u)], { type: "application/pdf" }),
            fileName: "merged.pdf",
          });
        } else {
          const o = await Promise.all(t.map((u) => u.text()));
          S({
            blob: new Blob(
              [
                o.join(`

`),
              ],
              { type: "text/plain" },
            ),
            fileName: "merged.txt",
          });
        }
        p.success("Merged. The combined file is below.");
      } catch (o) {
        (console.error("Merge failed:", o),
          p.error("Those files couldn't be merged."));
      } finally {
        A(null);
      }
    },
    l = () =>
      de
        ? Se(
            J.map((t) => ue(t.blob, t.fileName)),
            de,
          )
        : void 0,
    q = gt(h.map((t) => ({ name: t.file.name, type: t.file.type }))),
    $ = h.some((t) => t.targetId && !(q === "pdf" && t.targetId === "pdf")),
    z = async () => {
      q &&
        (await d()) &&
        (await Se(
          h.map((t) => t.file),
          q,
        ));
    },
    _e = () => {
      ((ee.current = !0),
        j([]),
        S(null),
        b(new Set()),
        O(null),
        N(null),
        De(null));
    },
    me = (t, a, o, u) => {
      const w = xt({ name: a, type: o.type }),
        k = bt({ name: a, type: o.type }),
        K = T.has(t);
      return e.jsxs("div", {
        className: "flex flex-wrap items-center gap-1.5",
        children: [
          e.jsxs(f, {
            size: "sm",
            variant: "outline",
            className: "gap-1.5",
            onClick: () => Te(t),
            "aria-pressed": K,
            children: [
              K
                ? e.jsx(ts, { className: "h-3.5 w-3.5" })
                : e.jsx(ss, { className: "h-3.5 w-3.5" }),
              " Preview",
            ],
          }),
          u.editTarget &&
            e.jsxs(f, {
              size: "sm",
              variant: "outline",
              className: "gap-1.5",
              disabled: !w || !!P,
              title: w ? void 0 : "Editing isn't available for this file type",
              onClick: () => O(u.editTarget),
              children: [e.jsx(Fs, { className: "h-3.5 w-3.5" }), " Edit"],
            }),
          u.download &&
            e.jsxs(e.Fragment, {
              children: [
                e.jsxs(f, {
                  size: "sm",
                  className: "gap-1.5",
                  onClick: () => He(o, a),
                  children: [
                    e.jsx(rt, { className: "h-3.5 w-3.5" }),
                    " Download",
                  ],
                }),
                k &&
                  e.jsxs(f, {
                    size: "sm",
                    variant: "outline",
                    className: "gap-1.5",
                    onClick: () => {
                      Ne(o, a);
                    },
                    children: [
                      e.jsx(zt, { className: "h-3.5 w-3.5" }),
                      " Copy",
                    ],
                  }),
                wt([ue(o, a)]) &&
                  e.jsxs(f, {
                    size: "sm",
                    variant: "outline",
                    className: "gap-1.5",
                    onClick: () => {
                      Ce([ue(o, a)]);
                    },
                    children: [
                      e.jsx(ot, { className: "h-3.5 w-3.5" }),
                      " Share",
                    ],
                  }),
              ],
            }),
        ],
      });
    },
    B = E ? Me(E) : null,
    Ve = B ? xt({ name: B.name, type: B.type }) : null;
  return e.jsxs(Nt, {
    children: [
      e.jsxs("div", {
        className: "space-y-6",
        children: [
          r,
          !P &&
            e.jsx(Xe, {
              onFiles: te,
              accept: Os,
              multiple: !0,
              deferUsageLog: !0,
              label: h.length
                ? "Drop more files to add them"
                : "Drop several files at once",
              description: `Up to ${st} files per batch, any mix of formats. The whole batch counts as one use.`,
            }),
          h.length > 0 &&
            e.jsxs("section", {
              className:
                "rounded-xl border border-border bg-card p-4 space-y-4",
              "aria-label": "Files to convert",
              children: [
                e.jsxs("div", {
                  className: "flex items-end justify-between gap-3 flex-wrap",
                  children: [
                    e.jsxs("p", {
                      className: "text-sm font-semibold",
                      children: [h.length, " file", h.length === 1 ? "" : "s"],
                    }),
                    e.jsxs("div", {
                      className: "flex items-end gap-3 flex-wrap",
                      children: [
                        e.jsxs("div", {
                          children: [
                            e.jsx(V, {
                              className:
                                "text-xs text-muted-foreground mb-1 block",
                              children: "Convert all to",
                            }),
                            e.jsxs(re, {
                              value: H ?? void 0,
                              onValueChange: ge,
                              disabled: !!P,
                              children: [
                                e.jsx(oe, {
                                  className: "w-44",
                                  children: e.jsx(ne, {
                                    placeholder: "Choose a format",
                                  }),
                                }),
                                e.jsx(ie, {
                                  children: Re.map((t) =>
                                    e.jsx(I, { value: t, children: t }, t),
                                  ),
                                }),
                              ],
                            }),
                          ],
                        }),
                        e.jsxs(f, {
                          variant: "ghost",
                          size: "sm",
                          onClick: _e,
                          className: "gap-1.5",
                          disabled: !!P,
                          children: [
                            e.jsx(kt, { className: "h-3.5 w-3.5" }),
                            " Start over",
                          ],
                        }),
                      ],
                    }),
                  ],
                }),
                e.jsx("ul", {
                  className: "space-y-3",
                  children: h.map((t, a) =>
                    e.jsx(
                      "li",
                      {
                        ref: (o) => {
                          ve.current[a] = o;
                        },
                        draggable: !ze && !P,
                        onDragStart: (o) => {
                          (y(a), (o.dataTransfer.effectAllowed = "move"));
                        },
                        onDragOver: (o) => {
                          (o.preventDefault(), a !== M && v(a));
                        },
                        onDrop: (o) => {
                          (o.preventDefault(), F !== null && _(F, a), xe());
                        },
                        onDragEnd: xe,
                        className: `rounded-lg border p-3 space-y-3 transition-colors ${F === a ? "opacity-50" : ""} ${M === a && F !== a ? "border-primary" : "border-border"}`,
                        children: e.jsxs("div", {
                          className: "flex items-start gap-2",
                          children: [
                            e.jsx("button", {
                              type: "button",
                              className:
                                "cursor-grab active:cursor-grabbing touch-none p-2 -m-1 shrink-0",
                              "aria-label": `Drag to reorder ${t.file.name}`,
                              title: "Drag to reorder",
                              disabled: !!P,
                              onPointerDown: Ie(a),
                              onPointerMove: je,
                              onPointerUp: (o) => $e(o),
                              onPointerCancel: () => $e(null),
                              children: e.jsx(ks, {
                                className: "h-4 w-4 text-muted-foreground",
                              }),
                            }),
                            e.jsxs("div", {
                              className: "min-w-0 flex-1 space-y-2",
                              children: [
                                e.jsxs("div", {
                                  className:
                                    "flex items-start justify-between gap-3 flex-wrap",
                                  children: [
                                    e.jsxs("div", {
                                      className: "min-w-0",
                                      children: [
                                        e.jsxs("p", {
                                          className:
                                            "text-sm font-medium truncate",
                                          title: t.file.name,
                                          children: [
                                            e.jsxs("span", {
                                              className:
                                                "text-muted-foreground mr-1.5",
                                              children: [a + 1, "."],
                                            }),
                                            t.file.name,
                                            we.has(a) &&
                                              e.jsx("span", {
                                                className:
                                                  "ml-2 align-middle text-xs rounded border border-amber-600/50 px-1.5 py-0.5 text-amber-600 whitespace-nowrap",
                                                title:
                                                  "The same file appears earlier in the list",
                                                children: "Duplicate",
                                              }),
                                          ],
                                        }),
                                        e.jsxs("p", {
                                          className:
                                            "text-xs text-muted-foreground",
                                          children: [
                                            fe[t.kind],
                                            " · ",
                                            qe(t.file.size),
                                          ],
                                        }),
                                        we.has(a) &&
                                          e.jsx(Jt, {
                                            className: "text-xs mt-1",
                                            children:
                                              "Same file as one above. Keep it if you meant to, or remove it.",
                                          }),
                                      ],
                                    }),
                                    e.jsxs("div", {
                                      className:
                                        "flex items-center gap-1.5 flex-wrap",
                                      children: [
                                        e.jsxs(re, {
                                          value: t.targetId ?? void 0,
                                          onValueChange: (o) =>
                                            G(t.id, {
                                              targetId: o,
                                              status: "idle",
                                              outputs: void 0,
                                              message: void 0,
                                            }),
                                          disabled: !!P,
                                          children: [
                                            e.jsx(oe, {
                                              className: "w-40 h-9",
                                              "aria-label": `Convert ${t.file.name} to`,
                                              children: e.jsx(ne, {
                                                placeholder: "Convert to…",
                                              }),
                                            }),
                                            e.jsx(ie, {
                                              children: X[t.kind].map((o) =>
                                                e.jsx(
                                                  I,
                                                  {
                                                    value: o.id,
                                                    children: o.label,
                                                  },
                                                  o.id,
                                                ),
                                              ),
                                            }),
                                          ],
                                        }),
                                        e.jsx(f, {
                                          size: "icon",
                                          variant: "ghost",
                                          className: "h-9 w-9",
                                          disabled: !!P || a === 0,
                                          onClick: () => _(a, a - 1),
                                          "aria-label": `Move ${t.file.name} up`,
                                          title: "Move up",
                                          children: e.jsx(Zt, {
                                            className: "h-4 w-4",
                                          }),
                                        }),
                                        e.jsx(f, {
                                          size: "icon",
                                          variant: "ghost",
                                          className: "h-9 w-9",
                                          disabled: !!P || a === h.length - 1,
                                          onClick: () => _(a, a + 1),
                                          "aria-label": `Move ${t.file.name} down`,
                                          title: "Move down",
                                          children: e.jsx(Ss, {
                                            className: "h-4 w-4",
                                          }),
                                        }),
                                        e.jsxs(f, {
                                          size: "sm",
                                          variant: "outline",
                                          className:
                                            "gap-1.5 text-destructive hover:text-destructive",
                                          onClick: () => W(t.id),
                                          disabled: !!P,
                                          "aria-label": `Remove ${t.file.name}`,
                                          children: [
                                            e.jsx(Ps, {
                                              className: "h-3.5 w-3.5",
                                            }),
                                            " Remove",
                                          ],
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                                t.status === "working" &&
                                  e.jsx(le, { message: "Converting..." }),
                                t.status === "error" &&
                                  e.jsx("p", {
                                    className: "text-sm text-destructive",
                                    children: t.message,
                                  }),
                                t.kind === "heic"
                                  ? me(`src-${t.id}`, t.file.name, t.file, {})
                                  : me(`src-${t.id}`, t.file.name, t.file, {
                                      editTarget: { scope: "source", id: t.id },
                                    }),
                                T.has(`src-${t.id}`) &&
                                  e.jsx(Ye, {
                                    blob: t.file,
                                    name: t.file.name,
                                  }),
                              ],
                            }),
                          ],
                        }),
                      },
                      t.id,
                    ),
                  ),
                }),
                P
                  ? e.jsxs("div", {
                      className: "space-y-2",
                      children: [
                        e.jsx(le, {
                          message: `Converting ${Math.min(P.done + 1, P.total)} of ${P.total}...`,
                        }),
                        e.jsx(f, {
                          variant: "outline",
                          size: "sm",
                          onClick: () => (ee.current = !0),
                          children: "Stop after this file",
                        }),
                      ],
                    })
                  : e.jsxs(e.Fragment, {
                      children: [
                        e.jsxs("div", {
                          className: "flex flex-wrap items-center gap-2",
                          children: [
                            e.jsxs(f, {
                              onClick: () => {
                                Ae();
                              },
                              disabled: be === 0 || !!L,
                              className: "gap-2",
                              children: [
                                "Convert ",
                                be,
                                " file",
                                be === 1 ? "" : "s",
                                " ",
                                e.jsx(et, { className: "h-4 w-4" }),
                              ],
                            }),
                            q &&
                              !$ &&
                              e.jsxs(f, {
                                variant: "outline",
                                onClick: () => {
                                  z();
                                },
                                disabled: !!L,
                                className: "gap-2",
                                children: [
                                  e.jsx(tt, { className: "h-4 w-4" }),
                                  " ",
                                  q === "pdf"
                                    ? "Merge these into one PDF"
                                    : "Merge these into one text file",
                                ],
                              }),
                          ],
                        }),
                        L === "merge" && e.jsx(le, { message: "Merging..." }),
                      ],
                    }),
              ],
            }),
          (J.length > 0 || g) &&
            !P &&
            e.jsxs("section", {
              className:
                "rounded-xl border border-border bg-card p-4 space-y-4",
              "aria-label": "Converted files",
              children: [
                e.jsx("p", {
                  className: "text-sm font-semibold",
                  children: "Converted files",
                }),
                e.jsxs("ul", {
                  className: "space-y-3",
                  children: [
                    J.map((t) =>
                      e.jsxs(
                        "li",
                        {
                          className:
                            "rounded-lg border border-border p-3 space-y-3",
                          children: [
                            e.jsxs("div", {
                              className: "min-w-0",
                              children: [
                                e.jsx("p", {
                                  className: "text-sm font-medium truncate",
                                  title: t.fileName,
                                  children: t.fileName,
                                }),
                                e.jsxs("p", {
                                  className: "text-xs text-muted-foreground",
                                  children: [
                                    "from ",
                                    t.source,
                                    " · ",
                                    qe(t.blob.size),
                                  ],
                                }),
                              ],
                            }),
                            me(`res-${t.id}`, t.fileName, t.blob, {
                              editTarget: { scope: "result", id: t.id },
                              download: !0,
                            }),
                            T.has(`res-${t.id}`) &&
                              e.jsx(Ye, { blob: t.blob, name: t.fileName }),
                          ],
                        },
                        t.id,
                      ),
                    ),
                    g &&
                      e.jsxs("li", {
                        className:
                          "rounded-lg border-2 border-primary/40 bg-primary/5 p-3 space-y-3",
                        children: [
                          e.jsxs("div", {
                            className: "min-w-0",
                            children: [
                              e.jsx("p", {
                                className: "text-sm font-semibold",
                                children: "Merged file",
                              }),
                              e.jsxs("p", {
                                className: "text-xs text-muted-foreground",
                                children: [
                                  g.fileName,
                                  " · ",
                                  qe(g.blob.size),
                                  " · in the order listed above",
                                ],
                              }),
                            ],
                          }),
                          me("merged", g.fileName, g.blob, {
                            editTarget: { scope: "merged" },
                            download: !0,
                          }),
                          T.has("merged") &&
                            e.jsx(Ye, { blob: g.blob, name: g.fileName }),
                        ],
                      }),
                  ],
                }),
                e.jsxs("div", {
                  className:
                    "flex flex-wrap items-center gap-2 border-t border-border pt-4",
                  children: [
                    e.jsxs(f, {
                      onClick: () => {
                        ke();
                      },
                      disabled: !!L,
                      className: "gap-2",
                      children: [
                        e.jsx(Tt, { className: "h-4 w-4" }),
                        " Download all as one zip",
                      ],
                    }),
                    e.jsxs(f, {
                      variant: "outline",
                      onClick: () => {
                        Ee();
                      },
                      disabled: !!L,
                      className: "gap-2",
                      children: [
                        e.jsx(rt, { className: "h-4 w-4" }),
                        " Download each file separately",
                      ],
                    }),
                    de &&
                      e.jsxs(f, {
                        variant: "outline",
                        onClick: () => {
                          l();
                        },
                        disabled: !!L,
                        className: "gap-2",
                        children: [
                          e.jsx(tt, { className: "h-4 w-4" }),
                          " ",
                          de === "pdf"
                            ? "Merge into one PDF"
                            : "Merge into one text file",
                        ],
                      }),
                    wt(Z().map((t) => ue(t.blob, t.name))) &&
                      e.jsxs(f, {
                        variant: "outline",
                        onClick: () => {
                          Ce(Z().map((t) => ue(t.blob, t.name)));
                        },
                        disabled: !!L,
                        className: "gap-2",
                        children: [
                          e.jsx(ot, { className: "h-4 w-4" }),
                          " Share all",
                        ],
                      }),
                  ],
                }),
                L &&
                  e.jsx(le, {
                    message:
                      L === "zip"
                        ? "Building the zip..."
                        : L === "merge"
                          ? "Merging..."
                          : "Downloading...",
                  }),
              ],
            }),
        ],
      }),
      e.jsx(qt, {
        open: !!E,
        onOpenChange: (t) => !t && O(null),
        children: e.jsxs(Yt, {
          className: "max-w-3xl max-h-[90vh] overflow-y-auto",
          children: [
            e.jsxs(Qt, {
              children: [
                e.jsxs(Xt, { children: ["Edit ", B?.name] }),
                e.jsx(es, {
                  children:
                    E?.scope === "source"
                      ? "The edited file is what gets converted."
                      : "The edited file replaces the one in the list.",
                }),
              ],
            }),
            B &&
              E &&
              (Ve === "text"
                ? e.jsx(
                    Ks,
                    {
                      file: B,
                      onUse: (t) => ye(E, t),
                      onCancel: () => O(null),
                    },
                    B.name + B.size,
                  )
                : c(
                    B,
                    (t) => ye(E, t),
                    () => O(null),
                  )),
          ],
        }),
      }),
      e.jsx(Pt, {
        whatIsIt:
          "Convert several files in one go. Drop up to 20 files of any mix of formats, pick what each should become (or one format for all of them), and convert the whole batch at once.",
        howToUse:
          "Add your files, then use Preview or Edit on any file you want to check or change first — nothing opens until you ask. Pick the target format, convert, and every result stays its own file with the same Preview and Edit buttons. Download each file, take them all in one zip, merge PDFs or images into a single PDF, copy, or share.",
        tip: "The whole batch counts as one use of your daily trial limit. Files are converted one after another in your browser, so a large batch takes a little while — you can stop it and keep what has finished.",
      }),
    ],
  });
}
const Gs = [
    {
      id: "sharpen",
      label: "Sharpness",
      hint: "Real edge-contrast sharpening",
    },
    {
      id: "clarity",
      label: "Clarity",
      hint: "Boosts midtone contrast for a clearer look",
    },
    {
      id: "colorBalance",
      label: "Color balance",
      hint: "Auto-corrects an overall color cast",
    },
    {
      id: "shadowRemove",
      label: "Shadow remove",
      hint: "Brightens dark areas, leaves highlights alone",
    },
  ],
  Qe = {
    what: "Drops in an image, PDF, Excel/CSV, Word, PowerPoint, HTML, Markdown or text file (not video, audio or SVG) and shows only the formats it can genuinely become — a PDF shows Word/Excel/JPG/etc. as real options, an image shows PDF/resize/crop/other-image-formats, and so on. Nothing is offered that isn't actually implemented for that specific file type.",
    how: "Upload a file to see its real conversion targets, then pick one. Every step — the original upload, each edit (crop, resize, rotate, watermark, and more, depending on the file type), and the converted result — stays visible as its own separately downloadable stage, so nothing gets overwritten as you keep working. Continue editing or converting from any stage, not just the most recent one.",
    tip: `For Excel to JSON, the first row of the sheet is used as the field names, so remove any title row above your column headings first. If you're not sure this is the right tool for a specific, repeated task — always converting PDFs to Word, say — the dedicated single-purpose tool for that exact conversion (PDF to Word, in this example) loads faster and skips the extra "what do you want to convert to" step, since it already knows. This tool is built for when you're not sure what you need yet, or need to chain several different operations on the same file in one place.`,
  },
  Js = ({ children: r }) => e.jsx("div", { children: r }),
  Zs = ["jpg", "png", "pdf"];
function vt({ embeddedEdit: r, topSlot: c, preset: d }) {
  const { gateShare: D } = jt(),
    { logExportNow: h } = yt(),
    [j, g] = n.useState(r?.file ?? null),
    [S, T] = n.useState(r ? Oe(r.file) : null),
    [b, E] = n.useState(
      r
        ? [
            {
              id: "original",
              label: "Original",
              blob: r.file,
              fileName: r.file.name,
            },
          ]
        : [],
    ),
    [O, P] = n.useState(0),
    [N, L] = n.useState(d?.from ?? null),
    [A, H] = n.useState(d?.to ?? null),
    [De, ee] = n.useState(null),
    [G, Te] = n.useState(!!r),
    [U, te] = n.useState(null),
    [F, y] = n.useState(null),
    [M, v] = n.useState(!1),
    [ze, he] = n.useState(""),
    [ve, se] = n.useState(""),
    [_, ce] = n.useState(null),
    [Ie, je] = n.useState(null),
    [$e, xe] = n.useState(!1),
    [W, Re] = n.useState({
      sharpen: !1,
      clarity: !1,
      colorBalance: !1,
      shadowRemove: !1,
    }),
    [ge, be] = n.useState("none"),
    [we, Ae] = n.useState(""),
    [J, de] = n.useState("bottom-center"),
    [Me, ye] = n.useState("auto"),
    [Ne, Ce] = n.useState(""),
    [Z, ke] = n.useState(null),
    [Ee, Se] = n.useState("a4"),
    l = b.length > 0 ? b[b.length - 1] : null,
    q = !!l && l.blob.type.startsWith("image/"),
    $ =
      !!l &&
      (l.blob.type === "application/pdf" ||
        l.fileName.toLowerCase().endsWith(".pdf")),
    z = () => new File([l.blob], l.fileName, { type: l.blob.type }),
    [_e, me] = n.useState(null);
  n.useEffect(() => {
    if (!l) {
      me(null);
      return;
    }
    const s = URL.createObjectURL(l.blob);
    return (me(s), () => URL.revokeObjectURL(s));
  }, [l]);
  const B = () => {
      (Te(!!r),
        te(null),
        y(null),
        v(!1),
        he(""),
        se(""),
        ce(null),
        je(null),
        xe(!1),
        Re({ sharpen: !1, clarity: !1, colorBalance: !1, shadowRemove: !1 }),
        be("none"),
        Ae(""),
        de("bottom-center"),
        ye("medium"),
        Ce(""),
        ke(null),
        Se("a4"));
    },
    Ve = n.useCallback(
      (s) => {
        const i = s[0];
        if (!i) return;
        const m = Oe(i);
        if (!m) {
          p.error(
            "That file type isn't supported yet — try a PDF, image, HEIC photo, text, HTML, Markdown, Word, Excel, CSV, or PowerPoint file.",
          );
          return;
        }
        if (N && m !== N) {
          p.error(
            `That looks like a ${fe[m]} file, not ${fe[N]}. Drop a ${fe[N]} file, or change "Convert from" above.`,
          );
          return;
        }
        (g(i),
          T(m),
          E([{ id: "original", label: "Original", blob: i, fileName: i.name }]),
          P(0),
          B());
      },
      [N],
    ),
    t = n.useMemo(() => {
      if (!S) return null;
      if (b.length <= 1) return S;
      const s = b[b.length - 1];
      return Oe(new File([], s.fileName));
    }, [S, b]),
    a = n.useMemo(() => {
      if (!t) return [];
      if (d) return (X[S ?? d.from] ?? []).filter((i) => Zs.includes(i.id));
      const s = X[t];
      return !A || b.length > 1
        ? s
        : [...s].sort((i, m) => (i.id === A ? -1 : m.id === A ? 1 : 0));
    }, [t, A, b.length, d, S]),
    o = async (s) => {
      if (!l) return;
      const i = d ? b[0] : l;
      ee(s.id);
      try {
        const m = await s.run(
          new File([i.blob], i.fileName, { type: i.blob.type }),
        );
        if ("skipped" in m) {
          p.error(m.reason);
          return;
        }
        const x = `${We(m.fileName)}-converted${Pe(m.fileName)}`,
          ae = {
            id: `converted-${Date.now()}`,
            label: "Converted",
            blob: m.blob,
            fileName: d ? m.fileName : x,
          };
        (E((pe) => (d ? [pe[0], ae] : [...pe, ae])), B());
      } catch (m) {
        (console.error("Conversion failed:", m),
          p.error(
            "That conversion didn't work on this file. Try a different file or target format.",
          ));
      } finally {
        ee(null);
      }
    },
    u = () => {
      (g(null), T(null), E([]), P(0), H(null), B());
    },
    w = () => {
      if (!F || !l) return;
      const s = O + 1,
        i = `${We(l.fileName)}-edit${s}${Pe(F.fileName || l.fileName)}`;
      (E((m) => [
        ...m,
        {
          id: `edit-${s}-${Date.now()}`,
          label: `Edit ${s}`,
          blob: F.blob,
          fileName: i,
        },
      ]),
        P(s),
        y(null),
        te(null),
        p.success(`Edit ${s} saved as its own file.`));
    },
    k = () => {
      y(null);
    },
    K = async () => {
      if (l) {
        if ((y(null), !$))
          try {
            const s = await Es(z());
            (he(String(s.naturalWidth)), se(String(s.naturalHeight)));
          } catch {}
        te("resize");
      }
    },
    Le = async () => {
      if (l) {
        v(!0);
        try {
          if ($) {
            const { width: s, height: i } = Ze[Ee],
              m = await cs(z(), s, i);
            y({ blob: m, fileName: l.fileName });
          } else {
            const s = parseInt(ze, 10),
              i = parseInt(ve, 10);
            if (!s || !i || s < 1 || i < 1) {
              p.error("Enter a valid width and height.");
              return;
            }
            const m = await Ts(z(), s, i);
            y({ blob: m.blob, fileName: m.filename });
          }
        } catch (s) {
          (console.error("Resize failed:", s),
            p.error("Resize didn't work on this file."));
        } finally {
          v(!1);
        }
      }
    },
    C = async () => {
      if (l) {
        if ((y(null), ce(null), $)) {
          (xe(!0), je(null));
          try {
            const i = await (await it(z())).getPage(1),
              m = await lt(i, 1.5);
            je(URL.createObjectURL(m));
          } catch (s) {
            (console.error("PDF crop preview failed:", s),
              p.error("Couldn't render a preview to crop from."));
          } finally {
            xe(!1);
          }
        }
        te("crop");
      }
    },
    Y = async () => {
      if (l) {
        if (!_ || _.w < 0.02 || _.h < 0.02) {
          p.error(
            "Drag on the image above to select the region to crop first.",
          );
          return;
        }
        v(!0);
        try {
          if ($) {
            const s = await ds(z(), _);
            y({ blob: s, fileName: l.fileName });
          } else {
            const s = await zs(z(), _);
            y({ blob: s.blob, fileName: s.filename });
          }
        } catch (s) {
          (console.error("Crop failed:", s),
            p.error("Crop didn't work on this file."));
        } finally {
          v(!1);
        }
      }
    },
    Ke = async () => {
      if (l) {
        v(!0);
        try {
          if ($) {
            const s = z(),
              i = await hs(s),
              m = {};
            for (let ae = 1; ae <= i; ae++) m[ae] = 90;
            const x = await xs(s, m);
            y({
              blob: new Blob([new Uint8Array(x)], { type: "application/pdf" }),
              fileName: l.fileName,
            });
          } else {
            const s = z(),
              i = await Is(s);
            $s(i);
            const m = await Rs(i, s);
            y({ blob: m.blob, fileName: m.filename });
          }
          te("rotate");
        } catch (s) {
          (console.error("Rotate failed:", s),
            p.error("Rotate didn't work on this file."));
        } finally {
          v(!1);
        }
      }
    },
    At = async () => {
      if (!l) return;
      if (!(Object.values(W).some(Boolean) || ge !== "none")) {
        p.error("Pick at least one quality option first.");
        return;
      }
      v(!0);
      try {
        if ($) {
          const i = await it(z()),
            m = i.numPages,
            x = [];
          for (let pe = 1; pe <= m; pe++) {
            const Kt = await i.getPage(pe),
              Ht = await lt(Kt, 2);
            let Q = new File([Ht], `page-${pe}.jpg`, { type: "image/jpeg" });
            if (W.sharpen) {
              const R = await ct(Q);
              Q = new File([R.blob], R.filename, { type: R.blob.type });
            }
            if (W.clarity) {
              const R = await dt(Q);
              Q = new File([R.blob], R.filename, { type: R.blob.type });
            }
            if (W.colorBalance) {
              const R = await mt(Q);
              Q = new File([R.blob], R.filename, { type: R.blob.type });
            }
            if (W.shadowRemove) {
              const R = await pt(Q);
              Q = new File([R.blob], R.filename, { type: R.blob.type });
            }
            x.push(Q);
          }
          const ae = await Ft(x, "original");
          y({ blob: ae, fileName: l.fileName });
        } else {
          let i = z(),
            m = l.fileName;
          if (W.sharpen) {
            const x = await ct(i);
            ((i = new File([x.blob], x.filename, { type: x.blob.type })),
              (m = x.filename));
          }
          if (W.clarity) {
            const x = await dt(i);
            ((i = new File([x.blob], x.filename, { type: x.blob.type })),
              (m = x.filename));
          }
          if (W.colorBalance) {
            const x = await mt(i);
            ((i = new File([x.blob], x.filename, { type: x.blob.type })),
              (m = x.filename));
          }
          if (W.shadowRemove) {
            const x = await pt(i);
            ((i = new File([x.blob], x.filename, { type: x.blob.type })),
              (m = x.filename));
          }
          if (ge !== "none") {
            const x = await As(i, parseFloat(ge));
            ((i = new File([x.blob], x.filename, { type: x.blob.type })),
              (m = x.filename));
          }
          y({ blob: i, fileName: m });
        }
      } catch (i) {
        (console.error("Quality adjustment failed:", i),
          p.error("That quality adjustment didn't work on this file."));
      } finally {
        v(!1);
      }
    },
    Mt = async () => {
      if (l) {
        if (!we.trim()) {
          p.error("Enter the watermark text first.");
          return;
        }
        v(!0);
        try {
          const s = await ms(z(), we.trim());
          y({ blob: s, fileName: l.fileName });
        } catch (s) {
          (console.error("Watermark failed:", s),
            p.error("Adding the watermark didn't work on this PDF."));
        } finally {
          v(!1);
        }
      }
    },
    Et = async () => {
      if (l) {
        v(!0);
        try {
          const s = await ps(z(), J, 1);
          y({ blob: s, fileName: l.fileName });
        } catch (s) {
          (console.error("Page numbers failed:", s),
            p.error("Adding page numbers didn't work on this PDF."));
        } finally {
          v(!1);
        }
      }
    },
    Lt = async () => {
      if (l) {
        v(!0);
        try {
          const s = await us(z(), Me);
          if (s.status !== "ok") {
            p.info(
              "This PDF is already compact — compressing wouldn't make it noticeably smaller, so the original is kept.",
            );
            return;
          }
          y({
            blob: new Blob([new Uint8Array(s.bytes)], {
              type: "application/pdf",
            }),
            fileName: l.fileName,
          });
        } catch (s) {
          (console.error("Compress failed:", s),
            p.error("Compression didn't work on this PDF."));
        } finally {
          v(!1);
        }
      }
    },
    Ut = async () => {
      if (l) {
        if (!Ne) {
          p.error("Enter a password first.");
          return;
        }
        v(!0);
        try {
          const s = await fs(z(), Ne);
          y({ blob: s, fileName: l.fileName });
        } catch (s) {
          (console.error("Password protect failed:", s),
            p.error("Password-protecting didn't work on this PDF."));
        } finally {
          v(!1);
        }
      }
    },
    Bt = async () => {
      if (l) {
        if (!Z) {
          p.error("Choose a PDF to merge in first.");
          return;
        }
        v(!0);
        try {
          const s = await Dt([z(), Z]);
          y({
            blob: new Blob([new Uint8Array(s)], { type: "application/pdf" }),
            fileName: l.fileName,
          });
        } catch (s) {
          (console.error("Merge failed:", s),
            p.error(
              "That file couldn't be merged in — make sure it's a valid PDF.",
            ));
        } finally {
          v(!1);
        }
      }
    },
    Ot = $
      ? [
          { id: "resize", label: "Resize", icon: ut },
          { id: "crop", label: "Crop", icon: ft },
          { id: "rotate", label: "Rotate 90°", icon: ht },
          { id: "watermark", label: "Watermark", icon: os },
          { id: "pagenum", label: "Page numbers", icon: Ls },
          { id: "compress", label: "Compress", icon: Tt },
          { id: "password", label: "Password protect", icon: ns },
          { id: "merge", label: "Merge in another PDF", icon: tt },
          { id: "quality", label: "Improve quality", icon: Je },
        ]
      : q
        ? [
            { id: "resize", label: "Resize", icon: ut },
            { id: "crop", label: "Crop", icon: ft },
            { id: "rotate", label: "Rotate 90°", icon: ht },
            { id: "quality", label: "Improve quality", icon: Je },
          ]
        : [],
    Wt = (s) => {
      if (s === "resize") return K();
      if (s === "crop") return C();
      if (s === "rotate") return Ke();
      (y(null), te(s));
    },
    _t = (s) => {
      const i = is({
        id: s.id,
        name: s.fileName,
        size: s.blob.size,
        type: s.blob.type,
      });
      return e.jsxs("div", {
        className: "rounded-xl border border-border bg-card p-4 space-y-3",
        children: [
          e.jsxs("div", {
            className: "flex items-center justify-between gap-3 flex-wrap",
            children: [
              e.jsxs("div", {
                children: [
                  e.jsx("p", {
                    className: "text-sm font-semibold",
                    children: s.label,
                  }),
                  e.jsxs("p", {
                    className: "text-xs text-muted-foreground",
                    children: [
                      s.fileName,
                      d && s.id === "original"
                        ? " (your file, shown for reference)"
                        : "",
                    ],
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "flex items-center gap-2",
                children: [
                  s.id !== "original" &&
                    s.blob.type.startsWith("image/") &&
                    e.jsxs(f, {
                      variant: "outline",
                      size: "sm",
                      className: "gap-1.5",
                      onClick: () => {
                        D(async () => {
                          try {
                            return (
                              await navigator.clipboard.write([
                                new ClipboardItem({ [s.blob.type]: s.blob }),
                              ]),
                              p.success("Image copied to clipboard."),
                              !0
                            );
                          } catch (m) {
                            return (
                              console.error("Copy to clipboard failed:", m),
                              p.error(
                                "Couldn't copy — your browser may not support copying images to the clipboard.",
                              ),
                              !1
                            );
                          }
                        }, i);
                      },
                      children: [
                        e.jsx(zt, { className: "h-3.5 w-3.5" }),
                        " Copy",
                      ],
                    }),
                  vs(s.id === "original", !!d, b.length)
                    ? e.jsx(Gt, {
                        blob: s.blob,
                        fileName: s.fileName,
                        ...(s.id === "original"
                          ? { freeDownload: !0 }
                          : { gate: () => h(i) }),
                        ...(d
                          ? {}
                          : {
                              toolId: "universal-file-converter",
                              category: "converters",
                            }),
                      })
                    : null,
                ],
              }),
            ],
          }),
          e.jsx(Be, { blob: s.blob, mimeType: s.blob.type }),
        ],
      });
    },
    Vt = r ? Js : Nt;
  return e.jsxs(Vt, {
    children: [
      b.length === 0
        ? e.jsxs("div", {
            className: "space-y-4",
            children: [
              c,
              e.jsxs("div", {
                className: "p-4 rounded-xl border border-border bg-muted/30",
                children: [
                  e.jsx("p", {
                    className: "text-sm font-medium mb-3",
                    children:
                      "Prefer to pick the formats yourself? Choose them here — or skip this and just drop your file below; we'll detect it and show every valid target automatically.",
                  }),
                  e.jsxs("div", {
                    className: "flex items-end gap-3 flex-wrap",
                    children: [
                      e.jsxs("div", {
                        className: "flex-1 min-w-[160px]",
                        children: [
                          e.jsx(V, {
                            className:
                              "text-xs text-muted-foreground mb-1 block",
                            children: "Convert from",
                          }),
                          e.jsxs(re, {
                            value: N ?? void 0,
                            onValueChange: (s) => {
                              (L(s), H(null));
                            },
                            children: [
                              e.jsx(oe, {
                                children: e.jsx(ne, {
                                  placeholder: "Any file type",
                                }),
                              }),
                              e.jsx(ie, {
                                children: gs.map((s) =>
                                  e.jsx(I, { value: s, children: fe[s] }, s),
                                ),
                              }),
                            ],
                          }),
                        ],
                      }),
                      e.jsx(et, {
                        className:
                          "h-4 w-4 text-muted-foreground mb-2.5 shrink-0",
                      }),
                      e.jsxs("div", {
                        className: "flex-1 min-w-[160px]",
                        children: [
                          e.jsx(V, {
                            className:
                              "text-xs text-muted-foreground mb-1 block",
                            children: "Convert to",
                          }),
                          e.jsxs(re, {
                            value: A ?? void 0,
                            onValueChange: H,
                            disabled: !N,
                            children: [
                              e.jsx(oe, {
                                children: e.jsx(ne, {
                                  placeholder: N
                                    ? "Pick a format"
                                    : "Pick a starting format first",
                                }),
                              }),
                              e.jsx(ie, {
                                children:
                                  N &&
                                  X[N].map((s) =>
                                    e.jsx(
                                      I,
                                      { value: s.id, children: s.label },
                                      s.id,
                                    ),
                                  ),
                              }),
                            ],
                          }),
                        ],
                      }),
                      (N || A) &&
                        e.jsx(f, {
                          variant: "ghost",
                          size: "sm",
                          onClick: () => {
                            (L(null), H(null));
                          },
                          children: "Clear",
                        }),
                    ],
                  }),
                ],
              }),
              e.jsx(Xe, {
                gateAtDownload: !0,
                onFiles: Ve,
                accept: N
                  ? bs[N]
                  : ".jpg,.jpeg,.png,.webp,.heic,.heif,.pdf,.txt,.html,.htm,.md,.xlsx,.xls,.csv,.ppt,.pptx,.doc,.docx",
                label: N
                  ? `Drop your ${fe[N]} file`
                  : "Drop a file to see what it can become",
                description: N
                  ? void 0
                  : "Images, PDF, Excel/CSV, Word, PowerPoint, HTML, Markdown, text. Not video, audio or SVG.",
                multiple: !1,
              }),
              !N &&
                e.jsxs("p", {
                  className: "text-xs text-muted-foreground",
                  children: [
                    "Need SVG, video or audio instead? Use ",
                    e.jsx(Ge, {
                      href: "/tool/convert-image",
                      className: "underline",
                      children: "Convert Image",
                    }),
                    " (also opens SVG),",
                    " ",
                    e.jsx(Ge, {
                      href: "/tool/convert-video",
                      className: "underline",
                      children: "Convert Video",
                    }),
                    " or ",
                    e.jsx(Ge, {
                      href: "/tool/audio-converter",
                      className: "underline",
                      children: "Audio Converter",
                    }),
                    ".",
                  ],
                }),
              !d &&
                !r &&
                e.jsxs("section", {
                  "aria-labelledby": "ufc-what",
                  "data-testid": "ufc-table",
                  className: "pt-2",
                  children: [
                    e.jsx("h2", {
                      id: "ufc-what",
                      className: "text-base font-semibold mb-2",
                      children: "What can I convert?",
                    }),
                    e.jsx("div", {
                      className:
                        "overflow-x-auto rounded-lg border border-border",
                      children: e.jsxs("table", {
                        className: "w-full text-sm",
                        children: [
                          e.jsx("thead", {
                            className: "bg-muted/40 text-left",
                            children: e.jsxs("tr", {
                              children: [
                                e.jsx("th", {
                                  scope: "col",
                                  className: "p-2 font-medium",
                                  children: "Drop this",
                                }),
                                e.jsx("th", {
                                  scope: "col",
                                  className: "p-2 font-medium",
                                  children: "Get this",
                                }),
                              ],
                            }),
                          }),
                          e.jsx("tbody", {
                            children: ws().map((s) =>
                              e.jsxs(
                                "tr",
                                {
                                  className: "border-t border-border align-top",
                                  children: [
                                    e.jsxs("th", {
                                      scope: "row",
                                      className: "p-2 text-left font-normal",
                                      children: [
                                        s.from,
                                        " ",
                                        e.jsxs("span", {
                                          className:
                                            "text-xs text-muted-foreground",
                                          children: ["(", s.extensions, ")"],
                                        }),
                                      ],
                                    }),
                                    e.jsx("td", {
                                      className: "p-2",
                                      children: s.to.join(", "),
                                    }),
                                  ],
                                },
                                s.kind,
                              ),
                            ),
                          }),
                        ],
                      }),
                    }),
                    e.jsx("p", {
                      className: "text-xs text-muted-foreground mt-2",
                      children:
                        "Only conversions that really work are listed. Files are converted in your browser and are not uploaded.",
                    }),
                  ],
                }),
            ],
          })
        : e.jsxs("div", {
            className: "space-y-6",
            children: [
              !r &&
                e.jsxs("div", {
                  className: "flex items-center justify-between",
                  children: [
                    e.jsxs("p", {
                      className: "text-sm text-muted-foreground",
                      children: [
                        j?.name,
                        " -- detected as ",
                        S ? fe[S] : "Unknown",
                      ],
                    }),
                    e.jsxs(f, {
                      variant: "ghost",
                      size: "sm",
                      onClick: u,
                      className: "gap-1.5",
                      children: [
                        e.jsx(kt, { className: "h-3.5 w-3.5" }),
                        " Start over",
                      ],
                    }),
                  ],
                }),
              r
                ? l && e.jsx(Be, { blob: l.blob, mimeType: l.blob.type })
                : (d ? [...b.slice(1), ...b.slice(0, 1)] : b).map((s) =>
                    e.jsx(n.Fragment, { children: _t(s) }, s.id),
                  ),
              !d &&
                (q || $) &&
                e.jsxs("div", {
                  className:
                    "rounded-xl border border-border bg-card overflow-hidden",
                  children: [
                    e.jsxs("button", {
                      type: "button",
                      onClick: () => Te((s) => !s),
                      className:
                        "w-full flex items-center justify-between p-4 text-sm font-medium",
                      children: [
                        e.jsxs("span", {
                          className: "flex items-center gap-2",
                          children: [
                            e.jsx(Je, { className: "h-4 w-4" }),
                            ' Edit "',
                            l?.fileName,
                            '"',
                          ],
                        }),
                        G
                          ? e.jsx(Ms, { className: "h-4 w-4" })
                          : e.jsx(rs, { className: "h-4 w-4" }),
                      ],
                    }),
                    G &&
                      e.jsxs("div", {
                        className: "p-4 pt-0 space-y-4 border-t border-border",
                        children: [
                          e.jsx("div", {
                            className: "flex flex-wrap gap-2",
                            children: Ot.map((s) =>
                              e.jsxs(
                                f,
                                {
                                  size: "sm",
                                  variant: U === s.id ? "default" : "outline",
                                  className: "gap-1.5",
                                  onClick: () => Wt(s.id),
                                  children: [
                                    e.jsx(s.icon, { className: "h-3.5 w-3.5" }),
                                    " ",
                                    s.label,
                                  ],
                                },
                                s.id,
                              ),
                            ),
                          }),
                          M && e.jsx(le, { message: "Applying..." }),
                          !M &&
                            U === "resize" &&
                            !F &&
                            e.jsx("div", {
                              className: "space-y-3",
                              children: $
                                ? e.jsxs("div", {
                                    className: "flex items-end gap-3 flex-wrap",
                                    children: [
                                      e.jsxs("div", {
                                        children: [
                                          e.jsx(V, {
                                            className:
                                              "text-xs text-muted-foreground mb-1 block",
                                            children: "Page size",
                                          }),
                                          e.jsxs(re, {
                                            value: Ee,
                                            onValueChange: (s) => Se(s),
                                            children: [
                                              e.jsx(oe, {
                                                className: "w-40",
                                                children: e.jsx(ne, {}),
                                              }),
                                              e.jsx(ie, {
                                                children: Object.keys(Ze).map(
                                                  (s) =>
                                                    e.jsx(
                                                      I,
                                                      {
                                                        value: s,
                                                        children: Ze[s].label,
                                                      },
                                                      s,
                                                    ),
                                                ),
                                              }),
                                            ],
                                          }),
                                        ],
                                      }),
                                      e.jsx(f, {
                                        size: "sm",
                                        onClick: Le,
                                        children: "Run resize",
                                      }),
                                    ],
                                  })
                                : e.jsxs("div", {
                                    className: "flex items-end gap-3 flex-wrap",
                                    children: [
                                      e.jsxs("div", {
                                        children: [
                                          e.jsx(V, {
                                            className:
                                              "text-xs text-muted-foreground mb-1 block",
                                            children: "Width (px)",
                                          }),
                                          e.jsx(Ue, {
                                            "aria-label": "Width (px)",
                                            type: "number",
                                            value: ze,
                                            onChange: (s) => he(s.target.value),
                                            className: "w-28",
                                            min: 1,
                                          }),
                                        ],
                                      }),
                                      e.jsxs("div", {
                                        children: [
                                          e.jsx(V, {
                                            className:
                                              "text-xs text-muted-foreground mb-1 block",
                                            children: "Height (px)",
                                          }),
                                          e.jsx(Ue, {
                                            "aria-label": "Height (px)",
                                            type: "number",
                                            value: ve,
                                            onChange: (s) => se(s.target.value),
                                            className: "w-28",
                                            min: 1,
                                          }),
                                        ],
                                      }),
                                      e.jsx(f, {
                                        size: "sm",
                                        onClick: Le,
                                        children: "Run resize",
                                      }),
                                    ],
                                  }),
                            }),
                          !M &&
                            U === "crop" &&
                            !F &&
                            e.jsxs("div", {
                              className: "space-y-3",
                              children: [
                                $
                                  ? e.jsxs(e.Fragment, {
                                      children: [
                                        e.jsx("p", {
                                          className:
                                            "text-xs text-muted-foreground",
                                          children:
                                            "Drag on this preview of page 1 to select the region — the same region crops from every page.",
                                        }),
                                        $e
                                          ? e.jsx(le, {
                                              message: "Rendering preview...",
                                            })
                                          : Ie
                                            ? e.jsx(nt, {
                                                imageUrl: Ie,
                                                onSelectionChange: ce,
                                              })
                                            : e.jsx("p", {
                                                className:
                                                  "text-xs text-destructive",
                                                children:
                                                  "Couldn't render a preview to crop from.",
                                              }),
                                      ],
                                    })
                                  : e.jsxs(e.Fragment, {
                                      children: [
                                        e.jsx("p", {
                                          className:
                                            "text-xs text-muted-foreground",
                                          children:
                                            "Drag on the image to select the region to keep.",
                                        }),
                                        e.jsx(nt, {
                                          imageUrl: _e ?? "",
                                          onSelectionChange: ce,
                                        }),
                                      ],
                                    }),
                                e.jsx(f, {
                                  size: "sm",
                                  onClick: Y,
                                  disabled: !_,
                                  children: "Run crop",
                                }),
                              ],
                            }),
                          !M &&
                            U === "quality" &&
                            !F &&
                            e.jsxs("div", {
                              className: "space-y-3",
                              children: [
                                $ &&
                                  e.jsx("p", {
                                    className: "text-xs text-muted-foreground",
                                    children:
                                      "Renders each page as an image to apply these, then rebuilds the PDF — selectable text becomes part of the page image afterward.",
                                  }),
                                e.jsxs("div", {
                                  className: "space-y-2",
                                  children: [
                                    Gs.map((s) =>
                                      e.jsxs(
                                        "label",
                                        {
                                          className:
                                            "flex items-start gap-2 cursor-pointer",
                                          children: [
                                            e.jsx(Ds, {
                                              checked: W[s.id],
                                              onCheckedChange: (i) =>
                                                Re((m) => ({
                                                  ...m,
                                                  [s.id]: !!i,
                                                })),
                                              className: "mt-0.5",
                                            }),
                                            e.jsxs("span", {
                                              children: [
                                                e.jsx("span", {
                                                  className:
                                                    "text-sm font-medium block",
                                                  children: s.label,
                                                }),
                                                e.jsx("span", {
                                                  className:
                                                    "text-xs text-muted-foreground",
                                                  children: s.hint,
                                                }),
                                              ],
                                            }),
                                          ],
                                        },
                                        s.id,
                                      ),
                                    ),
                                    !$ &&
                                      e.jsxs("div", {
                                        className: "pt-1",
                                        children: [
                                          e.jsx(V, {
                                            className:
                                              "text-xs text-muted-foreground mb-1 block",
                                            children:
                                              "Pixel increase (upscale)",
                                          }),
                                          e.jsxs(re, {
                                            value: ge,
                                            onValueChange: (s) => be(s),
                                            children: [
                                              e.jsx(oe, {
                                                className: "w-40",
                                                children: e.jsx(ne, {}),
                                              }),
                                              e.jsxs(ie, {
                                                children: [
                                                  e.jsx(I, {
                                                    value: "none",
                                                    children: "No change",
                                                  }),
                                                  e.jsx(I, {
                                                    value: "1.5",
                                                    children: "1.5× larger",
                                                  }),
                                                  e.jsx(I, {
                                                    value: "2",
                                                    children: "2× larger",
                                                  }),
                                                ],
                                              }),
                                            ],
                                          }),
                                        ],
                                      }),
                                  ],
                                }),
                                e.jsx(f, {
                                  size: "sm",
                                  onClick: At,
                                  children: "Run quality improvements",
                                }),
                              ],
                            }),
                          !M &&
                            U === "watermark" &&
                            !F &&
                            e.jsxs("div", {
                              className: "flex items-end gap-3 flex-wrap",
                              children: [
                                e.jsxs("div", {
                                  className: "flex-1 min-w-[200px]",
                                  children: [
                                    e.jsx(V, {
                                      className:
                                        "text-xs text-muted-foreground mb-1 block",
                                      children: "Watermark text",
                                    }),
                                    e.jsx(Ue, {
                                      "aria-label": "Watermark text",
                                      value: we,
                                      onChange: (s) => Ae(s.target.value),
                                      placeholder: "e.g. CONFIDENTIAL",
                                    }),
                                  ],
                                }),
                                e.jsx(f, {
                                  size: "sm",
                                  onClick: Mt,
                                  children: "Run watermark",
                                }),
                              ],
                            }),
                          !M &&
                            U === "pagenum" &&
                            !F &&
                            e.jsxs("div", {
                              className: "flex items-end gap-3 flex-wrap",
                              children: [
                                e.jsxs("div", {
                                  children: [
                                    e.jsx(V, {
                                      className:
                                        "text-xs text-muted-foreground mb-1 block",
                                      children: "Position",
                                    }),
                                    e.jsxs(re, {
                                      value: J,
                                      onValueChange: (s) => de(s),
                                      children: [
                                        e.jsx(oe, {
                                          className: "w-44",
                                          children: e.jsx(ne, {}),
                                        }),
                                        e.jsxs(ie, {
                                          children: [
                                            e.jsx(I, {
                                              value: "bottom-center",
                                              children: "Bottom center",
                                            }),
                                            e.jsx(I, {
                                              value: "bottom-right",
                                              children: "Bottom right",
                                            }),
                                            e.jsx(I, {
                                              value: "bottom-left",
                                              children: "Bottom left",
                                            }),
                                            e.jsx(I, {
                                              value: "top-center",
                                              children: "Top center",
                                            }),
                                            e.jsx(I, {
                                              value: "top-right",
                                              children: "Top right",
                                            }),
                                            e.jsx(I, {
                                              value: "top-left",
                                              children: "Top left",
                                            }),
                                          ],
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                                e.jsx(f, {
                                  size: "sm",
                                  onClick: Et,
                                  children: "Run page numbers",
                                }),
                              ],
                            }),
                          !M &&
                            U === "compress" &&
                            !F &&
                            e.jsxs("div", {
                              className: "flex items-end gap-3 flex-wrap",
                              children: [
                                e.jsxs("div", {
                                  children: [
                                    e.jsx(V, {
                                      className:
                                        "text-xs text-muted-foreground mb-1 block",
                                      children: "Compression level",
                                    }),
                                    e.jsxs(re, {
                                      value: Me,
                                      onValueChange: (s) => ye(s),
                                      children: [
                                        e.jsx(oe, {
                                          className: "w-40",
                                          children: e.jsx(ne, {}),
                                        }),
                                        e.jsxs(ie, {
                                          children: [
                                            e.jsx(I, {
                                              value: "auto",
                                              children:
                                                "Recommended (~50% smaller)",
                                            }),
                                            e.jsx(I, {
                                              value: "medium",
                                              children: "Medium (~25% smaller)",
                                            }),
                                            e.jsx(I, {
                                              value: "strong",
                                              children: "Strong (~50% smaller)",
                                            }),
                                          ],
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                                e.jsx(f, {
                                  size: "sm",
                                  onClick: Lt,
                                  children: "Run compression",
                                }),
                              ],
                            }),
                          !M &&
                            U === "password" &&
                            !F &&
                            e.jsxs("div", {
                              className: "flex items-end gap-3 flex-wrap",
                              children: [
                                e.jsxs("div", {
                                  children: [
                                    e.jsx(V, {
                                      className:
                                        "text-xs text-muted-foreground mb-1 block",
                                      children: "Password",
                                    }),
                                    e.jsx(Ue, {
                                      "aria-label": "Password",
                                      type: "password",
                                      value: Ne,
                                      onChange: (s) => Ce(s.target.value),
                                      className: "w-48",
                                    }),
                                  ],
                                }),
                                e.jsx(f, {
                                  size: "sm",
                                  onClick: Ut,
                                  children: "Run password protect",
                                }),
                              ],
                            }),
                          !M &&
                            U === "merge" &&
                            !F &&
                            e.jsxs("div", {
                              className: "space-y-3",
                              children: [
                                e.jsx("p", {
                                  className: "text-xs text-muted-foreground",
                                  children:
                                    "Adds another PDF's pages onto the end of this one.",
                                }),
                                Z
                                  ? e.jsxs("div", {
                                      className: "flex items-center gap-3",
                                      children: [
                                        e.jsx("p", {
                                          className: "text-sm",
                                          children: Z.name,
                                        }),
                                        e.jsx(f, {
                                          size: "sm",
                                          onClick: Bt,
                                          children: "Run merge",
                                        }),
                                        e.jsx(f, {
                                          size: "sm",
                                          variant: "ghost",
                                          onClick: () => ke(null),
                                          children: "Remove",
                                        }),
                                      ],
                                    })
                                  : e.jsx(Xe, {
                                      gateAtDownload: !0,
                                      onFiles: (s) => ke(s[0] ?? null),
                                      accept: ".pdf",
                                      label: "Drop the PDF to merge in",
                                      multiple: !1,
                                    }),
                              ],
                            }),
                          !M &&
                            F &&
                            e.jsxs("div", {
                              className:
                                "rounded-lg border-2 border-primary/40 bg-primary/5 p-3 space-y-3",
                              children: [
                                e.jsxs("p", {
                                  className: "text-sm font-semibold",
                                  children: ["Edit ", O + 1, " preview"],
                                }),
                                e.jsx(Be, {
                                  blob: F.blob,
                                  mimeType: F.blob.type,
                                }),
                                e.jsxs("div", {
                                  className: "flex gap-2",
                                  children: [
                                    e.jsxs(f, {
                                      size: "sm",
                                      onClick: w,
                                      children: [
                                        "Apply — save as Edit ",
                                        O + 1,
                                      ],
                                    }),
                                    e.jsx(f, {
                                      size: "sm",
                                      variant: "outline",
                                      onClick: k,
                                      children: "Deny — discard this attempt",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                        ],
                      }),
                  ],
                }),
              r &&
                !(q || $) &&
                e.jsx("p", {
                  className: "text-sm text-muted-foreground",
                  children: "Editing isn't available for this file type.",
                }),
              r &&
                e.jsxs("div", {
                  className: "flex flex-wrap gap-2 justify-end",
                  children: [
                    e.jsx(f, {
                      variant: "outline",
                      onClick: r.onCancel,
                      children: "Cancel",
                    }),
                    e.jsx(f, {
                      onClick: () =>
                        l &&
                        r.onUse(
                          new File([l.blob], r.file.name, {
                            type: l.blob.type,
                          }),
                        ),
                      disabled: b.length < 2,
                      children: "Use the edited file",
                    }),
                  ],
                }),
              !r &&
                e.jsxs("div", {
                  className:
                    "rounded-xl border border-border bg-card p-4 space-y-3",
                  children: [
                    e.jsx("p", {
                      className: "text-sm font-medium",
                      children: d
                        ? b.length > 1
                          ? `Need a different format for "${b[0]?.fileName}"?`
                          : `Convert "${b[0]?.fileName}" to:`
                        : `Convert "${l?.fileName}" to:`,
                    }),
                    d && e.jsx(ls, { toolId: "heic-to-jpg", what: "A PDF" }),
                    De
                      ? e.jsx(le, { message: "Converting..." })
                      : a.length === 0
                        ? e.jsx("p", {
                            className: "text-xs text-muted-foreground",
                            children:
                              "This file can't be converted further here. Download it above, or use Start over to convert another file.",
                          })
                        : e.jsx("div", {
                            className: "flex flex-wrap gap-2",
                            children: a.map((s) =>
                              e.jsxs(
                                f,
                                {
                                  variant: s.id === A ? "default" : "outline",
                                  className: "gap-2",
                                  onClick: () => o(s),
                                  children: [
                                    s.label,
                                    " ",
                                    e.jsx(et, { className: "h-3.5 w-3.5" }),
                                  ],
                                },
                                s.id,
                              ),
                            ),
                          }),
                  ],
                }),
            ],
          }),
      !r && e.jsx(Pt, { whatIsIt: Qe.what, howToUse: Qe.how, tip: Qe.tip }),
    ],
  });
}
function qs({ multi: r, onChange: c }) {
  return e.jsxs("div", {
    role: "group",
    "aria-label": "How many files",
    className: "inline-flex rounded-lg border border-border p-1 gap-1",
    children: [
      e.jsx(f, {
        type: "button",
        size: "sm",
        variant: r ? "ghost" : "default",
        "aria-pressed": !r,
        onClick: () => c(!1),
        children: "One file",
      }),
      e.jsx(f, {
        type: "button",
        size: "sm",
        variant: r ? "default" : "ghost",
        "aria-pressed": r,
        onClick: () => c(!0),
        children: "Multiple files",
      }),
    ],
  });
}
function yr({ preset: r } = {}) {
  const [c, d] = n.useState(!1),
    D = e.jsx(qs, { multi: c, onChange: d });
  return c
    ? e.jsx(Hs, {
        topSlot: D,
        renderEditor: (h, j, g) =>
          e.jsx(vt, { embeddedEdit: { file: h, onUse: j, onCancel: g } }),
      })
    : e.jsx(vt, { topSlot: D, preset: r });
}
export { yr as default };
//# sourceMappingURL=UniversalFileConverter-D_J0VhRj.js.map
