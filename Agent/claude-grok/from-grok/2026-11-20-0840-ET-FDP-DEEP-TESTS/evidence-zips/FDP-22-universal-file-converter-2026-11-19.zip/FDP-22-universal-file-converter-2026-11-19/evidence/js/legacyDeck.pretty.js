import { trpcVanilla as c } from "./trpcVanilla-DLV8pXkC.js";
const l = [
    "ppt",
    "pps",
    "pot",
    "odp",
    "otp",
    "key",
    "ppsx",
    "potx",
    "pptm",
    "ppsm",
    "potm",
  ],
  h = ".pptx,.ppt,.pps,.pot,.ppsx,.potx,.pptm,.odp,.otp,.key",
  w = ".pptx, .ppt, .odp or .key",
  r = 30 * 1024 * 1024,
  m = (t) => (/\.([A-Za-z0-9]{2,5})$/.exec(t)?.[1] ?? "").toLowerCase(),
  v = (t) => l.includes(m(t.name));
function f(t) {
  let o = "";
  for (let e = 0; e < t.length; e += 32768)
    o += String.fromCharCode.apply(null, Array.from(t.subarray(e, e + 32768)));
  return btoa(o);
}
function d(t) {
  const o = atob(t),
    e = new Uint8Array(o.length);
  for (let n = 0; n < o.length; n++) e[n] = o.charCodeAt(n);
  return e;
}
const E = 100,
  a =
    "This file is empty or damaged, so it cannot be converted. Choose a valid presentation, or save it again as .pptx in PowerPoint.";
function u(t) {
  const o = t instanceof Error ? t.message : "",
    e = o.trim();
  return e.startsWith("[") || e.startsWith("{") || /"code"\s*:\s*"/.test(e)
    ? /too_small|fileBase64/.test(e)
      ? a
      : "This file could not be converted. It may be damaged, or not a presentation. Try saving it again as .pptx in PowerPoint."
    : o || "This file could not be converted. Try again in a moment.";
}
async function x(t, o) {
  if (t.size > r)
    throw new Error(
      `This file is ${(t.size / 1048576).toFixed(1)} MB; the converter takes up to ${r / 1048576} MB. Save a smaller copy and try again.`,
    );
  const e = new Uint8Array(await t.arrayBuffer());
  if (e.length < E) throw new Error(a);
  let n;
  try {
    n = await c.presentation.convert.mutate({
      fileBase64: f(e),
      fileName: t.name,
      to: o,
    });
  } catch (p) {
    throw new Error(u(p));
  }
  const s = {
      pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
      odp: "application/vnd.oasis.opendocument.presentation",
      ppt: "application/vnd.ms-powerpoint",
      pdf: "application/pdf",
    }[o],
    i = t.name.replace(/\.[A-Za-z0-9]{2,5}$/, "") + "." + o;
  return {
    file: new File([d(n.fileBase64).buffer], i, { type: s }),
    from: n.from,
    note: n.note,
  };
}
export { w as O, h as a, x as c, v as n };
//# sourceMappingURL=legacyDeck-DRWwmRY1.js.map
