function Vt() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null,
  };
}
var xe = Vt();
function kr(t) {
  xe = t;
}
var be = { exec: () => null };
function Ne(t) {
  let e = [];
  return (n) => {
    let r = Math.max(0, Math.min(3, n - 1)),
      i = e[r];
    return (i || ((i = t(r)), (e[r] = i)), i);
  };
}
function b(t, e = "") {
  let n = typeof t == "string" ? t : t.source,
    r = {
      replace: (i, l) => {
        let o = typeof l == "string" ? l : l.source;
        return ((o = o.replace(I.caret, "$1")), (n = n.replace(i, o)), r);
      },
      getRegex: () => new RegExp(n, e),
    };
  return r;
}
var ki = ((t = "") => {
    try {
      return !!new RegExp("(?<=1)(?<!1)" + t);
    } catch {
      return !1;
    }
  })(),
  I = {
    codeRemoveIndent: /^(?: {0,3}\t| {1,4})/gm,
    outputLinkReplace: /\\([\[\]])/g,
    indentCodeCompensation: /^(\s+)(?:```)/,
    beginningSpace: /^\s+/,
    endingHash: /#$/,
    startingSpaceChar: /^ /,
    endingSpaceChar: / $/,
    endingSpaceTabChar: /[ \t]$/,
    nonSpaceChar: /[^ ]/,
    newLineCharGlobal: /\n/g,
    tabCharGlobal: /\t/g,
    leadingSpaceTab: /^[ \t]+/,
    multipleSpaceGlobal: /\s+/g,
    blankLine: /^[ \t]*$/,
    doubleBlankLine: /\n[ \t]*\n[ \t]*$/,
    blockquoteStart: /^ {0,3}>/,
    blockquoteSetextReplace: /\n {0,3}((?:=+|-+) *)(?=\n|$)/g,
    blockquoteSetextReplace2: /^ {0,3}>[ \t]?/gm,
    listReplaceNesting: /^ {1,4}(?=( {4})*[^ ])/g,
    listIsTask: /^\[[ xX]\] +\S/,
    listReplaceTask: /^\[[ xX]\] +/,
    listTaskCheckbox: /\[[ xX]\]/,
    anyLine: /\n.*\n/,
    hrefBrackets: /^<(.*)>$/,
    tableDelimiter: /[:|]/,
    tableAlignChars: /^\||\| *$/g,
    tableRowBlankLine: /\n[ \t]*$/,
    tableAlignRight: /^ *-+: *$/,
    tableAlignCenter: /^ *:-+: *$/,
    tableAlignLeft: /^ *:-+ *$/,
    startATag: /^<a /i,
    endATag: /^<\/a>/i,
    startPreScriptTag: /^<(pre|code|kbd|script)(\s|>)/i,
    endPreScriptTag: /^<\/(pre|code|kbd|script)(\s|>)/i,
    startAngleBracket: /^</,
    endAngleBracket: />$/,
    pedanticHrefTitle: /^([^'"]*[^\s])\s+(['"])(.*)\2/,
    unicodeAlphaNumeric: /[\p{L}\p{N}]/u,
    numericCharacterReference: /&#(?:(\d{1,7})|[Xx]([A-Fa-f0-9]{1,6}));/g,
    escapeTest: /[&<>"']/,
    escapeReplace: /[&<>"']/g,
    escapeTestNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/,
    escapeReplaceNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g,
    caret: /(^|[^\[])\^/g,
    percentDecode: /%25/g,
    findPipe: /\|/g,
    splitPipe: / \|/,
    slashPipe: /\\\|/g,
    carriageReturn: /\r\n|\r/g,
    spaceLine: /^ +$/gm,
    notSpaceStart: /^\S*/,
    endingNewline: /\n$/,
    listItemRegex: (t) => new RegExp(`^( {0,3}${t})((?:[	 ][^\\n]*)?(?:\\n|$))`),
    nextBulletRegex: Ne(
      (t) =>
        new RegExp(
          `^ {0,${t}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`,
        ),
    ),
    hrRegex: Ne(
      (t) =>
        new RegExp(
          `^ {0,${t}}((?:-[ 	]*){3,}|(?:_[ 	]*){3,}|(?:\\*[ 	]*){3,})(?:\\n+|$)`,
        ),
    ),
    fencesBeginRegex: Ne((t) => new RegExp(`^ {0,${t}}(?:\`\`\`|~~~)`)),
    headingBeginRegex: Ne((t) => new RegExp(`^ {0,${t}}#`)),
    htmlBeginRegex: Ne(
      (t) =>
        new RegExp(
          `^ {0,${t}}(?:</?(?:${Ye})(?: +|$|/?>)|<(?:script|pre|style|textarea|!--))`,
          "i",
        ),
    ),
    blockquoteBeginRegex: Ne((t) => new RegExp(`^ {0,${t}}>`)),
  },
  bi = /^(?:[ \t]*(?:\n|$))+/,
  Ti = /^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/,
  xi =
    /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/,
  qe = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/,
  wi = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/,
  Xt = / {0,3}(?:[*+-]|\d{1,9}[.)])/,
  br =
    /^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |fences|blockquote|heading|hr|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  Tr = b(br)
    .replace(/bull/g, Xt)
    .replace(/blockCode/g, /(?: {4}| {0,3}\t)/)
    .replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/)
    .replace(/blockquote/g, / {0,3}>/)
    .replace(/heading/g, / {0,3}#{1,6}(?:\s|$)/)
    .replace(
      /hr/g,
      / {0,3}(?:(?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/,
    )
    .replace(/html/g, / {0,3}<[^\n>]+>\n/)
    .replace(/\|table/g, "")
    .getRegex(),
  yi = b(br)
    .replace(/bull/g, Xt)
    .replace(/blockCode/g, /(?: {4}| {0,3}\t)/)
    .replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/)
    .replace(/blockquote/g, / {0,3}>/)
    .replace(/heading/g, / {0,3}#{1,6}(?:\s|$)/)
    .replace(
      /hr/g,
      / {0,3}(?:(?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/,
    )
    .replace(/html/g, / {0,3}<[^\n>]+>\n/)
    .replace(/table/g, / {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/)
    .getRegex(),
  Qt =
    /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table|[ \t]+\n)[^\n]+)*)/,
  Ai = /^[^\n]+/,
  Kt = /(?!\s*\])(?:\\[\s\S]|[^\[\]\\])+/,
  Si = b(
    /^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/,
  )
    .replace("label", Kt)
    .replace(
      "title",
      /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/,
    )
    .getRegex(),
  _i = b(/^(bull)([ \t][^\n]*?)?(?:\n|$)/)
    .replace(/bull/g, Xt)
    .getRegex(),
  Ye =
    "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul",
  Jt = /<!--(?:-?>|[\s\S]*?(?:-->|$))/,
  Ei = b(
    "^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n*|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>[^\\n]*\\n*|$)|<![A-Z][\\s\\S]*?(?:>[^\\n]*\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>[^\\n]*\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][a-z0-9-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][a-z0-9-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))",
    "i",
  )
    .replace("comment", Jt)
    .replace("tag", Ye)
    .replace(
      "attribute",
      / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/,
    )
    .getRegex(),
  xr = (t) =>
    b(Qt)
      .replace("hr", qe)
      .replace("heading", " {0,3}#{1,6}(?:\\s|$)")
      .replace("|lheading", "")
      .replace("|table", "")
      .replace("blockquote", " {0,3}>")
      .replace(
        "fences",
        " {0,3}(?:`{3,}(?=[^`\\n]*(?:\\n|$))|~~~)[^\\n]*(?:\\n|$)",
      )
      .replace("list", t)
      .replace(
        "html",
        "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)",
      )
      .replace("tag", Ye)
      .getRegex(),
  Ri = xr(/ {0,3}(?:[*+-]|1[.)])[ \t]+[^ \t\n]/),
  vi = xr(/ {0,3}(?:[*+-]|\d{1,9}[.)])(?:[ \t]|\n|$)/),
  Oi = b(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/)
    .replace("paragraph", vi)
    .getRegex(),
  en = {
    blockquote: Oi,
    code: Ti,
    def: Si,
    fences: xi,
    heading: wi,
    hr: qe,
    html: Ei,
    lheading: Tr,
    list: _i,
    newline: bi,
    paragraph: Ri,
    table: be,
    text: Ai,
  },
  Hn = b(
    "^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)",
  )
    .replace("hr", qe)
    .replace("heading", " {0,3}#{1,6}(?:\\s|$)")
    .replace("blockquote", " {0,3}>")
    .replace("code", "(?: {4}| {0,3}	)[^\\n]")
    .replace(
      "fences",
      " {0,3}(?:`{3,}(?=[^`\\n]*(?:\\n|$))|~~~)[^\\n]*(?:\\n|$)",
    )
    .replace("list", " {0,3}(?:[*+-]|1[.)])[ \\t]")
    .replace(
      "html",
      "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)",
    )
    .replace("tag", Ye)
    .getRegex(),
  Li = {
    ...en,
    lheading: yi,
    table: Hn,
    paragraph: b(Qt)
      .replace("hr", qe)
      .replace("heading", " {0,3}#{1,6}(?:\\s|$)")
      .replace("|lheading", "")
      .replace("table", Hn)
      .replace("blockquote", " {0,3}>")
      .replace(
        "fences",
        " {0,3}(?:`{3,}(?=[^`\\n]*(?:\\n|$))|~~~)[^\\n]*(?:\\n|$)",
      )
      .replace("list", " {0,3}(?:[*+-]|1[.)])[ \\t]+[^ \\t\\n]")
      .replace(
        "html",
        "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)",
      )
      .replace("tag", Ye)
      .getRegex(),
  },
  Ni = {
    ...en,
    html: b(
      `^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`,
    )
      .replace("comment", Jt)
      .replace(
        /tag/g,
        "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b",
      )
      .getRegex(),
    def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
    heading: /^(#{1,6})(.*)(?:\n+|$)/,
    fences: be,
    lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
    paragraph: b(Qt)
      .replace("hr", qe)
      .replace(
        "heading",
        ` *#{1,6} *[^
]`,
      )
      .replace("lheading", Tr)
      .replace("|table", "")
      .replace("blockquote", " {0,3}>")
      .replace("|fences", "")
      .replace("|list", "")
      .replace("|html", "")
      .replace("|tag", "")
      .getRegex(),
  },
  Ci = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/,
  Pi = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/,
  wr = /^( {2,}|\\)\n(?!\s*$)[ \t]*/,
  Di =
    /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/,
  ie = /[\p{P}\p{S}]/u,
  Ie = /[\s\p{P}\p{S}]/u,
  Ze = /[^\s\p{P}\p{S}]/u,
  Ii = b(/^((?![*_])punctSpace)/, "u")
    .replace(/punctSpace/g, Ie)
    .getRegex(),
  Mi = /[\p{Pi}\p{Ps}"']/u,
  yr = /(?!~)[\p{P}\p{S}]/u,
  $i = /(?!~)[\s\p{P}\p{S}]/u,
  zi = /(?:[^\s\p{P}\p{S}]|~)/u,
  Bi = b(/link|precode-code|html/, "g")
    .replace(
      "link",
      /\[(?:[^\[\]`]|(?<a>`+)[^`]+\k<a>(?!`))*?\]\((?:\\[\s\S]|[^\\\(\)]|\((?:\\[\s\S]|[^\\\(\)])*\))*\)/,
    )
    .replace("precode-", ki ? "(?<!`)()" : "(^^|[^`])")
    .replace("code", /(?<b>`+)[^`]+\k<b>(?!`)/)
    .replace("html", /<(?! )[^<>]*?>/)
    .getRegex(),
  Ar = /^(?:\*+(?:((?!\*)punct)|([^\s*]))?)|^_+(?:((?!_)punct)|([^\s_]))?/,
  Fi = b(Ar, "u").replace(/punct/g, ie).getRegex(),
  Ui = b(Ar, "u").replace(/punct/g, yr).getRegex(),
  Hi =
    /^(?:\*+(?:((?!\*)(?!openQuote)punct)|([^\s*]))?)|^_+(?:((?!_)(?!openQuote)punct)|([^\s_]))?/,
  Wi = b(Hi, "u")
    .replace(/openQuote/g, Mi)
    .replace(/punct/g, ie)
    .getRegex(),
  Sr =
    "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)",
  Gi = b(Sr, "gu")
    .replace(/notPunctSpace/g, Ze)
    .replace(/punctSpace/g, Ie)
    .replace(/punct/g, ie)
    .getRegex(),
  ji = b(Sr, "gu")
    .replace(/notPunctSpace/g, zi)
    .replace(/punctSpace/g, $i)
    .replace(/punct/g, yr)
    .getRegex(),
  qi =
    "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)[\\s](\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|(?:(?!\\*)punct|notPunctSpace)(\\*+)(?!\\*)(?=notPunctSpace)",
  Yi = b(qi, "gu")
    .replace(/notPunctSpace/g, Ze)
    .replace(/punctSpace/g, Ie)
    .replace(/punct/g, ie)
    .getRegex(),
  Zi = b(
    "^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)",
    "gu",
  )
    .replace(/notPunctSpace/g, Ze)
    .replace(/punctSpace/g, Ie)
    .replace(/punct/g, ie)
    .getRegex(),
  Vi =
    "^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)[\\s](_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)|(?:(?!_)punct|notPunctSpace)(_+)(?!_)(?=notPunctSpace)",
  Xi = b(Vi, "gu")
    .replace(/notPunctSpace/g, Ze)
    .replace(/punctSpace/g, Ie)
    .replace(/punct/g, ie)
    .getRegex(),
  Qi = b(/^~~?(?:((?!~)punct)|[^\s~])/, "u")
    .replace(/punct/g, ie)
    .getRegex(),
  Ki =
    "^[^~]+(?=[^~])|(?!~)punct(~~?)(?=[\\s]|$)|notPunctSpace(~~?)(?!~)(?=punctSpace|$)|(?!~)punctSpace(~~?)(?=notPunctSpace)|[\\s](~~?)(?!~)(?=punct)|(?!~)punct(~~?)(?!~)(?=punct)|notPunctSpace(~~?)(?=notPunctSpace)",
  Ji = b(Ki, "gu")
    .replace(/notPunctSpace/g, Ze)
    .replace(/punctSpace/g, Ie)
    .replace(/punct/g, ie)
    .getRegex(),
  es = b(/\\(punct)/, "gu")
    .replace(/punct/g, ie)
    .getRegex(),
  ts = b(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/)
    .replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/)
    .replace(
      "email",
      /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/,
    )
    .getRegex(),
  ns = b(Jt).replace("(?:-->|$)", "-->").getRegex(),
  rs = b(
    "^comment|^</[a-zA-Z][a-zA-Z0-9-]*\\s*>|^<[a-zA-Z][a-zA-Z0-9-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>",
  )
    .replace("comment", ns)
    .replace(
      "attribute",
      /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/,
    )
    .getRegex(),
  _r = /\[(?:\\[\s\S]|[^\[\]\\])*\]/,
  pt = b(
    /(?:\[(?:brackets|\\[\s\S]|[^\[\]\\])*\]|\\[\s\S]|`+(?!`)[^`]*?`+(?!`)|``+(?=\])|[^\[\]\\`])*?/,
  )
    .replace("brackets", _r)
    .getRegex(),
  is = b(
    /^!?\[(label)\]\([ \t\n]*(href)(?:(?:[ \t]+(?:\n[ \t]*)?|\n[ \t]*)(title))?[ \t\n]*\)/,
  )
    .replace("label", pt)
    .replace("href", /<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]+|(?=\))/)
    .replace(
      "title",
      /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/,
    )
    .getRegex(),
  ss = b(/^!?\[(label)\]\[(ref)\]/)
    .replace("label", pt)
    .replace("ref", Kt)
    .getRegex(),
  ls = b(/^!?\[(ref)\](?:\[\])?/)
    .replace("ref", Kt)
    .getRegex(),
  Wn = /(?!\s*\])(?:\\[\s\S]|[^\[\]\\]){1,999}/,
  as = b(
    /(?:[^\[\]\\`]*(?:\[(?:brackets|\\[\s\S]|[^\[\]\\])*\]|\\[\s\S]|`+(?!`)[^`]*?`+(?!`)|``+(?=\]))){0,999}?[^\[\]\\`]*?/,
  )
    .replace("brackets", _r)
    .getRegex(),
  os = b("reflink|nolink(?!\\()", "g")
    .replace(
      "reflink",
      b(/^!?\[(label)\]\[(ref)\]/)
        .replace("label", as)
        .replace("ref", Wn)
        .getRegex(),
    )
    .replace(
      "nolink",
      b(/^!?\[(ref)\](?:\[\])?/)
        .replace("ref", Wn)
        .getRegex(),
    )
    .getRegex(),
  Gn = /[hH][tT][tT][pP][sS]?|[fF][tT][pP]/,
  cs =
    /[A-Za-z0-9._+-]+@[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![\w-])/,
  us = b(/(?:mailto:email|xmpp:email(?:\/[A-Za-z0-9@.]+)?)/)
    .replace(/email/g, cs)
    .getRegex(),
  tn = {
    _backpedal: be,
    anyPunctuation: es,
    autolink: ts,
    blockSkip: Bi,
    br: wr,
    code: Pi,
    del: be,
    delLDelim: be,
    delRDelim: be,
    emStrongLDelim: Fi,
    emStrongRDelimAst: Gi,
    emStrongRDelimUnd: Zi,
    escape: Ci,
    link: is,
    nolink: ls,
    punctuation: Ii,
    reflink: ss,
    reflinkSearch: os,
    tag: rs,
    text: Di,
    url: be,
  },
  ps = {
    ...tn,
    emStrongLDelim: Wi,
    emStrongRDelimAst: Yi,
    emStrongRDelimUnd: Xi,
    link: b(/^!?\[(label)\]\((.*?)\)/)
      .replace("label", pt)
      .getRegex(),
    reflink: b(/^!?\[(label)\]\s*\[([^\]]*)\]/)
      .replace("label", pt)
      .getRegex(),
  },
  Wt = {
    ...tn,
    emStrongRDelimAst: ji,
    emStrongLDelim: Ui,
    delLDelim: Qi,
    delRDelim: Ji,
    url: b(
      /^emailProtocol|^((?:protocol):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/,
    )
      .replace("emailProtocol", us)
      .replace("protocol", Gn)
      .replace(
        "email",
        /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![\w-])/,
      )
      .getRegex(),
    _backpedal:
      /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
    del: /^(~~?)(?=[^\s~])((?:\\[\s\S]|[^\\])*?(?:\\[\s\S]|[^\s~\\]))\1(?=[^~]|$)/,
    text: b(
      /^(?:[^a-zA-Z0-9](?=emailProtocol)|(`+|~+|[^`~])(?:(?=[`~])|(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|protocol:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9](?=emailProtocol)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@))))/,
    )
      .replace("protocol", Gn)
      .replace(/emailProtocol/g, /(?:mailto|xmpp):/)
      .getRegex(),
  },
  fs = {
    ...Wt,
    br: b(wr).replace("{2,}", "*").getRegex(),
    text: b(Wt.text)
      .replace("\\b_", "\\b_| {2,}\\n")
      .replace(/\{2,\}/g, "*")
      .getRegex(),
  },
  ot = { normal: en, gfm: Li, pedantic: Ni },
  Fe = { normal: tn, gfm: Wt, breaks: fs, pedantic: ps },
  hs = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" },
  jn = (t) => hs[t];
function j(t, e) {
  if (e) {
    if (I.escapeTest.test(t)) return t.replace(I.escapeReplace, jn);
  } else if (I.escapeTestNoEncode.test(t))
    return t.replace(I.escapeReplaceNoEncode, jn);
  return t;
}
function gs(t) {
  return t.replace(I.numericCharacterReference, (e, n, r) => {
    let i = n === void 0 ? Number.parseInt(r, 16) : Number.parseInt(n, 10);
    return i === 0 || i > 1114111 || (i >= 55296 && i <= 57343)
      ? "�"
      : String.fromCodePoint(i);
  });
}
function qn(t) {
  try {
    t = encodeURI(t).replace(I.percentDecode, "%");
  } catch {
    return null;
  }
  return t;
}
function Yn(t, e) {
  let n = t.replace(I.findPipe, (l, o, a) => {
      let u = !1,
        p = o;
      for (; --p >= 0 && a[p] === "\\";) u = !u;
      return u ? "|" : " |";
    }),
    r = n.split(I.splitPipe),
    i = 0;
  if (
    (r[0].trim() || r.shift(), r.length > 0 && !r.at(-1)?.trim() && r.pop(), e)
  )
    if (r.length > e) r.splice(e);
    else for (; r.length < e;) r.push("");
  for (; i < r.length; i++) r[i] = r[i].trim().replace(I.slashPipe, "|");
  return r;
}
function ue(t, e, n) {
  let r = t.length;
  if (r === 0) return "";
  let i = 0;
  for (; i < r && t.charAt(r - i - 1) === e;) i++;
  return t.slice(0, r - i);
}
function Zn(t) {
  let e = t.split(`
`),
    n = e.length - 1;
  for (; n >= 0 && I.blankLine.test(e[n]);) n--;
  return e.length - n <= 2
    ? t
    : e.slice(0, n + 1).join(`
`);
}
function ft(t) {
  return t.trim().toLowerCase().toUpperCase().toLowerCase();
}
function Vn(t, e) {
  if (t.indexOf(e[0]) === -1 && t.indexOf(e[1]) === -1) return -1;
  let n = 0;
  for (let r = 0; r < t.length; r++)
    if (t[r] === "\\") r++;
    else if (t[r] === e[0]) n++;
    else if (t[r] === e[1] && (n--, n < 0)) return r;
  return n > 0 ? -2 : -1;
}
function Xn(t, e = 0) {
  let n = e,
    r = "";
  for (let i of t)
    if (i === "	") {
      let l = 4 - (n % 4);
      ((r += " ".repeat(l)), (n += l));
    } else ((r += i), n++);
  return r;
}
function Qn(t, e, n, r, i) {
  let l = e.href,
    o = e.title || null,
    a = t[1].replace(i.other.outputLinkReplace, "$1"),
    u = t[0].charAt(0) === "!";
  r.state.inLink = !0;
  let p = r.state.linkEmitted,
    d = r.state.inRawBlock;
  r.state.linkEmitted = !1;
  let m = r.inlineTokens(a),
    L = r.state.linkEmitted;
  if (((r.state.linkEmitted = p), (r.state.inLink = !1), !u)) {
    if (L) {
      r.state.inRawBlock = d;
      return;
    }
    r.state.linkEmitted = !0;
  }
  return {
    type: u ? "image" : "link",
    raw: n,
    href: l,
    title: o,
    text: a,
    tokens: m,
  };
}
function ds(t, e, n) {
  let r = t.match(n.other.indentCodeCompensation);
  if (r === null) return e;
  let i = r[1];
  return e
    .split(
      `
`,
    )
    .map((l) => {
      let o = l.match(n.other.beginningSpace);
      if (o === null) return l;
      let [a] = o;
      return l.slice(Math.min(a.length, i.length));
    }).join(`
`);
}
function Kn(t, e, n, r) {
  if (!e.includes("<")) return !1;
  for (let i = 0; i < e.length; i++) {
    if (e[i] === "\\") {
      i++;
      continue;
    }
    if (e[i] === "`") {
      let a = r.inline.code.exec(e.slice(i));
      if (a) {
        i += a[0].length - 1;
        continue;
      }
    }
    if (e[i] !== "<") continue;
    let l = t.slice(n + i),
      o = r.inline.tag.exec(l) || r.inline.autolink.exec(l);
    if (o) {
      if (o[0].length > e.length - i) return !0;
      i += o[0].length - 1;
    }
  }
  return !1;
}
var ht = class {
    options;
    rules;
    lexer;
    constructor(t) {
      this.options = t || xe;
    }
    space(t) {
      let e = this.rules.block.newline.exec(t);
      if (e && e[0].length > 0) return { type: "space", raw: e[0] };
    }
    code(t) {
      let e = this.rules.block.code.exec(t);
      if (e) {
        let n = this.options.pedantic ? e[0] : Zn(e[0]),
          r = n.replace(this.rules.other.codeRemoveIndent, "");
        return { type: "code", raw: n, codeBlockStyle: "indented", text: r };
      }
    }
    fences(t) {
      let e = this.rules.block.fences.exec(t);
      if (e) {
        let n = e[0],
          r = ds(n, e[3] || "", this.rules);
        return {
          type: "code",
          raw: n,
          lang: e[2]
            ? e[2].trim().replace(this.rules.inline.anyPunctuation, "$1")
            : e[2],
          text: r,
        };
      }
    }
    heading(t) {
      let e = this.rules.block.heading.exec(t);
      if (e) {
        let n = e[2].trim();
        if (this.rules.other.endingHash.test(n)) {
          let r = ue(n, "#");
          (this.options.pedantic ||
            !r ||
            this.rules.other.endingSpaceTabChar.test(r)) &&
            (n = r.trim());
        }
        return {
          type: "heading",
          raw: ue(
            e[0],
            `
`,
          ),
          depth: e[1].length,
          text: n,
          tokens: this.lexer.inline(n),
        };
      }
    }
    hr(t) {
      let e = this.rules.block.hr.exec(t);
      if (e)
        return {
          type: "hr",
          raw: ue(
            e[0],
            `
`,
          ),
        };
    }
    blockquote(t) {
      let e = this.rules.block.blockquote.exec(t);
      if (e) {
        let n = ue(
            e[0],
            `
`,
          ).split(`
`),
          r = "",
          i = "",
          l = [];
        for (; n.length > 0;) {
          let o = !1,
            a = [],
            u;
          for (u = 0; u < n.length; u++)
            if (this.rules.other.blockquoteStart.test(n[u]))
              (a.push(n[u]), (o = !0));
            else if (!o) a.push(n[u]);
            else break;
          n = n.slice(u);
          let p = a.join(`
`),
            d = p
              .replace(
                this.rules.other.blockquoteSetextReplace,
                `
    $1`,
              )
              .replace(this.rules.other.blockquoteSetextReplace2, "");
          ((r = r
            ? `${r}
${p}`
            : p),
            (i = i
              ? `${i}
${d}`
              : d));
          let m = this.lexer.state.top;
          if (
            ((this.lexer.state.top = !0),
            this.lexer.blockTokens(d, l, !0),
            (this.lexer.state.top = m),
            n.length === 0)
          )
            break;
          let L = l.at(-1);
          if (L?.type === "code") break;
          if (L?.type === "blockquote") {
            let _ = L,
              A = n.join(`
`),
              M =
                _.raw +
                `
` +
                A.replace(this.rules.other.blockquoteSetextReplace2, ""),
              S = this.blockquote(M);
            l[l.length - 1] = S;
            let H = M.substring(S.raw.length).replace(/^\n/, ""),
              se = H
                ? H.split(`
`).length
                : 0,
              te = se ? n.slice(0, -se) : n;
            (te.length > 0 &&
              (r = `${r}
${te.join(`
`)}`),
              (i = i.substring(0, i.length - _.text.length) + S.text));
            break;
          } else if (L?.type === "list") {
            let _ = L,
              A =
                _.raw +
                `
` +
                n.join(`
`),
              M = this.list(A);
            ((l[l.length - 1] = M),
              (r = r.substring(0, r.length - L.raw.length) + M.raw),
              (i = i.substring(0, i.length - _.raw.length) + M.raw),
              (n = A.substring(l.at(-1).raw.length).split(`
`)));
            continue;
          }
        }
        return { type: "blockquote", raw: r, tokens: l, text: i };
      }
    }
    list(t) {
      let e = this.rules.block.list.exec(t);
      if (e) {
        let n = e[1].trim(),
          r = n.length > 1,
          i = {
            type: "list",
            raw: "",
            ordered: r,
            start: r ? +n.slice(0, -1) : "",
            loose: !1,
            items: [],
          };
        ((n = r ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`),
          this.options.pedantic && (n = r ? n : "[*+-]"));
        let l = this.rules.other.listItemRegex(n),
          o = !1;
        for (; t;) {
          let u = !1,
            p = "",
            d = "";
          if (!(e = l.exec(t)) || this.rules.block.hr.test(t)) break;
          ((p = e[0]), (t = t.substring(p.length)));
          let m = e[2].split(
              `
`,
              1,
            )[0],
            L = e[1].length,
            _ = this.options.pedantic
              ? Xn(m, L)
              : m.replace(this.rules.other.leadingSpaceTab, (H) => Xn(H, L)),
            A = t.split(
              `
`,
              1,
            )[0],
            M = !_.trim(),
            S = 0;
          if (
            (this.options.pedantic
              ? ((S = 2), (d = _.trimStart()))
              : M
                ? (S = L + 1)
                : ((S = _.search(this.rules.other.nonSpaceChar)),
                  (S = S > 4 ? 1 : S),
                  (d = _.slice(S)),
                  (S += L)),
            M &&
              this.rules.other.blankLine.test(A) &&
              ((p +=
                A +
                `
`),
              (t = t.substring(A.length + 1)),
              (u = !0)),
            !u)
          ) {
            let H = this.rules.other.nextBulletRegex(S),
              se = this.rules.other.hrRegex(S),
              te = this.rules.other.fencesBeginRegex(S),
              Q = this.rules.other.headingBeginRegex(S),
              le = this.rules.other.htmlBeginRegex(S),
              we = this.rules.other.blockquoteBeginRegex(S);
            for (; t;) {
              let ne = t.split(
                  `
`,
                  1,
                )[0],
                re;
              if (
                ((A = ne),
                this.options.pedantic
                  ? ((A = A.replace(this.rules.other.listReplaceNesting, "  ")),
                    (re = A))
                  : (re = A.replace(this.rules.other.leadingSpaceTab, ($) =>
                      $.replace(this.rules.other.tabCharGlobal, "    "),
                    )),
                te.test(A) ||
                  Q.test(A) ||
                  le.test(A) ||
                  we.test(A) ||
                  H.test(A) ||
                  se.test(A))
              )
                break;
              if (re.search(this.rules.other.nonSpaceChar) >= S || !A.trim())
                d +=
                  `
` + re.slice(S);
              else {
                if (
                  M ||
                  _.replace(this.rules.other.tabCharGlobal, "    ").search(
                    this.rules.other.nonSpaceChar,
                  ) >= 4 ||
                  te.test(_) ||
                  Q.test(_) ||
                  se.test(_)
                )
                  break;
                d +=
                  `
` + A;
              }
              ((M = !A.trim()),
                (p +=
                  ne +
                  `
`),
                (t = t.substring(ne.length + 1)),
                (_ = re.slice(S)));
            }
          }
          (i.loose ||
            (o
              ? (i.loose = !0)
              : this.rules.other.doubleBlankLine.test(p) && (o = !0)),
            i.items.push({
              type: "list_item",
              raw: p,
              task: !!this.options.gfm && this.rules.other.listIsTask.test(d),
              loose: !1,
              text: d,
              tokens: [],
            }),
            (i.raw += p));
        }
        let a = i.items.at(-1);
        if (a) ((a.raw = a.raw.trimEnd()), (a.text = a.text.trimEnd()));
        else return;
        i.raw = i.raw.trimEnd();
        for (let u of i.items)
          if (
            ((this.lexer.state.top = !1),
            (u.tokens = this.lexer.blockTokens(u.text, [])),
            !i.loose)
          ) {
            let p = u.tokens.filter((m) => m.type === "space"),
              d =
                p.length > 0 &&
                p.some((m) => this.rules.other.anyLine.test(m.raw));
            i.loose = d;
          }
        for (let u of i.items) {
          let p = u.tokens[0];
          if (u.task && (p?.type === "text" || p?.type === "paragraph")) {
            ((u.text = u.text.replace(this.rules.other.listReplaceTask, "")),
              (p.raw = p.raw.replace(this.rules.other.listReplaceTask, "")),
              (p.text = p.text.replace(this.rules.other.listReplaceTask, "")));
            for (let m = this.lexer.inlineQueue.length - 1; m >= 0; m--)
              if (
                this.rules.other.listIsTask.test(this.lexer.inlineQueue[m].src)
              ) {
                this.lexer.inlineQueue[m].src = this.lexer.inlineQueue[
                  m
                ].src.replace(this.rules.other.listReplaceTask, "");
                break;
              }
            let d = this.rules.other.listTaskCheckbox.exec(u.raw);
            if (d) {
              let m = {
                type: "checkbox",
                raw: d[0] + " ",
                checked: d[0] !== "[ ]",
              };
              ((u.checked = m.checked),
                i.loose
                  ? u.tokens[0] &&
                    ["paragraph", "text"].includes(u.tokens[0].type) &&
                    "tokens" in u.tokens[0] &&
                    u.tokens[0].tokens
                    ? ((u.tokens[0].raw = m.raw + u.tokens[0].raw),
                      (u.tokens[0].text = m.raw + u.tokens[0].text),
                      u.tokens[0].tokens.unshift(m))
                    : u.tokens.unshift({
                        type: "paragraph",
                        raw: m.raw,
                        text: m.raw,
                        tokens: [m],
                      })
                  : u.tokens.unshift(m));
            }
          } else u.task && (u.task = !1);
        }
        if (i.loose)
          for (let u of i.items) {
            u.loose = !0;
            for (let p of u.tokens) p.type === "text" && (p.type = "paragraph");
          }
        return i;
      }
    }
    html(t) {
      let e = this.rules.block.html.exec(t);
      if (e) {
        let n = Zn(e[0]);
        return {
          type: "html",
          block: !0,
          raw: n,
          pre: e[1] === "pre" || e[1] === "script" || e[1] === "style",
          text: n,
        };
      }
    }
    def(t) {
      let e = this.rules.block.def.exec(t);
      if (e) {
        if (
          !this.rules.other.startAngleBracket.test(e[2]) &&
          Vn(e[2], "()") !== -1
        )
          return;
        let n = ft(e[1]).replace(this.rules.other.multipleSpaceGlobal, " "),
          r = e[2]
            ? e[2]
                .replace(this.rules.other.hrefBrackets, "$1")
                .replace(this.rules.inline.anyPunctuation, "$1")
            : "",
          i = e[3]
            ? e[3]
                .substring(1, e[3].length - 1)
                .replace(this.rules.inline.anyPunctuation, "$1")
            : e[3];
        return {
          type: "def",
          tag: n,
          raw: ue(
            e[0],
            `
`,
          ),
          href: r,
          title: i,
        };
      }
    }
    table(t) {
      let e = this.rules.block.table.exec(t);
      if (!e || !this.rules.other.tableDelimiter.test(e[2])) return;
      let n = Yn(e[1]),
        r = e[2].replace(this.rules.other.tableAlignChars, "").split("|"),
        i = e[3]?.trim()
          ? e[3].replace(this.rules.other.tableRowBlankLine, "").split(`
`)
          : [],
        l = {
          type: "table",
          raw: ue(
            e[0],
            `
`,
          ),
          header: [],
          align: [],
          rows: [],
        };
      if (n.length === r.length) {
        for (let o of r)
          this.rules.other.tableAlignRight.test(o)
            ? l.align.push("right")
            : this.rules.other.tableAlignCenter.test(o)
              ? l.align.push("center")
              : this.rules.other.tableAlignLeft.test(o)
                ? l.align.push("left")
                : l.align.push(null);
        for (let o = 0; o < n.length; o++)
          l.header.push({
            text: n[o],
            tokens: this.lexer.inline(n[o]),
            header: !0,
            align: l.align[o],
          });
        for (let o of i)
          l.rows.push(
            Yn(o, l.header.length).map((a, u) => ({
              text: a,
              tokens: this.lexer.inline(a),
              header: !1,
              align: l.align[u],
            })),
          );
        return l;
      }
    }
    lheading(t) {
      let e = this.rules.block.lheading.exec(t);
      if (e) {
        let n = e[1].trim();
        return {
          type: "heading",
          raw: ue(
            e[0],
            `
`,
          ),
          depth: e[2].charAt(0) === "=" ? 1 : 2,
          text: n,
          tokens: this.lexer.inline(n),
        };
      }
    }
    paragraph(t) {
      let e = this.rules.block.paragraph.exec(t);
      if (e) {
        let n =
          e[1].charAt(e[1].length - 1) ===
          `
`
            ? e[1].slice(0, -1)
            : e[1];
        return {
          type: "paragraph",
          raw: e[0],
          text: n,
          tokens: this.lexer.inline(n),
        };
      }
    }
    text(t) {
      let e = this.rules.block.text.exec(t);
      if (e)
        return {
          type: "text",
          raw: e[0],
          text: e[0],
          tokens: this.lexer.inline(e[0]),
        };
    }
    escape(t) {
      let e = this.rules.inline.escape.exec(t);
      if (e) return { type: "escape", raw: e[0], text: e[1] };
    }
    tag(t) {
      let e = this.rules.inline.tag.exec(t);
      if (e)
        return (
          !this.lexer.state.inLink && this.rules.other.startATag.test(e[0])
            ? (this.lexer.state.inLink = !0)
            : this.lexer.state.inLink &&
              this.rules.other.endATag.test(e[0]) &&
              (this.lexer.state.inLink = !1),
          !this.lexer.state.inRawBlock &&
          this.rules.other.startPreScriptTag.test(e[0])
            ? (this.lexer.state.inRawBlock = !0)
            : this.lexer.state.inRawBlock &&
              this.rules.other.endPreScriptTag.test(e[0]) &&
              (this.lexer.state.inRawBlock = !1),
          {
            type: "html",
            raw: e[0],
            inLink: this.lexer.state.inLink,
            inRawBlock: this.lexer.state.inRawBlock,
            block: !1,
            text: e[0],
          }
        );
    }
    link(t) {
      if (this.lexer.state.linkParenPossible === !1) return;
      let e = this.rules.inline.link.exec(t);
      if (e) {
        let n = e[0].charAt(0) === "!" ? 2 : 1;
        if (!this.options.pedantic && Kn(t, e[1], n, this.rules)) return;
        let r = e[2].trim();
        if (
          !this.options.pedantic &&
          this.rules.other.startAngleBracket.test(r)
        ) {
          if (!this.rules.other.endAngleBracket.test(r)) return;
          let o = ue(r.slice(0, -1), "\\");
          if ((r.length - o.length) % 2 === 0) return;
        } else {
          let o = Vn(e[2], "()");
          if (o === -2) return;
          if (o > -1) {
            let a = (e[0].indexOf("!") === 0 ? 5 : 4) + e[1].length + o;
            ((e[2] = e[2].substring(0, o)),
              (e[0] = e[0].substring(0, a).trim()),
              (e[3] = ""));
          }
        }
        let i = e[2],
          l = "";
        if (this.options.pedantic) {
          let o = this.rules.other.pedanticHrefTitle.exec(i);
          o && ((i = o[1]), (l = o[3]));
        } else l = e[3] ? e[3].slice(1, -1) : "";
        return (
          (i = i.trim()),
          this.rules.other.startAngleBracket.test(i) &&
            (this.options.pedantic && !this.rules.other.endAngleBracket.test(r)
              ? (i = i.slice(1))
              : (i = i.slice(1, -1))),
          Qn(
            e,
            {
              href: i && i.replace(this.rules.inline.anyPunctuation, "$1"),
              title: l && l.replace(this.rules.inline.anyPunctuation, "$1"),
            },
            e[0],
            this.lexer,
            this.rules,
          )
        );
      }
    }
    reflink(t, e) {
      let n;
      if (
        (n = this.rules.inline.reflink.exec(t)) ||
        (n = this.rules.inline.nolink.exec(t))
      ) {
        let r = n[0].charAt(0) === "!" ? 2 : 1;
        if (!this.options.pedantic && Kn(t, n[1], r, this.rules)) return;
        let i = (n[2] || n[1]).replace(
            this.rules.other.multipleSpaceGlobal,
            " ",
          ),
          l = e[ft(i)];
        if (!l) {
          let o = n[0].charAt(0);
          return { type: "text", raw: o, text: o };
        }
        return Qn(n, l, n[0], this.lexer, this.rules);
      }
    }
    emStrong(t, e, n = "") {
      let r = this.rules.inline.emStrongLDelim.exec(t);
      if (
        !(
          !r ||
          (!r[1] && !r[2] && !r[3] && !r[4]) ||
          (r[4] && n.match(this.rules.other.unicodeAlphaNumeric))
        ) &&
        (!(r[1] || r[3]) || !n || this.rules.inline.punctuation.exec(n))
      ) {
        let i = [...r[0]].length - 1,
          l,
          o,
          a = i,
          u = 0,
          p = r[0][0],
          d = n === p,
          m =
            p === "*"
              ? this.rules.inline.emStrongRDelimAst
              : this.rules.inline.emStrongRDelimUnd;
        for (
          m.lastIndex = 0, e = e.slice(-1 * t.length + i);
          (r = m.exec(e)) !== null;
        ) {
          if (((l = r[1] || r[2] || r[3] || r[4] || r[5] || r[6]), !l))
            continue;
          if (((o = [...l].length), r[3] || r[4])) {
            a += o;
            continue;
          } else if (r[5] || r[6]) {
            if (i % 3 && !((i + o) % 3)) {
              u += o;
              continue;
            }
            if (d) break;
          }
          if (((a -= o), a > 0)) continue;
          o = Math.min(o, o + a + u);
          let L = [...r[0]][0].length,
            _ = t.slice(0, i + r.index + L + o);
          if (Math.min(i, o) % 2) {
            let M = _.slice(1, -1);
            return {
              type: "em",
              raw: _,
              text: M,
              tokens: this.lexer.inlineTokens(M),
            };
          }
          let A = _.slice(2, -2);
          return {
            type: "strong",
            raw: _,
            text: A,
            tokens: this.lexer.inlineTokens(A),
          };
        }
      }
    }
    codespan(t) {
      let e = this.rules.inline.code.exec(t);
      if (e) {
        let n = e[2].replace(this.rules.other.newLineCharGlobal, " "),
          r = this.rules.other.nonSpaceChar.test(n),
          i =
            this.rules.other.startingSpaceChar.test(n) &&
            this.rules.other.endingSpaceChar.test(n);
        return (
          r && i && (n = n.substring(1, n.length - 1)),
          { type: "codespan", raw: e[0], text: n }
        );
      }
    }
    br(t) {
      let e = this.rules.inline.br.exec(t);
      if (e) return { type: "br", raw: e[0] };
    }
    del(t, e, n = "") {
      let r = this.rules.inline.delLDelim.exec(t);
      if (r && (!r[1] || !n || this.rules.inline.punctuation.exec(n))) {
        let i = [...r[0]].length - 1,
          l,
          o,
          a = i,
          u = this.rules.inline.delRDelim;
        for (
          u.lastIndex = 0, e = e.slice(-1 * t.length + i);
          (r = u.exec(e)) !== null;
        ) {
          if (
            ((l = r[1] || r[2] || r[3] || r[4] || r[5] || r[6]),
            !l || ((o = [...l].length), o !== i))
          )
            continue;
          if (r[3] || r[4]) {
            a += o;
            continue;
          }
          if (((a -= o), a > 0)) continue;
          o = Math.min(o, o + a);
          let p = [...r[0]][0].length,
            d = t.slice(0, i + r.index + p + o),
            m = d.slice(i, -i);
          return {
            type: "del",
            raw: d,
            text: m,
            tokens: this.lexer.inlineTokens(m),
          };
        }
      }
    }
    autolink(t) {
      let e = this.rules.inline.autolink.exec(t);
      if (e) {
        let n, r;
        return (
          e[2] === "@"
            ? ((n = e[1]), (r = "mailto:" + n))
            : ((n = e[1]), (r = n)),
          {
            type: "link",
            raw: e[0],
            text: n,
            href: r,
            autolink: !0,
            tokens: [{ type: "text", raw: n, text: n }],
          }
        );
      }
    }
    url(t) {
      let e;
      if ((e = this.rules.inline.url.exec(t))) {
        let n, r;
        if (e[2] === "@") ((n = e[0]), (r = "mailto:" + n));
        else {
          let i;
          do
            ((i = e[0]),
              (e[0] = this.rules.inline._backpedal.exec(e[0])?.[0] ?? ""));
          while (i !== e[0]);
          ((n = e[0]), e[1] === "www." ? (r = "http://" + e[0]) : (r = e[0]));
        }
        return {
          type: "link",
          raw: e[0],
          text: n,
          href: r,
          autolink: !0,
          tokens: [{ type: "text", raw: n, text: n }],
        };
      }
    }
    inlineText(t) {
      let e = this.rules.inline.text.exec(t);
      if (e) {
        let n = this.lexer.state.inRawBlock;
        return {
          type: "text",
          raw: e[0],
          text: n ? e[0] : gs(e[0]),
          escaped: n,
        };
      }
    }
  },
  V = class Gt {
    tokens;
    options;
    state;
    inlineQueue;
    tokenizer;
    constructor(e) {
      ((this.tokens = []),
        (this.tokens.links = Object.create(null)),
        (this.options = e || xe),
        (this.options.tokenizer = this.options.tokenizer || new ht()),
        (this.tokenizer = this.options.tokenizer),
        (this.tokenizer.options = this.options),
        (this.tokenizer.lexer = this),
        (this.inlineQueue = []),
        (this.state = {
          inLink: !1,
          inRawBlock: !1,
          linkEmitted: !1,
          linkParenPossible: !0,
          top: !0,
        }));
      let n = { other: I, block: ot.normal, inline: Fe.normal };
      (this.options.pedantic
        ? ((n.block = ot.pedantic), (n.inline = Fe.pedantic))
        : this.options.gfm &&
          ((n.block = ot.gfm),
          this.options.breaks ? (n.inline = Fe.breaks) : (n.inline = Fe.gfm)),
        (this.tokenizer.rules = n));
    }
    static get rules() {
      return { block: ot, inline: Fe };
    }
    static lex(e, n) {
      return new Gt(n).lex(e);
    }
    static lexInline(e, n) {
      return new Gt(n).inlineTokens(e);
    }
    lex(e) {
      ((e = e.replace(
        I.carriageReturn,
        `
`,
      )),
        this.blockTokens(e, this.tokens));
      for (let n = 0; n < this.inlineQueue.length; n++) {
        let r = this.inlineQueue[n];
        this.inlineTokens(r.src, r.tokens);
      }
      return ((this.inlineQueue = []), this.tokens);
    }
    blockTokens(e, n = [], r = !1) {
      ((this.tokenizer.lexer = this),
        this.options.pedantic &&
          (e = e.replace(I.tabCharGlobal, "    ").replace(I.spaceLine, "")));
      let i = 1 / 0;
      for (; e;) {
        if (e.length < i) i = e.length;
        else {
          this.infiniteLoopError(e.charCodeAt(0));
          break;
        }
        let l;
        if (
          this.options.extensions?.block?.some((a) =>
            (l = a.call({ lexer: this }, e, n))
              ? ((e = e.substring(l.raw.length)), n.push(l), !0)
              : !1,
          )
        )
          continue;
        if ((l = this.tokenizer.space(e))) {
          e = e.substring(l.raw.length);
          let a = n.at(-1);
          l.raw.length === 1 && a !== void 0
            ? (a.raw += `
`)
            : n.push(l);
          continue;
        }
        if ((l = this.tokenizer.code(e))) {
          e = e.substring(l.raw.length);
          let a = n.at(-1);
          a?.type === "paragraph" || a?.type === "text"
            ? ((a.raw +=
                (a.raw.endsWith(`
`)
                  ? ""
                  : `
`) + l.raw),
              (a.text +=
                `
` + l.text),
              (this.inlineQueue.at(-1).src = a.text))
            : n.push(l);
          continue;
        }
        if ((l = this.tokenizer.fences(e))) {
          ((e = e.substring(l.raw.length)), n.push(l));
          continue;
        }
        if ((l = this.tokenizer.heading(e))) {
          ((e = e.substring(l.raw.length)), n.push(l));
          continue;
        }
        if ((l = this.tokenizer.hr(e))) {
          ((e = e.substring(l.raw.length)), n.push(l));
          continue;
        }
        if ((l = this.tokenizer.blockquote(e))) {
          ((e = e.substring(l.raw.length)), n.push(l));
          continue;
        }
        if ((l = this.tokenizer.list(e))) {
          ((e = e.substring(l.raw.length)), n.push(l));
          continue;
        }
        if ((l = this.tokenizer.html(e))) {
          ((e = e.substring(l.raw.length)), n.push(l));
          continue;
        }
        if ((l = this.tokenizer.def(e))) {
          e = e.substring(l.raw.length);
          let a = n.at(-1);
          a?.type === "paragraph" || a?.type === "text"
            ? ((a.raw +=
                (a.raw.endsWith(`
`)
                  ? ""
                  : `
`) + l.raw),
              (a.text +=
                `
` + l.raw),
              (this.inlineQueue.at(-1).src = a.text))
            : this.tokens.links[l.tag] ||
              ((this.tokens.links[l.tag] = { href: l.href, title: l.title }),
              n.push(l));
          continue;
        }
        if ((l = this.tokenizer.table(e))) {
          ((e = e.substring(l.raw.length)), n.push(l));
          continue;
        }
        if ((l = this.tokenizer.lheading(e))) {
          ((e = e.substring(l.raw.length)), n.push(l));
          continue;
        }
        let o = e;
        if (this.options.extensions?.startBlock) {
          let a = 1 / 0,
            u = e.slice(1),
            p;
          (this.options.extensions.startBlock.forEach((d) => {
            ((p = d.call({ lexer: this }, u)),
              typeof p == "number" && p >= 0 && (a = Math.min(a, p)));
          }),
            a < 1 / 0 && a >= 0 && (o = e.substring(0, a + 1)));
        }
        if (this.state.top && (l = this.tokenizer.paragraph(o))) {
          let a = n.at(-1);
          (r && a?.type === "paragraph"
            ? ((a.raw +=
                (a.raw.endsWith(`
`)
                  ? ""
                  : `
`) + l.raw),
              (a.text +=
                `
` + l.text),
              this.inlineQueue.pop(),
              (this.inlineQueue.at(-1).src = a.text))
            : n.push(l),
            (r = o.length !== e.length),
            (e = e.substring(l.raw.length)));
          continue;
        }
        if ((l = this.tokenizer.text(e))) {
          e = e.substring(l.raw.length);
          let a = n.at(-1);
          a?.type === "text"
            ? ((a.raw +=
                (a.raw.endsWith(`
`)
                  ? ""
                  : `
`) + l.raw),
              (a.text +=
                `
` + l.text),
              this.inlineQueue.pop(),
              (this.inlineQueue.at(-1).src = a.text))
            : n.push(l);
          continue;
        }
        if (e) {
          this.infiniteLoopError(e.charCodeAt(0));
          break;
        }
      }
      return ((this.state.top = !0), n);
    }
    inline(e, n = []) {
      return (this.inlineQueue.push({ src: e, tokens: n }), n);
    }
    linkInText(e) {
      if (!e.includes("[")) return !1;
      let n = this.tokenizer.rules.inline.link;
      for (let r of e.matchAll(this.tokenizer.rules.inline.blockSkip))
        if (n.test(r[0]) && e.charAt(r.index - 1) !== "!") return !0;
      for (let r of e.matchAll(this.tokenizer.rules.inline.reflinkSearch)) {
        let i = r[0],
          l = i.lastIndexOf("[");
        if (
          !(
            i.charAt(0) === "!" ||
            !Object.hasOwn(this.tokens.links, ft(i.slice(l + 1, -1)))
          ) &&
          !(l > 1 && this.linkInText(i.slice(1, l - 1)))
        )
          return !0;
      }
      return !1;
    }
    inlineTokens(e, n = []) {
      this.tokenizer.lexer = this;
      let r = this.state.linkParenPossible;
      this.state.linkParenPossible = r && e.includes(")");
      try {
        return this.#e(e, n);
      } finally {
        this.state.linkParenPossible = r;
      }
    }
    #e(e, n) {
      let r = e;
      if (this.tokens.links && e.includes("[")) {
        let a = this.tokenizer.rules.inline.reflinkSearch,
          u = (p) => {
            let d = p.lastIndexOf("[");
            if (!Object.hasOwn(this.tokens.links, ft(p.slice(d + 1, -1))))
              return p;
            if (d > 1 && p.charAt(0) !== "!") {
              let m = p.slice(1, d - 1);
              if (this.linkInText(m))
                return (
                  "[" +
                  m.replace(a, u) +
                  "][" +
                  "a".repeat(p.length - d - 2) +
                  "]"
                );
            }
            return "[" + "a".repeat(p.length - 2) + "]";
          };
        r = r.replace(a, u);
      }
      ((r = r.replace(this.tokenizer.rules.inline.anyPunctuation, (a) =>
        "+".repeat(a.length),
      )),
        (r = r.replace(this.tokenizer.rules.inline.blockSkip, (a, u, p) => {
          let d = p ? p.length : 0;
          return a.slice(0, d) + "[" + "a".repeat(a.length - d - 2) + "]";
        })),
        (r = this.options.hooks?.emStrongMask?.call({ lexer: this }, r) ?? r));
      let i = !1,
        l = "",
        o = 1 / 0;
      for (; e;) {
        if (e.length < o) o = e.length;
        else {
          this.infiniteLoopError(e.charCodeAt(0));
          break;
        }
        (i || (l = ""), (i = !1));
        let a;
        if (
          this.options.extensions?.inline?.some((p) =>
            (a = p.call({ lexer: this }, e, n))
              ? ((e = e.substring(a.raw.length)), n.push(a), !0)
              : !1,
          )
        )
          continue;
        if ((a = this.tokenizer.escape(e))) {
          ((e = e.substring(a.raw.length)), n.push(a));
          continue;
        }
        if ((a = this.tokenizer.tag(e))) {
          ((e = e.substring(a.raw.length)), n.push(a));
          continue;
        }
        if ((a = this.tokenizer.link(e))) {
          ((e = e.substring(a.raw.length)), n.push(a));
          continue;
        }
        if ((a = this.tokenizer.reflink(e, this.tokens.links))) {
          e = e.substring(a.raw.length);
          let p = n.at(-1);
          a.type === "text" && p?.type === "text"
            ? ((p.raw += a.raw), (p.text += a.text))
            : n.push(a);
          continue;
        }
        if ((a = this.tokenizer.emStrong(e, r, l))) {
          ((e = e.substring(a.raw.length)), n.push(a));
          continue;
        }
        if ((a = this.tokenizer.codespan(e))) {
          ((e = e.substring(a.raw.length)), n.push(a));
          continue;
        }
        if ((a = this.tokenizer.br(e))) {
          ((e = e.substring(a.raw.length)), n.push(a));
          continue;
        }
        if ((a = this.tokenizer.del(e, r, l))) {
          ((e = e.substring(a.raw.length)), n.push(a));
          continue;
        }
        if ((a = this.tokenizer.autolink(e))) {
          ((e = e.substring(a.raw.length)), n.push(a));
          continue;
        }
        if (!this.state.inLink && (a = this.tokenizer.url(e))) {
          ((e = e.substring(a.raw.length)), n.push(a));
          continue;
        }
        let u = e;
        if (this.options.extensions?.startInline) {
          let p = 1 / 0,
            d = e.slice(1),
            m;
          (this.options.extensions.startInline.forEach((L) => {
            ((m = L.call({ lexer: this }, d)),
              typeof m == "number" && m >= 0 && (p = Math.min(p, m)));
          }),
            p < 1 / 0 && p >= 0 && (u = e.substring(0, p + 1)));
        }
        if ((a = this.tokenizer.inlineText(u))) {
          ((e = e.substring(a.raw.length)),
            a.raw.slice(-1) !== "_" && (l = a.raw.slice(-1)),
            (i = !0));
          let p = n.at(-1);
          p?.type === "text"
            ? ((p.raw += a.raw), (p.text += a.text))
            : n.push(a);
          continue;
        }
        if (e) {
          this.infiniteLoopError(e.charCodeAt(0));
          break;
        }
      }
      return n;
    }
    infiniteLoopError(e) {
      let n = "Infinite loop on byte: " + e;
      if (this.options.silent) console.error(n);
      else throw new Error(n);
    }
  },
  gt = class {
    options;
    parser;
    constructor(t) {
      this.options = t || xe;
    }
    space(t) {
      return "";
    }
    code({ text: t, lang: e, escaped: n }) {
      let r = (e || "").match(I.notSpaceStart)?.[0],
        i = t
          ? t.replace(I.endingNewline, "") +
            `
`
          : "";
      return r
        ? '<pre><code class="language-' +
            j(r) +
            '">' +
            (n ? i : j(i, !0)) +
            `</code></pre>
`
        : "<pre><code>" +
            (n ? i : j(i, !0)) +
            `</code></pre>
`;
    }
    blockquote({ tokens: t }) {
      return `<blockquote>
${this.parser.parse(t)}</blockquote>
`;
    }
    html({ text: t }) {
      return t;
    }
    def(t) {
      return "";
    }
    heading({ tokens: t, depth: e }) {
      return `<h${e}>${this.parser.parseInline(t)}</h${e}>
`;
    }
    hr(t) {
      return `<hr>
`;
    }
    list(t) {
      let e = t.ordered,
        n = t.start,
        r = "";
      for (let o = 0; o < t.items.length; o++) {
        let a = t.items[o];
        r += this.listitem(a);
      }
      let i = e ? "ol" : "ul",
        l = e && n !== 1 ? ' start="' + n + '"' : "";
      return (
        "<" +
        i +
        l +
        `>
` +
        r +
        "</" +
        i +
        `>
`
      );
    }
    listitem(t) {
      return `<li>${this.parser.parse(t.tokens)}</li>
`;
    }
    checkbox({ checked: t }) {
      return (
        "<input " + (t ? 'checked="" ' : "") + 'disabled="" type="checkbox"> '
      );
    }
    paragraph({ tokens: t }) {
      return `<p>${this.parser.parseInline(t)}</p>
`;
    }
    table(t) {
      let e = "",
        n = "";
      for (let i = 0; i < t.header.length; i++)
        n += this.tablecell(t.header[i]);
      e += this.tablerow({ text: n });
      let r = "";
      for (let i = 0; i < t.rows.length; i++) {
        let l = t.rows[i];
        n = "";
        for (let o = 0; o < l.length; o++) n += this.tablecell(l[o]);
        r += this.tablerow({ text: n });
      }
      return (
        r && (r = `<tbody>${r}</tbody>`),
        `<table>
<thead>
` +
          e +
          `</thead>
` +
          r +
          `</table>
`
      );
    }
    tablerow({ text: t }) {
      return `<tr>
${t}</tr>
`;
    }
    tablecell(t) {
      let e = this.parser.parseInline(t.tokens),
        n = t.header ? "th" : "td";
      return (
        (t.align ? `<${n} align="${t.align}">` : `<${n}>`) +
        e +
        `</${n}>
`
      );
    }
    strong({ tokens: t }) {
      return `<strong>${this.parser.parseInline(t)}</strong>`;
    }
    em({ tokens: t }) {
      return `<em>${this.parser.parseInline(t)}</em>`;
    }
    codespan({ text: t }) {
      return `<code>${j(t, !0)}</code>`;
    }
    br(t) {
      return "<br>";
    }
    del({ tokens: t }) {
      return `<del>${this.parser.parseInline(t)}</del>`;
    }
    link({ href: t, title: e, text: n, tokens: r, autolink: i }) {
      let l = i ? j(n, !0) : this.parser.parseInline(r),
        o = qn(t);
      if (o === null) return l;
      t = j(o, i);
      let a = '<a href="' + t + '"';
      return (e && (a += ' title="' + j(e) + '"'), (a += ">" + l + "</a>"), a);
    }
    image({ href: t, title: e, text: n, tokens: r }) {
      r && (n = this.parser.parseInline(r, this.parser.textRenderer));
      let i = qn(t);
      if (i === null) return j(n);
      t = i;
      let l = `<img src="${j(t)}" alt="${j(n)}"`;
      return (e && (l += ` title="${j(e)}"`), (l += ">"), l);
    }
    text(t) {
      return "tokens" in t && t.tokens
        ? this.parser.parseInline(t.tokens)
        : "escaped" in t && t.escaped
          ? t.text
          : j(t.text);
    }
  },
  nn = class {
    strong({ text: t }) {
      return t;
    }
    em({ text: t }) {
      return t;
    }
    codespan({ text: t }) {
      return t;
    }
    del({ text: t }) {
      return t;
    }
    html({ text: t }) {
      return t;
    }
    text({ text: t }) {
      return t;
    }
    link({ text: t }) {
      return "" + t;
    }
    image({ text: t }) {
      return "" + t;
    }
    br() {
      return "";
    }
    checkbox({ raw: t }) {
      return t;
    }
  },
  X = class jt {
    options;
    renderer;
    textRenderer;
    constructor(e) {
      ((this.options = e || xe),
        (this.options.renderer = this.options.renderer || new gt()),
        (this.renderer = this.options.renderer),
        (this.renderer.options = this.options),
        (this.renderer.parser = this),
        (this.textRenderer = new nn()));
    }
    static parse(e, n) {
      return new jt(n).parse(e);
    }
    static parseInline(e, n) {
      return new jt(n).parseInline(e);
    }
    parse(e) {
      this.renderer.parser = this;
      let n = "";
      for (let r = 0; r < e.length; r++) {
        let i = e[r];
        if (this.options.extensions?.renderers?.[i.type]) {
          let o = i,
            a = this.options.extensions.renderers[o.type].call(
              { parser: this },
              o,
            );
          if (
            a !== !1 ||
            ![
              "space",
              "hr",
              "heading",
              "code",
              "table",
              "blockquote",
              "list",
              "checkbox",
              "html",
              "def",
              "paragraph",
              "text",
            ].includes(o.type)
          ) {
            n += a || "";
            continue;
          }
        }
        let l = i;
        switch (l.type) {
          case "space": {
            n += this.renderer.space(l);
            break;
          }
          case "hr": {
            n += this.renderer.hr(l);
            break;
          }
          case "heading": {
            n += this.renderer.heading(l);
            break;
          }
          case "code": {
            n += this.renderer.code(l);
            break;
          }
          case "table": {
            n += this.renderer.table(l);
            break;
          }
          case "blockquote": {
            n += this.renderer.blockquote(l);
            break;
          }
          case "list": {
            n += this.renderer.list(l);
            break;
          }
          case "checkbox": {
            n += this.renderer.checkbox(l);
            break;
          }
          case "html": {
            n += this.renderer.html(l);
            break;
          }
          case "def": {
            n += this.renderer.def(l);
            break;
          }
          case "paragraph": {
            n += this.renderer.paragraph(l);
            break;
          }
          case "text": {
            n += this.renderer.text(l);
            break;
          }
          default: {
            let o = 'Token with "' + l.type + '" type was not found.';
            if (this.options.silent) return (console.error(o), "");
            throw new Error(o);
          }
        }
      }
      return n;
    }
    parseInline(e, n = this.renderer) {
      this.renderer.parser = this;
      let r = "";
      for (let i = 0; i < e.length; i++) {
        let l = e[i];
        if (this.options.extensions?.renderers?.[l.type]) {
          let a = this.options.extensions.renderers[l.type].call(
            { parser: this },
            l,
          );
          if (
            a !== !1 ||
            ![
              "escape",
              "html",
              "link",
              "image",
              "checkbox",
              "strong",
              "em",
              "codespan",
              "br",
              "del",
              "text",
            ].includes(l.type)
          ) {
            r += a || "";
            continue;
          }
        }
        let o = l;
        switch (o.type) {
          case "escape": {
            r += n.text(o);
            break;
          }
          case "html": {
            r += n.html(o);
            break;
          }
          case "link": {
            r += n.link(o);
            break;
          }
          case "image": {
            r += n.image(o);
            break;
          }
          case "checkbox": {
            r += n.checkbox(o);
            break;
          }
          case "strong": {
            r += n.strong(o);
            break;
          }
          case "em": {
            r += n.em(o);
            break;
          }
          case "codespan": {
            r += n.codespan(o);
            break;
          }
          case "br": {
            r += n.br(o);
            break;
          }
          case "del": {
            r += n.del(o);
            break;
          }
          case "text": {
            r += n.text(o);
            break;
          }
          default: {
            let a = 'Token with "' + o.type + '" type was not found.';
            if (this.options.silent) return (console.error(a), "");
            throw new Error(a);
          }
        }
      }
      return r;
    }
  },
  Ge = class {
    options;
    block;
    constructor(t) {
      this.options = t || xe;
    }
    static passThroughHooks = new Set([
      "preprocess",
      "postprocess",
      "processAllTokens",
      "emStrongMask",
    ]);
    static passThroughHooksRespectAsync = new Set([
      "preprocess",
      "postprocess",
      "processAllTokens",
    ]);
    preprocess(t) {
      return t;
    }
    postprocess(t) {
      return t;
    }
    processAllTokens(t) {
      return t;
    }
    emStrongMask(t) {
      return t;
    }
    provideLexer(t = this.block) {
      return t ? V.lex : V.lexInline;
    }
    provideParser(t = this.block) {
      return t ? X.parse : X.parseInline;
    }
  },
  ms = class {
    defaults = Vt();
    options = this.setOptions;
    parse = this.parseMarkdown(!0);
    parseInline = this.parseMarkdown(!1);
    Parser = X;
    Renderer = gt;
    TextRenderer = nn;
    Lexer = V;
    Tokenizer = ht;
    Hooks = Ge;
    constructor(...t) {
      this.use(...t);
    }
    walkTokens(t, e) {
      let n = [];
      for (let r of t)
        switch (((n = n.concat(e.call(this, r))), r.type)) {
          case "table": {
            let i = r;
            for (let l of i.header) n = n.concat(this.walkTokens(l.tokens, e));
            for (let l of i.rows)
              for (let o of l) n = n.concat(this.walkTokens(o.tokens, e));
            break;
          }
          case "list": {
            let i = r;
            n = n.concat(this.walkTokens(i.items, e));
            break;
          }
          default: {
            let i = r;
            this.defaults.extensions?.childTokens?.[i.type]
              ? this.defaults.extensions.childTokens[i.type].forEach((l) => {
                  let o = i[l].flat(1 / 0);
                  n = n.concat(this.walkTokens(o, e));
                })
              : i.tokens && (n = n.concat(this.walkTokens(i.tokens, e)));
          }
        }
      return n;
    }
    use(...t) {
      let e = this.defaults.extensions || { renderers: {}, childTokens: {} };
      return (
        t.forEach((n) => {
          let r = { ...n };
          if (
            ((r.async = this.defaults.async || r.async || !1),
            n.extensions &&
              (n.extensions.forEach((i) => {
                if (!i.name) throw new Error("extension name required");
                if ("renderer" in i) {
                  let l = e.renderers[i.name];
                  l
                    ? (e.renderers[i.name] = function (...o) {
                        let a = i.renderer.apply(this, o);
                        return (a === !1 && (a = l.apply(this, o)), a);
                      })
                    : (e.renderers[i.name] = i.renderer);
                }
                if ("tokenizer" in i) {
                  if (!i.level || (i.level !== "block" && i.level !== "inline"))
                    throw new Error(
                      "extension level must be 'block' or 'inline'",
                    );
                  let l = e[i.level];
                  (l ? l.unshift(i.tokenizer) : (e[i.level] = [i.tokenizer]),
                    i.start &&
                      (i.level === "block"
                        ? e.startBlock
                          ? e.startBlock.push(i.start)
                          : (e.startBlock = [i.start])
                        : i.level === "inline" &&
                          (e.startInline
                            ? e.startInline.push(i.start)
                            : (e.startInline = [i.start]))));
                }
                "childTokens" in i &&
                  i.childTokens &&
                  (e.childTokens[i.name] = i.childTokens);
              }),
              (r.extensions = e)),
            n.renderer)
          ) {
            let i = this.defaults.renderer || new gt(this.defaults);
            for (let l in n.renderer) {
              if (!(l in i)) throw new Error(`renderer '${l}' does not exist`);
              if (["options", "parser"].includes(l)) continue;
              let o = l,
                a = n.renderer[o],
                u = i[o];
              i[o] = (...p) => {
                let d = a.apply(i, p);
                return (d === !1 && (d = u.apply(i, p)), d || "");
              };
            }
            r.renderer = i;
          }
          if (n.tokenizer) {
            let i = this.defaults.tokenizer || new ht(this.defaults);
            for (let l in n.tokenizer) {
              if (!(l in i)) throw new Error(`tokenizer '${l}' does not exist`);
              if (["options", "rules", "lexer"].includes(l)) continue;
              let o = l,
                a = n.tokenizer[o],
                u = i[o];
              i[o] = (...p) => {
                let d = a.apply(i, p);
                return (d === !1 && (d = u.apply(i, p)), d);
              };
            }
            r.tokenizer = i;
          }
          if (n.hooks) {
            let i = this.defaults.hooks || new Ge();
            for (let l in n.hooks) {
              if (!(l in i)) throw new Error(`hook '${l}' does not exist`);
              if (["options", "block"].includes(l)) continue;
              let o = l,
                a = n.hooks[o],
                u = i[o];
              Ge.passThroughHooks.has(l)
                ? (i[o] = (p) => {
                    if (
                      this.defaults.async &&
                      Ge.passThroughHooksRespectAsync.has(l)
                    )
                      return (async () => {
                        let m = await a.call(i, p);
                        return u.call(i, m);
                      })();
                    let d = a.call(i, p);
                    return u.call(i, d);
                  })
                : (i[o] = (...p) => {
                    if (this.defaults.async)
                      return (async () => {
                        let m = await a.apply(i, p);
                        return (m === !1 && (m = await u.apply(i, p)), m);
                      })();
                    let d = a.apply(i, p);
                    return (d === !1 && (d = u.apply(i, p)), d);
                  });
            }
            r.hooks = i;
          }
          if (n.walkTokens) {
            let i = this.defaults.walkTokens,
              l = n.walkTokens;
            r.walkTokens = function (o) {
              let a = [];
              return (
                a.push(l.call(this, o)),
                i && (a = a.concat(i.call(this, o))),
                a
              );
            };
          }
          this.defaults = { ...this.defaults, ...r };
        }),
        this
      );
    }
    setOptions(t) {
      return ((this.defaults = { ...this.defaults, ...t }), this);
    }
    lexer(t, e) {
      return V.lex(t, e ?? this.defaults);
    }
    parser(t, e) {
      return X.parse(t, e ?? this.defaults);
    }
    parseMarkdown(t) {
      return (e, n) => {
        let r = { ...n },
          i = { ...this.defaults, ...r },
          l = this.onError(!!i.silent, !!i.async);
        if (this.defaults.async === !0 && r.async === !1)
          return l(
            new Error(
              "marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise.",
            ),
          );
        if (typeof e > "u" || e === null)
          return l(new Error("marked(): input parameter is undefined or null"));
        if (typeof e != "string")
          return l(
            new Error(
              "marked(): input parameter is of type " +
                Object.prototype.toString.call(e) +
                ", string expected",
            ),
          );
        if ((i.hooks && ((i.hooks.options = i), (i.hooks.block = t)), i.async))
          return (async () => {
            let o = i.hooks ? await i.hooks.preprocess(e) : e,
              a = await (
                i.hooks
                  ? await i.hooks.provideLexer(t)
                  : t
                    ? V.lex
                    : V.lexInline
              )(o, i),
              u = i.hooks ? await i.hooks.processAllTokens(a) : a;
            i.walkTokens &&
              (await Promise.all(this.walkTokens(u, i.walkTokens)));
            let p = await (
              i.hooks
                ? await i.hooks.provideParser(t)
                : t
                  ? X.parse
                  : X.parseInline
            )(u, i);
            return i.hooks ? await i.hooks.postprocess(p) : p;
          })().catch(l);
        try {
          i.hooks && (e = i.hooks.preprocess(e));
          let o = (i.hooks ? i.hooks.provideLexer(t) : t ? V.lex : V.lexInline)(
            e,
            i,
          );
          (i.hooks && (o = i.hooks.processAllTokens(o)),
            i.walkTokens && this.walkTokens(o, i.walkTokens));
          let a = (
            i.hooks ? i.hooks.provideParser(t) : t ? X.parse : X.parseInline
          )(o, i);
          return (i.hooks && (a = i.hooks.postprocess(a)), a);
        } catch (o) {
          return l(o);
        }
      };
    }
    onError(t, e) {
      return (n) => {
        if (
          ((n.message += `
Please report this to https://github.com/markedjs/marked.`),
          t)
        ) {
          let r =
            "<p>An error occurred:</p><pre>" + j(n.message + "", !0) + "</pre>";
          return e ? Promise.resolve(r) : r;
        }
        if (e) return Promise.reject(n);
        throw n;
      };
    }
  },
  Te = new ms();
function y(t, e) {
  return Te.parse(t, e);
}
y.options = y.setOptions = function (t) {
  return (Te.setOptions(t), (y.defaults = Te.defaults), kr(y.defaults), y);
};
y.getDefaults = Vt;
y.defaults = xe;
function ks(...t) {
  return (Te.use(...t), (y.defaults = Te.defaults), kr(y.defaults), y);
}
y.use = ks;
y.walkTokens = function (t, e) {
  return Te.walkTokens(t, e);
};
y.parseInline = Te.parseInline;
y.Parser = X;
y.parser = X.parse;
y.Renderer = gt;
y.TextRenderer = nn;
y.Lexer = V;
y.lexer = V.lex;
y.Tokenizer = ht;
y.Hooks = Ge;
y.parse = y;
y.options;
y.setOptions;
y.walkTokens;
y.parseInline;
X.parse;
V.lex;
function Jn(t, e) {
  (e == null || e > t.length) && (e = t.length);
  for (var n = 0, r = Array(e); n < e; n++) r[n] = t[n];
  return r;
}
function bs(t) {
  if (Array.isArray(t)) return t;
}
function Ts(t, e) {
  var n =
    t == null
      ? null
      : (typeof Symbol < "u" && t[Symbol.iterator]) || t["@@iterator"];
  if (n != null) {
    var r,
      i,
      l,
      o,
      a = [],
      u = !0,
      p = !1;
    try {
      if (((l = (n = n.call(t)).next), e !== 0))
        for (
          ;
          !(u = (r = l.call(n)).done) && (a.push(r.value), a.length !== e);
          u = !0
        );
    } catch (d) {
      ((p = !0), (i = d));
    } finally {
      try {
        if (!u && n.return != null && ((o = n.return()), Object(o) !== o))
          return;
      } finally {
        if (p) throw i;
      }
    }
    return a;
  }
}
function xs() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function ws(t, e) {
  return bs(t) || Ts(t, e) || ys(t, e) || xs();
}
function ys(t, e) {
  if (t) {
    if (typeof t == "string") return Jn(t, e);
    var n = {}.toString.call(t).slice(8, -1);
    return (
      n === "Object" && t.constructor && (n = t.constructor.name),
      n === "Map" || n === "Set"
        ? Array.from(t)
        : n === "Arguments" ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
          ? Jn(t, e)
          : void 0
    );
  }
}
const Er = Object.entries,
  er = Object.setPrototypeOf,
  As = Object.isFrozen,
  Ss = Object.getPrototypeOf,
  _s = Object.getOwnPropertyDescriptor;
let P = Object.freeze,
  D = Object.seal,
  Ce = Object.create,
  Rr = typeof Reflect < "u" && Reflect,
  qt = Rr.apply,
  Yt = Rr.construct;
P ||
  (P = function (e) {
    return e;
  });
D ||
  (D = function (e) {
    return e;
  });
qt ||
  (qt = function (e, n) {
    for (
      var r = arguments.length, i = new Array(r > 2 ? r - 2 : 0), l = 2;
      l < r;
      l++
    )
      i[l - 2] = arguments[l];
    return e.apply(n, i);
  });
Yt ||
  (Yt = function (e) {
    for (
      var n = arguments.length, r = new Array(n > 1 ? n - 1 : 0), i = 1;
      i < n;
      i++
    )
      r[i - 1] = arguments[i];
    return new e(...r);
  });
const ke = C(Array.prototype.forEach),
  Es = C(Array.prototype.lastIndexOf),
  tr = C(Array.prototype.pop),
  Ue = C(Array.prototype.push),
  Rs = C(Array.prototype.splice),
  Pe = Array.isArray,
  je = C(String.prototype.toLowerCase),
  Dt = C(String.prototype.toString),
  nr = C(String.prototype.match),
  He = C(String.prototype.replace),
  rr = C(String.prototype.indexOf),
  vs = C(String.prototype.trim),
  Os = C(Number.prototype.toString),
  Ls = C(Boolean.prototype.toString),
  ir = typeof BigInt > "u" ? null : C(BigInt.prototype.toString),
  sr = typeof Symbol > "u" ? null : C(Symbol.prototype.toString),
  U = C(Object.prototype.hasOwnProperty),
  We = C(Object.prototype.toString),
  z = C(RegExp.prototype.test),
  pe = Ns(TypeError);
function C(t) {
  return function (e) {
    e instanceof RegExp && (e.lastIndex = 0);
    for (
      var n = arguments.length, r = new Array(n > 1 ? n - 1 : 0), i = 1;
      i < n;
      i++
    )
      r[i - 1] = arguments[i];
    return qt(t, e, r);
  };
}
function Ns(t) {
  return function () {
    for (var e = arguments.length, n = new Array(e), r = 0; r < e; r++)
      n[r] = arguments[r];
    return Yt(t, n);
  };
}
function w(t, e) {
  let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : je;
  if ((er && er(t, null), !Pe(e))) return t;
  let r = e.length;
  for (; r--;) {
    let i = e[r];
    if (typeof i == "string") {
      const l = n(i);
      l !== i && (As(e) || (e[r] = l), (i = l));
    }
    t[i] = !0;
  }
  return t;
}
function Cs(t) {
  for (let e = 0; e < t.length; e++) U(t, e) || (t[e] = null);
  return t;
}
function q(t) {
  const e = Ce(null);
  for (const r of Er(t)) {
    var n = ws(r, 2);
    const i = n[0],
      l = n[1];
    U(t, i) &&
      (Pe(l)
        ? (e[i] = Cs(l))
        : l && typeof l == "object" && l.constructor === Object
          ? (e[i] = q(l))
          : (e[i] = l));
  }
  return e;
}
function Ps(t) {
  switch (typeof t) {
    case "string":
      return t;
    case "number":
      return Os(t);
    case "boolean":
      return Ls(t);
    case "bigint":
      return ir ? ir(t) : "0";
    case "symbol":
      return sr ? sr(t) : "Symbol()";
    case "undefined":
      return We(t);
    case "function":
    case "object": {
      if (t === null) return We(t);
      const e = t,
        n = Z(e, "toString");
      if (typeof n == "function") {
        const r = n(e);
        return typeof r == "string" ? r : We(r);
      }
      return We(t);
    }
    default:
      return We(t);
  }
}
function Z(t, e) {
  for (; t !== null;) {
    const r = _s(t, e);
    if (r) {
      if (r.get) return C(r.get);
      if (typeof r.value == "function") return C(r.value);
    }
    t = Ss(t);
  }
  function n() {
    return null;
  }
  return n;
}
function Ds(t) {
  try {
    return (z(t, ""), !0);
  } catch {
    return !1;
  }
}
const lr = P([
    "a",
    "abbr",
    "acronym",
    "address",
    "area",
    "article",
    "aside",
    "audio",
    "b",
    "bdi",
    "bdo",
    "big",
    "blink",
    "blockquote",
    "body",
    "br",
    "button",
    "canvas",
    "caption",
    "center",
    "cite",
    "code",
    "col",
    "colgroup",
    "content",
    "data",
    "datalist",
    "dd",
    "decorator",
    "del",
    "details",
    "dfn",
    "dialog",
    "dir",
    "div",
    "dl",
    "dt",
    "element",
    "em",
    "fieldset",
    "figcaption",
    "figure",
    "font",
    "footer",
    "form",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "head",
    "header",
    "hgroup",
    "hr",
    "html",
    "i",
    "img",
    "input",
    "ins",
    "kbd",
    "label",
    "legend",
    "li",
    "main",
    "map",
    "mark",
    "marquee",
    "menu",
    "menuitem",
    "meter",
    "nav",
    "nobr",
    "ol",
    "optgroup",
    "option",
    "output",
    "p",
    "picture",
    "pre",
    "progress",
    "q",
    "rp",
    "rt",
    "ruby",
    "s",
    "samp",
    "search",
    "section",
    "select",
    "shadow",
    "slot",
    "small",
    "source",
    "spacer",
    "span",
    "strike",
    "strong",
    "style",
    "sub",
    "summary",
    "sup",
    "table",
    "tbody",
    "td",
    "template",
    "textarea",
    "tfoot",
    "th",
    "thead",
    "time",
    "tr",
    "track",
    "tt",
    "u",
    "ul",
    "var",
    "video",
    "wbr",
  ]),
  It = P([
    "svg",
    "a",
    "altglyph",
    "altglyphdef",
    "altglyphitem",
    "animatecolor",
    "animatemotion",
    "animatetransform",
    "circle",
    "clippath",
    "defs",
    "desc",
    "ellipse",
    "enterkeyhint",
    "exportparts",
    "filter",
    "font",
    "g",
    "glyph",
    "glyphref",
    "hkern",
    "image",
    "inputmode",
    "line",
    "lineargradient",
    "marker",
    "mask",
    "metadata",
    "mpath",
    "part",
    "path",
    "pattern",
    "polygon",
    "polyline",
    "radialgradient",
    "rect",
    "stop",
    "style",
    "switch",
    "symbol",
    "text",
    "textpath",
    "title",
    "tref",
    "tspan",
    "view",
    "vkern",
  ]),
  Mt = P([
    "feBlend",
    "feColorMatrix",
    "feComponentTransfer",
    "feComposite",
    "feConvolveMatrix",
    "feDiffuseLighting",
    "feDisplacementMap",
    "feDistantLight",
    "feDropShadow",
    "feFlood",
    "feFuncA",
    "feFuncB",
    "feFuncG",
    "feFuncR",
    "feGaussianBlur",
    "feImage",
    "feMerge",
    "feMergeNode",
    "feMorphology",
    "feOffset",
    "fePointLight",
    "feSpecularLighting",
    "feSpotLight",
    "feTile",
    "feTurbulence",
  ]),
  Is = P([
    "animate",
    "color-profile",
    "cursor",
    "discard",
    "font-face",
    "font-face-format",
    "font-face-name",
    "font-face-src",
    "font-face-uri",
    "foreignobject",
    "hatch",
    "hatchpath",
    "mesh",
    "meshgradient",
    "meshpatch",
    "meshrow",
    "missing-glyph",
    "script",
    "set",
    "solidcolor",
    "unknown",
    "use",
  ]),
  $t = P([
    "math",
    "menclose",
    "merror",
    "mfenced",
    "mfrac",
    "mglyph",
    "mi",
    "mlabeledtr",
    "mmultiscripts",
    "mn",
    "mo",
    "mover",
    "mpadded",
    "mphantom",
    "mroot",
    "mrow",
    "ms",
    "mspace",
    "msqrt",
    "mstyle",
    "msub",
    "msup",
    "msubsup",
    "mtable",
    "mtd",
    "mtext",
    "mtr",
    "munder",
    "munderover",
    "mprescripts",
  ]),
  Ms = P([
    "maction",
    "maligngroup",
    "malignmark",
    "mlongdiv",
    "mscarries",
    "mscarry",
    "msgroup",
    "mstack",
    "msline",
    "msrow",
    "semantics",
    "annotation",
    "annotation-xml",
    "mprescripts",
    "none",
  ]),
  ar = P(["#text"]),
  or = P([
    "accept",
    "action",
    "align",
    "alt",
    "autocapitalize",
    "autocomplete",
    "autopictureinpicture",
    "autoplay",
    "background",
    "bgcolor",
    "border",
    "capture",
    "cellpadding",
    "cellspacing",
    "checked",
    "cite",
    "class",
    "clear",
    "color",
    "cols",
    "colspan",
    "command",
    "commandfor",
    "controls",
    "controlslist",
    "coords",
    "crossorigin",
    "datetime",
    "decoding",
    "default",
    "dir",
    "disabled",
    "disablepictureinpicture",
    "disableremoteplayback",
    "download",
    "draggable",
    "enctype",
    "enterkeyhint",
    "exportparts",
    "face",
    "for",
    "headers",
    "height",
    "hidden",
    "high",
    "href",
    "hreflang",
    "id",
    "inert",
    "inputmode",
    "integrity",
    "ismap",
    "kind",
    "label",
    "lang",
    "list",
    "loading",
    "loop",
    "low",
    "max",
    "maxlength",
    "media",
    "method",
    "min",
    "minlength",
    "multiple",
    "muted",
    "name",
    "nonce",
    "noshade",
    "novalidate",
    "nowrap",
    "open",
    "optimum",
    "part",
    "pattern",
    "placeholder",
    "playsinline",
    "popover",
    "popovertarget",
    "popovertargetaction",
    "poster",
    "preload",
    "pubdate",
    "radiogroup",
    "readonly",
    "rel",
    "required",
    "rev",
    "reversed",
    "role",
    "rows",
    "rowspan",
    "spellcheck",
    "scope",
    "selected",
    "shape",
    "size",
    "sizes",
    "slot",
    "span",
    "srclang",
    "start",
    "src",
    "srcset",
    "step",
    "style",
    "summary",
    "tabindex",
    "title",
    "translate",
    "type",
    "usemap",
    "valign",
    "value",
    "width",
    "wrap",
    "xmlns",
  ]),
  zt = P([
    "accent-height",
    "accumulate",
    "additive",
    "alignment-baseline",
    "amplitude",
    "ascent",
    "attributename",
    "attributetype",
    "azimuth",
    "basefrequency",
    "baseline-shift",
    "begin",
    "bias",
    "by",
    "class",
    "clip",
    "clippathunits",
    "clip-path",
    "clip-rule",
    "color",
    "color-interpolation",
    "color-interpolation-filters",
    "color-profile",
    "color-rendering",
    "cx",
    "cy",
    "d",
    "dx",
    "dy",
    "diffuseconstant",
    "direction",
    "display",
    "divisor",
    "dominant-baseline",
    "dur",
    "edgemode",
    "elevation",
    "end",
    "exponent",
    "fill",
    "fill-opacity",
    "fill-rule",
    "filter",
    "filterunits",
    "flood-color",
    "flood-opacity",
    "font-family",
    "font-size",
    "font-size-adjust",
    "font-stretch",
    "font-style",
    "font-variant",
    "font-weight",
    "fx",
    "fy",
    "g1",
    "g2",
    "glyph-name",
    "glyphref",
    "gradientunits",
    "gradienttransform",
    "height",
    "href",
    "id",
    "image-rendering",
    "in",
    "in2",
    "intercept",
    "k",
    "k1",
    "k2",
    "k3",
    "k4",
    "kerning",
    "keypoints",
    "keysplines",
    "keytimes",
    "lang",
    "lengthadjust",
    "letter-spacing",
    "kernelmatrix",
    "kernelunitlength",
    "lighting-color",
    "local",
    "marker-end",
    "marker-mid",
    "marker-start",
    "markerheight",
    "markerunits",
    "markerwidth",
    "maskcontentunits",
    "maskunits",
    "max",
    "mask",
    "mask-type",
    "media",
    "method",
    "mode",
    "min",
    "name",
    "numoctaves",
    "offset",
    "operator",
    "opacity",
    "order",
    "orient",
    "orientation",
    "origin",
    "overflow",
    "paint-order",
    "path",
    "pathlength",
    "patterncontentunits",
    "patterntransform",
    "patternunits",
    "pointer-events",
    "points",
    "preservealpha",
    "preserveaspectratio",
    "primitiveunits",
    "r",
    "rx",
    "ry",
    "radius",
    "refx",
    "refy",
    "repeatcount",
    "repeatdur",
    "restart",
    "result",
    "rotate",
    "scale",
    "seed",
    "shape-rendering",
    "slope",
    "specularconstant",
    "specularexponent",
    "spreadmethod",
    "startoffset",
    "stddeviation",
    "stitchtiles",
    "stop-color",
    "stop-opacity",
    "stroke-dasharray",
    "stroke-dashoffset",
    "stroke-linecap",
    "stroke-linejoin",
    "stroke-miterlimit",
    "stroke-opacity",
    "stroke",
    "stroke-width",
    "style",
    "surfacescale",
    "systemlanguage",
    "tabindex",
    "tablevalues",
    "targetx",
    "targety",
    "transform",
    "transform-origin",
    "text-anchor",
    "text-decoration",
    "text-orientation",
    "text-rendering",
    "textlength",
    "type",
    "u1",
    "u2",
    "unicode",
    "values",
    "vector-effect",
    "viewbox",
    "visibility",
    "version",
    "vert-adv-y",
    "vert-origin-x",
    "vert-origin-y",
    "width",
    "word-spacing",
    "wrap",
    "writing-mode",
    "xchannelselector",
    "ychannelselector",
    "x",
    "x1",
    "x2",
    "xmlns",
    "y",
    "y1",
    "y2",
    "z",
    "zoomandpan",
  ]),
  cr = P([
    "accent",
    "accentunder",
    "align",
    "bevelled",
    "close",
    "columnalign",
    "columnlines",
    "columnspacing",
    "columnspan",
    "denomalign",
    "depth",
    "dir",
    "display",
    "displaystyle",
    "encoding",
    "fence",
    "frame",
    "height",
    "href",
    "id",
    "largeop",
    "length",
    "linethickness",
    "lquote",
    "lspace",
    "mathbackground",
    "mathcolor",
    "mathsize",
    "mathvariant",
    "maxsize",
    "minsize",
    "movablelimits",
    "notation",
    "numalign",
    "open",
    "rowalign",
    "rowlines",
    "rowspacing",
    "rowspan",
    "rspace",
    "rquote",
    "scriptlevel",
    "scriptminsize",
    "scriptsizemultiplier",
    "selection",
    "separator",
    "separators",
    "stretchy",
    "subscriptshift",
    "supscriptshift",
    "symmetric",
    "voffset",
    "width",
    "xmlns",
  ]),
  ct = P(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]),
  $s = D(/{{[\w\W]*|^[\w\W]*}}/g),
  zs = D(/<%[\w\W]*|^[\w\W]*%>/g),
  Bs = D(/\${[\w\W]*/g),
  Fs = D(/^data-[\-\w.\u00B7-\uFFFF]+$/),
  Us = D(/^aria-[\-\w]+$/),
  ur = D(
    /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i,
  ),
  Hs = D(/^(?:\w+script|data):/i),
  Ws = D(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g),
  Gs = D(/^html$/i),
  js = D(/^[a-z][.\w]*(-[.\w]+)+$/i),
  pr = D(/<[/\w!]/g),
  fr = D(/<[/\w]/g),
  qs = D(/<\/no(script|embed|frames)/i),
  Ys = D(/\/>/i),
  G = {
    element: 1,
    attribute: 2,
    text: 3,
    cdataSection: 4,
    entityReference: 5,
    entityNode: 6,
    processingInstruction: 7,
    comment: 8,
    document: 9,
    documentType: 10,
    documentFragment: 11,
    notation: 12,
  },
  vr = [
    "style",
    "script",
    "xmp",
    "iframe",
    "noembed",
    "noframes",
    "plaintext",
    "noscript",
  ],
  Zs = P(w({}, vr)),
  Vs = (function () {
    const t = {};
    return (
      ke(vr, (e) => {
        t[e] = D(new RegExp("</" + e + "(?=[\\t\\n\\f\\r />])", "i"));
      }),
      P(t)
    );
  })(),
  Xs = function () {
    return typeof window > "u" ? null : window;
  },
  Qs = function (e, n) {
    if (typeof e != "object" || typeof e.createPolicy != "function")
      return null;
    let r = null;
    const i = "data-tt-policy-suffix";
    n && n.hasAttribute(i) && (r = n.getAttribute(i));
    const l = "dompurify" + (r ? "#" + r : "");
    try {
      return e.createPolicy(l, {
        createHTML(o) {
          return o;
        },
        createScriptURL(o) {
          return o;
        },
      });
    } catch {
      return (
        console.warn("TrustedTypes policy " + l + " could not be created."),
        null
      );
    }
  },
  hr = function () {
    return {
      afterSanitizeAttributes: [],
      afterSanitizeElements: [],
      afterSanitizeShadowDOM: [],
      beforeSanitizeAttributes: [],
      beforeSanitizeElements: [],
      beforeSanitizeShadowDOM: [],
      uponSanitizeAttribute: [],
      uponSanitizeElement: [],
      uponSanitizeShadowNode: [],
    };
  },
  fe = function (e, n, r, i) {
    return U(e, n) && Pe(e[n])
      ? w(i.base ? q(i.base) : {}, e[n], i.transform)
      : r;
  },
  Bt = function (e, n, r) {
    const i = U(e, n) ? e[n] : void 0;
    return i && typeof i == "object" ? q(i) : r();
  };
function Or() {
  let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : Xs();
  const e = (h) => Or(h);
  if (
    ((e.version = "3.4.16"),
    (e.removed = []),
    !t || !t.document || t.document.nodeType !== G.document || !t.Element)
  )
    return ((e.isSupported = !1), e);
  let n = t.document;
  const r = n,
    i = r.currentScript;
  t.DocumentFragment;
  const l = t.HTMLTemplateElement,
    o = t.Node,
    a = t.Element,
    u = t.NodeFilter;
  (t.NamedNodeMap === void 0 && (t.NamedNodeMap || t.MozNamedAttrMap),
    t.HTMLFormElement);
  const p = t.DOMParser,
    d = t.trustedTypes,
    m = a.prototype,
    L = Z(m, "cloneNode"),
    _ = Z(m, "remove"),
    A = Z(m, "removeAttributeNode"),
    M = Z(m, "nextSibling"),
    S = Z(m, "childNodes"),
    H = Z(m, "parentNode"),
    se = Z(m, "shadowRoot"),
    te = Z(m, "attributes"),
    Q = o && o.prototype ? Z(o.prototype, "nodeType") : null,
    le = o && o.prototype ? Z(o.prototype, "nodeName") : null,
    we = o && o.prototype ? Z(o.prototype, "ownerDocument") : null,
    ne = function (s) {
      return Q ? Q(s) : s.nodeType;
    },
    re = function (s) {
      return le ? le(s) : s.nodeName;
    };
  if (typeof l == "function") {
    const h = n.createElement("template");
    h.content && h.content.ownerDocument && (n = h.content.ownerDocument);
  }
  let $,
    he = "",
    kt,
    un = !1,
    Me = 0;
  const pn = function () {
      if (Me > 0)
        throw pe(
          'A configured TRUSTED_TYPES_POLICY callback (createHTML or createScriptURL) must not call DOMPurify.sanitize, as that causes infinite recursion. Do not pass a policy whose callbacks wrap DOMPurify as TRUSTED_TYPES_POLICY; see the "DOMPurify and Trusted Types" section of the README.',
        );
    },
    ye = function (s) {
      (pn(), Me++);
      try {
        return $.createHTML(s);
      } finally {
        Me--;
      }
    },
    Wr = function (s) {
      (pn(), Me++);
      try {
        return $.createScriptURL(s);
      } finally {
        Me--;
      }
    },
    Gr = function () {
      return (un || ((kt = Qs(d, i)), (un = !0)), kt);
    },
    Ve = n,
    bt = Ve.implementation,
    fn = Ve.createNodeIterator,
    jr = Ve.createDocumentFragment,
    qr = Ve.getElementsByTagName,
    Yr = r.importNode;
  let E = hr();
  e.isSupported =
    typeof Er == "function" &&
    typeof H == "function" &&
    bt &&
    bt.createHTMLDocument !== void 0;
  const Zr = $s,
    Vr = zs,
    Xr = Bs,
    Qr = Fs,
    Kr = Us,
    Jr = Hs,
    hn = Ws,
    ei = js;
  let gn = ur,
    R = null;
  const Tt = w({}, [...lr, ...It, ...Mt, ...$t, ...ar]);
  let v = null;
  const xt = w({}, [...or, ...zt, ...cr, ...ct]);
  let K = Object.seal(
      Ce(null, {
        tagNameCheck: {
          writable: !0,
          configurable: !1,
          enumerable: !0,
          value: null,
        },
        attributeNameCheck: {
          writable: !0,
          configurable: !1,
          enumerable: !0,
          value: null,
        },
        allowCustomizedBuiltInElements: {
          writable: !0,
          configurable: !1,
          enumerable: !0,
          value: !1,
        },
      }),
    ),
    $e = null,
    dn = null;
  const ae = Object.seal(
    Ce(null, {
      tagCheck: { writable: !0, configurable: !1, enumerable: !0, value: null },
      attributeCheck: {
        writable: !0,
        configurable: !1,
        enumerable: !0,
        value: null,
      },
    }),
  );
  let mn = !0,
    wt = !0,
    kn = !1,
    bn = !0,
    oe = !1,
    ge = !0,
    de = !1,
    yt = !1,
    Xe = null,
    Qe = null,
    At = !1,
    Ae = !1,
    Ke = !1,
    Je = !1,
    Tn = !0,
    xn = !1;
  const wn = "user-content-";
  let St = !0,
    _t = !1,
    Se = {},
    _e = null;
  const yn = w({}, [
    "annotation-xml",
    "audio",
    "colgroup",
    "desc",
    "foreignobject",
    "head",
    "iframe",
    "math",
    "mi",
    "mn",
    "mo",
    "ms",
    "mtext",
    "noembed",
    "noframes",
    "noscript",
    "plaintext",
    "script",
    "selectedcontent",
    "style",
    "svg",
    "template",
    "thead",
    "title",
    "video",
    "xmp",
  ]);
  let An = null;
  const Sn = w({}, ["audio", "video", "img", "source", "image", "track"]);
  let _n = null;
  const En = w({}, [
      "alt",
      "class",
      "for",
      "id",
      "label",
      "name",
      "pattern",
      "placeholder",
      "role",
      "summary",
      "title",
      "value",
      "style",
      "xmlns",
    ]),
    et = "http://www.w3.org/1998/Math/MathML",
    tt = "http://www.w3.org/2000/svg",
    J = "http://www.w3.org/1999/xhtml";
  let Ee = J,
    Et = !1,
    Rt = null;
  const ti = w({}, [et, tt, J], Dt),
    Rn = P(["mi", "mo", "mn", "ms", "mtext"]);
  let vt = w({}, Rn);
  const vn = P(["annotation-xml"]);
  let Ot = w({}, vn);
  const ni = w({}, ["title", "style", "font", "a", "script"]);
  let ze = null;
  const ri = ["application/xhtml+xml", "text/html"],
    ii = "text/html";
  let N = null,
    Re = null;
  const si = n.createElement("form"),
    On = function (s) {
      return s instanceof RegExp || s instanceof Function;
    },
    Lt = function () {
      let s =
        arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      if (Re && Re === s) return;
      ((!s || typeof s != "object") && (s = {}),
        (s = q(s)),
        (ze =
          ri.indexOf(s.PARSER_MEDIA_TYPE) === -1 ? ii : s.PARSER_MEDIA_TYPE),
        (N = ze === "application/xhtml+xml" ? Dt : je),
        (R = fe(s, "ALLOWED_TAGS", Tt, { transform: N })),
        (v = fe(s, "ALLOWED_ATTR", xt, { transform: N })),
        (Rt = fe(s, "ALLOWED_NAMESPACES", ti, { transform: Dt })),
        (_n = fe(s, "ADD_URI_SAFE_ATTR", En, { transform: N, base: En })),
        (An = fe(s, "ADD_DATA_URI_TAGS", Sn, { transform: N, base: Sn })),
        (_e = fe(s, "FORBID_CONTENTS", yn, { transform: N })),
        ($e = fe(s, "FORBID_TAGS", q({}), { transform: N })),
        (dn = fe(s, "FORBID_ATTR", q({}), { transform: N })),
        (Se = U(s, "USE_PROFILES")
          ? s.USE_PROFILES && typeof s.USE_PROFILES == "object"
            ? q(s.USE_PROFILES)
            : s.USE_PROFILES
          : !1),
        (mn = s.ALLOW_ARIA_ATTR !== !1),
        (wt = s.ALLOW_DATA_ATTR !== !1),
        (kn = s.ALLOW_UNKNOWN_PROTOCOLS || !1),
        (bn = s.ALLOW_SELF_CLOSE_IN_ATTR !== !1),
        (oe = s.SAFE_FOR_TEMPLATES || !1),
        (ge = s.SAFE_FOR_XML !== !1),
        (de = s.WHOLE_DOCUMENT || !1),
        (Ae = s.RETURN_DOM || !1),
        (Ke = s.RETURN_DOM_FRAGMENT || !1),
        (Je = s.RETURN_TRUSTED_TYPE || !1),
        (At = s.FORCE_BODY || !1),
        (Tn = s.SANITIZE_DOM !== !1),
        (xn = s.SANITIZE_NAMED_PROPS || !1),
        (St = s.KEEP_CONTENT !== !1),
        (_t = s.IN_PLACE || !1),
        (gn = Ds(s.ALLOWED_URI_REGEXP) ? s.ALLOWED_URI_REGEXP : ur),
        (Ee = typeof s.NAMESPACE == "string" ? s.NAMESPACE : J),
        (vt = Bt(s, "MATHML_TEXT_INTEGRATION_POINTS", () => w({}, Rn))),
        (Ot = Bt(s, "HTML_INTEGRATION_POINTS", () => w({}, vn))));
      const c = Bt(s, "CUSTOM_ELEMENT_HANDLING", () => Ce(null));
      if (
        ((K = Ce(null)),
        U(c, "tagNameCheck") &&
          On(c.tagNameCheck) &&
          (K.tagNameCheck = c.tagNameCheck),
        U(c, "attributeNameCheck") &&
          On(c.attributeNameCheck) &&
          (K.attributeNameCheck = c.attributeNameCheck),
        U(c, "allowCustomizedBuiltInElements") &&
          typeof c.allowCustomizedBuiltInElements == "boolean" &&
          (K.allowCustomizedBuiltInElements = c.allowCustomizedBuiltInElements),
        D(K),
        oe && (wt = !1),
        Ke && (Ae = !0),
        Se &&
          ((R = w({}, ar)),
          (v = Ce(null)),
          Se.html === !0 && (w(R, lr), w(v, or)),
          Se.svg === !0 && (w(R, It), w(v, zt), w(v, ct)),
          Se.svgFilters === !0 && (w(R, Mt), w(v, zt), w(v, ct)),
          Se.mathMl === !0 && (w(R, $t), w(v, cr), w(v, ct))),
        (ae.tagCheck = null),
        (ae.attributeCheck = null),
        U(s, "ADD_TAGS") &&
          (typeof s.ADD_TAGS == "function"
            ? (ae.tagCheck = s.ADD_TAGS)
            : Pe(s.ADD_TAGS) && (R === Tt && (R = q(R)), w(R, s.ADD_TAGS, N))),
        U(s, "ADD_ATTR") &&
          (typeof s.ADD_ATTR == "function"
            ? (ae.attributeCheck = s.ADD_ATTR)
            : Pe(s.ADD_ATTR) && (v === xt && (v = q(v)), w(v, s.ADD_ATTR, N))),
        U(s, "ADD_FORBID_CONTENTS") &&
          Pe(s.ADD_FORBID_CONTENTS) &&
          (_e === yn && (_e = q(_e)), w(_e, s.ADD_FORBID_CONTENTS, N)),
        St && (R["#text"] = !0),
        de && w(R, ["html", "head", "body"]),
        R.table && (w(R, ["tbody"]), delete $e.tbody),
        s.TRUSTED_TYPES_POLICY)
      ) {
        if (typeof s.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw pe(
            'TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.',
          );
        if (typeof s.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw pe(
            'TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.',
          );
        const f = $;
        $ = s.TRUSTED_TYPES_POLICY;
        try {
          he = ye("");
        } catch (g) {
          throw (($ = f), g);
        }
      } else
        s.TRUSTED_TYPES_POLICY === null
          ? (($ = void 0), (he = ""))
          : ($ === void 0 && ($ = Gr()),
            $ && typeof he == "string" && (he = ye("")));
      (P && P(s), (Re = s));
    },
    Ln = w({}, [...It, ...Mt, ...Is]),
    Nn = w({}, [...$t, ...Ms]),
    li = function (s, c, f) {
      return c.namespaceURI === J
        ? s === "svg"
        : c.namespaceURI === et
          ? s === "svg" && (f === "annotation-xml" || vt[f])
          : !!Ln[s];
    },
    ai = function (s, c, f) {
      return c.namespaceURI === J
        ? s === "math"
        : c.namespaceURI === tt
          ? s === "math" && Ot[f]
          : !!Nn[s];
    },
    oi = function (s, c, f) {
      return (c.namespaceURI === tt && !Ot[f]) ||
        (c.namespaceURI === et && !vt[f])
        ? !1
        : !Nn[s] && (ni[s] || !Ln[s]);
    },
    ci = function (s) {
      let c = H(s);
      (!c || !c.tagName) && (c = { namespaceURI: Ee, tagName: "template" });
      const f = je(s.tagName),
        g = je(c.tagName);
      return Rt[s.namespaceURI]
        ? s.namespaceURI === tt
          ? li(f, c, g)
          : s.namespaceURI === et
            ? ai(f, c, g)
            : s.namespaceURI === J
              ? oi(f, c, g)
              : !!(ze === "application/xhtml+xml" && Rt[s.namespaceURI])
        : !1;
    },
    ce = function (s) {
      Ue(e.removed, { element: s });
      try {
        H(s).removeChild(s);
      } catch {
        if ((_(s), !H(s)))
          throw pe(
            "a node selected for removal could not be detached from its tree and cannot be safely returned; refusing to sanitize in place",
          );
      }
    },
    Cn = function (s, c, f) {
      try {
        A(s, c);
      } catch {
        try {
          s.removeAttribute(f);
        } catch {}
      }
    },
    nt = function (s) {
      rt(s);
      const c = S(s);
      if (c) {
        const g = [];
        (ke(c, (k) => {
          Ue(g, k);
        }),
          ke(g, (k) => {
            try {
              _(k);
            } catch {}
          }));
      }
      const f = te(s);
      if (f)
        for (let g = f.length - 1; g >= 0; --g) {
          const k = f[g],
            T = k && k.name;
          typeof T == "string" && Cn(s, k, T);
        }
    },
    me = function (s, c, f) {
      if (!f)
        try {
          f = c.getAttributeNode(s);
        } catch {
          f = null;
        }
      Ue(e.removed, { attribute: f || null, from: c });
      try {
        f ? A(c, f) : c.removeAttribute(s);
      } catch {
        try {
          c.removeAttribute(s);
        } catch {}
      }
      if (s === "is")
        if (Ae || Ke)
          try {
            ce(c);
          } catch {}
        else
          try {
            c.setAttribute(s, "");
          } catch {}
    },
    ui = function (s) {
      const c = te(s);
      if (c)
        for (let f = c.length - 1; f >= 0; --f) {
          const g = c[f],
            k = g && g.name;
          typeof k != "string" || v[N(k)] || Cn(s, g, k);
        }
    },
    rt = function (s) {
      const c = [s];
      for (; c.length > 0;) {
        const f = c.pop();
        ne(f) === G.element && ui(f);
        const g = S(f);
        if (g) for (let k = g.length - 1; k >= 0; --k) c.push(g[k]);
      }
    },
    Pn = function (s, c) {
      return ge
        ? s === "patchsrc"
          ? !0
          : s === "for" && c !== "label" && c !== "output"
        : !1;
    },
    pi = function (s) {
      if (!ge) return;
      const c = [s];
      for (; c.length > 0;) {
        const f = c.pop(),
          g = ne(f);
        if (
          g === G.processingInstruction ||
          (g === G.comment && z(fr, f.data))
        ) {
          try {
            _(f);
          } catch {}
          continue;
        }
        if (g === G.element) {
          const T = f,
            x = N(re(f));
          try {
            (T.hasAttribute &&
              T.hasAttribute("patchsrc") &&
              T.removeAttribute("patchsrc"),
              T.hasAttribute &&
                T.hasAttribute("for") &&
                Pn("for", x) &&
                T.removeAttribute("for"));
          } catch {}
        }
        const k = S(f);
        if (k) for (let T = k.length - 1; T >= 0; --T) c.push(k[T]);
      }
    },
    Dn = function (s) {
      let c = null,
        f = null;
      if (At) s = "<remove></remove>" + s;
      else {
        const T = nr(s, /^[\r\n\t ]+/);
        f = T && T[0];
      }
      ze === "application/xhtml+xml" &&
        Ee === J &&
        (s =
          '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' +
          s +
          "</body></html>");
      const g = $ ? ye(s) : s;
      if (Ee === J)
        try {
          c = new p().parseFromString(g, ze);
        } catch {}
      if (!c || !c.documentElement) {
        c = bt.createDocument(Ee, "template", null);
        try {
          c.documentElement.innerHTML = Et ? he : g;
        } catch {}
      }
      const k = c.body || c.documentElement;
      return (
        s && f && k.insertBefore(n.createTextNode(f), k.childNodes[0] || null),
        Ee === J
          ? qr.call(c, de ? "html" : "body")[0]
          : de
            ? c.documentElement
            : k
      );
    },
    In = function (s) {
      const c = we ? we(s) : s.ownerDocument;
      return fn.call(
        c || s,
        s,
        u.SHOW_ELEMENT |
          u.SHOW_COMMENT |
          u.SHOW_TEXT |
          u.SHOW_PROCESSING_INSTRUCTION |
          u.SHOW_CDATA_SECTION,
        null,
      );
    },
    it = function (s) {
      return (
        (s = He(s, Zr, " ")),
        (s = He(s, Vr, " ")),
        (s = He(s, Xr, " ")),
        s
      );
    },
    Nt = function (s) {
      var c;
      s.normalize();
      const f = we ? we(s) : s.ownerDocument,
        g = fn.call(
          f || s,
          s,
          u.SHOW_TEXT |
            u.SHOW_COMMENT |
            u.SHOW_CDATA_SECTION |
            u.SHOW_PROCESSING_INSTRUCTION,
          null,
        );
      let k = g.nextNode();
      for (; k;) ((k.data = it(k.data)), (k = g.nextNode()));
      const T =
        (c = s.querySelectorAll) === null || c === void 0
          ? void 0
          : c.call(s, "template");
      T &&
        ke(T, (x) => {
          ve(x.content) && Nt(x.content);
        });
    },
    st = function (s) {
      const c = le ? le(s) : null;
      return typeof c != "string" || N(c) !== "form"
        ? !1
        : typeof s.nodeName != "string" ||
            typeof s.textContent != "string" ||
            typeof s.removeChild != "function" ||
            s.attributes !== te(s) ||
            typeof s.removeAttribute != "function" ||
            typeof s.removeAttributeNode != "function" ||
            typeof s.getAttributeNode != "function" ||
            typeof s.setAttribute != "function" ||
            typeof s.namespaceURI != "string" ||
            typeof s.insertBefore != "function" ||
            typeof s.hasChildNodes != "function" ||
            s.nodeType !== Q(s) ||
            s.childNodes !== S(s);
    },
    ve = function (s) {
      if (!Q || typeof s != "object" || s === null) return !1;
      try {
        return Q(s) === G.documentFragment;
      } catch {
        return !1;
      }
    },
    Be = function (s) {
      if (!Q || typeof s != "object" || s === null) return !1;
      try {
        return typeof Q(s) == "number";
      } catch {
        return !1;
      }
    };
  function ee(h, s, c) {
    h.length !== 0 &&
      ke(h, (f) => {
        f.call(e, s, c, Re);
      });
  }
  const fi = function (s, c) {
      return !!(
        (ge &&
          s.hasChildNodes() &&
          !Be(s.firstElementChild) &&
          z(pr, s.textContent) &&
          z(pr, s.innerHTML)) ||
        (ge &&
          s.namespaceURI === J &&
          Zs[c] &&
          (Be(s.firstElementChild) ||
            (typeof s.textContent == "string" && z(Vs[c], s.textContent)))) ||
        s.nodeType === G.processingInstruction ||
        (ge && s.nodeType === G.comment && z(fr, s.data))
      );
    },
    lt = function (s, c) {
      if (s instanceof RegExp) return z(s, c);
      if (s instanceof Function) {
        for (
          var f = arguments.length, g = new Array(f > 2 ? f - 2 : 0), k = 2;
          k < f;
          k++
        )
          g[k - 2] = arguments[k];
        return !!s(c, ...g);
      }
      return !1;
    },
    hi = function (s, c, f) {
      if (!$e[c] && Bn(c) && lt(K.tagNameCheck, c)) return !1;
      if (St && !_e[c]) {
        const g = H(s),
          k = S(s);
        if (k && g) {
          const T = k.length;
          for (let x = T - 1; x >= 0; --x) {
            const O = s === f ? L(k[x], !0) : k[x];
            g.insertBefore(O, M(s));
          }
        }
      }
      return (ce(s), !0);
    },
    Mn = function (s, c, f, g) {
      return s.length === 0 ? c : c === f || c === g ? q(c) : c;
    },
    Oe = function (s, c) {
      return s === c || H(s) !== null ? !1 : (_t && rt(s), !0);
    },
    $n = function (s, c) {
      if ((ee(E.beforeSanitizeElements, s, null), Oe(s, c))) return !0;
      if (st(s)) return (ce(s), !0);
      const f = N(re(s));
      if (
        ((R = Mn(E.uponSanitizeElement, R, Tt, Xe)),
        ee(E.uponSanitizeElement, s, { tagName: f, allowedTags: R }),
        Oe(s, c))
      )
        return !0;
      if (fi(s, f)) return (ce(s), !0);
      if (
        $e[f] ||
        (!(ae.tagCheck instanceof Function && ae.tagCheck(f)) && !R[f])
      ) {
        const g = hi(s, f, c);
        return g === !1 && (ee(E.afterSanitizeElements, s, null), Oe(s, c))
          ? !0
          : g;
      }
      if (
        (ne(s) === G.element && !ci(s)) ||
        ((f === "noscript" || f === "noembed" || f === "noframes") &&
          z(qs, s.innerHTML))
      )
        return (ce(s), !0);
      if (oe && s.nodeType === G.text) {
        const g = it(s.textContent);
        s.textContent !== g &&
          (Ue(e.removed, { element: s.cloneNode() }), (s.textContent = g));
      }
      return (ee(E.afterSanitizeElements, s, null), Oe(s, c));
    },
    zn = function (s, c, f) {
      if (
        dn[c] ||
        Pn(c, s) ||
        (Tn && (c === "id" || c === "name") && (f in n || f in si))
      )
        return !1;
      const g =
        v[c] ||
        (ae.attributeCheck instanceof Function && ae.attributeCheck(c, s));
      return (wt && z(Qr, c)) || (mn && z(Kr, c))
        ? !0
        : g
          ? _n[c] ||
            z(gn, He(f, hn, "")) ||
            ((c === "src" || c === "xlink:href" || c === "href") &&
              s !== "script" &&
              rr(f, "data:") === 0 &&
              An[s]) ||
            (kn && !z(Jr, He(f, hn, "")))
            ? !0
            : !f
          : (Bn(s) &&
              lt(K.tagNameCheck, s) &&
              lt(K.attributeNameCheck, c, s)) ||
            (c === "is" &&
              K.allowCustomizedBuiltInElements &&
              lt(K.tagNameCheck, f));
    },
    gi = w({}, [
      "annotation-xml",
      "color-profile",
      "font-face",
      "font-face-format",
      "font-face-name",
      "font-face-src",
      "font-face-uri",
      "missing-glyph",
    ]),
    Bn = function (s) {
      return !gi[je(s)] && z(ei, s);
    },
    di = function (s, c, f, g) {
      if (
        $ &&
        typeof d == "object" &&
        typeof d.getAttributeType == "function" &&
        !f
      )
        switch (d.getAttributeType(s, c)) {
          case "TrustedHTML":
            return ye(g);
          case "TrustedScriptURL":
            return Wr(g);
        }
      return g;
    },
    mi = function (s, c, f, g) {
      try {
        return (
          f ? s.setAttributeNS(f, c, g) : s.setAttribute(c, g),
          st(s) ? (ce(s), !1) : !0
        );
      } catch {
        return (me(c, s), !1);
      }
    },
    Fn = function (s, c) {
      if ((ee(E.beforeSanitizeAttributes, s, null), Oe(s, c))) return;
      const f = s.attributes;
      if (!f || st(s)) return;
      v = Mn(E.uponSanitizeAttribute, v, xt, Qe);
      const g = {
        attrName: "",
        attrValue: "",
        keepAttr: !0,
        allowedAttributes: v,
        forceKeepAttr: void 0,
      };
      let k = f.length;
      const T = N(s.nodeName);
      for (; k--;) {
        const x = f[k],
          O = x.name,
          Y = x.namespaceURI,
          W = x.value,
          Le = N(O),
          Pt = W;
        let F = O === "value" ? Pt : vs(Pt),
          Un = !1;
        if (
          ((g.attrName = Le),
          (g.attrValue = F),
          (g.keepAttr = !0),
          (g.forceKeepAttr = void 0),
          ee(E.uponSanitizeAttribute, s, g),
          (F = g.attrValue),
          xn &&
            (Le === "id" || Le === "name") &&
            rr(F, wn) !== 0 &&
            (me(O, s, x), (F = wn + F), (Un = !0)),
          ge &&
            z(
              /((--!?|])>)|<\/(style|script|title|xmp|textarea|noscript|iframe|noembed|noframes)/i,
              F,
            ))
        ) {
          me(O, s, x);
          continue;
        }
        if (Le === "attributename" && nr(F, "href")) {
          me(O, s, x);
          continue;
        }
        if (!g.forceKeepAttr) {
          if (!g.keepAttr) {
            me(O, s, x);
            continue;
          }
          if (!bn && z(Ys, F)) {
            me(O, s, x);
            continue;
          }
          if ((oe && (F = it(F)), !zn(T, Le, F))) {
            me(O, s, x);
            continue;
          }
          ((F = di(T, Le, Y, F)),
            F !== Pt && mi(s, O, Y, F) && Un && tr(e.removed));
        }
      }
      (ee(E.afterSanitizeAttributes, s, null), Oe(s, c));
    },
    at = function (s) {
      let c = null;
      const f = In(s);
      for (ee(E.beforeSanitizeShadowDOM, s, null); (c = f.nextNode());)
        if (
          (ee(E.uponSanitizeShadowNode, c, null),
          $n(c, s),
          Fn(c, s),
          ve(c.content) && at(c.content),
          ne(c) === G.element)
        ) {
          const g = se(c);
          ve(g) && (Ct(g), at(g));
        }
      ee(E.afterSanitizeShadowDOM, s, null);
    },
    Ct = function (s) {
      const c = [{ node: s, shadow: null }];
      for (; c.length > 0;) {
        const f = c.pop();
        if (f.shadow) {
          at(f.shadow);
          continue;
        }
        const g = f.node,
          k = ne(g) === G.element,
          T = S(g);
        if (T)
          for (let x = T.length - 1; x >= 0; --x)
            c.push({ node: T[x], shadow: null });
        if (k) {
          const x = le ? le(g) : null;
          if (typeof x == "string" && N(x) === "template") {
            const O = g.content;
            ve(O) && c.push({ node: O, shadow: null });
          }
        }
        if (k) {
          const x = se(g);
          ve(x) && c.push({ node: null, shadow: x }, { node: x, shadow: null });
        }
      }
    };
  return (
    (e.sanitize = function (h) {
      let s =
          arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {},
        c = null,
        f = null,
        g = null,
        k = null;
      if (
        ((Et = !h),
        Et && (h = "<!-->"),
        typeof h != "string" && !Be(h) && ((h = Ps(h)), typeof h != "string"))
      )
        throw pe("dirty is not a string, aborting");
      if (!e.isSupported) return h;
      (yt ? ((R = Xe), (v = Qe)) : Lt(s),
        (E.uponSanitizeElement.length > 0 ||
          E.uponSanitizeAttribute.length > 0) &&
          (R = q(R)),
        E.uponSanitizeAttribute.length > 0 && (v = q(v)),
        (e.removed = []));
      const T = _t && typeof h != "string" && Be(h);
      if (T) {
        pi(h);
        const Y = re(h);
        if (typeof Y == "string") {
          const W = N(Y);
          if (!R[W] || $e[W])
            throw (
              nt(h),
              pe("root node is forbidden and cannot be sanitized in-place")
            );
        }
        if (st(h))
          throw (
            nt(h),
            pe("root node is clobbered and cannot be sanitized in-place")
          );
        try {
          Ct(h);
        } catch (W) {
          throw (nt(h), W);
        }
      } else if (Be(h))
        ((c = Dn("<!---->")),
          (f = c.ownerDocument.importNode(h, !0)),
          (f.nodeType === G.element && f.nodeName === "BODY") ||
          f.nodeName === "HTML"
            ? (c = f)
            : c.appendChild(f),
          Ct(c));
      else {
        if (!Ae && !oe && !de && h.indexOf("<") === -1)
          return $ && Je ? ye(h) : h;
        if (((c = Dn(h)), !c)) return Ae ? null : Je ? he : "";
      }
      c && At && ce(c.firstChild);
      const x = T ? h : c;
      try {
        const Y = In(x);
        for (; (g = Y.nextNode());)
          ($n(g, x), Fn(g, x), ve(g.content) && at(g.content));
      } catch (Y) {
        throw (
          T &&
            (nt(h),
            ke(e.removed, (W) => {
              W.element && rt(W.element);
            })),
          Y
        );
      }
      if (T) {
        let Y = !1;
        if (
          (ke(e.removed, (W) => {
            W.element && (W.element === h && (Y = !0), rt(W.element));
          }),
          Y)
        )
          throw pe(
            "a node selected for removal could not be safely returned; refusing to sanitize in place",
          );
        return (oe && Nt(h), h);
      }
      if (Ae) {
        if ((oe && Nt(c), Ke))
          for (k = jr.call(c.ownerDocument); c.firstChild;)
            k.appendChild(c.firstChild);
        else k = c;
        return (
          (v.shadowroot || v.shadowrootmode) && (k = Yr.call(r, k, !0)),
          k
        );
      }
      let O = de ? c.outerHTML : c.innerHTML;
      return (
        de &&
          R["!doctype"] &&
          c.ownerDocument &&
          c.ownerDocument.doctype &&
          c.ownerDocument.doctype.name &&
          z(Gs, c.ownerDocument.doctype.name) &&
          (O =
            "<!DOCTYPE " +
            c.ownerDocument.doctype.name +
            `>
` +
            O),
        oe && (O = it(O)),
        $ && Je ? ye(O) : O
      );
    }),
    (e.setConfig = function () {
      let h =
        arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      (Lt(h), (yt = !0), (Xe = R), (Qe = v));
    }),
    (e.clearConfig = function () {
      ((Re = null), (yt = !1), (Xe = null), (Qe = null), ($ = kt), (he = ""));
    }),
    (e.isValidAttribute = function (h, s, c) {
      Re || Lt({});
      const f = N(h),
        g = N(s);
      return zn(f, g, c);
    }),
    (e.addHook = function (h, s) {
      typeof s == "function" && U(E, h) && Ue(E[h], s);
    }),
    (e.removeHook = function (h, s) {
      if (U(E, h)) {
        if (s !== void 0) {
          const c = Es(E[h], s);
          return c === -1 ? void 0 : Rs(E[h], c, 1)[0];
        }
        return tr(E[h]);
      }
    }),
    (e.removeHooks = function (h) {
      U(E, h) && (E[h] = []);
    }),
    (e.removeAllHooks = function () {
      E = hr();
    }),
    e
  );
}
var Lr = Or();
function Ks(t) {
  for (var e = 1; e < arguments.length; e++) {
    var n = arguments[e];
    for (var r in n)
      Object.prototype.hasOwnProperty.call(n, r) && (t[r] = n[r]);
  }
  return t;
}
function Zt(t, e) {
  return Array(e + 1).join(t);
}
function Nr(t) {
  return t.replace(/^\n*/, "");
}
function Cr(t) {
  for (
    var e = t.length;
    e > 0 &&
    t[e - 1] ===
      `
`;
  )
    e--;
  return t.substring(0, e);
}
function Pr(t) {
  return Cr(Nr(t));
}
var Js = [
  "ADDRESS",
  "ARTICLE",
  "ASIDE",
  "AUDIO",
  "BLOCKQUOTE",
  "BODY",
  "CANVAS",
  "CENTER",
  "DD",
  "DIR",
  "DIV",
  "DL",
  "DT",
  "FIELDSET",
  "FIGCAPTION",
  "FIGURE",
  "FOOTER",
  "FORM",
  "FRAMESET",
  "H1",
  "H2",
  "H3",
  "H4",
  "H5",
  "H6",
  "HEADER",
  "HGROUP",
  "HR",
  "HTML",
  "ISINDEX",
  "LI",
  "MAIN",
  "MENU",
  "NAV",
  "NOFRAMES",
  "NOSCRIPT",
  "OL",
  "OUTPUT",
  "P",
  "PRE",
  "SECTION",
  "TABLE",
  "TBODY",
  "TD",
  "TFOOT",
  "TH",
  "THEAD",
  "TR",
  "UL",
];
function rn(t) {
  return sn(t, Js);
}
var Dr = [
  "AREA",
  "BASE",
  "BR",
  "COL",
  "COMMAND",
  "EMBED",
  "HR",
  "IMG",
  "INPUT",
  "KEYGEN",
  "LINK",
  "META",
  "PARAM",
  "SOURCE",
  "TRACK",
  "WBR",
];
function Ir(t) {
  return sn(t, Dr);
}
function el(t) {
  return $r(t, Dr);
}
var Mr = [
  "A",
  "TABLE",
  "THEAD",
  "TBODY",
  "TFOOT",
  "TH",
  "TD",
  "IFRAME",
  "SCRIPT",
  "AUDIO",
  "VIDEO",
];
function tl(t) {
  return sn(t, Mr);
}
function nl(t) {
  return $r(t, Mr);
}
function sn(t, e) {
  return e.indexOf(t.nodeName) >= 0;
}
function $r(t, e) {
  return (
    t.getElementsByTagName &&
    e.some(function (n) {
      return t.getElementsByTagName(n).length;
    })
  );
}
var rl = [
  [/\\/g, "\\\\"],
  [/\*/g, "\\*"],
  [/^-/g, "\\-"],
  [/^\+ /g, "\\+ "],
  [/^(=+)/g, "\\$1"],
  [/^(#{1,6}) /g, "\\$1 "],
  [/`/g, "\\`"],
  [/^~~~/g, "\\~~~"],
  [/\[/g, "\\["],
  [/\]/g, "\\]"],
  [/^>/g, "\\>"],
  [/_/g, "\\_"],
  [/^(\d+)\. /g, "$1\\. "],
];
function zr(t) {
  return rl.reduce(function (e, n) {
    return e.replace(n[0], n[1]);
  }, t);
}
var B = {};
B.paragraph = {
  filter: "p",
  replacement: function (t) {
    return (
      `

` +
      t +
      `

`
    );
  },
};
B.lineBreak = {
  filter: "br",
  replacement: function (t, e, n) {
    return (
      n.br +
      `
`
    );
  },
};
B.heading = {
  filter: ["h1", "h2", "h3", "h4", "h5", "h6"],
  replacement: function (t, e, n) {
    var r = Number(e.nodeName.charAt(1));
    if (n.headingStyle === "setext" && r < 3) {
      var i = Zt(r === 1 ? "=" : "-", t.length);
      return (
        `

` +
        t +
        `
` +
        i +
        `

`
      );
    } else
      return (
        `

` +
        Zt("#", r) +
        " " +
        t +
        `

`
      );
  },
};
B.blockquote = {
  filter: "blockquote",
  replacement: function (t) {
    return (
      (t = Pr(t).replace(/^/gm, "> ")),
      `

` +
        t +
        `

`
    );
  },
};
B.list = {
  filter: ["ul", "ol"],
  replacement: function (t, e) {
    var n = e.parentNode;
    return n.nodeName === "LI" && n.lastElementChild === e
      ? `
` + t
      : `

` +
          t +
          `

`;
  },
};
B.listItem = {
  filter: "li",
  replacement: function (t, e, n) {
    var r = n.bulletListMarker + "   ",
      i = e.parentNode;
    if (i.nodeName === "OL") {
      var l = i.getAttribute("start"),
        o = Array.prototype.indexOf.call(i.children, e);
      r = (l ? Number(l) + o : o + 1) + ".  ";
    }
    var a = /\n$/.test(t);
    return (
      (t =
        Pr(t) +
        (a
          ? `
`
          : "")),
      (t = t.replace(
        /\n/gm,
        `
` + " ".repeat(r.length),
      )),
      r +
        t +
        (e.nextSibling
          ? `
`
          : "")
    );
  },
};
B.indentedCodeBlock = {
  filter: function (t, e) {
    return (
      e.codeBlockStyle === "indented" &&
      t.nodeName === "PRE" &&
      t.firstChild &&
      t.firstChild.nodeName === "CODE"
    );
  },
  replacement: function (t, e, n) {
    return (
      `

    ` +
      e.firstChild.textContent.replace(
        /\n/g,
        `
    `,
      ) +
      `

`
    );
  },
};
B.fencedCodeBlock = {
  filter: function (t, e) {
    return (
      e.codeBlockStyle === "fenced" &&
      t.nodeName === "PRE" &&
      t.firstChild &&
      t.firstChild.nodeName === "CODE"
    );
  },
  replacement: function (t, e, n) {
    for (
      var r = e.firstChild.getAttribute("class") || "",
        i = (r.match(/language-(\S+)/) || [null, ""])[1],
        l = e.firstChild.textContent,
        o = n.fence.charAt(0),
        a = 3,
        u = new RegExp("^" + o + "{3,}", "gm"),
        p;
      (p = u.exec(l));
    )
      p[0].length >= a && (a = p[0].length + 1);
    var d = Zt(o, a);
    return (
      `

` +
      d +
      i +
      `
` +
      l.replace(/\n$/, "") +
      `
` +
      d +
      `

`
    );
  },
};
B.horizontalRule = {
  filter: "hr",
  replacement: function (t, e, n) {
    return (
      `

` +
      n.hr +
      `

`
    );
  },
};
B.inlineLink = {
  filter: function (t, e) {
    return (
      e.linkStyle === "inlined" && t.nodeName === "A" && t.getAttribute("href")
    );
  },
  replacement: function (t, e) {
    var n = ln(e.getAttribute("href")),
      r = an(dt(e.getAttribute("title"))),
      i = r ? ' "' + r + '"' : "";
    return "[" + t + "](" + n + i + ")";
  },
};
B.referenceLink = {
  filter: function (t, e) {
    return (
      e.linkStyle === "referenced" &&
      t.nodeName === "A" &&
      t.getAttribute("href")
    );
  },
  replacement: function (t, e, n) {
    var r = ln(e.getAttribute("href")),
      i = dt(e.getAttribute("title"));
    i && (i = ' "' + an(i) + '"');
    var l, o;
    switch (n.linkReferenceStyle) {
      case "collapsed":
        ((l = "[" + t + "][]"), (o = "[" + t + "]: " + r + i));
        break;
      case "shortcut":
        ((l = "[" + t + "]"), (o = "[" + t + "]: " + r + i));
        break;
      default:
        var a = this.references.length + 1;
        ((l = "[" + t + "][" + a + "]"), (o = "[" + a + "]: " + r + i));
    }
    return (this.references.push(o), l);
  },
  references: [],
  append: function (t) {
    var e = "";
    return (
      this.references.length &&
        ((e =
          `

` +
          this.references.join(`
`) +
          `

`),
        (this.references = [])),
      e
    );
  },
};
B.emphasis = {
  filter: ["em", "i"],
  replacement: function (t, e, n) {
    return t.trim() ? n.emDelimiter + t + n.emDelimiter : "";
  },
};
B.strong = {
  filter: ["strong", "b"],
  replacement: function (t, e, n) {
    return t.trim() ? n.strongDelimiter + t + n.strongDelimiter : "";
  },
};
B.code = {
  filter: function (t) {
    var e = t.previousSibling || t.nextSibling,
      n = t.parentNode.nodeName === "PRE" && !e;
    return t.nodeName === "CODE" && !n;
  },
  replacement: function (t) {
    if (!t) return "";
    t = t.replace(/\r?\n|\r/g, " ");
    for (
      var e = /^`|^ .*?[^ ].* $|`$/.test(t) ? " " : "",
        n = "`",
        r = t.match(/`+/gm) || [];
      r.indexOf(n) !== -1;
    )
      n = n + "`";
    return n + e + t + e + n;
  },
};
B.image = {
  filter: "img",
  replacement: function (t, e) {
    var n = zr(dt(e.getAttribute("alt"))),
      r = ln(e.getAttribute("src") || ""),
      i = dt(e.getAttribute("title")),
      l = i ? ' "' + an(i) + '"' : "";
    return r ? "![" + n + "](" + r + l + ")" : "";
  },
};
function dt(t) {
  return t
    ? t.replace(
        /(\n+\s*)+/g,
        `
`,
      )
    : "";
}
function ln(t) {
  var e = t.replace(/([<>()])/g, "\\$1");
  return e.indexOf(" ") >= 0 ? "<" + e + ">" : e;
}
function an(t) {
  return t.replace(/"/g, '\\"');
}
function Br(t) {
  ((this.options = t),
    (this._keep = []),
    (this._remove = []),
    (this.blankRule = { replacement: t.blankReplacement }),
    (this.keepReplacement = t.keepReplacement),
    (this.defaultRule = { replacement: t.defaultReplacement }),
    (this.array = []));
  for (var e in t.rules) this.array.push(t.rules[e]);
}
Br.prototype = {
  add: function (t, e) {
    this.array.unshift(e);
  },
  keep: function (t) {
    this._keep.unshift({ filter: t, replacement: this.keepReplacement });
  },
  remove: function (t) {
    this._remove.unshift({
      filter: t,
      replacement: function () {
        return "";
      },
    });
  },
  forNode: function (t) {
    if (t.isBlank) return this.blankRule;
    var e;
    return (e = Ft(this.array, t, this.options)) ||
      (e = Ft(this._keep, t, this.options)) ||
      (e = Ft(this._remove, t, this.options))
      ? e
      : this.defaultRule;
  },
  forEach: function (t) {
    for (var e = 0; e < this.array.length; e++) t(this.array[e], e);
  },
};
function Ft(t, e, n) {
  for (var r = 0; r < t.length; r++) {
    var i = t[r];
    if (il(i, e, n)) return i;
  }
}
function il(t, e, n) {
  var r = t.filter;
  if (typeof r == "string") {
    if (r === e.nodeName.toLowerCase()) return !0;
  } else if (Array.isArray(r)) {
    if (r.indexOf(e.nodeName.toLowerCase()) > -1) return !0;
  } else if (typeof r == "function") {
    if (r.call(t, e, n)) return !0;
  } else
    throw new TypeError("`filter` needs to be a string, array, or function");
}
function sl(t) {
  var e = t.element,
    n = t.isBlock,
    r = t.isVoid,
    i =
      t.isPre ||
      function (m) {
        return m.nodeName === "PRE";
      };
  if (!(!e.firstChild || i(e))) {
    for (var l = null, o = !1, a = null, u = gr(a, e, i); u !== e;) {
      if (u.nodeType === 3 || u.nodeType === 4) {
        var p = u.data.replace(/[ \r\n\t]+/g, " ");
        if (
          ((!l || / $/.test(l.data)) && !o && p[0] === " " && (p = p.substr(1)),
          !p)
        ) {
          u = Ut(u);
          continue;
        }
        ((u.data = p), (l = u));
      } else if (u.nodeType === 1)
        n(u) || u.nodeName === "BR"
          ? (l && (l.data = l.data.replace(/ $/, "")), (l = null), (o = !1))
          : r(u) || i(u)
            ? ((l = null), (o = !0))
            : l && (o = !1);
      else {
        u = Ut(u);
        continue;
      }
      var d = gr(a, u, i);
      ((a = u), (u = d));
    }
    l && ((l.data = l.data.replace(/ $/, "")), l.data || Ut(l));
  }
}
function Ut(t) {
  var e = t.nextSibling || t.parentNode;
  return (t.parentNode.removeChild(t), e);
}
function gr(t, e, n) {
  return (t && t.parentNode === e) || n(e)
    ? e.nextSibling || e.parentNode
    : e.firstChild || e.nextSibling || e.parentNode;
}
var on = typeof window < "u" ? window : {};
function ll() {
  var t = on.DOMParser,
    e = !1;
  try {
    new t().parseFromString("", "text/html") && (e = !0);
  } catch {}
  return e;
}
function al() {
  var t = function () {};
  return (
    ol()
      ? (t.prototype.parseFromString = function (e) {
          var n = new window.ActiveXObject("htmlfile");
          return ((n.designMode = "on"), n.open(), n.write(e), n.close(), n);
        })
      : (t.prototype.parseFromString = function (e) {
          var n = document.implementation.createHTMLDocument("");
          return (n.open(), n.write(e), n.close(), n);
        }),
    t
  );
}
function ol() {
  var t = !1;
  try {
    document.implementation.createHTMLDocument("").open();
  } catch {
    on.ActiveXObject && (t = !0);
  }
  return t;
}
var cl = ll() ? on.DOMParser : al();
function ul(t, e) {
  var n;
  if (typeof t == "string") {
    var r = pl().parseFromString(
      '<x-turndown id="turndown-root">' + t + "</x-turndown>",
      "text/html",
    );
    n = r.getElementById("turndown-root");
  } else n = t.cloneNode(!0);
  return (
    sl({
      element: n,
      isBlock: rn,
      isVoid: Ir,
      isPre: e.preformattedCode ? fl : null,
    }),
    n
  );
}
var Ht;
function pl() {
  return ((Ht = Ht || new cl()), Ht);
}
function fl(t) {
  return t.nodeName === "PRE" || t.nodeName === "CODE";
}
function hl(t, e) {
  return (
    (t.isBlock = rn(t)),
    (t.isCode = t.nodeName === "CODE" || t.parentNode.isCode),
    (t.isBlank = gl(t)),
    (t.flankingWhitespace = dl(t, e)),
    t
  );
}
function gl(t) {
  return !Ir(t) && !tl(t) && /^\s*$/i.test(t.textContent) && !el(t) && !nl(t);
}
function dl(t, e) {
  if (t.isBlock || (e.preformattedCode && t.isCode))
    return { leading: "", trailing: "" };
  var n = ml(t.textContent);
  return (
    n.leadingAscii && dr("left", t, e) && (n.leading = n.leadingNonAscii),
    n.trailingAscii && dr("right", t, e) && (n.trailing = n.trailingNonAscii),
    { leading: n.leading, trailing: n.trailing }
  );
}
function ml(t) {
  var e = t.match(
    /^(([ \t\r\n]*)(\s*))(?:(?=\S)[\s\S]*\S)?((\s*?)([ \t\r\n]*))$/,
  );
  return {
    leading: e[1],
    leadingAscii: e[2],
    leadingNonAscii: e[3],
    trailing: e[4],
    trailingNonAscii: e[5],
    trailingAscii: e[6],
  };
}
function dr(t, e, n) {
  var r, i, l;
  return (
    t === "left"
      ? ((r = e.previousSibling), (i = / $/))
      : ((r = e.nextSibling), (i = /^ /)),
    r &&
      (r.nodeType === 3
        ? (l = i.test(r.nodeValue))
        : n.preformattedCode && r.nodeName === "CODE"
          ? (l = !1)
          : r.nodeType === 1 && !rn(r) && (l = i.test(r.textContent))),
    l
  );
}
var kl = Array.prototype.reduce;
function mt(t) {
  if (!(this instanceof mt)) return new mt(t);
  var e = {
    rules: B,
    headingStyle: "setext",
    hr: "* * *",
    bulletListMarker: "*",
    codeBlockStyle: "indented",
    fence: "```",
    emDelimiter: "_",
    strongDelimiter: "**",
    linkStyle: "inlined",
    linkReferenceStyle: "full",
    br: "  ",
    preformattedCode: !1,
    blankReplacement: function (n, r) {
      return r.isBlock
        ? `

`
        : "";
    },
    keepReplacement: function (n, r) {
      return r.isBlock
        ? `

` +
            r.outerHTML +
            `

`
        : r.outerHTML;
    },
    defaultReplacement: function (n, r) {
      return r.isBlock
        ? `

` +
            n +
            `

`
        : n;
    },
  };
  ((this.options = Ks({}, e, t)), (this.rules = new Br(this.options)));
}
mt.prototype = {
  turndown: function (t) {
    if (!xl(t))
      throw new TypeError(
        t + " is not a string, or an element/document/fragment node.",
      );
    if (t === "") return "";
    var e = Fr.call(this, new ul(t, this.options));
    return bl.call(this, e);
  },
  use: function (t) {
    if (Array.isArray(t)) for (var e = 0; e < t.length; e++) this.use(t[e]);
    else if (typeof t == "function") t(this);
    else
      throw new TypeError("plugin must be a Function or an Array of Functions");
    return this;
  },
  addRule: function (t, e) {
    return (this.rules.add(t, e), this);
  },
  keep: function (t) {
    return (this.rules.keep(t), this);
  },
  remove: function (t) {
    return (this.rules.remove(t), this);
  },
  escape: function (t) {
    return zr(t);
  },
};
function Fr(t) {
  var e = this;
  return kl.call(
    t.childNodes,
    function (n, r) {
      r = new hl(r, e.options);
      var i = "";
      return (
        r.nodeType === 3
          ? (i = r.isCode ? r.nodeValue : e.escape(r.nodeValue))
          : r.nodeType === 1 && (i = Tl.call(e, r)),
        Ur(n, i)
      );
    },
    "",
  );
}
function bl(t) {
  var e = this;
  return (
    this.rules.forEach(function (n) {
      typeof n.append == "function" && (t = Ur(t, n.append(e.options)));
    }),
    t.replace(/^[\t\r\n]+/, "").replace(/[\t\r\n\s]+$/, "")
  );
}
function Tl(t) {
  var e = this.rules.forNode(t),
    n = Fr.call(this, t),
    r = t.flankingWhitespace;
  return (
    (r.leading || r.trailing) && (n = n.trim()),
    r.leading + e.replacement(n, t, this.options) + r.trailing
  );
}
function Ur(t, e) {
  var n = Cr(t),
    r = Nr(e),
    i = Math.max(t.length - n.length, e.length - r.length),
    l = `

`.substring(0, i);
  return n + l + r;
}
function xl(t) {
  return (
    t != null &&
    (typeof t == "string" ||
      (t.nodeType &&
        (t.nodeType === 1 || t.nodeType === 9 || t.nodeType === 11)))
  );
}
var mr = /highlight-(?:text|source)-([a-z0-9]+)/;
function wl(t) {
  t.addRule("highlightedCodeBlock", {
    filter: function (e) {
      var n = e.firstChild;
      return (
        e.nodeName === "DIV" &&
        mr.test(e.className) &&
        n &&
        n.nodeName === "PRE"
      );
    },
    replacement: function (e, n, r) {
      var i = n.className || "",
        l = (i.match(mr) || [null, ""])[1];
      return (
        `

` +
        r.fence +
        l +
        `
` +
        n.firstChild.textContent +
        `
` +
        r.fence +
        `

`
      );
    },
  });
}
function yl(t) {
  t.addRule("strikethrough", {
    filter: ["del", "s", "strike"],
    replacement: function (e) {
      return "~" + e + "~";
    },
  });
}
var Al = Array.prototype.indexOf,
  Sl = Array.prototype.every,
  De = {};
De.tableCell = {
  filter: ["th", "td"],
  replacement: function (t, e) {
    return Hr(t, e);
  },
};
De.tableRow = {
  filter: "tr",
  replacement: function (t, e) {
    var n = "",
      r = { left: ":--", right: "--:", center: ":-:" };
    if (cn(e))
      for (var i = 0; i < e.childNodes.length; i++) {
        var l = "---",
          o = (e.childNodes[i].getAttribute("align") || "").toLowerCase();
        (o && (l = r[o] || l), (n += Hr(l, e.childNodes[i])));
      }
    return (
      `
` +
      t +
      (n
        ? `
` + n
        : "")
    );
  },
};
De.table = {
  filter: function (t) {
    return t.nodeName === "TABLE" && cn(t.rows[0]);
  },
  replacement: function (t) {
    return (
      (t = t.replace(
        `

`,
        `
`,
      )),
      `

` +
        t +
        `

`
    );
  },
};
De.tableSection = {
  filter: ["thead", "tbody", "tfoot"],
  replacement: function (t) {
    return t;
  },
};
function cn(t) {
  var e = t.parentNode;
  return (
    e.nodeName === "THEAD" ||
    (e.firstChild === t &&
      (e.nodeName === "TABLE" || _l(e)) &&
      Sl.call(t.childNodes, function (n) {
        return n.nodeName === "TH";
      }))
  );
}
function _l(t) {
  var e = t.previousSibling;
  return (
    t.nodeName === "TBODY" &&
    (!e || (e.nodeName === "THEAD" && /^\s*$/i.test(e.textContent)))
  );
}
function Hr(t, e) {
  var n = Al.call(e.parentNode.childNodes, e),
    r = " ";
  return (n === 0 && (r = "| "), r + t + " |");
}
function El(t) {
  t.keep(function (n) {
    return n.nodeName === "TABLE" && !cn(n.rows[0]);
  });
  for (var e in De) t.addRule(e, De[e]);
}
function Rl(t) {
  t.addRule("taskListItems", {
    filter: function (e) {
      return e.type === "checkbox" && e.parentNode.nodeName === "LI";
    },
    replacement: function (e, n) {
      return (n.checked ? "[x]" : "[ ]") + " ";
    },
  });
}
function vl(t) {
  t.use([wl, yl, El, Rl]);
}
function Ol(t) {
  const e = t.split(/\r?\n/),
    n = new Map(),
    r = [];
  let i = !1;
  for (let a = 0; a < e.length; a++) {
    const u = e[a];
    if (/^\s*(```|~~~)/.test(u)) {
      ((i = !i), r.push(u));
      continue;
    }
    const p = !i && u.match(/^\[\^([^\]\s]+)\]:\s*(.*)$/);
    if (!p) {
      r.push(u);
      continue;
    }
    let d = p[2];
    for (; a + 1 < e.length && /^( {2,}|\t)\S/.test(e[a + 1]);)
      d += " " + e[++a].trim();
    n.set(p[1], d);
  }
  const l = [];
  return (
    (i = !1),
    {
      body: r.map((a) =>
        /^\s*(```|~~~)/.test(a)
          ? ((i = !i), a)
          : i
            ? a
            : a
                .split(/(`+[^`]*`+)/)
                .map((u, p) =>
                  p % 2 === 1
                    ? u
                    : u.replace(/\[\^([^\]\s]+)\]/g, (d, m) => {
                        if (!n.has(m)) return d;
                        l.includes(m) || l.push(m);
                        const L = l.indexOf(m) + 1;
                        return `<sup><a href="#fn-${m}" id="fnref-${m}">${L}</a></sup>`;
                      }),
                )
                .join(""),
      ).join(`
`),
      notes: l.map((a, u) => ({ id: a, n: u + 1, text: n.get(a) })),
    }
  );
}
function Nl(t) {
  const { body: e, notes: n } = Ol(t);
  let r = y.parse(e, { gfm: !0, breaks: !1, async: !1 });
  return (
    n.length &&
      (r += `
<section class="footnotes"><hr><ol>
${n.map(
  (i) =>
    `<li id="fn-${i.id}">${y.parseInline(i.text, { gfm: !0, async: !1 })} <a href="#fnref-${i.id}">↩</a></li>`,
).join(`
`)}
</ol></section>`),
    Lr.sanitize(r, { USE_PROFILES: { html: !0 } }).trim()
  );
}
let ut = null;
function Ll() {
  return (
    ut ||
      ((ut = new mt({
        headingStyle: "atx",
        codeBlockStyle: "fenced",
        bulletListMarker: "-",
        emDelimiter: "*",
        hr: "---",
      })),
      ut.use(vl)),
    ut
  );
}
function Cl(t) {
  const e = Lr.sanitize(t, { USE_PROFILES: { html: !0 } });
  return Ll().turndown(e).trim();
}
export { Cl as h, Nl as m };
//# sourceMappingURL=mdConvert-ChWDCiEy.js.map
