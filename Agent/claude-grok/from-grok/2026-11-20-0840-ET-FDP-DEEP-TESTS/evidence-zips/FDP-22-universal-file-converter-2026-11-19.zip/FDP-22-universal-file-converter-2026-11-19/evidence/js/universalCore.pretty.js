const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/excelPdf-CBfEpp0U.js",
      "assets/index-D2ZT81un.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/index-BJxTAPRn.css",
      "assets/index-BRvxULIc.js",
      "assets/index-CnXdQaNG.js",
      "assets/index-DMQTJy3b.js",
      "assets/jszip.min-CT0ZA6V1.js",
      "assets/jszip.min-C-FLQHAz.js",
      "assets/_commonjs-dynamic-modules-TDtrdbi3.js",
      "assets/backgroundSafe-DObGz9DE.js",
      "assets/pdfFonts-Ckcqm3Ic.js",
      "assets/fontkit.es-DA-3qwB1.js",
      "assets/pdfMetadata-CcxIhQF2.js",
      "assets/textToPdf-BuGdG5vq.js",
      "assets/xmlLite-D0-GZ86u.js",
      "assets/operations-DhLfXHFN.js",
      "assets/pdfBookmarks-BjfxtCfb.js",
      "assets/pageView-BQIwVYOi.js",
      "assets/formAppearance-CdNbuISd.js",
      "assets/drawTextAnywhere-DcuP6lHH.js",
      "assets/ocrText-C_9cxcFa.js",
      "assets/ocrImage-CmXFNUud.js",
      "assets/utils-s8ucLyj8.js",
      "assets/imageRecompress-eXQFDUm-.js",
      "assets/formatFileSize-B-JRDfN5.js",
      "assets/plural-FIChqbp4.js",
      "assets/textDiff-DxE9AzvO.js",
      "assets/utils-BCX55KBw.js",
      "assets/decode-D7I8Qajh.js",
      "assets/formFill-Dg9Myfyq.js",
      "assets/redactSearch-DQpyyh_t.js",
      "assets/nameDetect-DvHCRM0m.js",
      "assets/ocrEngine-C8AaB6dN.js",
      "assets/index-DQo6ttmA.js",
      "assets/imagePdf-Dtz8PQyf.js",
      "assets/heic2any-Cwwvdsxn.js",
    ]),
) => i.map((i) => d[i]);
import { ap as p } from "./index-D2ZT81un.js";
import { n as I, c as v } from "./legacyDeck-DRWwmRY1.js";
import {
  D as O,
  E as H,
  F as J,
  G as E,
  H as M,
  k as W,
  I as G,
  x as K,
} from "./operations-DhLfXHFN.js";
import { decodeTextFile as Y } from "./textToPdf-BuGdG5vq.js";
import { w as P } from "./operations-ISiPxXUp.js";
import "./vendor-react-D01g8YgM.js";
import "./ToolPage-DS5jbfzr.js";
import { m as L, h as z } from "./mdConvert-ChWDCiEy.js";
import {
  TableRow as q,
  TableCell as Z,
  Paragraph as R,
  Document as B,
  Table as Q,
  Packer as C,
  TextRun as tt,
} from "./index-CHifq31M.js";
import { l as et } from "./utils-s8ucLyj8.js";
import "./trpcVanilla-DLV8pXkC.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./pdfMetadata-CcxIhQF2.js";
import "./pageView-BQIwVYOi.js";
import "./formAppearance-CdNbuISd.js";
import "./drawTextAnywhere-DcuP6lHH.js";
import "./ocrText-C_9cxcFa.js";
import "./ocrImage-CmXFNUud.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./imageRecompress-eXQFDUm-.js";
import "./formatFileSize-B-JRDfN5.js";
import "./plural-FIChqbp4.js";
import "./textDiff-DxE9AzvO.js";
import "./utils-BCX55KBw.js";
import "./decode-D7I8Qajh.js";
import "./formFill-Dg9Myfyq.js";
import "./redactSearch-DQpyyh_t.js";
import "./nameDetect-DvHCRM0m.js";
import "./useUploadApi-CeBVbB2U.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-mA9gIB_c.js";
import "./share-2-wJ7OG3q6.js";
import "./copy-DxyF2bO9.js";
import "./workflowCta-QcLjv4ms.js";
import "./UsageAndUpgradeStrip-Ckl_cEoN.js";
import "./access-BBg1iIm1.js";
import "./useAdminAccess-D2xxeUJv.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-BaZhqv4P.js";
import "./map-pin-DiPhQKiV.js";
import "./FaqSection-DgbFc-d2.js";
import "./ToolVideoEmbed-DltoCXpM.js";
import "./GuideLinks-BsEl-oB0.js";
import "./blog-Cqpj3gtZ.js";
import "./info-BGlOhDp4.js";
import "./productCards-CAZfINO_.js";
import "./layers-B7zHnkyf.js";
import "./usePwaManifest-D8HDEEPW.js";
const nt = /^(\d{4})-(\d{2})-(\d{2})$/;
function at(t) {
  const e = nt.exec(t.trim());
  if (!e) return null;
  const [n, a, r] = [Number(e[1]), Number(e[2]), Number(e[3])],
    s = Date.UTC(n, a - 1, r),
    i = new Date(s);
  return i.getUTCFullYear() !== n ||
    i.getUTCMonth() !== a - 1 ||
    i.getUTCDate() !== r
    ? null
    : s / 864e5 + 25569;
}
function ot(t, e) {
  for (const n of Object.keys(e)) {
    if (n.startsWith("!")) continue;
    const a = e[n],
      r = typeof a.v == "string" ? a.v : "",
      s = t[n] ?? {},
      i = at(r);
    i !== null
      ? (t[n] = { t: "n", v: i, z: "yyyy-mm-dd", w: r.trim() })
      : r.startsWith("=") && s.f !== void 0 && (t[n] = { t: "s", v: r });
  }
}
async function rt(t) {
  return `<!DOCTYPE html>
<html><head><meta charset="utf-8"></head><body>
${(await O(t))
  .split(
    `
`,
  )
  .filter((r) => r.trim().length > 0)
  .map((r) => `<p>${X(r)}</p>`).join(`
`)}
</body></html>`;
}
async function A(t) {
  const e = t
      .split(
        `
`,
      )
      .map((a) => new R({ children: [new tt(a)] })),
    n = new B({ sections: [{ children: e }] });
  return C.toBlob(n);
}
function k(t) {
  return `<!DOCTYPE html>
<html><head><meta charset="utf-8"></head><body>
${t
  .split(
    `
`,
  )
  .filter((n) => n.trim().length > 0)
  .map((n) => `<p>${X(n)}</p>`).join(`
`)}
</body></html>`;
}
async function N(t) {
  const e = await et(t),
    n = [];
  for (let a = 1; a <= e.numPages; a++) {
    const i = (await (await e.getPage(a)).getTextContent()).items
      .map((m) => ("str" in m ? m.str : ""))
      .join(" ");
    n.push(i);
  }
  return n.join(`

`);
}
async function it(t) {
  return N(t);
}
async function st(t) {
  const e = await N(t);
  return A(e);
}
async function ct(t) {
  const e = await N(t);
  return k(e);
}
function F(t) {
  const e = t.SheetNames.findIndex((n, a) => !t.Workbook?.Sheets?.[a]?.Hidden);
  return t.SheetNames[e < 0 ? 0 : e];
}
async function $(t) {
  const e = await p(() => import("./xlsx-CNerDvZX.js"), []),
    { readSheetExtras: n } = await p(
      async () => {
        const { readSheetExtras: c } = await import("./excelPdf-CBfEpp0U.js");
        return { readSheetExtras: c };
      },
      __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]),
    ),
    a = await t.arrayBuffer(),
    r = e.read(a, { type: "array", cellStyles: !0 }),
    s = F(r),
    i = r.Sheets[s],
    x =
      new Uint8Array(a.slice(0, 2)).join() === "80,75"
        ? (await n(a)).get(s)
        : void 0;
  if (!i || !i["!ref"]) return i;
  const w = (c) => !!i["!rows"]?.[c]?.hidden || !!x?.hiddenRows.has(c),
    d = (c) => !!i["!cols"]?.[c]?.hidden || !!x?.hiddenCols.has(c),
    l = e.utils.decode_range(i["!ref"]);
  let u = !1;
  for (let c = l.s.r; c <= l.e.r && !u; c++) u = w(c);
  for (let c = l.s.c; c <= l.e.c && !u; c++) u = d(c);
  if (!u) return i;
  const b = {};
  let g = 0,
    _ = 0;
  for (let c = l.s.r; c <= l.e.r; c++) {
    if (w(c)) continue;
    let T = 0;
    for (let h = l.s.c; h <= l.e.c; h++) {
      if (d(h)) continue;
      const D = i[e.utils.encode_cell({ r: c, c: h })];
      (D && (b[e.utils.encode_cell({ r: g, c: T })] = D), T++);
    }
    ((_ = Math.max(_, T)), g++);
  }
  return (
    (b["!ref"] = e.utils.encode_range({
      s: { r: 0, c: 0 },
      e: { r: Math.max(g - 1, 0), c: Math.max(_ - 1, 0) },
    })),
    b
  );
}
async function lt(t) {
  const e = await p(() => import("./xlsx-CNerDvZX.js"), []),
    n = await $(t),
    a = e.utils.sheet_to_csv(n);
  return new Blob([a], { type: "text/csv" });
}
async function mt(t) {
  const e = await p(() => import("./xlsx-CNerDvZX.js"), []),
    n = await $(t),
    a = e.utils.sheet_to_json(n, { defval: "" });
  return new Blob([JSON.stringify(a, null, 2)], { type: "application/json" });
}
async function pt(t) {
  const e = await p(() => import("./xlsx-CNerDvZX.js"), []),
    n = await $(t),
    r = e.utils
      .sheet_to_json(n, { header: 1, raw: !1, defval: "" })
      .map(
        (i) =>
          new q({
            children: i.map((m) => new Z({ children: [new R(String(m))] })),
          }),
      ),
    s = new B({ sections: [{ children: [new Q({ rows: r })] }] });
  return C.toBlob(s);
}
async function dt(t) {
  const e = await p(() => import("./xlsx-CNerDvZX.js"), []),
    n = await t.text(),
    a = e.read(n, { type: "string" }),
    r = e.read(n, { type: "string", raw: !0 });
  for (const i of a.SheetNames) r.Sheets[i] && ot(a.Sheets[i], r.Sheets[i]);
  const s = e.write(a, { type: "array", bookType: "xlsx" });
  return new Blob([s], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
}
async function ut(t) {
  const e = await p(() => import("./xlsx-CNerDvZX.js"), []),
    n = await t.text(),
    a = e.read(n, { type: "string" }),
    r = a.Sheets[F(a)],
    s = e.utils.sheet_to_json(r, { defval: "" });
  return new Blob([JSON.stringify(s, null, 2)], { type: "application/json" });
}
async function ft(t) {
  const { convertPowerPointToPdf: e, convertPdfsToJpgs: n } = await p(
      async () => {
        const { convertPowerPointToPdf: s, convertPdfsToJpgs: i } =
          await import("./operations-DhLfXHFN.js").then((m) => m.Z);
        return { convertPowerPointToPdf: s, convertPdfsToJpgs: i };
      },
      __vite__mapDeps([
        16, 1, 2, 3, 11, 4, 5, 6, 12, 17, 13, 18, 19, 20, 21, 22, 7, 8, 9, 23,
        24, 25, 26, 27, 28, 29, 30, 31, 32,
      ]),
    ),
    a = await e(t),
    r = new File([a], t.name.replace(/\.pptx?$/i, ".pdf"), {
      type: "application/pdf",
    });
  return n([r]);
}
function U(t) {
  return new DOMParser().parseFromString(t, "text/html").body.textContent || "";
}
async function V(t) {
  const { convertTextToPdf: e } = await p(
    async () => {
      const { convertTextToPdf: n } =
        await import("./operations-DhLfXHFN.js").then((a) => a.Z);
      return { convertTextToPdf: n };
    },
    __vite__mapDeps([
      16, 1, 2, 3, 11, 4, 5, 6, 12, 17, 13, 18, 19, 20, 21, 22, 7, 8, 9, 23, 24,
      25, 26, 27, 28, 29, 30, 31, 32,
    ]),
  );
  return e(U(t));
}
async function wt(t, e) {
  return V(t(e));
}
function bt(t) {
  return new Promise((e, n) => {
    const a = new FileReader();
    ((a.onload = () => e(a.result)), (a.onerror = n), a.readAsDataURL(t));
  });
}
async function xt(t) {
  const e = new Image(),
    n = URL.createObjectURL(t);
  try {
    await new Promise((r, s) => {
      ((e.onload = () => r()),
        (e.onerror = () => s(new Error("Couldn't read this image"))),
        (e.src = n));
    });
    const a = document.createElement("canvas");
    return (
      (a.width = e.naturalWidth),
      (a.height = e.naturalHeight),
      a.getContext("2d").drawImage(e, 0, 0),
      a
    );
  } finally {
    URL.revokeObjectURL(n);
  }
}
async function ht(t) {
  const e = await xt(t),
    n = 256,
    a = document.createElement("canvas");
  ((a.width = n), (a.height = n));
  const r = a.getContext("2d"),
    s = Math.min(n / e.width, n / e.height),
    i = e.width * s,
    m = e.height * s;
  r.drawImage(e, (n - i) / 2, (n - m) / 2, i, m);
  const x = await new Promise((u) => a.toBlob((b) => u(b), "image/png")),
    w = new Uint8Array(await x.arrayBuffer()),
    d = new Uint8Array(22),
    l = new DataView(d.buffer);
  return (
    l.setUint16(0, 0, !0),
    l.setUint16(2, 1, !0),
    l.setUint16(4, 1, !0),
    (d[6] = 0),
    (d[7] = 0),
    (d[8] = 0),
    (d[9] = 0),
    l.setUint16(10, 1, !0),
    l.setUint16(12, 32, !0),
    l.setUint32(14, w.length, !0),
    l.setUint32(18, 22, !0),
    new Blob([d, w], { type: "image/x-icon" })
  );
}
function X(t) {
  return t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function $e(t) {
  const e = t.name.toLowerCase();
  return /\.(heic|heif)$/.test(e)
    ? "heic"
    : /\.(jpe?g|png|webp)$/.test(e)
      ? "image"
      : /\.pdf$/.test(e)
        ? "pdf"
        : /\.md$/.test(e)
          ? "markdown"
          : /\.html?$/.test(e)
            ? "html"
            : /\.txt$/.test(e)
              ? "text"
              : /\.csv$/.test(e)
                ? "csv"
                : /\.xlsx?$/.test(e)
                  ? "excel"
                  : /\.(pptx?|pps|odp|key)$/.test(e)
                    ? "powerpoint"
                    : /\.docx?$/.test(e)
                      ? "docx"
                      : null;
}
async function S(t) {
  return I(t) ? (await v(t, "pptx")).file : t;
}
function o(t) {
  return t.replace(/\.[^.]+$/, "");
}
function f(t) {
  return new Blob([t], { type: "text/plain" });
}
function y(t) {
  return new Blob([t], { type: "text/html" });
}
async function yt(t) {
  const [
      { startOcrEngine: e },
      { ocrParagraphs: n },
      { normalizeImageFile: a },
    ] = await Promise.all([
      p(
        () => import("./ocrEngine-C8AaB6dN.js"),
        __vite__mapDeps([33, 34, 9, 22, 21]),
      ),
      p(() => import("./ocrText-C_9cxcFa.js"), []),
      p(
        () => import("./imagePdf-Dtz8PQyf.js"),
        __vite__mapDeps([35, 4, 5, 2, 6, 13]),
      ),
    ]),
    r = await a(t),
    s = await e("eng");
  try {
    const i = await s.read(r, { autoRotate: !0 }),
      m = n(i);
    return m.length
      ? m.join(`

`)
      : (i.text ?? "").trim();
  } finally {
    await s.terminate();
  }
}
async function gt(t) {
  const e = (
      await p(
        async () => {
          const { default: r } = await import("./heic2any-Cwwvdsxn.js").then(
            (s) => s.h,
          );
          return { default: r };
        },
        __vite__mapDeps([36, 2]),
      )
    ).default,
    n = await e({ blob: t, toType: "image/jpeg", quality: 0.92 }),
    a = Array.isArray(n) ? n[0] : n;
  return new File([a], `${o(t.name)}.jpg`, { type: "image/jpeg" });
}
const j = () => [
    {
      id: "pdf",
      label: "PDF",
      run: async (t) => ({
        blob: await K([t], "a4"),
        fileName: `${o(t.name)}.pdf`,
      }),
    },
    {
      id: "png",
      label: "PNG",
      run: async (t) => ({
        blob: await P(t, "image/png"),
        fileName: `${o(t.name)}.png`,
      }),
    },
    {
      id: "jpg",
      label: "JPG",
      run: async (t) => ({
        blob: await P(t, "image/jpeg"),
        fileName: `${o(t.name)}.jpg`,
      }),
    },
    {
      id: "webp",
      label: "WebP",
      run: async (t) => ({
        blob: await P(t, "image/webp"),
        fileName: `${o(t.name)}.webp`,
      }),
    },
    {
      id: "ico",
      label: "ICO",
      run: async (t) => ({ blob: await ht(t), fileName: `${o(t.name)}.ico` }),
    },
    {
      id: "base64",
      label: "Base64 text",
      run: async (t) => ({
        blob: f(await bt(t)),
        fileName: `${o(t.name)}-base64.txt`,
      }),
    },
    {
      id: "text",
      label: "Text (OCR)",
      run: async (t) => ({
        blob: f(await yt(t)),
        fileName: `${o(t.name)}.txt`,
      }),
    },
  ],
  _t = {
    image: j(),
    heic: j().map((t) => ({
      ...t,
      run: async (e) => {
        const n = await gt(e);
        return t.run(n);
      },
    })),
    pdf: [
      {
        id: "jpg",
        label: "JPG",
        run: async (t) => {
          const e = await W([t]);
          return { blob: e.blob, fileName: e.filename };
        },
      },
      {
        id: "excel",
        label: "Excel",
        run: async (t) => {
          const e = await G(t);
          return e.hasData
            ? { blob: e.blob, fileName: `${o(t.name)}.xlsx` }
            : {
                skipped: !0,
                reason: "No tables were found in this PDF to convert.",
              };
        },
      },
      {
        id: "word",
        label: "Word",
        run: async (t) => ({
          blob: await st(t),
          fileName: `${o(t.name)}.docx`,
        }),
      },
      {
        id: "txt",
        label: "Text",
        run: async (t) => ({
          blob: f(await it(t)),
          fileName: `${o(t.name)}.txt`,
        }),
      },
      {
        id: "html",
        label: "HTML",
        run: async (t) => ({
          blob: y(await ct(t)),
          fileName: `${o(t.name)}.html`,
        }),
      },
    ],
    text: [
      {
        id: "pdf",
        label: "PDF",
        run: async (t) => ({
          blob: await M(Y(await t.arrayBuffer()), o(t.name)),
          fileName: `${o(t.name)}.pdf`,
        }),
      },
      {
        id: "word",
        label: "Word",
        run: async (t) => ({
          blob: await A(await t.text()),
          fileName: `${o(t.name)}.docx`,
        }),
      },
      {
        id: "html",
        label: "HTML",
        run: async (t) => ({
          blob: y(k(await t.text())),
          fileName: `${o(t.name)}.html`,
        }),
      },
    ],
    excel: [
      {
        id: "pdf",
        label: "PDF",
        run: async (t) => ({ blob: await E(t), fileName: `${o(t.name)}.pdf` }),
      },
      {
        id: "csv",
        label: "CSV",
        run: async (t) => ({ blob: await lt(t), fileName: `${o(t.name)}.csv` }),
      },
      {
        id: "json",
        label: "JSON",
        run: async (t) => ({
          blob: await mt(t),
          fileName: `${o(t.name)}.json`,
        }),
      },
      {
        id: "word",
        label: "Word (table)",
        run: async (t) => ({
          blob: await pt(t),
          fileName: `${o(t.name)}.docx`,
        }),
      },
    ],
    csv: [
      {
        id: "excel",
        label: "Excel",
        run: async (t) => ({
          blob: await dt(t),
          fileName: `${o(t.name)}.xlsx`,
        }),
      },
      {
        id: "json",
        label: "JSON",
        run: async (t) => ({
          blob: await ut(t),
          fileName: `${o(t.name)}.json`,
        }),
      },
      {
        id: "pdf",
        label: "PDF",
        run: async (t) => ({ blob: await E(t), fileName: `${o(t.name)}.pdf` }),
      },
    ],
    powerpoint: [
      {
        id: "pdf",
        label: "PDF",
        run: async (t) => ({
          blob: await J(await S(t)),
          fileName: `${o(t.name)}.pdf`,
        }),
      },
      {
        id: "jpg",
        label: "JPG",
        run: async (t) => {
          const e = await ft(await S(t));
          return { blob: e.blob, fileName: e.filename };
        },
      },
      {
        id: "pptx",
        label: "PowerPoint .pptx (from old formats)",
        run: async (t) =>
          I(t)
            ? { blob: (await v(t, "pptx")).file, fileName: `${o(t.name)}.pptx` }
            : { skipped: !0, reason: "This file is already a .pptx." },
      },
      {
        id: "odp",
        label: "OpenDocument .odp",
        run: async (t) => ({
          blob: (await v(t, "odp")).file,
          fileName: `${o(t.name)}.odp`,
        }),
      },
    ],
    docx: [
      {
        id: "pdf",
        label: "PDF",
        run: async (t) => ({ blob: await H(t), fileName: `${o(t.name)}.pdf` }),
      },
      {
        id: "txt",
        label: "Text",
        run: async (t) => ({
          blob: f(await O(t)),
          fileName: `${o(t.name)}.txt`,
        }),
      },
      {
        id: "html",
        label: "HTML",
        run: async (t) => ({
          blob: y(await rt(t)),
          fileName: `${o(t.name)}.html`,
        }),
      },
    ],
    html: [
      {
        id: "pdf",
        label: "PDF",
        run: async (t) => ({
          blob: await V(await t.text()),
          fileName: `${o(t.name)}.pdf`,
        }),
      },
      {
        id: "markdown",
        label: "Markdown",
        run: async (t) => ({
          blob: f(z(await t.text())),
          fileName: `${o(t.name)}.md`,
        }),
      },
      {
        id: "text",
        label: "Text",
        run: async (t) => ({
          blob: f(U(await t.text())),
          fileName: `${o(t.name)}.txt`,
        }),
      },
    ],
    markdown: [
      {
        id: "html",
        label: "HTML",
        run: async (t) => ({
          blob: y(L(await t.text())),
          fileName: `${o(t.name)}.html`,
        }),
      },
      {
        id: "pdf",
        label: "PDF",
        run: async (t) => ({
          blob: await wt(L, await t.text()),
          fileName: `${o(t.name)}.pdf`,
        }),
      },
    ],
  },
  Tt = {
    image: "Image",
    heic: "HEIC photo",
    pdf: "PDF",
    text: "Text file",
    excel: "Spreadsheet",
    csv: "CSV",
    powerpoint: "PowerPoint presentation",
    docx: "Word document",
    html: "HTML file",
    markdown: "Markdown file",
  },
  Pt = {
    image: ".jpg,.jpeg,.png,.webp",
    heic: ".heic,.heif",
    pdf: ".pdf",
    text: ".txt",
    excel: ".xlsx,.xls",
    csv: ".csv",
    powerpoint: ".ppt,.pptx,.pps,.odp,.key",
    docx: ".doc,.docx",
    html: ".html,.htm",
    markdown: ".md",
  };
function De() {
  return vt.map((t) => ({
    kind: t,
    from: Tt[t],
    extensions: Pt[t].split(",").join(" "),
    to: _t[t].map((e) => e.label),
  }));
}
const vt = [
  "image",
  "heic",
  "pdf",
  "text",
  "excel",
  "csv",
  "powerpoint",
  "docx",
  "html",
  "markdown",
];
function Ee(t) {
  const e = t.match(/\.[^./]+$/);
  return e ? e[0] : "";
}
function Le(t, e, n) {
  return !(t && (e || n > 1));
}
export {
  vt as ALL_KINDS,
  Pt as KIND_EXT,
  Tt as KIND_LABEL,
  _t as TARGETS_BY_KIND,
  De as conversionTable,
  $e as detectKind,
  Ee as extOf,
  y as htmlBlob,
  Le as showStageDownload,
  o as stripExt,
  f as textBlob,
};
//# sourceMappingURL=universalCore-mY4FT3mW.js.map
