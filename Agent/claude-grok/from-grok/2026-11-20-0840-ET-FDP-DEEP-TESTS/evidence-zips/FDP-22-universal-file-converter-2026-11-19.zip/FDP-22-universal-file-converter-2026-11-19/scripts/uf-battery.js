// universal-file-converter battery: one fresh context per input file (uf-cases.json; argv[2] = comma IDs); for each target: drop the file, press the target, capture the result
// from the in-memory Blob/File (init-script hook), then Start over. Records every request to freedailypro.com (method + path, request size) to see which conversions send the file to the server. Conversions cost no trial use (gate is at Download); nothing is downloaded.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/22-universal-file-converter/live/'; const T = '/workspace/deep/22-universal-file-converter/testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const ids = process.argv[2] ? process.argv[2].split(',') : null; const tag = ids ? '-' + ids.join('_') : '';
const cases = JSON.parse(fs.readFileSync(__dirname + '/uf-cases.json')).filter(c => !ids || ids.includes(c.id));
const HOOK = `(() => { window.__blobs = []; const OB = window.Blob, OF = window.File; window.Blob = class extends OB { constructor(p, o) { super(p, o); window.__blobs.push({ b: this, name: null, t: Date.now() }); } }; window.File = class extends OF { constructor(p, n, o) { super(p, n, o); window.__blobs.push({ b: this, name: n, t: Date.now() }); } }; })();`;
(async () => { const b = await chromium.launch(); const R = { t: now(), cases: [] }; const save = () => fs.writeFileSync(OUT + 'battery' + tag + '.json', JSON.stringify(R, null, 1));
 for (const c of cases) { const r = { id: c.id, file: c.file, t: now(), runs: [] }; const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); await ctx.addInitScript(HOOK); const p = await ctx.newPage(); p.setDefaultTimeout(12000);
  let reqs = []; p.on('request', q => { const u = new URL(q.url()); if (/freedailypro/.test(u.host) && !/\/assets\//.test(u.pathname)) reqs.push({ m: q.method(), path: (u.pathname + u.search).slice(0, 90).replace(/input=[^&]*/, 'input=…'), bytes: (q.postDataBuffer() || Buffer.alloc(0)).length }); });
  const toastsNow = () => p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim().slice(0, 220))).catch(() => []);
  try { await p.goto('https://www.freedailypro.com/tool/universal-file-converter', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
   r.used0 = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
   const drop = async () => { await p.locator('main input[type=file]').first().setInputFiles(T + c.file); await p.waitForTimeout(3500); };
   await drop(); r.detected = await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*detected as[^\n]*/) || [null])[0]); r.dropToasts = await toastsNow();
   r.targetsShown = await p.evaluate(() => { const t = document.querySelector('main').innerText; const i = t.indexOf('to:\n'); return i < 0 ? null : t.slice(i + 4, i + 300).split('\n\n')[0].split('\n'); });
   r.dropText = await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*(not supported|can't|cannot|isn't|Unsupported|not accepted)[^\n]*/i) || [null])[0]);
   if (!c.targets.length) await p.screenshot({ path: OUT + 'res-' + c.id + '.png' });
   for (let i = 0; i < c.targets.length; i++) { const tg = c.targets[i]; const run = { target: tg };
    if (i > 0) { await p.getByRole('button', { name: 'Start over' }).first().click().catch(() => {}); await p.waitForTimeout(800); await drop(); }
    reqs = []; const n0 = await p.evaluate(() => window.__blobs.length); const t0 = Date.now();
    const btn = p.locator('main').getByRole('button', { name: tg, exact: true }); run.present = await btn.count();
    if (!run.present) { r.runs.push(run); continue; }
    await btn.last().click();
    for (let k = 0; k < 60; k++) { await p.waitForTimeout(1000); const st = await p.evaluate(() => { const t = document.querySelector('main').innerText; return { conv: /\nConverted\n/.test(t) || /Converted/.test(t), busy: /Converting|Working|Loading/i.test(t) }; }); if (st.conv && !st.busy) break; }
    run.ms = Date.now() - t0; await p.waitForTimeout(800); run.toasts = await toastsNow();
    run.stage = await p.evaluate(() => { const t = document.querySelector('main').innerText; const i = t.lastIndexOf('Converted'); return i < 0 ? null : t.slice(i, i + 260); });
    run.requests = reqs.filter(x => !/insight\.hit|auth\.me|cloudStorage\.config/.test(x.path)); run.allReqs = reqs.length;
    const out = await p.evaluate(async n0 => { const L = window.__blobs.slice(n0).filter(x => x.b.size > 0); const named = L.filter(x => x.name); const x = (named.length ? named : L).sort((a, b) => a.t - b.t).pop(); if (!x) return null; const bb = new Uint8Array(await x.b.arrayBuffer()); let s = ''; for (let i = 0; i < bb.length; i += 8192) s += String.fromCharCode.apply(null, bb.subarray(i, i + 8192)); return { name: x.name, type: x.b.type, size: x.b.size, b64: btoa(s) }; }, n0);
    if (out) { const ext = (out.name && out.name.split('.').pop()) || (out.type.split('/')[1] || 'bin'); const fn = `out-${c.id}-${i + 1}.${ext}`.replace(/[^\w.-]/g, '_'); fs.writeFileSync(OUT + fn, Buffer.from(out.b64, 'base64')); Object.assign(run, { outName: out.name, outType: out.type, outBytes: out.size, outFile: fn }); }
    run.mark = await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*Created with FreeDailyPro[^\n]*/) || [null])[0]);
    await p.screenshot({ path: OUT + `res-${c.id}-${i + 1}.png` }); r.runs.push(run); console.log(c.id, tg, run.outName || '', run.outBytes || '', run.ms, JSON.stringify(run.requests).slice(0, 160), (run.toasts || []).join(' / ').slice(0, 160)); }
   r.used1 = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
  } catch (e) { r.err = String(e).slice(0, 220); await p.screenshot({ path: OUT + 'err-' + c.id + '.png' }).catch(() => {}); }
  R.cases.push(r); save(); console.log(c.id, 'detected:', r.detected, '| shown:', JSON.stringify(r.targetsShown), r.dropText || '', JSON.stringify(r.dropToasts), r.err || ''); await ctx.close(); }
 R.t1 = now(); save(); await b.close(); })();
