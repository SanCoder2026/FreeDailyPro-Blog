// universal-file-converter in Firefox and WebKit: load, starting count, drop data.csv -> Excel and photo.heic -> JPG (no Download), record the result stage and console errors.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/22-universal-file-converter/live/'; const T = '/workspace/deep/22-universal-file-converter/testfiles/'; const URL = 'https://www.freedailypro.com/tool/universal-file-converter'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const R = { t: now() };
 for (const n of ['firefox', 'webkit']) { const b = await pw[n].launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(15000); const errs = []; p.on('pageerror', e => errs.push(String(e).slice(0, 150))); const r = {};
  try { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); r.start = JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
   for (const [f, tg] of [['data.csv', 'Excel'], ['photo.heic', 'JPG']]) { await p.locator('main input[type=file]').first().setInputFiles(T + f); await p.waitForTimeout(3000); await p.locator('main').getByRole('button', { name: tg, exact: true }).last().click();
    const ok = await p.getByText(/^Converted/).first().waitFor({ timeout: 45000 }).then(() => true).catch(() => false); r[f] = { ok, stage: (await p.locator('main').innerText()).match(/Converted[^\n]*\n?[^\n]*/)?.[0], toasts: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim())) };
    await p.screenshot({ path: OUT + `br-${n}-${f}.png` }); await p.getByRole('button', { name: /Start over/ }).first().click().catch(() => {}); await p.waitForTimeout(1500); }
  } catch (e) { r.err = String(e).slice(0, 200); } r.errs = errs; R[n] = r; await b.close(); }
 R.t2 = now(); fs.writeFileSync(OUT + 'browsers.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); })();
