// universal-file-converter Download gate: fresh contexts until one is at the cap and one has uses left (max 10). In each: drop small.jpg, convert to PDF (free), press the CONVERTED file's Download.
// At the cap: record the dialog, press Buy Day Pass, record the email prompt and stop (types nothing). With uses left: record cost of 1st and 2nd Download, filename, bytes vs the in-memory result, and the badge text in the PDF.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const crypto = require('crypto');
const OUT = '/workspace/deep/22-universal-file-converter/live/'; const T = '/workspace/deep/22-universal-file-converter/testfiles/'; const URL = 'https://www.freedailypro.com/tool/universal-file-converter'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const HOOK = fs.readFileSync(__dirname + '/uf-battery.js', 'utf8').match(/const HOOK = `([^`]*)`/)[1];
const sha = b => crypto.createHash('sha256').update(b).digest('hex').slice(0, 16);
(async () => { const b = await chromium.launch(); const R = { t: now(), tries: [] }; let gotCap = false, gotSpend = false;
 for (let i = 0; i < 10 && !(gotCap && gotSpend); i++) { const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); await c.addInitScript(HOOK); const p = await c.newPage(); p.setDefaultTimeout(12000);
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
  const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday; const u0 = await used(); const r = { i, t: now(), start: u0 };
  const cap = u0 >= 2; if ((cap && gotCap) || (!cap && gotSpend)) { R.tries.push(r); await c.close(); continue; }
  await p.locator('main input[type=file]').first().setInputFiles(T + 'small.jpg'); await p.waitForTimeout(3000);
  await p.locator('main').getByRole('button', { name: 'PDF', exact: true }).last().click(); await p.getByText(/^Converted/).first().waitFor({ timeout: 30000 }); await p.waitForTimeout(1500);
  const mem = Buffer.from(await p.evaluate(async () => { const x = window.__blobs.filter(o => o.b.type === 'application/pdf' || /\.pdf$/.test(o.name || '')).pop(); return x ? [...new Uint8Array(await x.b.arrayBuffer())] : []; }));
  r.memBytes = mem.length; r.memSha = sha(mem); r.afterConvert = await used();
  const dlBtns = p.locator('main').getByRole('button', { name: /^Download$/ }); r.dlButtons = await dlBtns.count();
  const press = async k => { const dl = p.waitForEvent('download', { timeout: 8000 }).catch(() => null); await dlBtns.last().click(); const d = await dl; await p.waitForTimeout(2000); const o = { after: await used() };
    const dg = p.locator('[role=dialog],[role=alertdialog]'); if (await dg.count()) o.dialog = (await dg.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500);
    if (d) { const f = OUT + `dl-${k}-${d.suggestedFilename()}`; await d.saveAs(f); const buf = fs.readFileSync(f); o.file = d.suggestedFilename(); o.bytes = buf.length; o.sha = sha(buf); o.sameAsMemory = o.sha === r.memSha; } return o; };
  r.dl1 = await press('1');
  if (cap) { gotCap = true; await p.screenshot({ path: OUT + 'cap-dialog.png' }); const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); const dg = p.locator('[role=dialog]'); r.dayPass = { dialog: (await dg.count()) ? (await dg.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 400) : null, emailField: await p.locator('input[type=email]').count(), url: p.url().slice(0, 80) }; await p.screenshot({ path: OUT + 'daypass-email.png' }); } }
  else { gotSpend = true; await p.keyboard.press('Escape'); r.dl2 = await press('2'); await p.screenshot({ path: OUT + 'spend-after.png' }); }
  R.tries.push(r); fs.writeFileSync(OUT + 'dl-gate.json', JSON.stringify(R, null, 1)); await c.close(); }
 R.t2 = now(); fs.writeFileSync(OUT + 'dl-gate.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
