// universal-file-converter: starting count; keyboard to drop zone; axe; edit panel on a PDF stage (compression level names); Download / Save to Google Drive / Save to my cloud storage at the starting count
// (at 0: cap dialog -> Buy Day Pass -> email prompt; types nothing); Multiple files with 21 files (cap 20?) + buttons; phones. "Open from Google Drive" and "Take photo with camera" are not clicked.
const { chromium, devices } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/22-universal-file-converter/live/'; const T = '/workspace/deep/22-universal-file-converter/testfiles/'; const URL = 'https://www.freedailypro.com/tool/universal-file-converter';
const AXE = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8'); const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const axe = async p => { await p.addScriptTag({ content: AXE }); return p.evaluate(async () => (await axe.run(document.querySelector('main'), { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'best-practice'] }, resultTypes: ['violations'] })).violations.map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length, t: v.nodes.slice(0, 4).map(n => n.target.join(' ')) }))); };
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams)=[^&]*/g, '$1=REDACTED').slice(0, 160);
(async () => { const b = await chromium.launch(); const R = { t: now() };
 const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await c.newPage(); p.setDefaultTimeout(12000);
 await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 R.start = await used(); R.strip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]); R.axeIdle = await axe(p);
 let chooser = false; p.on('filechooser', () => { chooser = true; }); const seq = [];
 for (let i = 0; i < 60; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('role') || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50).replace(/\n/g, ' '); }); seq.push(a); if (/Drop a file/i.test(a)) { await p.keyboard.press('Enter'); await p.waitForTimeout(1200); seq.push('ENTER -> chooser=' + chooser); break; } }
 R.kbd = { tabs: seq.length, last: seq.slice(-3), chooser };
 await p.locator('main input[type=file]').first().setInputFiles(T + 'contract.pdf'); await p.waitForTimeout(3500);
 R.axeDrop = await axe(p);
 const ed = p.getByRole('button', { name: /^Edit "/ }).first(); if (await ed.count()) { await ed.click(); await p.waitForTimeout(800); R.editOptions = await p.evaluate(() => [...document.querySelectorAll('main button')].map(b => b.innerText.trim()).filter(x => /Resize|Crop|Rotate|Watermark|Page numbers|Compress|Password|Merge|Improve/.test(x)));
  const cb = p.locator('main').getByRole('button', { name: 'Compress', exact: true }); if (await cb.count()) { await cb.first().click(); await p.waitForTimeout(800); const combo = p.locator('main [role=combobox]').last(); await combo.click().catch(() => {}); await p.waitForTimeout(500); R.compressLevels = await p.getByRole('option').allInnerTexts().catch(() => []); await p.keyboard.press('Escape'); await p.screenshot({ path: OUT + 'edit-compress.png' }); } }
 await esc();
 const act = async (name, rx) => { const r = { before: await used() }; const loc = p.getByRole('button', { name: rx }).first(); if (!(await loc.count())) { r.missing = true; return r; }
   const pop = c.waitForEvent('page', { timeout: 5000 }).catch(() => null); const dl = p.waitForEvent('download', { timeout: 5000 }).catch(() => null); const url0 = p.url(); await loc.click(); const [pg, d] = await Promise.all([pop, dl]); await p.waitForTimeout(2000);
   r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null; r.download = d ? d.suggestedFilename() : null; if (pg) { r.popup = red(pg.url()); await pg.close(); }
   if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + '.png' });
   if (name === 'download' && r.dialog) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); r.dayPass = { dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); } }
   await esc(); if (r.url) { await p.goBack().catch(() => {}); await p.waitForTimeout(2500); } return r; };
 R.download = await act('download', /^Download$/);
 R.drive = await act('drive', /Save to Google Drive/);
 R.cloud = await act('cloud', /Save to my cloud storage/);
 R.liveRegions = await p.evaluate(() => [...document.querySelectorAll('main [aria-live],main [role=status],main [role=alert]')].map(e => ({ live: e.getAttribute('aria-live'), role: e.getAttribute('role'), text: e.innerText.slice(0, 80) })));
 R.end = await used(); await c.close();
 { const c3 = await b.newContext({ viewport: { width: 1366, height: 900 } }); const q = await c3.newPage(); q.setDefaultTimeout(12000); const r = {};
  try { await q.goto(URL, { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4500); r.used0 = JSON.parse(await q.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday; await q.getByRole('button', { name: 'Multiple files', exact: true }).click(); await q.waitForTimeout(800);
   const many = []; for (let i = 0; i < 21; i++) { const f = T + `m${i}.txt`; fs.writeFileSync(f, 'file ' + i + '\n'); many.push(f); }
   await q.locator('main input[type=file]').first().setInputFiles(many); await q.waitForTimeout(3000);
   r.toasts = await q.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim()));
   r.count = await q.evaluate(() => (document.querySelector('main').innerText.match(/m\d+\.txt/g) || []).length);
   r.buttons = await q.evaluate(() => [...document.querySelectorAll('main button')].map(b => b.innerText.trim()).filter(x => /Convert all|zip|Merge|Download|Clear|Stop/i.test(x) && x.length < 60));
   await q.screenshot({ path: OUT + 'multi-21.png', fullPage: false }); many.forEach(f => fs.unlinkSync(f)); } catch (e) { r.err = String(e).slice(0, 200); }
  R.multi = r; await c3.close(); }
 for (const [nm, d] of [['iphone-se', devices['iPhone SE']], ['pixel-7', devices['Pixel 7']]]) { const { defaultBrowserType, ...dd } = d; const c2 = await b.newContext(dd); const q = await c2.newPage(); q.setDefaultTimeout(12000);
  await q.goto(URL, { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4000); await q.locator('main input[type=file]').first().setInputFiles(T + 'data.csv'); await q.waitForTimeout(3000);
  await q.locator('main').getByRole('button', { name: 'Excel', exact: true }).last().tap().catch(() => {}); await q.waitForTimeout(4000);
  const lay = await q.evaluate(() => ({ vh: innerHeight, overflowX: document.documentElement.scrollWidth > innerWidth + 1, sw: document.documentElement.scrollWidth, conv: /Converted/.test(document.querySelector('main').innerText) }));
  await q.screenshot({ path: OUT + `layout-${nm}.png`, fullPage: true }); R[nm] = lay; await c2.close(); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate-kbd.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
