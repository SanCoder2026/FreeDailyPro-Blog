// universal-file-converter: OCR result text for ocr.png ("INVOICE 2026-117 / Total due: 1,234.50 USD") from the in-memory result (no Download).
const { chromium } = require('playwright'); const fs = require('fs');
const HOOK = '(() => { window.__blobs = []; const o = URL.createObjectURL; URL.createObjectURL = function (b) { try { if (b instanceof Blob) window.__blobs.push({ b, name: b.name || null, t: Date.now() }); } catch (e) {} return o.apply(this, arguments); }; })();'; // URL.createObjectURL hook: the Blob subclass hook used by uf-battery.js breaks the OCR worker (artifact), so this one only records blobs turned into URLs
(async () => { const b = await chromium.launch(); const c = await b.newContext(); await c.addInitScript(HOOK); const p = await c.newPage();
 await p.goto('https://www.freedailypro.com/tool/universal-file-converter', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 await p.locator('main input[type=file]').first().setInputFiles('/workspace/deep/22-universal-file-converter/testfiles/ocr.png'); await p.waitForTimeout(3000);
 await p.locator('main').getByRole('button', { name: 'Text (OCR)', exact: true }).last().click(); await p.getByText(/^Converted/).first().waitFor({ timeout: 60000 }); await p.waitForTimeout(1000);
 const t = await p.evaluate(async () => { const x = window.__blobs.filter(o => /text\/plain/.test(o.b.type) || /\.txt$/.test(o.name || '')).pop(); return x ? await x.b.text() : null; });
 fs.writeFileSync('/workspace/deep/22-universal-file-converter/live/ocr-result.txt', String(t)); console.log(JSON.stringify(t)); await b.close(); })();
