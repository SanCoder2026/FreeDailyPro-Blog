// universal-file-converter probe: starting count, controls after dropping small.jpg and after one conversion (PDF). Network requests recorded (host+path only). No use spent.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/22-universal-file-converter/live/'; const T = '/workspace/deep/22-universal-file-converter/testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(10000); const R = { t: now(), req: [] };
 p.on('request', r => { const u = new URL(r.url()); if (/freedailypro/.test(u.host)) R.req.push(r.method() + ' ' + u.pathname.slice(0, 80)); });
 await p.goto('https://www.freedailypro.com/tool/universal-file-converter', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 R.ls = await p.evaluate(() => localStorage.getItem('fdp-usage-v1')); R.strip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]);
 const btns = () => p.evaluate(() => [...document.querySelectorAll('main button, main [role=button], main a[download]')].map(e => (e.getAttribute('aria-label') ? '[' + e.getAttribute('aria-label') + '] ' : '') + (e.innerText || '').trim().replace(/\n/g, ' ').slice(0, 50)).filter(x => x && !/^(About|Common|Details|Guides|Share this|Create Shortcut|Subscribe|See File)/.test(x)));
 R.req0 = R.req.length;
 await p.locator('main input[type=file]').first().setInputFiles(T + 'small.jpg'); await p.waitForTimeout(3500);
 R.afterDrop = await btns(); R.textDrop = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 3000));
 await p.screenshot({ path: OUT + 'probe-drop.png', fullPage: true });
 const pdf = p.locator('main').getByRole('button', { name: 'PDF', exact: true }); if (await pdf.count()) { await pdf.first().click(); await p.waitForTimeout(4000); }
 R.afterConvert = await btns(); R.textConvert = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 4000));
 R.used = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 await p.screenshot({ path: OUT + 'probe-convert.png', fullPage: true }); R.reqAfter = R.req.slice(R.req0);
 fs.writeFileSync(OUT + 'probe.json', JSON.stringify(R, null, 1)); await b.close(); })();
