// universal-file-converter: the slow/silent cases. Fresh context per case; polls toasts + stage text every 500 ms, logs ALL requests (any host) and page errors, waits up to 120 s.
// Cases: ocr.png -> Text (OCR); letter.doc -> PDF; contract.pdf -> Excel; deck.pptx -> "PowerPoint .pptx (from old formats)"; broken.pptx -> PDF; page.html -> PDF (remote <img>?)
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/22-universal-file-converter/live/'; const T = '/workspace/deep/22-universal-file-converter/testfiles/'; const URL = 'https://www.freedailypro.com/tool/universal-file-converter'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const CASES = [['T1', 'ocr.png', 'Text (OCR)'], ['T2', 'letter.doc', 'PDF'], ['T3', 'contract.pdf', 'Excel'], ['T4', 'deck.pptx', 'PowerPoint .pptx (from old formats)'], ['T5', 'broken.pptx', 'PDF'], ['T6', 'page.html', 'PDF']];
(async () => { const b = await chromium.launch(); const R = { t: now(), cases: [] };
 for (const [id, f, tg] of CASES) { const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(12000); const r = { id, f, tg, t: now(), toasts: [], reqs: [], errs: [] };
  p.on('pageerror', e => r.errs.push(String(e).slice(0, 200))); p.on('console', m => { if (m.type() === 'error') r.errs.push('console: ' + m.text().slice(0, 200)); });
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
  p.on('request', q => { const u = q.url(); if (/googlesyndication|doubleclick|adservice|google-analytics|googletagmanager|media\.net|adtrafficquality/.test(u)) return; r.reqs.push(q.method() + ' ' + u.replace(/\?.*/, '').slice(0, 120) + (q.postData() ? ' post=' + q.postData().length : '')); });
  await p.locator('main input[type=file]').first().setInputFiles(T + f); await p.waitForTimeout(3000); const t0 = Date.now();
  await p.locator('main').getByRole('button', { name: tg, exact: true }).last().click();
  for (let i = 0; i < 240; i++) { const s = await p.evaluate(() => ({ toasts: [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim().replace(/\n/g, ' / ')), conv: (document.querySelector('main').innerText.match(/Converted\n+[^\n]+/) || [null])[0], prog: (document.querySelector('main').innerText.match(/[^\n]*(Reading|Recogni|Loading|Working|Converting|%)[^\n]*/) || [null])[0] }));
   s.toasts.forEach(x => { if (!r.toasts.includes(x)) r.toasts.push(x); }); if (s.prog && r.lastProg !== s.prog) { r.lastProg = s.prog; (r.progs = r.progs || []).push(((Date.now() - t0) / 1000).toFixed(1) + 's ' + s.prog.slice(0, 80)); }
   if (s.conv) { r.converted = s.conv.replace(/\n+/g, ' '); r.ms = Date.now() - t0; break; } if (s.toasts.length && i > 6) { r.ms = Date.now() - t0; break; } await p.waitForTimeout(500); }
  if (!r.ms) r.ms = 'timeout ' + (Date.now() - t0);
  if (id === 'T1' && r.converted) r.ocrText = await p.evaluate(() => document.querySelector('main').innerText.match(/INVOICE[\s\S]{0,60}/)?.[0] || null);
  await p.screenshot({ path: OUT + `toast-${id}.png` }); R.cases.push(r); fs.writeFileSync(OUT + 'toasts.json', JSON.stringify(R, null, 1)); await c.close(); }
 R.t2 = now(); fs.writeFileSync(OUT + 'toasts.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
