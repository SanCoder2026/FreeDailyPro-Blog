import { j as e, r as b } from "./vendor-react-D01g8YgM.js";
import { T as at, F as st, P as rt, D as ot } from "./ToolPage-DS5jbfzr.js";
import {
  N as it,
  B as G,
  I as nt,
  ax as lt,
  f as ct,
  ay as dt,
} from "./index-D2ZT81un.js";
import { C as Z } from "./card-D0VH8Tdy.js";
import { T as ht } from "./ToolInfoSection-M0kcUBq8.js";
import { f as gt } from "./formatFileSize-B-JRDfN5.js";
import { p as $ } from "./plural-FIChqbp4.js";
import { u as pt } from "./useRunToken-sJpsnYiZ.js";
import { e as ut, r as mt, l as ft } from "./utils-s8ucLyj8.js";
import { g as Pt, q as wt } from "./operations-DhLfXHFN.js";
import { m as xt, b as bt, a as Q } from "./pdfMetadata-CcxIhQF2.js";
import { Packer as yt } from "./index-CHifq31M.js";
import { s as E } from "./index-DQo6ttmA.js";
import { p as q, o as kt, b as vt } from "./ocrBlocks-CqBbJ5zn.js";
import { l as jt } from "./pdfLayout-BswErtWz.js";
import { r as Ct } from "./pdfPageContent-BLgAwNtO.js";
import { preprocessForOcr as Nt } from "./ocrImage-CmXFNUud.js";
import {
  allowsDevanagari as Ft,
  needsSecondReading as St,
  readingScore as X,
  ocrParagraphs as Rt,
  OCR_LANGUAGES as Tt,
} from "./ocrText-C_9cxcFa.js";
import { T as $t } from "./ToolSteps-DtiMymsE.js";
import { u as Dt } from "./useDownloadedResult-C1FfMpBH.js";
import { I as Wt } from "./info-BGlOhDp4.js";
import "./useUploadApi-CeBVbB2U.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-mA9gIB_c.js";
import "./share-2-wJ7OG3q6.js";
import "./copy-DxyF2bO9.js";
import "./workflowCta-QcLjv4ms.js";
import "./UsageAndUpgradeStrip-Ckl_cEoN.js";
import "./access-BBg1iIm1.js";
import "./useAdminAccess-D2xxeUJv.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-BaZhqv4P.js";
import "./map-pin-DiPhQKiV.js";
import "./FaqSection-DgbFc-d2.js";
import "./ToolVideoEmbed-DltoCXpM.js";
import "./GuideLinks-BsEl-oB0.js";
import "./blog-Cqpj3gtZ.js";
import "./productCards-CAZfINO_.js";
import "./layers-B7zHnkyf.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-CmqWEytu.js";
import "./chevron-up-Bx33pgGu.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./pageView-BQIwVYOi.js";
import "./formAppearance-CdNbuISd.js";
import "./drawTextAnywhere-DcuP6lHH.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./imageRecompress-eXQFDUm-.js";
import "./textDiff-DxE9AzvO.js";
import "./utils-BCX55KBw.js";
import "./decode-D7I8Qajh.js";
import "./formFill-Dg9Myfyq.js";
import "./redactSearch-DQpyyh_t.js";
import "./nameDetect-DvHCRM0m.js";
class I extends Error {
  constructor() {
    super("cancelled");
  }
}
const Ot = 40,
  Y = async (a) => new Uint8Array(await a.arrayBuffer());
function tt(a) {
  let n = 0,
    i = 0;
  const s = (l) => l.forEach((m) => m.link && i++);
  for (const l of a)
    l.kind === "table"
      ? (n++, l.rows.forEach((m) => m.forEach((y) => s(y.runs))))
      : s(l.runs);
  return { tables: n, links: i };
}
function Mt(a) {
  return Array.from(new Set(a))
    .sort((n, i) => n - i)
    .map((n) => n + 1);
}
function At(a, n) {
  return {
    numPages: n.length,
    getPage: (i) => a.getPage(n[i - 1]),
    getMetadata: () => a.getMetadata(),
    destroy: () => a.destroy?.(),
  };
}
async function Et(a, n, i) {
  const s = () => {
      if (!i.isCurrent()) throw new I();
    },
    l = a.numPages,
    m = [],
    y = [],
    w = [];
  let d = 0,
    v = 0,
    F = 0,
    x = 0,
    u = null;
  try {
    const O = await a.getMetadata().catch(() => null);
    s();
    for (let r = 0; r < l; r++) {
      (i.status(`Reading page ${r + 1} of ${l}…`), i.progress(r / (l * 2)));
      const f = await a.getPage(r + 1);
      s();
      const t = await Ct(f);
      s();
      let c = [];
      const g = await ut(f).catch(
        (p) => (
          console.warn("Couldn't read the pictures on page", r + 1, p),
          { images: [], failed: 1 }
        ),
      );
      (s(), (d += g.failed));
      for (const p of g.images) {
        if (p.coversPage && t.hasText) {
          F++;
          continue;
        }
        (p.fromRender && v++,
          c.push({
            kind: "image",
            data: await Y(p.blob),
            type: p.type,
            widthPt: p.position.widthPt,
            heightPt: p.position.heightPt,
            topPt: p.position.topPt,
            leftPt: p.position.xPt,
            rightPt: p.position.xPt + p.position.widthPt,
            description: `Picture from page ${r + 1} of the PDF`,
          }),
          s());
      }
      (t.annotationsFailed && x++, m.push(t), y.push(c));
    }
    const C = jt(
        m,
        y.map((r) =>
          r.map((f) => ({
            left: f.leftPt,
            right: f.rightPt,
            top: f.topPt,
            bottom: f.topPt + f.heightPt,
          })),
        ),
      ),
      k = [],
      P = [];
    let S = 0,
      h = 0,
      R = 0,
      j = 0,
      N = 0,
      D = 0;
    for (let r = 0; r < l; r++) {
      const f = m[r],
        t = C.pages[r];
      if (((D += f.items.filter((o) => o.synthetic).length), f.hasText)) {
        const o = q(t.blocks, y[r]),
          W = tt(t.blocks);
        ((S += W.tables),
          (h += W.links),
          (R += y[r].length),
          k.push({
            widthPt: t.widthPt,
            heightPt: t.heightPt,
            marginsPt: t.marginsPt,
            blocks: o,
          }),
          P.length < 2 &&
            P.push({
              widthPt: t.widthPt,
              heightPt: t.heightPt,
              blocks: o.map((A) =>
                A.kind === "image"
                  ? { kind: "image", widthPt: A.widthPt, heightPt: A.heightPt }
                  : A,
              ),
            }));
        continue;
      }
      const c = y[r],
        g = t.widthPt * t.heightPt;
      if (
        !c.some((o) => o.widthPt * o.heightPt >= 0.5 * g) &&
        c.length > 0 &&
        !f.items.some((o) => o.synthetic)
      ) {
        ((R += c.length),
          k.push({
            widthPt: t.widthPt,
            heightPt: t.heightPt,
            marginsPt: { top: 36, right: 36, bottom: 36, left: 36 },
            blocks: q([], c),
          }),
          P.length < 2 &&
            P.push({
              widthPt: t.widthPt,
              heightPt: t.heightPt,
              blocks: c.map((o) => ({
                kind: "image",
                widthPt: o.widthPt,
                heightPt: o.heightPt,
              })),
              note: "Pictures only on this page.",
            }));
        continue;
      }
      if (f.items.some((o) => o.synthetic)) {
        const o = tt(t.blocks);
        ((S += o.tables),
          k.push({
            widthPt: t.widthPt,
            heightPt: t.heightPt,
            marginsPt: t.marginsPt,
            blocks: q(t.blocks, c),
          }));
        continue;
      }
      const T = await a.getPage(r + 1);
      if ((s(), !u)) {
        i.status("Starting OCR (first use downloads the language data)…");
        try {
          u = await E.createWorker(n.ocrLanguage, 1);
        } catch (o) {
          throw i.isCurrent()
            ? (console.error("OCR engine failed to start", o),
              new Error(
                "The OCR engine couldn't start. It downloads its language data the first time it is used, so it needs an internet connection; check yours and try again.",
              ))
            : new I();
        }
        if (!i.isCurrent())
          throw (await u.terminate().catch(() => {}), (u = null), new I());
        (i.registerWorker(u),
          await u.setParameters({ tessedit_pageseg_mode: E.PSM.AUTO }),
          s());
      }
      (i.status(`Reading page ${r + 1} of ${l} with OCR…`),
        i.progress(0.5 + r / (l * 2)));
      const _ = c
          .filter((o) => o.widthPt * o.heightPt >= 0.5 * g)
          .sort((o, W) => W.widthPt * W.heightPt - o.widthPt * o.heightPt)[0],
        z = _
          ? new Blob([_.data], {
              type: _.type === "jpg" ? "image/jpeg" : "image/png",
            })
          : await mt(T, 3, 0.92);
      s();
      const J = await Nt(z);
      s();
      const U = Ft(n.ocrLanguage);
      let M = (await u.recognize(J, {}, { text: !0, blocks: !0 })).data;
      if ((s(), St(M, U))) {
        (i.status(`Reading page ${r + 1} of ${l} again as one block of text…`),
          await u.setParameters({ tessedit_pageseg_mode: E.PSM.SINGLE_BLOCK }),
          s());
        const o = (await u.recognize(J, {}, { text: !0, blocks: !0 })).data;
        (s(),
          await u.setParameters({ tessedit_pageseg_mode: E.PSM.AUTO }),
          s(),
          X(o, U) > X(M, U) && (M = o));
      }
      const K = Rt(M);
      if (K.join("").replace(/\s/g, "").length >= Ot) {
        j++;
        const o = kt(K);
        (k.push({
          widthPt: t.widthPt,
          heightPt: t.heightPt,
          marginsPt: { top: 72, right: 72, bottom: 72, left: 72 },
          blocks: o,
        }),
          P.length < 2 &&
            P.push({
              widthPt: t.widthPt,
              heightPt: t.heightPt,
              blocks: o,
              note: "Read with OCR.",
            }));
      } else {
        N++;
        const o = {
          kind: "image",
          data: await Y(z),
          type: z.type === "image/png" ? "png" : "jpg",
          widthPt: t.widthPt - 72,
          heightPt: ((t.widthPt - 72) * t.heightPt) / t.widthPt,
          topPt: 36,
          leftPt: 36,
          rightPt: t.widthPt - 36,
          description: `Page ${r + 1} of the PDF, kept as a picture`,
        };
        (s(),
          k.push({
            widthPt: t.widthPt,
            heightPt: t.heightPt,
            marginsPt: { top: 36, right: 36, bottom: 36, left: 36 },
            blocks: [o],
          }),
          P.length < 2 &&
            P.push({
              widthPt: t.widthPt,
              heightPt: t.heightPt,
              blocks: [
                { kind: "image", widthPt: o.widthPt, heightPt: o.heightPt },
              ],
              note: "No readable text; kept as a picture.",
            }));
      }
    }
    if (!k.some((r) => r.blocks.length > 0)) return null;
    (x > 0 &&
      w.push(
        `Links and form-field values could not be read on ${x} ${x === 1 ? "page" : "pages"}; the text itself was converted.`,
      ),
      d > 0 &&
        w.push(
          `${d} ${d === 1 ? "picture" : "pictures"} could not be included.`,
        ),
      v > 0 &&
        w.push(
          `${v} ${v === 1 ? "picture was" : "pictures were"} captured as drawn on the page (rotated or unusual pictures), so any text on top of it is part of the picture.`,
        ),
      F > 0 &&
        w.push(
          `${F} ${F === 1 ? "page has" : "pages have"} a scan behind its text; the text was used and the scan picture left out.`,
        ),
      N > 0 &&
        w.push(
          `${N} ${N === 1 ? "page" : "pages"} had no readable text and ${N === 1 ? "is" : "are"} kept as a picture.`,
        ),
      i.status("Building the Word document…"),
      i.progress(0.95));
    const B = vt({
        pages: k,
        header: C.header,
        footer: C.footer,
        title: bt(O?.info?.Title) ?? n.fallbackTitle,
        author: xt(O?.info?.Author),
      }),
      L = await yt.toBlob(B);
    return (
      s(),
      {
        blob: L,
        preview: P,
        summary: {
          pages: l,
          tables: S,
          images: R,
          ocrPages: j,
          pictureOnlyPages: N,
          formValues: D,
          links: h,
          warnings: w,
        },
      }
    );
  } finally {
    if (u) {
      i.registerWorker(null);
      try {
        await u.terminate();
      } catch {}
    }
  }
}
function It({ run: a }) {
  const n = {
    fontWeight: a.bold ? 700 : void 0,
    fontStyle: a.italic ? "italic" : void 0,
    color: a.color ? `#${a.color}` : a.link ? "#0563C1" : void 0,
    textDecoration: a.link ? "underline" : void 0,
    fontSize: `${Math.max(7, Math.min(40, a.sizePt))}pt`,
  };
  return e.jsx("span", {
    style: n,
    children: a.field
      ? a.field === "PAGE"
        ? "1"
        : "N"
      : a.text.replace(/\t/g, "    "),
  });
}
function et({ runs: a }) {
  return e.jsx(e.Fragment, {
    children: a.map((n, i) => e.jsx(It, { run: n }, i)),
  });
}
function Bt({ pages: a }) {
  return e.jsx("div", {
    className: "space-y-3",
    "aria-label": "Preview of the converted document",
    children: a.map((n, i) =>
      e.jsxs(
        "div",
        {
          className:
            "rounded-md border bg-white text-black p-4 overflow-x-auto",
          children: [
            e.jsxs("p", {
              className:
                "text-[10px] uppercase tracking-wide text-gray-500 mb-2",
              children: ["Page ", i + 1],
            }),
            n.note &&
              e.jsx("p", {
                className: "text-xs text-gray-600 italic",
                children: n.note,
              }),
            n.blocks.map((s, l) =>
              s.kind === "paragraph"
                ? e.jsxs(
                    "p",
                    {
                      style: {
                        textAlign: s.align,
                        marginLeft: s.indentPt
                          ? Math.min(s.indentPt, 120)
                          : void 0,
                        marginBottom: Math.max(2, Math.min(14, s.spaceAfterPt)),
                      },
                      className: s.bullet ? "pl-5 relative" : void 0,
                      children: [
                        s.bullet &&
                          e.jsx("span", {
                            className: "absolute left-1",
                            children: "•",
                          }),
                        e.jsx(et, { runs: s.runs }),
                      ],
                    },
                    l,
                  )
                : s.kind === "table"
                  ? e.jsx(
                      "table",
                      {
                        className: "border-collapse my-2 text-[10pt]",
                        children: e.jsx("tbody", {
                          children: s.rows.map((m, y) =>
                            e.jsx(
                              "tr",
                              {
                                children: m.map((w, d) =>
                                  e.jsx(
                                    "td",
                                    {
                                      className:
                                        "border border-gray-300 px-1.5 py-0.5 align-top",
                                      style: { textAlign: s.colAlign[d] },
                                      children: e.jsx(et, { runs: w.runs }),
                                    },
                                    d,
                                  ),
                                ),
                              },
                              y,
                            ),
                          ),
                        }),
                      },
                      l,
                    )
                  : e.jsx(
                      "div",
                      {
                        className:
                          "my-2 flex items-center justify-center rounded bg-gray-100 text-xs text-gray-500",
                        style: {
                          height: Math.min(160, Math.max(30, s.heightPt * 0.4)),
                          maxWidth: Math.max(60, s.widthPt * 0.8),
                        },
                        children: "picture",
                      },
                      l,
                    ),
            ),
          ],
        },
        i,
      ),
    ),
  });
}
const V = {
  what: "Converts a PDF into an editable Microsoft Word (.docx) document. Paragraphs stay paragraphs, with the real font size, bold, italic and colour; bullet lists become Word lists; text in two or three columns is read column by column; tables are rebuilt as real Word tables (numbers stay in their own columns); pictures are placed where they were; web links stay clickable; filled-in form fields (names, ticked boxes) are written out; running headers and page numbers go into the Word header and footer; and each page keeps its own size, so Letter, A4 and landscape pages come out the right shape. Pages that are scans or photos with no selectable text are read with OCR page by page, so a scanned page inside an otherwise normal PDF is not left blank.",
  how: "Drop your PDF, choose the language of any scanned pages if it isn't English, optionally type the pages you want (like 1-3,6; empty means all), and click Convert to Word. When it finishes you get a short summary (pages, tables, pictures, anything that could not be included), a preview of the first pages, and the .docx to download. Everything runs in your browser; the file is not uploaded.",
  tip: "The result is a normal Word document whose text reflows as you edit; it is not a pixel-exact copy of the PDF page, so small spacing and line-break differences are expected. Check anything important in the preview or in Word. Scanned pages are read with OCR, which is slower (several seconds a page, and the first scan downloads the language data) and can misread poor scans; pick the right language first, because the wrong language gives wrong characters. Numbered lists keep their numbers as typed text. Text that sits on top of a picture in the PDF stays part of the picture when the picture itself is rotated or unusual. Text in colour patterns or special colour spaces comes out in the default colour rather than a wrong one.",
};
function Je() {
  const [a, n] = b.useState(null),
    [i, s] = b.useState(!1),
    [l, m] = b.useState(""),
    [y, w] = b.useState(0),
    [d, v] = b.useState(null),
    [F, x] = b.useState(""),
    [u, O] = b.useState("eng"),
    [C, k] = b.useState(0),
    [P, S] = b.useState(""),
    h = pt(),
    R = b.useRef(null),
    j = b.useCallback(() => {
      const t = R.current;
      ((R.current = null), t && t.terminate().catch(() => {}));
    }, []);
  b.useEffect(
    () => () => {
      (h.cancel(), j());
    },
    [h, j],
  );
  const N = b.useCallback(
      (t) => {
        (h.cancel(),
          j(),
          s(!1),
          n(t[0] || null),
          v(null),
          x(""),
          S(""),
          k(0),
          t[0] &&
            Pt(t[0])
              .then(k)
              .catch(() => {}));
      },
      [h, j],
    ),
    D = () => {
      (h.cancel(),
        j(),
        s(!1),
        n(null),
        v(null),
        x(""),
        S(""),
        k(0),
        w(0),
        m(""));
    },
    H = () => {
      (h.cancel(), j(), s(!1), m(""), w(0));
    },
    B = async () => {
      if (!a) return;
      let t = null;
      if (P.trim()) {
        if (!C) {
          x(
            "Still reading the page count. Wait a moment and try again, or clear the page range.",
          );
          return;
        }
        const g = wt(P, C);
        if ("error" in g) {
          x(`Pages to convert: ${g.error}`);
          return;
        }
        t = Mt(g.pages);
      }
      const c = h.start();
      (s(!0), v(null), x(""), w(0), m("Opening the PDF…"));
      try {
        const g = await ft(a);
        if (!h.isCurrent(c)) return;
        const p = await Et(
          t ? At(g, t) : g,
          { ocrLanguage: u, fallbackTitle: Q(a.name) },
          {
            isCurrent: () => h.isCurrent(c),
            status: (T) => h.isCurrent(c) && m(T),
            progress: (T) => h.isCurrent(c) && w(T),
            registerWorker: (T) => {
              h.isCurrent(c) && (R.current = T);
            },
          },
        );
        if (!h.isCurrent(c)) return;
        if (!p) {
          x(
            "No readable text or pictures were found on any page, even with OCR. The PDF may be blank, too low in quality to read, or in a different language than the one selected.",
          );
          return;
        }
        (v({ ...p, forFile: a.name }),
          ct.success("PDF converted to Word"),
          dt("pdf-to-word", "pdf-tools"));
      } catch (g) {
        if (g instanceof I || !h.isCurrent(c)) return;
        console.error(g);
        const p = g instanceof Error ? g.message : String(g);
        x(`Conversion failed: ${p}`);
      } finally {
        h.isCurrent(c) && (s(!1), m(""));
      }
    },
    L = Dt(d),
    r = d?.summary,
    f = r
      ? [
          $(r.pages, "page"),
          r.tables ? $(r.tables, "table") : null,
          r.images ? $(r.images, "picture") : null,
          r.links ? $(r.links, "link") : null,
          r.formValues ? $(r.formValues, "form field value") : null,
          r.ocrPages ? `${$(r.ocrPages, "page")} read with OCR` : null,
        ].filter(Boolean)
      : [];
  return e.jsxs(at, {
    children: [
      e.jsx($t, {
        toolId: "pdf-to-word",
        state: {
          hasFile: !!a,
          optionsChosen: u !== "eng" || P.trim() !== "",
          processing: i,
          resultReady: !!d && !i,
          downloaded: L,
        },
      }),
      a
        ? e.jsxs("div", {
            className: "space-y-4",
            children: [
              e.jsxs("div", {
                className: "p-4 rounded-lg border bg-card",
                children: [
                  e.jsx("p", {
                    className: "text-sm font-medium break-all",
                    children: a.name,
                  }),
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground mt-0.5",
                    children: gt(a.size),
                  }),
                ],
              }),
              i
                ? e.jsx("div", {
                    className: "space-y-2",
                    children: e.jsx(rt, {
                      message: l || "Working…",
                      onStop: H,
                      progress: y > 0 ? y * 100 : void 0,
                    }),
                  })
                : d
                  ? e.jsxs("div", {
                      className: "space-y-4",
                      children: [
                        e.jsxs(Z, {
                          className: "p-4 space-y-2",
                          "aria-live": "polite",
                          children: [
                            e.jsxs("p", {
                              className: "text-sm font-medium",
                              children: ["Converted: ", f.join(" · ")],
                            }),
                            r.warnings.map((t) =>
                              e.jsxs(
                                it,
                                {
                                  className: "text-xs flex gap-1.5",
                                  children: [
                                    e.jsx(Wt, {
                                      className: "h-3.5 w-3.5 shrink-0 mt-0.5",
                                    }),
                                    t,
                                  ],
                                },
                                t,
                              ),
                            ),
                          ],
                        }),
                        e.jsxs("div", {
                          className: "flex flex-wrap gap-3",
                          children: [
                            e.jsx(ot, {
                              blob: d.blob,
                              fileName: `${Q(d.forFile)}.docx`,
                              label: "Download Word File",
                            }),
                            e.jsx(G, {
                              variant: "outline",
                              onClick: D,
                              children: "Convert another",
                            }),
                          ],
                        }),
                        d.preview.length > 0 &&
                          e.jsxs("details", {
                            open: !0,
                            className: "rounded-lg border p-3",
                            children: [
                              e.jsxs("summary", {
                                className: "cursor-pointer text-sm font-medium",
                                children: [
                                  "Preview of the first ",
                                  d.preview.length === 1
                                    ? "page"
                                    : `${d.preview.length} pages`,
                                ],
                              }),
                              e.jsxs("div", {
                                className: "mt-3 max-h-[28rem] overflow-y-auto",
                                children: [
                                  e.jsx(Bt, { pages: d.preview }),
                                  e.jsx("p", {
                                    className:
                                      "text-xs text-muted-foreground mt-2",
                                    children:
                                      "A quick look at the text, styling and tables. Word lays the page out itself, so spacing will differ slightly.",
                                  }),
                                ],
                              }),
                            ],
                          }),
                      ],
                    })
                  : e.jsxs(e.Fragment, {
                      children: [
                        e.jsxs("div", {
                          className:
                            "flex flex-wrap items-center gap-2 text-sm",
                          children: [
                            e.jsx("label", {
                              htmlFor: "ocr-language",
                              className: "text-muted-foreground",
                              children:
                                "Language of scanned pages (only used for pages with no selectable text):",
                            }),
                            e.jsx("select", {
                              id: "ocr-language",
                              value: u,
                              onChange: (t) => O(t.target.value),
                              className:
                                "h-9 rounded-md border bg-background px-2 text-sm",
                              children: Tt.map((t) =>
                                e.jsx(
                                  "option",
                                  { value: t.id, children: t.label },
                                  t.id,
                                ),
                              ),
                            }),
                          ],
                        }),
                        e.jsxs("div", {
                          className:
                            "flex flex-wrap items-center gap-2 text-sm",
                          children: [
                            e.jsxs("label", {
                              htmlFor: "word-pages",
                              className: "text-muted-foreground",
                              children: [
                                "Pages to convert",
                                C ? ` (the PDF has ${C})` : "",
                                ":",
                              ],
                            }),
                            e.jsx(nt, {
                              id: "word-pages",
                              value: P,
                              onChange: (t) => {
                                (S(t.target.value), x(""));
                              },
                              placeholder: "All pages, or like 1-3,6",
                              className: "h-9 w-48",
                              "data-testid": "word-pages",
                            }),
                          ],
                        }),
                        F &&
                          e.jsx(Z, {
                            className:
                              "p-3 border-red-300 bg-red-50 dark:bg-red-950/30",
                            role: "alert",
                            children: e.jsxs("div", {
                              className: "flex gap-2",
                              children: [
                                e.jsx(lt, {
                                  className:
                                    "h-4 w-4 text-red-600 shrink-0 mt-0.5",
                                }),
                                e.jsx("p", {
                                  className:
                                    "text-sm text-red-800 dark:text-red-300",
                                  children: F,
                                }),
                              ],
                            }),
                          }),
                        e.jsxs("div", {
                          className: "flex gap-3",
                          children: [
                            e.jsx(G, {
                              onClick: B,
                              children: "Convert to Word",
                            }),
                            e.jsx(G, {
                              variant: "outline",
                              onClick: D,
                              children: "Reset",
                            }),
                          ],
                        }),
                      ],
                    }),
            ],
          })
        : e.jsx(st, {
            gateAtDownload: !0,
            accept: ".pdf",
            onFiles: N,
            label: "Drop a PDF to convert to Word",
            description:
              "Extracts real, editable text — processed entirely in your browser",
          }),
      e.jsx(ht, { whatIsIt: V.what, howToUse: V.how, tip: V.tip }),
    ],
  });
}
export { Je as default };
//# sourceMappingURL=PdfToWord-BRvpB3Rt.js.map
