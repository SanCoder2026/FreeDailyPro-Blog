import {
  Table as N,
  Header as O,
  Footer as X,
  PageOrientation as U,
  Document as V,
  Paragraph as P,
  AlignmentType as M,
  BorderStyle as W,
  TableLayoutType as $,
  WidthType as A,
  TableRow as K,
  TableCell as Y,
  VerticalAlign as Z,
  ImageRun as j,
  TextRun as B,
  Tab as S,
  PageNumber as R,
  ExternalHyperlink as q,
  TabStopType as T,
} from "./index-CHifq31M.js";
const c = (t) => Math.max(0, Math.round(t * 20)),
  D = 96 / 72,
  J = /[ऀ-ॿ]/,
  Q = new RegExp(
    "[\\uE000-\\uF8FF\\u{F0000}-\\u{FFFFD}\\u{100000}-\\u{10FFFD}]",
    "gu",
  ),
  tt = /[\u0000-\u0008\u000B\u000C\u000E-\u001F￾￿]/g;
function et(t) {
  const n = t.replace(Q, "•").replace(tt, "");
  return { text: n, font: J.test(n) ? "Nirmala UI" : void 0 };
}
const E = (t) => (t && /^[0-9a-f]{6}$/i.test(t) ? t.toUpperCase() : void 0);
function I(t, n, e) {
  const i = et(n),
    o = i.text.split("	"),
    a = [];
  return (
    o.forEach((r, s) => {
      (s > 0 && a.push(new S()), r && a.push(r));
    }),
    new B({
      children: a,
      bold: t.bold || void 0,
      italics: t.italic || void 0,
      size: Math.max(2, Math.round(t.sizePt * 2)),
      color: e?.color ?? E(t.color),
      font: i.font ?? t.font,
      underline: e?.underline ? {} : void 0,
    })
  );
}
function k(t) {
  const n = [];
  for (const e of t)
    e.field
      ? n.push(
          new B({
            children: [e.field === "PAGE" ? R.CURRENT : R.TOTAL_PAGES],
            bold: e.bold || void 0,
            italics: e.italic || void 0,
            size: Math.max(2, Math.round(e.sizePt * 2)),
            color: E(e.color),
            font: e.font,
          }),
        )
      : e.link
        ? n.push(
            new q({
              link: e.link,
              children: [
                I(e, e.text, { color: E(e.color) ?? "0563C1", underline: !0 }),
              ],
            }),
          )
        : e.text && n.push(I(e, e.text));
  return n;
}
const v = { left: M.LEFT, center: M.CENTER, right: M.RIGHT };
function nt(t, n = {}) {
  return new P({
    children: k(t.runs),
    alignment: t.align ? v[t.align] : void 0,
    indent: t.indentPt > 0 ? { left: c(t.indentPt) } : void 0,
    bullet: t.bullet ? { level: t.bullet.level } : void 0,
    spacing: { after: c(t.spaceAfterPt) },
    pageBreakBefore: n.pageBreakBefore || void 0,
  });
}
const p = { style: W.SINGLE, size: 4, color: "BFBFBF" };
function ot(t, n) {
  const e = t.colWidthsPt.map(c),
    i = e.reduce((r, s) => r + s, 0) || 1,
    o = Math.min(1, n / i),
    a = e.map((r) => Math.max(240, Math.round(r * o)));
  return new N({
    width: { size: a.reduce((r, s) => r + s, 0), type: A.DXA },
    columnWidths: a,
    layout: $.FIXED,
    borders: {
      top: p,
      bottom: p,
      left: p,
      right: p,
      insideHorizontal: p,
      insideVertical: p,
    },
    rows: t.rows.map(
      (r) =>
        new K({
          cantSplit: !0,
          children: r.map(
            (s, l) =>
              new Y({
                width: { size: a[l], type: A.DXA },
                verticalAlign: Z.TOP,
                children: [
                  new P({
                    children: k(s.runs),
                    alignment: v[t.colAlign[l] ?? "left"],
                  }),
                ],
              }),
          ),
        }),
    ),
  });
}
function it(t, n, e, i = {}) {
  const o = Math.min(1, e / Math.max(1, t.widthPt)),
    a = Math.max(1, Math.round(t.widthPt * o * D)),
    r = Math.max(1, Math.round(t.heightPt * o * D)),
    s = Math.abs((t.leftPt + t.rightPt) / 2 - n / 2) < 12 && t.leftPt > 24;
  return new P({
    alignment: s ? M.CENTER : void 0,
    pageBreakBefore: i.pageBreakBefore || void 0,
    children: [
      new j({
        type: t.type,
        data: t.data,
        transformation: { width: a, height: r },
        altText: {
          name: "Image",
          description: t.description,
          title: t.description,
        },
      }),
    ],
  });
}
const w = (t = !1) =>
  new P({
    run: { size: 2 },
    spacing: { before: 0, after: 80, line: 20 },
    pageBreakBefore: t || void 0,
  });
function z(t, n) {
  const e = [],
    i = [],
    o = t.parts;
  return (
    o.length === 2 && i.push({ type: T.RIGHT, position: n }),
    o.length === 3 &&
      (i.push({ type: T.CENTER, position: Math.round(n / 2) }),
      i.push({ type: T.RIGHT, position: n })),
    o.forEach((a, r) => {
      (r > 0 && e.push(new B({ children: [new S()] })), e.push(...k(a)));
    }),
    new P({
      children: e,
      alignment: o.length === 1 ? v[t.align] : void 0,
      tabStops: i.length ? i : void 0,
    })
  );
}
const C = (t) => `${Math.round(t.widthPt / 2)}x${Math.round(t.heightPt / 2)}`;
function st(t, n) {
  const e = [...t],
    i = [...n].sort((o, a) => o.topPt - a.topPt);
  for (const o of i) {
    const a = (l) =>
      Math.min(l.rightPt, o.rightPt) - Math.max(l.leftPt, o.leftPt) >=
      0.3 * Math.min(l.rightPt - l.leftPt, o.rightPt - o.leftPt);
    let r = -1,
      s = -1;
    for (let l = 0; l < e.length; l++) {
      const f = e[l];
      if (a(f) && ((s = l), f.topPt > o.topPt)) {
        r = l;
        break;
      }
    }
    (r < 0 &&
      (s >= 0
        ? (r = s + 1)
        : ((r = e.findIndex((l) => l.topPt > o.topPt)),
          r < 0 && (r = e.length))),
      e.splice(r, 0, o));
  }
  return e;
}
const x = (t) => [...t].sort((n, e) => n - e)[Math.floor(t.length / 2)] ?? 0;
function lt(t) {
  const n = [];
  for (const i of t.pages) {
    const o = n[n.length - 1];
    o && C(o[0]) === C(i) ? o.push(i) : n.push([i]);
  }
  const e = n.map((i, o) => {
    const a = i[0],
      r = a.widthPt > a.heightPt,
      s = {
        top: x(i.map((h) => h.marginsPt.top)),
        bottom: x(i.map((h) => h.marginsPt.bottom)),
        left: x(i.map((h) => h.marginsPt.left)),
        right: x(i.map((h) => h.marginsPt.right)),
      },
      l = Math.max(72, a.widthPt - s.left - s.right),
      f = c(l),
      d = [];
    (i.forEach((h, _) => {
      const y = _ > 0,
        u = h.blocks;
      if (!u.length) {
        d.push(w(y));
        return;
      }
      let m = y;
      u.forEach((g, F) => {
        const H = u[F + 1]?.kind === "table";
        (g.kind === "paragraph"
          ? d.push(nt(g, { pageBreakBefore: m }))
          : g.kind === "table"
            ? (m && d.push(w(!0)),
              d.push(ot(g, f)),
              (F === u.length - 1 || H || u[F + 1]?.kind === "image") &&
                d.push(w()))
            : d.push(it(g, h.widthPt, l, { pageBreakBefore: m })),
          (m = !1));
      });
    }),
      d[d.length - 1] instanceof N && d.push(w()));
    const G = t.header?.length
        ? { default: new O({ children: t.header.map((h) => z(h, f)) }) }
        : void 0,
      L = t.footer?.length
        ? { default: new X({ children: t.footer.map((h) => z(h, f)) }) }
        : void 0;
    return {
      headers: G,
      footers: L,
      properties: {
        page: {
          size: r
            ? {
                width: c(Math.min(a.widthPt, a.heightPt)),
                height: c(Math.max(a.widthPt, a.heightPt)),
                orientation: U.LANDSCAPE,
              }
            : { width: c(a.widthPt), height: c(a.heightPt) },
          margin: {
            top: c(s.top),
            bottom: c(s.bottom),
            left: c(s.left),
            right: c(s.right),
            header: 360,
            footer: 360,
          },
        },
      },
      children: d,
    };
  });
  return new V({
    creator: t.author || "FreeDailyPro",
    lastModifiedBy: "FreeDailyPro",
    title: t.title,
    description: "Converted from PDF with FreeDailyPro",
    sections: e,
  });
}
const b = 11;
function ht(t) {
  return t.map((n, e) => ({
    kind: "paragraph",
    runs: [{ text: n, bold: !1, italic: !1, sizePt: b }],
    topPt: e * 20,
    bottomPt: e * 20 + 12,
    leftPt: 72,
    rightPt: 540,
    indentPt: 0,
    spaceAfterPt: 8,
    sizePt: b,
  }));
}
export { lt as b, ht as o, st as p };
//# sourceMappingURL=ocrBlocks-CqBbJ5zn.js.map
