const D = /^[•●▪◦‣·■▫⁃∙-*\-–—]$/,
  J = /^(\d{1,3}[.)]|\(\d{1,3}\)|[a-zA-Z][.)]|\([a-zA-Z]\)|[ivxIVX]{1,5}[.)])$/,
  Q = /^([•●▪◦‣·■▫⁃∙-*]|[-–—])\s+(?=\S)/,
  tt = /^(\d{1,3}[.)]|\(\d{1,3}\)|[a-z][.)]|\([a-z]\))\s+(?=\S)/,
  et = (e) => Math.max(8, 0.8 * e),
  V = (e) => 0.15 * e;
function st(e) {
  let t = "",
    s = -1 / 0;
  for (const o of e) {
    const n = o.str.replace(/\s+/g, " ");
    (t &&
      s > -1 / 0 &&
      o.x - s > V(o.size) &&
      !/\s$/.test(t) &&
      !/^\s/.test(n) &&
      (t += " "),
      (t += n),
      (s = Math.max(s, o.x + o.width)));
  }
  return t.trim();
}
function nt(e) {
  const t = [...e].sort((s, o) => s.x - o.x);
  return {
    left: Math.min(...t.map((s) => s.x)),
    right: Math.max(...t.map((s) => s.x + s.width)),
    items: t,
    size: Math.max(...t.map((s) => s.size)),
    text: st(t),
  };
}
function W(e) {
  const t = [...e].sort((g, f) => g.x - f.x),
    s = [];
  let o = [],
    n = -1 / 0;
  for (const g of t)
    (o.length &&
      g.x - n > et(Math.max(g.size, o[o.length - 1].size)) &&
      (s.push(o), (o = []), (n = -1 / 0)),
      o.push(g),
      (n = Math.max(n, g.x + g.width)));
  o.length && s.push(o);
  const i = s.map(nt).filter((g) => g.text.length > 0),
    l = e.reduce((g, f) => (f.size > g.size ? f : g), e[0]);
  return {
    baseline: l.baseline,
    size: l.size,
    top: l.baseline - l.size * 0.8,
    segs: i,
  };
}
function ot(e) {
  const t = e.filter((i) => i.str.trim().length > 0),
    s = t
      .filter((i) => !i.rotated)
      .sort((i, l) => i.baseline - l.baseline || i.x - l.x),
    o = [];
  for (const i of s) {
    const l = o[o.length - 1],
      g = Math.min(5, Math.max(2, 0.35 * Math.max(i.size, l?.size ?? 0)));
    l && Math.abs(i.baseline - l.ref) <= g
      ? (l.items.push(i), (l.size = Math.max(l.size, i.size)))
      : o.push({ ref: i.baseline, size: i.size, items: [i] });
  }
  const n = o.map((i) => W(i.items));
  for (const i of t.filter((l) => l.rotated)) n.push(W([i]));
  n.sort((i, l) => i.baseline - l.baseline);
  for (const i of n) it(i);
  return n.filter((i) => i.segs.length > 0 || i.marker);
}
function it(e) {
  const t = e.segs[0];
  if (t)
    if (e.segs.length >= 2) {
      if (D.test(t.text)) {
        ((e.marker = { kind: "bullet", text: t.text, left: t.left }),
          e.segs.shift());
        return;
      }
      if (J.test(t.text)) {
        ((e.marker = { kind: "number", text: t.text, left: t.left }),
          e.segs.shift());
        return;
      }
    } else
      e.segs.length === 1 &&
        D.test(t.text) &&
        t.text.length === 1 &&
        /[•●▪◦‣⁃∙]/.test(t.text) &&
        ((e.marker = { kind: "bullet", text: t.text, left: t.left }),
        (e.segs = []));
}
const F = (e) =>
    e.segs.length
      ? Math.min(...e.segs.map((t) => t.left))
      : (e.marker?.left ?? 0),
  G = (e) =>
    e.segs.length
      ? Math.max(...e.segs.map((t) => t.right))
      : (e.marker?.left ?? 0),
  X = 20;
function rt(e) {
  const t = e.filter((m) => m.segs.length > 0);
  if (t.length < 6) return null;
  const s = Math.min(...t.map(F)),
    o = Math.max(...t.map(G)),
    n = o - s;
  if (n < 220) return null;
  const i = Math.ceil(s + 0.18 * n),
    l = Math.floor(o - 0.18 * n),
    g = [];
  for (let m = i; m <= l; m += 2) {
    let M = 0,
      R = 0,
      k = 0;
    for (const v of t) {
      let I = !1,
        N = !1,
        z = !1;
      for (const y of v.segs)
        y.left + 1 < m && y.right - 1 > m
          ? (I = !0)
          : y.right <= m + 1 && y.text.length >= X
            ? (N = !0)
            : y.left >= m - 1 && y.text.length >= X && (z = !0);
      (I && M++, N && R++, z && k++);
    }
    g.push({ x: m, cross: M, L: R, R: k });
  }
  const f = g
    .map((m) => ({ ...m, side: Math.min(m.L, m.R) }))
    .filter((m) => m.side >= 3 && m.cross <= 0.5 * m.side);
  if (!f.length) return null;
  f.sort((m, M) => M.side - 2 * M.cross - (m.side - 2 * m.cross));
  const a = f[0],
    p = (m) => {
      let M = 0;
      for (const R of t)
        R.segs.some((k) => k.left + 1 < m && k.right - 1 > m) && M++;
      return M;
    };
  let x = a.x,
    u = a.x;
  for (; x - 1 > s && p(x - 1) <= a.cross;) x--;
  for (; u + 1 < o && p(u + 1) <= a.cross;) u++;
  if (u - x < 10) return null;
  const h = (x + u) / 2,
    r = t.flatMap((m) => m.segs),
    c = r.filter((m) => m.right <= h + 1).map((m) => m.right),
    d = r.filter((m) => m.left >= h - 1).map((m) => m.left),
    b = c.length ? Math.max(...c.filter((m) => m <= u)) : x,
    P = d.length ? Math.min(...d.filter((m) => m >= x)) : u;
  return !Number.isFinite(b) || !Number.isFinite(P) || P - b < 10
    ? null
    : { left: b, right: P };
}
const lt = (e, t) => e.left < t.right - 0.01 && e.right > t.left + 0.01;
function Y(e, t, s) {
  const o = t.flatMap((i) => i.items),
    n = o.reduce((i, l) => (l.size > i.size ? l : i), o[0]);
  return {
    baseline: n.baseline,
    size: n.size,
    top: n.baseline - n.size * 0.8,
    segs: t,
    marker: s,
  };
}
function H(e, t = 0) {
  const s = t < 2 ? rt(e) : null;
  if (!s) return [e];
  const o = [];
  let n = [],
    i = [],
    l = [];
  const g = () => {
      (i.length && o.push(...H(i, t + 1)),
        l.length && o.push(...H(l, t + 1)),
        (i = []),
        (l = []));
    },
    f = () => {
      (n.length && o.push(n), (n = []));
    };
  for (const a of e) {
    if (a.segs.some((u) => lt(u, s))) {
      (g(), n.push(a));
      continue;
    }
    f();
    const p = a.segs.filter((u) => u.right <= s.left + 0.01),
      x = a.segs.filter((u) => u.left >= s.right - 0.01);
    (p.length
      ? i.push(Y(a, p, a.marker && a.marker.left <= s.left ? a.marker : void 0))
      : a.marker &&
        a.marker.left <= s.left &&
        !x.length &&
        i.push({ ...a, segs: [] }),
      x.length &&
        l.push(
          Y(a, x, a.marker && a.marker.left > s.left ? a.marker : void 0),
        ));
  }
  return (g(), f(), o.filter((a) => a.length > 0));
}
class at {
  constructor(t) {
    this.p = Array.from({ length: t }, (s, o) => o);
  }
  find(t) {
    for (; this.p[t] !== t;) ((this.p[t] = this.p[this.p[t]]), (t = this.p[t]));
    return t;
  }
  union(t, s) {
    this.p[this.find(t)] = this.find(s);
  }
}
function $(e, t) {
  const s = e.map((l, g) => [l, g]).sort((l, g) => l[0] - g[0]),
    o = [];
  let n = [],
    i = -1 / 0;
  for (const [l, g] of s)
    (n.length && l - i > t && (o.push(n), (n = [])), n.push(g), (i = l));
  return (n.length && o.push(n), o);
}
function ft(e) {
  const t = [];
  e.forEach((r, c) => r.segs.forEach((d) => t.push({ row: c, seg: d })));
  const s = new at(t.length);
  for (const r of $(
    t.map((c) => c.seg.left),
    2.5,
  ))
    for (let c = 1; c < r.length; c++) r.length >= 2 && s.union(r[0], r[c]);
  for (const r of $(
    t.map((c) => c.seg.right),
    2.5,
  ))
    for (let c = 1; c < r.length; c++) r.length >= 2 && s.union(r[0], r[c]);
  for (const r of $(
    t.map((c) => (c.seg.left + c.seg.right) / 2),
    2,
  ))
    if (r.length >= 3) for (let c = 1; c < r.length; c++) s.union(r[0], r[c]);
  const o = new Map();
  t.forEach((r, c) => {
    const d = s.find(c);
    (o.get(d) ?? o.set(d, []).get(d)).push(c);
  });
  const n = [],
    i = [];
  for (const r of Array.from(o.values()))
    r.length >= 2 ? n.push(r) : i.push(r[0]);
  const l = [],
    g = new Map(),
    f = (r) => ({
      left: Math.min(...r.map((c) => t[c].seg.left)),
      right: Math.max(...r.map((c) => t[c].seg.right)),
      members: r.map((c) => ({ row: t[c].row, seg: t[c].seg })),
      align: "left",
    });
  for (const r of n) {
    const c = l.length;
    (l.push(f(r)), r.forEach((d) => g.set(d, c)));
  }
  const a = (r, c) => l[r].members.some((d) => d.row === c);
  for (const r of i) {
    const { row: c, seg: d } = t[r];
    let b = -1,
      P = 1 / 0;
    (l.forEach((m, M) => {
      if (a(M, c)) return;
      const R = Math.min(d.right, m.right) - Math.max(d.left, m.left),
        k = R > 0 ? -R : Math.max(d.left - m.right, m.left - d.right);
      k < P && ((P = k), (b = M));
    }),
      b >= 0 && P < 40
        ? (l[b].members.push({ row: c, seg: d }),
          (l[b].left = Math.min(l[b].left, d.left)),
          (l[b].right = Math.max(l[b].right, d.right)),
          g.set(r, b))
        : (g.set(r, l.length), l.push(f([r]))));
  }
  const p = l
      .map((r, c) => [c, (r.left + r.right) / 2])
      .sort((r, c) => r[1] - c[1])
      .map((r) => r[0]),
    x = new Map();
  p.forEach((r, c) => x.set(r, c));
  const u = p.map((r) => l[r]),
    h = new Map();
  t.forEach((r, c) => h.set(r.seg, x.get(g.get(c))));
  for (const r of u) {
    const c = r.members.map((M) => M.seg.left),
      d = r.members.map((M) => M.seg.right),
      b = (M) => Math.max(...M) - Math.min(...M),
      P =
        r.members.filter((M) => Math.abs(M.seg.left - U(c)) <= 2.5).length /
        r.members.length;
    if (
      r.members.filter((M) => Math.abs(M.seg.right - U(d)) <= 2.5).length /
        r.members.length >=
        0.6 &&
      P < 0.6 &&
      b(c) > 4
    )
      r.align = "right";
    else if (P >= 0.5) r.align = "left";
    else {
      const M = r.members.map((k) => (k.seg.left + k.seg.right) / 2),
        R = M.filter((k) => Math.abs(k - U(M)) <= 3).length / M.length;
      r.align = R >= 0.6 ? "center" : "left";
    }
  }
  return { columns: u, cellOf: h };
}
function U(e) {
  const t = [...e].sort((s, o) => s - o);
  return t[Math.floor(t.length / 2)] ?? 0;
}
function ht(e) {
  const t = e.flatMap((n) => n.segs);
  if (!t.length) return 0;
  const s = (n, i) => Math.abs(n - i) <= 2.5;
  let o = 0;
  for (const n of t)
    t.some(
      (l) =>
        l !== n &&
        (s(l.left, n.left) ||
          s(l.right, n.right) ||
          s((l.left + l.right) / 2, (n.left + n.right) / 2)),
    ) && o++;
  return o / t.length;
}
const ct = (e, t) =>
  e.bold === t.bold &&
  e.italic === t.italic &&
  Math.abs(e.sizePt - t.sizePt) < 0.6 &&
  e.color === t.color &&
  e.font === t.font &&
  e.link === t.link &&
  !e.field &&
  !t.field;
function B(e, t) {
  if (!t.text && !t.field) return;
  const s = e[e.length - 1];
  s && ct(s, t) ? (s.text += t.text) : e.push({ ...t });
}
function C(e) {
  const t = [];
  let s = -1 / 0,
    o = !1;
  for (const n of e.items) {
    const i = n.str.replace(/\s+/g, " "),
      l = s > -1 / 0 ? n.x - s : 0,
      g = t.length ? t[t.length - 1].text : "";
    if (
      (t.length &&
        l > V(n.size) &&
        !/\s$/.test(g) &&
        !/^\s/.test(i) &&
        (o = !0),
      o)
    ) {
      const f = t[t.length - 1];
      ((f.text += " "), (o = !1));
    }
    (B(t, {
      text: i,
      bold: n.bold,
      italic: n.italic,
      sizePt: q(n.size),
      color: n.color,
      font: n.font,
      link: n.link,
    }),
      (s = Math.max(s, n.x + n.width)));
  }
  return (O(t), t);
}
const q = (e) => Math.round(e * 10) / 10;
function O(e) {
  for (; e.length && !e[0].field && !e[0].text.trim();) e.shift();
  for (; e.length && !e[e.length - 1].field && !e[e.length - 1].text.trim();)
    e.pop();
  e.length && !e[0].field && (e[0].text = e[0].text.replace(/^\s+/, ""));
  const t = e[e.length - 1];
  t && !t.field && (t.text = t.text.replace(/\s+$/, ""));
}
function gt(e) {
  const t = [];
  return (
    e.segs.forEach((s, o) => {
      if (o > 0) {
        const i = s.left - e.segs[o - 1].right > 3 * e.size ? "	" : " ",
          l = t[t.length - 1];
        l && (l.text += i);
      }
      for (const n of C(s)) B(t, n);
    }),
    O(t),
    t
  );
}
function Z(e) {
  for (const t of e) t.text = t.text.replace(/ {2,}/g, " ");
  return e;
}
function mt(e) {
  let t = gt(e),
    s = e.marker;
  if (!s && t.length) {
    const f = t.map((x) => x.text).join(""),
      a = Q.exec(f),
      p = a ? null : tt.exec(f);
    a
      ? ((s = { kind: "bullet", text: a[1], left: F(e) }),
        (t = ut(t, a[0].length)))
      : p && (s = { kind: "number", text: p[1], left: F(e) });
  }
  if (!t.length && !s) return null;
  const o = t.filter((f) => f.text.trim()),
    n = o.length ? o : t,
    i = n.length > 0 && n.every((f) => f.bold),
    l = t.map((f) => f.text).join(""),
    g = s && e.marker ? Math.min(F(e), s.left) : F(e);
  return {
    row: e,
    runs: Z(t),
    text: l,
    left: g,
    right: G(e),
    baseline: e.baseline,
    top: e.top,
    size: e.size,
    allBold: i,
    marker: s,
    multi: e.segs.length >= 2,
  };
}
function ut(e, t) {
  const s = [];
  let o = t;
  for (const n of e)
    o <= 0
      ? s.push(n)
      : n.text.length <= o
        ? (o -= n.text.length)
        : (s.push({ ...n, text: n.text.slice(o) }), (o = 0));
  return s;
}
const K = (e) => /[.!?:;,)"”’]\s*$/.test(e);
function pt(e) {
  const t = [];
  return (
    e.forEach((s, o) => {
      if (o > 0) {
        const n = e[o - 1].text;
        !(/[A-Za-zÀ-ɏ]-$/.test(n) && /^[a-zß-ÿ]/.test(s.text)) &&
          t.length &&
          (t[t.length - 1].text += " ");
      }
      for (const n of s.runs) B(t, n);
    }),
    O(t),
    Z(t)
  );
}
function xt(e) {
  const t = [];
  for (let s = 1; s < e.length; s++) {
    const o = e[s - 1],
      n = e[s];
    if (Math.abs(o.size - n.size) >= 0.6) continue;
    const i = n.baseline - o.baseline;
    i >= 0.9 * o.size && i <= 3 * o.size && t.push(i);
  }
  return t.length < 3
    ? NaN
    : (t.sort((s, o) => s - o), t[Math.floor(0.25 * (t.length - 1))]);
}
function dt(e, t) {
  const s = e.map(mt).filter((h) => !!h);
  if (!s.length) return [];
  const o = t.left,
    n = t.right,
    i = xt(s),
    l = s.filter((h) => h.text.length >= 25).map((h) => h.right),
    g = l.length ? Math.max(...l) : n,
    f = Math.max(30, 0.15 * (g - o)),
    a = [];
  let p = [];
  const x = (h, r, c) => {
    if (r.marker || r.multi || h.multi) return !0;
    const d = r.baseline - h.baseline,
      b = Math.max(h.size, r.size),
      P = Number.isFinite(i) ? Math.min(i, 1.7 * b) : 1.2 * b;
    if (
      d > Math.max(1.6 * b, P * 1.4) ||
      Math.abs(h.size - r.size) > 1 ||
      h.allBold !== r.allBold
    )
      return !0;
    const m = !!p[0]?.marker;
    return !!(
      (r.left > h.left + 8 &&
        !(m && Math.abs(r.left - h.left) < 40 && !r.marker && c === 1)) ||
      (r.left < h.left - 8 && c > 1) ||
      (!(
        h.allBold &&
        r.allBold &&
        !K(h.text) &&
        d <= 1.35 * b &&
        /^[a-zß-ÿ0-9]/i.test(r.text) &&
        h.right > o + 0.6 * (g - o)
      ) &&
        h.right < g - f &&
        (K(h.text) || !/^[a-zß-ÿ]/.test(r.text)))
    );
  };
  for (const h of s)
    (p.length && x(p[p.length - 1], h, p.length) && (a.push(p), (p = [])),
      p.push(h));
  p.length && a.push(p);
  const u = [];
  return (
    a.forEach((h, r) => {
      const c = h[0],
        d = h[h.length - 1],
        b = pt(h);
      if (!b.length) return;
      const P = Math.min(...h.map((y) => y.left)),
        m = Math.max(...h.map((y) => y.right)),
        M = q(Math.max(...h.map((y) => y.size)));
      let R;
      const k = P - o,
        v = n - m;
      if (h.length === 1 && !c.marker) {
        const y = (P + m) / 2 - (o + n) / 2;
        k > 12 && v > 12 && Math.abs(y) < 12 && m - P < 0.85 * (n - o)
          ? (R = "center")
          : v < 4 && k > 40 && (R = "right");
      }
      const I = a[r + 1]?.[0],
        N = I
          ? Math.max(0, Math.min(36, I.baseline - d.baseline - 1.2 * d.size))
          : 0,
        z =
          c.marker?.kind === "bullet"
            ? {
                level: Math.max(
                  0,
                  Math.min(2, Math.floor((c.marker.left - o) / 18)),
                ),
              }
            : void 0;
      u.push({
        kind: "paragraph",
        runs: b,
        topPt: c.top,
        bottomPt: d.baseline + d.size * 0.25,
        leftPt: P,
        rightPt: m,
        align: R,
        indentPt: !z && !R && k > 14 ? Math.round(k) : 0,
        bullet: z,
        spaceAfterPt: Math.round(N * 10) / 10,
        sizePt: M,
      });
    }),
    u
  );
}
const Mt = 3;
function bt(e) {
  const { columns: t, cellOf: s } = ft(e);
  if (t.length < 2) return null;
  const o = e.map((f) => {
    const a = t.map(() => []);
    for (const p of f.segs) {
      const x = a[s.get(p)];
      x.length && (x[x.length - 1].text += " ");
      for (const u of C(p)) B(x, u);
    }
    return (a.forEach((p) => O(p)), a);
  });
  if (
    t
      .map((f, a) => o.filter((p) => p[a].length > 0).length)
      .filter((f) => f >= 2).length < 2
  )
    return null;
  const i = [];
  t.forEach((f, a) => {
    const p = a === 0 ? f.left - 3 : (t[a - 1].right + f.left) / 2,
      x = a === t.length - 1 ? f.right + 3 : (f.right + t[a + 1].left) / 2;
    i.push(Math.max(12, x - p));
  });
  const l = e[0],
    g = e[e.length - 1];
  return {
    kind: "table",
    rows: o.map((f) => f.map((a) => ({ runs: Z(a) }))),
    colWidthsPt: i,
    colAlign: t.map((f) => f.align),
    colExtents: t.map((f) => ({ left: f.left, right: f.right })),
    topPt: l.top,
    bottomPt: g.baseline + g.size * 0.25,
    leftPt: Math.min(...t.map((f) => f.left)),
    rightPt: Math.max(...t.map((f) => f.right)),
  };
}
function zt(e) {
  if (e.rows.length < 2 || e.rows[0].length !== 2) return !1;
  const t = e.rows.map((n) =>
    n[0].runs
      .map((i) => i.text)
      .join("")
      .trim(),
  );
  if (!t.every((n) => /^(\d{1,3}|[A-Za-z])[.)]?$/.test(n))) return !1;
  const s = t.map((n) => parseInt(n, 10));
  if (s.every((n) => !Number.isNaN(n)))
    return s.every((n, i) => i === 0 || n === s[i - 1] + 1);
  const o = t.map((n) => n.replace(/[.)]/g, "").toLowerCase().charCodeAt(0));
  return o.every((n, i) => i === 0 || n === o[i - 1] + 1);
}
function kt(e, t) {
  const s = [];
  let o = [];
  const n = () => {
      (o.length && s.push(...dt(o, t)), (o = []));
    },
    i = (g) => g.segs.length >= 2 && !g.marker;
  let l = 0;
  for (; l < e.length;) {
    if (!i(e[l])) {
      (o.push(e[l]), l++);
      continue;
    }
    let g = l + 1;
    for (
      ;
      g < e.length &&
      i(e[g]) &&
      e[g].baseline - e[g - 1].baseline <=
        3.2 * Math.max(e[g].size, e[g - 1].size);
    )
      g++;
    const f = e.slice(l, g);
    let a = null;
    (f.length >= Mt && ht(f) >= 0.7 && (a = bt(f)),
      a && zt(a) && (a = null),
      a ? (n(), s.push(a)) : o.push(...f),
      (l = g));
  }
  return (n(), s);
}
function yt(e, t) {
  const s = H(e),
    o = [];
  for (const n of s) {
    const i = n.filter((p) => p.segs.length);
    if (!i.length && !n.some((p) => p.marker)) continue;
    const g =
        s.length === 1 ||
        n.some((p) =>
          p.segs.some((x) => x.right - x.left > 0.6 * (t.right - t.left)),
        )
          ? t
          : { left: Math.min(...i.map(F)), right: Math.max(...i.map(G)) },
      f = kt(n, g),
      a = o[o.length - 1];
    (a &&
      a.kind === "paragraph" &&
      a.spaceAfterPt < 10 &&
      (a.spaceAfterPt = 10),
      o.push(...f));
  }
  return o;
}
const Pt = (e) => e.match(/\d+/g) ?? [],
  Rt = (e) => e.replace(/\d+/g, "#");
function wt(e, t) {
  const s = new Set(),
    o = { remove: s, header: [], footer: [] },
    n = e.length;
  if (n < 2) return o;
  const i = new Map();
  for (const u of e)
    for (const h of u.rows)
      for (const r of h.segs)
        i.set(
          Math.round(r.size * 2) / 2,
          (i.get(Math.round(r.size * 2) / 2) ?? 0) + r.text.length,
        );
  let l = 11,
    g = 0;
  i.forEach((u, h) => {
    u > g && ((g = u), (l = h));
  });
  const f = [];
  e.forEach((u, h) => {
    for (const r of u.rows) {
      if (!r.segs.length || r.segs.length > 3 || r.size > l * 1.05 + 0.5)
        continue;
      const c = r.segs.map((d) => d.text).join(" ");
      r.top < 0.1 * u.heightPt
        ? f.push({ page: h, row: r, zone: "header", text: c })
        : r.baseline > 0.9 * u.heightPt &&
          f.push({ page: h, row: r, zone: "footer", text: c });
    }
  });
  const a = Math.max(2, Math.ceil(0.75 * n)),
    p = new Map();
  for (const u of f) {
    const h = u.zone + "|" + u.row.segs.length + "|" + Rt(u.text);
    (p.get(h) ?? p.set(h, []).get(h)).push(u);
  }
  const x = [];
  for (const u of Array.from(p.values())) {
    const h = new Map();
    for (const z of u) h.has(z.page) || h.set(z.page, z);
    if (h.size < a) continue;
    const r = Array.from(h.values()).sort((z, y) => z.page - y.page),
      c = r.map((z) => Pt(z.text)),
      d = c[0].length,
      b = [];
    let P = !0;
    for (let z = 0; z < d && P; z++) {
      const y = r.map((E, L) => ({ v: Number(c[L][z]), page: E.page + 1 })),
        T = r[0].text;
      let w = -1;
      for (let E = 0, L = /\d+/g, A; (A = L.exec(T)); E++)
        E === z && (w = A.index);
      const S = w >= 0 ? T.slice(0, w) : "";
      y.every((E) => E.v === E.page)
        ? b.push("PAGE")
        : y.every((E) => E.v === n) && /(\bof|\/|\bde|\bvon|\bsur)\s*$/i.test(S)
          ? b.push("NUMPAGES")
          : y.every((E) => E.v === y[0].v)
            ? b.push("LIT")
            : (P = !1);
    }
    if (!P) continue;
    const m = r[0];
    let M = 0;
    const R = m.row.segs.map((z) => {
        const y = C(z),
          T = [];
        for (const w of y) {
          let S = 0;
          const E = /\d+/g;
          let L;
          const A = [];
          for (; (L = E.exec(w.text));) {
            const _ = b[M++];
            (L.index > S && A.push({ ...w, text: w.text.slice(S, L.index) }),
              A.push(
                _ === "LIT"
                  ? { ...w, text: L[0] }
                  : { ...w, text: "", field: _ },
              ),
              (S = L.index + L[0].length));
          }
          (S < w.text.length && A.push({ ...w, text: w.text.slice(S) }),
            A.length || A.push(w));
          for (const _ of A) B(T, _);
        }
        return T;
      }),
      k = m.row,
      v = Math.min(...k.segs.map((z) => z.left)),
      I = Math.max(...k.segs.map((z) => z.right)),
      N =
        k.segs.length > 1
          ? "left"
          : Math.abs(v - (t - I)) < 12
            ? "center"
            : v > t * 0.55
              ? "right"
              : "left";
    x.push({
      zone: m.zone,
      baseline: k.baseline,
      line: { parts: R, align: N },
      rows: r.map((z) => z.row),
    });
  }
  for (const u of x) for (const h of u.rows) s.add(h);
  return (
    x.sort((u, h) => u.baseline - h.baseline),
    {
      remove: s,
      header: x.filter((u) => u.zone === "header").map((u) => u.line),
      footer: x.filter((u) => u.zone === "footer").map((u) => u.line),
    }
  );
}
const j = (e, t, s) => Math.max(t, Math.min(s, e));
function Et(e, t, s, o) {
  const n = [...(s ? [s.left] : []), ...o.map((x) => x.left)],
    i = [...(s ? [s.right] : []), ...o.map((x) => x.right)],
    l = [...(s ? [s.top] : []), ...o.map((x) => x.top)],
    g = [...(s ? [s.bottom] : []), ...o.map((x) => x.bottom)];
  if (!n.length) return { top: 72, right: 72, bottom: 72, left: 72 };
  const f = j(Math.min(...n), 18, e * 0.3),
    a = j(e - Math.max(...i), 18, e * 0.3),
    p = Math.min(a, Math.max(f, 36));
  return {
    left: f,
    right: p,
    top: j(Math.min(...l), 18, t * 0.3),
    bottom: j(t - Math.max(...g) - 4, 18, t * 0.3),
  };
}
function Lt(e, t = []) {
  const s = e.map((i) => ({ content: i, rows: ot(i.items) })),
    o = wt(
      s.map((i) => ({ rows: i.rows, heightPt: i.content.heightPt })),
      e[0]?.widthPt ?? 612,
    );
  return {
    pages: s.map(({ content: i, rows: l }, g) => {
      const f = l.filter((h) => !o.remove.has(h)),
        a = f.filter((h) => h.segs.length),
        p = a.length
          ? { left: Math.min(...a.map(F)), right: Math.max(...a.map(G)) }
          : { left: 72, right: i.widthPt - 72 },
        x = yt(f, p),
        u = a.length
          ? {
              left: p.left,
              right: p.right,
              top: Math.min(...a.map((h) => h.top)),
              bottom: Math.max(...a.map((h) => h.baseline)),
            }
          : null;
      return {
        widthPt: i.widthPt,
        heightPt: i.heightPt,
        blocks: x,
        marginsPt: Et(i.widthPt, i.heightPt, u, t[g] ?? []),
        hasText: i.hasText,
      };
    }),
    header: o.header,
    footer: o.footer,
  };
}
function At(e) {
  return e.kind === "paragraph"
    ? e.runs.map((t) => (t.field ? `{${t.field}}` : t.text)).join("")
    : e.rows.map((t) =>
        t.map((s) => s.runs.map((o) => o.text).join("")).join(" | "),
      ).join(`
`);
}
export { yt as a, ot as b, At as c, Lt as l };
//# sourceMappingURL=pdfLayout-BswErtWz.js.map
