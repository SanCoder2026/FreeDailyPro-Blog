import { r as n } from "./vendor-react-D01g8YgM.js";
function l(e) {
  const [t, d] = n.useState(null),
    o = n.useRef(e);
  return (
    (o.current = e),
    n.useEffect(() => {
      const r = () => {
        o.current != null && d(o.current);
      };
      return (
        window.addEventListener("freedailypro:download-complete", r),
        () => window.removeEventListener("freedailypro:download-complete", r)
      );
    }, []),
    e != null && t === e
  );
}
export { l as u };
//# sourceMappingURL=useDownloadedResult-C1FfMpBH.js.map
