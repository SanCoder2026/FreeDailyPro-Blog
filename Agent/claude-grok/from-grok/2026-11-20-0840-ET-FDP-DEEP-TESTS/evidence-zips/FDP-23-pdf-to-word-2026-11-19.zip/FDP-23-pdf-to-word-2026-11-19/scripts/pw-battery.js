// pdf-to-word battery: one fresh context per case (pw-cases.json; argv[2] = comma IDs). Drop the PDF, set language/pages if given, press Convert to Word, poll status/progress
// every 500 ms (up to 240 s), record the summary line, warnings, errors, trial count before/after, and every request (any host except ads) with POST sizes.
// The .docx is captured from memory (Proxy on the Blob constructor that only records Word blobs; it returns real Blobs so the OCR worker keeps working). Download is never pressed.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/23-pdf-to-word/live/'; const T = '/workspace/deep/23-pdf-to-word/testfiles/'; const URL = 'https://www.freedailypro.com/tool/pdf-to-word'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const ids = process.argv[2] ? process.argv[2].split(',') : null; const tag = ids ? '-' + ids.join('_') : '';
const cases = JSON.parse(fs.readFileSync(__dirname + '/pw-cases.json')).filter(c => !ids || ids.includes(c.id));
const HOOK = `(() => { window.__docx = []; const OB = window.Blob; window.Blob = new Proxy(OB, { construct(t, a) { const b = Reflect.construct(t, a); try { if (/wordprocessingml/.test((a[1] || {}).type || '')) window.__docx.push(b); } catch (e) {} return b; } }); })();`;
const ADS = /googlesyndication|doubleclick|adservice|google-analytics|googletagmanager|media\.net|adtrafficquality|gstatic|fundingchoices|youtube|ytimg|ggpht/;
(async () => { const b = await chromium.launch(); const R = { t: now(), cases: [] }; const save = () => fs.writeFileSync(OUT + 'battery' + tag + '.json', JSON.stringify(R, null, 1));
 for (const c of cases) { const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); await ctx.addInitScript(HOOK); const p = await ctx.newPage(); p.setDefaultTimeout(12000);
  const r = { id: c.id, file: c.file, opts: { pages: c.pages, lang: c.lang }, t: now(), reqs: [], errs: [], status: [] };
  p.on('pageerror', e => r.errs.push(String(e).slice(0, 200))); p.on('console', m => { if (m.type() === 'error' && !/no_div|adsbygoogle|Permissions policy/.test(m.text())) r.errs.push('console: ' + m.text().slice(0, 200)); });
  try { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
   const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday; r.start = await used();
   p.on('request', q => { const u = q.url(); if (ADS.test(u) || /\/assets\//.test(u)) return; r.reqs.push(q.method() + ' ' + u.replace(/\?.*/, '').slice(0, 110) + (q.postData() ? ' post=' + q.postData().length : '')); });
   await p.locator('main input[type=file]').first().setInputFiles(T + c.file); await p.waitForTimeout(3000);
   r.afterDrop = await p.evaluate(() => (document.querySelector('main').innerText.match(/(Pages to convert[^\n]*|[^\n]*(password|damaged|isn't a PDF|can't|couldn't|not a PDF)[^\n]*)/gi) || []).slice(0, 4));
   if (c.lang) await p.locator('main select').first().selectOption({ label: c.lang });
   if (c.pages) await p.locator('main input:not([type=file]):not([type=checkbox]):not([type=radio])').first().fill(c.pages);
   const cv = p.getByRole('button', { name: 'Convert to Word', exact: true }); if (!(await cv.count())) { r.noConvert = true; r.text = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 1500)); throw new Error('no Convert button'); }
   const t0 = Date.now(); await cv.click();
   for (let i = 0; i < 480; i++) { const s = await p.evaluate(() => { const m = document.querySelector('main').innerText; return { conv: (m.match(/Converted: [^\n]*/) || [null])[0], err: (m.match(/(Conversion failed[^\n]*|No readable text[^\n]*|Pages to convert: [^\n]*|Still reading[^\n]*|[^\n]*password[^\n]*)/i) || [null])[0], st: (m.match(/(Opening the PDF…|Reading page[^\n]*|Starting OCR[^\n]*|Building the Word[^\n]*|Working…|[^\n]*page \d+ of \d+[^\n]*)/) || [null])[0], toasts: [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim()) }; });
    if (s.st && r.status[r.status.length - 1]?.s !== s.st) r.status.push({ s: s.st, at: ((Date.now() - t0) / 1000).toFixed(1) }); (s.toasts || []).forEach(x => { if (!(r.toasts = r.toasts || []).includes(x)) r.toasts.push(x); });
    if (s.conv) { r.converted = s.conv; break; } if (s.err && i > 2 && !/Pages to convert \(/.test(s.err)) { r.error = s.err; break; } await p.waitForTimeout(500); }
   r.ms = Date.now() - t0; if (!r.converted && !r.error) r.timeout = true;
   r.warnings = await p.evaluate(() => [...document.querySelectorAll('main [aria-live=polite] p, main [aria-live=polite] div')].map(e => e.innerText.trim()).filter(x => x && !/^Converted:/.test(x)).slice(0, 8));
   r.after = await used();
   if (r.converted) { const bytes = await p.evaluate(async () => { const x = window.__docx.pop(); return x ? [...new Uint8Array(await x.arrayBuffer())] : []; }); if (bytes.length) { r.outFile = `out-${c.id}.docx`; fs.writeFileSync(OUT + r.outFile, Buffer.from(bytes)); r.outBytes = bytes.length; }
    r.buttons = await p.evaluate(() => [...document.querySelectorAll('main button')].map(b => b.innerText.trim()).filter(x => /Download|Convert another|Save|Copy|Share|Drive|cloud/i.test(x) && x.length < 50)); }
   await p.screenshot({ path: OUT + `res-${c.id}.png` });
  } catch (e) { r.fail = String(e).slice(0, 200); }
  R.cases.push(r); save(); console.log(c.id, r.converted || r.error || r.fail || (r.timeout ? 'TIMEOUT' : ''), r.ms, r.outBytes || '', r.start + '->' + r.after, JSON.stringify(r.reqs.filter(x => !/insight\.hit|funnel\.hit|auth\.me|version\.json/.test(x)))); await ctx.close(); }
 R.t2 = now(); save(); await b.close(); })();
