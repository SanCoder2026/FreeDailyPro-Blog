// pdf-to-word in Firefox and WebKit: starting count, rich.pdf (text) and scan_rich_2p.pdf (OCR) → Convert to Word; records the summary line, toasts, page errors. Download not pressed.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/23-pdf-to-word/live/'; const T = '/workspace/deep/23-pdf-to-word/testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const R = { t: now() };
 for (const n of ['firefox', 'webkit']) { const b = await pw[n].launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(15000); const errs = []; p.on('pageerror', e => errs.push(String(e).slice(0, 150))); const r = {};
  try { await p.goto('https://www.freedailypro.com/tool/pdf-to-word', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); r.start = JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
   for (const f of ['rich.pdf', 'scan_rich_2p.pdf']) { await p.locator('main input[type=file]').first().setInputFiles(T + f); await p.waitForTimeout(2500); const t0 = Date.now(); await p.getByRole('button', { name: 'Convert to Word', exact: true }).click();
    const ok = await p.getByText(/^Converted: /).first().waitFor({ timeout: 90000 }).then(() => true).catch(() => false); r[f] = { ok, ms: Date.now() - t0, line: ok ? (await p.getByText(/^Converted: /).first().innerText()) : (await p.locator('main').innerText()).match(/Conversion failed[^\n]*|[^\n]*couldn't[^\n]*/)?.[0] };
    await p.screenshot({ path: OUT + `br-${n}-${f}.png` }); const ca = p.getByRole('button', { name: 'Convert another', exact: true }); if (await ca.count()) await ca.click(); else await p.getByRole('button', { name: 'Reset', exact: true }).click().catch(() => {}); await p.waitForTimeout(1000); }
  } catch (e) { r.err = String(e).slice(0, 200); } r.errs = errs.filter(x => !/googleads|doubleclick/.test(x)); R[n] = r; await b.close(); }
 R.t2 = now(); fs.writeFileSync(OUT + 'browsers.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); })();
