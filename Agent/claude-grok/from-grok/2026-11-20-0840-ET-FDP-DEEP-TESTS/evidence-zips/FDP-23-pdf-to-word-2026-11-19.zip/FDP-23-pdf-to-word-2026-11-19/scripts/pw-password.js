// pdf-to-word: password-protected test PDF (test password "user123", part of our own test file). Wrong password first, then the right one; convert; record messages and requests (is anything uploaded?).
const { chromium } = require('playwright'); const fs = require('fs');
(async () => { const b = await chromium.launch(); const p = await (await b.newContext()).newPage(); const R = { reqs: [] };
 p.on('request', q => { if (/freedailypro/.test(q.url()) && q.method() === 'POST') R.reqs.push(q.url().replace(/\?.*/, '').slice(0, 90) + ' post=' + (q.postData() || '').length); });
 await p.goto('https://www.freedailypro.com/tool/pdf-to-word', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 await p.locator('main input[type=file]').first().setInputFiles('/workspace/deep/23-pdf-to-word/testfiles/J_password_user123_2p.pdf'); await p.locator('input[type=password]').waitFor();
 await p.locator('input[type=password]').fill('wrong'); await p.getByRole('button', { name: 'Unlock' }).click(); await p.waitForTimeout(1500);
 R.wrong = await p.evaluate(() => [...document.querySelectorAll('[role=dialog], [data-sonner-toast]')].map(x => x.innerText.replace(/\n+/g, ' / ')).join(' || ').slice(0, 400));
 await p.locator('input[type=password]').fill('user123'); await p.getByRole('button', { name: 'Unlock' }).click(); await p.waitForTimeout(2500);
 await p.getByRole('button', { name: 'Convert to Word', exact: true }).click(); R.ok = await p.getByText(/^Converted: /).first().waitFor({ timeout: 30000 }).then(async () => await p.getByText(/^Converted: /).first().innerText()).catch(() => false);
 R.toasts = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim())); fs.writeFileSync('/workspace/deep/23-pdf-to-word/live/password.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
