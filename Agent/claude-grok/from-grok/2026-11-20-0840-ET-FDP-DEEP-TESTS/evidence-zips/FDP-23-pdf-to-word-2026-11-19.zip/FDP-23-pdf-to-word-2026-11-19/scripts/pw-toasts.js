// pdf-to-word: what the user sees for bad inputs. Fresh context per file; polls toasts, alerts and the drop-area text every 300 ms for 20 s after the drop (password PDF also: does a password prompt appear?).
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/23-pdf-to-word/live/'; const T = '/workspace/deep/23-pdf-to-word/testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const R = { t: now(), cases: [] };
 for (const f of ['J_password_user123_2p.pdf', 'L_truncated.pdf', 'N_text_renamed.pdf', 'P_empty.pdf']) { const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); const r = { f, seen: [], errs: [] };
  p.on('console', m => { if (m.type() === 'error' && !/no_div|adsbygoogle|Permissions/.test(m.text())) r.errs.push(m.text().slice(0, 160)); });
  await p.goto('https://www.freedailypro.com/tool/pdf-to-word', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
  await p.locator('main input[type=file]').first().setInputFiles(T + f);
  for (let i = 0; i < 66; i++) { const s = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast], [role=alert], [role=dialog]')].map(x => x.innerText.trim().replace(/\n/g, ' / ')).concat((document.querySelector('main').innerText.match(/(Preparing[^\n]*|[^\n]*password[^\n]*|Convert to Word)/gi) || [])));
   s.forEach(x => { if (x && !r.seen.includes(x)) r.seen.push(x); }); await p.waitForTimeout(300); }
  r.pwField = await p.locator('input[type=password]').count(); await p.screenshot({ path: OUT + `bad-${f.replace('.pdf', '')}.png` });
  R.cases.push(r); await c.close(); }
 fs.writeFileSync(OUT + 'bad-inputs.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
