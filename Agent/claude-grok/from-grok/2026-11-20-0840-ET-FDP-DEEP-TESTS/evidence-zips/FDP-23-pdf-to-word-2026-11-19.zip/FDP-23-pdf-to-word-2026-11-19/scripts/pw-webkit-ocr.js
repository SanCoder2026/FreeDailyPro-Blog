// pdf-to-word: re-check of the WebKit crash on OCR (scan_rich_2p.pdf), 2 attempts in fresh browsers; also C_scan_grey_4p.pdf. Records crash vs result.
const pw = require('playwright'); const fs = require('fs');
(async () => { const R = [];
 for (const f of ['scan_rich_2p.pdf', 'scan_rich_2p.pdf', 'C_scan_grey_4p.pdf']) { const b = await pw.webkit.launch(); const p = await (await b.newContext()).newPage(); const r = { f }; p.on('crash', () => { r.crash = true; });
  try { await p.goto('https://www.freedailypro.com/tool/pdf-to-word', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); await p.locator('main input[type=file]').first().setInputFiles('/workspace/deep/23-pdf-to-word/testfiles/' + f); await p.waitForTimeout(2500);
   await p.getByRole('button', { name: 'Convert to Word', exact: true }).click(); r.ok = await p.getByText(/^Converted: /).first().waitFor({ timeout: 90000 }).then(() => true).catch(e => String(e).slice(0, 80)); } catch (e) { r.err = String(e).slice(0, 120); }
  R.push(r); await b.close().catch(() => {}); }
 fs.writeFileSync('/workspace/deep/23-pdf-to-word/live/webkit-ocr.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R)); })();
