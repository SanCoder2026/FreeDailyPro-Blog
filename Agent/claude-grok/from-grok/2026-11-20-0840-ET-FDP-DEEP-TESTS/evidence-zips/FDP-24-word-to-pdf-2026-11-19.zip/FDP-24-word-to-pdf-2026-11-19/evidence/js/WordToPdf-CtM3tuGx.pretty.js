const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/docxRaster-Bk1M3JAm.js",
      "assets/index-D2ZT81un.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/index-BJxTAPRn.css",
      "assets/index-BRvxULIc.js",
      "assets/index-CnXdQaNG.js",
      "assets/index-DMQTJy3b.js",
      "assets/jszip.min-CT0ZA6V1.js",
      "assets/jszip.min-C-FLQHAz.js",
      "assets/_commonjs-dynamic-modules-TDtrdbi3.js",
      "assets/pdfFonts-Ckcqm3Ic.js",
      "assets/fontkit.es-DA-3qwB1.js",
      "assets/domTextLines-YXN485C_.js",
      "assets/pdfMetadata-CcxIhQF2.js",
      "assets/backgroundSafe-DObGz9DE.js",
    ]),
) => i.map((i) => d[i]);
import {
  ax as W,
  N as P,
  B as b,
  ap as H,
  f as K,
  ay as G,
} from "./index-D2ZT81un.js";
import { r as l, j as e } from "./vendor-react-D01g8YgM.js";
import { T as J } from "./ToolWithSidebar-Bj9NAKKH.js";
import { P as O, F as V, D as X, R as Z } from "./ToolPage-DS5jbfzr.js";
import { f as L } from "./formatFileSize-B-JRDfN5.js";
import { p as f } from "./plural-FIChqbp4.js";
import { u as q } from "./useRunToken-sJpsnYiZ.js";
import { T as Q } from "./TrialFooterNotice-CAAe1Tug.js";
import { readDocx as Y, NotDocxError as ee } from "./docxRead-O6CRn7oc.js";
import { blocksText as te } from "./docxModel-CrYTKRGY.js";
import {
  convertDocxDocumentToPdf as se,
  DocxPdfCancelled as re,
} from "./docxToPdf-K5O8yYaD.js";
import {
  decodeTextFile as oe,
  convertTextToPdfDocument as ae,
} from "./textToPdf-BuGdG5vq.js";
import { u as $, b as ne } from "./pdfFonts-Ckcqm3Ic.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./CollapsibleText-CmqWEytu.js";
import "./chevron-up-Bx33pgGu.js";
import "./useUploadApi-CeBVbB2U.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-mA9gIB_c.js";
import "./share-2-wJ7OG3q6.js";
import "./copy-DxyF2bO9.js";
import "./workflowCta-QcLjv4ms.js";
import "./UsageAndUpgradeStrip-Ckl_cEoN.js";
import "./access-BBg1iIm1.js";
import "./useAdminAccess-D2xxeUJv.js";
import "./InstallToolButton-BaZhqv4P.js";
import "./map-pin-DiPhQKiV.js";
import "./FaqSection-DgbFc-d2.js";
import "./ToolVideoEmbed-DltoCXpM.js";
import "./GuideLinks-BsEl-oB0.js";
import "./blog-Cqpj3gtZ.js";
import "./info-BGlOhDp4.js";
import "./productCards-CAZfINO_.js";
import "./layers-B7zHnkyf.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./xmlLite-D0-GZ86u.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./pdfMetadata-CcxIhQF2.js";
import "./fontkit.es-DA-3qwB1.js";
const z = {
    what: `Turns a Word document (.docx) or a plain text file (.txt) into a PDF. For a Word file the PDF keeps the headings, bold and italic, colours, bullet and numbered lists, tables (with borders, shading and repeating header rows), pictures, links, tabs, page breaks, headers and footers with page numbers, and the page size and margins of your document. Text only is also available if you want the plainest, smallest file.

For best results use a document saved from Word, Google Docs or LibreOffice. Fonts are matched to the closest standard PDF font (Calibri and Arial become Helvetica-style, Times New Roman and Cambria become Times-style), so line breaks can fall in slightly different places than in Word.`,
    tip: "Convert as the last step, after you finish editing. Greek, Cyrillic and most European languages are supported. Chinese, Japanese, Korean, Hindi and other Indic scripts, Arabic, Hebrew, Thai and emoji are drawn as pictures so they look right, but that text cannot be selected or searched in the PDF. Text boxes, shapes, charts and multi-column layouts are reproduced by “Exact look” (pages as pictures with a hidden text layer), which is chosen for you when a file has them. Old .doc, .rtf and .odt files are not accepted: open them in Word and save as .docx first.",
  },
  F = (t) => t.replace(/\.[^.]+$/, "");
function qe() {
  const [t, w] = l.useState(null),
    [S, j] = l.useState(!1),
    [v, g] = l.useState(!1),
    [A, T] = l.useState(0),
    [n, y] = l.useState(null),
    [E, i] = l.useState(""),
    [c, C] = l.useState("format"),
    [k, B] = l.useState(() =>
      typeof navigator < "u" && /^en-(US|CA)|^es-MX/i.test(navigator.language)
        ? "Letter"
        : "A4",
    ),
    o = q();
  l.useEffect(() => () => o.cancel(), [o]);
  const N = () => {
      (o.cancel(), g(!1), j(!1), w(null), y(null), i(""), T(0));
    },
    I = l.useCallback(
      async (s) => {
        (o.cancel(), g(!1), y(null), i(""), w(null));
        const r = s[0];
        if (!r) return;
        const d = r.name.toLowerCase();
        if (/\.doc$/.test(d))
          return i(
            "Old .doc files are not supported. Open it in Word and use Save As → Word Document (.docx), then drop it here.",
          );
        if (/\.rtf$/.test(d))
          return i(
            "RTF files are not supported. Open it in Word and save it as .docx, then drop it here.",
          );
        if (/\.odt$/.test(d))
          return i(
            "OpenDocument (.odt) files are not supported. Open it in Word or LibreOffice and save it as .docx, then drop it here.",
          );
        const p = o.start();
        j(!0);
        try {
          if (d.endsWith(".docx")) {
            const a = await Y(r);
            if (!o.isCurrent(p)) return;
            const u = a.sections.map((D) => te(D.blocks)).join(`
`);
            w({ file: r, kind: "docx", doc: a, text: u, scripts: $(u) });
            const m = a.warnings;
            C(
              m.textBoxes > 0 || m.charts > 0 || m.columnSections > 0
                ? "exact"
                : "format",
            );
          } else {
            const a = oe(await r.arrayBuffer());
            if (!o.isCurrent(p)) return;
            w({ file: r, kind: "txt", text: a, scripts: $(a) });
          }
        } catch (a) {
          if (!o.isCurrent(p)) return;
          (console.error(a),
            i(
              a instanceof ee
                ? "This file is not a Word document (.docx). It may be damaged, or it may be another kind of file renamed to .docx."
                : "This file could not be read. It may be damaged or password-protected.",
            ));
        } finally {
          o.isCurrent(p) && j(!1);
        }
      },
      [o],
    ),
    _ = async () => {
      if (!t) return;
      if (!t.text.trim() && !t.doc?.sections.some((r) => r.blocks.length)) {
        i("There is no text in this file, so there is nothing to convert.");
        return;
      }
      const s = o.start();
      (g(!0), y(null), i(""), T(0));
      try {
        const r = F(t.file.name),
          d = {
            isCurrent: () => o.isCurrent(s),
            progress: (m) => o.isCurrent(s) && T(m * 100),
          };
        let p, a, u;
        if (t.kind === "docx" && c === "exact") {
          const { convertDocxToPdfRaster: m, DocxRasterCancelled: D } = await H(
            async () => {
              const { convertDocxToPdfRaster: x, DocxRasterCancelled: M } =
                await import("./docxRaster-Bk1M3JAm.js");
              return { convertDocxToPdfRaster: x, DocxRasterCancelled: M };
            },
            __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]),
          );
          try {
            const x = await m(t.file, {
              fallbackTitle: r,
              title: t.doc?.title,
              author: t.doc?.author,
              isCurrent: d.isCurrent,
              progress: d.progress,
            });
            ((p = x.bytes), (a = x.pages), (u = []));
          } catch (x) {
            if (x instanceof D) return;
            throw x;
          }
        } else
          t.kind === "docx" && c === "format" && t.doc
            ? ({
                bytes: p,
                pages: a,
                warnings: u,
              } = await se(t.doc, { fallbackTitle: r }, d))
            : ({
                bytes: p,
                pages: a,
                warnings: u,
              } = await ae(t.text, {
                pageSize: k,
                title: t.doc?.title || r,
                isCurrent: d.isCurrent,
              }));
        if (!o.isCurrent(s)) return;
        (y({
          blob: new Blob([p], { type: "application/pdf" }),
          pages: a,
          warnings: u,
          forFile: t.file.name,
        }),
          K.success(`Converted to PDF (${f(a, "page")})`),
          G("word-to-pdf", "pdf-tools"));
      } catch (r) {
        if (
          r instanceof re ||
          !o.isCurrent(s) ||
          (r instanceof Error && r.message === "cancelled")
        )
          return;
        (console.error("Word to PDF conversion failed:", r),
          i("The conversion failed. Try again, or choose Text only."));
      } finally {
        o.isCurrent(s) && g(!1);
      }
    },
    U = ne() !== null,
    h = t?.kind === "docx",
    R = t?.scripts ?? [];
  return e.jsxs(J, {
    toolId: "word-to-pdf",
    categoryId: "pdf-tools",
    whatItDoes: z.what,
    proTip: z.tip,
    children: [
      e.jsxs("div", {
        className:
          "mb-4 p-3 rounded-lg border bg-muted/50 text-xs text-muted-foreground flex flex-wrap gap-x-4 gap-y-1",
        children: [
          e.jsx("span", {
            children: "🔒 Runs entirely in your browser, never uploaded",
          }),
          e.jsx("span", {
            children:
              "📄 Keeps headings, lists, tables, pictures and page numbers",
          }),
        ],
      }),
      E &&
        e.jsxs("div", {
          role: "alert",
          className:
            "mb-4 p-3 rounded-lg border border-destructive/40 bg-destructive/5 text-sm flex gap-2",
          children: [
            e.jsx(W, { className: "h-4 w-4 mt-0.5 shrink-0 text-destructive" }),
            e.jsx("span", { children: E }),
          ],
        }),
      t
        ? e.jsxs("div", {
            className: "space-y-4",
            children: [
              e.jsxs("div", {
                className: "p-4 rounded-lg border bg-card",
                children: [
                  e.jsx("p", {
                    className: "text-sm font-medium break-all",
                    children: t.file.name,
                  }),
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground",
                    children: L(t.file.size),
                  }),
                ],
              }),
              R.length > 0 &&
                e.jsxs(P, {
                  role: "alert",
                  className: "text-sm flex gap-2",
                  children: [
                    e.jsx(W, {
                      className: "h-4 w-4 mt-0.5 shrink-0 text-primary",
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsxs("p", {
                          className: "font-medium",
                          children: [
                            "This file has ",
                            R.map(
                              (s) => `${s.name} (${f(s.count, "character")})`,
                            ).join(", "),
                            ".",
                          ],
                        }),
                        e.jsx("p", {
                          className: "text-muted-foreground",
                          children: U
                            ? "These are drawn as pictures so they look right, but that text cannot be selected, copied or searched in the PDF. Everything else stays real text."
                            : "This browser cannot draw them, so they will appear as “?” in the PDF. Use Save as PDF in Word for a complete result.",
                        }),
                      ],
                    }),
                  ],
                }),
              h &&
                t.doc &&
                c === "format" &&
                (t.doc.warnings.textBoxes > 0 ||
                  t.doc.warnings.charts > 0 ||
                  t.doc.warnings.columnSections > 0 ||
                  t.doc.warnings.pictures > 0) &&
                e.jsxs(P, {
                  role: "status",
                  className: "text-sm",
                  children: [
                    "Not carried over:",
                    " ",
                    [
                      t.doc.warnings.textBoxes > 0 &&
                        `${f(t.doc.warnings.textBoxes, "text box / shape", "text boxes / shapes")}`,
                      t.doc.warnings.charts > 0 &&
                        `${f(t.doc.warnings.charts, "chart")}`,
                      t.doc.warnings.pictures > 0 &&
                        `${f(t.doc.warnings.pictures, "picture")} in an unsupported format`,
                      t.doc.warnings.columnSections > 0 &&
                        `${f(t.doc.warnings.columnSections, "multi-column section")} (shown as one column)`,
                    ]
                      .filter(Boolean)
                      .join(", "),
                    ". ",
                    e.jsx("button", {
                      type: "button",
                      className: "underline",
                      onClick: () => C("exact"),
                      children: "Use “Exact look” to include them",
                    }),
                    ".",
                  ],
                }),
              !v &&
                !n &&
                e.jsxs("fieldset", {
                  className: "space-y-3",
                  children: [
                    e.jsx("legend", {
                      className: "text-sm font-medium mb-1",
                      children: "Output",
                    }),
                    h &&
                      e.jsx("div", {
                        className: "flex flex-wrap gap-2",
                        role: "group",
                        "aria-label": "Conversion mode",
                        children: [
                          ["format", "Keep formatting (selectable text)"],
                          ["exact", "Exact look (pages as pictures)"],
                          ["text", "Text only (smallest file)"],
                        ].map(([s, r]) =>
                          e.jsx(
                            b,
                            {
                              size: "sm",
                              variant: c === s ? "default" : "outline",
                              "aria-pressed": c === s,
                              onClick: () => C(s),
                              children: r,
                            },
                            s,
                          ),
                        ),
                      }),
                    (!h || c === "text") &&
                      e.jsxs("div", {
                        className: "flex flex-wrap items-center gap-2",
                        role: "group",
                        "aria-label": "Page size",
                        children: [
                          e.jsx("span", {
                            className: "text-sm text-muted-foreground",
                            children: "Page size",
                          }),
                          ["A4", "Letter"].map((s) =>
                            e.jsx(
                              b,
                              {
                                size: "sm",
                                variant: k === s ? "default" : "outline",
                                "aria-pressed": k === s,
                                onClick: () => B(s),
                                children: s === "Letter" ? "US Letter" : s,
                              },
                              s,
                            ),
                          ),
                        ],
                      }),
                    h &&
                      c === "format" &&
                      e.jsx("p", {
                        className: "text-xs text-muted-foreground",
                        children:
                          "The page size and margins of your document are used. Text stays real, selectable text.",
                      }),
                    h &&
                      c === "text" &&
                      e.jsx("p", {
                        className: "text-xs text-muted-foreground",
                        children:
                          "Only the body text is kept: no pictures, colours, headers, footers or page numbers. Page breaks are kept.",
                      }),
                    h &&
                      c === "exact" &&
                      e.jsx("p", {
                        className: "text-xs text-muted-foreground",
                        children:
                          "Every page is drawn exactly as Word lays it out, including text boxes, shapes, charts and columns. Pages are pictures with a hidden text layer, so Latin-script text can still be searched; the file is larger and can take longer.",
                      }),
                  ],
                }),
              !n && !v && e.jsx(Q, { toolId: "word-to-pdf" }),
              e.jsx("div", {
                className: "flex flex-wrap gap-3",
                children: v
                  ? e.jsx("div", {
                      className: "w-full",
                      children: e.jsx(O, {
                        message: "Converting…",
                        progress: A,
                        onStop: () => {
                          (o.cancel(), g(!1));
                        },
                      }),
                    })
                  : n
                    ? e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(X, {
                            blob: n.blob,
                            fileName: `${F(n.forFile)}.pdf`,
                          }),
                          e.jsx(b, {
                            variant: "outline",
                            onClick: N,
                            children: "Convert another file",
                          }),
                        ],
                      })
                    : e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(b, {
                            onClick: _,
                            disabled: S,
                            children: "Convert to PDF",
                          }),
                          e.jsx(b, {
                            variant: "outline",
                            onClick: N,
                            children: "Choose a different file",
                          }),
                        ],
                      }),
              }),
              n &&
                e.jsxs("div", {
                  className: "space-y-3",
                  children: [
                    e.jsxs("p", {
                      className: "text-sm text-muted-foreground",
                      role: "status",
                      children: [
                        f(n.pages, "page"),
                        " · ",
                        L(n.blob.size),
                        " · ",
                        F(n.forFile),
                        ".pdf",
                      ],
                    }),
                    n.warnings.map((s, r) =>
                      e.jsx(
                        P,
                        { className: "text-sm", role: "alert", children: s },
                        r,
                      ),
                    ),
                    e.jsx(Z, { blob: n.blob, mimeType: "application/pdf" }),
                  ],
                }),
            ],
          })
        : S
          ? e.jsx(O, { message: "Reading the file…", onStop: N })
          : e.jsx(V, {
              gateAtDownload: !0,
              onAttempt: () => i(""),
              accept: ".docx,.txt",
              acceptLabel: ".docx and .txt",
              onFiles: I,
              label: "Drop a .docx or .txt file",
              description: "Word documents (.docx) and plain text files (.txt)",
            }),
    ],
  });
}
export { qe as default };
//# sourceMappingURL=WordToPdf-CtM3tuGx.js.map
