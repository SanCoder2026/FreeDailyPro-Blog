const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/docx-preview-DZsRh4Zh.js",
      "assets/jszip.min-CT0ZA6V1.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/jszip.min-C-FLQHAz.js",
      "assets/_commonjs-dynamic-modules-TDtrdbi3.js",
      "assets/domCapture-DZNyCy6P.js",
      "assets/index-D2ZT81un.js",
      "assets/index-BJxTAPRn.css",
    ]),
) => i.map((i) => d[i]);
import { ap as z } from "./index-D2ZT81un.js";
import { k as X, e as V } from "./index-BRvxULIc.js";
import { J as W } from "./jszip.min-CT0ZA6V1.js";
import { P as K } from "./pdfFonts-Ckcqm3Ic.js";
import { c as F } from "./domTextLines-YXN485C_.js";
import { s as Z } from "./pdfMetadata-CcxIhQF2.js";
import { r as _, i as Q, y as Y } from "./backgroundSafe-DObGz9DE.js";
import "./vendor-react-D01g8YgM.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./fontkit.es-DA-3qwB1.js";
function tt(t, e, r, n = []) {
  const o = t.filter((l) => l.bottom > l.top).sort((l, a) => l.top - a.top),
    s = [];
  let i = 0;
  for (; e - i > r + 1 && s.length < 2e3;) {
    const l = (p) => {
      let h = i + r;
      for (let g = 0; g < 5e3; g++) {
        let S = 1 / 0;
        for (const P of p) {
          if (P.top >= h) break;
          P.bottom > h + 0.5 && P.top < h - 0.5 && P.top < S && (S = P.top);
        }
        if (S === 1 / 0) break;
        h = S;
      }
      return h;
    };
    let a = l(o);
    a <= i + 1 && (a = l(o.filter((p) => !p.soft)));
    const m = n
      .filter((p) => p > i + 1 && p < a && a - p < r * 0.25)
      .sort((p, h) => p - h)[0];
    (m !== void 0 && (a = m),
      a <= i + 1 && (a = i + r),
      s.push({ start: i, end: a }));
    const u = o.find((p) => p.top >= a - 0.5);
    i = u && u.top - a < 40 ? u.top : a;
  }
  return (s.push({ start: i, end: Math.max(e, i + 1) }), s);
}
const G = (t, e) => {
    if (t <= 0 || t >= 4e3) return String(t);
    const r = [
      [1e3, "m"],
      [900, "cm"],
      [500, "d"],
      [400, "cd"],
      [100, "c"],
      [90, "xc"],
      [50, "l"],
      [40, "xl"],
      [10, "x"],
      [9, "ix"],
      [5, "v"],
      [4, "iv"],
      [1, "i"],
    ];
    let n = "";
    for (const [o, s] of r) for (; t >= o;) ((n += s), (t -= o));
    return e ? n.toUpperCase() : n;
  },
  O = (t, e) => {
    if (t <= 0) return String(t);
    let r = "";
    for (; t > 0;)
      (t--,
        (r = String.fromCharCode(97 + (t % 26)) + r),
        (t = Math.floor(t / 26)));
    return e ? r.toUpperCase() : r;
  };
function et(t, e) {
  switch (e) {
    case "lower-alpha":
    case "lower-latin":
      return O(t, !1);
    case "upper-alpha":
    case "upper-latin":
      return O(t, !0);
    case "lower-roman":
      return G(t, !1);
    case "upper-roman":
      return G(t, !0);
    case "decimal-leading-zero":
      return t >= 0 && t < 10 ? `0${t}` : String(t);
    case "none":
      return "";
    default:
      return String(t);
  }
}
function ot(t, e) {
  const r =
    /"((?:[^"\\]|\\.)*)"|counters?\(\s*([^,)\s]+)\s*(?:,\s*([^)]*?))?\s*\)/g;
  let n = "",
    o = !1,
    s;
  for (; (s = r.exec(t));)
    if (s[2]) {
      o = !0;
      const i =
        (s[3] ?? "")
          .replace(/"[^"]*"/g, "")
          .replace(/,/g, "")
          .trim() || "decimal";
      n += et(e.get(s[2]) ?? 0, i.split(/\s+/).pop() ?? "decimal");
    } else
      n += s[1]
        .replace(/\\([0-9a-f]{1,6})\s?/gi, (i, l) =>
          String.fromCodePoint(parseInt(l, 16)),
        )
        .replace(/\\(.)/g, "$1");
  return o ? n : null;
}
function q(t, e) {
  if (!t || t === "none") return [];
  const r = t.trim().split(/\s+/),
    n = [];
  for (let o = 0; o < r.length; o++) {
    const s = r[o];
    if (/^-?\d+$/.test(s)) continue;
    const i = r[o + 1];
    i !== void 0 && /^-?\d+$/.test(i)
      ? (n.push([s, parseInt(i, 10)]), o++)
      : n.push([s, e]);
  }
  return n;
}
class H extends Error {
  constructor() {
    super("cancelled");
  }
}
const x = 0.75,
  M = "⟦PAGE⟧",
  D = "⟦NUMPAGES⟧";
function rt(t) {
  const e = /<w:r(?:\s[^>]*)?>[\s\S]*?<\/w:r>/g,
    r = [];
  let n = 0,
    o = null,
    s;
  for (; (s = e.exec(t));) {
    const i = s[0],
      l = t.slice(n, s.index);
    n = s.index + i.length;
    const a = /<w:fldChar[^>]*w:fldCharType="(begin|separate|end)"/.exec(
      i,
    )?.[1];
    if (!o && a === "begin" && /w:fldCharType="end"/.test(i)) {
      const u = /<w:instrText[^>]*>([^<]*)<\/w:instrText>/
          .exec(i)?.[1]
          ?.trim()
          .split(/\s+/)[0]
          ?.toUpperCase(),
        p = /<w:rPr>[\s\S]*?<\/w:rPr>/.exec(i)?.[0] ?? "";
      r.push(
        l,
        u === "PAGE" || u === "NUMPAGES"
          ? `<w:r>${p}<w:t>${u === "PAGE" ? M : D}</w:t></w:r>`
          : i,
      );
      continue;
    }
    if (a === "begin") {
      o = {
        kind: null,
        phase: "instr",
        held: [l + i],
        rPr: /<w:rPr>[\s\S]*?<\/w:rPr>/.exec(i)?.[0] ?? "",
      };
      continue;
    }
    if (!o) {
      r.push(l, i);
      continue;
    }
    o.held.push(l + i);
    const m = /<w:instrText[^>]*>([^<]*)<\/w:instrText>/.exec(i)?.[1];
    if (m !== void 0) {
      const u = m.trim().split(/\s+/)[0]?.toUpperCase();
      (u === "PAGE" || u === "NUMPAGES") && (o.kind = u);
    }
    (a === "separate" && (o.phase = "result"),
      a === "end" &&
        (o.kind
          ? r.push(`<w:r>${o.rPr}<w:t>${o.kind === "PAGE" ? M : D}</w:t></w:r>`)
          : r.push(...o.held),
        (o = null)));
  }
  return (o && r.push(...o.held), r.push(t.slice(n)), r.join(""));
}
function nt(t) {
  const e = /<w:docDefaults>[\s\S]*?<\/w:docDefaults>/.exec(t)?.[0] ?? "",
    r = /<w:rPrDefault>[\s\S]*?<\/w:rPrDefault>/.exec(e)?.[0] ?? "",
    n = /<w:rFonts[^>]*w:(?:ascii|hAnsi)="([^"]+)"/.exec(r)?.[1],
    o = /<w:sz\s+w:val="(\d+)"/.exec(r)?.[1];
  return { font: n, sizePt: o ? parseInt(o, 10) / 2 : void 0 };
}
function st(t) {
  let e = "",
    r = "";
  return t.replace(
    /(<w:sectPr(?:\s[^>]*)?>)([\s\S]*?)(<\/w:sectPr>)/g,
    (n, o, s, i) => {
      const l = s.match(/<w:headerReference\b[^>]*\/>/g)?.join("") ?? "",
        a = s.match(/<w:footerReference\b[^>]*\/>/g)?.join("") ?? "",
        m = (l ? "" : e) + (a ? "" : r);
      return (l && (e = l), a && (r = a), o + m + s + i);
    },
  );
}
async function it(t) {
  try {
    const e = await W.loadAsync(t);
    let r = !1;
    const n = e.file("word/document.xml");
    if (n) {
      const o = await n.async("string"),
        s = st(o);
      s !== o && (e.file("word/document.xml", s), (r = !0));
    }
    for (const o of Object.keys(e.files)) {
      if (!/^word\/(header|footer)\d*\.xml$/.test(o)) continue;
      const s = await e.file(o).async("string"),
        i = rt(s);
      i !== s && (e.file(o, i), (r = !0));
    }
    return r ? await e.generateAsync({ type: "arraybuffer" }) : t;
  } catch {
    return t;
  }
}
function at(t) {
  const e = document.createTreeWalker(t, NodeFilter.SHOW_TEXT),
    r = [];
  let n;
  for (; (n = e.nextNode());)
    n.data.includes("⟦") && r.push({ node: n, template: n.data });
  return r;
}
function lt(t, e, r) {
  for (const n of t)
    n.node.data = n.template.split(M).join(String(e)).split(D).join(String(r));
}
function ct(t) {
  const e = new Map(),
    r = document.createElement("style");
  ((r.textContent =
    "[data-fdp-num]::before{content:attr(data-fdp-num) !important;}"),
    t.appendChild(r));
  for (const n of Array.from(t.querySelectorAll('[class*="fdp-docx-num-"]'))) {
    const o = getComputedStyle(n);
    for (const [l, a] of q(o.counterReset, 0)) e.set(l, a);
    for (const [l, a] of q(o.getPropertyValue("counter-set"), 0)) e.set(l, a);
    const s = getComputedStyle(n, "::before");
    for (const [l, a] of q(s.counterIncrement, 1))
      e.set(l, (e.get(l) ?? 0) + a);
    const i = ot(s.content, e);
    i !== null && n.setAttribute("data-fdp-num", i);
  }
}
function ft(t) {
  const e = getComputedStyle(t),
    r = parseFloat(e.minHeight) || t.getBoundingClientRect().height,
    n = t.getBoundingClientRect(),
    o = at(t);
  if (n.height <= r + 1.5) return [{ section: t, slots: o }];
  const s = t.querySelector(":scope > article");
  if (!s) return [{ section: t, slots: o }];
  const i = t.querySelector(":scope > header"),
    l = t.querySelector(":scope > footer"),
    a = s.getBoundingClientRect(),
    m = a.top - n.top,
    u = a.left - n.left,
    p = i
      ? {
          top: i.getBoundingClientRect().top - n.top,
          left: i.getBoundingClientRect().left - n.left,
          width: i.getBoundingClientRect().width,
        }
      : void 0,
    h = l?.getBoundingClientRect(),
    g = h
      ? { fromBottom: n.bottom - h.top, left: h.left - n.left, width: h.width }
      : void 0,
    S = g ? g.fromBottom : parseFloat(e.paddingBottom) || 0,
    P = Math.max(r - m - S, r * 0.3),
    E = [],
    w = document.createRange(),
    C = document.createTreeWalker(s, NodeFilter.SHOW_TEXT);
  let y;
  for (; (y = C.nextNode());)
    if (y.data.trim()) {
      w.selectNodeContents(y);
      for (const d of Array.from(w.getClientRects()))
        d.height > 0 &&
          E.push({ top: d.top - a.top, bottom: d.bottom - a.top });
    }
  for (const d of Array.from(s.querySelectorAll("img, svg, canvas, tr"))) {
    const v = d.getBoundingClientRect();
    v.height > 0 &&
      E.push({
        top: v.top - a.top,
        bottom: v.bottom - a.top,
        soft: d.tagName === "TR",
      });
  }
  const T = Array.from(
      s.querySelectorAll(
        'h1,h2,h3,h4,h5,h6,p[class*="heading"],p[class*="title"]',
      ),
    ).map((d) => d.getBoundingClientRect().top - a.top),
    B = tt(E, a.height, P, T),
    $ = F(s),
    R = [];
  for (const d of Array.from(s.querySelectorAll("a[href]"))) {
    const v = d.getAttribute("href") ?? "";
    if (/^(https?:|mailto:)/i.test(v))
      for (const A of Array.from(d.getClientRects()))
        A.width > 1 &&
          A.height > 1 &&
          R.push({
            url: v,
            x: A.left - a.left,
            y: A.top - a.top,
            w: A.width,
            h: A.height,
          });
  }
  return B.map((d) => ({
    section: t,
    slots: o,
    tall: {
      slice: d,
      pageH: r,
      articleH: a.height,
      aTop: m,
      aLeft: u,
      aWidth: a.width,
      header: p,
      footer: g,
      lines: $,
      links: R,
    },
  }));
}
function pt(t, e) {
  const r = t.querySelector(":scope > article"),
    n = t.querySelector(":scope > header"),
    o = t.querySelector(":scope > footer");
  ((t.style.display = "block"),
    (t.style.position = "relative"),
    (t.style.overflow = "hidden"),
    (t.style.height = `${e.pageH}px`),
    (t.style.minHeight = `${e.pageH}px`),
    (t.style.paddingTop = "0"),
    (t.style.paddingBottom = "0"));
  const s = `inset(${e.slice.start}px -9999px ${Math.max(0, e.articleH - e.slice.end)}px -9999px)`;
  ((r.style.cssText += `;position:absolute;margin:0;left:${e.aLeft}px;top:${e.aTop - e.slice.start}px;width:${e.aWidth}px;clip-path:${s};`),
    n &&
      e.header &&
      (n.style.cssText += `;position:absolute;margin:0;left:${e.header.left}px;top:${e.header.top}px;width:${e.header.width}px;`),
    o &&
      e.footer &&
      (o.style.cssText += `;position:absolute;margin:0;left:${e.footer.left}px;top:${e.pageH - e.footer.fromBottom}px;width:${e.footer.width}px;`));
}
function U(t, e) {
  if (!t) return [];
  const r = e.getBoundingClientRect(),
    n = t.getBoundingClientRect();
  return F(t).map((o) => ({
    ...o,
    x: o.x + (n.left - r.left),
    y: o.y + (n.top - r.top),
  }));
}
async function Tt(t, e) {
  const r = () => !!e.isCurrent && !e.isCurrent(),
    n = () => {
      if (r()) throw new H();
    },
    o = () => {
      throw new H();
    },
    [{ renderAsync: s }, { captureElementJpeg: i }] = await Promise.all([
      z(
        () => import("./docx-preview-DZsRh4Zh.js"),
        __vite__mapDeps([0, 1, 2, 3, 4]),
      ),
      z(
        () => import("./domCapture-DZNyCy6P.js"),
        __vite__mapDeps([5, 6, 2, 7]),
      ),
    ]),
    l = document.createElement("div");
  (l.setAttribute("aria-hidden", "true"),
    (l.style.cssText =
      "position:fixed;left:-100000px;top:0;background:#fff;pointer-events:none;"),
    document.body.appendChild(l));
  try {
    const a = await t.arrayBuffer();
    let m = {};
    try {
      const w = await (
        await W.loadAsync(a)
      )
        .file("word/styles.xml")
        ?.async("string");
      w && (m = nt(w));
    } catch {}
    ((l.style.fontSize = `${m.sizePt ?? 11}pt`),
      (l.style.lineHeight = "normal"),
      (l.style.fontFamily = `${m.font ? `"${m.font.replace(/"/g, "")}", ` : ""}Arial, Helvetica, sans-serif`),
      await _(
        s(await it(a), l, void 0, {
          className: "fdp-docx",
          inWrapper: !1,
          breakPages: !0,
          ignoreLastRenderedPageBreak: !0,
          renderHeaders: !0,
          renderFooters: !0,
          renderFootnotes: !0,
          renderEndnotes: !0,
          useBase64URL: !0,
          experimental: !0,
        }),
        r,
        o,
      ),
      n());
    try {
      await _(Promise.resolve(document.fonts?.ready), r, o);
    } catch (w) {
      if (w instanceof H) throw w;
    }
    const u = Array.from(l.querySelectorAll("section.fdp-docx"));
    if (u.length === 0) throw new Error("no pages");
    (await _(Promise.all(Array.from(l.querySelectorAll("img")).map(Q)), r, o),
      ct(l));
    const p = u.flatMap(ft),
      h = p.length,
      g = await X.create(),
      S = new K(g, void 0, null);
    let P = 0,
      E = 0;
    for (let w = 0; w < p.length; w++) {
      (n(), e.progress?.(w / h));
      const C = p[w],
        y = C.section;
      (lt(C.slots, w + 1, h), C.tall && pt(y, C.tall));
      const T = y.getBoundingClientRect(),
        B = T.width * x,
        $ = T.height * x;
      let R;
      const d = [];
      if (C.tall) {
        const c = C.tall;
        R = [
          ...c.lines
            .filter(
              (f) => f.y >= c.slice.start - 1 && f.y + f.h <= c.slice.end + 1,
            )
            .map((f) => ({
              ...f,
              x: f.x + c.aLeft,
              y: f.y - c.slice.start + c.aTop,
            })),
          ...U(y.querySelector(":scope > header"), y),
          ...U(y.querySelector(":scope > footer"), y),
        ];
        for (const f of c.links)
          f.y >= c.slice.start - 1 &&
            f.y + f.h <= c.slice.end + 1 &&
            d.push({
              url: f.url,
              x: f.x + c.aLeft,
              y: f.y - c.slice.start + c.aTop,
              w: f.w,
              h: f.h,
            });
      } else {
        R = F(y);
        for (const c of Array.from(y.querySelectorAll("a[href]"))) {
          const f = c.getAttribute("href") ?? "";
          if (/^(https?:|mailto:)/i.test(f))
            for (const b of Array.from(c.getClientRects()))
              b.width > 1 &&
                b.height > 1 &&
                d.push({
                  url: f,
                  x: b.left - T.left,
                  y: b.top - T.top,
                  w: b.width,
                  h: b.height,
                });
        }
      }
      const v = await _(
        i(y, {
          pixelRatio: 2,
          quality: 0.85,
          width: T.width,
          height: T.height,
          style: { margin: "0", boxShadow: "none" },
        }),
        r,
        o,
      );
      n();
      const A = g.addPage([B, $]);
      A.drawImage(await g.embedJpg(v), { x: 0, y: 0, width: B, height: $ });
      for (const c of d) {
        const f = g.context.obj({
          Type: "Annot",
          Subtype: "Link",
          Rect: [c.x * x, $ - (c.y + c.h) * x, (c.x + c.w) * x, $ - c.y * x],
          Border: [0, 0, 0],
          A: { Type: "Action", S: "URI", URI: V.of(c.url) },
        });
        (A.node.addAnnot(g.context.register(f)), E++);
      }
      if (R.length) {
        await S.prepare(R.map((c) => c.text).join(" "));
        for (const c of R) {
          const f = Array.from(c.text)
            .filter((k) => S.canDraw(k))
            .join("");
          if (!f.trim()) continue;
          const b = S.runs(f, "sans"),
            L = b.reduce((k, j) => k + j.font.widthOfTextAtSize(j.text, 1), 0);
          if (L <= 0) continue;
          const N = Math.min(
            Math.max((c.w * x) / L, c.h * x * 0.4),
            c.h * x * 1.3,
          );
          let I = c.x * x;
          const J = $ - (c.y + c.h * 0.8) * x;
          for (const k of b)
            (A.drawText(k.text, {
              x: I,
              y: J,
              size: N,
              font: k.font,
              opacity: 0,
            }),
              (I += k.font.widthOfTextAtSize(k.text, N)));
          P++;
        }
      }
      await Y();
    }
    return (
      Z(g, {
        title: e.title,
        author: e.author,
        fallbackTitle: e.fallbackTitle,
      }),
      e.progress?.(1),
      { bytes: await g.save(), pages: h, textLines: P, links: E }
    );
  } finally {
    l.remove();
  }
}
export {
  H as DocxRasterCancelled,
  Tt as convertDocxToPdfRaster,
  st as inheritHeaderRefs,
  rt as markPageFields,
  nt as readDocDefaults,
};
//# sourceMappingURL=docxRaster-Bk1M3JAm.js.map
