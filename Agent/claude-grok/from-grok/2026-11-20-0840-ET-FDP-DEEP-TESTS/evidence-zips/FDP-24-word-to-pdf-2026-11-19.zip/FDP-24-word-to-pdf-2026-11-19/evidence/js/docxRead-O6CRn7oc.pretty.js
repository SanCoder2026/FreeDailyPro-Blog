import { J as _ } from "./jszip.min-CT0ZA6V1.js";
import {
  p as S,
  c as r,
  k as N,
  a as n,
  f as M,
  b as X,
} from "./xmlLite-D0-GZ86u.js";
import "./vendor-react-D01g8YgM.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
class O extends Error {
  constructor(o) {
    (super(o), (this.name = "NotDocxError"));
  }
}
const m = (i) =>
    i === void 0 || i === "" || isNaN(Number(i)) ? void 0 : Number(i) / 20,
  C = (i) => {
    if (!i) return;
    const o = n(i, "w:val");
    return o === void 0 ? !0 : !(o === "0" || o === "false" || o === "off");
  },
  B = (i) => (i && /^[0-9a-fA-F]{6}$/.test(i) ? i.toUpperCase() : void 0),
  Y = {
    yellow: "FFFF00",
    green: "00FF00",
    cyan: "00FFFF",
    magenta: "FF00FF",
    blue: "0000FF",
    red: "FF0000",
    darkBlue: "000080",
    darkCyan: "008080",
    darkGreen: "008000",
    darkMagenta: "800080",
    darkRed: "800000",
    darkYellow: "808000",
    darkGray: "808080",
    lightGray: "C0C0C0",
    black: "000000",
    white: "FFFFFF",
  },
  $ = {
    align: "left",
    beforePt: 0,
    afterPt: 0,
    line: { value: 1, rule: "auto" },
    leftPt: 0,
    rightPt: 0,
    firstPt: 0,
    keepNext: !1,
    keepLines: !1,
    pageBreakBefore: !1,
    contextualSpacing: !1,
    widowControl: !0,
    borders: {},
    tabs: [],
  };
function R(i, o, s) {
  if (o)
    for (const e of o.children)
      switch (e.name) {
        case "w:b":
          i.bold = C(e);
          break;
        case "w:i":
          i.italic = C(e);
          break;
        case "w:strike":
        case "w:dstrike":
          i.strike = C(e);
          break;
        case "w:caps":
          i.caps = C(e);
          break;
        case "w:smallCaps":
          i.smallCaps = C(e);
          break;
        case "w:vanish":
          i.hidden = C(e);
          break;
        case "w:u": {
          const t = n(e, "w:val");
          i.underline = t !== "none" && t !== "0";
          break;
        }
        case "w:color": {
          const t = B(n(e, "w:val"));
          t ? (i.color = t) : n(e, "w:val") === "auto" && (i.color = void 0);
          break;
        }
        case "w:sz": {
          const t = Number(n(e, "w:val"));
          t > 0 && (i.sizePt = t / 2);
          break;
        }
        case "w:highlight": {
          const t = n(e, "w:val");
          t && t !== "none"
            ? (i.background = Y[t])
            : t === "none" && (i.background = void 0);
          break;
        }
        case "w:shd": {
          const t = B(n(e, "w:fill"));
          t && (i.background = t);
          break;
        }
        case "w:vertAlign": {
          const t = n(e, "w:val");
          i.vert =
            t === "superscript" ? "sup" : t === "subscript" ? "sub" : void 0;
          break;
        }
        case "w:rFonts": {
          const t = n(e, "w:ascii", "w:hAnsi", "w:cs"),
            a = n(e, "w:asciiTheme", "w:hAnsiTheme");
          t
            ? (i.font = t)
            : a && (i.font = /major/i.test(a) ? s.major : s.minor);
          break;
        }
      }
}
function j(i) {
  if (!i) return;
  const o = n(i, "w:val");
  if (!o || o === "nil" || o === "none") return;
  const s = Number(n(i, "w:sz"));
  return {
    style: o,
    sizePt: s > 0 ? s / 8 : 0.5,
    color: B(n(i, "w:color")) ?? "000000",
  };
}
function L(i, o) {
  if (o)
    for (const s of o.children)
      switch (s.name) {
        case "w:jc": {
          const e = n(s, "w:val");
          i.align =
            e === "center"
              ? "center"
              : e === "right" || e === "end"
                ? "right"
                : e === "both" || e === "distribute" || e === "justify"
                  ? "justify"
                  : "left";
          break;
        }
        case "w:spacing": {
          const e = m(n(s, "w:before"));
          e !== void 0 && (i.beforePt = e);
          const t = m(n(s, "w:after"));
          t !== void 0 && (i.afterPt = t);
          const a = Number(n(s, "w:line"));
          if (a > 0) {
            const c = n(s, "w:lineRule");
            i.line =
              c === "exact"
                ? { value: a / 20, rule: "exact" }
                : c === "atLeast"
                  ? { value: a / 20, rule: "atLeast" }
                  : { value: a / 240, rule: "auto" };
          }
          break;
        }
        case "w:ind": {
          const e = m(n(s, "w:left", "w:start"));
          e !== void 0 && (i.leftPt = e);
          const t = m(n(s, "w:right", "w:end"));
          t !== void 0 && (i.rightPt = t);
          const a = m(n(s, "w:hanging")),
            c = m(n(s, "w:firstLine"));
          a !== void 0 ? (i.firstPt = -a) : c !== void 0 && (i.firstPt = c);
          break;
        }
        case "w:keepNext":
          i.keepNext = C(s) ?? !0;
          break;
        case "w:keepLines":
          i.keepLines = C(s) ?? !0;
          break;
        case "w:pageBreakBefore":
          i.pageBreakBefore = C(s) ?? !0;
          break;
        case "w:contextualSpacing":
          i.contextualSpacing = C(s) ?? !0;
          break;
        case "w:widowControl":
          i.widowControl = C(s) ?? !0;
          break;
        case "w:shd": {
          const e = B(n(s, "w:fill"));
          i.shade = e;
          break;
        }
        case "w:pBdr": {
          const e = {};
          for (const [t, a] of [
            ["top", "w:top"],
            ["bottom", "w:bottom"],
            ["left", "w:left"],
            ["right", "w:right"],
          ]) {
            const c = j(r(s, a));
            c && (e[t] = c);
          }
          i.borders = e;
          break;
        }
        case "w:tabs": {
          const e = [...i.tabs];
          for (const t of N(s, "w:tab")) {
            const a = m(n(t, "w:pos"));
            if (a === void 0) continue;
            const c = n(t, "w:val"),
              l = e.findIndex((b) => Math.abs(b.posPt - a) < 0.5);
            if (c === "clear") {
              l >= 0 && e.splice(l, 1);
              continue;
            }
            const w = {
              posPt: a,
              align:
                c === "center"
                  ? "center"
                  : c === "right" || c === "end"
                    ? "right"
                    : c === "decimal"
                      ? "decimal"
                      : "left",
            };
            l >= 0 ? (e[l] = w) : e.push(w);
          }
          i.tabs = e.sort((t, a) => t.posPt - a.posPt);
          break;
        }
      }
}
class Z {
  constructor(o, s) {
    if (
      ((this.theme = s),
      (this.byId = new Map()),
      (this.docP = { ...$, borders: {}, tabs: [] }),
      (this.docR = { sizePt: 11, font: "Times New Roman" }),
      !o)
    )
      return;
    const e = r(o, "w:docDefaults");
    (R(this.docR, r(r(e, "w:rPrDefault"), "w:rPr"), s),
      L(this.docP, r(r(e, "w:pPrDefault"), "w:pPr")));
    for (const t of N(o, "w:style")) {
      const a = n(t, "w:styleId");
      if (!a) continue;
      const c = {
        id: a,
        type: n(t, "w:type") ?? "paragraph",
        name: n(r(t, "w:name"), "w:val") ?? a,
        basedOn: n(r(t, "w:basedOn"), "w:val"),
        pPr: r(t, "w:pPr"),
        rPr: r(t, "w:rPr"),
        tblPr: r(t, "w:tblPr"),
      };
      (this.byId.set(a, c),
        c.type === "paragraph" &&
          n(t, "w:default") === "1" &&
          (this.defaultPara = a));
    }
  }
  chain(o) {
    const s = [],
      e = new Set();
    let t = o ? this.byId.get(o) : void 0;
    for (; t && !e.has(t.id);)
      (e.add(t.id),
        s.unshift(t),
        (t = t.basedOn ? this.byId.get(t.basedOn) : void 0));
    return s;
  }
  paragraph(o) {
    const s = {
        ...this.docP,
        borders: { ...this.docP.borders },
        tabs: [...this.docP.tabs],
      },
      e = { ...this.docR },
      t = this.chain(o ?? this.defaultPara);
    for (const a of t) (L(s, a.pPr), R(e, a.rPr, this.theme));
    return { p: s, r: e, styles: t };
  }
  character(o) {
    const s = {};
    for (const e of this.chain(o)) R(s, e.rPr, this.theme);
    return s;
  }
  tableBorders(o) {
    const s = {};
    for (const e of this.chain(o)) V(s, r(e.tblPr, "w:tblBorders"));
    return s;
  }
}
function V(i, o) {
  if (o)
    for (const [s, e] of [
      ["top", ["w:top"]],
      ["bottom", ["w:bottom"]],
      ["left", ["w:left", "w:start"]],
      ["right", ["w:right", "w:end"]],
      ["insideH", ["w:insideH"]],
      ["insideV", ["w:insideV"]],
    ])
      for (const t of e) {
        const a = r(o, t);
        if (!a) continue;
        const c = j(a);
        c ? (i[s] = c) : delete i[s];
      }
}
function H(i) {
  const o = [
    [1e3, "M"],
    [900, "CM"],
    [500, "D"],
    [400, "CD"],
    [100, "C"],
    [90, "XC"],
    [50, "L"],
    [40, "XL"],
    [10, "X"],
    [9, "IX"],
    [5, "V"],
    [4, "IV"],
    [1, "I"],
  ];
  let s = "";
  for (const [e, t] of o) for (; i >= e;) ((s += t), (i -= e));
  return s;
}
function U(i) {
  let o = "";
  for (; i > 0; i = Math.floor((i - 1) / 26))
    o = String.fromCharCode(97 + ((i - 1) % 26)) + o;
  return o;
}
function K(i, o) {
  switch (o) {
    case "lowerLetter":
      return U(i);
    case "upperLetter":
      return U(i).toUpperCase();
    case "lowerRoman":
      return H(i).toLowerCase();
    case "upperRoman":
      return H(i);
    case "decimalZero":
      return i < 10 ? `0${i}` : String(i);
    case "ordinal": {
      const s = ["th", "st", "nd", "rd"],
        e = i % 100;
      return i + (s[(e - 20) % 10] || s[e] || s[0]);
    }
    case "none":
      return "";
    default:
      return String(i);
  }
}
class q {
  constructor(o) {
    if (
      ((this.abstracts = new Map()),
      (this.nums = new Map()),
      (this.counters = new Map()),
      !!o)
    ) {
      for (const s of N(o, "w:abstractNum")) {
        const e = n(s, "w:abstractNumId");
        if (e === void 0) continue;
        const t = new Map();
        for (const a of N(s, "w:lvl")) {
          const c = Number(n(a, "w:ilvl") ?? 0);
          t.set(c, {
            start: Number(n(r(a, "w:start"), "w:val") ?? 1),
            fmt: n(r(a, "w:numFmt"), "w:val") ?? "decimal",
            text: n(r(a, "w:lvlText"), "w:val") ?? "",
            pPr: r(a, "w:pPr"),
            rPr: r(a, "w:rPr"),
          });
        }
        this.abstracts.set(e, t);
      }
      for (const s of N(o, "w:num")) {
        const e = n(s, "w:numId"),
          t = n(r(s, "w:abstractNumId"), "w:val");
        if (e === void 0 || t === void 0) continue;
        const a = new Map();
        for (const c of N(s, "w:lvlOverride")) {
          const l = r(c, "w:startOverride");
          l && a.set(Number(n(c, "w:ilvl") ?? 0), Number(n(l, "w:val") ?? 1));
        }
        this.nums.set(e, { abstractId: t, overrides: a });
      }
    }
  }
  level(o, s) {
    const e = this.nums.get(o);
    return e ? this.abstracts.get(e.abstractId)?.get(s) : void 0;
  }
  next(o, s) {
    const e = this.nums.get(o),
      t = this.level(o, s);
    if (!e || !t) return;
    if (t.fmt === "bullet") return { text: Q(t.text), bullet: !0, level: t };
    const a = this.counters.get(o) ?? [],
      c = (w) => e.overrides.get(w) ?? this.level(o, w)?.start ?? 1;
    a[s] = a[s] === void 0 ? c(s) : a[s] + 1;
    for (let w = s + 1; w < a.length; w++) a[w] = void 0;
    return (
      this.counters.set(o, a),
      {
        text: t.text.replace(/%(\d)/g, (w, b) => {
          const p = Number(b) - 1,
            h = this.level(o, p),
            f = a[p] ?? c(p);
          return K(f, h?.fmt ?? "decimal");
        }),
        bullet: !1,
        level: t,
      }
    );
  }
}
function Q(i) {
  if (!i) return "•";
  const o = i.codePointAt(0);
  return o >= 61440 && o <= 61695 ? "•" : i === "o" ? "–" : i;
}
function tt(i) {
  return i[0] === 137 && i[1] === 80 && i[2] === 78 && i[3] === 71
    ? "png"
    : i[0] === 255 && i[1] === 216
      ? "jpg"
      : "other";
}
class et {
  constructor(o, s) {
    ((this.zip = o),
      (this.opts = s),
      (this.theme = {}),
      (this.media = new Map()),
      (this.warnings = {
        textBoxes: 0,
        pictures: 0,
        columnSections: 0,
        charts: 0,
      }),
      (this.footnoteXml = new Map()),
      (this.usedFootnotes = []),
      (this.fields = []),
      (this.partCache = new Map()),
      (this.pendingImages = []));
  }
  async text(o) {
    const s = this.zip.file(o);
    return s ? s.async("string") : void 0;
  }
  async relsFor(o) {
    const s = o.lastIndexOf("/"),
      e = o.slice(0, s + 1),
      t = await this.text(`${e}_rels/${o.slice(s + 1)}.rels`),
      a = new Map();
    if (t)
      for (const c of N(S(t), "Relationship")) {
        const l = n(c, "Id"),
          w = n(c, "Target");
        l &&
          w &&
          a.set(l, { target: w, external: n(c, "TargetMode") === "External" });
      }
    return { rels: a, dir: e };
  }
  resolve(o, s) {
    if (s.startsWith("/")) return s.slice(1);
    const e = (o.dir + s).split("/"),
      t = [];
    for (const a of e) a === ".." ? t.pop() : a && a !== "." && t.push(a);
    return t.join("/");
  }
  async init() {
    const o = await this.text("word/theme/theme1.xml");
    if (o) {
      const c = S(o);
      this.theme = {
        major: n(r(M(c, "a:majorFont"), "a:latin"), "typeface"),
        minor: n(r(M(c, "a:minorFont"), "a:latin"), "typeface"),
      };
    }
    const s = await this.text("word/styles.xml");
    this.styles = new Z(s ? S(s) : void 0, this.theme);
    const e = await this.text("word/numbering.xml");
    this.numbering = new q(e ? S(e) : void 0);
    const t = await this.text("word/footnotes.xml");
    if (t)
      for (const c of N(S(t), "w:footnote")) {
        const l = n(c, "w:id"),
          w = n(c, "w:type");
        l !== void 0 && !w && this.footnoteXml.set(l, c);
      }
    const a = [];
    (this.zip.forEach((c, l) => {
      !l.dir &&
        /^word\/media\//i.test(c) &&
        a.push(
          l.async("uint8array").then((w) => {
            this.media.set(c, w);
          }),
        );
    }),
      await Promise.all(a));
  }
  blocks(o, s, e) {
    const t = [],
      a = (c) => {
        for (const l of c.children)
          if (l.name === "w:p") {
            t.push(this.paragraph(l, s));
            const w = r(r(l, "w:pPr"), "w:sectPr");
            w && e && e(w, t.splice(0, t.length));
          } else
            l.name === "w:tbl"
              ? t.push(this.table(l, s))
              : l.name === "w:sdt"
                ? a(r(l, "w:sdtContent") ?? l)
                : l.name === "w:customXml" ||
                    l.name === "w:ins" ||
                    l.name === "w:moveTo"
                  ? a(l)
                  : l.name === "mc:AlternateContent" &&
                    a(r(l, "mc:Choice") ?? l);
      };
    return (a(o), t);
  }
  paragraph(o, s) {
    const e = r(o, "w:pPr"),
      t = n(r(e, "w:pStyle"), "w:val"),
      { p: a, r: c, styles: l } = this.styles.paragraph(t);
    let w = n(r(r(e, "w:numPr"), "w:numId"), "w:val"),
      b = Number(n(r(r(e, "w:numPr"), "w:ilvl"), "w:val") ?? NaN);
    for (const P of l) {
      const x = r(P.pPr, "w:numPr");
      x &&
        (w === void 0 && (w = n(r(x, "w:numId"), "w:val")),
        isNaN(b) && (b = Number(n(r(x, "w:ilvl"), "w:val") ?? NaN)));
    }
    isNaN(b) && (b = 0);
    let p;
    if (w && w !== "0") {
      const P = this.numbering.next(w, b);
      if (P) {
        L(a, P.level.pPr);
        const x = { ...c };
        (R(x, P.level.rPr, this.theme),
          (p = { text: P.text, bullet: P.bullet, p: x }));
      }
    }
    L(a, e);
    const h = { ...c };
    (R(h, r(e, "w:rPr"), this.theme),
      p &&
        (p.p = {
          ...p.p,
          ...(r(e, "w:rPr")
            ? { sizePt: h.sizePt, bold: h.bold ?? p.p.bold }
            : {}),
        }));
    const f = [];
    this.inlineContainer(o, s, c, f, void 0);
    const d = {
        kind: "p",
        inlines: f,
        props: a,
        base: h,
        list: p,
        styleId: t ?? this.styles.defaultPara,
      },
      v = this.styles.byId.get(t ?? "")?.name ?? "",
      g =
        n(r(e, "w:outlineLvl"), "w:val") ??
        n(r(this.styles.byId.get(t ?? "")?.pPr, "w:outlineLvl"), "w:val"),
      k = /^heading\s*(\d)/i.exec(v);
    return (
      g !== void 0 && Number(g) < 9
        ? (d.outline = Number(g) + 1)
        : k
          ? (d.outline = Number(k[1]))
          : /^title$/i.test(v) && (d.outline = 1),
      d
    );
  }
  push(o, s) {
    const e = o[o.length - 1];
    if (
      s.t === "text" &&
      e &&
      e.t === "text" &&
      e.link === s.link &&
      JSON.stringify(e.p) === JSON.stringify(s.p)
    ) {
      e.text += s.text;
      return;
    }
    o.push(s);
  }
  skipping() {
    return this.fields.some((o) => o.mode === "instr" || o.skipResult);
  }
  inlineContainer(o, s, e, t, a) {
    for (const c of o.children)
      switch (c.name) {
        case "w:r":
          this.run(c, s, e, t, a);
          break;
        case "w:hyperlink": {
          const l = n(c, "r:id"),
            w = l ? s.rels.get(l) : void 0;
          this.inlineContainer(c, s, e, t, w?.external ? w.target : a);
          break;
        }
        case "w:ins":
        case "w:smartTag":
        case "w:customXml":
        case "w:moveTo":
        case "w:sdtContent":
        case "w:bdo":
        case "w:dir":
          this.inlineContainer(c, s, e, t, a);
          break;
        case "w:sdt":
          this.inlineContainer(r(c, "w:sdtContent") ?? c, s, e, t, a);
          break;
        case "w:fldSimple": {
          const l = (n(c, "w:instr") ?? "").trim(),
            w = /^PAGE\b/i.test(l)
              ? "PAGE"
              : /^NUMPAGES\b/i.test(l)
                ? "NUMPAGES"
                : void 0;
          if (w && !this.skipping()) {
            const b = { ...e };
            (R(b, r(r(c, "w:r"), "w:rPr"), this.theme),
              t.push({ t: "field", kind: w, p: b }));
          } else this.inlineContainer(c, s, e, t, a);
          break;
        }
        case "mc:AlternateContent":
          this.inlineContainer(r(c, "mc:Choice") ?? c, s, e, t, a);
          break;
      }
  }
  run(o, s, e, t, a) {
    const c = r(o, "w:rPr"),
      l = { ...e },
      w = n(r(c, "w:rStyle"), "w:val");
    (w && Object.assign(l, this.styles.character(w)), R(l, c, this.theme));
    const b = [...this.fields].reverse().find((h) => h.link)?.link,
      p = a ?? b;
    p && !l.color && ((l.color = "0563C1"), (l.underline = l.underline ?? !0));
    for (const h of o.children) {
      switch (h.name) {
        case "w:fldChar": {
          const f = n(h, "w:fldCharType");
          if (f === "begin")
            this.fields.push({ instr: "", mode: "instr", skipResult: !1 });
          else if (f === "separate") {
            const d = this.fields[this.fields.length - 1];
            if (d) {
              d.mode = "result";
              const v = d.instr.trim(),
                g = /^PAGE\b/i.test(v)
                  ? "PAGE"
                  : /^NUMPAGES\b/i.test(v)
                    ? "NUMPAGES"
                    : void 0;
              g && ((d.skipResult = !0), t.push({ t: "field", kind: g, p: l }));
              const k = /^HYPERLINK\s+"([^"]+)"/i.exec(v);
              k && (d.link = k[1]);
            }
          } else f === "end" && this.fields.pop();
          break;
        }
        case "w:instrText": {
          const f = this.fields[this.fields.length - 1];
          f && f.mode === "instr" && (f.instr += h.text);
          break;
        }
      }
      if (!this.skipping() && !l.hidden)
        switch (h.name) {
          case "w:t":
            h.text.split("	").forEach((f, d) => {
              (d > 0 && t.push({ t: "tab", p: l }),
                f && this.push(t, { t: "text", text: f, p: l, link: p }));
            });
            break;
          case "w:tab":
          case "w:ptab":
            t.push({ t: "tab", p: l });
            break;
          case "w:br":
          case "w:cr": {
            n(h, "w:type") === "page"
              ? t.push({ t: "pagebreak" })
              : t.push({ t: "br", p: l });
            break;
          }
          case "w:noBreakHyphen":
            this.push(t, { t: "text", text: "-", p: l, link: p });
            break;
          case "w:sym": {
            const f = n(h, "w:char");
            if (f) {
              const d = parseInt(f, 16);
              this.push(t, {
                t: "text",
                text: d >= 61440 ? "•" : String.fromCodePoint(d),
                p: l,
                link: p,
              });
            }
            break;
          }
          case "w:footnoteReference": {
            const f = n(h, "w:id");
            if (f !== void 0 && this.footnoteXml.has(f)) {
              const d = String(this.usedFootnotes.length + 1);
              (this.usedFootnotes.push({ id: f, label: d }),
                t.push({
                  t: "footnoteRef",
                  label: d,
                  p: { ...l, vert: "sup" },
                }));
            }
            break;
          }
          case "w:drawing":
            this.drawing(h, s, t);
            break;
          case "w:pict":
          case "w:object":
            ((this.warnings.pictures += X(h, "v:imagedata").length),
              (this.warnings.textBoxes += X(h, "w:txbxContent").length));
            break;
          case "mc:AlternateContent": {
            const f = r(h, "mc:Choice") ?? h,
              d = M(f, "w:drawing");
            d && this.drawing(d, s, t);
            break;
          }
        }
    }
  }
  drawing(o, s, e) {
    const t = r(o, "wp:inline") ?? r(o, "wp:anchor");
    if (!t) return;
    const a = () => X(t, "w:t").some((P) => P.text.trim() !== "");
    if (M(t, "wps:txbx")) {
      (n(t, "behindDoc") !== "1" || a()) && this.warnings.textBoxes++;
      return;
    }
    if (n(t, "behindDoc") === "1") return;
    if (M(t, "c:chart")) {
      this.warnings.charts++;
      return;
    }
    const c = r(t, "wp:extent"),
      l = Number(n(c, "cx")),
      w = Number(n(c, "cy")),
      b = M(t, "a:blip"),
      p = n(b, "r:embed");
    if (!b || !p) {
      M(t, "wps:wsp") === void 0 &&
        M(t, "a:graphicData") &&
        this.warnings.pictures++;
      return;
    }
    const h = s.rels.get(p),
      f = h ? this.resolve(s, h.target) : "",
      d = this.media.get(f);
    if (!d || !(l > 0) || !(w > 0)) {
      this.warnings.pictures++;
      return;
    }
    const v = n(r(t, "wp:docPr"), "descr"),
      g = tt(d),
      k = { t: "image", wPt: l / 12700, hPt: w / 12700, alt: v };
    g === "other"
      ? (this.pendingImages.push({
          out: e,
          index: e.length,
          data: d,
          ext: (f.split(".").pop() ?? "").toLowerCase(),
          image: k,
        }),
        e.push({ ...k, data: d, type: "png" }))
      : e.push({ ...k, data: d, type: g });
  }
  async finishImages() {
    for (const o of this.pendingImages) {
      let s = null;
      if (this.opts.convertImage && !/^(emf|wmf|tif|tiff|svg)$/.test(o.ext))
        try {
          s = await this.opts.convertImage(o.data, o.ext);
        } catch {
          s = null;
        }
      const e = o.out[o.index];
      s && e && e.t === "image"
        ? (e.data = s)
        : e &&
          e.t === "image" &&
          (this.warnings.pictures++,
          (o.out[o.index] = { t: "text", text: "", p: {} }));
    }
    this.pendingImages = [];
  }
  table(o, s) {
    const e = r(o, "w:tblPr"),
      t = n(r(e, "w:tblStyle"), "w:val"),
      a = this.styles.tableBorders(t);
    V(a, r(e, "w:tblBorders"));
    const c = r(e, "w:tblCellMar"),
      l = {
        left: m(n(r(c, "w:left") ?? r(c, "w:start"), "w:w")) ?? 5.4,
        right: m(n(r(c, "w:right") ?? r(c, "w:end"), "w:w")) ?? 5.4,
        top: m(n(r(c, "w:top"), "w:w")) ?? 0,
        bottom: m(n(r(c, "w:bottom"), "w:w")) ?? 0,
      },
      w = r(e, "w:tblW"),
      b = n(w, "w:type"),
      p = Number(n(w, "w:w")),
      h = n(r(e, "w:jc"), "w:val"),
      f = {
        kind: "tbl",
        rows: [],
        grid: [],
        borders: a,
        margins: l,
        align:
          h === "center"
            ? "center"
            : h === "right" || h === "end"
              ? "right"
              : "left",
        indentPt: m(n(r(e, "w:tblInd"), "w:w")) ?? 0,
        widthPt: b === "dxa" && p > 0 ? p / 20 : void 0,
        widthFraction: b === "pct" && p > 0 ? p / 5e3 : void 0,
      };
    for (const d of N(r(o, "w:tblGrid"), "w:gridCol"))
      f.grid.push(m(n(d, "w:w")) ?? 0);
    for (const d of N(o, "w:tr")) {
      const v = r(d, "w:trPr"),
        g = r(v, "w:trHeight"),
        k = {
          cells: [],
          header: !!r(v, "w:tblHeader"),
          cantSplit: !!r(v, "w:cantSplit"),
          heightPt: m(n(g, "w:val")),
          heightRule: n(g, "w:hRule") === "exact" ? "exact" : "atLeast",
        },
        P = [],
        x = (A) => {
          for (const u of A.children)
            u.name === "w:tc"
              ? P.push(u)
              : u.name === "w:sdt" && x(r(u, "w:sdtContent") ?? u);
        };
      x(d);
      for (const A of P) {
        const u = r(A, "w:tcPr"),
          y = r(u, "w:vMerge"),
          F = {},
          T = r(u, "w:tcBorders");
        for (const [z, W] of [
          ["top", ["w:top"]],
          ["bottom", ["w:bottom"]],
          ["left", ["w:left", "w:start"]],
          ["right", ["w:right", "w:end"]],
        ])
          for (const J of W) {
            const D = r(T, J);
            if (!D) continue;
            const G = j(D);
            G
              ? (F[z] = G)
              : (F[z] = { style: "none", sizePt: 0, color: "000000" });
          }
        const I = r(u, "w:tcMar"),
          E = {
            blocks: this.blocks(A, s),
            span: Math.max(1, Number(n(r(u, "w:gridSpan"), "w:val") ?? 1)),
            vMerge: y
              ? n(y, "w:val") === "restart"
                ? "restart"
                : "continue"
              : void 0,
            shade: B(n(r(u, "w:shd"), "w:fill")),
            borders: F,
            vAlign:
              n(r(u, "w:vAlign"), "w:val") === "center"
                ? "center"
                : n(r(u, "w:vAlign"), "w:val") === "bottom"
                  ? "bottom"
                  : "top",
            margins: I
              ? {
                  left: m(n(r(I, "w:left") ?? r(I, "w:start"), "w:w")),
                  right: m(n(r(I, "w:right") ?? r(I, "w:end"), "w:w")),
                  top: m(n(r(I, "w:top"), "w:w")),
                  bottom: m(n(r(I, "w:bottom"), "w:w")),
                }
              : void 0,
          };
        (E.blocks.length === 0 &&
          E.blocks.push({
            kind: "p",
            inlines: [],
            props: { ...$, borders: {}, tabs: [] },
            base: { sizePt: 11 },
          }),
          k.cells.push(E));
      }
      f.rows.push(k);
    }
    if (f.grid.length === 0 || f.grid.every((d) => d === 0)) {
      const d = f.rows[0],
        v = d ? d.cells.reduce((g, k) => g + k.span, 0) : 0;
      f.grid = Array.from({ length: v }, () => 100);
    }
    return f;
  }
  async part(o) {
    const s = this.partCache.get(o);
    if (s) return s;
    const e = await this.text(o);
    if (!e) return;
    const t = await this.relsFor(o),
      a = this.blocks(S(e), t);
    return (this.partCache.set(o, a), a);
  }
  async sectionProps(o, s) {
    const e = r(o, "w:pgSz"),
      t = r(o, "w:pgMar"),
      a = async (p) => {
        const h = {};
        for (const f of N(o, p)) {
          const d = n(f, "r:id"),
            v = d ? s.rels.get(d)?.target : void 0;
          if (!v) continue;
          const g = await this.part(this.resolve(s, v)),
            k = n(f, "w:type") ?? "default";
          k === "first" ? (h.first = g) : k === "default" && (h.def = g);
        }
        return h;
      },
      c = await a("w:headerReference"),
      l = await a("w:footerReference"),
      w = n(r(o, "w:type"), "w:val"),
      b = Number(n(r(o, "w:cols"), "w:num") ?? 1);
    return (
      b > 1 && this.warnings.columnSections++,
      {
        widthPt: m(n(e, "w:w")) ?? 612,
        heightPt: m(n(e, "w:h")) ?? 792,
        marginTop: m(n(t, "w:top")) ?? 72,
        marginRight: m(n(t, "w:right")) ?? 72,
        marginBottom: m(n(t, "w:bottom")) ?? 72,
        marginLeft: m(n(t, "w:left")) ?? 72,
        headerDist: m(n(t, "w:header")) ?? 36,
        footerDist: m(n(t, "w:footer")) ?? 36,
        titlePg: !!r(o, "w:titlePg"),
        breakType:
          w === "continuous"
            ? "continuous"
            : w === "evenPage"
              ? "evenPage"
              : w === "oddPage"
                ? "oddPage"
                : "nextPage",
        columns: b,
        header: c.def,
        headerFirst: c.first,
        footer: l.def,
        footerFirst: l.first,
      }
    );
  }
}
async function at(i, o = {}) {
  let s;
  try {
    s = await _.loadAsync(i);
  } catch {
    throw new O("This isn't a Word (.docx) file.");
  }
  const e = await s.file("word/document.xml")?.async("string");
  if (!e)
    throw new O("This isn't a Word (.docx) file: it has no document inside.");
  const t = new et(s, o);
  await t.init();
  const a = await t.relsFor("word/document.xml"),
    c = S(e),
    l = r(c, "w:body") ?? c,
    w = [],
    b = [];
  let p = [];
  p = t.blocks(l, a, (u, y) => b.push({ sect: u, blocks: y }));
  const f = r(l, "w:sectPr"),
    d = (u, y, F) => {
      u[F] === void 0 && y && (u[F] = y[F]);
    },
    v = [
      ...b.map((u) => ({ sect: u.sect, blocks: u.blocks })),
      ...(f
        ? [{ sect: f, blocks: p }]
        : [{ sect: S("<w:sectPr/>"), blocks: p }]),
    ];
  for (const { sect: u, blocks: y } of v) {
    const F = await t.sectionProps(u, a),
      T = w[w.length - 1];
    (["header", "headerFirst", "footer", "footerFirst"].forEach((I) =>
      d(F, T, I),
    ),
      w.push({ ...F, blocks: y }));
  }
  for (; w.length > 1 && w[w.length - 1].blocks.length === 0;) w.pop();
  const g = [],
    k = await t.relsFor("word/footnotes.xml");
  for (const u of t.usedFootnotes) {
    const y = t.footnoteXml.get(u.id);
    y && g.push({ label: u.label, blocks: t.blocks(y, k) });
  }
  await t.finishImages();
  const P = await s.file("docProps/core.xml")?.async("string");
  let x, A;
  if (P) {
    const u = S(P);
    ((x = r(u, "dc:title")?.text.trim() || void 0),
      (A = r(u, "dc:creator")?.text.trim() || void 0));
  }
  return {
    sections: w,
    footnotes: g,
    title: x,
    author: A,
    warnings: t.warnings,
  };
}
export { O as NotDocxError, K as formatNumber, at as readDocx };
//# sourceMappingURL=docxRead-O6CRn7oc.js.map
