import { u as M, k as W, e as H, P as $ } from "./index-BRvxULIc.js";
import { blocksText as N } from "./docxModel-CrYTKRGY.js";
import { d as E, P as I, r as j, e as U, g as _ } from "./pdfFonts-Ckcqm3Ic.js";
import { s as G } from "./pdfMetadata-CcxIhQF2.js";
import "./index-CnXdQaNG.js";
import "./vendor-react-D01g8YgM.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
class J extends Error {
  constructor() {
    super("cancelled");
  }
}
const V = 1.17,
  O = 11,
  D = 36,
  R = 0.01,
  T = (F, t = [0, 0, 0]) =>
    !F || !/^[0-9a-fA-F]{6}$/.test(F)
      ? t
      : [
          parseInt(F.slice(0, 2), 16) / 255,
          parseInt(F.slice(2, 4), 16) / 255,
          parseInt(F.slice(4, 6), 16) / 255,
        ];
function C(F, t = []) {
  for (const s of F)
    if (s.kind === "p") t.push(...s.inlines);
    else for (const e of s.rows) for (const i of e.cells) C(i.blocks, t);
  return t;
}
class Y {
  constructor(t, s, e) {
    ((this.doc = t),
      (this.opts = s),
      (this.hooks = e),
      (this.images = new Map()),
      (this.imageFailures = 0),
      (this.pages = []),
      (this.total = 1),
      (this.y = 0),
      (this.top = 0),
      (this.bottom = 0),
      (this.atTop = !0),
      (this.pageNo = 0),
      (this.counting = !1),
      (this.sectionFirstPage = new Map()),
      (this.pagesOfSection = 0));
  }
  alive() {
    if (this.hooks.isCurrent && !this.hooks.isCurrent()) throw new J();
  }
  style(t, s, e) {
    const i = E(t.font);
    let o = t.sizePt ?? O,
      a = 0;
    (t.vert && ((a = t.vert === "sup" ? o * 0.35 : -o * 0.12), (o *= 0.65)),
      t.smallCaps && !t.caps && (o *= 0.85));
    const n = t.caps || t.smallCaps ? s.toUpperCase() : s;
    return {
      runs: this.fonts.runs(n, i, !!t.bold, !!t.italic),
      size: o,
      color: T(t.color),
      underline: !!t.underline,
      strike: !!t.strike,
      background: t.background ? T(t.background) : void 0,
      link: e,
      raise: a,
    };
  }
  widthOf(t, s) {
    let e = 0;
    for (const i of t) e += i.font.widthOfTextAtSize(i.text, s);
    return e;
  }
  atomsFor(t, s) {
    const e = [];
    let i = !0;
    const o = (a, n, h) => {
      const r = this.style(n, "", h),
        f = r.size,
        m = this.fonts
          .standard(E(n.font), !!n.bold, !!n.italic)
          .widthOfTextAtSize(" ", f),
        l = a.split(/( +)/);
      for (const u of l) {
        if (!u) continue;
        if (u[0] === " ") {
          for (let d = 0; d < u.length; d++)
            e.push({
              k: "space",
              w: m,
              size: f,
              background: r.background,
              link: h,
            });
          i = !0;
          continue;
        }
        u.split(new RegExp("(?<=[-–—])(?=[^-–—])")).forEach((d, P) => {
          const c = this.style(n, d, h);
          (e.push({
            k: "word",
            w: this.widthOf(c.runs, c.size),
            breakBefore: P > 0 || i,
            ...c,
          }),
            (i = !1));
        });
      }
    };
    for (const a of t)
      switch (a.t) {
        case "text":
          o(a.text.replace(/[\r\n]+/g, " "), a.p, a.link);
          break;
        case "field":
          o(a.kind === "PAGE" ? String(s) : String(this.total), a.p);
          break;
        case "footnoteRef":
          o(a.label, a.p);
          break;
        case "tab":
          (e.push({ k: "tab", size: a.p.sizePt ?? O }), (i = !0));
          break;
        case "br":
          (e.push({ k: "br", size: a.p.sizePt ?? O }), (i = !0));
          break;
        case "pagebreak":
          (e.push({ k: "pagebreak", size: O }), (i = !0));
          break;
        case "image": {
          const n = this.images.get(a.data);
          (n && e.push({ k: "image", w: a.wPt, h: a.hPt, image: n }), (i = !1));
          break;
        }
      }
    return e;
  }
  layoutPara(t, s, e) {
    const i = t.props,
      o = [];
    (t.list &&
      (o.push({ t: "text", text: t.list.text, p: t.list.p }),
      o.push({ t: "tab", p: t.list.p })),
      o.push(...t.inlines));
    const a = this.atomsFor(o, e);
    if (t.list) {
      const h = a.find((r) => r.k === "tab");
      h && h.k === "tab" && (h.implicit = !0);
    }
    return {
      kind: "p",
      lines: this.breakLines(a, i, s, t.base.sizePt ?? O),
      props: i,
      before: i.beforePt,
      after: i.afterPt,
      width: s,
      styleId: t.styleId,
    };
  }
  clusters(t) {
    const s = [];
    let e = null,
      i = !1;
    const o = () => {
      (e && s.push(e), (e = null));
    };
    for (const a of t)
      a.k === "space"
        ? (e ||
            (e = { kind: "text", atoms: [], width: 0, spaceW: 0, spaces: [] }),
          (e.spaceW += a.w),
          e.spaces.push(a),
          (i = !0))
        : a.k === "word"
          ? ((!e || i || a.breakBefore) &&
              (o(),
              (e = {
                kind: "text",
                atoms: [],
                width: 0,
                spaceW: 0,
                spaces: [],
              }),
              (i = !1)),
            e.atoms.push(a),
            (e.width += a.w))
          : a.k === "image"
            ? (o(),
              s.push({
                kind: "image",
                atoms: [a],
                width: a.w,
                spaceW: 0,
                spaces: [],
              }),
              (i = !1))
            : (o(),
              s.push({
                kind: a.k === "tab" ? "tab" : a.k === "br" ? "br" : "pb",
                atoms: [a],
                width: 0,
                spaceW: 0,
                spaces: [],
                implicit: a.k === "tab" ? a.implicit : void 0,
              }),
              (i = !1));
    return (o(), s);
  }
  breakLines(t, s, e, i) {
    const o = this.clusters(t),
      a = [],
      n = (k) => e - s.rightPt - (k ? s.leftPt + s.firstPt : s.leftPt);
    let h = s.leftPt + s.firstPt,
      r = n(!0),
      f = [],
      m = 0,
      l = 0,
      u = !1;
    const w = (k, g = !1) => {
        let p = m;
        f[f.length - 1];
        let b = 0,
          x = 0,
          y = 0;
        for (const A of f) {
          const B = A.atom;
          B.k === "word" ||
          B.k === "space" ||
          B.k === "tab" ||
          B.k === "br" ||
          B.k === "pagebreak"
            ? (y = Math.max(y, B.size))
            : B.k === "image" && (x = Math.max(x, B.h));
        }
        (f.length === 0 && (y = i), y === 0 && (y = i));
        const v = y * V;
        let z = v;
        const S = s.line;
        S.rule === "auto"
          ? (z = v * S.value)
          : S.rule === "exact"
            ? (z = S.value)
            : (z = Math.max(v, S.value));
        let L = z - y * 0.22;
        if (x > 0) {
          const A = x + y * 0.22;
          A > z && S.rule !== "exact"
            ? ((z = A), (L = x))
            : (L = Math.max(L, x));
        }
        ((b = z),
          a.push({
            items: f,
            startX: h,
            width: p,
            avail: r,
            height: b,
            baseline: L,
            gapCount: l,
            endsHard: k,
            pageBreakAfter: g,
            hasTab: u,
          }),
          (f = []),
          (m = 0),
          (l = 0),
          (u = !1),
          (h = s.leftPt),
          (r = n(!1)));
      },
      d = (k) => {
        const g = [...s.tabs];
        (s.firstPt < 0,
          g.push({ posPt: s.leftPt, align: "left" }),
          g.sort((y, v) => y.posPt - v.posPt));
        for (const y of g)
          if (y.posPt > k + 0.5) return { pos: y.posPt, align: y.align };
        const p = g.length ? g[g.length - 1].posPt : 0,
          b = Math.max(p, 0),
          x = Math.floor((k - b) / D) + 1;
        return { pos: b + x * D, align: "left" };
      },
      P = (k, g) => {
        for (const p of k.atoms) {
          const b = p.k === "word" || p.k === "image" ? p.w : 0;
          (f.push({ atom: p, x: m, gaps: l }), (m += b));
        }
        if (g && k.spaces.length) {
          for (const p of k.spaces)
            (f.push({ atom: p, x: m, gaps: l }),
              (m += p.k === "space" ? p.w : 0));
          l++;
        }
      };
    for (let k = 0; k < o.length; k++) {
      const g = o[k];
      if (g.kind === "br") {
        (f.push({ atom: g.atoms[0], x: m, gaps: l }), w(!0));
        continue;
      }
      if (g.kind === "pb") {
        w(!0, !0);
        continue;
      }
      if (g.kind === "tab") {
        const p = h + m,
          b =
            g.implicit && s.firstPt < 0 && p < s.leftPt + R
              ? { pos: s.leftPt, align: "left" }
              : d(p);
        let x = b.pos;
        if (b.align !== "left") {
          let y = 0;
          for (
            let v = k + 1;
            v < o.length &&
            o[v].kind !== "tab" &&
            o[v].kind !== "br" &&
            o[v].kind !== "pb";
            v++
          )
            y +=
              o[v].width +
              (o[v + 1] && o[v + 1].kind !== "tab" ? o[v].spaceW : 0);
          (b.align === "right"
            ? (x = b.pos - y)
            : (b.align, (x = b.pos - y / 2)),
            x < p && (x = p));
        }
        (f.push({ atom: g.atoms[0], x: m, gaps: l }),
          (m = Math.min(x - h, r + 200)),
          (u = !0));
        continue;
      }
      if (
        (m + g.width > r + R &&
          f.some((p) => p.atom.k === "word" || p.atom.k === "image") &&
          w(!1),
        g.width > r + R && g.kind === "text")
      ) {
        const p = this.splitLongCluster(g, Math.max(r, 20));
        p.forEach((b, x) => {
          (x > 0 && w(!1), P(b, x === p.length - 1));
        });
        continue;
      }
      P(g, !0);
    }
    w(!1);
    const c = a[a.length - 1];
    return ((c.endsHard = !0), a);
  }
  splitLongCluster(t, s) {
    const e = [];
    let i = { kind: "text", atoms: [], width: 0, spaceW: 0, spaces: [] };
    for (const o of t.atoms)
      if (o.k === "word")
        for (const a of o.runs)
          for (const n of Array.from(a.text)) {
            const h = a.font.widthOfTextAtSize(n, o.size);
            i.width + h > s &&
              i.atoms.length &&
              (e.push(i),
              (i = {
                kind: "text",
                atoms: [],
                width: 0,
                spaceW: 0,
                spaces: [],
              }));
            const r = i.atoms[i.atoms.length - 1];
            (r &&
            r.k === "word" &&
            r.runs[r.runs.length - 1].font === a.font &&
            r.color === o.color
              ? ((r.runs[r.runs.length - 1].text += n), (r.w += h))
              : i.atoms.push({
                  ...o,
                  runs: [{ text: n, font: a.font }],
                  w: h,
                  breakBefore: !1,
                }),
              (i.width += h));
          }
    return ((i.spaceW = t.spaceW), (i.spaces = t.spaces), e.push(i), e);
  }
  drawLine(t, s, e, i, o, a, n) {
    let h = 0,
      r = 0;
    const f = i.avail - i.width;
    o === "center"
      ? (h = f / 2)
      : o === "right"
        ? (h = f)
        : o === "justify" &&
          !i.endsHard &&
          !i.hasTab &&
          i.gapCount > 0 &&
          f > 0 &&
          (r = f / i.gapCount);
    const m = n + i.baseline,
      l = i.items.map((d) => a + i.startX + h + d.x + d.gaps * r),
      u = (d) =>
        d.k === "word" &&
        d.runs.some((P) => P.font instanceof U && _.test(P.text)),
      w = (d) =>
        d.k === "word" || d.k === "space" || d.k === "image" ? d.w : 0;
    for (let d = 0; d < i.items.length; d++) {
      if (!u(i.items[d].atom)) continue;
      let P = d;
      for (let g = d + 1; g < i.items.length; g++) {
        const p = i.items[g].atom;
        if (u(p)) P = g;
        else if (p.k !== "space") break;
      }
      const c = l[d],
        k = l[P] + w(i.items[P].atom);
      for (let g = d; g <= P; g++) l[g] = c + k - (l[g] + w(i.items[g].atom));
      d = P;
    }
    for (let d = 0; d < i.items.length; d++) {
      const P = i.items[d],
        c = P.atom,
        k = l[d];
      if (c.k === "word") {
        let g = k;
        const p = s - (m - c.raise);
        c.background &&
          t.drawRectangle({
            x: k,
            y: p - c.size * 0.22,
            width: c.w,
            height: c.size * 1.1,
            color: M(...c.background),
          });
        for (const b of c.runs)
          b.text &&
            (this.fonts.drawRun(t, b, {
              x: g,
              y: p,
              size: c.size,
              color: c.color,
            }),
            (g += b.font.widthOfTextAtSize(b.text, c.size)));
        (c.underline &&
          t.drawLine({
            start: { x: k, y: p - c.size * 0.12 },
            end: { x: k + c.w, y: p - c.size * 0.12 },
            thickness: Math.max(0.4, c.size * 0.05),
            color: M(...c.color),
          }),
          c.strike &&
            t.drawLine({
              start: { x: k, y: p + c.size * 0.28 },
              end: { x: k + c.w, y: p + c.size * 0.28 },
              thickness: Math.max(0.4, c.size * 0.05),
              color: M(...c.color),
            }),
          c.link &&
            e.push({
              x: k,
              y: p - c.size * 0.22,
              w: c.w,
              h: c.size * 1.1,
              url: c.link,
            }));
      } else
        c.k === "space"
          ? c.background &&
            t.drawRectangle({
              x: k,
              y: s - m - c.size * 0.22,
              width: c.w + (P.gaps >= 0, 0),
              height: c.size * 1.1,
              color: M(...c.background),
            })
          : c.k === "image" &&
            t.drawImage(c.image, { x: k, y: s - m, width: c.w, height: c.h });
    }
  }
  borderLine(t, s, e, i, o, a, n) {
    const h = M(...T(e.color)),
      r = Math.max(0.25, e.sizePt),
      f =
        e.style === "dashed"
          ? [r * 3, r * 2]
          : e.style === "dotted"
            ? [r, r * 1.5]
            : void 0,
      m = Math.abs(o - n) < 0.01,
      l = (u, w) =>
        t.drawLine({
          start: { x: i + (m ? 0 : u), y: s - (o + (m ? u : 0)) },
          end: { x: a + (m ? 0 : u), y: s - (n + (m ? u : 0)) },
          thickness: w,
          color: h,
          dashArray: f,
        });
    e.style === "double" ? (l(-r, r * 0.8), l(r, r * 0.8)) : l(0, r);
  }
  layoutTable(t, s, e) {
    const i = t.grid.reduce((u, w) => u + w, 0) || 1;
    let o = t.widthPt ?? (t.widthFraction ? t.widthFraction * s : i);
    const a = s - t.indentPt;
    (!t.widthPt && !t.widthFraction && i > a && (o = a), o > a && (o = a));
    const n = o / i,
      h = t.grid.map((u) => u * n),
      r = [0];
    h.forEach((u, w) => r.push(r[w] + u));
    const f = r[r.length - 1];
    let m = t.indentPt;
    t.align === "center"
      ? (m = (s - f) / 2)
      : t.align === "right" && (m = s - f);
    const l = [];
    return (
      t.rows.forEach((u) => {
        let w = 0;
        const d = [];
        for (const c of u.cells) {
          const k = Math.min(c.span, Math.max(1, h.length - w)),
            g = r[Math.min(w + k, h.length)] - r[w],
            p = {
              left: c.margins?.left ?? t.margins.left,
              right: c.margins?.right ?? t.margins.right,
              top: c.margins?.top ?? t.margins.top,
              bottom: c.margins?.bottom ?? t.margins.bottom,
            },
            b = Math.max(10, g - p.left - p.right),
            x = c.vMerge === "continue",
            y = x ? [] : this.layoutBlocks(c.blocks, b, e),
            v = y.reduce((z, S) => z + this.heightOf(S, !0), 0);
          (d.push({
            col: w,
            span: k,
            x: r[w],
            w: g,
            content: y,
            contentH: x ? 0 : v + p.top + p.bottom,
            shade: c.shade,
            borders: c.borders,
            vAlign: c.vAlign,
            margin: p,
            rowSpan: 1,
            hidden: x,
          }),
            (w += k));
        }
        let P = Math.max(
          0,
          ...d.filter((c) => !c.hidden).map((c) => c.contentH),
        );
        (u.heightPt && u.heightRule === "exact"
          ? (P = u.heightPt)
          : u.heightPt && (P = Math.max(P, u.heightPt)),
          P === 0 && (P = 12),
          l.push({
            height: P,
            cells: d,
            header: u.header,
            cantSplit: u.cantSplit,
          }));
      }),
      l.forEach((u, w) => {
        u.cells.forEach((d) => {
          if (t.rows[w].cells[u.cells.indexOf(d)].vMerge !== "restart") return;
          let c = 1;
          for (let g = w + 1; g < l.length; g++) {
            const p = l[g].cells.find((b) => b.col === d.col);
            if (p && p.hidden) c++;
            else break;
          }
          d.rowSpan = c;
          const k = l.slice(w, w + c).reduce((g, p) => g + p.height, 0);
          d.contentH > k && (l[w + c - 1].height += d.contentH - k);
        });
      }),
      { kind: "t", table: t, rows: l, width: f, x: m, cols: r }
    );
  }
  drawRow(t, s, e, i, o, a, n, h) {
    const r = i.rows[o],
      f = i.table.borders,
      m = o === i.rows.length - 1;
    r.cells.forEach((l, u) => {
      if (l.hidden) return;
      let w = r.height;
      for (let L = 1; L < l.rowSpan; L++)
        w += (h ?? i.rows.slice(o + 1))[L - 1]?.height ?? 0;
      const d = a + i.x + l.x;
      l.shade &&
        t.drawRectangle({
          x: d,
          y: s - (n + w),
          width: l.w,
          height: w,
          color: M(...T(l.shade)),
        });
      const P = w - l.contentH;
      let c =
        n +
        l.margin.top +
        (l.vAlign === "center" ? P / 2 : l.vAlign === "bottom" ? P : 0);
      for (const L of l.content)
        (this.drawLayout(t, s, e, L, d + l.margin.left, c),
          (c += this.heightOf(L, !0)));
      const k = o === 0,
        g = l.col === 0,
        p = l.col + l.span >= i.cols.length - 1,
        b = (L) => l.borders[L],
        x = (L, A) => (b(L) ? (b(L).style === "none" ? void 0 : b(L)) : A),
        y = x("top", k ? f.top : f.insideH),
        v = x("left", g ? f.left : f.insideV),
        z = x(
          "bottom",
          m || (l.rowSpan > 1 && o + l.rowSpan >= i.rows.length)
            ? f.bottom
            : void 0,
        ),
        S = x("right", p ? f.right : void 0);
      (y && this.borderLine(t, s, y, d, n, d + l.w, n),
        v && this.borderLine(t, s, v, d, n, d, n + w),
        z && this.borderLine(t, s, z, d, n + w, d + l.w, n + w),
        S && this.borderLine(t, s, S, d + l.w, n, d + l.w, n + w));
    });
  }
  layoutBlocks(t, s, e) {
    return t.map((i) =>
      i.kind === "p" ? this.layoutPara(i, s, e) : this.layoutTable(i, s, e),
    );
  }
  heightOf(t, s) {
    return t.kind === "p"
      ? t.lines.reduce((i, o) => i + o.height, 0) + (s ? t.before + t.after : 0)
      : t.rows.reduce((e, i) => e + i.height, 0);
  }
  drawLayout(t, s, e, i, o, a) {
    if (i.kind === "p") {
      let n = a + i.before;
      this.paraDecor(
        t,
        s,
        i,
        o,
        n,
        i.lines.reduce((h, r) => h + r.height, 0),
        !0,
        !0,
      );
      for (const h of i.lines)
        (this.drawLine(t, s, e, h, i.props.align, o, n), (n += h.height));
    } else {
      let n = a;
      i.rows.forEach((h, r) => {
        (this.drawRow(t, s, e, i, r, o, n), (n += h.height));
      });
    }
  }
  paraDecor(t, s, e, i, o, a, n, h) {
    const r = i + e.props.leftPt,
      f = e.width - e.props.leftPt - e.props.rightPt;
    e.props.shade &&
      t.drawRectangle({
        x: r,
        y: s - (o + a),
        width: f,
        height: a,
        color: M(...T(e.props.shade)),
      });
    const m = e.props.borders;
    (m.top && n && this.borderLine(t, s, m.top, r, o, r + f, o),
      m.bottom && h && this.borderLine(t, s, m.bottom, r, o + a, r + f, o + a),
      m.left && this.borderLine(t, s, m.left, r, o, r, o + a),
      m.right && this.borderLine(t, s, m.right, r + f, o, r + f, o + a));
  }
  newPage(t) {
    const s = this.pdf.addPage([t.widthPt, t.heightPt]);
    (this.pageNo++,
      (this.cur = { page: s, section: t, index: this.pageNo, links: [] }),
      this.pages.push(this.cur),
      (this.sec = t));
    const { top: e, bottom: i } = this.bodyBounds(
      t,
      this.pageNo === 1 && t.titlePg,
    );
    ((this.top = e),
      (this.bottom = t.heightPt - i),
      (this.y = this.top),
      (this.atTop = !0));
  }
  headerLayouts(t, s) {
    const e = t.titlePg && this.isFirstOfSection(t, s),
      i = (e ? t.headerFirst : t.header) ?? [],
      o = (e ? t.footerFirst : t.footer) ?? [],
      a = t.widthPt - t.marginLeft - t.marginRight;
    return {
      header: this.layoutBlocks(i, a, s),
      footer: this.layoutBlocks(o, a, s),
    };
  }
  isFirstOfSection(t, s) {
    return this.sectionFirstPage.get(t) === s;
  }
  bodyBounds(t, s) {
    const e = (s ? t.headerFirst : t.header) ?? [],
      i = (s ? t.footerFirst : t.footer) ?? [],
      o = t.widthPt - t.marginLeft - t.marginRight,
      a = e.length
        ? this.layoutBlocks(e, o, 1).reduce(
            (h, r) => h + this.heightOf(r, !0),
            0,
          )
        : 0,
      n = i.length
        ? this.layoutBlocks(i, o, 1).reduce(
            (h, r) => h + this.heightOf(r, !0),
            0,
          )
        : 0;
    return {
      top: Math.max(t.marginTop, e.length ? t.headerDist + a + 6 : 0),
      bottom: Math.max(t.marginBottom, i.length ? t.footerDist + n + 6 : 0),
    };
  }
  contentWidth() {
    return this.sec.widthPt - this.sec.marginLeft - this.sec.marginRight;
  }
  remaining() {
    return this.bottom - this.y;
  }
  placePara(t) {
    const s = this.contentWidth();
    let e = this.layoutPara(t, s, this.pageNo);
    (this.prevPara &&
      this.prevPara.contextual &&
      e.props.contextualSpacing &&
      this.prevPara.styleId === e.styleId &&
      ((e.before = 0),
      this.prevPara.pageNo === this.pageNo && (this.y -= this.prevPara.after)),
      e.props.pageBreakBefore && !this.atTop && this.newPage(this.sec));
    let o = this.atTop && this.pageNo > 1 ? 0 : e.before;
    this.atTop &&
      this.pageNo === 1 &&
      this.pagesOfSection === 0 &&
      (o = e.before);
    const a = e.lines.reduce((f, m) => f + m.height, 0),
      n = this.bottom - this.top;
    ((e.props.keepLines || (!e.props.widowControl && !1)) &&
      a + o > this.remaining() &&
      a <= n &&
      !this.atTop &&
      (this.newPage(this.sec),
      (e = this.layoutPara(t, this.contentWidth(), this.pageNo)),
      (o = 0)),
      (this.y += o),
      (this.atTop = !1));
    let h = 0;
    const r = e.lines.length;
    for (; h < r;) {
      let f = 0,
        m = 0;
      for (
        ;
        h + f < r &&
        m + e.lines[h + f].height <= this.remaining() + R &&
        ((m += e.lines[h + f].height), f++, !e.lines[h + f - 1].pageBreakAfter);
      );
      const l = f > 0 && e.lines[h + f - 1].pageBreakAfter;
      if (
        f < r - h &&
        !l &&
        (e.props.widowControl && r >= 4
          ? h === 0 && f === 1
            ? (f = 0)
            : r - (h + f) === 1 && f >= 2 && (f -= 1)
          : e.props.widowControl &&
            r >= 2 &&
            r < 4 &&
            h === 0 &&
            f >= 1 &&
            f < r &&
            (f = 0),
        f === 0)
      )
        if (
          this.y <= this.top + R ||
          this.remaining() >= this.bottom - this.top - R
        )
          f = 1;
        else {
          this.newPage(this.sec);
          continue;
        }
      const u = e.lines.slice(h, h + f),
        w = u.reduce((c, k) => c + k.height, 0);
      this.paraDecor(
        this.cur.page,
        this.sec.heightPt,
        e,
        this.sec.marginLeft,
        this.y,
        w,
        h === 0,
        h + f >= r,
      );
      let d = this.y;
      for (const c of u)
        (this.drawLine(
          this.cur.page,
          this.sec.heightPt,
          this.cur.links,
          c,
          e.props.align,
          this.sec.marginLeft,
          d,
        ),
          (d += c.height));
      ((this.y = d),
        (this.atTop = !1),
        (h += f),
        u[u.length - 1].pageBreakAfter
          ? this.newPage(this.sec)
          : h < r && this.newPage(this.sec));
    }
    ((this.y += e.after),
      (this.prevPara = {
        styleId: e.styleId,
        contextual: e.props.contextualSpacing,
        after: e.after,
        pageNo: this.pageNo,
      }));
  }
  placeTable(t) {
    const s = this.contentWidth(),
      e = this.layoutTable(t, s, this.pageNo),
      i = this.bottom - this.top,
      o = [];
    for (let h = 0; h < e.rows.length && e.rows[h].header; h++) o.push(h);
    const a = o.reduce((h, r) => h + e.rows[r].height, 0);
    this.prevPara = void 0;
    let n = 0;
    for (; n < e.rows.length;) {
      const h = e.rows[n];
      let r = h.height,
        f = 1;
      const m = Math.max(1, ...h.cells.map((l) => l.rowSpan));
      for (let l = 1; l < m && n + l < e.rows.length; l++)
        ((r += e.rows[n + l].height), f++);
      if (r > i - (n > 0 ? a : 0) + R) {
        for (let l = 0; l < f; l++) this.flattenRow(t, n + l);
        n += f;
        continue;
      }
      (r > this.remaining() + R
        ? this.atTop ||
          (this.newPage(this.sec),
          o.length &&
            n > o.length - 1 &&
            !o.includes(n) &&
            this.drawHeaderRows(e, o))
        : this.atTop &&
          this.pageNo > 1 &&
          n > 0 &&
          o.length &&
          !o.includes(n) &&
          this.y === this.top &&
          this.drawHeaderRows(e, o),
        (this.atTop = !1));
      for (let l = 0; l < f; l++)
        (this.drawRow(
          this.cur.page,
          this.sec.heightPt,
          this.cur.links,
          e,
          n + l,
          this.sec.marginLeft,
          this.y,
          e.rows.slice(n + l + 1),
        ),
          (this.y += e.rows[n + l].height));
      n += f;
    }
  }
  drawHeaderRows(t, s) {
    for (const e of s)
      (this.drawRow(
        this.cur.page,
        this.sec.heightPt,
        this.cur.links,
        t,
        e,
        this.sec.marginLeft,
        this.y,
        t.rows.slice(e + 1),
      ),
        (this.y += t.rows[e].height));
    this.atTop = !1;
  }
  flattenRow(t, s) {
    for (const e of t.rows[s].cells)
      for (const i of e.blocks) this.placeBlock(i, void 0);
  }
  placeBlock(t, s) {
    if ((this.alive(), t.kind === "p")) {
      if (t.props.keepNext && s && !this.atTop) {
        const e = this.contentWidth(),
          i = this.layoutPara(t, e, this.pageNo),
          o = i.lines.reduce((n, h) => n + h.height, 0) + i.before + i.after;
        let a = 0;
        if (s.kind === "p") {
          const n = this.layoutPara(s, e, this.pageNo);
          a = n.before + n.lines.slice(0, 2).reduce((h, r) => h + r.height, 0);
        } else a = this.layoutTable(s, e, this.pageNo).rows[0]?.height ?? 0;
        o + a > this.remaining() + R &&
          o + a <= this.bottom - this.top &&
          this.newPage(this.sec);
      }
      this.placePara(t);
    } else this.placeTable(t);
  }
  async embedImages() {
    const t = [];
    for (const s of this.doc.sections) {
      C(s.blocks, t);
      for (const e of [s.header, s.headerFirst, s.footer, s.footerFirst])
        e && C(e, t);
    }
    for (const s of this.doc.footnotes) C(s.blocks, t);
    for (const s of t)
      if (!(s.t !== "image" || this.images.has(s.data)))
        try {
          this.images.set(
            s.data,
            s.type === "png"
              ? await this.pdf.embedPng(s.data)
              : await this.pdf.embedJpg(s.data),
          );
        } catch {
          this.imageFailures++;
        }
  }
  allText() {
    const t = [];
    for (const s of this.doc.sections) {
      t.push(N(s.blocks));
      for (const e of [s.header, s.headerFirst, s.footer, s.footerFirst])
        e && t.push(N(e));
    }
    for (const s of this.doc.footnotes) t.push(N(s.blocks));
    return t.join(`
`);
  }
  runBody() {
    ((this.pages = []),
      (this.pageNo = 0),
      this.sectionFirstPage.clear(),
      (this.prevPara = void 0));
    const t = this.doc.sections.map((s) => ({ section: s, blocks: s.blocks }));
    if (this.doc.footnotes.length) {
      const s = this.doc.sections[this.doc.sections.length - 1],
        e = [
          {
            kind: "p",
            inlines: [],
            props: {
              ...Z(),
              borders: {
                top: { style: "single", sizePt: 0.5, color: "808080" },
              },
              afterPt: 4,
              beforePt: 12,
            },
            base: { sizePt: 4 },
          },
        ];
      for (const i of this.doc.footnotes)
        i.blocks.forEach((o, a) => {
          o.kind === "p" && a === 0
            ? e.push({
                ...o,
                inlines: [
                  {
                    t: "text",
                    text: `${i.label} `,
                    p: { sizePt: 8, vert: "sup" },
                  },
                  ...o.inlines,
                ],
                props: { ...o.props, afterPt: Math.min(o.props.afterPt, 2) },
              })
            : e.push(o);
        });
      t[t.length - 1] = { section: s, blocks: [...s.blocks, ...e] };
    }
    t.forEach(({ section: s, blocks: e }, i) => {
      const o = i > 0 ? this.doc.sections[i - 1] : void 0;
      if (
        s.breakType === "continuous" &&
        o &&
        o.widthPt === s.widthPt &&
        o.heightPt === s.heightPt &&
        this.pages.length > 0
      )
        ((this.sec = s), (this.cur = { ...this.cur, section: s }));
      else if (
        (this.newPage(s),
        this.sectionFirstPage.set(s, this.pageNo),
        (this.pagesOfSection = 0),
        s.titlePg)
      ) {
        const n = this.bodyBounds(s, !0);
        ((this.top = n.top),
          (this.bottom = s.heightPt - n.bottom),
          (this.y = this.top));
      }
      (e.forEach((n, h) => {
        (this.placeBlock(n, e[h + 1]), this.pagesOfSection++);
      }),
        this.hooks.progress?.((i + 1) / t.length));
    });
  }
  async build() {
    ((this.pdf = await W.create()),
      (this.fonts = new I(
        this.pdf,
        this.opts.fallbackLoader,
        this.opts.rasterEnv,
      )),
      await this.fonts.prepare(this.allText()),
      await this.embedImages(),
      this.alive(),
      this.runBody(),
      (this.total = Math.max(1, this.pages.length)));
    const t = this.total;
    ((this.pdf = await W.create()),
      (this.fonts = new I(
        this.pdf,
        this.opts.fallbackLoader,
        this.opts.rasterEnv,
      )),
      await this.fonts.prepare(this.allText()),
      this.fonts.scan(this.allText()),
      this.images.clear(),
      await this.embedImages(),
      this.runBody(),
      this.pages.length !== t && (this.total = this.pages.length));
    for (const a of this.pages) {
      const { header: n, footer: h } = this.headerLayouts(a.section, a.index),
        r = a.section.marginLeft;
      let f = a.section.headerDist;
      for (const u of n)
        (this.drawLayout(a.page, a.section.heightPt, a.links, u, r, f),
          (f += this.heightOf(u, !0)));
      const m = h.reduce((u, w) => u + this.heightOf(w, !0), 0);
      let l = a.section.heightPt - a.section.footerDist - m;
      for (const u of h)
        (this.drawLayout(a.page, a.section.heightPt, a.links, u, r, l),
          (l += this.heightOf(u, !0)));
      for (const u of a.links) {
        const w = this.pdf.context,
          d = w.obj({
            Type: "Annot",
            Subtype: "Link",
            Rect: [u.x, u.y, u.x + u.w, u.y + u.h],
            Border: [0, 0, 0],
            A: { S: $.of("URI"), URI: H.of(u.url) },
          });
        a.page.node.addAnnot(w.register(d));
      }
    }
    G(this.pdf, {
      title: this.doc.title,
      author: this.doc.author,
      fallbackTitle: this.opts.fallbackTitle,
    });
    const s = [],
      e = j(this.fonts);
    e && s.push(e);
    const i = this.doc.warnings;
    return (
      i.textBoxes &&
        s.push(
          `${i.textBoxes} text ${i.textBoxes === 1 ? "box was" : "boxes were"} not included.`,
        ),
      i.charts &&
        s.push(
          `${i.charts} ${i.charts === 1 ? "chart was" : "charts were"} not included.`,
        ),
      i.pictures + this.imageFailures &&
        s.push(
          `${i.pictures + this.imageFailures} ${i.pictures + this.imageFailures === 1 ? "picture" : "pictures"} could not be included.`,
        ),
      i.columnSections &&
        s.push(
          `${i.columnSections} ${i.columnSections === 1 ? "section is" : "sections are"} set in columns in Word and shown here as a single column.`,
        ),
      await this.fonts.flushRasters(),
      {
        bytes: await this.pdf.save(),
        pages: this.pages.length,
        warnings: s,
        replacedChars: this.fonts.replacedCount,
      }
    );
  }
}
function Z() {
  return {
    align: "left",
    beforePt: 0,
    afterPt: 0,
    line: { value: 1, rule: "auto" },
    leftPt: 0,
    rightPt: 0,
    firstPt: 0,
    keepNext: !1,
    keepLines: !1,
    pageBreakBefore: !1,
    contextualSpacing: !1,
    widowControl: !0,
    borders: {},
    tabs: [],
  };
}
async function ot(F, t, s = {}) {
  return new Y(F, t, s).build();
}
export { J as DocxPdfCancelled, ot as convertDocxDocumentToPdf };
//# sourceMappingURL=docxToPdf-K5O8yYaD.js.map
