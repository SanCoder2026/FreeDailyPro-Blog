import { k as O, u as R } from "./index-BRvxULIc.js";
import { P as W, r as G } from "./pdfFonts-Ckcqm3Ic.js";
import { s as H } from "./pdfMetadata-CcxIhQF2.js";
import "./index-CnXdQaNG.js";
import "./vendor-react-D01g8YgM.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
const I = { A4: [595.28, 841.89], Letter: [612, 792] };
function K(i) {
  const e = new Uint8Array(i);
  return e[0] === 255 && e[1] === 254
    ? new TextDecoder("utf-16le").decode(e.subarray(2))
    : e[0] === 254 && e[1] === 255
      ? new TextDecoder("utf-16be").decode(e.subarray(2))
      : new TextDecoder("utf-8").decode(e).replace(/^﻿/, "");
}
async function N(i, e = {}) {
  const [g, u] = I[e.pageSize ?? "A4"],
    o = e.fontSize ?? 11,
    f = 56,
    F = o * 1.4,
    a = await O.create(),
    r = new W(a, e.fallbackLoader, e.rasterEnv);
  (await r.prepare(i), r.scan(i));
  const h = g - f * 2;
  let T = a.addPage([g, u]),
    p = u - f;
  const b = () => {
      ((T = a.addPage([g, u])), (p = u - f));
    },
    D = "sans",
    m = (n) => {
      p < f + o && b();
      let x = f;
      for (const l of r.runs(n, D))
        (r.drawRun(T, l, { x, y: p - o, size: o, color: R(0, 0, 0) }),
          (x += l.font.widthOfTextAtSize(l.text, o)));
      p -= F;
    },
    c = (n) => r.width(n, o, D),
    S = i.split(/\r\n|\r|\n/);
  for (let n = 0; n < S.length; n++) {
    if (e.isCurrent && !e.isCurrent()) throw new Error("cancelled");
    S[n].split("\f").forEach((l, L) => {
      L > 0 && b();
      const k = l.replace(/\t/g, "    "),
        d = k.match(/^ */)[0].length,
        z = k.slice(d),
        y = d * c(" ");
      if (!z.trim()) {
        m("");
        return;
      }
      let t = " ".repeat(d),
        w = y;
      for (const P of z.split(" ")) {
        const C = c(P),
          M = t.trim() ? " " : "";
        if (
          (t.trim() && w + c(M) + C > h && (m(t), (t = " ".repeat(d)), (w = y)),
          C > h - y)
        ) {
          let s = "";
          for (const v of P)
            (c(t + s + v) > h &&
              (s || t.trim()) &&
              (m(t + s), (t = " ".repeat(d)), (s = "")),
              (s += v));
          ((t += s), (w = c(t)));
        } else ((t += (t.trim() ? " " : "") + P), (w = c(t)));
      }
      m(t);
    });
  }
  H(a, { title: e.title, fallbackTitle: "Text document" });
  const A = [],
    E = G(r);
  return (
    E && A.push(E),
    await r.flushRasters(),
    { bytes: await a.save(), pages: a.getPageCount(), warnings: A }
  );
}
export { I as PAGE_SIZES, N as convertTextToPdfDocument, K as decodeTextFile };
//# sourceMappingURL=textToPdf-BuGdG5vq.js.map
