// word-to-pdf battery: fresh context per case (wp-cases.json; argv[2] = IDs). Drop the file, record the pre-convert notes (scripts list, mode line, default mode, errors),
// pick the Output mode / page size if given, Convert to PDF, poll up to 240 s, record the result text, warnings, toasts, trial count and every non-asset request (POST sizes).
// The PDF is captured from memory (Blob Proxy recording application/pdf blobs only). Download is never pressed.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/24-word-to-pdf/live/'; const T = '/workspace/deep/24-word-to-pdf/testfiles/'; const URL = 'https://www.freedailypro.com/tool/word-to-pdf'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const ids = process.argv[2] ? process.argv[2].split(',') : null; const tag = ids ? '-' + ids.join('_') : '';
const cases = JSON.parse(fs.readFileSync(__dirname + '/wp-cases.json')).filter(c => !ids || ids.includes(c.id));
const HOOK = `(() => { window.__pdf = []; const OB = window.Blob; window.Blob = new Proxy(OB, { construct(t, a) { const b = Reflect.construct(t, a); try { if (/pdf/.test((a[1] || {}).type || '')) window.__pdf.push(b); } catch (e) {} return b; } }); })();`;
const ADS = /googlesyndication|doubleclick|adservice|google-analytics|analytics\.google|googletagmanager|media\.net|adtrafficquality|gstatic|fundingchoices|youtube|ytimg|ggpht/;
(async () => { const b = await chromium.launch(); const R = { t: now(), cases: [] }; const save = () => fs.writeFileSync(OUT + 'battery' + tag + '.json', JSON.stringify(R, null, 1));
 for (const c of cases) { const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); await ctx.addInitScript(HOOK); const p = await ctx.newPage(); p.setDefaultTimeout(12000);
  const r = { id: c.id, file: c.file, mode: c.mode, size: c.size, t: now(), reqs: [], errs: [] };
  p.on('console', m => { if (m.type() === 'error' && !/no_div|adsbygoogle|Permissions policy/.test(m.text())) r.errs.push(m.text().slice(0, 200)); });
  try { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
   const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday; r.start = await used(); r.accept = await p.locator('main input[type=file]').first().getAttribute('accept');
   p.on('request', q => { const u = q.url(); if (ADS.test(u) || /\/assets\//.test(u) || /insight\.hit|funnel\.hit|auth\.me|version\.json/.test(u)) return; r.reqs.push(q.method() + ' ' + u.replace(/\?.*/, '').slice(0, 110) + (q.postData() ? ' post=' + q.postData().length : '')); });
   await p.locator('main input[type=file]').first().setInputFiles(T + c.file); await p.waitForTimeout(3500);
   const main = () => p.evaluate(() => document.querySelector('main').innerText);
   let m = await main(); const i0 = m.indexOf(c.file.split('.')[0]); r.preText = m.slice(Math.max(0, m.indexOf('Large files')), m.indexOf('NEXT STEP')).slice(0, 900);
   r.pressed = await p.evaluate(() => [...document.querySelectorAll('main button[aria-pressed=true], main [data-state=on], main [aria-checked=true]')].map(b => b.innerText.trim()).filter(Boolean));
   const cv = p.getByRole('button', { name: 'Convert to PDF', exact: true }); if (!(await cv.count())) { r.noConvert = true; r.toasts = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim())); throw new Error('no Convert button'); }
   if (c.mode) await p.getByRole('button', { name: c.mode, exact: true }).click(); if (c.size) await p.getByRole('button', { name: c.size, exact: true }).click().catch(e => r.sizeErr = String(e).slice(0, 80));
   await p.waitForTimeout(400); r.modeLine = await p.evaluate(() => { const t = document.querySelector('main').innerText; return (t.match(/(The page size[^\n]*|Pages are[^\n]*|Every page[^\n]*|Only the[^\n]*|[^\n]*(would lose|will be lost|not carried|shown as one column)[^\n]*)/g) || []).slice(0, 4); });
   const t0 = Date.now(); await cv.click();
   for (let i = 0; i < 480; i++) { m = await main(); const done = m.match(/[^\n]*\d+ pages?[^\n]*(KB|MB|bytes)[^\n]*/); const err = m.match(/(The conversion failed[^\n]*|There is no text[^\n]*)/); if (done) { r.result = done[0]; break; } if (err) { r.error = err[0]; break; } if (await p.getByRole('button', { name: /^Download/ }).count()) { r.result = 'Download shown'; break; } await p.waitForTimeout(500); }
   r.ms = Date.now() - t0; if (!r.result && !r.error) r.timeout = true;
   await p.waitForTimeout(600); m = await main(); r.resultText = m.slice(m.indexOf('Convert to PDF') > 0 ? 0 : 0).match(/(Converted[\s\S]{0,500}|[^\n]*\d+ pages?[\s\S]{0,500})/)?.[0];
   r.toasts = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim())); r.after = await used();
   r.buttons = await p.evaluate(() => [...document.querySelectorAll('main button')].map(b => b.innerText.trim()).filter(x => /Download|Convert another|Save|Copy|Share|Drive|cloud|different file/i.test(x) && x.length < 60));
   const bytes = await p.evaluate(async () => { const x = window.__pdf.pop(); return x ? [...new Uint8Array(await x.arrayBuffer())] : []; }); if (bytes.length) { r.outFile = `out-${c.id}.pdf`; fs.writeFileSync(OUT + r.outFile, Buffer.from(bytes)); r.outBytes = bytes.length; }
   await p.screenshot({ path: OUT + `res-${c.id}.png` });
  } catch (e) { r.fail = String(e).slice(0, 200); }
  R.cases.push(r); save(); console.log(c.id, r.result || r.error || r.fail || (r.timeout ? 'TIMEOUT' : ''), r.ms, r.outBytes || '', r.start + '->' + r.after, JSON.stringify(r.reqs), JSON.stringify(r.toasts || [])); await ctx.close(); }
 R.t2 = now(); save(); await b.close(); })();
