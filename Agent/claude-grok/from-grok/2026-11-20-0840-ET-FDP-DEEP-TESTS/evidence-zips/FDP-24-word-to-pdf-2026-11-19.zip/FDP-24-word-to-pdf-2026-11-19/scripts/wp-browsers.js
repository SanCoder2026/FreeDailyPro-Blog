// word-to-pdf in Firefox and WebKit: rich.docx in Keep formatting and Exact look; records the result line, page errors; PDF captured from memory to compare. Download not pressed.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/24-word-to-pdf/live/'; const T = '/workspace/deep/24-word-to-pdf/testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const HOOK = fs.readFileSync(__dirname + '/wp-battery.js', 'utf8').match(/const HOOK = `([^`]*)`/)[1];
(async () => { const R = { t: now() };
 for (const n of ['firefox', 'webkit']) { const b = await pw[n].launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); await c.addInitScript(HOOK); const p = await c.newPage(); p.setDefaultTimeout(15000); const errs = []; p.on('pageerror', e => errs.push(String(e).slice(0, 150))); const r = {};
  try { await p.goto('https://www.freedailypro.com/tool/word-to-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
   for (const mode of ['Keep formatting (selectable text)', 'Exact look (pages as pictures)']) { await p.locator('main input[type=file]').first().setInputFiles(T + 'rich.docx'); await p.waitForTimeout(3000); await p.getByRole('button', { name: mode, exact: true }).click(); await p.getByRole('button', { name: 'Convert to PDF', exact: true }).click();
    const ok = await p.getByText(/^\d+ pages? · /).first().waitFor({ timeout: 90000 }).then(() => true).catch(() => false); const k = mode.split(' ')[0]; r[k] = { ok, line: ok ? await p.getByText(/^\d+ pages? · /).first().innerText() : null };
    const bytes = await p.evaluate(async () => { const x = window.__pdf.pop(); return x ? [...new Uint8Array(await x.arrayBuffer())] : []; }); if (bytes.length) fs.writeFileSync(OUT + `br-${n}-${k}.pdf`, Buffer.from(bytes));
    await p.getByRole('button', { name: 'Convert another file', exact: true }).click().catch(() => {}); await p.waitForTimeout(1000); }
  } catch (e) { r.err = String(e).slice(0, 200); } r.errs = errs.filter(x => !/googleads|doubleclick/.test(x)); R[n] = r; await b.close(); }
 R.t2 = now(); fs.writeFileSync(OUT + 'browsers.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); })();
