// word-to-pdf: the inline messages for broken.docx and renamed.docx (polled 10 s after the drop) — no conversion.
const { chromium } = require('playwright'); const fs = require('fs');
(async () => { const b = await chromium.launch(); const R = [];
 for (const f of ['broken.docx', 'renamed.docx', 'rich.doc']) { const p = await (await b.newContext()).newPage(); await p.goto('https://www.freedailypro.com/tool/word-to-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
  await p.locator('main input[type=file]').first().setInputFiles('/workspace/deep/24-word-to-pdf/testfiles/' + f); const seen = [];
  for (let i = 0; i < 30; i++) { const s = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast],[role=alert]')].map(x => x.innerText.trim().replace(/\n/g, ' / ')).concat(document.querySelector('main').innerText.match(/[^\n]*(not a Word|could not be read|damaged|can't be used|not supported)[^\n]*/g) || [])); s.forEach(x => { if (!seen.includes(x)) seen.push(x); }); await p.waitForTimeout(300); }
  await p.screenshot({ path: '/workspace/deep/24-word-to-pdf/live/err-' + f + '.png' }); R.push({ f, seen }); await p.context().close(); }
 fs.writeFileSync('/workspace/deep/24-word-to-pdf/live/errors.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
