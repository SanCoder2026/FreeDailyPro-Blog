// word-to-pdf: starting count; keyboard path to the drop zone; labels; axe idle + after a result; result buttons; Stop during an Exact-look run of the 200-page file;
// phones (iPhone SE, Pixel 7) convert rich.docx by tap. Download is not pressed here (see wp-dl.js). "Open from Google Drive" is not clicked.
const { chromium, devices } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/24-word-to-pdf/live/'; const T = '/workspace/deep/24-word-to-pdf/testfiles/'; const URL = 'https://www.freedailypro.com/tool/word-to-pdf';
const AXE = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8'); const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const axe = async p => { await p.addScriptTag({ content: AXE }); return p.evaluate(async () => (await axe.run(document.querySelector('main'), { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'best-practice'] }, resultTypes: ['violations'] })).violations.map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length, t: v.nodes.slice(0, 3).map(n => n.target.join(' ')) }))); };
const dialog = async p => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
(async () => { const b = await chromium.launch(); const R = { t: now() };
 const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(12000);
 await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
 R.start = await used(); R.strip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]); R.axeIdle = await axe(p);
 let chooser = false; p.on('filechooser', () => { chooser = true; }); const seq = [];
 for (let i = 0; i < 60; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('role') || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50).replace(/\n/g, ' '); }); seq.push(a); if (/Drop a .docx/i.test(a)) { await p.keyboard.press('Enter'); await p.waitForTimeout(1200); seq.push('ENTER -> chooser=' + chooser); break; } }
 R.kbd = { tabs: seq.length, last: seq.slice(-3), chooser };
 // labels of the options
 await p.locator('main input[type=file]').first().setInputFiles(T + 'rich.docx'); await p.waitForTimeout(3000);
 R.optionLabels = await p.evaluate(() => [...document.querySelectorAll('main select, main input:not([type=file])')].map(e => ({ tag: e.tagName, id: e.id, label: e.labels && e.labels[0] ? e.labels[0].innerText.trim() : null, aria: e.getAttribute('aria-label'), placeholder: e.getAttribute('placeholder') })));
 R.axeDrop = await axe(p);
 await p.getByRole('button', { name: 'Convert to PDF', exact: true }).click(); await p.getByText(/^\d+ pages? · /).first().waitFor({ timeout: 60000 });
 R.resultButtons = await p.evaluate(() => [...document.querySelectorAll('main button, main a')].map(b => b.innerText.trim()).filter(x => x && x.length < 40).slice(0, 40));
 R.resultText = await p.evaluate(() => (document.querySelector('main').innerText.match(/\d+ pages? ·[\s\S]{0,600}/) || [''])[0]);
 R.axeResult = await axe(p); R.liveRegions = await p.evaluate(() => [...document.querySelectorAll('main [aria-live],main [role=status],main [role=alert]')].map(e => ({ live: e.getAttribute('aria-live'), role: e.getAttribute('role'), text: e.innerText.slice(0, 80) })));
 await p.screenshot({ path: OUT + 'result-rich.png', fullPage: true }); R.usedAfterConvert = await used();
 // Stop during Exact look
 await p.getByRole('button', { name: 'Convert another file', exact: true }).click(); await p.waitForTimeout(800);
 await p.locator('main input[type=file]').first().setInputFiles(T + 'long_200p.docx'); await p.waitForTimeout(2500); await p.getByRole('button', { name: 'Exact look (pages as pictures)', exact: true }).click(); await p.getByRole('button', { name: 'Convert to PDF', exact: true }).click(); await p.waitForTimeout(2500);
 const stop = p.getByRole('button', { name: /^Stop/ }); R.stop = { present: await stop.count() }; if (R.stop.present) { R.stop.statusBefore = await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*(\d+%|Converting|Working|page)[^\n]*/) || [''])[0]); await stop.first().click(); await p.waitForTimeout(1500); R.stop.after = await p.evaluate(() => (document.querySelector('main').innerText.match(/(Convert to Word|Converted:[^\n]*|Stopped[^\n]*|cancel[^\n]*)/i) || [''])[0]); R.stop.toasts = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim())); }
 await p.screenshot({ path: OUT + 'stop.png' });
 // Quick Buy
 const qb = p.getByRole('button', { name: 'Quick Buy', exact: true }); R.quickBuy = { count: await qb.count() };
 if (R.quickBuy.count) { const pop = c.waitForEvent('page', { timeout: 5000 }).catch(() => null); const u0 = p.url(); await qb.first().click(); const pg = await pop; await p.waitForTimeout(2500); R.quickBuy.dialog = await dialog(p); R.quickBuy.url = p.url() !== u0 ? p.url().slice(0, 100) : null; R.quickBuy.emailField = await p.locator('input[type=email]').count(); if (pg) { R.quickBuy.popup = pg.url().slice(0, 100); await pg.close(); } await p.screenshot({ path: OUT + 'quickbuy.png' }); }
 R.end = await used(); await c.close();
 for (const [nm, d] of [['iphone-se', devices['iPhone SE']], ['pixel-7', devices['Pixel 7']]]) { const { defaultBrowserType, ...dd } = d; const c2 = await b.newContext(dd); const q = await c2.newPage(); q.setDefaultTimeout(12000);
  await q.goto(URL, { waitUntil: 'domcontentloaded' }); await q.waitForTimeout(4000); await q.locator('main input[type=file]').first().setInputFiles(T + 'rich.docx'); await q.waitForTimeout(2500);
  await q.getByRole('button', { name: 'Convert to PDF', exact: true }).tap(); const ok = await q.getByText(/^\d+ pages? · /).first().waitFor({ timeout: 60000 }).then(() => true).catch(() => false);
  const lay = await q.evaluate(() => { const d = [...document.querySelectorAll('main button')].find(b => /^Download$/.test(b.innerText)); return { vh: innerHeight, sw: document.documentElement.scrollWidth, vw: innerWidth, downloadY: d ? Math.round(d.getBoundingClientRect().top + scrollY) : null }; });
  await q.screenshot({ path: OUT + `layout-${nm}.png`, fullPage: true }); R[nm] = { ok, ...lay }; await c2.close(); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate-kbd.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
