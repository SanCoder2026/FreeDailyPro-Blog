// word-to-pdf probe: starting count, JS chunks loaded, controls before/after dropping rich.docx and after pressing the main convert button (if any). Requests to freedailypro.com logged. Download not pressed.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/24-word-to-pdf/live/'; const T = '/workspace/deep/24-word-to-pdf/testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(10000); const R = { t: now(), req: [], js: [] };
 p.on('request', r => { const u = new URL(r.url()); if (/freedailypro/.test(u.host)) { R.req.push(r.method() + ' ' + u.pathname.slice(0, 80) + (r.postData() ? ' post=' + r.postData().length : '')); if (/\.m?js$/.test(u.pathname)) R.js.push(u.pathname); } });
 await p.goto('https://www.freedailypro.com/tool/word-to-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 R.ls = await p.evaluate(() => localStorage.getItem('fdp-usage-v1')); R.strip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]);
 const btns = () => p.evaluate(() => [...document.querySelectorAll('main button, main [role=button], main a[download], main input, main select, main [role=combobox], main [role=switch], main [role=checkbox]')].map(e => e.tagName + ':' + (e.type || '') + ' ' + (e.getAttribute('aria-label') ? '[' + e.getAttribute('aria-label') + '] ' : '') + (e.innerText || e.value || '').trim().replace(/\n/g, ' ').slice(0, 50)).filter(x => !/(About|Common|Details|Guides|Share this|Create Shortcut|Subscribe|See File)/.test(x)));
 R.idle = await btns(); R.textIdle = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 2500)); R.req0 = R.req.length;
 await p.locator('main input[type=file]').first().setInputFiles(T + 'rich.docx'); await p.waitForTimeout(5000);
 R.afterDrop = await btns(); R.textDrop = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 3500)); await p.screenshot({ path: OUT + 'probe-drop.png', fullPage: true });
 R.usedAfterDrop = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 R.reqAfter = R.req.slice(R.req0); R.t2 = now();
 fs.writeFileSync(OUT + 'probe.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
