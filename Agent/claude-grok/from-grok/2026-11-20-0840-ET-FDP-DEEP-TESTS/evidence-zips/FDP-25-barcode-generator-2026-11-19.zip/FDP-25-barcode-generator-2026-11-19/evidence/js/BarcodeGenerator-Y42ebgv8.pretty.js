import { r as a, j as e } from "./vendor-react-D01g8YgM.js";
import { J as ce } from "./jszip.min-CT0ZA6V1.js";
import { e as b, B as Z, I as M, T as me, f as C } from "./index-D2ZT81un.js";
import { t as he } from "./csv-DBvSFDe9.js";
import { T as ue, D as V, d as G } from "./ToolPage-DS5jbfzr.js";
import { S, a as T, b as P, c as F, d } from "./select-DC0cHVOZ.js";
import { T as pe } from "./ToolInfoSection-M0kcUBq8.js";
import { d as xe, G as _, e as $ } from "./qrHelpers-av3Dz-dA.js";
import { g as R, B as be, P as w, a as H } from "./codeGeneration-D1g4LVfX.js";
import { T as fe } from "./ToolSteps-DtiMymsE.js";
import { u as ge } from "./useDownloadedResult-C1FfMpBH.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./useUploadApi-CeBVbB2U.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-mA9gIB_c.js";
import "./share-2-wJ7OG3q6.js";
import "./copy-DxyF2bO9.js";
import "./workflowCta-QcLjv4ms.js";
import "./UsageAndUpgradeStrip-Ckl_cEoN.js";
import "./access-BBg1iIm1.js";
import "./useAdminAccess-D2xxeUJv.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-BaZhqv4P.js";
import "./map-pin-DiPhQKiV.js";
import "./FaqSection-DgbFc-d2.js";
import "./ToolVideoEmbed-DltoCXpM.js";
import "./GuideLinks-BsEl-oB0.js";
import "./blog-Cqpj3gtZ.js";
import "./info-BGlOhDp4.js";
import "./productCards-CAZfINO_.js";
import "./layers-B7zHnkyf.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./chevron-up-Bx33pgGu.js";
import "./CollapsibleText-CmqWEytu.js";
import "./JsBarcode-QeG8kXh7.js";
import "./browser-CMr8NRjw.js";
const U = 200,
  J = "590123412345",
  L = {
    what: "Generates a real, scannable barcode — Code 128, EAN-13, EAN-8, UPC-A, Code 39, or ITF-14 — from a number or text value, ready to download and use on inventory labels, product packaging, or shipping materials.",
    how: `Choose a barcode format, enter the value to encode, and optionally describe what the barcode is for — that description is printed above the barcode in the downloaded PNG (the SVG download leaves it out), so anyone looking at the file later (not just the barcode reader) knows what it's for. You can switch the digits under the bars on or off and pick a taller or shorter bar. For many labels at once, choose "A list": paste one value per line and download one ZIP with a file per value; lines that cannot be encoded are listed with the reason and left out.`,
    tip: "Each format has its own rules for valid input — EAN-13 needs 12 digits (the check digit is added for you), UPC-A needs 11, Code 128 accepts letters, numbers and symbols but no accents. If generation fails the tool tells you exactly what to change. The PNG downloads at 4× (300 dpi) by default; the 1× option is for screens, and the SVG scales to any print size.",
  };
function ot() {
  const [o, W] = a.useState(J),
    [s, X] = a.useState("EAN13"),
    [j, Y] = a.useState(""),
    O = a.useRef(null),
    [f, k] = a.useState(null),
    [h, B] = a.useState(null),
    [g, q] = a.useState("4"),
    [l, D] = a.useState("one"),
    [u, K] = a.useState(!0),
    [p, Q] = a.useState("80"),
    [E, ee] = a.useState(""),
    [y, te] = a.useState("png"),
    [I, z] = a.useState(!1),
    [se, ae] = a.useState(!1),
    [N, oe] = a.useState(0);
  a.useEffect(() => {
    let t = !1;
    return (
      (async () => {
        if (!o.trim()) {
          (k(null), B(null));
          return;
        }
        try {
          const c = await R(o, s, {
            caption: j,
            displayValue: u,
            barHeight: Number(p),
          });
          if (t) return;
          (k(null), B(c));
          const v = O.current;
          if (v) {
            const n = new Blob([new Uint8Array(c)], { type: "image/png" }),
              x = URL.createObjectURL(n),
              m = new Image();
            ((m.onload = () => {
              (oe(m.width),
                (v.width = m.width),
                (v.height = m.height),
                v.getContext("2d")?.drawImage(m, 0, 0),
                URL.revokeObjectURL(x));
            }),
              (m.src = x));
          }
        } catch (c) {
          if (t) return;
          (k(c instanceof Error ? c.message : "Couldn't generate this barcode"),
            B(null));
        }
      })(),
      () => {
        t = !0;
      }
    );
  }, [o, s, j, u, p]);
  const r = a.useMemo(() => xe(E, s, y), [E, s, y]),
    i = r.rows.slice(0, U),
    re = r.rows.length > U,
    A = l === "list" ? i.length > 0 : o !== J && o.trim() !== "" && !!h && !f,
    le = ge(l === "list" ? (i.length > 0 ? i : null) : A ? h : null),
    ie = async () => {
      if (!(i.length === 0 || I)) {
        z(!0);
        try {
          const t = new ce(),
            c = { displayValue: u, barHeight: Number(p) };
          for (let n = 0; n < i.length; n++) {
            const x = i[n];
            (y === "svg"
              ? t.file(x.file, H(x.value, s, c))
              : t.file(x.file, await R(x.value, s, { ...c, scale: 4, dpi: w })),
              n % 5 === 4 && (await new Promise((m) => setTimeout(m, 0))));
          }
          t.file(
            "index.csv",
            he(
              i.map((n) => ({ file: n.file, value: n.value })),
              [
                { key: "file", header: "file" },
                { key: "value", header: "value" },
              ],
            ),
          );
          const v = await t.generateAsync({ type: "blob" });
          G(v, `barcodes-${s.toLowerCase()}.zip`);
        } catch (t) {
          C.error(t instanceof Error ? t.message : "Couldn't build the ZIP");
        } finally {
          z(!1);
        }
      }
    },
    ne = async () => {
      if (!h) {
        C.error("Fix the barcode value first");
        return;
      }
      try {
        const t =
          g === "1"
            ? h
            : await R(o, s, {
                caption: j,
                displayValue: u,
                barHeight: Number(p),
                scale: Number(g),
                ...(g === "4" ? { dpi: w } : {}),
              });
        G(new Blob([new Uint8Array(t)], { type: "image/png" }), $(o, s, "png"));
      } catch (t) {
        C.error(
          t instanceof Error ? t.message : "Couldn't generate this barcode",
        );
      }
    },
    de = () => {
      try {
        G(
          new Blob([H(o, s, { displayValue: u, barHeight: Number(p) })], {
            type: "image/svg+xml",
          }),
          $(o, s, "svg"),
        );
      } catch (t) {
        C.error(
          t instanceof Error ? t.message : "Couldn't generate this barcode",
        );
      }
    };
  return e.jsxs(ue, {
    children: [
      e.jsx(fe, {
        toolId: "barcode-generator",
        state: {
          formatChosen: se || s !== "EAN13" || A,
          valueReady: A,
          optionsChosen: j.trim() !== "" || !u || p !== "80" || g !== "4",
          downloaded: le,
        },
      }),
      e.jsxs("div", {
        className: "max-w-md mx-auto space-y-4",
        children: [
          e.jsxs("div", {
            children: [
              e.jsx(b, { htmlFor: "bc-format", children: "Format" }),
              e.jsxs(S, {
                value: s,
                onValueChange: (t) => {
                  (X(t), ae(!0));
                },
                children: [
                  e.jsx(T, { id: "bc-format", children: e.jsx(P, {}) }),
                  e.jsx(F, {
                    children: be.map((t) =>
                      e.jsx(d, { value: t.value, children: t.label }, t.value),
                    ),
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("div", {
            className: "flex gap-2",
            role: "group",
            "aria-label": "One barcode or a list",
            children: [
              e.jsx(Z, {
                size: "sm",
                variant: l === "one" ? "default" : "outline",
                onClick: () => D("one"),
                "data-testid": "bc-mode-one",
                children: "One barcode",
              }),
              e.jsx(Z, {
                size: "sm",
                variant: l === "list" ? "default" : "outline",
                onClick: () => D("list"),
                "data-testid": "bc-mode-list",
                children: "A list (ZIP)",
              }),
            ],
          }),
          l === "one" &&
            e.jsxs("div", {
              children: [
                e.jsx(b, { htmlFor: "bc-value", children: "Barcode Value" }),
                e.jsx(M, {
                  id: "bc-value",
                  type: "text",
                  inputMode: ["EAN13", "EAN8", "UPC", "ITF14"].includes(s)
                    ? "numeric"
                    : "text",
                  autoComplete: "off",
                  spellCheck: !1,
                  value: o,
                  onChange: (t) => W(t.target.value),
                  "aria-invalid": !!f || void 0,
                  "data-testid": "bc-value",
                }),
                !o.trim() &&
                  e.jsx("p", {
                    role: "alert",
                    className: "text-xs text-destructive mt-1",
                    "data-testid": "bc-empty",
                    children:
                      "Enter a value to encode; Download stays off until you do.",
                  }),
                _.includes(s) &&
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground mt-1",
                    "data-testid": "bc-gs1-note",
                    children:
                      "To sell in shops or marketplaces, the number must come from GS1 (your company prefix). Numbers made here are fine for internal use, samples and testing.",
                  }),
                s === "CODE39" &&
                  o !== o.toUpperCase() &&
                  !f &&
                  e.jsxs("p", {
                    className: "text-xs text-muted-foreground mt-1",
                    "data-testid": "bc-uppercase-note",
                    children: [
                      "Code 39 has no lower-case letters, so this encodes ",
                      o.trim().toUpperCase(),
                      ".",
                    ],
                  }),
              ],
            }),
          l === "one" &&
            e.jsxs("div", {
              children: [
                e.jsx(b, {
                  htmlFor: "bc-caption",
                  children: "What is this barcode for? (optional)",
                }),
                e.jsx(M, {
                  id: "bc-caption",
                  type: "text",
                  value: j,
                  onChange: (t) => Y(t.target.value),
                  placeholder: "e.g. Blue T-Shirt, Size M",
                }),
              ],
            }),
          l === "list" &&
            e.jsxs("div", {
              children: [
                e.jsx(b, {
                  htmlFor: "bc-list",
                  children: "Barcode values, one per line",
                }),
                e.jsx(me, {
                  id: "bc-list",
                  value: E,
                  onChange: (t) => ee(t.target.value),
                  spellCheck: !1,
                  autoComplete: "off",
                  placeholder: `590123412345
401234567890
...`,
                  className: "min-h-[160px] font-mono",
                  "data-testid": "bc-list",
                }),
                _.includes(s) &&
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground mt-1",
                    "data-testid": "bc-gs1-note",
                    children:
                      "To sell in shops or marketplaces, the numbers must come from GS1 (your company prefix). Numbers made here are fine for internal use, samples and testing.",
                  }),
                e.jsxs("p", {
                  className: "text-xs text-muted-foreground mt-1",
                  "data-testid": "bc-list-summary",
                  "aria-live": "polite",
                  children: [
                    i.length,
                    " barcode",
                    i.length === 1 ? "" : "s",
                    " ready",
                    r.problems.length > 0
                      ? `, ${r.problems.length} line${r.problems.length === 1 ? "" : "s"} with a problem`
                      : "",
                    r.duplicates > 0
                      ? `, ${r.duplicates} repeated value${r.duplicates === 1 ? "" : "s"} made once`
                      : "",
                    ".",
                    re ? ` Only the first ${U} are made.` : "",
                    " The check digit is added where the format needs one.",
                  ],
                }),
                r.problems.length > 0 &&
                  e.jsxs("ul", {
                    role: "alert",
                    className: "mt-2 space-y-1 text-sm text-destructive",
                    "data-testid": "bc-list-problems",
                    children: [
                      r.problems
                        .slice(0, 20)
                        .map((t) =>
                          e.jsxs(
                            "li",
                            {
                              children: [
                                "Line ",
                                t.line,
                                " (",
                                t.input.length > 30
                                  ? `${t.input.slice(0, 30)}…`
                                  : t.input,
                                "): ",
                                t.message,
                              ],
                            },
                            t.line,
                          ),
                        ),
                      r.problems.length > 20 &&
                        e.jsxs("li", {
                          children: ["…and ", r.problems.length - 20, " more."],
                        }),
                    ],
                  }),
              ],
            }),
          e.jsxs("div", {
            className: "flex flex-wrap items-end gap-4",
            children: [
              e.jsxs("label", {
                className: "flex items-center gap-2 text-sm",
                children: [
                  e.jsx("input", {
                    type: "checkbox",
                    checked: u,
                    onChange: (t) => K(t.target.checked),
                    "data-testid": "bc-show-text",
                  }),
                  "Show the number under the bars",
                ],
              }),
              e.jsxs("div", {
                className: "w-40",
                children: [
                  e.jsx(b, { htmlFor: "bc-height", children: "Bar height" }),
                  e.jsxs(S, {
                    value: p,
                    onValueChange: Q,
                    children: [
                      e.jsx(T, { id: "bc-height", children: e.jsx(P, {}) }),
                      e.jsxs(F, {
                        children: [
                          e.jsx(d, { value: "50", children: "Short" }),
                          e.jsx(d, { value: "80", children: "Standard" }),
                          e.jsx(d, { value: "120", children: "Tall" }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          l === "one" &&
            e.jsxs("div", {
              className:
                "flex justify-center p-4 border rounded-lg bg-white min-h-[140px] items-center",
              children: [
                f &&
                  e.jsx("p", {
                    role: "alert",
                    "data-testid": "barcode-error",
                    className: "text-sm text-destructive text-center px-4",
                    children: f,
                  }),
                e.jsx("canvas", {
                  ref: O,
                  className: f || !h ? "hidden" : "max-w-full h-auto",
                  "data-testid": "barcode-canvas",
                }),
              ],
            }),
          l === "list" &&
            e.jsxs("div", {
              className: "flex items-end gap-2 flex-wrap",
              children: [
                e.jsxs("div", {
                  className: "w-32",
                  children: [
                    e.jsx(b, {
                      htmlFor: "bc-zip-format",
                      children: "Files in the ZIP",
                    }),
                    e.jsxs(S, {
                      value: y,
                      onValueChange: (t) => te(t),
                      children: [
                        e.jsx(T, {
                          id: "bc-zip-format",
                          children: e.jsx(P, {}),
                        }),
                        e.jsxs(F, {
                          children: [
                            e.jsx(d, {
                              value: "png",
                              children: "PNG (300 dpi)",
                            }),
                            e.jsx(d, {
                              value: "svg",
                              children: "SVG (vector)",
                            }),
                          ],
                        }),
                      ],
                    }),
                  ],
                }),
                e.jsx(V, {
                  onClick: ie,
                  label: I ? "Building ZIP…" : "Download ZIP",
                  disabled: i.length === 0 || I,
                }),
              ],
            }),
          l === "one" &&
            e.jsxs("div", {
              className: "flex items-end gap-2 flex-wrap",
              children: [
                e.jsxs("div", {
                  className: "w-32",
                  children: [
                    e.jsx(b, { htmlFor: "bc-scale", children: "PNG size" }),
                    e.jsxs(S, {
                      value: g,
                      onValueChange: q,
                      children: [
                        e.jsx(T, { id: "bc-scale", children: e.jsx(P, {}) }),
                        e.jsxs(F, {
                          children: [
                            e.jsx(d, {
                              value: "1",
                              children: "1× (small, screen)",
                            }),
                            e.jsx(d, { value: "2", children: "2×" }),
                            e.jsx(d, {
                              value: "4",
                              children: "4× (print, 300 dpi)",
                            }),
                          ],
                        }),
                      ],
                    }),
                  ],
                }),
                g === "4" &&
                  N > 0 &&
                  e.jsxs("p", {
                    className:
                      "w-full text-xs text-muted-foreground order-last",
                    "data-testid": "bc-physical",
                    children: [
                      "Prints ",
                      ((N * 4) / w).toFixed(2),
                      " in (",
                      (((N * 4) / w) * 2.54).toFixed(1),
                      " cm) wide at 100% (",
                      N * 4,
                      " px at ",
                      w,
                      " dpi).",
                    ],
                  }),
                e.jsx(V, { onClick: ne, label: "Download PNG", disabled: !h }),
                e.jsx(V, { onClick: de, label: "Download SVG", disabled: !h }),
              ],
            }),
        ],
      }),
      e.jsx(pe, { whatIsIt: L.what, howToUse: L.how, tip: L.tip }),
    ],
  });
}
export { ot as default };
//# sourceMappingURL=BarcodeGenerator-Y42ebgv8.js.map
