import { J as u } from "./JsBarcode-QeG8kXh7.js";
import { Q as g } from "./browser-CMr8NRjw.js";
import { b as w } from "./qrHelpers-av3Dz-dA.js";
const B = [
    {
      value: "CODE128",
      label: "Code 128 (letters, numbers and symbols, no accents)",
    },
    { value: "EAN13", label: "EAN-13 (13-digit retail)" },
    { value: "EAN8", label: "EAN-8 (8-digit retail)" },
    { value: "UPC", label: "UPC-A (12-digit retail)" },
    { value: "CODE39", label: "Code 39 (alphanumeric, industrial)" },
    { value: "ITF14", label: "ITF-14 (14-digit shipping/case)" },
  ],
  P = 300,
  b = 80,
  m = (t) =>
    t && Number.isFinite(t) ? Math.max(20, Math.min(200, Math.round(t))) : b,
  y = (() => {
    const t = new Uint32Array(256);
    for (let r = 0; r < 256; r++) {
      let e = r;
      for (let n = 0; n < 8; n++) e = e & 1 ? 3988292384 ^ (e >>> 1) : e >>> 1;
      t[r] = e >>> 0;
    }
    return t;
  })();
function E(t) {
  let r = 4294967295;
  for (let e = 0; e < t.length; e++) r = y[(r ^ t[e]) & 255] ^ (r >>> 8);
  return (r ^ 4294967295) >>> 0;
}
function A(t, r) {
  const e = [137, 80, 78, 71, 13, 10, 26, 10];
  if (t.length < 33 || e.some((o, h) => t[h] !== o)) return t;
  const n = Math.round(r / 0.0254),
    a = new Uint8Array(21),
    i = new DataView(a.buffer);
  (i.setUint32(0, 9),
    a.set([112, 72, 89, 115], 4),
    i.setUint32(8, n),
    i.setUint32(12, n),
    (a[16] = 1),
    i.setUint32(17, E(a.subarray(4, 17))));
  const s = [t.subarray(0, 33), a];
  let c = 33;
  for (; c + 12 <= t.length;) {
    const o = new DataView(t.buffer, t.byteOffset + c, 4).getUint32(0),
      h = String.fromCharCode(t[c + 4], t[c + 5], t[c + 6], t[c + 7]),
      f = c + 12 + o;
    (h !== "pHYs" && s.push(t.subarray(c, f)), (c = f));
  }
  const l = new Uint8Array(s.reduce((o, h) => o + h.length, 0));
  let d = 0;
  for (const o of s) (l.set(o, d), (d += o.length));
  return l;
}
function C(t) {
  return new Promise((r, e) => {
    t.toBlob((n) => {
      if (!n) {
        e(new Error("Couldn't render the barcode image"));
        return;
      }
      n.arrayBuffer().then((a) => r(new Uint8Array(a)));
    }, "image/png");
  });
}
async function T(t, r, e = {}) {
  if (!t.trim()) throw new Error("Enter a value to encode first");
  const n = Math.max(1, Math.min(8, e.scale ?? 1)),
    a = w(t, r);
  if (a) throw new Error(a);
  const i = document.createElement("canvas");
  let s = !0;
  if (
    (u(i, t.trim(), {
      format: r,
      displayValue: e.displayValue ?? !0,
      width: 2 * n,
      height: m(e.barHeight) * n,
      margin: 10 * n,
      fontSize: 20 * n,
      valid: (h) => {
        s = h;
      },
    }),
    !s)
  )
    throw new Error(
      `"${t}" can't be encoded as ${r}. Check the length and characters this format allows.`,
    );
  const c = async (h) => {
    const f = await C(h);
    return e.dpi ? A(f, e.dpi) : f;
  };
  if (!e.caption?.trim()) return c(i);
  const l = document.createElement("canvas"),
    d = 26 * n;
  ((l.width = i.width), (l.height = i.height + d));
  const o = l.getContext("2d");
  return (
    (o.fillStyle = "#ffffff"),
    o.fillRect(0, 0, l.width, l.height),
    (o.fillStyle = "#111111"),
    (o.font = `${14 * n}px sans-serif`),
    (o.textAlign = "center"),
    o.fillText(e.caption.trim(), l.width / 2, 18 * n),
    o.drawImage(i, 0, d),
    c(l)
  );
}
function x(t, r, e = {}) {
  if (!t.trim()) throw new Error("Enter a value to encode first");
  const n = w(t, r);
  if (n) throw new Error(n);
  const a = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  let i = !0;
  if (
    (u(a, t.trim(), {
      format: r,
      displayValue: e.displayValue ?? !0,
      width: 2,
      height: m(e.barHeight),
      margin: 10,
      valid: (s) => {
        i = s;
      },
    }),
    !i)
  )
    throw new Error(
      `"${t}" can't be encoded as ${r}. Check the length and characters this format allows.`,
    );
  return (
    a.setAttribute("xmlns", "http://www.w3.org/2000/svg"),
    new XMLSerializer().serializeToString(a)
  );
}
async function D(t, r = {}) {
  if (!t.trim()) throw new Error("Enter a URL or text to encode first");
  const n = (
      await g.toDataURL(t.trim(), { margin: 1, width: r.size ?? 240 })
    ).split(",")[1],
    a = atob(n),
    i = new Uint8Array(a.length);
  for (let s = 0; s < a.length; s++) i[s] = a.charCodeAt(s);
  return i;
}
export { B, P, x as a, D as b, T as g };
//# sourceMappingURL=codeGeneration-D1g4LVfX.js.map
