function w(e) {
  return e.replace(/([\\;,:"])/g, "\\$1");
}
function O(e) {
  const t = [
    `WIFI:T:${e.security === "nopass" ? "nopass" : e.security}`,
    `S:${w(e.ssid)}`,
  ];
  return (
    e.security !== "nopass" && t.push(`P:${w(e.password)}`),
    e.hidden && t.push("H:true"),
    t.join(";") + ";;"
  );
}
function p(e) {
  return e
    .replace(/\\/g, "\\\\")
    .replace(/\r?\n/g, "\\n")
    .replace(/;/g, ";")
    .replace(/,/g, "\\,");
}
function P(e) {
  const t = [
    "BEGIN:VCARD",
    "VERSION:3.0",
    `N:${p(e.last)};${p(e.first)};;;`,
    `FN:${p([e.first, e.last].filter(Boolean).join(" "))}`,
  ];
  return (
    e.company.trim() && t.push(`ORG:${p(e.company.trim())}`),
    e.phone.trim() && t.push(`TEL;TYPE=CELL:${e.phone.trim()}`),
    e.email.trim() && t.push(`EMAIL:${e.email.trim()}`),
    e.website.trim() && t.push(`URL:${e.website.trim()}`),
    t.push("END:VCARD"),
    t.join(`
`)
  );
}
function T(e) {
  const t = [];
  return (
    e.subject && t.push(`subject=${encodeURIComponent(e.subject)}`),
    e.body && t.push(`body=${encodeURIComponent(e.body)}`),
    `mailto:${e.to.trim()}${t.length ? "?" + t.join("&") : ""}`
  );
}
const j = (e, t) => `SMSTO:${e.trim()}:${t}`,
  v = (e) => `tel:${e.trim()}`;
function N(e) {
  let t = e.trim().replace(/^#/, "");
  return (
    t.length === 3 &&
      (t = t
        .split("")
        .map((s) => s + s)
        .join("")),
    /^[0-9a-f]{6}$/i.test(t)
      ? [
          parseInt(t.slice(0, 2), 16),
          parseInt(t.slice(2, 4), 16),
          parseInt(t.slice(4, 6), 16),
        ]
      : null
  );
}
function f(e) {
  const t = N(e) ?? [0, 0, 0],
    [s, n, i] = t.map((r) => {
      const o = r / 255;
      return o <= 0.03928 ? o / 12.92 : Math.pow((o + 0.055) / 1.055, 2.4);
    });
  return 0.2126 * s + 0.7152 * n + 0.0722 * i;
}
function R(e, t) {
  const s = f(e),
    n = f(t);
  return (Math.max(s, n) + 0.05) / (Math.min(s, n) + 0.05);
}
function M(e, t) {
  if (f(e) > f(t))
    return "The code is lighter than its background (inverted). Many phone scanners cannot read inverted codes. Use a dark code on a light background.";
  const s = R(e, t);
  return s < 4
    ? `Low contrast (${s.toFixed(1)}:1). Printed codes with less than about 4:1 often fail to scan. Make the code darker or the background lighter.`
    : null;
}
function S(e, t = 60) {
  return (
    e
      .trim()
      .replace(/^https?:\/\//i, "")
      .normalize("NFKD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-zA-Z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, t)
      .replace(/-+$/g, "") || "code"
  );
}
function F(e, t, s, n = "png") {
  const i = Math.max(3, String(t).length);
  return `${String(e + 1).padStart(i, "0")}-${S(s)}.${n}`;
}
function D(e, t) {
  const s = new Set(),
    n = [];
  let i = 0,
    r = 0;
  for (const o of e.split(/\r?\n/)) {
    const a = o.trim();
    if (!a) {
      r++;
      continue;
    }
    let u = null,
      l = a;
    if (t) {
      const c = a.indexOf(",");
      c >= 0 &&
        a.slice(c + 1).trim() &&
        ((u = a.slice(0, c).trim() || null), (l = a.slice(c + 1).trim()));
    }
    if (s.has(l)) {
      i++;
      continue;
    }
    (s.add(l), n.push({ name: u, value: l }));
  }
  return { rows: n, duplicates: i, blank: r };
}
const k = 300;
function x(e) {
  return e.filter((t) => t.value.length > k).length;
}
function h(e) {
  let t = 0;
  for (let s = 0; s < e.length; s++) {
    const n = Number(e[e.length - 1 - s]);
    t += s % 2 === 0 ? n * 3 : n;
  }
  return (10 - (t % 10)) % 10;
}
const m = {
  EAN13: { name: "EAN-13", body: 12 },
  EAN8: { name: "EAN-8", body: 7 },
  UPC: { name: "UPC-A", body: 11 },
  ITF14: { name: "ITF-14", body: 13 },
};
function I(e, t) {
  const s = e.trim();
  if (!s) return null;
  const n = m[t];
  if (n) {
    if (!/^\d+$/.test(s))
      return `${n.name} uses digits only (0-9). Remove letters, spaces and symbols.`;
    if (s.length !== n.body && s.length !== n.body + 1)
      return `${n.name} needs ${n.body} digits (the check digit is added for you) or ${n.body + 1} digits including it. You entered ${s.length}.`;
    if (s.length === n.body + 1) {
      const i = h(s.slice(0, n.body));
      if (Number(s[n.body]) !== i)
        return `Check digit should be ${i}, not ${s[n.body]}. Enter ${n.body} digits and it is added for you.`;
    }
    return null;
  }
  return t === "CODE39"
    ? /^[A-Z0-9 \-.$/+%]+$/i.test(s)
      ? null
      : "Code 39 accepts letters A-Z, digits, space and - . $ / + % only."
    : t === "CODE128" && /[^\x20-\x7e]/.test(s)
      ? "Code 128 accepts standard keyboard characters only (letters, digits, symbols; no accents or emoji)."
      : null;
}
function C(e, t, s) {
  let n = e.trim();
  const i = m[t];
  i && /^\d+$/.test(n) && n.length === i.body && (n += String(h(n)));
  const r = n
      .replace(/[^A-Za-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 40),
    o = t === "UPC" ? "upca" : t.toLowerCase();
  return r ? `${o}-${r}.${s}` : `${o}.${s}`;
}
function V(e, t, s) {
  const n = [],
    i = [],
    r = new Set(),
    o = new Set();
  let a = 0;
  return (
    e.split(/\r?\n/).forEach((u, l) => {
      const c = u.trim();
      if (!c) return;
      const g = l + 1,
        y = I(c, t);
      if (y) {
        i.push({ line: g, input: c, message: y });
        return;
      }
      const $ = m[t],
        b =
          t === "CODE39"
            ? c.toUpperCase()
            : $ && c.length === $.body
              ? c + h(c)
              : c;
      if (r.has(b)) {
        a++;
        return;
      }
      r.add(b);
      let d = C(c, t, s);
      for (let E = 2; o.has(d.toLowerCase()); E++)
        d = C(c, t, s).replace(/(\.[a-z]+)$/, `-${E}$1`);
      (o.add(d.toLowerCase()), n.push({ line: g, value: c, file: d }));
    }),
    { rows: n, problems: i, duplicates: a }
  );
}
const G = ["EAN13", "EAN8", "UPC", "ITF14"],
  A = new Set([
    "bit.ly",
    "t.co",
    "tinyurl.com",
    "goo.gl",
    "ow.ly",
    "is.gd",
    "buff.ly",
    "rebrand.ly",
    "cutt.ly",
    "shorturl.at",
    "tiny.cc",
    "rb.gy",
  ]);
function L(e, t) {
  const s = [];
  let n = "";
  for (let i = 0; i < e.length; i++)
    e[i] === "\\" && i + 1 < e.length
      ? ((n += e[i] + e[i + 1]), i++)
      : e[i] === t
        ? (s.push(n), (n = ""))
        : (n += e[i]);
  return (s.push(n), s);
}
const U = (e) => e.replace(/\\([\\;,:"])/g, "$1");
function B(e) {
  const t = e.trim();
  if (/^WIFI:/i.test(t)) {
    const n = {};
    for (const i of L(t.slice(5), ";")) {
      const r = i.indexOf(":");
      r > 0 && (n[i.slice(0, r).toUpperCase()] = U(i.slice(r + 1)));
    }
    return {
      kind: "wifi",
      wifi: {
        ssid: n.S ?? "",
        password: n.P ?? "",
        security: n.T || "nopass",
        hidden: /^true$/i.test(n.H ?? ""),
      },
    };
  }
  if (/^BEGIN:VCARD/i.test(t)) {
    const n = { name: "", phones: [], emails: [], org: "", url: "" };
    for (const i of t.split(/\r?\n/)) {
      const r = i.indexOf(":");
      if (r < 0) continue;
      const o = i.slice(0, r).split(";")[0].toUpperCase(),
        a = i
          .slice(r + 1)
          .replace(/\\n/gi, " ")
          .replace(/\\([;,\\])/g, "$1")
          .trim();
      o === "FN"
        ? (n.name = a)
        : o === "N" && !n.name
          ? (n.name = a.split(";").filter(Boolean).reverse().join(" "))
          : o === "TEL"
            ? n.phones.push(a)
            : o === "EMAIL"
              ? n.emails.push(a)
              : o === "ORG"
                ? (n.org = a.replace(/;/g, " ").trim())
                : o === "URL" && (n.url = a);
    }
    return { kind: "vcard", contact: n };
  }
  if (/^mailto:/i.test(t))
    try {
      const n = new URL(t);
      return {
        kind: "email",
        to: decodeURIComponent(n.pathname),
        subject: n.searchParams.get("subject") ?? "",
        body: n.searchParams.get("body") ?? "",
      };
    } catch {}
  const s = /^(?:SMSTO|SMS):([^:?]*)[:?]?(.*)$/i.exec(t);
  if (s) return { kind: "sms", to: s[1], body: s[2].replace(/^body=/i, "") };
  if (/^tel:/i.test(t)) return { kind: "phone", to: t.slice(4) };
  try {
    const n = new URL(t);
    if (n.protocol === "http:" || n.protocol === "https:") {
      const i = n.hostname.replace(/^www\./, "");
      let r;
      return (
        n.protocol === "http:"
          ? (r =
              "This link is not encrypted (http). Only open it if you trust the source.")
          : A.has(i) &&
            (r =
              "This is a shortened link, so the real destination is hidden. Only open it if you trust the source."),
        { kind: "url", url: n, warning: r }
      );
    }
  } catch {}
  return { kind: "text" };
}
function W(e) {
  const t = ["BEGIN:VCARD", "VERSION:3.0", `FN:${e.name}`];
  return (
    e.org && t.push(`ORG:${e.org}`),
    e.phones.forEach((s) => t.push(`TEL:${s}`)),
    e.emails.forEach((s) => t.push(`EMAIL:${s}`)),
    e.url && t.push(`URL:${e.url}`),
    t.push("END:VCARD"),
    t.join(`\r
`)
  );
}
export {
  G,
  F as a,
  I as b,
  M as c,
  V as d,
  C as e,
  f,
  N as g,
  B as h,
  W as i,
  h as j,
  x as l,
  T as m,
  D as p,
  j as s,
  v as t,
  P as v,
  O as w,
};
//# sourceMappingURL=qrHelpers-av3Dz-dA.js.map
