// barcode-generator battery (no trial use): fresh context per case (bc-cases.json; argv[2]=IDs). Pick Format, type the value, optional caption/number off/bar height,
// record the error/notes, the Download button state, the "Prints … wide" line; capture the 1× preview PNG from memory (Blob Proxy on image/png) and decode it with zxing-cpp afterwards. Download is never pressed.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/25-barcode-generator/live/'; const URL = 'https://www.freedailypro.com/tool/barcode-generator'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const ids = process.argv[2] ? process.argv[2].split(',') : null; const tag = ids ? '-' + ids.join('_') : '';
const cases = JSON.parse(fs.readFileSync(__dirname + '/bc-cases.json')).filter(c => !ids || ids.includes(c.id));
const HOOK = `(() => { window.__png = []; const OB = window.Blob; window.Blob = new Proxy(OB, { construct(t, a) { const b = Reflect.construct(t, a); try { if (/png|svg/.test((a[1] || {}).type || '')) window.__png.push(b); } catch (e) {} return b; } }); })();`;
const val = v => v === 'LONG80' ? 'ABCDEFGHIJ'.repeat(8) : v === 'LONG300' ? 'ABCDEFGHIJ'.repeat(30) : v;
(async () => { const b = await chromium.launch(); const R = { t: now(), cases: [] }; const save = () => fs.writeFileSync(OUT + 'battery' + tag + '.json', JSON.stringify(R, null, 1));
 for (const c of cases) { const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); await ctx.addInitScript(HOOK); const p = await ctx.newPage(); p.setDefaultTimeout(10000);
  const r = { id: c.id, fmt: c.fmt, v: val(c.v), t: now(), errs: [], reqs: [] };
  p.on('console', m => { if (m.type() === 'error' && !/no_div|adsbygoogle|Permissions policy|status of 4/.test(m.text())) r.errs.push(m.text().slice(0, 200)); });
  try { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
   r.start = JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
   p.on('request', q => { const u = q.url(); if (/freedailypro\.com\/(api|trpc)/.test(u) && !/insight|funnel|auth\.me|version/.test(u)) r.reqs.push(q.method() + ' ' + u.replace(/\?.*/, '').slice(0, 100)); });
   if (c.fmt !== 'EAN-13') { await p.locator('#bc-format').click(); await p.getByRole('option', { name: new RegExp('^' + c.fmt.replace(/[-]/g, '\\-')) }).click(); }
   await p.locator('#bc-value').fill(r.v); if (c.caption) await p.locator('#bc-caption').fill(c.caption); if (c.nonum) await p.getByLabel('Show the number under the bars').uncheck();
   if (c.height) { await p.locator('#bc-height').click(); await p.getByRole('option', { name: c.height }).click(); }
   await p.evaluate(() => window.__png.length = 0); await p.locator('#bc-value').press('End'); await p.waitForTimeout(1800);
   r.alerts = await p.evaluate(() => [...document.querySelectorAll('main [role=alert], main [data-testid=bc-uppercase-note]')].map(e => e.innerText.trim()).filter(Boolean));
   r.ariaInvalid = await p.locator('#bc-value').getAttribute('aria-invalid'); r.prints = await p.evaluate(() => document.querySelector('[data-testid=bc-physical]')?.innerText || null);
   r.dlDisabled = await p.getByRole('button', { name: 'Download PNG' }).isDisabled().catch(() => 'n/a');
   r.canvas = await p.evaluate(() => { const cv = document.querySelector('[data-testid=barcode-canvas]'); return cv ? { w: cv.width, h: cv.height, hidden: cv.classList.contains('hidden'), cssW: cv.getBoundingClientRect().width } : null; });
   r.steps = await p.evaluate(() => (document.body.innerText.match(/\d of 4 steps done[^\n]*/) || [''])[0]);
   const bytes = await p.evaluate(async () => { const pngs = window.__png.filter(x => /png/.test(x.type)); const x = pngs[pngs.length - 1]; return x ? [...new Uint8Array(await x.arrayBuffer())] : []; });
   if (bytes.length && !r.canvas?.hidden) { r.png = `prev-${c.id}.png`; fs.writeFileSync(OUT + r.png, Buffer.from(bytes)); }
   await p.locator('[data-testid=barcode-canvas]').locator('..').screenshot({ path: OUT + `box-${c.id}.png` }).catch(() => {});
  } catch (e) { r.fail = String(e).slice(0, 200); }
  R.cases.push(r); save(); console.log(c.id, c.fmt, JSON.stringify(r.v).slice(0, 40), '|', (r.alerts || []).join(' / ').slice(0, 160), '| dlDis', r.dlDisabled, '|', r.canvas && r.canvas.w + 'x' + r.canvas.h, r.prints || '', r.png || '', r.fail || '', r.reqs.length ? r.reqs : ''); await ctx.close(); }
 R.t2 = now(); save(); await b.close(); })();
