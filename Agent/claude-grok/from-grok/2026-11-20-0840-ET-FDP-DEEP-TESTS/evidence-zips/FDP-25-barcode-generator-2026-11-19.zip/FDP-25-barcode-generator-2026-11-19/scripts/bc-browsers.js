// barcode-generator in Firefox + WebKit (no trial use): EAN-13, UPC-A, Code 128 previews captured from memory and decoded later; plus iPhone 13 (WebKit) and Pixel 7 (Chromium) with Code 128 chosen:
// page scroll width and a screenshot of the Format control, and the keyboard pick of a format (Enter, ArrowDown ×2, Enter) in Chromium.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/25-barcode-generator/live/'; const URL = 'https://www.freedailypro.com/tool/barcode-generator'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const HOOK = `(() => { window.__png = []; const OB = window.Blob; window.Blob = new Proxy(OB, { construct(t, a) { const b = Reflect.construct(t, a); try { if (/png/.test((a[1] || {}).type || '')) window.__png.push(b); } catch (e) {} return b; } }); })();`;
const fmt = async (p, f) => { await p.locator('#bc-format').click(); await p.getByRole('option', { name: new RegExp('^' + f) }).click(); };
(async () => { const R = { t: now(), runs: [] };
 for (const name of ['firefox', 'webkit']) { const b = await pw[name].launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); await c.addInitScript(HOOK); const p = await c.newPage(); p.setDefaultTimeout(12000); const errs = []; p.on('pageerror', e => errs.push(String(e).slice(0, 150)));
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
  for (const [f, v] of [['EAN-13', '400638133393'], ['UPC-A', '03600029145'], ['Code 128', 'SKU-00042/Blue M']]) { const r = { name, f, v };
   try { await fmt(p, f); await p.locator('#bc-value').fill(v); await p.waitForTimeout(1500); const bytes = await p.evaluate(async () => { const x = window.__png[window.__png.length - 1]; return x ? [...new Uint8Array(await x.arrayBuffer())] : []; }); r.alert = await p.locator('[data-testid=barcode-error]').innerText().catch(() => null);
    if (bytes.length) { r.png = `br-${name}-${f.replace(/\W/g, '')}.png`; fs.writeFileSync(OUT + r.png, Buffer.from(bytes)); } } catch (e) { r.fail = String(e).slice(0, 150); } R.runs.push(r); }
  R[name + 'Errs'] = errs; await p.screenshot({ path: OUT + `br-${name}.png` }); await b.close(); }
 for (const [k, bt, d] of [['iphone13-webkit', 'webkit', pw.devices['iPhone 13']], ['pixel7', 'chromium', pw.devices['Pixel 7']]]) { const b = await pw[bt].launch(); const c = await b.newContext(d); const p = await c.newPage(); p.setDefaultTimeout(12000);
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); const before = await p.evaluate(() => document.documentElement.scrollWidth); await fmt(p, 'Code 128'); await p.waitForTimeout(800);
  R[k] = { before, after: await p.evaluate(() => document.documentElement.scrollWidth), cw: await p.evaluate(() => document.documentElement.clientWidth), fmtBox: await p.locator('#bc-format').boundingBox() };
  await p.locator('#bc-format').scrollIntoViewIfNeeded(); await p.evaluate(() => window.scrollBy(0, -120)); await p.screenshot({ path: OUT + `overflow-${k}.png` }); await b.close(); }
 const b = await pw.chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 await p.locator('#bc-format').focus(); await p.keyboard.press('Enter'); await p.waitForTimeout(600); R.kbdOpen = await p.getByRole('listbox').count(); R.kbdActive = await p.evaluate(() => document.activeElement.innerText); await p.keyboard.press('ArrowDown'); await p.waitForTimeout(200); await p.keyboard.press('ArrowDown'); await p.waitForTimeout(200); R.kbdActive2 = await p.evaluate(() => document.activeElement.innerText); await p.keyboard.press('Enter'); await p.waitForTimeout(600);
 R.kbdFormat = await p.locator('#bc-format').innerText(); R.kbdFocusBack = await p.evaluate(() => document.activeElement.id); await b.close();
 R.t2 = now(); fs.writeFileSync(OUT + 'browsers.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); })();
