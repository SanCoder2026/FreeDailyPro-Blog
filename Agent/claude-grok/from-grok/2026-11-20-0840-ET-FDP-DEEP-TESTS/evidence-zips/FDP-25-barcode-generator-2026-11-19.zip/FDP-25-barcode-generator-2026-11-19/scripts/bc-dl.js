// barcode-generator Download gate: fresh contexts until one is at the cap and one has uses left. Never types an email or card.
// Cap: Download PNG → dialog → Buy Day Pass → email prompt (stop); Quick Buy; the post-download buttons. With uses (single context, in order): sample value Download PNG; new value 4× PNG; SVG of same value;
// 1× PNG of same value; another value 4× PNG; list ZIP (PNG) and ZIP (SVG); 300-char Code 128 4× PNG. Each step: trial count before/after, downloaded file saved (not opened/executed) for decoding.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const crypto = require('crypto');
const OUT = '/workspace/deep/25-barcode-generator/live/dl/'; fs.mkdirSync(OUT, { recursive: true }); const URL = 'https://www.freedailypro.com/tool/barcode-generator'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').slice(0, 140); const sha = b => crypto.createHash('sha256').update(b).digest('hex').slice(0, 16);
const fmt = async (p, f) => { await p.locator('#bc-format').click(); await p.getByRole('option', { name: new RegExp('^' + f) }).click(); await p.waitForTimeout(300); };
const sel = async (p, id, name) => { await p.locator(id).click(); await p.getByRole('option', { name }).click(); await p.waitForTimeout(300); };
(async () => { const b = await chromium.launch(); const R = { t: now(), tries: [] }; let gotCap = process.argv[2] === 'spend', gotSpend = false;
 for (let i = 0; i < 25 && !(gotCap && gotSpend); i++) { const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await c.newPage(); p.setDefaultTimeout(12000);
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
  const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday; const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
  const u0 = await used(); const r = { i, t: now(), start: u0 }; const cap = u0 >= 10; if ((cap && gotCap) || (!cap && gotSpend)) { R.tries.push(r); await c.close(); continue; }
  const press = async (k, label) => { const b0 = await used(); const dl = p.waitForEvent('download', { timeout: 15000 }).catch(() => null); await p.getByRole('button', { name: label, exact: true }).first().click(); const d = await dl; await p.waitForTimeout(1800);
   const o = { k, t: now(), before: b0, after: await used(), dialog: await dialog(), toasts: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText.trim())) };
   if (d) { const f = OUT + `${k}-${d.suggestedFilename()}`; await d.saveAs(f); const buf = fs.readFileSync(f); o.file = d.suggestedFilename(); o.bytes = buf.length; o.sha = sha(buf); }
   o.btns = await p.evaluate(() => [...document.querySelectorAll('main button')].map(b => b.innerText.trim()).filter(x => /Download|Drive|cloud|Save|Share|Print|Copy/i.test(x) && x.length < 50)); console.log(JSON.stringify(o)); return o; };
  if (cap) { gotCap = true; await p.locator('#bc-value').fill('400638133393'); await p.waitForTimeout(800); r.capPress = await press('cap', 'Download PNG'); await p.screenshot({ path: OUT + '../cap-dialog.png' });
   const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); r.dayPass = { dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + '../daypass-email.png' }); }
   for (let k = 0; k < 3; k++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); }
   r.dayPassLink = await (async () => { const l = p.getByRole('button', { name: 'Get a Day Pass to download' }).first(); await l.click(); await p.waitForTimeout(2000); const o = { dialog: await dialog(), url: p.url().slice(0, 100) }; for (let k = 0; k < 3; k++) await p.keyboard.press('Escape'); return o; })();
   const qb = p.getByRole('button', { name: 'Quick Buy' }); r.quickBuy = { count: await qb.count() }; if (r.quickBuy.count) { await qb.first().click(); await p.waitForTimeout(2500); r.quickBuy.dialog = await dialog(); r.quickBuy.emailField = await p.locator('input[type=email]').count(); await p.screenshot({ path: OUT + '../quickbuy.png' }); for (let k = 0; k < 3; k++) await p.keyboard.press('Escape'); }
   r.end = await used(); }
  else { gotSpend = true; const S = r.steps = [];
   S.push(await press('s1-sample', 'Download PNG'));
   await p.locator('#bc-value').fill('400638133393'); await p.locator('#bc-caption').fill('Blue T-Shirt, Size M'); await p.waitForTimeout(1000); S.push(await press('s2-ean13-4x', 'Download PNG')); await p.screenshot({ path: OUT + '../spend-after.png' });
   S.push(await press('s3-ean13-svg', 'Download SVG'));
   await sel(p, '#bc-scale', /^1×/); S.push(await press('s4-ean13-1x', 'Download PNG'));
   await sel(p, '#bc-scale', /^4×/); await fmt(p, 'Code 128'); await p.locator('#bc-value').fill('SKU-00042/Blue M'); await p.locator('#bc-caption').fill(''); await p.waitForTimeout(1000); S.push(await press('s5-c128-4x', 'Download PNG'));
   await fmt(p, 'ITF-14'); await p.locator('#bc-value').fill('1540014128876'); await p.waitForTimeout(1000); S.push(await press('s6-itf-svg', 'Download SVG'));
   await fmt(p, 'EAN-13'); await p.getByRole('button', { name: 'A list (ZIP)' }).click(); await p.locator('#bc-list').fill('590123412345\n4006381333931\n4006381333932\n\n590123412345\n5901234123457\nabc\n12345\n=1+1\n000000000000'); await p.waitForTimeout(800);
   S.push(await press('s7-zip-png', 'Download ZIP')); await sel(p, '#bc-zip-format', /^SVG/); S.push(await press('s8-zip-svg', 'Download ZIP'));
   await p.getByRole('button', { name: 'One barcode' }).click(); await fmt(p, 'Code 128'); await p.locator('#bc-value').fill('ABCDEFGHIJ'.repeat(40)); await p.waitForTimeout(2500); r.long400 = { alert: await p.locator('[data-testid=barcode-error]').innerText().catch(() => null), prints: await p.locator('[data-testid=bc-physical]').innerText().catch(() => null) };
   S.push(await press('s9-c128-400ch-4x', 'Download PNG')); r.end = await used(); }
  R.tries.push(r); fs.writeFileSync(OUT + '../' + (process.argv[2] === 'spend' ? 'dl-spend.json' : 'dl-gate.json'), JSON.stringify(R, null, 1)); await c.close(); }
 R.t2 = now(); fs.writeFileSync(OUT + '../' + (process.argv[2] === 'spend' ? 'dl-spend.json' : 'dl-gate.json'), JSON.stringify(R, null, 1)); console.log(JSON.stringify(R.tries.map(t => ({ i: t.i, start: t.start, end: t.end, capPress: t.capPress && t.capPress.dialog, dayPass: t.dayPass, dayPassLink: t.dayPassLink, quickBuy: t.quickBuy, long400: t.long400 })), null, 1)); await b.close(); })();
