// barcode-generator: one fresh context with uses left. Type a distinctive Code 128 value + caption, press Download PNG (1 trial use), log every request to any host
// and whether the value/caption appears in any URL or POST body; then reload the page and press Download for a new value to see if the free re-downloads survive a reload.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/25-barcode-generator/live/'; const URL = 'https://www.freedailypro.com/tool/barcode-generator'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const ADS = /googlesyndication|doubleclick|adservice|adtrafficquality|fundingchoices|ytimg|ggpht|youtube/; const V = 'ZQX-PRIV-7731', CAP = 'SecretCaption9';
(async () => { const b = await chromium.launch(); const R = { t: now(), tries: 0 };
 for (let i = 0; i < 20; i++) { const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await c.newPage(); p.setDefaultTimeout(12000);
  const reqs = []; p.on('request', q => { const u = q.url(); if (ADS.test(u)) return; const pd = q.postData() || ''; reqs.push({ m: q.method(), u: u.replace(/\?.*/, '').slice(0, 100), post: pd.length, hit: (u + pd).includes(V) || (u + pd).includes(CAP) || (u + pd).includes(encodeURIComponent(CAP)) }); });
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday; R.tries++;
  if (await used() >= 10) { await c.close(); continue; } R.start = await used();
  await p.locator('#bc-format').click(); await p.getByRole('option', { name: /^Code 128/ }).click(); const n0 = reqs.length; await p.locator('#bc-value').fill(V); await p.locator('#bc-caption').fill(CAP); await p.waitForTimeout(1500);
  let dl = p.waitForEvent('download', { timeout: 15000 }); await p.getByRole('button', { name: 'Download PNG', exact: true }).click(); await dl; await p.waitForTimeout(2500); R.afterFirst = await used(); R.reqsFromTyping = reqs.slice(n0);
  await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); R.afterReload = await used(); await p.locator('#bc-value').fill('400638133390'); await p.waitForTimeout(1000);
  dl = p.waitForEvent('download', { timeout: 15000 }).catch(() => null); await p.getByRole('button', { name: 'Download PNG', exact: true }).click(); R.reloadDl = !!(await dl); await p.waitForTimeout(2000); R.afterReloadDl = await used();
  R.anyHit = reqs.filter(r => r.hit); R.hosts = [...new Set(reqs.map(r => r.u.split('/')[2]))]; await c.close(); break; }
 R.t2 = now(); fs.writeFileSync(OUT + 'privacy.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
