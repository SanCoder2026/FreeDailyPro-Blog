// render the downloaded SVGs (single + from the ZIP) to PNG in Chromium at 3x for decoding (files are only displayed as images, never executed as scripts)
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path'); const glob = d => fs.readdirSync(d, { recursive: true }).filter(f => f.endsWith('.svg')).map(f => path.join(d, f));
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ deviceScaleFactor: 3 })).newPage(); const D = '/workspace/deep/25-barcode-generator/live/dl/';
 for (const f of glob(D)) { const svg = fs.readFileSync(f, 'utf8'); await p.setContent(`<body style="margin:20px;background:#fff"><img id=i src="data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}"></body>`); await p.waitForTimeout(200); const bb = await p.locator('#i').boundingBox(); await p.locator('#i').screenshot({ path: f + '.render.png' }); console.log(path.relative(D, f), JSON.stringify(bb)); }
 await b.close(); })();
