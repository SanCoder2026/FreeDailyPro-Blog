const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/invoiceDocx-B7gx31PS.js",
      "assets/index-CHifq31M.js",
      "assets/money-Dkxewa8a.js",
      "assets/invoiceCalc-DKfNuJtN.js",
      "assets/numberInput-5hjoxJ5z.js",
      "assets/invoiceAssets-GV284LFA.js",
      "assets/browser-CMr8NRjw.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/logoFile-BxMwsj0a.js",
      "assets/index-B1CTyGtY.js",
      "assets/index-BJxTAPRn.css",
      "assets/invoiceXlsx-CmTpngam.js",
      "assets/xlsx-CNerDvZX.js",
    ]),
) => i.map((i) => d[i]);
import {
  aU as pt,
  cl as Me,
  B as R,
  e as u,
  I as g,
  T as Ne,
  D as Ce,
  f as A,
  cm as ht,
  cn as xt,
  co as gt,
  ap as Oe,
  cp as vt,
} from "./index-B1CTyGtY.js";
import { r as d, j as t } from "./vendor-react-D01g8YgM.js";
import {
  A as ft,
  a as yt,
  b as bt,
  c as jt,
  d as wt,
  e as Nt,
  f as Ct,
  g as Dt,
} from "./alert-dialog-ocUtNtwl.js";
import {
  b as Pt,
  T as St,
  U as It,
  f as kt,
  d as De,
} from "./ToolPage-DwLoDncN.js";
import { C as Pe } from "./checkbox-Ml1pfDb3.js";
import { T as Tt } from "./ToolInfoSection-C0i6Zbwo.js";
import { f as We, C as Ft } from "./money-Dkxewa8a.js";
import {
  t as Xe,
  n as oe,
  b as Ve,
  a as le,
  T as Se,
} from "./invoiceCalc-DKfNuJtN.js";
import { t as de } from "./legalClauses-DgeuUksw.js";
import { P as _t } from "./ProfileBar-BPOawnEt.js";
import {
  c as Ke,
  h as Lt,
  p as $t,
  e as Ge,
  i as Ie,
  s as Rt,
} from "./invoiceAssets-GV284LFA.js";
import { u as Te, k as At } from "./index-BRvxULIc.js";
import { T as zt } from "./pdfText-bjh9eBB-.js";
import { a as Et } from "./logoFile-BxMwsj0a.js";
import { d as Ut } from "./tradeDoc-CN8_dtsj.js";
import { C as Bt } from "./copy-DcUvE8ta.js";
import { F as qt } from "./flask-conical-DwAwxK3z.js";
import { E as Mt } from "./eraser-DVBgSK_0.js";
import { U as Ot } from "./user-plus-C7KussDa.js";
import { T as Xt } from "./trash-2-CmoDM6Qu.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-DhOoIDuZ.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./numberInput-5hjoxJ5z.js";
import "./dates-DoPZ1fRV.js";
import "./EmbedContext-CCnUNY-R.js";
import "./browser-CMr8NRjw.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./fontkit.es-DA-3qwB1.js";
const m = 50,
  Vt = 70,
  ie = Te(0.45, 0.45, 0.45),
  He = Te(0.8, 0.8, 0.8);
async function Gt(a) {
  const y = (r) => We(r, a.currency),
    l = Ke({ ...a, money: y }),
    [V, z] = a.paper === "a4" ? [595, 842] : [612, 792],
    f = V - 50,
    F = f - 562,
    Y = z - 52,
    _ = l.taxGroups.length > 1,
    G = Te(...Lt(a.brandColor)),
    C = await At.create(),
    v = a.business,
    P = "Tax",
    H = [
      Xe(a.terms),
      v.name,
      v.address,
      v.taxId,
      v.email,
      v.phone,
      v.website,
      a.client.name,
      a.client.address,
      a.number,
      a.date,
      a.dueDate,
      a.notes,
      a.taxLabel,
      a.payment.link,
      a.payment.instructions,
      l.lateFee?.text ?? "",
      ...l.lines.map((r) => r.description),
      "INVOICE Total Subtotal Discount Shipping Amount paid Balance due (credit) Description Qty Unit Price Amount Bill To FROM Notes Invoice Date Due Page Approved by Tax ID Payment instructions Pay online Scan to pay on",
      P,
      ...l.taxGroups.map((r) => `${a.taxLabel} ${r.rate}%`),
      y(0),
      "0123456789,.-%:",
    ].join(`
`),
    s = await zt.create(C, H),
    S = await Et(a.logoDataUrl).catch(() => null),
    E = S
      ? S.type === "png"
        ? await C.embedPng(S.bytes)
        : await C.embedJpg(S.bytes)
      : null,
    U = await $t(a.payment.link),
    I = U ? await C.embedPng(U) : null;
  let o = C.addPage([V, z]),
    i = Y;
  const k = _
      ? {
          qtyRight: 330 + F,
          priceRight: 405 + F,
          taxRight: 455 + F,
          amountRight: f,
        }
      : { qtyRight: 372 + F, priceRight: 462 + F, taxRight: 0, amountRight: f },
    B = k.qtyRight - 40 - m,
    W = () => {
      (s.draw(o, "Description", { x: m, y: i, size: 10, bold: !0 }),
        s.drawRight(o, "Qty", { rightX: k.qtyRight, y: i, size: 10, bold: !0 }),
        s.drawRight(o, "Unit price", {
          rightX: k.priceRight,
          y: i,
          size: 10,
          bold: !0,
        }),
        _ &&
          s.drawRight(o, P, { rightX: k.taxRight, y: i, size: 10, bold: !0 }),
        s.drawRight(o, "Amount", {
          rightX: k.amountRight,
          y: i,
          size: 10,
          bold: !0,
        }),
        (i -= 8),
        o.drawLine({
          start: { x: m, y: i },
          end: { x: f, y: i },
          thickness: 1,
          color: He,
        }),
        (i -= 16));
    },
    K = (r) => {
      ((o = C.addPage([V, z])),
        (i = Y),
        s.draw(o, `Invoice ${a.number} (continued)`, {
          x: m,
          y: i,
          size: 10,
          color: ie,
        }),
        (i -= 24),
        r && W());
    },
    L = (r, h = !0) => {
      i - r < Vt && K(h);
    };
  if (E && S) {
    const r = Math.min(140 / S.width, 48 / S.height, 4),
      h = S.width * r,
      p = S.height * r;
    (o.drawImage(E, { x: m, y: i - p + 14, width: h, height: p }),
      (i -= p + 8));
  }
  (s.draw(o, "INVOICE", { x: m, y: i, size: 24, bold: !0, color: G }),
    s.drawRight(o, `Invoice #: ${a.number}`, {
      rightX: f,
      y: i + 14,
      size: 10,
    }),
    s.drawRight(o, `Date: ${a.date}`, { rightX: f, y: i, size: 10 }),
    a.dueDate &&
      s.drawRight(o, `Due: ${a.dueDate}`, { rightX: f, y: i - 14, size: 10 }));
  const $ = Xe(a.terms);
  ($ &&
    s.drawRight(o, $, { rightX: f, y: i - (a.dueDate ? 28 : 14), size: 10 }),
    (i -= $ ? 54 : 40));
  const J = (r, h, p, D = []) => {
    (s.draw(o, r, { x: m, y: i, size: 9, bold: !0, color: ie }),
      (i -= 14),
      s.draw(o, h, { x: m, y: i, size: 12, bold: !0 }),
      (i -= 14));
    for (const M of s.wrap(p, 10, 240))
      M && (s.draw(o, M, { x: m, y: i, size: 10 }), (i -= 13));
    for (const M of D) (s.draw(o, M, { x: m, y: i, size: 10 }), (i -= 13));
    i -= 10;
  };
  (J(
    "FROM",
    v.name,
    v.address,
    [
      v.taxId.trim() ? `Tax ID: ${v.taxId.trim()}` : "",
      v.email,
      v.phone,
      v.website,
    ].filter(Boolean),
  ),
    J("BILL TO", a.client.name, a.client.address),
    (i -= 6),
    W());
  for (const r of l.lines) {
    const h = s.wrap(
      r.credit ? `${r.description} (credit)` : r.description,
      10,
      B,
    );
    (L(h.length * 13 + 8),
      h.forEach((p, D) => s.draw(o, p, { x: m, y: i - D * 13, size: 10 })),
      s.drawRight(o, String(r.qty), { rightX: k.qtyRight, y: i, size: 10 }),
      s.drawRight(o, y(r.price), { rightX: k.priceRight, y: i, size: 10 }),
      _ &&
        s.drawRight(o, `${r.taxRate}%`, { rightX: k.taxRight, y: i, size: 10 }),
      s.drawRight(o, y(r.amount), { rightX: k.amountRight, y: i, size: 10 }),
      (i -= h.length * 13 + 6));
  }
  (L(110, !1),
    (i -= 4),
    o.drawLine({
      start: { x: 340 + F, y: i },
      end: { x: f, y: i },
      thickness: 1,
      color: He,
    }),
    (i -= 16));
  const N = (r, h, p = !1, D = 10) => {
    (s.draw(o, r, { x: 340 + F, y: i, size: D, bold: p }),
      s.drawRight(o, h, { rightX: f, y: i, size: D, bold: p }),
      (i -= D + 6));
  };
  ((l.discount > 0 || l.tax > 0 || l.shipping > 0) &&
    N("Subtotal", y(l.subtotal)),
    l.discount > 0 && N(`Discount (${a.discountPct}%)`, `-${y(l.discount)}`));
  const Z = a.taxLabel.trim() || "Tax";
  if (_)
    for (const r of l.taxGroups) r.tax > 0 && N(`${Z} ${r.rate}%`, y(r.tax));
  else l.tax > 0 && N(`${Z} (${l.taxGroups[0]?.rate ?? 0}%)`, y(l.tax));
  (l.shipping > 0 && N("Shipping", y(l.shipping)),
    N("Total", y(l.total), !0, 12),
    l.paid > 0 &&
      (N("Amount paid", `-${y(l.paid)}`),
      N("Balance due", y(l.balanceDue), !0, 12)));
  const Q = (r, h) => {
    if (h.trim()) {
      ((i -= 14),
        L(40, !1),
        s.draw(o, r, { x: m, y: i, size: 10, bold: !0 }),
        (i -= 15));
      for (const p of s.wrap(h.trim(), 10, f - m))
        (L(15, !1), s.draw(o, p, { x: m, y: i, size: 10 }), (i -= 13));
    }
  };
  if (l.lateFee) {
    i -= 6;
    for (const r of s.wrap(l.lateFee.text, 9, f - m))
      (L(14, !1), s.draw(o, r, { x: m, y: i, size: 9, color: ie }), (i -= 12));
  }
  if (
    (Q("Notes", a.notes),
    Q("Payment instructions", a.payment.instructions),
    a.payment.link.trim() || I)
  ) {
    const r = I ? 110 : 40;
    ((i -= 14),
      L(r, !1),
      s.draw(o, "Pay online", { x: m, y: i, size: 10, bold: !0 }),
      (i -= 15),
      I &&
        (o.drawImage(I, { x: m, y: i - 80, width: 80, height: 80 }),
        s.draw(o, "Scan to pay on your phone", {
          x: m + 92,
          y: i - 12,
          size: 9,
          color: ie,
        })),
      s.draw(o, a.payment.link.trim(), {
        x: I ? m + 92 : m,
        y: I ? i - 28 : i,
        size: 9,
        color: G,
      }),
      (i -= I ? 88 : 14));
  }
  a.includeSignature &&
    ((i -= 30),
    L(50, !1),
    s.draw(o, "Approved by: _________________________", {
      x: m,
      y: i,
      size: 10,
    }),
    (i -= 20),
    s.draw(o, "Date: _____________", { x: m, y: i, size: 10 }));
  const q = C.getPages();
  return (
    q.length > 1 &&
      q.forEach((r, h) =>
        s.drawRight(r, `Page ${h + 1} of ${q.length}`, {
          rightX: f,
          y: 40,
          size: 8,
          color: ie,
        }),
      ),
    await s.finish(),
    { bytes: await C.save(), note: s.note() }
  );
}
const Je = "fdp-invoice-last-number",
  Qe = () => {
    try {
      return sessionStorage.getItem(Je);
    } catch {
      return null;
    }
  },
  Ht = (a) => {
    try {
      sessionStorage.setItem(Je, a);
    } catch {}
  },
  Ye = {
    businessName: "Northwind Design Studio",
    businessAddress: `12 Market Street
Portland, OR 97201`,
    businessTaxId: "",
    clientName: "Acme Corp",
    clientAddress: `500 Main Street
Seattle, WA 98101`,
    terms: "net30",
    currency: "USD",
    discountPct: "5",
    taxPct: "8",
    taxLabel: "Tax",
    shipping: "",
    paid: "100",
    notes: "Payment by bank transfer within 30 days. Thank you!",
    items: [
      {
        id: "s1",
        description: "Brand identity design",
        quantity: "1",
        unitPrice: "1200",
      },
      {
        id: "s2",
        description: "Website mockups (hours)",
        quantity: "6",
        unitPrice: "85",
      },
    ],
    includeSignature: !1,
    lateFeePct: "1.5",
    lateFeeFlat: "",
    lateFeeDays: "10",
    payLink: "",
    showLogo: !0,
  },
  ke = {
    what: "Builds a professional invoice with your logo, per-line tax, a late-fee line and a payment link with a QR code, and gives you the finished invoice as a PDF, an editable Word file or an Excel sheet with live formulas. Load your saved business profile and your details, clients and next invoice number fill in for you.",
    how: 'Load your business profile (or type your details once and save the profile file). Pick a saved client or import a client list from a CSV, add line items with quantities, prices and an optional tax rate per line, and set the currency, discount and late fee. Add a payment link to print a QR code on the invoice. Download PDF, Word or Excel. The invoice number moves on to the next one and is kept in your profile file, and "Duplicate last invoice" starts the next one from the last. Long invoices continue on extra pages. Names and notes in any language work, including accents, ₹ and Hindi.',
    tip: "Save your profile file after each invoice run: it holds your next invoice number, your clients and your last invoice, and nothing is stored on our servers. For India, put your GSTIN in the tax ID box; for the EU, your VAT number. Use a different tax rate on a line for zero-rated or reduced-rate items.",
  };
function Xi() {
  const [a, y] = pt(),
    [l, V] = d.useState(""),
    [z, f] = d.useState(""),
    [F, Y] = d.useState(""),
    [_, G] = d.useState(""),
    [C, v] = d.useState(""),
    [P, H] = d.useState(() => oe(Qe())),
    [s, S] = d.useState(de()),
    [E, U] = d.useState(""),
    [I, o] = d.useState("custom"),
    [i, k] = d.useState(""),
    [B, W] = d.useState(""),
    [K, L] = d.useState("USD"),
    [$, J] = d.useState(""),
    [N, Z] = d.useState(""),
    [Q, q] = d.useState("Tax"),
    [r, h] = d.useState(""),
    [p, D] = d.useState([
      { id: "1", description: "", quantity: "1", unitPrice: "" },
    ]),
    [M, Fe] = d.useState(!1),
    [ce, ue] = d.useState(""),
    [me, pe] = d.useState(""),
    [he, xe] = d.useState(""),
    [ee, ge] = d.useState(""),
    [ve, _e] = d.useState(!0),
    [Le, $e] = d.useState(() => Ut()),
    [Ze, fe] = d.useState(!1),
    [ae, ye] = d.useState(null),
    Re = d.useRef(null),
    et = () => ({
      businessName: l,
      businessAddress: z,
      businessTaxId: F,
      clientName: _,
      clientAddress: C,
      invoiceNumber: P,
      invoiceDate: s,
      dueDate: E,
      terms: I,
      currency: K,
      discountPct: $,
      taxPct: N,
      taxLabel: Q,
      shipping: i,
      paid: B,
      notes: r,
      items: p,
      includeSignature: M,
      lateFeePct: ce,
      lateFeeFlat: me,
      lateFeeDays: he,
      payLink: ee,
      showLogo: ve,
    }),
    Ae = (e) => {
      (V(e.businessName),
        f(e.businessAddress),
        Y(e.businessTaxId),
        G(e.clientName),
        v(e.clientAddress),
        H(e.invoiceNumber),
        S(e.invoiceDate),
        U(e.dueDate),
        o(e.terms),
        L(e.currency),
        J(e.discountPct),
        Z(e.taxPct),
        q(e.taxLabel),
        k(e.shipping),
        W(e.paid),
        h(e.notes),
        D(e.items),
        Fe(e.includeSignature),
        ue(e.lateFeePct),
        pe(e.lateFeeFlat),
        xe(e.lateFeeDays),
        ge(e.payLink),
        _e(e.showLogo),
        fe(!1));
    };
  d.useEffect(() => {
    (V((e) => (e.trim() ? e : a.name)),
      f((e) => (e.trim() ? e : a.address)),
      Y((e) => (e.trim() ? e : a.taxId)),
      ge((e) => (e.trim() ? e : a.payment.link)),
      h((e) => (e.trim() ? e : a.payment.instructions)),
      a.defaults.currency && L((e) => (e === "USD" ? a.defaults.currency : e)),
      a.defaults.taxPct && Z((e) => (e.trim() ? e : a.defaults.taxPct)),
      a.defaults.taxLabel && q((e) => (e === "Tax" ? a.defaults.taxLabel : e)),
      a.defaults.paper && $e(a.defaults.paper),
      a.numbering.invoice &&
        H((e) =>
          e === oe(Qe()) || e === "INV-001" ? Me(a, "invoice", "INV-001") : e,
        ));
  }, [a]);
  const tt = !!(
      l ||
      _ ||
      z ||
      C ||
      F ||
      r ||
      i ||
      B ||
      $ ||
      N ||
      p.some((e) => e.description || e.unitPrice)
    ),
    ze = (e, n) => {
      const c = et();
      (Ae(n()),
        A(e, {
          action: { label: "Undo", onClick: () => Ae(c) },
          duration: 8e3,
        }));
    },
    Ee = () =>
      ze("Sample invoice loaded.", () => {
        const e = de();
        return {
          ...Ye,
          invoiceNumber: P,
          invoiceDate: e,
          dueDate: le(e, 30),
          items: Ye.items.map((n) => ({ ...n })),
        };
      }),
    Ue = () =>
      ze("Invoice cleared.", () => ({
        businessName: "",
        businessAddress: "",
        businessTaxId: "",
        clientName: "",
        clientAddress: "",
        invoiceNumber: P,
        invoiceDate: de(),
        dueDate: "",
        terms: "custom",
        currency: "USD",
        discountPct: "",
        taxPct: "",
        taxLabel: "Tax",
        shipping: "",
        paid: "",
        notes: "",
        items: [
          {
            id: Date.now().toString(),
            description: "",
            quantity: "1",
            unitPrice: "",
          },
        ],
        includeSignature: !1,
        lateFeePct: "",
        lateFeeFlat: "",
        lateFeeDays: "",
        payLink: "",
        showLogo: !0,
      })),
    Be = (e) => {
      tt ? ye(e) : (e === "sample" ? Ee : Ue)();
    },
    it = (e) => {
      (S(e), I !== "custom" && U(le(e, Se[I])));
    },
    at = (e) => {
      (o(e), e !== "custom" && U(le(s, Se[e])));
    },
    st = () =>
      D((e) => [
        ...e,
        {
          id: Date.now().toString(),
          description: "",
          quantity: "1",
          unitPrice: "",
        },
      ]),
    nt = (e) => D((n) => n.filter((c) => c.id !== e)),
    se = (e, n, c) =>
      D((x) => x.map((T) => (T.id === e ? { ...T, [n]: c } : T))),
    rt = (e) => {
      const n = a.clients.find((c) => c.id === e);
      n && (G(n.name), v(n.address));
    },
    ot = () => {
      if (!_.trim()) {
        A.error("Type the client name first.");
        return;
      }
      (y.set((e) => ht(e, { name: _, address: C, email: "", taxId: "" })),
        A.success(
          "Client saved to your profile. Save the profile file to keep it.",
        ));
    },
    lt = async (e) => {
      if (!e) return;
      const n = xt(await e.text());
      if (n.error) {
        A.error(n.error);
        return;
      }
      (y.set((c) => gt(c, n.clients)),
        A.success(
          `${n.clients.length} client${n.clients.length === 1 ? "" : "s"} imported${n.skipped ? ` (${n.skipped} row${n.skipped === 1 ? "" : "s"} without a name skipped)` : ""}. Save the profile file to keep them.`,
        ));
    },
    dt = () => {
      const e = a.lastInvoice;
      if (!e) return;
      const n = de(),
        c =
          ["custom", "receipt", "net15", "net30", "net60"].find(
            (x) => x === e.terms,
          ) ?? "custom";
      (G(e.clientName),
        v(e.clientAddress),
        L(e.currency || "USD"),
        o(c),
        q(e.taxLabel || "Tax"),
        h(e.notes),
        J(e.discountPct),
        k(e.shipping),
        ue(e.lateFeePct),
        pe(e.lateFeeFlat),
        xe(e.lateFeeAfterDays),
        W(""),
        S(n),
        U(c === "custom" ? "" : le(n, Se[c])),
        H(Me(a, "invoice", "INV-001")),
        D(
          e.items.map((x, T) => ({
            id: `dup${Date.now()}${T}`,
            description: x.description,
            quantity: x.quantity,
            unitPrice: x.unitPrice,
            taxPct: x.taxPct,
            credit: x.credit,
          })),
        ),
        fe(!1),
        A.success(
          "Last invoice copied with today's date and the next number.",
        ));
    },
    qe = {
      businessName: l,
      clientName: _,
      invoiceDate: s,
      dueDate: E,
      items: p,
      discountPct: $,
      taxPct: N,
      shipping: i,
      paid: B,
    },
    ne = { pct: ce, flat: me, afterDays: he },
    ct = Ze ? [...Ve(qe), ...Ge(p, ne, ee)] : [],
    te = (e) => ct.find((n) => n.field === e)?.message,
    O = (e) => We(e, K),
    b = Ke({
      items: p,
      defaultTaxPct: N,
      discountPct: $,
      shipping: i,
      paid: B,
      lateFee: ne,
      dueDate: E,
      money: O,
    }),
    { logUsageNow: ut } = Pt(),
    mt = () => ({
      business: {
        name: l,
        address: z,
        taxId: F,
        email: a.email,
        phone: a.phone,
        website: a.website,
      },
      client: { name: _, address: C },
      number: P,
      date: s,
      dueDate: E,
      terms: I,
      currency: K,
      taxLabel: Q,
      defaultTaxPct: N,
      discountPct: $,
      shipping: i,
      paid: B,
      notes: r,
      items: p,
      lateFee: ne,
      payment: {
        link: ee,
        instructions:
          a.payment.instructions && a.payment.instructions !== r
            ? a.payment.instructions
            : "",
      },
      includeSignature: M,
      logoDataUrl: ve ? a.logoDataUrl : "",
      brandColor: a.brand.primary,
      paper: Le,
    }),
    be = async (e) => {
      fe(!0);
      const n = [...Ve(qe), ...Ge(p, ne, ee)];
      if (n.length) {
        (A.error(
          n.length === 1
            ? n[0].message
            : `Please fix ${n.length} things before generating. The first is marked.`,
        ),
          setTimeout(() => {
            const x = document.getElementById(n[0].field);
            (x?.scrollIntoView({ block: "center" }), x?.focus());
          }, 0));
        return;
      }
      if (await ut())
        try {
          const x = mt();
          let T = null;
          if (e === "pdf") {
            const X = await Gt(x);
            ((T = X.note),
              De(
                new Blob([new Uint8Array(X.bytes)], {
                  type: "application/pdf",
                }),
                Ie(P, "pdf"),
              ));
          } else if (e === "docx") {
            const { buildInvoiceDocx: X } = await Oe(
              async () => {
                const { buildInvoiceDocx: we } =
                  await import("./invoiceDocx-B7gx31PS.js");
                return { buildInvoiceDocx: we };
              },
              __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]),
            );
            De(
              new Blob([new Uint8Array(await X(x))], {
                type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
              }),
              Ie(P, "docx"),
            );
          } else {
            const { buildInvoiceXlsx: X } = await Oe(
              async () => {
                const { buildInvoiceXlsx: we } =
                  await import("./invoiceXlsx-CmTpngam.js");
                return { buildInvoiceXlsx: we };
              },
              __vite__mapDeps([11, 12, 5, 6, 7, 8, 9, 10, 3, 4, 2]),
            );
            De(
              new Blob([new Uint8Array(X(x))], {
                type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
              }),
              Ie(P, "xlsx"),
            );
          }
          Ht(P.trim());
          const re = P.trim();
          (y.set((X) => ({ ...vt(X, "invoice", re), lastInvoice: Rt(x) })),
            H(oe(re)),
            T
              ? A.warning(T)
              : A.success(
                  `Invoice ${re} downloaded. Next number: ${oe(re)}. Save your profile to keep it.`,
                ));
        } catch (x) {
          (console.error("Invoice export failed", x),
            A.error(
              "Couldn't build the file. Try removing unusual symbols from the text, or contact us if it keeps happening.",
            ));
        }
    },
    j = (e) => {
      const n = te(e);
      return n
        ? t.jsx("p", {
            id: `${e}-err`,
            role: "alert",
            className: "text-xs text-destructive mt-1",
            children: n,
          })
        : null;
    },
    w = (e) => ({
      "aria-invalid": te(e) ? !0 : void 0,
      "aria-describedby": te(e) ? `${e}-err` : void 0,
      className: te(e) ? "border-destructive" : void 0,
    }),
    je = (e, n) => `${n} ${te(e) ? "border-destructive" : ""}`;
  return t.jsxs(St, {
    children: [
      t.jsxs("div", {
        className: "max-w-xl mx-auto space-y-5",
        children: [
          t.jsx(_t, {}),
          t.jsxs("div", {
            className: "flex flex-wrap gap-2 justify-end",
            children: [
              a.lastInvoice &&
                t.jsxs(R, {
                  variant: "outline",
                  size: "sm",
                  className: "gap-1.5",
                  onClick: dt,
                  "data-testid": "inv-duplicate",
                  children: [
                    t.jsx(Bt, { className: "h-3.5 w-3.5" }),
                    " Duplicate last invoice",
                  ],
                }),
              t.jsxs(R, {
                variant: "ghost",
                size: "sm",
                className: "gap-1.5",
                onClick: () => Be("sample"),
                children: [
                  t.jsx(qt, { className: "h-3.5 w-3.5" }),
                  " Try a sample",
                ],
              }),
              t.jsxs(R, {
                variant: "ghost",
                size: "sm",
                className: "gap-1.5",
                onClick: () => Be("clear"),
                children: [t.jsx(Mt, { className: "h-3.5 w-3.5" }), " Clear"],
              }),
            ],
          }),
          t.jsxs("div", {
            className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
            children: [
              t.jsxs("div", {
                children: [
                  t.jsx(u, {
                    htmlFor: "inv-business",
                    children: "Your Business Name *",
                  }),
                  t.jsx(g, {
                    id: "inv-business",
                    ...w("inv-business"),
                    value: l,
                    onChange: (e) => V(e.target.value),
                    "data-testid": "inv-business",
                  }),
                  j("inv-business"),
                ],
              }),
              t.jsxs("div", {
                children: [
                  t.jsx(u, {
                    htmlFor: "inv-client",
                    children: "Client Name *",
                  }),
                  t.jsx(g, {
                    id: "inv-client",
                    ...w("inv-client"),
                    value: _,
                    onChange: (e) => G(e.target.value),
                    "data-testid": "inv-client",
                  }),
                  j("inv-client"),
                ],
              }),
              t.jsxs("div", {
                children: [
                  t.jsx(u, {
                    htmlFor: "inv-baddr",
                    children: "Your address (optional)",
                  }),
                  t.jsx(Ne, {
                    id: "inv-baddr",
                    rows: 2,
                    value: z,
                    onChange: (e) => f(e.target.value),
                  }),
                ],
              }),
              t.jsxs("div", {
                children: [
                  t.jsx(u, {
                    htmlFor: "inv-caddr",
                    children: "Client address (optional)",
                  }),
                  t.jsx(Ne, {
                    id: "inv-caddr",
                    rows: 2,
                    value: C,
                    onChange: (e) => v(e.target.value),
                  }),
                ],
              }),
            ],
          }),
          t.jsxs("div", {
            className: "flex flex-wrap items-end gap-2",
            "data-testid": "inv-clients",
            children: [
              a.clients.length > 0 &&
                t.jsxs("div", {
                  className: "min-w-[10rem] flex-1",
                  children: [
                    t.jsxs(u, {
                      htmlFor: "inv-pick",
                      children: ["Saved clients (", a.clients.length, ")"],
                    }),
                    t.jsxs("select", {
                      id: "inv-pick",
                      className:
                        "border rounded px-2 py-2 w-full bg-background text-base sm:text-sm h-10",
                      defaultValue: "",
                      onChange: (e) => {
                        (rt(e.target.value), (e.target.value = ""));
                      },
                      children: [
                        t.jsx("option", {
                          value: "",
                          children: "Choose a client...",
                        }),
                        a.clients.map((e) =>
                          t.jsx(
                            "option",
                            { value: e.id, children: e.name },
                            e.id,
                          ),
                        ),
                      ],
                    }),
                  ],
                }),
              t.jsxs(R, {
                variant: "outline",
                size: "sm",
                className: "gap-1.5 min-h-10",
                onClick: ot,
                children: [
                  t.jsx(Ot, { className: "h-3.5 w-3.5" }),
                  " Save client to profile",
                ],
              }),
              t.jsxs(R, {
                variant: "outline",
                size: "sm",
                className: "gap-1.5 min-h-10",
                onClick: () => Re.current?.click(),
                children: [
                  t.jsx(It, { className: "h-3.5 w-3.5" }),
                  " Import clients (CSV)",
                ],
              }),
              t.jsx("input", {
                ref: Re,
                type: "file",
                accept: ".csv,text/csv",
                className: "hidden",
                "aria-label": "Import clients from a CSV file",
                onChange: (e) => {
                  (lt(e.target.files?.[0]), (e.target.value = ""));
                },
              }),
            ],
          }),
          t.jsxs("div", {
            children: [
              t.jsx(u, {
                htmlFor: "inv-taxid",
                children: "Your tax ID (optional: EIN, VAT, GSTIN)",
              }),
              t.jsx(g, {
                id: "inv-taxid",
                value: F,
                onChange: (e) => Y(e.target.value),
              }),
            ],
          }),
          a.logoDataUrl &&
            t.jsxs("label", {
              className: "flex items-center gap-2 text-sm min-h-10",
              children: [
                t.jsx(Pe, {
                  checked: ve,
                  onCheckedChange: (e) => _e(e === !0),
                  "aria-label": "Show my logo",
                }),
                " ",
                t.jsx("img", {
                  src: a.logoDataUrl,
                  alt: "",
                  className: "h-7 max-w-[7rem] object-contain",
                }),
                " Show my logo on the invoice",
              ],
            }),
          t.jsxs("div", {
            className: "grid grid-cols-2 sm:grid-cols-4 gap-3",
            children: [
              t.jsxs("div", {
                children: [
                  t.jsx(u, { htmlFor: "inv-number", children: "Invoice #" }),
                  t.jsx(g, {
                    id: "inv-number",
                    value: P,
                    onChange: (e) => H(e.target.value),
                  }),
                ],
              }),
              t.jsxs("div", {
                children: [
                  t.jsx(u, { htmlFor: "inv-date", children: "Date" }),
                  t.jsx(g, {
                    id: "inv-date",
                    ...w("inv-date"),
                    type: "date",
                    value: s,
                    onChange: (e) => it(e.target.value),
                    "data-testid": "inv-date",
                  }),
                  j("inv-date"),
                ],
              }),
              t.jsxs("div", {
                children: [
                  t.jsx(u, { htmlFor: "inv-terms", children: "Payment terms" }),
                  t.jsxs("select", {
                    id: "inv-terms",
                    className:
                      "border rounded px-2 py-2 w-full bg-background text-sm h-10",
                    value: I,
                    onChange: (e) => at(e.target.value),
                    children: [
                      t.jsx("option", {
                        value: "custom",
                        children: "Custom date",
                      }),
                      t.jsx("option", {
                        value: "receipt",
                        children: "Due on receipt",
                      }),
                      t.jsx("option", { value: "net15", children: "Net 15" }),
                      t.jsx("option", { value: "net30", children: "Net 30" }),
                      t.jsx("option", { value: "net60", children: "Net 60" }),
                    ],
                  }),
                ],
              }),
              t.jsxs("div", {
                children: [
                  t.jsx(u, { htmlFor: "inv-due", children: "Due Date" }),
                  t.jsx(g, {
                    id: "inv-due",
                    ...w("inv-due"),
                    type: "date",
                    value: E,
                    onChange: (e) => {
                      (U(e.target.value), o("custom"));
                    },
                  }),
                  j("inv-due"),
                ],
              }),
            ],
          }),
          t.jsxs("div", {
            className: "grid grid-cols-2 sm:grid-cols-4 gap-3",
            children: [
              t.jsxs("div", {
                children: [
                  t.jsx(u, { htmlFor: "inv-currency", children: "Currency" }),
                  t.jsx("select", {
                    id: "inv-currency",
                    className:
                      "border rounded px-2 py-2 w-full bg-background text-sm h-10",
                    value: K,
                    onChange: (e) => L(e.target.value),
                    children: Ft.map((e) =>
                      t.jsx(
                        "option",
                        { value: e.code, children: e.label },
                        e.code,
                      ),
                    ),
                  }),
                ],
              }),
              t.jsxs("div", {
                children: [
                  t.jsx(u, {
                    htmlFor: "inv-discount",
                    children: "Discount (%)",
                  }),
                  t.jsx(g, {
                    id: "inv-discount",
                    ...w("inv-discount"),
                    inputMode: "decimal",
                    value: $,
                    onChange: (e) => J(e.target.value),
                  }),
                  j("inv-discount"),
                ],
              }),
              t.jsxs("div", {
                children: [
                  t.jsx(u, { htmlFor: "inv-tax", children: "Default tax (%)" }),
                  t.jsx(g, {
                    id: "inv-tax",
                    ...w("inv-tax"),
                    inputMode: "decimal",
                    value: N,
                    onChange: (e) => Z(e.target.value),
                    "data-testid": "inv-tax",
                  }),
                  j("inv-tax"),
                ],
              }),
              t.jsxs("div", {
                children: [
                  t.jsx(u, { htmlFor: "inv-taxlabel", children: "Tax label" }),
                  t.jsx(g, {
                    id: "inv-taxlabel",
                    value: Q,
                    onChange: (e) => q(e.target.value),
                    placeholder: "Tax",
                  }),
                ],
              }),
            ],
          }),
          t.jsxs("div", {
            className: "space-y-2",
            children: [
              t.jsx(u, { children: "Line Items" }),
              t.jsx("p", {
                className: "text-xs text-muted-foreground",
                children:
                  "Tax % on a line replaces the default tax for that line only. Leave it empty to use the default.",
              }),
              p.map((e, n) =>
                t.jsxs(
                  "div",
                  {
                    className: "space-y-1",
                    children: [
                      t.jsxs("div", {
                        className:
                          "flex gap-2 items-start flex-wrap sm:flex-nowrap",
                        children: [
                          t.jsx("div", {
                            className: "flex-1 min-w-[10rem]",
                            children: t.jsx(g, {
                              ...w(`inv-item-${e.id}-desc`),
                              "aria-label": `Description, line ${n + 1}`,
                              placeholder: "Description",
                              value: e.description,
                              onChange: (c) =>
                                se(e.id, "description", c.target.value),
                              "data-testid": "inv-desc",
                            }),
                          }),
                          t.jsx(g, {
                            ...w(`inv-item-${e.id}-qty`),
                            "aria-label": `Quantity, line ${n + 1}`,
                            inputMode: "decimal",
                            placeholder: "Qty",
                            value: e.quantity,
                            onChange: (c) =>
                              se(e.id, "quantity", c.target.value),
                            className: je(`inv-item-${e.id}-qty`, "w-16"),
                          }),
                          t.jsx(g, {
                            ...w(`inv-item-${e.id}-price`),
                            "aria-label": `Unit price, line ${n + 1}`,
                            inputMode: "decimal",
                            placeholder: "Price",
                            value: e.unitPrice,
                            onChange: (c) =>
                              se(e.id, "unitPrice", c.target.value),
                            className: je(`inv-item-${e.id}-price`, "w-24"),
                            "data-testid": "inv-price",
                          }),
                          t.jsx(g, {
                            ...w(`inv-item-${e.id}-tax`),
                            "aria-label": `Tax %, line ${n + 1}`,
                            inputMode: "decimal",
                            placeholder: "Tax %",
                            value: e.taxPct ?? "",
                            onChange: (c) => se(e.id, "taxPct", c.target.value),
                            className: je(`inv-item-${e.id}-tax`, "w-20"),
                          }),
                          t.jsxs("label", {
                            className:
                              "flex items-center gap-1 text-xs h-10 cursor-pointer whitespace-nowrap",
                            children: [
                              t.jsx(Pe, {
                                checked: !!e.credit,
                                onCheckedChange: (c) =>
                                  D((x) =>
                                    x.map((T) =>
                                      T.id === e.id
                                        ? { ...T, credit: c === !0 }
                                        : T,
                                    ),
                                  ),
                                "aria-label": `Credit line, line ${n + 1}`,
                              }),
                              " Credit",
                            ],
                          }),
                          t.jsx(R, {
                            size: "icon",
                            variant: "ghost",
                            className: "min-h-10 min-w-10",
                            onClick: () => nt(e.id),
                            disabled: p.length === 1,
                            "aria-label": `Remove line item ${n + 1}`,
                            children: t.jsx(Xt, { className: "h-4 w-4" }),
                          }),
                        ],
                      }),
                      j(`inv-item-${e.id}-desc`),
                      j(`inv-item-${e.id}-qty`),
                      j(`inv-item-${e.id}-price`),
                      j(`inv-item-${e.id}-tax`),
                      e.credit &&
                        t.jsx("p", {
                          className: "text-xs text-muted-foreground",
                          children:
                            "Credit line: this amount is subtracted from the invoice.",
                        }),
                    ],
                  },
                  e.id,
                ),
              ),
              t.jsxs(R, {
                variant: "outline",
                size: "sm",
                onClick: st,
                className: "gap-1.5",
                children: [
                  t.jsx(kt, { className: "h-3.5 w-3.5" }),
                  " Add Line Item",
                ],
              }),
            ],
          }),
          t.jsxs("div", {
            className: "grid grid-cols-2 gap-3",
            children: [
              t.jsxs("div", {
                children: [
                  t.jsx(u, {
                    htmlFor: "inv-shipping",
                    children: "Shipping / delivery (optional)",
                  }),
                  t.jsx(g, {
                    id: "inv-shipping",
                    ...w("inv-shipping"),
                    inputMode: "decimal",
                    value: i,
                    onChange: (e) => k(e.target.value),
                  }),
                  j("inv-shipping"),
                ],
              }),
              t.jsxs("div", {
                children: [
                  t.jsx(u, {
                    htmlFor: "inv-paid",
                    children: "Amount paid / deposit (optional)",
                  }),
                  t.jsx(g, {
                    id: "inv-paid",
                    ...w("inv-paid"),
                    inputMode: "decimal",
                    value: B,
                    onChange: (e) => W(e.target.value),
                  }),
                  j("inv-paid"),
                ],
              }),
            ],
          }),
          t.jsxs("fieldset", {
            className: "rounded-lg border p-3 space-y-2",
            children: [
              t.jsx("legend", {
                className: "text-sm font-medium px-1",
                children: "Late fee (optional)",
              }),
              t.jsxs("div", {
                className: "grid grid-cols-3 gap-3",
                children: [
                  t.jsxs("div", {
                    children: [
                      t.jsx(u, {
                        htmlFor: "inv-late-pct",
                        children: "Fee (% of balance)",
                      }),
                      t.jsx(g, {
                        id: "inv-late-pct",
                        ...w("inv-late-pct"),
                        inputMode: "decimal",
                        placeholder: "1.5",
                        value: ce,
                        onChange: (e) => ue(e.target.value),
                      }),
                      j("inv-late-pct"),
                    ],
                  }),
                  t.jsxs("div", {
                    children: [
                      t.jsx(u, {
                        htmlFor: "inv-late-flat",
                        children: "Plus flat fee",
                      }),
                      t.jsx(g, {
                        id: "inv-late-flat",
                        ...w("inv-late-flat"),
                        inputMode: "decimal",
                        value: me,
                        onChange: (e) => pe(e.target.value),
                      }),
                      j("inv-late-flat"),
                    ],
                  }),
                  t.jsxs("div", {
                    children: [
                      t.jsx(u, {
                        htmlFor: "inv-late-days",
                        children: "After (days)",
                      }),
                      t.jsx(g, {
                        id: "inv-late-days",
                        ...w("inv-late-days"),
                        inputMode: "numeric",
                        placeholder: "10",
                        value: he,
                        onChange: (e) => xe(e.target.value),
                      }),
                      j("inv-late-days"),
                    ],
                  }),
                ],
              }),
              b.lateFee
                ? t.jsx("p", {
                    className: "text-xs text-muted-foreground",
                    "data-testid": "inv-late-preview",
                    children: b.lateFee.text,
                  })
                : t.jsx("p", {
                    className: "text-xs text-muted-foreground",
                    children:
                      "Prints a late-fee line under the totals. Check that late fees are allowed where you and your client are.",
                  }),
            ],
          }),
          t.jsxs("div", {
            children: [
              t.jsx(u, {
                htmlFor: "inv-paylink",
                children: "Payment link (optional: adds a link and a QR code)",
              }),
              t.jsx(g, {
                id: "inv-paylink",
                ...w("inv-paylink"),
                type: "url",
                inputMode: "url",
                placeholder: "https://",
                value: ee,
                onChange: (e) => ge(e.target.value),
              }),
              j("inv-paylink"),
            ],
          }),
          t.jsxs("div", {
            children: [
              t.jsx(u, {
                htmlFor: "inv-notes",
                children: "Notes / payment instructions (optional)",
              }),
              t.jsx(Ne, {
                id: "inv-notes",
                rows: 3,
                value: r,
                onChange: (e) => h(e.target.value),
                placeholder:
                  "Payment instructions, bank details, payment terms, thank-you note",
              }),
            ],
          }),
          t.jsxs("div", {
            className:
              "p-4 rounded-xl border bg-primary/5 text-right space-y-0.5",
            children: [
              (b.discount > 0 || b.tax > 0 || b.shipping > 0) &&
                t.jsxs("p", {
                  className: "text-xs text-muted-foreground",
                  children: [
                    "Subtotal ",
                    O(b.subtotal),
                    b.discount > 0 ? ` · Discount -${O(b.discount)}` : "",
                    b.tax > 0 ? ` · ${Q.trim() || "Tax"} ${O(b.tax)}` : "",
                    b.shipping > 0 ? ` · Shipping ${O(b.shipping)}` : "",
                  ],
                }),
              t.jsx("p", {
                className: "text-xs text-muted-foreground",
                children: "Total",
              }),
              t.jsx("p", {
                className: "text-2xl font-bold text-primary",
                "data-testid": "inv-total",
                children: O(b.total),
              }),
              b.paid > 0 &&
                t.jsxs("p", {
                  className: "text-sm text-muted-foreground",
                  children: [
                    "Paid ",
                    O(b.paid),
                    " · Balance due ",
                    t.jsx("strong", {
                      className: "text-foreground",
                      "data-testid": "inv-balance",
                      children: O(b.balanceDue),
                    }),
                  ],
                }),
            ],
          }),
          t.jsxs("div", {
            className: "grid grid-cols-2 gap-3 items-end",
            children: [
              t.jsxs("div", {
                children: [
                  t.jsx(u, { htmlFor: "inv-paper", children: "Paper size" }),
                  t.jsxs("select", {
                    id: "inv-paper",
                    className:
                      "border rounded px-2 py-2 w-full bg-background text-base sm:text-sm h-10",
                    value: Le,
                    onChange: (e) => $e(e.target.value),
                    children: [
                      t.jsx("option", { value: "a4", children: "A4" }),
                      t.jsx("option", { value: "letter", children: "Letter" }),
                    ],
                  }),
                ],
              }),
              t.jsxs("div", {
                className: "flex items-center gap-2 min-h-10",
                children: [
                  t.jsx(Pe, {
                    id: "include-signature",
                    checked: M,
                    onCheckedChange: (e) => Fe(e === !0),
                  }),
                  t.jsx(u, {
                    htmlFor: "include-signature",
                    className: "font-normal cursor-pointer",
                    children: "Client approval line",
                  }),
                ],
              }),
            ],
          }),
          t.jsxs(R, {
            onClick: () => be("pdf"),
            className: "w-full gap-2",
            "data-testid": "inv-generate",
            children: [
              t.jsx(Ce, { className: "h-4 w-4" }),
              " Generate & Download Invoice (PDF)",
            ],
          }),
          t.jsxs("div", {
            className: "grid grid-cols-2 gap-2",
            children: [
              t.jsxs(R, {
                variant: "outline",
                onClick: () => be("docx"),
                className: "gap-2",
                "data-testid": "inv-docx",
                children: [
                  t.jsx(Ce, { className: "h-4 w-4" }),
                  " Word (.docx)",
                ],
              }),
              t.jsxs(R, {
                variant: "outline",
                onClick: () => be("xlsx"),
                className: "gap-2",
                "data-testid": "inv-xlsx",
                children: [
                  t.jsx(Ce, { className: "h-4 w-4" }),
                  " Excel (.xlsx)",
                ],
              }),
            ],
          }),
        ],
      }),
      t.jsx(ft, {
        open: ae !== null,
        onOpenChange: (e) => {
          e || ye(null);
        },
        children: t.jsxs(yt, {
          children: [
            t.jsxs(bt, {
              children: [
                t.jsx(jt, {
                  children:
                    ae === "sample"
                      ? "Replace your entries with a sample?"
                      : "Clear this invoice?",
                }),
                t.jsx(wt, {
                  children:
                    "You can undo this right after from the message that appears.",
                }),
              ],
            }),
            t.jsxs(Nt, {
              children: [
                t.jsx(Ct, { children: "Cancel" }),
                t.jsx(Dt, {
                  onClick: () => {
                    const e = ae;
                    (ye(null), e === "sample" ? Ee() : Ue());
                  },
                  children: ae === "sample" ? "Load sample" : "Clear",
                }),
              ],
            }),
          ],
        }),
      }),
      t.jsx(Tt, { whatIsIt: ke.what, howToUse: ke.how, tip: ke.tip }),
    ],
  });
}
export { Xi as default };
//# sourceMappingURL=InvoiceGenerator-CcQb7dIX.js.map
