import { r as m, j as e } from "./vendor-react-D01g8YgM.js";
import {
  aU as F,
  aV as D,
  q as S,
  B as i,
  D as B,
  a0 as E,
  e as l,
  I as n,
  T as b,
  aW as U,
  f as u,
  aX as z,
  aY as N,
  aZ as I,
} from "./index-B1CTyGtY.js";
import { U as T, d as R } from "./ToolPage-DwLoDncN.js";
import { u as $ } from "./EmbedContext-CCnUNY-R.js";
import { l as A } from "./logoFile-BxMwsj0a.js";
import { E as L } from "./eraser-DVBgSK_0.js";
const V = (o) =>
  o
    .replace(/[^\w.-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 50) || "business";
function G({ id: o, label: p, value: s, onCommit: d }) {
  const [g, x] = m.useState(s),
    [f, c] = m.useState(s);
  return (
    f !== s && (c(s), x(s)),
    e.jsxs("div", {
      children: [
        e.jsx(l, { htmlFor: o, className: "text-xs", children: p }),
        e.jsxs("div", {
          className: "flex gap-1.5 items-center",
          children: [
            e.jsx("input", {
              type: "color",
              "aria-label": `${p} picker`,
              className:
                "h-9 w-9 p-0 border rounded cursor-pointer bg-transparent",
              value: s || "#0f766e",
              onChange: (h) => d(N(h.target.value)),
            }),
            e.jsx(n, {
              id: o,
              className: "font-mono",
              placeholder: "#0f766e",
              value: g,
              onChange: (h) => x(h.target.value),
              onBlur: () => d(N(g)),
            }),
          ],
        }),
      ],
    })
  );
}
function Q({ onLoaded: o, compact: p = !1 } = {}) {
  const [s, d] = F(),
    g = $(),
    x = m.useRef(null),
    f = m.useRef(null),
    [c, h] = m.useState(!1),
    [y, v] = m.useState(!1),
    j = D(s),
    C = () => {
      (R(
        new Blob([U(s)], { type: "application/json" }),
        `${V(s.name)}.fdp-profile.json`,
      ),
        u.success(
          "Profile saved to a file. Keep it somewhere safe; load it next time.",
        ));
    },
    w = async (a) => {
      if (!a) return;
      const t = I(await a.text());
      if (!t.ok) {
        u.error(t.error);
        return;
      }
      (d.set(t.profile),
        o?.(t.profile),
        u.success(
          t.warnings.length
            ? `Profile loaded. ${t.warnings.join(" ")}`
            : "Profile loaded",
        ));
    },
    k = () => {
      (v(!1), d.clear(), u("Profile cleared from this tab."));
    },
    r = (a) => d.set((t) => z(t, a)),
    P = async (a) => {
      if (a)
        try {
          r({ logoDataUrl: await A(a) });
        } catch (t) {
          u.error(
            t instanceof Error ? t.message : "That image could not be read.",
          );
        }
    };
  return g
    ? null
    : e.jsxs("div", {
        className: "mt-4 text-xs text-muted-foreground",
        "data-testid": "profile-bar",
        children: [
          e.jsxs("div", {
            className: "flex flex-wrap items-center gap-2",
            children: [
              e.jsx(S, { className: "h-3.5 w-3.5", "aria-hidden": "true" }),
              e.jsxs("span", {
                children: [
                  "Business profile: ",
                  e.jsx("strong", {
                    className: "text-foreground",
                    children: j ? "none loaded" : s.name || "unnamed",
                  }),
                  ". Kept in this tab only, then erased.",
                ],
              }),
              e.jsxs(i, {
                variant: "outline",
                size: "sm",
                onClick: () => x.current?.click(),
                "data-testid": "profile-load",
                children: [
                  e.jsx(T, { className: "h-3.5 w-3.5 mr-1" }),
                  "Load profile",
                ],
              }),
              e.jsxs(i, {
                variant: "outline",
                size: "sm",
                onClick: C,
                disabled: j,
                "data-testid": "profile-save",
                children: [
                  e.jsx(B, { className: "h-3.5 w-3.5 mr-1" }),
                  "Save profile",
                ],
              }),
              e.jsxs(i, {
                variant: "ghost",
                size: "sm",
                onClick: () => (j ? void 0 : v(!0)),
                disabled: j,
                "data-testid": "profile-clear",
                children: [
                  e.jsx(L, { className: "h-3.5 w-3.5 mr-1" }),
                  "Clear",
                ],
              }),
              !p &&
                e.jsxs(i, {
                  variant: "ghost",
                  size: "sm",
                  onClick: () => h((a) => !a),
                  "aria-expanded": c,
                  "aria-controls": "bp-editor",
                  children: [
                    e.jsx(E, {
                      className: `h-3.5 w-3.5 mr-1 transition-transform ${c ? "rotate-180" : ""}`,
                    }),
                    c ? "Hide details" : "Edit details",
                  ],
                }),
            ],
          }),
          y &&
            e.jsxs("div", {
              className:
                "flex flex-wrap items-center gap-2 mt-2 rounded border bg-muted/40 px-2 py-1.5 text-foreground",
              role: "alertdialog",
              "aria-label": "Clear the profile?",
              children: [
                "Clear the profile from this tab? Save it first if you want to keep it.",
                e.jsx(i, {
                  size: "sm",
                  onClick: k,
                  "data-testid": "profile-clear-yes",
                  children: "Clear",
                }),
                e.jsx(i, {
                  size: "sm",
                  variant: "ghost",
                  onClick: () => v(!1),
                  children: "Cancel",
                }),
              ],
            }),
          c &&
            !p &&
            e.jsxs("div", {
              id: "bp-editor",
              className:
                "mt-3 grid grid-cols-1 sm:grid-cols-2 gap-3 rounded-lg border p-3 text-foreground",
              "data-testid": "profile-editor",
              children: [
                e.jsxs("div", {
                  children: [
                    e.jsx(l, {
                      htmlFor: "bp-name",
                      className: "text-xs",
                      children: "Business name",
                    }),
                    e.jsx(n, {
                      id: "bp-name",
                      value: s.name,
                      onChange: (a) => r({ name: a.target.value }),
                    }),
                  ],
                }),
                e.jsxs("div", {
                  children: [
                    e.jsx(l, {
                      htmlFor: "bp-tax",
                      className: "text-xs",
                      children: "Tax ID (EIN, VAT, GSTIN)",
                    }),
                    e.jsx(n, {
                      id: "bp-tax",
                      value: s.taxId,
                      onChange: (a) => r({ taxId: a.target.value }),
                    }),
                  ],
                }),
                e.jsxs("div", {
                  children: [
                    e.jsx(l, {
                      htmlFor: "bp-addr",
                      className: "text-xs",
                      children: "Address",
                    }),
                    e.jsx(b, {
                      id: "bp-addr",
                      rows: 2,
                      value: s.address,
                      onChange: (a) => r({ address: a.target.value }),
                    }),
                  ],
                }),
                e.jsxs("div", {
                  className: "space-y-2",
                  children: [
                    e.jsxs("div", {
                      children: [
                        e.jsx(l, {
                          htmlFor: "bp-email",
                          className: "text-xs",
                          children: "Email",
                        }),
                        e.jsx(n, {
                          id: "bp-email",
                          type: "email",
                          value: s.email,
                          onChange: (a) => r({ email: a.target.value }),
                        }),
                      ],
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsx(l, {
                          htmlFor: "bp-phone",
                          className: "text-xs",
                          children: "Phone",
                        }),
                        e.jsx(n, {
                          id: "bp-phone",
                          value: s.phone,
                          onChange: (a) => r({ phone: a.target.value }),
                        }),
                      ],
                    }),
                  ],
                }),
                e.jsxs("div", {
                  children: [
                    e.jsx(l, {
                      htmlFor: "bp-web",
                      className: "text-xs",
                      children: "Website",
                    }),
                    e.jsx(n, {
                      id: "bp-web",
                      value: s.website,
                      onChange: (a) => r({ website: a.target.value }),
                    }),
                  ],
                }),
                e.jsxs("div", {
                  children: [
                    e.jsx(l, {
                      htmlFor: "bp-paylink",
                      className: "text-xs",
                      children:
                        "Payment link (shown as a link and QR on invoices)",
                    }),
                    e.jsx(n, {
                      id: "bp-paylink",
                      placeholder: "https://",
                      value: s.payment.link,
                      onChange: (a) => r({ payment: { link: a.target.value } }),
                    }),
                  ],
                }),
                e.jsxs("div", {
                  className: "sm:col-span-2",
                  children: [
                    e.jsx(l, {
                      htmlFor: "bp-payinfo",
                      className: "text-xs",
                      children: "Payment instructions",
                    }),
                    e.jsx(b, {
                      id: "bp-payinfo",
                      rows: 2,
                      value: s.payment.instructions,
                      onChange: (a) =>
                        r({ payment: { instructions: a.target.value } }),
                    }),
                  ],
                }),
                e.jsx("div", {
                  className: "grid grid-cols-3 gap-2 sm:col-span-2",
                  children: ["primary", "secondary", "accent"].map((a) =>
                    e.jsx(
                      G,
                      {
                        id: `bp-${a}`,
                        label:
                          a === "primary"
                            ? "Primary colour"
                            : a === "secondary"
                              ? "Secondary"
                              : "Accent",
                        value: s.brand[a],
                        onCommit: (t) => r({ brand: { [a]: t } }),
                      },
                      a,
                    ),
                  ),
                }),
                e.jsxs("div", {
                  className: "sm:col-span-2 flex flex-wrap items-center gap-3",
                  children: [
                    s.logoDataUrl
                      ? e.jsx("img", {
                          src: s.logoDataUrl,
                          alt: "Your logo",
                          className:
                            "h-12 max-w-[10rem] object-contain rounded border bg-white p-1",
                        })
                      : e.jsx("span", { children: "No logo yet." }),
                    e.jsx(i, {
                      variant: "outline",
                      size: "sm",
                      onClick: () => f.current?.click(),
                      children: s.logoDataUrl ? "Replace logo" : "Add logo",
                    }),
                    s.logoDataUrl &&
                      e.jsx(i, {
                        variant: "ghost",
                        size: "sm",
                        onClick: () => r({ logoDataUrl: "" }),
                        children: "Remove logo",
                      }),
                    e.jsx("input", {
                      ref: f,
                      type: "file",
                      accept: "image/*",
                      className: "hidden",
                      onChange: (a) => {
                        (P(a.target.files?.[0]), (a.target.value = ""));
                      },
                    }),
                  ],
                }),
                e.jsxs("p", {
                  className: "sm:col-span-2",
                  children: [
                    s.clients.length,
                    " saved client",
                    s.clients.length === 1 ? "" : "s",
                    " (add them in the Invoice Generator or import a CSV there). Numbering and the last invoice are kept in the file too.",
                  ],
                }),
              ],
            }),
          e.jsx("input", {
            ref: x,
            type: "file",
            accept: ".json,application/json",
            className: "hidden",
            onChange: (a) => {
              (w(a.target.files?.[0]), (a.target.value = ""));
            },
          }),
        ],
      });
}
export { Q as P };
//# sourceMappingURL=ProfileBar-BPOawnEt.js.map
