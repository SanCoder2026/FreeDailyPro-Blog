function D(t) {
  const e = /^(\d{4})-(\d{2})-(\d{2})$/.exec(t);
  if (!e) return null;
  const [n, a, s] = [Number(e[1]), Number(e[2]), Number(e[3])],
    r = new Date(Date.UTC(n, a - 1, s));
  return r.getUTCFullYear() !== n ||
    r.getUTCMonth() !== a - 1 ||
    r.getUTCDate() !== s
    ? null
    : { y: n, m: a, d: s };
}
function f(t = new Date()) {
  return { y: t.getFullYear(), m: t.getMonth() + 1, d: t.getDate() };
}
const c = (t) => Math.round(Date.UTC(t.y, t.m - 1, t.d) / 864e5),
  i = (t, e) => c(e) - c(t),
  l = (t, e) => new Date(Date.UTC(t, e, 0)).getUTCDate(),
  y = (t) => l(t, 2) === 29,
  m = (t, e) => c(t) - c(e);
function u(t, e) {
  const n = t.y * 12 + (t.m - 1) + e,
    a = Math.floor(n / 12),
    s = (n % 12) + 1;
  return { y: a, m: s, d: Math.min(t.d, l(a, s)) };
}
function h(t, e) {
  let n = (e.y - t.y) * 12 + (e.m - t.m);
  m(u(t, n), e) > 0 && n--;
  const a = i(u(t, n), e);
  return { years: Math.floor(n / 12), months: n % 12, days: a };
}
function g(t, e) {
  return new Date(t.y, t.m - 1, t.d).toLocaleDateString(e, { weekday: "long" });
}
function C(t, e) {
  const n = (s) =>
    t.m === 2 && t.d === 29 && !y(s)
      ? { date: { y: s, m: 3, d: 1 }, usedMarch1: !0 }
      : { date: { y: s, m: t.m, d: t.d }, usedMarch1: !1 };
  let a = n(e.y);
  return (m(a.date, e) < 0 && (a = n(e.y + 1)), a);
}
function M(t, e, n) {
  const a = c(t),
    s = c(e) + (n ? 1 : 0);
  let r = 0;
  for (let o = a; o < s; o++) {
    const d = new Date(o * 864e5).getUTCDay();
    d !== 0 && d !== 6 && r++;
  }
  return r;
}
function T(t, e) {
  const n = new Date(Date.UTC(t.y, t.m - 1, t.d + e));
  return { y: n.getUTCFullYear(), m: n.getUTCMonth() + 1, d: n.getUTCDate() };
}
export {
  i as a,
  h as b,
  m as c,
  l as d,
  M as e,
  T as f,
  C as n,
  D as p,
  f as t,
  g as w,
};
//# sourceMappingURL=dates-DoPZ1fRV.js.map
