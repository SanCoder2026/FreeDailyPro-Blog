import { Q as w } from "./browser-CMr8NRjw.js";
import { d as q } from "./logoFile-BxMwsj0a.js";
import { r, a as A } from "./invoiceCalc-DKfNuJtN.js";
import { p as D } from "./numberInput-5hjoxJ5z.js";
const y = (t) => (t === void 0 ? null : D(String(t).replace(/[$€£¥₹%]/g, ""))),
  m = (t) => {
    const e = y(t ?? "");
    return e === null || !Number.isFinite(e) ? 0 : e;
  };
function F(t, e) {
  const i = Math.min(100, Math.max(0, m(e.pct))),
    n = Math.max(0, m(e.flat));
  return r((Math.max(0, t) * i) / 100 + n);
}
function I(t, e, i, n = "") {
  const l = Math.min(100, Math.max(0, m(e.pct))),
    o = Math.max(0, m(e.flat));
  if (l <= 0 && o <= 0) return "";
  const s = Math.max(0, Math.floor(m(e.afterDays))),
    c = [];
  (l > 0 && c.push(`${l}% of the unpaid balance`), o > 0 && c.push(`${i(o)}`));
  const p =
      s > 0
        ? `${s} day${s === 1 ? "" : "s"} after the due date${n ? ` (${A(n, s) || n})` : ""}`
        : n
          ? `after the due date (${n})`
          : "after the due date",
    d = t > 0 ? ` On the current balance that is ${i(F(t, e))}.` : "";
  return `Late fee: ${c.join(" plus ")} is added to any balance still unpaid ${p}.${d}`;
}
function U(t) {
  const e = Math.min(100, Math.max(0, m(t.discountPct))),
    i = t.items
      .filter((a) => a.description.trim())
      .map((a) => {
        const u = m(a.quantity),
          f = m(a.unitPrice),
          x = !!a.credit,
          L = r(x ? -Math.abs(u * f) : u * f),
          R = (a.taxPct ?? "").trim() === "" ? m(t.defaultTaxPct) : m(a.taxPct);
        return {
          description: a.description.trim(),
          qty: u,
          price: x ? -Math.abs(f) : f,
          amount: L,
          credit: x,
          taxRate: Math.min(100, Math.max(0, R)),
        };
      }),
    n = r(i.reduce((a, u) => a + u.amount, 0)),
    l = r((n * e) / 100),
    o = r(n - l),
    s = new Map();
  for (const a of i) s.set(a.taxRate, r((s.get(a.taxRate) ?? 0) + a.amount));
  const c = Array.from(s.entries())
      .sort((a, u) => a[0] - u[0])
      .map(([a, u]) => {
        const f = r(u - (u * e) / 100);
        return { rate: a, base: f, tax: r((f * a) / 100) };
      }),
    p = r(c.reduce((a, u) => a + u.tax, 0)),
    d = i.map((a) => ({
      ...a,
      tax: r(((a.amount - (a.amount * e) / 100) * a.taxRate) / 100),
    })),
    b = r(Math.max(0, m(t.shipping))),
    $ = r(o + p + b),
    M = r(Math.max(0, m(t.paid))),
    h = r($ - M),
    v = t.money ?? ((a) => a.toFixed(2)),
    g = I(h, t.lateFee, v, t.dueDate);
  return {
    lines: d,
    subtotal: n,
    discount: l,
    taxable: o,
    tax: p,
    taxGroups: c,
    shipping: b,
    total: $,
    paid: M,
    balanceDue: h,
    lateFee: g ? { amount: F(h, t.lateFee), text: g } : null,
  };
}
function k(t, e, i) {
  const n = [];
  for (const o of t) {
    const s = (o.taxPct ?? "").trim();
    if (!s) continue;
    const c = y(s);
    c === null
      ? n.push({
          field: `inv-item-${o.id}-tax`,
          message: "Line tax must be a number.",
        })
      : (c < 0 || c > 100) &&
        n.push({
          field: `inv-item-${o.id}-tax`,
          message: "Line tax must be between 0 and 100.",
        });
  }
  const l = (o, s, c, p) => {
    if (!o.trim()) return;
    const d = y(o);
    (d === null || d < 0 || d > p) &&
      n.push({
        field: s,
        message: `${c} must be a number from 0 to ${p.toLocaleString("en-US")}.`,
      });
  };
  return (
    l(e.pct, "inv-late-pct", "Late fee %", 100),
    l(e.flat, "inv-late-flat", "Late fee amount", 1e9),
    l(e.afterDays, "inv-late-days", "Grace days", 3650),
    i.trim() &&
      !P(i) &&
      n.push({
        field: "inv-paylink",
        message: "The payment link must start with https:// (or http://).",
      }),
    n
  );
}
const P = (t) => /^https?:\/\/[^\s]+\.[^\s]+$/i.test(t.trim());
function C(t, e) {
  return `${
    t
      .trim()
      .replace(/[\\/:*?"<>|\u0000-\u001f\s]+/g, "-")
      .replace(/^-+|-+$/g, "") || "invoice"
  }.${e}`;
}
function G(t) {
  return {
    clientName: t.client.name,
    clientAddress: t.client.address,
    currency: t.currency,
    terms: t.terms,
    taxLabel: t.taxLabel,
    notes: t.notes,
    discountPct: t.discountPct,
    shipping: t.shipping,
    lateFeePct: t.lateFee.pct,
    lateFeeFlat: t.lateFee.flat,
    lateFeeAfterDays: t.lateFee.afterDays,
    items: t.items
      .filter((e) => e.description.trim())
      .map((e) => ({
        description: e.description,
        quantity: e.quantity,
        unitPrice: e.unitPrice,
        taxPct: e.taxPct ?? "",
        credit: !!e.credit,
      })),
  };
}
async function j(t, e = 320) {
  if (!P(t)) return null;
  try {
    const i = await w.toDataURL(t.trim(), {
      margin: 1,
      width: e,
      errorCorrectionLevel: "M",
    });
    return q(i)?.bytes ?? null;
  } catch {
    return null;
  }
}
function z(t, e = [0.07, 0.07, 0.07]) {
  const i = /^#([0-9a-f]{6})$/i.exec(t || "");
  if (!i) return e;
  const n = parseInt(i[1], 16);
  return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
}
export { U as c, k as e, z as h, C as i, j as p, G as s };
//# sourceMappingURL=invoiceAssets-GV284LFA.js.map
