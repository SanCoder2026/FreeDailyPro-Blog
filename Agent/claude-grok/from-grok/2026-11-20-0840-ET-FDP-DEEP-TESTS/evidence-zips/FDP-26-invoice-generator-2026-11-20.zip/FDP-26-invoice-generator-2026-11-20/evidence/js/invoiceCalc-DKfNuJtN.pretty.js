import { p as N } from "./numberInput-5hjoxJ5z.js";
const d = (e) => N(String(e ?? "").replace(/[$€£¥₹%]/g, "")),
  m = (e) => {
    const t = d(String(e ?? ""));
    if (t !== null) return t;
    const n = Number(String(e).replace(/,/g, ""));
    return Number.isFinite(n) ? n : 0;
  },
  c = (e) => Math.round((e + Number.EPSILON) * 100) / 100;
function E(e, t, n, o = "", i = "") {
  const s = e
      .filter((a) => a.description.trim())
      .map((a) => {
        const l = m(a.quantity),
          h = m(a.unitPrice),
          g = !!a.credit,
          y = c(g ? -Math.abs(l * h) : l * h);
        return {
          description: a.description.trim(),
          qty: l,
          price: g ? -Math.abs(h) : h,
          amount: y,
          credit: g,
        };
      }),
    r = c(s.reduce((a, l) => a + l.amount, 0)),
    u = Math.min(100, Math.max(0, m(t))),
    p = c((r * u) / 100),
    f = c(r - p),
    b = c((f * Math.max(0, m(n))) / 100),
    v = c(Math.max(0, m(o))),
    $ = c(f + b + v),
    x = c(Math.max(0, m(i)));
  return {
    lines: s,
    subtotal: r,
    discount: p,
    taxable: f,
    tax: b,
    shipping: v,
    total: $,
    paid: x,
    balanceDue: c($ - x),
  };
}
const D = (e) => e.trim() !== "" && d(e) === null;
function P(e) {
  const t = [];
  if (
    (e.businessName.trim() ||
      t.push({ field: "inv-business", message: "Enter your business name." }),
    e.clientName.trim() ||
      t.push({ field: "inv-client", message: "Enter the client name." }),
    e.invoiceDate ||
      t.push({ field: "inv-date", message: "Choose the invoice date." }),
    e.dueDate &&
      e.invoiceDate &&
      e.dueDate < e.invoiceDate &&
      t.push({
        field: "inv-due",
        message: "The due date can't be before the invoice date.",
      }),
    e.items.filter((i) => i.description.trim()).length === 0)
  ) {
    const i = e.items[0];
    t.push({
      field: `inv-item-${i?.id ?? "1"}-desc`,
      message: "Add at least one line item with a description.",
    });
  }
  for (const i of e.items) {
    const s = i.id ?? "1";
    if (!(i.description.trim() || i.unitPrice.trim())) continue;
    i.description.trim() ||
      t.push({
        field: `inv-item-${s}-desc`,
        message: "Describe this line item.",
      });
    const u = d(i.quantity);
    u === null
      ? t.push({
          field: `inv-item-${s}-qty`,
          message: "Enter a quantity above 0.",
        })
      : u > 0 ||
        t.push({
          field: `inv-item-${s}-qty`,
          message:
            "Quantity must be above 0. For a refund or credit, tick Credit instead.",
        });
    const p = d(i.unitPrice);
    p === null
      ? t.push({
          field: `inv-item-${s}-price`,
          message:
            i.unitPrice.trim() === ""
              ? "Enter a price."
              : "Price must be a number.",
        })
      : p < 0 &&
        !i.credit &&
        t.push({
          field: `inv-item-${s}-price`,
          message:
            "A negative price is only allowed on a credit line. Tick Credit.",
        });
  }
  const o = (i, s, r) => {
    if (D(i)) t.push({ field: s, message: `${r} must be a number.` });
    else if (i.trim() !== "") {
      const u = d(i);
      (u < 0 || u > 100) &&
        t.push({ field: s, message: `${r} must be between 0 and 100.` });
    }
  };
  (o(e.discountPct, "inv-discount", "Discount"), o(e.taxPct, "inv-tax", "Tax"));
  for (const [i, s, r] of [
    [e.shipping, "inv-shipping", "Shipping"],
    [e.paid, "inv-paid", "Amount paid"],
  ])
    D(i)
      ? t.push({ field: s, message: `${r} must be a number.` })
      : i.trim() !== "" &&
        d(i) < 0 &&
        t.push({ field: s, message: `${r} can't be negative.` });
  return t;
}
const T = { receipt: 0, net15: 15, net30: 30, net60: 60 },
  S = {
    receipt: "Due on receipt",
    net15: "Net 15",
    net30: "Net 30",
    net60: "Net 60",
  };
function q(e) {
  return e === "custom" ? "" : `Payment terms: ${S[e]}`;
}
function I(e, t) {
  const n = /^(\d{4})-(\d{2})-(\d{2})$/.exec(e);
  return n
    ? new Date(Date.UTC(+n[1], +n[2] - 1, +n[3] + t)).toISOString().slice(0, 10)
    : "";
}
function A(e) {
  const t = (e ?? "").trim();
  if (!t) return "INV-001";
  const n = /^(.*?)(\d+)(\D*)$/.exec(t);
  if (!n) return `${t}-2`;
  const o = String(BigInt(n[2]) + BigInt(1)).padStart(n[2].length, "0");
  return `${n[1]}${o}${n[3]}`;
}
export { T, I as a, P as b, E as i, A as n, c as r, q as t };
//# sourceMappingURL=invoiceCalc-DKfNuJtN.js.map
