import { d as c, f as u, p } from "./dates-DoPZ1fRV.js";
const w = [
    "Alabama",
    "Alaska",
    "Arizona",
    "Arkansas",
    "California",
    "Colorado",
    "Connecticut",
    "Delaware",
    "District of Columbia",
    "Florida",
    "Georgia",
    "Hawaii",
    "Idaho",
    "Illinois",
    "Indiana",
    "Iowa",
    "Kansas",
    "Kentucky",
    "Louisiana",
    "Maine",
    "Maryland",
    "Massachusetts",
    "Michigan",
    "Minnesota",
    "Mississippi",
    "Missouri",
    "Montana",
    "Nebraska",
    "Nevada",
    "New Hampshire",
    "New Jersey",
    "New Mexico",
    "New York",
    "North Carolina",
    "North Dakota",
    "Ohio",
    "Oklahoma",
    "Oregon",
    "Pennsylvania",
    "Rhode Island",
    "South Carolina",
    "South Dakota",
    "Tennessee",
    "Texas",
    "Utah",
    "Vermont",
    "Virginia",
    "Washington",
    "West Virginia",
    "Wisconsin",
    "Wyoming",
  ],
  y = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ],
  s = (e) => `${y[e.m - 1]} ${e.d}, ${e.y}`,
  i = (e) => {
    const t = Number(e.replace(/,/g, ""));
    return Number.isFinite(t)
      ? t.toLocaleString("en-US", {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        })
      : e;
  };
function m(e, t) {
  const n = e.y * 12 + (e.m - 1) + t,
    a = Math.floor(n / 12),
    _ = (n % 12) + 1,
    o = Math.min(e.d, c(a, _));
  return u({ y: a, m: _, d: o }, -1);
}
function v(e) {
  const t = p(e.startDate),
    n = t ? m(t, e.termMonths) : null,
    a = (o, r) => o.trim() || r,
    _ = [
      {
        paragraphs: [
          `This Lease Agreement is made on ${e.signedOn}, between ${a(e.landlord, "[Landlord Name]")} ("Landlord") and ${a(e.tenant, "[Tenant Name]")} ("Tenant") for the property located at ${a(e.address, "[Property Address]")} (the "Property").`,
        ],
      },
      {
        heading: "1. Term",
        paragraphs: [
          `The lease term begins on ${t ? s(t) : "[start date]"} and ends on ${n ? s(n) : "[end date]"} (${e.termMonths} months).`,
          e.afterTerm === "monthly"
            ? `If Tenant remains in the Property after the term ends with Landlord's consent, the tenancy continues month to month on the same terms. Either party may end a month-to-month tenancy by giving the other at least ${a(e.noticeDays, "30")} days' written notice, or any longer notice the law requires.`
            : "This lease ends on the date above and does not renew automatically. Tenant must vacate by the end date unless the parties sign a new agreement or written extension.",
        ],
      },
      {
        heading: "2. Rent",
        paragraphs: [
          `Tenant agrees to pay $${i(e.rent)} per month, due on day ${a(e.rentDueDay, "1")} of each month.`,
          e.lateFee.trim() && Number(e.lateFee) > 0
            ? `If rent is not received within ${a(e.graceDays, "5")} day(s) after it is due, Tenant shall pay a late fee of $${i(e.lateFee)}, to the extent permitted by law.`
            : "Late payments may be subject to fees only as permitted by law.",
        ],
      },
      {
        heading: "3. Security Deposit",
        paragraphs: [
          `Tenant shall pay a security deposit of $${i(e.deposit)}. Landlord will return the deposit, less any deductions permitted by law, with an itemized statement, within ${a(e.depositReturnDays, "30")} days after Tenant moves out and returns possession, or within any shorter period the law of ${a(e.state, "the state where the Property is located")} requires.`,
        ],
      },
      {
        heading: "4. Use of Property and Occupants",
        paragraphs: [
          "The Property shall be used solely as a private residence. Subletting or assigning this lease requires prior written consent from Landlord.",
          e.occupants.trim()
            ? `Persons permitted to live in the Property: ${e.occupants.trim()}.`
            : "Only Tenant and the persons named in this lease may live in the Property.",
        ],
      },
      {
        heading: "5. Utilities",
        paragraphs: [
          e.utilities.trim()
            ? e.utilities.trim()
            : "Tenant pays for all utilities and services used at the Property, except those Landlord agrees in writing to provide.",
        ],
      },
      {
        heading: "6. Pets and Smoking",
        paragraphs: [
          e.pets === "none"
            ? "No pets are allowed without Landlord's prior written consent. This does not apply to service animals or assistance animals as defined by law."
            : "Pets are allowed only with Landlord's prior written consent, which may include an additional deposit or fee as the law allows. Service animals and assistance animals are governed by law.",
          e.smoking
            ? "Smoking is permitted in the Property."
            : "Smoking is not permitted inside the Property.",
        ],
      },
      {
        heading: "7. Landlord's Entry",
        paragraphs: [
          `Landlord may enter the Property after giving at least ${a(e.entryHours, "24")} hours' notice, at reasonable times, for repairs, inspections or showings. In an emergency Landlord may enter without notice.`,
        ],
      },
      {
        heading: "8. Maintenance",
        paragraphs: [
          "Tenant agrees to keep the Property clean and in good condition and to report needed repairs promptly. Landlord is responsible for major repairs and for keeping the Property fit to live in, except damage caused by Tenant or Tenant's guests.",
        ],
      },
      {
        heading: "9. Governing Law",
        paragraphs: [
          `This Agreement is governed by the laws of ${a(e.state, "[State]")} and all applicable local landlord-tenant laws.`,
        ],
      },
    ];
  return (
    e.builtBefore1978 &&
      _.push({
        heading: "10. Lead-Based Paint Disclosure (housing built before 1978)",
        paragraphs: [
          "Lead Warning Statement: Housing built before 1978 may contain lead-based paint. Lead from paint, paint chips and dust can pose health hazards if not managed properly. Lead exposure is especially harmful to young children and pregnant women. Before renting pre-1978 housing, lessors must disclose the presence of known lead-based paint and lead-based paint hazards in the dwelling. Lessees must also receive a federally approved pamphlet on lead poisoning prevention.",
          "Landlord's disclosure (check one):  [  ] Landlord knows of lead-based paint or lead-based paint hazards in the Property (explain): ____________________   [  ] Landlord has no knowledge of lead-based paint or lead-based paint hazards in the Property.",
          "Records and reports (check one):  [  ] Landlord has given Tenant all available records and reports about lead-based paint in the Property (list): ____________________   [  ] Landlord has no such records or reports.",
          `Tenant's acknowledgment (initial):  ______ Tenant has received copies of all information listed above.   ______ Tenant has received the pamphlet "Protect Your Family From Lead in Your Home."`,
          "Certification of accuracy: The parties have reviewed the information above and certify, to the best of their knowledge, that it is true and accurate.",
          "Landlord: _________________________  Date: _____________",
          "Tenant: _________________________  Date: _____________",
        ],
      }),
    _.push({
      heading: "Signatures",
      paragraphs: [
        "Landlord: _________________________  Date: _____________",
        "Tenant: _________________________  Date: _____________",
      ],
    }),
    _
  );
}
function $(e) {
  const t = (o, r) => o.trim() || r,
    n = p(e.expiration),
    a = e.durable
      ? "This Power of Attorney shall not be affected by my later disability or incapacity. It remains effective even if I become incapacitated."
      : "This Power of Attorney is not durable: it ends if I become incapacitated.",
    _ =
      e.springing && e.durable
        ? 'This Power of Attorney becomes effective only if I become incapacitated, as certified in writing by my attending physician or by two licensed physicians (a "springing" power). Until then my Agent has no authority under it.'
        : `This Power of Attorney is effective immediately on ${e.signedOn}.`;
  return [
    {
      paragraphs: [
        `I, ${t(e.principal, "[Principal Name]")} ("Principal"), residing in ${t(e.state, "[State]")}, appoint ${t(e.agent, "[Agent Name]")} ("Agent") as my attorney-in-fact.${e.alternateAgent.trim() ? ` If my Agent is unable or unwilling to act, I appoint ${e.alternateAgent.trim()} as my alternate Agent.` : ""}`,
      ],
    },
    {
      heading: "1. Grant of Authority",
      paragraphs: [
        `I grant my Agent authority to act for me in connection with the following matters: ${t(e.powers, "[powers]")}. This authority includes the power to sign documents, endorse and deposit checks, and take any action I could take personally for these matters.`,
      ],
    },
    { heading: "2. Durability and When It Takes Effect", paragraphs: [a, _] },
    {
      heading: "3. Duration",
      paragraphs: [
        n
          ? `This Power of Attorney ends on ${s(n)}, unless I revoke it earlier in writing.`
          : `This Power of Attorney continues until I revoke it in writing or until my death${e.durable ? "" : " or incapacity"}.`,
      ],
    },
    {
      heading: "4. Agent's Duties",
      paragraphs: [
        "My Agent must act in my best interest, keep my property separate from the Agent's own, keep records of all transactions made for me, and not make gifts or change beneficiaries unless this document expressly allows it.",
      ],
    },
    {
      heading: "5. Revocation",
      paragraphs: [
        "I may revoke this Power of Attorney at any time by written notice to my Agent and to any institution that has relied on it.",
      ],
    },
    {
      heading: "6. Governing Law",
      paragraphs: [
        `This document is governed by the laws of ${t(e.state, "[State]")}. Execution requirements (notarization, witnesses, statutory wording) vary by state.`,
      ],
    },
    {
      heading: "Signature of Principal",
      paragraphs: [
        `Signed on ${e.signedOn}.`,
        "Principal: _________________________  Date: _____________",
      ],
    },
    {
      heading: "Agent's Acceptance",
      paragraphs: [
        "I accept this appointment and agree to act as Agent in the Principal's best interest.",
        "Agent: _________________________  Date: _____________",
      ],
    },
    {
      heading: "Witnesses (if required by your state)",
      paragraphs: [
        "Witness 1: ________________________  Date: ____________",
        "Printed name: ________________________",
        "Witness 2: ________________________  Date: ____________",
        "Printed name: ________________________",
      ],
    },
    {
      heading: "Notary Acknowledgment",
      paragraphs: [
        "State of ____________________     County of ____________________",
        "On this ______ day of ________________, 20____, before me, the undersigned notary public, personally appeared ______________________________, known to me or satisfactorily proven to be the person whose name is signed on this document, and acknowledged that he or she signed it voluntarily for its stated purpose.",
        "Notary Public: _________________________   My commission expires: _____________   (Seal)",
      ],
    },
  ];
}
const d = {
    California: { days: 3, note: "excluding weekends and court holidays" },
    Texas: {
      days: 3,
      note: "notice to vacate, unless the lease sets a different period",
    },
    Florida: { days: 3, note: "excluding weekends and legal holidays" },
    "New York": { days: 14, note: "" },
    Washington: { days: 14, note: "" },
    Ohio: { days: 3, note: "" },
  },
  g = (e) => `${e} day${e === 1 ? "" : "s"}`;
function f(e, t) {
  return t !== "pay-or-quit" ? null : (d[e] ?? null);
}
function T() {
  return Object.keys(d);
}
function P(e, t, n) {
  if (!Number.isFinite(n) || n < 1 || !Number.isInteger(n))
    return "Enter a whole number of days (1 or more).";
  const a = f(e, t);
  return a && n < a.days
    ? `${e} requires at least ${a.days} days for a pay-or-quit notice${a.note ? ` (${a.note})` : ""}. A shorter notice can get your case dismissed.`
    : null;
}
const l = [
  {
    value: "pay-or-quit",
    label: "Pay Rent or Quit",
    text: "You are in default for failure to pay rent.",
  },
  {
    value: "cure-or-quit",
    label: "Cure or Quit (lease violation)",
    text: "You are in violation of the terms of your lease agreement.",
  },
  {
    value: "unconditional-quit",
    label: "Unconditional Quit (no cure option)",
    text: "Your tenancy is being terminated.",
  },
];
function A(e) {
  const t = l.find((r) => r.value === e.type) ?? l[0],
    n = (r, h) => r.trim() || h,
    a = e.state ? (d[e.state]?.note ?? "") : "",
    _ = e.type === "pay-or-quit" && a ? ` (${a})` : "",
    o = g(e.days);
  return [
    {
      paragraphs: [
        `To: ${n(e.tenant, "[Tenant Name]")}`,
        `Property Address: ${n(e.address, "[Property Address]")}`,
        `From: ${n(e.landlord, "[Landlord Name]")}`,
        `Date: ${e.dateText}`,
      ],
    },
    {
      heading: t.label.toUpperCase(),
      paragraphs: [
        t.text,
        ...(e.type === "cure-or-quit" && e.violation.trim()
          ? [`The violation is: ${e.violation.trim()}`]
          : []),
        e.type === "pay-or-quit"
          ? `The amount currently owed is $${i(n(e.amountOwed, "0"))}. You have ${o}${_} from receipt of this notice to pay the amount owed in full or vacate the premises. The last day to comply is: ____________________ (fill in after the notice is served).`
          : e.type === "cure-or-quit"
            ? `You have ${o} from receipt of this notice to correct this violation or vacate the premises. The last day to comply is: ____________________ (fill in after the notice is served).`
            : `You are required to vacate the premises within ${o} of receipt of this notice. The last day to vacate is: ____________________ (fill in after the notice is served).`,
      ],
    },
    {
      heading: "Consequences of Non-Compliance",
      paragraphs: [
        "If you do not comply within the stated period, legal proceedings to recover possession of the property may be started against you, which may include additional costs and fees as permitted by law.",
      ],
    },
    {
      heading: "Signature",
      paragraphs: [
        "Landlord/Agent: _________________________  Date: _____________",
      ],
    },
    {
      heading: "Proof of Service",
      paragraphs: [
        "I served this notice on the tenant named above as follows (check one):",
        "[  ] Delivered to the tenant in person      [  ] Left with a person of suitable age at the property      [  ] Posted at the property and mailed      [  ] Sent by certified mail",
        "Date served: _______________   Time: ___________   Served by (printed name): ______________________",
        "Signature of person serving: _________________________",
      ],
    },
  ];
}
function k(e = new Date()) {
  const t = (n) => String(n).padStart(2, "0");
  return `${e.getFullYear()}-${t(e.getMonth() + 1)}-${t(e.getDate())}`;
}
export {
  l as N,
  w as U,
  m as a,
  v as b,
  $ as c,
  A as d,
  s as l,
  f as m,
  P as n,
  T as s,
  k as t,
};
//# sourceMappingURL=legalClauses-DgeuUksw.js.map
