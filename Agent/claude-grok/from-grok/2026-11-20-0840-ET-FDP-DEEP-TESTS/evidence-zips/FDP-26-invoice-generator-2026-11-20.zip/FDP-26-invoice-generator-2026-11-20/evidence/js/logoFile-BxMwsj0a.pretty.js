import { aS as f, aT as w } from "./index-B1CTyGtY.js";
function m(a) {
  const e = /^data:([\w/+.-]+);base64,(.*)$/.exec(a);
  if (!e) return null;
  try {
    const h = atob(e[2]),
      g = new Uint8Array(h.length);
    for (let t = 0; t < h.length; t++) g[t] = h.charCodeAt(t);
    return {
      bytes: g,
      type:
        e[1] === "image/png" ? "png" : e[1] === "image/jpeg" ? "jpg" : "other",
      mime: e[1],
    };
  } catch {
    return null;
  }
}
async function y(a, e = 800, h = "image/png") {
  if (!/^image\//.test(a.type) && !/\.(png|jpe?g|webp|gif|svg)$/i.test(a.name))
    throw new Error("Choose an image file (PNG, JPEG, WebP, GIF or SVG).");
  if (a.size > 12e6)
    throw new Error("That image is too large. Choose one under 12 MB.");
  const g = URL.createObjectURL(a);
  try {
    const t = new Image();
    ((t.decoding = "async"),
      await new Promise((u, d) => {
        ((t.onload = () => u()),
          (t.onerror = () => d(new Error("That image could not be read."))),
          (t.src = g));
      }));
    const r = t.naturalWidth || 300,
      o = t.naturalHeight || 300,
      i = Math.min(1, e / Math.max(r, o)),
      n = document.createElement("canvas");
    ((n.width = Math.max(1, Math.round(r * i))),
      (n.height = Math.max(1, Math.round(o * i))));
    const l = n.getContext("2d");
    (h === "image/jpeg" &&
      ((l.fillStyle = "#ffffff"), l.fillRect(0, 0, n.width, n.height)),
      l.drawImage(t, 0, 0, n.width, n.height));
    let c =
      h === "image/jpeg"
        ? n.toDataURL("image/jpeg", 0.88)
        : n.toDataURL("image/png");
    c.length > f * 1.3 && (c = n.toDataURL("image/jpeg", 0.85));
    const s = w(c);
    if (!s)
      throw new Error(
        "That image is too large to keep in a profile. Try a smaller one.",
      );
    return s;
  } finally {
    URL.revokeObjectURL(g);
  }
}
async function b(a) {
  if (!a) return null;
  let e = m(a);
  if (!e) return null;
  const h = async (r) =>
    new Promise((o) => {
      if (typeof Image > "u") {
        o({ width: 1, height: 1 });
        return;
      }
      const i = new Image();
      ((i.onload = () =>
        o({ width: i.naturalWidth || 1, height: i.naturalHeight || 1 })),
        (i.onerror = () => o({ width: 1, height: 1 })),
        (i.src = r));
    });
  let g = a;
  if (e.type === "other") {
    if (typeof document > "u") return null;
    const r = new Image();
    try {
      await new Promise((i, n) => {
        ((r.onload = () => i()),
          (r.onerror = () => n(new Error("x"))),
          (r.src = a));
      });
    } catch {
      return null;
    }
    const o = document.createElement("canvas");
    if (
      ((o.width = r.naturalWidth || 300),
      (o.height = r.naturalHeight || 300),
      o.getContext("2d").drawImage(r, 0, 0),
      (g = o.toDataURL("image/png")),
      (e = m(g)),
      !e)
    )
      return null;
  }
  const t = await h(g);
  return { bytes: e.bytes, type: e.type === "jpg" ? "jpg" : "png", ...t };
}
export { b as a, m as d, y as l };
//# sourceMappingURL=logoFile-BxMwsj0a.js.map
