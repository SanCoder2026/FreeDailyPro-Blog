const t = [
  { code: "USD", label: "$ US dollar" },
  { code: "EUR", label: "€ Euro" },
  { code: "GBP", label: "£ Pound" },
  { code: "INR", label: "₹ Rupee" },
  { code: "CAD", label: "C$ Canadian dollar" },
  { code: "AUD", label: "A$ Australian dollar" },
  { code: "JPY", label: "¥ Yen" },
  { code: "SGD", label: "S$ Singapore dollar" },
  { code: "AED", label: "AED Dirham" },
  { code: "ZAR", label: "R Rand" },
];
function r(e) {
  try {
    return (
      new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: e,
      }).resolvedOptions().maximumFractionDigits ?? 2
    );
  } catch {
    return 2;
  }
}
function n(e, a = "USD", l = r(a)) {
  if (!Number.isFinite(e)) return "—";
  const o = a === "INR" ? "en-IN" : "en-US";
  try {
    return new Intl.NumberFormat(o, {
      style: "currency",
      currency: a,
      minimumFractionDigits: l,
      maximumFractionDigits: l,
    }).format(e);
  } catch {
    return e.toFixed(l);
  }
}
export { t as C, r as c, n as f };
//# sourceMappingURL=money-Dkxewa8a.js.map
