function m(e) {
  e = e
    .trim()
    .replace(/^([-+−]?)\s*[$€£¥₹]\s*/, "$1")
    .replace(/\s*[%$€£¥₹]$/, "");
  let t = e.trim().replace(/[\s_  ']/g, "");
  if (!t) return null;
  let u = 1;
  if (
    (t.startsWith("-") || t.startsWith("−")
      ? ((u = -1), (t = t.slice(1)))
      : t.startsWith("+") && (t = t.slice(1)),
    !/^[\d.,]+$/.test(t) || !/\d/.test(t))
  )
    return null;
  const r = t.lastIndexOf("."),
    l = t.lastIndexOf(",");
  let n;
  if (r >= 0 && l >= 0) {
    const i = r > l ? "." : ",",
      s = i === "." ? "," : ".";
    if (t.split(i).length > 2) return null;
    n = t.split(s).join("").replace(i, ".");
  } else if (l >= 0 || r >= 0) {
    const i = l >= 0 ? "," : ".",
      s = t.split(i),
      a =
        /^\d{1,3}$/.test(s[0]) &&
        s
          .slice(1)
          .every((c, f, p) =>
            f === p.length - 1 ? /^\d{3}$/.test(c) : /^\d{2,3}$/.test(c),
          );
    if (s.length > 2) {
      if (!a) return null;
      n = s.join("");
    } else a && i === "," ? (n = s.join("")) : (n = s.join("."));
  } else n = t;
  const o = Number(n);
  return Number.isFinite(o) ? u * o : null;
}
function d(e, t = 6) {
  return Number.isFinite(e)
    ? e.toLocaleString("en-US", { maximumFractionDigits: t })
    : "—";
}
function g(e) {
  const t = m(String(e ?? ""));
  return t === null ? NaN : t;
}
export { g as a, d as f, m as p };
//# sourceMappingURL=numberInput-5hjoxJ5z.js.map
