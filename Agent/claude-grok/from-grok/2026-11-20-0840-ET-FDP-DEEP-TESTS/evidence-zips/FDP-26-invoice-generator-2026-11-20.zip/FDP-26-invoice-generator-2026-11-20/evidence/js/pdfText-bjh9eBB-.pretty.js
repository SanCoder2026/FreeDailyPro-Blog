import { u as m } from "./index-BRvxULIc.js";
import { P as d, r as g } from "./pdfFonts-Ckcqm3Ic.js";
class w {
  constructor(s, e = []) {
    ((this.set = s), (this.emoji = e));
  }
  static async create(s, e, t, i = null) {
    const n =
      t === void 0
        ? new d(s, void 0, void 0, null, i)
        : new d(s, void 0, t, null, i);
    return (await n.prepare(e), n.scan(e), new w(n, j(e, n)));
  }
  width(s, e, t = !1) {
    return this.set.width(s, e, "sans", t);
  }
  draw(s, e, t) {
    let i = t.x;
    for (const n of this.set.runs(e, "sans", t.bold ?? !1))
      (this.set.drawRun(s, n, {
        x: i,
        y: t.y,
        size: t.size,
        color: t.color ?? m(0.1, 0.1, 0.1),
      }),
        (i += n.font.widthOfTextAtSize(n.text, t.size)));
  }
  drawRight(s, e, t) {
    this.draw(s, e, {
      x: t.rightX - this.width(e, t.size, t.bold),
      y: t.y,
      size: t.size,
      bold: t.bold,
      color: t.color,
    });
  }
  wrap(s, e, t, i = !1) {
    const n = (h) => this.width(h, e, i),
      a = [];
    for (const h of s.split(/\r?\n/)) {
      const p = h.split(/\s+/).filter(Boolean);
      let o = "";
      for (const l of p) {
        const u = o ? `${o} ${l}` : l;
        if (n(u) <= t) {
          o = u;
          continue;
        }
        if ((o && a.push(o), n(l) > t)) {
          let r = "";
          for (const f of l)
            n(r + f) > t && r ? (a.push(r), (r = f)) : (r += f);
          o = r;
        } else o = l;
      }
      a.push(o);
    }
    return a.length ? a : [""];
  }
  async finish() {
    await this.set.flushRasters();
  }
  note() {
    const s = g(this.set),
      e = z(this.emoji);
    return [s, e].filter(Boolean).join(" ") || null;
  }
}
const y = new RegExp("\\p{Extended_Pictographic}", "u");
function j(c, s) {
  const e = new Set();
  for (const t of c) y.test(t) && !(s && s.canDraw(t)) && e.add(t);
  return Array.from(e);
}
function z(c) {
  return c.length === 0
    ? null
    : `Emoji (${c.slice(0, 5).join(" ")}${c.length > 5 ? " …" : ""}) may not show in the PDF because PDF fonts have no emoji. Remove them or use the Word file if they matter.`;
}
export { w as T };
//# sourceMappingURL=pdfText-bjh9eBB-.js.map
