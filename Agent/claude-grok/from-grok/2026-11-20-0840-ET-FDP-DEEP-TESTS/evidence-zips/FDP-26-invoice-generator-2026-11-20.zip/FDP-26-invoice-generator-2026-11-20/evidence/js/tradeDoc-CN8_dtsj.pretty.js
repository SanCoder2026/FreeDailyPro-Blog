import { p as m } from "./numberInput-5hjoxJ5z.js";
import { c as b } from "./money-Dkxewa8a.js";
import { i as y, r as h } from "./invoiceCalc-DKfNuJtN.js";
function q(t) {
  const n = (typeof navigator < "u" ? navigator.language : "") ?? "",
    e = /[-_]([A-Za-z]{2})\b/.exec(n)?.[1]?.toUpperCase();
  return e
    ? ["US", "CA", "MX", "PH"].includes(e)
      ? "letter"
      : "a4"
    : "letter";
}
const o = (t) => {
    const n = Number(String(t).replace(/,/g, ""));
    return Number.isFinite(n) ? n : 0;
  },
  P = (t) => t !== "packing-slip";
function x(t) {
  return Math.max(0, h(o(t)));
}
function L(t) {
  const n = t.currency ? b(t.currency) : 2,
    e = y(t.items, t.discountPct, t.taxPct);
  if (n === 2) {
    const r = x(t.shipping);
    return { ...e, shipping: r, total: h(e.total + r) };
  }
  const a = 10 ** n,
    i = (r) => Math.round((r + Number.EPSILON) * a) / a,
    u = e.lines.map((r) => ({ ...r, amount: i(r.qty * r.price) })),
    s = i(u.reduce((r, p) => r + p.amount, 0)),
    g = Math.min(100, Math.max(0, o(t.discountPct))),
    l = i((s * g) / 100),
    c = i(s - l),
    d = i((c * Math.max(0, o(t.taxPct))) / 100),
    f = Math.max(0, i(o(t.shipping)));
  return {
    lines: u,
    subtotal: s,
    discount: l,
    taxable: c,
    tax: d,
    shipping: f,
    total: i(c + d + f),
  };
}
function w(t) {
  const [n, e] = t.parties;
  if (!n?.name.trim())
    return "Please fill in your name or company in the first box.";
  if (!e?.name.trim())
    return "Please fill in the other party's name in the second box.";
  const a = t.items.filter((i) => i.description.trim());
  if (a.length === 0) return "Add at least one line with a description.";
  if (a.some((i) => !(o(i.quantity) > 0)))
    return "Every line needs a quantity above 0.";
  if (P(t.kind)) {
    const i = v(t.items);
    if (i) return `Line ${i} has a negative price. Prices must be 0 or more.`;
    const u = N(t.items);
    if (u) return `Line ${u} has a price that is not a number.`;
    if (a.some((s) => s.unitPrice.trim() === ""))
      return "Every line needs a price (0 or more).";
  }
  return null;
}
function v(t) {
  const n = t.findIndex((e) => e.unitPrice.trim() !== "" && o(e.unitPrice) < 0);
  return n >= 0 ? n + 1 : null;
}
function C(t, n) {
  return !/^\d{4}-\d{2}-\d{2}$/.test(t) || !/^\d{4}-\d{2}-\d{2}$/.test(n)
    ? null
    : n < t
      ? "The delivery date is before the order date. Check that it is right."
      : null;
}
function k(t, n) {
  const e = new Date(`${t}T00:00:00Z`);
  return Number.isNaN(e.getTime())
    ? t
    : (e.setUTCDate(e.getUTCDate() + n), e.toISOString().slice(0, 10));
}
function A(t) {
  return t
    .filter((n) => n.description.trim())
    .reduce((n, e) => n + Math.max(0, o(e.quantity)), 0);
}
function D(t, n) {
  return `${
    t
      .trim()
      .replace(/[\\/:*?"<>|\u0000-\u001f\s]+/g, "-")
      .replace(/^-+|-+$/g, "") || n
  }.pdf`;
}
function I(t) {
  for (let n = 0; n < t.length; n++) {
    const e = t[n];
    if (!(!e.description.trim() && !e.unitPrice.trim()) && !(o(e.quantity) > 0))
      return n + 1;
  }
  return null;
}
function S(t) {
  const n = t.trim();
  if (!n) return null;
  const e = m(n.replace(/[%]/g, ""));
  return e === null
    ? "Discount must be a number between 0 and 100."
    : e < 0 || e > 100
      ? "Discount must be between 0 and 100 per cent. A discount over 100% would give a negative order."
      : null;
}
function N(t) {
  for (let n = 0; n < t.length; n++) {
    const e = t[n].unitPrice.trim();
    if (e && m(e.replace(/[$€£¥₹%]/g, "")) === null) return n + 1;
  }
  return null;
}
function U(t, n) {
  return !/^\d{4}-\d{2}-\d{2}$/.test(t) || !/^\d{4}-\d{2}-\d{2}$/.test(n)
    ? null
    : n < t
      ? "The valid-until date is before the quote date, so the quote would already be expired. Check that it is right."
      : null;
}
function E(t) {
  for (let n = 0; n < t.length; n++) {
    const e = t[n];
    if (!e.description.trim()) continue;
    const a = o(e.quantity);
    if (a > 0 && !Number.isInteger(a)) return n + 1;
  }
  return null;
}
export {
  A as a,
  k as b,
  I as c,
  q as d,
  S as e,
  N as f,
  E as g,
  C as h,
  P as i,
  w as j,
  D as k,
  v as n,
  L as t,
  U as v,
};
//# sourceMappingURL=tradeDoc-CN8_dtsj.js.map
