const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/BmiExtras-Fs-a8-UB.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/index-B1CTyGtY.js",
      "assets/index-BJxTAPRn.css",
      "assets/CalcSteps-CMhW1YVy.js",
      "assets/ResultsTable-CpxaKI_z.js",
      "assets/history-B6kbrtr3.js",
      "assets/csv-DBvSFDe9.js",
      "assets/copy-DcUvE8ta.js",
      "assets/share-2-B4TSO3Yd.js",
      "assets/CalcHistory-B9VfOON0.js",
      "assets/steps-X1Sejec4.js",
      "assets/table-CJAX3ymv.js",
      "assets/numberInput-5hjoxJ5z.js",
      "assets/ToolPage-DwLoDncN.js",
      "assets/useUploadApi-cn-OKK9Q.js",
      "assets/cloudStorage-BzUdFuQl.js",
      "assets/camera-8PGplCT5.js",
      "assets/workflowCta-WWwB7oO9.js",
      "assets/UsageAndUpgradeStrip-B1CY210m.js",
      "assets/access-BB4298M0.js",
      "assets/useAdminAccess-CRDzdxJU.js",
      "assets/tool-name-translations-d1j9ms8v.js",
      "assets/InstallToolButton-CQjOKKQY.js",
      "assets/map-pin-Dp16LrFV.js",
      "assets/FaqSection-C8274byc.js",
      "assets/ToolVideoEmbed-CCFWLqkW.js",
      "assets/GuideLinks-CJoJwps-.js",
      "assets/blog-8brHQns7.js",
      "assets/info-B8t_e6MS.js",
      "assets/productCards-BBBZlV20.js",
      "assets/layers-Dw7RJFNV.js",
      "assets/usePwaManifest-D8HDEEPW.js",
      "assets/MeasureField-DjJ0Relq.js",
      "assets/ToolInfoSection-C0i6Zbwo.js",
      "assets/CollapsibleText-BCSBEG9-.js",
      "assets/chevron-up-BDUcPssj.js",
      "assets/useLogToolUsage-BdvvKW0n.js",
      "assets/copyText-DPnES92p.js",
    ]),
) => i.map((i) => d[i]);
import { e as $, I as D, ap as G } from "./index-B1CTyGtY.js";
import { r as u, j as o } from "./vendor-react-D01g8YgM.js";
import { p as V } from "./numberInput-5hjoxJ5z.js";
import { T as z } from "./ToolPage-DwLoDncN.js";
import { U as K, M as j } from "./MeasureField-DjJ0Relq.js";
import { T as Q } from "./ToolInfoSection-C0i6Zbwo.js";
import { u as Y } from "./useLogToolUsage-BdvvKW0n.js";
const q = { under: 18.5, over: 25, obese: 30 },
  X = { under: 18.5, over: 23, obese: 27.5 },
  I = (e, t) => e / (t / 100) ** 2,
  N = (e) => Math.round(e * 10) / 10,
  k = (e) => (e ? X : q);
function A(e, t) {
  const i = k(t);
  return e < i.under
    ? "Underweight"
    : e < i.over
      ? "Normal"
      : e < i.obese
        ? "Overweight"
        : "Obese";
}
const J = (e) => (e ? 22.9 : 24.9);
function T(e, t) {
  const i = (e / 100) ** 2;
  return { lo: 18.5 * i, hi: J(t) * i };
}
function Z(e, t, i) {
  const a = A(N(I(e, t)), i),
    { lo: s, hi: n } = T(t, i);
  return a === "Underweight"
    ? s - e
    : a === "Overweight" || a === "Obese"
      ? n - e
      : 0;
}
function ee(e, t) {
  return t.trim() === ""
    ? { kind: "none" }
    : e == null ||
        !Number.isFinite(e) ||
        e < 0 ||
        e > 120 ||
        Math.floor(e) !== e
      ? {
          kind: "invalid",
          message: "Enter a whole age between 0 and 120, or leave it empty.",
        }
      : e < 2
        ? {
            kind: "child",
            message:
              "BMI is not used for children under 2. Ask your child's doctor to check growth with weight-for-length charts.",
          }
        : e < 20
          ? {
              kind: "child",
              message:
                "Adult BMI categories do not apply under age 20. For ages 2 to 19, BMI is read as a percentile for age and sex on the CDC growth charts. Ask your child's doctor or use the CDC child BMI percentile tool.",
            }
          : { kind: "adult" };
}
function te(e, t) {
  const i = e / t,
    a = Math.round(i * 100) / 100,
    s = a < 0.4 ? "low" : a < 0.5 ? "below" : a < 0.6 ? "above" : "high";
  return {
    ratio: a,
    band: s,
    note:
      s === "low"
        ? "Below 0.4. This is lower than typical; if you are unsure why, ask a doctor."
        : s === "below"
          ? "Below the 0.5 guideline (keep your waist under half your height)."
          : s === "above"
            ? "At or above the 0.5 guideline. A waist over half your height is linked with more health risk."
            : "0.6 or more, well above the 0.5 guideline. Consider talking to a doctor.",
    halfHeightCm: t / 2,
  };
}
const C = 15,
  oe = 40,
  M = (e) => Math.min(1, Math.max(0, (e - C) / (oe - C)));
function ie(e) {
  const t = k(e),
    i = (a) => M(a);
  return [
    { label: "Underweight", from: 0, to: i(t.under) },
    { label: "Normal", from: i(t.under), to: i(t.over) },
    { label: "Overweight", from: i(t.over), to: i(t.obese) },
    { label: "Obese", from: i(t.obese), to: 1 },
  ];
}
const ae = (e) => Math.round((e / 25) * 100) / 100,
  se = (e, t) => Math.round((e / (t / 100) ** 3) * 10) / 10,
  O = [
    { id: 1, label: "Severe thinness", from: 0, to: 16, range: "below 16" },
    {
      id: 2,
      label: "Moderate thinness",
      from: 16,
      to: 17,
      range: "16 to 16.99",
    },
    { id: 3, label: "Mild thinness", from: 17, to: 18.5, range: "17 to 18.49" },
    {
      id: 4,
      label: "Normal range",
      from: 18.5,
      to: 25,
      range: "18.5 to 24.99",
    },
    {
      id: 5,
      label: "Pre-obese (overweight)",
      from: 25,
      to: 30,
      range: "25 to 29.99",
    },
    { id: 6, label: "Obese class I", from: 30, to: 35, range: "30 to 34.99" },
    { id: 7, label: "Obese class II", from: 35, to: 40, range: "35 to 39.99" },
    {
      id: 8,
      label: "Obese class III",
      from: 40,
      to: null,
      range: "40 and above",
    },
  ];
function ne(e) {
  return O.find((t) => e >= t.from && (t.to === null || e < t.to)) ?? O[0];
}
function ye(e, t, i) {
  if (!(i >= 10 && i <= 60) || !Number.isFinite(i))
    return { ok: !1, message: "Enter a target BMI between 10 and 60." };
  const a = i * (t / 100) ** 2;
  return { ok: !0, targetKg: a, deltaKg: a - e };
}
function je(e, t, i = (a) => `${a.toFixed(1)} kg`) {
  const a = I(e, t),
    s = N(a),
    n = ne(s);
  return [
    {
      label: "Height in metres",
      formula: "height in cm / 100",
      inputs: { cm: +t.toFixed(2) },
      result: +(t / 100).toFixed(4),
    },
    {
      label: "BMI",
      formula: "weight in kg / (height in m)^2",
      inputs: { weight: i(e), height: `${+(t / 100).toFixed(4)} m` },
      result: s.toFixed(1),
    },
    {
      label: "BMI Prime",
      formula: "BMI / 25",
      inputs: { BMI: s.toFixed(1) },
      result: ae(a).toFixed(2),
    },
    {
      label: "Ponderal Index",
      formula: "weight in kg / (height in m)^3",
      inputs: { weight: i(e), height: `${+(t / 100).toFixed(4)} m` },
      result: `${se(e, t).toFixed(1)} kg/m3`,
    },
    {
      label: "WHO class",
      formula: "the WHO adult BMI table row that contains the BMI",
      inputs: { BMI: s.toFixed(1) },
      result: `${n.label} (${n.range})`,
    },
  ];
}
function re(e) {
  const t = new URLSearchParams(e),
    i = (a, s, n) => {
      const d = t.get(a);
      if (d === null || !/^\d{1,3}(\.\d{1,2})?$/.test(d)) return null;
      const l = Number(d);
      return l >= s && l <= n ? l : null;
    };
  return {
    weight: i("kg", 30, 300),
    height: i("cm", 100, 250),
    units: t.get("u") === "imperial" ? "imperial" : "metric",
  };
}
function le(e, t, i) {
  const a = new URLSearchParams();
  return (
    e !== null && e !== 70 && a.set("kg", String(Math.round(e * 100) / 100)),
    t !== null && t !== 170 && a.set("cm", String(Math.round(t * 100) / 100)),
    i === "imperial" && a.set("u", "imperial"),
    a.toString()
  );
}
const de = u.lazy(() =>
    G(
      () => import("./BmiExtras-Fs-a8-UB.js"),
      __vite__mapDeps([
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
        20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37,
        38,
      ]),
    ),
  ),
  v = {
    what: "Calculates Body Mass Index (BMI) from your height and weight — one general, widely-used (though imperfect) health screening measure. Accepts either metric (kg/cm) or imperial (lb/ft+in) units. For daily calorie needs specifically, use the separate Calorie Calculator tool.",
    how: "Choose your preferred units, enter your height and weight, and your BMI and category are calculated automatically. Age, sex and waist are optional: under age 20 adult categories are hidden, the Asian cut-offs option moves the overweight and obese lines to 23 and 27.5, and a waist measurement adds a waist-to-height ratio.",
    tip: "BMI doesn't distinguish between muscle and fat, so it can be misleading for very muscular individuals or older adults with reduced muscle mass — it's a useful general screening number, not a complete picture of health on its own.",
  },
  ce = "border rounded px-2 py-2 w-full bg-background text-sm",
  _ = {
    Underweight: { text: "text-blue-500", fill: "#3b82f6" },
    Normal: { text: "text-green-500", fill: "#22c55e" },
    Overweight: { text: "text-yellow-500", fill: "#eab308" },
    Obese: { text: "text-red-500", fill: "#ef4444" },
  };
function ue({ bmi: e, asian: t, category: i }) {
  const a = ie(t),
    s = k(t),
    n = 300,
    d = (r) => r * n,
    l = d(M(e)),
    f = `BMI gauge from 15 to 40. Cut-offs at ${s.under}, ${s.over} and ${s.obese}. Your BMI is ${e.toFixed(1)}, in the ${i} range.`;
  return o.jsxs("figure", {
    className: "mt-4",
    "data-testid": "bmi-gauge",
    children: [
      o.jsxs("svg", {
        viewBox: `0 0 ${n} 46`,
        role: "img",
        "aria-label": f,
        className: "w-full max-w-xs mx-auto",
        children: [
          a.map((r) =>
            o.jsx(
              "rect",
              {
                x: d(r.from),
                y: 18,
                width: Math.max(0, d(r.to) - d(r.from)),
                height: 12,
                fill: _[r.label].fill,
                opacity: 0.85,
              },
              r.label,
            ),
          ),
          o.jsx("polygon", {
            points: `${l - 6},4 ${l + 6},4 ${l},16`,
            fill: "currentColor",
          }),
          o.jsx("line", {
            x1: l,
            y1: 16,
            x2: l,
            y2: 32,
            stroke: "currentColor",
            strokeWidth: 2,
          }),
          [s.under, s.over, s.obese].map((r) =>
            o.jsx(
              "text",
              {
                x: d(M(r)),
                y: 43,
                fontSize: 8,
                textAnchor: "middle",
                fill: "currentColor",
                children: r,
              },
              r,
            ),
          ),
        ],
      }),
      o.jsx("figcaption", { className: "sr-only", children: f }),
    ],
  });
}
function he() {
  const [e] = u.useState(() =>
      typeof window > "u"
        ? { weight: null, height: null, units: "metric" }
        : re(window.location.search),
    ),
    [t, i] = u.useState(e.units),
    [a, s] = u.useState(e.weight ?? 70),
    [n, d] = u.useState(e.height ?? 170);
  u.useEffect(() => {
    try {
      const c = le(a, n, t);
      window.history.replaceState(
        null,
        "",
        `${window.location.pathname}${c ? `?${c}` : ""}${window.location.hash}`,
      );
    } catch {}
  }, [a, n, t]);
  const [l, f] = u.useState(null),
    [r, U] = u.useState(""),
    [S, W] = u.useState(""),
    [g, E] = u.useState(!1),
    h = a != null && n != null,
    H = h ? I(a, n) : 0,
    p = N(H),
    m = ee(V(r), r),
    x = m.kind === "child",
    w = A(p, g),
    F = _[w].text,
    { lo: P, hi: L } = h ? T(n, g) : { lo: 0, hi: 0 },
    B = (c) =>
      t === "metric"
        ? `${c.toFixed(1)} kg`
        : `${(c / 0.45359237).toFixed(0)} lb`,
    b = h && !x ? Z(a, n, g) : 0,
    y = h && l != null ? te(l, n) : null,
    { gate: R } = Y(h);
  return o.jsxs(z, {
    children: [
      o.jsx(K, { units: t, onChange: i }),
      o.jsxs("div", {
        className: "grid grid-cols-1 md:grid-cols-2 gap-8",
        children: [
          o.jsxs("div", {
            className: "space-y-4",
            children: [
              o.jsx(j, {
                label: "Weight",
                kind: "weight",
                units: t,
                initialMetric: e.weight ?? 70,
                onValue: s,
              }),
              o.jsx(j, {
                label: "Height",
                kind: "height",
                units: t,
                initialMetric: e.height ?? 170,
                onValue: d,
              }),
              t === "metric" &&
                o.jsx("p", {
                  className: "text-xs text-muted-foreground",
                  children: `Quick reference: 5'0" ≈ 152 cm · 5'4" ≈ 163 cm · 5'7" ≈ 170 cm · 5'8" ≈ 173 cm · 5'11" ≈ 180 cm · 6'2" ≈ 188 cm`,
                }),
              o.jsxs("div", {
                className: "grid grid-cols-2 gap-3",
                children: [
                  o.jsxs("div", {
                    children: [
                      o.jsx($, {
                        htmlFor: "bmi-age",
                        children: "Age (optional)",
                      }),
                      o.jsx(D, {
                        id: "bmi-age",
                        inputMode: "numeric",
                        "aria-label": "Age",
                        "aria-invalid": m.kind === "invalid" ? !0 : void 0,
                        value: r,
                        onChange: (c) => U(c.target.value),
                      }),
                      m.kind === "invalid" &&
                        o.jsx("p", {
                          role: "alert",
                          className: "text-xs text-destructive mt-1",
                          children: m.message,
                        }),
                    ],
                  }),
                  o.jsxs("div", {
                    children: [
                      o.jsx($, {
                        htmlFor: "bmi-sex",
                        children: "Sex (optional)",
                      }),
                      o.jsxs("select", {
                        id: "bmi-sex",
                        className: ce,
                        value: S,
                        onChange: (c) => W(c.target.value),
                        children: [
                          o.jsx("option", {
                            value: "",
                            children: "Prefer not to say",
                          }),
                          o.jsx("option", {
                            value: "female",
                            children: "Female",
                          }),
                          o.jsx("option", { value: "male", children: "Male" }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              o.jsx(j, {
                label: "Waist (optional)",
                kind: "length",
                units: t,
                initialMetric: 80,
                onValue: f,
                ariaLabel: "Waist",
                optional: !0,
              }),
              o.jsxs("label", {
                className: "flex items-start gap-2 text-sm",
                children: [
                  o.jsx("input", {
                    type: "checkbox",
                    className: "mt-1",
                    checked: g,
                    onChange: (c) => E(c.target.checked),
                  }),
                  o.jsx("span", {
                    children: "Use Asian BMI cut-offs (WHO: 23 and 27.5)",
                  }),
                ],
              }),
              S &&
                !x &&
                o.jsx("p", {
                  className: "text-xs text-muted-foreground",
                  children:
                    "Sex does not change adult BMI categories; it is only used for child percentile charts.",
                }),
            ],
          }),
          o.jsxs("div", {
            className: "p-6 rounded-xl border bg-card text-center",
            "data-result": !0,
            children: [
              o.jsx("p", {
                className: "text-sm text-muted-foreground",
                children: "Your BMI",
              }),
              h
                ? o.jsxs(o.Fragment, {
                    children: [
                      o.jsx("p", {
                        className: `text-4xl font-bold ${x ? "" : F}`,
                        "data-testid": "bmi-value",
                        children: p.toFixed(1),
                      }),
                      x
                        ? o.jsx("p", {
                            className: "text-sm mt-2 text-left",
                            "data-testid": "bmi-child-note",
                            role: "status",
                            children: m.kind === "child" ? m.message : "",
                          })
                        : o.jsxs(o.Fragment, {
                            children: [
                              o.jsxs("p", {
                                className: `text-sm font-medium mt-1 ${F}`,
                                "data-testid": "bmi-category",
                                children: [w, g ? " (Asian cut-offs)" : ""],
                              }),
                              o.jsx(ue, { bmi: p, asian: g, category: w }),
                              o.jsxs("p", {
                                className: "text-xs text-muted-foreground mt-3",
                                "data-testid": "bmi-range",
                                children: [
                                  "Healthy range for your height: ",
                                  B(P),
                                  " to ",
                                  B(L),
                                ],
                              }),
                              b !== 0 &&
                                o.jsxs("p", {
                                  className: "text-sm mt-2",
                                  "data-testid": "bmi-change",
                                  children: [
                                    "To reach the healthy range you would need to ",
                                    b < 0 ? "lose" : "gain",
                                    " about ",
                                    t === "metric"
                                      ? `${Math.abs(b).toFixed(1)} kg`
                                      : `${Math.round(Math.abs(b) / 0.45359237)} lb`,
                                    ".",
                                  ],
                                }),
                            ],
                          }),
                      y &&
                        o.jsxs("p", {
                          className: "text-sm mt-3 text-left",
                          "data-testid": "bmi-whtr",
                          children: [
                            "Waist-to-height ratio: ",
                            o.jsx("strong", { children: y.ratio.toFixed(2) }),
                            ". ",
                            y.note,
                          ],
                        }),
                      o.jsx("p", {
                        className: "text-xs text-muted-foreground mt-2",
                        "data-testid": "bmi-disclaimer",
                        "data-no-copy": !0,
                        children:
                          "BMI is a screening number, not a diagnosis. It does not apply to children or teenagers, and it can mislead for very muscular people, older adults and during pregnancy. Talk to a doctor about your health.",
                      }),
                    ],
                  })
                : o.jsx("p", {
                    className: "text-4xl font-bold",
                    "data-testid": "bmi-value",
                    children: "—",
                  }),
            ],
          }),
        ],
      }),
      h &&
        !0 &&
        !x &&
        m.kind !== "invalid" &&
        o.jsx(u.Suspense, {
          fallback: null,
          children: o.jsx(de, {
            kg: a,
            cm: n,
            imperial: t === "imperial",
            gate: R,
          }),
        }),
      o.jsx(Q, { whatIsIt: v.what, howToUse: v.how, tip: v.tip }),
    ],
  });
}
const ve = Object.freeze(
  Object.defineProperty({ __proto__: null, default: he }, Symbol.toStringTag, {
    value: "Module",
  }),
);
export {
  ve as B,
  O as W,
  ae as a,
  je as b,
  I as c,
  se as p,
  N as r,
  ye as t,
  ne as w,
};
//# sourceMappingURL=BmiCalculator-CIQaJbup.js.map
