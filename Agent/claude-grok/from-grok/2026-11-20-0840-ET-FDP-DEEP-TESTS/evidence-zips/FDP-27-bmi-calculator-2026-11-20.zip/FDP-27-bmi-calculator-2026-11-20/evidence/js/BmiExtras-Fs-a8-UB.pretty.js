import { r as m, j as e } from "./vendor-react-D01g8YgM.js";
import { e as B, I as v } from "./index-B1CTyGtY.js";
import { C } from "./CalcSteps-CMhW1YVy.js";
import { C as T, R as F } from "./ResultsTable-CpxaKI_z.js";
import { r as H, E as W } from "./history-B6kbrtr3.js";
import { C as S } from "./CalcHistory-B9VfOON0.js";
import { s as $ } from "./steps-X1Sejec4.js";
import { t as O } from "./table-CJAX3ymv.js";
import { p as P } from "./numberInput-5hjoxJ5z.js";
import {
  w as E,
  b as k,
  a as f,
  p as y,
  W as p,
  r as K,
  c as u,
  t as R,
} from "./BmiCalculator-CIQaJbup.js";
import "./csv-DBvSFDe9.js";
import "./copy-DcUvE8ta.js";
import "./share-2-B4TSO3Yd.js";
import "./ToolPage-DwLoDncN.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./MeasureField-DjJ0Relq.js";
import "./ToolInfoSection-C0i6Zbwo.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./useLogToolUsage-BdvvKW0n.js";
import "./copyText-DPnES92p.js";
function Me({ kg: s, cm: a, imperial: h, gate: w }) {
  const [d, g] = m.useState("24.9"),
    [n, I] = m.useState("bmi"),
    b = K(u(s, a)),
    i = E(b),
    c = (t) => (h ? `${(t / 0.45359237).toFixed(0)} lb` : `${t.toFixed(1)} kg`),
    j = m.useMemo(() => k(s, a, c), [s, a, h]),
    N = [
      {
        key: "label",
        header: "WHO class",
        get: (t) => t.label,
        format: (t) => `${t.label}${t.id === i.id ? " (you)" : ""}`,
        align: "left",
      },
      {
        key: "range",
        header: "BMI (kg/m2)",
        get: (t) => t.range,
        align: "left",
      },
    ],
    o = d.trim() === "" ? null : P(d),
    l = o === null ? null : n === "prime" ? o * 25 : o,
    r = l === null ? null : R(s, a, l),
    x = `BMI ${b.toFixed(1)}, Prime ${f(u(s, a)).toFixed(2)}, Ponderal Index ${y(s, a).toFixed(1)}, ${i.label}`;
  m.useEffect(() => {
    const t = setTimeout(() => H("bmi-calculator", x), 800);
    return () => clearTimeout(t);
  }, [x]);
  const M = [
    "BMI calculation",
    x,
    "",
    "How this was calculated",
    $(j),
    "",
    "WHO adult classes",
    ...p.map((t) => `${t.label}: ${t.range}${t.id === i.id ? "  <- you" : ""}`),
    "",
    "BMI is a screening number, not a diagnosis. Calculated with FreeDailyPro.com",
  ].join(`
`);
  return e.jsxs("div", {
    className: "space-y-6 calc-print-area mt-6",
    "data-testid": "bmi-extras",
    children: [
      e.jsx("style", { children: T }),
      e.jsxs("div", {
        className: "grid grid-cols-2 gap-3",
        children: [
          e.jsxs("div", {
            className: "p-3 rounded-lg border bg-card text-center",
            children: [
              e.jsx("p", {
                className: "text-xs text-muted-foreground",
                children: "BMI Prime (BMI / 25)",
              }),
              e.jsx("p", {
                className: "text-xl font-bold",
                "data-testid": "bmi-prime",
                children: f(u(s, a)).toFixed(2),
              }),
              e.jsx("p", {
                className: "text-xs text-muted-foreground",
                children: "1.00 is the top of the normal range",
              }),
            ],
          }),
          e.jsxs("div", {
            className: "p-3 rounded-lg border bg-card text-center",
            children: [
              e.jsx("p", {
                className: "text-xs text-muted-foreground",
                children: "Ponderal Index (kg/m3)",
              }),
              e.jsx("p", {
                className: "text-xl font-bold",
                "data-testid": "bmi-pi",
                children: y(s, a).toFixed(1),
              }),
              e.jsx("p", {
                className: "text-xs text-muted-foreground",
                children: "Weight against height cubed",
              }),
            ],
          }),
        ],
      }),
      e.jsxs("section", {
        "aria-label": "WHO BMI classes",
        className: "space-y-2",
        children: [
          e.jsx("h3", {
            className: "text-base font-semibold",
            children: "WHO adult BMI classes",
          }),
          e.jsx("div", {
            "data-testid": "bmi-who",
            children: e.jsx(F, {
              caption: "WHO adult BMI classification with your class marked",
              rows: p,
              columns: N,
              rowKey: (t) => t.id,
              maxHeightClass: "max-h-96",
            }),
          }),
          e.jsxs("p", {
            className: "text-xs text-muted-foreground",
            children: [
              "You are in: ",
              e.jsx("strong", {
                "data-testid": "bmi-who-you",
                children: i.label,
              }),
              ". Source: WHO adult BMI classification (WHO Technical Report Series 894, 2000). The Asian cut-offs option above changes the main category but not this table.",
            ],
          }),
        ],
      }),
      e.jsxs("section", {
        "aria-label": "Target weight",
        className: "space-y-2",
        children: [
          e.jsx("h3", {
            className: "text-base font-semibold",
            children: "Target weight",
          }),
          e.jsxs("div", {
            className: "flex flex-wrap items-end gap-3",
            children: [
              e.jsxs("div", {
                children: [
                  e.jsxs(B, {
                    htmlFor: "bmi-target",
                    children: ["Target ", n === "prime" ? "BMI Prime" : "BMI"],
                  }),
                  e.jsx(v, {
                    id: "bmi-target",
                    className: "w-28",
                    inputMode: "decimal",
                    value: d,
                    onChange: (t) => g(t.target.value),
                  }),
                ],
              }),
              e.jsxs("select", {
                className: "border rounded px-2 py-2 bg-background text-sm",
                "aria-label": "Target type",
                value: n,
                onChange: (t) => {
                  (I(t.target.value),
                    g(t.target.value === "prime" ? "1" : "24.9"));
                },
                children: [
                  e.jsx("option", { value: "bmi", children: "BMI" }),
                  e.jsx("option", { value: "prime", children: "BMI Prime" }),
                ],
              }),
            ],
          }),
          r &&
            (r.ok
              ? e.jsxs("p", {
                  className: "text-sm",
                  "data-testid": "bmi-target-result",
                  children: [
                    "A BMI of ",
                    l.toFixed(1),
                    " at your height is ",
                    e.jsx("strong", { children: c(r.targetKg) }),
                    ", which is ",
                    Math.abs(r.deltaKg) < 0.05
                      ? "your current weight"
                      : e.jsxs(e.Fragment, {
                          children: [
                            r.deltaKg < 0 ? "lose" : "gain",
                            " ",
                            e.jsx("strong", {
                              children: c(Math.abs(r.deltaKg)),
                            }),
                          ],
                        }),
                    ".",
                  ],
                })
              : e.jsx("p", {
                  role: "alert",
                  className: "text-sm text-destructive",
                  "data-testid": "bmi-target-error",
                  children: r.message,
                })),
          o !== null && l !== null && !r && null,
        ],
      }),
      e.jsx(C, { steps: j, title: "Formula and worked example" }),
      e.jsx(W, {
        gate: w,
        text: M,
        csv: O(p, [
          { key: "label", header: "WHO class", get: (t) => t.label },
          { key: "range", header: "BMI (kg/m2)", get: (t) => t.range },
          {
            key: "you",
            header: "Your class",
            get: (t) => (t.id === i.id ? "yes" : ""),
          },
        ]),
        filename: "bmi-who-classes.csv",
        label: "result",
      }),
      e.jsx(S, { tool: "bmi-calculator" }),
    ],
  });
}
export { Me as default };
//# sourceMappingURL=BmiExtras-Fs-a8-UB.js.map
