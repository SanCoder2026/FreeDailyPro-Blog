import { j as e } from "./vendor-react-D01g8YgM.js";
function i({ steps: t, title: l = "How this was calculated" }) {
  return t.length === 0
    ? null
    : e.jsx("section", {
        "aria-label": l,
        className: "rounded-xl border bg-card p-4",
        "data-testid": "calc-steps",
        children: e.jsxs("details", {
          children: [
            e.jsx("summary", {
              className: "cursor-pointer text-sm font-semibold",
              children: l,
            }),
            e.jsx("ol", {
              className: "mt-3 space-y-3 text-sm",
              children: t.map((s, a) =>
                e.jsxs(
                  "li",
                  {
                    "data-testid": "calc-step",
                    children: [
                      e.jsxs("p", {
                        className: "font-medium",
                        children: [a + 1, ". ", s.label],
                      }),
                      e.jsx("p", {
                        className: "text-muted-foreground",
                        children: s.formula,
                      }),
                      Object.keys(s.inputs).length > 0 &&
                        e.jsxs("p", {
                          className: "text-muted-foreground",
                          children: [
                            "Using ",
                            Object.entries(s.inputs)
                              .map(([r, n]) => `${r} = ${n}`)
                              .join("; "),
                          ],
                        }),
                      e.jsxs("p", {
                        children: [
                          "Result: ",
                          e.jsx("strong", { children: s.result }),
                        ],
                      }),
                    ],
                  },
                  `${a}-${s.label}`,
                ),
              ),
            }),
          ],
        }),
      });
}
export { i as C };
//# sourceMappingURL=CalcSteps-CMhW1YVy.js.map
