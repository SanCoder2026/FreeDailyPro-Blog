import { j as a, r as c } from "./vendor-react-D01g8YgM.js";
import { B, e as S, I as N } from "./index-B1CTyGtY.js";
import { p as $ } from "./numberInput-5hjoxJ5z.js";
const T = {
    height: { min: 100, max: 250 },
    weight: { min: 30, max: 300 },
    length: { min: 10, max: 250 },
  },
  m = 2.54,
  p = 0.45359237,
  o = (l, t = 1) => String(Math.round(l * 10 ** t) / 10 ** t);
function G({ units: l, onChange: t }) {
  return a.jsxs("div", {
    className: "flex gap-2 mb-4 justify-center",
    children: [
      a.jsx(B, {
        size: "sm",
        variant: l === "metric" ? "default" : "outline",
        onClick: () => t("metric"),
        children: "Metric (kg / cm)",
      }),
      a.jsx(B, {
        size: "sm",
        variant: l === "imperial" ? "default" : "outline",
        onClick: () => t("imperial"),
        children: "Imperial (lb / ft-in)",
      }),
    ],
  });
}
function L({
  label: l,
  kind: t,
  units: s,
  initialMetric: h,
  onValue: j,
  ariaLabel: w,
  optional: x,
}) {
  const [M, v] = c.useState(x ? null : h),
    [b, u] = c.useState(() => (x ? "" : o(h))),
    [C, I] = c.useState(() => String(Math.floor(h / m / 12))),
    [y, R] = c.useState(() => o((h / m) % 12)),
    [f, d] = c.useState(""),
    _ = c.useRef(s),
    E = (e, r) => {
      const i = T[t],
        g = r.trim() === "";
      let n = "";
      (e != null && (e < i.min || e > i.max)
        ? (t === "height" && s === "metric" && e >= 0.5 && e <= 2.5
            ? (n = `That looks like metres. Enter your height in centimetres (for example ${Math.round(e * 100)}).`)
            : (n = `Enter a ${t} between ${Math.round(t === "weight" && s === "imperial" ? i.min / p : t !== "weight" && s === "imperial" ? i.min / m : i.min)} and ${Math.round(t === "weight" && s === "imperial" ? i.max / p : t !== "weight" && s === "imperial" ? i.max / m : i.max)} ${t === "weight" ? (s === "metric" ? "kg" : "lb") : s === "metric" ? "cm" : "in"}.`),
          (e = null))
        : e == null && g && x
          ? (n = "")
          : e == null &&
            (n = g
              ? `Enter your ${l.toLowerCase()}.`
              : "Numbers only, please."),
        d(n),
        v(e),
        j(e));
    };
  c.useEffect(() => {
    if (_.current === s) {
      E(M, s === "metric" || t !== "height" ? b : "x");
      return;
    }
    if (((_.current = s), x && M == null)) {
      (u(""), d(""));
      return;
    }
    const e = M ?? h;
    if (s === "metric") u(o(e));
    else if (t === "weight") u(o(e / p));
    else if (t === "height") {
      const r = e / m;
      (I(String(Math.floor(r / 12))), R(o(r % 12)));
    } else u(o(e / m));
    (v(e), j(e), d(""));
  }, [s]);
  const P =
    t === "weight"
      ? s === "metric"
        ? "kg"
        : "lb"
      : s === "metric"
        ? "cm"
        : "in";
  if (t === "height" && s === "imperial") {
    const e = (r, i) => {
      const g = $(r),
        n = $(i) ?? 0;
      if (n < 0 || n >= 12) {
        (d(
          "Inches must be between 0 and 11.9. Put whole feet in the feet box.",
        ),
          v(null),
          j(null));
        return;
      }
      E(g == null ? null : (g * 12 + n) * m, r);
    };
    return a.jsxs("div", {
      children: [
        a.jsxs("div", {
          className: "grid grid-cols-2 gap-3",
          children: [
            a.jsxs("div", {
              children: [
                a.jsxs(S, { children: [l, " (ft)"] }),
                a.jsx(N, {
                  inputMode: "decimal",
                  "aria-label": `${w ?? l} ft`,
                  value: C,
                  onChange: (r) => {
                    (I(r.target.value), e(r.target.value, y));
                  },
                }),
              ],
            }),
            a.jsxs("div", {
              children: [
                a.jsxs(S, { children: [l, " (in)"] }),
                a.jsx(N, {
                  inputMode: "decimal",
                  "aria-label": `${w ?? l} in`,
                  value: y,
                  onChange: (r) => {
                    (R(r.target.value), e(C, r.target.value));
                  },
                }),
              ],
            }),
          ],
        }),
        f &&
          a.jsx("p", {
            className: "text-xs text-red-600 mt-1",
            "data-testid": "measure-error",
            children: f,
          }),
      ],
    });
  }
  return a.jsxs("div", {
    children: [
      a.jsxs(S, { children: [l, " (", P, ")"] }),
      a.jsx(N, {
        inputMode: "decimal",
        "aria-label": w ?? l,
        value: b,
        onChange: (e) => {
          u(e.target.value);
          const r = $(e.target.value);
          E(
            r == null
              ? null
              : s === "metric"
                ? r
                : t === "weight"
                  ? r * p
                  : r * m,
            e.target.value,
          );
        },
      }),
      f &&
        a.jsx("p", {
          className: "text-xs text-red-600 mt-1",
          "data-testid": "measure-error",
          children: f,
        }),
    ],
  });
}
export { L as M, G as U };
//# sourceMappingURL=MeasureField-DjJ0Relq.js.map
