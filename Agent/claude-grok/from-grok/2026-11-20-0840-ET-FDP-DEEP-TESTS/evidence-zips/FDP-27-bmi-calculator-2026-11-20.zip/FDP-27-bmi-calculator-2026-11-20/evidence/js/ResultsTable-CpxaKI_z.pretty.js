import { j as e } from "./vendor-react-D01g8YgM.js";
function d({
  caption: r,
  rows: l,
  columns: i,
  rowKey: s,
  maxHeightClass: o = "max-h-[420px]",
}) {
  return e.jsx("div", {
    className: "border rounded-xl overflow-hidden",
    children: e.jsx("div", {
      className: `${o} overflow-y-auto print:max-h-none print:overflow-visible`,
      tabIndex: 0,
      role: "region",
      "aria-label": `${r} (scrollable)`,
      children: e.jsxs("table", {
        className: "w-full text-sm",
        "data-testid": "calc-table",
        children: [
          e.jsx("caption", { className: "sr-only", children: r }),
          e.jsx("thead", {
            className: "sticky top-0 bg-card border-b",
            children: e.jsx("tr", {
              className: "text-left text-muted-foreground",
              children: i.map((t) =>
                e.jsx(
                  "th",
                  {
                    scope: "col",
                    className: `p-2 ${t.align === "right" ? "text-right" : ""}`,
                    children: t.header,
                  },
                  t.key,
                ),
              ),
            }),
          }),
          e.jsx("tbody", {
            children: l.map((t) =>
              e.jsx(
                "tr",
                {
                  className: "border-b last:border-0",
                  children: i.map((a) =>
                    e.jsx(
                      "td",
                      {
                        className: `p-2 ${a.align === "right" ? "text-right" : "whitespace-nowrap"}`,
                        children: a.format
                          ? a.format(t)
                          : String(a.get(t) ?? ""),
                      },
                      a.key,
                    ),
                  ),
                },
                s(t),
              ),
            ),
          }),
        ],
      }),
    }),
  });
}
const c =
  "@media print { body * { visibility: hidden !important; } .calc-print-area, .calc-print-area * { visibility: visible !important; } .calc-print-area { position: absolute; left: 0; top: 0; width: 100%; } }";
export { c as C, d as R };
//# sourceMappingURL=ResultsTable-CpxaKI_z.js.map
