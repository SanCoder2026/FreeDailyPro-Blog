// bmi-calculator: export actions (export bar: Copy result / Download CSV / Print or save as PDF; result actions: Copy result / Save as text / Print)
// at 0 and with uses left. window.print stubbed. Max 6 fresh contexts. At 0: one pass of the cap dialog -> Buy Day Pass -> email prompt (stop, type nothing).
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/27-bmi-calculator/live/'; fs.mkdirSync(OUT + 'downloads', { recursive: true }); const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const ORDERS = { A_csv_first: ['bar:Download CSV', 'bar:Copy result', 'bar:Print or save as PDF', 'res:Copy result', 'res:Save as text', 'res:Print'],
 B_save_first: ['res:Save as text', 'res:Save as text', 'bar:Download CSV', 'res:Copy result'] };
(async () => { const b = await chromium.launch(); const R = { t: now(), contexts: [] }; let zeroDone = false; const todo = Object.keys(ORDERS);
 for (let i = 0; i < 6 && (todo.length || !zeroDone); i++) {
  const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true, permissions: ['clipboard-read', 'clipboard-write'] });
  await c.addInitScript(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
  const p = await c.newPage(); p.setDefaultTimeout(10000); await p.goto('https://www.freedailypro.com/tool/bmi-calculator?kg=82&cm=178', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
  const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
  const row = { i, t: now(), start: await used(), steps: [] }; R.contexts.push(row); const atZero = row.start >= 10;
  if (atZero && zeroDone) { row.note = 'loaded at 0; skipped'; await c.close(); continue; }
  if (!atZero && !todo.length) { await c.close(); continue; }
  const name = atZero ? 'Z_at_zero' : todo.shift(); row.name = name;
  const acts = atZero ? ORDERS.A_csv_first : ORDERS[name];
  for (const a of acts) { const [area, label] = a.split(':'); let d = null; const h = x => d = x; p.on('download', h);
   const sel = area === 'bar' ? '[data-testid=calc-export-bar] button' : '[data-testid=result-actions] button';
   await p.locator(sel).filter({ hasText: label }).first().click(); await p.waitForTimeout(1800); p.off('download', h);
   const dl = p.locator('[role=dialog],[role=alertdialog]'); const dialog = (await dl.count()) ? (await dl.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 400) : null;
   const toast = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast], [role=status]')].map(e => e.innerText.trim()).filter(Boolean).slice(-2));
   const st = { a, used: await used(), dialog, toast, download: d ? d.suggestedFilename() : null, printed: await p.evaluate(() => window.__printed), clip: (await p.evaluate(() => navigator.clipboard.readText()).catch(() => '')).slice(0, 1500) };
   if (d) { const f = OUT + 'downloads/' + name + '-' + d.suggestedFilename(); await d.saveAs(f); st.file = f; st.content = fs.readFileSync(f, 'utf8').slice(0, 2500); }
   row.steps.push(st);
   if (dialog) { if (atZero && !row.capShot) { row.capShot = OUT + 'cap-dialog.png'; await p.screenshot({ path: row.capShot }); }
     if (atZero && !row.daypass) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500);
       row.daypass = { url: p.url(), dialog: (await p.locator('[role=dialog]').first().innerText().catch(() => '')).replace(/\s*\n\s*/g, ' | ').slice(0, 300), emailField: await p.locator('input[type=email]').count() };
       await p.screenshot({ path: OUT + 'daypass-email.png' }); } }
     await p.keyboard.press('Escape'); await p.waitForTimeout(400); await p.keyboard.press('Escape'); await p.waitForTimeout(300); } }
  await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); row.afterReload = await used();
  if (atZero) zeroDone = true; await c.close(); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1).slice(0, 12000)); await b.close(); })();
