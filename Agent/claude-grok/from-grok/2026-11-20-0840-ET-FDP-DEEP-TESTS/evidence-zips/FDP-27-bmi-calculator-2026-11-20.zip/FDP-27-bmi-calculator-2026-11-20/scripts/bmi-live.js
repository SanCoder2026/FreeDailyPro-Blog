// bmi-calculator: calculation cases (reading only; no copy/save/print/CSV, so no trial use). Usage: node bmi-live.js [ids] [outfile]
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/27-bmi-calculator/live/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
// u: units; kg/cm (metric) or lb/ft/in (imperial); age, sex, waist, asian, target, ttype
const C = {
 B01_default: {}, B02_50_170: { kg: '50' }, B03_90_170: { kg: '90' }, B04_72_25_170: { kg: '72.25' }, B05_72_2_170_edge: { kg: '72.2' },
 B06_53_4_170_edge: { kg: '53.4' }, B07_asian_70: { asian: 1 }, B08_asian_65: { kg: '65', asian: 1 }, B09_asian_80: { kg: '80', asian: 1 },
 B10_age15: { age: '15' }, B11_age1: { age: '1' }, B12_age_25_5: { age: '25.5' }, B13_age130: { age: '130' }, B14_age_abc: { age: 'abc' },
 B15_cm_1_7: { cm: '1.7' }, B16_cm_99: { cm: '99' }, B17_cm_251: { cm: '251' }, B18_kg_29: { kg: '29' }, B19_kg_301: { kg: '301' },
 B20_kg_abc: { kg: 'abc' }, B21_kg_empty: { kg: '' }, B22_kg_neg: { kg: '-5' }, B23_kg_comma: { kg: '70,5' }, B24_kg_thousand: { kg: '1,000' },
 B25_waist85: { waist: '85' }, B26_waist60: { waist: '60' }, B27_waist110: { waist: '110' }, B28_waist5: { waist: '5' },
 B29_target22: { target: '22' }, B30_prime1: { ttype: 'prime' }, B31_target5: { target: '5' }, B32_target_abc: { target: 'abc' },
 B33_extreme_300_100: { kg: '300', cm: '100' }, B34_extreme_30_250: { kg: '30', cm: '250' }, B35_sex_female: { sex: 'female' },
 B36_age15_sex_female: { age: '15', sex: 'female' }, B37_age70: { age: '70' }, B38_120_175: { kg: '120', cm: '175' },
 I01_154lb_5_7: { u: 'imperial', lb: '154', ft: '5', in: '7' }, I02_200lb_6_0: { u: 'imperial', lb: '200', ft: '6', in: '0' },
 I03_in_12: { u: 'imperial', lb: '154', ft: '5', in: '12' }, I04_ft_empty_in_67: { u: 'imperial', lb: '154', ft: '', in: '67' },
 I05_lb_50: { u: 'imperial', lb: '50', ft: '5', in: '7' }, I06_waist34in: { u: 'imperial', lb: '154', ft: '5', in: '7', waist: '34' },
 I07_ft_5_5: { u: 'imperial', lb: '154', ft: '5.5', in: '0' }, B39_lb_in_kg_box: { kg: '154' },
};
(async () => { const ids = process.argv[2] ? process.argv[2].split(',') : Object.keys(C); const b = await chromium.launch();
 const ctx = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await ctx.newPage(); p.setDefaultTimeout(8000);
 const R = { t0: now(), cases: {} };
 for (const id of ids) { const c = C[id];
  await p.goto('https://www.freedailypro.com/tool/bmi-calculator', { waitUntil: 'domcontentloaded' }); await p.waitForSelector('[data-testid=bmi-value]'); await p.waitForTimeout(1200);
  if (!R.ls0) R.ls0 = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
  const main = p.locator('main');
  if (c.u === 'imperial') { await p.getByRole('button', { name: 'Imperial (lb / ft-in)' }).click(); await p.waitForTimeout(300);
   await main.getByLabel('Weight', { exact: true }).fill(c.lb); await main.getByLabel('Height ft', { exact: true }).fill(c.ft); await main.getByLabel('Height in', { exact: true }).fill(c.in); }
  else { if ('kg' in c) await main.getByLabel('Weight', { exact: true }).fill(c.kg); if ('cm' in c) await main.getByLabel('Height', { exact: true }).fill(c.cm); }
  if (c.age) await p.locator('#bmi-age').fill(c.age); if (c.sex) await p.selectOption('#bmi-sex', c.sex);
  if (c.waist) await main.getByLabel('Waist', { exact: true }).fill(c.waist); if (c.asian) await main.getByLabel(/Asian BMI cut-offs/).check();
  if (c.ttype) { await p.selectOption('select[aria-label="Target type"]', c.ttype); } if (c.target) await p.locator('#bmi-target').fill(c.target);
  await p.waitForTimeout(1100);
  R.cases[id] = { input: c, url: p.url().replace('https://www.freedailypro.com', ''), ...(await p.evaluate(() => { const g = s => { const e = document.querySelector(`[data-testid=${s}]`); return e ? e.innerText.trim() : null; };
   return { bmi: g('bmi-value'), cat: g('bmi-category'), range: g('bmi-range'), change: g('bmi-change'), child: g('bmi-child-note'), whtr: g('bmi-whtr'), prime: g('bmi-prime'), pi: g('bmi-pi'), who: g('bmi-who-you'),
     target: g('bmi-target-result') || g('bmi-target-error'), errs: [...document.querySelectorAll('[data-testid=measure-error], main [role=alert]')].map(e => e.innerText.trim()), gauge: (document.querySelector('[data-testid=bmi-gauge] svg') || {}).ariaLabel || (document.querySelector('[data-testid=bmi-gauge] svg') ? document.querySelector('[data-testid=bmi-gauge] svg').getAttribute('aria-label') : null),
     extras: !!document.querySelector('[data-testid=bmi-extras]'), hist: g('calc-history'), sexNote: [...document.querySelectorAll('main p')].map(e => e.innerText).find(t => /Sex does not change/.test(t)) || null }; })) };
  if (['B01_default', 'B07_asian_70', 'B10_age15', 'B15_cm_1_7', 'I01_154lb_5_7', 'B25_waist85'].includes(id)) await p.locator('[data-result]').screenshot({ path: OUT + 'case-' + id + '.png' });
 }
 R.lsEnd = await p.evaluate(() => localStorage.getItem('fdp-usage-v1')); R.lsKeys = await p.evaluate(() => Object.keys(localStorage)); R.t1 = now();
 fs.writeFileSync(OUT + (process.argv[3] || 'cases.json'), JSON.stringify(R, null, 1));
 for (const [k, v] of Object.entries(R.cases)) console.log(k, '|', v.bmi, '|', v.cat, '|', v.range, '|', v.change || '', '|', v.child ? 'CHILD:' + v.child.slice(0, 60) : '', '|', v.whtr || '', '| prime', v.prime, '| pi', v.pi, '| who', v.who, '|', v.target, '|', v.errs.join(' / '), '|', v.url);
 await b.close(); })();
