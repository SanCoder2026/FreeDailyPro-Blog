// bmi-calculator: do the typed weight/height (mirrored into the page URL as ?kg=&cm=) leave the browser? Records request URLs/bodies that contain the values. Read-only; never clicks ads.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/27-bmi-calculator/live/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage();
 const R = { t: now(), hits: [], hosts: {} };
 const rx = /kg(=|%3D|%253D)8[37]|cm(=|%3D|%253D)17[89]|87\.3|179\.5/;
 p.on('request', r => { const u = r.url(); const h = new URL(u).host; R.hosts[h] = (R.hosts[h] || 0) + 1; const body = r.postData() || ''; if (rx.test(u) || rx.test(body)) R.hits.push({ phase: R.phase, method: r.method(), host: h, path: new URL(u).pathname.slice(0, 60), where: rx.test(u) ? 'url' : 'body', sample: (rx.test(u) ? u : body).match(/.{0,60}(kg(=|%3D|%253D)8[37]|cm(=|%3D|%253D)17[89]|87\.3|179\.5).{0,40}/)[0] }); });
 R.phase = 'A_typed'; await p.goto('https://www.freedailypro.com/tool/bmi-calculator', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 await p.locator('main').getByLabel('Weight', { exact: true }).fill('87.3'); await p.locator('main').getByLabel('Height', { exact: true }).fill('179.5'); await p.waitForTimeout(6000);
 await p.mouse.wheel(0, 2500); await p.waitForTimeout(5000);
 R.urlA = p.url(); R.phase = 'B_reload_or_shared_link'; await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(8000); await p.mouse.wheel(0, 2500); await p.waitForTimeout(4000);
 R.t2 = now(); fs.writeFileSync(OUT + 'privacy.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
