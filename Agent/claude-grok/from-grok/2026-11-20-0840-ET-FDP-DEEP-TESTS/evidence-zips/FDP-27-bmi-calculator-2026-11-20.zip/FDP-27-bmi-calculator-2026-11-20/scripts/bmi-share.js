// bmi-calculator: Share this tool, Add to favorites, Create Shortcut, URL state round-trip. Stops at any sign-in. No export.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/27-bmi-calculator/live/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 }, permissions: ['clipboard-read', 'clipboard-write'] }); const p = await c.newPage(); p.setDefaultTimeout(8000);
 const R = { t: now() }; await p.goto('https://www.freedailypro.com/tool/bmi-calculator', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 R.start = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
 await p.locator('main').getByLabel('Weight', { exact: true }).fill('82'); await p.locator('main').getByLabel('Height', { exact: true }).fill('178'); await p.locator('#bmi-age').fill('40'); await p.locator('main').getByLabel(/Asian/).check(); await p.waitForTimeout(800);
 R.urlAfterEdit = p.url();
 const popups = []; c.on('page', np => popups.push(np));
 await p.getByRole('button', { name: 'Share this tool' }).first().click(); await p.waitForTimeout(1500);
 R.shareUI = await p.evaluate(() => { const d = document.querySelector('[role=dialog],[role=menu],[data-radix-popper-content-wrapper]'); return d ? d.innerText.slice(0, 500) : null; });
 R.shareToast = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText));
 R.clip = await p.evaluate(() => navigator.clipboard.readText()).catch(e => 'ERR ' + e.message);
 await p.screenshot({ path: OUT + 'share-ui.png' }); await p.keyboard.press('Escape'); await p.waitForTimeout(400);
 await p.getByRole('button', { name: 'Add to favorites' }).first().click(); await p.waitForTimeout(1500);
 R.fav = { dialog: await p.evaluate(() => { const d = document.querySelector('[role=dialog]'); return d ? d.innerText.slice(0, 300) : null; }), toast: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText)), url: p.url(), ls: await p.evaluate(() => Object.keys(localStorage)) };
 await p.screenshot({ path: OUT + 'favorites.png' }); await p.keyboard.press('Escape'); await p.waitForTimeout(400);
 R.popups = popups.map(x => x.url().replace(/(opparams|dsh|client_id)=[^&]*/g, '$1=REDACTED').slice(0, 160));
 // round trip: open the edited URL in a new page
 const p2 = await c.newPage(); await p2.goto(R.urlAfterEdit, { waitUntil: 'domcontentloaded' }); await p2.waitForTimeout(4000);
 R.roundTrip = await p2.evaluate(() => ({ bmi: document.querySelector('[data-testid=bmi-value]').innerText, cat: (document.querySelector('[data-testid=bmi-category]') || {}).innerText, age: document.querySelector('#bmi-age').value }));
 R.end = await p.evaluate(() => localStorage.getItem('fdp-usage-v1')); R.t2 = now(); fs.writeFileSync(OUT + 'share.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
