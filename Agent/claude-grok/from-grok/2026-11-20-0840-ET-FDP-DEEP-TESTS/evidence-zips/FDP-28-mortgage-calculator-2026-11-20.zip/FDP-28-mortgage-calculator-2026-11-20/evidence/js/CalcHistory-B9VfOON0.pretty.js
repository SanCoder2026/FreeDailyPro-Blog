import { j as e } from "./vendor-react-D01g8YgM.js";
import { u as l, c as a } from "./history-B6kbrtr3.js";
function n({ tool: r }) {
  const t = l().filter((s) => s.tool === r);
  return t.length === 0
    ? null
    : e.jsxs("section", {
        "aria-label": "Recent calculations",
        className: "rounded-xl border bg-card p-4",
        "data-testid": "calc-history",
        children: [
          e.jsxs("div", {
            className: "flex items-center justify-between gap-2",
            children: [
              e.jsx("h3", {
                className: "text-sm font-semibold",
                children: "Recent calculations",
              }),
              e.jsx("button", {
                type: "button",
                className: "text-xs underline text-muted-foreground",
                onClick: a,
                children: "Clear",
              }),
            ],
          }),
          e.jsx("ol", {
            className: "mt-2 space-y-1 text-sm",
            children: t.map((s) => e.jsx("li", { children: s.summary }, s.id)),
          }),
          e.jsx("p", {
            className: "mt-2 text-xs text-muted-foreground",
            children:
              "Kept only while this page is open. Nothing is saved on our servers or in your browser.",
          }),
        ],
      });
}
export { n as C };
//# sourceMappingURL=CalcHistory-B9VfOON0.js.map
