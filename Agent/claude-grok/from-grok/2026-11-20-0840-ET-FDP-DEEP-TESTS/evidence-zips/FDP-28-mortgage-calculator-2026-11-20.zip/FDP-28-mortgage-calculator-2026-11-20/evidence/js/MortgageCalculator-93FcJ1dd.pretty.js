const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/MortgageExtras-Ci9ZoUPC.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/CalcSteps-CMhW1YVy.js",
      "assets/ResultsTable-CpxaKI_z.js",
      "assets/history-B6kbrtr3.js",
      "assets/index-B1CTyGtY.js",
      "assets/index-BJxTAPRn.css",
      "assets/csv-DBvSFDe9.js",
      "assets/copy-DcUvE8ta.js",
      "assets/share-2-B4TSO3Yd.js",
      "assets/CalcHistory-B9VfOON0.js",
      "assets/steps-X1Sejec4.js",
      "assets/table-CJAX3ymv.js",
      "assets/paymentDates-4j4nTGxO.js",
      "assets/dates-DoPZ1fRV.js",
      "assets/ToolPage-DwLoDncN.js",
      "assets/useUploadApi-cn-OKK9Q.js",
      "assets/cloudStorage-BzUdFuQl.js",
      "assets/camera-8PGplCT5.js",
      "assets/workflowCta-WWwB7oO9.js",
      "assets/UsageAndUpgradeStrip-B1CY210m.js",
      "assets/access-BB4298M0.js",
      "assets/useAdminAccess-CRDzdxJU.js",
      "assets/tool-name-translations-d1j9ms8v.js",
      "assets/InstallToolButton-CQjOKKQY.js",
      "assets/map-pin-Dp16LrFV.js",
      "assets/FaqSection-C8274byc.js",
      "assets/ToolVideoEmbed-CCFWLqkW.js",
      "assets/GuideLinks-CJoJwps-.js",
      "assets/blog-8brHQns7.js",
      "assets/info-B8t_e6MS.js",
      "assets/productCards-BBBZlV20.js",
      "assets/layers-Dw7RJFNV.js",
      "assets/usePwaManifest-D8HDEEPW.js",
      "assets/ToolInfoSection-C0i6Zbwo.js",
      "assets/CollapsibleText-BCSBEG9-.js",
      "assets/chevron-up-BDUcPssj.js",
      "assets/useLogToolUsage-BdvvKW0n.js",
      "assets/copyText-DPnES92p.js",
      "assets/numberInput-5hjoxJ5z.js",
      "assets/money-Dkxewa8a.js",
      "assets/loan-CAZoObwd.js",
    ]),
) => i.map((i) => d[i]);
import { e as u, I as g, N as Ft, ap as Ot } from "./index-B1CTyGtY.js";
import { r as l, j as e } from "./vendor-react-D01g8YgM.js";
import { T as _t } from "./ToolPage-DwLoDncN.js";
import { T as Gt } from "./ToolInfoSection-C0i6Zbwo.js";
import { u as Rt } from "./useLogToolUsage-BdvvKW0n.js";
import { p as N } from "./numberInput-5hjoxJ5z.js";
import { f as Bt } from "./money-Dkxewa8a.js";
import { a as ot, m as Yt } from "./loan-CAZoObwd.js";
import {
  p as Ge,
  i as Vt,
  b as K,
  y as Wt,
  d as zt,
  M as Ze,
  a as et,
  f as ue,
  j as qt,
  k as Qt,
  l as Kt,
  c as V,
  m as Xt,
} from "./paymentDates-4j4nTGxO.js";
import { t as Jt } from "./dates-DoPZ1fRV.js";
const Zt = 1.75;
function ea(a, n, r) {
  const s = Math.max(0, a - n),
    i = a > 0 ? s / a : 0,
    f = r > 15 ? (i > 0.95 ? 0.55 : 0.5) : i > 0.9 ? 0.4 : 0.15,
    x = Math.round(r * 12),
    h = i > 0.9 ? x : Math.min(132, x),
    j = Math.round(s * Zt) / 100;
  return {
    baseLoan: s,
    upfront: j,
    loan: s + j,
    ltv: i,
    annualMipPct: f,
    mipMonths: h,
    minDownPct: 3.5,
  };
}
const Oe = "2026 standard rates, confirm with your lender",
  tt = 1,
  ta = 0.35,
  $e = (a) => Math.round(a * 100) / 100;
function aa(a, n = "first") {
  return n === "exempt"
    ? 0
    : a >= 10
      ? 1.25
      : a >= 5
        ? 1.5
        : n === "subsequent"
          ? 3.3
          : 2.15;
}
function lt(a, n, r, s, i = "first") {
  const c = Math.max(0, n - r),
    f = n > 0 ? c / n : 0,
    x = Math.round(s * 12);
  if (a === "fha") {
    const h = ea(n, r, s);
    return {
      baseLoan: c,
      upfront: h.upfront,
      loan: h.loan,
      ltv: f,
      upfrontPct: 1.75,
      upfrontLabel: "Upfront MIP (financed, 1.75%)",
      annualPct: h.annualMipPct,
      insMonths: h.mipMonths,
      insName: "MIP",
      minDownPct: 3.5,
    };
  }
  if (a === "va") {
    const h = aa(n > 0 ? (r / n) * 100 : 0, i),
      j = $e((c * h) / 100);
    return {
      baseLoan: c,
      upfront: j,
      loan: c + j,
      ltv: f,
      upfrontPct: h,
      upfrontLabel:
        i === "exempt"
          ? "VA funding fee (exempt)"
          : `VA funding fee (financed, ${h}%, ${i === "subsequent" ? "later use" : "first use"})`,
      annualPct: 0,
      insMonths: 0,
      insName: "",
      minDownPct: 0,
    };
  }
  if (a === "usda") {
    const h = $e((c * tt) / 100);
    return {
      baseLoan: c,
      upfront: h,
      loan: c + h,
      ltv: f,
      upfrontPct: tt,
      upfrontLabel: "USDA upfront guarantee fee (financed, 1%)",
      annualPct: ta,
      insMonths: x,
      insName: "USDA annual fee",
      minDownPct: 0,
    };
  }
  return {
    baseLoan: c,
    upfront: 0,
    loan: c,
    ltv: f,
    upfrontPct: 0,
    upfrontLabel: "",
    annualPct: 0,
    insMonths: 0,
    insName: "PMI",
    minDownPct: 0,
  };
}
const na = (a, n) => $e((a * Math.max(0, n)) / 100),
  sa = (a, n) => $e(a + n);
function at(a, n, r, s, i, c = "first") {
  const f = lt(a, n, r, i, c),
    x = ot({ principal: f.loan, annualPct: s, months: Math.round(i * 12) });
  return {
    years: i,
    loan: f.loan,
    payment: x.payment,
    totalInterest: x.totalInterest,
  };
}
function ra(a, n, r, s, i = 15, c = 30, f = "first") {
  const x = at(a, n, r, s, i, f),
    h = at(a, n, r, s, c, f);
  return {
    short: x,
    long: h,
    interestDifference: h.totalInterest - x.totalInterest,
    paymentDifference: x.payment - h.payment,
  };
}
function Ce(a) {
  const n = Math.floor(a / 12),
    r = a % 12;
  return (
    [
      n ? `${n} year${n > 1 ? "s" : ""}` : "",
      r ? `${r} month${r > 1 ? "s" : ""}` : "",
    ]
      .filter(Boolean)
      .join(" ") || "0 months"
  );
}
const it = {
    price: "400000",
    down: "20",
    downUnit: "pct",
    rate: "6.5",
    years: "30",
    tax: "1.1",
    taxUnit: "pct",
    insurance: "100",
    hoa: "0",
    pmiRate: "0.6",
    loanType: "conventional",
    vaUse: "first",
    extraMonthly: "",
    oneTime: "",
    oneTimeMonth: "1",
    closingPct: "3",
    income: "",
    firstPayment: "",
    debts: "",
    taxGrowth: "",
    insGrowth: "",
    hoaGrowth: "",
    other: "",
    yearlyExtra: "",
    yearlyExtraMonth: "12",
  },
  Ae = {
    price: "price",
    down: "down",
    downUnit: "du",
    rate: "rate",
    years: "yrs",
    tax: "tax",
    taxUnit: "tu",
    insurance: "ins",
    hoa: "hoa",
    pmiRate: "pmi",
    loanType: "type",
    vaUse: "vau",
    extraMonthly: "xm",
    oneTime: "x1",
    oneTimeMonth: "x1m",
    closingPct: "cc",
    income: "inc",
    firstPayment: "fpd",
    debts: "debts",
    taxGrowth: "tg",
    insGrowth: "ig",
    hoaGrowth: "hg",
    other: "oth",
    yearlyExtra: "xy",
    yearlyExtraMonth: "xym",
  },
  oa = /^[\d.,\s$%-]{0,14}$/,
  la = {
    downUnit: ["pct", "usd"],
    taxUnit: ["pct", "year", "month"],
    loanType: ["conventional", "fha", "va", "usda"],
    vaUse: ["first", "subsequent", "exempt"],
  };
function ia(a) {
  const n = new URLSearchParams();
  return (
    Object.keys(Ae).forEach((r) => {
      a[r] !== it[r] && n.set(Ae[r], a[r]);
    }),
    n.toString()
  );
}
function nt(a) {
  const n = new URLSearchParams(a),
    r = { ...it };
  return (
    Object.keys(Ae).forEach((s) => {
      const i = n.get(Ae[s]);
      if (i == null) return;
      const c = la[s];
      s === "firstPayment"
        ? Ge(i) && (r.firstPayment = i)
        : c
          ? c.includes(i) && (r[s] = i)
          : oa.test(i) && (r[s] = i);
    }),
    r
  );
}
const st = { front: 28, back: 36 },
  rt = { front: 31, back: 43 };
function ca(a, n, r = 0) {
  if (a == null || !(a > 0) || !Number.isFinite(n)) return null;
  const s = Number.isFinite(r) && r > 0 ? r : 0,
    i = (n / a) * 100,
    c = ((n + s) / a) * 100,
    f = 1e-9,
    x = i <= st.front + f && c <= st.back + f,
    h = !x && i <= rt.front + f && c <= rt.back + f;
  return {
    front: i,
    back: c,
    label: x ? "within" : h ? "stretch" : "above",
    message: x
      ? "Within the common 28/36 guideline."
      : h
        ? "A stretch: above 28/36 but within the 31/43 limits FHA uses as its benchmark. Some lenders approve it, many want more cushion."
        : "Above both common guidelines. Lenders are likely to ask for a lower payment, a larger down payment or less other debt.",
    maxHousing28: a * 0.28,
    maxTotalDebt36: a * 0.36,
  };
}
function wa(a, n, r, s) {
  if (!(a > 0) || !(r >= 1) || !Number.isFinite(n) || n < 0) return null;
  const i = Yt(a, n, r),
    c = i / 2,
    f = n / 100 / 26;
  let x = a,
    h = 0,
    j = 0;
  const I = Math.ceil((r * 26) / 12) + 5;
  for (; x > 0.005 && j < I;) {
    j++;
    const $ = x * f,
      P = Math.min(x, c - $);
    ((h += $), (x -= P));
  }
  const S = i * Math.round(r) - a,
    G = Math.round(r),
    T = Math.max(0, Math.round(G - (j * 14) / 30.4375)),
    re = s ? Vt(s, 14 * (j - 1)) : null,
    R = (() => {
      const $ = Math.floor(T / 12),
        P = T % 12;
      return (
        [
          $ ? `${$} year${$ === 1 ? "" : "s"}` : "",
          P ? `${P} month${P === 1 ? "" : "s"}` : "",
        ]
          .filter(Boolean)
          .join(" ") || "0 months"
      );
    })();
  return {
    payment: c,
    payments: j,
    totalInterest: h,
    monthlyInterest: S,
    interestSaved: Math.max(0, S - h),
    monthlyPayments: G,
    payoff: re,
    monthlyPayoff: s ? K(s, G - 1) : null,
    monthsSooner: T,
    yearsLabel: R,
  };
}
const se = (a) => Math.round(a * 100) / 100,
  Ee = (a, n, r) => a * Math.pow(1 + n / 100, r - 1);
function Ma(a, n) {
  const r = [];
  for (const s of a) {
    const i = Math.ceil(s.month / 12);
    r[i - 1] ||
      (r[i - 1] = {
        year: i,
        payments: 0,
        taxMonthly: 0,
        insMonthly: 0,
        hoaMonthly: 0,
        otherMonthly: 0,
        pmiMonthly: 0,
        avgMonthly: 0,
        yearTotal: 0,
      });
    const c = r[i - 1];
    (c.payments++,
      (c.yearTotal += s.payment + s.pmi),
      (c.pmiMonthly = Math.max(c.pmiMonthly, s.pmi)));
  }
  for (const s of r)
    ((s.taxMonthly = se(Ee(n.tax, n.taxGrowthPct, s.year))),
      (s.insMonthly = se(Ee(n.insurance, n.insGrowthPct, s.year))),
      (s.hoaMonthly = se(Ee(n.hoa, n.hoaGrowthPct, s.year))),
      (s.otherMonthly = se(Ee(n.other, n.insGrowthPct, s.year))),
      (s.yearTotal = se(
        s.yearTotal +
          (s.taxMonthly + s.insMonthly + s.hoaMonthly + s.otherMonthly) *
            s.payments,
      )),
      (s.avgMonthly = se(s.yearTotal / s.payments)));
  return r;
}
const da = l.lazy(() =>
    Ot(
      () => import("./MortgageExtras-Ci9ZoUPC.js"),
      __vite__mapDeps([
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
        20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37,
        38, 39, 40, 41,
      ]),
    ),
  ),
  _e = {
    what: "Estimates your full monthly mortgage payment (principal, interest, property tax, home insurance, HOA and mortgage insurance) for Conventional, FHA, VA and USDA loans, shows cash to close, the effect of extra payments, a 15-year versus 30-year comparison and how the payment compares with your income. Every schedule row, the chart and the payoff date use real calendar dates that start from your first payment date.",
    how: "Enter the home price and your down payment as a dollar amount or a percentage, then the rate and term. Property tax can be a yearly amount or a percentage of the price. If you put down less than 20%, PMI is added automatically until your balance reaches 78% of the home price. Set the first payment date to the day your first payment is due (it starts as the 1st of next month) to see the real dates in the schedule, the chart and the payoff date; it only labels the schedule and does not change the amounts.",
    tip: "A down payment of 20% or more avoids PMI, which usually costs about 0.3%–1.5% of the loan each year. Compare the total monthly cost, not just principal and interest — taxes and insurance can add hundreds of dollars.",
  },
  p = (a, n = 2) => Bt(a, "USD", n),
  Ie = "border rounded px-2 py-2 w-full bg-background text-sm";
function ma({ points: a, first: n, total: r }) {
  const h = Math.max(1, ...a.map((d) => d.balance)),
    j = Math.max(1, r),
    I = (d) => 8 + (d / j) * 304,
    S = (d) => 8 + (1 - d / h) * 102,
    G = V(n),
    T = V(K(n, Math.max(0, r - 1))),
    re = a[a.length - 1],
    R = `Chart of remaining loan balance by date. It starts at ${p(a[0]?.balance ?? 0, 0)} at the first payment in ${G} and reaches ${p(re?.balance ?? 0, 0)} at the last payment in ${T}.`,
    $ = Math.max(1.5, (304 / (a.length || 1)) * 0.7),
    P = Xt(n, r);
  return e.jsxs("figure", {
    className: "mt-3",
    "data-testid": "mg-chart",
    children: [
      e.jsxs("svg", {
        viewBox: "0 0 320 130",
        role: "img",
        "aria-label": R,
        className: "w-full text-primary",
        children: [
          a.map((d) =>
            e.jsx(
              "rect",
              {
                x: I(d.index) - $ / 2,
                y: S(d.balance),
                width: $,
                height: 110 - S(d.balance),
                fill: "currentColor",
                opacity: 0.25,
                children: e.jsx("title", {
                  children: `${d.label}: ${p(d.balance, 0)} left`,
                }),
              },
              d.index,
            ),
          ),
          e.jsx("polyline", {
            fill: "none",
            stroke: "currentColor",
            strokeWidth: 2,
            points: a.map((d) => `${I(d.index)},${S(d.balance)}`).join(" "),
          }),
          a.map((d) =>
            e.jsx(
              "circle",
              {
                cx: I(d.index),
                cy: S(d.balance),
                r: 3,
                fill: "currentColor",
                opacity: 1e-4,
                children: e.jsx("title", {
                  children: `${d.label}: ${p(d.balance, 0)} left`,
                }),
              },
              `c${d.index}`,
            ),
          ),
          P.map((d) =>
            e.jsx(
              "line",
              {
                x1: I(d.index),
                x2: I(d.index),
                y1: 110,
                y2: 113,
                stroke: "currentColor",
                opacity: 0.5,
              },
              `l${d.year}`,
            ),
          ),
          e.jsx("text", {
            x: 8,
            y: 124,
            fontSize: 9,
            fill: "currentColor",
            className: "text-muted-foreground",
            "data-testid": "mg-axis-start",
            children: G,
          }),
          P.map((d) =>
            e.jsx(
              "text",
              {
                x: I(d.index),
                y: 124,
                fontSize: 9,
                textAnchor: "middle",
                fill: "currentColor",
                className: "text-muted-foreground",
                "data-testid": "mg-axis-tick",
                children: d.year,
              },
              `t${d.year}`,
            ),
          ),
          e.jsx("text", {
            x: 312,
            y: 124,
            fontSize: 9,
            textAnchor: "end",
            fill: "currentColor",
            className: "text-muted-foreground",
            "data-testid": "mg-axis-end",
            children: T,
          }),
        ],
      }),
      e.jsx("figcaption", {
        className: "text-xs text-muted-foreground text-center",
        children: "Remaining balance over time",
      }),
    ],
  });
}
function ha() {
  const [a] = l.useState(() =>
      nt(typeof window > "u" ? "" : window.location.search),
    ),
    [n, r] = l.useState(a.price),
    [s, i] = l.useState(a.down),
    [c, f] = l.useState(a.downUnit),
    [x, h] = l.useState(a.rate),
    [j, I] = l.useState(a.years),
    [S, G] = l.useState(a.tax),
    [T, re] = l.useState(a.taxUnit),
    [R, $] = l.useState(a.insurance),
    [P, d] = l.useState(a.hoa),
    [pe, ct] = l.useState(a.pmiRate),
    [b, dt] = l.useState(a.loanType),
    [X, mt] = l.useState(a.vaUse),
    [oe, ht] = l.useState(a.extraMonthly),
    [le, xt] = l.useState(a.oneTime),
    [ye, ut] = l.useState(a.oneTimeMonth),
    [ie, pt] = l.useState(a.closingPct),
    [J, yt] = l.useState(a.income),
    [fe, ft] = l.useState(a.debts),
    [ge, gt] = l.useState(a.taxGrowth),
    [je, jt] = l.useState(a.insGrowth),
    [be, bt] = l.useState(a.hoaGrowth),
    [ve, vt] = l.useState(a.other),
    [Ne, Nt] = l.useState(a.yearlyExtra),
    [we, wt] = l.useState(a.yearlyExtraMonth),
    [Re, Mt] = l.useState(!1),
    [ce] = l.useState(() => Wt(zt(Jt()))),
    [W, Pt] = l.useState(a.firstPayment || ce),
    [Be, St] = l.useState(!1),
    [Z, Ye] = l.useState("yearly");
  l.useEffect(() => {
    try {
      const t = ia({
        price: n,
        down: s,
        downUnit: c,
        rate: x,
        years: j,
        tax: S,
        taxUnit: T,
        insurance: R,
        hoa: P,
        pmiRate: pe,
        loanType: b,
        vaUse: X,
        extraMonthly: oe,
        oneTime: le,
        oneTimeMonth: ye,
        closingPct: ie,
        income: J,
        firstPayment: W === ce ? "" : W,
        debts: fe,
        taxGrowth: ge,
        insGrowth: je,
        hoaGrowth: be,
        other: ve,
        yearlyExtra: Ne,
        yearlyExtraMonth: we,
      });
      window.history.replaceState(
        null,
        "",
        `${window.location.pathname}${t ? `?${t}` : ""}${window.location.hash}`,
      );
    } catch {}
  }, [
    n,
    s,
    c,
    x,
    j,
    S,
    T,
    R,
    P,
    pe,
    b,
    X,
    oe,
    le,
    ye,
    ie,
    J,
    W,
    ce,
    fe,
    ge,
    je,
    be,
    ve,
    Ne,
    we,
  ]);
  const v = N(n),
    B = N(x),
    A = N(j),
    Ve = N(s) ?? 0,
    L = v == null ? 0 : c === "pct" ? (v * Ve) / 100 : Ve,
    de = oe.trim() === "" ? 0 : N(oe),
    H = le.trim() === "" ? 0 : N(le),
    D = N(ye),
    ee = ie.trim() === "" ? 0 : N(ie),
    me = J.trim() === "" ? null : N(J),
    te = (t) => (t.trim() === "" ? 0 : N(t)),
    Me = te(fe),
    We = te(ge),
    ze = te(je),
    qe = te(be),
    De = te(ve),
    F = te(Ne),
    z = N(we),
    Qe = Ge(W),
    w = l.useMemo(() => Qe ?? Ge(ce), [W, ce]),
    ke =
      W.trim() !== "" && !Qe
        ? `Pick a date between ${Ze} and ${et}. Showing dates from ${ue(w)} for now.`
        : "",
    Ke = b === "fha" ? 3.5 : 0,
    o = {
      price:
        v == null || v <= 0
          ? "Enter a home price greater than 0, like 400000."
          : "",
      down:
        v != null && v > 0 && (N(s) == null || L < 0 || L >= v)
          ? "The down payment must be between 0 and the home price."
          : v != null && v > 0 && Ke > 0 && L < v * (Ke / 100) - 0.005
            ? "FHA needs at least 3.5% down."
            : "",
      rate:
        B == null || B < 0 || B > 100
          ? "Enter an interest rate between 0% and 100%."
          : "",
      years:
        A == null || A < 1 || A > 50
          ? "Enter a term between 1 and 50 years."
          : "",
      xm:
        de == null || de < 0
          ? "Enter an extra monthly amount of 0 or more."
          : "",
      x1: H == null || H < 0 ? "Enter a one-time amount of 0 or more." : "",
      x1m:
        H != null &&
        H > 0 &&
        (D == null || D < 1 || D > 600 || Math.floor(D) !== D)
          ? "Enter a month number, like 1 or 24."
          : "",
      cc:
        ee == null || ee < 0 || ee > 20
          ? "Enter closing costs between 0% and 20%."
          : "",
      debts:
        Me == null || Me < 0
          ? "Enter your other monthly debt payments as 0 or more, or leave it empty."
          : "",
      growth: [We, ze, qe].some((t) => t == null || t < 0 || t > 25)
        ? "Enter yearly increases between 0% and 25%, or leave them empty."
        : "",
      other:
        De == null || De < 0
          ? "Enter maintenance and other costs as 0 or more a month, or leave it empty."
          : "",
      xy: F == null || F < 0 ? "Enter a yearly extra amount of 0 or more." : "",
      xym:
        F != null &&
        F > 0 &&
        (z == null || z < 1 || z > 12 || Math.floor(z) !== z)
          ? "Enter a payment number from 1 to 12."
          : "",
      inc:
        (me != null && me <= 0) || (J.trim() !== "" && me == null)
          ? "Enter your gross monthly income, like 8000, or leave it empty."
          : "",
    },
    C =
      o.price ||
      o.down ||
      o.rate ||
      o.years ||
      o.xm ||
      o.x1 ||
      o.x1m ||
      o.cc ||
      o.debts ||
      o.growth ||
      o.other ||
      o.xy ||
      o.xym,
    M = ({ m: t }) =>
      t
        ? e.jsx("p", {
            role: "alert",
            className: "text-xs text-destructive mt-1",
            children: t,
          })
        : null,
    y = C ? null : lt(b, v, L, A, X),
    q = y ? y.loan : 0,
    Ue = y ? y.ltv : 0,
    k = b === "conventional",
    Pe = !C && (k ? Ue > 0.8 : y.annualPct > 0),
    U = Pe
      ? k
        ? (q * (N(pe) ?? 0)) / 100 / 12
        : (y.baseLoan * y.annualPct) / 100 / 12
      : 0,
    Tt = (de ?? 0) > 0 || (H ?? 0) > 0 || (F ?? 0) > 0,
    m = l.useMemo(
      () =>
        C
          ? null
          : ot({
              principal: q,
              annualPct: B,
              months: Math.round(A * 12),
              extra: de ?? 0,
              oneTime: (H ?? 0) > 0 ? { month: D ?? 1, amount: H } : void 0,
              yearlyExtra:
                (F ?? 0) > 0 ? { amount: F, month: z ?? 12 } : void 0,
              pmiMonthly: k ? U : 0,
              pmiDropBalance: v * 0.78,
            }),
      [C, q, B, A, U, v, k, de, H, D, F, z],
    ),
    Y = y?.insName || "PMI",
    Le = k ? (m?.pmiMonths ?? 0) : (y?.insMonths ?? 0),
    Ct = k ? (m?.totalPmi ?? 0) : U * (y?.insMonths ?? 0),
    Et = l.useMemo(() => (m ? qt(m.rows, w) : []), [m, w]),
    It = l.useMemo(() => (m ? Qt(q, m.rows, w) : []), [m, q, w]),
    ae = m && m.rows.length > 0 ? K(w, m.rows.length - 1) : null,
    Xe = C ? null : K(w, Math.round(A * 12) - 1),
    O = l.useMemo(
      () => (C ? null : ra(b, v, L, B, 15, 30, X)),
      [C, b, X, v, L, B],
    ),
    He = C ? 0 : na(v, ee ?? 0),
    Je = sa(L, He),
    Fe = N(S) ?? 0,
    he = C
      ? 0
      : T === "pct"
        ? (v * Fe) / 100 / 12
        : T === "year"
          ? Fe / 12
          : Fe,
    xe = N(R) ?? 0,
    ne = N(P) ?? 0,
    Q = C || o.other ? 0 : (De ?? 0),
    Se = (m?.payment ?? 0) + he + xe + ne + U + Q,
    _ = !C && !o.inc && !o.debts ? ca(me, Se - Q, Me ?? 0) : null,
    { gate: $t } = Rt(m),
    At = l.useCallback((t) => p(t), []),
    E = ({ label: t, v: Te, id: Ht }) =>
      e.jsxs("div", {
        className: "text-center p-3 rounded-lg border bg-card",
        children: [
          e.jsx("p", {
            className: "text-xs text-muted-foreground",
            children: t,
          }),
          e.jsx("p", {
            className: "text-sm font-bold",
            "data-testid": Ht,
            children: p(Te),
          }),
        ],
      }),
    Dt = {
      tax: he,
      insurance: xe,
      hoa: ne,
      other: Q,
      taxGrowthPct: We ?? 0,
      insGrowthPct: ze ?? 0,
      hoaGrowthPct: qe ?? 0,
    },
    kt = [
      { key: "pi", label: "Principal and interest", value: m?.payment ?? 0 },
      { key: "tax", label: "Property tax", value: he },
      { key: "ins", label: "Home insurance", value: xe },
      { key: "hoa", label: "HOA", value: ne },
      { key: "pmi", label: Y === "PMI" ? "PMI" : Y, value: U },
      { key: "other", label: "Maintenance and other", value: Q },
    ],
    Ut =
      m && y
        ? {
            price: v,
            downAmt: L,
            baseLoan: y.baseLoan,
            upfront: y.upfront,
            upfrontLabel: y.upfrontLabel,
            loan: q,
            ltv: Ue,
            annualPct: B,
            years: A,
            payment: m.payment,
            monthlyTax: he,
            monthlyIns: xe,
            monthlyHoa: ne,
            other: Q,
            pmiMonthly: U,
            insName: Y,
            pmiMonths: Le,
            total: Se,
            totalInterest: m.totalInterest,
            payoffMonths: m.payoffMonths,
            first: w,
            lastPay: ae,
            closingPct: ee ?? 0,
            closing: He,
            cash: Je,
            income: me,
            otherDebts: Me ?? 0,
            dti: _,
          }
        : null,
    Lt = k ? !1 : y ? y.insMonths >= Math.round(A * 12) : !1;
  return e.jsxs(_t, {
    children: [
      e.jsxs("div", {
        className: "max-w-md mx-auto space-y-6",
        children: [
          m &&
            e.jsxs("div", {
              className: "p-4 rounded-xl border bg-primary/5 text-center",
              "data-result": !0,
              children: [
                e.jsx("p", {
                  className: "text-xs text-muted-foreground",
                  children: "Estimated Monthly Payment",
                }),
                e.jsx("p", {
                  className: "text-2xl font-bold text-primary",
                  "data-testid": "mg-total",
                  children: p(Se),
                }),
                Pe &&
                  (Lt
                    ? e.jsxs("p", {
                        className: "text-xs text-muted-foreground mt-1",
                        "data-testid": "mg-pmi-note",
                        children: [
                          "Includes ",
                          Y === "MIP" ? "MIP" : "the USDA annual fee",
                          " of ",
                          p(U),
                          " a month for the life of the loan.",
                          b === "fha"
                            ? " With less than 10% down, FHA mortgage insurance does not drop off; refinancing into a conventional loan is the way to remove it."
                            : " It does not drop off; refinancing is the way to remove it.",
                        ],
                      })
                    : e.jsxs("p", {
                        className: "text-xs text-muted-foreground mt-1",
                        "data-testid": "mg-pmi-note",
                        children: [
                          "Includes ",
                          Y,
                          " of ",
                          p(U),
                          " for ",
                          k
                            ? `about ${Le} months (until the balance reaches 78% of the price)`
                            : `${Math.round(Le / 12)} years`,
                          ". ",
                          k ? `Without ${Y}` : "After that",
                          " the payment drops to ",
                          p(Se - U),
                          ".",
                        ],
                      })),
                b === "va" &&
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground mt-1",
                    "data-testid": "mg-va-note",
                    children:
                      "VA loans have no monthly mortgage insurance. The funding fee is financed into the loan.",
                  }),
              ],
            }),
          e.jsxs("div", {
            children: [
              e.jsx(u, { children: "Loan type" }),
              e.jsxs("select", {
                className: Ie,
                "aria-label": "Loan type",
                value: b,
                onChange: (t) => {
                  const Te = t.target.value;
                  (dt(Te),
                    Te === "fha" &&
                      c === "pct" &&
                      N(s) !== null &&
                      N(s) < 3.5 &&
                      i("3.5"));
                },
                children: [
                  e.jsx("option", {
                    value: "conventional",
                    children: "Conventional",
                  }),
                  e.jsx("option", {
                    value: "fha",
                    children: "FHA (3.5% minimum down)",
                  }),
                  e.jsx("option", {
                    value: "va",
                    children: "VA (0% minimum down)",
                  }),
                  e.jsx("option", {
                    value: "usda",
                    children: "USDA (0% minimum down)",
                  }),
                ],
              }),
              b === "va" &&
                e.jsxs("div", {
                  className: "mt-2",
                  children: [
                    e.jsx(u, {
                      className: "text-xs",
                      children: "VA funding fee",
                    }),
                    e.jsxs("select", {
                      className: Ie,
                      "aria-label": "VA funding fee use",
                      value: X,
                      onChange: (t) => mt(t.target.value),
                      children: [
                        e.jsx("option", {
                          value: "first",
                          children: "First use of the VA benefit",
                        }),
                        e.jsx("option", {
                          value: "subsequent",
                          children: "Used the benefit before",
                        }),
                        e.jsx("option", {
                          value: "exempt",
                          children: "Exempt (for example a disabled veteran)",
                        }),
                      ],
                    }),
                  ],
                }),
              b !== "conventional" &&
                e.jsxs("p", {
                  className: "text-xs text-muted-foreground mt-1",
                  children: [
                    "Fee rates shown are ",
                    Oe,
                    ". ",
                    b === "va"
                      ? "VA is for eligible veterans and service members; choose first use, later use or exempt below; some disabled veterans are exempt."
                      : b === "usda"
                        ? "USDA is for eligible rural and suburban homes and income limits apply."
                        : "",
                  ],
                }),
            ],
          }),
          e.jsxs("div", {
            children: [
              e.jsx(u, { children: "Home Price ($)" }),
              e.jsx(g, {
                inputMode: "decimal",
                "aria-label": "Home price",
                "aria-invalid": o.price ? !0 : void 0,
                value: n,
                onChange: (t) => r(t.target.value),
              }),
              e.jsx(M, { m: o.price }),
            ],
          }),
          e.jsxs("div", {
            className: "grid grid-cols-3 gap-3",
            children: [
              e.jsxs("div", {
                className: "col-span-2",
                children: [
                  e.jsx(u, { children: "Down Payment" }),
                  e.jsx(g, {
                    inputMode: "decimal",
                    "aria-label": "Down payment",
                    "aria-invalid": o.down ? !0 : void 0,
                    value: s,
                    onChange: (t) => i(t.target.value),
                  }),
                  e.jsx(M, { m: o.down }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx(u, { children: " " }),
                  e.jsxs("select", {
                    className: Ie,
                    "aria-label": "Down payment unit",
                    value: c,
                    onChange: (t) => f(t.target.value),
                    children: [
                      e.jsx("option", { value: "pct", children: "%" }),
                      e.jsx("option", { value: "usd", children: "$" }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("div", {
            className: "grid grid-cols-2 gap-3",
            children: [
              e.jsxs("div", {
                children: [
                  e.jsx(u, { children: "Interest Rate (%)" }),
                  e.jsx(g, {
                    inputMode: "decimal",
                    "aria-label": "Interest rate",
                    "aria-invalid": o.rate ? !0 : void 0,
                    value: x,
                    onChange: (t) => h(t.target.value),
                  }),
                  e.jsx(M, { m: o.rate }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx(u, { children: "Loan Term (years)" }),
                  e.jsx(g, {
                    inputMode: "decimal",
                    "aria-label": "Loan term",
                    "aria-invalid": o.years ? !0 : void 0,
                    value: j,
                    onChange: (t) => I(t.target.value),
                  }),
                  e.jsx(M, { m: o.years }),
                ],
              }),
            ],
          }),
          e.jsxs("div", {
            children: [
              e.jsx(u, {
                htmlFor: "mg-first-payment",
                children: "First payment date",
              }),
              e.jsx(g, {
                id: "mg-first-payment",
                type: "date",
                "aria-label": "First payment date",
                "aria-describedby": "mg-first-payment-help",
                min: `${Ze}-01-01`,
                max: `${et}-12-31`,
                "aria-invalid": ke ? !0 : void 0,
                value: W,
                onChange: (t) => Pt(t.target.value),
              }),
              e.jsx("p", {
                id: "mg-first-payment-help",
                className: "text-xs text-muted-foreground mt-1",
                children:
                  "The date your first payment is due, usually the 1st of the month after closing. Later payments fall on the same day each month. It only puts dates on the schedule, chart and payoff; it does not change your payment or interest, because every period is treated as a full month. Clear it to use the 1st of next month.",
              }),
              ke &&
                e.jsx("p", {
                  role: "alert",
                  className: "text-xs text-destructive mt-1",
                  children: ke,
                }),
            ],
          }),
          e.jsxs("div", {
            className: "grid grid-cols-3 gap-3",
            children: [
              e.jsxs("div", {
                className: "col-span-2",
                children: [
                  e.jsx(u, { children: "Property Tax" }),
                  e.jsx(g, {
                    inputMode: "decimal",
                    "aria-label": "Property tax",
                    value: S,
                    onChange: (t) => G(t.target.value),
                  }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx(u, { children: " " }),
                  e.jsxs("select", {
                    className: Ie,
                    "aria-label": "Property tax unit",
                    value: T,
                    onChange: (t) => re(t.target.value),
                    children: [
                      e.jsx("option", {
                        value: "pct",
                        children: "% of price / yr",
                      }),
                      e.jsx("option", { value: "year", children: "$ / year" }),
                      e.jsx("option", {
                        value: "month",
                        children: "$ / month",
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("div", {
            className: "grid grid-cols-3 gap-3",
            children: [
              e.jsxs("div", {
                children: [
                  e.jsx(u, {
                    className: "text-xs",
                    children: "Insurance ($/month)",
                  }),
                  e.jsx(g, {
                    inputMode: "decimal",
                    "aria-label": "Insurance",
                    value: R,
                    onChange: (t) => $(t.target.value),
                  }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx(u, { className: "text-xs", children: "HOA ($/month)" }),
                  e.jsx(g, {
                    inputMode: "decimal",
                    "aria-label": "HOA",
                    value: P,
                    onChange: (t) => d(t.target.value),
                  }),
                ],
              }),
              k
                ? e.jsxs("div", {
                    children: [
                      e.jsx(u, {
                        className: "text-xs",
                        children: "PMI rate (%/yr)",
                      }),
                      e.jsx(g, {
                        inputMode: "decimal",
                        "aria-label": "PMI rate",
                        value: pe,
                        onChange: (t) => ct(t.target.value),
                      }),
                    ],
                  })
                : e.jsxs("div", {
                    children: [
                      e.jsx(u, {
                        className: "text-xs",
                        children:
                          b === "fha"
                            ? "MIP rate (%/yr)"
                            : b === "usda"
                              ? "USDA fee (%/yr)"
                              : "Monthly insurance",
                      }),
                      e.jsx(g, {
                        readOnly: !0,
                        "aria-label":
                          b === "fha"
                            ? "MIP rate"
                            : b === "usda"
                              ? "USDA annual fee rate"
                              : "Monthly insurance",
                        value: y
                          ? y.annualPct > 0
                            ? String(y.annualPct)
                            : "None"
                          : "",
                      }),
                    ],
                  }),
            ],
          }),
          e.jsxs("fieldset", {
            className: "space-y-3 rounded-lg border p-3",
            children: [
              e.jsx("legend", {
                className: "text-sm font-medium px-1",
                children: "Extra payments (optional)",
              }),
              e.jsxs("div", {
                className: "grid grid-cols-2 gap-3",
                children: [
                  e.jsxs("div", {
                    children: [
                      e.jsx(u, {
                        className: "text-xs",
                        children: "Extra principal per month ($)",
                      }),
                      e.jsx(g, {
                        inputMode: "decimal",
                        "aria-label": "Extra monthly principal payment",
                        "aria-invalid": o.xm ? !0 : void 0,
                        value: oe,
                        onChange: (t) => ht(t.target.value),
                      }),
                      e.jsx(M, { m: o.xm }),
                    ],
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx(u, {
                        className: "text-xs",
                        children: "One-time extra payment ($)",
                      }),
                      e.jsx(g, {
                        inputMode: "decimal",
                        "aria-label": "One-time extra payment",
                        "aria-invalid": o.x1 ? !0 : void 0,
                        value: le,
                        onChange: (t) => xt(t.target.value),
                      }),
                      e.jsx(M, { m: o.x1 }),
                    ],
                  }),
                ],
              }),
              (H ?? 0) > 0 &&
                e.jsxs("div", {
                  children: [
                    e.jsx(u, {
                      className: "text-xs",
                      children: "One-time payment made in month #",
                    }),
                    e.jsx(g, {
                      inputMode: "numeric",
                      "aria-label": "One-time extra payment month",
                      "aria-invalid": o.x1m ? !0 : void 0,
                      value: ye,
                      onChange: (t) => ut(t.target.value),
                    }),
                    e.jsx(M, { m: o.x1m }),
                    !o.x1m &&
                      D != null &&
                      e.jsxs("p", {
                        className: "text-xs text-muted-foreground mt-1",
                        "data-testid": "mg-onetime-date",
                        children: [
                          "Payment #",
                          D,
                          " is due ",
                          ue(Kt(w, D)),
                          ".",
                        ],
                      }),
                  ],
                }),
              e.jsxs("div", {
                className: "grid grid-cols-2 gap-3",
                children: [
                  e.jsxs("div", {
                    children: [
                      e.jsx(u, {
                        className: "text-xs",
                        children: "Extra once a year ($)",
                      }),
                      e.jsx(g, {
                        inputMode: "decimal",
                        "aria-label": "Yearly extra payment",
                        "aria-invalid": o.xy ? !0 : void 0,
                        value: Ne,
                        onChange: (t) => Nt(t.target.value),
                      }),
                      e.jsx(M, { m: o.xy }),
                    ],
                  }),
                  (F ?? 0) > 0 &&
                    e.jsxs("div", {
                      children: [
                        e.jsx(u, {
                          className: "text-xs",
                          children: "Paid with payment # (1-12) each year",
                        }),
                        e.jsx(g, {
                          inputMode: "numeric",
                          "aria-label": "Yearly extra payment month",
                          "aria-invalid": o.xym ? !0 : void 0,
                          value: we,
                          onChange: (t) => wt(t.target.value),
                        }),
                        e.jsx(M, { m: o.xym }),
                      ],
                    }),
                ],
              }),
            ],
          }),
          e.jsxs("fieldset", {
            className: "space-y-3 rounded-lg border p-3",
            children: [
              e.jsx("legend", {
                className: "text-sm font-medium px-1",
                children: "Costs that rise over time (optional)",
              }),
              e.jsxs("div", {
                className: "grid grid-cols-3 gap-3",
                children: [
                  e.jsxs("div", {
                    children: [
                      e.jsx(u, {
                        className: "text-xs",
                        children: "Property tax increase (%/yr)",
                      }),
                      e.jsx(g, {
                        inputMode: "decimal",
                        "aria-label": "Property tax yearly increase",
                        value: ge,
                        onChange: (t) => gt(t.target.value),
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx(u, {
                        className: "text-xs",
                        children: "Insurance increase (%/yr)",
                      }),
                      e.jsx(g, {
                        inputMode: "decimal",
                        "aria-label": "Insurance yearly increase",
                        value: je,
                        onChange: (t) => jt(t.target.value),
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx(u, {
                        className: "text-xs",
                        children: "HOA increase (%/yr)",
                      }),
                      e.jsx(g, {
                        inputMode: "decimal",
                        "aria-label": "HOA yearly increase",
                        value: be,
                        onChange: (t) => bt(t.target.value),
                      }),
                    ],
                  }),
                ],
              }),
              e.jsx(M, { m: o.growth }),
              e.jsxs("div", {
                children: [
                  e.jsx(u, {
                    className: "text-xs",
                    children: "Maintenance and other costs ($/month)",
                  }),
                  e.jsx(g, {
                    inputMode: "decimal",
                    "aria-label": "Maintenance and other monthly costs",
                    "aria-invalid": o.other ? !0 : void 0,
                    value: ve,
                    onChange: (t) => vt(t.target.value),
                  }),
                  e.jsx(M, { m: o.other }),
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground mt-1",
                    children:
                      "Repairs, utilities or anything else you want in the monthly total. It rises with the insurance percentage and is not counted in the debt ratios.",
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("div", {
            className: "grid grid-cols-2 gap-3",
            children: [
              e.jsxs("div", {
                children: [
                  e.jsx(u, {
                    className: "text-xs",
                    children: "Closing costs (% of price)",
                  }),
                  e.jsx(g, {
                    inputMode: "decimal",
                    "aria-label": "Closing costs percent",
                    "aria-invalid": o.cc ? !0 : void 0,
                    value: ie,
                    onChange: (t) => pt(t.target.value),
                  }),
                  e.jsx(M, { m: o.cc }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx(u, {
                    className: "text-xs",
                    children: "Gross monthly income ($, optional)",
                  }),
                  e.jsx(g, {
                    inputMode: "decimal",
                    "aria-label": "Gross monthly income",
                    "aria-invalid": o.inc ? !0 : void 0,
                    value: J,
                    onChange: (t) => yt(t.target.value),
                  }),
                  e.jsx(M, { m: o.inc }),
                ],
              }),
            ],
          }),
          e.jsxs("div", {
            children: [
              e.jsx(u, {
                className: "text-xs",
                children: "Other monthly debts ($, for the debt ratio)",
              }),
              e.jsx(g, {
                inputMode: "decimal",
                "aria-label": "Other monthly debts",
                "aria-invalid": o.debts ? !0 : void 0,
                value: fe,
                onChange: (t) => ft(t.target.value),
              }),
              e.jsx(M, { m: o.debts }),
              e.jsx("p", {
                className: "text-xs text-muted-foreground mt-1",
                children:
                  "Car, credit card minimums, student loans. Used with your income above.",
              }),
            ],
          }),
          e.jsxs("label", {
            className: "flex items-center gap-2 text-sm",
            children: [
              e.jsx("input", {
                type: "checkbox",
                checked: Re,
                onChange: (t) => Mt(t.target.checked),
                "aria-label": "Compare biweekly payments",
              }),
              "Compare paying half every 2 weeks (biweekly)",
            ],
          }),
          C &&
            e.jsx("p", {
              className: "text-sm text-red-600",
              "data-testid": "mg-error",
              children: "Fix the highlighted fields to see your payment.",
            }),
          m &&
            y &&
            e.jsxs(e.Fragment, {
              children: [
                e.jsxs("div", {
                  className: "grid grid-cols-2 gap-3",
                  "data-result": !0,
                  children: [
                    e.jsx(E, {
                      label: "Principal & interest",
                      v: m.payment,
                      id: "mg-pi",
                    }),
                    e.jsx(E, { label: "Property tax", v: he }),
                    e.jsx(E, { label: "Home insurance", v: xe }),
                    Q > 0 && e.jsx(E, { label: "Maintenance and other", v: Q }),
                    ne > 0 && e.jsx(E, { label: "HOA", v: ne }),
                    Pe && e.jsx(E, { label: Y, v: U, id: "mg-pmi" }),
                    y.upfront > 0 &&
                      e.jsx(E, { label: y.upfrontLabel, v: y.upfront }),
                    e.jsx(E, {
                      label: `Loan amount (${(Ue * 100).toFixed(1)}% of price)`,
                      v: q,
                    }),
                    e.jsx(E, {
                      label: "Total interest paid",
                      v: m.totalInterest,
                    }),
                    Pe && e.jsx(E, { label: `Total ${Y} paid`, v: Ct }),
                    e.jsx(E, { label: "Down payment", v: L }),
                    e.jsx(E, {
                      label: `Closing costs (${ee ?? 0}%)`,
                      v: He,
                      id: "mg-closing",
                    }),
                    e.jsxs("div", {
                      className:
                        "col-span-2 text-center p-3 rounded-lg border bg-card",
                      children: [
                        e.jsx("p", {
                          className: "text-xs text-muted-foreground",
                          children:
                            "Cash to close (down payment + closing costs)",
                        }),
                        e.jsx("p", {
                          className: "text-lg font-bold",
                          "data-testid": "mg-cash",
                          children: p(Je),
                        }),
                      ],
                    }),
                    ae &&
                      e.jsxs(Ft, {
                        className: "col-span-2 text-center",
                        testId: "mg-payoff",
                        children: [
                          e.jsx("p", {
                            className: "text-xs text-muted-foreground",
                            children: "Payoff",
                          }),
                          e.jsx("p", {
                            className: "text-lg font-bold",
                            "data-testid": "mg-payoff-date",
                            children: V(ae),
                          }),
                          e.jsxs("p", {
                            className: "text-xs text-muted-foreground",
                            "data-testid": "mg-payoff-detail",
                            children: [
                              "First payment ",
                              ue(w),
                              ". Last payment ",
                              ue(ae),
                              ".",
                            ],
                          }),
                        ],
                      }),
                    Tt &&
                      e.jsxs("div", {
                        className:
                          "col-span-2 text-center p-3 rounded-lg border bg-card",
                        "data-testid": "mg-extra-result",
                        children: [
                          e.jsx("p", {
                            className: "text-xs text-muted-foreground",
                            children: "With your extra payments",
                          }),
                          e.jsxs("p", {
                            className: "text-sm font-bold",
                            children: [
                              "Paid off ",
                              Ce(m.monthsSaved),
                              " sooner, ",
                              p(m.interestSaved, 0),
                              " less interest",
                            ],
                          }),
                          e.jsxs("p", {
                            className: "text-xs text-muted-foreground",
                            children: [
                              "Payoff in ",
                              Ce(m.payoffMonths),
                              " instead of ",
                              Ce(Math.round(A * 12)),
                              ".",
                            ],
                          }),
                          ae &&
                            Xe &&
                            e.jsxs("p", {
                              className: "text-xs text-muted-foreground",
                              "data-testid": "mg-extra-dates",
                              children: [
                                "New payoff date ",
                                V(ae),
                                " instead of ",
                                V(Xe),
                                m.monthsSaved > 0
                                  ? `, ${Ce(m.monthsSaved)} saved`
                                  : "",
                                ".",
                              ],
                            }),
                        ],
                      }),
                  ],
                }),
                e.jsxs("p", {
                  className: "text-xs text-muted-foreground text-center -mt-3",
                  children: ["Program fees: ", Oe, "."],
                }),
                _ &&
                  e.jsxs("div", {
                    className: "rounded-lg border p-3 text-sm",
                    "data-testid": "mg-income",
                    "data-result": !0,
                    children: [
                      e.jsxs("p", {
                        children: [
                          "Housing is ",
                          e.jsxs("strong", {
                            "data-testid": "mg-front",
                            children: [_.front.toFixed(1), "%"],
                          }),
                          " of your gross monthly income (front-end, guideline 28%). With your other monthly debts the total is ",
                          e.jsxs("strong", {
                            "data-testid": "mg-back",
                            children: [_.back.toFixed(1), "%"],
                          }),
                          " (back-end, guideline 36%).",
                        ],
                      }),
                      e.jsxs("p", {
                        className: "mt-1",
                        "data-testid": "mg-dti-label",
                        children: [
                          e.jsxs("strong", {
                            children: [
                              _.label === "within"
                                ? "Within 28/36"
                                : _.label === "stretch"
                                  ? "A stretch"
                                  : "Above the guidelines",
                              ".",
                            ],
                          }),
                          " ",
                          _.message,
                        ],
                      }),
                      e.jsxs("p", {
                        className: "text-xs text-muted-foreground mt-1",
                        children: [
                          "At your income, 28% is about ",
                          p(_.maxHousing28, 0),
                          " a month for housing and 36% is about ",
                          p(_.maxTotalDebt36, 0),
                          " a month for housing and all other debts together. These ratios are common guidelines, not a lender decision; limits vary by lender and loan type.",
                        ],
                      }),
                    ],
                  }),
                O &&
                  e.jsxs("div", {
                    className: "rounded-lg border overflow-hidden",
                    "data-testid": "mg-compare",
                    "data-result": !0,
                    children: [
                      e.jsx("p", {
                        className: "text-sm font-medium p-3 pb-1",
                        children: "15-year vs 30-year, same rate and price",
                      }),
                      e.jsxs("table", {
                        className: "w-full text-xs",
                        children: [
                          e.jsx("thead", {
                            children: e.jsxs("tr", {
                              className: "bg-muted",
                              children: [
                                e.jsx("th", { className: "p-2 text-left" }),
                                e.jsx("th", {
                                  className: "p-2 text-right",
                                  children: "15 years",
                                }),
                                e.jsx("th", {
                                  className: "p-2 text-right",
                                  children: "30 years",
                                }),
                              ],
                            }),
                          }),
                          e.jsxs("tbody", {
                            children: [
                              e.jsxs("tr", {
                                className: "border-t",
                                children: [
                                  e.jsx("td", {
                                    className: "p-2",
                                    children: "Monthly P&I",
                                  }),
                                  e.jsx("td", {
                                    className: "p-2 text-right",
                                    children: p(O.short.payment),
                                  }),
                                  e.jsx("td", {
                                    className: "p-2 text-right",
                                    children: p(O.long.payment),
                                  }),
                                ],
                              }),
                              e.jsxs("tr", {
                                className: "border-t",
                                children: [
                                  e.jsxs("td", {
                                    className: "p-2",
                                    children: ["Payoff (from ", V(w), ")"],
                                  }),
                                  e.jsx("td", {
                                    className: "p-2 text-right",
                                    "data-testid": "mg-compare-payoff-15",
                                    children: V(K(w, O.short.years * 12 - 1)),
                                  }),
                                  e.jsx("td", {
                                    className: "p-2 text-right",
                                    "data-testid": "mg-compare-payoff-30",
                                    children: V(K(w, O.long.years * 12 - 1)),
                                  }),
                                ],
                              }),
                              e.jsxs("tr", {
                                className: "border-t",
                                children: [
                                  e.jsx("td", {
                                    className: "p-2",
                                    children: "Total interest",
                                  }),
                                  e.jsx("td", {
                                    className: "p-2 text-right",
                                    children: p(O.short.totalInterest, 0),
                                  }),
                                  e.jsx("td", {
                                    className: "p-2 text-right",
                                    children: p(O.long.totalInterest, 0),
                                  }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      }),
                      e.jsxs("p", {
                        className: "text-xs text-muted-foreground p-3 pt-2",
                        children: [
                          "The 15-year loan costs ",
                          p(O.paymentDifference, 0),
                          " more a month and saves about ",
                          p(O.interestDifference, 0),
                          " in interest. Both use your rate; 15-year rates are often lower. Extra payments are not included here.",
                        ],
                      }),
                    ],
                  }),
                e.jsxs("div", {
                  children: [
                    e.jsx("div", {
                      className: "flex items-center justify-between",
                      children: e.jsxs("button", {
                        type: "button",
                        className: "text-sm underline",
                        onClick: () => St((t) => !t),
                        children: [
                          Be ? "Hide" : "Show",
                          " amortization schedule",
                        ],
                      }),
                    }),
                    Be &&
                      e.jsxs(e.Fragment, {
                        children: [
                          e.jsxs("div", {
                            className: "flex gap-2 mt-2",
                            role: "group",
                            "aria-label": "Schedule view",
                            children: [
                              e.jsx("button", {
                                type: "button",
                                "aria-pressed": Z === "yearly",
                                className: `text-xs px-3 py-1 rounded border ${Z === "yearly" ? "bg-primary text-primary-foreground" : ""}`,
                                onClick: () => Ye("yearly"),
                                children: "Yearly",
                              }),
                              e.jsx("button", {
                                type: "button",
                                "aria-pressed": Z === "monthly",
                                className: `text-xs px-3 py-1 rounded border ${Z === "monthly" ? "bg-primary text-primary-foreground" : ""}`,
                                onClick: () => Ye("monthly"),
                                children: "Monthly",
                              }),
                            ],
                          }),
                          e.jsx(ma, {
                            points: It,
                            first: w,
                            total: m.rows.length,
                          }),
                          e.jsx("div", {
                            className:
                              "mt-2 max-h-80 overflow-auto rounded-lg border",
                            children: e.jsxs("table", {
                              className: "w-full text-xs",
                              children: [
                                e.jsx("thead", {
                                  className: "sticky top-0 bg-muted",
                                  children: e.jsxs("tr", {
                                    children: [
                                      Z === "yearly"
                                        ? e.jsx("th", {
                                            className: "p-2 text-left",
                                            children: "Year",
                                          })
                                        : e.jsxs(e.Fragment, {
                                            children: [
                                              e.jsx("th", {
                                                className: "p-2 text-left",
                                                children: "#",
                                              }),
                                              e.jsx("th", {
                                                className: "p-2 text-left",
                                                children: "Date",
                                              }),
                                            ],
                                          }),
                                      e.jsx("th", {
                                        className: "p-2 text-right",
                                        children: "Principal",
                                      }),
                                      e.jsx("th", {
                                        className: "p-2 text-right",
                                        children: "Interest",
                                      }),
                                      e.jsx("th", {
                                        className: "p-2 text-right",
                                        children: "Balance",
                                      }),
                                    ],
                                  }),
                                }),
                                e.jsx("tbody", {
                                  children:
                                    Z === "yearly"
                                      ? Et.map((t) =>
                                          e.jsxs(
                                            "tr",
                                            {
                                              className: "border-t",
                                              children: [
                                                e.jsxs("td", {
                                                  className: "p-2",
                                                  children: [
                                                    t.year,
                                                    t.payments < 12 &&
                                                      e.jsxs("span", {
                                                        className:
                                                          "text-muted-foreground",
                                                        children: [
                                                          " (",
                                                          t.payments,
                                                          " ",
                                                          t.payments === 1
                                                            ? "payment"
                                                            : "payments",
                                                          ")",
                                                        ],
                                                      }),
                                                  ],
                                                }),
                                                e.jsx("td", {
                                                  className: "p-2 text-right",
                                                  children: p(t.principal, 0),
                                                }),
                                                e.jsx("td", {
                                                  className: "p-2 text-right",
                                                  children: p(t.interest, 0),
                                                }),
                                                e.jsx("td", {
                                                  className: "p-2 text-right",
                                                  children: p(t.balance, 0),
                                                }),
                                              ],
                                            },
                                            t.year,
                                          ),
                                        )
                                      : m.rows.map((t) =>
                                          e.jsxs(
                                            "tr",
                                            {
                                              className: "border-t",
                                              children: [
                                                e.jsx("td", {
                                                  className: "p-2",
                                                  children: t.month,
                                                }),
                                                e.jsx("td", {
                                                  className:
                                                    "p-2 whitespace-nowrap",
                                                  children: ue(
                                                    K(w, t.month - 1),
                                                  ),
                                                }),
                                                e.jsx("td", {
                                                  className: "p-2 text-right",
                                                  children: p(
                                                    t.principal + t.extra,
                                                    2,
                                                  ),
                                                }),
                                                e.jsx("td", {
                                                  className: "p-2 text-right",
                                                  children: p(t.interest, 2),
                                                }),
                                                e.jsx("td", {
                                                  className: "p-2 text-right",
                                                  children: p(t.balance, 2),
                                                }),
                                              ],
                                            },
                                            t.month,
                                          ),
                                        ),
                                }),
                              ],
                            }),
                          }),
                        ],
                      }),
                  ],
                }),
                e.jsx(l.Suspense, {
                  fallback: e.jsx("p", {
                    className: "text-sm text-muted-foreground",
                    role: "status",
                    children: "Loading breakdown and working...",
                  }),
                  children: e.jsx(da, {
                    d: Ut,
                    res: m,
                    first: w,
                    money: At,
                    gate: $t,
                    growth: Dt,
                    parts: kt,
                    biweeklyOn: Re,
                  }),
                }),
              ],
            }),
          e.jsxs("p", {
            className: "text-xs text-muted-foreground text-center",
            children: [
              "Estimate only. Conventional PMI ends here when the balance reaches 78% of the original price; lenders may differ. FHA figures use the standard HUD insurance table (1.75% upfront, financed; annual MIP by down payment and term) for loans within the standard limit. VA and USDA fees are ",
              Oe,
              ". Rates, taxes and insurance vary by lender and location. The page address updates with your numbers so you can copy it and share it; nothing is stored.",
            ],
          }),
        ],
      }),
      e.jsx(Gt, { whatIsIt: _e.what, howToUse: _e.how, tip: _e.tip }),
    ],
  });
}
const Pa = Object.freeze(
  Object.defineProperty({ __proto__: null, default: ha }, Symbol.toStringTag, {
    value: "Module",
  }),
);
export { Pa as M, wa as b, Ma as c, se as r };
//# sourceMappingURL=MortgageCalculator-93FcJ1dd.js.map
