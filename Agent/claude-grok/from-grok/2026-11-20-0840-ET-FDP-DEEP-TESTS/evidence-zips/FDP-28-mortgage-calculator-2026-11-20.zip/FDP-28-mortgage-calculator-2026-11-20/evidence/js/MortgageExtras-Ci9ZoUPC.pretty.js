import { r as p, j as n } from "./vendor-react-D01g8YgM.js";
import { C as v } from "./CalcSteps-CMhW1YVy.js";
import { C as $, R as N } from "./ResultsTable-CpxaKI_z.js";
import { r as C, E as T } from "./history-B6kbrtr3.js";
import { C as H } from "./CalcHistory-B9VfOON0.js";
import { s as I } from "./steps-X1Sejec4.js";
import { a as A, t as F } from "./table-CJAX3ymv.js";
import { c as M, f, y as R, b as S, j as L } from "./paymentDates-4j4nTGxO.js";
import { r as c, b as D, c as E } from "./MortgageCalculator-93FcJ1dd.js";
import "./index-B1CTyGtY.js";
import "./csv-DBvSFDe9.js";
import "./copy-DcUvE8ta.js";
import "./share-2-B4TSO3Yd.js";
import "./dates-DoPZ1fRV.js";
import "./ToolPage-DwLoDncN.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./ToolInfoSection-C0i6Zbwo.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./useLogToolUsage-BdvvKW0n.js";
import "./copyText-DPnES92p.js";
import "./numberInput-5hjoxJ5z.js";
import "./money-Dkxewa8a.js";
import "./loan-CAZoObwd.js";
function O(e) {
  return [
    { key: "year", header: "Loan year", get: (t) => t.year, align: "left" },
    {
      key: "tax",
      header: "Property tax / month",
      get: (t) => t.taxMonthly,
      format: (t) => e(t.taxMonthly),
      align: "right",
    },
    {
      key: "ins",
      header: "Insurance / month",
      get: (t) => t.insMonthly,
      format: (t) => e(t.insMonthly),
      align: "right",
    },
    {
      key: "hoa",
      header: "HOA / month",
      get: (t) => t.hoaMonthly,
      format: (t) => e(t.hoaMonthly),
      align: "right",
    },
    {
      key: "other",
      header: "Maintenance and other / month",
      get: (t) => t.otherMonthly,
      format: (t) => e(t.otherMonthly),
      align: "right",
    },
    {
      key: "pmi",
      header: "Mortgage insurance / month",
      get: (t) => t.pmiMonthly,
      format: (t) => e(t.pmiMonthly),
      align: "right",
    },
    {
      key: "avg",
      header: "Average total / month",
      get: (t) => t.avgMonthly,
      format: (t) => e(t.avgMonthly),
      align: "right",
    },
    {
      key: "total",
      header: "Total for the year",
      get: (t) => t.yearTotal,
      format: (t) => e(t.yearTotal),
      align: "right",
    },
  ];
}
function B(e) {
  const t = [];
  for (const o of e) {
    const a = Math.ceil(o.month / 12);
    t[a - 1] ||
      (t[a - 1] = {
        year: a,
        payments: 0,
        principal: 0,
        interest: 0,
        extra: 0,
        balance: 0,
      });
    const r = t[a - 1];
    (r.payments++,
      (r.principal += o.principal),
      (r.interest += o.interest),
      (r.extra += o.extra),
      (r.balance = o.balance));
  }
  return t;
}
function G(e, t) {
  const o = B(e).map((r) => ({
      type: "Year",
      period: r.year,
      date: "",
      principal: c(r.principal),
      interest: c(r.interest),
      extra: c(r.extra),
      pmi: c(
        e
          .filter((l) => Math.ceil(l.month / 12) === r.year)
          .reduce((l, h) => l + h.pmi, 0),
      ),
      balance: c(r.balance),
    })),
    a = e.map((r) => ({
      type: "Month",
      period: r.month,
      date: R(S(t, r.month - 1)),
      principal: c(r.principal),
      interest: c(r.interest),
      extra: c(r.extra),
      pmi: c(r.pmi),
      balance: c(r.balance),
    }));
  return [...o, ...a];
}
const Y = [
  { key: "type", header: "Row type", get: (e) => e.type },
  { key: "period", header: "Loan year or month", get: (e) => e.period },
  { key: "date", header: "Payment date", get: (e) => e.date },
  { key: "principal", header: "Principal", get: (e) => e.principal },
  { key: "interest", header: "Interest", get: (e) => e.interest },
  { key: "extra", header: "Extra principal", get: (e) => e.extra },
  { key: "pmi", header: "Mortgage insurance", get: (e) => e.pmi },
  { key: "balance", header: "Remaining balance", get: (e) => e.balance },
];
function W(e) {
  const t = e.filter((a) => a.value > 0.005),
    o = t.reduce((a, r) => a + r.value, 0);
  return t.map((a) => ({ ...a, pct: o > 0 ? (a.value / o) * 100 : 0 }));
}
const g = (e) => `${+e.toFixed(4)}%`;
function _(e, t) {
  const o = e.annualPct / 100 / 12,
    a = [
      {
        label: "Loan amount",
        formula:
          e.upfront > 0
            ? "Home price - down payment + the upfront fee that is financed into the loan"
            : "Home price - down payment",
        inputs: {
          "Home price": t(e.price),
          "Down payment": t(e.downAmt),
          ...(e.upfront > 0 ? { [e.upfrontLabel]: t(e.upfront) } : {}),
        },
        result: t(e.loan),
      },
      {
        label: "Monthly interest rate",
        formula: "Annual rate / 100 / 12",
        inputs: { "Annual rate": g(e.annualPct) },
        result: String(+o.toFixed(8)),
      },
      {
        label: "Principal and interest",
        formula:
          o === 0
            ? "Loan amount / number of payments (the rate is 0)"
            : "Loan amount x rate / (1 - (1 + rate) ^ -payments)",
        inputs: {
          "Loan amount": t(e.loan),
          "Monthly rate": String(+o.toFixed(8)),
          Payments: Math.round(e.years * 12),
        },
        result: t(e.payment),
      },
      {
        label: "Property tax, insurance and HOA",
        formula: "Each yearly amount / 12, then added as monthly amounts",
        inputs: {
          "Property tax": t(e.monthlyTax),
          Insurance: t(e.monthlyIns),
          HOA: t(e.monthlyHoa),
          ...(e.other > 0 ? { "Maintenance and other": t(e.other) } : {}),
        },
        result: t(e.monthlyTax + e.monthlyIns + e.monthlyHoa),
      },
    ];
  return (
    e.pmiMonthly > 0 &&
      a.push({
        label:
          e.insName === "PMI"
            ? "Private mortgage insurance"
            : e.insName === "MIP"
              ? "FHA mortgage insurance premium"
              : "Mortgage insurance",
        formula: "Yearly rate x loan amount / 12, charged while it applies",
        inputs: { "Loan amount": t(e.loan), "Loan to value": g(e.ltv * 100) },
        result: `${t(e.pmiMonthly)} a month${e.pmiMonths > 0 ? ` for ${e.pmiMonths} months` : ""}`,
      }),
    a.push({
      label: "Estimated monthly payment",
      formula:
        "Principal and interest + property tax + insurance + HOA + mortgage insurance",
      inputs: {
        "Principal and interest": t(e.payment),
        "Tax, insurance and HOA": t(e.monthlyTax + e.monthlyIns + e.monthlyHoa),
        "Mortgage insurance": t(e.pmiMonthly),
      },
      result: t(e.total),
    }),
    a.push({
      label: "Total interest",
      formula: "Add up the interest part of every payment in the schedule",
      inputs: { Payments: e.payoffMonths },
      result: t(e.totalInterest),
    }),
    e.lastPay &&
      a.push({
        label: "Payoff date",
        formula: "The first payment date plus (number of payments - 1) months",
        inputs: { "First payment": f(e.first), Payments: e.payoffMonths },
        result: M(e.lastPay),
      }),
    a.push({
      label: "Cash to close",
      formula:
        "Down payment + closing costs (closing costs = home price x closing percent)",
      inputs: {
        "Down payment": t(e.downAmt),
        "Closing costs": `${t(e.closing)} (${g(e.closingPct)})`,
      },
      result: t(e.cash),
    }),
    e.dti &&
      (a.push({
        label: "Front-end ratio",
        formula: "Monthly housing payment / gross monthly income",
        inputs: {
          Housing: t(e.total),
          "Gross monthly income": t(e.income ?? 0),
        },
        result: `${e.dti.front.toFixed(1)}%`,
      }),
      a.push({
        label: "Back-end ratio",
        formula:
          "(Monthly housing payment + other monthly debts) / gross monthly income",
        inputs: {
          Housing: t(e.total),
          "Other monthly debts": t(e.otherDebts),
          "Gross monthly income": t(e.income ?? 0),
        },
        result: `${e.dti.back.toFixed(1)}% (${e.dti.label === "within" ? "within 28/36" : e.dti.label === "stretch" ? "a stretch against 28/36" : "above 28/36 and 31/43"})`,
      })),
    a
  );
}
function z(e, t, o, a, r) {
  return `${r(e)} home at ${g(t)} for ${o} years: ${r(a)}/month`;
}
const d = ["#2563eb", "#d97706", "#059669", "#7c3aed", "#dc2626", "#0891b2"];
function K({ parts: e, total: t, money: o }) {
  const a = W(e),
    r = 42,
    l = 2 * Math.PI * r;
  let h = 0;
  const x = `Donut chart of the monthly payment of ${o(t)}: ${a.map((i) => `${i.label} ${o(i.value)} (${i.pct.toFixed(1)}%)`).join(", ")}.`;
  return n.jsxs("figure", {
    className: "flex flex-col sm:flex-row items-center gap-4",
    "data-testid": "mg-donut",
    children: [
      n.jsxs("svg", {
        viewBox: "0 0 120 120",
        role: "img",
        "aria-label": x,
        className: "w-36 h-36 shrink-0",
        children: [
          n.jsx("g", {
            transform: "rotate(-90 60 60)",
            children: a.map((i, s) => {
              const y = (i.pct / 100) * l,
                u = n.jsx(
                  "circle",
                  {
                    cx: "60",
                    cy: "60",
                    r,
                    fill: "none",
                    stroke: d[s % d.length],
                    strokeWidth: "16",
                    strokeDasharray: `${y} ${l - y}`,
                    strokeDashoffset: -h,
                    children: n.jsx("title", {
                      children: `${i.label}: ${o(i.value)} (${i.pct.toFixed(1)}%)`,
                    }),
                  },
                  i.key,
                );
              return ((h += y), u);
            }),
          }),
          n.jsx("text", {
            x: "60",
            y: "64",
            textAnchor: "middle",
            fontSize: "11",
            fontWeight: "700",
            fill: "currentColor",
            children: o(t),
          }),
        ],
      }),
      n.jsxs("figcaption", {
        className: "text-sm w-full",
        children: [
          n.jsx("p", {
            className: "font-medium mb-1",
            children: "Where each month's payment goes",
          }),
          n.jsx("ul", {
            className: "space-y-1",
            children: a.map((i, s) =>
              n.jsxs(
                "li",
                {
                  className: "flex items-center gap-2",
                  "data-testid": "mg-donut-item",
                  children: [
                    n.jsx("span", {
                      "aria-hidden": "true",
                      className: "inline-block h-3 w-3 rounded-sm",
                      style: { background: d[s % d.length] },
                    }),
                    n.jsx("span", { className: "flex-1", children: i.label }),
                    n.jsx("span", { children: o(i.value) }),
                    n.jsxs("span", {
                      className: "text-muted-foreground w-14 text-right",
                      children: [i.pct.toFixed(1), "%"],
                    }),
                  ],
                },
                i.key,
              ),
            ),
          }),
        ],
      }),
    ],
  });
}
function Re({
  d: e,
  res: t,
  first: o,
  money: a,
  gate: r,
  growth: l,
  parts: h,
  biweeklyOn: x,
}) {
  const i = p.useMemo(() => _(e, a), [e, a]),
    s = p.useMemo(
      () => D(e.loan, e.annualPct, Math.round(e.years * 12), o),
      [e.loan, e.annualPct, e.years, o],
    ),
    y = p.useMemo(() => E(t.rows, l), [t.rows, l]),
    u = p.useMemo(() => O(a), [a]),
    w =
      l.taxGrowthPct > 0 ||
      l.insGrowthPct > 0 ||
      l.hoaGrowthPct > 0 ||
      l.other > 0,
    j = p.useMemo(() => G(t.rows, o), [t.rows, o]),
    k = p.useMemo(() => L(t.rows, o), [t, o]),
    b = z(e.price, e.annualPct, e.years, e.total, a);
  p.useEffect(() => {
    const m = setTimeout(() => C("mortgage-calculator", b), 800);
    return () => clearTimeout(m);
  }, [b]);
  const P = [
    "Mortgage estimate",
    b,
    "",
    "How this was calculated",
    I(i),
    "",
    ...(s
      ? [
          "Biweekly payments (principal and interest only)",
          `${a(s.payment)} every 2 weeks: ${s.payments} payments, interest ${a(s.totalInterest)} vs ${a(s.monthlyInterest)} monthly, ${a(s.interestSaved)} saved${s.payoff ? `, paid off ${f(s.payoff)} instead of ${f(s.monthlyPayoff)}` : ""}`,
          "",
        ]
      : []),
    ...(w ? ["Monthly cost by loan year", A(y, u), ""] : []),
    "Yearly schedule",
    [
      "Year	Principal	Interest	Balance",
      ...k.map(
        (m) => `${m.year}	${a(m.principal)}	${a(m.interest)}	${a(m.balance)}`,
      ),
    ].join(`
`),
    "",
    "Estimate only. Confirm with your lender. Calculated with FreeDailyPro.com",
  ].join(`
`);
  return n.jsxs("div", {
    className: "space-y-6 calc-print-area",
    children: [
      n.jsx("style", { children: $ }),
      n.jsx("section", {
        "aria-label": "Payment breakdown",
        className: "rounded-xl border bg-card p-4",
        children: n.jsx(K, { parts: h, total: e.total, money: a }),
      }),
      n.jsx(v, { steps: i }),
      x &&
        s &&
        n.jsxs("section", {
          "aria-label": "Biweekly payments",
          className: "rounded-xl border bg-card p-4 space-y-2",
          "data-testid": "mg-biweekly",
          children: [
            n.jsx("h3", {
              className: "text-base font-semibold",
              children: "Biweekly payments",
            }),
            n.jsxs("p", {
              className: "text-sm",
              children: [
                "Paying ",
                n.jsx("strong", { children: a(s.payment) }),
                " (half of the ",
                a(e.payment),
                " principal and interest) every 2 weeks means 26 half-payments, the same as 13 monthly payments a year.",
              ],
            }),
            n.jsxs("ul", {
              className: "text-sm space-y-1",
              children: [
                n.jsxs("li", {
                  children: [
                    "Paid off in ",
                    n.jsx("strong", { children: s.payments }),
                    " biweekly payments",
                    s.payoff
                      ? n.jsxs(n.Fragment, {
                          children: [
                            " on ",
                            n.jsx("strong", {
                              "data-testid": "mg-bw-payoff",
                              children: f(s.payoff),
                            }),
                            " instead of ",
                            M(s.monthlyPayoff),
                          ],
                        })
                      : "",
                    ", about ",
                    s.yearsLabel,
                    " sooner.",
                  ],
                }),
                n.jsxs("li", {
                  children: [
                    "Interest ",
                    n.jsx("strong", { children: a(s.totalInterest) }),
                    " instead of ",
                    a(s.monthlyInterest),
                    ": ",
                    n.jsx("strong", {
                      "data-testid": "mg-bw-saved",
                      children: a(s.interestSaved),
                    }),
                    " saved.",
                  ],
                }),
              ],
            }),
            n.jsx("p", {
              className: "text-xs text-muted-foreground",
              children:
                "Model: interest builds up every 14 days at the yearly rate / 26, and each payment is posted when made. Principal and interest only, compared with the plain monthly schedule (your extra payments are not included). Many servicers hold biweekly payments and post them monthly, which saves less, and some charge a fee for a biweekly plan. Ask your lender before you start.",
            }),
          ],
        }),
      w &&
        n.jsxs("section", {
          "aria-label": "Monthly cost by year",
          className: "space-y-2",
          "data-testid": "mg-cost-growth",
          children: [
            n.jsx("h3", {
              className: "text-base font-semibold",
              children: "How the monthly cost changes each year",
            }),
            n.jsx("p", {
              className: "text-xs text-muted-foreground",
              children:
                "Principal and interest stay fixed. Property tax, insurance, HOA and maintenance rise by the percentages you entered at the start of each loan year (maintenance and other costs rise with the insurance percentage). Mortgage insurance ends as it does in the schedule.",
            }),
            n.jsx(N, {
              caption: "Monthly cost by loan year",
              rows: y,
              columns: u,
              rowKey: (m) => m.year,
              maxHeightClass: "max-h-72",
            }),
          ],
        }),
      n.jsxs("section", {
        "aria-label": "Export",
        className: "space-y-2",
        children: [
          n.jsx("p", {
            className: "text-sm font-medium no-print print:hidden",
            children: "Take it with you",
          }),
          n.jsx(T, {
            gate: r,
            text: P,
            csv: F(j, Y),
            filename: "mortgage-schedule.csv",
            label: "report",
          }),
          n.jsx("p", {
            className: "text-xs text-muted-foreground no-print print:hidden",
            children: "The CSV has the yearly summary first, then every month.",
          }),
        ],
      }),
      n.jsx(H, { tool: "mortgage-calculator" }),
    ],
  });
}
export { Re as default };
//# sourceMappingURL=MortgageExtras-Ci9ZoUPC.js.map
