const i = /^[=+\-@\t\r]/;
function c(e) {
  if (e == null) return "";
  let t = typeof e == "string" ? e : String(e);
  return (
    typeof e == "string" && i.test(t) && (t = `'${t}`),
    /[",\r\n]/.test(t) ? `"${t.replace(/"/g, '""')}"` : t
  );
}
function d(e, t) {
  const r = t.map((n) => c(n.header)).join(","),
    o = e.map((n) => t.map((s) => c(n[s.key])).join(","));
  return (
    "\uFEFF" +
    [r, ...o].join(`\r
`) +
    `\r
`
  );
}
function a(e, t, r = "text/csv;charset=utf-8") {
  const o = URL.createObjectURL(new Blob([t], { type: r })),
    n = document.createElement("a");
  ((n.href = o),
    (n.download = e),
    document.body.appendChild(n),
    n.click(),
    n.remove(),
    setTimeout(() => URL.revokeObjectURL(o), 1e3));
}
export { c, a as d, d as t };
//# sourceMappingURL=csv-DBvSFDe9.js.map
