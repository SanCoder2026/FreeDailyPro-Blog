import { j as o, r as m } from "./vendor-react-D01g8YgM.js";
import { B as l, D as v, f as p } from "./index-B1CTyGtY.js";
import { d as w } from "./csv-DBvSFDe9.js";
import { C as y } from "./copy-DcUvE8ta.js";
import { P as h } from "./share-2-B4TSO3Yd.js";
async function C(t, e, a) {
  if (!(await e.gate())) return !1;
  if (t === "copy")
    try {
      return (await e.copyText(a.text ?? ""), !0);
    } catch {
      return !1;
    }
  return t === "csv"
    ? (e.saveCsv(a.filename ?? "table.csv", a.csv ?? ""), !0)
    : (e.print(), !0);
}
function I({ gate: t, text: e, csv: a, filename: x, label: n = "table" }) {
  const f = {
      gate: t,
      copyText: async (s) => {
        await navigator.clipboard.writeText(s);
      },
      saveCsv: (s, i) => w(s, i),
      print: () => window.print(),
    },
    c = async (s) => {
      const i = await C(s, f, { text: e, csv: a, filename: x });
      (i &&
        s === "copy" &&
        p.success(`${n[0].toUpperCase()}${n.slice(1)} copied`),
        !i &&
          s === "copy" &&
          p.error("Couldn't copy. Use Download CSV instead."));
    };
  return o.jsxs("div", {
    className: "no-print print:hidden flex flex-wrap gap-2",
    role: "group",
    "aria-label": `Export the ${n}`,
    "data-testid": "calc-export-bar",
    children: [
      o.jsxs(l, {
        type: "button",
        size: "sm",
        variant: "outline",
        className: "gap-1.5",
        onClick: () => {
          c("copy");
        },
        children: [
          o.jsx(y, { className: "h-4 w-4", "aria-hidden": "true" }),
          "Copy ",
          n,
        ],
      }),
      o.jsxs(l, {
        type: "button",
        size: "sm",
        variant: "outline",
        className: "gap-1.5",
        onClick: () => {
          c("csv");
        },
        children: [
          o.jsx(v, { className: "h-4 w-4", "aria-hidden": "true" }),
          "Download CSV",
        ],
      }),
      o.jsxs(l, {
        type: "button",
        size: "sm",
        variant: "outline",
        className: "gap-1.5",
        onClick: () => {
          c("print");
        },
        children: [
          o.jsx(h, { className: "h-4 w-4", "aria-hidden": "true" }),
          "Print or save as PDF",
        ],
      }),
    ],
  });
}
const j = 10;
let r = [],
  g = 1;
const u = new Set(),
  d = () => u.forEach((t) => t());
function P(t, e, a = Date.now()) {
  (r[0] && r[0].tool === t && r[0].summary === e) ||
    ((r = [{ id: g++, tool: t, summary: e, at: a }, ...r].slice(0, j)), d());
}
function z() {
  ((r = []), d());
}
const E = (t) => (
  u.add(t),
  () => {
    u.delete(t);
  }
);
function B() {
  return m.useSyncExternalStore(
    E,
    () => r,
    () => r,
  );
}
export { I as E, z as c, P as r, B as u };
//# sourceMappingURL=history-B6kbrtr3.js.map
