function b(t, r, n) {
  if (n <= 0 || t <= 0) return 0;
  const a = r / 100 / 12;
  return a > 0 ? (t * a) / (1 - Math.pow(1 + a, -n)) : t / n;
}
function v(t) {
  const r = Math.max(0, Math.round(t.months)),
    n = b(t.principal, t.annualPct, r),
    a = t.annualPct / 100 / 12,
    e = Math.max(0, t.extra ?? 0),
    h = [];
  let o = t.principal,
    m = 0,
    s = 0,
    y = 0;
  for (let l = 1; l <= r && o > 0.005; l++) {
    const x = o * a;
    let i = Math.min(o, n - x);
    const E =
      t.yearlyExtra &&
      t.yearlyExtra.month >= 1 &&
      l >= t.yearlyExtra.month &&
      (l - t.yearlyExtra.month) % 12 === 0
        ? Math.max(0, t.yearlyExtra.amount)
        : 0;
    let u = Math.min(
      e +
        E +
        (t.oneTime && t.oneTime.month === l
          ? Math.max(0, t.oneTime.amount)
          : 0),
      Math.max(0, o - i),
    );
    l === r && ((i = o), (u = 0));
    const f =
      t.pmiMonthly && t.pmiMonthly > 0 && o > (t.pmiDropBalance ?? 0)
        ? t.pmiMonthly
        : 0;
    (f && (s++, (y += f)),
      (o = Math.max(0, o - i - u)),
      (m += x),
      h.push({
        month: l,
        payment: i + x,
        principal: i,
        interest: x,
        extra: u,
        pmi: f,
        balance: o,
      }));
  }
  const c =
      e > 0 || (t.oneTime?.amount ?? 0) > 0 || (t.yearlyExtra?.amount ?? 0) > 0
        ? v({ ...t, extra: 0, oneTime: void 0, yearlyExtra: void 0 })
        : null,
    d = c ? c.totalInterest : m;
  return {
    payment: n,
    months: r,
    rows: h,
    totalInterest: m,
    totalPaid: t.principal + m,
    payoffMonths: h.length,
    baseInterest: d,
    interestSaved: Math.max(0, d - m),
    monthsSaved: c ? Math.max(0, c.payoffMonths - h.length) : 0,
    pmiMonths: s,
    totalPmi: y,
  };
}
function P(t, r, n) {
  const a = Math.max(1, Math.round(n)),
    e = t * (r / 100) * (a / 12),
    h = (t + e) / a,
    o = [];
  let m = t;
  for (let s = 1; s <= a; s++) {
    const y = e / a,
      M = t / a;
    ((m = s === a ? 0 : Math.max(0, m - M)),
      o.push({
        month: s,
        payment: h,
        principal: M,
        interest: y,
        extra: 0,
        pmi: 0,
        balance: m,
      }));
  }
  return {
    payment: h,
    months: a,
    rows: o,
    totalInterest: e,
    totalPaid: t + e,
    payoffMonths: a,
    baseInterest: e,
    interestSaved: 0,
    monthsSaved: 0,
    pmiMonths: 0,
    totalPmi: 0,
  };
}
function I(t) {
  const r = Math.max(0, Math.round(t)),
    n = Math.floor(r / 12),
    a = r % 12,
    e = [];
  return (
    n && e.push(`${n} ${n === 1 ? "year" : "years"}`),
    (a || !n) && e.push(`${a} ${a === 1 ? "month" : "months"}`),
    e.join(" ")
  );
}
export { v as a, I as b, P as f, b as m };
//# sourceMappingURL=loan-CAZoObwd.js.map
