import { d as p, p as h } from "./dates-DoPZ1fRV.js";
const u = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ],
  d = 1990,
  M = 2100,
  l = (t, n = 2) => String(t).padStart(n, "0"),
  A = (t) => `${l(t.y, 4)}-${l(t.m)}-${l(t.d)}`;
function T(t) {
  if (!t) return null;
  const n = h(t.trim());
  return n && n.y >= d && n.y <= M ? n : null;
}
function g(t) {
  return t.m === 12 ? { y: t.y + 1, m: 1, d: 1 } : { y: t.y, m: t.m + 1, d: 1 };
}
function c(t, n) {
  const e = t.y * 12 + (t.m - 1) + n,
    a = Math.floor(e / 12),
    o = (e % 12) + 1;
  return { y: a, m: o, d: Math.min(t.d, p(a, o)) };
}
const Y = (t, n) => c(t, n - 1),
  i = (t) => `${u[t.m - 1]} ${t.y}`,
  m = (t) => `${u[t.m - 1]} ${t.d}, ${t.y}`,
  b = (t) => Math.round(t * 12);
function D(t, n, e) {
  const a = c(t, n),
    o = c(t, e);
  return a.y === o.y && a.m === o.m ? i(a) : `${i(a)} to ${i(o)}`;
}
function S(t, n, e = 1 / 0) {
  return D(t, (n - 1) * 12, Math.min(n * 12, e) - 1);
}
const F = (t, n) => c(t, n);
function N(t, n) {
  const e = b(n);
  return !Number.isFinite(n) || e < 1
    ? null
    : {
        months: e,
        first: t,
        last: c(t, e - 1),
        end: c(t, e),
        exact: Math.abs(n * 12 - e) < 1e-9,
      };
}
function x(t, n) {
  const e = [];
  for (const a of t) {
    const o = c(n, a.month - 1);
    let r = e[e.length - 1];
    ((!r || r.year !== o.y) &&
      ((r = {
        year: o.y,
        payments: 0,
        principal: 0,
        interest: 0,
        balance: 0,
        firstDate: o,
        lastDate: o,
        endMonth: a.month,
      }),
      e.push(r)),
      r.payments++,
      (r.principal += a.principal + a.extra),
      (r.interest += a.interest),
      (r.balance = a.balance),
      (r.lastDate = o),
      (r.endMonth = a.month));
  }
  return e;
}
function C(t, n, e) {
  const a = [{ index: 0, balance: t, label: `Before first payment (${m(e)})` }];
  for (const o of x(n, e))
    a.push({
      index: o.endMonth,
      balance: o.balance,
      label: `After ${m(o.lastDate)}`,
    });
  return a;
}
function E(t, n, e = 4) {
  const a = c(t, Math.max(0, n - 1)),
    o = [];
  for (let s = t.y + 1; s <= a.y; s++)
    o.push({ year: s, index: (s - t.y) * 12 - (t.m - 1) });
  const r = o.filter(
      (s) => s.index / Math.max(1, n) > 0.18 && s.index / Math.max(1, n) < 0.82,
    ),
    y =
      [1, 2, 5, 10, 20].find(
        (s) => r.filter((f) => f.year % s === 0).length <= e,
      ) ?? 20;
  return r.filter((s) => s.year % y === 0);
}
function I(t, n) {
  const e = new Date(Date.UTC(t.y, t.m - 1, t.d + n));
  return { y: e.getUTCFullYear(), m: e.getUTCMonth() + 1, d: e.getUTCDate() };
}
export {
  d as M,
  M as a,
  c as b,
  i as c,
  g as d,
  F as e,
  m as f,
  b as g,
  S as h,
  I as i,
  x as j,
  C as k,
  Y as l,
  E as m,
  T as p,
  N as t,
  A as y,
};
//# sourceMappingURL=paymentDates-4j4nTGxO.js.map
