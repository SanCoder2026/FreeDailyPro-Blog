function $(e) {
  return e.map((t, r) => {
    const n = Object.entries(t.inputs)
      .map(([s, u]) => `${s} = ${u}`)
      .join("; ");
    return `${r + 1}. ${t.label}
   ${t.formula}
   ${
     n
       ? `Using ${n}
   `
       : ""
   }Result: ${t.result}`;
  }).join(`
`);
}
export { $ as s };
//# sourceMappingURL=steps-X1Sejec4.js.map
