// mortgage-calculator: calculation cases via the UI (reading results only; no exports). One context; page reloaded per case.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/28-mortgage-calculator/live/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const C = [
 ['B01 blog 10%', { 'Home price': '450000', 'Down payment': '10', 'Insurance': '110' }],
 ['B02 blog 20%', { 'Home price': '450000', 'Down payment': '20', 'Insurance': '110' }],
 ['B03 blog 10% 15y', { 'Home price': '450000', 'Down payment': '10', 'Insurance': '110', 'Loan term': '15' }],
 ['B04 blog 45000 in pct', { 'Home price': '450000', 'Down payment': '45000' }],
 ['M01 default', {}],
 ['M02 10% down PMI', { 'Down payment': '10' }],
 ['M03 down $100,000', { 'Down payment unit': 'usd', 'Down payment': '100,000' }],
 ['M04 rate 0', { 'Interest rate': '0' }],
 ['M05 term 15', { 'Loan term': '15' }],
 ['M06 FHA 3.5%', { 'Loan type': 'fha', 'Down payment': '3.5' }],
 ['M07 FHA 3%', { 'Loan type': 'fha', 'Down payment': '3' }],
 ['M08 VA 0 first', { 'Loan type': 'va', 'Down payment': '0' }],
 ['M09 VA 0 subsequent', { 'Loan type': 'va', 'Down payment': '0', 'VA funding fee use': 'subsequent' }],
 ['M10 VA 10 first', { 'Loan type': 'va', 'Down payment': '10' }],
 ['M11 USDA 0', { 'Loan type': 'usda', 'Down payment': '0' }],
 ['M12 tax $6000/yr', { 'Property tax unit': 'year', 'Property tax': '6000' }],
 ['M13 tax $400/mo + HOA 250', { 'Property tax unit': 'month', 'Property tax': '400', 'HOA': '250' }],
 ['M14 extra 200/mo', { 'Extra monthly principal payment': '200' }],
 ['M15 one-time 10000 m12', { 'One-time extra payment': '10000', 'One-time extra payment month': '12' }],
 ['M16 yearly 5000', { 'Yearly extra payment': '5000' }],
 ['M17 income 10000 debts 500', { 'Gross monthly income': '10000', 'Other monthly debts': '500' }],
 ['M18 income 6000', { 'Gross monthly income': '6000' }],
 ['M19 biweekly', { 'Compare biweekly payments': true }],
 ['M20 first payment 2027-03-15', { 'First payment date': '2027-03-15' }],
 ['M21 price 0', { 'Home price': '0' }],
 ['M22 price abc', { 'Home price': 'abc' }],
 ['M23 down >= price', { 'Down payment unit': 'usd', 'Down payment': '400000' }],
 ['M24 rate 101', { 'Interest rate': '101' }],
 ['M25 term 0', { 'Loan term': '0' }],
 ['M26 term 51', { 'Loan term': '51' }],
 ['M27 closing 25', { 'Closing costs percent': '25' }],
 ['M28 growth 30', { 'Property tax yearly increase': '30' }],
 ['M29 income abc', { 'Gross monthly income': 'abc' }],
 ['M30 rate 6,5', { 'Interest rate': '6,5' }],
 ['M31 price 400.000', { 'Home price': '400.000' }],
 ['M32 term 20', { 'Loan term': '20' }],
 ['M33 big 10M at 25%', { 'Home price': '10000000', 'Interest rate': '25' }],
 ['M34 down 19.99', { 'Down payment': '19.99' }],
 ['M35 down 5 PMI months', { 'Down payment': '5' }],
 ['M36 growth tax 3 ins 5', { 'Property tax yearly increase': '3', 'Insurance yearly increase': '5' }],
 ['M37 maintenance 300 + income 10000', { 'Maintenance and other monthly costs': '300', 'Gross monthly income': '10000' }],
 ['M38 date 1989', { 'First payment date': '1989-01-01' }],
 ['M39 one-time month 0', { 'One-time extra payment': '5000', 'One-time extra payment month': '0' }],
 ['M40 term 30.5', { 'Loan term': '30.5' }],
 ['M41 FHA 10% 15y', { 'Loan type': 'fha', 'Down payment': '10', 'Loan term': '15' }],
 ['M42 USDA 0 + 5% down', { 'Loan type': 'usda', 'Down payment': '5' }],
 ['M43 negative rate', { 'Interest rate': '-1' }],
 ['M44 price $400,000', { 'Home price': '$400,000' }],
];
const pick = process.argv[2] ? process.argv[2].split(',') : null; const outf = process.argv[3] || 'cases.json';
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 1000 } }); const p = await c.newPage(); p.setDefaultTimeout(8000);
 const R = { t: now(), cases: [] };
 for (const [id, set] of C) { if (pick && !pick.includes(id.split(' ')[0])) continue;
  await p.goto('https://www.freedailypro.com/tool/mortgage-calculator', { waitUntil: 'domcontentloaded' }); await p.locator('[aria-label="Home price"]').waitFor(); await p.waitForTimeout(800);
  const order = Object.keys(set).sort((a, b) => (/type|unit/i.test(b) ? 1 : 0) - (/type|unit/i.test(a) ? 1 : 0));
  for (const k of order) { const el = p.locator(`[aria-label="${k}"]`).first(); const tag = await el.evaluate(e => e.tagName + (e.type || ''));
   if (tag.startsWith('SELECT')) await el.selectOption(set[k]); else if (set[k] === true) await el.check(); else await el.fill(set[k]); await p.waitForTimeout(250); }
  await p.waitForTimeout(900);
  const r = await p.evaluate(() => { const o = {}; document.querySelectorAll('[data-testid^=mg-]').forEach(e => { const k = e.getAttribute('data-testid'); const v = e.innerText.replace(/\s+/g, ' ').trim().slice(0, 400); if (o[k]) { if (!Array.isArray(o[k])) o[k] = [o[k]]; o[k].push(v); } else o[k] = v; });
   o.alerts = [...document.querySelectorAll('main [role=alert]')].map(e => e.innerText.trim()); o.url = location.search;
   const t = document.querySelector('[data-testid=tool-area]'); o.area = t ? t.innerText.replace(/\s+/g, ' ').slice(0, 2500) : ''; return o; });
  R.cases.push({ id, set, ...r }); const n = id.split(' ')[0]; if (['M01', 'M06', 'M08', 'M11', 'M17', 'M19', 'M22', 'M33'].includes(n)) await p.screenshot({ path: OUT + 'case-' + n + '.png', fullPage: false });
  console.log(id, '|', r['mg-total'], '|', r.alerts.join(' / ')); }
 R.t2 = now(); fs.writeFileSync(OUT + outf, JSON.stringify(R, null, 1)); await b.close(); })();
