// mortgage-calculator: inputs incl. income and debts are mirrored into the page URL (?price=&inc=&debts=). Do they leave the browser? Records request URLs/bodies containing the typed values. Read-only; never clicks ads.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/28-mortgage-calculator/live/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage();
 const R = { t: now(), hits: [], hosts: {} };
 const rx = /(inc|debts|price)(=|%3D|%253D)(9137|612|487250)|9137|487250/;
 p.on('request', r => { const u = r.url(); const h = new URL(u).host; R.hosts[h] = (R.hosts[h] || 0) + 1; const body = r.postData() || ''; if (rx.test(u) || rx.test(body)) { const s = rx.test(u) ? u : body; R.hits.push({ phase: R.phase, method: r.method(), host: h, path: new URL(u).pathname.slice(0, 60), where: rx.test(u) ? 'url' : 'body', sample: (s.match(/.{0,70}(9137|487250|612).{0,50}/) || [''])[0] }); } });
 R.phase = 'A_typed'; await p.goto('https://www.freedailypro.com/tool/mortgage-calculator', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 await p.locator('[aria-label="Home price"]').fill('487250'); await p.locator('[aria-label="Gross monthly income"]').fill('9137'); await p.locator('[aria-label="Other monthly debts"]').fill('612'); await p.waitForTimeout(6000);
 await p.mouse.wheel(0, 2500); await p.waitForTimeout(5000);
 R.urlA = p.url(); R.phase = 'B_reload_or_shared_link'; await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(8000); await p.mouse.wheel(0, 2500); await p.waitForTimeout(4000);
 R.t2 = now(); fs.writeFileSync(OUT + 'privacy.json', JSON.stringify(R, null, 1)); await b.close();
 console.log(R.urlA); const g = {}; R.hits.forEach(h => { const k = h.phase + ' ' + h.method + ' ' + h.host + h.path + ' ' + h.where; g[k] = (g[k] || 0) + 1; }); console.log(g); console.log(R.hits.slice(0, 6)); })();
