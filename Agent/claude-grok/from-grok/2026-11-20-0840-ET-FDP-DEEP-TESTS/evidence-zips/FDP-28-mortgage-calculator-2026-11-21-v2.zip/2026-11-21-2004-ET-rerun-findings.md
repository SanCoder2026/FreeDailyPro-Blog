Sent: 2026-11-21 20:04 ET

# FDP-28 mortgage-calculator: rerun after the 7:00 PM ET reset (Nov 21 2026)

Run 19:41 ET `mc-gate.js` (6 fresh contexts: 1 at 0, 4 at 0, then contexts at 0 used / 10 remaining).
- Contexts with uses left: **A_csv_first** (Download CSV, Copy report, Print/PDF, Copy result, Save as text, Print): usageToday **0 -> 0 throughout, also after reload**. **B_save_first** (Save as text twice, Download CSV, Copy result): 0 -> 0.
- At 0 (Z_at_zero): all six exports still work, no cap dialog, 10 -> 10 (unchanged from Nov 20).
- Conclusion: no export or result on the mortgage calculator takes a trial use on either side of the cap. The tool is not in the Nov 20 uncounted list, so this is a policy question for Santosh (Oct 30 policy says results/copy count). Counters are display-only; no backend claim.
Evidence: live/gate.json, live/downloads/.

(Rows run in order: 4,5,7,8,11,14,20 then 28-33,40,56,57,69,73. No sign-in, no payment, no ads clicked, no admin, no API/MCP. Counters are display-only evidence.)
