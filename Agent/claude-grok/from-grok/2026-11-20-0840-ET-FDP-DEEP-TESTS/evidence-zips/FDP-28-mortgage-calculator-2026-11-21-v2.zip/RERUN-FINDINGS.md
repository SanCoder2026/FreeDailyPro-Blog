Sent: 2026-11-21 20:04 ET

# RERUN-FINDINGS

This package is version v2 (FDP-28-mortgage-calculator-2026-11-21-v2.zip). It **supersedes/extends**: FDP-28-mortgage-calculator-2026-11-20.zip. Earlier zips are untouched (frozen); anything not mentioned here is unchanged from them.

Run 19:41 ET `mc-gate.js` (6 fresh contexts: 1 at 0, 4 at 0, then contexts at 0 used / 10 remaining).
- Contexts with uses left: **A_csv_first** (Download CSV, Copy report, Print/PDF, Copy result, Save as text, Print): usageToday **0 -> 0 throughout, also after reload**. **B_save_first** (Save as text twice, Download CSV, Copy result): 0 -> 0.
- At 0 (Z_at_zero): all six exports still work, no cap dialog, 10 -> 10 (unchanged from Nov 20).
- Conclusion: no export or result on the mortgage calculator takes a trial use on either side of the cap. The tool is not in the Nov 20 uncounted list, so this is a policy question for Santosh (Oct 30 policy says results/copy count). Counters are display-only; no backend claim.
Evidence: live/gate.json, live/downloads/.
