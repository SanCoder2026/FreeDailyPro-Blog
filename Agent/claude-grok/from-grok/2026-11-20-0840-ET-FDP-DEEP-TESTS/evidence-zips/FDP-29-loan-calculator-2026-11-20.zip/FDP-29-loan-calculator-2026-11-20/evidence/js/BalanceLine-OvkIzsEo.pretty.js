import { j as t } from "./vendor-react-D01g8YgM.js";
const g = 3;
function j(e) {
  return e.slice(0, g);
}
function y(e, s) {
  return e === 0 ? s(0) : `${e > 0 ? "+" : "-"}${s(Math.abs(e))}`;
}
function N(e, s) {
  const c = j(e);
  return s.map((a) => {
    const o = (n) => (a.format ? a.format(n) : String(n)),
      r = c[0]?.values[a.key];
    return {
      key: a.key,
      label: a.label,
      cells: c.map((n) =>
        n.values[a.key] === void 0 ? "" : o(n.values[a.key]),
      ),
      deltas: c.map((n, l) => {
        const d = n.values[a.key];
        return l === 0 ||
          a.kind !== "number" ||
          typeof d != "number" ||
          typeof r != "number"
          ? ""
          : y(d - r, (x) => o(x));
      }),
    };
  });
}
function S({ scenarios: e, metrics: s, caption: c = "Scenario comparison" }) {
  const a = e.slice(0, 3),
    o = N(a, s);
  return t.jsx("div", {
    className: "border rounded-xl overflow-x-auto",
    "data-testid": "scenario-compare",
    children: t.jsxs("table", {
      className: "w-full text-sm",
      children: [
        t.jsx("caption", { className: "sr-only", children: c }),
        t.jsx("thead", {
          className: "bg-card border-b",
          children: t.jsxs("tr", {
            className: "text-left text-muted-foreground",
            children: [
              t.jsx("th", {
                scope: "col",
                className: "p-2 pl-4",
                children: "Measure",
              }),
              a.map((r) =>
                t.jsx(
                  "th",
                  {
                    scope: "col",
                    className: "p-2 text-right",
                    children: r.name,
                  },
                  r.id,
                ),
              ),
            ],
          }),
        }),
        t.jsx("tbody", {
          children: o.map((r) =>
            t.jsxs(
              "tr",
              {
                className: "border-b last:border-0",
                children: [
                  t.jsx("th", {
                    scope: "row",
                    className: "p-2 pl-4 text-left font-normal",
                    children: r.label,
                  }),
                  r.cells.map((n, l) =>
                    t.jsxs(
                      "td",
                      {
                        className: "p-2 text-right",
                        children: [
                          n,
                          r.deltas[l] &&
                            t.jsxs("span", {
                              className: "block text-xs text-muted-foreground",
                              "data-testid": "scenario-delta",
                              children: [r.deltas[l], " vs ", a[0].name],
                            }),
                        ],
                      },
                      l,
                    ),
                  ),
                ],
              },
              r.key,
            ),
          ),
        }),
      ],
    }),
  });
}
function k(e, s = 120) {
  if (e.length <= s) return e;
  const c = (e.length - 1) / (s - 1);
  return Array.from({ length: s }, (a, o) => e[Math.round(o * c)]);
}
function $({
  points: e,
  money: s,
  caption: c = "Remaining balance over time",
  startLabel: a,
  endLabel: o,
}) {
  if (e.length < 2) return null;
  const r = 320,
    n = 120,
    l = 6,
    d = 8,
    x = 18,
    u = k(e),
    m = Math.max(1, ...u.map((i) => i.balance)),
    h = u[u.length - 1].n || 1,
    f = (i) => l + (i / h) * (r - 2 * l),
    p = (i) => d + (1 - i / m) * (n - d - x),
    b = `Chart of the remaining loan balance. It starts at ${s(e[0].balance)} at ${a} and reaches ${s(e[e.length - 1].balance)} at ${o}.`;
  return t.jsxs("figure", {
    "data-testid": "balance-line",
    children: [
      t.jsxs("svg", {
        viewBox: `0 0 ${r} ${n}`,
        role: "img",
        "aria-label": b,
        className: "w-full text-primary",
        children: [
          t.jsx("polyline", {
            fill: "none",
            stroke: "currentColor",
            strokeWidth: 2,
            points: u.map((i) => `${f(i.n)},${p(i.balance)}`).join(" "),
          }),
          t.jsx("text", {
            x: l,
            y: n - 4,
            fontSize: 9,
            fill: "currentColor",
            className: "text-muted-foreground",
            children: a,
          }),
          t.jsx("text", {
            x: r - l,
            y: n - 4,
            fontSize: 9,
            textAnchor: "end",
            fill: "currentColor",
            className: "text-muted-foreground",
            children: o,
          }),
        ],
      }),
      t.jsx("figcaption", {
        className: "text-xs text-muted-foreground text-center",
        children: c,
      }),
    ],
  });
}
export { $ as B, S, N as c };
//# sourceMappingURL=BalanceLine-OvkIzsEo.js.map
