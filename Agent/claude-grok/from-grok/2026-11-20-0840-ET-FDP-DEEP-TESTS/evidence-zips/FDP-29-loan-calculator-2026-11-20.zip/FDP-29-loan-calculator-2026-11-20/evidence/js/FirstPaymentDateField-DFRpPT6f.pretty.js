import { r as o, j as r } from "./vendor-react-D01g8YgM.js";
import { e as u, I as x, N as f } from "./index-B1CTyGtY.js";
import { t as p } from "./dates-DoPZ1fRV.js";
import {
  p as l,
  M as d,
  a as c,
  y as h,
  d as y,
  f as m,
  b as g,
  c as N,
} from "./paymentDates-4j4nTGxO.js";
function F() {
  const [e] = o.useState(() => h(y(p()))),
    [t, a] = o.useState(e),
    s = l(t),
    n = o.useMemo(() => s ?? l(e), [t, e]),
    i =
      t.trim() !== "" && !s
        ? `Pick a date between ${d} and ${c}. Showing dates from ${m(n)} for now.`
        : "";
  return { value: t, setValue: a, first: n, message: i };
}
function b() {
  const [e, t] = o.useState(""),
    a = l(e),
    s =
      e.trim() !== "" && !a
        ? `Pick a date between ${d} and ${c}, or clear the field. Showing the plain results for now.`
        : "";
  return { value: e, setValue: t, start: a, message: s };
}
function D({
  id: e,
  state: t,
  help: a,
  label: s = "First payment date",
  compact: n,
}) {
  return r.jsxs("div", {
    children: [
      r.jsx(u, { htmlFor: e, className: n ? "text-xs" : void 0, children: s }),
      r.jsx(x, {
        id: e,
        type: "date",
        "aria-label": s,
        "aria-describedby": `${e}-help`,
        min: `${d}-01-01`,
        max: `${c}-12-31`,
        "aria-invalid": t.message ? !0 : void 0,
        value: t.value,
        onChange: (i) => t.setValue(i.target.value),
      }),
      r.jsx("p", {
        id: `${e}-help`,
        className: "text-xs text-muted-foreground mt-1",
        children: a,
      }),
      t.message &&
        r.jsx("p", {
          role: "alert",
          className: "text-xs text-destructive mt-1",
          children: t.message,
        }),
    ],
  });
}
function M({ first: e, payments: t, testId: a }) {
  if (t < 1) return null;
  const s = g(e, t - 1);
  return r.jsxs(f, {
    className: "text-center",
    testId: a,
    children: [
      r.jsx("p", {
        className: "text-xs text-muted-foreground",
        children: "Payoff",
      }),
      r.jsx("p", {
        className: "text-lg font-bold",
        "data-testid": `${a}-date`,
        children: N(s),
      }),
      r.jsxs("p", {
        className: "text-xs text-muted-foreground",
        "data-testid": `${a}-detail`,
        children: ["First payment ", m(e), ". Last payment ", m(s), "."],
      }),
    ],
  });
}
export { D as F, M as P, F as a, b as u };
//# sourceMappingURL=FirstPaymentDateField-DFRpPT6f.js.map
