const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/LoanExtras-DkVbNvNv.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/index-B1CTyGtY.js",
      "assets/index-BJxTAPRn.css",
      "assets/CalcSteps-CMhW1YVy.js",
      "assets/ResultsTable-CpxaKI_z.js",
      "assets/history-B6kbrtr3.js",
      "assets/csv-DBvSFDe9.js",
      "assets/copy-DcUvE8ta.js",
      "assets/share-2-B4TSO3Yd.js",
      "assets/BalanceLine-OvkIzsEo.js",
      "assets/CalcHistory-B9VfOON0.js",
      "assets/steps-X1Sejec4.js",
      "assets/table-CJAX3ymv.js",
      "assets/numberInput-5hjoxJ5z.js",
      "assets/paymentDates-4j4nTGxO.js",
      "assets/dates-DoPZ1fRV.js",
      "assets/loan-CAZoObwd.js",
      "assets/chevron-up-BDUcPssj.js",
      "assets/LoanWorkbench-bbP73gp2.js",
      "assets/tabs-Rb7RCr47.js",
    ]),
) => i.map((i) => d[i]);
import { e as y, I as S, ap as A } from "./index-B1CTyGtY.js";
import { r as n, j as e } from "./vendor-react-D01g8YgM.js";
import { T as q } from "./ToolPage-DwLoDncN.js";
import { T as Q } from "./ToolInfoSection-C0i6Zbwo.js";
import { u as H } from "./useLogToolUsage-BdvvKW0n.js";
import { p as C } from "./numberInput-5hjoxJ5z.js";
import { C as F, f as K } from "./money-Dkxewa8a.js";
import { f as Z, a as B, b as G } from "./loan-CAZoObwd.js";
import { b as O, c as U } from "./paymentDates-4j4nTGxO.js";
import { a as J, F as X, P as ee } from "./FirstPaymentDateField-DFRpPT6f.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./copyText-DPnES92p.js";
import "./dates-DoPZ1fRV.js";
const D = {
    principal: "100000",
    rate: "5",
    term: "30",
    unit: "years",
    extra: "0",
    currency: "USD",
    method: "reducing",
  },
  g = {
    principal: "amt",
    rate: "rate",
    term: "term",
    unit: "unit",
    extra: "xm",
    currency: "cur",
    method: "m",
  },
  te = /^[\d.,\s$%-]{0,14}$/;
function ae(s) {
  const l = new URLSearchParams();
  return (
    Object.keys(g).forEach((i) => {
      s[i] !== D[i] && l.set(g[i], s[i]);
    }),
    l.toString()
  );
}
function k(s, l = []) {
  const i = new URLSearchParams(s),
    d = { ...D };
  for (const u of ["principal", "rate", "term", "extra"]) {
    const v = i.get(g[u]);
    v !== null && te.test(v) && (d[u] = v);
  }
  const j = i.get(g.unit);
  (j === "years" || j === "months") && (d.unit = j);
  const h = i.get(g.method);
  (h === "reducing" || h === "flat") && (d.method = h);
  const f = i.get(g.currency);
  return (
    f &&
      /^[A-Z]{3}$/.test(f) &&
      (l.length === 0 || l.includes(f)) &&
      (d.currency = f),
    d
  );
}
const ne = n.lazy(() =>
    A(
      () => import("./LoanExtras-DkVbNvNv.js"),
      __vite__mapDeps([
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18,
      ]),
    ),
  ),
  re = n.lazy(() =>
    A(
      () => import("./LoanWorkbench-bbP73gp2.js"),
      __vite__mapDeps([
        19, 1, 2, 3, 20, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16,
      ]),
    ),
  ),
  L = {
    what: "Calculates the monthly payment, total interest and full amortization schedule for a loan from the principal, interest rate and term, with an optional extra monthly payment that shows how much interest and time you save. Every payment in the schedule, and the payoff date, uses real calendar dates that start from your first payment date.",
    how: "Enter the loan amount, interest rate and term (in years or months), and choose a currency. Add an extra monthly payment to see the payoff date move earlier. Set the first payment date to the day your first payment is due (it starts as the 1st of next month) to see the real date of every payment and the payoff date. It only labels the schedule and does not change the amounts. Expand the schedule for the principal/interest split of every payment, or download it, dates included, as a CSV file.",
    tip: "Even a small difference in interest rate makes a real difference in total interest paid over a long loan, so compare the total cost, not just the monthly payment. In the early years most of each payment is interest, which is why extra principal payments early on save the most.",
  };
function De() {
  const [s] = n.useState(() =>
      typeof window > "u"
        ? k("")
        : k(
            window.location.search,
            F.map((a) => a.code),
          ),
    ),
    [l, i] = n.useState(s.principal),
    [d, j] = n.useState(s.rate),
    [h, f] = n.useState(s.term),
    [u, v] = n.useState(s.unit),
    [E, $] = n.useState(s.extra),
    [b, z] = n.useState(s.currency),
    [r, V] = n.useState(s.method);
  n.useEffect(() => {
    try {
      const a = ae({
        principal: l,
        rate: d,
        term: h,
        unit: u,
        extra: E,
        currency: b,
        method: r,
      });
      window.history.replaceState(
        null,
        "",
        `${window.location.pathname}${a ? `?${a}` : ""}${window.location.hash}`,
      );
    } catch {}
  }, [l, d, h, u, E, b, r]);
  const P = J(),
    w = P.first,
    m = C(l),
    c = C(d),
    I = C(h),
    p = C(E) ?? 0,
    o = I == null ? NaN : Math.round(u === "years" ? I * 12 : I),
    N =
      m == null || m <= 0
        ? "Enter a loan amount greater than 0."
        : c == null || c < 0 || c > 100
          ? "Enter an interest rate between 0% and 100%."
          : !Number.isFinite(o) || o < 1
            ? "Enter a term of at least 1 month."
            : o > 1200
              ? "The term can be at most 100 years."
              : p < 0
                ? "The extra payment cannot be negative."
                : "",
    t = n.useMemo(
      () =>
        N
          ? null
          : r === "flat"
            ? Z(m, c, o)
            : B({ principal: m, annualPct: c, months: o, extra: p }),
      [N, m, c, o, p, r],
    ),
    W = !!t && r === "reducing" && t.rows.length === 1 && o > 1,
    { gate: M } = H(!!t),
    x = n.useCallback((a) => K(a, b), [b]),
    T = t && t.rows.length > 0 ? O(w, t.rows.length - 1) : null,
    _ = N ? null : O(w, o - 1),
    R = n.useMemo(
      () =>
        t
          ? {
              principal: m,
              annualPct: c,
              months: o,
              extra: r === "reducing" ? p : 0,
              method: r,
            }
          : null,
      [t, m, c, o, p, r],
    ),
    Y = n.useMemo(
      () =>
        t && r === "reducing"
          ? { principal: m, annualPct: c, years: o / 12 }
          : null,
      [t, r, m, c, o],
    );
  return e.jsxs(q, {
    children: [
      e.jsxs("div", {
        className: "grid grid-cols-1 md:grid-cols-2 gap-8",
        children: [
          e.jsxs("div", {
            className: "space-y-4",
            children: [
              e.jsxs("div", {
                className: "grid grid-cols-3 gap-3",
                children: [
                  e.jsxs("div", {
                    className: "col-span-2",
                    children: [
                      e.jsx(y, { children: "Loan Amount" }),
                      e.jsx(S, {
                        inputMode: "decimal",
                        "aria-label": "Loan amount",
                        value: l,
                        onChange: (a) => i(a.target.value),
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx(y, { children: "Currency" }),
                      e.jsx("select", {
                        className:
                          "border rounded px-2 py-2 w-full bg-background text-sm",
                        "aria-label": "Currency",
                        value: b,
                        onChange: (a) => z(a.target.value),
                        children: F.map((a) =>
                          e.jsx(
                            "option",
                            { value: a.code, children: a.code },
                            a.code,
                          ),
                        ),
                      }),
                    ],
                  }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx(y, { children: "Annual Interest Rate (%)" }),
                  e.jsx(S, {
                    inputMode: "decimal",
                    "aria-label": "Interest rate",
                    value: d,
                    onChange: (a) => j(a.target.value),
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "grid grid-cols-3 gap-3",
                children: [
                  e.jsxs("div", {
                    className: "col-span-2",
                    children: [
                      e.jsx(y, { children: "Loan Term" }),
                      e.jsx(S, {
                        inputMode: "decimal",
                        "aria-label": "Loan term",
                        value: h,
                        onChange: (a) => f(a.target.value),
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx(y, { children: " " }),
                      e.jsxs("select", {
                        className:
                          "border rounded px-2 py-2 w-full bg-background text-sm",
                        "aria-label": "Term unit",
                        value: u,
                        onChange: (a) => v(a.target.value),
                        children: [
                          e.jsx("option", {
                            value: "years",
                            children: "years",
                          }),
                          e.jsx("option", {
                            value: "months",
                            children: "months",
                          }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx(y, { children: "Interest method" }),
                  e.jsxs("select", {
                    className:
                      "border rounded px-2 py-2 w-full bg-background text-sm",
                    "aria-label": "Interest method",
                    value: r,
                    onChange: (a) => V(a.target.value),
                    children: [
                      e.jsx("option", {
                        value: "reducing",
                        children: "Reducing balance (standard EMI)",
                      }),
                      e.jsx("option", {
                        value: "flat",
                        children: "Flat rate (interest on the original amount)",
                      }),
                    ],
                  }),
                ],
              }),
              e.jsx(X, {
                id: "ln-first-payment",
                state: P,
                help: "The date your first payment is due. Later payments fall on the same day each month. It only puts dates on the schedule and the payoff; it does not change your payment or interest, because every period is treated as a full month. Clear it to use the 1st of next month.",
              }),
              r === "reducing" &&
                e.jsxs("div", {
                  children: [
                    e.jsx(y, { children: "Extra monthly payment (optional)" }),
                    e.jsx(S, {
                      inputMode: "decimal",
                      "aria-label": "Extra payment",
                      value: E,
                      onChange: (a) => $(a.target.value),
                    }),
                  ],
                }),
              N &&
                e.jsx("p", {
                  className: "text-sm text-red-600",
                  "data-testid": "loan-error",
                  children: N,
                }),
            ],
          }),
          e.jsxs("div", {
            className: "space-y-4",
            children: [
              e.jsxs("div", {
                className: "p-6 rounded-xl border bg-card text-center",
                children: [
                  e.jsx("p", {
                    className: "text-sm text-muted-foreground",
                    children: "Monthly Payment",
                  }),
                  e.jsx("p", {
                    className: "text-3xl font-bold text-primary",
                    "data-testid": "loan-payment",
                    children: t ? x(t.payment) : "—",
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "grid grid-cols-2 gap-4",
                children: [
                  e.jsxs("div", {
                    className: "p-4 rounded-lg border bg-card text-center",
                    children: [
                      e.jsx("p", {
                        className: "text-xs text-muted-foreground",
                        children: "Total Payment",
                      }),
                      e.jsx("p", {
                        className: "text-lg font-semibold",
                        "data-testid": "loan-total",
                        children: t ? x(t.totalPaid) : "—",
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className: "p-4 rounded-lg border bg-card text-center",
                    children: [
                      e.jsx("p", {
                        className: "text-xs text-muted-foreground",
                        children: "Total Interest",
                      }),
                      e.jsx("p", {
                        className: "text-lg font-semibold",
                        "data-testid": "loan-interest",
                        children: t ? x(t.totalInterest) : "—",
                      }),
                    ],
                  }),
                ],
              }),
              T &&
                e.jsx(ee, {
                  first: w,
                  payments: t.rows.length,
                  testId: "loan-payoff",
                }),
              W &&
                e.jsx("p", {
                  className:
                    "text-sm text-center p-3 rounded-lg border bg-primary/5",
                  "data-testid": "loan-paid-m1",
                  children:
                    "With this extra payment the loan is paid off in month 1. The monthly payment shown is the regular scheduled amount.",
                }),
              r === "flat" &&
                e.jsx("p", {
                  className: "text-xs text-center text-muted-foreground",
                  children:
                    "Flat rate: interest is charged on the full original amount for the whole term, so the true annual cost is higher than the quoted rate.",
                }),
              t &&
                t.monthsSaved + t.interestSaved > 0 &&
                p > 0 &&
                e.jsxs("p", {
                  className:
                    "text-sm text-center p-3 rounded-lg border bg-primary/5",
                  "data-testid": "loan-saved",
                  children: [
                    "With ",
                    x(p),
                    " extra each month you finish ",
                    G(t.monthsSaved),
                    " early and save ",
                    x(t.interestSaved),
                    " in interest.",
                    T &&
                      _ &&
                      e.jsxs("span", {
                        "data-testid": "loan-extra-dates",
                        children: [
                          " New payoff date ",
                          U(T),
                          " instead of ",
                          U(_),
                          ".",
                        ],
                      }),
                  ],
                }),
            ],
          }),
        ],
      }),
      t &&
        R &&
        t.rows.length > 0 &&
        e.jsx(n.Suspense, {
          fallback: e.jsx("p", {
            className: "mt-8 text-sm text-muted-foreground",
            role: "status",
            children: "Loading schedule and working...",
          }),
          children: e.jsx(ne, {
            inputs: R,
            res: t,
            first: w,
            money: x,
            gate: M,
          }),
        }),
      r === "reducing" &&
        e.jsx(n.Suspense, {
          fallback: null,
          children: e.jsx(re, { main: Y, first: w, money: x, gate: M }),
        }),
      e.jsx(Q, { whatIsIt: L.what, howToUse: L.how, tip: L.tip }),
    ],
  });
}
export { De as default };
//# sourceMappingURL=LoanCalculator-c-nwviyv.js.map
