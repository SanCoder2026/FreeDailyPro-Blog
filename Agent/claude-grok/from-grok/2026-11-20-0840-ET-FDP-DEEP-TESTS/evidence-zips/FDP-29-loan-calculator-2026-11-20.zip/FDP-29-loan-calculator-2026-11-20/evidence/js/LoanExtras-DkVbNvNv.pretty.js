import { r as c, j as o } from "./vendor-react-D01g8YgM.js";
import { e as v, I as j, B as N, a0 as $ } from "./index-B1CTyGtY.js";
import { C as E } from "./CalcSteps-CMhW1YVy.js";
import { C as F, R as A } from "./ResultsTable-CpxaKI_z.js";
import { r as R, E as B } from "./history-B6kbrtr3.js";
import { c as z, B as D, S as H } from "./BalanceLine-OvkIzsEo.js";
import { C as _ } from "./CalcHistory-B9VfOON0.js";
import { s as O } from "./steps-X1Sejec4.js";
import { t as Y, a as K } from "./table-CJAX3ymv.js";
import { p as T } from "./numberInput-5hjoxJ5z.js";
import { c as P, b as p, f as x, y as U } from "./paymentDates-4j4nTGxO.js";
import { b as X, a as I } from "./loan-CAZoObwd.js";
import { C as q } from "./chevron-up-BDUcPssj.js";
import "./csv-DBvSFDe9.js";
import "./copy-DcUvE8ta.js";
import "./share-2-B4TSO3Yd.js";
import "./dates-DoPZ1fRV.js";
const b = (e) => `${+e.toFixed(4)}%`;
function G(e, a, n, t) {
  const h = e.annualPct / 100 / 12;
  if (e.method === "flat")
    return [
      {
        label: "Total interest",
        formula:
          "Loan amount x annual rate x years (interest is charged on the original amount for the whole term)",
        inputs: {
          "Loan amount": t(e.principal),
          "Annual rate": b(e.annualPct),
          Years: +(e.months / 12).toFixed(4),
        },
        result: t(a.totalInterest),
      },
      {
        label: "Monthly payment",
        formula: "(Loan amount + total interest) / number of payments",
        inputs: {
          "Loan amount": t(e.principal),
          "Total interest": t(a.totalInterest),
          Payments: a.months,
        },
        result: t(a.payment),
      },
      {
        label: "Total paid",
        formula: "Loan amount + total interest",
        inputs: {
          "Loan amount": t(e.principal),
          "Total interest": t(a.totalInterest),
        },
        result: t(a.totalPaid),
      },
    ];
  const i = +h.toFixed(8),
    l = a.rows[0],
    r = [
      {
        label: "Monthly interest rate",
        formula: "Annual rate / 100 / 12",
        inputs: { "Annual rate": b(e.annualPct) },
        result: String(i),
      },
      {
        label: "Monthly payment",
        formula:
          h === 0
            ? "Loan amount / number of payments (the rate is 0)"
            : "Loan amount x rate / (1 - (1 + rate) ^ -payments)",
        inputs: {
          "Loan amount": t(e.principal),
          "Monthly rate": String(i),
          Payments: e.months,
        },
        result: t(a.payment),
      },
    ];
  return (
    l &&
      r.push({
        label: "Split of the first payment",
        formula:
          "Interest = balance x monthly rate; principal = payment - interest",
        inputs: {
          Balance: t(e.principal),
          "Monthly rate": String(i),
          Payment: t(a.payment),
        },
        result: `interest ${t(l.interest)}, principal ${t(l.principal)}`,
      }),
    r.push({
      label: "Number of payments",
      formula:
        e.extra > 0
          ? "Payments are made until the balance reaches 0; each month's extra amount goes straight to principal"
          : "The term in months",
      inputs:
        e.extra > 0
          ? { "Extra each month": t(e.extra), "Term (months)": e.months }
          : { "Term (months)": e.months },
      result: a.rows.length,
    }),
    r.push({
      label: "Total interest",
      formula: "Add up the interest part of every payment in the schedule",
      inputs: { Payments: a.rows.length },
      result: t(a.totalInterest),
    }),
    r.push({
      label: "Total paid",
      formula: "Loan amount + total interest",
      inputs: {
        "Loan amount": t(e.principal),
        "Total interest": t(a.totalInterest),
      },
      result: t(a.totalPaid),
    }),
    e.extra > 0 &&
      a.interestSaved > 0 &&
      r.push({
        label: "Interest and time saved by the extra payment",
        formula:
          "Interest without the extra payment - interest with it; and the payments saved",
        inputs: {
          "Interest without extra": t(a.baseInterest),
          "Interest with extra": t(a.totalInterest),
        },
        result: `${t(a.interestSaved)} saved, ${X(a.monthsSaved)} sooner`,
      }),
    a.rows.length > 0 &&
      r.push({
        label: "Payoff date",
        formula: "The first payment date plus (number of payments - 1) months",
        inputs: { "First payment": x(n), Payments: a.rows.length },
        result: P(p(n, a.rows.length - 1)),
      }),
    r
  );
}
function J(e, a) {
  const n = (t) => +t.toFixed(2);
  return [
    { key: "month", header: "Month", get: (t) => t.month, align: "left" },
    {
      key: "date",
      header: "Payment date",
      get: (t) => U(p(e, t.month - 1)),
      format: (t) => x(p(e, t.month - 1)),
      align: "left",
    },
    {
      key: "payment",
      header: "Payment",
      get: (t) => n(t.payment),
      format: (t) => a(t.payment),
      align: "right",
    },
    {
      key: "principal",
      header: "Principal",
      get: (t) => n(t.principal),
      format: (t) => a(t.principal),
      align: "right",
    },
    {
      key: "interest",
      header: "Interest",
      get: (t) => n(t.interest),
      format: (t) => a(t.interest),
      align: "right",
    },
    {
      key: "extra",
      header: "Extra",
      get: (t) => n(t.extra),
      format: (t) => a(t.extra),
      align: "right",
    },
    {
      key: "balance",
      header: "Remaining balance",
      get: (t) => n(t.balance),
      format: (t) => a(t.balance),
      align: "right",
    },
  ];
}
const Q = 1e9;
function V(e, a, n, t = String) {
  const h = [
      0,
      ...a
        .slice(0, 2)
        .map((l) => (Number.isFinite(l) ? Math.min(Math.max(0, l), Q) : 0)),
    ],
    i = I({ principal: e.principal, annualPct: e.annualPct, months: e.months });
  return h.map((l, r) => {
    const m =
        r === 0
          ? i
          : I({
              principal: e.principal,
              annualPct: e.annualPct,
              months: e.months,
              extra: l,
            }),
      u = m.rows.length > 0 ? P(p(n, m.rows.length - 1)) : "";
    return {
      id: `s${r + 1}`,
      name: r === 0 ? "No extra payment" : `${t(l)} extra/month`,
      values: {
        extra: l,
        payment: m.payment,
        payments: m.rows.length,
        payoff: u,
        interest: m.totalInterest,
        total: m.totalPaid,
        interestSaved: Math.max(0, i.totalInterest - m.totalInterest),
      },
    };
  });
}
function W(e) {
  const a = (t) => e(Number(t));
  return [
    { key: "extra", label: "Extra each month", kind: "number", format: a },
    {
      key: "payment",
      label: "Regular monthly payment",
      kind: "number",
      format: a,
    },
    {
      key: "payments",
      label: "Payments until paid off",
      kind: "number",
      format: (t) =>
        `${Math.round(Number(t))} ${Math.round(Number(t)) === 1 ? "month" : "months"}`,
      better: "lower",
    },
    { key: "payoff", label: "Payoff month", kind: "text" },
    {
      key: "interest",
      label: "Total interest",
      kind: "number",
      format: a,
      better: "lower",
    },
    {
      key: "total",
      label: "Total paid",
      kind: "number",
      format: a,
      better: "lower",
    },
    {
      key: "interestSaved",
      label: "Interest saved vs no extra",
      kind: "number",
      format: a,
      better: "higher",
    },
  ];
}
function Z(e, a, n) {
  return `${n(e.principal)} at ${b(e.annualPct)} for ${e.months} months${e.extra > 0 ? ` with ${n(e.extra)} extra` : ""}: ${n(a.payment)}/month, ${n(a.totalInterest)} interest`;
}
function ft({ inputs: e, res: a, first: n, money: t, gate: h }) {
  const [i, l] = c.useState(!1),
    [r, m] = c.useState("100"),
    [u, C] = c.useState("250"),
    g = c.useMemo(() => G(e, a, n, t), [e, a, n, t]),
    y = c.useMemo(() => J(n, t), [n, t]),
    d = e.method === "reducing",
    w = c.useMemo(
      () => (d ? V(e, [T(r) ?? 0, T(u) ?? 0], n, t) : []),
      [d, e, r, u, n, t],
    ),
    S = c.useMemo(() => W(t), [t]),
    f = Z(e, a, t);
  c.useEffect(() => {
    const s = setTimeout(() => R("loan-calculator", f), 800);
    return () => clearTimeout(s);
  }, [f]);
  const k = Y(a.rows, y),
    L = K(a.rows, y),
    M = [
      "Loan calculation",
      f,
      "",
      "How this was calculated",
      O(g),
      "",
      ...(d
        ? [
            "Scenario comparison",
            ...z(w, S).map((s) => `${s.label}: ${s.cells.join(" | ")}`),
            "",
          ]
        : []),
      "Amortization schedule",
      L,
      "",
      "Calculated with FreeDailyPro.com",
    ].join(`
`);
  return o.jsxs("div", {
    className: "mt-8 space-y-6 calc-print-area",
    children: [
      o.jsx("style", { children: F }),
      o.jsx(E, { steps: g }),
      o.jsx(D, {
        points: [
          { n: 0, balance: e.principal },
          ...a.rows.map((s) => ({ n: s.month, balance: s.balance })),
        ],
        money: t,
        startLabel: x(n),
        endLabel: x(p(n, a.rows.length - 1)),
      }),
      d &&
        o.jsxs("section", {
          "aria-label": "Compare extra payments",
          className: "space-y-3",
          children: [
            o.jsx("h3", {
              className: "text-base font-semibold",
              children: "Compare extra payments",
            }),
            o.jsxs("div", {
              className:
                "no-print print:hidden grid grid-cols-2 gap-3 max-w-md",
              children: [
                o.jsxs("div", {
                  children: [
                    o.jsx(v, {
                      htmlFor: "ln-scn-b",
                      children: "Scenario 2: extra each month",
                    }),
                    o.jsx(j, {
                      id: "ln-scn-b",
                      inputMode: "decimal",
                      value: r,
                      onChange: (s) => m(s.target.value),
                    }),
                  ],
                }),
                o.jsxs("div", {
                  children: [
                    o.jsx(v, {
                      htmlFor: "ln-scn-c",
                      children: "Scenario 3: extra each month",
                    }),
                    o.jsx(j, {
                      id: "ln-scn-c",
                      inputMode: "decimal",
                      value: u,
                      onChange: (s) => C(s.target.value),
                    }),
                  ],
                }),
              ],
            }),
            o.jsx(H, {
              scenarios: w,
              metrics: S,
              caption: "Loan scenarios with different extra monthly payments",
            }),
          ],
        }),
      o.jsxs("section", {
        "aria-label": "Amortization schedule",
        className: "space-y-3",
        children: [
          o.jsx("div", {
            className: "no-print print:hidden flex flex-wrap gap-2",
            children: o.jsxs(N, {
              type: "button",
              variant: "outline",
              onClick: () => l((s) => !s),
              "aria-expanded": i,
              className: "gap-2",
              children: [
                i
                  ? o.jsx(q, { className: "h-4 w-4", "aria-hidden": "true" })
                  : o.jsx($, { className: "h-4 w-4", "aria-hidden": "true" }),
                i ? "Hide" : "Show",
                " full amortization schedule (",
                a.rows.length,
                " ",
                a.rows.length === 1 ? "payment" : "payments",
                ")",
              ],
            }),
          }),
          o.jsx(B, {
            gate: h,
            text: M,
            csv: k,
            filename: "loan-schedule.csv",
            label: "report",
          }),
          o.jsx("div", {
            className: i ? "" : "hidden print:block",
            children: o.jsx(A, {
              caption: "Loan amortization schedule",
              rows: a.rows,
              columns: y,
              rowKey: (s) => s.month,
            }),
          }),
        ],
      }),
      o.jsx(_, { tool: "loan-calculator" }),
    ],
  });
}
export { ft as default };
//# sourceMappingURL=LoanExtras-DkVbNvNv.js.map
