import { r as f, j as t } from "./vendor-react-D01g8YgM.js";
import { e as g, I as N } from "./index-B1CTyGtY.js";
import { T as Be, a as De, b as O, c as z } from "./tabs-Rb7RCr47.js";
import { C as _e } from "./CalcSteps-CMhW1YVy.js";
import { C as Ue, R as We } from "./ResultsTable-CpxaKI_z.js";
import { E as Ye, r as Oe } from "./history-B6kbrtr3.js";
import { B as ze, S as Ve } from "./BalanceLine-OvkIzsEo.js";
import { s as He } from "./steps-X1Sejec4.js";
import { a as Ze, t as V } from "./table-CJAX3ymv.js";
import { p as Ge } from "./numberInput-5hjoxJ5z.js";
import {
  c as be,
  f as ae,
  b as ge,
  i as Ke,
  y as Qe,
} from "./paymentDates-4j4nTGxO.js";
import "./csv-DBvSFDe9.js";
import "./copy-DcUvE8ta.js";
import "./share-2-B4TSO3Yd.js";
import "./dates-DoPZ1fRV.js";
const C = { monthly: 12, biweekly: 26, weekly: 52 },
  ne = { annual: 1, monthly: 12, daily: 365 },
  L = { monthly: "monthly", biweekly: "every 2 weeks", weekly: "weekly" },
  S = {
    payment: "same as the payments",
    annual: "annually",
    monthly: "monthly",
    daily: "daily",
    continuous: "continuously",
  },
  we = 5200,
  $ = (e) => Math.round(e * 100) / 100;
function I(e, n, a) {
  const i = e / 100,
    l = C[n];
  if (a === "payment") return i / l;
  if (a === "continuous") return Math.exp(i / l) - 1;
  const o = ne[a];
  return Math.pow(1 + i / o, o / l) - 1;
}
function G(e, n, a) {
  return n === 0 ? e / a : (e * n) / (1 - Math.pow(1 + n, -a));
}
function q(e) {
  if (!(
    typeof e.principal == "number" &&
    e.principal > 0 &&
    Number.isFinite(e.principal)
  ))
    return "Enter a loan amount greater than 0.";
  if (!(
    typeof e.annualPct == "number" &&
    e.annualPct >= 0 &&
    e.annualPct <= 100
  ))
    return "Enter an interest rate between 0% and 100%.";
  if (!(typeof e.years == "number" && e.years > 0 && e.years <= 100))
    return "Enter a term greater than 0 and at most 100 years.";
  const n = Math.round(e.years * C[e.freq ?? "monthly"]);
  return n < 1
    ? "The term is shorter than one payment."
    : n > we
      ? "That is more than the calculator can list."
      : "";
}
function K(e) {
  const n = Math.round(e.years * C[e.freq]),
    a = I(e.annualPct, e.freq, e.comp),
    i = G(e.principal, a, n),
    l = [];
  let o = e.principal,
    s = 0;
  for (let x = 1; x <= n; x++) {
    const h = o * a,
      y = x === n ? o : Math.min(o, i - h);
    ((o = x === n ? 0 : Math.max(0, o - y)),
      (s += h),
      l.push({ n: x, payment: y + h, interest: h, principal: y, balance: o }));
  }
  return {
    freq: e.freq,
    comp: e.comp,
    periodicRate: a,
    payments: n,
    payment: i,
    totalPaid: l.reduce((x, h) => x + h.payment, 0),
    totalInterest: s,
    rows: l,
  };
}
function Xe(e, n = (a) => String($(a))) {
  if (!(e.payment > 0) || !Number.isFinite(e.payment))
    throw new Error("Enter a payment greater than 0.");
  const a = C[e.freq];
  if (e.solveFor === "amount") {
    const y = q({
      principal: 1,
      annualPct: e.annualPct,
      years: e.years,
      freq: e.freq,
    });
    if (y && !y.startsWith("Enter a loan amount")) throw new Error(y);
    const m = Math.round(e.years * a),
      v = I(e.annualPct, e.freq, e.comp),
      c = v === 0 ? e.payment * m : (e.payment * (1 - Math.pow(1 + v, -m))) / v;
    return {
      solveFor: "amount",
      value: $(c),
      unit: "money",
      payments: m,
      steps: [
        {
          label: "Rate per payment",
          formula:
            e.comp === "payment"
              ? "annual rate / payments per year"
              : "(1 + annual rate / compounds per year) ^ (compounds per year / payments per year) - 1",
          inputs: {
            "annual rate": `${e.annualPct}%`,
            "payments per year": a,
            compounding: S[e.comp],
          },
          result: +v.toFixed(8),
        },
        {
          label: "Number of payments",
          formula: "years x payments per year",
          inputs: { years: e.years, "payments per year": a },
          result: m,
        },
        {
          label: "Loan amount",
          formula: "payment x (1 - (1 + i) ^ -n) / i",
          inputs: { payment: n(e.payment), i: +v.toFixed(8), n: m },
          result: n(c),
        },
      ],
    };
  }
  if (e.solveFor === "term") {
    const y = q({
      principal: e.principal,
      annualPct: e.annualPct,
      years: 1,
      freq: e.freq,
    });
    if (y) throw new Error(y);
    const m = I(e.annualPct, e.freq, e.comp),
      v = e.principal;
    if (m > 0 && e.payment <= v * m + 1e-9)
      throw new Error(
        `A payment of ${n(e.payment)} does not cover the interest of ${n(v * m)} for one period, so the loan would never be paid off. Raise the payment.`,
      );
    const c =
      m === 0
        ? v / e.payment
        : -Math.log(1 - (v * m) / e.payment) / Math.log(1 + m);
    if (c > we)
      throw new Error(
        "That payment would take more than 100 years to pay off.",
      );
    return {
      solveFor: "term",
      value: +(c / a).toFixed(4),
      unit: "years",
      payments: Math.ceil(c - 0.01),
      steps: [
        {
          label: "Rate per payment",
          formula: "see rate per payment",
          inputs: { "annual rate": `${e.annualPct}%`, compounding: S[e.comp] },
          result: +m.toFixed(8),
        },
        {
          label: "Number of payments",
          formula: "-ln(1 - P x i / payment) / ln(1 + i)",
          inputs: { P: n(v), i: +m.toFixed(8), payment: n(e.payment) },
          result: +c.toFixed(4),
        },
        {
          label: "Term in years",
          formula: "payments / payments per year",
          inputs: { payments: +c.toFixed(4), "payments per year": a },
          result: +(c / a).toFixed(4),
        },
      ],
    };
  }
  const i = q({
    principal: e.principal,
    annualPct: 0,
    years: e.years,
    freq: e.freq,
  });
  if (i) throw new Error(i);
  const l = Math.round(e.years * a),
    o = e.principal;
  if (e.payment * l < o - 1e-9)
    throw new Error(
      `Paying ${n(e.payment)} ${L[e.freq]} for ${l} payments totals ${n(e.payment * l)}, less than the ${n(o)} borrowed, so no interest rate (even negative) fits. Raise the payment or the term.`,
    );
  let s = 0,
    x = 100;
  if (G(o, I(x, e.freq, e.comp), l) < e.payment)
    throw new Error("That payment needs an interest rate above 100%.");
  for (let y = 0; y < 200; y++) {
    const m = (s + x) / 2;
    G(o, I(m, e.freq, e.comp), l) < e.payment ? (s = m) : (x = m);
  }
  const h = (s + x) / 2;
  return {
    solveFor: "rate",
    value: +h.toFixed(4),
    unit: "percent",
    payments: l,
    steps: [
      {
        label: "Number of payments",
        formula: "years x payments per year",
        inputs: { years: e.years, "payments per year": a },
        result: l,
      },
      {
        label: "Find the rate",
        formula:
          "Try annual rates until payment = P x i / (1 - (1 + i) ^ -n) matches the target (payments rise with the rate, so the match is found by halving the range)",
        inputs: {
          P: n(o),
          n: l,
          "target payment": n(e.payment),
          compounding: S[e.comp],
        },
        result: `${+h.toFixed(4)}%`,
      },
      {
        label: "Check",
        formula: "payment at that rate",
        inputs: { rate: `${+h.toFixed(4)}%` },
        result: n(G(o, I(h, e.freq, e.comp), l)),
      },
    ],
  };
}
function ve(e, n = (a) => String($(a))) {
  const a = q(e);
  if (a) throw new Error(a);
  if (!(e.fee >= 0) || !Number.isFinite(e.fee))
    throw new Error("Enter a fee of 0 or more.");
  if (e.fee >= e.principal)
    throw new Error("The fee must be smaller than the loan amount.");
  const i = K(e),
    l = e.principal - e.fee,
    o = i.payments,
    s = C[e.freq],
    x = (c) =>
      c === 0 ? i.payment * o : (i.payment * (1 - Math.pow(1 + c, -o))) / c;
  let h = 0,
    y = 1;
  for (; x(y) > l && y < 1e6;) y *= 2;
  for (let c = 0; c < 200; c++) {
    const B = (h + y) / 2;
    x(B) > l ? (h = B) : (y = B);
  }
  const m = (h + y) / 2,
    v = m * s * 100;
  return {
    payment: i.payment,
    payments: o,
    received: l,
    apr: +v.toFixed(4),
    extraCost: e.fee,
    steps: [
      {
        label: "Payment",
        formula: "the regular payment of the loan (the fee does not change it)",
        inputs: {
          amount: n(e.principal),
          rate: `${e.annualPct}%`,
          payments: o,
        },
        result: n(i.payment),
      },
      {
        label: "Money actually received",
        formula: "loan amount - upfront fee",
        inputs: { amount: n(e.principal), fee: n(e.fee) },
        result: n(l),
      },
      {
        label: "APR",
        formula:
          "the annual rate (periodic rate x payments per year) at which the payments are worth exactly the money received",
        inputs: { payment: n(i.payment), payments: o, received: n(l) },
        result: `${+v.toFixed(4)}%`,
      },
    ],
  };
}
function je(e, n, a) {
  const i = e / 100;
  return a === "continuous"
    ? Math.exp(i * n)
    : Math.pow(1 + i / ne[a], ne[a] * n);
}
function Fe(e, n, a, i) {
  if (!(e > 0) || !Number.isFinite(e))
    throw new Error(`Enter ${i} greater than 0.`);
  if (!(n >= 0 && n <= 100))
    throw new Error("Enter an interest rate between 0% and 100%.");
  if (!(a > 0 && a <= 100))
    throw new Error("Enter a term greater than 0 and at most 100 years.");
}
function Je(e, n, a, i, l = (o) => String($(o))) {
  Fe(e, n, a, "a loan amount");
  const o = je(n, a, i),
    s = e * o;
  return {
    dueAtMaturity: $(s),
    interest: $(s - e),
    steps: [
      {
        label: "Growth factor",
        formula:
          i === "continuous"
            ? "e ^ (rate x years)"
            : "(1 + rate / m) ^ (m x years)",
        inputs: {
          rate: `${n}%`,
          years: a,
          compounding:
            i === "continuous"
              ? "continuous"
              : i === "annual"
                ? "annual (m = 1)"
                : i === "monthly"
                  ? "monthly (m = 12)"
                  : "daily (m = 365)",
        },
        result: +o.toFixed(8),
      },
      {
        label: "Due at maturity",
        formula: "loan amount x growth factor",
        inputs: { "loan amount": l(e), "growth factor": +o.toFixed(8) },
        result: l(s),
      },
      {
        label: "Interest",
        formula: "due at maturity - loan amount",
        inputs: { due: l(s), "loan amount": l(e) },
        result: l(s - e),
      },
    ],
  };
}
function et(e, n, a, i, l = (o) => String($(o))) {
  Fe(e, n, a, "a face value");
  const o = je(n, a, i),
    s = e / o;
  return {
    presentValue: $(s),
    discount: $(e - s),
    steps: [
      {
        label: "Growth factor",
        formula:
          i === "continuous"
            ? "e ^ (yield x years)"
            : "(1 + yield / m) ^ (m x years)",
        inputs: { yield: `${n}%`, years: a },
        result: +o.toFixed(8),
      },
      {
        label: "Price today (present value)",
        formula: "face value / growth factor",
        inputs: { "face value": l(e), "growth factor": +o.toFixed(8) },
        result: l(s),
      },
      {
        label: "Discount",
        formula: "face value - price today",
        inputs: { "face value": l(e), price: l(s) },
        result: l(e - s),
      },
    ],
  };
}
function tt(e, n, a) {
  const i = C[e.freq];
  return [
    {
      label: "Rate per payment",
      formula:
        e.comp === "payment"
          ? "annual rate / payments per year"
          : e.comp === "continuous"
            ? "e ^ (annual rate / payments per year) - 1"
            : "(1 + annual rate / m) ^ (m / payments per year) - 1",
      inputs: {
        "annual rate": `${e.annualPct}%`,
        "payments per year": i,
        compounding: S[e.comp],
      },
      result: +n.periodicRate.toFixed(8),
    },
    {
      label: "Number of payments",
      formula: "years x payments per year",
      inputs: { years: e.years, "payments per year": i },
      result: n.payments,
    },
    {
      label: "Payment",
      formula: "amount x i / (1 - (1 + i) ^ -n)",
      inputs: {
        amount: a(e.principal),
        i: +n.periodicRate.toFixed(8),
        n: n.payments,
      },
      result: a(n.payment),
    },
    {
      label: "Total interest",
      formula: "add up the interest part of every payment",
      inputs: { payments: n.payments },
      result: a(n.totalInterest),
    },
    {
      label: "Total paid",
      formula: "amount + total interest",
      inputs: { amount: a(e.principal), "total interest": a(n.totalInterest) },
      result: a(n.totalPaid),
    },
  ];
}
const H = "border rounded px-2 py-2 w-full bg-background text-sm";
function re(e, n, a) {
  return n === "monthly"
    ? ge(e, a - 1)
    : Ke(e, (n === "biweekly" ? 14 : 7) * (a - 1));
}
const E = (e) => (e.trim() === "" ? null : Ge(e));
function w({ label: e, value: n, testId: a }) {
  return t.jsxs("div", {
    className: "p-3 rounded-lg border bg-card text-center",
    children: [
      t.jsx("p", { className: "text-xs text-muted-foreground", children: e }),
      t.jsx("p", {
        className: "text-lg font-semibold",
        "data-testid": a,
        children: n,
      }),
    ],
  });
}
const at = ({ m: e }) =>
  e
    ? t.jsx("p", {
        role: "alert",
        className: "text-sm text-red-600",
        "data-testid": "lw-error",
        children: e,
      })
    : null;
function rt({ summary: e }) {
  return (
    f.useEffect(() => {
      if (!e) return;
      const n = setTimeout(() => Oe("loan-calculator", e), 800);
      return () => clearTimeout(n);
    }, [e]),
    null
  );
}
function vt({ main: e, first: n, money: a, gate: i }) {
  const [l, o] = f.useState("freq"),
    [s, x] = f.useState("biweekly"),
    [h, y] = f.useState("payment"),
    [m, v] = f.useState(!1),
    [c, B] = f.useState("rate"),
    [le, Pe] = f.useState("536.82"),
    [se, ke] = f.useState("300"),
    [Q, $e] = f.useState("deferred"),
    [D, Ne] = f.useState("annual"),
    [oe, Ee] = f.useState("100000"),
    [ie, Se] = f.useState("100000"),
    [ue, Ce] = f.useState("4.5"),
    [ce, Me] = f.useState("15"),
    [pe, Te] = f.useState("0"),
    [de, Le] = f.useState("0"),
    _ = e
      ? {
          principal: e.principal,
          annualPct: e.annualPct,
          years: e.years,
          freq: s,
          comp: h,
        }
      : null,
    b = f.useMemo(() => (!_ || q(_) ? null : K(_)), [e, s, h]),
    U = f.useMemo(
      () =>
        e && !q({ ...e, freq: "monthly" })
          ? K({ ...e, freq: "monthly", comp: "payment" })
          : null,
      [e],
    );
  if (!e)
    return t.jsx("section", {
      "aria-label": "Loan workbench",
      className: "rounded-xl border bg-card p-4 text-sm text-muted-foreground",
      children:
        "Fix the loan amount, rate and term above to use the workbench.",
    });
  const X = [
    { key: "n", header: "Payment", get: (r) => r.n, align: "left" },
    {
      key: "date",
      header: "Date",
      get: (r) => Qe(re(n, s, r.n)),
      format: (r) => ae(re(n, s, r.n)),
      align: "left",
    },
    {
      key: "payment",
      header: "Payment amount",
      get: (r) => +r.payment.toFixed(2),
      format: (r) => a(r.payment),
      align: "right",
    },
    {
      key: "principal",
      header: "Principal",
      get: (r) => +r.principal.toFixed(2),
      format: (r) => a(r.principal),
      align: "right",
    },
    {
      key: "interest",
      header: "Interest",
      get: (r) => +r.interest.toFixed(2),
      format: (r) => a(r.interest),
      align: "right",
    },
    {
      key: "balance",
      header: "Remaining balance",
      get: (r) => +r.balance.toFixed(2),
      format: (r) => a(r.balance),
      align: "right",
    },
  ];
  let j = [],
    M = "",
    F = null,
    R = "",
    k = "";
  const W = (r) => {
    try {
      r();
    } catch (p) {
      ((F = t.jsx(at, {
        m: p instanceof Error ? p.message : "Check the inputs.",
      })),
        (j = []),
        (k = ""));
    }
  };
  (l === "freq" &&
    W(() => {
      if (!b || !_)
        throw new Error("Check the loan amount, rate and term above.");
      ((j = tt(_, b, a)), (M = `${L[s]} payments`));
      const r = re(n, s, b.payments),
        p = U ? U.totalInterest - b.totalInterest : 0;
      ((k = `${a(e.principal)} at ${e.annualPct}% for ${e.years} years, ${L[s]} payments (${S[h]}): ${a(b.payment)} each, ${a(b.totalInterest)} interest`),
        (R = V(b.rows, X)),
        (F = t.jsxs(t.Fragment, {
          children: [
            t.jsxs("div", {
              className: "grid grid-cols-2 sm:grid-cols-4 gap-3",
              children: [
                t.jsx(w, {
                  label: `Payment (${L[s]})`,
                  value: a(b.payment),
                  testId: "lw-payment",
                }),
                t.jsx(w, {
                  label: "Number of payments",
                  value: String(b.payments),
                  testId: "lw-count",
                }),
                t.jsx(w, {
                  label: "Total interest",
                  value: a(b.totalInterest),
                  testId: "lw-interest",
                }),
                t.jsx(w, {
                  label: "Last payment",
                  value: be(r),
                  testId: "lw-last",
                }),
              ],
            }),
            U &&
              s !== "monthly" &&
              t.jsxs("p", {
                className: "text-sm",
                "data-testid": "lw-vs-monthly",
                children: [
                  "Compared with monthly payments of ",
                  a(U.payment),
                  ": ",
                  p >= 0 ? `${a(p)} less interest` : `${a(-p)} more interest`,
                  ", and ",
                  C[s],
                  " payments of ",
                  a(b.payment),
                  " a year add up to ",
                  a(b.payment * C[s]),
                  " instead of ",
                  a(U.payment * 12),
                  ".",
                ],
              }),
            t.jsx(ze, {
              points: [
                { n: 0, balance: e.principal },
                ...b.rows.map((u) => ({ n: u.n, balance: u.balance })),
              ],
              money: a,
              startLabel: ae(n),
              endLabel: ae(r),
            }),
            t.jsxs("button", {
              type: "button",
              className: "text-sm underline",
              "aria-expanded": m,
              onClick: () => v((u) => !u),
              children: [
                m ? "Hide" : "Show",
                " the schedule (",
                b.payments,
                " payments)",
              ],
            }),
            t.jsx("div", {
              className: m ? "" : "hidden print:block",
              children: t.jsx(We, {
                caption: `Loan schedule, ${L[s]} payments`,
                rows: b.rows,
                columns: X,
                rowKey: (u) => u.n,
              }),
            }),
          ],
        })));
    }),
    l === "solve" &&
      W(() => {
        const r = E(le);
        if (r === null) throw new Error("Enter the target payment.");
        const p = {
            payment: r,
            freq: s,
            comp: h,
            principal: e.principal,
            annualPct: e.annualPct,
            years: e.years,
          },
          u = Xe({ solveFor: c, ...p }, a);
        ((j = u.steps), (M = `Solve for ${c}`));
        const T =
          u.unit === "money"
            ? a(u.value)
            : u.unit === "years"
              ? `${u.value} years (${u.payments} payments)`
              : `${u.value}%`;
        ((k = `Solve for ${c === "amount" ? "the loan amount" : c === "term" ? "the term" : "the rate"} with a ${L[s]} payment of ${a(r)}: ${T}`),
          (R = V(
            u.steps.map((P, Z) => ({
              step: Z + 1,
              label: P.label,
              result: String(P.result),
            })),
            [
              { key: "step", header: "Step", get: (P) => P.step },
              { key: "label", header: "What", get: (P) => P.label },
              { key: "result", header: "Result", get: (P) => P.result },
            ],
          )),
          (F = t.jsxs("div", {
            className: "grid grid-cols-2 gap-3",
            children: [
              t.jsx(w, {
                label:
                  c === "amount"
                    ? "Loan amount you can borrow"
                    : c === "term"
                      ? "Time to pay off"
                      : "Interest rate",
                value: T,
                testId: "lw-solved",
              }),
              t.jsx("p", {
                className: "text-sm self-center text-muted-foreground",
                children:
                  c === "amount"
                    ? "Uses the rate and term above."
                    : c === "term"
                      ? "Uses the loan amount and rate above."
                      : "Uses the loan amount and term above.",
              }),
            ],
          })));
      }),
    l === "fees" &&
      W(() => {
        const r = E(se);
        if (r === null) throw new Error("Enter the upfront fee (0 if none).");
        const p = ve(
          {
            principal: e.principal,
            annualPct: e.annualPct,
            years: e.years,
            freq: s,
            comp: h,
            fee: r,
          },
          a,
        );
        ((j = p.steps),
          (M = "Fees and APR"),
          (k = `${a(e.principal)} at ${e.annualPct}% with a ${a(r)} fee: APR ${p.apr}%`),
          (R = V(
            p.steps.map((u, T) => ({
              step: T + 1,
              label: u.label,
              result: String(u.result),
            })),
            [
              { key: "step", header: "Step", get: (u) => u.step },
              { key: "label", header: "What", get: (u) => u.label },
              { key: "result", header: "Result", get: (u) => u.result },
            ],
          )),
          (F = t.jsxs("div", {
            className: "grid grid-cols-2 sm:grid-cols-3 gap-3",
            children: [
              t.jsx(w, {
                label: "APR (effective annual cost)",
                value: `${p.apr}%`,
                testId: "lw-apr",
              }),
              t.jsx(w, { label: `Payment (${L[s]})`, value: a(p.payment) }),
              t.jsx(w, { label: "Money you receive", value: a(p.received) }),
              t.jsxs("p", {
                className: "col-span-full text-xs text-muted-foreground",
                children: [
                  "The fee is taken out of the loan, so you receive less than you repay. The APR is the rate at which your payments are worth exactly what you received. It is higher than the quoted ",
                  e.annualPct,
                  "% by the cost of the fee. Lenders' own APR figures can differ when other charges or an odd first period apply.",
                ],
              }),
            ],
          })));
      }),
    l === "lump" &&
      W(() => {
        if (Q === "deferred") {
          const r = Je(e.principal, e.annualPct, e.years, D, a);
          ((j = r.steps),
            (M = "Deferred loan"),
            (k = `Deferred ${a(e.principal)} at ${e.annualPct}% for ${e.years} years (${D}): ${a(r.dueAtMaturity)} due at the end`),
            (F = t.jsxs("div", {
              className: "grid grid-cols-2 gap-3",
              children: [
                t.jsx(w, {
                  label: "Due at maturity",
                  value: a(r.dueAtMaturity),
                  testId: "lw-due",
                }),
                t.jsx(w, { label: "Interest", value: a(r.interest) }),
              ],
            })));
        } else {
          const r = E(oe);
          if (r === null) throw new Error("Enter the face value.");
          const p = et(r, e.annualPct, e.years, D, a);
          ((j = p.steps),
            (M = "Zero-coupon bond"),
            (k = `Zero-coupon bond, face ${a(r)} at a ${e.annualPct}% yield for ${e.years} years (${D}): price today ${a(p.presentValue)}`),
            (F = t.jsxs("div", {
              className: "grid grid-cols-2 gap-3",
              children: [
                t.jsx(w, {
                  label: "Price today (present value)",
                  value: a(p.presentValue),
                  testId: "lw-pv",
                }),
                t.jsx(w, {
                  label: "Discount to face value",
                  value: a(p.discount),
                }),
              ],
            })));
        }
        R = V(
          j.map((r, p) => ({
            step: p + 1,
            label: r.label,
            result: String(r.result),
          })),
          [
            { key: "step", header: "Step", get: (r) => r.step },
            { key: "label", header: "What", get: (r) => r.label },
            { key: "result", header: "Result", get: (r) => r.result },
          ],
        );
      }));
  let me = null;
  l === "compare" &&
    W(() => {
      const r = E(de),
        p = E(pe),
        u = E(ie),
        T = E(ue),
        P = E(ce);
      if (r === null || p === null || u === null || T === null || P === null)
        throw new Error("Fill in every box for loan B (fee 0 if none).");
      const Z = (d, he, ye, fe, Ae, ee) => {
          const te = {
              principal: ye,
              annualPct: fe,
              years: Ae,
              freq: "monthly",
              comp: "payment",
            },
            xe = q(te);
          if (xe) throw new Error(`${he}: ${xe}`);
          const Y = K(te),
            Ie = ee > 0 ? ve({ ...te, fee: ee }).apr : fe;
          return {
            id: d,
            name: he,
            values: {
              amount: ye,
              payment: Y.payment,
              payments: Y.payments,
              interest: Y.totalInterest,
              total: Y.totalPaid + ee,
              apr: Ie,
              payoff: be(ge(n, Y.payments - 1)),
            },
          };
        },
        A = [
          Z("a", "Loan A (above)", e.principal, e.annualPct, e.years, r),
          Z("b", "Loan B", u, T, P, p),
        ],
        Re = [
          {
            key: "amount",
            label: "Loan amount",
            kind: "number",
            format: (d) => a(Number(d)),
          },
          {
            key: "payment",
            label: "Monthly payment",
            kind: "number",
            format: (d) => a(Number(d)),
            better: "lower",
          },
          {
            key: "payments",
            label: "Number of payments",
            kind: "number",
            format: (d) => String(Math.round(Number(d))),
            better: "lower",
          },
          { key: "payoff", label: "Payoff month", kind: "text" },
          {
            key: "interest",
            label: "Total interest",
            kind: "number",
            format: (d) => a(Number(d)),
            better: "lower",
          },
          {
            key: "total",
            label: "Total cost (payments + fee)",
            kind: "number",
            format: (d) => a(Number(d)),
            better: "lower",
          },
          {
            key: "apr",
            label: "APR",
            kind: "number",
            format: (d) => `${+Number(d).toFixed(3)}%`,
            better: "lower",
          },
        ];
      ((M = "Compare two loans"),
        (k = `Loan A ${a(A[0].values.payment)}/month, ${a(A[0].values.interest)} interest vs loan B ${a(A[1].values.payment)}/month, ${a(A[1].values.interest)} interest`),
        (R = V(A, [
          { key: "name", header: "Loan", get: (d) => d.name },
          {
            key: "amount",
            header: "Amount",
            get: (d) => +d.values.amount.toFixed(2),
          },
          {
            key: "payment",
            header: "Monthly payment",
            get: (d) => +d.values.payment.toFixed(2),
          },
          {
            key: "interest",
            header: "Total interest",
            get: (d) => +d.values.interest.toFixed(2),
          },
          {
            key: "total",
            header: "Total cost",
            get: (d) => +d.values.total.toFixed(2),
          },
          { key: "apr", header: "APR %", get: (d) => +d.values.apr.toFixed(3) },
        ])),
        (j = []),
        (me = t.jsx(Ve, {
          scenarios: A,
          metrics: Re,
          caption: "Two loans side by side",
        })));
    });
  const qe = [
      M,
      k,
      "",
      ...(j.length ? ["How this was calculated", He(j), ""] : []),
      l === "freq" && b
        ? ["Schedule", Ze(b.rows, X), ""].join(`
`)
        : "",
      "Calculated with FreeDailyPro.com",
    ].join(`
`),
    J = t.jsxs("div", {
      className: "grid grid-cols-2 gap-3 max-w-lg",
      children: [
        t.jsxs("div", {
          children: [
            t.jsx(g, { htmlFor: "lw-freq", children: "Payment frequency" }),
            t.jsxs("select", {
              id: "lw-freq",
              className: H,
              value: s,
              onChange: (r) => x(r.target.value),
              children: [
                t.jsx("option", {
                  value: "monthly",
                  children: "Monthly (12 a year)",
                }),
                t.jsx("option", {
                  value: "biweekly",
                  children: "Every 2 weeks (26 a year)",
                }),
                t.jsx("option", {
                  value: "weekly",
                  children: "Weekly (52 a year)",
                }),
              ],
            }),
          ],
        }),
        t.jsxs("div", {
          children: [
            t.jsx(g, { htmlFor: "lw-comp", children: "Interest compounds" }),
            t.jsx("select", {
              id: "lw-comp",
              className: H,
              value: h,
              onChange: (r) => y(r.target.value),
              children: Object.keys(S).map((r) =>
                t.jsx(
                  "option",
                  { value: r, children: S[r][0].toUpperCase() + S[r].slice(1) },
                  r,
                ),
              ),
            }),
          ],
        }),
      ],
    });
  return t.jsxs("section", {
    "aria-label": "Loan workbench",
    className: "mt-8 space-y-4 calc-print-area",
    "data-testid": "loan-workbench",
    children: [
      t.jsx("style", { children: Ue }),
      t.jsx("h3", {
        className: "text-lg font-semibold",
        children: "Loan workbench",
      }),
      t.jsxs("p", {
        className: "text-sm text-muted-foreground no-print print:hidden",
        children: [
          "Uses the loan amount, rate and term above (",
          a(e.principal),
          ", ",
          e.annualPct,
          "%, ",
          e.years,
          " years).",
        ],
      }),
      t.jsxs(Be, {
        value: l,
        onValueChange: o,
        children: [
          t.jsxs(De, {
            className:
              "grid grid-cols-2 sm:grid-cols-5 w-full h-auto no-print print:hidden",
            children: [
              t.jsx(O, { value: "freq", children: "Payment frequency" }),
              t.jsx(O, { value: "solve", children: "Solve for" }),
              t.jsx(O, { value: "fees", children: "Fees and APR" }),
              t.jsx(O, { value: "lump", children: "Deferred and zero-coupon" }),
              t.jsx(O, { value: "compare", children: "Compare two loans" }),
            ],
          }),
          t.jsxs(z, {
            value: "freq",
            className: "mt-4 space-y-4",
            children: [J, l === "freq" && F],
          }),
          t.jsxs(z, {
            value: "solve",
            className: "mt-4 space-y-4",
            children: [
              t.jsxs("div", {
                className: "grid grid-cols-2 gap-3 max-w-lg",
                children: [
                  t.jsxs("div", {
                    children: [
                      t.jsx(g, { htmlFor: "lw-solve", children: "Solve for" }),
                      t.jsxs("select", {
                        id: "lw-solve",
                        className: H,
                        value: c,
                        onChange: (r) => B(r.target.value),
                        children: [
                          t.jsx("option", {
                            value: "rate",
                            children: "Interest rate",
                          }),
                          t.jsx("option", {
                            value: "amount",
                            children: "Loan amount",
                          }),
                          t.jsx("option", { value: "term", children: "Term" }),
                        ],
                      }),
                    ],
                  }),
                  t.jsxs("div", {
                    children: [
                      t.jsx(g, {
                        htmlFor: "lw-target",
                        children: "Target payment",
                      }),
                      t.jsx(N, {
                        id: "lw-target",
                        inputMode: "decimal",
                        value: le,
                        onChange: (r) => Pe(r.target.value),
                      }),
                    ],
                  }),
                ],
              }),
              J,
              l === "solve" && F,
            ],
          }),
          t.jsxs(z, {
            value: "fees",
            className: "mt-4 space-y-4",
            children: [
              t.jsxs("div", {
                className: "max-w-xs",
                children: [
                  t.jsx(g, { htmlFor: "lw-fee", children: "Upfront fee" }),
                  t.jsx(N, {
                    id: "lw-fee",
                    inputMode: "decimal",
                    value: se,
                    onChange: (r) => ke(r.target.value),
                  }),
                ],
              }),
              J,
              l === "fees" && F,
            ],
          }),
          t.jsxs(z, {
            value: "lump",
            className: "mt-4 space-y-4",
            children: [
              t.jsxs("div", {
                className: "grid grid-cols-2 gap-3 max-w-lg",
                children: [
                  t.jsxs("div", {
                    children: [
                      t.jsx(g, { htmlFor: "lw-lump", children: "Type" }),
                      t.jsxs("select", {
                        id: "lw-lump",
                        className: H,
                        value: Q,
                        onChange: (r) => $e(r.target.value),
                        children: [
                          t.jsx("option", {
                            value: "deferred",
                            children:
                              "Deferred loan (pay everything at the end)",
                          }),
                          t.jsx("option", {
                            value: "zero",
                            children: "Zero-coupon bond (price today)",
                          }),
                        ],
                      }),
                    ],
                  }),
                  t.jsxs("div", {
                    children: [
                      t.jsx(g, {
                        htmlFor: "lw-lcomp",
                        children: "Compounding",
                      }),
                      t.jsxs("select", {
                        id: "lw-lcomp",
                        className: H,
                        value: D,
                        onChange: (r) => Ne(r.target.value),
                        children: [
                          t.jsx("option", {
                            value: "annual",
                            children: "Annually",
                          }),
                          t.jsx("option", {
                            value: "monthly",
                            children: "Monthly",
                          }),
                          t.jsx("option", {
                            value: "daily",
                            children: "Daily",
                          }),
                          t.jsx("option", {
                            value: "continuous",
                            children: "Continuously",
                          }),
                        ],
                      }),
                    ],
                  }),
                  Q === "zero" &&
                    t.jsxs("div", {
                      children: [
                        t.jsx(g, {
                          htmlFor: "lw-face",
                          children: "Face value paid at maturity",
                        }),
                        t.jsx(N, {
                          id: "lw-face",
                          inputMode: "decimal",
                          value: oe,
                          onChange: (r) => Ee(r.target.value),
                        }),
                      ],
                    }),
                ],
              }),
              l === "lump" && F,
            ],
          }),
          t.jsxs(z, {
            value: "compare",
            className: "mt-4 space-y-4",
            children: [
              t.jsxs("div", {
                className: "grid grid-cols-2 sm:grid-cols-4 gap-3",
                children: [
                  t.jsxs("div", {
                    children: [
                      t.jsx(g, { htmlFor: "lw-afee", children: "Loan A fee" }),
                      t.jsx(N, {
                        id: "lw-afee",
                        inputMode: "decimal",
                        value: de,
                        onChange: (r) => Le(r.target.value),
                      }),
                    ],
                  }),
                  t.jsxs("div", {
                    children: [
                      t.jsx(g, {
                        htmlFor: "lw-bamt",
                        children: "Loan B amount",
                      }),
                      t.jsx(N, {
                        id: "lw-bamt",
                        inputMode: "decimal",
                        value: ie,
                        onChange: (r) => Se(r.target.value),
                      }),
                    ],
                  }),
                  t.jsxs("div", {
                    children: [
                      t.jsx(g, {
                        htmlFor: "lw-brate",
                        children: "Loan B rate (%)",
                      }),
                      t.jsx(N, {
                        id: "lw-brate",
                        inputMode: "decimal",
                        value: ue,
                        onChange: (r) => Ce(r.target.value),
                      }),
                    ],
                  }),
                  t.jsxs("div", {
                    children: [
                      t.jsx(g, {
                        htmlFor: "lw-byrs",
                        children: "Loan B years",
                      }),
                      t.jsx(N, {
                        id: "lw-byrs",
                        inputMode: "decimal",
                        value: ce,
                        onChange: (r) => Me(r.target.value),
                      }),
                    ],
                  }),
                  t.jsxs("div", {
                    children: [
                      t.jsx(g, { htmlFor: "lw-bfee", children: "Loan B fee" }),
                      t.jsx(N, {
                        id: "lw-bfee",
                        inputMode: "decimal",
                        value: pe,
                        onChange: (r) => Te(r.target.value),
                      }),
                    ],
                  }),
                ],
              }),
              l === "compare" && (me ?? F),
            ],
          }),
        ],
      }),
      t.jsx(rt, { summary: k }),
      t.jsx(_e, { steps: j }),
      k &&
        t.jsx(Ye, {
          gate: i,
          text: qe,
          csv: R,
          filename: `loan-${l}.csv`,
          label: "result",
        }),
    ],
  });
}
export { vt as default };
//# sourceMappingURL=LoanWorkbench-bbP73gp2.js.map
