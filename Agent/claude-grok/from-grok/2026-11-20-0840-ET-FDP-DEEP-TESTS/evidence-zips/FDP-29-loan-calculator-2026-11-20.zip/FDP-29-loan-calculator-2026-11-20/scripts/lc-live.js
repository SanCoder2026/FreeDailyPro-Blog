// loan-calculator: main calculator + Loan workbench cases via the UI (reading results only; no exports). Page reloaded per case.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/29-loan-calculator/live/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const C = [
 ['L01 default', {}], ['L02 rate 0', { 'Interest rate': '0' }], ['L03 60 months', { 'Loan term': '60', 'Term unit': 'months' }],
 ['L04 flat 10% 5y', { 'Interest method': 'flat', 'Interest rate': '10', 'Loan term': '5' }],
 ['L05 extra 200', { 'Extra payment': '200' }], ['L06 INR 500000 9% 20y', { 'Currency': 'INR', 'Loan amount': '500000', 'Interest rate': '9', 'Loan term': '20' }],
 ['L07 JPY 3000000 1.5% 35y', { 'Currency': 'JPY', 'Loan amount': '3000000', 'Interest rate': '1.5', 'Loan term': '35' }],
 ['L08 EUR 25000 7% 5y', { 'Currency': 'EUR', 'Loan amount': '25000', 'Interest rate': '7', 'Loan term': '5' }],
 ['L09 amount 0', { 'Loan amount': '0' }], ['L10 amount abc', { 'Loan amount': 'abc' }], ['L11 rate 101', { 'Interest rate': '101' }],
 ['L12 term 0', { 'Loan term': '0' }], ['L13 term 101y', { 'Loan term': '101' }], ['L14 extra -5', { 'Extra payment': '-5' }],
 ['L15 extra 200000', { 'Extra payment': '200000' }], ['L16 term 0.5y', { 'Loan term': '0.5' }], ['L17 amount 400.000', { 'Loan amount': '400.000' }],
 ['L18 term 2.5 months', { 'Loan term': '2.5', 'Term unit': 'months' }], ['L19 extra 200 then flat', { 'Extra payment': '200', 'Interest method': 'flat' }],
 ['L20 car 35000 6.9% 72mo', { 'Loan amount': '35,000', 'Interest rate': '6.9', 'Loan term': '72', 'Term unit': 'months' }],
 ['W01 freq monthly/payment', { tab: 'Payment frequency', '#lw-freq': 'monthly' }],
 ['W02 weekly', { tab: 'Payment frequency', '#lw-freq': 'weekly' }],
 ['W03 biweekly comp monthly', { tab: 'Payment frequency', '#lw-comp': 'monthly' }],
 ['W04 biweekly comp daily', { tab: 'Payment frequency', '#lw-comp': 'daily' }],
 ['W05 solve rate 600', { tab: 'Solve for', '#lw-solve': 'rate', '#lw-target': '600' }],
 ['W06 solve amount 600', { tab: 'Solve for', '#lw-solve': 'amount', '#lw-target': '600' }],
 ['W07 solve term 600', { tab: 'Solve for', '#lw-solve': 'term', '#lw-target': '600' }],
 ['W08 solve term 400', { tab: 'Solve for', '#lw-solve': 'term', '#lw-target': '400' }],
 ['W09 solve rate 200', { tab: 'Solve for', '#lw-solve': 'rate', '#lw-target': '200' }],
 ['W10 fees 2000', { tab: 'Fees and APR', '#lw-fee': '2000' }],
 ['W11 fees default 300', { tab: 'Fees and APR' }],
 ['W12 fees 100000', { tab: 'Fees and APR', '#lw-fee': '100000' }],
 ['W13 deferred annual', { tab: 'Deferred and zero-coupon' }],
 ['W14 zero-coupon', { tab: 'Deferred and zero-coupon', '#lw-lump': 'zero' }],
 ['W15 compare default', { tab: 'Compare two loans' }],
 ['W16 compare B 4.5% 15y fee 3000', { tab: 'Compare two loans', '#lw-bfee': '3000' }],
 ['W18 solve default (no change)', { tab: 'Solve for' }],
 ['W19 compare default monthly A', { tab: 'Compare two loans' }],
 ['W17 main changed then solve rate (target stays 536.82?)', { 'Loan amount': '50000', tab: 'Solve for', '#lw-solve': 'rate' }],
];
const pick = process.argv[2] ? process.argv[2].split(',') : null; const outf = process.argv[3] || 'cases.json';
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 1000 } }); const p = await c.newPage(); p.setDefaultTimeout(8000);
 const R = { t: now(), cases: [] };
 for (const [id, set] of C) { if (pick && !pick.includes(id.split(' ')[0])) continue;
  await p.goto('https://www.freedailypro.com/tool/loan-calculator', { waitUntil: 'domcontentloaded' }); await p.locator('[aria-label="Loan amount"]').waitFor(); await p.waitForTimeout(800);
  const keys = Object.keys(set).filter(k => k !== 'tab' && !k.startsWith('#'));
  for (const k of keys) { const el = p.locator(`main [aria-label="${k}"]`).first(); const tag = await el.evaluate(e => e.tagName); if (tag === 'SELECT') await el.selectOption(set[k]); else await el.fill(set[k]); await p.waitForTimeout(250); }
  if (set.tab) { await p.locator('[data-testid=loan-workbench]').getByRole('tab', { name: set.tab }).click(); await p.waitForTimeout(500);
   for (const k of Object.keys(set).filter(k => k.startsWith('#'))) { const el = p.locator(k); const tag = await el.evaluate(e => e.tagName); if (tag === 'SELECT') await el.selectOption(set[k]); else await el.fill(set[k]); await p.waitForTimeout(300); } }
  await p.waitForTimeout(900);
  const r = await p.evaluate(() => { const o = {}; ['loan-payment', 'loan-total', 'loan-interest', 'loan-payoff-detail', 'lw-payment', 'lw-count', 'lw-interest', 'lw-last', 'lw-vs-monthly', 'lw-error'].forEach(k => { const e = document.querySelector(`[data-testid=${k}]`); if (e) o[k] = e.innerText.replace(/\s+/g, ' ').trim(); });
   o.alerts = [...document.querySelectorAll('main [role=alert], main .text-destructive, [data-testid=loan-paid-m1]')].map(e => e.innerText.trim()); o.url = location.search;
   const w = document.querySelector('[data-testid=loan-workbench] [role=tabpanel][data-state=active]'); o.wb = w ? w.innerText.replace(/\s+/g, ' ').slice(0, 1500) : '';
   const sc = document.querySelector('[data-testid=scenario-compare]'); o.scen = sc ? sc.innerText.replace(/\s+/g, ' ').slice(0, 900) : '';
   const t = document.querySelector('[data-testid=tool-area]'); o.area = t ? t.innerText.replace(/\s+/g, ' ').slice(0, 1800) : ''; return o; });
  R.cases.push({ id, set, ...r }); const n = id.split(' ')[0]; if (['L01', 'L04', 'L06', 'L15', 'W05', 'W10', 'W15'].includes(n)) await p.screenshot({ path: OUT + 'case-' + n + '.png' });
  console.log(id, '|', r['loan-payment'], '|', r['lw-payment'] || '', '|', r.alerts.join(' / '), '|', (r['lw-error'] || '')); }
 R.t2 = now(); fs.writeFileSync(OUT + outf, JSON.stringify(R, null, 1)); await b.close(); })();
