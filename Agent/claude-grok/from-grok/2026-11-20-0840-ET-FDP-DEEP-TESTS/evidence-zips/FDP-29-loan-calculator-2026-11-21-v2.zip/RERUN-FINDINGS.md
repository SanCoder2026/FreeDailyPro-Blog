Sent: 2026-11-21 20:04 ET

# RERUN-FINDINGS

This package is version v2 (FDP-29-loan-calculator-2026-11-21-v2.zip). It **supersedes/extends**: FDP-29-loan-calculator-2026-11-20.zip. Earlier zips are untouched (frozen); anything not mentioned here is unchanged from them.

Run 19:42 ET `lc-gate.js` (4 contexts used). Two contexts loaded with uses left (A_csv_first, B_save_first), one at 0.
- A_csv_first: all 9 actions (main bar Download CSV / Copy report / Print; workbench bar Download CSV / Copy result / Print; result Copy / Save as text / Print): usageToday **0 -> 0, also after reload**.
- B_save_first: Save as text x2, Download CSV, Copy result: 0 -> 0.
- At 0: all 9 actions work with no dialog (10 -> 10).
- Same policy question as FDP-28: nothing is counted on this tool. Counters are display-only.
Evidence: live/gate.json, live/downloads/.
