Sent: 2026-11-21 20:04 ET

# FDP-30 jwt-decoder: rerun after the 7:00 PM ET reset (Nov 21 2026)

Run 19:43 ET `jd-gate.js`: contexts 0-3 loaded at 0 (10), contexts 4 and 5 loaded with uses left.
- A_csv_first context: Copy result, Save as text, Print, Copy result again: usageToday **0 -> 0 throughout and after reload**.
- B_save_first context: Save as text twice, Copy result: 0 -> 0.
- At 0 (unchanged): all four actions work, 10 -> 10.
- Conclusion: decode/copy/save/print take no trial use on the display counter. Claude/Santosh should confirm that is intended (JWT decoder is a Professional Tool with a 10-use trial). Selection copy not separately re-run.
Evidence: live/gate.json.

(Rows run in order: 4,5,7,8,11,14,20 then 28-33,40,56,57,69,73. No sign-in, no payment, no ads clicked, no admin, no API/MCP. Counters are display-only evidence.)
