Sent: 2026-11-21 20:04 ET

# RERUN-FINDINGS

This package is version v2 (FDP-30-jwt-decoder-2026-11-21-v2.zip). It **supersedes/extends**: FDP-30-jwt-decoder-2026-11-21.zip. Earlier zips are untouched (frozen); anything not mentioned here is unchanged from them.

Run 19:43 ET `jd-gate.js`: contexts 0-3 loaded at 0 (10), contexts 4 and 5 loaded with uses left.
- A_csv_first context: Copy result, Save as text, Print, Copy result again: usageToday **0 -> 0 throughout and after reload**.
- B_save_first context: Save as text twice, Copy result: 0 -> 0.
- At 0 (unchanged): all four actions work, 10 -> 10.
- Conclusion: decode/copy/save/print take no trial use on the display counter. Claude/Santosh should confirm that is intended (JWT decoder is a Professional Tool with a 10-use trial). Selection copy not separately re-run.
Evidence: live/gate.json.
