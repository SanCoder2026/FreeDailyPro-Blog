import { r as f, j as t } from "./vendor-react-D01g8YgM.js";
import { T as h } from "./ToolPage-DwLoDncN.js";
import { e as l, T as g, N as y } from "./index-B1CTyGtY.js";
import { T as v } from "./ToolInfoSection-C0i6Zbwo.js";
import { u as N } from "./useLogToolUsage-BdvvKW0n.js";
import { f as j } from "./utf8-C8MzR3N4.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./copyText-DPnES92p.js";
function T(o) {
  return o
    .trim()
    .replace(/^bearer(\s+|$)/i, "")
    .replace(/\s+/g, "");
}
function p(o, a) {
  let r;
  try {
    r = j(o);
  } catch {
    return {
      error: `The ${a} is not valid Base64URL text, so it could not be decoded.`,
    };
  }
  try {
    return { value: JSON.parse(r) };
  } catch {
    return { error: `The ${a} decoded to text, but it is not valid JSON.` };
  }
}
function b(o) {
  const a = T(o);
  if (!a) return null;
  const r = a.split(".");
  if (r.length !== 3)
    return {
      ok: !1,
      error: `Invalid JWT format: expected 3 parts separated by dots, found ${r.length}.`,
    };
  const e = p(r[0], "header");
  if ("error" in e) return { ok: !1, error: e.error };
  const s = p(r[1], "payload");
  if ("error" in s) return { ok: !1, error: s.error };
  const d =
    e.value && typeof e.value == "object" && typeof e.value.alg == "string"
      ? e.value.alg
      : null;
  return { ok: !0, header: e.value, payload: s.value, alg: d };
}
const w = (o) => o !== null && o.trim().toLowerCase() === "none";
function k(o, a, r) {
  const e = a * 1e3;
  return o === "exp"
    ? e < r
      ? "expired"
      : "not-expired"
    : o === "nbf"
      ? e > r
        ? "not-yet-valid"
        : "active"
      : null;
}
const S = [
  ["iat", "Issued at"],
  ["nbf", "Not before"],
  ["exp", "Expires"],
];
function u(o) {
  if (!o || typeof o != "object") return [];
  const a = o;
  return S.flatMap(([r, e]) =>
    typeof a[r] == "number"
      ? [{ k: r, label: e, date: new Date(a[r] * 1e3) }]
      : [],
  );
}
const c = {
  what: "Decodes a JSON Web Token (JWT) and displays its header and payload contents in readable form, useful for debugging authentication issues.",
  how: 'Paste your JWT, and the decoded header and payload are displayed automatically. A leading "Bearer " prefix and any line breaks are ignored. Time claims are shown in UTC and in your local time.',
  tip: "Decoding a JWT here reveals its contents but doesn't verify its cryptographic signature — a token can be decoded and read without confirming it's actually valid or unaltered.",
};
function re() {
  const [o, a] = f.useState(""),
    r = b(o),
    e = r ? (r.ok ? r : { error: r.error }) : null,
    s = !!r && r.ok && w(r.alg),
    d = Date.now();
  return (
    N(e),
    t.jsxs(h, {
      children: [
        t.jsxs("div", {
          className: "space-y-4",
          children: [
            t.jsxs("div", {
              children: [
                t.jsx(l, { htmlFor: "jwt-input", children: "JWT Token" }),
                t.jsx(g, {
                  id: "jwt-input",
                  value: o,
                  onChange: (n) => a(n.target.value),
                  placeholder:
                    "Paste your JWT here (a leading Bearer prefix is removed automatically)...",
                  className: "font-mono text-sm min-h-[100px]",
                }),
              ],
            }),
            e &&
              "error" in e &&
              t.jsx("p", {
                role: "alert",
                className: "text-sm text-destructive",
                children: e.error,
              }),
            s &&
              t.jsx(y, {
                className: "text-sm",
                role: "alert",
                children:
                  'Warning: this token uses alg "none", meaning it is unsigned. Anyone can create or alter such a token, so a server must never accept it as proof of identity.',
              }),
            e &&
              "header" in e &&
              t.jsxs("div", {
                className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                children: [
                  t.jsxs("div", {
                    className: "p-4 rounded-lg border bg-card",
                    children: [
                      t.jsx(l, {
                        className: "text-xs text-muted-foreground",
                        children: "Header",
                      }),
                      t.jsx("pre", {
                        className: "text-sm font-mono mt-2 whitespace-pre-wrap",
                        children: JSON.stringify(e.header, null, 2),
                      }),
                    ],
                  }),
                  t.jsxs("div", {
                    className: "p-4 rounded-lg border bg-card",
                    children: [
                      t.jsx(l, {
                        className: "text-xs text-muted-foreground",
                        children: "Payload",
                      }),
                      t.jsx("pre", {
                        className: "text-sm font-mono mt-2 whitespace-pre-wrap",
                        children: JSON.stringify(e.payload, null, 2),
                      }),
                    ],
                  }),
                ],
              }),
            e &&
              "payload" in e &&
              u(e.payload).length > 0 &&
              t.jsx("div", {
                className: "p-4 rounded-lg border bg-card space-y-1 text-sm",
                children: u(e.payload).map((n) => {
                  const i = k(n.k, n.date.getTime() / 1e3, d),
                    x = i === "expired" || i === "not-yet-valid",
                    m =
                      i === "expired"
                        ? "Expired"
                        : i === "not-expired"
                          ? "Not expired"
                          : i === "not-yet-valid"
                            ? "Not yet valid"
                            : null;
                  return t.jsxs(
                    "div",
                    {
                      children: [
                        t.jsxs("p", {
                          children: [
                            t.jsxs("span", {
                              className: "text-muted-foreground",
                              children: [n.label, " (", n.k, "):"],
                            }),
                            " ",
                            t.jsx("span", {
                              className: "font-mono",
                              children: n.date.toISOString(),
                            }),
                            " ",
                            t.jsx("span", {
                              className: "text-xs text-muted-foreground",
                              children: "UTC",
                            }),
                            m &&
                              t.jsx("span", {
                                className: x
                                  ? "ml-2 text-destructive font-medium"
                                  : "ml-2 text-green-600 font-medium",
                                children: m,
                              }),
                          ],
                        }),
                        t.jsxs("p", {
                          className: "text-xs text-muted-foreground pl-2",
                          children: [
                            "Local time: ",
                            t.jsx("span", {
                              className: "font-mono",
                              children: n.date.toLocaleString(void 0, {
                                dateStyle: "medium",
                                timeStyle: "long",
                              }),
                            }),
                          ],
                        }),
                      ],
                    },
                    n.k,
                  );
                }),
              }),
          ],
        }),
        t.jsx(v, { whatIsIt: c.what, howToUse: c.how, tip: c.tip }),
      ],
    })
  );
}
export { re as default };
//# sourceMappingURL=JwtDecoder-4zWjWHdb.js.map
