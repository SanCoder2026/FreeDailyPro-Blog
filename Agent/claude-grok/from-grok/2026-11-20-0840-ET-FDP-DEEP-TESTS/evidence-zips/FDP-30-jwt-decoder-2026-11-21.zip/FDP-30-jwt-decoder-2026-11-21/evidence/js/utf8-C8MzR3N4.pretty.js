const l = (e) => new TextEncoder().encode(e),
  c = (e, t = !0) => new TextDecoder("utf-8", { fatal: t }).decode(e);
function f(e, t = !1) {
  let o = "";
  for (let a = 0; a < e.length; a += 32768)
    o += String.fromCharCode.apply(null, Array.from(e.subarray(a, a + 32768)));
  let s = btoa(o);
  return (
    t && (s = s.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")),
    s
  );
}
function d(e) {
  let t = e
    .trim()
    .replace(/^data:[^,]*;base64,/i, "")
    .replace(/\s+/g, "");
  if (
    ((t = t.replace(/-/g, "+").replace(/_/g, "/")),
    !/^[A-Za-z0-9+/]*={0,2}$/.test(t))
  )
    throw new Error("Not valid Base64");
  if (((t = t.replace(/=+$/, "")), t.length % 4 === 1))
    throw new Error("Not valid Base64");
  t += "=".repeat((4 - (t.length % 4)) % 4);
  const o = atob(t),
    s = new Uint8Array(o.length);
  for (let a = 0; a < o.length; a++) s[a] = o.charCodeAt(a);
  return s;
}
const g = (e, t = !1) => f(l(e), t),
  h = (e) => c(d(e));
function u(e) {
  const t = e.match(/^\s*data:[^,]*;base64,/i),
    o = t ? t[0].length : 0;
  let s = !1;
  for (let n = o; n < e.length; n++) {
    const r = e[n];
    if (!/\s/.test(r)) {
      if (r === "=") {
        s = !0;
        continue;
      }
      if (s || !/[A-Za-z0-9+/_-]/.test(r)) {
        const i =
          r ===
          `
`
            ? "line break"
            : `"${r}"`;
        return {
          position: n + 1,
          message:
            s && /[A-Za-z0-9+/_-]/.test(r)
              ? `Not valid Base64: data continues after the "=" padding at position ${n + 1}.`
              : `Not valid Base64: unexpected ${i} at position ${n + 1}.`,
        };
      }
    }
  }
  const a = e.slice(o).replace(/[\s=]/g, "").length;
  return a === 0 && !e.slice(o).trim()
    ? {
        position: 1,
        message: "Nothing to decode. Paste a Base64 string first.",
      }
    : a % 4 === 1
      ? {
          position: e.length,
          message:
            "Not valid Base64: the length is wrong (one character left over at the end).",
        }
      : null;
}
const p = (e) =>
  Array.from(e, (t) => t.toString(16).padStart(2, "0")).join(" ");
export { d as a, u as b, p as c, f as d, l as e, h as f, g as t, c as u };
//# sourceMappingURL=utf8-C8MzR3N4.js.map
