// jwt-decoder: token cases via the UI (paste/fill only), page errors, network check for token leakage, and the selection-copy gate. Test tokens are synthetic (signed with a dummy secret).
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/30-jwt-decoder/live/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const T = JSON.parse(fs.readFileSync('/workspace/deep/30-jwt-decoder/testfiles/tokens.json', 'utf8'));
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 1000 }, timezoneId: 'America/New_York', permissions: ['clipboard-read', 'clipboard-write'] }); const p = await c.newPage(); p.setDefaultTimeout(8000);
 const R = { t: now(), cases: [], leaks: [] }; let errs = [];
 p.on('pageerror', e => errs.push(e.message.slice(0, 200))); p.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text().slice(0, 160)); });
 const sigs = Object.values(T).map(t => (t.split('.')[1] || '').slice(0, 24)).filter(s => s.length > 10);
 p.on('request', r => { const s = r.url() + ' ' + (r.postData() || ''); for (const x of sigs) if (s.includes(x)) R.leaks.push({ host: new URL(r.url()).host, path: new URL(r.url()).pathname.slice(0, 60), piece: x.slice(0, 10) + '…' }); });
 for (const [id, tok] of Object.entries(T)) { if (process.argv[2] && !process.argv[2].split(',').includes(id.split('_')[0])) continue;
  errs = []; await p.goto('https://www.freedailypro.com/tool/jwt-decoder', { waitUntil: 'domcontentloaded' }); await p.locator('#jwt-input').waitFor(); await p.waitForTimeout(600);
  const t0 = Date.now(); await p.locator('#jwt-input').fill(tok); await p.waitForTimeout(900);
  const r = await p.evaluate(() => { const area = document.querySelector('[data-testid=tool-area]'); return { alive: !!document.querySelector('#jwt-input'), url: location.search,
   alerts: [...document.querySelectorAll('main [role=alert]')].map(e => e.innerText.trim()), pres: [...document.querySelectorAll('main pre')].map(e => e.innerText.slice(0, 400)),
   area: area ? area.innerText.replace(/\s+/g, ' ').slice(0, 1500) : (document.querySelector('main') || document.body).innerText.slice(0, 600) }; });
  R.cases.push({ id, len: tok.length, ms: Date.now() - t0, errs: [...errs], ...r }); console.log(id, '| alive', r.alive, '| alerts', r.alerts.join(' / ').slice(0, 140), '| errs', errs.length);
  if (['J01_hs256_valid', 'J04_alg_none', 'J13_exp_huge', 'J02_expired', 'J16_rs256_kid'].includes(id)) await p.screenshot({ path: OUT + 'case-' + id.split('_')[0] + '.png' }); }
 // selection copy gate
 await p.goto('https://www.freedailypro.com/tool/jwt-decoder', { waitUntil: 'domcontentloaded' }); await p.locator('#jwt-input').waitFor(); await p.locator('#jwt-input').fill(T.J01_hs256_valid); await p.waitForTimeout(800);
 const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
 const g = { before: await used() }; await p.locator('main pre').nth(1).selectText(); await p.keyboard.press('Control+c'); await p.waitForTimeout(1500);
 g.dialog = await p.evaluate(() => { const d = document.querySelector('[role=dialog],[role=alertdialog]'); return d ? d.innerText.replace(/\s*\n\s*/g, ' | ').slice(0, 400) : null; });
 g.clip = (await p.evaluate(() => navigator.clipboard.readText()).catch(e => 'ERR')).slice(0, 200); g.after = await used(); if (g.dialog) await p.screenshot({ path: OUT + 'copy-gate.png' });
 g.buttons = await p.evaluate(() => [...document.querySelectorAll('main button')].map(b => b.innerText.trim() || b.getAttribute('aria-label')).filter(Boolean));
 R.copyGate = g; R.t2 = now(); fs.writeFileSync(OUT + (process.argv[3] || 'cases.json'), JSON.stringify(R, null, 1)); console.log(JSON.stringify({ leaks: R.leaks, copyGate: g }, null, 1)); await b.close(); })();
