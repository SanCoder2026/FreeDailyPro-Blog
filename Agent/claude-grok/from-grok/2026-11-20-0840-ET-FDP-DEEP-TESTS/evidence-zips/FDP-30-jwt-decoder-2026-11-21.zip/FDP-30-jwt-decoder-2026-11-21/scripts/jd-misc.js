// jwt-decoder: trial/upgrade copy on the page, print rendering (page.pdf with print media), keyboard path, head SEO tags, share/favorites. No export clicked.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const TOK = JSON.parse(fs.readFileSync('/workspace/deep/30-jwt-decoder/testfiles/tokens.json', 'utf8')).J16_rs256_kid;
const OUT = '/workspace/deep/30-jwt-decoder/live/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(10000);
 const R = { t: now() };
 await p.goto('https://www.freedailypro.com/tool/jwt-decoder', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); await p.locator('#jwt-input').fill(TOK); await p.waitForTimeout(800);
 R.ls = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
 R.trialMentions = await p.evaluate(() => document.body.innerText.split('\n').filter(l => /trial|pass|upgrade|Quick Buy|Premium|\$|remaining|per visit|uses/i.test(l)).slice(0, 40));
 R.head = await p.evaluate(() => ({ title: document.title, desc: (document.querySelector('meta[name=description]') || {}).content, canonical: (document.querySelector('link[rel=canonical]') || {}).href, robots: (document.querySelector('meta[name=robots]') || {}).content,
   hreflang: [...document.querySelectorAll('link[rel=alternate][hreflang]')].map(l => l.hreflang + ' ' + l.href), og: [...document.querySelectorAll('meta[property^="og:"], meta[name^="twitter:"]')].map(m => (m.getAttribute('property') || m.name) + '=' + m.content),
   h1: [...document.querySelectorAll('h1')].map(h => h.innerText), h2: [...document.querySelectorAll('h2')].map(h => h.innerText), h3: [...document.querySelectorAll('h3')].map(h => h.innerText),
   imgsNoAlt: [...document.querySelectorAll('img')].filter(i => !i.alt).map(i => i.src.slice(0, 100)), lang: document.documentElement.lang, ld: [...document.querySelectorAll('script[type="application/ld+json"]')].map(s => { try { return JSON.parse(s.textContent)['@type'] || JSON.parse(s.textContent)['@graph']?.map(x => x['@type']); } catch (e) { return 'ERR'; } }) }));
 // keyboard: tab through first 25 stops
 await p.locator('body').click({ position: { x: 5, y: 300 } }); R.tabs = [];
 for (let i = 0; i < 30; i++) { await p.keyboard.press('Tab'); R.tabs.push(await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('aria-label') || e.innerText || e.id || '').trim().slice(0, 40); })); }
 // print rendering
 await p.emulateMedia({ media: 'print' }); await p.pdf({ path: OUT + 'print-preview.pdf', format: 'A4' }); await p.emulateMedia({ media: 'screen' });
  // dark/light toggle check of gauge contrast: light mode
 R.t2 = now(); fs.writeFileSync(OUT + 'misc.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
