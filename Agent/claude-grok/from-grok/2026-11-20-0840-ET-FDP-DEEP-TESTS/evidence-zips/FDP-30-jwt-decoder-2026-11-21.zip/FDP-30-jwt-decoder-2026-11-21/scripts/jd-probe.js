// jwt-decoder probe: starting count, JS chunks, controls, requests while typing. Nothing exported.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/30-jwt-decoder/live/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(10000); const R = { t: now(), req: [], js: [] };
 p.on('request', r => { const u = new URL(r.url()); if (/freedailypro/.test(u.host)) { R.req.push(r.method() + ' ' + u.pathname.slice(0, 80) + (r.postData() ? ' post=' + r.postData().length : '')); if (/\.m?js$/.test(u.pathname)) R.js.push(u.pathname); } });
 await p.goto('https://www.freedailypro.com/tool/jwt-decoder', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 R.ls = await p.evaluate(() => localStorage.getItem('fdp-usage-v1')); R.strip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]);
 R.controls = await p.evaluate(() => [...document.querySelectorAll('main button, main input, main select, main textarea, main [role=combobox], main [role=radio], main [role=tab], main [role=checkbox], main [role=switch], main canvas, main svg, main img')].map(e => ({ tag: e.tagName, type: e.type || e.getAttribute('role') || '', id: e.id, testid: e.getAttribute('data-testid'), name: (e.getAttribute('aria-label') || e.innerText || e.value || e.getAttribute('alt') || '').trim().slice(0, 60), label: e.labels && e.labels[0] ? e.labels[0].innerText.trim().slice(0, 60) : null, ph: e.placeholder || null, val: e.value || null, min: e.min || null, max: e.max || null })).filter(x => !/About|Common|Details|Guides|Share this|Create Shortcut|Subscribe|Watch/.test(x.name)));
 R.main = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 3000));
 R.testids = await p.evaluate(() => [...document.querySelectorAll('[data-testid]')].map(e => e.getAttribute('data-testid') + ' = ' + e.innerText.trim().slice(0, 60)));
 await p.screenshot({ path: OUT + 'probe.png', fullPage: false }); await p.screenshot({ path: OUT + 'probe-full.png', fullPage: true });
 fs.writeFileSync(OUT + 'probe.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
