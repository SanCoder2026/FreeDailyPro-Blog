// jwt-decoder: paste a token, click "Share this tool", read what is shared/copied. Guest, read-only.
const { chromium } = require('playwright'); const fs = require('fs');
const T = JSON.parse(fs.readFileSync('/workspace/deep/30-jwt-decoder/testfiles/tokens.json', 'utf8'));
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ permissions: ['clipboard-read', 'clipboard-write'] }); const p = await c.newPage();
  await p.addInitScript(() => { window.__shared = null; navigator.share = d => { window.__shared = d; return Promise.resolve(); }; });
  await p.goto('https://www.freedailypro.com/tool/jwt-decoder', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  await p.locator('#jwt-input').fill(T.J16_rs256_kid); await p.waitForTimeout(600);
  const before = await p.evaluate(() => navigator.clipboard.readText().catch(() => ''));
  await p.getByRole('button', { name: 'Share this tool' }).first().click(); await p.waitForTimeout(1500);
  const r = { t: new Date().toString(), url: p.url(), shared: await p.evaluate(() => window.__shared), clip: await p.evaluate(() => navigator.clipboard.readText().catch(() => '')), dialog: await p.evaluate(() => { const d = document.querySelector('[role=dialog],[role=menu]'); return d ? d.innerText.slice(0, 300) : null; }) };
  r.clipChanged = r.clip !== before; r.tokenInShare = JSON.stringify(r).includes(T.J16_rs256_kid.slice(0, 30));
  await p.screenshot({ path: '/workspace/deep/30-jwt-decoder/live/share.png' });
  fs.writeFileSync('/workspace/deep/30-jwt-decoder/live/share.json', JSON.stringify(r, null, 1)); console.log(JSON.stringify(r)); await b.close();
})();
