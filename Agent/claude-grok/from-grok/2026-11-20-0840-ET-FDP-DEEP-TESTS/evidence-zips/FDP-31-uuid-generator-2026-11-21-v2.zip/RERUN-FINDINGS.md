Sent: 2026-11-21 20:04 ET

# RERUN-FINDINGS

This package is version v2 (FDP-31-uuid-generator-2026-11-21-v2.zip). It **supersedes/extends**: FDP-31-uuid-generator-2026-11-21.zip. Earlier zips are untouched (frozen); anything not mentioned here is unchanged from them.

Run 19:44 ET `ug-gate.js`. Contexts with uses left: A_gen_first and B_gen_then_all.
- A_gen_first: Generate, Copy UUID 1, Copy All, Generate again, selection: usageToday **0 -> 0 on every step, also after reload**. B_gen_then_all: Generate, Copy All, Copy UUID 2, Copy UUID 3: 0 -> 0.
- At 0: same actions work, 10 -> 10.
- The code calls `logUsageNow()` on Generate and `gateShare` on copy and the blog says each Generate costs a trial use, but the display counter never moved in these contexts. **Discrepancy to review** (counter-only evidence; no backend claim).
Evidence: live/gate.json.
