import { r as i, j as e } from "./vendor-react-D01g8YgM.js";
import { u as j } from "./useShareGate-BYBawloP.js";
import { b as N, T as U } from "./ToolPage-DwLoDncN.js";
import {
  e as k,
  I as C,
  B as p,
  b9 as v,
  N as I,
  f as c,
} from "./index-B1CTyGtY.js";
import { T as S } from "./ToolInfoSection-C0i6Zbwo.js";
import { C as T } from "./copy-DcUvE8ta.js";
import "./useExportGate-BU4jIFHF.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
const n = 1e3;
function D(o) {
  const s = o.trim();
  if (!s) return { ok: !1, error: "Enter how many UUIDs you want." };
  const t = Number(s);
  return Number.isFinite(t)
    ? Number.isInteger(t)
      ? t < 1
        ? {
            ok: !1,
            error:
              "Enter 1 or more. Zero and negative counts cannot be generated.",
          }
        : t > n
          ? { ok: !0, n, capped: !0 }
          : { ok: !0, n: t, capped: !1 }
      : { ok: !1, error: "Enter a whole number, such as 5." }
    : { ok: !1, error: "Enter a whole number." };
}
function E(o, s) {
  let t = s.hyphens ? o : o.replace(/-/g, "");
  return (s.upper && (t = t.toUpperCase()), t);
}
const u = {
  what: "Generates random UUIDs (universally unique identifiers), commonly used as unique keys for database records, API resources, or session tokens.",
  how: "Choose how many UUIDs you need (1 to 1,000 per batch), optionally drop the hyphens or switch to uppercase, and generate them. Copy the results individually or as a full list.",
  tip: "Standard UUIDs are designed to be unique across systems without any central coordination — you can generate them independently in different places and trust they won't collide.",
};
function ne() {
  const { gateShare: o } = j(),
    [s, t] = i.useState("5"),
    [d, x] = i.useState(!0),
    [m, f] = i.useState(!1),
    [y, g] = i.useState([]),
    { logUsageNow: w } = N(),
    a = D(s),
    l = y.map((r) => E(r, { hyphens: d, upper: m })),
    b = async () => {
      !a.ok ||
        !(await w()) ||
        g(Array.from({ length: a.n }, () => crypto.randomUUID()));
    };
  return e.jsxs(U, {
    children: [
      e.jsxs("div", {
        className: "space-y-4",
        children: [
          e.jsxs("div", {
            className: "flex items-end gap-4 flex-wrap",
            children: [
              e.jsxs("div", {
                children: [
                  e.jsx(k, { htmlFor: "uuid-count", children: "Count" }),
                  e.jsx(C, {
                    id: "uuid-count",
                    type: "number",
                    value: s,
                    onChange: (r) => t(r.target.value),
                    className: "w-24",
                    min: "1",
                    max: n,
                    "aria-invalid": !a.ok,
                    "aria-describedby": "uuid-count-msg",
                  }),
                ],
              }),
              e.jsxs(p, {
                onClick: b,
                disabled: !a.ok,
                className: "gap-2",
                children: [e.jsx(v, { className: "h-4 w-4" }), " Generate"],
              }),
            ],
          }),
          e.jsxs("div", {
            id: "uuid-count-msg",
            children: [
              !a.ok &&
                e.jsx("p", {
                  role: "alert",
                  className: "text-xs text-destructive",
                  children: a.error,
                }),
              a.ok &&
                a.capped &&
                e.jsxs(I, {
                  className: "text-xs",
                  children: [
                    "Maximum is ",
                    n.toLocaleString("en-US"),
                    " per batch; generating ",
                    n.toLocaleString("en-US"),
                    ".",
                  ],
                }),
            ],
          }),
          e.jsxs("div", {
            className: "flex flex-wrap gap-4 text-sm",
            children: [
              e.jsxs("label", {
                className: "flex items-center gap-2",
                children: [
                  e.jsx("input", {
                    type: "checkbox",
                    checked: d,
                    onChange: (r) => x(r.target.checked),
                  }),
                  " Hyphens",
                ],
              }),
              e.jsxs("label", {
                className: "flex items-center gap-2",
                children: [
                  e.jsx("input", {
                    type: "checkbox",
                    checked: m,
                    onChange: (r) => f(r.target.checked),
                  }),
                  " Uppercase",
                ],
              }),
            ],
          }),
          l.length > 0 &&
            e.jsxs("div", {
              className: "space-y-1",
              children: [
                l.map((r, h) =>
                  e.jsxs(
                    "div",
                    {
                      className:
                        "flex items-center gap-2 p-2 rounded border bg-card",
                      children: [
                        e.jsx("code", {
                          className: "text-sm font-mono flex-1 break-all",
                          children: r,
                        }),
                        e.jsx(p, {
                          variant: "ghost",
                          size: "icon",
                          className: "h-7 w-7",
                          "aria-label": `Copy UUID ${h + 1}`,
                          onClick: () => {
                            o(async () => {
                              try {
                                return (
                                  await navigator.clipboard.writeText(r),
                                  c.success("Copied!"),
                                  !0
                                );
                              } catch {
                                return (
                                  c.error(
                                    "Couldn't copy. Select the text and copy it by hand.",
                                  ),
                                  !1
                                );
                              }
                            });
                          },
                          children: e.jsx(T, { className: "h-3.5 w-3.5" }),
                        }),
                      ],
                    },
                    h,
                  ),
                ),
                e.jsx(p, {
                  variant: "outline",
                  size: "sm",
                  className: "mt-2",
                  onClick: () => {
                    o(async () => {
                      try {
                        return (
                          await navigator.clipboard.writeText(
                            l.join(`
`),
                          ),
                          c.success("All copied!"),
                          !0
                        );
                      } catch {
                        return (
                          c.error(
                            "Couldn't copy. Select the text and copy it by hand.",
                          ),
                          !1
                        );
                      }
                    });
                  },
                  children: "Copy All",
                }),
              ],
            }),
        ],
      }),
      e.jsx(S, { whatIsIt: u.what, howToUse: u.how, tip: u.tip }),
    ],
  });
}
export { ne as default };
//# sourceMappingURL=UuidGenerator-CmXHafTq.js.map
