// uuid-generator: count validation, format toggles, 1000-batch quality, timing, and a scan of every request for generated UUIDs. Guest, read-only.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/31-uuid-generator/live/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 }, permissions: ['clipboard-read', 'clipboard-write'] }); const p = await c.newPage();
  const bodies = []; p.on('request', r => bodies.push(r.url() + ' ' + (r.postData() || ''))); const errs = []; p.on('pageerror', e => errs.push(String(e)));
  await p.goto('https://www.freedailypro.com/tool/uuid-generator', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000);
  const R = { t: now(), cases: [], all: [] };
  const area = () => p.getByTestId('tool-area'); const gen = () => area().getByRole('button', { name: 'Generate', exact: true });
  const read = async () => ({ disabled: await gen().isDisabled(), alert: await area().locator('[role=alert]').allInnerTexts(), note: (await p.locator('#uuid-count-msg').innerText()).trim(), codes: await p.$$eval('main code', e => e.map(x => x.innerText)), url: p.url() });
  const hy = area().getByLabel('Hyphens'), up = area().getByLabel('Uppercase');
  const cases = [['U01', '5'], ['U02', '1'], ['U03', ''], ['U04', '0'], ['U05', '-3'], ['U06', '2.5'], ['U07', '1001'], ['U08', '1000'], ['U09', '1e3'], ['U10', '999999999'], ['U11', '007'], ['U12', ' 12 ']];
  for (const [id, v] of cases) {
    await p.locator('#uuid-count').fill(v).catch(() => {}); await p.waitForTimeout(300);
    const pre = await read(); let ms = null;
    if (!pre.disabled) { const t0 = Date.now(); await gen().click(); await p.waitForFunction(() => document.querySelectorAll('main code').length > 0, null, { timeout: 15000 }); await p.waitForTimeout(300); ms = Date.now() - t0; }
    const r = await read(); const codes = r.codes; R.all.push(...codes);
    R.cases.push({ id, input: v, inputValue: await p.locator('#uuid-count').inputValue(), disabled: pre.disabled, alert: pre.alert, note: pre.note, n: codes.length, ms, allV4: codes.every(x => V4.test(x)), unique: new Set(codes).size, sample: codes.slice(0, 2), url: r.url });
    console.log(id, v, '| disabled', pre.disabled, '|', pre.alert.join(' ') || pre.note, '| n', codes.length, ms);
    if (id === 'U08') await p.screenshot({ path: OUT + 'case-1000.png' });
  }
  // format toggles on a batch of 5
  await p.locator('#uuid-count').fill('5'); await gen().click(); await p.waitForTimeout(500);
  const base = await p.$$eval('main code', e => e.map(x => x.innerText));
  await hy.uncheck(); await p.waitForTimeout(300); const noHy = await p.$$eval('main code', e => e.map(x => x.innerText));
  await up.check(); await p.waitForTimeout(300); const noHyUp = await p.$$eval('main code', e => e.map(x => x.innerText));
  await area().getByRole('button', { name: 'Copy All' }).click(); await p.waitForTimeout(500); const clip = await p.evaluate(() => navigator.clipboard.readText());
  await hy.check(); await p.waitForTimeout(300); const hyUp = await p.$$eval('main code', e => e.map(x => x.innerText));
  await p.screenshot({ path: OUT + 'case-upper.png' });
  R.toggles = { base, noHy, noHyUp, hyUp, clipNoHyUp: clip, sameValues: base.every((x, i) => noHy[i] === x.replace(/-/g, '') && hyUp[i] === x.toUpperCase()), noHyFormat: noHy.every(x => /^[0-9a-f]{32}$/.test(x)) };
  // statistics over every UUID generated
  const all = R.all.map(x => x.toLowerCase()); const set = new Set(all);
  const hex = {}; all.forEach(x => x.replace(/-/g, '').split('').forEach((ch, i) => { if (i !== 12 && i !== 16) hex[ch] = (hex[ch] || 0) + 1; }));
  R.stats = { total: all.length, unique: set.size, allV4: all.every(x => V4.test(x)), variantNibbles: all.reduce((m, x) => (m[x[19]] = (m[x[19]] || 0) + 1, m), {}), hexFreq: hex };
  const pieces = [...set].slice(0, 400); R.leaks = bodies.filter(bd => pieces.some(u => bd.includes(u) || bd.includes(u.replace(/-/g, '')))).map(x => x.slice(0, 200));
  R.errs = errs; R.reload = {}; await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); R.reload.codesAfterReload = await p.locator('main code').count(); R.reload.count = await p.locator('#uuid-count').inputValue();
  R.t2 = now(); fs.writeFileSync(OUT + 'cases.json', JSON.stringify(R, (k, v) => k === 'all' ? undefined : v, 1));
  fs.writeFileSync('/workspace/deep/31-uuid-generator/testfiles/generated-sample.txt', R.all.slice(0, 1000).join('\n'));
  console.log(JSON.stringify({ toggles: { sameValues: R.toggles.sameValues, noHyFormat: R.toggles.noHyFormat, clip: R.toggles.clipNoHyUp.split('\n')[0] }, stats: R.stats, leaks: R.leaks, errs, reload: R.reload }, null, 1)); await b.close();
})();
