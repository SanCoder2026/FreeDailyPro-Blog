// uuid-generator: one fresh guest context, click Generate once, record result/dialog. Guest, no sign-in.
const { chromium } = require('playwright'); const fs = require('fs');
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ permissions: ['clipboard-read', 'clipboard-write'] }); const p = await c.newPage();
  const reqs = []; p.on('request', r => { if (r.method() === 'POST' || /usage|trpc|log/i.test(r.url())) reqs.push(r.method() + ' ' + r.url().split('?')[0]); });
  await p.goto('https://www.freedailypro.com/tool/uuid-generator', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
  const ls0 = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
  await p.getByTestId('tool-area').getByRole('button', { name: 'Generate', exact: true }).click(); await p.waitForTimeout(2500);
  const r = { t: new Date().toString(), ls0, codes: await p.$$eval('main code', e => e.map(x => x.innerText)), dialog: await p.evaluate(() => { const d = document.querySelector('[role=dialog],[role=alertdialog]'); return d ? d.innerText.replace(/\s*\n\s*/g, ' | ') : null; }), toasts: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText)), reqs, ls1: await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) };
  await p.screenshot({ path: '/workspace/deep/31-uuid-generator/live/try-generate.png' });
  fs.writeFileSync('/workspace/deep/31-uuid-generator/live/try.json', JSON.stringify(r, null, 1)); console.log(JSON.stringify(r, null, 1).slice(0, 2500)); await b.close();
})();
