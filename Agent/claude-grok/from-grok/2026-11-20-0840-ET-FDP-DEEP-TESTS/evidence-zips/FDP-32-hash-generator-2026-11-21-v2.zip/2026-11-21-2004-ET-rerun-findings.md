Sent: 2026-11-21 20:04 ET

# FDP-32 hash-generator: rerun after the 7:00 PM ET reset (Nov 21 2026)

Run 19:45 ET `hg-gate.js`. Contexts with uses left: A_gen_first (text Generate, copy SHA-256, compare, file F01, copy MD5, select) and B_file_first (file first, copy, text Generate x2).
- Both: usageToday **0 -> 0 on every step, also after reload**. At 0: everything works, 10 -> 10.
- Same discrepancy as FDP-31: code calls `logUsageNow()` on Generate but the display counter does not move. `hg-uses.js` not run.
Evidence: live/gate.json.

(Rows run in order: 4,5,7,8,11,14,20 then 28-33,40,56,57,69,73. No sign-in, no payment, no ads clicked, no admin, no API/MCP. Counters are display-only evidence.)
