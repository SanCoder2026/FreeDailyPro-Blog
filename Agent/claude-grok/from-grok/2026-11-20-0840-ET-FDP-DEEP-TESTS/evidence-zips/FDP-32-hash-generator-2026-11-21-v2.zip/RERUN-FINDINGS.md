Sent: 2026-11-21 20:04 ET

# RERUN-FINDINGS

This package is version v2 (FDP-32-hash-generator-2026-11-21-v2.zip). It **supersedes/extends**: FDP-32-hash-generator-2026-11-21.zip. Earlier zips are untouched (frozen); anything not mentioned here is unchanged from them.

Run 19:45 ET `hg-gate.js`. Contexts with uses left: A_gen_first (text Generate, copy SHA-256, compare, file F01, copy MD5, select) and B_file_first (file first, copy, text Generate x2).
- Both: usageToday **0 -> 0 on every step, also after reload**. At 0: everything works, 10 -> 10.
- Same discrepancy as FDP-31: code calls `logUsageNow()` on Generate but the display counter does not move. `hg-uses.js` not run.
Evidence: live/gate.json.
