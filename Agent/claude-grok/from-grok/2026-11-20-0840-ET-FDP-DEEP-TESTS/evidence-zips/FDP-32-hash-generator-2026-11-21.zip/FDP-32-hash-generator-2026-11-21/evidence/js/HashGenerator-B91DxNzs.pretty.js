import { r as n, j as e } from "./vendor-react-D01g8YgM.js";
import { b as v, T as b } from "./ToolPage-DwLoDncN.js";
import { ap as N, e as S, T, B as j, I as C } from "./index-B1CTyGtY.js";
import { T as k } from "./ToolInfoSection-C0i6Zbwo.js";
import { e as E } from "./utf8-C8MzR3N4.js";
import { c as I } from "./copyText-DPnES92p.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
const O = ["MD5", "SHA-1", "SHA-256", "SHA-384", "SHA-512"];
async function M(a) {
  const s = await N(() => import("./index.esm-Dup_VHWH.js"), []);
  switch (a) {
    case "MD5":
      return await s.createMD5();
    case "SHA-1":
      return await s.createSHA1();
    case "SHA-256":
      return await s.createSHA256();
    case "SHA-384":
      return await s.createSHA384();
    case "SHA-512":
      return await s.createSHA512();
  }
}
async function _(a, s) {
  const r = await Promise.all(O.map(async (t) => [t, await M(t)]));
  r.forEach(([, t]) => t.init());
  const o = 4 * 1024 * 1024;
  if (a instanceof Uint8Array) r.forEach(([, t]) => t.update(a));
  else
    for (let t = 0; t < a.size; t += o) {
      const c = new Uint8Array(await a.slice(t, t + o).arrayBuffer());
      (r.forEach(([, d]) => d.update(c)), s?.(Math.min(1, (t + o) / a.size)));
    }
  const h = {};
  for (const [t, c] of r) h[t] = c.digest();
  return h;
}
function U(a, s) {
  const r = s.trim().toLowerCase().replace(/\s+/g, "");
  return r ? (Object.entries(a).find(([, o]) => o === r)?.[0] ?? "") : null;
}
const u = {
  what: "Generates a cryptographic hash (MD5, SHA-1, SHA-256, and others) from text or a file, useful for verifying file integrity or generating a checksum.",
  how: "Paste text or choose a file and press Generate. You get MD5, SHA-1, SHA-256, SHA-384 and SHA-512 together, and files are read in chunks on your device (they are never uploaded). Paste an expected checksum to see whether it matches.",
  tip: "MD5 and SHA-1 are considered cryptographically broken for security purposes (though still fine for basic integrity checks) — use SHA-256 or stronger if the hash needs to actually resist tampering, not just detect accidental corruption.",
};
function he() {
  const [a, s] = n.useState(""),
    [r, o] = n.useState({}),
    { logUsageNow: h } = v(),
    [t, c] = n.useState(null),
    [d, f] = n.useState(0),
    [x, g] = n.useState(!1),
    [y, A] = n.useState(""),
    [p, l] = n.useState(""),
    H = async () => {
      if ((l(""), !a && !t)) {
        l("Enter some text or choose a file to hash.");
        return;
      }
      if (await h()) {
        (g(!0), f(0));
        try {
          o(await _(t ?? E(a), f));
        } catch {
          (o({}),
            l(
              "Could not read that file. It may be locked, moved or too large for the browser to open.",
            ));
        } finally {
          g(!1);
        }
      }
    },
    m = U(r, y);
  return e.jsxs(b, {
    children: [
      e.jsxs("div", {
        className: "space-y-4",
        children: [
          e.jsxs("div", {
            children: [
              e.jsx(S, { children: "Input Text (hashed as UTF-8)" }),
              e.jsx(T, {
                "aria-label": "Input Text (hashed as UTF-8)",
                value: a,
                onChange: (i) => {
                  (s(i.target.value), l(""));
                },
                placeholder: "Enter text to hash...",
                "aria-invalid": !!p,
              }),
            ],
          }),
          e.jsxs("div", {
            className: "flex flex-wrap items-center gap-3 text-sm",
            children: [
              e.jsxs("label", {
                className: "underline cursor-pointer",
                children: [
                  t
                    ? `File: ${t.name} (${t.size.toLocaleString()} bytes)`
                    : "Or choose a file to hash",
                  e.jsx("input", {
                    type: "file",
                    className: "hidden",
                    onChange: (i) => {
                      (c(i.target.files?.[0] ?? null), o({}), l(""));
                    },
                  }),
                ],
              }),
              t &&
                e.jsx("button", {
                  className: "text-xs text-muted-foreground underline",
                  onClick: () => {
                    (c(null), o({}));
                  },
                  children: "Remove file",
                }),
            ],
          }),
          e.jsx(j, {
            onClick: H,
            disabled: x,
            children: x
              ? `Hashing… ${Math.round(d * 100)}%`
              : "Generate Hashes",
          }),
          p &&
            e.jsx("p", {
              role: "alert",
              className: "text-xs text-destructive mt-1",
              children: p,
            }),
          Object.keys(r).length > 0 &&
            e.jsxs("div", {
              className: "space-y-3",
              children: [
                e.jsxs("div", {
                  children: [
                    e.jsx(S, {
                      children: "Compare with expected checksum (optional)",
                    }),
                    e.jsx(C, {
                      "aria-label": "Compare with expected checksum (optional)",
                      value: y,
                      onChange: (i) => A(i.target.value),
                      placeholder: "Paste a hash to verify…",
                      className: "font-mono text-xs",
                    }),
                    m !== null &&
                      e.jsx("p", {
                        className: `text-sm mt-1 font-medium ${m ? "text-green-600" : "text-destructive"}`,
                        children: m
                          ? `Match (${m})`
                          : "No match for any algorithm",
                      }),
                  ],
                }),
                Object.entries(r).map(([i, w]) =>
                  e.jsxs(
                    "div",
                    {
                      className: "p-3 rounded-lg border bg-card",
                      children: [
                        e.jsxs("div", {
                          className: "flex justify-between items-center mb-1",
                          children: [
                            e.jsx("span", {
                              className:
                                "text-xs font-medium text-muted-foreground",
                              children: i,
                            }),
                            e.jsx(j, {
                              variant: "ghost",
                              size: "sm",
                              className: "h-6 text-xs",
                              onClick: () => {
                                I(w, "Copied!");
                              },
                              children: "Copy",
                            }),
                          ],
                        }),
                        e.jsx("code", {
                          className: "text-xs font-mono break-all",
                          children: w,
                        }),
                      ],
                    },
                    i,
                  ),
                ),
              ],
            }),
        ],
      }),
      e.jsx(k, { whatIsIt: u.what, howToUse: u.how, tip: u.tip }),
    ],
  });
}
export { he as default };
//# sourceMappingURL=HashGenerator-B91DxNzs.js.map
