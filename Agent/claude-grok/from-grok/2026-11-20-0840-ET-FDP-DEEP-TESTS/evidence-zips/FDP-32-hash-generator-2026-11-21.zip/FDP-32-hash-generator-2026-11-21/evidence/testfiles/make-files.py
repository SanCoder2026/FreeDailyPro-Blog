# Recreates the hash-generator test files (big ones are not shipped in the zip).
import os
os.makedirs('files', exist_ok=True)
open('files/F01_hello.txt', 'wb').write(b'hello world\n')
open('files/F02_random_10MB.bin', 'wb').write(os.urandom(10 * 1024 * 1024))  # random: digest differs per run; the test compared against hashlib on the same file
open('files/F03_empty.txt', 'wb').write(b'')
open('files/F04_zeros_60MB.bin', 'wb').write(b'\0' * (60 * 1024 * 1024))
