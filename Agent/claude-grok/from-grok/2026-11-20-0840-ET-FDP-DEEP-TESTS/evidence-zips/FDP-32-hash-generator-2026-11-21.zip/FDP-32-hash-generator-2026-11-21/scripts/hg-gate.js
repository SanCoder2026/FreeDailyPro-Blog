// hash-generator: Generate Hashes (text and file), Copy (SHA-256), Compare and selection copy, at 0 and with uses left.
// at 0 and with uses left. window.print stubbed. Max 6 fresh contexts. At 0: one pass of the cap dialog -> Buy Day Pass -> email prompt (stop, type nothing).
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/32-hash-generator/live/'; fs.mkdirSync(OUT + 'downloads', { recursive: true }); const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const ORDERS = { A_gen_first: ['gen:text', 'row:SHA-256', 'cmp:compare', 'file:F01', 'row:MD5', 'sel:select'],
 B_file_first: ['file:F01', 'row:SHA-256', 'gen:text', 'gen:text'] };
(async () => { const b = await chromium.launch(); const R = { t: now(), contexts: [] }; let zeroDone = false; const todo = Object.keys(ORDERS);
 for (let i = 0; i < 6 && (todo.length || !zeroDone); i++) {
  const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true, permissions: ['clipboard-read', 'clipboard-write'] });
  await c.addInitScript(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
  const p = await c.newPage(); p.setDefaultTimeout(10000); await p.goto('https://www.freedailypro.com/tool/hash-generator', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000); 
  const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
  const row = { i, t: now(), start: await used(), steps: [] }; R.contexts.push(row); const atZero = row.start >= 10;
  if (atZero && zeroDone) { row.note = 'loaded at 0; skipped'; await c.close(); continue; }
  if (!atZero && !todo.length) { await c.close(); continue; }
  const name = atZero ? 'Z_at_zero' : todo.shift(); row.name = name;
  const acts = atZero ? ORDERS.A_gen_first : ORDERS[name];
  for (const a of acts) { const [area, label] = a.split(':'); let d = null; const h = x => d = x; p.on('download', h);
   const before = await p.$$eval('main .bg-card code', e => e.map(x => x.innerText));
   if (area === 'gen') { if (await p.getByRole('button', { name: 'Remove file' }).count()) await p.getByRole('button', { name: 'Remove file' }).click(); await p.getByLabel('Input Text (hashed as UTF-8)').fill('gate test ' + Date.now()); await p.getByRole('button', { name: 'Generate Hashes' }).click(); }
   else if (area === 'file') { await p.locator('main input[type=file]').setInputFiles('/workspace/deep/32-hash-generator/testfiles/files/F01_hello.txt'); await p.getByRole('button', { name: 'Generate Hashes' }).click(); }
   else if (area === 'row') await p.locator('main .bg-card').filter({ hasText: label }).getByRole('button', { name: 'Copy' }).click();
   else if (area === 'cmp') await p.getByLabel('Compare with expected checksum (optional)').fill('0'.repeat(64));
   else { await p.evaluate(() => { const c = document.querySelector('main .bg-card code'); const r = document.createRange(); r.selectNodeContents(c); const s = getSelection(); s.removeAllRanges(); s.addRange(r); }); await p.keyboard.press('Control+c'); }
   await p.waitForTimeout(1800); p.off('download', h);
   const after = await p.$$eval('main .bg-card code', e => e.map(x => x.innerText));
   const dl = p.locator('[role=dialog],[role=alertdialog]'); const dialog = (await dl.count()) ? (await dl.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 400) : null;
   const toast = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast], [role=status]')].map(e => e.innerText.trim()).filter(Boolean).slice(-2));
   const st = { a, used: await used(), dialog, toast, download: d ? d.suggestedFilename() : null, codes: after.length, newCodes: JSON.stringify(after) !== JSON.stringify(before), first: after[0] || null, clip: (await p.evaluate(() => navigator.clipboard.readText()).catch(() => '')).slice(0, 1500) };
   if (d) { const f = OUT + 'downloads/' + name + '-' + d.suggestedFilename(); await d.saveAs(f); st.file = f; st.content = fs.readFileSync(f, 'utf8').slice(0, 2500); }
   row.steps.push(st);
   if (dialog) { if (atZero && !row.capShot) { row.capShot = OUT + 'cap-dialog.png'; await p.screenshot({ path: row.capShot }); }
     if (atZero && !row.daypass) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500);
       row.daypass = { url: p.url(), dialog: (await p.locator('[role=dialog]').first().innerText().catch(() => '')).replace(/\s*\n\s*/g, ' | ').slice(0, 300), emailField: await p.locator('input[type=email]').count() };
       await p.screenshot({ path: OUT + 'daypass-email.png' }); } }
     await p.keyboard.press('Escape'); await p.waitForTimeout(400); await p.keyboard.press('Escape'); await p.waitForTimeout(300); } }
  await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); row.afterReload = await used();
  if (atZero) zeroDone = true; await c.close(); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1).slice(0, 12000)); await b.close(); })();
