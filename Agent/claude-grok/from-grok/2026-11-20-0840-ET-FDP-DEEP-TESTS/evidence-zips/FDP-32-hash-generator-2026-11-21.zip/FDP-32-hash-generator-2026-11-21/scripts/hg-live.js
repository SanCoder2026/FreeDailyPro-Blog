// hash-generator: text vectors, files (incl. 10 MB / 60 MB), compare box, stale-result and file-vs-text checks, request scan. Guest, read-only.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/32-hash-generator/'; const OUT = BASE + 'live/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const V = JSON.parse(fs.readFileSync(BASE + 'testfiles/vectors.json', 'utf8'));
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 }, permissions: ['clipboard-read', 'clipboard-write'] }); const p = await c.newPage();
  const bodies = []; p.on('request', r => bodies.push(r.url() + ' ' + (r.postData() || ''))); const errs = []; p.on('pageerror', e => errs.push(String(e)));
  await p.goto('https://www.freedailypro.com/tool/hash-generator', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000);
  const R = { t: now(), cases: [] };
  const ta = p.getByLabel('Input Text (hashed as UTF-8)'); const gen = p.getByRole('button', { name: /Generate Hashes|Hashing/ }); const fileIn = p.locator('main input[type=file]');
  const read = () => p.evaluate(() => { const o = {}; document.querySelectorAll('main .bg-card').forEach(d => { const k = d.querySelector('span')?.innerText; const v = d.querySelector('code')?.innerText; if (k && v) o[k] = v; }); return { hashes: o, alert: [...document.querySelectorAll('main [role=alert]')].map(e => e.innerText), fileLabel: document.querySelector('main label.underline')?.innerText || null }; });
  const cmp = (got, exp) => exp ? Object.keys(exp).every(k => got[k] === exp[k]) : null;
  const run = async (id, prep, expKey) => { await prep(); const t0 = Date.now(); await gen.click(); await p.waitForFunction(() => !/Hashing/.test(document.body.innerText) && (document.querySelectorAll('main .bg-card code').length || document.querySelector('main [role=alert]')), null, { timeout: 120000 }).catch(() => {}); const ms = Date.now() - t0; const r = await read(); const row = { id, ms, ok: cmp(r.hashes, V.expected[expKey]), ...r }; R.cases.push(row); console.log(id, '| ok', row.ok, '|', ms, 'ms |', r.alert.join(' '), '|', r.fileLabel); return row; };
  for (const [k, v] of Object.entries(V.texts)) await run(k, () => ta.fill(v), k);
  await run('H08_empty', () => ta.fill(''), null);
  // stale: hash abc, then edit to abd without pressing Generate
  await run('S01_abc', () => ta.fill('abc'), 'H01_abc'); await ta.fill('abd'); await p.waitForTimeout(500); const st = await read();
  R.stale = { textNow: 'abd', shownSHA256: st.hashes['SHA-256'], stillAbc: st.hashes['SHA-256'] === V.expected.H01_abc['SHA-256'], anyNotice: await p.locator('main').innerText().then(t => /out of date|stale|press Generate/i.test(t)) };
  await p.screenshot({ path: OUT + 'stale.png' }); console.log('stale', JSON.stringify(R.stale));
  // compare box
  await run('C00_abc', () => ta.fill('abc'), 'H01_abc'); const cb = p.getByLabel('Compare with expected checksum (optional)'); R.compare = [];
  for (const [id, val] of [['C01_sha256', V.expected.H01_abc['SHA-256']], ['C02_upper', V.expected.H01_abc['SHA-256'].toUpperCase()], ['C03_spaces', V.expected.H01_abc['MD5'].replace(/(.{8})/g, '$1 ')], ['C04_prefix', 'sha256:' + V.expected.H01_abc['SHA-256']], ['C05_wrong', '0'.repeat(64)], ['C06_md5', V.expected.H01_abc['MD5']], ['C07_sha512', V.expected.H01_abc['SHA-512']], ['C08_trailing_space', V.expected.H01_abc['SHA-1'] + '  '], ['C09_filename', V.expected.H01_abc['SHA-256'] + '  file.iso']]) {
    await cb.fill(val); await p.waitForTimeout(300); const msg = await p.locator('main p.text-sm.mt-1').allInnerTexts(); R.compare.push({ id, msg }); console.log(id, msg.join(' ')); }
  await cb.fill(V.expected.H01_abc['SHA-256']); await p.screenshot({ path: OUT + 'compare-match.png' });
  // files
  for (const f of ['F01_hello.txt', 'F03_empty.txt', 'F02_random_10MB.bin', 'F04_zeros_60MB.bin']) { await run('FILE_' + f, async () => { await fileIn.setInputFiles(BASE + 'testfiles/files/' + f); await p.waitForTimeout(400); }, f); }
  await p.screenshot({ path: OUT + 'file-60MB.png' });
  // file + text precedence: file F01 selected, text 'abc' typed
  await run('P01_file_and_text', async () => { await fileIn.setInputFiles(BASE + 'testfiles/files/F01_hello.txt'); await ta.fill('abc'); }, 'F01_hello.txt');
  R.precedence = { hashedFile: R.cases.at(-1).ok, notice: await p.locator('main').innerText().then(t => /file (takes|is used)|text is ignored/i.test(t)) };
  await p.getByRole('button', { name: 'Remove file' }).click(); await p.waitForTimeout(300); R.afterRemove = await read();
  // copy
  await run('CP_abc', () => ta.fill('abc'), 'H01_abc'); await p.locator('main .bg-card').filter({ hasText: 'SHA-256' }).getByRole('button', { name: 'Copy' }).click(); await p.waitForTimeout(500); R.copySHA256 = await p.evaluate(() => navigator.clipboard.readText());
  // keyboard: can the file picker be reached with Tab?
  await p.goto('https://www.freedailypro.com/tool/hash-generator', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4000); await ta.focus(); const tabs = [];
  for (let i = 0; i < 4; i++) { await p.keyboard.press('Tab'); tabs.push(await p.evaluate(() => { const a = document.activeElement; return a.tagName + ' ' + (a.type || '') + ' ' + (a.innerText || a.getAttribute('aria-label') || '').slice(0, 40); })); }
  R.tabAfterTextarea = tabs; R.fileInputStyle = await fileIn.evaluate(e => ({ display: getComputedStyle(e).display, tabIndex: e.tabIndex }));
  const pieces = ['héllo 日本', 'quick brown fox', V.expected.H02_fox['SHA-256'], V.expected.H01_abc['SHA-256'], 'hello world', V.expected['F01_hello.txt']['SHA-256']];
  R.leaks = bodies.filter(x => pieces.some(s => x.includes(s) || x.includes(encodeURIComponent(s)))).map(x => x.slice(0, 200)); R.url = p.url(); R.errs = errs; R.t2 = now();
  fs.writeFileSync(OUT + 'cases.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify({ copy: R.copySHA256, prec: R.precedence, afterRemove: R.afterRemove.fileLabel, tabs: R.tabAfterTextarea, fileInput: R.fileInputStyle, leaks: R.leaks, errs }, null, 1)); await b.close();
})();
