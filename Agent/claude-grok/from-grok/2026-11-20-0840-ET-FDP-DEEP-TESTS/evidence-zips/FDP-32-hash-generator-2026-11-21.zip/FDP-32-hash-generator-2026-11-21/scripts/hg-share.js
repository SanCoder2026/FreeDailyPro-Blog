// hash-generator: paste a token, click "Share this tool", read what is shared/copied. Guest, read-only.
const { chromium } = require('playwright'); const fs = require('fs');
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ permissions: ['clipboard-read', 'clipboard-write'] }); const p = await c.newPage();
  await p.addInitScript(() => { window.__shared = null; navigator.share = d => { window.__shared = d; return Promise.resolve(); }; });
  await p.goto('https://www.freedailypro.com/tool/hash-generator', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4000);
  await p.getByLabel('Input Text (hashed as UTF-8)').fill('abc'); await p.getByRole('button', { name: 'Generate Hashes' }).click(); await p.waitForTimeout(1200); const first = 'ba7816bf8f01cfea';
  const before = await p.evaluate(() => navigator.clipboard.readText().catch(() => ''));
  await p.getByRole('button', { name: 'Share this tool' }).first().click(); await p.waitForTimeout(1500);
  const r = { t: new Date().toString(), url: p.url(), shared: await p.evaluate(() => window.__shared), clip: await p.evaluate(() => navigator.clipboard.readText().catch(() => '')), dialog: await p.evaluate(() => { const d = document.querySelector('[role=dialog],[role=menu]'); return d ? d.innerText.slice(0, 300) : null; }) };
  r.clipChanged = r.clip !== before; r.hashInShare = JSON.stringify(r).includes(first);
  await p.screenshot({ path: '/workspace/deep/32-hash-generator/live/share.png' });
  fs.writeFileSync('/workspace/deep/32-hash-generator/live/share.json', JSON.stringify(r, null, 1)); console.log(JSON.stringify(r)); await b.close();
})();
