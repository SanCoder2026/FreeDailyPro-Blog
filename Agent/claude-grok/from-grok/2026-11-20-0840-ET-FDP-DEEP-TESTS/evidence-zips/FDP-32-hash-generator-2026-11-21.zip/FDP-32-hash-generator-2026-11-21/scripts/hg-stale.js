// hash-generator: stale result + compare. Hash "abc", edit the text to "abd" (no Generate), paste abc's SHA-256 into Compare. Guest, read-only.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage();
  await p.goto('https://www.freedailypro.com/tool/hash-generator', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000);
  const ta = p.getByLabel('Input Text (hashed as UTF-8)'); await ta.fill('abc'); await p.getByRole('button', { name: 'Generate Hashes' }).click(); await p.waitForTimeout(1200);
  await ta.fill('abd'); await p.getByLabel('Compare with expected checksum (optional)').fill('ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'); await p.waitForTimeout(500);
  const r = { t: cp.execSync('date "+%F %T %Z"').toString().trim(), textarea: await ta.inputValue(), verdict: await p.locator('main p.text-sm.mt-1').allInnerTexts() };
  await p.locator('main').screenshot({ path: '/workspace/deep/32-hash-generator/live/stale-compare.png' }).catch(() => p.screenshot({ path: '/workspace/deep/32-hash-generator/live/stale-compare.png' }));
  fs.writeFileSync('/workspace/deep/32-hash-generator/live/stale-compare.json', JSON.stringify(r, null, 1)); console.log(JSON.stringify(r)); await b.close(); })();
