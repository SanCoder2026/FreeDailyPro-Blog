// hash-generator: fresh contexts until one loads with uses left; record full fdp-usage-v1 (scope redacted) before/after Generate and reload. Max 6 contexts. Guest.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const red = s => (s || '').replace(/dev:[0-9a-f-]{36}/g, 'dev:REDACTED');
(async () => { const b = await chromium.launch(); const R = { t: now(), ctx: [] };
  for (let i = 0; i < 6; i++) { const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage();
    await p.goto('https://www.freedailypro.com/tool/hash-generator', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000);
    const ls = () => p.evaluate(() => localStorage.getItem('fdp-usage-v1')); const strip = () => p.evaluate(() => (document.querySelector('[data-testid*=usage], [class*=UsageAndUpgrade]')?.innerText || '').slice(0, 200));
    const row = { i, t: now(), before: red(await ls()), stripBefore: await strip() }; R.ctx.push(row);
    const u = JSON.parse(await ls() || '{}').usageToday;
    if (u === 0 || u === undefined) {
      const ta = p.getByLabel('Input Text (hashed as UTF-8)');
      for (let k = 1; k <= 3; k++) { await ta.fill('uses test ' + k); await p.getByRole('button', { name: 'Generate Hashes' }).click(); await p.waitForTimeout(2500); row['afterGen' + k] = red(await ls()); }
      row.dialog = await p.evaluate(() => document.querySelector('[role=dialog]')?.innerText.slice(0, 300) || null);
      await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); row.afterReload = red(await ls()); row.stripAfter = await strip(); await p.screenshot({ path: '/workspace/deep/32-hash-generator/live/uses-left-ctx.png' });
      await c.close(); break; }
    await c.close(); }
  R.t2 = now(); fs.writeFileSync('/workspace/deep/32-hash-generator/live/uses-left.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
