import { r as d, j as t } from "./vendor-react-D01g8YgM.js";
import { l as he } from "./utils-qgqMjnRG.js";
import { T as fe, F as ge, D as xe, d as be } from "./ToolPage-DwLoDncN.js";
import { f as v, N as we, B as b } from "./index-B1CTyGtY.js";
import { T as ve } from "./ToolInfoSection-C0i6Zbwo.js";
import { f as je } from "./operations-P8Ty5WBe.js";
import { J as ye } from "./jszip.min-CT0ZA6V1.js";
import { p as ee } from "./timeParse-8r2SbiBd.js";
import {
  loadFFmpeg as ke,
  fetchFile as Se,
  ffmpegOutputToBlob as Te,
} from "./ffmpegEngine-DH91Xnxx.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./scriptFonts-B9baRZsf.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
const U = {
    what: "Generates a thumbnail image from a specific frame of a video, useful for creating a preview image without needing to take a separate screenshot or open a video editor — a common need for uploading a video somewhere that requires its own thumbnail, or for a preview image on a page linking to the video.",
    how: "Upload your video, find the frame you want (step buttons, a time box, or the Suggest frames strip), choose a size such as 1280 x 720 for YouTube, add a title if you like, and capture. Download one image or all of them as a ZIP.",
    tip: "Pick a frame with a clear, in-focus subject and good lighting — a thumbnail pulled from a blurry transition or motion-heavy moment rarely looks good on its own, even if that exact moment matters in the video itself. Scrubbing slowly near a scene change usually finds a sharper frame than scrubbing quickly and guessing.",
  },
  te = [
    { id: "orig", label: "Original size", w: 0, h: 0 },
    {
      id: "yt4k",
      label: "YouTube 4K 3840 x 2160 (recommended)",
      w: 3840,
      h: 2160,
    },
    { id: "yt", label: "YouTube HD 1280 x 720", w: 1280, h: 720 },
    {
      id: "short4k",
      label: "YouTube Shorts 4K 2160 x 3840 (recommended)",
      w: 2160,
      h: 3840,
    },
    { id: "vert", label: "Shorts / Reels 1080 x 1920", w: 1080, h: 1920 },
    { id: "sq", label: "Square 1080 x 1080", w: 1080, h: 1080 },
  ],
  M = (p) => `${Math.floor(p / 60)}:${(p % 60).toFixed(2).padStart(5, "0")}`,
  Ne = (p) => {
    const T = Math.floor(p / 60),
      j = (p % 60).toFixed(2).padStart(5, "0");
    return `${String(T).padStart(2, "0")}m${j}s`;
  },
  ae = [
    {
      id: "sans",
      label: "Bold sans",
      css: '800 {px}px "Noto Sans", "Noto Sans Devanagari", system-ui, sans-serif',
    },
    {
      id: "serif",
      label: "Serif",
      css: '700 {px}px "Noto Serif", Georgia, "Noto Sans Devanagari", serif',
    },
    {
      id: "impact",
      label: "Impact style",
      css: '900 {px}px Impact, "Arial Black", "Noto Sans", "Noto Sans Devanagari", sans-serif',
    },
    {
      id: "mono",
      label: "Monospace",
      css: "700 {px}px ui-monospace, Menlo, Consolas, monospace",
    },
  ],
  $e = [
    { id: "#ffffff", label: "White" },
    { id: "#ffdd00", label: "Yellow" },
    { id: "#ff4040", label: "Red" },
    { id: "#000000", label: "Black" },
  ];
function lt() {
  const [p, T] = d.useState(null),
    [j, Y] = d.useState(""),
    [y, z] = d.useState([]),
    [D, se] = d.useState(!1),
    N = d.useRef(null),
    [k, oe] = d.useState("orig"),
    [W, re] = d.useState("fill"),
    [$, ie] = d.useState(""),
    [_, ne] = d.useState("sans"),
    [E, le] = d.useState("#ffffff"),
    [A, ce] = d.useState(9),
    [R, B] = d.useState(""),
    [J, C] = d.useState([]),
    [Z, q] = d.useState(!1),
    [L, O] = d.useState(!1),
    [G, H] = d.useState(!1),
    de = d.useCallback((e) => {
      const a = e[0];
      if (a) {
        if (!he(a)) {
          v.error(`"${a.name}" isn't a video file`);
          return;
        }
        (T(a), Y(URL.createObjectURL(a)), z([]), C([]), O(!1), B(""));
      }
    }, []),
    F = (e) => {
      const a = N.current;
      a &&
        (a.pause(),
        (a.currentTime = Math.max(
          0,
          Math.min(a.duration || 0, a.currentTime + e),
        )));
    },
    K = (e, a, i) => {
      const c = te.find((r) => r.id === k),
        s = c.w || a,
        o = c.h || i,
        x = document.createElement("canvas");
      ((x.width = s), (x.height = o));
      const n = x.getContext("2d");
      if (!c.w) n.drawImage(e, 0, 0);
      else if (W === "fill") {
        const r = Math.max(s / a, o / i),
          h = a * r,
          l = i * r;
        n.drawImage(e, (s - h) / 2, (o - l) / 2, h, l);
      } else {
        ((n.fillStyle = "#000"), n.fillRect(0, 0, s, o));
        const r = Math.min(s / a, o / i),
          h = a * r,
          l = i * r;
        n.drawImage(e, (s - h) / 2, (o - l) / 2, h, l);
      }
      const u = $.trim();
      if (u) {
        const r = Math.round((o * A) / 100);
        ((n.font = ae.find((g) => g.id === _).css.replace("{px}", String(r))),
          (n.textAlign = "center"),
          (n.textBaseline = "alphabetic"));
        const h = u.split(/\s+/),
          l = [];
        let f = "";
        for (const g of h) {
          const w = f ? `${f} ${g}` : g;
          n.measureText(w).width > s * 0.9 && f
            ? (l.push(f), (f = g))
            : (f = w);
        }
        f && l.push(f);
        const I = o - o * 0.06 - (l.length - 1) * r * 1.15;
        ((n.lineJoin = "round"),
          (n.lineWidth = r * 0.16),
          (n.strokeStyle = E === "#000000" ? "#fff" : "#000"),
          (n.fillStyle = E),
          l.forEach((g, w) => {
            const m = I + w * r * 1.15;
            (n.strokeText(g, s / 2, m), n.fillText(g, s / 2, m));
          }));
      }
      return x;
    },
    V = (e, a) => {
      e.toBlob(
        (i) => {
          if (!i || !p) return;
          const c = D ? "jpg" : "png",
            s = `${k !== "orig" ? `_${k}` : ""}${$.trim() ? "_title" : ""}`,
            o = `${p.name.replace(/\.[^.]+$/, "")}_${Ne(a)}${s}`;
          (z((x) => {
            const n = new Set(x.map((h) => h.name));
            let u = `${o}.${c}`,
              r = 2;
            for (; n.has(u);) u = `${o}-${r++}.${c}`;
            return [
              ...x,
              { url: URL.createObjectURL(i), name: u, time: a, blob: i },
            ];
          }),
            v.success(
              `Captured at ${a.toFixed(2)} s (${e.width} x ${e.height} px)`,
            ));
        },
        D ? "image/jpeg" : "image/png",
        0.92,
      );
    },
    me = async () => {
      const e = N.current;
      if (p) {
        if (L) {
          const a = ee(R);
          if (!(a >= 0)) {
            v.error("Type the time of the frame, for example 0:05.5");
            return;
          }
          H(!0);
          try {
            const i = await ke(() => {}),
              c = p.name.match(/\.([^.]+)$/)?.[1] || "mp4";
            await i.writeFile(`input.${c}`, await Se(p));
            const s = await je(i, `input.${c}`, a),
              o = await createImageBitmap(Te(s, "image/png"));
            V(K(o, o.width, o.height), a);
          } catch {
            v.error("Could not read that frame from the video");
          } finally {
            H(!1);
          }
          return;
        }
        e && V(K(e, e.videoWidth, e.videoHeight), e.currentTime);
      }
    },
    Q = (e) => {
      const a = N.current;
      a &&
        (a.pause(),
        (a.currentTime = Math.max(0, Math.min(a.duration || 0, e))));
    },
    ue = async () => {
      if (j) {
        (q(!0), C([]));
        try {
          const e = document.createElement("video");
          ((e.src = j),
            (e.muted = !0),
            (e.preload = "auto"),
            await new Promise((u, r) => {
              ((e.onloadeddata = () => u()),
                (e.onerror = () => r(new Error("play"))));
            }));
          const a = e.duration || 0,
            i = [],
            c = document.createElement("canvas"),
            s = 192,
            o = Math.max(
              1,
              Math.round((192 * e.videoHeight) / Math.max(1, e.videoWidth)),
            );
          ((c.width = s), (c.height = o));
          const x = c.getContext("2d", { willReadFrequently: !0 });
          for (let u = 0; u < 10; u++) {
            const r = a * ((u + 0.5) / 10);
            (await new Promise((m) => {
              ((e.onseeked = () => m()), (e.currentTime = r));
            }),
              x.drawImage(e, 0, 0, s, o));
            const h = x.getImageData(0, 0, s, o).data,
              l = new Float32Array(s * o);
            let f = 0;
            for (let m = 0; m < l.length; m++)
              ((l[m] =
                0.299 * h[m * 4] + 0.587 * h[m * 4 + 1] + 0.114 * h[m * 4 + 2]),
                (f += l[m]));
            f /= l.length;
            let I = 0,
              g = 0;
            for (let m = 1; m < o - 1; m++)
              for (let P = 1; P < s - 1; P++) {
                const S = m * s + P,
                  X = 4 * l[S] - l[S - 1] - l[S + 1] - l[S - s] - l[S + s];
                ((I += X * X), g++);
              }
            const w = g ? I / g : 0;
            i.push({
              t: r,
              url: c.toDataURL("image/jpeg", 0.7),
              score: f < 20 || f > 240 ? -1 : w,
              best: !1,
            });
          }
          const n = i.reduce((u, r) => (r.score > u.score ? r : u), i[0]);
          (n && n.score >= 0 && (n.best = !0), C(i));
        } catch {
          v.error(
            "This video can't be previewed in your browser, so frames can't be suggested.",
          );
        } finally {
          q(!1);
        }
      }
    },
    pe = async () => {
      const e = new ye(),
        a = new Set();
      for (const i of y) {
        let c = i.name,
          s = 2;
        for (; a.has(c);) c = i.name.replace(/(\.[^.]+)$/, `-${s++}$1`);
        (a.add(c), e.file(c, i.blob));
      }
      be(
        await e.generateAsync({ type: "blob" }),
        `${p?.name.replace(/\.[^.]+$/, "") || "thumbnails"}_frames.zip`,
      );
    };
  return t.jsxs(fe, {
    children: [
      p
        ? t.jsxs("div", {
            className: "space-y-4",
            children: [
              L
                ? t.jsx(we, {
                    className: "text-sm",
                    children:
                      "Your browser can't play this video (often iPhone HEVC video). You can still capture a frame: type the time below and press Capture. It takes a little longer because the frame is read by the video engine.",
                  })
                : t.jsx("video", {
                    ref: N,
                    src: j,
                    controls: !0,
                    className: "w-full max-h-64 rounded-lg border",
                    onError: () => O(!0),
                    onLoadedMetadata: (e) => {
                      e.currentTarget.videoWidth || O(!0);
                    },
                    onTimeUpdate: (e) => {
                      document.activeElement?.id !== "thumb-time" &&
                        B(M(e.currentTarget.currentTime));
                    },
                  }),
              t.jsx("p", {
                className: "text-sm text-muted-foreground",
                children:
                  "Seek to the frame you want (use the step buttons for fine control), then click Capture. You can capture as many frames as you like.",
              }),
              t.jsxs("div", {
                className: "flex flex-wrap gap-2 items-center",
                children: [
                  t.jsx(b, {
                    variant: "outline",
                    size: "sm",
                    onClick: () => F(-1),
                    children: "-1 s",
                  }),
                  t.jsx(b, {
                    variant: "outline",
                    size: "sm",
                    onClick: () => F(-1 / 30),
                    children: "-1 frame",
                  }),
                  t.jsx(b, {
                    variant: "outline",
                    size: "sm",
                    onClick: () => F(1 / 30),
                    children: "+1 frame",
                  }),
                  t.jsx(b, {
                    variant: "outline",
                    size: "sm",
                    onClick: () => F(1),
                    children: "+1 s",
                  }),
                  t.jsxs("label", {
                    className: "flex items-center gap-1.5 text-sm",
                    children: [
                      "Time",
                      t.jsx("input", {
                        id: "thumb-time",
                        className:
                          "border rounded px-2 py-1 w-24 bg-background",
                        value: R,
                        onChange: (e) => B(e.target.value),
                        onKeyDown: (e) => {
                          if (e.key === "Enter") {
                            const a = ee(R);
                            a >= 0
                              ? Q(a)
                              : v.error("Use a time like 1:05.5 or 65.5");
                          }
                        },
                        "aria-label":
                          "Time of the frame (mm:ss.ms), press Enter to jump",
                      }),
                    ],
                  }),
                  t.jsxs("label", {
                    className: "flex items-center gap-1.5 text-sm ml-2",
                    children: [
                      t.jsx("input", {
                        type: "checkbox",
                        checked: D,
                        onChange: (e) => se(e.target.checked),
                      }),
                      " Save as JPG (smaller)",
                    ],
                  }),
                ],
              }),
              t.jsxs("div", {
                className: "flex flex-wrap gap-3 items-center text-sm",
                children: [
                  t.jsxs("label", {
                    className: "flex items-center gap-1.5",
                    children: [
                      "Size",
                      t.jsx("select", {
                        className: "border rounded px-2 py-1 bg-background",
                        value: k,
                        onChange: (e) => oe(e.target.value),
                        children: te.map((e) =>
                          t.jsx(
                            "option",
                            { value: e.id, children: e.label },
                            e.id,
                          ),
                        ),
                      }),
                    ],
                  }),
                  k !== "orig" &&
                    t.jsxs("label", {
                      className: "flex items-center gap-1.5",
                      children: [
                        "Shape",
                        t.jsxs("select", {
                          className: "border rounded px-2 py-1 bg-background",
                          value: W,
                          onChange: (e) => re(e.target.value),
                          children: [
                            t.jsx("option", {
                              value: "fill",
                              children: "Fill (crop the edges)",
                            }),
                            t.jsx("option", {
                              value: "fit",
                              children: "Fit (black bars)",
                            }),
                          ],
                        }),
                      ],
                    }),
                  t.jsxs("label", {
                    className: "flex items-center gap-1.5",
                    children: [
                      "Title (optional)",
                      t.jsx("input", {
                        className:
                          "border rounded px-2 py-1 bg-background w-56",
                        value: $,
                        onChange: (e) => ie(e.target.value),
                        placeholder: "Text on the image",
                      }),
                    ],
                  }),
                  $.trim() &&
                    t.jsxs(t.Fragment, {
                      children: [
                        t.jsxs("label", {
                          className: "flex items-center gap-1.5",
                          children: [
                            "Font",
                            t.jsx("select", {
                              className:
                                "border rounded px-2 py-1 bg-background",
                              value: _,
                              onChange: (e) => ne(e.target.value),
                              children: ae.map((e) =>
                                t.jsx(
                                  "option",
                                  { value: e.id, children: e.label },
                                  e.id,
                                ),
                              ),
                            }),
                          ],
                        }),
                        t.jsxs("label", {
                          className: "flex items-center gap-1.5",
                          children: [
                            "Colour",
                            t.jsx("select", {
                              className:
                                "border rounded px-2 py-1 bg-background",
                              value: E,
                              onChange: (e) => le(e.target.value),
                              children: $e.map((e) =>
                                t.jsx(
                                  "option",
                                  { value: e.id, children: e.label },
                                  e.id,
                                ),
                              ),
                            }),
                          ],
                        }),
                        t.jsxs("label", {
                          className: "flex items-center gap-1.5",
                          children: [
                            "Size",
                            t.jsx("input", {
                              type: "range",
                              min: 5,
                              max: 16,
                              value: A,
                              onChange: (e) => ce(Number(e.target.value)),
                              "aria-label": "Title size",
                            }),
                          ],
                        }),
                      ],
                    }),
                ],
              }),
              t.jsxs("div", {
                className: "flex flex-wrap gap-3",
                children: [
                  t.jsx(b, {
                    onClick: me,
                    disabled: G,
                    children: G ? "Reading frame..." : "Capture Thumbnail",
                  }),
                  !L &&
                    t.jsx(b, {
                      variant: "outline",
                      onClick: ue,
                      disabled: Z,
                      children: Z ? "Looking..." : "Suggest frames",
                    }),
                  t.jsx(b, {
                    variant: "outline",
                    onClick: () => {
                      (T(null), Y(""), z([]), C([]));
                    },
                    children: "Reset",
                  }),
                ],
              }),
              J.length > 0 &&
                t.jsxs("div", {
                  className: "space-y-1",
                  children: [
                    t.jsx("p", {
                      className: "text-xs text-muted-foreground",
                      children:
                        "Click a frame to jump to it. The marked one is the sharpest, well-lit frame; dark or very bright frames are skipped.",
                    }),
                    t.jsx("div", {
                      className: "grid grid-cols-5 gap-2",
                      children: J.map((e, a) =>
                        t.jsxs(
                          "button",
                          {
                            type: "button",
                            onClick: () => Q(e.t),
                            className: `relative rounded border overflow-hidden ${e.best ? "ring-2 ring-primary" : ""} ${e.score < 0 ? "opacity-40" : ""}`,
                            title: `${M(e.t)}${e.best ? " (suggested)" : e.score < 0 ? " (too dark or bright)" : ""}`,
                            children: [
                              t.jsx("img", {
                                src: e.url,
                                alt: `Frame at ${M(e.t)}`,
                                className: "w-full",
                              }),
                              t.jsxs("span", {
                                className:
                                  "absolute bottom-0 left-0 bg-black/60 text-white text-[10px] px-1",
                                children: [M(e.t), e.best ? " ★" : ""],
                              }),
                            ],
                          },
                          a,
                        ),
                      ),
                    }),
                  ],
                }),
              y.length > 1 &&
                t.jsxs(b, {
                  variant: "outline",
                  size: "sm",
                  onClick: pe,
                  children: ["Download all as ZIP (", y.length, ")"],
                }),
              y.length > 0 &&
                t.jsx("div", {
                  className: "grid grid-cols-2 sm:grid-cols-3 gap-3",
                  "data-testid": "thumb-gallery",
                  children: y.map((e, a) =>
                    t.jsxs(
                      "div",
                      {
                        className: "space-y-1",
                        children: [
                          t.jsx("img", {
                            src: e.url,
                            alt: `Frame at ${e.time.toFixed(1)}s`,
                            className: "rounded-lg border w-full",
                          }),
                          t.jsx("p", {
                            className: "text-xs text-muted-foreground truncate",
                            children: e.name,
                          }),
                          t.jsx(xe, {
                            blob: e.blob,
                            fileName: e.name,
                            label: "Download",
                          }),
                        ],
                      },
                      a,
                    ),
                  ),
                }),
            ],
          })
        : t.jsx(ge, {
            gateAtDownload: !0,
            accept: "video/*",
            onFiles: de,
            label: "Drop a video",
            description: "Generate thumbnails from video frames",
          }),
      t.jsx(ve, { whatIsIt: U.what, howToUse: U.how, tip: U.tip }),
    ],
  });
}
export { lt as default };
//# sourceMappingURL=ThumbnailGen-BeEuZmFi.js.map
