var s;
(function (t) {
  ((t.LOAD = "LOAD"),
    (t.EXEC = "EXEC"),
    (t.FFPROBE = "FFPROBE"),
    (t.WRITE_FILE = "WRITE_FILE"),
    (t.READ_FILE = "READ_FILE"),
    (t.DELETE_FILE = "DELETE_FILE"),
    (t.RENAME = "RENAME"),
    (t.CREATE_DIR = "CREATE_DIR"),
    (t.LIST_DIR = "LIST_DIR"),
    (t.DELETE_DIR = "DELETE_DIR"),
    (t.ERROR = "ERROR"),
    (t.DOWNLOAD = "DOWNLOAD"),
    (t.PROGRESS = "PROGRESS"),
    (t.LOG = "LOG"),
    (t.MOUNT = "MOUNT"),
    (t.UNMOUNT = "UNMOUNT"));
})(s || (s = {}));
const y = (() => {
    let t = 0;
    return () => t++;
  })(),
  L = new Error("ffmpeg is not loaded, call `await ffmpeg.load()` first"),
  N = new Error("called FFmpeg.terminate()");
class I {
  #t = null;
  #o = {};
  #r = {};
  #n = [];
  #s = [];
  loaded = !1;
  #a = () => {
    this.#t &&
      (this.#t.onmessage = ({ data: { id: e, type: r, data: o } }) => {
        switch (r) {
          case s.LOAD:
            ((this.loaded = !0), this.#o[e](o));
            break;
          case s.MOUNT:
          case s.UNMOUNT:
          case s.EXEC:
          case s.FFPROBE:
          case s.WRITE_FILE:
          case s.READ_FILE:
          case s.DELETE_FILE:
          case s.RENAME:
          case s.CREATE_DIR:
          case s.LIST_DIR:
          case s.DELETE_DIR:
            this.#o[e](o);
            break;
          case s.LOG:
            this.#n.forEach((n) => n(o));
            break;
          case s.PROGRESS:
            this.#s.forEach((n) => n(o));
            break;
          case s.ERROR:
            this.#r[e](o);
            break;
        }
        (delete this.#o[e], delete this.#r[e]);
      });
  };
  #e = ({ type: e, data: r }, o = [], n) =>
    this.#t
      ? new Promise((c, i) => {
          const a = y();
          (this.#t && this.#t.postMessage({ id: a, type: e, data: r }, o),
            (this.#o[a] = c),
            (this.#r[a] = i),
            n?.addEventListener(
              "abort",
              () => {
                i(new DOMException(`Message # ${a} was aborted`, "AbortError"));
              },
              { once: !0 },
            ));
        })
      : Promise.reject(L);
  on(e, r) {
    e === "log" ? this.#n.push(r) : e === "progress" && this.#s.push(r);
  }
  off(e, r) {
    e === "log"
      ? (this.#n = this.#n.filter((o) => o !== r))
      : e === "progress" && (this.#s = this.#s.filter((o) => o !== r));
  }
  load = ({ classWorkerURL: e, ...r } = {}, { signal: o } = {}) => (
    this.#t ||
      ((this.#t = e
        ? new Worker(new URL(e, import.meta.url), { type: "module" })
        : new Worker(new URL("/assets/worker-DYSz7Krg.js", import.meta.url), {
            type: "module",
          })),
      this.#a()),
    this.#e({ type: s.LOAD, data: r }, void 0, o)
  );
  exec = (e, r = -1, { signal: o } = {}) =>
    this.#e({ type: s.EXEC, data: { args: e, timeout: r } }, void 0, o);
  ffprobe = (e, r = -1, { signal: o } = {}) =>
    this.#e({ type: s.FFPROBE, data: { args: e, timeout: r } }, void 0, o);
  terminate = () => {
    const e = Object.keys(this.#r);
    for (const r of e) (this.#r[r](N), delete this.#r[r], delete this.#o[r]);
    this.#t && (this.#t.terminate(), (this.#t = null), (this.loaded = !1));
  };
  writeFile = (e, r, { signal: o } = {}) => {
    const n = [];
    return (
      r instanceof Uint8Array && n.push(r.buffer),
      this.#e({ type: s.WRITE_FILE, data: { path: e, data: r } }, n, o)
    );
  };
  mount = (e, r, o) => {
    const n = [];
    return this.#e(
      { type: s.MOUNT, data: { fsType: e, options: r, mountPoint: o } },
      n,
    );
  };
  unmount = (e) => {
    const r = [];
    return this.#e({ type: s.UNMOUNT, data: { mountPoint: e } }, r);
  };
  readFile = (e, r = "binary", { signal: o } = {}) =>
    this.#e({ type: s.READ_FILE, data: { path: e, encoding: r } }, void 0, o);
  deleteFile = (e, { signal: r } = {}) =>
    this.#e({ type: s.DELETE_FILE, data: { path: e } }, void 0, r);
  rename = (e, r, { signal: o } = {}) =>
    this.#e({ type: s.RENAME, data: { oldPath: e, newPath: r } }, void 0, o);
  createDir = (e, { signal: r } = {}) =>
    this.#e({ type: s.CREATE_DIR, data: { path: e } }, void 0, r);
  listDir = (e, { signal: r } = {}) =>
    this.#e({ type: s.LIST_DIR, data: { path: e } }, void 0, r);
  deleteDir = (e, { signal: r } = {}) =>
    this.#e({ type: s.DELETE_DIR, data: { path: e } }, void 0, r);
}
var b;
(function (t) {
  ((t.MEMFS = "MEMFS"),
    (t.NODEFS = "NODEFS"),
    (t.NODERAWFS = "NODERAWFS"),
    (t.IDBFS = "IDBFS"),
    (t.WORKERFS = "WORKERFS"),
    (t.PROXYFS = "PROXYFS"));
})(b || (b = {}));
const A = new Error("failed to get response body reader"),
  B = new Error("failed to complete download"),
  v = "Content-Length",
  U = (t) =>
    new Promise((e, r) => {
      const o = new FileReader();
      ((o.onload = () => {
        const { result: n } = o;
        n instanceof ArrayBuffer ? e(new Uint8Array(n)) : e(new Uint8Array());
      }),
        (o.onerror = (n) => {
          r(
            Error(
              `File could not be read! Code=${n?.target?.error?.code || -1}`,
            ),
          );
        }),
        o.readAsArrayBuffer(t));
    }),
  T = async (t) => {
    let e;
    if (typeof t == "string")
      /data:_data\/([a-zA-Z]*);base64,([^"]*)/.test(t)
        ? (e = atob(t.split(",")[1])
            .split("")
            .map((r) => r.charCodeAt(0)))
        : (e = await (await fetch(t)).arrayBuffer());
    else if (t instanceof URL) e = await (await fetch(t)).arrayBuffer();
    else if (t instanceof File || t instanceof Blob) e = await U(t);
    else return new Uint8Array();
    return new Uint8Array(e);
  },
  F = async (t, e) => {
    const r = await fetch(t);
    let o;
    try {
      const n = parseInt(r.headers.get(v) || "-1"),
        c = r.body?.getReader();
      if (!c) throw A;
      const i = [];
      let a = 0;
      for (;;) {
        const { done: f, value: h } = await c.read(),
          p = h ? h.length : 0;
        if (f) {
          if (n != -1 && n !== a) throw B;
          e && e({ url: t, total: n, received: a, delta: p, done: f });
          break;
        }
        (i.push(h),
          (a += p),
          e && e({ url: t, total: n, received: a, delta: p, done: f }));
      }
      const d = new Uint8Array(a);
      let l = 0;
      for (const f of i) (d.set(f, l), (l += f.length));
      o = d.buffer;
    } catch (n) {
      (console.log("failed to send download progress event: ", n),
        (o = await r.arrayBuffer()));
    }
    return o;
  },
  _ = async (t, e, r = !1, o) => {
    const n = r ? await F(t, o) : await (await fetch(t)).arrayBuffer(),
      c = new Blob([n], { type: e });
    return URL.createObjectURL(c);
  },
  R = 50 * 1024 * 1024,
  g = 200 * 1024 * 1024;
function j(t) {
  return t ? g : R;
}
function C(t, e, r = !1) {
  const o = t.reduce((c, i) => c + i.size, 0);
  let n = "ok";
  return (
    r ||
      (o > g
        ? (n = "over-hard-limit")
        : !e && o > R && (n = "over-free-limit")),
    { severity: n, totalBytes: o, freeMaxBytes: R, proMaxBytes: g }
  );
}
function M(t) {
  return t >= 1024 * 1024
    ? `${(t / (1024 * 1024)).toFixed(1)} MB`
    : `${(t / 1024).toFixed(0)} KB`;
}
class S extends Error {
  constructor() {
    (super(
      "Couldn't download the processing engine — a firewall or restrictive network may be blocking it.",
    ),
      (this.name = "FirewallBlockedError"));
  }
}
class D extends Error {
  constructor() {
    (super("Processing was stopped."), (this.name = "UserCancelledError"));
  }
}
let w = null,
  E = null;
function k(t) {
  (t.terminate(), (w = null), (E = null));
}
const W = k;
async function $(t) {
  return (
    w ||
    (E ||
      (E = (async () => {
        const e = new I();
        e.on("log", ({ message: a }) => console.log("[ffmpeg]", a));
        const r = "https://cdn.jsdelivr.net/npm/@ffmpeg/core@0.12.10/dist/esm",
          o = "https://cdn.jsdelivr.net/npm/@ffmpeg/ffmpeg@0.12.15/dist/esm";
        let n, c, i;
        try {
          (t?.(
            "Downloading processing engine (about 25MB, first time only)...",
          ),
            ([n, c] = await Promise.all([
              _(`${r}/ffmpeg-core.js`, "text/javascript"),
              _(`${r}/ffmpeg-core.wasm`, "application/wasm"),
            ])));
          const l = (await (await fetch(`${o}/worker.js`)).text())
            .replace('"./const.js"', `"${o}/const.js"`)
            .replace('"./errors.js"', `"${o}/errors.js"`);
          i = URL.createObjectURL(new Blob([l], { type: "text/javascript" }));
        } catch (a) {
          throw (
            console.error("FFmpeg engine download failed:", a),
            (E = null),
            new S()
          );
        }
        try {
          (t?.("Starting processing engine..."),
            await e.load({ coreURL: n, wasmURL: c, classWorkerURL: i }));
        } catch (a) {
          throw (
            console.error(
              "FFmpeg engine failed to start after downloading successfully:",
              a,
            ),
            (E = null),
            a
          );
        }
        return ((w = e), e);
      })()),
    E)
  );
}
async function X(t, e, r, o, n) {
  const c = ({ progress: d, time: l }) => {
    let f = d;
    (n && n > 0 && typeof l == "number" && l > 0 && (f = l / 1e6 / n),
      Number.isFinite(f) && r(Math.max(0, Math.min(1, f))));
  };
  t.on("progress", c);
  const i = [],
    a = ({ message: d }) => {
      (i.push(d), i.length > 30 && i.shift());
    };
  t.on("log", a);
  try {
    const d = await t.exec(e, void 0, o ? { signal: o } : void 0);
    if (o?.aborted) throw new D();
    if (d !== 0) {
      console.error(
        `FFmpeg command failed. Recent log output:
` +
          i.join(`
`),
      );
      const l = P(i);
      throw new Error(
        l ? `Processing failed: ${l}` : `Processing failed (exit code ${d}).`,
      );
    }
  } catch (d) {
    throw o?.aborted
      ? new D()
      : ((!(d instanceof Error) ||
          !d.message.startsWith("Processing failed")) &&
          console.error(
            `FFmpeg command threw. Recent log output:
` +
              i.join(`
`),
          ),
        d);
  } finally {
    (t.off("progress", c), t.off("log", a));
  }
}
function z(t, e) {
  return typeof t == "string"
    ? new Blob([t], { type: e })
    : new Blob([new Uint8Array(t)], { type: e });
}
async function G(t, e) {
  await t.ffprobe([
    "-v",
    "error",
    "-show_entries",
    "format=duration",
    "-of",
    "default=noprint_wrappers=1:nokey=1",
    e,
    "-o",
    "duration.txt",
  ]);
  const r = await t.readFile("duration.txt"),
    o = typeof r == "string" ? r : new TextDecoder().decode(r),
    n = parseFloat(o.trim());
  if (!Number.isFinite(n) || n <= 0)
    throw new Error("Couldn't determine this file's duration");
  return n;
}
function x(t) {
  const e = JSON.parse(t),
    r = e.streams ?? [],
    o = r.find((u) => u.codec_type === "video"),
    n = r.find((u) => u.codec_type === "audio");
  let c = Number(o?.width) || 0,
    i = Number(o?.height) || 0;
  const a = (o?.side_data_list ?? [])
      .map((u) => u.rotation)
      .find((u) => u !== void 0),
    d = Math.abs(Number(a ?? o?.tags?.rotate ?? 0)) % 180,
    l = a !== void 0 ? -Number(a) : Number(o?.tags?.rotate ?? 0),
    f = Number.isFinite(l)
      ? (((Math.round(l / 90) * 90) % 360) + 360) % 360
      : 0;
  d === 90 && ([c, i] = [i, c]);
  let h = 30;
  const m = String(o?.avg_frame_rate ?? o?.r_frame_rate ?? "").match(
    /^(\d+)\/(\d+)$/,
  );
  m &&
    Number(m[2]) > 0 &&
    Number(m[1]) > 0 &&
    (h = Number(m[1]) / Number(m[2]));
  const O = Number(e.format?.duration) || Number(o?.duration) || 0;
  return {
    width: c,
    height: i,
    duration: O,
    hasAudio: !!n,
    hasVideo: !!o,
    fps: h,
    vcodec: o?.codec_name ?? "",
    acodec: n?.codec_name ?? "",
    sampleRate: Number(n?.sample_rate) || 0,
    channels: Number(n?.channels) || 0,
    pixFmt: o?.pix_fmt ?? "",
    rotation: f,
  };
}
async function Y(t, e) {
  await t.ffprobe([
    "-v",
    "error",
    "-show_entries",
    "stream=codec_type,codec_name,width,height,avg_frame_rate,r_frame_rate,duration,sample_rate,channels,pix_fmt:stream_side_data=rotation:stream_tags=rotate:format=duration",
    "-of",
    "json",
    e,
    "-o",
    "probe.json",
  ]);
  const r = await t.readFile("probe.json");
  return x(typeof r == "string" ? r : new TextDecoder().decode(r));
}
function P(t) {
  const e = t.join(`
`);
  return /moov atom not found/i.test(e)
    ? "The file looks incomplete or damaged (no movie header found)."
    : /Invalid data found when processing input/i.test(e)
      ? "This file isn't a video ffmpeg can read, or it is damaged."
      : /does not contain any stream/i.test(e)
        ? "This file has no audio or video in it."
        : /Output file does not contain any stream/i.test(e)
          ? "Nothing could be produced from this file."
          : /Error while opening encoder/i.test(e)
            ? "The video's size or settings can't be encoded (try a smaller size)."
            : /Cannot allocate memory|memory access out of bounds|out of memory/i.test(
                  e,
                )
              ? "The browser ran out of memory. Try a shorter or smaller video."
              : /Invalid argument/i.test(e) && /subtitle|ass|srt/i.test(e)
                ? "The subtitles could not be read."
                : null;
}
export {
  R as FREE_MAX_BYTES,
  S as FirewallBlockedError,
  g as PRO_MAX_BYTES,
  D as UserCancelledError,
  C as checkFileSize,
  X as execWithProgress,
  P as explainFfmpegLog,
  T as fetchFile,
  z as ffmpegOutputToBlob,
  M as formatBytes,
  j as getMaxFileSize,
  G as getMediaDurationSeconds,
  $ as loadFFmpeg,
  x as parseProbeJson,
  Y as probeMedia,
  k as resetFFmpegEngine,
  W as stopProcessing,
};
//# sourceMappingURL=ffmpegEngine-DH91Xnxx.js.map
