import {
  s as T,
  b as B,
  a as D,
  t as L,
  h as I,
} from "./scriptFonts-B9baRZsf.js";
import { c as z } from "./utils-qgqMjnRG.js";
import {
  execWithProgress as x,
  probeMedia as M,
  fetchFile as y,
  FREE_MAX_BYTES as H,
  FirewallBlockedError as W,
  PRO_MAX_BYTES as U,
  UserCancelledError as P,
  checkFileSize as Y,
  ffmpegOutputToBlob as G,
  formatBytes as X,
  getMaxFileSize as q,
  getMediaDurationSeconds as J,
  loadFFmpeg as Q,
  resetFFmpegEngine as K,
  stopProcessing as Z,
} from "./ffmpegEngine-DH91Xnxx.js";
function tt(t) {
  return T(
    t.map((e) => e.text).join(`
`),
  ).some((e) => e.id !== "Hebrew");
}
const et = 0.4;
function at(t, e, a) {
  const n = Math.round((e * et) / 2) * 2,
    c =
      a === "top"
        ? 0
        : a === "middle"
          ? Math.round((e - n) / 2 / 2) * 2
          : e - n;
  return { w: t, h: n, y: c };
}
async function nt(t) {
  const e = [],
    a = "/fonts/Roboto-Regular.ttf",
    n = [],
    c = (r, o) => {
      if (
        (e.push(r),
        !Array.from(document.fonts).some(
          (i) => i.family.replace(/"/g, "") === r && i.status === "loaded",
        ))
      ) {
        const i = new FontFace(r, `url(${o})`);
        n.push(i.load().then((u) => document.fonts.add(u)));
      }
    };
  c("Roboto", a);
  for (const r of T(t)) c(D(r), B(r.file));
  return (await Promise.all(n), e);
}
function ot(t, e, a) {
  const n = [];
  for (const c of e.split(`
`)) {
    const r = c.trim().split(/\s+/);
    let o = "";
    for (const i of r) {
      const u = o ? `${o} ${i}` : i;
      t.measureText(u).width > a && o ? (n.push(o), (o = i)) : (o = u);
    }
    n.push(o);
  }
  return n;
}
async function it(t, e, a, n) {
  const c = (m) => m.replace(/<[^>]*>/g, "").trim(),
    r = await nt(
      t.map((m) => m.text).join(`
`),
    ),
    o = at(e, a, n.position),
    i = Math.max(14, Math.round(Math.min(e, a) * n.sizeFraction)),
    u = r
      .map((m) => `"${m}"`)
      .concat("sans-serif")
      .join(", "),
    l = document.createElement("canvas");
  ((l.width = o.w), (l.height = o.h));
  const s = l.getContext("2d"),
    d = () =>
      new Promise((m, g) =>
        l.toBlob(
          async (f) =>
            f
              ? m(new Uint8Array(await f.arrayBuffer()))
              : g(new Error("Could not draw the subtitles")),
          "image/png",
        ),
      );
  s.clearRect(0, 0, o.w, o.h);
  const p = await d(),
    h = [],
    $ = Math.round(a * 0.05);
  for (const m of t) {
    (s.clearRect(0, 0, o.w, o.h),
      (s.font = `400 ${i}px ${u}`),
      (s.textAlign = "center"),
      (s.textBaseline = "alphabetic"));
    const g = ot(s, c(m.text), o.w * 0.9),
      f = i * 1.35,
      w = g.length * f;
    let b =
      n.position === "top"
        ? $
        : n.position === "middle"
          ? (o.h - w) / 2
          : o.h - $ - w;
    if (((b = Math.max(0, b)), n.background)) {
      const S = Math.max(...g.map((v) => s.measureText(v).width));
      ((s.fillStyle = "rgba(0,0,0,0.6)"),
        s.fillRect(
          o.w / 2 - S / 2 - i * 0.4,
          b - i * 0.1,
          S + i * 0.8,
          w + i * 0.2,
        ));
    }
    ((s.lineJoin = "round"),
      (s.lineWidth = Math.max(2, i * 0.12)),
      (s.strokeStyle = "#000"),
      (s.fillStyle = n.color === "yellow" ? "#ffff00" : "#ffffff"),
      g.forEach((S, v) => {
        const F = b + v * f + i * 1;
        (s.strokeText(S, o.w / 2, F), s.fillText(S, o.w / 2, F));
      }),
      h.push(await d()));
  }
  return { strips: h, blank: p, geo: o };
}
function rt(t) {
  const e = [];
  let a = 0;
  const n = (r, o) => {
      e.push(`file '${r}'`, `duration ${o.toFixed(3)}`);
    },
    c = t.map((r, o) => ({ c: r, i: o })).sort((r, o) => r.c.start - o.c.start);
  for (const { c: r, i: o } of c) {
    const i = Math.max(r.start, a);
    (i > a && n("blank.png", i - a),
      r.end > i && (n(`strip${o}.png`, r.end - i), (a = r.end)));
  }
  return (
    e.push("file 'blank.png'"),
    e.join(`
`) +
      `
`
  );
}
const Rt = [
    {
      value: "mp4",
      label: "MP4 (widely compatible)",
      mime: "video/mp4",
      ext: "mp4",
    },
    {
      value: "mp4-web",
      label: "MP4 for web (streaming / HTML5)",
      mime: "video/mp4",
      ext: "mp4",
    },
    {
      value: "webm",
      label: "WebM (HTML5 web video)",
      mime: "video/webm",
      ext: "webm",
    },
    {
      value: "mov",
      label: "MOV (Apple / QuickTime)",
      mime: "video/quicktime",
      ext: "mov",
    },
    {
      value: "mkv",
      label: "MKV (Matroska)",
      mime: "video/x-matroska",
      ext: "mkv",
    },
    {
      value: "avi",
      label: "AVI (older players)",
      mime: "video/x-msvideo",
      ext: "avi",
    },
  ],
  k = "scale=trunc(iw/2)*2:trunc(ih/2)*2",
  V = ["mp4", "mp4-web", "mov", "mkv"];
function st(t, e) {
  return (
    V.includes(t) && e.vcodec === "h264" && (!e.hasAudio || e.acodec === "aac")
  );
}
function ct(t, e, a) {
  return [
    "-i",
    e,
    "-c",
    "copy",
    ...(t === "mp4" || t === "mp4-web" ? ["-movflags", "+faststart"] : []),
    a,
  ];
}
function lt(t, e, a) {
  return t === "webm"
    ? [
        "-i",
        e,
        "-vf",
        "scale='min(1280,iw)':-2",
        "-c:v",
        "libvpx",
        "-deadline",
        "realtime",
        "-cpu-used",
        "8",
        "-b:v",
        "1M",
        "-c:a",
        "libvorbis",
        "-b:a",
        "96k",
        "-f",
        "webm",
        a,
      ]
    : t === "avi"
      ? [
          "-i",
          e,
          "-vf",
          k,
          "-c:v",
          "mpeg4",
          "-q:v",
          "4",
          "-pix_fmt",
          "yuv420p",
          "-c:a",
          "libmp3lame",
          "-b:a",
          "128k",
          a,
        ]
      : [
          "-i",
          e,
          "-vf",
          k,
          "-c:v",
          "libx264",
          "-preset",
          "veryfast",
          "-crf",
          "23",
          "-pix_fmt",
          "yuv420p",
          "-c:a",
          "aac",
          "-b:a",
          "128k",
          ...(t === "mp4" || t === "mp4-web"
            ? ["-movflags", "+faststart"]
            : []),
          a,
        ];
}
const A = (t) => Math.max(2, Math.round(t / 2) * 2),
  dt = 0.5,
  ut = {
    landscape: [1920, 1080],
    portrait: [1080, 1920],
    square: [1080, 1080],
  },
  ft = new Set(["h264"]),
  mt = new Set(["aac"]);
function pt(t) {
  const e = t[0];
  return !e ||
    !e.hasVideo ||
    !ft.has(e.vcodec) ||
    (e.hasAudio && !mt.has(e.acodec))
    ? !1
    : t.every(
        (a) =>
          a.hasVideo &&
          a.vcodec === e.vcodec &&
          a.width === e.width &&
          a.height === e.height &&
          Math.abs(a.fps - e.fps) < 0.01 &&
          a.pixFmt === e.pixFmt &&
          a.hasAudio === e.hasAudio &&
          a.acodec === e.acodec &&
          a.sampleRate === e.sampleRate &&
          a.channels === e.channels,
      );
}
function ht(t, e) {
  if (!(e > 0) || t.length < 2) return 0;
  const a = Math.min(...t.map((c) => (c.duration > 0 ? c.duration : 1))),
    n = Math.floor(Math.min(e, a * 0.4) * 100) / 100;
  return n >= 0.1 ? n : 0;
}
function wt(t, e = "first", a = !1, n = 0) {
  const c = t[0],
    [r, o] = e === "first" ? [A(c.width || 1280), A(c.height || 720)] : ut[e],
    i = Math.min(60, Math.max(10, Math.round(c.fps || 30))),
    u = t.some((f) => f.hasAudio),
    l = ht(t, n),
    s = (f) => Math.max(0.1, f.duration || 1),
    d = [],
    p = [];
  t.forEach((f, w) => {
    if (
      (d.push(
        `[${w}:v]${a ? `scale=${r}:${o}:force_original_aspect_ratio=increase,crop=${r}:${o}` : `scale=${r}:${o}:force_original_aspect_ratio=decrease,pad=${r}:${o}:(ow-iw)/2:(oh-ih)/2:color=black`},setsar=1,fps=${i},format=yuv420p,setpts=PTS-STARTPTS[v${w}]`,
      ),
      u)
    ) {
      const b = l ? `,apad,atrim=duration=${s(f).toFixed(3)}` : "";
      (f.hasAudio
        ? d.push(
            `[${w}:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo${b},asetpts=PTS-STARTPTS[a${w}]`,
          )
        : d.push(
            `anullsrc=r=44100:cl=stereo,atrim=duration=${s(f).toFixed(3)},asetpts=PTS-STARTPTS[a${w}]`,
          ),
        p.push(`[v${w}][a${w}]`));
    } else p.push(`[v${w}]`);
  });
  let h,
    $ = t.reduce((f, w) => f + (w.duration > 0 ? w.duration : 0), 0);
  if (l) {
    const f = t.length - 1;
    let w = s(t[0]),
      b = "[v0]",
      S = "[a0]";
    for (let v = 1; v <= f; v++) {
      const F = v === f ? "[outv]" : `[xv${v}]`,
        E = v === f ? "[outa]" : `[xa${v}]`;
      (d.push(
        `${b}[v${v}]xfade=transition=fade:duration=${l}:offset=${(w - l).toFixed(3)}${F}`,
      ),
        u && d.push(`${S}[a${v}]acrossfade=d=${l}:c1=tri:c2=tri${E}`),
        (w += s(t[v]) - l),
        (b = F),
        (S = E));
    }
    ((h = d.join(";")), ($ = w));
  } else
    h = `${d.join(";")};${p.join("")}concat=n=${t.length}:v=1:a=${u ? 1 : 0}[outv]${u ? "[outa]" : ""}`;
  const m = t.some((f) => f.width !== r || f.height !== o),
    g = t.some((f) => f.fps > 0 && Math.abs(f.fps - i) > 0.5);
  return {
    mode: e === "first" && !l && pt(t) ? "copy" : "reencode",
    width: r,
    height: o,
    fps: i,
    withAudio: u,
    filter: h,
    fitted: m,
    fpsMismatch: g,
    crossfade: l,
    totalSeconds: $,
  };
}
function $t(t) {
  return [
    "-filter_complex",
    t.filter,
    "-map",
    "[outv]",
    ...(t.withAudio ? ["-map", "[outa]"] : []),
    "-c:v",
    "libx264",
    "-preset",
    "veryfast",
    "-crf",
    "24",
    "-pix_fmt",
    "yuv420p",
    ...(t.withAudio ? ["-c:a", "aac", "-b:a", "128k"] : []),
    "-movflags",
    "+faststart",
    "output.mp4",
  ];
}
const j = {
    sizeFraction: 0.05,
    position: "bottom",
    color: "white",
    background: !1,
  },
  _ = /(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})/;
function R(t) {
  return (
    Number(t[1]) * 3600 +
    Number(t[2]) * 60 +
    Number(t[3]) +
    Number(t[4].padEnd(3, "0")) / 1e3
  );
}
function Ot(t) {
  const e = t.replace(/^\uFEFF/, "").replace(
    /\r\n?/g,
    `
`,
  );
  if (/^\s*\[Script Info\]/im.test(e) || /^Dialogue:/m.test(e)) {
    const a = /^Format:\s*(Layer|Marked),.*Start,\s*End.*Text\s*$/m.exec(
        e,
      )?.[0],
      n = a
        ? a
            .replace(/^Format:\s*/, "")
            .split(",")
            .map((l) => l.trim())
        : [
            "Layer",
            "Start",
            "End",
            "Style",
            "Name",
            "MarginL",
            "MarginR",
            "MarginV",
            "Effect",
            "Text",
          ],
      c = n.indexOf("Start"),
      r = n.indexOf("End"),
      o = n.indexOf("Text"),
      i = (l) => {
        const s = /(\d+):(\d{2}):(\d{2})\.(\d{1,2})/.exec(l.trim());
        return s
          ? `${s[1].padStart(2, "0")}:${s[2]}:${s[3]},${s[4].padEnd(3, "0")}`
          : l.trim();
      },
      u = [];
    for (const l of e.split(`
`)) {
      if (!/^Dialogue:/i.test(l)) continue;
      const s = l.replace(/^Dialogue:\s*/i, "").split(","),
        d = s
          .slice(o)
          .join(",")
          .replace(/\{[^}]*\}/g, "")
          .replace(
            /\\N/gi,
            `
`,
          )
          .trim();
      d &&
        u.push(`${u.length + 1}
${i(s[c])} --> ${i(s[r])}
${d}`);
    }
    return u.join(`

`);
  }
  return /^\s*WEBVTT/.test(e)
    ? e
        .replace(/^\s*WEBVTT[^\n]*\n/, "")
        .trim()
        .split(/\n{2,}/)
        .filter((n) => n.includes("-->"))
        .map((n, c) => {
          const r = n.split(`
`),
            o = r.findIndex((u) => u.includes("-->")),
            i = r[o]
              .replace(/(\s+(align|position|line|size):\S+)+\s*$/g, "")
              .replace(/(^|\s)(\d{2}:\d{2})\.(\d{3})/g, "$100:$2,$3")
              .replace(/(\d{2}:\d{2}:\d{2})\.(\d{3})/g, "$1,$2");
          return `${c + 1}
${i}
${r.slice(o + 1).join(`
`)}`;
        }).join(`

`)
    : e;
}
function N(t) {
  const e = t
    .replace(/^﻿/, "")
    .replace(
      /\r\n?/g,
      `
`,
    )
    .trim();
  if (!e) throw new Error("The subtitles are empty.");
  const a = e.split(/\n{2,}/),
    n = [];
  let c = 1;
  for (const r of a) {
    const o = r.split(`
`);
    let i = 0;
    /^\d+$/.test(o[0].trim()) && (i = 1);
    const u = o[i] ?? "",
      l = u.split("-->"),
      s = l[0]?.match(_),
      d = l[1]?.match(_);
    if (l.length !== 2 || !s || !d)
      throw new Error(
        `Line ${c + i}: expected a time like "00:00:01,000 --> 00:00:04,000" but found "${u.trim().slice(0, 40)}".`,
      );
    const p = R(s),
      h = R(d);
    if (h <= p)
      throw new Error(
        `Line ${c + i}: the end time must be after the start time.`,
      );
    const $ = o
      .slice(i + 1)
      .join(
        `
`,
      )
      .trim();
    ($ && n.push({ start: p, end: h, text: $ }), (c += o.length + 1));
  }
  if (!n.length)
    throw new Error(
      "No subtitle text was found. Each entry needs a time line followed by the text.",
    );
  return n;
}
const O = (t) => {
  const e = Math.round(t * 100),
    a = Math.floor(e / 36e4),
    n = Math.floor((e % 36e4) / 6e3),
    c = Math.floor((e % 6e3) / 100),
    r = e % 100;
  return `${a}:${String(n).padStart(2, "0")}:${String(c).padStart(2, "0")}.${String(r).padStart(2, "0")}`;
};
function gt(t, e, a, n = j) {
  const c = Math.max(14, Math.round(Math.min(e, a) * n.sizeFraction)),
    r = n.position === "top" ? 8 : n.position === "middle" ? 5 : 2,
    o = n.color === "yellow" ? "&H0000FFFF" : "&H00FFFFFF",
    i = Math.round(a * 0.05),
    u = n.background ? 3 : 1,
    l = n.background ? "&H99000000" : "&H00000000",
    s = [
      "[Script Info]",
      "ScriptType: v4.00+",
      `PlayResX: ${e}`,
      `PlayResY: ${a}`,
      "WrapStyle: 0",
      "ScaledBorderAndShadow: yes",
      "",
      "[V4+ Styles]",
      "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding",
      `Style: Default,Roboto,${c},${o},&H000000FF,&H00000000,${l},0,0,0,0,100,100,0,0,${n.background ? 4 : 1},${u},0,${r},${Math.round(e * 0.05)},${Math.round(e * 0.05)},${i},1`,
      "",
      "[Events]",
      "Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text",
    ];
  for (const d of t) {
    const p = d.text
      .replace(/<[^>]*>/g, "")
      .replace(/[{}\\]/g, "")
      .split(
        `
`,
      )
      .map((h) => L(h.trim()))
      .join("\\N");
    s.push(`Dialogue: 0,${O(d.start)},${O(d.end)},Default,,0,0,0,,${p}`);
  }
  return (
    s.join(`
`) +
    `
`
  );
}
async function vt(t, e, a, n, c, r) {
  if (V.includes(n))
    try {
      const i = await M(t, e);
      if (st(n, i))
        return (
          await x(t, ct(n, e, a), c, r),
          { data: await t.readFile(a), rewrapped: !0 }
        );
    } catch (i) {
      if (r?.aborted) throw i;
    }
  let o;
  try {
    const i = (await M(t, e)).duration;
    i > 0 && (o = i);
  } catch {}
  return (
    await x(t, lt(n, e, a), c, r, o),
    { data: await t.readFile(a), rewrapped: !1 }
  );
}
async function xt(t, e, a, n, c, r, o, i = "exact", u = "mp4", l = 0) {
  const s = Number(n),
    d = Number(c),
    p = Math.max(0.1, d - s),
    h = `${a}.mp4`,
    $ = async () => (
      await x(
        t,
        [
          "-ss",
          String(s),
          "-i",
          e,
          "-t",
          p.toFixed(3),
          "-c:v",
          "libx264",
          "-preset",
          "veryfast",
          "-crf",
          "23",
          ...(l > 0
            ? [
                "-maxrate",
                `${Math.round(l)}k`,
                "-bufsize",
                `${Math.round(l * 2)}k`,
              ]
            : []),
          "-pix_fmt",
          "yuv420p",
          "-c:a",
          "aac",
          "-b:a",
          "128k",
          "-movflags",
          "+faststart",
          h,
        ],
        r,
        o,
        p,
      ),
      await t.readFile(h)
    );
  if (i === "exact") return { data: await $(), extension: "mp4", fellBack: !1 };
  const m = `${a}.${u}`;
  await x(
    t,
    [
      "-ss",
      String(s),
      "-i",
      e,
      "-t",
      p.toFixed(3),
      "-c",
      "copy",
      "-avoid_negative_ts",
      "make_zero",
      m,
    ],
    r,
    o,
  );
  try {
    const g = await M(t, m);
    if (
      g.hasVideo &&
      g.duration >= p * 0.5 &&
      g.duration <= p + 2.5 &&
      (await x(
        t,
        ["-i", m, "-frames:v", "1", "-f", "image2", "check_frame.png"],
        () => {},
        o,
      ),
      (await t.readFile("check_frame.png")).length > 200)
    )
      return {
        data: await t.readFile(m),
        extension: u,
        fellBack: !1,
        startedEarlyBy: Math.max(0, Math.round((g.duration - p) * 10) / 10),
      };
  } catch {}
  return { data: await $(), extension: "mp4", fellBack: !0 };
}
async function bt(t, e, a, n, c, r = "first", o = !1, i = !1) {
  const u = [],
    l = [],
    s = [];
  for (let m = 0; m < e.length; m++) {
    const g = (e[m].name.match(/\.([a-z0-9]+)$/i)?.[1] ?? "mp4").toLowerCase(),
      f = `in${m}.${g}`;
    (c?.(`Reading clip ${m + 1} of ${e.length}...`),
      await t.writeFile(f, await y(e[m])));
    const w = await M(t, f);
    if (!w.hasVideo)
      throw new Error(
        `"${e[m].name}" has no video in it, so it can't be merged.`,
      );
    (u.push(w), s.push(f), l.push("-i", f));
  }
  const d = wt(u, r, o, i ? dt : 0),
    p = d.totalSeconds || void 0,
    h = d.withAudio ? u.filter((m) => !m.hasAudio).length : 0;
  return (
    d.mode === "copy"
      ? (c?.("Joining clips without re-encoding..."),
        await t.writeFile(
          "list.txt",
          s.map((m) => `file '${m}'`).join(`
`),
        ),
        await x(
          t,
          [
            "-f",
            "concat",
            "-safe",
            "0",
            "-i",
            "list.txt",
            "-c",
            "copy",
            "-movflags",
            "+faststart",
            "output.mp4",
          ],
          a,
          n,
          p,
        ))
      : (c?.(`Merging clips (matching them to ${d.width} x ${d.height})...`),
        await x(t, [...l, ...$t(d)], a, n, p)),
    {
      data: await t.readFile("output.mp4"),
      mode: d.mode,
      noSound: !d.withAudio,
      silentClips: h,
      width: d.width,
      height: d.height,
      fitted: d.fitted,
      fps: d.fps,
      fpsMismatch: d.fpsMismatch,
      crossfade: d.crossfade,
    }
  );
}
async function St(t, e, a, n, c, r = {}) {
  const {
      startSeconds: o = 0,
      lengthSeconds: i,
      width: u = 480,
      fps: l = 12,
      speed: s = 1,
      playOnce: d = !1,
    } = r,
    p = [...(o > 0 ? ["-ss", String(o)] : []), ...(i ? ["-t", String(i)] : [])],
    h = `${s !== 1 ? `setpts=PTS/${s},` : ""}fps=${l},scale='min(${u},iw)':-2:flags=lanczos`;
  return (
    c?.("Generating color palette..."),
    await x(
      t,
      [...p, "-i", e, "-vf", `${h},palettegen=stats_mode=diff`, "palette.png"],
      ($) => a($ * 0.3),
      n,
    ),
    c?.("Encoding GIF..."),
    await x(
      t,
      [
        ...p,
        "-i",
        e,
        "-i",
        "palette.png",
        "-lavfi",
        `${h}[x];[x][1:v]paletteuse=dither=bayer:bayer_scale=4`,
        ...(d ? ["-loop", "-1"] : []),
        "output.gif",
      ],
      ($) => a(0.3 + $ * 0.7),
      n,
    ),
    t.readFile("output.gif")
  );
}
async function Ft(t, e, a, n, c, r, o = j) {
  const i = N(n),
    u = i.map((s) => s.text).join(`
`);
  if (I(u))
    throw new Error(
      "Chinese, Japanese and Korean subtitles aren't supported yet: their fonts are too large to bundle. Hindi, Tamil, Telugu, Bengali, Arabic, Thai and other scripts are supported.",
    );
  const l = await M(t, e);
  if (!l.hasVideo)
    throw new Error("This file has no picture to put subtitles on.");
  if (tt(i)) {
    const { strips: s, blank: d, geo: p } = await it(i, l.width, l.height, o);
    await t.writeFile("blank.png", d);
    for (let h = 0; h < s.length; h++) await t.writeFile(`strip${h}.png`, s[h]);
    return (
      await t.writeFile("strips.txt", rt(i)),
      await x(
        t,
        [
          "-i",
          e,
          "-f",
          "concat",
          "-safe",
          "0",
          "-i",
          "strips.txt",
          "-filter_complex",
          `[1:v]format=rgba[s];[0:v][s]overlay=0:${p.y}:eof_action=pass:format=auto,format=yuv420p[v]`,
          "-map",
          "[v]",
          "-map",
          "0:a?",
          "-c:v",
          "libx264",
          "-preset",
          "veryfast",
          "-crf",
          "23",
          "-c:a",
          "aac",
          "-b:a",
          "128k",
          "-movflags",
          "+faststart",
          a,
        ],
        c,
        r,
      ),
      t.readFile(a)
    );
  }
  (await t.writeFile("subs.ass", gt(i, l.width, l.height, o)),
    await t.writeFile(
      "Roboto-Regular.ttf",
      await y("/fonts/Roboto-Regular.ttf"),
    ));
  for (const s of T(u)) await t.writeFile(s.file, await y(B(s.file)));
  return (
    await x(
      t,
      [
        "-i",
        e,
        "-vf",
        "subtitles=subs.ass:fontsdir=.",
        "-c:v",
        "libx264",
        "-preset",
        "veryfast",
        "-crf",
        "23",
        "-pix_fmt",
        "yuv420p",
        "-c:a",
        "aac",
        "-b:a",
        "128k",
        "-movflags",
        "+faststart",
        a,
      ],
      c,
      r,
    ),
    t.readFile(a)
  );
}
const C = (t) => {
    const e = Math.round(t * 1e3),
      a = (n, c = 2) => String(n).padStart(c, "0");
    return `${a(Math.floor(e / 36e5))}:${a(Math.floor(e / 6e4) % 60)}:${a(Math.floor(e / 1e3) % 60)},${a(e % 1e3, 3)}`;
  },
  Mt = (t) =>
    ["h264", "hevc", "mpeg4"].includes(t.vcodec) &&
    (!t.hasAudio || ["aac", "mp3", "ac3"].includes(t.acodec));
async function yt(t, e, a, n, c, r) {
  const i = N(n).map(
    (u, l) => `${l + 1}
${C(u.start)} --> ${C(u.end)}
${u.text}
`,
  ).join(`
`);
  return (
    await t.writeFile("soft.srt", i),
    await x(
      t,
      [
        "-i",
        e,
        "-i",
        "soft.srt",
        "-map",
        "0:v",
        "-map",
        "0:a?",
        "-map",
        "1:0",
        "-c:v",
        "copy",
        "-c:a",
        "copy",
        "-c:s",
        "mov_text",
        "-metadata:s:s:0",
        "language=eng",
        "-movflags",
        "+faststart",
        a,
      ],
      c,
      r,
    ),
    t.readFile(a)
  );
}
function Tt(t) {
  const e = document.createElement("canvas");
  return (
    (e.width = t.videoWidth),
    (e.height = t.videoHeight),
    e.getContext("2d").drawImage(t, 0, 0),
    e.toDataURL("image/png")
  );
}
async function Et(t, e, a) {
  return (
    await t.exec([
      "-ss",
      String(Math.max(0, a)),
      "-i",
      e,
      "-frames:v",
      "1",
      "-y",
      "frame.png",
    ]),
    t.readFile("frame.png")
  );
}
const Ct = Object.freeze(
  Object.defineProperty(
    {
      __proto__: null,
      FREE_MAX_BYTES: H,
      FirewallBlockedError: W,
      PRO_MAX_BYTES: U,
      UserCancelledError: P,
      addSoftSubtitles: yt,
      burnSubtitles: Ft,
      canCopyIntoMp4: Mt,
      captureVideoFrame: Tt,
      checkFileSize: Y,
      compressVideoToTarget: z,
      convertVideoFormat: vt,
      execWithProgress: x,
      fetchFile: y,
      ffmpegOutputToBlob: G,
      formatBytes: X,
      frameWithFfmpeg: Et,
      getMaxFileSize: q,
      getVideoDurationSeconds: J,
      loadFFmpeg: Q,
      mergeVideos: bt,
      resetFFmpegEngine: K,
      stopProcessing: Z,
      trimVideoSegment: xt,
      videoToGif: St,
    },
    Symbol.toStringTag,
    { value: "Module" },
  ),
);
export {
  Rt as C,
  j as D,
  yt as a,
  Ft as b,
  Mt as c,
  vt as d,
  dt as e,
  Et as f,
  xt as g,
  bt as m,
  Ct as o,
  N as p,
  Ot as t,
  St as v,
};
//# sourceMappingURL=operations-P8Ty5WBe.js.map
