const o = (e) => {
    const t = e.trim().split(":");
    return t.length === 0 ||
      t.length > 3 ||
      t.some((r) => r === "" || isNaN(Number(r)))
      ? NaN
      : t.reduce((r, a) => r * 60 + Number(a), 0);
  },
  s = (e) => {
    const t = Math.floor(e / 3600),
      r = Math.floor((e % 3600) / 60),
      a = (e % 60).toFixed(1).padStart(4, "0");
    return t > 0 ? `${t}:${String(r).padStart(2, "0")}:${a}` : `${r}:${a}`;
  };
export { s as f, o as p };
//# sourceMappingURL=timeParse-8r2SbiBd.js.map
