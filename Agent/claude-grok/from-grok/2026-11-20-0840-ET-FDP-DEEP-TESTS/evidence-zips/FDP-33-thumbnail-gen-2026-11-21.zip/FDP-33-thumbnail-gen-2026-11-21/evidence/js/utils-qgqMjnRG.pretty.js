import {
  getMediaDurationSeconds as _,
  execWithProgress as w,
  ffmpegOutputToBlob as K,
} from "./ffmpegEngine-DH91Xnxx.js";
const S = [
  "mp4",
  "m4v",
  "mov",
  "webm",
  "mkv",
  "avi",
  "wmv",
  "flv",
  "3gp",
  "3g2",
  "mpg",
  "mpeg",
  "ogv",
  "ts",
  "mts",
  "m2ts",
  "mxf",
];
function D(t) {
  if ((t.type || "").startsWith("video/")) return !0;
  if (
    t.type &&
    ![
      "application/octet-stream",
      "application/mp4",
      "application/x-matroska",
    ].includes(t.type)
  )
    return !1;
  const e = (t.name.toLowerCase().match(/\.([^./\\]+)$/) ?? [])[1] ?? "";
  return S.includes(e);
}
const f = 128,
  r = 100;
function A(t, e) {
  if (!e) return t;
  const a = Math.min(e.end ?? t, t) - e.start;
  if (!(a > 0))
    throw new Error(
      "The Start time is at or after the end of the video. Choose an earlier Start or a later End.",
    );
  return a;
}
function I(t, e, s, a) {
  const c = a <= 1 ? 0.97 : 0.93;
  return Math.max(r, (t * (s * c)) / e);
}
const $ = 3;
async function V(t, e, s, a, c, b, d, n) {
  const m = A(await _(t, e), n),
    v =
      n && (n.start > 0 || n.end !== void 0)
        ? ["-ss", String(n.start), "-t", String(m)]
        : [],
    h = d ? ["-vf", `scale=-2:'min(${d},ih)':flags=fast_bilinear`] : [],
    T = (a * 8) / 1e3 / m;
  let u = Math.max(r, Math.round(T - f)) * 0.94,
    l = 0;
  const g = [
    [0, 0.6],
    [0.6, 0.2],
    [0.8, 0.2],
  ];
  for (let o = 1; o <= $; o++) {
    const [x, M] = g[o - 1],
      i = Math.max(r, Math.round(u));
    if (
      (await w(
        t,
        [
          ...v,
          "-i",
          e,
          "-vsync",
          "cfr",
          ...h,
          "-c:v",
          "libx264",
          "-preset",
          "superfast",
          "-b:v",
          `${i}k`,
          "-maxrate",
          `${Math.round(i * 1.1)}k`,
          "-bufsize",
          `${i * 2}k`,
          "-pix_fmt",
          "yuv420p",
          "-c:a",
          "aac",
          "-b:a",
          `${f}k`,
          "-movflags",
          "+faststart",
          s,
        ],
        (E) => c(x + E * M, o),
        b,
        v.length ? m : void 0,
      ),
      (l = (await t.readFile(s)).length),
      l <= a || i <= r)
    )
      break;
    u = I(i, l, a, o);
  }
  const k = await t.readFile(s),
    p = K(k, "video/mp4");
  return { blob: p, size: p.size, metTarget: p.size <= a, targetBytes: a };
}
export { V as c, D as l };
//# sourceMappingURL=utils-qgqMjnRG.js.map
