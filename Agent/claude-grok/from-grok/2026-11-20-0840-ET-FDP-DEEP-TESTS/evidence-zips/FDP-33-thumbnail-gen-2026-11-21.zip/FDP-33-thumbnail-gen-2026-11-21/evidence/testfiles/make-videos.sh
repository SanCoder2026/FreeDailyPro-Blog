#!/bin/sh
# Recreates the synthetic test videos (not shipped). Needs ffmpeg with libx264, libvpx-vp9, libx265, aac.
ffmpeg -y -f lavfi -i testsrc2=size=1920x1080:rate=30:duration=10 -f lavfi -i sine=frequency=440:duration=10 -c:v libx264 -pix_fmt yuv420p -c:a aac -shortest V1_1080p_30fps_10s.mp4
ffmpeg -y -f lavfi -i testsrc2=size=1080x1920:rate=30:duration=6 -c:v libx264 -pix_fmt yuv420p V2_portrait_1080x1920.mp4
ffmpeg -y -f lavfi -i testsrc2=size=1280x720:rate=25:duration=5 -c:v libvpx-vp9 -b:v 500k V3_720p.webm
ffmpeg -y -f lavfi -i testsrc2=size=1280x720:rate=30:duration=4 -c:v libx265 -tag:v hvc1 -pix_fmt yuv420p V4_hevc.mp4
ffmpeg -y -f lavfi -i color=black:size=1280x720:rate=30:duration=4 -c:v libx264 -pix_fmt yuv420p V5_black.mp4
echo "not a video" > X1_notvideo.txt; cp X1_notvideo.txt X2_fake.mp4
