// thumbnail-gen: dump the blog post text and its links/dates. Read-only.
const { chromium } = require('playwright'); const fs = require('fs');
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage();
 for (const [u, f] of [['https://www.freedailypro.com/blog/thumbnail-gen', 'blog.txt']]) {
  await p.goto(u, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000);
  const t = await p.evaluate(() => (document.querySelector('article') || document.querySelector('main')).innerText);
  const links = await p.evaluate(() => [...(document.querySelector('article') || document.querySelector('main')).querySelectorAll('a')].map(a => a.innerText.trim().slice(0, 50) + ' -> ' + a.href));
  fs.writeFileSync('/workspace/deep/33-thumbnail-gen/curl/' + f, t + '\n\n--- links\n' + links.join('\n') + '\n\n--- title: ' + await p.title());
  await p.screenshot({ path: '/workspace/deep/33-thumbnail-gen/live/blog-top.png' }); }
 await b.close(); })();
