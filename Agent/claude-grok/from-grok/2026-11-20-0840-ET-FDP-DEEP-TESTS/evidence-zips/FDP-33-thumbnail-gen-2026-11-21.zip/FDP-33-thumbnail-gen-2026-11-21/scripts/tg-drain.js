// thumbnail-gen: one fresh context; capture 2 frames; press the per-image Download until the cap dialog appears (max 11), then at 0: ZIP, Capture, Suggest,
// and the cap dialog -> Buy Day Pass -> email prompt (types nothing). Records usageToday after each step and after reload. Guest.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/33-thumbnail-gen/live/'; const TF = '/workspace/deep/33-thumbnail-gen/testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await c.newPage(); p.setDefaultTimeout(15000);
 await p.goto('https://www.freedailypro.com/tool/thumbnail-gen', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000);
 const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
 const strip = () => p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]);
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 const R = { t: now(), start: await used(), stripStart: await strip(), steps: [] };
 await p.locator('main input[type=file]').first().setInputFiles(TF + 'V3_720p.webm'); await p.waitForTimeout(2500);
 for (const t of ['0:01', '0:03']) { await p.locator('#thumb-time').fill(t); await p.locator('#thumb-time').press('Enter'); await p.waitForTimeout(500); await p.getByRole('button', { name: 'Capture Thumbnail' }).click(); await p.waitForTimeout(1500); }
 const dlBtn = p.locator('[data-testid=thumb-gallery]').getByRole('button', { name: /^Download$/ }).first();
 for (let i = 1; i <= 11; i++) { const dl = p.waitForEvent('download', { timeout: 5000 }).catch(() => null); await dlBtn.click(); const d = await dl; await p.waitForTimeout(1500);
   const st = { i, a: 'Download', download: d ? d.suggestedFilename() : null, used: await used(), strip: await strip(), dialog: await dialog() }; R.steps.push(st); console.log(JSON.stringify(st).slice(0, 300));
   if (st.dialog) { await p.screenshot({ path: OUT + 'cap-dialog.png' }); const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.dayPass = { dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); } await esc(); break; } }
 // at 0
 const at0 = async (a, fn) => { const dl = p.waitForEvent('download', { timeout: 5000 }).catch(() => null); await fn(); const d = await dl; await p.waitForTimeout(1500); const st = { a, download: d ? d.suggestedFilename() : null, used: await used(), dialog: await dialog(), gallery: await p.locator('[data-testid=thumb-gallery] img').count() }; if (d) { const f = OUT + 'downloads/at0-' + d.suggestedFilename(); await d.saveAs(f); st.bytes = fs.statSync(f).size; } R.steps.push(st); console.log(JSON.stringify(st).slice(0, 300)); await esc(); };
 await at0('Capture at 0', () => p.getByRole('button', { name: 'Capture Thumbnail' }).click());
 await at0('ZIP at 0', () => p.getByRole('button', { name: /Download all as ZIP/ }).click());
 await at0('Download at 0 (again)', () => dlBtn.click());
 await at0('Suggest at 0', () => p.getByRole('button', { name: 'Suggest frames' }).click());
 await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); R.afterReload = await used(); R.stripAfter = await strip();
 R.t2 = now(); fs.writeFileSync(OUT + 'drain.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify({ start: R.start, stripStart: R.stripStart, dayPass: R.dayPass, afterReload: R.afterReload, stripAfter: R.stripAfter }, null, 1)); await b.close(); })();
