// thumbnail-gen: at the starting count, per-image Download (cap dialog -> Buy Day Pass -> email prompt, types nothing), Download all as ZIP,
// Save to Google Drive / my cloud storage (stop at the first dialog or sign-in page), Quick Buy day/monthly (stop at email prompt / Stripe), keyboard reach of the drop zone. Guest.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/33-thumbnail-gen/live/'; const TF = '/workspace/deep/33-thumbnail-gen/testfiles/'; const URL = 'https://www.freedailypro.com/tool/thumbnail-gen';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').slice(0, 160);
(async () => { const b = await chromium.launch(); const R = { t: now() };
 const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await c.newPage(); p.setDefaultTimeout(15000);
 await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000);
 const used = async () => JSON.parse(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')) || '{}').usageToday;
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 R.start = await used(); R.strip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]);
 // keyboard reach of the drop zone
 let chooser = false; p.on('filechooser', () => { chooser = true; }); const seq = [];
 for (let i = 0; i < 40; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('role') || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50).replace(/\n/g, ' '); }); seq.push(a); if (/Drop a video/i.test(a)) { await p.keyboard.press('Enter'); await p.waitForTimeout(1200); seq.push('ENTER -> chooser=' + chooser); break; } }
 R.kbd = { tabs: seq.length, last: seq.slice(-3), chooser };
 await p.locator('main input[type=file]').first().setInputFiles(TF + 'V3_720p.webm'); await p.waitForTimeout(2500);
 R.afterUpload = await used();
 const cap = async (size) => { await p.locator('main select').first().selectOption(size); await p.locator('#thumb-time').fill('0:02'); await p.locator('#thumb-time').press('Enter'); await p.waitForTimeout(600); await p.getByRole('button', { name: 'Capture Thumbnail' }).click(); await p.waitForTimeout(1500); };
 await cap('yt'); await cap('orig'); R.afterCapture = await used();
 // save the gallery blob of image 1 (unmarked preview) for comparison
 const g = await p.evaluate(async () => { const im = document.querySelector('[data-testid=thumb-gallery] img'); const bl = await (await fetch(im.src)).blob(); const a = new Uint8Array(await bl.arrayBuffer()); let s = ''; for (let i = 0; i < a.length; i += 0x8000) s += String.fromCharCode(...a.subarray(i, i + 0x8000)); return btoa(s); });
 fs.writeFileSync(OUT + 'downloads/gate-gallery-preview-1.png', Buffer.from(g, 'base64'));
 R.resultText = await p.evaluate(() => { const t = document.querySelector('[data-testid=tool-area]').innerText; const i = t.indexOf('Download all'); return t.slice(i, i + 700); });
 const act = async (name, loc) => { const r = { before: await used() }; if (!(await loc.count())) { r.missing = true; return r; }
   const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); const dl = p.waitForEvent('download', { timeout: 6000 }).catch(() => null); const url0 = p.url(); await loc.first().click(); const [pg, d] = await Promise.all([pop, dl]); await p.waitForTimeout(2000);
   r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null;
   if (d) { r.download = d.suggestedFilename(); const f = OUT + 'downloads/gate-' + name + '-' + d.suggestedFilename(); await d.saveAs(f); r.file = f; r.bytes = fs.statSync(f).size; }
   if (pg) { await pg.waitForLoadState('domcontentloaded').catch(() => {}); r.popup = red(pg.url()); r.popupTitle = await pg.title().catch(() => null); await pg.close(); }
   if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + '.png' });
   if (r.dialog && /Day Pass/.test(r.dialog) && !R.dayPassFromCap) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.dayPassFromCap = { from: name, dialog: await dialog(), emailField: await p.locator('input[type=email]').count(), url: red(p.url()) }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); } }
   await esc(); if (r.url) { await p.goBack().catch(() => {}); await p.waitForTimeout(2500); } return r; };
 const gal = p.locator('[data-testid=thumb-gallery]');
 R.download = await act('download', gal.getByRole('button', { name: /^Download$/ }));
 R.zip = await act('zip', p.getByRole('button', { name: /Download all as ZIP/ }));
 R.drive = await act('drive', gal.getByRole('button', { name: /Save to Google Drive/ }));
 R.cloud = await act('cloud', gal.getByRole('button', { name: /Save to my cloud storage/ }));
 await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); R.afterReload = await used();
 // Quick Buy (strip): day, then monthly; stop at the first email prompt / Stripe page
 const qb = p.getByRole('button', { name: 'Quick Buy' }); R.quickBuyCount = await qb.count();
 if (R.quickBuyCount) { const u0 = p.url(); await qb.first().click(); await p.waitForTimeout(3000); R.qbDay = { url: p.url() !== u0 ? red(p.url()) : null, dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await esc();
   if (p.url() !== u0) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); }
   await p.getByRole('button', { name: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); R.qbMonth = { url: red(p.url()), dialog: await dialog(), title: await p.title(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' }); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
