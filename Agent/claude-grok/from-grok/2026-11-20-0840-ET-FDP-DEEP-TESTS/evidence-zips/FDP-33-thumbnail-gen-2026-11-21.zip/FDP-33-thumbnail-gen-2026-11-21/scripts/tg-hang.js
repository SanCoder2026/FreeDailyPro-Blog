// thumbnail-gen: a text file renamed .mp4 -> fallback -> Capture; watch the button for 180 s. Guest.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage();
  await p.goto('https://www.freedailypro.com/tool/thumbnail-gen', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000);
  await p.locator('main input[type=file]').first().setInputFiles('/workspace/deep/33-thumbnail-gen/testfiles/X2_fake.mp4'); await p.waitForTimeout(2500);
  await p.locator('#thumb-time').fill('0:01'); await p.getByRole('button', { name: 'Capture Thumbnail' }).click(); const R = { t: now(), obs: [] };
  for (const s of [1,2,3,4,5,6,8,10,15,20]) { await p.waitForTimeout((s - (R.obs.at(-1)?.s || 0)) * 1000); R.obs.push({ s, button: await p.locator('main button').filter({ hasText: /Capture Thumbnail|Reading frame/ }).innerText(), toasts: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText)) }); console.log(JSON.stringify(R.obs.at(-1))); }
  await p.screenshot({ path: '/workspace/deep/33-thumbnail-gen/live/fake-mp4-hang.png' }); R.t2 = now(); fs.writeFileSync('/workspace/deep/33-thumbnail-gen/live/fake-mp4-hang.json', JSON.stringify(R, null, 1)); await b.close(); })();
