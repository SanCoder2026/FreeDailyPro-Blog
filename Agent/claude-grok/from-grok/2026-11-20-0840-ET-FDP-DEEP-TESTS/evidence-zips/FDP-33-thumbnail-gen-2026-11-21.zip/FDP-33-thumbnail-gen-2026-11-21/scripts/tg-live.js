// thumbnail-gen: upload synthetic videos, seek, capture at each size/shape/title/JPG, suggest frames, fallback path, bad files; reads captured images from the gallery blobs (no Download clicks). Request scan for uploads. Guest.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/33-thumbnail-gen/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const which = process.argv[2] || 'V1_1080p_30fps_10s.mp4';
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(20000);
  const reqs = []; p.on('request', r => { const d = r.postDataBuffer(); reqs.push({ m: r.method(), u: r.url().slice(0, 160), n: d ? d.length : 0 }); }); const errs = []; p.on('pageerror', e => errs.push(String(e)));
  const toasts = []; const grabToasts = async () => { const t = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim())); t.forEach(x => { if (!toasts.includes(x)) toasts.push(x); }); return t; };
  await p.goto('https://www.freedailypro.com/tool/thumbnail-gen', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000);
  const R = { t: now(), file: which, steps: [] };
  await p.locator('main input[type=file]').first().setInputFiles(TF + which); await p.waitForTimeout(3000);
  R.afterUpload = await p.evaluate(() => { const v = document.querySelector('main video'); return { video: !!v, w: v?.videoWidth, h: v?.videoHeight, dur: v?.duration, err: v?.error?.code ?? null, mainText: document.querySelector('[data-testid=tool-area]')?.innerText.slice(0, 600) }; });
  R.toastsUpload = await grabToasts(); console.log('upload', JSON.stringify(R.afterUpload).slice(0, 400), R.toastsUpload);
  await p.screenshot({ path: OUT + 'upload-' + which.split('.')[0] + '.png' });
  const time = p.locator('#thumb-time'); const sel = p.locator('main select');
  const capture = async (label, opts) => {
    if (opts.size !== undefined) await sel.first().selectOption(opts.size); await p.waitForTimeout(200);
    if (opts.shape) await sel.nth(1).selectOption(opts.shape).catch(() => {});
    if (opts.title !== undefined) { const ti = p.getByPlaceholder('Text on the image'); if (await ti.count()) await ti.first().fill(opts.title); }
    if (opts.font) await p.getByLabel('Font').selectOption(opts.font).catch(e => console.log('font', String(e).slice(0, 80)));
    if (opts.jpg !== undefined) { const cb = p.getByLabel(/Save as JPG/); if (await cb.count()) { if (opts.jpg) await cb.check(); else await cb.uncheck(); } }
    if (opts.t) { await time.fill(opts.t); await time.press('Enter'); await p.waitForTimeout(800); }
    if (opts.step) { await p.getByRole('button', { name: opts.step, exact: true }).click(); await p.waitForTimeout(500); }
    const n0 = await p.locator('[data-testid=thumb-gallery] img').count(); const t0 = Date.now();
    await p.getByRole('button', { name: /Capture Thumbnail|Reading frame/ }).click();
    await p.waitForFunction(n => document.querySelectorAll('[data-testid=thumb-gallery] img').length > n, n0, { timeout: 90000 }).catch(() => {});
    await p.waitForTimeout(500); const tst = await grabToasts();
    const info = await p.evaluate(async () => { const imgs = [...document.querySelectorAll('[data-testid=thumb-gallery] img')]; const im = imgs.at(-1); if (!im) return null; const blob = await (await fetch(im.src)).blob(); const buf = new Uint8Array(await blob.arrayBuffer()); let s = ''; for (let i = 0; i < buf.length; i += 0x8000) s += String.fromCharCode(...buf.subarray(i, i + 0x8000)); return { name: im.parentElement.querySelector('p')?.innerText, alt: im.alt, type: blob.type, size: blob.size, w: im.naturalWidth, h: im.naturalHeight, b64: btoa(s) }; });
    const row = { label, opts, ms: Date.now() - t0, toast: tst.slice(-1)[0] || null, timeBox: await time.inputValue().catch(() => null) };
    if (info) { const f = OUT + 'downloads/' + which.split('.')[0] + '__' + label + '.' + (info.type.includes('jpeg') ? 'jpg' : 'png'); fs.writeFileSync(f, Buffer.from(info.b64, 'base64')); delete info.b64; Object.assign(row, info, { saved: f }); }
    R.steps.push(row); console.log(label, JSON.stringify(row).slice(0, 300));
  };
  if (R.afterUpload.video || R.afterUpload.mainText) {
    const fallback = /can't play this video/.test(R.afterUpload.mainText || '');
    R.fallback = fallback;
    await capture('orig_t3.5', { t: '0:03.5', size: 'orig' }).catch(e => R.steps.push({ label: 'orig_t3.5', err: String(e).slice(0, 200) }));
    if (!fallback && process.argv[3] !== 'short') {
      await capture('plus1frame', { step: '+1 frame' }).catch(e => R.steps.push({ label: 'plus1frame', err: String(e).slice(0, 200) }));
      await capture('yt_fill', { size: 'yt', shape: 'fill' });
      await capture('yt4k_fill', { size: 'yt4k', shape: 'fill' });
      await capture('short4k_fill', { size: 'short4k', shape: 'fill' });
      await capture('vert_fit', { size: 'vert', shape: 'fit' });
      await capture('sq_fill_title', { size: 'sq', shape: 'fill', title: 'How I Built This in 10 Minutes — नमस्ते 🚀 Ünïcödé', font: 'impact' });
      await capture('yt_title_long', { size: 'yt', shape: 'fill', title: 'This is a very long title that should wrap onto several lines without running off the edge of the image at all ever', font: 'sans' });
      await capture('yt4k_jpg', { size: 'yt4k', shape: 'fill', title: '', jpg: true });
      await capture('yt_jpg', { size: 'yt', jpg: true });
      await capture('t_beyond_end', { t: '0:59', size: 'orig', jpg: false });
      await capture('t_bad', { t: 'abc' }).catch(() => {});
      await p.screenshot({ path: OUT + 'gallery-' + which.split('.')[0] + '.png', fullPage: false });
      // suggest frames
      const t0 = Date.now(); await p.getByRole('button', { name: 'Suggest frames' }).click(); await p.waitForFunction(() => !/Looking\.\.\./.test(document.body.innerText), null, { timeout: 60000 }).catch(() => {});
      await p.waitForTimeout(800); R.suggest = { ms: Date.now() - t0, toasts: await grabToasts(), text: await p.evaluate(() => { const m = document.querySelector('[data-testid=tool-area]').innerText; const i = m.indexOf('Suggest'); return m.slice(i, i + 300); }), imgs: await p.locator('main img[src^="data:image/jpeg"]').count() };
      await p.screenshot({ path: OUT + 'suggest-' + which.split('.')[0] + '.png' });
      R.dlNote = await p.evaluate(() => { const m = document.querySelector('[data-testid=tool-area]').innerText; const i = m.indexOf('This download'); return i < 0 ? null : m.slice(i, i + 300); });
      R.zipButton = await p.getByRole('button', { name: /Download all as ZIP/ }).innerText().catch(() => null);
      R.downloadButtons = await p.locator('[data-testid=thumb-gallery]').getByRole('button', { name: /Download/ }).count().catch(() => 0);
    }
  }
  R.toasts = toasts; R.errs = errs; R.bigPosts = reqs.filter(r => r.n > 50000 || (/upload|storage|r2|s3/i.test(r.u) && r.m !== 'GET')); R.hosts = [...new Set(reqs.map(r => r.u.split('/')[2]))]; R.ffmpegReqs = reqs.filter(r => /ffmpeg|wasm|core/i.test(r.u)).map(r => r.u);
  R.t2 = now(); fs.writeFileSync(OUT + 'cases-' + which.split('.')[0] + '.json', JSON.stringify(R, null, 1));
  console.log(JSON.stringify({ fallback: R.fallback, suggest: R.suggest, zip: R.zipButton, dl: R.downloadButtons, toasts, errs, bigPosts: R.bigPosts, ff: R.ffmpegReqs }, null, 1)); await b.close();
})();
