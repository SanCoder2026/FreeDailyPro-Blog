const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/jszip.min-CT0ZA6V1.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/jszip.min-C-FLQHAz.js",
      "assets/_commonjs-dynamic-modules-TDtrdbi3.js",
    ]),
) => i.map((i) => d[i]);
import {
  e as ze,
  I as $e,
  B as E,
  f as U,
  ap as Ge,
} from "./index-B1CTyGtY.js";
import { r as f, j as t } from "./vendor-react-D01g8YgM.js";
import {
  b as Be,
  F as ue,
  P as fe,
  d as Te,
  p as Ue,
  a6 as De,
  T as le,
  o as Me,
  q as Oe,
  r as ce,
  R as Re,
  D as Je,
} from "./ToolPage-DwLoDncN.js";
import { T as me } from "./ToolInfoSection-C0i6Zbwo.js";
import { a as Ze, r as de, d as _e } from "./decode-DrS85i4S.js";
import {
  u as he,
  o as ge,
  f as xe,
  b as we,
  Q as ye,
  c as ve,
  F as je,
  M as be,
  e as We,
  d as Le,
} from "./ConvertOptionsPanel-DhmFQStl.js";
import {
  convertImageDetailed as He,
  convertImageInBrowser as pe,
} from "./convertBrowser-CYvv7SBJ.js";
import {
  parseConvertOptions as ke,
  formatInfo as V,
  parseFormat as Ke,
} from "./convertCore-pdjQ6UTb.js";
import { u as Ve } from "./useConverterPair-rg6H4-hf.js";
import {
  D as oe,
  b as qe,
  f as Fe,
  a as Ce,
  n as Pe,
  c as Qe,
  d as Xe,
  m as Ye,
  e as et,
} from "./convertForm-Bkb1Ezx2.js";
import { J as tt } from "./jszip.min-CT0ZA6V1.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./select-ic5yaeGw.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./slider-nIHsxb_2.js";
import "./checkbox-Ml1pfDb3.js";
import "./jpegDpi-c8DPdZxl.js";
import "./operations-YdcesJcx.js";
import "./utils-1EQcVBdK.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
const q = (e, a, r) =>
    Array.from(e.subarray(a, a + r), (c) => String.fromCharCode(c)).join(""),
  T = (e, a) => e[a] | (e[a + 1] << 8);
function Ie(e) {
  const a = q(e, 0, 6);
  return a === "GIF87a" || a === "GIF89a";
}
function re(e, a) {
  for (; a < e.length && e[a] !== 0;) a += e[a] + 1;
  return a + 1;
}
function st(e, a) {
  if (!Ie(e)) throw new Error("This is not a GIF file.");
  const r = T(e, 6),
    c = T(e, 8),
    o = e[10],
    d = e[11];
  let s = 13,
    g = null;
  if (o & 128) {
    const p = 3 * (1 << ((o & 7) + 1));
    ((g = e.slice(s, s + p)), (s += p));
  }
  const h = [];
  let x = 0,
    n = { delay: 100, transparent: -1, disposal: 0 };
  for (; s < e.length;) {
    const p = e[s++];
    if (p === 59) break;
    if (p === 33) {
      if (e[s++] === 249 && e[s] >= 4) {
        const m = e[s + 1];
        n = {
          disposal: (m >> 2) & 7,
          transparent: m & 1 ? e[s + 4] : -1,
          delay: T(e, s + 2) * 10,
        };
      }
      s = re(e, s);
    } else if (p === 44) {
      x++;
      const j = T(e, s),
        m = T(e, s + 2),
        F = T(e, s + 4),
        w = T(e, s + 6),
        v = e[s + 8];
      s += 9;
      let b = null;
      if (v & 128) {
        const C = 3 * (1 << ((v & 7) + 1));
        ((b = e.slice(s, s + C)), (s += C));
      }
      const l = e[s++],
        N = [];
      let u = 0;
      for (; s < e.length && e[s] !== 0;)
        (N.push(e.subarray(s + 1, s + 1 + e[s])), (u += e[s]), (s += e[s] + 1));
      if ((s++, h.length < a)) {
        const C = new Uint8Array(u);
        let $ = 0;
        for (const z of N) (C.set(z, $), ($ += z.length));
        h.push({
          left: j,
          top: m,
          w: F,
          h: w,
          interlaced: !!(v & 64),
          palette: b,
          minCode: l,
          data: C,
          delayMs: n.delay,
          transparent: n.transparent,
          disposal: n.disposal,
        });
      }
      n = { delay: 100, transparent: -1, disposal: 0 };
    } else break;
  }
  return { width: r, height: c, gct: g, bg: d, frames: h, total: x };
}
function at(e) {
  if (!Ie(e)) return 0;
  let a = 13;
  const r = e[10];
  r & 128 && (a += 3 * (1 << ((r & 7) + 1)));
  let c = 0;
  for (; a < e.length;) {
    const o = e[a++];
    if (o === 59) break;
    if (o === 33) (a++, (a = re(e, a)));
    else if (o === 44) {
      c++;
      const d = e[a + 8];
      ((a += 9),
        d & 128 && (a += 3 * (1 << ((d & 7) + 1))),
        a++,
        (a = re(e, a)));
    } else break;
  }
  return c;
}
function nt(e, a, r) {
  const c = new Uint8Array(r),
    o = 1 << a,
    d = o + 1,
    s = new Int16Array(4096),
    g = new Uint8Array(4096),
    h = new Uint8Array(4097);
  let x = a + 1,
    n = (1 << x) - 1,
    p = d + 1,
    j = -1,
    m = 0,
    F = 0,
    w = 0,
    v = 0,
    b = 0;
  for (let l = 0; l < o; l++) g[l] = l;
  for (; b < r;) {
    for (; F < x && v < e.length;) ((w |= e[v++] << F), (F += 8));
    if (F < x) break;
    let l = w & n;
    if (((w >>>= x), (F -= x), l === o)) {
      ((x = a + 1), (n = (1 << x) - 1), (p = d + 1), (j = -1));
      continue;
    }
    if (l === d) break;
    if (j === -1) {
      ((c[b++] = g[l]), (j = l), (m = l));
      continue;
    }
    const N = l;
    let u = 0;
    for (l >= p && ((h[u++] = m), (l = j)); l >= o;)
      ((h[u++] = g[l]), (l = s[l]));
    for (
      m = g[l],
        h[u++] = m,
        p < 4096 &&
          ((s[p] = j),
          (g[p] = m),
          p++,
          (p & n) === 0 && p < 4096 && (x++, (n = (1 << x) - 1))),
        j = N;
      u > 0 && b < r;
    )
      c[b++] = h[--u];
  }
  return c;
}
function ot(e, a, r) {
  const c = new Uint8Array(e.length);
  let o = 0;
  for (const [d, s] of [
    [0, 8],
    [4, 8],
    [2, 4],
    [1, 2],
  ])
    for (let g = d; g < r; g += s)
      (c.set(e.subarray(o * a, (o + 1) * a), g * a), o++);
  return c;
}
function rt(e, a = 1e3) {
  const r = st(e, a),
    { width: c, height: o } = r;
  let d = new Uint8ClampedArray(c * o * 4);
  const s = [];
  let g = 0,
    h = { left: 0, top: 0, w: 0, h: 0 },
    x = null;
  for (const n of r.frames) {
    if (g === 2)
      for (let m = h.top; m < Math.min(o, h.top + h.h); m++)
        d.fill(
          0,
          (m * c + h.left) * 4,
          (m * c + Math.min(c, h.left + h.w)) * 4,
        );
    else g === 3 && x && (d = new Uint8ClampedArray(x));
    x = n.disposal === 3 ? new Uint8ClampedArray(d) : null;
    const p = n.palette ?? r.gct;
    let j = nt(n.data, n.minCode, n.w * n.h);
    if ((n.interlaced && (j = ot(j, n.w, n.h)), p))
      for (let m = 0; m < n.h; m++) {
        const F = n.top + m;
        if (F >= o) break;
        for (let w = 0; w < n.w; w++) {
          const v = n.left + w;
          if (v >= c) break;
          const b = j[m * n.w + w];
          if (b === n.transparent) continue;
          const l = (F * c + v) * 4;
          ((d[l] = p[b * 3]),
            (d[l + 1] = p[b * 3 + 1]),
            (d[l + 2] = p[b * 3 + 2]),
            (d[l + 3] = 255));
        }
      }
    (s.push({
      rgba: new Uint8ClampedArray(d),
      delayMs: n.delayMs <= 10 ? 100 : n.delayMs,
    }),
      (g = n.disposal),
      (h = { left: n.left, top: n.top, w: n.w, h: n.h }));
  }
  return { width: c, height: o, frames: s, truncated: r.total > s.length };
}
function it(e) {
  return e.length < 21 || q(e, 0, 4) !== "RIFF" || q(e, 8, 4) !== "WEBP"
    ? !1
    : q(e, 12, 4) === "VP8X" && (e[20] & 2) !== 0;
}
function lt({ initialFiles: e = [], onExit: a }) {
  const [r, c] = f.useState(e),
    [o, d] = f.useState({ ...oe, format: "jpeg", quality: 80 }),
    [s, g] = f.useState(!1),
    [h, x] = f.useState(0),
    [n, p] = f.useState(""),
    [j, m] = f.useState([]),
    [F, w] = f.useState(""),
    v = f.useRef(!1),
    { logUsageNow: b } = Be(),
    l = he(),
    N = f.useCallback((i) => {
      (d((I) => ({ ...I, ...i })), m([]), w(""));
    }, []),
    u = f.useMemo(() => ke(qe(Fe(o), n)), [o, n]),
    C = ge(o, u.ok ? null : Ce(u.error)),
    $ = !u.ok || !!C || xe(l, o.format),
    z = r.some(
      (i) =>
        /\.(png|webp|gif|svg|avif)$/i.test(i.name) ||
        /^image\/(png|webp|gif|svg\+xml|avif)$/.test(i.type),
    ),
    W = f.useCallback((i) => {
      (c((I) => [...I, ...i]), m([]), w(""));
    }, []),
    Q = () => {
      v.current = !0;
    },
    X = async () => {
      if (r.length === 0 || !u.ok) return;
      const i = u.options;
      if (await b()) {
        ((v.current = !1), g(!0), x(0));
        try {
          const D = new tt(),
            Y = new Set(),
            R = [];
          let P = 0,
            G = 0;
          for (const A of r) {
            if (v.current) break;
            try {
              const { blob: M, width: ee, height: te } = await He(A, i),
                L = Qe(A.name, i.format, Y);
              (D.file(L, M),
                P++,
                R.push({
                  name: L,
                  status: "done",
                  detail: Xe(
                    A.size,
                    M.size,
                    i.format === "ico"
                      ? `sizes ${i.sizes.join(", ")} px`
                      : `${ee} x ${te} px`,
                  ),
                }));
            } catch (M) {
              R.push({
                name: A.name,
                status: "failed",
                detail: M?.message || "could not be read",
              });
            }
            (G++, x((G / r.length) * 100));
          }
          if (
            (m(R),
            w(
              `${r.length} in, ${P} out${P < r.length ? ` (${r.length - P} skipped - see the list)` : ""}`,
            ),
            P > 0)
          ) {
            const A = await D.generateAsync({ type: "blob" });
            Te(A, "bulk-processed-images.zip");
          }
          v.current
            ? U.info(
                `Stopped after ${G} of ${r.length} image(s) — the ones already processed are in the downloaded ZIP`,
              )
            : P === r.length
              ? U.success(`Processed ${P} images! Downloaded as one ZIP.`)
              : U.warning(
                  `${P} of ${r.length} images processed - ${r.length - P} could not be read`,
                );
        } catch (D) {
          U.error(D?.message || "Processing failed");
        } finally {
          (g(!1), x(0));
        }
      }
    };
  return t.jsxs("div", {
    "data-testid": "bulk-panel",
    children: [
      t.jsx(ue, {
        accept: "image/*",
        multiple: !0,
        onFiles: W,
        label: "Drop several images to convert them all",
        description: "One ZIP with every converted image",
        deferUsageLog: !0,
      }),
      r.length > 0 &&
        t.jsxs("div", {
          className: "mt-6 space-y-4",
          children: [
            t.jsxs("p", {
              className: "text-sm font-medium",
              children: [r.length, " image(s) selected"],
            }),
            t.jsx("ul", {
              className:
                "max-h-48 overflow-auto text-xs space-y-1 border rounded-md p-2",
              "data-testid": "bulk-list",
              children: r.map((i, I) =>
                t.jsxs(
                  "li",
                  {
                    className: "flex justify-between gap-2",
                    children: [
                      t.jsx("span", {
                        className: "truncate",
                        children: i.name,
                      }),
                      t.jsxs("span", {
                        className: "text-muted-foreground",
                        children: [(i.size / 1024).toFixed(0), " KB"],
                      }),
                    ],
                  },
                  I,
                ),
              ),
            }),
            t.jsx(we, { form: o, onChange: N, support: l }),
            t.jsx(ye, { form: o, onChange: N, min: 10 }),
            t.jsx(ve, { form: o, onChange: N }),
            t.jsx(je, { form: o, onChange: N, show: Pe(o) && z, many: !0 }),
            t.jsx(be, {
              form: o,
              onChange: N,
              metaHelp:
                "Copied into each new JPEG that came from a JPEG. For every other file this information is removed.",
              sizeExtra: t.jsxs("div", {
                className: "space-y-1 max-w-xs",
                children: [
                  t.jsx(ze, {
                    htmlFor: "bulk-longest",
                    className: "text-xs",
                    children: "Longest side (optional, px)",
                  }),
                  t.jsx($e, {
                    id: "bulk-longest",
                    type: "number",
                    min: "0",
                    placeholder: "keep original size",
                    value: n,
                    onChange: (i) => {
                      (p(i.target.value), m([]), w(""));
                    },
                  }),
                  t.jsx("p", {
                    className: "text-xs text-muted-foreground",
                    children:
                      "Shrinks every picture so its longest side is at most this. Used when width and height are empty.",
                  }),
                ],
              }),
            }),
            C &&
              t.jsx("p", {
                role: "alert",
                className: "text-sm text-destructive",
                children: C,
              }),
            F &&
              t.jsx("p", {
                className: "text-sm font-medium",
                "data-testid": "bulk-summary",
                children: F,
              }),
            j.length > 0 &&
              t.jsx("ul", {
                className:
                  "max-h-48 overflow-auto text-xs space-y-1 border rounded-md p-2",
                "data-testid": "bulk-results",
                children: j.map((i, I) =>
                  t.jsxs(
                    "li",
                    {
                      className: i.status === "failed" ? "text-red-600" : "",
                      children: [
                        i.status === "failed" ? "Skipped" : "Done",
                        ": ",
                        i.name,
                        " - ",
                        i.detail,
                      ],
                    },
                    I,
                  ),
                ),
              }),
            t.jsxs("div", {
              className: "flex gap-3",
              children: [
                s
                  ? t.jsx(fe, {
                      message: "Processing images...",
                      progress: h,
                      onStop: Q,
                    })
                  : t.jsx(E, {
                      onClick: X,
                      disabled: $,
                      children: "Convert all",
                    }),
                t.jsx(E, {
                  variant: "outline",
                  onClick: () => {
                    (c([]), m([]), w(""));
                  },
                  children: "Clear",
                }),
              ],
            }),
          ],
        }),
      a &&
        t.jsx(E, {
          variant: "ghost",
          className: "mt-4",
          onClick: a,
          "data-testid": "bulk-exit",
          children: "Back to one image",
        }),
    ],
  });
}
const ct = new Set([
    "image/png",
    "image/webp",
    "image/gif",
    "image/svg+xml",
    "image/avif",
  ]),
  mt = (e) => et(e.type, _e(e)),
  _ = 500,
  O = {
    what: "Converts an image between PNG, JPEG, WebP, AVIF, GIF, BMP, ICO and TIFF, and reads HEIC (iPhone), SVG and animated GIF too. Different websites, print shops, programs and operating systems expect different formats, so the same picture often has to exist in more than one. It can also resize the picture, turn or flip it, make it black and white, set a print resolution, and remove or keep camera and location data, all in the same step. Drop several pictures at once to give them all the same settings and get one ZIP file back.",
    how: 'Upload your image, choose the format you want, change any option you need, and press Convert. Converting a picture with a transparent background to JPEG or 24-bit BMP shows a fill colour picker first, since those formats cannot be see-through; the transparent areas get the colour you pick (white by default) rather than turning black. Icons (ICO) can hold several sizes in one file: tick the sizes you want. For many pictures, drop them all together (or press "Convert several images at once"), choose the format, quality and any size limit once, and press Convert all: every converted image comes back inside a single ZIP, with a list of anything that could not be read.',
    tip: "Use PNG for logos, icons and screenshots, JPEG for photos where file size matters, WebP when the destination accepts it and a small file is the priority, and ICO for a website favicon. A transparent picture saved as JPEG loses its transparency for good, so keep the original if you might need it again. Options that need a different kind of encoder, such as lossless WebP, progressive JPEG or PNG palettes, are available through the FreeDailyPro API.",
  };
function es() {
  const [e, a] = f.useState(null),
    [r, c] = f.useState(null),
    o = Ve("convert-image"),
    d = o ? Ue(o) : void 0,
    [s, g] = f.useState({ ...oe, format: d ?? oe.format }),
    [h, x] = f.useState(0),
    [n, p] = f.useState("first"),
    [j, m] = f.useState(!1),
    [F, w] = f.useState(""),
    [v, b] = f.useState(!1),
    [l, N] = f.useState(!1),
    [u, C] = f.useState(null),
    [$, z] = f.useState(null),
    W = he(),
    [Q, X] = f.useState(null),
    { format: i } = s;
  V(i);
  const I = f.useCallback((k) => {
      (g((y) => ({ ...y, ...k })), C(null));
    }, []),
    D = async (k, y) => {
      try {
        if (k.type === "image/jpeg")
          return We(new Uint8Array(await k.slice(0, 65536).arrayBuffer()));
        if (k.type === "image/webp") return Le(k.size, y.width, y.height);
      } catch {}
      return null;
    },
    Y = f.useCallback(
      (k) => {
        if (k.length > 1) {
          (c(k), z(null));
          return;
        }
        const y = k[0];
        y &&
          (z(null),
          Ze(y)
            .then(async ({ canvas: J }) => {
              X(await D(y, J));
              const S = y.type === "image/gif" || /\.gif$/i.test(y.name),
                H = y.type === "image/webp" || /\.webp$/i.test(y.name),
                Z = S ? at(new Uint8Array(await y.arrayBuffer())) : 0;
              (x(Z),
                m(H && it(new Uint8Array(await y.slice(0, 64).arrayBuffer()))),
                p(o?.slug === "gif-to-png" && Z > 1 ? "all" : "first"),
                a(y),
                C(null),
                b(!1));
              const se = d && De(y.name) !== o?.to ? d : mt(y);
              g((ae) => ({ ...ae, format: se }));
            })
            .catch((J) => {
              const S = `${J?.message || "This file could not be opened as an image"} Nothing was used from your trial.`;
              (z(S), U.error(S));
            }));
      },
      [o, d],
    ),
    R = !!e && ct.has(e.type),
    P = f.useMemo(() => ke(Fe(s)), [s]),
    G = ge(s, P.ok ? null : Ce(P.error)),
    A = h > 1 && n === "all" && i !== "gif",
    M = async (k, y) => {
      const { default: J } = await Ge(
          async () => {
            const { default: B } = await import("./jszip.min-CT0ZA6V1.js").then(
              (ne) => ne.j,
            );
            return { default: B };
          },
          __vite__mapDeps([0, 1, 2, 3]),
        ),
        S = rt(new Uint8Array(await k.arrayBuffer()), _),
        H = new J(),
        Z = k.name.replace(/\.[^./\\]+$/, ""),
        se = V(y.format).ext,
        ae =
          String(S.frames.length).length < 3
            ? 3
            : String(S.frames.length).length,
        K = document.createElement("canvas");
      ((K.width = S.width), (K.height = S.height));
      const Se = K.getContext("2d");
      for (let B = 0; B < S.frames.length; B++) {
        (w(`Frame ${B + 1} of ${S.frames.length}`),
          Se.putImageData(
            new ImageData(
              new Uint8ClampedArray(S.frames[B].rgba),
              S.width,
              S.height,
            ),
            0,
            0,
          ));
        const ne = await new Promise((Ae, Ee) =>
            K.toBlob(
              (ie) =>
                ie
                  ? Ae(ie)
                  : Ee(new Error("This browser could not encode a frame.")),
              "image/png",
            ),
          ),
          Ne = await pe(new File([ne], `${Z}.png`, { type: "image/png" }), y);
        H.file(`${Z}-frame-${String(B + 1).padStart(ae, "0")}.${se}`, Ne);
      }
      return (w(""), H.generateAsync({ type: "blob" }));
    },
    ee = async () => {
      if (!(!e || !P.ok)) {
        N(!0);
        try {
          const k = A ? await M(e, P.options) : await pe(e, P.options);
          (C(k), b(A), U.success(A ? "Frames converted!" : "Image converted!"));
        } catch (k) {
          U.error(k?.message || "Failed to convert");
        } finally {
          (N(!1), w(""));
        }
      }
    },
    te = V(Ke(u?.type) ?? i).ext,
    L = !!e && Ye(i, e.type);
  return r
    ? t.jsxs(le, {
        children: [
          t.jsx(lt, { initialFiles: r, onExit: () => c(null) }),
          t.jsx(me, { whatIsIt: O.what, howToUse: O.how, tip: O.tip }),
        ],
      })
    : t.jsxs(le, {
        children: [
          e
            ? null
            : t.jsx(ue, {
                gateAtDownload: !0,
                multiple: !0,
                accept: "image/*",
                onFiles: Y,
                label: o
                  ? `Drop ${Me(o.from)} image to convert to ${Oe(o.to).label}`
                  : "Drop an image to convert",
                description:
                  "PNG, JPEG, WebP - also opens HEIC (iPhone), AVIF, TIFF, GIF, BMP, SVG. Drop several at once to convert them all to a ZIP",
              }),
          !e &&
            t.jsx(E, {
              variant: "outline",
              size: "sm",
              className: "mt-3",
              onClick: () => c([]),
              "data-testid": "convert-several",
              children: "Convert several images at once (ZIP)",
            }),
          !e &&
            $ &&
            t.jsx("p", {
              role: "alert",
              className: "mt-3 text-sm text-destructive",
              children: $,
            }),
          e
            ? t.jsxs("div", {
                className: "space-y-4",
                children: [
                  t.jsx("div", {
                    className: "p-4 rounded-lg border bg-card",
                    children: t.jsx("p", {
                      className: "text-sm font-medium",
                      children: e.name,
                    }),
                  }),
                  t.jsx(we, { form: s, onChange: I, support: W }),
                  t.jsx(ye, { form: s, onChange: I, sourceEstimate: Q }),
                  t.jsx(ve, { form: s, onChange: I }),
                  ce(o, e.name) &&
                    t.jsx("p", {
                      className: "text-xs text-muted-foreground",
                      "data-testid": "pair-mismatch",
                      children: ce(o, e.name),
                    }),
                  h > 1 &&
                    i !== "gif" &&
                    t.jsxs("div", {
                      role: "group",
                      "aria-label": "Animated GIF",
                      className: "space-y-2",
                      "data-testid": "gif-frames",
                      children: [
                        t.jsxs("p", {
                          className: "text-xs text-muted-foreground",
                          children: [
                            "This GIF is animated (",
                            h,
                            " frames). The result cannot move; choose what to save.",
                          ],
                        }),
                        t.jsxs("div", {
                          className: "flex flex-wrap gap-2",
                          children: [
                            t.jsx(E, {
                              size: "sm",
                              variant: n === "first" ? "default" : "outline",
                              "aria-pressed": n === "first",
                              onClick: () => {
                                (p("first"), C(null));
                              },
                              children: "First frame only",
                            }),
                            t.jsxs(E, {
                              size: "sm",
                              variant: n === "all" ? "default" : "outline",
                              "aria-pressed": n === "all",
                              onClick: () => {
                                (p("all"), C(null));
                              },
                              children: [
                                "All ",
                                Math.min(h, _),
                                " frames (ZIP)",
                              ],
                            }),
                          ],
                        }),
                        n === "all" &&
                          h > _ &&
                          t.jsxs("p", {
                            className: "text-xs text-muted-foreground",
                            children: [
                              "Only the first ",
                              _,
                              " frames are saved.",
                            ],
                          }),
                      ],
                    }),
                  j &&
                    i !== "webp" &&
                    i !== "gif" &&
                    t.jsx("p", {
                      className: "text-xs text-muted-foreground",
                      "data-testid": "webp-animated",
                      children:
                        "This WebP is animated. Only its first frame is converted.",
                    }),
                  t.jsx(je, { form: s, onChange: I, show: Pe(s) && R }),
                  t.jsx(be, {
                    form: s,
                    onChange: I,
                    metaHelp: L
                      ? "Copied into the new JPEG."
                      : "Only possible when both the original and the result are JPEG. Otherwise this information is removed.",
                  }),
                  G &&
                    t.jsx("p", {
                      role: "alert",
                      className: "text-sm text-destructive",
                      children: G,
                    }),
                  u && !v && t.jsx(Re, { blob: u }),
                  u &&
                    v &&
                    t.jsxs("p", {
                      className: "text-sm",
                      "data-testid": "convert-frames-zip",
                      children: [
                        Math.min(h, _),
                        " frames saved as separate ",
                        V(i).label,
                        " images in one ZIP (",
                        (u.size / 1024).toFixed(0),
                        " KB).",
                      ],
                    }),
                  u &&
                    !v &&
                    t.jsxs("p", {
                      className: "text-xs text-muted-foreground",
                      "data-testid": "convert-size",
                      children: [
                        "Result: ",
                        (u.size / 1024).toFixed(0),
                        " KB (original ",
                        (e.size / 1024).toFixed(0),
                        " KB)",
                        u.size > e.size * 1.5
                          ? `. This is ${(u.size / e.size).toFixed(1)}x larger than the original${i !== "webp" && i !== "avif" ? "; WebP is usually smaller" : ""}.`
                          : "",
                      ],
                    }),
                  t.jsx("div", {
                    className: "flex gap-3",
                    children: l
                      ? t.jsxs(t.Fragment, {
                          children: [
                            t.jsx(fe, {}),
                            F &&
                              t.jsx("span", {
                                className:
                                  "text-sm text-muted-foreground self-center",
                                role: "status",
                                children: F,
                              }),
                          ],
                        })
                      : u
                        ? t.jsxs(t.Fragment, {
                            children: [
                              t.jsx(Je, {
                                blob: u,
                                fileName: v
                                  ? de(e.name, "zip", "").replace(
                                      /\.zip$/,
                                      "-frames.zip",
                                    )
                                  : de(e.name, te),
                              }),
                              t.jsx(E, {
                                variant: "outline",
                                onClick: () => {
                                  (a(null), C(null));
                                },
                                children: "New",
                              }),
                            ],
                          })
                        : t.jsxs(t.Fragment, {
                            children: [
                              t.jsx(E, {
                                onClick: ee,
                                disabled: !P.ok || !!G || xe(W, i),
                                children: "Convert",
                              }),
                              t.jsx(E, {
                                variant: "outline",
                                onClick: () => a(null),
                                children: "Reset",
                              }),
                            ],
                          }),
                  }),
                ],
              })
            : null,
          t.jsx(me, { whatIsIt: O.what, howToUse: O.how, tip: O.tip }),
        ],
      });
}
export { es as default };
//# sourceMappingURL=ConvertImage-BKNYLFdo.js.map
