import { r as N, j as e } from "./vendor-react-D01g8YgM.js";
import { S as u, a as x, b as m, c as p, d as h } from "./select-ic5yaeGw.js";
import { e as c, B as M, N as P, I as v } from "./index-B1CTyGtY.js";
import { S as E } from "./slider-nIHsxb_2.js";
import { C as y } from "./checkbox-Ml1pfDb3.js";
import {
  formatInfo as f,
  FIT_MODES as I,
  FORMATS as b,
  ICO_SIZES as T,
  rgbaToHex as O,
} from "./convertCore-pdjQ6UTb.js";
import { n as S, F as z } from "./convertForm-Bkb1Ezx2.js";
const B =
  "AVIF output isn't available in this browser; use a current Chrome or Firefox desktop to create AVIF.";
function $(s) {
  const t = [
    16, 11, 10, 16, 24, 40, 51, 61, 12, 12, 14, 19, 26, 58, 60, 55, 14, 13, 16,
    24, 40, 57, 69, 56, 14, 17, 22, 29, 51, 87, 80, 62, 18, 22, 37, 56, 68, 109,
    103, 77, 24, 35, 55, 64, 81, 104, 113, 92, 49, 64, 78, 87, 103, 121, 120,
    101, 72, 92, 95, 98, 112, 100, 103, 99,
  ].reduce((r, o) => r + o, 0);
  let i = 2;
  for (; i + 4 < s.length;) {
    if (s[i] !== 255) return null;
    const r = s[i + 1],
      o = (s[i + 2] << 8) | s[i + 3];
    if (r === 218) return null;
    if (r === 219) {
      if (s[i + 4] >> 4 !== 0) return null;
      let l = 0;
      for (let g = 0; g < 64; g++) l += s[i + 5 + g] ?? 0;
      const j = (l / t) * 100,
        F = j <= 100 ? (200 - j) / 2 : 5e3 / j;
      return Math.round(Math.min(100, Math.max(1, F)));
    }
    i += 2 + o;
  }
  return null;
}
function G(s, a, t) {
  const i = (s * 8) / Math.max(1, a * t);
  return i < 0.4 ? 50 : i < 0.8 ? 65 : i < 1.5 ? 75 : i < 2.5 ? 82 : 90;
}
function q(s) {
  return Math.min(100, Math.max(40, Math.round(s)));
}
const w = new Map();
function R(s) {
  if (s === "image/png") return Promise.resolve(!0);
  let a = w.get(s);
  return (
    a ||
      ((a = new Promise((t) => {
        try {
          const i = document.createElement("canvas");
          ((i.width = i.height = 1),
            i.toBlob((r) => t(!!r && r.type === s), s, 0.5));
        } catch {
          t(!1);
        }
      })),
      w.set(s, a)),
    a
  );
}
const V =
  "WebP output isn't available in this browser; use a current Chrome, Edge or Firefox to create WebP.";
function J() {
  const [s, a] = N.useState({ "image/webp": null, "image/avif": null });
  return (
    N.useEffect(() => {
      for (const t of ["image/webp", "image/avif"])
        R(t).then((i) => a((r) => ({ ...r, [t]: i })));
    }, []),
    s
  );
}
const k = (s, a) =>
  (a === "webp" && s["image/webp"] === !1) ||
  (a === "avif" && s["image/avif"] === !1);
function A(s) {
  const a = /^#([0-9a-f]{6})$/i.exec(s),
    t = a ? parseInt(a[1], 16) : 16777215;
  return { r: (t >> 16) & 255, g: (t >> 8) & 255, b: t & 255, a: 1 };
}
function d({ id: s, checked: a, onChange: t, label: i, help: r }) {
  return e.jsxs("div", {
    className: "flex items-start gap-2",
    children: [
      e.jsx(y, {
        id: s,
        checked: a,
        onCheckedChange: (o) => t(o === !0),
        className: "mt-0.5",
      }),
      e.jsxs("div", {
        children: [
          e.jsx(c, {
            htmlFor: s,
            className: "text-sm font-normal cursor-pointer",
            children: i,
          }),
          r &&
            e.jsx("p", {
              className: "text-xs text-muted-foreground",
              children: r,
            }),
        ],
      }),
    ],
  });
}
function C({ id: s, form: a, onChange: t }) {
  return e.jsxs("div", {
    className: "flex items-center gap-2",
    children: [
      e.jsx(c, { htmlFor: s, className: "text-sm", children: "Fill color:" }),
      e.jsx("input", {
        id: s,
        type: "color",
        value: O(A(a.bgColor)),
        onChange: (i) => t({ bgColor: i.target.value }),
        className: "h-8 w-14 rounded border cursor-pointer",
      }),
    ],
  });
}
function K({ form: s, onChange: a, support: t, formats: i }) {
  const r = f(s.format),
    o = i ? b.filter((n) => i.includes(n.id)) : b;
  return e.jsxs("div", {
    className: "space-y-1",
    children: [
      e.jsx(c, { children: "Convert to" }),
      e.jsxs(u, {
        value: s.format,
        onValueChange: (n) => a({ format: n }),
        children: [
          e.jsx(x, {
            className: "w-48",
            "aria-label": "Convert to format",
            children: e.jsx(m, {}),
          }),
          e.jsx(p, {
            children: o.map((n) =>
              e.jsxs(
                h,
                {
                  value: n.id,
                  disabled: k(t, n.id),
                  children: [
                    n.label,
                    k(t, n.id) ? " (not available here)" : "",
                  ],
                },
                n.id,
              ),
            ),
          }),
        ],
      }),
      e.jsx("p", {
        className: "text-xs text-muted-foreground",
        children: r.hint,
      }),
      t["image/avif"] === !1 &&
        s.format !== "avif" &&
        e.jsx("p", { className: "text-xs text-muted-foreground", children: B }),
      t["image/webp"] === !1 &&
        s.format !== "webp" &&
        e.jsx("p", { className: "text-xs text-muted-foreground", children: V }),
    ],
  });
}
function Z({ form: s, onChange: a, sourceEstimate: t, min: i = 40 }) {
  return f(s.format).lossy
    ? e.jsxs("div", {
        className: "space-y-2 max-w-sm",
        children: [
          e.jsxs(c, { children: ["Quality: ", s.quality, "%"] }),
          e.jsx(E, {
            value: [s.quality],
            onValueChange: (r) => a({ quality: r[0] }),
            min: i,
            max: 100,
            step: 1,
          }),
          t != null &&
            e.jsxs(M, {
              type: "button",
              variant: "outline",
              size: "sm",
              onClick: () => a({ quality: q(t) }),
              children: ["Same as source (estimate: about ", t, "%)"],
            }),
          e.jsx("p", {
            className: "text-xs text-muted-foreground",
            children:
              "Lower quality makes a smaller file. 90 and above looks the same to most eyes.",
          }),
        ],
      })
    : null;
}
function X({ form: s, onChange: a }) {
  return e.jsxs(e.Fragment, {
    children: [
      s.format === "ico" &&
        e.jsxs("div", {
          className: "space-y-2",
          children: [
            e.jsx(c, { children: "Icon sizes (pixels)" }),
            e.jsx("div", {
              className: "flex flex-wrap gap-4",
              children: T.map((t) =>
                e.jsxs(
                  "div",
                  {
                    className: "flex items-center gap-2",
                    children: [
                      e.jsx(y, {
                        id: `ico-${t}`,
                        checked: s.icoSizes.includes(t),
                        onCheckedChange: (i) =>
                          a({
                            icoSizes:
                              i === !0
                                ? [...s.icoSizes, t].sort((r, o) => r - o)
                                : s.icoSizes.filter((r) => r !== t),
                          }),
                      }),
                      e.jsx(c, {
                        htmlFor: `ico-${t}`,
                        className: "text-sm font-normal cursor-pointer",
                        children: t,
                      }),
                    ],
                  },
                  t,
                ),
              ),
            }),
            e.jsx("p", {
              className: "text-xs text-muted-foreground",
              children:
                "One icon file holds all ticked sizes. 16, 32 and 48 cover browser tabs and shortcuts; add 256 for large Windows icons. A picture that is not square is centred with see-through padding.",
            }),
          ],
        }),
      s.format === "bmp" &&
        e.jsxs("div", {
          className: "space-y-1",
          children: [
            e.jsx(c, { children: "Colour depth" }),
            e.jsxs(u, {
              value: s.bmpDepth,
              onValueChange: (t) => a({ bmpDepth: t }),
              children: [
                e.jsx(x, {
                  className: "w-64",
                  "aria-label": "BMP colour depth",
                  children: e.jsx(m, {}),
                }),
                e.jsxs(p, {
                  children: [
                    e.jsx(h, {
                      value: "24",
                      children: "24-bit (no transparency)",
                    }),
                    e.jsx(h, {
                      value: "32",
                      children: "32-bit (keeps transparency)",
                    }),
                  ],
                }),
              ],
            }),
          ],
        }),
      s.format === "gif" &&
        e.jsx("p", {
          className: "text-xs text-muted-foreground",
          children:
            "GIF holds 256 colours at most, so photos look flatter. Only the first frame of an animated picture is used here.",
        }),
    ],
  });
}
function Y({ form: s, onChange: a, show: t, many: i = !1 }) {
  if (!S(s) || !t) return null;
  const r = f(s.format).label;
  return e.jsxs(P, {
    className: "space-y-2",
    testId: "alpha-notice",
    children: [
      e.jsxs("p", {
        className: "text-sm",
        children: [
          r,
          " doesn't support transparency, so the transparent areas of ",
          i ? "the images" : "this image",
          " will be filled with the color below instead. This can't be undone from the ",
          r,
          " afterward.",
        ],
      }),
      e.jsx(C, { id: "bg-color", form: s, onChange: a }),
    ],
  });
}
function ee(s, a) {
  return s.format === "ico" && s.icoSizes.length === 0
    ? "Tick at least one icon size."
    : a;
}
function se({ form: s, onChange: a, metaHelp: t, sizeExtra: i, open: r = !1 }) {
  const o = f(s.format),
    n = !S(s) && (o.alpha || s.fit === "contain");
  return e.jsxs("details", {
    className: "rounded-lg border bg-card p-4",
    open: r,
    children: [
      e.jsx("summary", {
        className: "cursor-pointer text-sm font-medium",
        children: "More options: size, turn, color, details",
      }),
      e.jsxs("div", {
        className: "mt-4 space-y-5",
        children: [
          e.jsxs("fieldset", {
            className: "space-y-2",
            children: [
              e.jsx("legend", {
                className: "text-sm font-medium",
                children: "Size",
              }),
              e.jsxs("div", {
                className: "flex flex-wrap items-end gap-3",
                children: [
                  e.jsxs("div", {
                    className: "space-y-1",
                    children: [
                      e.jsx(c, {
                        htmlFor: "cv-w",
                        className: "text-xs",
                        children: "Width (px)",
                      }),
                      e.jsx(v, {
                        id: "cv-w",
                        inputMode: "numeric",
                        className: "w-28",
                        placeholder: "keep",
                        value: s.width,
                        onChange: (l) => a({ width: l.target.value }),
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className: "space-y-1",
                    children: [
                      e.jsx(c, {
                        htmlFor: "cv-h",
                        className: "text-xs",
                        children: "Height (px)",
                      }),
                      e.jsx(v, {
                        id: "cv-h",
                        inputMode: "numeric",
                        className: "w-28",
                        placeholder: "keep",
                        value: s.height,
                        onChange: (l) => a({ height: l.target.value }),
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className: "space-y-1",
                    children: [
                      e.jsx(c, {
                        className: "text-xs",
                        children: "When both are set",
                      }),
                      e.jsxs(u, {
                        value: s.fit,
                        onValueChange: (l) => a({ fit: l }),
                        children: [
                          e.jsx(x, {
                            className: "w-40",
                            "aria-label": "How the picture fits the size",
                            children: e.jsx(m, {}),
                          }),
                          e.jsx(p, {
                            children: I.map((l) =>
                              e.jsx(
                                h,
                                {
                                  value: l,
                                  children:
                                    l.charAt(0).toUpperCase() + l.slice(1),
                                },
                                l,
                              ),
                            ),
                          }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              i,
              e.jsxs("p", {
                className: "text-xs text-muted-foreground",
                children: [
                  "Leave a box empty to keep that side. Set only one side and the other follows the picture's shape. ",
                  z[s.fit],
                ],
              }),
              e.jsx(d, {
                id: "cv-noenlarge",
                checked: s.noEnlarge,
                onChange: (l) => a({ noEnlarge: l }),
                label: "Never make it bigger than the original",
              }),
            ],
          }),
          n &&
            e.jsxs("fieldset", {
              className: "space-y-2",
              children: [
                e.jsx("legend", {
                  className: "text-sm font-medium",
                  children: "Background",
                }),
                e.jsx(d, {
                  id: "cv-usebg",
                  checked: s.useBg,
                  onChange: (l) => a({ useBg: l }),
                  label: "Fill transparent areas and padding with a color",
                  help: "Off keeps the picture see-through where the format allows it.",
                }),
                s.useBg &&
                  e.jsx(C, { id: "bg-color-optional", form: s, onChange: a }),
              ],
            }),
          e.jsxs("fieldset", {
            className: "space-y-2",
            children: [
              e.jsx("legend", {
                className: "text-sm font-medium",
                children: "Turn and flip",
              }),
              e.jsxs("div", {
                className: "flex flex-wrap items-center gap-4",
                children: [
                  e.jsxs("div", {
                    className: "space-y-1",
                    children: [
                      e.jsx(c, {
                        className: "text-xs",
                        children: "Rotate clockwise",
                      }),
                      e.jsxs(u, {
                        value: s.rotate,
                        onValueChange: (l) => a({ rotate: l }),
                        children: [
                          e.jsx(x, {
                            className: "w-32",
                            "aria-label": "Rotate",
                            children: e.jsx(m, {}),
                          }),
                          e.jsx(p, {
                            children: ["0", "90", "180", "270"].map((l) =>
                              e.jsx(
                                h,
                                {
                                  value: l,
                                  children:
                                    l === "0" ? "Not at all" : `${l} degrees`,
                                },
                                l,
                              ),
                            ),
                          }),
                        ],
                      }),
                    ],
                  }),
                  e.jsx(d, {
                    id: "cv-flop",
                    checked: s.flop,
                    onChange: (l) => a({ flop: l }),
                    label: "Mirror left to right",
                  }),
                  e.jsx(d, {
                    id: "cv-flip",
                    checked: s.flip,
                    onChange: (l) => a({ flip: l }),
                    label: "Mirror top to bottom",
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("fieldset", {
            className: "space-y-2",
            children: [
              e.jsx("legend", {
                className: "text-sm font-medium",
                children: "Color",
              }),
              e.jsx(d, {
                id: "cv-gray",
                checked: s.grayscale,
                onChange: (l) => a({ grayscale: l }),
                label: "Black and white",
                help: "Removes all color from the picture.",
              }),
            ],
          }),
          e.jsxs("fieldset", {
            className: "space-y-2",
            children: [
              e.jsx("legend", {
                className: "text-sm font-medium",
                children: "Details",
              }),
              e.jsx(d, {
                id: "cv-orient",
                checked: s.autoOrient,
                onChange: (l) => a({ autoOrient: l }),
                label: "Turn photos upright automatically",
                help: "Phone photos store a hidden rotation flag. This applies it so the picture looks right everywhere. Some browsers always apply it.",
              }),
              e.jsx(d, {
                id: "cv-keep",
                checked: s.keepMeta,
                onChange: (l) => a({ keepMeta: l }),
                label: "Keep camera, date and location details",
                help: t,
              }),
              !s.keepMeta &&
                e.jsx("p", {
                  className: "text-xs text-muted-foreground",
                  children: "Location and camera data are removed.",
                }),
              (s.format === "png" ||
                s.format === "jpeg" ||
                s.format === "tiff" ||
                s.format === "bmp") &&
                e.jsxs("div", {
                  className: "space-y-1",
                  children: [
                    e.jsx(c, {
                      htmlFor: "cv-dpi",
                      className: "text-xs",
                      children: "Print resolution (dpi)",
                    }),
                    e.jsx(v, {
                      id: "cv-dpi",
                      inputMode: "numeric",
                      className: "w-28",
                      placeholder: "default",
                      value: s.dpi,
                      onChange: (l) => a({ dpi: l.target.value }),
                    }),
                    e.jsx("p", {
                      className: "text-xs text-muted-foreground",
                      children:
                        "Print shops read this, for example 300. It does not change the pixel size.",
                    }),
                  ],
                }),
            ],
          }),
        ],
      }),
    ],
  });
}
export {
  d as C,
  Y as F,
  se as M,
  Z as Q,
  V as W,
  C as a,
  K as b,
  X as c,
  G as d,
  $ as e,
  k as f,
  ee as o,
  J as u,
};
//# sourceMappingURL=ConvertOptionsPanel-DhmFQStl.js.map
