import { d as I, a as k, c as b, h as M } from "./decode-DrS85i4S.js";
import {
  formatInfo as v,
  encodeIco as D,
  encodeTiff as B,
  encodeBmp as E,
  encodeGif as j,
  setPngDpi as C,
  extractJpegExif as S,
  insertJpegExif as H,
  resetExifOrientation as O,
  computeFit as T,
} from "./convertCore-pdjQ6UTb.js";
import { s as W } from "./jpegDpi-c8DPdZxl.js";
import { d as z } from "./operations-YdcesJcx.js";
import "./index-B1CTyGtY.js";
import "./vendor-react-D01g8YgM.js";
import "./utils-1EQcVBdK.js";
const R = { r: 255, g: 255, b: 255 },
  y = (e) => `rgb(${e.r},${e.g},${e.b})`;
function s(e, t) {
  const n = document.createElement("canvas");
  return ((n.width = e), (n.height = t), n);
}
function c(e) {
  const t = e.getContext("2d", { willReadFrequently: !0 });
  if (!t)
    throw new Error(
      "This browser could not create a drawing surface for the image.",
    );
  return t;
}
async function F(e) {
  try {
    if (typeof createImageBitmap != "function") return null;
    const t = await createImageBitmap(e, { imageOrientation: "none" }),
      n = s(t.width, t.height);
    return (c(n).drawImage(t, 0, 0), t.close?.(), n);
  } catch {
    return null;
  }
}
function J(e, t, n, o) {
  if (!t && !n && !o) return e;
  const a = t === 90 || t === 270,
    h = s(a ? e.height : e.width, a ? e.width : e.height),
    i = c(h);
  return (
    i.translate(h.width / 2, h.height / 2),
    i.rotate((t * Math.PI) / 180),
    i.scale(o ? -1 : 1, n ? -1 : 1),
    i.drawImage(e, -e.width / 2, -e.height / 2),
    h
  );
}
function $(e) {
  const t = c(e),
    n = t.getImageData(0, 0, e.width, e.height),
    o = n.data;
  for (let a = 0; a < o.length; a += 4) {
    const h = Math.round(0.2126 * o[a] + 0.7152 * o[a + 1] + 0.0722 * o[a + 2]);
    o[a] = o[a + 1] = o[a + 2] = h;
  }
  t.putImageData(n, 0, 0);
}
function x(e, t) {
  const n = s(e.width, e.height),
    o = c(n);
  return (
    (o.fillStyle = y(t)),
    o.fillRect(0, 0, n.width, n.height),
    o.drawImage(e, 0, 0),
    n
  );
}
const u = async (e) => new Uint8Array(await e.arrayBuffer());
function q(e, t, n, o, a, h) {
  if (!t && !n) return e;
  const i = T(e.width, e.height, t, n, o, a);
  if (i.outW === e.width && i.outH === e.height && i.dw === e.width) return e;
  if (
    i.sx === 0 &&
    i.sy === 0 &&
    i.sw === e.width &&
    i.sh === e.height &&
    i.dx === 0 &&
    i.dy === 0 &&
    i.dw === i.outW &&
    i.dh === i.outH
  ) {
    const g = z(e, i.outW, i.outH);
    return h ? x(g, h) : g;
  }
  const d = s(i.outW, i.outH),
    r = c(d);
  return (
    h && ((r.fillStyle = y(h)), r.fillRect(0, 0, d.width, d.height)),
    (r.imageSmoothingEnabled = !0),
    (r.imageSmoothingQuality = "high"),
    r.drawImage(e, i.sx, i.sy, i.sw, i.sh, i.dx, i.dy, i.dw, i.dh),
    d
  );
}
async function V(e, t) {
  return (await A(e, t)).blob;
}
async function A(e, t) {
  const n = v(t.format),
    o = I(e);
  let a = null;
  (!t.autoOrient &&
    o === "native" &&
    e.type === "image/jpeg" &&
    (a = await F(e)),
    a || (a = (await k(e)).canvas),
    (a = J(a, t.rotate, t.flip, t.flop)));
  const h =
    t.backgroundColor && t.backgroundColor.a > 0 ? t.backgroundColor : void 0;
  ((a = q(a, t.width, t.height, t.fit, t.withoutEnlargement, h)),
    t.grayscale && $(a),
    (t.format === "jpeg" || h) && (a = x(a, h ?? R)));
  let i;
  switch (t.format) {
    case "png":
    case "jpeg":
    case "webp":
    case "avif": {
      const d = await b(
        a,
        n.mime,
        n.lossy
          ? (t.quality ??
              (t.format === "jpeg" ? 92 : t.format === "webp" ? 85 : 60)) / 100
          : void 0,
      );
      if (
        ((i = await u(d)),
        t.dpi && t.format === "png" && (i = C(i, t.dpi)),
        t.dpi && t.format === "jpeg" && (i = W(i, t.dpi)),
        !t.stripMetadata && t.format === "jpeg" && e.type === "image/jpeg")
      ) {
        const r = S(await u(e));
        r && (i = H(i, t.autoOrient ? O(r) : r));
      }
      break;
    }
    case "gif": {
      const d = c(a).getImageData(0, 0, a.width, a.height).data;
      i = j(d, a.width, a.height, { background: h });
      break;
    }
    case "bmp": {
      const d = c(a).getImageData(0, 0, a.width, a.height).data;
      i = E(d, a.width, a.height, {
        bits: t.bitDepth,
        background: h,
        dpi: t.dpi,
      });
      break;
    }
    case "tiff": {
      const d = c(a).getImageData(0, 0, a.width, a.height).data;
      i = B(d, a.width, a.height, { alpha: !h && M(a), dpi: t.dpi });
      break;
    }
    case "ico": {
      const d = [];
      for (const r of t.sizes) {
        const g = s(r, r),
          f = c(g),
          w = Math.min(r / a.width, r / a.height),
          p = Math.max(1, Math.round(a.width * w)),
          l = Math.max(1, Math.round(a.height * w));
        ((f.imageSmoothingQuality = "high"),
          f.drawImage(
            a,
            Math.round((r - p) / 2),
            Math.round((r - l) / 2),
            p,
            l,
          ),
          d.push({ size: r, png: await u(await b(g, "image/png")) }));
      }
      i = D(d);
      break;
    }
  }
  const m = t.format === "ico" ? Math.max(...t.sizes) : 0;
  return {
    blob: new Blob([i], { type: n.mime }),
    width: m || a.width,
    height: m || a.height,
  };
}
export {
  A as convertImageDetailed,
  V as convertImageInBrowser,
  q as fitCanvas,
  J as rotateFlip,
  $ as toGrayscale,
};
//# sourceMappingURL=convertBrowser-CYvv7SBJ.js.map
