import { formatInfo as r } from "./convertCore-pdjQ6UTb.js";
const c = {
    format: "png",
    bgColor: "#ffffff",
    useBg: !1,
    quality: 92,
    width: "",
    height: "",
    fit: "inside",
    noEnlarge: !1,
    rotate: "0",
    flip: !1,
    flop: !1,
    grayscale: !1,
    autoOrient: !0,
    keepMeta: !1,
    dpi: "",
    icoSizes: [16, 32, 48],
    bmpDepth: "24",
  },
  h = {
    inside:
      "Fits inside the size you give and keeps the picture's shape. Nothing is cropped or padded.",
    contain:
      "Fits inside the exact size and fills the leftover space with the background colour.",
    cover: "Fills the exact size and crops whatever sticks out.",
    fill: "Stretches the picture to the exact size. It can look squashed.",
    outside:
      "Keeps the shape and makes the picture at least as big as the size you give.",
  };
function u(e) {
  return e.format === "jpeg" || (e.format === "bmp" && e.bmpDepth === "24");
}
function g(e, t) {
  return e === "jpeg" && t === "image/jpeg";
}
function d(e) {
  return {
    format: e.format,
    quality: r(e.format).lossy ? e.quality : void 0,
    backgroundColor: u(e) || e.useBg ? e.bgColor : void 0,
    width: e.width,
    height: e.height,
    fit: e.fit,
    withoutEnlargement: e.noEnlarge,
    rotate: e.rotate,
    flip: e.flip,
    flop: e.flop,
    grayscale: e.grayscale,
    autoOrient: e.autoOrient,
    stripMetadata: !e.keepMeta,
    dpi: e.dpi,
    sizes: e.icoSizes.join(","),
    bitDepth: e.bmpDepth,
  };
}
function f(e, t) {
  const i = Math.round(Number(t)),
    a = (n) => n == null || String(n).trim() === "";
  return !(i > 0) || !a(e.width) || !a(e.height)
    ? e
    : { ...e, width: i, height: i, fit: "inside", withoutEnlargement: !0 };
}
function m(e) {
  const t = {
    width: "Width",
    height: "Height",
    dpi: "Resolution",
    sizes: "Icon sizes",
  };
  return e.replace(/^'(\w+)'/, (i, a) => t[a] ?? `'${a}'`);
}
function b(e, t) {
  return t === "heic" || t === "tiff" || e === "image/png"
    ? "jpeg"
    : e === "image/jpeg"
      ? "png"
      : e === "image/webp"
        ? "jpeg"
        : "png";
}
function l(e, t) {
  const i = e.lastIndexOf("."),
    a = i > 0 ? e.slice(0, i) : e,
    n = i > 0 ? e.slice(i) : "";
  let o = e,
    s = 1;
  for (; t.has(o.toLowerCase());) o = `${a}-${++s}${n}`;
  return (t.add(o.toLowerCase()), o);
}
function w(e, t, i) {
  const a = e.replace(/\.[^./\\]+$/, "") || "image";
  return l(`${a}.${r(t).ext}`, i);
}
function z(e, t, i) {
  const a = t > e;
  return `${(e / 1024).toFixed(0)} KB -> ${(t / 1024).toFixed(0)} KB, ${i}${a ? " (larger than the original)" : ""}`;
}
function F(e, t, i) {
  const a = Number(i);
  return a === 90 || a === 270 ? { w: t, h: e } : { w: e, h: t };
}
export {
  c as D,
  h as F,
  m as a,
  f as b,
  w as c,
  z as d,
  b as e,
  d as f,
  g as m,
  u as n,
  F as t,
  l as u,
};
//# sourceMappingURL=convertForm-Bkb1Ezx2.js.map
