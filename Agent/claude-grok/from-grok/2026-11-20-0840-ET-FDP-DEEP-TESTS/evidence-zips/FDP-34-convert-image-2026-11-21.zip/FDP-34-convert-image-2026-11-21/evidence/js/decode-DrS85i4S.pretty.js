const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/heic2any-Cwwvdsxn.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/UTIF-B1u3ONBr.js",
      "assets/_commonjs-dynamic-modules-TDtrdbi3.js",
      "assets/index-DMQTJy3b.js",
    ]),
) => i.map((i) => d[i]);
import { ap as u } from "./index-B1CTyGtY.js";
const g = (a) => (a.toLowerCase().match(/\.([^./\\]+)$/) ?? [])[1] ?? "";
function w(a) {
  const n = g(a.name),
    t = (a.type || "").toLowerCase();
  return t === "image/heic" ||
    t === "image/heif" ||
    n === "heic" ||
    n === "heif"
    ? "heic"
    : t === "image/avif" || n === "avif"
      ? "avif"
      : t === "image/tiff" || n === "tif" || n === "tiff"
        ? "tiff"
        : "native";
}
class c extends Error {
  constructor(n) {
    (super(n), (this.name = "ImageDecodeError"));
  }
}
function d(a, n, t) {
  const e = document.createElement("canvas");
  ((e.width = n), (e.height = t));
  const r = e.getContext("2d");
  if (!r)
    throw new c(
      "This browser could not create a drawing surface for the image.",
    );
  return (r.drawImage(a, 0, 0, n, t), e);
}
async function l(a) {
  const n = (
      await u(
        async () => {
          const { default: e } = await import("./heic2any-Cwwvdsxn.js").then(
            (r) => r.h,
          );
          return { default: e };
        },
        __vite__mapDeps([0, 1]),
      )
    ).default,
    t = await n({ blob: a, toType: "image/png" });
  return Array.isArray(t) ? t[0] : t;
}
async function p(a) {
  const n =
      (
        await u(
          async () => {
            const { default: s } = await import("./UTIF-B1u3ONBr.js").then(
              (m) => m.U,
            );
            return { default: s };
          },
          __vite__mapDeps([2, 1, 3, 4]),
        )
      ).default ??
      (await u(
        () => import("./UTIF-B1u3ONBr.js").then((s) => s.U),
        __vite__mapDeps([2, 1, 3, 4]),
      )),
    t = await a.arrayBuffer(),
    e = n.decode(t);
  if (!e.length) throw new c("This TIFF file has no readable picture in it.");
  n.decodeImage(t, e[0]);
  const r = n.toRGBA8(e[0]),
    o = e[0].width,
    h = e[0].height,
    i = document.createElement("canvas");
  return (
    (i.width = o),
    (i.height = h),
    i
      .getContext("2d")
      .putImageData(new ImageData(new Uint8ClampedArray(r), o, h), 0, 0),
    i
  );
}
function f(a) {
  return new Promise((n, t) => {
    const e = URL.createObjectURL(a),
      r = new Image();
    ((r.onload = () => {
      (URL.revokeObjectURL(e), n(r));
    }),
      (r.onerror = () => {
        (URL.revokeObjectURL(e), t(new Error("decode")));
      }),
      (r.src = e));
  });
}
async function y(a) {
  const n = w(a);
  try {
    if (n === "tiff") {
      const t = await p(a);
      return { canvas: t, width: t.width, height: t.height, mayHaveAlpha: !0 };
    }
    if (n === "heic") {
      const t = await l(a),
        e = await f(t);
      return {
        canvas: d(e, e.naturalWidth, e.naturalHeight),
        width: e.naturalWidth,
        height: e.naturalHeight,
        mayHaveAlpha: !1,
      };
    }
    try {
      const t = await f(a),
        e = t.naturalWidth || 300,
        r = t.naturalHeight || 150;
      return { canvas: d(t, e, r), width: e, height: r, mayHaveAlpha: !0 };
    } catch {
      if (typeof createImageBitmap == "function") {
        const t = await createImageBitmap(a),
          e = d(t, t.width, t.height);
        return (
          t.close?.(),
          { canvas: e, width: e.width, height: e.height, mayHaveAlpha: !0 }
        );
      }
      throw new Error("decode");
    }
  } catch (t) {
    throw t instanceof c
      ? t
      : n === "avif"
        ? new c(
            `"${a.name}" is an AVIF image and this browser cannot open AVIF. Try Chrome, Edge, Firefox or a current Safari.`,
          )
        : n === "heic"
          ? new c(
              `"${a.name}" could not be read as an iPhone (HEIC) photo. The file may be damaged or use an unusual HEIC variant.`,
            )
          : new c(
              `"${a.name}" could not be read as an image. The file may be damaged or not a picture.`,
            );
  }
}
function I(a, n = "#ffffff") {
  const t = document.createElement("canvas");
  ((t.width = a.width), (t.height = a.height));
  const e = t.getContext("2d");
  return (
    (e.fillStyle = n),
    e.fillRect(0, 0, t.width, t.height),
    e.drawImage(a, 0, 0),
    t
  );
}
function E(a, n, t) {
  return new Promise((e, r) =>
    a.toBlob(
      (o) => {
        if (!o) return r(new Error("This browser could not encode the image."));
        if (n !== "image/png" && o.type && o.type !== n)
          return r(
            new Error(
              `This browser cannot create ${n.replace("image/", "").toUpperCase()} images. Try Chrome, Edge or Firefox, or pick another format.`,
            ),
          );
        e(o);
      },
      n,
      t,
    ),
  );
}
function T(a) {
  const n = Math.min(1, 256 / Math.max(a.width, a.height)),
    t = Math.max(1, Math.round(a.width * n)),
    e = Math.max(1, Math.round(a.height * n)),
    r = document.createElement("canvas");
  ((r.width = t), (r.height = e));
  const o = r.getContext("2d");
  o.drawImage(a, 0, 0, t, e);
  const h = o.getImageData(0, 0, t, e).data;
  for (let i = 3; i < h.length; i += 4) if (h[i] < 250) return !0;
  return !1;
}
function x(a, n, t = "") {
  return `${t}${a.replace(/\.[^./\\]+$/, "")}.${n}`;
}
export { y as a, E as c, w as d, I as f, T as h, x as r };
//# sourceMappingURL=decode-DrS85i4S.js.map
