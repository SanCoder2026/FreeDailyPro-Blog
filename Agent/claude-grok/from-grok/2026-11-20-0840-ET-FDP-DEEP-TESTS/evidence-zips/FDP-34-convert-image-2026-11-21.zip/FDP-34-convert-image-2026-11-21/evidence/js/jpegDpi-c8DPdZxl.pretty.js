function c(n, i) {
  if (n.length < 4 || n[0] !== 255 || n[1] !== 216) return n;
  const o = (i >> 8) & 255,
    a = i & 255;
  if (
    n[2] === 255 &&
    n[3] === 224 &&
    n[6] === 74 &&
    n[7] === 70 &&
    n[8] === 73 &&
    n[9] === 70
  ) {
    const r = new Uint8Array(n);
    return ((r[13] = 1), (r[14] = o), (r[15] = a), (r[16] = o), (r[17] = a), r);
  }
  const u = Uint8Array.from([
      255,
      224,
      0,
      16,
      74,
      70,
      73,
      70,
      0,
      1,
      1,
      1,
      o,
      a,
      o,
      a,
      0,
      0,
    ]),
    t = new Uint8Array(n.length + u.length);
  return (
    t.set(n.subarray(0, 2), 0),
    t.set(u, 2),
    t.set(n.subarray(2), 2 + u.length),
    t
  );
}
export { c as s };
//# sourceMappingURL=jpegDpi-c8DPdZxl.js.map
