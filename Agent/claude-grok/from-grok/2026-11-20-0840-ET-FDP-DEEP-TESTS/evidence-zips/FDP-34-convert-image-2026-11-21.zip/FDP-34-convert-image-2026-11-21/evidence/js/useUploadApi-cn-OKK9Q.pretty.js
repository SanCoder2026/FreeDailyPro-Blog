import {
  v as T,
  t as x,
  bh as A,
  f as D,
  ar as P,
  as as k,
  at as L,
  au as M,
  av as O,
  bi as _,
  B as y,
  L as N,
} from "./index-B1CTyGtY.js";
import { r as C, j as n } from "./vendor-react-D01g8YgM.js";
import { a as R, b as z, c as v } from "./cloudStorage-BzUdFuQl.js";
const H = T("CloudUpload", [
  ["path", { d: "M12 13v8", key: "1l5pq0" }],
  [
    "path",
    {
      d: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242",
      key: "1pljnt",
    },
  ],
  ["path", { d: "m8 17 4-4 4 4", key: "1quai1" }],
]);
function B() {
  const t = x.cloudStorage.checkout.useMutation(),
    [e, r] = C.useState(!1);
  return {
    start: async (a) => {
      if (!a) {
        window.location.href = A(
          window.location.pathname + window.location.search,
        );
        return;
      }
      r(!0);
      try {
        const o = await t.mutateAsync();
        window.location.href = o.url;
      } catch (o) {
        (D.error(
          o instanceof Error
            ? o.message
            : "Could not open checkout. Please try again.",
        ),
          r(!1));
      }
    },
    busy: e,
  };
}
function W({ open: t, onOpenChange: e, signedIn: r }) {
  const { start: l, busy: a } = B();
  return n.jsx(P, {
    open: t,
    onOpenChange: e,
    children: n.jsxs(k, {
      "data-testid": "cloud-storage-upsell",
      children: [
        n.jsxs(L, {
          children: [
            n.jsx(M, { children: "Cloud storage" }),
            n.jsx(O, { children: R }),
          ],
        }),
        n.jsx("p", {
          className: "text-sm text-muted-foreground",
          children: r
            ? z
            : "Sign in with your email first, then add cloud storage to your account.",
        }),
        n.jsx("p", { className: "text-sm text-muted-foreground", children: v }),
        n.jsxs(_, {
          children: [
            n.jsx(y, {
              variant: "outline",
              onClick: () => e(!1),
              children: "Not now",
            }),
            n.jsxs(y, {
              onClick: () => {
                l(r);
              },
              disabled: a,
              "data-testid": "cloud-storage-upsell-buy",
              children: [
                a &&
                  n.jsx(N, {
                    className: "mr-2 h-4 w-4 animate-spin",
                    "aria-hidden": !0,
                  }),
                r ? "Add cloud storage" : "Sign in",
              ],
            }),
          ],
        }),
      ],
    }),
  });
}
class E extends Error {}
const I = async (t, e, r, l) => {
    const a = await fetch(
      `/api/cloud-storage/uploads/${encodeURIComponent(t)}/parts/${e}`,
      {
        method: "PUT",
        body: r,
        signal: l,
        credentials: "same-origin",
        headers: { "Content-Type": "application/octet-stream" },
      },
    );
    if (a.ok) return;
    let o = `The upload of one part failed (${a.status}).`;
    try {
      const i = await a.json();
      typeof i?.message == "string" && (o = i.message);
    } catch {}
    throw a.status >= 400 &&
      a.status < 500 &&
      a.status !== 408 &&
      a.status !== 429
      ? new E(o)
      : new Error(o);
  },
  q = (t) => new Promise((e) => setTimeout(e, t));
async function J(t) {
  const e = t.put ?? I,
    r = t.attempts ?? 3,
    l = t.sleep ?? q,
    a = t.blob.size,
    o = await t.api.prepareUpload({
      name: t.name,
      sizeBytes: a,
      contentType: t.blob.type || t.contentType,
      sourceTool: t.sourceTool,
    }),
    i = new Set(
      o.resumed ? (await t.api.uploadProgress({ fileId: o.fileId })).done : [],
    ),
    u = o.partBytes,
    U = (s) => (s === o.partCount ? a - u * (s - 1) : u);
  let f = Array.from(i).reduce((s, c) => s + U(c), 0);
  const g = () =>
    t.onProgress?.(
      a === 0 ? (i.size >= o.partCount ? 1 : 0) : Math.min(1, f / a),
    );
  g();
  const h = Array.from({ length: o.partCount }, (s, c) => c + 1).filter(
    (s) => !i.has(s),
  );
  let w = 0;
  const b = async (s) => {
      const c = t.blob.slice(u * (s - 1), Math.min(a, u * s));
      let m;
      for (let p = 1; p <= r; p++) {
        if (t.signal?.aborted)
          throw new DOMException("Upload stopped", "AbortError");
        try {
          (await e(o.fileId, s, c, t.signal), i.add(s), (f += c.size), g());
          return;
        } catch (d) {
          if (
            (d instanceof DOMException && d.name === "AbortError") ||
            d instanceof E
          )
            throw d;
          ((m = d), p < r && (await l(500 * 2 ** (p - 1))));
        }
      }
      throw m instanceof Error
        ? m
        : new Error("The upload could not be finished.");
    },
    j = async () => {
      for (; w < h.length;) {
        const s = h[w++];
        await b(s);
      }
    };
  await Promise.all(
    Array.from(
      { length: Math.max(1, Math.min(t.concurrency ?? 3, h.length || 1)) },
      j,
    ),
  );
  const S = await t.api.completeUpload({ fileId: o.fileId });
  return (t.onProgress?.(1), S);
}
function K() {
  const t = x.useUtils();
  return C.useMemo(
    () => ({
      prepareUpload: (e) => t.client.cloudStorage.prepareUpload.mutate(e),
      uploadProgress: (e) => t.client.cloudStorage.uploadProgress.query(e),
      completeUpload: (e) => t.client.cloudStorage.completeUpload.mutate(e),
      cancelUpload: (e) => t.client.cloudStorage.cancelUpload.mutate(e),
    }),
    [t],
  );
}
export { H as C, K as a, J as b, W as c, B as u };
//# sourceMappingURL=useUploadApi-cn-OKK9Q.js.map
