# Recreates the synthetic test images for FDP-34 (convert-image). Needs Pillow, pillow-heif, piexif.
from PIL import Image, ImageDraw
import pillow_heif, piexif, io, os
pillow_heif.register_heif_opener()
def pic(w,h,mode='RGB',bg=(30,90,160)):
    im=Image.new(mode,(w,h),bg if mode=='RGB' else bg+(255,)); d=ImageDraw.Draw(im)
    for i in range(0,w,40): d.line([(i,0),(i,h)],fill=(255,255,255) if mode=='RGB' else (255,255,255,255),width=2)
    d.ellipse([w//4,h//4,3*w//4,3*h//4],fill=(240,180,20) if mode=='RGB' else (240,180,20,255)); d.text((10,10),f'{w}x{h}',fill=(0,0,0) if mode=='RGB' else (0,0,0,255)); return im
# T01 transparent PNG logo
im=Image.new('RGBA',(800,600),(0,0,0,0)); d=ImageDraw.Draw(im); d.ellipse([150,100,650,500],fill=(220,40,60,255)); d.rectangle([350,250,450,350],fill=(0,0,0,0)); im.save('T01_logo_transparent.png')
# T02 JPEG with EXIF incl. GPS, orientation 6, 300 dpi
ex={'0th':{piexif.ImageIFD.Make:b'TestCam',piexif.ImageIFD.Model:b'QA-1',piexif.ImageIFD.Orientation:6,piexif.ImageIFD.XResolution:(300,1),piexif.ImageIFD.YResolution:(300,1)},
    'Exif':{piexif.ExifIFD.DateTimeOriginal:b'2026:11:01 10:00:00'},
    'GPS':{piexif.GPSIFD.GPSLatitudeRef:b'N',piexif.GPSIFD.GPSLatitude:((40,1),(44,1),(0,1)),piexif.GPSIFD.GPSLongitudeRef:b'W',piexif.GPSIFD.GPSLongitude:((73,1),(59,1),(0,1))}}
pic(1600,1200).save('T02_photo_exif_gps_orient6.jpg',quality=90,exif=piexif.dump(ex),dpi=(300,300))
pic(640,480).save('T03_lossy.webp',quality=80)
fr=[pic(320,240,bg=(i*60,40,120)) for i in range(3)]; fr[0].save('T04_animated.webp',save_all=True,append_images=fr[1:],duration=200,loop=0)
pic(640,480).save('T05_photo.avif',quality=60)
g=[pic(200,200,bg=(40,i*50,90)).convert('P') for i in range(5)]; g[0].save('T06_animated_5f.gif',save_all=True,append_images=g[1:],duration=150,loop=0)
pic(300,200).save('T07_old.bmp')
p=[pic(400,300,bg=(10,10,10)),pic(400,300,bg=(200,30,30))]; p[0].save('T08_2page.tiff',save_all=True,append_images=p[1:])
open('T09_sized.svg','w').write('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="200"><rect width="400" height="200" fill="#2a6"/><circle cx="200" cy="100" r="80" fill="#fd0"/></svg>')
open('T10_nosize_script.svg','w').write('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 50" onload="alert(1)"><script>alert(2)</script><rect width="100" height="50" fill="#36c"/></svg>')
pic(1024,768).save('T11_iphone.heic',quality=70)
open('T12_notimage.png','w').write('this is plain text, not an image\n')
b=io.BytesIO(); pic(800,600).save(b,'JPEG'); open('T13_truncated.jpg','wb').write(b.getvalue()[:3000])
pic(6000,4000).save('T14_big_6000x4000.jpg',quality=92)
pic(500,500).save('T15_photo été #1.png')
pic(64,64).save('T16_square_64.png')
for f in sorted(os.listdir('.')): print(f, os.path.getsize(f))
