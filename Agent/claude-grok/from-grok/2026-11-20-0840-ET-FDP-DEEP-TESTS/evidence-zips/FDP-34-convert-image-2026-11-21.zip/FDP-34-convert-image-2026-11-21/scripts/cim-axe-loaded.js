// convert-image: axe on the loaded state (file loaded, More options open) and in batch mode; accessible names of switches/slider. Guest, no Convert.
const { chromium } = require('playwright'); const fs = require('fs'); const AXE = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8');
const BASE = '/workspace/deep/34-convert-image/';
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); p.setDefaultTimeout(15000); const R = {};
 await p.goto('https://www.freedailypro.com/tool/convert-image', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500);
 await p.locator('main input[type=file]').first().setInputFiles(BASE + 'testfiles/T01_logo_transparent.png'); await p.waitForTimeout(2000); await p.getByText(/More options/).first().click(); await p.waitForTimeout(500);
 const run = async () => { await p.addScriptTag({ content: AXE }); return p.evaluate(async () => (await axe.run(document.querySelector('main'), { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'] }, resultTypes: ['violations'] })).violations.map(v => ({ id: v.id, impact: v.impact, count: v.nodes.length, sample: v.nodes.slice(0, 6).map(n => n.target.join(' ') + ' :: ' + n.html.slice(0, 120)) }))); };
 R.loaded = await run();
 const snap = await p.accessibility?.snapshot?.().catch(() => null);
 R.names = await p.evaluate(() => [...document.querySelectorAll('main [role=switch], main [role=slider], main input[type=text], main input[type=color], main [role=checkbox]')].map(e => { const lb = e.getAttribute('aria-labelledby'); const lab = e.id ? document.querySelector(`label[for="${e.id}"]`) : null; return { id: e.id, role: e.getAttribute('role') || e.type, ariaLabel: e.getAttribute('aria-label'), labelledby: lb ? (document.getElementById(lb)?.innerText || '') : null, labelFor: lab ? lab.innerText.trim().slice(0, 50) : null }; }));
 await p.screenshot({ path: BASE + 'live/loaded-more-options.png', fullPage: true });
 fs.writeFileSync(BASE + 'live/axe-loaded.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
