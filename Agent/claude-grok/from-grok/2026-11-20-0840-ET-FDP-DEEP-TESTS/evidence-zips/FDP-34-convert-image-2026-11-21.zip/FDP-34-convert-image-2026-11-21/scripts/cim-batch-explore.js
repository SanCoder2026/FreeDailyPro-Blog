// convert-image: open batch mode, add 3 files, dump the UI (no Convert all). Guest.
const { chromium } = require('playwright'); const BASE = '/workspace/deep/34-convert-image/'; const TF = BASE + 'testfiles/';
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); p.setDefaultTimeout(15000);
 await p.goto('https://www.freedailypro.com/tool/convert-image', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500);
 await p.getByTestId('convert-several').click(); await p.waitForTimeout(1000);
 console.log('inputs', await p.locator('main input[type=file]').count());
 await p.locator('main input[type=file]').first().setInputFiles([TF + 'T01_logo_transparent.png', TF + 'T03_lossy.webp', TF + 'T07_old.bmp', TF + 'T12_notimage.png']); await p.waitForTimeout(1500);
 console.log(await p.evaluate(() => { const t = document.querySelector('main').innerText; const i = t.indexOf('Trial:'); return t.slice(i, i + 1500); }));
 console.log(JSON.stringify(await p.evaluate(() => [...document.querySelectorAll('main button, main input, main [role=combobox]')].map(e => (e.getAttribute('aria-label') || e.innerText || e.type || '').trim().slice(0, 40) + (e.disabled ? ' [disabled]' : '')).slice(0, 40))));
 await p.screenshot({ path: BASE + 'live/batch-ui.png', fullPage: false }); await b.close(); })();
