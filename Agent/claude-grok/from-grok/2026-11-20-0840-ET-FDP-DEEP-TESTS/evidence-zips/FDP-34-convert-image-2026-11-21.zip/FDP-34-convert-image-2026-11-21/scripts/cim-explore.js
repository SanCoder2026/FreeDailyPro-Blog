// convert-image: one Convert (T01 -> JPEG) and dump the result area + blob URLs; no Download. Guest.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/34-convert-image/'; const OUT = BASE + 'live/';
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(15000);
 await p.goto('https://www.freedailypro.com/tool/convert-image', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000);
 await p.locator('main input[type=file]').first().setInputFiles(BASE + 'testfiles/T01_logo_transparent.png'); await p.waitForTimeout(2000);
 await p.getByRole('button', { name: 'Convert', exact: true }).click(); await p.waitForTimeout(3000);
 const R = { ls: await p.evaluate(() => localStorage.getItem('fdp-usage-v1')).then(s => JSON.parse(s).usageToday) };
 R.text = await p.evaluate(() => { const t = document.querySelector('main').innerText; const i = t.indexOf('T01_'); return t.slice(i, i + 1200); });
 R.blobs = await p.evaluate(() => [...document.querySelectorAll('main img, main a')].map(e => e.tagName + ' ' + (e.src || e.href || '')).filter(s => /blob:|data:/.test(s)).map(s => s.slice(0, 80)));
 R.buttons = await p.evaluate(() => [...document.querySelectorAll('main button')].map(e => (e.getAttribute('aria-label') || e.innerText).trim().slice(0, 40)).filter(Boolean).slice(0, 30));
 R.html = await p.evaluate(() => { const el = [...document.querySelectorAll('[data-testid=convert-size]')][0]; return el ? el.parentElement.outerHTML.slice(0, 3000) : null; });
 await p.screenshot({ path: OUT + 'explore-result.png' });
 console.log(JSON.stringify(R, null, 1)); await b.close(); })();
