// convert-image gate: find a fresh context with uses left (max 8), then single Convert/Download (x2), GIF all-frames ZIP Download, batch Convert all,
// Drive/cloud (stop at sign-in), reload. Then in a context at 0: Download -> cap dialog -> Buy Day Pass -> email prompt (types nothing), batch Convert all at 0,
// Quick Buy day/monthly (stop at email / Stripe). Keyboard reach of the drop zone. Guest.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const crypto = require('crypto');
const BASE = '/workspace/deep/34-convert-image/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/convert-image';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex').slice(0, 16);
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_[REDACTED]').replace(/#.*$/, '#REDACTED').slice(0, 160);
(async () => { const b = await chromium.launch(); const R = { t: now(), tries: [] };
 const open = async () => { const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await c.newPage(); p.setDefaultTimeout(15000); await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); return [c, p]; };
 const used = p => p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 const dialog = async p => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async p => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 const load = async (p, f) => { await p.locator('main input[type=file]').first().setInputFiles(TF + f); await p.waitForTimeout(2500); };
 const convert = async p => { await p.getByRole('button', { name: 'Convert', exact: true }).click(); await p.waitForSelector('[data-testid=convert-size],[data-testid=convert-frames-zip]', { timeout: 60000 }); await p.waitForTimeout(600); };
 const preview = async (p, name) => { const g = await p.evaluate(async () => { const im = [...document.querySelectorAll('main img')].find(i => i.src.startsWith('blob:')); if (!im) return null; const bl = await (await fetch(im.src)).blob(); const a = new Uint8Array(await bl.arrayBuffer()); let s = ''; for (let i = 0; i < a.length; i += 0x8000) s += String.fromCharCode(...a.subarray(i, i + 0x8000)); return btoa(s); }); if (!g) return null; const f = OUT + 'downloads/' + name; fs.writeFileSync(f, Buffer.from(g, 'base64')); return { file: f, bytes: fs.statSync(f).size, sha: sha(f) }; };
 const act = async (c, p, name, loc) => { const r = { before: await used(p) }; if (!(await loc.count())) { r.missing = true; return r; }
   const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); const dl = p.waitForEvent('download', { timeout: 8000 }).catch(() => null); const url0 = p.url(); await loc.first().click(); const [pg, d] = await Promise.all([pop, dl]); await p.waitForTimeout(2000);
   r.dialog = await dialog(p); r.after = await used(p); r.url = p.url() !== url0 ? red(p.url()) : null; r.toasts = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim()));
   if (d) { r.download = d.suggestedFilename(); const f = OUT + 'downloads/gate-' + name + '-' + d.suggestedFilename(); await d.saveAs(f); r.file = f; r.bytes = fs.statSync(f).size; r.sha = sha(f); }
   if (pg) { await pg.waitForLoadState('domcontentloaded').catch(() => {}); r.popup = red(pg.url()); r.popupTitle = await pg.title().catch(() => null); await pg.close(); }
   if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + '.png' });
   if (r.dialog && /Day Pass/.test(r.dialog) && !R.dayPassFromCap) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.dayPassFromCap = { from: name, dialog: await dialog(p), emailField: await p.locator('input[type=email]').count(), url: red(p.url()) }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); } }
   await esc(p); if (r.url) { await p.goBack().catch(() => {}); await p.waitForTimeout(2500); } return r; };
 // 1) find uses left
 let c, p; for (let i = 0; i < 14; i++) { [c, p] = await open(); const u = await used(p); R.tries.push({ i, t: now(), used: u }); if (u < 10) break; await c.close(); c = null; }
 if (c) { const L = R.left = { t: now(), start: await used(p) };
  await load(p, 'T02_photo_exif_gps_orient6.jpg'); L.afterLoad = await used(p); await convert(p); L.afterConvert = await used(p); L.dlLabels = await p.evaluate(() => [...document.querySelectorAll('main button')].map(e => e.innerText.trim()).filter(x => /Download|Day Pass|trial/i.test(x)));
  L.preview = await preview(p, 'gate-preview-T02.png');
  L.download1 = await act(c, p, 'dl1', p.getByRole('button', { name: /^Download$/ }));
  L.download2 = await act(c, p, 'dl2', p.getByRole('button', { name: /^Download$/ }));
  L.drive = await act(c, p, 'drive', p.getByRole('button', { name: /Save to Google Drive/ }));
  L.cloud = await act(c, p, 'cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
  await p.getByRole('button', { name: 'New' }).click(); await load(p, 'T06_animated_5f.gif'); await p.getByText(/All 5 frames/).click(); await convert(p); L.afterGifConvert = await used(p);
  L.gifZip = await act(c, p, 'gifzip', p.getByRole('button', { name: /^Download$/ }));
  await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); L.afterReload = await used(p);
  await p.getByTestId('convert-several').click(); await p.waitForTimeout(800); await p.locator('main input[type=file]').first().setInputFiles([TF + 'T01_logo_transparent.png', TF + 'T03_lossy.webp', TF + 'T07_old.bmp', TF + 'T12_notimage.png', TF + 'T15_photo été #1.png']); await p.waitForTimeout(1500);
  L.batch = await act(c, p, 'batch', p.getByRole('button', { name: 'Convert all' })); await p.waitForTimeout(3000); L.batch.after2 = await used(p);
  L.batchList = await p.evaluate(() => { const t = document.querySelector('main').innerText; const i = t.search(/\d+ in, \d+ out/); return i < 0 ? t.slice(t.indexOf('selected'), t.indexOf('selected') + 600) : t.slice(i, i + 600); });
  await p.screenshot({ path: OUT + 'batch-done.png' });
  await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); L.afterReload2 = await used(p); L.t2 = now(); await c.close(); }
 // 2) at 0
 for (let i = 0; i < 4; i++) { [c, p] = await open(); if (await used(p) >= 10) break; await c.close(); } const Z = R.zero = { t: now(), start: await used(p) };
 let chooser = false; p.on('filechooser', () => { chooser = true; }); const seq = [];
 for (let i = 0; i < 40; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('role') || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50).replace(/\n/g, ' '); }); seq.push(a); if (/Drop an image/i.test(a)) { await p.keyboard.press('Enter'); await p.waitForTimeout(1200); seq.push('ENTER -> chooser=' + chooser); break; } }
 Z.kbd = { tabs: seq.length, last: seq.slice(-3), chooser };
 if (Z.start >= 10) { await load(p, 'T01_logo_transparent.png'); await convert(p); Z.afterConvert = await used(p);
  Z.download = await act(c, p, 'zero-dl', p.getByRole('button', { name: /^Download$/ }));
  Z.dayPassBtn = await act(c, p, 'zero-daypassbtn', p.getByRole('button', { name: /Get a Day Pass to download/ }));
  await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  await p.getByTestId('convert-several').click(); await p.waitForTimeout(800); await p.locator('main input[type=file]').first().setInputFiles([TF + 'T01_logo_transparent.png', TF + 'T03_lossy.webp']); await p.waitForTimeout(1500);
  Z.batch = await act(c, p, 'zero-batch', p.getByRole('button', { name: 'Convert all' })); Z.end = await used(p);
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  const qb = p.getByRole('button', { name: 'Quick Buy' }); const u0 = p.url(); await qb.first().click(); await p.waitForTimeout(3000); Z.qbDay = { url: p.url() !== u0 ? red(p.url()) : null, dialog: await dialog(p), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await esc(p);
  if (p.url() !== u0) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); }
  await p.getByRole('button', { name: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); Z.qbMonth = { url: red(p.url()), dialog: await dialog(p), title: await p.title(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' }); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
