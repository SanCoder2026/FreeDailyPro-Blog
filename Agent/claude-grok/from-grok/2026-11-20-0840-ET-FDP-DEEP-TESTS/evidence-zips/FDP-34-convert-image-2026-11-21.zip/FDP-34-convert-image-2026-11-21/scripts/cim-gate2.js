// convert-image: is Download charged per file or once per page load? Find a context with uses left (max 14), then in one page:
// T01->JPEG Download, New, T03->JPEG Download, New, T07->PNG Download; reload; T06 all-frames ZIP Download first; New; T09 Download. Records usageToday around each. Guest.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/34-convert-image/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/convert-image';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const R = { t: now(), tries: [], steps: [] }; let c, p;
 const used = () => p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 for (let i = 0; i < 14; i++) { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); p = await c.newPage(); p.setDefaultTimeout(15000); await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); const u = await used(); R.tries.push(u); if (u < 10) break; await c.close(); c = null; }
 if (!c) { R.note = 'no context with uses left'; } else {
  const step = async (label, file, gifAll) => { const s = { label, file, before: await used() };
   await p.locator('main input[type=file]').first().setInputFiles(TF + file); await p.waitForTimeout(2500);
   if (gifAll) await p.getByText(/All \d+ frames/).click();
   await p.getByRole('button', { name: 'Convert', exact: true }).click(); await p.waitForSelector('[data-testid=convert-size],[data-testid=convert-frames-zip]', { timeout: 60000 }); await p.waitForTimeout(600); s.afterConvert = await used();
   const dl = p.waitForEvent('download', { timeout: 8000 }).catch(() => null); await p.getByRole('button', { name: /^Download$/ }).click(); const d = await dl; await p.waitForTimeout(1500);
   s.download = d ? d.suggestedFilename() : null; if (d) await d.saveAs(OUT + 'downloads/gate2-' + label + '-' + d.suggestedFilename());
   s.dialog = await p.locator('[role=dialog]').count() ? (await p.locator('[role=dialog]').first().innerText()).slice(0, 200) : null; s.after = await used(); s.t = now(); R.steps.push(s); console.log(JSON.stringify(s));
   for (let i = 0; i < 2; i++) await p.keyboard.press('Escape'); const nw = p.getByRole('button', { name: 'New' }); if (await nw.count()) await nw.click(); await p.waitForTimeout(800); };
  await step('A', 'T01_logo_transparent.png'); await step('B', 'T03_lossy.webp'); await step('C', 'T07_old.bmp');
  await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); R.afterReload = await used();
  await step('D_gif_all', 'T06_animated_5f.gif', true); await step('E', 'T09_sized.svg');
  await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); R.end = await used(); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate2.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify({ tries: R.tries, afterReload: R.afterReload, end: R.end, note: R.note })); await b.close(); })();
