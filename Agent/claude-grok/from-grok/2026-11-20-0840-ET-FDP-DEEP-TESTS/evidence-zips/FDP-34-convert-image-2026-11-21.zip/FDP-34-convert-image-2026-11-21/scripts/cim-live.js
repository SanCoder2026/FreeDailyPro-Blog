// convert-image: one fresh page per case; load a synthetic file, set format/options, Convert, read the on-page result (preview blob, size line, toasts).
// No Download / Drive / cloud clicks here. Request scan for uploads. Guest. Usage: node cim-live.js [caseId,...]
const { chromium, firefox } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/34-convert-image/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const CASES = [
 ['C01', 'T01_logo_transparent.png', { fmt: null }],
 ['C02', 'T01_logo_transparent.png', { fmt: 'JPEG', fill: '#ff0000' }],
 ['C03', 'T01_logo_transparent.png', { fmt: 'WebP' }],
 ['C04', 'T01_logo_transparent.png', { fmt: 'GIF' }],
 ['C05', 'T01_logo_transparent.png', { fmt: 'BMP' }],
 ['C06', 'T01_logo_transparent.png', { fmt: 'ICO' }],
 ['C07', 'T01_logo_transparent.png', { fmt: 'TIFF' }],
 ['C08', 'T02_photo_exif_gps_orient6.jpg', { fmt: null }],
 ['C09', 'T02_photo_exif_gps_orient6.jpg', { fmt: 'JPEG', keep: true }],
 ['C10', 'T02_photo_exif_gps_orient6.jpg', { fmt: 'JPEG' }],
 ['C11', 'T02_photo_exif_gps_orient6.jpg', { fmt: 'JPEG', dpi: '150' }],
 ['C12', 'T03_lossy.webp', { fmt: null }],
 ['C13', 'T04_animated.webp', { fmt: 'PNG' }],
 ['C14', 'T05_photo.avif', { fmt: null }],
 ['C15', 'T06_animated_5f.gif', { fmt: null }],
 ['C16', 'T06_animated_5f.gif', { fmt: 'PNG', allFrames: true }],
 ['C17', 'T07_old.bmp', { fmt: null }],
 ['C18', 'T08_2page.tiff', { fmt: null }],
 ['C19', 'T09_sized.svg', { fmt: null }],
 ['C20', 'T10_nosize_script.svg', { fmt: 'PNG' }],
 ['C21', 'T11_iphone.heic', { fmt: null }],
 ['C22', 'T12_notimage.png', { fmt: null }],
 ['C23', 'T13_truncated.jpg', { fmt: null }],
 ['C24', 'T14_big_6000x4000.jpg', { fmt: 'WebP' }],
 ['C25', 'T14_big_6000x4000.jpg', { fmt: 'JPEG', w: '1920' }],
 ['C26', 'T16_square_64.png', { fmt: 'PNG', w: '512', noEnlarge: true }],
 ['C27', 'T16_square_64.png', { fmt: 'PNG', w: '512' }],
 ['C28', 'T03_lossy.webp', { fmt: 'PNG', rotate: /90/, gray: true, flop: true }],
 ['C29', 'T15_photo été #1.png', { fmt: 'JPEG' }],
 ['C30', 'T01_logo_transparent.png', { fmt: 'JPEG', quality: 'min' }],
 ['C31', 'T14_big_6000x4000.jpg', { fmt: 'JPEG', w: 'abc' }],
 ['C32', 'T01_logo_transparent.png', { fmt: 'AVIF' }],
];
const only = process.argv[2] ? process.argv[2].split(',') : null; const engine = process.argv[3] === 'firefox' ? firefox : process.argv[3] === 'webkit' ? require('playwright').webkit : chromium;
(async () => {
 const b = await engine.launch(); const ALL = { t: now(), engine: process.argv[3] || 'chromium', cases: [] };
 for (const [id, file, o] of CASES) { if (only && !only.includes(id)) continue;
  const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(15000);
  const reqs = []; p.on('request', r => { const d = r.postDataBuffer(); if (d && d.length > 2000) reqs.push(r.method() + ' ' + r.url().slice(0, 100) + ' ' + d.length); if (!/freedailypro|google|doubleclick|adtraffic|ytimg|producthunt|gstatic/.test(r.url())) reqs.push('3P ' + r.url().slice(0, 100)); });
  const dialogs = []; p.on('dialog', d => { dialogs.push(d.message()); d.dismiss(); });
  const toasts = []; const grab = async () => { (await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim()))).forEach(x => { if (!toasts.includes(x)) toasts.push(x); }); };
  const R = { id, file, o: JSON.parse(JSON.stringify(o, (k, v) => v instanceof RegExp ? String(v) : v)), t: now() };
  try {
   await p.goto('https://www.freedailypro.com/tool/convert-image', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500);
   R.used0 = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
   await p.locator('main input[type=file]').first().setInputFiles(TF + file); await p.waitForTimeout(2500); await grab();
   R.loaded = await p.evaluate(() => { const t = document.querySelector('main').innerText; const i = t.indexOf('Convert to'); return i < 0 ? null : t.slice(i, i + 700); });
   R.defaultFmt = await p.evaluate(() => document.querySelector('[aria-label="Convert to format"]')?.innerText.trim() || null);
   if (R.loaded) {
    if (o.fmt) { await p.getByRole('combobox', { name: 'Convert to format' }).click(); await p.waitForTimeout(300); const opt = p.getByRole('option', { name: new RegExp('^' + o.fmt) }); R.optDisabled = await opt.first().getAttribute('aria-disabled'); await opt.first().click({ timeout: 4000 }).catch(e => { R.fmtErr = String(e).slice(0, 100); }); await p.keyboard.press('Escape').catch(() => {}); await p.waitForTimeout(400); }
    R.fmtNow = await p.evaluate(() => document.querySelector('[aria-label="Convert to format"]')?.innerText.trim());
    if (o.fill) await p.locator('#bg-color').fill(o.fill);
    if (o.quality === 'min') { const s = p.locator('main [role=slider]').first(); await s.focus(); for (let i = 0; i < 80; i++) await s.press('ArrowLeft'); }
    if (o.allFrames) { const a = p.getByText(/All \d+ frames|every frame|All frames/i).first(); if (await a.count()) await a.click().catch(() => {}); R.frameChoice = await p.evaluate(() => { const t = document.querySelector('main').innerText; const i = t.search(/frame/i); return t.slice(Math.max(0, i - 200), i + 300); }); }
    const more = p.getByText(/More options/).first(); if ((o.w || o.keep || o.dpi || o.rotate || o.gray || o.flop || o.noEnlarge) && await more.count()) { await more.click().catch(() => {}); await p.waitForTimeout(500); }
    if (o.w) await p.locator('#cv-w').fill(o.w);
    if (o.noEnlarge) await p.locator('#cv-noenlarge').click();
    if (o.keep) await p.locator('#cv-keep').click();
    if (o.dpi) await p.locator('#cv-dpi').fill(o.dpi);
    if (o.gray) await p.locator('#cv-gray').click();
    if (o.flop) await p.locator('#cv-flop').click();
    if (o.rotate) { await p.getByRole('combobox', { name: 'Rotate' }).click(); await p.waitForTimeout(300); R.rotateOpts = await p.evaluate(() => [...document.querySelectorAll('[role=option]')].map(x => x.innerText)); await p.getByRole('option', { name: o.rotate }).first().click(); }
    R.icoBmp = await p.evaluate(() => { const t = document.querySelector('main').innerText; const m = t.match(/(Icon sizes|sizes)[\s\S]{0,200}|24-bit[\s\S]{0,120}/); return m ? m[0] : null; });
    const conv = p.getByRole('button', { name: 'Convert', exact: true }); R.convertDisabled = await conv.isDisabled().catch(() => null); R.validation = await p.evaluate(() => [...document.querySelectorAll('main [role=alert], main .text-destructive')].map(e => e.innerText.trim()).filter(Boolean));
    if (!R.convertDisabled) { const t0 = Date.now(); await conv.click();
     await p.waitForFunction(() => /Result:|images in one ZIP|frames/.test(document.querySelector('main').innerText) && !!document.querySelector('[data-testid=convert-size], [data-testid=convert-frames-zip]'), null, { timeout: 120000 }).catch(() => {});
     R.ms = Date.now() - t0; await p.waitForTimeout(700); await grab();
     R.result = await p.evaluate(() => { const e = document.querySelector('[data-testid=convert-size], [data-testid=convert-frames-zip]'); return e ? e.innerText : null; });
     const info = await p.evaluate(async () => { const im = [...document.querySelectorAll('main img')].find(i => i.src.startsWith('blob:')); if (!im) return null; const bl = await (await fetch(im.src)).blob(); const a = new Uint8Array(await bl.arrayBuffer()); let s = ''; for (let i = 0; i < a.length; i += 0x8000) s += String.fromCharCode(...a.subarray(i, i + 0x8000)); return { type: bl.type, size: bl.size, w: im.naturalWidth, h: im.naturalHeight, alt: im.alt, b64: btoa(s) }; });
     if (info) { const ext = (info.type.split('/')[1] || 'bin').replace('jpeg', 'jpg').replace('x-icon', 'ico').replace('vnd.microsoft.icon', 'ico').replace('svg+xml', 'svg'); const f = OUT + 'downloads/' + id + '_preview.' + ext; fs.writeFileSync(f, Buffer.from(info.b64, 'base64')); delete info.b64; R.preview = { ...info, saved: f }; }
     R.dlLabel = await p.evaluate(() => [...document.querySelectorAll('main button, main a')].map(e => e.innerText.trim()).filter(x => /Download|Day Pass|trial/.test(x)));
    }
   }
   R.used1 = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
   await p.screenshot({ path: OUT + 'case-' + id + '.png' });
  } catch (e) { R.err = String(e).slice(0, 300); }
  R.toasts = toasts; R.dialogs = dialogs; R.reqs = reqs; console.log(JSON.stringify(R)); ALL.cases.push(R); await c.close(); }
 ALL.t2 = now(); fs.writeFileSync(OUT + 'cases-' + (process.argv[3] || 'chromium') + (only ? '-' + only.join('_').slice(0, 40) : '') + '.json', JSON.stringify(ALL, null, 1)); await b.close(); })();
