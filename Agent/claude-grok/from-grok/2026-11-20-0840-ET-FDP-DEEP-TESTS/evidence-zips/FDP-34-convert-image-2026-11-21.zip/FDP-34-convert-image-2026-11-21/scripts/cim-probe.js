// convert-image probe: starting count, controls before/after loading T01 and after More options; Convert (no Download). Guest.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/34-convert-image/'; const OUT = BASE + 'live/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const ctl = p => p.evaluate(() => [...document.querySelectorAll('main button, main input, main select, main [role=combobox], main [role=checkbox], main [role=switch], main [role=slider], main [role=radio]')].map(e => ({ tag: e.tagName, type: e.type || e.getAttribute('role') || '', id: e.id, testid: e.getAttribute('data-testid'), name: (e.getAttribute('aria-label') || e.innerText || e.value || '').trim().slice(0, 50), label: e.labels && e.labels[0] ? e.labels[0].innerText.trim().slice(0, 50) : null, val: e.value || e.getAttribute('aria-valuenow') || null, checked: e.checked ?? e.getAttribute('aria-checked') })).filter(x => !/About|Common|Details|Guides|Share this|Create Shortcut|Subscribe|Watch|\?$/.test(x.name)));
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(15000); const R = { t: now(), req: [] };
 p.on('request', r => { const d = r.postDataBuffer(); if (!/google|doubleclick|adtraffic|ytimg|producthunt/.test(r.url())) R.req.push(r.method() + ' ' + r.url().slice(0, 120) + (d ? ' post=' + d.length : '')); });
 await p.goto('https://www.freedailypro.com/tool/convert-image', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000);
 R.ls = await p.evaluate(() => localStorage.getItem('fdp-usage-v1')); R.strip = await p.evaluate(() => (document.body.innerText.match(/Trial:[^\n]*/) || [''])[0]);
 R.c0 = await ctl(p); await p.screenshot({ path: OUT + 'probe.png' });
 await p.locator('main input[type=file]').first().setInputFiles(BASE + 'testfiles/T01_logo_transparent.png'); await p.waitForTimeout(2500);
 R.c1 = await ctl(p); R.area1 = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 2500)); await p.screenshot({ path: OUT + 'probe-loaded.png', fullPage: false });
 const mo = p.getByRole('button', { name: /More options/ }); if (await mo.count()) { await mo.first().click(); await p.waitForTimeout(800); }
 R.c2 = await ctl(p); await p.screenshot({ path: OUT + 'probe-more.png', fullPage: true });
 R.selects = await p.evaluate(() => [...document.querySelectorAll('main select')].map(s => ({ id: s.id, opts: [...s.options].map(o => o.value + '=' + o.text + (o.disabled ? ' (disabled)' : '')) })));
 R.combos = []; for (const cb of await p.locator('main [role=combobox]').all()) { await cb.click().catch(() => {}); await p.waitForTimeout(400); R.combos.push(await p.evaluate(() => [...document.querySelectorAll('[role=option]')].map(o => o.innerText.trim() + (o.getAttribute('aria-disabled') === 'true' ? ' (disabled)' : '')))); await p.keyboard.press('Escape'); }
 R.ls2 = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
 fs.writeFileSync(OUT + 'probe.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
