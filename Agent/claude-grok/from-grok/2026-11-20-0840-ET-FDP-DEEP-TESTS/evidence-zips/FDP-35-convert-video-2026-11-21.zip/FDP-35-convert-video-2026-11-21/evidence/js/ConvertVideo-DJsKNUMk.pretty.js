import { r as n, j as t } from "./vendor-react-D01g8YgM.js";
import { l as _ } from "./utils-qgqMjnRG.js";
import {
  p as q,
  T as D,
  F as U,
  o as K,
  q as H,
  r as $,
  R as Q,
  D as Z,
} from "./ToolPage-DwLoDncN.js";
import { f as T, e as J, b as X, B as g } from "./index-B1CTyGtY.js";
import {
  S as Y,
  a as ee,
  b as te,
  c as oe,
  d as se,
} from "./select-ic5yaeGw.js";
import { T as re } from "./ToolInfoSection-C0i6Zbwo.js";
import { u as ie } from "./UsageAndUpgradeStrip-B1CY210m.js";
import { C as ae, d as ne } from "./operations-P8Ty5WBe.js";
import { F as le, V as ce, s as me } from "./uiHelpers-BQOK1Ksf.js";
import {
  formatBytes as h,
  checkFileSize as de,
  stopProcessing as ue,
  loadFFmpeg as pe,
  fetchFile as fe,
  ffmpegOutputToBlob as he,
  resetFFmpegEngine as ve,
} from "./ffmpegEngine-DH91Xnxx.js";
import { u as we } from "./useConverterPair-rg6H4-hf.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./chevron-up-BDUcPssj.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./scriptFonts-B9baRZsf.js";
import "./progress-Y72GQ7li.js";
import "./square-DmBnvOHU.js";
const xe =
  "MP4, MOV, MKV, AVI, WebM, WMV, FLV, 3GP, animated GIF and similar files";
function ge(e, o) {
  return e > 0 ? Math.round(((o - e) / e) * 100) : 0;
}
function be(e) {
  const o = ge(e.inBytes, e.outBytes),
    s = (e.fileName.match(/\.([^.]+)$/)?.[1] ?? "video").toUpperCase(),
    r = e.format === "mp4-web" ? "MP4 (web)" : e.format.toUpperCase(),
    v = e.rewrapped
      ? "the picture and sound were copied into the new format without re-encoding, so the quality is unchanged and the size hardly moves"
      : "re-encoded",
    l = /webm$/i.test(e.fileName),
    d =
      !e.rewrapped && o > 25 && l && e.format.startsWith("mp4")
        ? " MP4 (H.264) is often larger than WebM for the same picture quality — that is normal."
        : "";
  return `${s} ${h(e.inBytes)} → ${r} ${h(e.outBytes)} (${o >= 0 ? "+" : ""}${o}%), ${v}.${d}`;
}
function k(e, o) {
  const s = (e.match(/\.([^.]+)$/)?.[1] ?? "").toLowerCase();
  return (o === "mp4" || o === "mp4-web") && (s === "mp4" || s === "m4v")
    ? "This file is already an MP4. Both MP4 choices write the same fast-start MP4, so converting changes little; pick WebM or MOV if you need a different format."
    : o === "mov" && s === "mov"
      ? "This file is already a MOV. Pick MP4 for a file that plays on more devices."
      : o === "mkv" && s === "mkv"
        ? "This file is already an MKV. Pick MP4 for a file that plays on phones and in QuickTime."
        : o === "avi" && s === "avi"
          ? "This file is already an AVI. It would be re-encoded for no gain; pick MP4 instead."
          : o === "webm" && s === "webm"
            ? "This file is already a WebM. It would be re-encoded at lower quality for no gain; pick MP4 instead."
            : null;
}
const b = {
    what: "Converts a video between MP4, web-optimized MP4 (fast-start for HTML5), WebM, MOV, MKV and AVI, and turns an animated GIF into a video. Prefer “MP4 for web” for sites; use WebM only when you specifically need a .webm file, and AVI only for older players. A video already in H.264 with AAC sound is repackaged into MP4, MOV or MKV in seconds without any quality loss. Runs entirely in your browser — the video never leaves your device.",
    how: "Upload your video (or an animated GIF), choose the format you want to convert it to, and download the converted file once processing finishes.",
    tip: "For websites and embeds, choose “MP4 for web” (fast-start). WebM works in modern browsers but is slower to encode in-browser; use a short clip if it feels stuck. Because WebM and AVI are always re-encoded, short clips often come out larger than the original.",
  },
  M = ae;
function Me(e, o) {
  const s = e.replace(/\.[^.]+$/, "");
  return (e.match(/\.([^.]+)$/)?.[1] ?? "").toLowerCase() === o
    ? `${s}_converted.${o}`
    : `${s}.${o}`;
}
const S = (e) => M.find((o) => o.value === e)?.ext ?? e,
  ye = (e) => e.type === "image/gif" || /\.gif$/i.test(e.name);
function at() {
  const [e, o] = n.useState(null),
    s = we("convert-video"),
    [r, v] = n.useState(s ? q(s) : "mp4"),
    [l, d] = n.useState(!1),
    [O, y] = n.useState(0),
    [A, u] = n.useState(""),
    [c, p] = n.useState(null),
    [P, j] = n.useState(""),
    { isPro: F, isLoading: I, isAdmin: E } = ie(),
    m = n.useRef(null),
    V = n.useRef(null),
    W = n.useCallback((a) => {
      const i = a[0];
      if (i) {
        if (!_(i) && !ye(i)) {
          T.error(`"${i.name}" isn't a video file`);
          return;
        }
        (o(i), p(null), j(""));
      }
    }, []),
    w = e ? de([e], F || I, E) : null,
    R = () => {
      (V.current?.abort(), m.current && ue(m.current));
    },
    L = async () => {
      if (!e) return;
      (d(!0), y(0));
      const a = new AbortController();
      V.current = a;
      try {
        u("Loading video engine...");
        const i = await pe((x) => u(x));
        ((m.current = i), u("Reading video file..."));
        const C = e.name.match(/\.([^.]+)$/)?.[1] || "mp4";
        (await i.writeFile(`input.${C}`, await fe(e)),
          u(`Converting to ${r.toUpperCase()}...`));
        const z = S(r),
          { data: B, rewrapped: N } = await ne(
            i,
            `input.${C}`,
            `output.${z}`,
            r,
            y,
            a.signal,
          ),
          G = M.find((x) => x.value === r)?.mime || "video/mp4",
          f = he(B, G);
        (p(f),
          j(
            be({
              fileName: e.name,
              inBytes: e.size,
              outBytes: f.size,
              format: r,
              rewrapped: N,
            }),
          ),
          T.success(
            N
              ? `Converted in seconds without re-encoding (no quality loss): ${h(f.size)}`
              : `Video converted: ${h(f.size)}`,
          ));
      } catch (i) {
        me(i);
      } finally {
        (m.current && ve(m.current), d(!1));
      }
    };
  return t.jsxs(D, {
    children: [
      e
        ? t.jsxs("div", {
            className: "space-y-4",
            children: [
              t.jsx("div", {
                className: "p-4 rounded-lg border bg-card",
                children: t.jsx("p", {
                  className: "text-sm font-medium",
                  children: e.name,
                }),
              }),
              w && t.jsx(le, { check: w, isPro: F }),
              t.jsxs("div", {
                children: [
                  t.jsx(J, { children: "Output Format" }),
                  t.jsxs(Y, {
                    value: r,
                    onValueChange: (a) => {
                      (v(a), p(null));
                    },
                    children: [
                      t.jsx(ee, {
                        className: "w-full sm:w-64",
                        children: t.jsx(te, {}),
                      }),
                      t.jsx(oe, {
                        children: M.map((a) =>
                          t.jsx(
                            se,
                            { value: a.value, children: a.label },
                            a.value,
                          ),
                        ),
                      }),
                    ],
                  }),
                  $(s, e.name) &&
                    t.jsx("p", {
                      className: "text-xs text-muted-foreground mt-1",
                      "data-testid": "pair-mismatch",
                      children: $(s, e.name),
                    }),
                  r === "avi" &&
                    t.jsx("p", {
                      className: "text-xs text-muted-foreground mt-1",
                      "data-testid": "avi-note",
                      children:
                        "AVI is re-encoded to older MPEG-4 video, so the file is usually larger than the MP4. Choose it only for players that need it.",
                    }),
                  k(e.name, r) &&
                    t.jsx("p", {
                      className: "text-xs text-muted-foreground mt-1",
                      "data-testid": "same-format-note",
                      children: k(e.name, r),
                    }),
                  r === "webm" &&
                    t.jsx("p", {
                      className: "text-xs text-muted-foreground mt-1",
                      "data-testid": "webm-note",
                      children:
                        "Short clips often get bigger as WebM, because the video is re-encoded rather than just repackaged.",
                    }),
                ],
              }),
              l && t.jsx(ce, { progress: O, statusMessage: A, onStop: R }),
              c &&
                P &&
                t.jsx("p", {
                  className: "text-sm",
                  "data-testid": "convert-summary",
                  children: P,
                }),
              c && t.jsx(Q, { blob: c }),
              c &&
                t.jsxs("p", {
                  className: "text-xs text-muted-foreground",
                  children: [
                    "Want only the sound? ",
                    t.jsx(X, {
                      href: "/tool/extract-audio",
                      className: "underline",
                      children: "Extract Audio",
                    }),
                    " saves it as MP3, WAV, M4A, OGG or FLAC.",
                  ],
                }),
              t.jsx("div", {
                className: "flex gap-3",
                children: c
                  ? t.jsxs(t.Fragment, {
                      children: [
                        t.jsx(Z, { blob: c, fileName: Me(e.name, S(r)) }),
                        t.jsx(g, {
                          variant: "outline",
                          onClick: () => {
                            (o(null), p(null));
                          },
                          children: "New",
                        }),
                      ],
                    })
                  : t.jsxs(t.Fragment, {
                      children: [
                        t.jsx(g, {
                          onClick: L,
                          disabled: l || w?.severity !== "ok",
                          children: l ? "Converting..." : "Convert",
                        }),
                        t.jsx(g, {
                          variant: "outline",
                          onClick: () => o(null),
                          disabled: l,
                          children: "Reset",
                        }),
                      ],
                    }),
              }),
            ],
          })
        : t.jsx(U, {
            gateAtDownload: !0,
            accept: "video/*,image/gif",
            maxSize: 5e3,
            onFiles: W,
            label: s
              ? `Drop ${K(s.from)} file to convert to ${H(s.to).label}`
              : "Drop a video to convert",
            description: `Works with ${xe}. Output: MP4, MP4 for web, WebM, MOV, MKV or AVI.`,
          }),
      t.jsx(re, { whatIsIt: b.what, howToUse: b.how, tip: b.tip }),
    ],
  });
}
export { at as default };
//# sourceMappingURL=ConvertVideo-DJsKNUMk.js.map
