// convert-video gate. Part 1 (uses-left context, max 14 tries): Convert V01->MOV (copy), preview blob vs Download bytes, Download again,
// New + V09->MP4 Download, New + V11->MOV Download (later downloads in the same page load), Drive/cloud (stop at sign-in), reload, V05->MP4 Download, reload.
// Part 2 (context at 0): Convert, Download -> cap dialog -> Buy Day Pass -> email prompt (types nothing); Quick Buy day/monthly (stop); keyboard; preview controlsList. Guest.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const crypto = require('crypto');
const BASE = '/workspace/deep/35-convert-video/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/convert-video';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex').slice(0, 16);
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').slice(0, 160);
(async () => { const b = await chromium.launch(); const R = { t: now(), tries: [] }; let c, p;
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); p = await c.newPage(); p.setDefaultTimeout(15000); await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 const conv = async (file, fmt) => { await p.locator('main input[type=file]').first().setInputFiles(TF + file); await p.waitForTimeout(2000); await p.getByRole('combobox').first().click(); await p.waitForTimeout(300); await p.getByRole('option', { name: new RegExp('^' + fmt) }).first().click(); await p.waitForTimeout(300); await p.getByRole('button', { name: 'Convert', exact: true }).click(); await p.waitForFunction(() => /\(\+?-?\d+%\)/.test(document.querySelector('main').innerText), null, { timeout: 240000 }); await p.waitForTimeout(800); };
 const prev = async name => { const g = await p.evaluate(async () => { const el = document.querySelector('main video[src^="blob:"]'); if (!el) return null; const bl = await (await fetch(el.src)).blob(); const a = new Uint8Array(await bl.arrayBuffer()); let s = ''; for (let i = 0; i < a.length; i += 0x8000) s += String.fromCharCode(...a.subarray(i, i + 0x8000)); return { b64: btoa(s), controls: el.controls, controlsList: el.getAttribute('controlslist') }; }); if (!g) return null; const f = OUT + 'downloads/' + name; fs.writeFileSync(f, Buffer.from(g.b64, 'base64')); return { file: f, bytes: fs.statSync(f).size, sha: sha(f), controls: g.controls, controlsList: g.controlsList }; };
 const act = async (name, loc) => { const r = { before: await used() }; if (!(await loc.count())) { r.missing = true; return r; }
   const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); const dl = p.waitForEvent('download', { timeout: 10000 }).catch(() => null); const url0 = p.url(); await loc.first().click(); const [pg, d] = await Promise.all([pop, dl]); await p.waitForTimeout(2000);
   r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null; r.t = now();
   if (d) { r.download = d.suggestedFilename(); const f = OUT + 'downloads/gate-' + name + '-' + d.suggestedFilename(); await d.saveAs(f); r.bytes = fs.statSync(f).size; r.sha = sha(f); }
   if (pg) { await pg.waitForLoadState('domcontentloaded').catch(() => {}); r.popup = red(pg.url()); r.popupTitle = await pg.title().catch(() => null); await pg.close(); }
   if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + '.png' });
   if (r.dialog && /Day Pass/.test(r.dialog) && !R.dayPassFromCap) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.dayPassFromCap = { from: name, dialog: await dialog(), emailField: await p.locator('input[type=email]').count(), url: red(p.url()) }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); } }
   await esc(); if (r.url) { await p.goBack().catch(() => {}); await p.waitForTimeout(2500); } console.log(name, JSON.stringify(r)); return r; };
 const newBtn = async () => { const n = p.getByRole('button', { name: 'New' }); if (await n.count()) { await n.click(); await p.waitForTimeout(800); } };
 for (let i = 0; i < 14; i++) { await open(); const u = await used(); R.tries.push(u); if (u < 10) break; await c.close(); c = null; }
 if (c) { const L = R.left = { t: now(), start: await used() };
  await conv('V01_h264_aac.mp4', 'MOV'); L.afterConvert = await used(); L.preview = await prev('gate-preview-V01.mov');
  L.dlA = await act('A', p.getByRole('button', { name: /^Download$/ })); L.dlA2 = await act('A2', p.getByRole('button', { name: /^Download$/ }));
  L.drive = await act('drive', p.getByRole('button', { name: /Save to Google Drive/ })); L.cloud = await act('cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
  await newBtn(); await conv('V09.3gp', 'MP4 \\(w'); L.dlB = await act('B', p.getByRole('button', { name: /^Download$/ }));
  await newBtn(); await conv('V11_h264_noaudio.mp4', 'MOV'); L.dlC = await act('C', p.getByRole('button', { name: /^Download$/ }));
  await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); L.afterReload = await used();
  await conv('V05_h264.mkv', 'MP4 \\(w'); L.dlD = await act('D', p.getByRole('button', { name: /^Download$/ }));
  await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); L.end = await used(); L.t2 = now(); await c.close(); }
 for (let i = 0; i < 4; i++) { await open(); if (await used() >= 10) break; await c.close(); }
 const Z = R.zero = { t: now(), start: await used() };
 let chooser = false; p.on('filechooser', () => { chooser = true; }); const seq = [];
 for (let i = 0; i < 40; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('role') || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50).replace(/\n/g, ' '); }); seq.push(a); if (/Drop a video/i.test(a)) { await p.keyboard.press('Enter'); await p.waitForTimeout(1200); seq.push('ENTER -> chooser=' + chooser); break; } }
 Z.kbd = { tabs: seq.length, last: seq.slice(-3), chooser };
 if (Z.start >= 10) { await conv('V01_h264_aac.mp4', 'MOV'); Z.afterConvert = await used(); Z.preview = await prev('gate-zero-preview-V01.mov');
  Z.download = await act('zero-dl', p.getByRole('button', { name: /^Download$/ })); Z.end = await used();
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  const qb = p.getByRole('button', { name: 'Quick Buy' }); const u0 = p.url(); await qb.first().click(); await p.waitForTimeout(3000); Z.qbDay = { url: p.url() !== u0 ? red(p.url()) : null, dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await esc();
  if (p.url() !== u0) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); }
  await p.getByRole('button', { name: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); Z.qbMonth = { url: red(p.url()), dialog: await dialog(), title: await p.title(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' }); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify({ tries: R.tries }, null, 1)); await b.close(); })();
