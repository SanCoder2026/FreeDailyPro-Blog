// convert-video: one reload per case in a shared context (engine cached); load a synthetic file, pick output, Convert, read the summary line and the preview <video> blob (saved). No Download. Guest.
const { chromium, firefox } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/35-convert-video/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const CASES = [['K01','V01_h264_aac.mp4','MP4 (w'],['K02','V01_h264_aac.mp4','MOV'],['K03','V01_h264_aac.mp4','MKV'],['K04','V01_h264_aac.mp4','WebM'],['K05','V01_h264_aac.mp4','AVI'],
 ['K06','V02_h264_aac_1080p.mov','MP4 (w'],['K07','V03_hevc_iphone.mov','MP4 (w'],['K08','V04_vp9_opus.webm','MP4 (w'],['K09','V05_h264.mkv','MP4 (w'],['K10','V06_mpeg4.avi','MP4 (w'],
 ['K11','V07.wmv','MP4 (w'],['K12','V08.flv','MP4 (w'],['K13','V09.3gp','MP4 (w'],['K14','V10_animated.gif','MP4 (w'],['K15','V11_h264_noaudio.mp4','MOV'],['K16','V12_h264_mp3.mp4','MP4 (w'],
 ['K17','A13_audio_only.mp3',null],['K18','X14_text.mp4','MP4 (w'],['K19','V15_vp8_1080p.webm','WebM'],['K20','V16_60s.mp4','WebM'],['K21','V17_over50MB.mp4','MOV'],['K22','V01_h264_aac.mp4','MP4 for web'],['K23','V04_vp9_opus.webm','WebM']];
const only = process.argv[2] && process.argv[2] !== 'all' ? process.argv[2].split(',') : null; const eng = process.argv[3] === 'firefox' ? firefox : chromium;
(async () => { const b = await eng.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(15000);
 const reqs = []; p.on('request', r => { const d = r.postDataBuffer(); if (d && d.length > 20000) reqs.push(r.method() + ' ' + r.url().slice(0, 100) + ' ' + d.length); if (!/freedailypro|google|doubleclick|adtraffic|ytimg|producthunt|gstatic|jsdelivr|^blob:|^data:/.test(r.url())) reqs.push('3P ' + r.url().slice(0, 100)); });
 const ALL = { t: now(), engine: process.argv[3] || 'chromium', cases: [] };
 for (const [id, file, fmt] of CASES) { if (only && !only.includes(id)) continue; const R = { id, file, fmt, t: now() }; const n0 = reqs.length;
  try {
   await p.goto('https://www.freedailypro.com/tool/convert-video', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(3500);
   R.used0 = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
   await p.locator('main input[type=file]').first().setInputFiles(TF + file); await p.waitForTimeout(2000);
   R.toastsLoad = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim()));
   R.loaded = await p.evaluate(f => { const t = document.querySelector('main').innerText; const i = t.indexOf(f); return i < 0 ? null : t.slice(i, i + 500); }, file);
   if (R.loaded && fmt) {
    const cb = p.getByRole('combobox').first(); await cb.click(); await p.waitForTimeout(300); await p.getByRole('option', { name: new RegExp('^' + fmt.replace(/[()]/g, '\\$&')) }).first().click(); await p.waitForTimeout(400);
    R.fmtNow = (await cb.innerText()).trim(); R.note = await p.evaluate(f => { const t = document.querySelector('main').innerText; const i = t.indexOf(f); return t.slice(i, i + 400); }, file);
    const conv = p.getByRole('button', { name: 'Convert', exact: true }); R.disabled = await conv.isDisabled();
    if (!R.disabled) { const t0 = Date.now(); await conv.click(); const stat = [];
     const iv = setInterval(async () => { try { stat.push(await p.evaluate(() => [...document.querySelectorAll('main [role=progressbar], main [role=status]')].map(e => e.getAttribute('aria-valuenow') + ' ' + e.innerText.trim().slice(0, 60)).join(' | '))); } catch (e) {} }, 5000);
     await p.waitForFunction(() => /→|could not|couldn't|failed|Error|error/i.test((document.querySelector('[data-sonner-toast]') || {}).innerText || '') || /\(\+?-?\d+%\)/.test(document.querySelector('main').innerText), null, { timeout: 300000 }).catch(() => {});
     clearInterval(iv); R.ms = Date.now() - t0; R.status = stat.filter(Boolean).slice(0, 8); await p.waitForTimeout(1200);
     R.summary = await p.evaluate(() => (document.querySelector('main').innerText.match(/[A-Z0-9]+ [\d.]+ [KMG]?B → .*/) || [null])[0]);
     R.toasts = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim()));
     const v = await p.evaluate(async () => { const el = document.querySelector('main video[src^="blob:"]'); if (!el) return null; const bl = await (await fetch(el.src)).blob(); const a = new Uint8Array(await bl.arrayBuffer()); let s = ''; for (let i = 0; i < a.length; i += 0x8000) s += String.fromCharCode(...a.subarray(i, i + 0x8000)); return { type: bl.type, size: bl.size, controls: el.controls, controlsList: el.getAttribute('controlsList'), b64: btoa(s) }; });
     if (v) { const f = OUT + 'downloads/' + id + '_preview.' + (fmt.startsWith('MP4') ? 'mp4' : fmt.toLowerCase()); fs.writeFileSync(f, Buffer.from(v.b64, 'base64')); delete v.b64; try { v.probe = cp.execSync(`ffprobe -v error -show_entries stream=codec_type,codec_name,width,height:format=format_name,duration -of compact=p=0 "${f}"`).toString().trim().split('\n'); } catch (e) { v.probe = 'ffprobe failed'; } R.preview = { ...v, saved: f }; }
     R.dl = await p.evaluate(() => [...document.querySelectorAll('main button')].map(e => e.innerText.trim()).filter(x => /Download|Day Pass/.test(x))); }
   }
   R.used1 = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
   await p.screenshot({ path: OUT + 'case-' + id + '.png' });
  } catch (e) { R.err = String(e).slice(0, 300); }
  R.reqs = reqs.slice(n0); console.log(JSON.stringify(R).slice(0, 1500)); ALL.cases.push(R); }
 ALL.t2 = now(); fs.writeFileSync(OUT + 'cases-' + ALL.engine + (only ? '-' + only.join('_').slice(0, 40) : '') + '.json', JSON.stringify(ALL, null, 1)); await b.close(); })();
