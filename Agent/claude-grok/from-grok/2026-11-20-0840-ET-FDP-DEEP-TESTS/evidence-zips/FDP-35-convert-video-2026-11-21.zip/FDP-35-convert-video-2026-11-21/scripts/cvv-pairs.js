// convert-image pair pages: drop label, preselected target after loading a file, GIF frame default. No Download. Guest.
const { chromium } = require('playwright'); const fs = require('fs'); const BASE = '/workspace/deep/35-convert-video/'; const TF = BASE + 'testfiles/';
const P = [['mov-to-mp4', 'V02_h264_aac_1080p.mov'], ['mp4-to-webm', 'V01_h264_aac.mp4'], ['gif-to-mp4', 'V10_animated.gif'], ['mp4-to-avi', 'V01_h264_aac.mp4'], ['wmv-to-mp4', 'V07.wmv']];
(async () => { const b = await chromium.launch(); const out = [];
 for (const [slug, f] of P) { const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); p.setDefaultTimeout(15000);
  await p.goto('https://www.freedailypro.com/tool/convert-video/' + slug, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4000);
  const r = { slug, file: f, title: await p.title(), h1: await p.evaluate(() => document.querySelector('h1')?.innerText), drop: await p.evaluate(() => document.querySelector('[role=button]')?.innerText.split('\n')[0]) };
  await p.locator('main input[type=file]').first().setInputFiles(TF + f); await p.waitForTimeout(2500);
  r.target = await p.evaluate(() => document.querySelector('[role=combobox]')?.innerText.trim()); r.gifChoice = await p.evaluate(() => { const x = [...document.querySelectorAll('main [role=radio], main input[type=radio]')].map(e => (e.getAttribute('aria-checked') || e.checked) + ' ' + (e.parentElement?.innerText || '').trim().slice(0, 30)); return x; });
  out.push(r); console.log(JSON.stringify(r)); await p.context().close(); }
 fs.writeFileSync(BASE + 'live/pairs.json', JSON.stringify(out, null, 1)); await b.close(); })();
