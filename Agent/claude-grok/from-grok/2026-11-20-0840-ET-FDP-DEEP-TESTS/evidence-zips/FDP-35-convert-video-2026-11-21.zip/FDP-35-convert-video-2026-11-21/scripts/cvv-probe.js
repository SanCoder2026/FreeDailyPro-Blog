// convert-video probe: count, controls after loading V01, one Convert to MP4 (copy path), result area dump. No Download. Guest.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/35-convert-video/'; const OUT = BASE + 'live/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(15000); const R = { t: now(), req: [] };
 p.on('request', r => { const d = r.postDataBuffer(); if (!/google|doubleclick|adtraffic|ytimg|producthunt/.test(r.url())) R.req.push(r.method() + ' ' + r.url().slice(0, 120) + (d ? ' post=' + d.length : '')); });
 await p.goto('https://www.freedailypro.com/tool/convert-video', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000);
 R.ls = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1')).usageToday); await p.screenshot({ path: OUT + 'probe.png' });
 await p.locator('main input[type=file]').first().setInputFiles(BASE + 'testfiles/V01_h264_aac.mp4'); await p.waitForTimeout(2000);
 R.controls = await p.evaluate(() => [...document.querySelectorAll('main button, main [role=combobox], main video, main input')].map(e => e.tagName + ' ' + (e.getAttribute('role') || e.type || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50)).slice(0, 30));
 R.text1 = await p.evaluate(() => { const t = document.querySelector('main').innerText; const i = t.indexOf('V01_'); return t.slice(i, i + 800); });
 await p.getByRole('combobox').first().click(); await p.waitForTimeout(400); R.opts = await p.evaluate(() => [...document.querySelectorAll('[role=option]')].map(o => o.innerText)); await p.keyboard.press('Escape');
 const t0 = Date.now(); await p.getByRole('button', { name: /^Convert/ }).first().click();
 await p.waitForFunction(() => /→/.test(document.querySelector('main').innerText), null, { timeout: 180000 }).catch(() => {}); R.ms = Date.now() - t0; await p.waitForTimeout(1000);
 R.text2 = await p.evaluate(() => { const t = document.querySelector('main').innerText; const i = t.indexOf('V01_'); return t.slice(i, i + 1200); });
 R.media = await p.evaluate(() => [...document.querySelectorAll('main video, main audio, main source')].map(v => v.tagName + ' ' + (v.src || '').slice(0, 60)));
 R.toasts = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim()));
 R.ls2 = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1')).usageToday);
 await p.screenshot({ path: OUT + 'probe-result.png' });
 fs.writeFileSync(OUT + 'probe.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
