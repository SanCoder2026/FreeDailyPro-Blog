// convert-video: paste a token, click "Share this tool", read what is shared/copied. Guest, read-only.
const { chromium } = require('playwright'); const fs = require('fs');
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ permissions: ['clipboard-read', 'clipboard-write'] }); const p = await c.newPage();
  await p.addInitScript(() => { window.__shared = null; navigator.share = d => { window.__shared = d; return Promise.resolve(); }; });
  await p.goto('https://www.freedailypro.com/tool/convert-video', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4000);
  await p.locator('main input[type=file]').first().setInputFiles('/workspace/deep/35-convert-video/testfiles/V01_h264_aac.mp4'); await p.waitForTimeout(2500); await p.getByRole('button', { name: "Convert", exact: true }).click(); await p.waitForTimeout(4000); const first = 'V01_h264';
  const before = await p.evaluate(() => navigator.clipboard.readText().catch(() => ''));
  await p.getByRole('button', { name: 'Share this tool' }).first().click(); await p.waitForTimeout(1500);
  const r = { t: new Date().toString(), url: p.url(), shared: await p.evaluate(() => window.__shared), clip: await p.evaluate(() => navigator.clipboard.readText().catch(() => '')), dialog: await p.evaluate(() => { const d = document.querySelector('[role=dialog],[role=menu]'); return d ? d.innerText.slice(0, 300) : null; }) };
  r.clipChanged = r.clip !== before; r.fileInShare = JSON.stringify(r).includes(first);
  await p.screenshot({ path: '/workspace/deep/35-convert-video/live/share.png' });
  fs.writeFileSync('/workspace/deep/35-convert-video/live/share.json', JSON.stringify(r, null, 1)); console.log(JSON.stringify(r)); await b.close();
})();
