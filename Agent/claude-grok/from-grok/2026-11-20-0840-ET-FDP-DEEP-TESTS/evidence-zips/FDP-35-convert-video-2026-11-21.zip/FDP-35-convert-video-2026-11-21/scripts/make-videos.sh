#!/bin/sh
# Recreates the synthetic test files for FDP-35 (convert-video). Needs ffmpeg with libx264, libx265, libvpx, libmp3lame, aac, wmv2, flv.
S="-f lavfi -i testsrc2=size=1280x720:rate=30:duration=4 -f lavfi -i sine=frequency=440:duration=4"
ffmpeg -y -loglevel error $S -c:v libx264 -pix_fmt yuv420p -c:a aac -shortest V01_h264_aac.mp4
ffmpeg -y -loglevel error -f lavfi -i testsrc2=size=1920x1080:rate=30:duration=4 -f lavfi -i sine=duration=4 -c:v libx264 -pix_fmt yuv420p -c:a aac -shortest V02_h264_aac_1080p.mov
ffmpeg -y -loglevel error $S -c:v libx265 -tag:v hvc1 -pix_fmt yuv420p -c:a aac -shortest V03_hevc_iphone.mov
ffmpeg -y -loglevel error $S -c:v libvpx-vp9 -b:v 600k -c:a libopus -shortest V04_vp9_opus.webm
ffmpeg -y -loglevel error $S -c:v libx264 -pix_fmt yuv420p -c:a aac -shortest V05_h264.mkv
ffmpeg -y -loglevel error $S -c:v mpeg4 -q:v 5 -c:a libmp3lame -shortest V06_mpeg4.avi
ffmpeg -y -loglevel error $S -c:v wmv2 -b:v 1M -c:a wmav2 -shortest V07.wmv
ffmpeg -y -loglevel error -f lavfi -i testsrc2=size=640x360:rate=25:duration=4 -f lavfi -i sine=duration=4 -c:v flv1 -c:a libmp3lame -ar 44100 -shortest V08.flv
ffmpeg -y -loglevel error -f lavfi -i testsrc2=size=352x288:rate=15:duration=4 -f lavfi -i sine=duration=4 -c:v libx264 -pix_fmt yuv420p -c:a aac -ar 8000 -shortest V09.3gp
ffmpeg -y -loglevel error -f lavfi -i testsrc2=size=320x240:rate=10:duration=3 -vf "split[a][b];[a]palettegen[p];[b][p]paletteuse" V10_animated.gif
ffmpeg -y -loglevel error -f lavfi -i testsrc2=size=1280x720:rate=30:duration=4 -c:v libx264 -pix_fmt yuv420p V11_h264_noaudio.mp4
ffmpeg -y -loglevel error $S -c:v libx264 -pix_fmt yuv420p -c:a libmp3lame -shortest V12_h264_mp3.mp4
ffmpeg -y -loglevel error -f lavfi -i sine=duration=4 -c:a libmp3lame A13_audio_only.mp3
echo "not a video" > X14_text.mp4
ffmpeg -y -loglevel error -f lavfi -i testsrc2=size=1920x1080:rate=30:duration=3 -c:v libvpx -b:v 2M V15_vp8_1080p.webm
ffmpeg -y -loglevel error -f lavfi -i testsrc2=size=1280x720:rate=30:duration=60 -f lavfi -i sine=duration=60 -c:v libx264 -preset ultrafast -crf 28 -pix_fmt yuv420p -c:a aac -shortest V16_60s.mp4
