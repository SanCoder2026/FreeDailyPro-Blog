import { r as a, j as e } from "./vendor-react-D01g8YgM.js";
import {
  k as J,
  T as Q,
  F as X,
  D as ee,
  P as te,
} from "./ToolPage-DwLoDncN.js";
import {
  e as O,
  I,
  aF as se,
  aL as oe,
  N as j,
  ax as re,
  aM as ae,
  B as N,
  f as P,
} from "./index-B1CTyGtY.js";
import { T as ie } from "./ToolInfoSection-C0i6Zbwo.js";
import { a as R, v as z } from "./operations-B4LtHhm8.js";
import { a as U } from "./pdfMetadata-CcxIhQF2.js";
import { p as ne, U as le } from "./protectedPdfNotice-Dl0m_ReY.js";
import { f as $ } from "./formatFileSize-B-JRDfN5.js";
import { B as ce, a as pe } from "./BatchRunner-CHpN_wvN.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./pageView-BQIwVYOi.js";
import "./formAppearance-CdNbuISd.js";
import "./drawTextAnywhere-DcuP6lHH.js";
import "./ocrText-C_9cxcFa.js";
import "./ocrImage-CmXFNUud.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./utils-s8ucLyj8.js";
import "./imageRecompress-eXQFDUm-.js";
import "./plural-FIChqbp4.js";
import "./textDiff-DxE9AzvO.js";
import "./utils-1EQcVBdK.js";
import "./decode-DrS85i4S.js";
import "./formFill-Dg9Myfyq.js";
import "./redactSearch-DQpyyh_t.js";
import "./nameDetect-DvHCRM0m.js";
import "./batch-Bbh00IAr.js";
import "./trash-2-CmoDM6Qu.js";
import "./square-DmBnvOHU.js";
const v = {
    what: "Adds a password to a PDF with AES-256 encryption, the strongest standard the PDF format offers, so the file asks for the password before it opens in any current PDF reader. Your pages, bookmarks, form fields and links stay as they were. Everything happens in your browser; the file is never uploaded.",
    how: "Drop a PDF, type the password twice and click Protect PDF. The tool then opens the protected file with your password to check that it works, and shows the result before you download. Optionally block printing, copying or editing (readers are asked to respect this; the password is what keeps people out). To protect several PDFs with one password, switch to Several files (up to 5 at a time on the trial, counted as one use).",
    tip: "Write the password down somewhere safe: there is no way to recover it. Letters with accents and other alphabets work. Very old PDF readers from before 2006 may not open AES-256 files; every current reader, browser and phone does.",
  },
  de = new Set([
    "password",
    "password1",
    "12345678",
    "123456789",
    "qwertyuiop",
    "letmein",
    "iloveyou",
    "admin123",
    "welcome1",
    "p@ssw0rd",
    "passw0rd",
    "11111111",
    "abc12345",
  ]);
function me(o) {
  if (!o) return null;
  if (de.has(o.toLowerCase()) || /^(.)\1+$/.test(o))
    return { label: "Weak (very common)", color: "bg-red-500", pct: 15 };
  const i = [/[a-z]/, /[A-Z]/, /[0-9]/, /[^A-Za-z0-9]/].filter((l) =>
      l.test(o),
    ).length,
    s = o.length * Math.log2(Math.max(2, i * 12));
  return o.length < 8 || s < 40
    ? { label: "Weak", color: "bg-red-500", pct: 25 }
    : o.length < 12 && s < 60
      ? { label: "Medium", color: "bg-yellow-500", pct: 55 }
      : s < 75
        ? { label: "Good", color: "bg-lime-500", pct: 80 }
        : { label: "Strong", color: "bg-green-500", pct: 100 };
}
const h = 6;
function wt() {
  const [o, i] = a.useState(null),
    [s, l] = a.useState(""),
    [c, S] = a.useState(""),
    [p, W] = a.useState(!1),
    [u, F] = a.useState(!1),
    [f, C] = a.useState(!1),
    [w, D] = a.useState(!1),
    [_, T] = a.useState(!1),
    [E, A] = a.useState(null),
    x = a.useRef(!1),
    [B, Z] = a.useState(!1),
    [n, g] = a.useState(null),
    b = () => {
      (l(""), S(""), g(null), F(!1), C(!1), D(!1));
    },
    q = a.useCallback((t) => {
      const r = t[0] || null;
      if ((b(), r && J(r))) {
        (i(null), A(r.name));
        return;
      }
      (A(null), i(r));
    }, []),
    y = (t) => {
      (t(), g(null));
    },
    d = me(s),
    M = s.length > 0 && s.length < h,
    H = s !== s.trim(),
    k = s.length >= h && s === c,
    Y = c.length > 0 && s !== c,
    G = async () => {
      if (!(!o || !k || x.current)) {
        ((x.current = !0), T(!0));
        try {
          const t = await R(o, s, {
              restrict: { printing: u, copying: f, modifying: w },
            }),
            r = await z(o, t, s);
          if (!r.ok) {
            P.error(
              `The protected file did not pass its check (${r.reason ?? "unknown problem"}), so it was not offered. Try again or tell us about it.`,
            );
            return;
          }
          (g({ blob: t, check: r }), P.success("Password protection added"));
        } catch (t) {
          (console.error("PDF encryption failed:", t),
            P.error(
              "Couldn't protect this PDF. It may be damaged; try Repair PDF first.",
            ));
        } finally {
          ((x.current = !1), T(!1));
        }
      }
    },
    L = e.jsxs("div", {
      className: "space-y-4",
      children: [
        e.jsxs("div", {
          children: [
            e.jsx(O, { htmlFor: "pdf-pw", children: "Password to require" }),
            e.jsxs("div", {
              className: "relative",
              children: [
                e.jsx(I, {
                  id: "pdf-pw",
                  type: p ? "text" : "password",
                  autoComplete: "new-password",
                  value: s,
                  onChange: (t) => y(() => l(t.target.value)),
                  placeholder: "Enter a password...",
                  className: "pr-10",
                }),
                e.jsx("button", {
                  type: "button",
                  onClick: () => W((t) => !t),
                  "aria-label": p ? "Hide passwords" : "Show passwords",
                  className:
                    "absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground",
                  children: p
                    ? e.jsx(se, { className: "h-4 w-4" })
                    : e.jsx(oe, { className: "h-4 w-4" }),
                }),
              ],
            }),
            d &&
              e.jsxs("div", {
                className: "mt-1.5",
                children: [
                  e.jsx("div", {
                    className: "h-1.5 rounded-full bg-muted overflow-hidden",
                    children: e.jsx("div", {
                      className: `h-full ${d.color} transition-all`,
                      style: { width: `${d.pct}%` },
                    }),
                  }),
                  e.jsxs("p", {
                    className: "text-xs text-muted-foreground mt-0.5",
                    role: "status",
                    "aria-live": "polite",
                    children: ["Strength: ", d.label],
                  }),
                ],
              }),
            M &&
              e.jsxs("p", {
                className: "text-xs text-destructive mt-1",
                children: ["Use at least ", h, " characters."],
              }),
            H &&
              !M &&
              e.jsx(j, {
                className: "text-xs mt-1",
                children:
                  "The password starts or ends with a space. Spaces count, so you will need to type it exactly.",
              }),
          ],
        }),
        e.jsxs("div", {
          children: [
            e.jsx(O, { htmlFor: "pdf-pw2", children: "Confirm password" }),
            e.jsx(I, {
              id: "pdf-pw2",
              type: p ? "text" : "password",
              autoComplete: "new-password",
              value: c,
              onChange: (t) => y(() => S(t.target.value)),
              placeholder: "Re-enter the same password...",
            }),
            Y &&
              e.jsx("p", {
                className: "text-xs text-destructive mt-1",
                children: "Passwords don't match",
              }),
          ],
        }),
        e.jsxs("fieldset", {
          className: "space-y-1.5",
          children: [
            e.jsx("legend", {
              className: "text-sm font-medium",
              children: "Also ask readers to block (optional)",
            }),
            [
              ["Printing", u, F],
              ["Copying text", f, C],
              ["Editing", w, D],
            ].map(([t, r, m]) =>
              e.jsxs(
                "label",
                {
                  className: "flex items-center gap-2 text-sm",
                  children: [
                    e.jsx("input", {
                      type: "checkbox",
                      checked: r,
                      onChange: (V) => y(() => m(V.target.checked)),
                    }),
                    t,
                  ],
                },
                t,
              ),
            ),
            e.jsx("p", {
              className: "text-xs text-muted-foreground",
              children:
                "Readers are asked to respect these, and most do. The password is what keeps people out.",
            }),
          ],
        }),
        e.jsx(j, {
          children: e.jsxs("div", {
            className: "flex gap-2",
            children: [
              e.jsx(re, { className: "h-4 w-4 text-primary shrink-0 mt-0.5" }),
              e.jsx("p", {
                className: "text-xs",
                children:
                  "Write this password down somewhere safe. There is no way to recover it if you forget it. Your original file is not changed.",
              }),
            ],
          }),
        }),
      ],
    }),
    K = () =>
      k
        ? null
        : "Type the password twice, the same both times, with at least " +
          h +
          " characters";
  return e.jsxs(Q, {
    children: [
      e.jsx(ce, {
        batch: B,
        onChange: Z,
        limitText:
          "Up to 5 files on the trial, one password for all, counts as one use.",
      }),
      B
        ? e.jsx(pe, {
            accept: ".pdf",
            noun: "PDF",
            zipName: "protected-pdfs.zip",
            runLabel: "Protect all",
            check: K,
            process: async (t) => {
              const r = await R(t, s, {
                  restrict: { printing: u, copying: f, modifying: w },
                }),
                m = await z(t, r, s);
              if (!m.ok)
                throw new Error(
                  `Did not pass its check (${m.reason ?? "unknown problem"})`,
                );
              return { blob: r, fileName: `${U(t.name)}-protected.pdf` };
            },
            children: L,
          })
        : o
          ? e.jsxs("form", {
              className: "space-y-4",
              onSubmit: (t) => {
                (t.preventDefault(), G());
              },
              children: [
                e.jsxs("div", {
                  className: "p-4 rounded-lg border bg-card",
                  children: [
                    e.jsx("p", {
                      className: "text-sm font-medium",
                      children: o.name,
                    }),
                    e.jsx("p", {
                      className: "text-xs text-muted-foreground",
                      children: $(o.size),
                    }),
                  ],
                }),
                L,
                n &&
                  e.jsxs(j, {
                    className: "flex items-start gap-2",
                    role: "status",
                    children: [
                      e.jsx(ae, {
                        className: "h-4 w-4 text-primary mt-0.5 shrink-0",
                      }),
                      e.jsxs("p", {
                        className: "text-sm",
                        children: [
                          "Checked: opens with your password · ",
                          n.check.pages,
                          " ",
                          n.check.pages === 1 ? "page" : "pages",
                          " · ",
                          $(n.blob.size),
                          " · AES-256",
                        ],
                      }),
                    ],
                  }),
                e.jsx("div", {
                  className: "flex gap-3",
                  children: n
                    ? e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(ee, {
                            blob: n.blob,
                            fileName: `${U(o.name)}-protected.pdf`,
                          }),
                          e.jsx(N, {
                            type: "button",
                            variant: "outline",
                            onClick: () => {
                              (i(null), b());
                            },
                            children: "New",
                          }),
                        ],
                      })
                    : _
                      ? e.jsx(te, {})
                      : e.jsxs(e.Fragment, {
                          children: [
                            e.jsx(N, {
                              type: "submit",
                              disabled: !k,
                              children: "Protect PDF",
                            }),
                            e.jsx(N, {
                              type: "button",
                              variant: "ghost",
                              onClick: () => {
                                (i(null), b());
                              },
                              children: "Reset",
                            }),
                          ],
                        }),
                }),
              ],
            })
          : e.jsxs("div", {
              className: "space-y-3",
              children: [
                e.jsx(X, {
                  gateAtDownload: !0,
                  keepSkippedProtectedFiles: !0,
                  accept: ".pdf",
                  onFiles: q,
                  label: "Drop a PDF file",
                  description:
                    "Add real password protection, entirely in your browser",
                }),
                E &&
                  e.jsxs("p", {
                    role: "alert",
                    className: "text-sm text-destructive",
                    children: [
                      ne(E, "protected with a new password"),
                      " ",
                      e.jsx("a", {
                        href: le,
                        className: "underline font-medium",
                        children: "Unlock it with Unlock PDF",
                      }),
                      " first, then drop the unlocked copy here.",
                    ],
                  }),
              ],
            }),
      e.jsx(ie, { whatIsIt: v.what, howToUse: v.how, tip: v.tip }),
    ],
  });
}
export { wt as default };
//# sourceMappingURL=PdfPassword-CSuI9QpX.js.map
