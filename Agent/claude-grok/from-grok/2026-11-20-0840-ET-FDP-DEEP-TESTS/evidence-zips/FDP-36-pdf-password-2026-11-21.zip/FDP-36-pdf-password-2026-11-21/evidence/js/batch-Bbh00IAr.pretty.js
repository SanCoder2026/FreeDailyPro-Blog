const l = 5;
function h(t) {
  return t.isLoading ? 5 : t.isPro || t.isAdmin ? 100 : 5;
}
function A(t, r, e) {
  const s = Math.max(0, e - t.length);
  return {
    files: [...t, ...r.slice(0, s)],
    dropped: Math.max(0, r.length - s),
  };
}
function b(t) {
  const r = new Set();
  return t.map((e) => {
    const s = e.lastIndexOf("."),
      a = s > 0 ? e.slice(0, s) : e,
      i = s > 0 ? e.slice(s) : "";
    let n = e,
      o = 1;
    for (; r.has(n.toLowerCase());) (o++, (n = `${a} (${o})${i}`));
    return (r.add(n.toLowerCase()), n);
  });
}
function f(t, r) {
  return r
    ? new Promise((e, s) => {
        const a = () => s(new DOMException("Stopped", "AbortError"));
        if (r.aborted) return a();
        (r.addEventListener("abort", a, { once: !0 }),
          t.then(e, s).finally(() => r.removeEventListener("abort", a)));
      })
    : t;
}
async function T(t, r, e, s = () => !1, a) {
  let i = t.map((o) => ({ id: o.id, file: o.file, status: "queued" }));
  const n = (o, u) => {
    ((i = i.map((c, d) => (d === o ? { ...c, ...u } : c))), e(i));
  };
  e(i);
  for (let o = 0; o < i.length; o++) {
    if (s()) {
      n(o, { status: "skipped" });
      continue;
    }
    n(o, { status: "working" });
    try {
      const u = await f(r(i[o].file, a), a);
      n(o, { status: "done", result: u });
    } catch (u) {
      if (a?.aborted || u?.name === "AbortError") {
        n(o, { status: "skipped" });
        continue;
      }
      n(o, {
        status: "failed",
        error:
          u instanceof Error ? u.message : "This file could not be processed.",
      });
    }
  }
  return i;
}
function p(t) {
  const r = t.filter((e) => e.status === "done" && e.result);
  return {
    done: r.length,
    failed: t.filter((e) => e.status === "failed").length,
    before: r.reduce((e, s) => e + s.file.size, 0),
    after: r.reduce((e, s) => e + (s.result?.blob.size ?? 0), 0),
  };
}
export { l as T, p as a, h as b, A as c, T as r, b as u };
//# sourceMappingURL=batch-Bbh00IAr.js.map
