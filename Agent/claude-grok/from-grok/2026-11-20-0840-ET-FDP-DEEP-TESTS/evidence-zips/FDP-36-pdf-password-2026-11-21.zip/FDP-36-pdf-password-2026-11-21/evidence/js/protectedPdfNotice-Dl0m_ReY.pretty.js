const e = "/tool/unlock-pdf";
function c(t, o) {
  return `“${t}” is already password-protected, so it can't be ${o} yet.`;
}
export { e as U, c as p };
//# sourceMappingURL=protectedPdfNotice-Dl0m_ReY.js.map
