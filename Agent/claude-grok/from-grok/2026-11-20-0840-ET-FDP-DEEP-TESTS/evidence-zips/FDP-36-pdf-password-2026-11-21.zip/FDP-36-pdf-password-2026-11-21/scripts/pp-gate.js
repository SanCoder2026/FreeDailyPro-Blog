// pdf-password gate + download cases. Part 1 (uses-left context, up to 14 fresh contexts): Protect P01 (no use?), Download A, again A2, Drive/cloud (stop at sign-in),
// New + P01 with all 3 block options -> Download B, New + P03 unicode password -> C, New + P02 trailing-space password -> D (later downloads in same page load), reload + P01 -> E,
// reload + Several files B1-B5 -> Protect all -> per-file download + ZIP; reload + B1-B6 (trial cap 5). Part 2 (context at 0): Protect, Download -> cap dialog -> Day Pass (email prompt, types nothing),
// batch at 0 (per-file + ZIP), Quick Buy day/monthly (stop), keyboard. Guest. Saves downloads for pikepdf verification.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const crypto = require('crypto');
const BASE = '/workspace/deep/36-pdf-password/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/pdf-password';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex').slice(0, 16);
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').slice(0, 160);
const PW = { A: 'Tr1al-Horse-42!', U: 'Pässwört-日本語-42', S: 'space pw 42 ' };
(async () => { const b = await chromium.launch(); const R = { t: now(), tries: [] }; let c, p;
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); p = await c.newPage(); p.setDefaultTimeout(15000); await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 const toasts = () => p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim().replace(/\n/g, ' ')));
 const setPw = async pw => { const f = p.locator('main input#pdf-pw, main input[placeholder^="Enter a password"]'); const g = p.locator('main input#pdf-pw2, main input[placeholder^="Re-enter"]'); await f.first().fill(pw); await g.first().fill(pw); await p.waitForTimeout(300); };
 const protect = async (file, pw, blocks = []) => { await p.locator('main input[type=file]').first().setInputFiles(TF + file); await p.waitForTimeout(1500); await setPw(pw);
   for (const n of blocks) await p.locator('main label', { hasText: n }).locator('input[type=checkbox]').check();
   const note = await p.evaluate(() => document.querySelector('main').innerText.match(/Strength: .*|The password starts.*/g));
   await p.getByRole('button', { name: 'Protect PDF' }).click(); await p.waitForFunction(() => /Checked:|did not pass|Couldn't protect/.test(document.querySelector('main').innerText), null, { timeout: 60000 }).catch(() => {}); await p.waitForTimeout(700);
   return { file, note, checked: await p.evaluate(() => (document.querySelector('main').innerText.match(/Checked:.*/) || [null])[0]), toasts: await toasts(), used: await used() }; };
 const act = async (name, loc) => { const r = { before: await used() }; if (!(await loc.count())) { r.missing = true; return r; }
   const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); const dl = p.waitForEvent('download', { timeout: 10000 }).catch(() => null); const url0 = p.url(); await loc.first().click(); const [pg, d] = await Promise.all([pop, dl]); await p.waitForTimeout(2000);
   r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null; r.t = now();
   if (d) { r.download = d.suggestedFilename(); const f = OUT + 'downloads/gate-' + name + '-' + d.suggestedFilename(); await d.saveAs(f); r.bytes = fs.statSync(f).size; r.sha = sha(f); r.saved = f; }
   if (pg) { await pg.waitForLoadState('domcontentloaded').catch(() => {}); r.popup = red(pg.url()); r.popupTitle = await pg.title().catch(() => null); await pg.close(); }
   if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + '.png' });
   if (r.dialog && /Day Pass/.test(r.dialog) && !R.dayPassFromCap) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.dayPassFromCap = { from: name, dialog: await dialog(), emailField: await p.locator('input[type=email]').count(), url: red(p.url()) }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); } }
   await esc(); if (r.url) { await p.goBack().catch(() => {}); await p.waitForTimeout(2500); } console.log(name, JSON.stringify(r)); return r; };
 const newBtn = async () => { const n = p.getByRole('button', { name: 'New' }); if (await n.count()) { await n.click(); await p.waitForTimeout(800); } };
 const reload = async () => { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); };
 const batch = async (files, tag) => { const r = {}; await p.getByRole('button', { name: 'Several files' }).click(); await p.waitForTimeout(800);
   await p.locator('main input[type=file]').first().setInputFiles(files.map(f => TF + f)); await p.waitForTimeout(1500); r.toastsAdd = await toasts(); await setPw(PW.A);
   r.rows = await p.evaluate(() => document.querySelector('[data-testid=batch-runner]')?.innerText.slice(0, 600)); r.before = await used();
   await p.locator('[data-testid=batch-run]').click(); await p.waitForFunction(() => /Run again/.test(document.querySelector('[data-testid=batch-runner]').innerText), null, { timeout: 60000 }).catch(() => {}); await p.waitForTimeout(800);
   r.afterRun = await used(); r.result = await p.evaluate(() => document.querySelector('[data-testid=batch-runner]')?.innerText.slice(0, 900)); await p.screenshot({ path: OUT + 'batch-' + tag + '.png' });
   r.file1 = await act(tag + '-file1', p.locator('[data-testid=batch-runner] button[aria-label^="Download "]'));
   r.file2 = await act(tag + '-file2', p.locator('[data-testid=batch-runner] button[aria-label^="Download "]').nth(1));
   r.zip = await act(tag + '-zip', p.locator('[data-testid=batch-zip]')); return r; };
 for (let i = 0; i < 14; i++) { await open(); const u = await used(); R.tries.push(u); if (u < 10) break; await c.close(); c = null; }
 if (c) { const L = R.left = { t: now(), start: await used() };
  L.pA = await protect('P01_payslip_3p_form.pdf', PW.A); L.dlA = await act('A', p.getByRole('button', { name: /^Download$/ })); L.dlA2 = await act('A2', p.getByRole('button', { name: /^Download$/ }));
  L.drive = await act('drive', p.getByRole('button', { name: /Save to Google Drive/ })); L.cloud = await act('cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
  await newBtn(); L.pB = await protect('P01_payslip_3p_form.pdf', PW.A, ['Printing', 'Copying text', 'Editing']); L.dlB = await act('B', p.getByRole('button', { name: /^Download$/ }));
  await newBtn(); L.pC = await protect('P03_50pages.pdf', PW.U); L.dlC = await act('C', p.getByRole('button', { name: /^Download$/ }));
  await newBtn(); L.pD = await protect('P02_plain_1p.pdf', PW.S); L.dlD = await act('D', p.getByRole('button', { name: /^Download$/ }));
  await reload(); L.afterReload = await used(); L.pE = await protect('P02_plain_1p.pdf', PW.A, ['Printing']); L.dlE = await act('E', p.getByRole('button', { name: /^Download$/ }));
  await reload(); L.batch5 = await batch(['B1_batch.pdf', 'B2_batch.pdf', 'B3_batch.pdf', 'B4_batch.pdf', 'B5_batch.pdf'], 'b5');
  await reload(); L.batch6 = await batch(['B1_batch.pdf', 'B2_batch.pdf', 'B3_batch.pdf', 'B4_batch.pdf', 'B5_batch.pdf', 'B6_batch.pdf'], 'b6');
  await reload(); L.end = await used(); L.t2 = now(); await c.close(); }
 for (let i = 0; i < 4; i++) { await open(); if (await used() >= 10) break; await c.close(); }
 const Z = R.zero = { t: now(), start: await used() };
 let chooser = false; p.on('filechooser', () => { chooser = true; }); const seq = [];
 for (let i = 0; i < 40; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('role') || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50).replace(/\n/g, ' '); }); seq.push(a); if (/Drop a PDF/i.test(a)) { await p.keyboard.press('Enter'); await p.waitForTimeout(1200); seq.push('ENTER -> chooser=' + chooser); break; } }
 Z.kbd = { tabs: seq.length, last: seq.slice(-3), chooser };
 if (Z.start >= 10) { Z.p = await protect('P01_payslip_3p_form.pdf', PW.A); Z.blobs = await p.evaluate(() => [...document.querySelectorAll('main [src^="blob:"], main [data^="blob:"], main a[href^="blob:"], main iframe, main embed, main object')].map(e => e.tagName + ' ' + (e.src || e.data || e.href || '').slice(0, 40)));
  Z.download = await act('zero-dl', p.getByRole('button', { name: /^Download$/ })); Z.end = await used();
  await reload(); Z.batch = await batch(['B1_batch.pdf', 'B2_batch.pdf'], 'zero-b2'); Z.endBatch = await used();
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  const qb = p.getByRole('button', { name: 'Quick Buy' }); const u0 = p.url(); await qb.first().click(); await p.waitForTimeout(3000); Z.qbDay = { url: p.url() !== u0 ? red(p.url()) : null, dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await esc();
  if (p.url() !== u0) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); }
  await p.getByRole('button', { name: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); Z.qbMonth = { url: red(p.url()), dialog: await dialog(), title: await p.title(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' }); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify({ tries: R.tries }, null, 1)); await b.close(); })();
