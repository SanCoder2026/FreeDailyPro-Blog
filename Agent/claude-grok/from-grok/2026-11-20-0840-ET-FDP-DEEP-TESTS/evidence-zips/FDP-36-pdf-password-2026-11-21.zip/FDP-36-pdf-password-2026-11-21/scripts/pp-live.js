// pdf-password live cases (no Download; any usage state). Reload per case. Records alerts, toasts, button state, strength text, Checked line, timing, network. Guest.
const { chromium, firefox } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/36-pdf-password/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const CASES = [
 ['L01', 'P01_payslip_3p_form.pdf', 'Tr1al-Horse-42!', 'Tr1al-Horse-42!', true],
 ['L02', 'P03_50pages.pdf', 'Tr1al-Horse-42!', 'Tr1al-Horse-42!', true],
 ['L03', 'P04_already_userpw_old123.pdf', 'Tr1al-Horse-42!', 'Tr1al-Horse-42!', true],
 ['L04', 'P05_owner_only_restrict.pdf', 'Tr1al-Horse-42!', 'Tr1al-Horse-42!', true],
 ['L05', 'P09_pdf_1_3_rc4.pdf', 'Tr1al-Horse-42!', 'Tr1al-Horse-42!', true],
 ['L06', 'P06_corrupt.pdf', 'Tr1al-Horse-42!', 'Tr1al-Horse-42!', true],
 ['L07', 'P07_text_renamed.pdf', 'Tr1al-Horse-42!', 'Tr1al-Horse-42!', true],
 ['L08', 'P08_over50MB.pdf', 'Tr1al-Horse-42!', 'Tr1al-Horse-42!', true],
 ['L09', 'P02_plain_1p.pdf', 'abc12', 'abc12', false],
 ['L10', 'P02_plain_1p.pdf', 'Tr1al-Horse-42!', 'Tr1al-Horse-43!', false],
 ['L11', 'P02_plain_1p.pdf', 'letmein', 'letmein', true],
 ['L12', 'P02_plain_1p.pdf', 'aaaaaaaa', 'aaaaaaaa', false],
 ['L13', 'P02_plain_1p.pdf', ' lead space 42', ' lead space 42', false],
 ['L14', 'P02_plain_1p.pdf', 'abcdef', 'abcdef', true],
 ['L15', 'B1_batch.pdf', 'Tr1al-Horse-42!', 'Tr1al-Horse-42!', 'toggle'],
];
const eng = process.argv[2] === 'firefox' ? firefox : chromium; const only = process.argv[3] ? process.argv[3].split(',') : null;
(async () => { const b = await eng.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(15000);
 const reqs = []; p.on('request', r => { const d = r.postDataBuffer(); if (d && d.length > 1500) reqs.push(r.method() + ' ' + r.url().slice(0, 100) + ' ' + d.length); if (!/freedailypro|google|doubleclick|adtraffic|ytimg|producthunt|gstatic|^blob:|^data:/.test(r.url())) reqs.push('3P ' + r.url().slice(0, 100)); });
 const ALL = { t: now(), engine: process.argv[2] || 'chromium', cases: [] };
 for (const [id, file, pw1, pw2, go] of CASES) { if (only && !only.includes(id)) continue; const R = { id, file, pw1: pw1.length + ' chars', t: now() }; const n0 = reqs.length;
  try { await p.goto('https://www.freedailypro.com/tool/pdf-password', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(3000);
   const t0 = Date.now(); await p.locator('main input[type=file]').first().setInputFiles(TF + file); await p.waitForTimeout(2500); R.loadMs = Date.now() - t0;
   R.alert = await p.evaluate(() => [...document.querySelectorAll('main [role=alert]')].map(e => e.innerText.trim()));
   R.toastsLoad = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim().replace(/\n/g, ' ')));
   R.loaded = await p.evaluate(f => document.querySelector('main').innerText.includes(f), file);
   const f1 = p.locator('main input[placeholder^="Enter a password"]');
   if (await f1.count()) { await f1.fill(pw1); await p.locator('main input[placeholder^="Re-enter"]').fill(pw2); await p.waitForTimeout(500);
    R.msgs = await p.evaluate(() => document.querySelector('main').innerText.match(/Strength: .*|Use at least.*|Passwords don't match|The password starts.*/g));
    const btn = p.getByRole('button', { name: 'Protect PDF' }); R.disabled = await btn.isDisabled();
    if (go === 'toggle') { await p.getByRole('button', { name: 'Show passwords' }).click(); R.types = await p.evaluate(() => [...document.querySelectorAll('main #pdf-pw, main #pdf-pw2')].map(e => e.type)); await p.getByRole('button', { name: 'Hide passwords' }).click(); R.types2 = await p.evaluate(() => [...document.querySelectorAll('main #pdf-pw, main #pdf-pw2')].map(e => e.type));
     await p.getByRole('button', { name: 'Reset' }).click(); await p.waitForTimeout(500); R.afterReset = await p.evaluate(() => ({ dz: !!document.querySelector('main input[type=file]'), pw: document.querySelector('main #pdf-pw')?.value ?? null })); }
    else if (go && !R.disabled) { const t1 = Date.now(); await btn.click(); await p.waitForFunction(() => /Checked:|did not pass|Couldn't protect/.test(document.querySelector('main').innerText + [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText).join(' ')), null, { timeout: 90000 }).catch(() => {}); R.ms = Date.now() - t1; await p.waitForTimeout(800);
     R.checked = await p.evaluate(() => (document.querySelector('main').innerText.match(/Checked:.*/) || [null])[0]); R.toasts = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim().replace(/\n/g, ' '))); } }
   else R.state = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 900));
   await p.screenshot({ path: OUT + 'case-' + id + (ALL.engine === 'firefox' ? '-ff' : '') + '.png' });
  } catch (e) { R.err = String(e).slice(0, 300); }
  R.reqs = reqs.slice(n0); console.log(JSON.stringify(R).slice(0, 900)); ALL.cases.push(R); }
 ALL.t2 = now(); fs.writeFileSync(OUT + 'cases-' + ALL.engine + '.json', JSON.stringify(ALL, null, 1)); await b.close(); })();
