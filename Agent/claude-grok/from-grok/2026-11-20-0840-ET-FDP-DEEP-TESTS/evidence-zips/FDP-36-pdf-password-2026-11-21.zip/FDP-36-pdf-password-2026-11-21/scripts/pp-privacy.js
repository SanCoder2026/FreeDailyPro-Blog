// pdf-password privacy: protect P01 with a marker password; search every request URL/body, localStorage, sessionStorage, IndexedDB names and cookies for the marker and the PDF title. Guest, no Download.
const { chromium } = require('playwright'); const fs = require('fs');
(async () => { const b = await chromium.launch(); const c = await b.newContext(); const p = await c.newPage(); const MK = 'Zq9Marker-7731'; const hits = []; let n = 0, bytes = 0;
 p.on('request', r => { n++; const d = r.postDataBuffer(); if (d) bytes += d.length; const s = r.url() + ' ' + (d ? d.toString('latin1') : ''); if (s.includes(MK) || s.includes('FDP Test Payslip') || s.includes('%PDF')) hits.push(r.url().slice(0, 100)); });
 await p.goto('https://www.freedailypro.com/tool/pdf-password', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4000);
 await p.locator('main input[type=file]').first().setInputFiles('/workspace/deep/36-pdf-password/testfiles/P01_payslip_3p_form.pdf'); await p.waitForTimeout(2000);
 await p.locator('main #pdf-pw').fill(MK); await p.locator('main #pdf-pw2').fill(MK); await p.getByRole('button', { name: 'Protect PDF' }).click(); await p.waitForTimeout(6000);
 const store = await p.evaluate(async MK => { const ls = JSON.stringify(localStorage), ss = JSON.stringify(sessionStorage); const dbs = indexedDB.databases ? (await indexedDB.databases()).map(d => d.name) : []; return { lsHit: ls.includes(MK), ssHit: ss.includes(MK), lsKeys: Object.keys(localStorage), dbs }; }, MK);
 const ck = (await c.cookies()).some(k => k.value.includes(MK));
 await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3000); const afterReload = await p.evaluate(() => ({ fileShown: document.querySelector('main').innerText.includes('P01_'), pw: document.querySelector('#pdf-pw')?.value ?? null }));
 const R = { t: new Date().toString(), requests: n, postBytes: bytes, hits, store, cookieHit: ck, afterReload }; fs.writeFileSync('/workspace/deep/36-pdf-password/live/privacy.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R)); await b.close(); })();
