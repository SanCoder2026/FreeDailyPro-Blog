// pdf-password probe: load P01, dump controls, type password, Protect (no Download), dump result + network + usage. Guest.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/36-pdf-password/'; const OUT = BASE + 'live/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const U = () => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday;
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(15000); const R = { t: now(), req: [], scripts: [] };
 p.on('request', r => { const d = r.postDataBuffer(); const u = r.url(); if (/\/assets\/.*\.js/.test(u)) R.scripts.push(u.split('/').pop()); if (!/google|doubleclick|adtraffic|ytimg|producthunt|gstatic|\/assets\//.test(u)) R.req.push(r.method() + ' ' + u.slice(0, 120) + (d ? ' post=' + d.length : '')); });
 await p.goto('https://www.freedailypro.com/tool/pdf-password', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000);
 R.u0 = await p.evaluate(U); await p.screenshot({ path: OUT + 'probe.png' });
 await p.locator('main input[type=file]').first().setInputFiles(BASE + 'testfiles/P01_payslip_3p_form.pdf'); await p.waitForTimeout(2500);
 const dump = () => p.evaluate(() => [...document.querySelectorAll('main button, main input, main [role=checkbox], main [role=switch], main iframe, main embed, main object, main canvas, main img')].map(e => e.tagName + ' ' + (e.getAttribute('role') || e.type || '') + ' ' + (e.getAttribute('aria-label') || e.getAttribute('placeholder') || e.innerText || e.src || '').trim().slice(0, 60) + (e.disabled ? ' [disabled]' : '')).slice(0, 50));
 R.controls = await dump(); R.text1 = await p.evaluate(() => { const t = document.querySelector('main').innerText; const i = t.indexOf('P01_'); return t.slice(Math.max(0, i - 100), i + 1200); });
 await p.screenshot({ path: OUT + 'probe-loaded.png', fullPage: false });
 const pw = p.locator('main input[type=password]'); R.pwCount = await pw.count();
 if (R.pwCount >= 2) { await pw.nth(0).fill('Tr1al-Horse-42!'); await pw.nth(1).fill('Tr1al-Horse-42!'); }
 await p.waitForTimeout(600); R.text2 = await p.evaluate(() => { const t = document.querySelector('main').innerText; const i = t.indexOf('P01_'); return t.slice(i, i + 1200); });
 const btn = p.getByRole('button', { name: /Protect/ }).first(); R.btnDisabled = await btn.isDisabled().catch(() => 'n/a');
 if (R.btnDisabled === false) { const t0 = Date.now(); await btn.click(); await p.waitForFunction(() => /Checked|failed|couldn|error/i.test(document.querySelector('main').innerText), null, { timeout: 60000 }).catch(() => {}); R.ms = Date.now() - t0; await p.waitForTimeout(1500); }
 R.u1 = await p.evaluate(U); R.controls2 = await dump();
 R.text3 = await p.evaluate(() => { const t = document.querySelector('main').innerText; const i = t.indexOf('P01_'); return t.slice(i, i + 1500); });
 R.blobs = await p.evaluate(() => [...document.querySelectorAll('main [src^="blob:"], main [data^="blob:"], main a[href^="blob:"]')].map(e => e.tagName + ' ' + (e.src || e.data || e.href)));
 R.toasts = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim()));
 await p.screenshot({ path: OUT + 'probe-result.png' }); R.scripts = [...new Set(R.scripts)];
 fs.writeFileSync(OUT + 'probe.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
