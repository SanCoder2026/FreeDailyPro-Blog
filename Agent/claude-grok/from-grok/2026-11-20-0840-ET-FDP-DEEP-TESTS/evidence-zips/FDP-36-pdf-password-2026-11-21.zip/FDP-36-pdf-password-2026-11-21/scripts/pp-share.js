// pdf-password: paste a token, click "Share this tool", read what is shared/copied. Guest, read-only.
const { chromium } = require('playwright'); const fs = require('fs');
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ permissions: ['clipboard-read', 'clipboard-write'] }); const p = await c.newPage();
  await p.addInitScript(() => { window.__shared = null; navigator.share = d => { window.__shared = d; return Promise.resolve(); }; });
  await p.goto('https://www.freedailypro.com/tool/pdf-password', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4000);
  await p.locator('main input[type=file]').first().setInputFiles('/workspace/deep/36-pdf-password/testfiles/P01_payslip_3p_form.pdf'); await p.waitForTimeout(2500); await p.locator('main #pdf-pw').fill('Tr1al-Horse-42!'); await p.locator('main #pdf-pw2').fill('Tr1al-Horse-42!'); await p.getByRole('button', { name: 'Protect PDF' }).click(); await p.waitForTimeout(3000); const first = 'Tr1al';
  const before = await p.evaluate(() => navigator.clipboard.readText().catch(() => ''));
  await p.getByRole('button', { name: 'Share this tool' }).first().click(); await p.waitForTimeout(1500);
  const r = { t: new Date().toString(), url: p.url(), shared: await p.evaluate(() => window.__shared), clip: await p.evaluate(() => navigator.clipboard.readText().catch(() => '')), dialog: await p.evaluate(() => { const d = document.querySelector('[role=dialog],[role=menu]'); return d ? d.innerText.slice(0, 300) : null; }) };
  r.clipChanged = r.clip !== before; r.fileInShare = JSON.stringify(r).includes(first);
  await p.screenshot({ path: '/workspace/deep/36-pdf-password/live/share.png' });
  fs.writeFileSync('/workspace/deep/36-pdf-password/live/share.json', JSON.stringify(r, null, 1)); console.log(JSON.stringify(r)); await b.close();
})();
