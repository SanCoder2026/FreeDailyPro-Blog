// pdf-password: already-protected inputs. P04 (AES user pw old123): wrong pw, then right pw, then protect with a new pw. P09 (RC4 user pw rc4): right pw, protect. Cancel path. No Download. Guest.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/36-pdf-password/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); p.setDefaultTimeout(15000); const R = { t: now() };
 const dlg = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 400) : null; };
 const T = () => p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim().replace(/\n/g, ' ')));
 const go = async (file, tries, tag) => { const r = { file, steps: [] }; await p.goto('https://www.freedailypro.com/tool/pdf-password', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(3000);
  await p.locator('main input[type=file]').first().setInputFiles(TF + file); await p.waitForTimeout(2500); r.dialog = await dlg();
  for (const pw of tries) { if (pw === null) { await p.getByRole('button', { name: 'Cancel' }).click(); await p.waitForTimeout(1000); r.steps.push({ cancel: true, dialog: await dlg(), loaded: await p.evaluate(f => document.querySelector('main').innerText.includes(f), file), toasts: await T(), main: await p.evaluate(() => document.querySelector('main').innerText.slice(300, 700)) }); continue; }
   await p.locator('[role=dialog] input').first().fill(pw); await p.getByRole('button', { name: 'Unlock' }).click(); await p.waitForTimeout(1800);
   r.steps.push({ pw: pw.length + ' chars', dialog: await dlg(), toasts: await T(), loaded: await p.evaluate(f => document.querySelector('main').innerText.includes(f), file) }); await p.screenshot({ path: OUT + 'unlock-' + tag + '-' + r.steps.length + '.png' }); }
  if (r.steps.length && r.steps[r.steps.length - 1].loaded && await p.locator('main input[placeholder^="Enter a password"]').count()) { await p.locator('main input[placeholder^="Enter a password"]').fill('New-Secret-777'); await p.locator('main input[placeholder^="Re-enter"]').fill('New-Secret-777');
   await p.getByRole('button', { name: 'Protect PDF' }).click(); await p.waitForTimeout(2500); r.checked = await p.evaluate(() => (document.querySelector('main').innerText.match(/Checked:.*/) || [null])[0]); r.toasts = await T(); }
  console.log(JSON.stringify(r)); return r; };
 R.p04 = await go('P04_already_userpw_old123.pdf', ['wrongpass', 'old123'], 'p04'); R.p09 = await go('P09_pdf_1_3_rc4.pdf', ['rc4'], 'p09'); R.cancel = await go('P04_already_userpw_old123.pdf', [null], 'cancel');
 R.t2 = now(); fs.writeFileSync(OUT + 'unlock.json', JSON.stringify(R, null, 1)); await b.close(); })();
