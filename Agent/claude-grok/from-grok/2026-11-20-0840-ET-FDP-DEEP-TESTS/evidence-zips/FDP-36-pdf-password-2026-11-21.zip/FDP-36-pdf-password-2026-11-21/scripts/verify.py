# Verify protected outputs: encryption, opens with password, pages/title/fields/outlines/links preserved, permissions, producer, mark text.
import pikepdf, sys, json, glob, os
from pypdf import PdfReader
PW = {'A': 'Tr1al-Horse-42!', 'A2': 'Tr1al-Horse-42!', 'B': 'Tr1al-Horse-42!', 'C': 'Pässwört-日本語-42', 'D': 'space pw 42 ', 'E': 'Tr1al-Horse-42!'}
out = {}
for f in sorted(glob.glob(sys.argv[1] if len(sys.argv) > 1 else 'gate-*.pdf')):
    tag = os.path.basename(f).split('-')[1]; pw = PW.get(tag, 'Tr1al-Horse-42!'); r = {'bytes': os.path.getsize(f)}
    try:
        pikepdf.open(f); r['opens_without_pw'] = True
    except pikepdf.PasswordError: r['opens_without_pw'] = False
    except Exception as e: r['open_err'] = str(e)[:100]
    try:
        p = pikepdf.open(f, password=pw); e = p.encryption
        r.update(encrypted=p.is_encrypted, R=e.R, V=e.V, bits=e.bits, stream=str(e.stream_method), owner_pw_eq_user=None,
                 pages=len(p.pages), title=str(p.docinfo.get('/Title', '')), author=str(p.docinfo.get('/Author', '')), producer=str(p.docinfo.get('/Producer', '')),
                 fields=sorted(str(x.get('/T')) for x in p.Root.get('/AcroForm', {}).get('/Fields', [])) if '/AcroForm' in p.Root else [],
                 outlines=len(list(p.open_outline().root)), links=sum(1 for pg in p.pages for a in pg.get('/Annots', []) if a.get('/Subtype') == '/Link'),
                 allow={k: getattr(p.allow, k) for k in ('print_highres', 'print_lowres', 'extract', 'modify_other', 'modify_form', 'modify_annotation', 'modify_assembly', 'accessibility')})
        try: pikepdf.open(f, password=pw.strip()); r['opens_with_stripped_pw'] = pw != pw.strip()
        except pikepdf.PasswordError: r['opens_with_stripped_pw'] = False
        rd = PdfReader(f); rd.decrypt(pw); r['text_p1'] = (rd.pages[0].extract_text() or '')[:120]; r['text_last'] = (rd.pages[-1].extract_text() or '')[-120:]
    except Exception as ex: r['err'] = str(ex)[:200]
    out[os.path.basename(f)] = r
print(json.dumps(out, indent=1, ensure_ascii=False))
