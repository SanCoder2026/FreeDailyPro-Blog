import { r as a, j as e } from "./vendor-react-D01g8YgM.js";
import { x as u, y, T as P, F as N, D as j } from "./ToolPage-DwLoDncN.js";
import { N as f, aM as k, B as b } from "./index-B1CTyGtY.js";
import { T as F } from "./ToolInfoSection-C0i6Zbwo.js";
import { g as T } from "./operations-B4LtHhm8.js";
import { a as v } from "./pdfMetadata-CcxIhQF2.js";
import { f as D } from "./formatFileSize-B-JRDfN5.js";
import { u as E, P as S, a as I } from "./PdfPageThumbnails-DeGIJGYt.js";
import { I as C } from "./info-B8t_e6MS.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./pageView-BQIwVYOi.js";
import "./formAppearance-CdNbuISd.js";
import "./drawTextAnywhere-DcuP6lHH.js";
import "./ocrText-C_9cxcFa.js";
import "./ocrImage-CmXFNUud.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./utils-s8ucLyj8.js";
import "./imageRecompress-eXQFDUm-.js";
import "./plural-FIChqbp4.js";
import "./textDiff-DxE9AzvO.js";
import "./utils-1EQcVBdK.js";
import "./decode-DrS85i4S.js";
import "./formFill-Dg9Myfyq.js";
import "./redactSearch-DQpyyh_t.js";
import "./nameDetect-DvHCRM0m.js";
const O = 60,
  p = 12,
  U = new Set(),
  d = {
    what: "Removes the password from a PDF so it opens without asking, using the password you already know. When you add the file a box asks for the password; the unlocked copy is a normal PDF with no protection. Everything happens in your browser; the file and the password are never uploaded.",
    how: 'Drop the PDF and type its password when asked. If the file only has restrictions (for example no printing) and opens without a password, it unlocks straight away. When the "Password removed" message appears, download the new file below it; your original is not changed.',
    tip: "This tool cannot guess or crack a password: to open a file that asks for one, you need to know it. Use it only on documents you are allowed to change. Open the downloaded copy once in your usual reader to confirm it no longer asks for a password.",
  };
function Ue() {
  const [t, n] = a.useState(null),
    [l, m] = a.useState(!1),
    [s, r] = a.useState(null),
    [c, h] = a.useState(""),
    { thumbnails: i, loading: w } = E(t && s !== null && s <= O ? t : null),
    x = a.useCallback(async (g) => {
      const o = g[0];
      if (o) {
        if ((h(""), !u(o) && (await y(o)))) {
          (n(null),
            m(!1),
            r(null),
            h(
              `"${o.name}" couldn't be read as a PDF. It may not be a PDF at all, or it may be damaged. Nothing was used. Try another file.`,
            ));
          return;
        }
        (n(o), r(null), m(u(o)));
        try {
          r(await T(o));
        } catch {
          r(null);
        }
      }
    }, []);
  return e.jsxs(P, {
    children: [
      t
        ? e.jsxs("div", {
            className: "space-y-4",
            children: [
              e.jsxs("div", {
                className: "p-4 rounded-lg border bg-card",
                children: [
                  e.jsx("p", {
                    className: "text-sm font-medium",
                    children: t.name,
                  }),
                  e.jsxs("p", {
                    className: "text-xs text-muted-foreground",
                    children: [
                      D(t.size),
                      s ? ` · ${s} ${s === 1 ? "page" : "pages"}` : "",
                    ],
                  }),
                ],
              }),
              l
                ? e.jsxs(f, {
                    className: "flex items-start gap-2",
                    role: "status",
                    children: [
                      e.jsx(k, {
                        className: "h-4 w-4 text-primary mt-0.5 shrink-0",
                      }),
                      e.jsx("p", {
                        className: "text-sm",
                        children:
                          "Password removed. This copy opens with no password and no restrictions.",
                      }),
                    ],
                  })
                : e.jsxs(f, {
                    className: "flex items-start gap-2",
                    role: "status",
                    children: [
                      e.jsx(C, {
                        className: "h-4 w-4 mt-0.5 shrink-0 text-primary",
                      }),
                      e.jsx("p", {
                        className: "text-sm",
                        children:
                          "This PDF was not password-protected, so nothing was removed. The download below is the same file, and it does not use a trial use.",
                      }),
                    ],
                  }),
              w && e.jsx(S, {}),
              i.length > 0 &&
                e.jsxs("div", {
                  className: "space-y-2",
                  "data-testid": "unlock-preview",
                  children: [
                    e.jsx(I, {
                      thumbnails: i.slice(0, p),
                      selected: U,
                      onToggle: () => {},
                    }),
                    i.length > p &&
                      e.jsxs("p", {
                        className: "text-xs text-muted-foreground",
                        children: [
                          "Showing the first ",
                          p,
                          " of ",
                          i.length,
                          " pages.",
                        ],
                      }),
                  ],
                }),
              e.jsxs("div", {
                className: "flex gap-3 flex-wrap",
                children: [
                  e.jsx(j, {
                    freeDownload: !l,
                    blob: t,
                    fileName: `${v(t.name)}${l ? "-unlocked" : ""}.pdf`,
                  }),
                  e.jsx(b, {
                    variant: "outline",
                    onClick: () => {
                      (n(null), m(!1));
                    },
                    children: "New",
                  }),
                ],
              }),
            ],
          })
        : e.jsxs(e.Fragment, {
            children: [
              e.jsx(N, {
                gateAtDownload: !0,
                acceptDamagedPdf: !0,
                accept: ".pdf",
                onFiles: x,
                label: "Drop a password-protected PDF",
                description:
                  "Enter its password to remove it, entirely in your browser",
              }),
              c &&
                e.jsx("p", {
                  role: "alert",
                  className: "text-sm text-destructive mt-2",
                  children: c,
                }),
            ],
          }),
      e.jsx(F, { whatIsIt: d.what, howToUse: d.how, tip: d.tip }),
    ],
  });
}
export { Ue as default };
//# sourceMappingURL=UnlockPdf-C2SvH1Cm.js.map
