# Synthetic locked PDFs for FDP-37 (venv-pdf python). Sources from FDP-36 make-pdfs.py (P01 form 3p, P02 1p, P03 50p).
import pikepdf, os
E = pikepdf.Encryption
def lock(src, dst, **kw):
    p = pikepdf.open(src); p.save(dst, encryption=E(**kw)); p.close()
lock("P01_payslip_3p_form.pdf", "U01_aes256_user_old123.pdf", user="old123", owner="ownerA", R=6)
lock("P01_payslip_3p_form.pdf", "U02_aes128_user_old123.pdf", user="old123", owner="ownerB", R=4, aes=True)
lock("P02_plain_1p.pdf", "U03_rc4_128_user_rc4pass.pdf", user="rc4pass", owner="ownerC", R=3, aes=False, metadata=False)
lock("P02_plain_1p.pdf", "U04_rc4_40_user_rc4old.pdf", user="rc4old", owner="ownerD", R=2, aes=False, metadata=False)
lock("P02_plain_1p.pdf", "U05_owner_only_noprint.pdf", user="", owner="ownerE", R=6, allow=pikepdf.Permissions(print_lowres=False, print_highres=False, extract=False, modify_other=False))
lock("P03_50pages.pdf", "U06_unicode_pw.pdf", user="Pässwört-日本語-42", owner="ownerF", R=6)
lock("P02_plain_1p.pdf", "U07_space_pw.pdf", user="space pw 42 ", owner="ownerG", R=6)
lock("P02_plain_1p.pdf", "U08_user_eq_owner.pdf", user="same123", owner="same123", R=6)
lock("P01_payslip_3p_form.pdf", "U09_open_with_owner_pw.pdf", user="userX1", owner="ownerX1", R=6)
for i in range(1, 4): lock("P02_plain_1p.pdf", f"U1{i}_batch_pw{i}.pdf", user="batch123", owner=f"o{i}", R=6)
