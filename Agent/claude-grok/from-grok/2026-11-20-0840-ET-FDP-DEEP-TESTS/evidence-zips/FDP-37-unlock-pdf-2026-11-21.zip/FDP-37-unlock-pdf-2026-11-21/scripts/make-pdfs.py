# Synthetic PDFs for FDP-36 (run with /workspace/deep/venv-pdf/bin/python)
import pikepdf, os
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
def base(fn, pages=3, title="FDP Test Payslip", form=True, extra_bytes=0):
    c = canvas.Canvas(fn, pagesize=letter); c.setTitle(title); c.setAuthor("QA Author"); c.setSubject("Synthetic")
    for i in range(pages):
        c.setFont("Helvetica", 18); c.drawString(72, 700, f"{title} - page {i+1}"); c.bookmarkPage(f"p{i}"); c.addOutlineEntry(f"Page {i+1}", f"p{i}")
        c.linkURL("https://example.com", (72, 650, 250, 670)); c.drawString(72, 655, "example.com link")
        if form and i == 0:
            c.acroForm.textfield(name="employee_name", x=72, y=600, width=200, height=20); c.acroForm.checkbox(name="agree", x=72, y=560)
        c.showPage()
    c.save()
    if extra_bytes:
        pdf = pikepdf.open(fn, allow_overwriting_input=True)
        pdf.attachments["noise.bin"] = pikepdf.AttachedFileSpec(pdf, os.urandom(extra_bytes), mime_type="application/octet-stream")
        pdf.save(fn)
base("P01_payslip_3p_form.pdf")
base("P02_plain_1p.pdf", pages=1, title="Plain One", form=False)
base("P03_50pages.pdf", pages=50, title="Long Report", form=False)
p = pikepdf.open("P02_plain_1p.pdf"); p.save("P04_already_userpw_old123.pdf", encryption=pikepdf.Encryption(user="old123", owner="ownerX", R=6)); p.close()
p = pikepdf.open("P02_plain_1p.pdf"); p.save("P05_owner_only_restrict.pdf", encryption=pikepdf.Encryption(user="", owner="ownerY", R=4, allow=pikepdf.Permissions(print_lowres=False, print_highres=False, extract=False))); p.close()
open("P06_corrupt.pdf", "wb").write(b"%PDF-1.7\n1 0 obj<<>>endobj\ngarbage" + os.urandom(2000))
open("P07_text_renamed.pdf", "w").write("not a pdf\n" * 50)
for i in range(1, 7): base(f"B{i}_batch.pdf", pages=1, title=f"Batch {i}", form=False)
base("P08_over50MB.pdf", pages=1, title="Big", form=False, extra_bytes=52 * 1024 * 1024)
p = pikepdf.open("P02_plain_1p.pdf"); p.save("P09_pdf_1_3_rc4.pdf", encryption=pikepdf.Encryption(user="rc4", owner="rc4o", R=3, metadata=False, aes=False)); p.close()
