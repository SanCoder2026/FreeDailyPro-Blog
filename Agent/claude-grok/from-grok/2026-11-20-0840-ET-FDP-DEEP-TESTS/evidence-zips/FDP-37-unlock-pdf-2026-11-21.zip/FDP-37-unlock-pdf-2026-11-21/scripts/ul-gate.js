// unlock-pdf gate + download cases. Part 1 (uses-left context, up to 14 fresh contexts): unlock U01 -> Download A, again A2, Drive/cloud (stop at sign-in),
// New + U02 (AES-128) -> B, New + U05 (owner-only) -> C, New + P02 (not protected; "does not use a trial use") -> D, reload + U03 (RC4) -> E,
// then "Continue with Merge PDF" hand-off and the target tool's Download. Part 2 (context at 0): unlock U01, thumbnail sizes, Download -> cap dialog -> Day Pass (email prompt, types nothing),
// New + P02 pass-through Download (free by design), unlock U01 + Continue with Compress PDF hand-off at 0, Quick Buy day/monthly (stop), keyboard. Guest.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const crypto = require('crypto');
const BASE = '/workspace/deep/37-unlock-pdf/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/unlock-pdf';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex').slice(0, 16);
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').slice(0, 160);
(async () => { const b = await chromium.launch(); const R = { t: now(), tries: [] }; let c, p;
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); p = await c.newPage(); p.setDefaultTimeout(15000); await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 const toasts = () => p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim().replace(/\n/g, ' ')));
 const unlock = async (file, pw) => { await p.locator('main input[type=file]').first().setInputFiles(TF + file); await p.waitForTimeout(2500); const r = { file, dialog: await dialog() };
   if (r.dialog && pw) { await p.locator('[role=dialog] input').first().fill(pw); await p.getByRole('button', { name: 'Unlock' }).click(); await p.waitForTimeout(2500); }
   r.status = await p.evaluate(() => [...document.querySelectorAll('main [role=status]')].map(e => e.innerText.trim()).join(' | ')); r.toasts = await toasts(); r.used = await used();
   r.thumbs = await p.evaluate(() => [...document.querySelectorAll('[data-testid=unlock-preview] img')].map(i => i.naturalWidth + 'x' + i.naturalHeight)); return r; };
 const act = async (name, loc) => { const r = { before: await used() }; if (!(await loc.count())) { r.missing = true; return r; }
   const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); const dl = p.waitForEvent('download', { timeout: 10000 }).catch(() => null); const url0 = p.url(); await loc.first().click(); const [pg, d] = await Promise.all([pop, dl]); await p.waitForTimeout(2000);
   r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null; r.t = now();
   if (d) { r.download = d.suggestedFilename(); const f = OUT + 'downloads/gate-' + name + '-' + d.suggestedFilename(); await d.saveAs(f); r.bytes = fs.statSync(f).size; r.sha = sha(f); }
   if (pg) { await pg.waitForLoadState('domcontentloaded').catch(() => {}); r.popup = red(pg.url()); r.popupTitle = await pg.title().catch(() => null); await pg.close(); }
   if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + '.png' });
   if (r.dialog && /Day Pass/.test(r.dialog) && !R.dayPassFromCap) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.dayPassFromCap = { from: name, dialog: await dialog(), emailField: await p.locator('input[type=email]').count(), url: red(p.url()) }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); } }
   await esc(); console.log(name, JSON.stringify(r)); return r; };
 const DL = () => p.getByRole('button', { name: /^Download$/ });
 const newBtn = async () => { const n = p.getByRole('button', { name: 'New' }); if (await n.count()) { await n.first().click(); await p.waitForTimeout(800); } };
 const reload = async () => { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); };
 const handoff = async (label, tag) => { const r = { before: await used() }; await p.getByRole('button', { name: label }).click(); await p.waitForTimeout(5000); r.url = p.url(); r.used = await used();
   r.main = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 900)); r.buttons = await p.evaluate(() => [...document.querySelectorAll('main button')].map(e => e.innerText.trim()).filter(Boolean).slice(0, 30)); await p.screenshot({ path: OUT + 'handoff-' + tag + '.png' });
   const run = p.locator('main button').filter({ hasText: /^(Merge|Compress|Merge PDFs?|Compress PDF|Merge \d+ files?)/ }); if (await run.count()) { const dis = await run.first().isDisabled(); r.runLabel = await run.first().innerText(); if (!dis) { await run.first().click(); await p.waitForTimeout(8000); } r.afterRun = await used(); r.main2 = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 900)); await p.screenshot({ path: OUT + 'handoff-' + tag + '-run.png' }); }
   r.dl = await act(tag + '-dl', DL()); return r; };
 for (let i = 0; i < 14; i++) { await open(); const u = await used(); R.tries.push(u); if (u < 10) break; await c.close(); c = null; }
 if (c) { const L = R.left = { t: now(), start: await used() };
  L.uA = await unlock('U01_aes256_user_old123.pdf', 'old123'); L.dlA = await act('A', DL()); L.dlA2 = await act('A2', DL());
  L.drive = await act('drive', p.getByRole('button', { name: /Save to Google Drive/ })); L.cloud = await act('cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
  await newBtn(); L.uB = await unlock('U02_aes128_user_old123.pdf', 'old123'); L.dlB = await act('B', DL());
  await newBtn(); L.uC = await unlock('U05_owner_only_noprint.pdf', null); L.dlC = await act('C', DL());
  await newBtn(); L.uD = await unlock('P02_plain_1p.pdf', null); L.dlD = await act('D', DL());
  await reload(); L.afterReload = await used(); L.uE = await unlock('U03_rc4_128_user_rc4pass.pdf', 'rc4pass'); L.dlE = await act('E', DL());
  L.handoff = await handoff('Continue with Merge PDF', 'merge-left');
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); L.end = await used(); L.t2 = now(); await c.close(); }
 for (let i = 0; i < 4; i++) { await open(); if (await used() >= 10) break; await c.close(); }
 const Z = R.zero = { t: now(), start: await used() };
 let chooser = false; p.on('filechooser', () => { chooser = true; }); const seq = [];
 for (let i = 0; i < 40; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('role') || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50).replace(/\n/g, ' '); }); seq.push(a); if (/Drop a password/i.test(a)) { await p.keyboard.press('Enter'); await p.waitForTimeout(1200); seq.push('ENTER -> chooser=' + chooser); break; } }
 Z.kbd = { tabs: seq.length, last: seq.slice(-3), chooser };
 if (Z.start >= 10) { Z.u = await unlock('U01_aes256_user_old123.pdf', 'old123'); await p.screenshot({ path: OUT + 'zero-result.png', fullPage: true });
  Z.download = await act('zero-dl', DL()); Z.end = await used();
  await newBtn(); Z.uPlain = await unlock('P02_plain_1p.pdf', null); Z.dlPlain = await act('zero-plain', DL());
  await reload(); Z.u2 = await unlock('U01_aes256_user_old123.pdf', 'old123'); Z.handoff = await handoff('Continue with Compress PDF', 'compress-zero');
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  const qb = p.getByRole('button', { name: 'Quick Buy' }); const u0 = p.url(); await qb.first().click(); await p.waitForTimeout(3000); Z.qbDay = { url: p.url() !== u0 ? red(p.url()) : null, dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await esc();
  if (p.url() !== u0) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); }
  await p.getByRole('button', { name: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); Z.qbMonth = { url: red(p.url()), dialog: await dialog(), title: await p.title(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' }); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify({ tries: R.tries }, null, 1)); await b.close(); })();
