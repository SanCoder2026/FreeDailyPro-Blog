// unlock-pdf hand-off at 0: unlock U01, Continue with Compress PDF / Remove PDF Pages, click "Use the result…", run the target tool, try its Download (expect cap dialog). Types nothing. Guest.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/37-unlock-pdf/live/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const R = { t: now(), runs: [] };
 for (const target of ['Continue with Compress PDF', 'Continue with Remove PDF Pages']) { const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await c.newPage(); p.setDefaultTimeout(15000); const r = { target };
  const used = () => p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
  await p.goto('https://www.freedailypro.com/tool/unlock-pdf', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); r.start = await used();
  await p.locator('main input[type=file]').first().setInputFiles('/workspace/deep/37-unlock-pdf/testfiles/U01_aes256_user_old123.pdf'); await p.waitForTimeout(2500); await p.locator('[role=dialog] input').first().fill('old123'); await p.getByRole('button', { name: 'Unlock' }).click(); await p.waitForTimeout(3000);
  await p.getByRole('button', { name: target }).click(); await p.waitForTimeout(5000); r.url = p.url();
  const use = p.getByRole('button', { name: /^Use the result/ }); if (await use.count()) { await use.click(); await p.waitForTimeout(4000); }
  r.buttons = await p.evaluate(() => [...document.querySelectorAll('main button')].map(e => e.innerText.trim() + (e.disabled ? '[x]' : '')).filter(Boolean).slice(0, 40));
  const run = p.locator('main button').filter({ hasText: /^(Compress|Remove|Delete|Apply|Save)/ }).filter({ hasNotText: /Several/ }); if (await run.count()) { r.run = await run.first().innerText(); if (!(await run.first().isDisabled())) { await run.first().click(); await p.waitForTimeout(8000); } }
  r.main = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 1200)); await p.screenshot({ path: OUT + 'handoff2-' + target.split(' ').pop() + '.png' });
  const dlb = p.getByRole('button', { name: /^Download/ }); r.dlCount = await dlb.count();
  if (r.dlCount) { const dl = p.waitForEvent('download', { timeout: 8000 }).catch(() => null); await dlb.first().click(); const d = await dl; await p.waitForTimeout(1500); r.download = d ? d.suggestedFilename() : null; const dg = p.locator('[role=dialog]'); r.dialog = (await dg.count()) ? (await dg.first().innerText()).slice(0, 200).replace(/\n/g, ' | ') : null; await p.screenshot({ path: OUT + 'handoff2-' + target.split(' ').pop() + '-dl.png' }); }
  r.end = await used(); R.runs.push(r); console.log(JSON.stringify(r).slice(0, 1500)); await c.close(); }
 fs.writeFileSync(OUT + 'handoff.json', JSON.stringify(R, null, 1)); await b.close(); })();
