// unlock-pdf live cases (no Download). Reload per case. Dialog text, wrong-password message, status line, toasts, page count, thumbnails, alerts, network. Guest.
const { chromium, firefox } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/37-unlock-pdf/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const CASES = [
 ['K01', 'U01_aes256_user_old123.pdf', ['old123']], ['K02', 'U02_aes128_user_old123.pdf', ['old123']], ['K03', 'U03_rc4_128_user_rc4pass.pdf', ['rc4pass']],
 ['K04', 'U04_rc4_40_user_rc4old.pdf', ['rc4old']], ['K05', 'U05_owner_only_noprint.pdf', []], ['K06', 'U06_unicode_pw.pdf', ['Pässwört-日本語-42']],
 ['K07', 'U07_space_pw.pdf', ['space pw 42', 'space pw 42 ']], ['K08', 'U08_user_eq_owner.pdf', ['same123']], ['K09', 'U09_open_with_owner_pw.pdf', ['ownerX1']],
 ['K10', 'U01_aes256_user_old123.pdf', ['OLD123', 'wrong', 'old123']], ['K11', 'P02_plain_1p.pdf', []], ['K12', 'P06_corrupt.pdf', []], ['K13', 'P07_text_renamed.pdf', []],
 ['K14', 'U01_aes256_user_old123.pdf', ['CANCEL']], ['K15', 'P03_50pages.pdf', []],
];
const eng = process.argv[2] === 'firefox' ? firefox : chromium; const only = process.argv[3] ? process.argv[3].split(',') : null;
(async () => { const b = await eng.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(15000);
 const reqs = []; p.on('request', r => { const d = r.postDataBuffer(); if (d && d.length > 1500 && !/googlesyndication/.test(r.url())) reqs.push(r.method() + ' ' + r.url().slice(0, 100) + ' ' + d.length); if (!/freedailypro|google|doubleclick|adtraffic|ytimg|producthunt|gstatic|^blob:|^data:/.test(r.url())) reqs.push('3P ' + r.url().slice(0, 100)); });
 const dlg = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 400) : null; };
 const ALL = { t: now(), engine: process.argv[2] || 'chromium', cases: [] };
 for (const [id, file, pws] of CASES) { if (only && !only.includes(id)) continue; const R = { id, file, t: now(), steps: [] }; const n0 = reqs.length;
  try { await p.goto('https://www.freedailypro.com/tool/unlock-pdf', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(3000);
   const t0 = Date.now(); await p.locator('main input[type=file]').first().setInputFiles(TF + file); await p.waitForTimeout(2500); R.dialog = await dlg();
   for (const pw of pws) { if (!(await dlg())) break; if (pw === 'CANCEL') { await p.getByRole('button', { name: 'Cancel' }).click(); await p.waitForTimeout(1200); R.steps.push({ cancel: true }); continue; }
    await p.locator('[role=dialog] input').first().fill(pw); await p.getByRole('button', { name: 'Unlock' }).click(); await p.waitForTimeout(2000); R.steps.push({ pw: JSON.stringify(pw).length - 2 + ' chars', dialog: await dlg() }); }
   R.ms = Date.now() - t0; await p.waitForTimeout(1500);
   R.status = await p.evaluate(() => [...document.querySelectorAll('main [role=status], main [role=alert]')].map(e => e.innerText.trim()).join(' | '));
   R.info = await p.evaluate(f => { const t = document.querySelector('main').innerText; const i = t.indexOf(f); return i < 0 ? null : t.slice(i, i + 120); }, file);
   R.thumbs = await p.evaluate(() => { const im = [...document.querySelectorAll('[data-testid=unlock-preview] img')]; return { n: im.length, size: im[0] ? im[0].naturalWidth + 'x' + im[0].naturalHeight : null, note: (document.querySelector('[data-testid=unlock-preview]') || {}).innerText?.match(/Showing.*/)?.[0] || null }; });
   R.buttons = await p.evaluate(() => [...document.querySelectorAll('main button')].map(e => e.innerText.trim()).filter(x => /Download|Continue|New|Day Pass/.test(x)));
   R.toasts = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim().replace(/\n/g, ' ')));
   await p.screenshot({ path: OUT + 'case-' + id + (ALL.engine === 'firefox' ? '-ff' : '') + '.png' });
  } catch (e) { R.err = String(e).slice(0, 300); }
  R.reqs = reqs.slice(n0); console.log(JSON.stringify(R).slice(0, 700)); ALL.cases.push(R); }
 ALL.t2 = now(); fs.writeFileSync(OUT + 'cases-' + ALL.engine + '.json', JSON.stringify(ALL, null, 1)); await b.close(); })();
