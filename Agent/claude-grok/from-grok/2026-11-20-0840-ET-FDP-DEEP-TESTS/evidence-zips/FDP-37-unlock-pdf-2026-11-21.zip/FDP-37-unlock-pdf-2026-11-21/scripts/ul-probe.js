// unlock-pdf probe: load U01, unlock dialog, type old123, result UI (no Download), controls, blobs/previews, network, script chunks. Guest.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/37-unlock-pdf/'; const OUT = BASE + 'live/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const U = () => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday;
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(15000); const R = { t: now(), req: [], scripts: [] };
 p.on('request', r => { const d = r.postDataBuffer(); const u = r.url(); if (/\/assets\/.*\.js/.test(u)) R.scripts.push(u.split('/').pop()); if (!/google|doubleclick|adtraffic|ytimg|producthunt|gstatic|\/assets\//.test(u)) R.req.push(r.method() + ' ' + u.slice(0, 100) + (d ? ' post=' + d.length : '')); });
 await p.goto('https://www.freedailypro.com/tool/unlock-pdf', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000);
 R.u0 = await p.evaluate(U); await p.screenshot({ path: OUT + 'probe.png' });
 const dump = () => p.evaluate(() => [...document.querySelectorAll('main button, main input, main iframe, main embed, main object, main canvas, main img, main a[href^="blob:"]')].map(e => e.tagName + ' ' + (e.getAttribute('role') || e.type || '') + ' ' + (e.getAttribute('aria-label') || e.getAttribute('placeholder') || e.innerText || e.src || e.href || '').trim().slice(0, 60) + (e.disabled ? ' [disabled]' : '')).slice(0, 50));
 R.controls0 = await dump();
 await p.locator('main input[type=file]').first().setInputFiles(BASE + 'testfiles/U01_aes256_user_old123.pdf'); await p.waitForTimeout(2500);
 const dl = p.locator('[role=dialog]'); R.dialog = (await dl.count()) ? await dl.first().innerText() : null; await p.screenshot({ path: OUT + 'probe-dialog.png' });
 if (R.dialog) { await dl.locator('input').first().fill('old123'); await p.getByRole('button', { name: 'Unlock' }).click(); await p.waitForTimeout(3000); }
 R.u1 = await p.evaluate(U); R.controls1 = await dump(); R.text = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 1600));
 R.toasts = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim()));
 await p.screenshot({ path: OUT + 'probe-result.png' }); R.scripts = [...new Set(R.scripts)].filter(s => !/vendor|index-B1|trpc/.test(s));
 fs.writeFileSync(OUT + 'probe.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
