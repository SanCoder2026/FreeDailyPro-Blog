# FDP-37: check unlocked downloads open without a password and match their unprotected source (pages, title, author, fields, outlines, links, mediabox, text).
import pikepdf, glob, json, os, re
from pypdf import PdfReader
src = {'U01': 'P01_payslip_3p_form', 'U02': 'P01_payslip_3p_form', 'U03': 'P02_plain_1p', 'U05': 'P02_plain_1p', 'P02': 'P02_plain_1p'}
TF = os.path.join(os.path.dirname(os.path.abspath(__file__)), '')
def info(f):
    p = pikepdf.open(f); r = dict(encrypted=p.is_encrypted, pages=len(p.pages), title=str(p.docinfo.get('/Title', '')), author=str(p.docinfo.get('/Author', '')), producer=str(p.docinfo.get('/Producer', '')),
      fields=sorted(str(x.get('/T')) for x in p.Root.AcroForm.Fields) if '/AcroForm' in p.Root else [], outlines=len(list(p.open_outline().root)),
      links=sum(1 for pg in p.pages for a in pg.get('/Annots', []) if a.get('/Subtype') == '/Link'), mediabox=[float(x) for x in p.pages[0].MediaBox])
    r['text'] = (PdfReader(f).pages[0].extract_text() or '')[:60]; return r
out = {}
for f in sorted(glob.glob('gate-*.pdf')):
    k = re.search(r'(U\d\d|P\d\d)', os.path.basename(f)).group(1)
    try: o = info(f); o['opens_without_pw'] = True
    except pikepdf.PasswordError: o = {'opens_without_pw': False}
    if 'pages' in o:
        s = info(TF + src[k] + '.pdf'); o['matches_source'] = all(o[x] == s[x] for x in ('pages', 'title', 'author', 'fields', 'outlines', 'links', 'mediabox', 'text')); o['producer_src'] = s['producer']
    out[os.path.basename(f)] = o
print(json.dumps(out, indent=1, ensure_ascii=False))
