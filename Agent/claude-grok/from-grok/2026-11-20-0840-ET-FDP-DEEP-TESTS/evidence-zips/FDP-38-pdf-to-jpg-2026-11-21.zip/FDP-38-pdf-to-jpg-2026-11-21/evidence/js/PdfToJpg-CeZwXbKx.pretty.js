import { r as m, j as e } from "./vendor-react-D01g8YgM.js";
import { u as J } from "./useConverterPair-rg6H4-hf.js";
import { p as _, T as B, F as M, P as Z, D as Q } from "./ToolPage-DwLoDncN.js";
import {
  ao as H,
  B as h,
  X as W,
  e as k,
  I as X,
  N as Y,
  f as v,
} from "./index-B1CTyGtY.js";
import { T as K } from "./ToolInfoSection-C0i6Zbwo.js";
import { h as V, j as w, k as ee, P as te } from "./operations-B4LtHhm8.js";
import { u as ae } from "./useRunToken-sJpsnYiZ.js";
import { f as $ } from "./formatFileSize-B-JRDfN5.js";
import { l as se } from "./utils-s8ucLyj8.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./pdfMetadata-CcxIhQF2.js";
import "./pageView-BQIwVYOi.js";
import "./formAppearance-CdNbuISd.js";
import "./drawTextAnywhere-DcuP6lHH.js";
import "./ocrText-C_9cxcFa.js";
import "./ocrImage-CmXFNUud.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./imageRecompress-eXQFDUm-.js";
import "./plural-FIChqbp4.js";
import "./textDiff-DxE9AzvO.js";
import "./utils-1EQcVBdK.js";
import "./decode-DrS85i4S.js";
import "./formFill-Dg9Myfyq.js";
import "./redactSearch-DQpyyh_t.js";
import "./nameDetect-DvHCRM0m.js";
const I = "This file couldn't be read as a PDF";
async function oe(s, c) {
  const p = [],
    i = [];
  for (const t of s)
    try {
      (await c(t), p.push(t));
    } catch {
      i.push(t);
    }
  return { ok: p, bad: i };
}
function re(s) {
  return s.length === 1
    ? `${I}: ${s[0].name}. It may be damaged. Nothing was used.`
    : `${I}: ${s.map((c) => c.name).join(", ")}. Nothing was used.`;
}
const D = {
    what: "Converts each page of a PDF into a separate JPG or PNG image, useful for sharing a document as pictures, embedding a page in a presentation, or posting a page to social media where a PDF attachment isn't an option. Select several PDFs at once and each one is converted independently, keeping their pages organized separately rather than mixed together.",
    how: `Upload one or more PDFs, choose a quality/resolution level and image format, and optionally a page range (like 1, 3-5 or 4-) when a single PDF is loaded. The dpi shown on each quality button is the resolution of the images: Standard is 108 dpi, High is 144 dpi, Maximum is 216 dpi and Print is 300 dpi, so pick Print when the images are going to paper. When the result is exactly one image (a one-page PDF, or a single page chosen from a longer one) it downloads as that image, named with its page number, e.g. report-page-03.jpg. Anything more downloads as one ZIP; with several PDFs each gets its own folder, and PDFs that share a name are kept apart as "name" and "name (2)". A PDF that can't be read is skipped and listed, so the rest still convert.`,
    tip: "For very text-heavy pages meant to stay readable at small sizes, a higher resolution and PNG (lossless) tend to hold up better than a lower-resolution JPEG once shared or resized elsewhere — at the cost of a larger file. If you only need one specific page as a real PDF page rather than an image, Extract Pages & Text is the more direct tool for that.",
  },
  z = [
    { label: "Standard", scale: 1.5, quality: 0.85 },
    { label: "High", scale: 2, quality: 0.92 },
    { label: "Maximum", scale: 3, quality: 0.98 },
    { label: "Print", scale: 300 / 72, quality: 0.98 },
  ];
function ne({ result: s }) {
  const [c, p] = m.useState([]);
  m.useEffect(() => {
    const t = s.previews.map((n) => URL.createObjectURL(n.blob));
    return (p(t), () => t.forEach((n) => URL.revokeObjectURL(n)));
  }, [s]);
  const i = s.imageCount - s.previews.length;
  return e.jsxs("div", {
    "aria-label": "Converted pages",
    children: [
      e.jsx("div", {
        className: "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3",
        children: s.previews.map((t, n) =>
          e.jsxs(
            "figure",
            {
              className: "rounded-lg border bg-card p-2",
              children: [
                c[n] &&
                  e.jsx("img", {
                    src: c[n],
                    alt: `${t.sourceName}, page ${t.pageNum}`,
                    className: "w-full h-40 object-contain bg-white rounded",
                  }),
                e.jsxs("figcaption", {
                  className: "mt-1.5 text-xs text-muted-foreground",
                  children: [
                    e.jsx("span", {
                      className: "block truncate text-foreground",
                      title: t.name,
                      children: t.name,
                    }),
                    t.width,
                    " × ",
                    t.height,
                    " px · ",
                    $(t.blob.size),
                  ],
                }),
              ],
            },
            `${n}-${t.sourceName}-${t.pageNum}`,
          ),
        ),
      }),
      i > 0 &&
        e.jsxs("p", {
          className: "mt-2 text-xs text-muted-foreground",
          children: [
            "…and ",
            i,
            " more ",
            i === 1 ? "image" : "images",
            " in the download.",
          ],
        }),
    ],
  });
}
function it() {
  const [s, c] = m.useState([]),
    [p, i] = m.useState(!1),
    [t, n] = m.useState(null),
    [r, x] = m.useState(null),
    [P, q] = m.useState(1),
    S = J("pdf-to-jpg"),
    [f, T] = m.useState(S ? _(S) : "image/jpeg"),
    [N, y] = m.useState(""),
    l = ae(),
    g = f === "image/png" ? "PNG" : "JPG",
    [j, R] = m.useState(""),
    L = m.useCallback(
      async (a) => {
        const { ok: o, bad: u } = await oe(a, se);
        (R(u.length > 0 ? re(u) : ""),
          o.length !== 0 && (l.cancel(), c((d) => [...d, ...o]), x(null)));
      },
      [l],
    ),
    U = (a) => {
      (l.cancel(),
        i(!1),
        n(null),
        x(null),
        c((o) => {
          const u = o.filter((d, C) => C !== a);
          return (u.length === 0 && y(""), u);
        }));
    },
    b = (a) => {
      (a(), x(null));
    },
    G = async () => {
      if (s.length === 0) return;
      const a = l.start();
      (i(!0), x(null), n(null));
      try {
        const o = z[P],
          u = {
            scale: o.scale,
            quality: o.quality,
            format: f,
            pageRange: s.length === 1 && N.trim() ? N : void 0,
            isCancelled: () => !l.isCurrent(a),
          },
          d = await ee(
            s,
            (F, A) => {
              l.isCurrent(a) && n({ done: F, total: A });
            },
            u,
          );
        if (!l.isCurrent(a)) return;
        x(d);
        const C = `${w(d.imageCount)} to ${g}`;
        d.skipped.length > 0
          ? v.warning(
              `Converted ${d.imageCount === 1 ? "1 page" : `${d.imageCount} pages`} from ${d.fileCount} of ${s.length} PDFs. Could not read: ${d.skipped.map((F) => F.name).join(", ")}`,
            )
          : v.success(`Converted ${C}`);
      } catch (o) {
        if (o instanceof te || !l.isCurrent(a)) return;
        (console.error(o),
          v.error(
            o instanceof Error && o.message
              ? o.message
              : "Conversion failed. One of the PDFs may be corrupted or password-protected.",
          ));
      } finally {
        l.isCurrent(a) && (i(!1), n(null));
      }
    },
    O = () => {
      (l.cancel(), i(!1), n(null), v.info("Stopped"));
    },
    E = () => {
      (l.cancel(), c([]), R(""), x(null), y(""), i(!1), n(null));
    };
  return e.jsxs(B, {
    children: [
      s.length === 0
        ? e.jsxs(e.Fragment, {
            children: [
              e.jsx(M, {
                gateAtDownload: !0,
                acceptDamagedPdf: !0,
                accept: ".pdf",
                multiple: !0,
                onFiles: L,
                label: "Drop one or more PDFs to convert to images",
                description:
                  "Every page becomes a high-quality image — processed entirely in your browser",
              }),
              j &&
                e.jsx("p", {
                  role: "alert",
                  className: "mt-2 text-sm text-destructive",
                  children: j,
                }),
            ],
          })
        : e.jsxs("div", {
            className: "space-y-4",
            children: [
              j &&
                e.jsx("p", {
                  role: "alert",
                  className: "text-sm text-destructive",
                  children: j,
                }),
              e.jsx("div", {
                className:
                  "p-3 rounded-lg border bg-muted/50 text-xs text-muted-foreground flex flex-wrap gap-x-4 gap-y-1",
                children: e.jsx("span", {
                  children: "🔒 Runs entirely in your browser — never uploaded",
                }),
              }),
              e.jsx("div", {
                className: "space-y-2",
                children: s.map((a, o) =>
                  e.jsxs(
                    "div",
                    {
                      className:
                        "flex items-center gap-3 p-3 rounded-lg border bg-card",
                      children: [
                        e.jsx(H, {
                          className: "h-4 w-4 text-primary shrink-0",
                        }),
                        e.jsx("span", {
                          className: "text-sm flex-1 truncate",
                          children: a.name,
                        }),
                        e.jsx("span", {
                          className: "text-xs text-muted-foreground",
                          children: $(a.size),
                        }),
                        e.jsx(h, {
                          variant: "ghost",
                          size: "icon",
                          className: "h-7 w-7",
                          "aria-label": `Remove ${a.name}`,
                          onClick: () => U(o),
                          children: e.jsx(W, { className: "h-3.5 w-3.5" }),
                        }),
                      ],
                    },
                    `${a.name}-${o}`,
                  ),
                ),
              }),
              e.jsxs("fieldset", {
                disabled: p,
                className: "space-y-4 min-w-0 border-0 p-0 m-0",
                children: [
                  e.jsxs("div", {
                    className: "flex flex-wrap gap-4",
                    children: [
                      e.jsxs("div", {
                        children: [
                          e.jsx(k, {
                            className: "mb-1 block text-sm",
                            children: "Quality (resolution)",
                          }),
                          e.jsx("div", {
                            className: "flex flex-wrap gap-2",
                            children: z.map((a, o) =>
                              e.jsxs(
                                h,
                                {
                                  type: "button",
                                  size: "sm",
                                  variant: P === o ? "default" : "outline",
                                  "aria-pressed": P === o,
                                  onClick: () => b(() => q(o)),
                                  children: [
                                    a.label,
                                    " · ",
                                    V(a.scale),
                                    " dpi",
                                  ],
                                },
                                a.label,
                              ),
                            ),
                          }),
                        ],
                      }),
                      e.jsxs("div", {
                        children: [
                          e.jsx(k, {
                            className: "mb-1 block text-sm",
                            children: "Format",
                          }),
                          e.jsxs("div", {
                            className: "flex gap-2",
                            children: [
                              e.jsx(h, {
                                type: "button",
                                size: "sm",
                                variant:
                                  f === "image/jpeg" ? "default" : "outline",
                                "aria-pressed": f === "image/jpeg",
                                onClick: () => b(() => T("image/jpeg")),
                                children: "JPG",
                              }),
                              e.jsx(h, {
                                type: "button",
                                size: "sm",
                                variant:
                                  f === "image/png" ? "default" : "outline",
                                "aria-pressed": f === "image/png",
                                onClick: () => b(() => T("image/png")),
                                children: "PNG",
                              }),
                            ],
                          }),
                        ],
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className: "max-w-xs",
                    children: [
                      e.jsx(k, {
                        htmlFor: "pdf-jpg-range",
                        className: "mb-1 block text-sm",
                        children: "Page range (optional)",
                      }),
                      e.jsx(X, {
                        id: "pdf-jpg-range",
                        value: s.length === 1 ? N : "",
                        disabled: s.length > 1,
                        onChange: (a) => b(() => y(a.target.value)),
                        placeholder:
                          "Leave blank for every page (e.g. 1, 3-5, 8-)",
                      }),
                      s.length > 1 &&
                        e.jsx("p", {
                          className: "mt-1 text-xs text-muted-foreground",
                          children:
                            "Page ranges work with one PDF at a time. With several PDFs, every page of each is converted — remove the others to pick pages.",
                        }),
                    ],
                  }),
                ],
              }),
              p
                ? e.jsx(Z, {
                    message:
                      t && t.total > 0
                        ? `Rendering page ${Math.min(t.done + 1, t.total)} of ${t.total}...`
                        : "Reading PDFs...",
                    progress:
                      t && t.total > 0 ? (t.done / t.total) * 100 : void 0,
                    onStop: O,
                  })
                : r
                  ? e.jsxs(e.Fragment, {
                      children: [
                        r.skipped.length > 0 &&
                          e.jsxs(Y, {
                            role: "alert",
                            className: "text-sm",
                            children: [
                              "Converted ",
                              r.fileCount,
                              " of ",
                              s.length,
                              " PDFs. Could not read: ",
                              r.skipped
                                .map((a) => `${a.name} (${a.reason})`)
                                .join(", "),
                              ".",
                            ],
                          }),
                        r.reducedPages > 0 &&
                          e.jsxs("p", {
                            className: "text-xs text-muted-foreground",
                            children: [
                              w(r.reducedPages),
                              " ",
                              r.reducedPages === 1 ? "was" : "were",
                              " very large, so the resolution was lowered to fit what the browser can draw.",
                            ],
                          }),
                        e.jsxs("p", {
                          className: "text-sm text-muted-foreground",
                          children: [w(r.imageCount), " converted to ", g, "."],
                        }),
                        e.jsxs("div", {
                          className: "space-y-2 min-w-0",
                          children: [
                            e.jsx(Q, {
                              stacked: !0,
                              blob: r.blob,
                              fileName: r.filename,
                              label:
                                r.imageCount === 1
                                  ? `Download page as ${g}`
                                  : `Download all ${r.imageCount} pages (ZIP)`,
                              subtitle: [
                                r.filename,
                                w(r.imageCount),
                                r.imageCount === 1 ? g : `${g} images in a ZIP`,
                                $(r.blob.size),
                              ].join(" · "),
                            }),
                            e.jsx(h, {
                              variant: "link",
                              className: "h-11 min-h-11 px-0",
                              onClick: E,
                              children: "Convert another PDF",
                            }),
                          ],
                        }),
                        e.jsx(ne, { result: r }),
                      ],
                    })
                  : e.jsxs("div", {
                      className: "flex gap-3",
                      children: [
                        e.jsx(h, {
                          onClick: G,
                          children:
                            s.length > 1
                              ? `Convert ${s.length} PDFs to ${g}`
                              : `Convert to ${g}`,
                        }),
                        e.jsx(h, {
                          variant: "outline",
                          onClick: E,
                          children: "Reset",
                        }),
                      ],
                    }),
            ],
          }),
      e.jsx(K, { whatIsIt: D.what, howToUse: D.how, tip: D.tip }),
    ],
  });
}
export { it as default };
//# sourceMappingURL=PdfToJpg-CeZwXbKx.js.map
