}
function ql({
  onClick: e,
  label: t = "Download",
  disabled: n,
  blob: a,
  fileName: i,
  markHint: d,
  shareText: h,
  shareTitle: l,
  enableShare: c = !0,
  toolId: u,
  category: p,
  freeDownload: f = !1,
  gate: g,
  subtitle: b,
  stacked: y = !1,
  pinned: m,
  hideMarkNoticeOnPhone: w = !1,
}) {
  const { isAuthenticated: I } = Pe(),
    { logUsageNow: v } = la(),
    T = ee.usage.log.useMutation(),
    A = ee.useUtils(),
    N = pe(),
    C = Yo(),
    [, E] = No();
  Wt();
  const x = u ?? N.id ?? "unknown",
    _ = p ?? J(x)?.category ?? "unknown",
    j = !!C && C.currentStepIndex >= C.steps.length - 1,
    q = i && C && j ? C.finalName(i) : i,
    [D, W] = s.useState(!1),
    P = s.useMemo(
      () =>
        !a || !q
          ? null
          : new File([a], q, { type: a.type || "application/octet-stream" }),
      [a, q],
    ),
    $ = C?.recordOutput,
    F = C?.currentStepIndex ?? 0;
  s.useEffect(() => {
    $ && a && i && $(F, i, a.size, a);
  }, [$, F, a, i]);
  const K = c && P ? na(P) : !1,
    Y = c && !K && !!h && ra(),
    Z = () => {
      if (!(x === "unknown" || _ === "unknown") && !Ge(x)) {
        Eo(x);
        try {
          const L = I ? void 0 : ke();
          T.mutate(
            { toolId: x, category: _, deviceId: [REDACTED] },
            { onSuccess: () => A.usage.check.invalidate() },
          );
        } catch {}
      }
    },
    se = async () => (f ? !0 : g ? At(g) : u ? (Z(), !0) : v("download")),
    k = async () => {
      if (await se()) {
        if (a && q) {
          vt(a, q, { free: !0 });
          return;
        }
        e?.();
      }
    },
    V = async () => {
      if (await se())
        try {
          if (a && q) {
            (await Zn(a, q, { title: l || q })) || vt(a, q, { free: !0 });
            return;
          }
          h && (await Qn(h, { title: l }));
        } catch (L) {
          if (L instanceof DOMException && L.name === "AbortError") return;
          (console.error(L),
            a &&
              q &&
              (vt(a, q, { free: !0 }),
              M.info(
                "Sharing isn't available here — downloaded the file instead.",
              )));
