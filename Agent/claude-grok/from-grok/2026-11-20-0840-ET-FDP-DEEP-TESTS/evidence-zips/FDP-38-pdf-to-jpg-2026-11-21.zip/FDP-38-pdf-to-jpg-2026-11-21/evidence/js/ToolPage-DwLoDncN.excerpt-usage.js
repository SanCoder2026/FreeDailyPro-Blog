          ],
        }),
        o.jsxs("p", {
          className: "mt-4 text-xs text-muted-foreground text-center",
          "data-testid": "suite-terms",
          children: [
            w
              ? `After the ${oo}-day trial you are charged monthly unless you cancel first. `
              : "",
            "Billed monthly. If you cancel, your plan and anything you saved to your account continue to the end of the paid month, then saved data is erased. No trial uses and no day pass.",
          ],
        }),
        o.jsxs("p", {
          className: "mt-2 text-xs text-muted-foreground text-center",
          children: [
            "Several people? An ",
            o.jsx(O, {
              href: a("/pricing"),
              className: "underline",
              children: "organization plan",
            }),
            " covers a whole team. If yours has one, sign in with your work email.",
          ],
        }),
      ],
    }),
  });
}
function nr() {
  const t = pe().id ?? "unknown",
    n = J(t)?.category ?? "unknown",
    { isAuthenticated: a } = Pe(),
    i = ee.useUtils(),
    d = a ? void 0 : ke(),
    h = Mt(a, d, de(t)),
    l = t !== "unknown" && n !== "unknown",
    c = $t(),
    u = zt(t),
    p = s.useCallback(
      () => i.client.usage.check.query({ toolId: t, deviceId: [REDACTED] }),
      [i, t, d],
    );
  s.useEffect(() => {
    l && !u && Ma(h, p);
  }, [l, u, h, p]);
  const f = s.useCallback(() => {
      La();
      const y = () =>
        Oa(h, p, () => {
          i.usage.check.invalidate();
        });
      i.client.usage.log
        .mutate({ toolId: t, category: n, deviceId: [REDACTED] })
        .then(y, y);
    }, [h, p, i, t, n, d]),
    g = s.useCallback(
      async () => (c ? "allowed" : (Ge(t) || (await et(h, p)), pt(t, h, p, f))),
      [c, h, p, t, f],
    ),
    b = s.useCallback(
      async (y) => {
        if (c) return "allowed";
        if (u) return pt(t, h, p, f);
        const m = Do(t, y);
        if (m === "free") return "allowed";
        await et(h, p);
        const w = m === "first" ? await pt(t, h, p, f) : await za(h, p, f);
        return (w === "allowed" && (Ra(t, y), m !== "first" && Ua(t)), w);
      },
      [c, u, t, h, p, f],
    );
  return {
    known: l,
    scope: h,
    fetcher: p,
    tryUse: g,
    tryUseExport: b,
    paid: c,
    toolId: t,
  };
}
function la() {
  const { known: e, tryUse: t, tryUseExport: n, toolId: a } = nr(),
    i = s.useCallback(
      async (h) =>
        e
          ? At(async () => ((await t()) === "blocked" ? (tt(a, h), !1) : !0), {
              explainFalse: !0,
            })
          : !0,
      [e, t, a],
    ),
    d = s.useCallback(
      async (h) =>
        e
          ? At(
              async () =>
                (await n(h)) === "blocked" ? (tt(a, "download"), !1) : !0,
              { explainFalse: !0 },
            )
          : !0,
      [e, n, a],
    );
  return { logUsageNow: i, logExportNow: d };
}
function rr() {
