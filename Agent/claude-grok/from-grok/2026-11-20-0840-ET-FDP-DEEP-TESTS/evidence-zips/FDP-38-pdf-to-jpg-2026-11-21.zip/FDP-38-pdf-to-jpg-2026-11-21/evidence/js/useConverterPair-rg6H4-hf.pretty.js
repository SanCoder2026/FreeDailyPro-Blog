import { E as o } from "./index-B1CTyGtY.js";
import { c as e } from "./ToolPage-DwLoDncN.js";
function i(r) {
  const a = o();
  return e(r, a?.pair);
}
export { i as u };
//# sourceMappingURL=useConverterPair-rg6H4-hf.js.map
