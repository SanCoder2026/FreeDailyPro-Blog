import { r as n } from "./vendor-react-D01g8YgM.js";
function t() {
  let r = 0;
  return {
    start: () => ++r,
    cancel: () => {
      r++;
    },
    isCurrent: (e) => e === r,
  };
}
function c() {
  const r = n.useRef(null);
  return (r.current || (r.current = t()), r.current);
}
export { c as u };
//# sourceMappingURL=useRunToken-sJpsnYiZ.js.map
