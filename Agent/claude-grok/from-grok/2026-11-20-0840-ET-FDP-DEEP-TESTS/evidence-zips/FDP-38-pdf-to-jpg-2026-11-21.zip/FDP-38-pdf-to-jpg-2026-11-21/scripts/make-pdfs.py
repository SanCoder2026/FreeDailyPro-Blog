# Extra synthetic PDFs for FDP-38 (venv-pdf python): photo page, huge page (16 MP cap), A4 landscape, mixed sizes, same-name pair in subfolders.
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape, letter
from PIL import Image, ImageDraw
import os, random
random.seed(1)
im = Image.new("RGB", (1200, 800)); d = ImageDraw.Draw(im)
for y in range(800):
    for x in range(0, 1200, 4): im.putpixel((x, y), ((x * 255) // 1200, (y * 255) // 800, 128))
im.save("photo.jpg", quality=90)
c = canvas.Canvas("Q01_photo_page.pdf", pagesize=letter); c.drawImage("photo.jpg", 36, 200, 540, 360); c.setFont("Helvetica", 9); c.drawString(72, 150, "Tiny 9pt text for sharpness check: The quick brown fox jumps over the lazy dog 0123456789"); c.save()
c = canvas.Canvas("Q02_huge_page_100in.pdf", pagesize=(7200, 7200)); c.setFont("Helvetica", 200); c.drawString(400, 3600, "HUGE PAGE 100 x 100 in"); c.save()
c = canvas.Canvas("Q03_mixed_sizes.pdf")
for size, label in [(letter, "Letter portrait"), (landscape(A4), "A4 landscape"), ((288, 288), "4x4 in square")]:
    c.setPageSize(size); c.setFont("Helvetica", 20); c.drawString(30, size[1] / 2, label); c.showPage()
c.save()
os.makedirs("dupA", exist_ok=True); os.makedirs("dupB", exist_ok=True)
for dd, t in (("dupA", "Report A"), ("dupB", "Report B")):
    c = canvas.Canvas(f"{dd}/report.pdf", pagesize=letter); c.drawString(72, 700, t); c.showPage(); c.drawString(72, 700, t + " p2"); c.save()
os.remove("photo.jpg")
