// pdf-to-jpg gate + download cases. Part 1 (uses-left context, up to 14 fresh contexts): P01 (3 pages, High JPG) -> preview blobs saved -> Download ZIP A, again A2, Drive/cloud (stop at sign-in),
// Convert another + P02 (1 page) -> preview -> Download B (single JPG; compare with preview), Convert another + P03 range "2-4" PNG -> C, reload + Q01 Print JPG -> D, reload + dupA/report.pdf + dupB/report.pdf + P02 -> ZIP E.
// Part 2 (context at 0): Q01 Print -> preview saved (size), Download -> cap dialog -> Day Pass (email prompt, types nothing); P03 range "37" -> preview of page 37; Quick Buy day/monthly (stop); keyboard. Guest.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const crypto = require('crypto');
const BASE = '/workspace/deep/38-pdf-to-jpg/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/pdf-to-jpg';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex').slice(0, 16);
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').slice(0, 160);
(async () => { const b = await chromium.launch(); const R = { t: now(), tries: [] }; let c, p;
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); p = await c.newPage(); p.setDefaultTimeout(15000); await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 const convert = async (files, opts = {}) => { await p.locator('main input[type=file]').first().setInputFiles(files.map(f => TF + f)); await p.waitForTimeout(2000);
   if (opts.q) await p.getByRole('button', { name: new RegExp('^' + opts.q) }).click(); if (opts.fmt) await p.getByRole('button', { name: opts.fmt, exact: true }).click();
   if (opts.range) await p.locator('main input[placeholder^="Leave blank"]').fill(opts.range);
   await p.getByRole('button', { name: /^Convert (to|\d)/ }).click(); await p.waitForFunction(() => /converted to|Could not read|failed|outside/i.test(document.querySelector('main').innerText), null, { timeout: 120000 }).catch(() => {}); await p.waitForTimeout(1500);
   return { files, opts, used: await used(), summary: await p.evaluate(() => (document.querySelector('main').innerText.match(/.*converted to (JPG|PNG)\.|Converted \d+ of.*|.*very large.*/g) || []).join(' | ')), dlLabel: await p.evaluate(() => [...document.querySelectorAll('main button')].map(e => e.innerText.replace(/\n/g, ' · ')).find(x => /^Download/.test(x)) || null), toasts: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim().replace(/\n/g, ' '))) }; };
 const previews = async tag => { const g = await p.evaluate(async () => { const out = []; for (const im of document.querySelectorAll('main [aria-label="Converted pages"] img')) { const bl = await (await fetch(im.src)).blob(); const a = new Uint8Array(await bl.arrayBuffer()); let s = ''; for (let i = 0; i < a.length; i += 0x8000) s += String.fromCharCode(...a.subarray(i, i + 0x8000)); out.push({ name: im.closest('figure').querySelector('span').innerText, nw: im.naturalWidth, nh: im.naturalHeight, type: bl.type, b64: btoa(s) }); } return out; });
   return g.map((x, i) => { const f = OUT + 'downloads/prev-' + tag + '-' + x.name; fs.writeFileSync(f, Buffer.from(x.b64, 'base64')); return { name: x.name, nw: x.nw, nh: x.nh, type: x.type, bytes: fs.statSync(f).size, sha: sha(f), saved: f }; }); };
 const act = async (name, loc) => { const r = { before: await used() }; if (!(await loc.count())) { r.missing = true; return r; }
   const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); const dl = p.waitForEvent('download', { timeout: 15000 }).catch(() => null); const url0 = p.url(); await loc.first().click(); const [pg, d] = await Promise.all([pop, dl]); await p.waitForTimeout(2000);
   r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null; r.t = now();
   if (d) { r.download = d.suggestedFilename(); const f = OUT + 'downloads/gate-' + name + '-' + d.suggestedFilename(); await d.saveAs(f); r.bytes = fs.statSync(f).size; r.sha = sha(f); r.saved = f; }
   if (pg) { await pg.waitForLoadState('domcontentloaded').catch(() => {}); r.popup = red(pg.url()); r.popupTitle = await pg.title().catch(() => null); await pg.close(); }
   if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + '.png' });
   if (r.dialog && /Day Pass/.test(r.dialog) && !R.dayPassFromCap) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.dayPassFromCap = { from: name, dialog: await dialog(), emailField: await p.locator('input[type=email]').count(), url: red(p.url()) }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); } }
   await esc(); console.log(name, JSON.stringify(r)); return r; };
 const DL = () => p.getByRole('button', { name: /^Download (all|page)/ });
 const another = async () => { await p.getByRole('button', { name: 'Convert another PDF' }).click(); await p.waitForTimeout(800); };
 const reload = async () => { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); };
 for (let i = 0; i < 14; i++) { await open(); const u = await used(); R.tries.push(u); if (u < 10) break; await c.close(); c = null; }
 if (c) { const L = R.left = { t: now(), start: await used() };
  L.cA = await convert(['P01_payslip_3p_form.pdf']); L.pvA = await previews('A'); L.dlA = await act('A', DL()); L.dlA2 = await act('A2', DL());
  L.drive = await act('drive', p.getByRole('button', { name: /Save to Google Drive/ })); L.cloud = await act('cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
  await another(); L.cB = await convert(['P02_plain_1p.pdf']); L.pvB = await previews('B'); L.dlB = await act('B', DL());
  await another(); L.cC = await convert(['P03_50pages.pdf'], { fmt: 'PNG', range: '2-4' }); L.dlC = await act('C', DL());
  await reload(); L.afterReload = await used(); L.cD = await convert(['Q01_photo_page.pdf'], { q: 'Print' }); L.pvD = await previews('D'); L.dlD = await act('D', DL());
  await reload(); L.cE = await convert(['dupA/report.pdf', 'dupB/report.pdf', 'P02_plain_1p.pdf']); L.dlE = await act('E', DL());
  await reload(); L.end = await used(); L.t2 = now(); await c.close(); }
 for (let i = 0; i < 4; i++) { await open(); if (await used() >= 10) break; await c.close(); }
 const Z = R.zero = { t: now(), start: await used() };
 let chooser = false; p.on('filechooser', () => { chooser = true; }); const seq = [];
 for (let i = 0; i < 40; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('role') || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50).replace(/\n/g, ' '); }); seq.push(a); if (/Drop one or more/i.test(a)) { await p.keyboard.press('Enter'); await p.waitForTimeout(1200); seq.push('ENTER -> chooser=' + chooser); break; } }
 Z.kbd = { tabs: seq.length, last: seq.slice(-3), chooser };
 if (Z.start >= 10) { Z.c = await convert(['Q01_photo_page.pdf'], { q: 'Print' }); Z.pv = await previews('zero-Q01print'); await p.screenshot({ path: OUT + 'zero-result.png', fullPage: false });
  Z.download = await act('zero-dl', DL()); Z.end = await used();
  await another(); Z.c37 = await convert(['P03_50pages.pdf'], { range: '37' }); Z.pv37 = await previews('zero-p37'); Z.end2 = await used();
  await another(); Z.cP01 = await convert(['P01_payslip_3p_form.pdf']); Z.pvP01 = await previews('zero-P01');
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  const qb = p.getByRole('button', { name: 'Quick Buy' }); const u0 = p.url(); await qb.first().click(); await p.waitForTimeout(3000); Z.qbDay = { url: p.url() !== u0 ? red(p.url()) : null, dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await esc();
  if (p.url() !== u0) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); }
  await p.getByRole('button', { name: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); Z.qbMonth = { url: red(p.url()), dialog: await dialog(), title: await p.title(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' }); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify({ tries: R.tries }, null, 1)); await b.close(); })();
