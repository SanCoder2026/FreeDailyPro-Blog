// pdf-to-jpg live cases (no Download). Reload per case. Records options, summary, toasts/alerts, Download label, thumbnail dims, timing, network; pair page preselect. Guest.
const { chromium, firefox } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/38-pdf-to-jpg/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const CASES = [
 ['K01', ['P01_payslip_3p_form.pdf'], { q: 'Standard' }], ['K02', ['P01_payslip_3p_form.pdf'], { q: 'Maximum' }], ['K03', ['P01_payslip_3p_form.pdf'], { q: 'Print', fmt: 'PNG' }],
 ['K04', ['P01_payslip_3p_form.pdf'], { range: '3' }], ['K05', ['P03_50pages.pdf'], { range: '1, 3-5' }], ['K06', ['P03_50pages.pdf'], { range: '60' }],
 ['K07', ['P03_50pages.pdf'], { range: '8-' }], ['K08', ['Q02_huge_page_100in.pdf'], { q: 'Print' }], ['K09', ['Q03_mixed_sizes.pdf'], {}],
 ['K10', ['U01_aes256_user_old123.pdf'], { pw: 'old123' }], ['K11', ['U05_owner_only_noprint.pdf'], {}], ['K12', ['P06_corrupt.pdf'], {}], ['K13', ['P07_text_renamed.pdf'], {}],
 ['K14', ['dupA/report.pdf', 'dupB/report.pdf', 'P06_corrupt.pdf'], {}], ['K15', ['P01_payslip_3p_form.pdf', 'P02_plain_1p.pdf'], { range: '1' }], ['K16', ['P03_50pages.pdf'], { q: 'Print' }],
 ['K17', ['U01_aes256_user_old123.pdf', 'P02_plain_1p.pdf'], { cancel: true }], ['K18', ['P03_50pages.pdf'], { range: '5-3, x' }],
];
const eng = process.argv[2] === 'firefox' ? firefox : chromium; const only = process.argv[3] ? process.argv[3].split(',') : null;
(async () => { const b = await eng.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(15000);
 const reqs = []; p.on('request', r => { const d = r.postDataBuffer(); if (d && d.length > 1500 && !/googlesyndication/.test(r.url())) reqs.push(r.method() + ' ' + r.url().slice(0, 100) + ' ' + d.length); if (!/freedailypro|google|doubleclick|adtraffic|ytimg|producthunt|gstatic|^blob:|^data:/.test(r.url())) reqs.push('3P ' + r.url().slice(0, 100)); });
 const ALL = { t: now(), engine: process.argv[2] || 'chromium', cases: [] };
 for (const [id, files, o] of CASES) { if (only && !only.includes(id)) continue; const R = { id, files, o, t: now() }; const n0 = reqs.length;
  try { await p.goto('https://www.freedailypro.com/tool/pdf-to-jpg', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(3000);
   await p.locator('main input[type=file]').first().setInputFiles(files.map(f => TF + f)); await p.waitForTimeout(2500);
   const d = p.locator('[role=dialog]'); if (await d.count()) { R.dialog = (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300); if (o.pw) { await d.locator('input').first().fill(o.pw); await p.getByRole('button', { name: 'Unlock' }).click(); await p.waitForTimeout(2500); } else { await p.getByRole('button', { name: 'Skip this file' }).click(); await p.waitForTimeout(1500); } }
   R.loadAlert = await p.evaluate(() => [...document.querySelectorAll('main [role=alert]')].map(e => e.innerText.trim()).join(' | ')); R.toastsLoad = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim().replace(/\n/g, ' ')));
   R.list = await p.evaluate(() => [...document.querySelectorAll('main button[aria-label^="Remove "]')].map(e => e.getAttribute('aria-label').slice(7)));
   const rg = p.locator('main input[placeholder^="Leave blank"]'); R.rangeVisible = await rg.count() > 0 && await rg.isVisible(); R.rangeDisabled = R.rangeVisible ? await rg.isDisabled() : null;
   if (o.q) await p.getByRole('button', { name: new RegExp('^' + o.q) }).click(); if (o.fmt) await p.getByRole('button', { name: o.fmt, exact: true }).click(); if (o.range && R.rangeVisible && !R.rangeDisabled) await rg.fill(o.range);
   const cv = p.getByRole('button', { name: /^Convert (to|\d)/ });
   if (await cv.count()) { const t0 = Date.now(); await cv.click(); await p.waitForFunction(() => /\d+ pages? converted to|Converted \d|outside this|starts after|couldn't|failed/i.test(document.querySelector('main').innerText + [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText).join(' ')), null, { timeout: 180000 }).catch(() => {}); R.ms = Date.now() - t0; await p.waitForTimeout(1500);
    R.summary = await p.evaluate(() => (document.querySelector('main').innerText.match(/.*converted to (JPG|PNG)\.|Converted \d+ of.*|.*very large.*|…and \d+ more.*/g) || []).join(' | '));
    R.alert = await p.evaluate(() => [...document.querySelectorAll('main [role=alert]')].map(e => e.innerText.trim()).join(' | '));
    R.dl = await p.evaluate(() => [...document.querySelectorAll('main button')].map(e => e.innerText.replace(/\n/g, ' · ')).find(x => /^Download/.test(x)) || null);
    R.thumbs = await p.evaluate(() => [...document.querySelectorAll('main [aria-label="Converted pages"] figure')].map(f => f.innerText.replace(/\n/g, ' ')).slice(0, 4).concat(['n=' + document.querySelectorAll('main [aria-label="Converted pages"] figure').length]));
    R.toasts = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim().replace(/\n/g, ' '))); }
   await p.screenshot({ path: OUT + 'case-' + id + (ALL.engine === 'firefox' ? '-ff' : '') + '.png' });
  } catch (e) { R.err = String(e).slice(0, 300); }
  R.reqs = reqs.slice(n0); console.log(JSON.stringify(R).slice(0, 800)); ALL.cases.push(R); }
 if (!only) { await p.goto('https://www.freedailypro.com/tool/pdf-to-jpg/pdf-to-png', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(3500);
  ALL.pair = { title: await p.title(), h1: await p.locator('h1').first().innerText(), canonical: await p.evaluate(() => document.querySelector('link[rel=canonical]')?.href) };
  await p.locator('main input[type=file]').first().setInputFiles(TF + 'P02_plain_1p.pdf'); await p.waitForTimeout(2000); ALL.pair.buttons = await p.evaluate(() => [...document.querySelectorAll('main button')].map(e => e.innerText.trim() + (e.getAttribute('aria-pressed') === 'true' ? ' [on]' : '')).filter(x => /JPG|PNG|Convert/.test(x))); await p.screenshot({ path: OUT + 'pair-pdf-to-png.png' }); console.log(JSON.stringify(ALL.pair)); }
 ALL.t2 = now(); fs.writeFileSync(OUT + 'cases-' + ALL.engine + (only ? '-' + only.join('_') : '') + '.json', JSON.stringify(ALL, null, 1)); await b.close(); })();
