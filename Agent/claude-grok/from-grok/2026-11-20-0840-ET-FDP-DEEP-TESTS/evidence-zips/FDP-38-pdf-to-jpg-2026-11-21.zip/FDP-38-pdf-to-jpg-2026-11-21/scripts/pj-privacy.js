// pdf-to-jpg privacy: convert P02 (PNG) and U01 (password old123); search every request URL/body for %PDF, JPEG/PNG magic, the file names and the password; storage/cookies; then Share. Guest, no Download.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
(async () => { const b = await chromium.launch(); const c = await b.newContext({ permissions: ['clipboard-read', 'clipboard-write'] }); const p = await c.newPage(); const hits = []; let n = 0, bytes = 0;
 p.on('request', r => { n++; const d = r.postDataBuffer(); if (d) bytes += d.length; const s = decodeURIComponent(r.url()) + ' ' + (d ? d.toString('latin1') : ''); if (/%PDF|\xff\xd8\xff|\x89PNG|P02_plain|U01_aes|old123/.test(s)) hits.push(r.url().slice(0, 100)); });
 await p.goto('https://www.freedailypro.com/tool/pdf-to-jpg', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4000);
 await p.locator('main input[type=file]').first().setInputFiles(['/workspace/deep/38-pdf-to-jpg/testfiles/P02_plain_1p.pdf', '/workspace/deep/38-pdf-to-jpg/testfiles/U01_aes256_user_old123.pdf']); await p.waitForTimeout(2500);
 await p.locator('[role=dialog] input').first().fill('old123'); await p.getByRole('button', { name: 'Unlock' }).click(); await p.waitForTimeout(2500);
 await p.getByRole('button', { name: 'PNG', exact: true }).click(); await p.getByRole('button', { name: /^Convert/ }).click(); await p.waitForTimeout(6000);
 const store = await p.evaluate(async () => ({ lsHit: /old123|P02_plain|U01_aes/.test(JSON.stringify(localStorage)), ssHit: /old123|P02_plain/.test(JSON.stringify(sessionStorage)), lsKeys: Object.keys(localStorage), dbs: indexedDB.databases ? (await indexedDB.databases()).map(d => d.name) : [] }));
 const ck = (await c.cookies()).some(k => /old123|P02_plain/.test(k.value));
 await p.getByRole('button', { name: 'Share this tool' }).first().click(); await p.waitForTimeout(1500); const clip = await p.evaluate(() => navigator.clipboard.readText().catch(() => ''));
 await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3000); const afterReload = await p.evaluate(() => document.querySelector('main').innerText.includes('P02_'));
 const R = { t: cp.execSync('date "+%F %T %Z"').toString().trim(), requests: n, postBytes: bytes, hits, store, cookieHit: ck, shareClip: clip, afterReloadFileShown: afterReload }; fs.writeFileSync('/workspace/deep/38-pdf-to-jpg/live/privacy.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R)); await b.close(); })();
