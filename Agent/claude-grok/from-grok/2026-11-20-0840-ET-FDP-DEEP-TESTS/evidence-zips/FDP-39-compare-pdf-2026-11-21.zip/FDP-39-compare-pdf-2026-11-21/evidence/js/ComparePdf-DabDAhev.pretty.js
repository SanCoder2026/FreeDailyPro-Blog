import { r as N, j as e } from "./vendor-react-D01g8YgM.js";
import { T as re } from "./ToolWithSidebar-C7kxZj7O.js";
import {
  F as q,
  P as oe,
  D as ie,
  k as le,
  d as K,
} from "./ToolPage-DwLoDncN.js";
import { B, N as W, b as ce, f as de } from "./index-B1CTyGtY.js";
import { b as pe } from "./utils-s8ucLyj8.js";
import { d as ee } from "./textDiff-DxE9AzvO.js";
import { k as me, S as X, u as I } from "./index-BRvxULIc.js";
import { c as he } from "./pdfFonts-Ckcqm3Ic.js";
import { p as fe, U as ge } from "./protectedPdfNotice-Dl0m_ReY.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
const ue = /^(page\s*)?\d{1,4}(\s*(of|\/)\s*\d{1,4})?$/i,
  xe = /^(\d+(\.\d+)*[.)]|\(?[a-z]\)|[•▪◦\-–—*])\s/i,
  ye = /[.!?:;”"')\]]$/,
  T = (t) => t.replace(/\s+/g, " ").trim(),
  Y = (t) => t.toLowerCase().replace(/\d+/g, "#");
function ve(t) {
  const a = (o) => {
      const r = o.pageHeightPt ?? 842;
      return o.topPt < r * 0.09 || o.topPt > r * 0.9;
    },
    s = new Map();
  for (const o of t) {
    const r = new Set();
    for (const l of o) a(l) && r.add(Y(T(l.text)));
    Array.from(r).forEach((l) => s.set(l, (s.get(l) ?? 0) + 1));
  }
  return t.map((o) =>
    o.filter((r) => {
      if (!a(r)) return !0;
      const l = T(r.text);
      return ue.test(l)
        ? !1
        : !(t.length >= 2 && (s.get(Y(l)) ?? 0) >= 2 && l.length < 90);
    }),
  );
}
function we(t) {
  const a = ve(t),
    s = [];
  let o = null;
  return (
    a.forEach((r, l) => {
      const i = [];
      for (let g = 1; g < r.length; g++) {
        const u = r[g].topPt - r[g - 1].topPt;
        u > 0 && i.push(u);
      }
      i.sort((g, u) => g - u);
      const m = i.length ? i[Math.floor(i.length * 0.4)] : 12,
        h = [];
      let d = [];
      const v = () => {
        d.length && (h.push({ text: je(d), page: l + 1 }), (d = []));
      };
      (r.forEach((g, u) => {
        const c = T(g.text);
        if (!c) return;
        const f = u > 0 ? g.topPt - r[u - 1].topPt : 0;
        (d.length && (f > m * 1.45 || xe.test(c)) && v(), d.push(c));
      }),
        v(),
        o &&
          h.length &&
          !ye.test(o.text) &&
          /^[a-z]/.test(h[0].text) &&
          ((o.text = T(o.text + " " + h[0].text)), h.shift()),
        s.push(...h),
        (o =
          s.length && s[s.length - 1].page === l + 1 ? s[s.length - 1] : null));
    }),
    s
  );
}
function je(t) {
  let a = "";
  for (const s of t) {
    if (!a) {
      a = s;
      continue;
    }
    /[A-Za-z]-$/.test(a) && /^[a-z]/.test(s)
      ? (a = a.slice(0, -1) + s)
      : (a += " " + s);
  }
  return T(a);
}
const M = (t) => t.split(/\s+/).filter(Boolean);
function be(t, a) {
  const s = new Set(M(t.toLowerCase())),
    o = new Set(M(a.toLowerCase()));
  if (!s.size || !o.size) return 0;
  let r = 0;
  return (
    s.forEach((l) => {
      o.has(l) && r++;
    }),
    r / (s.size + o.size - r)
  );
}
function te(t, a) {
  const s = ee(M(t), M(a)),
    o = [],
    r = [],
    l = (i, m, h) => {
      const d = i[i.length - 1];
      d && d.type === m ? (d.text += " " + h) : i.push({ type: m, text: h });
    };
  for (const i of s)
    i.type === "same"
      ? (l(o, "same", i.text), l(r, "same", i.text))
      : i.type === "remove"
        ? l(o, "remove", i.text)
        : l(r, "add", i.text);
  return { before: o, after: r };
}
function Pe(t, a) {
  const s = ee(
      t.map((m) => m.text),
      a.map((m) => m.text),
    ),
    o = [];
  let r = 0,
    l = 0,
    i = 0;
  for (; i < s.length;) {
    const m = s[i];
    if (m.type === "same") {
      (o.push({
        type: "same",
        text: m.text,
        pageA: t[r].page,
        pageB: a[l].page,
      }),
        r++,
        l++,
        i++);
      continue;
    }
    const h = [],
      d = [];
    for (; i < s.length && s[i].type === "remove";) (h.push(r++), i++);
    for (; i < s.length && s[i].type === "add";) (d.push(l++), i++);
    let v = 0;
    const g = new Map();
    for (const f of h) {
      let j = -1,
        A = 0.4;
      for (let D = v; D < d.length; D++) {
        const $ = be(t[f].text, a[d[D]].text);
        $ > A && ((A = $), (j = D));
      }
      j >= 0 && (g.set(f, j), (v = j + 1));
    }
    const u = new Set(g.values());
    let c = 0;
    for (const f of h) {
      const j = g.get(f);
      if (j === void 0) {
        o.push({ type: "remove", text: t[f].text, pageA: t[f].page });
        continue;
      }
      for (; c < j;)
        (u.has(c) ||
          o.push({ type: "add", text: a[d[c]].text, pageB: a[d[c]].page }),
          c++);
      const A = te(t[f].text, a[d[j]].text);
      (o.push({
        type: "change",
        before: A.before,
        after: A.after,
        pageA: t[f].page,
        pageB: a[d[j]].page,
      }),
        (c = j + 1));
    }
    for (; c < d.length;)
      (u.has(c) ||
        o.push({ type: "add", text: a[d[c]].text, pageB: a[d[c]].page }),
        c++);
  }
  return ke(o);
}
function ke(t) {
  const a = [];
  let s = 0;
  for (; s < t.length;) {
    if (t[s].type === "same") {
      a.push(t[s++]);
      continue;
    }
    let o = s;
    for (; o < t.length && t[o].type !== "same";) o++;
    const r = t.slice(s, o);
    if (((s = o), !r.some((c) => c.type === "remove" || c.type === "add"))) {
      a.push(...r);
      continue;
    }
    const l = (c) => c.map((f) => f.text).join(" "),
      i = [],
      m = [];
    for (const c of r)
      c.type === "remove"
        ? i.push(c.text)
        : c.type === "add"
          ? m.push(c.text)
          : c.type === "change" && (i.push(l(c.before)), m.push(l(c.after)));
    const h = T(i.join(" ")),
      d = T(m.join(" ")),
      v = r.map((c) => ("pageA" in c ? c.pageA : 0)).find(Boolean) ?? 0,
      g = r.map((c) => ("pageB" in c ? c.pageB : 0)).find(Boolean) ?? 0;
    if (h === d) {
      a.push({ type: "same", text: d, pageA: v || g, pageB: g || v });
      continue;
    }
    if (!h) {
      a.push(...r);
      continue;
    }
    if (!d) {
      a.push(...r);
      continue;
    }
    if (r.length === 1) {
      a.push(...r);
      continue;
    }
    const u = te(h, d);
    a.push({
      type: "change",
      before: u.before,
      after: u.after,
      pageA: v || g,
      pageB: g || v,
    });
  }
  return a;
}
const Ne = (t) => t.filter((a) => a.type !== "same").length,
  G = 3e3;
async function J(t) {
  const a = await pe(t),
    s = a.map((o, r) => (o.length === 0 ? r + 1 : 0)).filter(Boolean);
  return { paragraphs: we(a), numPages: a.length, emptyPages: s };
}
async function Ae(t, a) {
  const [s, o] = await Promise.all([J(t), J(a)]),
    r = [];
  if (
    (s.paragraphs.length === 0 && r.push("original"),
    o.paragraphs.length === 0 && r.push("revised"),
    r.length > 0)
  )
    return { kind: "scanned", which: r, a: s, b: o };
  if (s.paragraphs.length > G || o.paragraphs.length > G)
    return { kind: "too-large" };
  const l = Pe(s.paragraphs, o.paragraphs);
  return { kind: "diff", entries: l, changes: Ne(l), a: s, b: o };
}
const De = (t) =>
  Array.from(t)
    .map((a) => (he(a.codePointAt(0)) ? a : "?"))
    .join("");
function $e(t) {
  const a = (t.date ?? new Date()).toISOString().slice(0, 10),
    s = [
      "PDF COMPARISON REPORT",
      `Original: ${t.nameA} (${t.pagesA} pages)`,
      `Revised:  ${t.nameB} (${t.pagesB} pages)`,
      `Date: ${a}`,
      `Changes: ${t.changes}`,
      "",
    ];
  let o = 0;
  for (const r of t.entries)
    r.type !== "same" &&
      (o++,
      r.type === "remove"
        ? s.push(`${o}. REMOVED (original p. ${r.pageA})`, `   - ${r.text}`, "")
        : r.type === "add"
          ? s.push(`${o}. ADDED (revised p. ${r.pageB})`, `   + ${r.text}`, "")
          : (s.push(
              `${o}. CHANGED (original p. ${r.pageA}, revised p. ${r.pageB})`,
            ),
            s.push(
              `   - ${r.before.map((l) => (l.type === "remove" ? `[-${l.text}-]` : l.text)).join(" ")}`,
            ),
            s.push(
              `   + ${r.after.map((l) => (l.type === "add" ? `[+${l.text}+]` : l.text)).join(" ")}`,
              "",
            )));
  return (
    o === 0 && s.push("The two files have the same text."),
    s.join(`
`)
  );
}
async function Fe(t) {
  const a = await me.create(),
    s = await a.embedFont(X.Helvetica),
    o = await a.embedFont(X.HelveticaBold),
    r = 595.28,
    l = 841.89,
    i = 48,
    m = 13;
  let h = a.addPage([r, l]),
    d = l - i,
    v = !1;
  const g = (p) => {
      const b = De(p);
      return (b !== p && (v = !0), b);
    },
    u = () => {
      ((h = a.addPage([r, l])), (d = l - i));
    },
    c = (p) => {
      d - p < i && u();
    },
    f = (p, b = s, x = 10, w = I(0.1, 0.1, 0.1)) => {
      (c(x + 4),
        h.drawText(g(p), { x: i, y: d - x, size: x, font: b, color: w }),
        (d -= x + 6));
    };
  (f("PDF comparison report", o, 20),
    (d -= 4),
    f(`Original: ${t.nameA} (${t.pagesA} page${t.pagesA === 1 ? "" : "s"})`),
    f(`Revised: ${t.nameB} (${t.pagesB} page${t.pagesB === 1 ? "" : "s"})`),
    f(`Date: ${(t.date ?? new Date()).toISOString().slice(0, 10)}`));
  const j = t.entries.filter((p) => p.type === "add").length,
    A = t.entries.filter((p) => p.type === "remove").length,
    D = t.entries.filter((p) => p.type === "change").length;
  (f(
    `${t.changes} change${t.changes === 1 ? "" : "s"}: ${D} edited, ${j} added, ${A} removed`,
    o,
    11,
  ),
    (d -= 6),
    t.changes === 0 && f("The two files have the same text."));
  const $ = I(0.75, 0.1, 0.1),
    z = I(0.05, 0.5, 0.2),
    R = I(0.2, 0.2, 0.2),
    S = (p, b) => {
      let w = i + b;
      c(m);
      for (const P of p)
        for (const L of g(P.text).split(/\s+/).filter(Boolean)) {
          const O = s.widthOfTextAtSize(L, 10),
            U = s.widthOfTextAtSize(" ", 10);
          if (
            (w + O > r - i && ((w = i + b), (d -= m), c(m)),
            h.drawText(L, {
              x: w,
              y: d - 10,
              size: 10,
              font: s,
              color: P.color,
            }),
            P.mark)
          ) {
            const H = P.mark === "strike" ? d - 6.5 : d - 10 - 1.5;
            h.drawLine({
              start: { x: w, y: H },
              end: { x: w + O, y: H },
              thickness: 0.7,
              color: P.color,
            });
          }
          w += O + U;
        }
      d -= m + 2;
    },
    _ = (p, b) =>
      p.map((x) => ({
        text: x.text,
        color: x.type === "same" ? R : b === "before" ? $ : z,
        mark: x.type === "same" ? void 0 : b === "before" ? "strike" : "under",
      }));
  let E = 0;
  for (const p of t.entries) {
    if (p.type === "same") continue;
    (E++, c(m * 3));
    const b =
      p.type === "remove"
        ? `${E}. Removed — original page ${p.pageA}`
        : p.type === "add"
          ? `${E}. Added — revised page ${p.pageB}`
          : `${E}. Changed — original page ${p.pageA}, revised page ${p.pageB}`;
    (f(b, o, 10),
      p.type === "remove"
        ? S([{ text: p.text, color: $, mark: "strike" }], 10)
        : p.type === "add"
          ? S([{ text: p.text, color: z, mark: "under" }], 10)
          : (S(_(p.before, "before"), 10), S(_(p.after, "after"), 10)),
      (d -= 4));
  }
  return (
    v &&
      (c(20),
      h.drawText(
        "Characters outside Latin-1 are shown as ? in this report; the on-screen comparison shows them.",
        { x: i, y: d - 9, size: 8, font: s, color: I(0.4, 0.4, 0.4) },
      )),
    a.setTitle("PDF comparison report"),
    a.setProducer("FreeDailyPro"),
    a.save()
  );
}
function Be(t, a) {
  return t.type === "application/pdf" || /\.pdf$/i.test(t.name)
    ? a
      ? { kind: "locked", name: t.name }
      : null
    : { kind: "not-pdf", name: t.name };
}
const Q = {
    what: `Compares two versions of a PDF — a contract before and after edits, two drafts of a report — and highlights exactly what text was added or removed between them, the same way a redline comparison works.

Honestly: this compares the real, underlying text content of both PDFs — it doesn't render or compare a pixel-level visual appearance of the pages. A purely visual difference (a font change, a color change, an image moved slightly) with no actual text change behind it won't be flagged. If either PDF is a scanned image with no real text layer, run it through OCR PDF first to add one before comparing.`,
    tip: "This compares the real text content of both PDFs, not a visual/pixel comparison — so it catches actual wording changes reliably, but won't flag purely visual differences like a font or color change with no text change behind it. If a PDF is a scan with no selectable text, OCR PDF first to give it a real text layer before comparing.",
  },
  C = ({ parts: t, side: a }) =>
    e.jsx(e.Fragment, {
      children: t.map((s, o) =>
        e.jsxs(
          "span",
          {
            children: [
              s.type === "same"
                ? s.text
                : a === "before"
                  ? e.jsx("span", {
                      className:
                        "bg-red-500/20 text-red-700 dark:text-red-300 line-through decoration-red-500/70 rounded px-0.5",
                      children: s.text,
                    })
                  : e.jsx("span", {
                      className:
                        "bg-green-500/20 text-green-700 dark:text-green-300 underline decoration-green-500/70 rounded px-0.5",
                      children: s.text,
                    }),
              " ",
            ],
          },
          o,
        ),
      ),
    });
function pt() {
  const [t, a] = N.useState(null),
    [s, o] = N.useState(null),
    [r, l] = N.useState(!1),
    [i, m] = N.useState(null),
    [h, d] = N.useState("unified"),
    [v, g] = N.useState(!0),
    [u, c] = N.useState(0),
    f = N.useRef([]),
    [j, A] = N.useState(null),
    [D, $] = N.useState(null),
    [z, R] = N.useState(""),
    S = (n, y) => (k) => {
      const F = k[0];
      if ((m(null), R(""), !F)) return;
      const Z = Be(F, le(F));
      (y(Z), n(Z ? null : F));
    },
    _ = N.useCallback(S(a, A), []),
    E = N.useCallback(S(o, $), []),
    p = (n) =>
      n.kind === "locked"
        ? e.jsxs(e.Fragment, {
            children: [
              fe(n.name, "compared"),
              " ",
              e.jsx("a", {
                href: ge,
                className: "underline font-medium",
                children: "Unlock it with Unlock PDF",
              }),
              ", then drop the unlocked copy here.",
            ],
          })
        : e.jsxs(e.Fragment, {
            children: ["“", n.name, "” is not a PDF. Choose a PDF file."],
          }),
    b = async () => {
      if (!(!t || !s)) {
        (l(!0), R(""), m(null), c(0));
        try {
          m(await Ae(t, s));
        } catch (n) {
          (console.error("PDF comparison failed:", n),
            R(
              "Couldn't compare these PDFs. One may be damaged (try Repair PDF) or password-protected (try Unlock PDF).",
            ));
        } finally {
          l(!1);
        }
      }
    },
    x = i?.kind === "diff" ? i : null,
    w = x?.entries ?? [],
    P = w.map((n, y) => (n.type === "same" ? -1 : y)).filter((n) => n >= 0),
    L = (n) => {
      if (P.length === 0) return;
      const y = ((n % P.length) + P.length) % P.length;
      (c(y),
        f.current[P[y]]?.scrollIntoView({
          block: "center",
          behavior: "smooth",
        }));
    },
    O = () => ({
      nameA: t.name,
      nameB: s.name,
      entries: w,
      changes: x.changes,
      pagesA: x.a.numPages,
      pagesB: x.b.numPages,
    }),
    U = async () => {
      if (!(!x || !t || !s))
        try {
          const n = await Fe(O());
          K(
            new Blob([n], { type: "application/pdf" }),
            "pdf-comparison-report.pdf",
          );
        } catch (n) {
          (console.error(n), de.error("Couldn't build the report"));
        }
    },
    H = () => {
      !x ||
        !t ||
        !s ||
        K(
          new Blob([$e(O())], { type: "text/plain" }),
          "pdf-comparison-report.txt",
        );
    },
    se = (n) =>
      n.type === "same"
        ? ""
        : n.type === "remove"
          ? `p. ${n.pageA}`
          : n.type === "add"
            ? `p. ${n.pageB}`
            : n.pageA === n.pageB
              ? `p. ${n.pageA}`
              : `p. ${n.pageA} → ${n.pageB}`,
    ne = () =>
      e.jsx("div", {
        className:
          "rounded-lg border text-sm max-h-[560px] overflow-y-auto divide-y",
        children: w.map((n, y) => {
          if (n.type === "same")
            return v
              ? e.jsx(
                  "div",
                  {
                    className: "px-3 py-1.5 text-muted-foreground",
                    children: n.text,
                  },
                  y,
                )
              : null;
          const k = P[u] === y;
          return e.jsxs(
            "div",
            {
              ref: (F) => {
                f.current[y] = F;
              },
              className: `px-3 py-2 space-y-1 ${k ? "bg-primary/10" : "bg-muted/30"}`,
              children: [
                e.jsxs("span", {
                  className:
                    "text-[10px] uppercase tracking-wide text-muted-foreground",
                  children: [
                    n.type === "change"
                      ? "Changed"
                      : n.type === "add"
                        ? "Added"
                        : "Removed",
                    " · ",
                    se(n),
                  ],
                }),
                n.type === "remove" &&
                  e.jsx("div", {
                    children: e.jsx(C, {
                      parts: [{ type: "remove", text: n.text }],
                      side: "before",
                    }),
                  }),
                n.type === "add" &&
                  e.jsx("div", {
                    children: e.jsx(C, {
                      parts: [{ type: "add", text: n.text }],
                      side: "after",
                    }),
                  }),
                n.type === "change" &&
                  e.jsxs(e.Fragment, {
                    children: [
                      e.jsx("div", {
                        children: e.jsx(C, { parts: n.before, side: "before" }),
                      }),
                      e.jsx("div", {
                        children: e.jsx(C, { parts: n.after, side: "after" }),
                      }),
                    ],
                  }),
              ],
            },
            y,
          );
        }),
      }),
    ae = () =>
      e.jsxs("div", {
        className: "rounded-lg border text-sm max-h-[560px] overflow-y-auto",
        children: [
          e.jsxs("div", {
            className:
              "grid grid-cols-2 divide-x sticky top-0 bg-background border-b text-xs font-medium text-muted-foreground",
            children: [
              e.jsx("div", { className: "px-3 py-1", children: "Original" }),
              e.jsx("div", { className: "px-3 py-1", children: "Revised" }),
            ],
          }),
          w.map((n, y) => {
            const k = n.type !== "same" && P[u] === y;
            return e.jsxs(
              "div",
              {
                ref: (F) => {
                  f.current[y] = F;
                },
                className: `grid grid-cols-2 divide-x border-b ${k ? "bg-primary/10" : ""}`,
                children: [
                  e.jsx("div", {
                    className: "px-3 py-1.5",
                    children:
                      n.type === "same"
                        ? e.jsx("span", {
                            className: "text-muted-foreground",
                            children: n.text,
                          })
                        : n.type === "add"
                          ? " "
                          : n.type === "remove"
                            ? e.jsx(C, {
                                parts: [{ type: "remove", text: n.text }],
                                side: "before",
                              })
                            : e.jsx(C, { parts: n.before, side: "before" }),
                  }),
                  e.jsx("div", {
                    className: "px-3 py-1.5",
                    children:
                      n.type === "same"
                        ? e.jsx("span", {
                            className: "text-muted-foreground",
                            children: n.text,
                          })
                        : n.type === "remove"
                          ? " "
                          : n.type === "add"
                            ? e.jsx(C, {
                                parts: [{ type: "add", text: n.text }],
                                side: "after",
                              })
                            : e.jsx(C, { parts: n.after, side: "after" }),
                  }),
                ],
              },
              y,
            );
          }),
        ],
      }),
    V = (n, y) => {
      const k = x?.[y];
      return !k || k.emptyPages.length === 0
        ? null
        : e.jsxs(W, {
            className: "text-xs",
            children: [
              n,
              ": page",
              k.emptyPages.length === 1 ? "" : "s",
              " ",
              k.emptyPages.slice(0, 10).join(", "),
              k.emptyPages.length > 10 ? "…" : "",
              " ha",
              k.emptyPages.length === 1 ? "s" : "ve",
              " no text (scanned?), so ",
              k.emptyPages.length === 1 ? "it was" : "they were",
              " not compared.",
            ],
          });
    };
  return e.jsx(re, {
    toolId: "compare-pdf",
    categoryId: "pdf-tools",
    whatItDoes: Q.what,
    proTip: Q.tip,
    children: e.jsxs("div", {
      className: "space-y-4",
      children: [
        e.jsxs("div", {
          className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
          children: [
            e.jsxs("div", {
              children: [
                e.jsx("p", {
                  className: "text-sm font-medium mb-2",
                  children: "Original",
                }),
                t
                  ? e.jsx("div", {
                      className: "p-3 rounded-lg border bg-card text-sm",
                      children: t.name,
                    })
                  : e.jsx(q, {
                      gateAtDownload: !0,
                      keepSkippedProtectedFiles: !0,
                      accept: "*",
                      acceptLabel: "PDF",
                      onFiles: _,
                      label: "Drop original PDF",
                      description: "PDF files only",
                    }),
                j &&
                  e.jsx("p", {
                    role: "alert",
                    className: "text-sm text-destructive mt-2",
                    children: p(j),
                  }),
              ],
            }),
            e.jsxs("div", {
              children: [
                e.jsx("p", {
                  className: "text-sm font-medium mb-2",
                  children: "Revised",
                }),
                s
                  ? e.jsx("div", {
                      className: "p-3 rounded-lg border bg-card text-sm",
                      children: s.name,
                    })
                  : e.jsx(q, {
                      gateAtDownload: !0,
                      keepSkippedProtectedFiles: !0,
                      accept: "*",
                      acceptLabel: "PDF",
                      onFiles: E,
                      label: "Drop revised PDF",
                      description: "PDF files only",
                    }),
                D &&
                  e.jsx("p", {
                    role: "alert",
                    className: "text-sm text-destructive mt-2",
                    children: p(D),
                  }),
              ],
            }),
          ],
        }),
        t &&
          s &&
          !i &&
          e.jsx("div", {
            className: "flex gap-3",
            children: r
              ? e.jsx(oe, { message: "Comparing..." })
              : e.jsx(B, { onClick: b, children: "Compare PDFs" }),
          }),
        z &&
          e.jsx("p", {
            role: "alert",
            className: "text-sm text-destructive",
            children: z,
          }),
        i?.kind === "too-large" &&
          e.jsxs("p", {
            className:
              "text-sm text-center text-muted-foreground p-4 border rounded-lg bg-muted/30",
            children: [
              "One of these PDFs has more than ",
              G,
              " paragraphs — comparison is skipped to keep your browser responsive.",
            ],
          }),
        i?.kind === "scanned" &&
          e.jsxs(W, {
            role: "alert",
            className: "text-sm p-4 space-y-2",
            children: [
              e.jsxs("p", {
                children: [
                  i.which.length === 2
                    ? "Both files look"
                    : `The ${i.which[0]} file looks`,
                  " like ",
                  i.which.length === 2 ? "scanned images" : "a scanned image",
                  " with no text to compare. Run ",
                  i.which.length === 2 ? "them" : "it",
                  " through ",
                  e.jsx(ce, {
                    href: "/tool/ocr-pdf",
                    className: "underline font-medium",
                    children: "OCR PDF",
                  }),
                  " first, then compare the results.",
                ],
              }),
              e.jsx(B, {
                variant: "outline",
                size: "sm",
                onClick: () => {
                  (a(null), o(null), m(null), A(null), $(null), R(""));
                },
                children: "New Comparison",
              }),
            ],
          }),
        x &&
          e.jsxs("div", {
            className: "space-y-3",
            children: [
              x.changes === 0
                ? e.jsx(W, {
                    className: "text-sm font-medium",
                    children:
                      "These two files have the same text. Differences in layout, fonts or line breaks are not counted.",
                  })
                : e.jsxs("div", {
                    className:
                      "flex items-center justify-between flex-wrap gap-2",
                    children: [
                      e.jsxs("div", {
                        className: "flex gap-3 text-sm items-center flex-wrap",
                        children: [
                          e.jsxs("span", {
                            className: "font-medium",
                            children: [
                              x.changes,
                              " change",
                              x.changes === 1 ? "" : "s",
                            ],
                          }),
                          e.jsxs("span", {
                            className: "text-green-600",
                            children: [
                              w.filter((n) => n.type === "add").length,
                              " added",
                            ],
                          }),
                          e.jsxs("span", {
                            className: "text-red-600",
                            children: [
                              w.filter((n) => n.type === "remove").length,
                              " removed",
                            ],
                          }),
                          e.jsxs("span", {
                            className: "text-muted-foreground",
                            children: [
                              w.filter((n) => n.type === "change").length,
                              " edited",
                            ],
                          }),
                        ],
                      }),
                      e.jsxs("div", {
                        className: "flex items-center gap-2 text-sm",
                        children: [
                          e.jsx(B, {
                            size: "sm",
                            variant: "outline",
                            onClick: () => L(u - 1),
                            children: "Previous",
                          }),
                          e.jsxs("span", {
                            children: ["Change ", u + 1, " of ", P.length],
                          }),
                          e.jsx(B, {
                            size: "sm",
                            variant: "outline",
                            onClick: () => L(u + 1),
                            children: "Next change",
                          }),
                        ],
                      }),
                    ],
                  }),
              V(t?.name ?? "Original", "a"),
              V(s?.name ?? "Revised", "b"),
              e.jsxs("div", {
                className: "flex items-center justify-between flex-wrap gap-2",
                children: [
                  e.jsxs("div", {
                    className: "flex gap-1",
                    children: [
                      e.jsx(B, {
                        size: "sm",
                        variant: h === "unified" ? "default" : "outline",
                        onClick: () => d("unified"),
                        children: "Unified",
                      }),
                      e.jsx(B, {
                        size: "sm",
                        variant: h === "side-by-side" ? "default" : "outline",
                        onClick: () => d("side-by-side"),
                        children: "Side by Side",
                      }),
                      e.jsxs("label", {
                        className: "flex items-center gap-1.5 text-xs ml-3",
                        children: [
                          e.jsx("input", {
                            type: "checkbox",
                            checked: v,
                            onChange: (n) => g(n.target.checked),
                          }),
                          "Show unchanged text",
                        ],
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className: "flex gap-2 flex-wrap",
                    children: [
                      e.jsx(ie, { onClick: U, label: "Report (PDF)" }),
                      e.jsx(B, {
                        variant: "outline",
                        size: "sm",
                        onClick: H,
                        children: "Report (.txt)",
                      }),
                      e.jsx(B, {
                        variant: "outline",
                        size: "sm",
                        onClick: () => {
                          (a(null), o(null), m(null), A(null), $(null), R(""));
                        },
                        children: "New Comparison",
                      }),
                    ],
                  }),
                ],
              }),
              h === "unified" ? ne() : ae(),
            ],
          }),
      ],
    }),
  });
}
export { pt as default };
//# sourceMappingURL=ComparePdf-DabDAhev.js.map
