const f = 3e3;
function u(n, o) {
  const p = n.length,
    i = o.length,
    r = Array.from({ length: p + 1 }, () => new Array(i + 1).fill(0));
  for (let s = p - 1; s >= 0; s--)
    for (let l = i - 1; l >= 0; l--)
      r[s][l] =
        n[s] === o[l]
          ? r[s + 1][l + 1] + 1
          : Math.max(r[s + 1][l], r[s][l + 1]);
  const h = [];
  let e = 0,
    t = 0;
  for (; e < p && t < i;)
    n[e] === o[t]
      ? (h.push({ type: "same", text: n[e] }), e++, t++)
      : r[e + 1][t] >= r[e][t + 1]
        ? (h.push({ type: "remove", text: n[e] }), e++)
        : (h.push({ type: "add", text: o[t] }), t++);
  for (; e < p;) (h.push({ type: "remove", text: n[e] }), e++);
  for (; t < i;) (h.push({ type: "add", text: o[t] }), t++);
  return h;
}
export { f as M, u as d };
//# sourceMappingURL=textDiff-DxE9AzvO.js.map
