// compare-pdf gate + report downloads. Part 1 (uses-left context, up to 14 fresh contexts): C01 vs C02 Compare (usage before/after) -> Report (PDF) A, again A2, Report (.txt) T, Drive/cloud (stop at sign-in),
// New Comparison + C08/C09 -> Report (.txt) B, New + C06/C07 -> Report (PDF) C, reload + C01/C03 -> Report (.txt) D, reload + C13/C14 -> Report (PDF) E.
// Part 2 (context at 0): keyboard; C06/C07 Compare -> on-screen diff incl. page 37 change; Report (.txt) and Report (PDF) -> cap dialog? -> Day Pass (email prompt, types nothing); Quick Buy day/monthly (stop). Guest.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const crypto = require('crypto');
const BASE = '/workspace/deep/39-compare-pdf/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/compare-pdf';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex').slice(0, 16);
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').slice(0, 160);
(async () => { const b = await chromium.launch(); const R = { t: now(), tries: [] }; let c, p;
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); p = await c.newPage(); p.setDefaultTimeout(15000); await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 const convert = async (files) => { const fi = p.locator('main input[type=file]'); await fi.first().setInputFiles(TF + files[0]); await p.waitForTimeout(1500); await fi.last().setInputFiles(TF + files[1]); await p.waitForTimeout(2000);
   const u0 = await used(); await p.getByRole('button', { name: /^Compare PDFs/ }).click(); await p.waitForFunction(() => /\d+ changes?|No differences|identical|scanned|couldn't|skipped/i.test(document.querySelector('main').innerText), null, { timeout: 120000 }).catch(() => {}); await p.waitForTimeout(1500);
   return { files, usedBefore: u0, used: await used(), summary: await p.evaluate(() => { const t = document.querySelector('main').innerText; const m = t.match(/\d+ changes?[\s\S]{0,80}|No [^\n]*differen[^\n]*|[^\n]*identical[^\n]*/i); return m ? m[0].replace(/\n/g, ' | ') : null; }), diff: await p.evaluate(() => { const t = document.querySelector('main').innerText; const i = t.indexOf('New Comparison'); const j = t.indexOf('Watch: Compare'); return i > 0 ? t.slice(i + 14, j > i ? j : i + 3000).trim().slice(0, 2500) : null; }), dlNote: await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*Day Pass to download[^\n]*|[^\n]*uses 1 trial use[^\n]*/g) || []).join(' | ')), toasts: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim().replace(/\n/g, ' '))) }; };
 const act = async (name, loc) => { const r = { before: await used() }; if (!(await loc.count())) { r.missing = true; return r; }
   const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); const dl = p.waitForEvent('download', { timeout: 15000 }).catch(() => null); const url0 = p.url(); await loc.first().click(); const [pg, d] = await Promise.all([pop, dl]); await p.waitForTimeout(2000);
   r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null; r.t = now();
   if (d) { r.download = d.suggestedFilename(); const f = OUT + 'downloads/gate-' + name + '-' + d.suggestedFilename(); await d.saveAs(f); r.bytes = fs.statSync(f).size; r.sha = sha(f); r.saved = f; }
   if (pg) { await pg.waitForLoadState('domcontentloaded').catch(() => {}); r.popup = red(pg.url()); r.popupTitle = await pg.title().catch(() => null); await pg.close(); }
   if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + '.png' });
   if (r.dialog && /Day Pass/.test(r.dialog) && !R.dayPassFromCap) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.dayPassFromCap = { from: name, dialog: await dialog(), emailField: await p.locator('input[type=email]').count(), url: red(p.url()) }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); } }
   await esc(); console.log(name, JSON.stringify(r)); return r; };
 const RP = () => p.getByRole('button', { name: /^Report \(PDF\)/ }); const RT = () => p.getByRole('button', { name: /^Report \(\.txt\)/ });
 const another = async () => { await p.getByRole('button', { name: 'New Comparison' }).click(); await p.waitForTimeout(800); };
 const reload = async () => { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); };
 for (let i = 0; i < 14; i++) { await open(); const u = await used(); R.tries.push(u); if (u < 10) break; await c.close(); c = null; }
 if (c) { const L = R.left = { t: now(), start: await used() };
  L.cA = await convert(['C01_contract_v1.pdf', 'C02_contract_v2.pdf']); L.dlA = await act('A', RP()); L.dlA2 = await act('A2', RP()); L.dlT = await act('T', RT());
  L.drive = await act('drive', p.getByRole('button', { name: /Save to Google Drive/ })); L.cloud = await act('cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
  await another(); L.cB = await convert(['C08_unicode_v1.pdf', 'C09_unicode_v2.pdf']); L.dlB = await act('B', RT());
  await another(); L.cC = await convert(['C06_log_50p_v1.pdf', 'C07_log_50p_v2_p37change.pdf']); L.dlC = await act('C', RP());
  await reload(); L.afterReload = await used(); L.cD = await convert(['C01_contract_v1.pdf', 'C03_contract_v1_restyled.pdf']); L.dlD = await act('D', RT());
  await reload(); L.cE = await convert(['C13_hyphen_v1.pdf', 'C14_hyphen_v2_joined.pdf']); L.dlE = await act('E', RP());
  await reload(); L.end = await used(); L.t2 = now(); await c.close(); }
 for (let i = 0; i < 4; i++) { await open(); if (await used() >= 10) break; await c.close(); }
 const Z = R.zero = { t: now(), start: await used() };
 let chooser = false; p.on('filechooser', () => { chooser = true; }); const seq = [];
 for (let i = 0; i < 40; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('role') || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50).replace(/\n/g, ' '); }); seq.push(a); if (/Drop original/i.test(a)) { await p.keyboard.press('Enter'); await p.waitForTimeout(1200); seq.push('ENTER -> chooser=' + chooser); break; } }
 Z.kbd = { tabs: seq.length, last: seq.slice(-3), chooser };
 if (Z.start >= 10) { Z.c = await convert(['C06_log_50p_v1.pdf', 'C07_log_50p_v2_p37change.pdf']); await p.screenshot({ path: OUT + 'zero-result.png', fullPage: false });
  Z.txt = await act('zero-txt', RT()); Z.pdf = await act('zero-pdf', RP()); Z.end = await used();
  await another(); Z.c2 = await convert(['C01_contract_v1.pdf', 'C02_contract_v2.pdf']); await p.getByRole('button', { name: 'Side by Side' }).click().catch(() => {}); await p.waitForTimeout(800); await p.screenshot({ path: OUT + 'zero-sidebyside.png', fullPage: true });
  Z.copySel = await p.evaluate(() => { const r = document.createRange(); r.selectNodeContents(document.querySelector('main')); const s = getSelection(); s.removeAllRanges(); s.addRange(r); return s.toString().includes('USD 14,000'); });
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  const qb = p.getByRole('button', { name: 'Quick Buy' }); const u0 = p.url(); await qb.first().click(); await p.waitForTimeout(3000); Z.qbDay = { url: p.url() !== u0 ? red(p.url()) : null, dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await esc();
  if (p.url() !== u0) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); }
  await p.getByRole('button', { name: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); Z.qbMonth = { url: red(p.url()), dialog: await dialog(), title: await p.title(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' }); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify({ tries: R.tries }, null, 1)); await b.close(); })();
