// compare-pdf live cases (no Download). Reload per case. Records summary, notices, toasts, dialogs, diff text, word-mark HTML, timing, uploads. Guest.
const { chromium, firefox } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/39-compare-pdf/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const CASES = [
 ['K01', 'C01_contract_v1.pdf', 'C02_contract_v2.pdf', { marks: true }], ['K02', 'C01_contract_v1.pdf', 'C02_contract_v2.pdf', { view: 'Side by Side' }], ['K03', 'C01_contract_v1.pdf', 'C02_contract_v2.pdf', { hideSame: true }],
 ['K04', 'C01_contract_v1.pdf', 'C02_contract_v2.pdf', { nav: true }], ['K05', 'C01_contract_v1.pdf', 'C01_contract_v1.pdf', {}], ['K06', 'C01_contract_v1.pdf', 'C03_contract_v1_restyled.pdf', {}],
 ['K07', 'C01_contract_v1.pdf', 'C10_contract_v1_blankpage.pdf', {}], ['K08', 'C04_scanned_v1.pdf', 'C01_contract_v1.pdf', {}], ['K09', 'C05_two_column_v1.pdf', 'C01_contract_v1.pdf', {}],
 ['K10', 'C06_log_50p_v1.pdf', 'C07_log_50p_v2_p37change.pdf', {}], ['K11', 'C08_unicode_v1.pdf', 'C09_unicode_v2.pdf', {}], ['K12', 'C11_3200_paragraphs_v1.pdf', 'C12_3200_paragraphs_v2.pdf', {}],
 ['K13', 'C13_hyphen_v1.pdf', 'C14_hyphen_v2_joined.pdf', {}], ['K14', 'U01_aes256_user_old123.pdf', 'C01_contract_v1.pdf', { pw: 'old123' }], ['K15', 'P06_corrupt.pdf', 'C01_contract_v1.pdf', {}],
 ['K16', 'P07_text_renamed.pdf', 'C01_contract_v1.pdf', {}], ['K17', 'C04_scanned_v1.pdf', 'C04_scanned_v1.pdf', {}], ['K18', 'C02_contract_v2.pdf', 'C01_contract_v1.pdf', {}],
 ['K19', 'U01_aes256_user_old123.pdf', 'C01_contract_v1.pdf', { skip: true }],
];
const eng = process.argv[2] === 'firefox' ? firefox : chromium; const only = process.argv[3] ? process.argv[3].split(',') : null;
(async () => { const b = await eng.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(15000);
 const reqs = []; p.on('request', r => { const d = r.postDataBuffer(); if (d && d.length > 1500 && !/googlesyndication/.test(r.url())) reqs.push(r.method() + ' ' + r.url().slice(0, 100) + ' ' + d.length); });
 const ALL = { t: now(), engine: process.argv[2] || 'chromium', cases: [] }; const main = () => p.evaluate(() => document.querySelector('main').innerText);
 const dlg = async () => { const d = p.locator('[role=dialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null; };
 const handle = async (R, o) => { const d = await dlg(); if (!d) return; R.dialogs = (R.dialogs || []).concat(d); const dd = p.locator('[role=dialog]'); if (o.pw && !o.skip) { await dd.locator('input').first().fill(o.pw); await p.getByRole('button', { name: 'Unlock' }).click(); } else { await p.getByRole('button', { name: /Skip this file|Cancel/ }).first().click().catch(() => {}); } await p.waitForTimeout(2000); };
 for (const [id, A, B, o] of CASES) { if (only && !only.includes(id)) continue; const R = { id, A, B, o, t: now() }; const n0 = reqs.length;
  try { await p.goto('https://www.freedailypro.com/tool/compare-pdf', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(3000);
   const fi = p.locator('main input[type=file]'); await fi.first().setInputFiles(TF + A); await p.waitForTimeout(2000); await handle(R, o);
   R.afterA = await p.evaluate(() => [...document.querySelectorAll('main [role=alert]')].map(e => e.innerText.trim()).join(' | ')); R.toastsA = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim().replace(/\n/g, ' ')));
   if (await fi.count()) { await fi.last().setInputFiles(TF + B); await p.waitForTimeout(2000); await handle(R, o); }
   R.slots = await p.evaluate(() => { const t = document.querySelector('main').innerText; const i = t.indexOf('Original'); return t.slice(i, i + 200).replace(/\n+/g, ' | '); });
   const cb = p.getByRole('button', { name: /^Compare PDFs/ }); R.compareEnabled = (await cb.count()) ? !(await cb.isDisabled()) : false;
   if (R.compareEnabled) { const t0 = Date.now(); await cb.click(); await p.waitForFunction(() => /\d+ changes?\n|same text|scanned|couldn't|skipped|too (large|long)|limit/i.test(document.querySelector('main').innerText), null, { timeout: 120000 }).catch(() => {}); R.ms = Date.now() - t0; await p.waitForTimeout(1200);
    if (o.view) { await p.getByRole('button', { name: o.view }).click(); await p.waitForTimeout(800); }
    if (o.hideSame) { await p.getByLabel('Show unchanged text').uncheck(); await p.waitForTimeout(800); }
    if (o.nav) { R.nav = []; for (const k of ['Next change', 'Next change', 'Previous']) { await p.getByRole('button', { name: k }).click(); await p.waitForTimeout(400); R.nav.push(await p.evaluate(() => (document.querySelector('main').innerText.match(/Change \d+ of \d+/) || [''])[0])); } }
    const t = await main(); const i = t.indexOf('Revised'); const j = t.indexOf('Watch: Compare'); R.result = t.slice(i, j > i ? j : i + 3000).replace(/\n+/g, ' ⏎ ').slice(0, 2200);
    R.alerts = await p.evaluate(() => [...document.querySelectorAll('main [role=alert], main [role=status]')].map(e => e.innerText.trim().replace(/\n/g, ' ')).filter(Boolean));
    if (o.marks) R.marks = await p.evaluate(() => { const m = document.querySelector('main'); return [...m.querySelectorAll('del, ins:not(.adsbygoogle), mark, s, u, span[class*="line-through"], span[class*="bg-"]')].slice(0, 10).map(e => ({ tag: e.tagName, cls: e.className.slice(0, 90), text: e.innerText.slice(0, 40), color: getComputedStyle(e).color, bg: getComputedStyle(e).backgroundColor, deco: getComputedStyle(e).textDecorationLine })); });
    R.toasts = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim().replace(/\n/g, ' '))); }
   await p.screenshot({ path: OUT + 'case-' + id + (ALL.engine === 'firefox' ? '-ff' : '') + '.png', fullPage: !!(o.view || o.marks) });
  } catch (e) { R.err = String(e).slice(0, 300); }
  R.reqs = reqs.slice(n0); console.log(JSON.stringify(R).slice(0, 1500)); ALL.cases.push(R); }
 ALL.t2 = now(); fs.writeFileSync(OUT + 'cases-' + ALL.engine + (only ? '-' + only.join('_') : '') + '.json', JSON.stringify(ALL, null, 1)); await b.close(); })();
