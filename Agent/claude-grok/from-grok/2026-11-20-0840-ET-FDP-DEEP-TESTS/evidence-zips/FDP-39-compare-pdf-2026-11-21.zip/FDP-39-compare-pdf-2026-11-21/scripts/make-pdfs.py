# Builds compare-pdf test pairs with reportlab. Run with venv-pdf python.
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from PIL import Image, ImageDraw, ImageFont
import textwrap
pdfmetrics.registerFont(TTFont('DV','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
W,H=letter
BASE=["This Services Agreement is made between Northwind Traders LLC and Contoso Design Ltd. on the Effective Date stated below.",
"1. Scope. The Contractor will deliver the website redesign described in Schedule A, including three rounds of revisions.",
"2. Fees. The Client will pay a fixed fee of USD 12,500, invoiced in two equal instalments, the first on signing.",
"3. Payment terms. Invoices are payable within 30 days of receipt. Late payments accrue interest at 1.5% per month.",
"4. Confidentiality. Each party will keep the other party's confidential information secret during the term and for two years after.",
"5. Termination. Either party may terminate this agreement on 14 days' written notice to the other party.",
"6. Liability. Neither party is liable for indirect or consequential loss. Total liability is capped at the fees paid.",
"7. Governing law. This agreement is governed by the laws of the State of New York.",
"8. Notices. Notices must be sent by email to the addresses listed in Schedule B and are effective on sending.",
"9. Entire agreement. This document is the entire agreement between the parties and replaces all earlier discussions."]
def doc(path,paras,font='Helvetica',size=11,color=(0,0,0),header='NORTHWIND / CONTOSO - CONFIDENTIAL',per_page=4,width=88,blank_page=None,title=None):
  c=canvas.Canvas(path,pagesize=letter); 
  if title: c.setTitle(title)
  pages=[paras[i:i+per_page] for i in range(0,len(paras),per_page)]
  for pi,pg in enumerate(pages):
    if blank_page is not None and pi==blank_page:
      c.showPage()
    c.setFont('Helvetica',8); c.setFillColorRGB(.4,.4,.4); c.drawString(72,H-40,header); c.drawRightString(W-72,40,f'Page {pi+1}')
    c.setFillColorRGB(*color); y=H-90
    for p in pg:
      c.setFont(font,size)
      for line in textwrap.wrap(p,width):
        c.drawString(72,y,line); y-=size*1.35
      y-=size*0.9
    c.showPage()
  c.save()
doc('C01_contract_v1.pdf',BASE,title='Contract v1')
v2=list(BASE)
v2[2]=v2[2].replace('12,500','14,000')                       # number edit
v2[3]=v2[3].replace('30 days','45 days').replace('1.5%','2%')   # two word edits
v2.insert(5,"4A. Non-solicitation. Neither party will hire the other party's staff during the term and for twelve months after.")  # added
del v2[7]                                                       # removed (6. Liability) index shifted
v2[1]=v2[1].replace('three rounds','Three rounds')              # case change
v2[8]=v2[8].replace('sending.','sending')                       # punctuation
doc('C02_contract_v2.pdf',v2,header='NORTHWIND / CONTOSO - CONFIDENTIAL - REV 2',title='Contract v2')
doc('C03_contract_v1_restyled.pdf',BASE,font='Times-Roman',size=12,color=(0,0,.6),width=80,per_page=3)  # visual only + reflow + page breaks
doc('C10_contract_v1_blankpage.pdf',BASE,blank_page=1)
# scanned: image-only page
im=Image.new('RGB',(1275,1650),'white'); d=ImageDraw.Draw(im); f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',26)
y=150
for p in BASE[:5]:
  for l in textwrap.wrap(p,70): d.text((120,y),l,fill='black',font=f); y+=36
  y+=20
im.save('_scan.png'); c=canvas.Canvas('C04_scanned_v1.pdf',pagesize=letter); c.drawImage('_scan.png',0,0,W,H); c.showPage(); c.save()
# two-column
c=canvas.Canvas('C05_two_column_v1.pdf',pagesize=letter); c.setFont('Helvetica',10); y=H-80
L=textwrap.wrap(' '.join(BASE[:3]),45); R=textwrap.wrap(' '.join(BASE[3:6]),45)
for i in range(max(len(L),len(R))):
  if i<len(L): c.drawString(60,y,L[i])
  if i<len(R): c.drawString(320,y,R[i])
  y-=14
c.showPage(); c.save()
# 50 pages, change on page 37
big=[f"Section {i//3+1}.{i%3+1}. The inspection log records reading {i*7%101} for unit {i} at station {chr(65+i%26)}; no defect was noted on this line." for i in range(150)]
doc('C06_log_50p_v1.pdf',big,per_page=3,header='INSPECTION LOG')
big2=list(big); big2[109]=big2[109].replace('no defect was noted','a hairline crack was noted and the unit was quarantined')
doc('C07_log_50p_v2_p37change.pdf',big2,per_page=3,header='INSPECTION LOG')
# unicode
U1=["Café Zürich – Rechnung Nr. 2026/11 über 1.250,00 € für Möbel.","Счёт выдан ООО «Ромашка», срок оплаты 10 дней.","Ελληνικά: Σύμβαση υπηρεσιών, έκδοση 1."]
U2=["Café Zürich – Rechnung Nr. 2026/11 über 1.350,00 € für Möbel.","Счёт выдан ООО «Ромашка», срок оплаты 15 дней.","Ελληνικά: Σύμβαση υπηρεσιών, έκδοση 2."]
doc('C08_unicode_v1.pdf',U1,font='DV'); doc('C09_unicode_v2.pdf',U2,font='DV')
# >3000 paragraphs
many=[f"Line item {i}: part {i:05d}." for i in range(3200)]
doc('C11_3200_paragraphs_v1.pdf',many,per_page=40,width=200)
many2=list(many); many2[1600]='Line item 1600: part CHANGED.'
doc('C12_3200_paragraphs_v2.pdf',many2,per_page=40,width=200)
# hyphenated line end vs not
c=canvas.Canvas('C13_hyphen_v1.pdf',pagesize=letter); c.setFont('Helvetica',11); c.drawString(72,700,'The contractor guarantees uninter-'); c.drawString(72,685,'rupted service for the full term.'); c.showPage(); c.save()
c=canvas.Canvas('C14_hyphen_v2_joined.pdf',pagesize=letter); c.setFont('Helvetica',11); c.drawString(72,700,'The contractor guarantees uninterrupted service for the full term.'); c.showPage(); c.save()
print('ok')
