Sent: 2026-11-21 20:04 ET

# RERUN-FINDINGS

This package is version v2 (FDP-40-extract-pdf-2026-11-21-v2.zip). It **supersedes/extends**: FDP-40-extract-pdf-2026-11-21.zip. Earlier zips are untouched (frozen); anything not mentioned here is unchanged from them.

Run 19:48-19:54 ET `ex-gate.js` (2 contexts: 1 at 10, then one with uses left) and `ex-live.js chromium V` (loaded at 10 remaining, V1-V9 only ran as no-download previews; nothing downloaded).
## Counting per page load (context with uses left, 0 start)
- Download A (E01 pages 2,5): **0 -> 1**; same file again (A2): free; Drive: Google sign-in popup, no charge; cloud: sign-in dialog.
- New file -> B (P01 pages 1-2) download: **free (1 -> 1)**; text extract + Copy text (T): free; Download Text File (C): free; reload keeps 1.
- After reload, new file D (P03 page 37): **1 -> 2**; text of page 3 (E) and copy: free (2).
- So extract-pdf counts about one use per page load, not per file: second and third different files in the same load are free (per-load gap, like merge/sign).
## Content (verify.py)
- A: 2 pages (markers PAGE-2, PAGE-5), bookmarks Chapter 2 and 5 kept, form fields applicant_name and agree_terms kept, badge on 2 pages, not encrypted. B: payslip pages 1-2 with bookmarks and fields kept, badge 2. D: page 37 only. Text file C: 2,238 bytes, 2,210 characters of page text.
- At 0 (Z): text still extractable and copyable, Copy/Download open the cap dialog (unchanged).
- Not covered (V1-V9 did not run live): duplicate "2,2", "6-", odd/even and the typed order 5,1,3 downloads; file name `-pages-1-5.pdf`.
Evidence: live/gate.json, downloads/gate-*, rr/40g.log, rr/40l.log.
