import { r as i, j as e } from "./vendor-react-D01g8YgM.js";
import { u as Q } from "./useShareGate-BYBawloP.js";
import { B as p, e as V, I as W, N as X, f as C } from "./index-B1CTyGtY.js";
import {
  T as Y,
  F as ee,
  P as te,
  D as ae,
  R as se,
} from "./ToolPage-DwLoDncN.js";
import { T as re } from "./ToolInfoSection-C0i6Zbwo.js";
import { l as oe } from "./utils-s8ucLyj8.js";
import { r as ne } from "./pdfPageContent-BLgAwNtO.js";
import { b as le, a as ie, c as ce } from "./pdfLayout-BswErtWz.js";
import { a as pe } from "./pdfMetadata-CcxIhQF2.js";
import { g as me, q as O, B as de } from "./operations-B4LtHhm8.js";
import { u as ue, P as ge, a as he } from "./PdfPageThumbnails-DeGIJGYt.js";
import { T as xe } from "./ToolSteps-DWea1Jiy.js";
import { u as fe } from "./useDownloadedResult-C1FfMpBH.js";
import { C as ye } from "./copy-DcUvE8ta.js";
import "./useExportGate-BU4jIFHF.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./pageView-BQIwVYOi.js";
import "./formAppearance-CdNbuISd.js";
import "./drawTextAnywhere-DcuP6lHH.js";
import "./ocrText-C_9cxcFa.js";
import "./ocrImage-CmXFNUud.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./imageRecompress-eXQFDUm-.js";
import "./formatFileSize-B-JRDfN5.js";
import "./plural-FIChqbp4.js";
import "./textDiff-DxE9AzvO.js";
import "./utils-1EQcVBdK.js";
import "./decode-DrS85i4S.js";
import "./formFill-Dg9Myfyq.js";
import "./redactSearch-DQpyyh_t.js";
import "./nameDetect-DvHCRM0m.js";
function we(d) {
  return d
    .map((r) =>
      r.kind === "paragraph"
        ? ce(r).replace(/\{[A-Za-z]+\}/g, "")
        : r.rows.map((n) =>
            n.map((s) => s.runs.map((x) => x.text).join("")).join("	"),
          ).join(`
`),
    )
    .map((r) => r.replace(/[ \t]+$/gm, "").trim())
    .filter(Boolean).join(`

`);
}
function je(d) {
  const r = le(d.items),
    n = r.filter((o) => o.segs.length);
  if (!n.length) return "";
  const s = Math.min(...n.map((o) => Math.min(...o.segs.map((y) => y.left)))),
    x = Math.max(...n.map((o) => Math.max(...o.segs.map((y) => y.right))));
  return we(ie(r, { left: s, right: x }));
}
function M(d, r, n, s) {
  return d === "text" && !r.trim()
    ? s > 0
      ? `All ${s} page${s === 1 ? "" : "s"} will be read (the page box is empty)`
      : null
    : n <= 0
      ? null
      : `${n} page${n === 1 ? "" : "s"} selected${d === "pages" ? " (kept in the order you typed or in page order)" : ""}`;
}
const N = {
  what: `Pulls specific pages out of a PDF as a new, smaller PDF, or extracts the raw selectable text content as a plain text file. This is the tool for when you only need a portion of a larger document — pulling three relevant pages out of a 60-page report to send someone, or getting the plain text out of a document to paste into another program — rather than sharing or processing the whole file.

If you need several separate output files from ranges of pages (rather than one file with a handful of pages picked out), or want to split a document into equal-sized chunks, Split PDF is the more direct tool for that — Extract is built around a single deliverable: one set of pages, or the text.`,
  how: "Upload your PDF, choose Pages or Text. For page extraction, click any page thumbnail to select or deselect it (or type a range/list directly if you'd rather not click through many pages) — selected pages are pulled out into one new PDF, in page order when you click thumbnails, or in the order you typed when you use a list such as 5,1,3. For text extraction, the selectable text of the pages you choose (all of them by default) is shown, ready to copy, and can be downloaded as a plain text file, with columns in reading order.",
  tip: "Text extraction reads columns in order, keeps tables as tab-separated cells and rebuilds paragraphs. It only works on PDFs with real, selectable text — a scanned document has no underlying text layer to extract, so the result will be empty for those. Run it through OCR PDF first if you're starting from a scan, which adds a real, searchable text layer that this tool can then pull from.",
};
function Ct() {
  const { gateShare: d } = Q(),
    [r, n] = i.useState(null),
    [s, x] = i.useState("pages"),
    [o, y] = i.useState(0),
    [u, b] = i.useState(""),
    [F, w] = i.useState(new Set()),
    [S, D] = i.useState(!1),
    [g, m] = i.useState(null),
    [j, h] = i.useState(null),
    [P, c] = i.useState(null),
    [z, I] = i.useState([]),
    { thumbnails: A, loading: B } = ue(r),
    L = i.useCallback(async (t) => {
      const a = t[0];
      if (!a) return;
      (n(a), m(null), h(null), c(null));
      const l = await me(a);
      (y(l), b("1"), w(new Set([1])));
    }, []),
    U = (t) => {
      (w((a) => {
        const l = new Set(a);
        l.has(t) ? l.delete(t) : l.add(t);
        const T = Array.from(l)
          .sort((R, f) => R - f)
          .join(",");
        return (b(T), l);
      }),
        m(null),
        h(null),
        c(null));
    },
    E = i.useMemo(() => Array.from(F).sort((t, a) => t - a), [F]),
    k = (t) => {
      (w(new Set(t)), b(t.join(",")), m(null), h(null), c(null));
    },
    v = i.useMemo(() => Array.from({ length: o }, (t, a) => a + 1), [o]),
    _ = () => {
      if (!u.trim())
        return s === "text"
          ? v
          : (c({
              kind: "error",
              message:
                "Choose at least one page: click a thumbnail or type pages such as 1, 3-5.",
            }),
            null);
      const t = O(u, o);
      return "error" in t
        ? (c({ kind: "error", message: t.error }), null)
        : t.pages.map((a) => a + 1);
    },
    q = async () => {
      c(null);
      const t = _();
      if (!(!t || !r)) {
        D(!0);
        try {
          if ((I(t), s === "pages"))
            (m(
              await de(
                r,
                t.map((a) => a - 1),
              ),
            ),
              C.success(
                `${t.length} page${t.length === 1 ? "" : "s"} extracted`,
              ));
          else {
            const a = await oe(r),
              l = [];
            for (const f of t) {
              const K = await ne(await a.getPage(f));
              l.push(`--- Page ${f} ---

${je(K)}`);
            }
            const T = l.join(`

`);
            if (!l.some((f) => f.replace(/^--- Page \d+ ---\s*/, "").trim())) {
              c({
                kind: "scan",
                message:
                  "No selectable text on these pages: this looks like a scanned image. Run it through OCR PDF first, then extract the text.",
              });
              return;
            }
            (h(T),
              m(new Blob([T], { type: "text/plain;charset=utf-8" })),
              C.success("Text extracted"));
          }
        } catch (a) {
          (console.error("Extraction failed:", a),
            c({
              kind: "error",
              message:
                a instanceof Error && a.message
                  ? a.message
                  : "Extraction failed. Check the page numbers and try again.",
            }));
        } finally {
          D(!1);
        }
      }
    },
    G = async () => {
      j &&
        (await d(async () => {
          try {
            return (
              await navigator.clipboard.writeText(j),
              C.success("Copied"),
              !0
            );
          } catch {
            return (
              C.error("Couldn't copy. Select the text and copy it by hand."),
              !1
            );
          }
        }));
    },
    Z = (t) =>
      t.length === 1 ? `${t[0]}` : `${Math.min(...t)}-${Math.max(...t)}`,
    $ = r ? pe(r.name) : "",
    H = fe(g),
    J = u.trim() !== "" && u.trim() !== "1";
  return e.jsxs(Y, {
    children: [
      e.jsx(xe, {
        toolId: "extract-pdf",
        state: {
          hasFile: !!r,
          pagesChosen: J,
          processing: S,
          resultReady: !!g && !S,
          downloaded: H,
        },
      }),
      r
        ? e.jsxs("div", {
            className: "space-y-4",
            children: [
              e.jsx("div", {
                className: "p-4 rounded-lg border bg-card",
                children: e.jsxs("p", {
                  className: "text-sm font-medium",
                  children: [r.name, " — ", o, " page", o === 1 ? "" : "s"],
                }),
              }),
              e.jsxs("div", {
                className: "flex gap-2",
                children: [
                  e.jsx(p, {
                    size: "sm",
                    "aria-pressed": s === "pages",
                    variant: s === "pages" ? "default" : "outline",
                    onClick: () => {
                      (x("pages"), m(null), h(null), c(null));
                    },
                    children: "Extract Pages",
                  }),
                  e.jsx(p, {
                    size: "sm",
                    "aria-pressed": s === "text",
                    variant: s === "text" ? "default" : "outline",
                    onClick: () => {
                      (x("text"), m(null), h(null), c(null));
                    },
                    children: "Extract Text",
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "space-y-3",
                children: [
                  B
                    ? e.jsx(ge, {})
                    : e.jsxs(e.Fragment, {
                        children: [
                          e.jsxs("div", {
                            className: "flex flex-wrap gap-1",
                            children: [
                              e.jsx(p, {
                                size: "sm",
                                variant: "ghost",
                                onClick: () => k(v),
                                children: "Select all",
                              }),
                              e.jsx(p, {
                                size: "sm",
                                variant: "ghost",
                                onClick: () => k(v.filter((t) => t % 2 === 1)),
                                children: "Odd pages",
                              }),
                              e.jsx(p, {
                                size: "sm",
                                variant: "ghost",
                                onClick: () => k(v.filter((t) => t % 2 === 0)),
                                children: "Even pages",
                              }),
                              e.jsx(p, {
                                size: "sm",
                                variant: "ghost",
                                onClick: () => k([]),
                                children: "Clear",
                              }),
                            ],
                          }),
                          e.jsx(he, {
                            thumbnails: A,
                            selected: F,
                            onToggle: U,
                          }),
                        ],
                      }),
                  e.jsxs("div", {
                    children: [
                      e.jsxs(V, {
                        htmlFor: "ex-pages",
                        children: [
                          s === "text"
                            ? "Pages to read (leave empty for all pages)"
                            : "Or type pages directly",
                          ' (e.g. "1, 3-5, 7")',
                        ],
                      }),
                      e.jsx(W, {
                        id: "ex-pages",
                        value: u,
                        onChange: (t) => {
                          if (
                            (b(t.target.value),
                            m(null),
                            h(null),
                            c(null),
                            !t.target.value.trim())
                          ) {
                            w(new Set());
                            return;
                          }
                          const a = O(t.target.value, o);
                          "error" in a || w(new Set(a.pages.map((l) => l + 1)));
                        },
                      }),
                    ],
                  }),
                  M(s, u, E.length, o) &&
                    e.jsx("p", {
                      className: "text-xs text-muted-foreground",
                      "aria-live": "polite",
                      children: M(s, u, E.length, o),
                    }),
                ],
              }),
              P &&
                (P.kind === "error"
                  ? e.jsx("p", {
                      role: "alert",
                      className: "text-sm text-destructive",
                      children: P.message,
                    })
                  : e.jsxs(X, {
                      role: "alert",
                      className: "text-sm",
                      children: [
                        P.message,
                        " ",
                        P.kind === "scan" &&
                          e.jsx("a", {
                            className: "underline",
                            href: "/tool/ocr-pdf",
                            children: "Open OCR PDF",
                          }),
                      ],
                    })),
              e.jsx("div", {
                className: "flex gap-3",
                children: S
                  ? e.jsx(te, {})
                  : g
                    ? e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(ae, {
                            blob: g,
                            fileName:
                              s === "pages"
                                ? `${$}-pages-${Z(z)}.pdf`
                                : `${$}-text.txt`,
                            label:
                              s === "pages"
                                ? "Download PDF"
                                : "Download Text File",
                          }),
                          e.jsx(p, {
                            variant: "outline",
                            onClick: () => {
                              (n(null), m(null));
                            },
                            children: "New",
                          }),
                        ],
                      })
                    : e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(p, {
                            onClick: q,
                            children:
                              s === "pages" ? "Extract Pages" : "Extract Text",
                          }),
                          e.jsx(p, {
                            variant: "outline",
                            onClick: () => n(null),
                            children: "Reset",
                          }),
                        ],
                      }),
              }),
              g &&
                s === "pages" &&
                e.jsx(se, { blob: g, mimeType: "application/pdf" }),
              g &&
                s === "text" &&
                j !== null &&
                e.jsxs("div", {
                  className: "space-y-2",
                  children: [
                    e.jsxs("div", {
                      className: "flex items-center justify-between",
                      children: [
                        e.jsxs("p", {
                          className: "text-sm font-medium",
                          children: [
                            "Extracted text (",
                            j.length.toLocaleString(),
                            " characters)",
                          ],
                        }),
                        e.jsxs(p, {
                          size: "sm",
                          variant: "outline",
                          onClick: G,
                          children: [
                            e.jsx(ye, { className: "h-3.5 w-3.5 mr-1" }),
                            " Copy",
                          ],
                        }),
                      ],
                    }),
                    e.jsx("textarea", {
                      readOnly: !0,
                      value: j,
                      className:
                        "w-full h-64 rounded-md border bg-background p-3 text-sm font-mono",
                      "aria-label": "Extracted text",
                    }),
                  ],
                }),
            ],
          })
        : e.jsx(ee, {
            gateAtDownload: !0,
            accept: ".pdf",
            onFiles: L,
            label: "Drop a PDF file",
            description: "Extract specific pages or the text content of a PDF",
          }),
      e.jsx(re, { whatIsIt: N.what, howToUse: N.how, tip: N.tip }),
    ],
  });
}
export { Ct as default };
//# sourceMappingURL=ExtractPdf-C5BRKXT9.js.map
