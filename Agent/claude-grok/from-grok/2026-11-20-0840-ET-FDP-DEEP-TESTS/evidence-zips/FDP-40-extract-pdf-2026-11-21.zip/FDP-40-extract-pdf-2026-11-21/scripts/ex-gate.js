// extract-pdf gate. Part 1 (uses-left context, up to 14 fresh contexts): E01 pages "2,5" Extract (count) -> Download PDF A, again A2, Drive/cloud (stop at sign-in), New + P01 "1-2" -> B;
// Text mode: E01 all pages Extract Text (count) -> Copy T (count) -> Download Text C; reload + P03 "37" -> Download D; reload + text E01 -> Copy E.
// Part 2 (context at 0): keyboard; E01 Extract Text (all) -> textarea length; manual select+Ctrl+C from the read-only textarea -> clipboard; Copy button -> cap?; Download Text -> cap -> Day Pass (email prompt, types nothing);
// P03 "37" Extract Pages -> Preview first page size; Download -> cap; Quick Buy day/monthly (stop). Guest.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const crypto = require('crypto');
const BASE = '/workspace/deep/40-extract-pdf/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/extract-pdf';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex').slice(0, 16);
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').slice(0, 160);
(async () => { const b = await chromium.launch(); const R = { t: now(), tries: [] }; let c, p;
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true, permissions: ['clipboard-read', 'clipboard-write'] }); p = await c.newPage(); p.setDefaultTimeout(15000); await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 const convert = async (file, mode, pages) => { if (file) { await p.locator('main input[type=file]').first().setInputFiles(TF + file); await p.waitForTimeout(3500); }
   if (mode === 'text') await p.getByRole('button', { name: /^Extract Text/ }).first().click(); else await p.getByRole('button', { name: /^Extract Pages/ }).first().click(); await p.waitForTimeout(500);
   const box = p.locator('main input:not([type=file]):not([type=checkbox])').first(); await box.fill(pages); await p.waitForTimeout(300);
   const u0 = await used(); await p.getByRole('button', { name: mode === 'text' ? /^Extract Text/ : /^Extract Pages/ }).last().click(); await p.waitForTimeout(3500);
   return { file, mode, pages, usedBefore: u0, used: await used(), textLen: await p.evaluate(() => { const t = document.querySelector('main textarea'); return t ? t.value.length : null; }), textHead: await p.evaluate(() => { const t = document.querySelector('main textarea'); return t ? t.value.slice(0, 300) : null; }), dlLabel: await p.evaluate(() => [...document.querySelectorAll('main button')].map(e => e.innerText.replace(/\n/g, ' · ')).find(x => /^Download/.test(x)) || null), note: await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*uses 1 trial use[^\n]*|[^\n]*Day Pass to download[^\n]*|[^\n]*remaining today[^\n]*/g) || []).slice(0, 3).join(' | ')), alerts: await p.evaluate(() => [...document.querySelectorAll('main [role=alert]')].map(e => e.innerText.trim()).join(' | ')), toasts: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim().replace(/\n/g, ' '))) }; };
 const clip = () => p.evaluate(() => navigator.clipboard.readText().catch(e => 'ERR ' + e));
 const act = async (name, loc) => { const r = { before: await used() }; if (!(await loc.count())) { r.missing = true; return r; }
   const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); const dl = p.waitForEvent('download', { timeout: 15000 }).catch(() => null); const url0 = p.url(); await loc.first().click(); const [pg, d] = await Promise.all([pop, dl]); await p.waitForTimeout(2000);
   r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null; r.t = now();
   if (d) { r.download = d.suggestedFilename(); const f = OUT + 'downloads/gate-' + name + '-' + d.suggestedFilename(); await d.saveAs(f); r.bytes = fs.statSync(f).size; r.sha = sha(f); r.saved = f; }
   if (pg) { await pg.waitForLoadState('domcontentloaded').catch(() => {}); r.popup = red(pg.url()); r.popupTitle = await pg.title().catch(() => null); await pg.close(); }
   if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + '.png' });
   if (r.dialog && /Day Pass/.test(r.dialog) && !R.dayPassFromCap) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.dayPassFromCap = { from: name, dialog: await dialog(), emailField: await p.locator('input[type=email]').count(), url: red(p.url()) }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); } }
   await esc(); console.log(name, JSON.stringify(r)); return r; };
 const DL = () => p.getByRole('button', { name: /^Download (PDF|Text File)/ }); const CP = () => p.getByRole('button', { name: /^\s*Copy$/ });
 const another = async () => { await p.getByRole('button', { name: 'New', exact: true }).click(); await p.waitForTimeout(800); };
 const reload = async () => { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); };
 for (let i = 0; i < 14; i++) { await open(); const u = await used(); R.tries.push(u); if (u < 10) break; await c.close(); c = null; }
 if (c) { const L = R.left = { t: now(), start: await used() };
  L.cA = await convert('E01_mixed_8p_bookmarks_form.pdf', 'pages', '2,5'); L.dlA = await act('A', DL()); L.dlA2 = await act('A2', DL());
  L.drive = await act('drive', p.getByRole('button', { name: /Save to Google Drive/ })); L.cloud = await act('cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
  await another(); L.cB = await convert('P01_payslip_3p_form.pdf', 'pages', '1-2'); L.dlB = await act('B', DL());
  await another(); L.cT = await convert('E01_mixed_8p_bookmarks_form.pdf', 'text', ''); await p.evaluate(() => navigator.clipboard.writeText('EMPTY')); L.cpT = await act('T', CP()); L.clipT = (await clip()).slice(0, 80); L.dlC = await act('C', DL());
  await reload(); L.afterReload = await used(); L.cD = await convert('P03_50pages.pdf', 'pages', '37'); L.dlD = await act('D', DL());
  await reload(); L.cE = await convert('E01_mixed_8p_bookmarks_form.pdf', 'text', '3'); L.cpE = await act('E', CP());
  await reload(); L.end = await used(); L.t2 = now(); await c.close(); }
 for (let i = 0; i < 4; i++) { await open(); if (await used() >= 10) break; await c.close(); }
 const Z = R.zero = { t: now(), start: await used() };
 let chooser = false; p.on('filechooser', () => { chooser = true; }); const seq = [];
 for (let i = 0; i < 40; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('role') || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50).replace(/\n/g, ' '); }); seq.push(a); if (/Drop a PDF/i.test(a)) { await p.keyboard.press('Enter'); await p.waitForTimeout(1200); seq.push('ENTER -> chooser=' + chooser); break; } }
 Z.kbd = { tabs: seq.length, last: seq.slice(-3), chooser };
 if (Z.start >= 10) { Z.c = await convert('E01_mixed_8p_bookmarks_form.pdf', 'text', ''); await p.screenshot({ path: OUT + 'zero-text.png', fullPage: false });
  await p.evaluate(() => navigator.clipboard.writeText('EMPTY')); await p.locator('main textarea').click(); await p.keyboard.press('Control+A'); await p.keyboard.press('Control+C'); await p.waitForTimeout(500); const mc = await clip(); Z.manualCopy = { len: mc.length, head: mc.slice(0, 120), hasPage8: mc.includes('PAGE-8 MARKER') }; Z.afterManual = await used();
  await p.evaluate(() => navigator.clipboard.writeText('EMPTY')); Z.copyBtn = await act('zero-copy', CP()); Z.clipAfterBtn = (await clip()).slice(0, 60);
  Z.dlText = await act('zero-dltext', DL()); Z.end = await used();
  await another(); Z.c37 = await convert('P03_50pages.pdf', 'pages', '37'); const pv = p.getByRole('button', { name: /Preview first page/ }); if (await pv.count()) { await pv.click(); await p.waitForTimeout(3000); Z.preview = await p.evaluate(() => { const i = document.querySelector('main img[alt="First page preview"]'); return i ? { nw: i.naturalWidth, nh: i.naturalHeight } : null; }); await p.screenshot({ path: OUT + 'zero-pages-preview.png', fullPage: false }); }
  Z.dlPages = await act('zero-dlpages', DL()); Z.end2 = await used();
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  const qb = p.getByRole('button', { name: 'Quick Buy' }); const u0 = p.url(); await qb.first().click(); await p.waitForTimeout(3000); Z.qbDay = { url: p.url() !== u0 ? red(p.url()) : null, dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await esc();
  if (p.url() !== u0) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); }
  await p.getByRole('button', { name: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); Z.qbMonth = { url: red(p.url()), dialog: await dialog(), title: await p.title(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' }); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify({ tries: R.tries }, null, 1)); await b.close(); })();
