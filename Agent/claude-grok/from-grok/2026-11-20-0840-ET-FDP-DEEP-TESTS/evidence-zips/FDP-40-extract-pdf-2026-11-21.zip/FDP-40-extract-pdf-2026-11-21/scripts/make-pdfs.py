# E01: 8-page mixed document with bookmarks per page, a text field + checkbox on page 5, a table on page 3, header/page numbers,
# two columns on page 6, Unicode on page 7, an image-only page 8. Run with venv-pdf python (reportlab, PIL).
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from PIL import Image, ImageDraw, ImageFont
import textwrap
pdfmetrics.registerFont(TTFont('DV','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
W,H=letter; c=canvas.Canvas('E01_mixed_8p_bookmarks_form.pdf',pagesize=letter); c.setTitle('Mixed Eight')
P="Paragraph text for page {n}. This sentence is long enough to wrap onto a second line so that paragraph rebuilding can be checked in the text output of the tool."
for n in range(1,9):
  c.bookmarkPage(f'p{n}'); c.addOutlineEntry(f'Chapter {n}',f'p{n}',level=0)
  c.setFont('Helvetica',8); c.drawString(72,H-40,'MIXED EIGHT - RUNNING HEADER'); c.drawRightString(W-72,40,f'Page {n}')
  c.setFont('Helvetica-Bold',16); c.drawString(72,H-80,f'PAGE-{n} MARKER')
  c.setFont('Helvetica',11); y=H-110
  if n==3:
    rows=[['Item','Qty','Price'],['Widget A','4','12.50'],['Widget B','10','3.25'],['Cable','2','7.00']]
    for r in rows:
      for j,cell in enumerate(r): c.drawString(72+j*140,y,cell)
      y-=18
  elif n==5:
    c.drawString(72,y,'Name:'); c.acroForm.textfield(name='applicant_name',x=130,y=y-6,width=200,height=18,value='Jane Roe')
    c.drawString(72,y-40,'Agree:'); c.acroForm.checkbox(name='agree_terms',x=130,y=y-46,size=16,checked=True)
  elif n==6:
    L=textwrap.wrap('LEFTCOL '+ 'The left column talks about apples and orchards in the valley. '*3,40); R=textwrap.wrap('RIGHTCOL '+'The right column talks about boats and harbours by the sea. '*3,40)
    for i in range(max(len(L),len(R))):
      if i<len(L): c.drawString(72,y,L[i])
      if i<len(R): c.drawString(330,y,R[i])
      y-=14
  elif n==7:
    c.setFont('DV',11); c.drawString(72,y,'Café Zürich – 1.250,00 € · Счёт № 7 · Ελληνικά · naïve résumé'); c.setFont('Helvetica',11)
  elif n==8:
    im=Image.new('RGB',(1000,300),'white'); d=ImageDraw.Draw(im); d.text((40,120),'IMAGE-ONLY WORDS ON PAGE 8',fill='black',font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',40)); im.save('_img.png'); c.drawImage('_img.png',72,y-200,450,135)
  if n not in (8,):
    for l in textwrap.wrap(P.format(n=n),80): c.drawString(72,y-80 if n in(3,5) else y-140 if n==6 else y-30 if n==7 else y,l); y-=15
  c.showPage()
c.save(); import os; os.remove('_img.png'); print('ok')
