# Inspect extract-pdf downloads: page markers in order, page count, bookmarks, form fields, encryption, badge text; txt markers/tabs. Usage: venv-pdf python verify.py <files...>
import sys,json,re,pikepdf,pypdf
out={}
for f in sys.argv[1:]:
  r={}
  try:
    if f.endswith('.pdf'):
      rd=pypdf.PdfReader(f); txt=[pg.extract_text() or '' for pg in rd.pages]
      r['pages']=len(rd.pages); r['markers']=[(re.findall(r'PAGE-\d+ MARKER|Long Report - page \d+|FDP Test Payslip - page \d+',t) or ['?'])[0] for t in txt]
      r['badge']=sum('FreeDailyPro' in t for t in txt); r['encrypted']=rd.is_encrypted
      p=pikepdf.open(f)
      with p.open_outline() as o: r['bookmarks']=[i.title for i in o.root]
      r['fields']=[str(x.get('/T')) for x in p.Root.AcroForm.Fields] if '/AcroForm' in p.Root else []
    else:
      t=open(f,encoding='utf-8').read(); r['chars']=len(t); r['pageMarkers']=re.findall(r'^--- Page \d+ ---$',t,re.M); r['tabRows']=sum(1 for l in t.splitlines() if '\t' in l)
  except Exception as e: r['err']=str(e)
  out[f.split('/')[-1]]=r
print(json.dumps(out,indent=1))
