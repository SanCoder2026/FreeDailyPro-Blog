import { r, j as t } from "./vendor-react-D01g8YgM.js";
import { u as z } from "./useRunToken-sJpsnYiZ.js";
import { OCR_LANGUAGES as G } from "./ocrText-C_9cxcFa.js";
import { T as q } from "./ToolWithSidebar-C7kxZj7O.js";
import { F as U, P as H, D as K, R as Z } from "./ToolPage-DwLoDncN.js";
import { N as S, b as J, B as v, f as D } from "./index-B1CTyGtY.js";
import { u as Q } from "./operations-B4LtHhm8.js";
import { L as F, i as V } from "./lockedPdfError-Js5vQrN8.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./pdfMetadata-CcxIhQF2.js";
import "./pageView-BQIwVYOi.js";
import "./formAppearance-CdNbuISd.js";
import "./drawTextAnywhere-DcuP6lHH.js";
import "./ocrImage-CmXFNUud.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./utils-s8ucLyj8.js";
import "./imageRecompress-eXQFDUm-.js";
import "./formatFileSize-B-JRDfN5.js";
import "./plural-FIChqbp4.js";
import "./textDiff-DxE9AzvO.js";
import "./utils-1EQcVBdK.js";
import "./decode-DrS85i4S.js";
import "./formFill-Dg9Myfyq.js";
import "./redactSearch-DQpyyh_t.js";
import "./nameDetect-DvHCRM0m.js";
const b = (e) => `${e} page${e === 1 ? "" : "s"}`,
  T = (e) =>
    e.length > 6
      ? `${e.slice(0, 6).join(", ")} and ${e.length - 6} more`
      : e.join(", ");
function X(e) {
  const l =
    "The scan may be sideways or upside down, a photo, or too faint. Choose a page orientation above (or “Detect automatically”) and try again.";
  if (e.pagesAttempted === 0)
    return {
      notice:
        "This PDF is already searchable — every page has real text, so nothing needed OCR.",
      warning: "",
      hasOutput: !1,
    };
  if (e.pagesOcrd === 0) {
    const n = e.unreadablePages.length;
    return {
      notice: "",
      warning:
        n > 0
          ? `The text read from ${n === e.pagesAttempted ? b(n) : `page${n === 1 ? "" : "s"} ${T(e.unreadablePages)}`} was not usable, so no text layer was added. ${l}`
          : `No text was found on the ${b(e.pagesAttempted)} that needed OCR, so nothing was added. A clearer, higher-resolution scan may help, and the language setting must match the document.`,
      hasOutput: !1,
    };
  }
  const p = e.rotatedPages.length
    ? ` ${e.rotatedPages.length === 1 ? `Page ${e.rotatedPages[0].page} was turned ${e.rotatedPages[0].degrees}° clockwise so it reads upright.` : `${b(e.rotatedPages.length)} were turned so they read upright.`}`
    : "";
  return {
    notice: `Recognised ${e.words} words on ${b(e.pagesOcrd)}.${p}`,
    warning: e.unreadablePages.length
      ? `Page${e.unreadablePages.length === 1 ? "" : "s"} ${T(e.unreadablePages)} could not be read reliably and ${e.unreadablePages.length === 1 ? "was" : "were"} left as they were. ${l}`
      : "",
    hasOutput: !0,
  };
}
const R = [
    { id: "0", label: "As scanned", value: 0 },
    {
      id: "auto",
      label: "Detect automatically (turns sideways pages)",
      value: "auto",
    },
    { id: "90", label: "Turn 90° clockwise first", value: 90 },
    { id: "180", label: "Turn 180° first", value: 180 },
    { id: "270", label: "Turn 90° counter-clockwise first", value: 270 },
  ],
  A = {
    what: `Makes a scanned PDF genuinely searchable and its text selectable/copyable, while keeping it looking exactly the same. Real OCR text — placed on each line's real position on the page — is added as an invisible layer underneath the visible scan, the same technique tools like Adobe Acrobat's "Recognize Text" use. Pages that already have real, selectable text are left completely untouched.

This is deliberately distinct from two similar-sounding tools: OCR Tool pulls text out as its own separate output (plain text or a new document) rather than adding an invisible layer to the existing PDF — use that if you just want the recognized text itself, not a searchable version of the original file. PDF to Word converts to an editable Word document instead of staying a PDF — use that if you need to actually edit the content, not just search or select it.`,
    tip: "The output looks pixel-identical to your original — nothing changes visually. The difference only shows up when you try to select, search, or copy text: on a scanned page, that now actually works. OCR accuracy depends on scan quality, same as any OCR tool — a clear, high-resolution scan reads far more reliably than a blurry photo of a document. Honestly: this recognizes printed text reliably, but handwriting recognition is far less accurate and shouldn't be relied on for anything important — a handwritten page may come through with significant errors or gaps.",
  };
function Ye() {
  const [e, l] = r.useState(null),
    [p, n] = r.useState(!1),
    [E, x] = r.useState(""),
    [M, f] = r.useState(0),
    [c, d] = r.useState(null),
    [w, O] = r.useState(0),
    [C, I] = r.useState("eng"),
    [y, P] = r.useState(""),
    [N, L] = r.useState("0"),
    [$, m] = r.useState(""),
    o = z(),
    [k, g] = r.useState("");
  r.useEffect(() => () => o.cancel(), [o]);
  const _ = r.useCallback((a) => {
      (l(a[0] || null), d(null), g(""), m(""), P(""));
    }, []),
    B = () => {
      (o.cancel(), n(!1), x(""), f(0));
    },
    W = async () => {
      if (!e) return;
      const a = o.start();
      (P(""), g(""), m(""), d(null), n(!0), O(0), f(0));
      try {
        const s = await Q(
          e,
          (u, h) => {
            o.isCurrent(a) && (x(u), typeof h == "number" && f(h));
          },
          {
            language: C,
            isCurrent: () => o.isCurrent(a),
            rotate: R.find((u) => u.id === N)?.value ?? 0,
          },
        );
        if (!o.isCurrent(a)) return;
        const i = s.pagesOcrd;
        O(i);
        const j = X({
          pagesOcrd: i,
          pagesAttempted: s.pagesAttempted,
          unreadablePages: s.unreadablePages,
          rotatedPages: s.rotatedPages,
          words: Object.values(s.wordsByPage).reduce((u, h) => u + h, 0),
        });
        if ((g(j.notice), m(j.warning), !j.hasOutput)) {
          d(null);
          return;
        }
        (d(s.blob),
          D.success(`Made ${i} scanned page${i === 1 ? "" : "s"} searchable`));
      } catch (s) {
        if (
          !o.isCurrent(a) ||
          (s instanceof Error && s.message === "cancelled")
        )
          return;
        console.error("OCR PDF failed:", s);
        const i = V(s)
          ? F
          : s instanceof Error && s.name === "OcrStartError"
            ? s.message
            : "Couldn't process this PDF. It may be damaged or password-protected.";
        (P(i), D.error(i));
      } finally {
        o.isCurrent(a) && (n(!1), x(""));
      }
    };
  return t.jsx(q, {
    toolId: "ocr-pdf",
    categoryId: "pdf-tools",
    whatItDoes: A.what,
    proTip: A.tip,
    children: e
      ? t.jsxs("div", {
          className: "space-y-4",
          children: [
            t.jsx("div", {
              className: "p-4 rounded-lg border bg-card",
              children: t.jsx("p", {
                className: "text-sm font-medium",
                children: e.name,
              }),
            }),
            !p &&
              !c &&
              t.jsxs("div", {
                className: "flex flex-wrap items-center gap-2",
                children: [
                  t.jsx("label", {
                    htmlFor: "ocr-pdf-lang",
                    className: "text-sm text-muted-foreground",
                    children: "Language of the scanned pages",
                  }),
                  t.jsx("select", {
                    id: "ocr-pdf-lang",
                    value: C,
                    onChange: (a) => I(a.target.value),
                    className:
                      "h-9 rounded-md border bg-background px-2 text-sm",
                    children: G.map((a) =>
                      t.jsx("option", { value: a.id, children: a.label }, a.id),
                    ),
                  }),
                  t.jsx("label", {
                    htmlFor: "ocr-pdf-orientation",
                    className: "text-sm text-muted-foreground sm:ml-3",
                    children: "Page orientation",
                  }),
                  t.jsx("select", {
                    id: "ocr-pdf-orientation",
                    value: N,
                    onChange: (a) => L(a.target.value),
                    className:
                      "h-9 rounded-md border bg-background px-2 text-sm",
                    children: R.map((a) =>
                      t.jsx("option", { value: a.id, children: a.label }, a.id),
                    ),
                  }),
                ],
              }),
            k &&
              t.jsx(S, { role: "status", className: "text-sm", children: k }),
            $ && t.jsx(S, { className: "text-sm", role: "alert", children: $ }),
            y &&
              t.jsxs("div", {
                role: "alert",
                className:
                  "p-3 rounded-lg border border-destructive/40 bg-destructive/5 text-sm",
                children: [
                  y,
                  y === F &&
                    t.jsxs(t.Fragment, {
                      children: [
                        " ",
                        t.jsx(J, {
                          href: "/tool/unlock-pdf",
                          className: "underline",
                          children: "Open Unlock PDF",
                        }),
                        ".",
                      ],
                    }),
                ],
              }),
            t.jsx("div", {
              className: "flex gap-3",
              children: p
                ? t.jsx(H, {
                    message: E || "Processing...",
                    progress: M,
                    onStop: B,
                  })
                : c
                  ? t.jsxs(t.Fragment, {
                      children: [
                        t.jsx(K, {
                          blob: c,
                          fileName: `searchable_${e.name}`,
                          label:
                            w > 0
                              ? `Download (${w} page${w === 1 ? "" : "s"} made searchable)`
                              : "Download",
                        }),
                        t.jsx(v, {
                          variant: "outline",
                          onClick: () => {
                            (l(null), d(null), g(""), m(""));
                          },
                          children: "New",
                        }),
                      ],
                    })
                  : t.jsxs(t.Fragment, {
                      children: [
                        t.jsx(v, { onClick: W, children: "Make Searchable" }),
                        t.jsx(v, {
                          variant: "ghost",
                          onClick: () => l(null),
                          children: "Reset",
                        }),
                      ],
                    }),
            }),
            c && t.jsx(Z, { blob: c, mimeType: "application/pdf" }),
          ],
        })
      : t.jsx(U, {
          gateAtDownload: !0,
          accept: ".pdf",
          onFiles: _,
          label: "Drop a scanned PDF",
          description: "Make it searchable without changing how it looks",
        }),
  });
}
export { Ye as default };
//# sourceMappingURL=OcrPdf-BJ90unSe.js.map
