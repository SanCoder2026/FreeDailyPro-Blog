const r =
  "This PDF is password-protected. Unlock it first, then drop the unlocked copy here.";
function t(s) {
  if (!s) return !1;
  const e = s;
  return (
    e.name === "PasswordException" ||
    e.name === "EncryptedPDFError" ||
    /password|encrypted/i.test(e.message ?? "")
  );
}
export { r as L, t as i };
//# sourceMappingURL=lockedPdfError-Js5vQrN8.js.map
