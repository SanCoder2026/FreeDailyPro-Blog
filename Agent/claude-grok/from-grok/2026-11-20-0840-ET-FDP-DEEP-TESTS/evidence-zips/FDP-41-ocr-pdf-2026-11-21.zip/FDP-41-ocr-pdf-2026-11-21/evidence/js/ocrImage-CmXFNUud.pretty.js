function f(r, s, i, h = Math.max(40, Math.round(s / 25))) {
  const a = (e, t) => r[(t * s + e) * 4],
    o = [];
  for (let e = 5; e < s - 5; e++) {
    let t = 0;
    for (; t < i;) {
      if (a(e, t) >= 110) {
        t++;
        continue;
      }
      const c = t;
      for (; t < i && a(e, t) < 110;) t++;
      if (t - c >= h) {
        let d = 0;
        for (let n = c; n < t; n++)
          a(e - 5, n) >= 110 && a(e + 5, n) >= 110 && d++;
        if (d >= 0.8 * (t - c)) for (let n = c; n < t; n++) o.push(n * s + e);
      }
    }
  }
  for (let e = 5; e < i - 5; e++) {
    let t = 0;
    for (; t < s;) {
      if (a(t, e) >= 110) {
        t++;
        continue;
      }
      const c = t;
      for (; t < s && a(t, e) < 110;) t++;
      if (t - c >= h) {
        let d = 0;
        for (let n = c; n < t; n++)
          a(n, e - 5) >= 110 && a(n, e + 5) >= 110 && d++;
        if (d >= 0.8 * (t - c)) for (let n = c; n < t; n++) o.push(e * s + n);
      }
    }
  }
  for (const e of o) {
    const t = e * 4;
    r[t] = r[t + 1] = r[t + 2] = 255;
  }
}
async function g(r) {
  const s = await createImageBitmap(r),
    i = document.createElement("canvas");
  ((i.width = s.width), (i.height = s.height));
  const h = i.getContext("2d");
  if (!h) return r;
  h.drawImage(s, 0, 0);
  const a = h.getImageData(0, 0, i.width, i.height),
    o = a.data,
    l = 1.15;
  for (let e = 0; e < o.length; e += 4) {
    const t = o[e] * 0.299 + o[e + 1] * 0.587 + o[e + 2] * 0.114;
    o[e] =
      o[e + 1] =
      o[e + 2] =
        Math.min(255, Math.max(0, (t - 128) * l + 128));
  }
  return (
    f(o, i.width, i.height),
    h.putImageData(a, 0, 0),
    new Promise((e, t) =>
      i.toBlob(
        (c) => (c ? e(c) : t(new Error("Preprocessing failed"))),
        "image/jpeg",
        0.92,
      ),
    )
  );
}
async function m(r, s) {
  const i = await createImageBitmap(r),
    h = s !== 180,
    a = document.createElement("canvas");
  ((a.width = h ? i.height : i.width), (a.height = h ? i.width : i.height));
  const o = a.getContext("2d");
  return o
    ? (o.translate(a.width / 2, a.height / 2),
      o.rotate((s * Math.PI) / 180),
      o.drawImage(i, -i.width / 2, -i.height / 2),
      new Promise((l, e) =>
        a.toBlob(
          (t) => (t ? l(t) : e(new Error("Rotation failed"))),
          "image/jpeg",
          0.92,
        ),
      ))
    : r;
}
export { g as preprocessForOcr, f as removeRuledLines, m as rotateImageBlob };
//# sourceMappingURL=ocrImage-CmXFNUud.js.map
