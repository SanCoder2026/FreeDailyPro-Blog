const u = (t) => t.replace(/[ \t]+/g, " ").trim(),
  g = /^(\d{1,3}[.)]|\([a-z0-9]{1,3}\)|[\u2022\-\u2013*])\s+\S/i,
  d = (t) => /[.!?:;,)"\u201D\u2019]\s*$/.test(t),
  p = (t) => /^[a-z\u00DF-\u00FF]/.test(t);
function m(t, n, i) {
  return !!(
    g.test(n.text.trim()) ||
    (t.bbox &&
      n.bbox &&
      (n.bbox.y0 - t.bbox.y1 > 0.9 * i.lineHeight ||
        (t.bbox.x1 < i.right - 0.15 * i.width &&
          (d(t.text.trim()) || !p(n.text.trim())))))
  );
}
function S(t) {
  const n = [];
  for (const e of t.blocks ?? [])
    for (const o of e.paragraphs ?? []) {
      const a = (
        o.lines?.length
          ? o.lines
          : (o.text ?? "")
              .split(
                `
`,
              )
              .map((h) => ({ text: h }))
      ).filter((h) => h.text.trim());
      a.length && n.push(a);
    }
  if (!n.length)
    for (const e of (t.text ?? "").split(/\n\s*\n/)) {
      const o = e
        .split(
          `
`,
        )
        .map((l) => ({ text: l }))
        .filter((l) => l.text.trim());
      o.length && n.push(o);
    }
  const r = n.flat().filter((e) => e.bbox),
    c = r.map((e) => e.bbox.y1 - e.bbox.y0).sort((e, o) => e - o),
    s = {
      right: r.length ? Math.max(...r.map((e) => e.bbox.x1)) : 0,
      width: r.length
        ? Math.max(...r.map((e) => e.bbox.x1)) -
          Math.min(...r.map((e) => e.bbox.x0))
        : 0,
      lineHeight: c.length ? c[Math.floor(c.length / 2)] : 0,
    },
    f = [];
  for (const e of n) {
    let o = [];
    (e.forEach((l, a) => {
      (a > 0 && m(e[a - 1], l, s) && (f.push(u(o.join(" "))), (o = [])),
        o.push(l.text.trim()));
    }),
      o.length && f.push(u(o.join(" "))));
  }
  return f.filter(Boolean);
}
function b(t) {
  const n = t
    .split(
      `
`,
    )
    .map((i) => i.trim())
    .filter(Boolean);
  return n.length < 6
    ? 0
    : n.filter((i) => i.replace(/\s/g, "").length < 6).length / n.length;
}
function x(t, n) {
  const i = new RegExp("\\p{L}", "u"),
    r = Array.from(t).filter((s) => i.test(s));
  return r.length
    ? r.filter((s) => (n ? !1 : /[ऀ-ॿ]/.test(s))).length / r.length
    : 0;
}
function w(t, n) {
  const i = t.text ?? "";
  return (
    (typeof t.confidence == "number" ? t.confidence : 60) -
    100 * b(i) -
    100 * x(i, n)
  );
}
function E(t, n) {
  const i = t.text ?? "";
  return b(i) > 0.2 || x(i, n) > 0.02 || (t.confidence ?? 100) < 60;
}
const y = [
    { id: "eng", label: "English" },
    { id: "eng+hin", label: "English + Hindi" },
    { id: "hin", label: "Hindi" },
    { id: "spa", label: "Spanish" },
    { id: "fra", label: "French" },
    { id: "deu", label: "German" },
    { id: "por", label: "Portuguese" },
    { id: "ita", label: "Italian" },
  ],
  F = (t) => t.split("+").includes("hin");
export {
  y as OCR_LANGUAGES,
  F as allowsDevanagari,
  x as foreignScriptFraction,
  b as fragmentFraction,
  E as needsSecondReading,
  S as ocrParagraphs,
  w as readingScore,
};
//# sourceMappingURL=ocrText-C_9cxcFa.js.map
