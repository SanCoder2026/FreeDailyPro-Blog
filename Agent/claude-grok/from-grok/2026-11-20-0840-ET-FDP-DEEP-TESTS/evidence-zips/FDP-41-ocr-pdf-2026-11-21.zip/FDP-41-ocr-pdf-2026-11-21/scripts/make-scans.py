# FDP-41 OCR PDF test set: image-only "scanned" PDFs with known ground truth (truth.json). Run with venv-pdf python.
# S01 clean English 1p; S02 3p (scan, real text, scan); S03 sideways (rotated 90 deg); S04 scan + small digital footer "Page 1 of 1";
# S05 Spanish; S06 German; S07 English+Hindi; S08 blank scan; S09 low-res noisy photo; S10 12p scan (timing); S11 table scan;
# S12 upside-down; S13 scan encrypted (user pw ocr123); S14 handwriting-style font.
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import random, json, io, pikepdf
W,H=letter; D=150  # 150 dpi scans
F='/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf'
HF='/usr/share/fonts/truetype/sand-box/google/Noto Sans Devanagari/NotoSansDevanagari-VariableFont_wdth,wght.ttf'
truth={}
def page_img(lines,size=34,font=F,rot=0,noise=False,res=D):
  w,h=int(8.5*res),int(11*res); im=Image.new('L',(w,h),255); d=ImageDraw.Draw(im); y=int(1*res)
  for l in lines:
    f=ImageFont.truetype(font if not isinstance(l,tuple) else l[1], int(size*res/150)); t=l if not isinstance(l,tuple) else l[0]
    d.text((int(0.9*res),y),t,fill=0,font=f); y+=int(size*1.6*res/150)
  if noise:
    im=im.filter(ImageFilter.GaussianBlur(1.1)); px=im.load()
    for _ in range(w*h//60): px[random.randrange(w),random.randrange(h)]=random.randrange(0,255)
  if rot: im=im.rotate(rot,expand=True,fillcolor=255)
  return im
def build(name,pages):
  c=canvas.Canvas(name,pagesize=letter); c.setTitle(name[:-4])
  for p in pages:
    if p[0]=='img':
      im=p[1]; b=io.BytesIO(); im.convert('RGB').save(b,'JPEG',quality=85); b.seek(0)
      from reportlab.lib.utils import ImageReader
      pw,ph=(W,H) if im.width<im.height else (H,W)
      c.setPageSize((pw,ph)); c.drawImage(ImageReader(b),0,0,pw,ph)
      if len(p)>2: c.setFont('Helvetica',8); c.drawRightString(pw-40,24,p[2])
    else:
      c.setPageSize(letter); c.setFont('Helvetica',12); y=H-80
      for l in p[1]: c.drawString(72,y,l); y-=18
    c.showPage()
  c.save()
EN=['INVOICE 4471 FROM NORTHWIND TRADERS','Customer: Contoso Legal LLP','Date: 12 March 2026','Consulting services for the quarter','Total due within thirty days: 1,250.00 USD','Please quote the invoice number','when you pay by bank transfer.']
truth['S01']=EN; build('S01_scan_clean_en.pdf',[('img',page_img(EN))])
P2=['SECOND PAGE IS REAL TEXT','Searchable already, must be left untouched.']
P3=['THIRD PAGE SCANNED AGAIN','Signature block and witness names','Witness: Maria Lopez']
truth['S02']=[EN,P2,P3]; build('S02_scan_text_scan_3p.pdf',[('img',page_img(EN)),('txt',P2),('img',page_img(P3))])
truth['S03']=EN; build('S03_sideways_90.pdf',[('img',page_img(EN,rot=90))])
truth['S04']=EN; build('S04_scan_digital_footer.pdf',[('img',page_img(EN),'Page 1 of 1')])
ES=['FACTURA NUMERO 2026 PARA LA EMPRESA','Descripción: servicios de consultoría','Año fiscal: dos mil veintiséis','Señor Muñoz, gracias por su atención']
truth['S05']=ES; build('S05_scan_spanish.pdf',[('img',page_img(ES))])
DE=['RECHNUNG FÜR DIE GROSSE BESTELLUNG','Straße: Königsallee 12, Düsseldorf','Gebühren für Übersetzungen','Bitte überweisen Sie den Betrag']
truth['S06']=DE; build('S06_scan_german.pdf',[('img',page_img(DE))])
HI=['RENT RECEIPT FOR MARCH 2026',('किराया रसीद मार्च महीने के लिए',HF),('मकान मालिक का नाम राम शर्मा',HF),'Amount received: 15,000 INR']
truth['S07']=[l if isinstance(l,str) else l[0] for l in HI]; build('S07_scan_eng_hindi.pdf',[('img',page_img(HI))])
build('S08_blank_scan.pdf',[('img',page_img([],noise=False))])
random.seed(4); truth['S09']=EN; build('S09_lowres_noisy.pdf',[('img',page_img(EN,noise=True,res=72))])
L10=[]; pg=[]
for i in range(1,13):
  t=[f'SCANNED REPORT PAGE {i} OF 12',f'Section {i}: quarterly figures for region {i}','The quick brown fox jumps over the lazy dog.']; L10.append(t); pg.append(('img',page_img(t)))
truth['S10']=L10; build('S10_scan_12p.pdf',pg)
TB=['ITEM          QTY     PRICE','Widget A        4      12.50','Widget B       10       3.25','Cable           2       7.00']
truth['S11']=TB; build('S11_scan_table.pdf',[('img',page_img(TB,font='/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'))])
truth['S12']=EN; build('S12_upside_down.pdf',[('img',page_img(EN,rot=180))])
build('_tmp.pdf',[('img',page_img(EN))]); pikepdf.open('_tmp.pdf').save('S13_scan_encrypted_ocr123.pdf',encryption=pikepdf.Encryption(user='ocr123',owner='own456',R=6)); import os; os.remove('_tmp.pdf'); truth['S13']=EN
json.dump(truth,open('truth.json','w'),indent=1,ensure_ascii=False); print('ok')
