// Check up to 8 fresh guest contexts for trial uses left on ocr-pdf (reads fdp-usage-v1 and the strip). No actions.
const { chromium } = require('playwright'); const cp = require('child_process');
(async () => { const b = await chromium.launch(); const out = [];
 for (let i = 0; i < 8; i++) { const c = await b.newContext(); const p = await c.newPage(); await p.goto('https://www.freedailypro.com/tool/ocr-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
  out.push([await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday), await p.evaluate(() => (document.querySelector('main').innerText.match(/Trial:[^\n]*/) || [''])[0])]); await c.close(); }
 console.log(cp.execSync('date "+%F %T %Z"').toString().trim(), JSON.stringify(out)); await b.close(); })();
