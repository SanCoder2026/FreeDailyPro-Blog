// ocr-pdf in Playwright WebKit (Linux build, not real Safari): load S01, Make Searchable, record outcome or crash. Twice. Guest, no Download.
const { webkit } = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const out = [];
(async () => { for (const dev of [null, 'iPhone 14 Pro Max']) { const b = await webkit.launch(); const R = { dev: dev || 'Desktop WebKit 1366', t: cp.execSync('date "+%F %T %Z"').toString().trim() };
 try { const c = await b.newContext(dev ? require('playwright').devices[dev] : { viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.on('crash', () => R.crash = true); p.on('console', m => { if (m.type() === 'error' && /OCR|tesseract|wasm/i.test(m.text())) (R.console = R.console || []).push(m.text().slice(0, 200)); });
  await p.goto('https://www.freedailypro.com/tool/ocr-pdf', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4000);
  await p.locator('main input[type=file]').first().setInputFiles('/workspace/deep/41-ocr-pdf/testfiles/S01_scan_clean_en.pdf'); await p.waitForTimeout(2500); const t0 = Date.now(); await p.getByRole('button', { name: 'Make Searchable' }).click();
  for (let i = 0; i < 90; i++) { await p.waitForTimeout(1000); if (R.crash) break; if (await p.getByRole('button', { name: /^New$/ }).count() || await p.locator('main [role=alert]').count()) break; }
  R.ms = Date.now() - t0; R.status = await p.evaluate(() => [...document.querySelectorAll('main [role=status], main [role=alert]')].map(e => e.innerText.trim()).filter(Boolean).join(' | ')).catch(e => 'ERR ' + String(e).slice(0, 80));
  await p.screenshot({ path: '/workspace/deep/41-ocr-pdf/live/webkit-' + (dev ? 'iphone' : 'desktop') + '.png' }).catch(e => R.shotErr = String(e).slice(0, 80)); } catch (e) { R.err = String(e).slice(0, 200); }
 out.push(R); console.log(JSON.stringify(R)); await b.close().catch(() => {}); }
 fs.writeFileSync('/workspace/deep/41-ocr-pdf/live/webkit.json', JSON.stringify(out, null, 1)); })();
