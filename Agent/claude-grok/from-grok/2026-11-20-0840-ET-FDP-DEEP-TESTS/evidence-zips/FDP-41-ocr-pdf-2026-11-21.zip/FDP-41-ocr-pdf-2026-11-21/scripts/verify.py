# Verify OCR PDF downloads: page count, /Rotate, text layer vs truth.json (word recall), invisible text (render mode / opacity),
# visual change vs the input (pdftoppm at 40 dpi, mean pixel diff, badge corner excluded), badge text. Usage: verify.py <downloads dir> [prefix]
import sys, os, re, json, subprocess, glob
import pypdf
from PIL import Image, ImageChops, ImageStat
TF=os.path.dirname(os.path.abspath(__file__)); truth=json.load(open(os.path.join(TF,'truth.json')))
def words(s): return re.findall(r"[\w\u0900-\u097f]+", s.lower())
def flat(t): return [w for l in (t if isinstance(t[0],str) else [x for p in t for x in p]) for w in words(l)]
def render(f,pw=None):
  out='/tmp/vr'; [os.remove(x) for x in glob.glob(out+'*')]
  cmd=['pdftoppm','-r','40','-png']+(['-upw',pw] if pw else [])+[f,out]; subprocess.run(cmd,capture_output=True); return sorted(glob.glob(out+'*.png'))
res=[]
for f in sorted(glob.glob(os.path.join(sys.argv[1],(sys.argv[2] if len(sys.argv)>2 else '')+'*.pdf'))):
  name=os.path.basename(f); m=re.search(r'(S\d\d)_',name); key=m.group(1) if m else None
  r=pypdf.PdfReader(f); R={'file':name,'pages':len(r.pages),'rotate':[p.get('/Rotate',0) for p in r.pages]}
  txt=[p.extract_text() or '' for p in r.pages]; R['text_head']=' / '.join(t.replace('\n',' ')[:90] for t in txt[:3])
  R['badge']=any('FreeDailyPro' in t for t in txt)
  if key and key in truth:
    T=set(flat(truth[key])); G=set(words(' '.join(txt))); R['recall']=round(len(T&G)/max(1,len(T)),2); R['missing']=sorted(T-G)[:12]
  raw=b''.join((p.get_contents().get_data() if p.get_contents() else b'') for p in r.pages)
  R['Tr3']=raw.count(b'3 Tr'); R['ca0']=bool(re.search(rb'/ca 0[ \]>/]|/ca 0\b',b''.join(str(p.get('/Resources')).encode() for p in r.pages)) or b'/GS' in raw)
  src=glob.glob(os.path.join(TF,key+'_*.pdf')) if key else []
  if src:
    a=render(src[0],'ocr123' if key=='S13' else None); A=[Image.open(x).convert('L') for x in a]
    b=render(f); B=[Image.open(x).convert('L') for x in b]; d=[]
    for x,y in zip(A,B):
      if x.size!=y.size: d.append('size %sx%s->%sx%s'%(x.size+y.size)); continue
      w,h=x.size; box=(0,0,int(w*0.7),int(h*0.92)); d.append(round(ImageStat.Stat(ImageChops.difference(x.crop(box),y.crop(box))).mean[0],2))
    R['visual_diff']=d
  res.append(R); print(json.dumps(R,ensure_ascii=False))
json.dump(res,open(os.path.join(sys.argv[1],'verify.json'),'w'),indent=1,ensure_ascii=False)
