import { r as s, j as e } from "./vendor-react-D01g8YgM.js";
import {
  b as Q,
  T as V,
  F as Y,
  U as ee,
  D as te,
  d as U,
} from "./ToolPage-DwLoDncN.js";
import {
  f as c,
  B as C,
  X as se,
  N as ae,
  ax as re,
  T as ne,
  e as m,
  I as P,
} from "./index-B1CTyGtY.js";
import { S as h } from "./switch-CQRPxs-N.js";
import { T as oe } from "./ToolInfoSection-C0i6Zbwo.js";
import {
  s as le,
  d as ie,
  a as ce,
  f as de,
  r as me,
} from "./utils-CRM_dY3d.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-DhOoIDuZ.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
const k = {
    what: "Finds every occurrence of a specific word or phrase and replaces it with something else, all at once. Works with pasted text, or upload a file directly — .txt, .json, .csv, .md, .html, .xml, and .docx are all supported, and the result downloads back in the same format you uploaded.",
    how: "Paste your text, or upload a file, then enter what you want to find and what to replace it with. For an uploaded file, download the corrected version afterward instead of copying from the box.",
    tip: "For a .docx file specifically, the replace happens inside the actual document so formatting is preserved — a phrase is found even when Word has split it across formatting changes; the replacement takes the formatting of where the match starts.",
  },
  ue = ["txt", "json", "csv", "md", "html", "xml"];
function T(r) {
  return r.split(".").pop()?.toLowerCase() || "";
}
function pe(r, l) {
  if (r === "json")
    try {
      return (JSON.parse(l), null);
    } catch {
      return "Heads up: this edit looks like it broke the JSON's structure — check the result carefully before using it.";
    }
  return r === "xml" &&
    new DOMParser()
      .parseFromString(l, "application/xml")
      .getElementsByTagName("parsererror").length > 0
    ? "Heads up: this edit looks like it broke the XML's structure — check the result carefully before using it."
    : null;
}
function ze() {
  const [r, l] = s.useState(""),
    [u, L] = s.useState(""),
    [S, W] = s.useState(""),
    [x, A] = s.useState(!1),
    [R, B] = s.useState(!1),
    [F, _] = s.useState(!1),
    [$, M] = s.useState(!1),
    [I, X] = s.useState(!1),
    [j, f] = s.useState(null),
    [D, g] = s.useState(null),
    [a, N] = s.useState(null),
    [n, b] = s.useState(!1),
    [y, p] = s.useState(null),
    [E, O] = s.useState(!1),
    v = {
      find: u,
      replace: S,
      useRegex: x,
      caseSensitive: R,
      wholeWord: F,
      preserveCase: $,
      multiline: I,
    },
    i = n ? null : le(v, r),
    H = s.useCallback(async (t) => {
      const o = t[0];
      if (!o) return;
      const d = T(o.name);
      if (d === "docx") {
        try {
          const w = await ie(o);
          (N(o), b(!0), l(w), p(null));
        } catch (w) {
          c.error(
            w instanceof Error ? w.message : "Couldn't read this .docx file",
          );
        }
        return;
      }
      if (d === "doc") {
        c.error(
          "The old .doc format isn't supported — only .docx. Save the file as .docx first (File > Save As in Word) and try again.",
        );
        return;
      }
      if (!ue.includes(d)) {
        c.error(
          `".${d}" isn't a supported format. Try .txt, .json, .csv, .md, .html, .xml, or .docx.`,
        );
        return;
      }
      const K = await o.text();
      (N(o), b(!1), p(null), l(K));
    }, []),
    J = () => {
      (N(null), b(!1), p(null), l(""), f(null), g(null));
    },
    z = () => {
      j !== null && (l(j), f(null), g("Last replace undone."), n && p(null));
    },
    { logUsageNow: Z } = Q(),
    q = async () => {
      if (u && !(!a && !(await Z()))) {
        if (n && a) {
          O(!0);
          try {
            const t = await ce(a, v);
            (f(r),
              l(t.previewText),
              g(
                t.replacementCount > 0
                  ? `Replaced ${t.replacementCount} occurrence${t.replacementCount === 1 ? "" : "s"}.`
                  : "No matches found in this document.",
              ),
              p({ blob: t.blob, replacementCount: t.replacementCount }),
              c.success(
                t.replacementCount > 0
                  ? `Replaced ${t.replacementCount} occurrence(s)!`
                  : "No matches found in this document.",
              ));
          } catch {
            c.error(
              "That pattern isn't valid — check your regex syntax and try again.",
            );
          } finally {
            O(!1);
          }
          return;
        }
        try {
          const t = de(v, r).length,
            o = me(v, r);
          if (
            (f(r),
            l(o),
            g(
              t > 0
                ? `Replaced ${t} occurrence${t === 1 ? "" : "s"}.`
                : "No matches found — nothing was changed.",
            ),
            t > 0 && c.success(`Replaced ${t} occurrence${t === 1 ? "" : "s"}`),
            a)
          ) {
            const d = pe(T(a.name), o);
            d && c.warning(d);
          }
        } catch {
          c.error(
            "That pattern isn't valid — check your regex syntax (an unclosed bracket or parenthesis is the usual cause) and try again.",
          );
        }
      }
    },
    G = () => {
      if (a)
        if (n && y) U(y.blob, a.name.replace(/\.docx$/i, "_edited.docx"));
        else {
          const t = T(a.name),
            o =
              t === "json"
                ? "application/json"
                : t === "html"
                  ? "text/html"
                  : t === "xml"
                    ? "application/xml"
                    : t === "csv"
                      ? "text/csv"
                      : t === "md"
                        ? "text/markdown"
                        : "text/plain";
          U(
            new Blob([r], { type: o }),
            a.name.replace(/\.[^.]+$/, `_edited.${t}`),
          );
        }
    };
  return e.jsxs(V, {
    children: [
      !a &&
        e.jsx(Y, {
          gateAtDownload: !0,
          accept: ".txt,.json,.csv,.md,.html,.xml,.docx",
          onFiles: H,
          label: "Drop a file (optional)",
          description:
            ".txt, .json, .csv, .md, .html, .xml, or .docx — or just paste text below instead",
        }),
      a &&
        e.jsxs("div", {
          className:
            "flex items-center justify-between p-3 rounded-lg border bg-card mb-3",
          children: [
            e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                e.jsx(ee, { className: "h-4 w-4 text-muted-foreground" }),
                e.jsx("p", {
                  className: "text-sm font-medium",
                  children: a.name,
                }),
                n &&
                  e.jsx("span", {
                    className: "text-xs text-muted-foreground",
                    children: "(preview — formatting preserved on download)",
                  }),
              ],
            }),
            e.jsx(C, {
              variant: "ghost",
              size: "icon",
              onClick: J,
              "aria-label": "Remove file",
              children: e.jsx(se, { className: "h-4 w-4" }),
            }),
          ],
        }),
      n &&
        e.jsx(ae, {
          className: "mb-3",
          children: e.jsxs("div", {
            className: "flex gap-2",
            children: [
              e.jsx(re, { className: "h-4 w-4 text-primary shrink-0 mt-0.5" }),
              e.jsx("p", {
                className: "text-xs",
                children:
                  "This is a read-only preview of the document's text. Formatting, images, and layout are preserved and aren't shown here — edit using Find/Replace below, then download the corrected .docx.",
              }),
            ],
          }),
        }),
      e.jsx(ne, {
        "aria-label": "Text to search",
        placeholder: "Enter your text...",
        value: r,
        onChange: (t) => !n && l(t.target.value),
        readOnly: n,
        className: `min-h-[150px] ${n ? "bg-muted/30" : ""}`,
      }),
      e.jsxs("div", {
        className: "grid grid-cols-1 md:grid-cols-2 gap-4 mt-4",
        children: [
          e.jsxs("div", {
            children: [
              e.jsx(m, { htmlFor: "fr-find", children: "Find" }),
              e.jsx(P, {
                id: "fr-find",
                value: u,
                onChange: (t) => L(t.target.value),
                placeholder: "Search text...",
                "aria-invalid": i === "invalid",
                "aria-describedby": i === "invalid" ? "fr-find-err" : void 0,
              }),
            ],
          }),
          e.jsxs("div", {
            children: [
              e.jsx(m, { htmlFor: "fr-replace", children: "Replace with" }),
              e.jsx(P, {
                id: "fr-replace",
                value: S,
                onChange: (t) => W(t.target.value),
                placeholder: "Replacement...",
              }),
            ],
          }),
        ],
      }),
      e.jsxs("div", {
        className: "flex flex-wrap items-center gap-x-6 gap-y-2 mt-3",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-2",
            children: [
              e.jsx(h, {
                checked: x,
                onCheckedChange: A,
                "aria-label": "Regex",
              }),
              e.jsx(m, { className: "text-sm", children: "Regex" }),
            ],
          }),
          e.jsxs("div", {
            className: "flex items-center gap-2",
            children: [
              e.jsx(h, {
                checked: R,
                onCheckedChange: B,
                "aria-label": "Case sensitive",
              }),
              e.jsx(m, { className: "text-sm", children: "Case sensitive" }),
            ],
          }),
          e.jsxs("div", {
            className: "flex items-center gap-2",
            children: [
              e.jsx(h, {
                checked: F,
                onCheckedChange: _,
                "aria-label": "Whole word",
              }),
              e.jsx(m, { className: "text-sm", children: "Whole word" }),
            ],
          }),
          e.jsxs("div", {
            className: "flex items-center gap-2",
            children: [
              e.jsx(h, {
                checked: $,
                onCheckedChange: M,
                "aria-label": "Preserve case",
              }),
              e.jsx(m, { className: "text-sm", children: "Preserve case" }),
            ],
          }),
          x &&
            e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                e.jsx(h, {
                  checked: I,
                  onCheckedChange: X,
                  "aria-label": "^ $ match each line",
                }),
                e.jsx(m, {
                  className: "text-sm",
                  children: "^ $ match each line",
                }),
              ],
            }),
          u &&
            !n &&
            e.jsx("span", {
              id: i === "invalid" ? "fr-find-err" : void 0,
              role: i === "invalid" ? "alert" : void 0,
              className: `text-sm ${i === "invalid" ? "text-destructive font-medium" : "text-muted-foreground"}`,
              children:
                i === "invalid"
                  ? "Invalid pattern — check your regex syntax"
                  : `${i} match${i === 1 ? "" : "es"} found`,
            }),
        ],
      }),
      e.jsxs("div", {
        className: "flex gap-3 mt-4",
        children: [
          e.jsx(C, {
            onClick: q,
            disabled: !u || i === "invalid" || E,
            children: E ? "Replacing..." : "Replace All",
          }),
          j !== null &&
            e.jsx(C, { variant: "outline", onClick: z, children: "Undo" }),
          a &&
            (n ? y : !0) &&
            e.jsx(te, {
              onClick: G,
              label: n ? "Download Corrected .docx" : "Download Corrected File",
            }),
        ],
      }),
      D &&
        e.jsx("p", {
          className: "text-sm mt-3",
          role: "status",
          "data-testid": "fr-result",
          children: D,
        }),
      x &&
        e.jsx("p", {
          className: "text-xs text-muted-foreground mt-2",
          children:
            "Regex mode: use $1, $& or $<name> in the replacement, and \\n or \\t for a new line or tab.",
        }),
      e.jsx(oe, { whatIsIt: k.what, howToUse: k.how, tip: k.tip }),
    ],
  });
}
export { ze as default };
//# sourceMappingURL=FindReplace-DrPESoBx.js.map
