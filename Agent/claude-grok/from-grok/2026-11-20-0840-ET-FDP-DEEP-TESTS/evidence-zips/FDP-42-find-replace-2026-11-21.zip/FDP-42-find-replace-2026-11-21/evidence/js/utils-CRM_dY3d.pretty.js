import { J as S } from "./jszip.min-CT0ZA6V1.js";
const $ = /[.*+?^${}()|[\]\\]/g;
function g(e) {
  let t = e.useRegex ? e.find : e.find.replace($, "\\$&");
  e.wholeWord && (t = `(?<![\\p{L}\\p{N}_])(?:${t})(?![\\p{L}\\p{N}_])`);
  const r =
    (e.caseSensitive ? "g" : "gi") +
    (e.multiline && e.useRegex ? "m" : "") +
    (e.wholeWord ? "u" : "");
  return new RegExp(t, r);
}
function z(e, t) {
  if (!e.find) return 0;
  try {
    return (t.match(g(e)) || []).length;
  } catch {
    return "invalid";
  }
}
function D(e, t, r, n, s, c) {
  return e.replace(/\$(\$|&|`|'|\d{1,2}|<[^>]+>)/g, (i, o) => {
    if (o === "$") return "$";
    if (o === "&") return t;
    if (o === "`") return s.slice(0, c);
    if (o === "'") return s.slice(c + t.length);
    if (o[0] === "<") return n?.[o.slice(1, -1)] ?? "";
    const u = Number(o);
    return u >= 1 && u <= r.length ? (r[u - 1] ?? "") : "$" + o;
  });
}
function M(e, t) {
  return /[A-Za-z\u00C0-\u024F]/.test(e)
    ? e === e.toUpperCase() && e.length > 1
      ? t.toUpperCase()
      : e === e.toLowerCase()
        ? t
        : e[0] === e[0].toUpperCase() && e.slice(1) === e.slice(1).toLowerCase()
          ? t.charAt(0).toUpperCase() + t.slice(1)
          : t
    : t;
}
function N(e, t) {
  const r = t[0],
    n = typeof t[t.length - 1] == "object" && t[t.length - 1] !== null,
    s = n ? t[t.length - 1] : void 0,
    c = n ? t.slice(1, -1) : t.slice(1),
    i = c[c.length - 1],
    o = c[c.length - 2],
    u = c.slice(0, -2);
  let a;
  if (e.useRegex) {
    const f = e.replace
      .replace(
        /\\n/g,
        `
`,
      )
      .replace(/\\t/g, "	");
    a = D(f, r, u, s, i, o);
  } else a = e.replace;
  return e.preserveCase ? M(r, a) : a;
}
function L(e, t) {
  const r = [];
  return (
    t.replace(g(e), (...n) => {
      const s = n[0],
        i =
          typeof n[n.length - 1] == "object" && n[n.length - 1] !== null
            ? n.slice(1, -1)
            : n.slice(1),
        o = i[i.length - 2];
      return (r.push({ start: o, end: o + s.length, replacement: N(e, n) }), s);
    }),
    r
  );
}
function B(e, t) {
  return t.replace(g(e), (...r) => N(e, r));
}
async function P(e) {
  const t = await S.loadAsync(e),
    r = "word/document.xml",
    n = t.file(r);
  if (!n)
    throw new Error(
      "This doesn't look like a valid .docx file (missing word/document.xml).",
    );
  const s = await n.async("text"),
    c = new DOMParser().parseFromString(s, "application/xml");
  if (c.getElementsByTagName("parsererror")[0])
    throw new Error("This .docx file's internal structure couldn't be read.");
  return { zip: t, xmlDoc: c, xmlPath: r };
}
function R(e) {
  return Array.from(e.getElementsByTagName("w:p")).map((r) =>
    Array.from(r.getElementsByTagName("w:t"))
      .map((n) => n.textContent || "")
      .join(""),
  ).join(`
`);
}
async function F(e) {
  const { xmlDoc: t } = await P(e);
  return R(t);
}
async function _(e, t) {
  const { zip: r, xmlDoc: n, xmlPath: s } = await P(e);
  g(t);
  let c = 0;
  for (const u of Array.from(n.getElementsByTagName("w:p"))) {
    const a = Array.from(u.getElementsByTagName("w:t"));
    if (a.length === 0) continue;
    const f = a.map((m) => m.textContent || ""),
      b = f.join("");
    if (!b) continue;
    const y = L(t, b);
    if (y.length === 0) continue;
    c += y.length;
    const v = [];
    let E = 0;
    for (const m of f) (v.push([E, E + m.length]), (E += m.length));
    a.forEach((m, d) => {
      const [p, w] = v[d];
      let x = "",
        h = p;
      for (const l of y) {
        const T =
            (l.start >= p && l.start < w) ||
            (l.start === w && d === a.length - 1 && l.end === l.start),
          C = Math.max(l.start, p),
          A = Math.min(l.end, w);
        (!T && A <= C) ||
          (C > h && (x += f[d].slice(h - p, C - p)),
          T && (x += l.replacement),
          (h = Math.max(h, A, T ? l.start : 0)));
      }
      (h < w && (x += f[d].slice(h - p)),
        x !== f[d] &&
          ((m.textContent = x), m.setAttribute("xml:space", "preserve")));
    });
  }
  const i = new XMLSerializer().serializeToString(n);
  return (
    r.file(s, i),
    {
      blob: await r.generateAsync({
        type: "blob",
        compression: "DEFLATE",
        compressionOptions: { level: 6 },
        mimeType:
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      }),
      replacementCount: c,
      previewText: R(n),
    }
  );
}
export { _ as a, F as d, L as f, B as r, z as s };
//# sourceMappingURL=utils-CRM_dY3d.js.map
