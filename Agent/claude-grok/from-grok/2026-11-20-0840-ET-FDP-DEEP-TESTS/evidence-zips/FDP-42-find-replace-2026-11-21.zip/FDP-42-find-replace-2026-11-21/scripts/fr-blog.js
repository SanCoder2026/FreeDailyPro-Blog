// Rendered check of /blog/find-replace: what the reader sees where the post explains "$&" (prerender String.replace artefact), and how many #root elements exist.
const { chromium } = require('playwright'); const fs = require('fs');
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage();
 await p.goto('https://www.freedailypro.com/blog/find-replace', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000);
 const R = await p.evaluate(() => { const t = document.body.innerText; const i = t.indexOf('inserts the whole match'); return { snippet: t.slice(i - 120, i + 30), roots: document.querySelectorAll('#root').length }; });
 const el = p.getByText('inserts the whole match').first(); await el.scrollIntoViewIfNeeded().catch(() => {}); await p.screenshot({ path: '/workspace/deep/42-find-replace/live/blog-dollar-amp.png' });
 fs.writeFileSync('/workspace/deep/42-find-replace/live/blog-render.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R)); await b.close(); })();
