// Expand every accordion on find-replace (guest) and save the visible text + JSON-LD found in the rendered DOM.
const { chromium } = require('playwright'); const fs = require('fs');
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage();
 await p.goto('https://www.freedailypro.com/tool/find-replace', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000);
 for (let k = 0; k < 3; k++) { const bs = p.locator('main button[aria-expanded=false]'); const n = await bs.count(); for (let i = n - 1; i >= 0; i--) await bs.nth(i).click().catch(() => {}); await p.waitForTimeout(800); }
 const t = await p.evaluate(() => document.querySelector('main').innerText); fs.writeFileSync('/workspace/deep/42-find-replace/tool-expanded.txt', t);
 const ld = await p.evaluate(() => [...document.querySelectorAll('script[type="application/ld+json"]')].map(s => { try { return JSON.parse(s.textContent) } catch (e) { return s.textContent } }));
 fs.writeFileSync('/workspace/deep/42-find-replace/tool-expanded.txt.jsonld.json', JSON.stringify(ld, null, 1));
 const links = await p.evaluate(() => [...document.querySelectorAll('main a')].map(a => a.getAttribute('href') + ' | ' + a.innerText.trim().slice(0, 80)));
 fs.writeFileSync('/workspace/deep/42-find-replace/tool-links.txt', links.join('\n')); console.log(t.length, ld.length); await b.close(); })();
