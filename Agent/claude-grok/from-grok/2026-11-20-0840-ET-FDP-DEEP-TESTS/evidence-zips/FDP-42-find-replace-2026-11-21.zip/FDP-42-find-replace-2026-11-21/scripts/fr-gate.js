// find-replace gate (guest). Part 1 needs a fresh context with trial uses left (tries up to 20): counter on load/reload, typing, pasted Replace All x2 (+Undo), reload + Replace All,
// .txt file Replace All -> Download x2 -> Drive/cloud (stop at sign-in), .docx Replace All -> Download. Part 2 (context at 0): pasted Replace All, .txt file Replace All (is the replaced text shown and copyable?), Download -> cap -> Day Pass (email prompt, types nothing), .docx Replace All + Download, keyboard.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const crypto = require('crypto');
const BASE = '/workspace/deep/42-find-replace/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/find-replace';
fs.mkdirSync(OUT + 'downloads', { recursive: true });
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex').slice(0, 16);
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').slice(0, 160);
const TXT = 'Acme Corp signed. ACME CORP ships. acme corp and Acme Corporation.';
const part = process.argv[2] || '12';
(async () => { const b = await chromium.launch(); const R = { t: now(), tries: [] }; let c, p;
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true, permissions: ['clipboard-read', 'clipboard-write'] }); p = await c.newPage(); p.setDefaultTimeout(15000); await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 const strip = () => p.evaluate(() => (document.querySelector('main').innerText.match(/Trial:[^\n]*|[^\n]*remaining today[^\n]*/) || [''])[0]);
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 const box = () => p.locator('main textarea[aria-label="Text to search"]');
 const state = async () => ({ used: await used(), box: (await box().inputValue().catch(() => '')).slice(0, 200), boxLen: (await box().inputValue().catch(() => '')).length, result: await p.evaluate(() => document.querySelector('[data-testid=fr-result]')?.innerText || null), counter: await p.evaluate(() => (document.querySelector('main').innerText.match(/\d+ match(es)? found|Invalid pattern[^\n]*/) || [''])[0]), toasts: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim().replace(/\n/g, ' '))), dl: await p.evaluate(() => [...document.querySelectorAll('main button')].map(e => e.innerText.trim()).filter(x => /^Download|Day Pass|Save to/.test(x))), dialog: await dialog() });
 const setFR = async (f, r) => { await p.locator('#fr-find').fill(f); await p.locator('#fr-replace').fill(r); await p.waitForTimeout(400); };
 const replaceAll = async (name) => { const u0 = await used(); await p.getByRole('button', { name: /^Replace All/ }).click(); await p.waitForTimeout(2500); const s = await state(); s.before = u0; s.t = now(); if (s.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + '.png' }); console.log(name, JSON.stringify(s).slice(0, 500)); await esc(); return s; };
 const drop = async (f) => { const rm = p.getByRole('button', { name: 'Remove file' }); if (await rm.count()) { await rm.click(); await p.waitForTimeout(500); } await p.locator('main input[type=file]').first().setInputFiles(TF + f); await p.waitForTimeout(2500); };
 const act = async (name, loc) => { const r = { before: await used() }; if (!(await loc.count())) { r.missing = true; return r; }
   const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); const dl = p.waitForEvent('download', { timeout: 12000 }).catch(() => null); await loc.first().click(); const [pg, d] = await Promise.all([pop, dl]); await p.waitForTimeout(2000);
   r.dialog = await dialog(); r.after = await used(); r.t = now();
   if (d) { r.download = d.suggestedFilename(); const f = OUT + 'downloads/gate-' + name + '-' + d.suggestedFilename(); await d.saveAs(f); r.bytes = fs.statSync(f).size; r.sha = sha(f); }
   if (pg) { await pg.waitForLoadState('domcontentloaded').catch(() => {}); r.popup = red(pg.url()); r.popupTitle = await pg.title().catch(() => null); await pg.close(); }
   if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + '.png' });
   if (r.dialog && /Day Pass/.test(r.dialog) && !R.dayPassFromCap) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.dayPassFromCap = { from: name, dialog: await dialog(), emailField: await p.locator('input[type=email]').count(), url: red(p.url()) }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); } }
   await esc(); console.log(name, JSON.stringify(r).slice(0, 500)); return r; };
 const DL = () => p.getByRole('button', { name: /^Download Corrected/ });
 const reload = async () => { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); };
 if (part.includes('1')) { for (let i = 0; i < 20; i++) { await open(); const u = await used(); R.tries.push(u); if (u < 10) { await p.waitForTimeout(6000); const u2 = await used(); R.tries.push('recheck ' + u2); if (u2 < 10) break; } await c.close(); c = null; }
  if (c) { const L = R.left = { t: now(), start: await used(), strip: await strip() };
   await reload(); L.reload1 = await used(); await reload(); L.reload2 = await used();
   await box().fill(TXT); await setFR('Acme Corp', 'Globex'); L.typed = await state();
   L.r1 = await replaceAll('L-r1'); await p.getByRole('button', { name: 'Undo' }).click(); await p.waitForTimeout(500); L.undo = await state();
   L.r2 = await replaceAll('L-r2'); await box().fill(TXT + ' Acme Corp again.'); await setFR('Acme Corp', 'Initech'); L.r3 = await replaceAll('L-r3');
   await reload(); L.afterReload = await used(); await box().fill(TXT); await setFR('Acme Corp', 'Globex'); L.r4 = await replaceAll('L-r4'); L.r5 = await replaceAll('L-r5');
   await reload(); await drop('F01_plain.txt'); await setFR('Acme Corp', 'Globex'); L.f1 = await replaceAll('L-f1'); L.dl1 = await act('L-dl1', DL()); L.dl2 = await act('L-dl2', DL());
   L.drive = await act('L-drive', p.getByRole('button', { name: /Save to Google Drive/ })); L.cloud = await act('L-cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
   await drop('F11_rich.docx'); await setFR('Acme Corp', 'Globex'); L.f2 = await replaceAll('L-f2'); L.dl3 = await act('L-dl3', DL());
   await reload(); L.end = await used(); L.t2 = now(); await c.close(); c = null; } }
 if (part.includes('2')) { for (let i = 0; i < 4; i++) { await open(); if (await used() >= 10) break; await c.close(); }
  const Z = R.zero = { t: now(), start: await used(), strip: await strip() };
  let chooser = false; p.on('filechooser', () => { chooser = true; }); const seq = [];
  for (let i = 0; i < 40; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('role') || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50).replace(/\n/g, ' '); }); seq.push(a); if (/Drop a file/i.test(a)) { await p.keyboard.press('Enter'); await p.waitForTimeout(1200); seq.push('ENTER -> chooser=' + chooser); break; } }
  Z.kbd = { tabs: seq.length, last: seq.slice(-3), chooser };
  await box().fill(TXT); await setFR('Acme Corp', 'Globex'); Z.typed = await state(); Z.r1 = await replaceAll('zero-paste'); await p.screenshot({ path: OUT + 'zero-paste.png' });
  await drop('F01_plain.txt'); await setFR('Acme Corp', 'Globex'); Z.f1 = await replaceAll('zero-txt'); await p.screenshot({ path: OUT + 'zero-txt.png' });
  await p.evaluate(() => navigator.clipboard.writeText('EMPTY')); await box().click(); await p.keyboard.press('Control+A'); await p.keyboard.press('Control+C'); await p.waitForTimeout(400); const clip = await p.evaluate(() => navigator.clipboard.readText()); Z.manualCopy = { len: clip.length, head: clip.slice(0, 120), hasGlobex: clip.includes('Globex') };
  Z.dl = await act('zero-dl', DL()); Z.drive = await act('zero-drive', p.getByRole('button', { name: /Save to Google Drive/ }));
  await drop('F11_rich.docx'); await setFR('Acme Corp', 'Globex'); Z.f2 = await replaceAll('zero-docx'); await p.screenshot({ path: OUT + 'zero-docx.png' }); Z.dl2 = await act('zero-dl-docx', DL()); Z.end = await used();
  const qb = p.getByRole('button', { name: 'Quick Buy' }); Z.quickBuy = await qb.count();
  if (Z.quickBuy) { const u0 = p.url(); await qb.first().click(); await p.waitForTimeout(3000); Z.qbDay = { url: p.url() !== u0 ? red(p.url()) : null, dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await esc();
   if (p.url() !== u0) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); }
   await p.getByRole('button', { name: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); Z.qbMonth = { url: red(p.url()), dialog: await dialog(), title: await p.title() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' }); } }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate-' + part + '.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify({ tries: R.tries, left: !!R.left }, null, 1)); await b.close(); })();
