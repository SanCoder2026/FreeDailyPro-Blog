// find-replace live cases (guest; works at 0 trial uses because the tool is uncounted). node fr-live.js <chromium|firefox|webkit>
// Each case: reload, paste text or drop a file, set switches, read the live counter, Replace All, read result/toasts, Download if a file was used (saved for verify.py).
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/42-find-replace/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/find-replace';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const engName = process.argv[2] || 'chromium'; const eng = pw[engName]; fs.mkdirSync(OUT + 'downloads', { recursive: true });
const P = 'Acme Corp signed the deal. ACME CORP will ship. acme corp, acmecorp and Acme Corporation differ.\nCall Acme Corp at 555-0100 on 2026-03-12.\nThe cat sat on the catalog. CAT! Cat?';
const C = [
 ['T01', { text: P, find: 'Acme Corp', rep: 'Globex' }], ['T02', { text: P, find: 'cat', rep: 'dog', sw: ['Whole word'] }], ['T03', { text: P, find: 'cat', rep: 'dog', sw: ['Whole word', 'Preserve case'] }],
 ['T04', { text: P, find: 'Acme Corp', rep: 'Globex', sw: ['Case sensitive'] }], ['T05', { text: P, find: '(\\d{4})-(\\d{2})-(\\d{2})', rep: '$3/$2/$1', sw: ['Regex'] }], ['T06', { text: P, find: '(unclosed', rep: 'x', sw: ['Regex'] }],
 ['T07', { text: P, find: '\\. ', rep: '.\\n', sw: ['Regex'] }], ['T08', { text: P, find: '^Call', rep: '>Call', sw: ['Regex', '^ $ match each line'] }], ['T08b', { text: P, find: '^Call', rep: '>Call', sw: ['Regex'] }],
 ['T09', { text: P, find: '(?<y>\\d{4})-(?<m>\\d{2})', rep: '$<m>/$<y>', sw: ['Regex'] }], ['T10', { text: P, find: 'Acme Corp', rep: '' }], ['T11', { file: 'F07_unicode.txt', find: 'café', rep: 'tea', sw: ['Whole word', 'Preserve case'] }],
 ['T12', { file: 'F07_unicode.txt', find: '👍', rep: 'OK' }], ['T12b', { file: 'F07_unicode.txt', find: 'привет', rep: 'hello', sw: ['Whole word'] }], ['T13', { file: 'F02_data.json', find: '"', rep: '' }], ['T13b', { file: 'F02_data.json', find: 'Acme Corp', rep: 'Globex' }],
 ['T14', { file: 'F06_feed.xml', find: '<company>', rep: '<company' }], ['T15', { file: 'F03_list.csv', find: 'Acme Corp', rep: 'Globex, Inc' }], ['T16', { file: 'F05_page.html', find: 'old.example.com', rep: 'new.example.com' }],
 ['T16b', { file: 'F04_readme.md', find: 'Acme Corp', rep: 'Globex' }], ['T17', { file: 'F08_old.doc' }], ['T18', { file: 'F10_image.png' }], ['T19', { file: 'F09_broken.docx' }],
 ['T20', { file: 'F11_rich.docx', find: 'Acme Corp', rep: 'Globex' }], ['T21', { file: 'F11_rich.docx', find: 'acme corp', rep: 'globex', sw: ['Preserve case'] }], ['T22', { file: 'F11_rich.docx', find: '\\{\\{name\\}\\}', rep: 'Jane', sw: ['Regex'] }],
 ['T23', { file: 'F12_large.txt', find: 'Acme Corp', rep: 'Globex' }], ['T24', { text: P, find: 'Acme Corp', rep: 'Globex', undo: true }], ['T25', { text: 'a'.repeat(28) + 'b', find: '(a+)+$', rep: 'x', sw: ['Regex'], slow: true }],
 ['T26', { text: 'abc', find: 'x*', rep: '-', sw: ['Regex'] }], ['T27', { file: 'F01_plain.txt', find: 'Acme Corp', rep: '$&!' }], ['T28', { file: 'F01_plain.txt', find: 'Acme Corp', rep: '$&!', sw: ['Regex'] }]];
(async () => { const b = await eng.launch(); const ctx = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await ctx.newPage(); p.setDefaultTimeout(15000); const ALL = { t: now(), engine: engName, cases: [] };
 const only = process.argv[3] ? process.argv[3].split(',') : null;
 for (const [id, o] of C) { if (only && !only.includes(id)) continue; const R = { id, o: { ...o, text: o.text ? o.text.slice(0, 60) : undefined }, t: now() };
  try { await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(2500);
   if (o.file) { await p.locator('main input[type=file]').first().setInputFiles(TF + o.file); await p.waitForTimeout(2500); R.afterLoad = { name: await p.evaluate(() => document.querySelector('main .bg-card p')?.innerText || null), toasts: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim().replace(/\n/g, ' '))), boxLen: (await p.locator('main textarea').first().inputValue().catch(() => '')).length } }
   else await p.locator('main textarea').first().fill(o.text);
   if (o.find !== undefined) { for (const s of o.sw || []) { await p.getByRole('switch', { name: s }).click(); await p.waitForTimeout(200); }
    const t0 = Date.now(); await p.locator('#fr-find').fill(o.find); R.findMs = Date.now() - t0; await p.locator('#fr-replace').fill(o.rep); await p.waitForTimeout(600);
    R.counter = await p.evaluate(() => (document.querySelector('main').innerText.match(/\d+ match(es)? found|Invalid pattern[^\n]*/) || [''])[0]); R.btnDisabled = await p.getByRole('button', { name: /^Replace All|^Replacing/ }).isDisabled();
    if (!R.btnDisabled) { const t1 = Date.now(); await p.getByRole('button', { name: /^Replace All/ }).click(); await p.waitForTimeout(1500); R.replaceMs = Date.now() - t1; }
    R.result = await p.evaluate(() => document.querySelector('[data-testid=fr-result]')?.innerText || null); R.toasts = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim().replace(/\n/g, ' ')));
    const v = await p.locator('main textarea').first().inputValue(); R.boxLen = v.length; R.box = v.slice(0, 400);
    if (o.undo) { await p.getByRole('button', { name: 'Undo' }).click(); await p.waitForTimeout(500); const u = await p.locator('main textarea').first().inputValue(); R.afterUndo = { same: u === o.text, result: await p.evaluate(() => document.querySelector('[data-testid=fr-result]')?.innerText || null), undoBtn: await p.getByRole('button', { name: 'Undo' }).count() }; }
    const dlb = p.getByRole('button', { name: /^Download Corrected/ }); if (o.file && await dlb.count()) { const dl = p.waitForEvent('download', { timeout: 12000 }).catch(() => null); await dlb.first().click(); const d = await dl; if (d) { const f = OUT + 'downloads/' + id + '-' + d.suggestedFilename(); await d.saveAs(f); R.file = f.split('/').pop(); R.bytes = fs.statSync(f).size; } R.dialog = await p.evaluate(() => document.querySelector('[role=dialog]')?.innerText.slice(0, 150) || null); } }
  } catch (e) { R.err = String(e).slice(0, 300); }
  if (['T01', 'T11', 'T13', 'T17', 'T20', 'T06', 'T25'].includes(id)) await p.screenshot({ path: OUT + 'case-' + id + (engName === 'chromium' ? '' : '-' + engName) + '.png' }).catch(() => {});
  console.log(JSON.stringify(R).slice(0, 800)); ALL.cases.push(R); }
 ALL.end = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday).catch(() => null); ALL.t2 = now(); fs.writeFileSync(OUT + 'cases-' + engName + (only ? '-subset' : '') + '.json', JSON.stringify(ALL, null, 1)); await b.close(); })();
