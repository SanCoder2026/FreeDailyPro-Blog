# FDP-42 Find & Replace test files. Run with venv-pdf python (python-docx, PIL for an image).
import json, docx, io
from docx.shared import Pt, RGBColor
from PIL import Image
T="Acme Corp signed the deal. ACME CORP will ship. acme corp, acmecorp and Acme Corporation differ.\nCall Acme Corp at 555-0100 on 2026-03-12.\nThe cat sat on the catalog. CAT! Cat?\n"
open('F01_plain.txt','w').write(T)
json.dump({"company":"Acme Corp","items":[{"name":"Widget","price":12.5},{"name":"Gadget \"Pro\"","price":3}],"note":"Acme Corp ships"},open('F02_data.json','w'),indent=2)
open('F03_list.csv','w').write('name,company,date\nJane,Acme Corp,2026-03-12\n"Roe, John","Acme Corp, Ltd",2026-04-01\n')
open('F04_readme.md','w').write('# Acme Corp README\n\nInstall **Acme Corp** tools: `acme-cli`.\n\n- [Docs](https://acme.example.com)\n')
open('F05_page.html','w').write('<!doctype html><html><head><title>Acme Corp</title></head><body><a href="https://old.example.com/acme">Acme Corp</a><p class="acme">Acme Corp &amp; partners</p></body></html>')
open('F06_feed.xml','w').write('<?xml version="1.0"?><feed><company>Acme Corp</company><url>https://old.example.com</url></feed>')
open('F07_unicode.txt','w').write('Café Zürich – naïve résumé. Straße STRASSE. Ελληνικά. Привет мир. 東京 タワー. emoji 👍👍 end.\nCAFÉ café Café\n')
open('F08_old.doc','wb').write(b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1'+b'\0'*500)
open('F10_image.png','wb').write(b'')
Image.new('RGB',(10,10)).save('F10_image.png')
# DOCX with split runs, formatting, table, header/footer, footnote-less, image
d=docx.Document(); s=d.sections[0]; s.header.paragraphs[0].text='HEADER Acme Corp'; s.footer.paragraphs[0].text='FOOTER Acme Corp'
p=d.add_paragraph(); r=p.add_run('Acme '); r.bold=True; r2=p.add_run('Corp'); r2.italic=True; p.add_run(' split across runs.')
p=d.add_paragraph(); r=p.add_run('Red Acme Corp text'); r.font.color.rgb=RGBColor(0xC0,0,0); r.font.size=Pt(16)
d.add_paragraph('Plain Acme Corp line with acme corp lowercase and ACME CORP caps.')
t=d.add_table(rows=2,cols=2); t.cell(0,0).text='Acme Corp'; t.cell(0,1).text='Price'; t.cell(1,0).text='Widget'; t.cell(1,1).text='12.50'
b=io.BytesIO(); Image.new('RGB',(120,60),(30,120,200)).save(b,'PNG'); b.seek(0); d.add_picture(b)
d.add_paragraph('Template: Dear {{name}}, your order {{order}} ships.')
d.add_paragraph('Line one of a paragraph'); d.add_paragraph('Acme')
d.add_paragraph('Corp starts the next paragraph.')
d.save('F11_rich.docx')
# Large text ~6 MB
open('F12_large.txt','w').write(('Acme Corp line %d with some filler text for size.\n'*1)*0 + ''.join('Acme Corp line %d with some filler text for size.\n'%i for i in range(120000)))
print('ok')
