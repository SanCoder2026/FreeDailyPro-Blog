# Verify Find & Replace downloads: .docx (runs + formatting, header/footer, table, image, paragraph-split phrase) and text files (byte diff vs input, encoding, BOM, line endings).
import sys, os, glob, json, zipfile, docx
D=sys.argv[1]; TF=os.path.dirname(os.path.abspath(__file__)); out=[]
for f in sorted(glob.glob(os.path.join(D,'*'))):
  n=os.path.basename(f); R={'file':n,'bytes':os.path.getsize(f)}
  if n.endswith('.docx'):
    d=docx.Document(f); R['paras']=[[ (r.text, bool(r.bold), bool(r.italic), str(r.font.color.rgb) if r.font.color and r.font.color.type else None, r.font.size.pt if r.font.size else None) for r in p.runs] for p in d.paragraphs[:4]]
    R['header']=d.sections[0].header.paragraphs[0].text; R['footer']=d.sections[0].footer.paragraphs[0].text
    R['table']=[[c.text for c in row.cells] for row in d.tables[0].rows]; R['images']=len([x for x in zipfile.ZipFile(f).namelist() if x.startswith('word/media/')])
    R['last_paras']=[p.text for p in d.paragraphs[-4:]]
  elif n.endswith('.json') and n!='verify.json':
    b=open(f,'rb').read(); R['bom']=b.startswith(b'\xef\xbb\xbf'); R['crlf']=b'\r\n' in b
    try: json.loads(b); R['json_valid']=True
    except Exception: R['json_valid']=False
  elif os.path.splitext(n)[1] in ('.txt','.csv','.md','.html','.xml'):
    b=open(f,'rb').read(); R['bom']=b.startswith(b'\xef\xbb\xbf'); R['crlf']=b'\r\n' in b; R['utf8']=True
    try: b.decode('utf-8')
    except Exception: R['utf8']=False
    R['head']=b[:120].decode('utf-8','replace')
  else: continue
  out.append(R); print(json.dumps(R,ensure_ascii=False)[:900])
json.dump(out,open(os.path.join(D,'..','verify.json'),'w'),indent=1,ensure_ascii=False)
