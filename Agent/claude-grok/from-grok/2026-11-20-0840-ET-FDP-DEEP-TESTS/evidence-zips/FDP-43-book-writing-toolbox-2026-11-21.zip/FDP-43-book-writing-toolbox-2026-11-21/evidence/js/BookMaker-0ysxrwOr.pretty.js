import {
  E as wa,
  t as P,
  M as Cn,
  m as Sn,
  r as l,
  u as pr,
  j as e,
  b as xr,
  N as gr,
  d as ta,
} from "./vendor-react-D01g8YgM.js";
import {
  s as fr,
  T as br,
  a as vr,
  b as wr,
  c as jr,
  d as yr,
  e as Nr,
  f as kr,
  g as Cr,
  i as Sr,
  h as Tr,
} from "./chapterImport-BUHVPQur.js";
import {
  v as Ne,
  B as u,
  du as Ar,
  dv as Pr,
  b6 as Dr,
  dw as Ir,
  ar as be,
  as as ve,
  at as we,
  au as je,
  bi as vt,
  e as j,
  I as k,
  br as Br,
  bs as Er,
  bt as $r,
  bw as Mr,
  X as js,
  r as ks,
  bu as Ur,
  by as Rr,
  bz as Lr,
  a as Fr,
  t as De,
  f as w,
  L as z,
  a0 as sa,
  e0 as Or,
  ak as Ji,
  Z as Zi,
  aL as Zt,
  D as en,
  av as Et,
  e1 as Hr,
  bh as zr,
  aN as _r,
  aR as Wr,
  T as aa,
  aP as tn,
  bc as Kr,
  aM as ia,
} from "./index-B1CTyGtY.js";
import {
  S as Z,
  a as ee,
  b as te,
  c as se,
  d as N,
} from "./select-ic5yaeGw.js";
import { D as qr } from "./DragCropSelector-uGcm88aI.js";
import { a as Qr } from "./operations-YdcesJcx.js";
import { U as Vr } from "./undo-2-CNrdKZ-W.js";
import { R as Gr } from "./redo-2-P1pU-lBd.js";
import {
  B as Yr,
  I as Xr,
  H as Jr,
  a as Zr,
  b as eo,
  L as to,
  T as so,
} from "./table-C6J8L3_u.js";
import { L as ao } from "./list-ordered-D0qzhOzB.js";
import { I as io } from "./image-plus-XffUX0hB.js";
import { C as no } from "./crop-D1wtdRSb.js";
import { T as $t } from "./trash-2-CmoDM6Qu.js";
import { i as ue, t as Ie } from "./tiptapToBlocks-8cXHU8rW.js";
import {
  d as ro,
  f as oo,
  g as lo,
  i as co,
  p as uo,
} from "./onixGenerator-CYngK7NS.js";
import {
  r as ho,
  p as mo,
  b as po,
  c as xo,
  d as go,
  a as fo,
} from "./retailerCompliance-CNCFpHWA.js";
import { k as sn } from "./index-BRvxULIc.js";
import { P as an, B as vs } from "./bookAssembly-DmpTM49o.js";
import { g as bo, b as vo, B as wo } from "./codeGeneration-D1g4LVfX.js";
import { S as nn } from "./switch-CQRPxs-N.js";
import { C as rn } from "./checkbox-Ml1pfDb3.js";
import { w as na, a as jo } from "./workflowCta-WWwB7oO9.js";
import {
  f as ra,
  an as on,
  ao as yo,
  d as bt,
  U as Be,
} from "./ToolPage-DwLoDncN.js";
import { F as No } from "./FaqSection-C8274byc.js";
import { B as ko, a as Co } from "./BookProjectBar-DV3JrprN.js";
import { t as So } from "./bookPageEstimate-TSHfl760.js";
import { P as To, c as Ao } from "./bookSpine-iDPjY9gU.js";
import { L as oa } from "./layers-Dw7RJFNV.js";
import { F as Po } from "./file-up-CSAbVrLN.js";
import { C as la } from "./chevron-up-BDUcPssj.js";
import { F as ln } from "./file-plus-2-CM-hUmGm.js";
import { E as Do } from "./eraser-DVBgSK_0.js";
import { F as es } from "./file-down-9s8MCtlL.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./utils-1EQcVBdK.js";
import "./decode-DrS85i4S.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./utils-s8ucLyj8.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./imagePdf-Dtz8PQyf.js";
import "./pdfMetadata-CcxIhQF2.js";
import "./pageView-BQIwVYOi.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./formAppearance-CdNbuISd.js";
import "./drawTextAnywhere-DcuP6lHH.js";
import "./JsBarcode-QeG8kXh7.js";
import "./browser-CMr8NRjw.js";
import "./qrHelpers-av3Dz-dA.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./localFiles-BJNBw6au.js";
const Io = Ne("AlignCenter", [
  ["path", { d: "M17 12H7", key: "16if0g" }],
  ["path", { d: "M19 18H5", key: "18s9l3" }],
  ["path", { d: "M21 6H3", key: "1jwq7v" }],
]);
const Bo = Ne("AlignJustify", [
  ["path", { d: "M3 12h18", key: "1i2n21" }],
  ["path", { d: "M3 18h18", key: "1h113x" }],
  ["path", { d: "M3 6h18", key: "d0wm0j" }],
]);
const Eo = Ne("AlignLeft", [
  ["path", { d: "M15 12H3", key: "6jk70r" }],
  ["path", { d: "M17 18H3", key: "1amg6g" }],
  ["path", { d: "M21 6H3", key: "1jwq7v" }],
]);
const $o = Ne("AlignRight", [
  ["path", { d: "M21 12H9", key: "dn1m92" }],
  ["path", { d: "M21 18H7", key: "1ygte8" }],
  ["path", { d: "M21 6H3", key: "1jwq7v" }],
]);
const Mo = Ne("Asterisk", [
  ["path", { d: "M12 6v12", key: "1vza4d" }],
  ["path", { d: "M17.196 9 6.804 15", key: "1ah31z" }],
  ["path", { d: "m6.804 9 10.392 6", key: "1b6pxd" }],
]);
const Uo = Ne("Heading4", [
  ["path", { d: "M4 12h8", key: "17cfdx" }],
  ["path", { d: "M4 18V6", key: "1rz3zl" }],
  ["path", { d: "M12 18V6", key: "zqpxq5" }],
  ["path", { d: "M17 10v4h4", key: "13sv97" }],
  ["path", { d: "M21 10v8", key: "1kdml4" }],
]);
const Ro = Ne("Library", [
  ["path", { d: "m16 6 4 14", key: "ji33uf" }],
  ["path", { d: "M12 6v14", key: "1n7gus" }],
  ["path", { d: "M8 8v12", key: "1gg7y9" }],
  ["path", { d: "M4 4v16", key: "6qkkli" }],
]);
const Lo = Ne("Subscript", [
  ["path", { d: "m4 5 8 8", key: "1eunvl" }],
  ["path", { d: "m12 5-8 8", key: "1ah0jp" }],
  [
    "path",
    {
      d: "M20 19h-4c0-1.5.44-2 1.5-2.5S20 15.33 20 14c0-.47-.17-.93-.48-1.29a2.11 2.11 0 0 0-2.62-.44c-.42.24-.74.62-.9 1.07",
      key: "e8ta8j",
    },
  ],
]);
const Fo = Ne("Superscript", [
  ["path", { d: "m4 19 8-8", key: "hr47gm" }],
  ["path", { d: "m12 19-8-8", key: "1dhhmo" }],
  [
    "path",
    {
      d: "M20 12h-4c0-1.5.442-2 1.5-2.5S20 8.334 20 7.002c0-.472-.17-.93-.484-1.29a2.105 2.105 0 0 0-2.617-.436c-.42.239-.738.614-.899 1.06",
      key: "1dfcux",
    },
  ],
]);
const Oo = Ne("Underline", [
    ["path", { d: "M6 4v6a6 6 0 0 0 12 0V4", key: "9kb039" }],
    ["line", { x1: "4", x2: "20", y1: "20", y2: "20", key: "nun2al" }],
  ]),
  Ho = (s) => P({ find: /--$/, replace: s ?? "—" }),
  zo = (s) => P({ find: /\.\.\.$/, replace: s ?? "…" }),
  ca = (s) =>
    P({ find: /(?:^|[\s{[(<'"\u2018\u201C])(")$/, replace: s ?? "“" }),
  da = (s) => P({ find: /"$/, replace: s ?? "”" }),
  ua = (s) =>
    P({ find: /(?:^|[\s{[(<'"\u2018\u201C])(')$/, replace: s ?? "‘" }),
  ha = (s) => P({ find: /'$/, replace: s ?? "’" }),
  _o = (s) => P({ find: /<-$/, replace: s ?? "←" }),
  Wo = (s) => P({ find: /->$/, replace: s ?? "→" }),
  Ko = (s) => P({ find: /\(c\)$/, replace: s ?? "©" }),
  qo = (s) => P({ find: /\(tm\)$/, replace: s ?? "™" }),
  Qo = (s) => P({ find: /\(sm\)$/, replace: s ?? "℠" }),
  Vo = (s) => P({ find: /\(r\)$/, replace: s ?? "®" }),
  Go = (s) => P({ find: /(?:^|\s)(1\/2)\s$/, replace: s ?? "½" }),
  Yo = (s) => P({ find: /\+\/-$/, replace: s ?? "±" }),
  Xo = (s) => P({ find: /!=$/, replace: s ?? "≠" }),
  Jo = (s) => P({ find: /<<$/, replace: s ?? "«" }),
  Zo = (s) => P({ find: />>$/, replace: s ?? "»" }),
  el = (s) => P({ find: /\d+\s?([*x])\s?\d+$/, replace: s ?? "×" }),
  tl = (s) => P({ find: /\^2$/, replace: s ?? "²" }),
  sl = (s) => P({ find: /\^3$/, replace: s ?? "³" }),
  al = (s) => P({ find: /(?:^|\s)(1\/4)\s$/, replace: s ?? "¼" }),
  il = (s) => P({ find: /(?:^|\s)(3\/4)\s$/, replace: s ?? "¾" }),
  nl = wa.create({
    name: "typography",
    addOptions() {
      return {
        closeDoubleQuote: "”",
        closeSingleQuote: "’",
        copyright: "©",
        ellipsis: "…",
        emDash: "—",
        laquo: "«",
        leftArrow: "←",
        multiplication: "×",
        notEqual: "≠",
        oneHalf: "½",
        oneQuarter: "¼",
        openDoubleQuote: "“",
        openSingleQuote: "‘",
        plusMinus: "±",
        raquo: "»",
        registeredTrademark: "®",
        rightArrow: "→",
        servicemark: "℠",
        superscriptThree: "³",
        superscriptTwo: "²",
        threeQuarters: "¾",
        trademark: "™",
      };
    },
    addInputRules() {
      var s, n;
      const a = [];
      (this.options.emDash !== !1 && a.push(Ho(this.options.emDash)),
        this.options.ellipsis !== !1 && a.push(zo(this.options.ellipsis)));
      const o = this.editor.options.textDirection === "rtl";
      if (
        !((s = this.options.doubleQuotes) === null || s === void 0) &&
        s.rtl
      ) {
        const { open: d, close: p } = this.options.doubleQuotes.rtl;
        (a.push(ca(d)), a.push(da(p)));
      } else
        o
          ? (a.push(ca("”")), a.push(da("“")))
          : (this.options.openDoubleQuote !== !1 &&
              a.push(ca(this.options.openDoubleQuote)),
            this.options.closeDoubleQuote !== !1 &&
              a.push(da(this.options.closeDoubleQuote)));
      if (
        !((n = this.options.singleQuotes) === null || n === void 0) &&
        n.rtl
      ) {
        const { open: d, close: p } = this.options.singleQuotes.rtl;
        (a.push(ua(d)), a.push(ha(p)));
      } else
        o
          ? (a.push(ua("’")), a.push(ha("‘")))
          : (this.options.openSingleQuote !== !1 &&
              a.push(ua(this.options.openSingleQuote)),
            this.options.closeSingleQuote !== !1 &&
              a.push(ha(this.options.closeSingleQuote)));
      return (
        this.options.leftArrow !== !1 && a.push(_o(this.options.leftArrow)),
        this.options.rightArrow !== !1 && a.push(Wo(this.options.rightArrow)),
        this.options.copyright !== !1 && a.push(Ko(this.options.copyright)),
        this.options.trademark !== !1 && a.push(qo(this.options.trademark)),
        this.options.servicemark !== !1 && a.push(Qo(this.options.servicemark)),
        this.options.registeredTrademark !== !1 &&
          a.push(Vo(this.options.registeredTrademark)),
        this.options.oneHalf !== !1 && a.push(Go(this.options.oneHalf)),
        this.options.plusMinus !== !1 && a.push(Yo(this.options.plusMinus)),
        this.options.notEqual !== !1 && a.push(Xo(this.options.notEqual)),
        this.options.laquo !== !1 && a.push(Jo(this.options.laquo)),
        this.options.raquo !== !1 && a.push(Zo(this.options.raquo)),
        this.options.multiplication !== !1 &&
          a.push(el(this.options.multiplication)),
        this.options.superscriptTwo !== !1 &&
          a.push(tl(this.options.superscriptTwo)),
        this.options.superscriptThree !== !1 &&
          a.push(sl(this.options.superscriptThree)),
        this.options.oneQuarter !== !1 && a.push(al(this.options.oneQuarter)),
        this.options.threeQuarters !== !1 &&
          a.push(il(this.options.threeQuarters)),
        a
      );
    },
  });
var rl = nl;
const ol = wa.create({
  name: "textAlign",
  addOptions() {
    return {
      types: [],
      alignments: ["left", "center", "right", "justify"],
      defaultAlignment: null,
    };
  },
  addGlobalAttributes() {
    return [
      {
        types: this.options.types,
        attributes: {
          textAlign: {
            default: this.options.defaultAlignment,
            parseHTML: (s) => {
              const n = s.style.textAlign;
              return this.options.alignments.includes(n)
                ? n
                : this.options.defaultAlignment;
            },
            renderHTML: (s) =>
              s.textAlign ? { style: `text-align: ${s.textAlign}` } : {},
          },
        },
      },
    ];
  },
  addCommands() {
    return {
      setTextAlign:
        (s) =>
        ({ commands: n }) =>
          this.options.alignments.includes(s)
            ? this.options.types
                .map((a) => n.updateAttributes(a, { textAlign: s }))
                .some((a) => a)
            : !1,
      unsetTextAlign:
        () =>
        ({ commands: s }) =>
          this.options.types
            .map((n) => s.resetAttributes(n, "textAlign"))
            .some((n) => n),
      toggleTextAlign:
        (s) =>
        ({ editor: n, commands: a }) =>
          this.options.alignments.includes(s)
            ? n.isActive({ textAlign: s })
              ? a.unsetTextAlign()
              : a.setTextAlign(s)
            : !1,
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-Shift-l": () => this.editor.commands.setTextAlign("left"),
      "Mod-Shift-e": () => this.editor.commands.setTextAlign("center"),
      "Mod-Shift-r": () => this.editor.commands.setTextAlign("right"),
      "Mod-Shift-j": () => this.editor.commands.setTextAlign("justify"),
    };
  },
});
var ll = ol;
const cl = Cn.create({
  name: "superscript",
  addOptions() {
    return { HTMLAttributes: {} };
  },
  parseHTML() {
    return [
      { tag: "sup" },
      {
        style: "vertical-align",
        getAttrs(s) {
          return s !== "super" ? !1 : null;
        },
      },
    ];
  },
  renderHTML({ HTMLAttributes: s }) {
    return ["sup", Sn(this.options.HTMLAttributes, s), 0];
  },
  addCommands() {
    return {
      setSuperscript:
        () =>
        ({ commands: s }) =>
          s.setMark(this.name),
      toggleSuperscript:
        () =>
        ({ commands: s }) =>
          s.toggleMark(this.name),
      unsetSuperscript:
        () =>
        ({ commands: s }) =>
          s.unsetMark(this.name),
    };
  },
  addKeyboardShortcuts() {
    return { "Mod-.": () => this.editor.commands.toggleSuperscript() };
  },
});
var dl = cl;
const ul = Cn.create({
  name: "subscript",
  addOptions() {
    return { HTMLAttributes: {} };
  },
  parseHTML() {
    return [
      { tag: "sub" },
      {
        style: "vertical-align",
        getAttrs(s) {
          return s !== "sub" ? !1 : null;
        },
      },
    ];
  },
  renderHTML({ HTMLAttributes: s }) {
    return ["sub", Sn(this.options.HTMLAttributes, s), 0];
  },
  addCommands() {
    return {
      setSubscript:
        () =>
        ({ commands: s }) =>
          s.setMark(this.name),
      toggleSubscript:
        () =>
        ({ commands: s }) =>
          s.toggleMark(this.name),
      unsetSubscript:
        () =>
        ({ commands: s }) =>
          s.unsetMark(this.name),
    };
  },
  addKeyboardShortcuts() {
    return { "Mod-,": () => this.editor.commands.toggleSubscript() };
  },
});
var hl = ul;
const ml = wa.create({
    name: "lineHeight",
    addOptions() {
      return { types: ["paragraph", "heading"] };
    },
    addGlobalAttributes() {
      return [
        {
          types: this.options.types,
          attributes: {
            lineHeight: {
              default: null,
              parseHTML: (s) => s.style.lineHeight || null,
              renderHTML: (s) =>
                s.lineHeight ? { style: `line-height: ${s.lineHeight}` } : {},
            },
          },
        },
      ];
    },
    addCommands() {
      return {
        setLineHeight:
          (s) =>
          ({ commands: n }) =>
            this.options.types.every((a) =>
              n.updateAttributes(a, { lineHeight: s }),
            ),
        unsetLineHeight:
          () =>
          ({ commands: s }) =>
            this.options.types.every((n) => s.resetAttributes(n, "lineHeight")),
      };
    },
  }),
  pl = gr.create({
    name: "sceneBreak",
    group: "block",
    atom: !0,
    selectable: !0,
    parseHTML() {
      return [{ tag: "div[data-scene-break]" }];
    },
    renderHTML() {
      return [
        "div",
        {
          "data-scene-break": "true",
          class:
            "scene-break-node text-center text-muted-foreground select-none py-2 tracking-[0.5em]",
        },
        "⁂",
      ];
    },
    addCommands() {
      return {
        insertSceneBreak:
          () =>
          ({ commands: s }) =>
            s.insertContent([{ type: this.name }, { type: "paragraph" }]),
      };
    },
  }),
  xl = Cr.extend({
    addAttributes() {
      return {
        ...this.parent?.(),
        widthFrac: {
          default: 0.85,
          parseHTML: (s) => {
            const n = s.getAttribute("data-width-frac");
            return n ? Number(n) : 0.85;
          },
          renderHTML: (s) => ({ "data-width-frac": s.widthFrac }),
        },
      };
    },
    addNodeView() {
      return ({ node: s, editor: n, getPos: a }) => {
        const o = document.createElement("span");
        o.style.cssText =
          "position:relative;display:block;width:fit-content;max-width:100%";
        const d = document.createElement("img");
        d.style.cssText = "max-width:100%;height:auto;display:block";
        const p = (f) => {
          ((d.src = f.attrs.src ?? ""),
            (d.alt = f.attrs.alt ?? ""),
            f.attrs.title
              ? (d.title = f.attrs.title)
              : d.removeAttribute("title"),
            d.setAttribute(
              "data-width-frac",
              String(f.attrs.widthFrac ?? 0.85),
            ));
        };
        p(s);
        const v = document.createElement("button");
        return (
          (v.type = "button"),
          v.setAttribute("aria-label", "Remove image"),
          (v.title = "Remove image"),
          (v.textContent = "×"),
          (v.style.cssText =
            "position:absolute;top:-8px;right:-8px;width:22px;height:22px;border-radius:9999px;border:1px solid #888;background:#fff;color:#111;font-size:16px;line-height:1;cursor:pointer;box-shadow:0 1px 3px rgba(0,0,0,.3)"),
          v.addEventListener("mousedown", (f) => f.preventDefault()),
          v.addEventListener("click", (f) => {
            f.preventDefault();
            const T = typeof a == "function" ? a() : void 0;
            typeof T == "number" &&
              n
                .chain()
                .focus()
                .deleteRange({ from: T, to: T + s.nodeSize })
                .run();
          }),
          o.append(d, v),
          {
            dom: o,
            update: (f) => (f.type !== s.type ? !1 : (p(f), !0)),
            selectNode: () => {
              d.style.outline = "2px solid #3b82f6";
            },
            deselectNode: () => {
              d.style.outline = "";
            },
          }
        );
      };
    },
  }),
  gl = [
    { name: "Black", value: "#000000" },
    { name: "Dark gray", value: "#555555" },
    { name: "Red", value: "#c0392b" },
    { name: "Orange", value: "#d35400" },
    { name: "Gold", value: "#b7950b" },
    { name: "Green", value: "#1e8449" },
    { name: "Teal", value: "#117864" },
    { name: "Blue", value: "#2471a3" },
    { name: "Navy", value: "#1a3d63" },
    { name: "Purple", value: "#6c3483" },
  ];
function ma(s) {
  return new Promise((n, a) => {
    const o = new FileReader();
    ((o.onload = () => n(o.result)),
      (o.onerror = () => a(o.error)),
      o.readAsDataURL(s));
  });
}
async function fl(s, n) {
  const o = await (await fetch(s)).blob();
  return new File([o], n, { type: o.type });
}
function cn({ initialContent: s, onChange: n, placeholder: a }) {
  const o = l.useRef(null),
    [d, p] = l.useState(null),
    [v, f] = l.useState(null),
    [T, Ee] = l.useState(null),
    [M, ke] = l.useState(null),
    h = pr({
      extensions: [
        Nr.configure({ heading: { levels: [1, 2, 3, 4] } }),
        rl.configure({
          copyright: !1,
          trademark: !1,
          registeredTrademark: !1,
          servicemark: !1,
          oneHalf: !1,
          oneQuarter: !1,
          threeQuarters: !1,
          plusMinus: !1,
          notEqual: !1,
          laquo: !1,
          raquo: !1,
          multiplication: !1,
          superscriptTwo: !1,
          superscriptThree: !1,
          rightArrow: !1,
          leftArrow: !1,
        }),
        fr,
        br,
        vr,
        ll.configure({ types: ["paragraph", "heading"] }),
        dl,
        hl,
        ml,
        pl,
        kr.configure({ resizable: !1 }),
        wr,
        jr,
        yr,
        xl.configure({ inline: !1 }),
      ],
      content: s,
      onUpdate: ({ editor: g }) => n?.(g.getJSON()),
      editorProps: {
        attributes: {
          class:
            "prose prose-sm max-w-none min-h-[200px] focus:outline-none px-3 py-2 [&_h1]:text-2xl [&_h1]:font-bold [&_h1]:mt-4 [&_h1]:mb-2 [&_h2]:text-xl [&_h2]:font-bold [&_h2]:mt-4 [&_h2]:mb-2 [&_h3]:text-lg [&_h3]:font-bold [&_h3]:italic [&_h3]:mt-3 [&_h3]:mb-1.5 [&_h4]:text-base [&_h4]:font-semibold [&_h4]:italic [&_h4]:mt-3 [&_h4]:mb-1.5 [&_table]:border-collapse [&_table]:w-full [&_table]:my-2 [&_th]:border [&_th]:border-border [&_th]:p-1.5 [&_th]:bg-muted [&_th]:font-semibold [&_th]:text-left [&_td]:border [&_td]:border-border [&_td]:p-1.5",
        },
        handlePaste: (g, C) => {
          const Se = C.clipboardData?.items;
          if (!Se) return !1;
          const Me = Array.from(Se).find((ie) => ie.type.startsWith("image/"));
          if (!Me) return !1;
          const Mt = Me.getAsFile();
          return Mt
            ? (C.preventDefault(),
              ma(Mt).then((ie) => {
                h?.chain().focus().setImage({ src: ie }).run();
              }),
              !0)
            : !1;
        },
      },
    });
  if ((l.useEffect(() => () => h?.destroy(), []), !h)) return null;
  async function ss() {
    o.current?.click();
  }
  async function We(g) {
    const C = g.target.files?.[0];
    if (((g.target.value = ""), !C || !h)) return;
    const Se = await ma(C);
    h.chain().focus().setImage({ src: Se }).run();
  }
  function Ts() {
    if (!h) return;
    const { selection: g } = h.state;
    if (!(g instanceof ta) || g.node.type.name !== "image") return;
    const C = g.node.attrs.src;
    fl(C, "image.png").then((Se) => {
      (p({ pos: g.from, dataUrl: C, originalFile: Se }), f(null));
    });
  }
  async function O() {
    if (!d || !v || !h) return;
    const { blob: g } = await Qr(d.originalFile, v),
      C = await ma(new File([g], "cropped.png", { type: g.type }));
    (h
      .chain()
      .setNodeSelection(d.pos)
      .updateAttributes("image", { src: C })
      .run(),
      p(null),
      f(null));
  }
  function as() {
    h && h.chain().focus().deleteSelection().run();
  }
  function Ce() {
    if (!h) return;
    const { selection: g } = h.state;
    if (!(g instanceof ta) || g.node.type.name !== "image") return;
    const C = g.node.attrs.title;
    Ee({ pos: g.from, value: C ?? "" });
  }
  function is() {
    !T ||
      !h ||
      (h
        .chain()
        .setNodeSelection(T.pos)
        .updateAttributes("image", { title: T.value })
        .run(),
      Ee(null));
  }
  function $e() {
    if (!h) return;
    const { selection: g } = h.state;
    if (!(g instanceof ta) || g.node.type.name !== "image") return;
    const C = g.node.attrs.alt;
    ke({ pos: g.from, value: C ?? "" });
  }
  function Ke() {
    !M ||
      !h ||
      (h
        .chain()
        .setNodeSelection(M.pos)
        .updateAttributes("image", { alt: M.value })
        .run(),
      ke(null));
  }
  const qe = h.isActive("image");
  return e.jsxs("div", {
    className: "border rounded-lg overflow-hidden",
    children: [
      e.jsxs("div", {
        className:
          "flex flex-wrap items-center gap-1 border-b bg-muted/40 p-1.5",
        children: [
          e.jsx(u, {
            type: "button",
            size: "icon",
            variant: "ghost",
            className: "h-8 w-8",
            disabled: !h.can().undo(),
            onClick: () => h.chain().focus().undo().run(),
            title: "Undo",
            children: e.jsx(Vr, { className: "h-4 w-4" }),
          }),
          e.jsx(u, {
            type: "button",
            size: "icon",
            variant: "ghost",
            className: "h-8 w-8",
            disabled: !h.can().redo(),
            onClick: () => h.chain().focus().redo().run(),
            title: "Redo",
            children: e.jsx(Gr, { className: "h-4 w-4" }),
          }),
          e.jsx("div", { className: "w-px h-5 bg-border mx-1" }),
          e.jsx(u, {
            type: "button",
            size: "icon",
            variant: h.isActive("bold") ? "secondary" : "ghost",
            className: "h-8 w-8",
            onClick: () => h.chain().focus().toggleBold().run(),
            children: e.jsx(Yr, { className: "h-4 w-4" }),
          }),
          e.jsx(u, {
            type: "button",
            size: "icon",
            variant: h.isActive("italic") ? "secondary" : "ghost",
            className: "h-8 w-8",
            onClick: () => h.chain().focus().toggleItalic().run(),
            children: e.jsx(Xr, { className: "h-4 w-4" }),
          }),
          e.jsx(u, {
            type: "button",
            size: "icon",
            variant: h.isActive("underline") ? "secondary" : "ghost",
            className: "h-8 w-8",
            onClick: () => h.chain().focus().toggleUnderline().run(),
            children: e.jsx(Oo, { className: "h-4 w-4" }),
          }),
          e.jsxs(Ar, {
            children: [
              e.jsx(Pr, {
                asChild: !0,
                children: e.jsx(u, {
                  type: "button",
                  size: "icon",
                  variant: "ghost",
                  className: "h-8 w-8",
                  title: "Text color",
                  children: e.jsx(Dr, {
                    className: "h-4 w-4",
                    style: {
                      color: h.getAttributes("textStyle").color || void 0,
                    },
                  }),
                }),
              }),
              e.jsxs(Ir, {
                className: "w-auto p-2",
                children: [
                  e.jsx("div", {
                    className: "grid grid-cols-5 gap-1.5 mb-2",
                    children: gl.map((g) =>
                      e.jsx(
                        "button",
                        {
                          type: "button",
                          title: g.name,
                          className: "h-6 w-6 rounded-full border shadow-sm",
                          style: { backgroundColor: g.value },
                          onClick: () =>
                            h.chain().focus().setColor(g.value).run(),
                        },
                        g.value,
                      ),
                    ),
                  }),
                  e.jsxs("div", {
                    className: "flex items-center gap-2 border-t pt-2",
                    children: [
                      e.jsx("label", {
                        className:
                          "relative h-7 w-7 shrink-0 rounded-md border overflow-hidden cursor-pointer",
                        children: e.jsx("input", {
                          type: "color",
                          className: "absolute -inset-1 cursor-pointer",
                          value:
                            h.getAttributes("textStyle").color || "#000000",
                          onChange: (g) =>
                            h.chain().focus().setColor(g.target.value).run(),
                        }),
                      }),
                      e.jsx("span", {
                        className: "text-xs text-muted-foreground",
                        children: "Custom",
                      }),
                      h.getAttributes("textStyle").color &&
                        e.jsx(u, {
                          type: "button",
                          size: "sm",
                          variant: "ghost",
                          className: "h-7 text-xs px-2 ml-auto",
                          onClick: () => h.chain().focus().unsetColor().run(),
                          children: "Reset",
                        }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          e.jsx(u, {
            type: "button",
            size: "icon",
            variant: h.isActive("superscript") ? "secondary" : "ghost",
            className: "h-8 w-8",
            title: "Superscript",
            onClick: () => h.chain().focus().toggleSuperscript().run(),
            children: e.jsx(Fo, { className: "h-4 w-4" }),
          }),
          e.jsx(u, {
            type: "button",
            size: "icon",
            variant: h.isActive("subscript") ? "secondary" : "ghost",
            className: "h-8 w-8",
            title: "Subscript",
            onClick: () => h.chain().focus().toggleSubscript().run(),
            children: e.jsx(Lo, { className: "h-4 w-4" }),
          }),
          e.jsx("div", { className: "w-px h-5 bg-border mx-1" }),
          e.jsx(u, {
            type: "button",
            size: "icon",
            variant: h.isActive({ textAlign: "left" }) ? "secondary" : "ghost",
            className: "h-8 w-8",
            title: "Align left",
            onClick: () => h.chain().focus().setTextAlign("left").run(),
            children: e.jsx(Eo, { className: "h-4 w-4" }),
          }),
          e.jsx(u, {
            type: "button",
            size: "icon",
            variant: h.isActive({ textAlign: "center" })
              ? "secondary"
              : "ghost",
            className: "h-8 w-8",
            title: "Align center",
            onClick: () => h.chain().focus().setTextAlign("center").run(),
            children: e.jsx(Io, { className: "h-4 w-4" }),
          }),
          e.jsx(u, {
            type: "button",
            size: "icon",
            variant: h.isActive({ textAlign: "right" }) ? "secondary" : "ghost",
            className: "h-8 w-8",
            title: "Align right",
            onClick: () => h.chain().focus().setTextAlign("right").run(),
            children: e.jsx($o, { className: "h-4 w-4" }),
          }),
          e.jsx(u, {
            type: "button",
            size: "icon",
            variant: h.isActive({ textAlign: "justify" })
              ? "secondary"
              : "ghost",
            className: "h-8 w-8",
            title: "Justify",
            onClick: () => h.chain().focus().setTextAlign("justify").run(),
            children: e.jsx(Bo, { className: "h-4 w-4" }),
          }),
          e.jsx("div", { className: "w-px h-5 bg-border mx-1" }),
          e.jsxs(Z, {
            value:
              h.getAttributes("paragraph").lineHeight ||
              h.getAttributes("heading").lineHeight ||
              "default",
            onValueChange: (g) => {
              g === "default"
                ? h.chain().focus().unsetLineHeight().run()
                : h.chain().focus().setLineHeight(g).run();
            },
            children: [
              e.jsx(ee, {
                className: "h-8 w-[92px] text-xs",
                title: "Line spacing",
                children: e.jsx(te, {}),
              }),
              e.jsxs(se, {
                children: [
                  e.jsx(N, { value: "default", children: "Spacing" }),
                  e.jsx(N, { value: "1", children: "1.0" }),
                  e.jsx(N, { value: "1.15", children: "1.15" }),
                  e.jsx(N, { value: "1.5", children: "1.5" }),
                  e.jsx(N, { value: "2", children: "2.0" }),
                ],
              }),
            ],
          }),
          e.jsx("div", { className: "w-px h-5 bg-border mx-1" }),
          e.jsx(u, {
            type: "button",
            size: "icon",
            variant: h.isActive("heading", { level: 1 })
              ? "secondary"
              : "ghost",
            className: "h-8 w-8",
            onClick: () => h.chain().focus().toggleHeading({ level: 1 }).run(),
            children: e.jsx(Jr, { className: "h-4 w-4" }),
          }),
          e.jsx(u, {
            type: "button",
            size: "icon",
            variant: h.isActive("heading", { level: 2 })
              ? "secondary"
              : "ghost",
            className: "h-8 w-8",
            onClick: () => h.chain().focus().toggleHeading({ level: 2 }).run(),
            children: e.jsx(Zr, { className: "h-4 w-4" }),
          }),
          e.jsx(u, {
            type: "button",
            size: "icon",
            variant: h.isActive("heading", { level: 3 })
              ? "secondary"
              : "ghost",
            className: "h-8 w-8",
            onClick: () => h.chain().focus().toggleHeading({ level: 3 }).run(),
            children: e.jsx(eo, { className: "h-4 w-4" }),
          }),
          e.jsx(u, {
            type: "button",
            size: "icon",
            variant: h.isActive("heading", { level: 4 })
              ? "secondary"
              : "ghost",
            className: "h-8 w-8",
            onClick: () => h.chain().focus().toggleHeading({ level: 4 }).run(),
            children: e.jsx(Uo, { className: "h-4 w-4" }),
          }),
          e.jsx("div", { className: "w-px h-5 bg-border mx-1" }),
          e.jsx(u, {
            type: "button",
            size: "icon",
            variant: h.isActive("bulletList") ? "secondary" : "ghost",
            className: "h-8 w-8",
            onClick: () => h.chain().focus().toggleBulletList().run(),
            children: e.jsx(to, { className: "h-4 w-4" }),
          }),
          e.jsx(u, {
            type: "button",
            size: "icon",
            variant: h.isActive("orderedList") ? "secondary" : "ghost",
            className: "h-8 w-8",
            onClick: () => h.chain().focus().toggleOrderedList().run(),
            children: e.jsx(ao, { className: "h-4 w-4" }),
          }),
          e.jsx("div", { className: "w-px h-5 bg-border mx-1" }),
          e.jsxs(u, {
            type: "button",
            size: "sm",
            variant: "ghost",
            className: "h-8 gap-1.5",
            onClick: ss,
            children: [e.jsx(io, { className: "h-4 w-4" }), " Image"],
          }),
          e.jsxs(u, {
            type: "button",
            size: "sm",
            variant: "ghost",
            className: "h-8 gap-1.5",
            onClick: () =>
              h
                .chain()
                .focus()
                .insertTable({ rows: 3, cols: 3, withHeaderRow: !0 })
                .run(),
            children: [e.jsx(so, { className: "h-4 w-4" }), " Table"],
          }),
          e.jsxs(u, {
            type: "button",
            size: "sm",
            variant: "ghost",
            className: "h-8 gap-1.5",
            title:
              "Marks a scene shift within this chapter — a time, place, or POV change, not a new chapter",
            onClick: () => h.chain().focus().insertSceneBreak().run(),
            children: [e.jsx(Mo, { className: "h-4 w-4" }), " Scene Break"],
          }),
          h.isActive("table") &&
            e.jsxs(e.Fragment, {
              children: [
                e.jsx(u, {
                  type: "button",
                  size: "sm",
                  variant: "ghost",
                  className: "h-8 text-xs px-2",
                  onClick: () => h.chain().focus().addRowAfter().run(),
                  children: "+Row",
                }),
                e.jsx(u, {
                  type: "button",
                  size: "sm",
                  variant: "ghost",
                  className: "h-8 text-xs px-2",
                  onClick: () => h.chain().focus().addColumnAfter().run(),
                  children: "+Col",
                }),
                e.jsx(u, {
                  type: "button",
                  size: "sm",
                  variant: "ghost",
                  className: "h-8 text-xs px-2 text-destructive",
                  onClick: () => h.chain().focus().deleteTable().run(),
                  children: "Delete table",
                }),
              ],
            }),
          qe &&
            e.jsxs(e.Fragment, {
              children: [
                e.jsx("div", { className: "w-px h-5 bg-border mx-1" }),
                e.jsxs(u, {
                  type: "button",
                  size: "sm",
                  variant: "ghost",
                  className: "h-8 gap-1.5",
                  onClick: Ts,
                  children: [e.jsx(no, { className: "h-4 w-4" }), " Crop"],
                }),
                e.jsx(u, {
                  type: "button",
                  size: "sm",
                  variant: "ghost",
                  className: "h-8",
                  onClick: Ce,
                  children: "Caption",
                }),
                e.jsx(u, {
                  type: "button",
                  size: "sm",
                  variant: "ghost",
                  className: "h-8",
                  onClick: $e,
                  children: "Alt text",
                }),
                e.jsx(u, {
                  type: "button",
                  size: "icon",
                  variant: "ghost",
                  className: "h-8 w-8 text-destructive",
                  onClick: as,
                  children: e.jsx($t, { className: "h-4 w-4" }),
                }),
              ],
            }),
          e.jsx("input", {
            ref: o,
            type: "file",
            accept: "image/*",
            className: "hidden",
            onChange: We,
          }),
        ],
      }),
      e.jsx(xr, { editor: h, placeholder: a }),
      e.jsx(be, {
        open: !!d,
        onOpenChange: (g) => !g && p(null),
        children: e.jsxs(ve, {
          className: "max-w-lg",
          children: [
            e.jsx(we, { children: e.jsx(je, { children: "Crop image" }) }),
            d && e.jsx(qr, { imageUrl: d.dataUrl, onSelectionChange: f }),
            e.jsxs(vt, {
              children: [
                e.jsx(u, {
                  variant: "outline",
                  onClick: () => p(null),
                  children: "Cancel",
                }),
                e.jsx(u, { onClick: O, disabled: !v, children: "Apply Crop" }),
              ],
            }),
          ],
        }),
      }),
      e.jsx(be, {
        open: !!T,
        onOpenChange: (g) => !g && Ee(null),
        children: e.jsxs(ve, {
          className: "max-w-md",
          children: [
            e.jsx(we, { children: e.jsx(je, { children: "Image caption" }) }),
            e.jsxs("div", {
              children: [
                e.jsx(j, {
                  className: "mb-1 block",
                  children: "Caption (optional)",
                }),
                e.jsx(k, {
                  "aria-label": "Caption (optional)",
                  value: T?.value ?? "",
                  onChange: (g) =>
                    Ee((C) => C && { ...C, value: g.target.value }),
                  placeholder: "e.g. The house, photographed in summer",
                }),
              ],
            }),
            e.jsxs(vt, {
              children: [
                e.jsx(u, {
                  variant: "outline",
                  onClick: () => Ee(null),
                  children: "Cancel",
                }),
                e.jsx(u, { onClick: is, children: "Save" }),
              ],
            }),
          ],
        }),
      }),
      e.jsx(be, {
        open: !!M,
        onOpenChange: (g) => !g && ke(null),
        children: e.jsxs(ve, {
          className: "max-w-md",
          children: [
            e.jsx(we, { children: e.jsx(je, { children: "Image alt text" }) }),
            e.jsxs("div", {
              children: [
                e.jsx(j, {
                  className: "mb-1 block",
                  children:
                    "Describes this image for screen readers (recommended for EPUB accessibility)",
                }),
                e.jsx(k, {
                  "aria-label":
                    "Describes this image for screen readers (recommended for EPUB accessibility)",
                  value: M?.value ?? "",
                  onChange: (g) =>
                    ke((C) => C && { ...C, value: g.target.value }),
                  placeholder:
                    "e.g. A two-story colonial house with a wraparound porch",
                }),
              ],
            }),
            e.jsxs(vt, {
              children: [
                e.jsx(u, {
                  variant: "outline",
                  onClick: () => ke(null),
                  children: "Cancel",
                }),
                e.jsx(u, { onClick: Ke, children: "Save" }),
              ],
            }),
          ],
        }),
      }),
    ],
  });
}
const Tn = "book-maker-drafts",
  bl = Tn,
  Y = "drafts",
  ae = "projectsMeta",
  ye = "appState",
  vl = 2,
  dn = "current",
  ys = "activeProjectId";
function jt() {
  return new Promise((s, n) => {
    const a = indexedDB.open(bl, vl);
    ((a.onupgradeneeded = () => {
      const o = a.result;
      (o.objectStoreNames.contains(Y) || o.createObjectStore(Y),
        o.objectStoreNames.contains(ae) || o.createObjectStore(ae),
        o.objectStoreNames.contains(ye) || o.createObjectStore(ye));
    }),
      (a.onsuccess = () => s(a.result)),
      (a.onerror = () => n(a.error)));
  });
}
function wt(s) {
  return new Promise((n, a) => {
    ((s.onsuccess = () => n(s.result)), (s.onerror = () => a(s.error)));
  });
}
async function wl(s) {
  if (await wt(s.transaction(ye, "readonly").objectStore(ye).get(ys))) return;
  const a = await wt(s.transaction(Y, "readonly").objectStore(Y).get(dn));
  if (a == null) return;
  const o = `proj_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
    d = a.bookTitle?.trim() || "Untitled Book";
  await new Promise((p, v) => {
    const f = s.transaction([Y, ae, ye], "readwrite");
    (f.objectStore(Y).put(a, o),
      f.objectStore(Y).delete(dn),
      f.objectStore(ae).put({ id: o, title: d, updatedAt: Date.now() }, o),
      f.objectStore(ye).put(o, ys),
      (f.oncomplete = () => p()),
      (f.onerror = () => v(f.error)));
  });
}
async function pa(s, n) {
  try {
    const a = await jt(),
      o = n.bookTitle?.trim() || "Untitled Book";
    (await new Promise((d, p) => {
      const v = a.transaction([Y, ae], "readwrite");
      (v.objectStore(Y).put(n, s),
        v.objectStore(ae).put({ id: s, title: o, updatedAt: Date.now() }, s),
        (v.oncomplete = () => d()),
        (v.onerror = () => p(v.error)));
    }),
      a.close());
  } catch {}
}
async function un(s) {
  try {
    const n = await jt(),
      a = await wt(n.transaction(Y, "readonly").objectStore(Y).get(s));
    return (n.close(), a ?? null);
  } catch {
    return null;
  }
}
async function hn() {
  try {
    const s = await jt(),
      n = await wt(s.transaction(ae, "readonly").objectStore(ae).getAll());
    return (s.close(), n.sort((a, o) => o.updatedAt - a.updatedAt));
  } catch {
    return [];
  }
}
async function ws() {
  const s = `proj_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
  try {
    const n = await jt();
    (await wt(
      n
        .transaction(ae, "readwrite")
        .objectStore(ae)
        .put({ id: s, title: "Untitled Book", updatedAt: Date.now() }, s),
    ),
      n.close());
  } catch {}
  return s;
}
async function mn(s) {
  try {
    const n = await jt();
    (await new Promise((a, o) => {
      const d = n.transaction([Y, ae], "readwrite");
      (d.objectStore(Y).delete(s),
        d.objectStore(ae).delete(s),
        (d.oncomplete = () => a()),
        (d.onerror = () => o(d.error)));
    }),
      n.close());
  } catch {}
}
async function jl() {
  try {
    const s = await jt();
    await wl(s);
    const n = await wt(s.transaction(ye, "readonly").objectStore(ye).get(ys));
    return (s.close(), n ?? null);
  } catch {
    return null;
  }
}
async function ts(s) {
  try {
    const n = await jt();
    (await wt(n.transaction(ye, "readwrite").objectStore(ye).put(s, ys)),
      n.close());
  } catch {}
}
const Cs = "fdp:book-writing-toolbox:session-draft:v1",
  An = 1;
function ja() {
  try {
    return typeof sessionStorage > "u" ? null : sessionStorage;
  } catch {
    return null;
  }
}
function yl(s, n, a = ja(), o = Date.now()) {
  if (!a) return !1;
  try {
    const d = { v: An, projectId: s, savedAt: o, snapshot: n };
    return (a.setItem(Cs, JSON.stringify(d)), !0);
  } catch {
    return !1;
  }
}
function Nl(s, n = ja()) {
  if (!n) return null;
  try {
    const a = n.getItem(Cs);
    if (!a) return null;
    const o = JSON.parse(a);
    return !o ||
      o.v !== An ||
      typeof o.snapshot != "object" ||
      o.snapshot === null
      ? null
      : (s !== void 0 && o.projectId, o);
  } catch {
    return null;
  }
}
function kl(s = ja()) {
  if (s)
    try {
      s.removeItem(Cs);
    } catch {}
}
const Cl = ["fdp:book-writing-toolbox", "book-maker"];
function pn(s) {
  if (s)
    try {
      const n = [];
      for (let a = 0; a < s.length; a++) {
        const o = s.key(a);
        o && (o === Cs || Cl.some((d) => o.startsWith(d))) && n.push(o);
      }
      for (const a of n) s.removeItem(a);
    } catch {}
}
function Sl(s) {
  return s
    ? new Promise((n) => {
        try {
          const a = s.deleteDatabase(Tn);
          ((a.onsuccess = () => n(!0)),
            (a.onerror = () => n(!1)),
            (a.onblocked = () => n(!1)));
        } catch {
          n(!1);
        }
      })
    : Promise.resolve(!0);
}
async function Tl(s) {
  const n = typeof indexedDB > "u" ? null : indexedDB,
    a = (o, d) => {
      try {
        return typeof window > "u" ? null : window[d];
      } catch {
        return null;
      }
    };
  return (
    pn(a(s?.local, "localStorage")),
    pn(a(s?.session, "sessionStorage")),
    Sl(n)
  );
}
function xn(s, n) {
  return s.filter((a) => a.enabled || a.id === n);
}
function Al(s) {
  return s.filter((n) => !n.enabled);
}
function B(s) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "");
}
function Pl(s, n) {
  const a = (s ?? "").trim(),
    o = a ? lo(a) : null,
    d = o?.ok ? o.isbn : a ? co(a) : null;
  return d && /^\d{13}$/.test(d)
    ? `    <ProductIdentifier>
      <ProductIDType>15</ProductIDType>
      <IDValue>${B(d)}</IDValue>
    </ProductIdentifier>
`
    : `    <ProductIdentifier>
      <ProductIDType>01</ProductIDType>
      <IDTypeName>Book Writing Toolbox record reference</IDTypeName>
      <IDValue>${B(n)}</IDValue>
    </ProductIdentifier>
`;
}
function Dl(s) {
  const n = s?.trim();
  if (!n) return "";
  const a = uo(
    /^\d{8}$/.test(n)
      ? `${n.slice(0, 4)}-${n.slice(4, 6)}-${n.slice(6, 8)}`
      : n,
  );
  return a.ok
    ? `      <PublishingDate>
        <PublishingDateRole>01</PublishingDateRole>
        <Date dateformat="${a.format}">${a.onix}</Date>
      </PublishingDate>
`
    : "";
}
function Il(s) {
  const n = `book-writing-toolbox-${(s.isbn || s.bookTitle).replace(/[^a-zA-Z0-9]+/g, "-").toLowerCase()}`,
    a = new Date(),
    o = `${a.getFullYear()}${String(a.getMonth() + 1).padStart(2, "0")}${String(a.getDate()).padStart(2, "0")}T${String(a.getHours()).padStart(2, "0")}${String(a.getMinutes()).padStart(2, "0")}${String(a.getSeconds()).padStart(2, "0")}`,
    d = s.authorNames.map(
      (f, T) => `      <Contributor>
        <SequenceNumber>${T + 1}</SequenceNumber>
        <ContributorRole>A01</ContributorRole>
        <PersonName>${B(f)}</PersonName>
      </Contributor>`,
    ).join(`
`),
    p = s.bisacCodes.map(
      (f) => `      <Subject>
        <SubjectSchemeIdentifier>10</SubjectSchemeIdentifier>
        <SubjectCode>${B(f.code)}</SubjectCode>
        ${f.label ? `<SubjectHeadingText>${B(f.label)}</SubjectHeadingText>` : ""}
      </Subject>`,
    ).join(`
`),
    v = [
      s.shortDescription?.trim()
        ? `      <TextContent>
        <TextType>02</TextType>
        <ContentAudience>00</ContentAudience>
        <Text>${B(s.shortDescription.trim())}</Text>
      </TextContent>`
        : "",
      s.longDescription?.trim()
        ? `      <TextContent>
        <TextType>03</TextType>
        <ContentAudience>00</ContentAudience>
        <Text>${B(s.longDescription.trim())}</Text>
      </TextContent>`
        : "",
    ].filter(Boolean).join(`
`);
  return `<?xml version="1.0" encoding="UTF-8"?>
<ONIXMessage release="3.0" xmlns="http://ns.editeur.org/onix/3.0/reference">
  <Header>
    <Sender>
      <SenderName>${B(s.publisherName || s.authorNames[0] || "Independent Publisher")}</SenderName>
    </Sender>
    <SentDateTime>${o}</SentDateTime>
  </Header>
  <Product>
    <RecordReference>${B(n)}</RecordReference>
    <NotificationType>03</NotificationType>
${Pl(s.isbn, n)}    <DescriptiveDetail>
      <ProductComposition>00</ProductComposition>
      <ProductForm>BC</ProductForm>
      <TitleDetail>
        <TitleType>01</TitleType>
        <TitleElement>
          <TitleElementLevel>01</TitleElementLevel>
          <TitleText>${B(s.bookTitle)}</TitleText>
${
  s.subtitle?.trim()
    ? `          <Subtitle>${B(s.subtitle.trim())}</Subtitle>
`
    : ""
}        </TitleElement>
      </TitleDetail>
${
  s.seriesName?.trim()
    ? `      <Collection>
        <CollectionType>10</CollectionType>
        <TitleDetail>
          <TitleType>01</TitleType>
          <TitleElement>
            <TitleElementLevel>02</TitleElementLevel>
            <TitleText>${B(s.seriesName.trim())}</TitleText>
          </TitleElement>
        </TitleDetail>
      </Collection>
`
    : ""
}${
    d
      ? d +
        `
`
      : ""
  }      <Language>
        <LanguageRole>01</LanguageRole>
        <LanguageCode>${B(s.language)}</LanguageCode>
      </Language>
${
  p
    ? p +
      `
`
    : ""
}      <Audience>
        <AudienceCodeType>01</AudienceCodeType>
        <AudienceCodeValue>${B(s.audienceCode)}</AudienceCodeValue>
      </Audience>
    </DescriptiveDetail>
${(() => {
  const f = s.coverImageUrl?.trim()
    ? `      <SupportingResource>
        <ResourceContentType>01</ResourceContentType>
        <ContentAudience>00</ContentAudience>
        <ResourceMode>03</ResourceMode>
        <ResourceVersion>
          <ResourceForm>02</ResourceForm>
          <ResourceLink>${B(s.coverImageUrl.trim())}</ResourceLink>
        </ResourceVersion>
      </SupportingResource>
`
    : "";
  return !v && !f
    ? ""
    : `    <CollateralDetail>
${
  v
    ? v +
      `
`
    : ""
}${f}    </CollateralDetail>
`;
})()}${(() => {
    const f = s.publisherName?.trim()
        ? `      <Publisher>
        <PublishingRole>01</PublishingRole>
        <PublisherName>${B(s.publisherName.trim())}</PublisherName>
      </Publisher>
`
        : "",
      T = Dl(s.pubDate);
    return !f && !T
      ? ""
      : `    <PublishingDetail>
${f}${T}    </PublishingDetail>
`;
  })()}    <ProductSupply>
      <Market>
        <Territory>
          <RegionsIncluded>${B(s.territorialRights)}</RegionsIncluded>
        </Territory>
      </Market>
      <SupplyDetail>
        <Supplier>
          <SupplierRole>01</SupplierRole>
          <SupplierName>${B(s.publisherName || s.authorNames[0] || "Independent Publisher")}</SupplierName>
        </Supplier>
        <ProductAvailability>20</ProductAvailability>
${
  s.priceAmount?.trim() && ro(s.priceAmount) === null
    ? `        <Price>
          <PriceType>${oo(s.priceCurrency)}</PriceType>
          <PriceAmount>${B(s.priceAmount.trim())}</PriceAmount>
          <CurrencyCode>${B(s.priceCurrency)}</CurrencyCode>
        </Price>
`
    : ""
}      </SupplyDetail>
    </ProductSupply>
  </Product>
</ONIXMessage>
`;
}
function Bl({ ...s }) {
  return e.jsx(Br, { "data-slot": "sheet", ...s });
}
function El({ ...s }) {
  return e.jsx(Er, { "data-slot": "sheet-trigger", ...s });
}
function $l({ ...s }) {
  return e.jsx(Rr, { "data-slot": "sheet-portal", ...s });
}
function Ml({ className: s, ...n }) {
  return e.jsx(Lr, {
    "data-slot": "sheet-overlay",
    className: ks(
      "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/50",
      s,
    ),
    ...n,
  });
}
function Ul({ className: s, children: n, side: a = "right", ...o }) {
  return e.jsxs($l, {
    children: [
      e.jsx(Ml, {}),
      e.jsxs($r, {
        "data-slot": "sheet-content",
        className: ks(
          "bg-background data-[state=open]:animate-in data-[state=closed]:animate-out fixed z-50 flex flex-col gap-4 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500",
          a === "right" &&
            "data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right inset-y-0 right-0 h-full w-3/4 border-l sm:max-w-sm",
          a === "left" &&
            "data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left inset-y-0 left-0 h-full w-3/4 border-r sm:max-w-sm",
          a === "top" &&
            "data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top inset-x-0 top-0 h-auto border-b",
          a === "bottom" &&
            "data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom inset-x-0 bottom-0 h-auto border-t",
          s,
        ),
        ...o,
        children: [
          n,
          e.jsxs(Mr, {
            className:
              "ring-offset-background focus:ring-ring data-[state=open]:bg-secondary absolute top-4 right-4 rounded-xs opacity-70 transition-opacity hover:opacity-100 focus:ring-2 focus:ring-offset-2 focus:outline-hidden disabled:pointer-events-none",
            children: [
              e.jsx(js, { className: "size-4" }),
              e.jsx("span", { className: "sr-only", children: "Close" }),
            ],
          }),
        ],
      }),
    ],
  });
}
function Rl({ className: s, ...n }) {
  return e.jsx("div", {
    "data-slot": "sheet-header",
    className: ks("flex flex-col gap-1.5 p-4", s),
    ...n,
  });
}
function Ll({ className: s, ...n }) {
  return e.jsx(Ur, {
    "data-slot": "sheet-title",
    className: ks("text-foreground font-semibold", s),
    ...n,
  });
}
function Fl({ content: s, toolName: n }) {
  return e.jsxs("div", {
    className: "mt-10 max-w-3xl space-y-8",
    children: [
      e.jsxs("div", {
        children: [
          e.jsxs("h2", {
            className: "text-lg font-semibold mb-3",
            children: ["How to use ", n],
          }),
          s.howToUse
            .split(
              `

`,
            )
            .map((a, o) =>
              e.jsx(
                "p",
                {
                  className:
                    "text-sm text-muted-foreground leading-relaxed mb-3 last:mb-0",
                  children: a,
                },
                o,
              ),
            ),
        ],
      }),
      e.jsxs("div", {
        children: [
          e.jsx("h2", {
            className: "text-lg font-semibold mb-3",
            children: "When to use it",
          }),
          e.jsx("p", {
            className: "text-sm text-muted-foreground leading-relaxed",
            children: s.whenToUse,
          }),
        ],
      }),
      e.jsxs("div", {
        children: [
          e.jsx("h2", {
            className: "text-lg font-semibold mb-3",
            children: "When not to use it",
          }),
          e.jsx("p", {
            className: "text-sm text-muted-foreground leading-relaxed",
            children: s.whenNotTo,
          }),
        ],
      }),
      e.jsxs("div", {
        children: [
          e.jsx("h2", {
            className: "text-lg font-semibold mb-3",
            children: "Tips for best results",
          }),
          e.jsx("p", {
            className: "text-sm text-muted-foreground leading-relaxed",
            children: s.tips,
          }),
        ],
      }),
      e.jsxs("div", {
        children: [
          e.jsx("h2", {
            className: "text-lg font-semibold mb-3",
            children: "Limitations",
          }),
          e.jsx("p", {
            className: "text-sm text-muted-foreground leading-relaxed",
            children: s.limitations,
          }),
        ],
      }),
      e.jsxs("div", {
        children: [
          e.jsx("h2", {
            className: "text-lg font-semibold mb-3",
            children: "Privacy",
          }),
          e.jsx("p", {
            className: "text-sm text-muted-foreground leading-relaxed",
            children: s.privacyNote,
          }),
        ],
      }),
    ],
  });
}
const gn = [
    [0, 0],
    [13, 13],
    [32, 126],
    [160, 716],
    [718, 727],
    [730, 730],
    [732, 769],
    [771, 772],
    [775, 777],
    [803, 803],
    [809, 809],
    [817, 817],
    [880, 887],
    [890, 895],
    [900, 906],
    [908, 908],
    [910, 929],
    [931, 1327],
    [1425, 1479],
    [1488, 1514],
    [1520, 1524],
    [1536, 1791],
    [1872, 1919],
    [2160, 2190],
    [2192, 2193],
    [2200, 2273],
    [2275, 2435],
    [2437, 2444],
    [2447, 2448],
    [2451, 2472],
    [2474, 2480],
    [2482, 2482],
    [2486, 2489],
    [2492, 2500],
    [2503, 2504],
    [2507, 2510],
    [2519, 2519],
    [2524, 2525],
    [2527, 2531],
    [2534, 2558],
    [2689, 2691],
    [2693, 2701],
    [2703, 2705],
    [2707, 2728],
    [2730, 2736],
    [2738, 2739],
    [2741, 2745],
    [2748, 2757],
    [2759, 2761],
    [2763, 2765],
    [2768, 2768],
    [2784, 2787],
    [2790, 2801],
    [2809, 2815],
    [2946, 2947],
    [2949, 2954],
    [2958, 2960],
    [2962, 2965],
    [2969, 2970],
    [2972, 2972],
    [2974, 2975],
    [2979, 2980],
    [2984, 2986],
    [2990, 3001],
    [3006, 3010],
    [3014, 3016],
    [3018, 3021],
    [3024, 3024],
    [3031, 3031],
    [3046, 3066],
    [3072, 3084],
    [3086, 3088],
    [3090, 3112],
    [3114, 3129],
    [3132, 3140],
    [3142, 3144],
    [3146, 3149],
    [3157, 3158],
    [3160, 3162],
    [3165, 3165],
    [3168, 3171],
    [3174, 3183],
    [3191, 3212],
    [3214, 3216],
    [3218, 3240],
    [3242, 3251],
    [3253, 3257],
    [3260, 3268],
    [3270, 3272],
    [3274, 3277],
    [3285, 3286],
    [3293, 3294],
    [3296, 3299],
    [3302, 3311],
    [3313, 3315],
    [3328, 3340],
    [3342, 3344],
    [3346, 3396],
    [3398, 3400],
    [3402, 3407],
    [3412, 3427],
    [3430, 3455],
    [3585, 3642],
    [3647, 3675],
    [7296, 7304],
    [7376, 7417],
    [7424, 7615],
    [7680, 7957],
    [7960, 7965],
    [7968, 8005],
    [8008, 8013],
    [8016, 8023],
    [8025, 8025],
    [8027, 8027],
    [8029, 8029],
    [8031, 8061],
    [8064, 8116],
    [8118, 8132],
    [8134, 8147],
    [8150, 8155],
    [8157, 8175],
    [8178, 8180],
    [8182, 8190],
    [8194, 8194],
    [8201, 8201],
    [8203, 8208],
    [8211, 8212],
    [8216, 8218],
    [8220, 8222],
    [8224, 8224],
    [8226, 8226],
    [8230, 8230],
    [8242, 8243],
    [8249, 8250],
    [8260, 8260],
    [8271, 8271],
    [8352, 8382],
    [8432, 8432],
    [8467, 8467],
    [8470, 8470],
    [8482, 8482],
    [8593, 8593],
    [8595, 8595],
    [8722, 8722],
    [8725, 8725],
    [9676, 9676],
    [11360, 11391],
    [11744, 11775],
    [11841, 11841],
    [42560, 42655],
    [42784, 42926],
    [42928, 42935],
    [42999, 43007],
    [43056, 43065],
    [43232, 43263],
    [64285, 64310],
    [64312, 64316],
    [64318, 64318],
    [64320, 64321],
    [64323, 64324],
    [64326, 64450],
    [64467, 64911],
    [64914, 64967],
    [64975, 64975],
    [65008, 65023],
    [65070, 65071],
    [65136, 65140],
    [65142, 65276],
    [65279, 65279],
    [65533, 65533],
    [65535, 65535],
    [69373, 69375],
    [72448, 72457],
  ],
  Ol = [
    "Latin (all accented letters, including Polish, Czech, Turkish, Romanian and Vietnamese)",
    "Greek (including polytonic)",
    "Cyrillic (Russian, Ukrainian, Bulgarian, Serbian and others)",
    "Hebrew",
    "Arabic",
    "Devanagari (Hindi, Marathi, Nepali)",
    "Bengali",
    "Tamil",
    "Telugu",
    "Gujarati",
    "Kannada",
    "Malayalam",
    "Thai",
  ],
  Pn = [
    "Latin",
    "Greek",
    "Cyrillic",
    "Hebrew",
    "Arabic",
    "Devanagari",
    "Bengali",
    "Tamil",
    "Telugu",
    "Gujarati",
    "Kannada",
    "Malayalam",
    "Thai",
  ],
  Hl =
    "Chinese, Japanese, Korean, Punjabi, Sinhala, Lao, Khmer, Burmese, Georgian, Armenian and Ethiopic are not available in PDFs yet",
  zl = new RegExp("[\\p{L}\\p{M}\\p{Nd}]", "u"),
  _l = [
    "Han",
    "Hiragana",
    "Katakana",
    "Hangul",
    "Bopomofo",
    "Arabic",
    "Hebrew",
    "Devanagari",
    "Bengali",
    "Gurmukhi",
    "Gujarati",
    "Oriya",
    "Tamil",
    "Telugu",
    "Kannada",
    "Malayalam",
    "Sinhala",
    "Thai",
    "Lao",
    "Tibetan",
    "Myanmar",
    "Khmer",
    "Georgian",
    "Armenian",
    "Ethiopic",
    "Thaana",
    "Syriac",
    "Mongolian",
    "Latin",
    "Greek",
    "Cyrillic",
  ].map((s) => [s, new RegExp(`^\\p{Script=${s}}$`, "u")]),
  Wl = {
    Han: "Chinese (Han)",
    Hiragana: "Japanese (Hiragana)",
    Katakana: "Japanese (Katakana)",
    Hangul: "Korean (Hangul)",
    Myanmar: "Burmese",
    Gurmukhi: "Punjabi (Gurmukhi)",
  },
  Kl = /(DataUri|dataUri)$/;
function ql(s) {
  let n = 0,
    a = gn.length - 1;
  for (; n <= a;) {
    const o = (n + a) >> 1,
      [d, p] = gn[o];
    if (s < d) a = o - 1;
    else if (s > p) n = o + 1;
    else return !0;
  }
  return !1;
}
function Ql(s) {
  for (const [n, a] of _l)
    if (a.test(s))
      return Pn.includes(n) ? `unusual ${n} characters` : (Wl[n] ?? n);
  return "symbols or numerals outside the fonts";
}
function Vl(s) {
  return zl.test(s) && !ql(s.codePointAt(0));
}
function ba(s, n, a, o) {
  if (typeof s == "string") o(s, n);
  else if (Array.isArray(s)) s.forEach((d, p) => ba(d, `${n}[${p}]`, a, o));
  else if (s && typeof s == "object")
    for (const [d, p] of Object.entries(s))
      a.test(d) || ba(p, n ? `${n}.${d}` : d, a, o);
}
function Gl(s, n = Kl) {
  const a = new Set();
  let o = "",
    d = "";
  return (
    ba(s, "", n, (p, v) => {
      let f = "";
      for (const T of p)
        Vl(T) && (a.add(Ql(T)), f.length < 6 && !f.includes(T) && (f += T));
      f && !o && !d && ((o = v), (d = f));
    }),
    a.size ? { scripts: Array.from(a), path: o, sample: d } : null
  );
}
function Yl() {
  const s = [...Pn];
  return `${s.slice(0, -1).join(", ")} and ${s[s.length - 1]}`;
}
function Xl(s, n = s.path || "your text") {
  return `The book and manuscript PDF fonts cover ${Yl()} text, but ${n} contains ${s.scripts.join(", ")} ("${s.sample}"), which would print as missing characters. Supported scripts: ${Ol.join("; ")}. ${Hl}. Remove or replace that text. EPUB and Word files leave the font to the reading app or Word, so any script works there.`;
}
const Jl = new RegExp(
    "^[\\p{Script=Arabic}\\p{Script=Hebrew}\\p{Script=Syriac}\\p{Script=Thaana}\\p{Script=Nko}]$",
    "u",
  ),
  Zl = new RegExp("^\\p{L}$", "u"),
  ec = new RegExp("^\\p{Script=Arabic}$", "u"),
  tc = new RegExp("^\\p{Script=Hebrew}$", "u"),
  sc =
    /^(text|title|bookTitle|subtitle|byline|name|caption|alt|authorName|blurb|partTitle|edition|seriesName|publisherName|bio|authorNames|copyrightHolder)$/;
function Dn(s, n = { rtl: 0, ltr: 0, arabic: 0, hebrew: 0 }) {
  for (const a of s)
    a < "A" ||
      (Jl.test(a)
        ? (n.rtl++, ec.test(a) ? n.arabic++ : tc.test(a) && n.hebrew++)
        : Zl.test(a) && n.ltr++);
  return n;
}
function Ns(s, n, a, o) {
  if (!(o > 40)) {
    if (typeof s == "string") sc.test(a) && Dn(s, n);
    else if (Array.isArray(s)) for (const d of s) Ns(d, n, a, o + 1);
    else if (s && typeof s == "object")
      for (const [d, p] of Object.entries(s)) Ns(p, n, d, o + 1);
  }
}
function In(s) {
  const n = { rtl: 0, ltr: 0, arabic: 0, hebrew: 0 };
  if (Array.isArray(s) || typeof s == "string") {
    const a = [s];
    for (; a.length;) {
      const o = a.pop();
      typeof o == "string"
        ? Dn(o, n)
        : Array.isArray(o)
          ? a.push(...o)
          : o && typeof o == "object" && Ns(o, n, "", 0);
    }
    return n;
  }
  return (Ns(s, n, "", 0), n);
}
function ac(s) {
  const n = In(s);
  return n.rtl > n.ltr ? "rtl" : "ltr";
}
function ic(s) {
  const n = In(s);
  if (!(n.rtl <= n.ltr || n.rtl === 0))
    return n.hebrew > n.arabic ? "he" : "ar";
}
const fn = [
    "literata",
    "eb-garamond",
    "merriweather",
    "lora",
    "tinos",
    "inter",
    "arimo",
    "playfair-display",
  ],
  Ss = [
    {
      id: "literata",
      name: "Literata",
      group: "serif",
      note: "literary serif, made for long reading",
      cssName: "Literata",
      previewFamily: "FdpBook Literata",
    },
    {
      id: "eb-garamond",
      name: "EB Garamond",
      group: "serif",
      note: "classic book serif",
      cssName: "EBGaramond",
      previewFamily: "FdpBook EB Garamond",
    },
    {
      id: "merriweather",
      name: "Merriweather",
      group: "serif",
      note: "sturdy, readable on any screen",
      cssName: "Merriweather",
      previewFamily: "FdpBook Merriweather",
    },
    {
      id: "lora",
      name: "Lora",
      group: "serif",
      note: "warm contemporary serif for fiction",
      cssName: "Lora",
      previewFamily: "FdpBook Lora",
    },
    {
      id: "tinos",
      name: "Tinos",
      group: "serif",
      note: "Times New Roman style",
      cssName: "Tinos",
      previewFamily: "FdpBook Tinos",
    },
    {
      id: "inter",
      name: "Inter",
      group: "sans",
      note: "clean sans-serif",
      cssName: "Inter",
      previewFamily: "FdpBook Inter",
    },
    {
      id: "arimo",
      name: "Arimo",
      group: "sans",
      note: "Arial style",
      cssName: "Arimo",
      previewFamily: "FdpBook Arimo",
    },
    {
      id: "playfair-display",
      name: "Playfair Display",
      group: "display",
      note: "high-contrast display serif for poetry, memoir and covers-style titles",
      cssName: "PlayfairDisplay",
      previewFamily: "FdpBook Playfair Display",
    },
  ];
Object.fromEntries(Ss.map((s) => [s.id, s.cssName]));
const xa = new Map();
function nc(s) {
  const n = xa.get(s);
  if (n) return n;
  const a = Ss.find((d) => d.id === s),
    o = (async () => {
      try {
        if (
          !a ||
          typeof FontFace > "u" ||
          typeof document > "u" ||
          !document.fonts
        )
          return;
        const d = [400, 700].map(
          (p) =>
            new FontFace(
              a.previewFamily,
              `url(/fonts/book/${s}-${p === 400 ? "regular" : "bold"}.woff) format("woff")`,
              { weight: String(p) },
            ),
        );
        (await Promise.all(d.map((p) => p.load())),
          d.forEach((p) => document.fonts.add(p)));
      } catch {
        xa.delete(s);
      }
    })();
  return (xa.set(s, o), o);
}
function bn(s) {
  const n = Ss.find((o) => o.id === s),
    a = n?.group === "sans" ? "sans-serif" : "serif";
  return n ? `"${n.previewFamily}", ${a}` : "serif";
}
const b = { type: "doc", content: [{ type: "paragraph" }] },
  va = To.kdp.papers;
function vn(s, n, a, o) {
  const d = a % 2 === 1 ? a + 1 : a,
    p = Ao({
      trimWidthIn: s,
      trimHeightIn: n,
      pages: d,
      thicknessIn: va.find((v) => v.id === o).thicknessIn,
      bleedIn: 0.125,
    });
  return {
    printed: d,
    spineIn: p.spineIn,
    widthIn: p.coverWidthIn,
    heightIn: p.coverHeightIn,
  };
}
const rc = { serif: "Serif", sans: "Sans-serif", display: "Display" };
function oc(s) {
  const n = Date.now() - s,
    a = Math.floor(n / 6e4);
  if (a < 1) return "just now";
  if (a < 60) return `${a} minute${a === 1 ? "" : "s"} ago`;
  const o = Math.floor(a / 60);
  if (o < 24) return `${o} hour${o === 1 ? "" : "s"} ago`;
  const d = Math.floor(o / 24);
  if (d < 7) return `${d} day${d === 1 ? "" : "s"} ago`;
  const p = Math.floor(d / 7);
  if (p < 5) return `${p} week${p === 1 ? "" : "s"} ago`;
  const v = Math.floor(d / 30);
  return `${v} month${v === 1 ? "" : "s"} ago`;
}
const lc = `data:image/svg+xml,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="140" height="140">
    <text x="70" y="70" font-family="Georgia, serif" font-weight="700" font-size="20"
      fill="#000000" fill-opacity="0.22" text-anchor="middle" dominant-baseline="middle"
      transform="rotate(-30 70 70)">PREVIEW</text>
  </svg>`)}`;
function ga(s) {
  return {
    id: crypto.randomUUID(),
    kind: "chapter",
    title: `Chapter ${s}`,
    content: b,
  };
}
function cc(s) {
  return { id: crypto.randomUUID(), kind: "part", title: `Part ${s}` };
}
function fa(s) {
  return { id: crypto.randomUUID(), name: "", role: s, bio: b };
}
function wn(s) {
  return new Promise((n, a) => {
    const o = new FileReader();
    ((o.onload = () => n(o.result)),
      (o.onerror = () => a(o.error)),
      o.readAsDataURL(s));
  });
}
function jn(s, n) {
  let a = "";
  for (let o = 0; o < s.length; o++) a += String.fromCharCode(s[o]);
  return `data:${n};base64,${btoa(a)}`;
}
function dc(s) {
  return s.length === 0
    ? ""
    : s.length === 1
      ? s[0]
      : s.length === 2
        ? `${s[0]} and ${s[1]}`
        : `${s.slice(0, -1).join(", ")}, and ${s[s.length - 1]}`;
}
const yn = [
    { id: "praise", label: "Praise", enabled: !1 },
    { id: "title-page", label: "Title Page", enabled: !0 },
    { id: "copyright-page", label: "Copyright Page", enabled: !0 },
    { id: "authors", label: "Authors", enabled: !0 },
    { id: "dedication", label: "Dedication", enabled: !1 },
    { id: "epigraph", label: "Epigraph", enabled: !1 },
    { id: "foreword", label: "Foreword", enabled: !1 },
    { id: "authors-note", label: "Author's Note", enabled: !1 },
    { id: "preface", label: "Preface", enabled: !1 },
    { id: "how-to-use", label: "How to Use This Book", enabled: !1 },
    { id: "publisher", label: "About the Publisher", enabled: !1 },
    { id: "peer-review", label: "Peer Review Note", enabled: !1 },
    { id: "toc", label: "Table of Contents", enabled: !0 },
    { id: "list-of-images", label: "List of Images", enabled: !0 },
    { id: "list-of-tables", label: "List of Tables", enabled: !1 },
    { id: "list-of-graphs", label: "List of Graphs", enabled: !1 },
  ],
  Nn = [
    { id: "acknowledgments", label: "Acknowledgments", enabled: !1 },
    { id: "also-by-author", label: "Also by the Author", enabled: !1 },
    { id: "appendix", label: "Appendix", enabled: !1 },
    { id: "bibliography", label: "Bibliography", enabled: !1 },
    { id: "endnotes", label: "Notes", enabled: !1 },
    { id: "glossary", label: "Glossary", enabled: !1 },
    { id: "answer-key", label: "Answer Key", enabled: !1 },
    { id: "index", label: "Index", enabled: !1 },
  ];
function kn(s, n, a) {
  const o = n + a;
  if (o < 0 || o >= s.length) return s;
  const d = [...s];
  return (([d[n], d[o]] = [d[o], d[n]]), d);
}
function _e({ src: s, className: n, onRemove: a, label: o = "Remove image" }) {
  return e.jsxs("span", {
    className: "relative inline-block shrink-0",
    children: [
      e.jsx("img", { src: s, alt: "", className: n }),
      e.jsx("button", {
        type: "button",
        "aria-label": o,
        title: o,
        onClick: a,
        className:
          "absolute -top-2 -right-2 flex h-5 w-5 items-center justify-center rounded-full border bg-background text-foreground shadow hover:bg-destructive hover:text-destructive-foreground focus:outline-none focus:ring-2 focus:ring-ring",
        children: e.jsx(js, { className: "h-3 w-3" }),
      }),
    ],
  });
}
function Sd() {
  const { isAuthenticated: s } = Fr(),
    n = De.useUtils(),
    [a, o] = l.useState("Untitled Book"),
    [d, p] = l.useState(""),
    [v, f] = l.useState(""),
    [T, Ee] = l.useState(""),
    [M, ke] = l.useState(""),
    [h, ss] = l.useState(""),
    [We, Ts] = l.useState(() => crypto.randomUUID()),
    [O, as] = l.useState("auto"),
    [Ce, is] = l.useState("eng"),
    [$e, Ke] = l.useState([]),
    [qe, g] = l.useState("WORLD"),
    [C, Se] = l.useState("01"),
    [Me, Mt] = l.useState(""),
    [ie, As] = l.useState(""),
    [Ut, ya] = l.useState("USD"),
    [Rt, Na] = l.useState(""),
    [Lt, ka] = l.useState(""),
    [U, Ca] = l.useState(""),
    [he, Sa] = l.useState(""),
    [Ue, Ta] = l.useState(""),
    [Re, Aa] = l.useState(""),
    [Le, Ft] = l.useState([fa("main")]),
    [me, Pa] = l.useState("default"),
    L = an[me],
    [Q, Ps] = l.useState("print"),
    [_, Ot] = l.useState("trade6x9"),
    [yt, ns] = l.useState("6"),
    [Nt, rs] = l.useState("9"),
    [pe, Da] = l.useState("literata"),
    [D, Fe] = l.useState([ga(1)]),
    [I, Ds] = l.useState("front-cover");
  (l.useEffect(() => {
    Q === "ebook" && (I === "spine" || I === "back-cover") && Ds("front-cover");
  }, [Q]),
    l.useEffect(() => {
      if (L.forcesEbookOnly) {
        Ps("ebook");
        return;
      }
      if (Q !== "print") return;
      const t = L.validSizeIds;
      if (!(_ === "custom" ? L.allowsCustomSize : !t || t.includes(_)))
        if (L.allowsCustomSize) {
          if (_ !== "custom") {
            const r = vs[_];
            (ns((r.width / 72).toString()), rs((r.height / 72).toString()));
          }
          Ot("custom");
        } else t && t.length > 0 && Ot(t[0]);
    }, [me]));
  const [Bn, Is] = l.useState(!1);
  function F(t) {
    (Ds(t), Is(!1));
  }
  const [S, Bs] = l.useState(yn),
    [W, Es] = l.useState(Nn),
    [$s, kt] = l.useState(null),
    [os, ls] = l.useState(!1),
    [cs, Ia] = l.useState(!1),
    [En, V] = l.useState(!1),
    [$n, Ba] = l.useState(!1),
    [Mn, Ms] = l.useState(!1),
    [Ea, $a] = l.useState(!1),
    [Ct, St] = l.useState(!1),
    [ds, Ma] = l.useState(!1),
    [Ua, Ra] = l.useState(!1),
    [La, Fa] = l.useState(null),
    [Oa, Ha] = l.useState(null),
    [Ht, Un] = l.useState("bw-white"),
    [za, Rn] = l.useState(!0),
    [Te, Ln] = l.useState(null),
    [Us, _a] = l.useState(null),
    [Tt, us] = l.useState(null),
    [ne, Wa] = l.useState(b),
    [Qe, Rs] = l.useState(void 0),
    [zt, Ka] = l.useState(!1),
    [re, qa] = l.useState(b),
    [Ve, Ls] = l.useState(void 0),
    [_t, Qa] = l.useState(!1),
    [Ge, Fs] = l.useState(void 0),
    [Ye, Va] = l.useState(b),
    [Xe, Os] = l.useState(void 0),
    [Je, Ga] = l.useState(b),
    [At, Ya] = l.useState(""),
    [Ze, Xa] = l.useState(b),
    [et, Ja] = l.useState(b),
    [tt, Za] = l.useState(b),
    [st, ei] = l.useState(b),
    [at, ti] = l.useState(b),
    [R, si] = l.useState(""),
    [H, Hs] = l.useState(void 0),
    [it, ai] = l.useState(b),
    [nt, ii] = l.useState(b),
    [rt, ni] = l.useState(""),
    [ot, ri] = l.useState(b),
    [lt, oi] = l.useState(b),
    [ct, li] = l.useState(b),
    [dt, ci] = l.useState(b),
    [ut, di] = l.useState(b),
    [ht, ui] = l.useState(b),
    [mt, hi] = l.useState(b),
    [pt, mi] = l.useState(b),
    [xt, pi] = l.useState(b),
    [gt, xi] = l.useState(b),
    gi = l.useMemo(
      () =>
        ac([
          a,
          d,
          D,
          ne,
          re,
          Ye,
          Je,
          Ze,
          et,
          tt,
          st,
          at,
          it,
          nt,
          ot,
          lt,
          ct,
          dt,
          ut,
          ht,
          mt,
          pt,
          xt,
          gt,
        ]),
      [
        a,
        d,
        D,
        ne,
        re,
        Ye,
        Je,
        Ze,
        et,
        tt,
        st,
        at,
        it,
        nt,
        ot,
        lt,
        ct,
        dt,
        ut,
        ht,
        mt,
        pt,
        xt,
        gt,
      ],
    ),
    zs = O === "auto" ? gi : O,
    fi = (t) => (zs === "rtl" ? (ic([a, t]) ?? "en") : "en"),
    [K, _s] = l.useState(void 0),
    [Wt, bi] = l.useState(""),
    [Oe, Ws] = l.useState(void 0),
    [Ae, vi] = l.useState(void 0),
    [xe, wi] = l.useState(""),
    [ft, ji] = l.useState(""),
    [Kt, yi] = l.useState("CODE128"),
    [oe, Ks] = l.useState(null),
    [Ni, qs] = l.useState(null),
    [Pt, ki] = l.useState(""),
    [ge, Qs] = l.useState(null);
  function qt() {
    return {
      v: 1,
      bookTitle: a,
      subtitle: d,
      edition: v,
      seriesName: T,
      bodyFontFamily: pe,
      isbn: M,
      eisbn: h,
      epubStableId: We,
      bookDirection: O,
      onixLanguage: Ce,
      onixBisacCodes: $e,
      onixTerritorialRights: qe,
      onixAudienceCode: C,
      onixShortDescription: Me,
      onixPriceAmount: ie,
      onixPriceCurrency: Ut,
      onixPubDate: Rt,
      onixCoverImageUrl: Lt,
      manuscriptAuthorName: U,
      manuscriptAddress: he,
      manuscriptPhone: Ue,
      manuscriptEmail: Re,
      authors: Le,
      publishingPlatform: me,
      publishTarget: Q,
      sizeId: _,
      customWidthIn: yt,
      customHeightIn: Nt,
      body: D,
      frontSections: S,
      backSections: W,
      dedication: ne,
      dedicationImageDataUri: Qe,
      dedicationShowLabel: zt,
      epigraph: re,
      epigraphImageDataUri: Ve,
      epigraphShowLabel: _t,
      titlePageImageDataUri: Ge,
      titlePageContent: Ye,
      copyrightPageImageDataUri: Xe,
      copyrightPageContent: Je,
      forewordAuthorName: At,
      forewordContent: Ze,
      praise: et,
      authorsNote: tt,
      preface: st,
      howToUseThisBook: at,
      publisherName: R,
      publisherLogoDataUri: H,
      publisherIntro: it,
      peerReviewNote: nt,
      copyrightHolder: rt,
      listOfTables: ot,
      listOfGraphs: lt,
      acknowledgments: ct,
      alsoByAuthor: dt,
      appendix: ut,
      bibliography: ht,
      endnotes: mt,
      glossary: pt,
      answerKey: xt,
      indexContent: gt,
      frontCoverImageDataUri: K,
      spineText: Wt,
      spineImageDataUri: Oe,
      backCoverImageDataUri: Ae,
      backCoverBlurb: xe,
      barcodeValue: ft,
      barcodeFormat: Kt,
      qrValue: Pt,
    };
  }
  function Qt(t) {
    (o(t.bookTitle || "Untitled Book"),
      p(t.subtitle || ""),
      f(t.edition || ""),
      Ee(t.seriesName || ""),
      Da(fn.includes(t.bodyFontFamily) ? t.bodyFontFamily : "literata"),
      ke(t.isbn || ""),
      ss(t.eisbn || ""),
      Ts(t.epubStableId || crypto.randomUUID()),
      as(
        t.bookDirection === "ltr" || t.bookDirection === "rtl"
          ? t.bookDirection
          : "auto",
      ),
      is(t.onixLanguage || "eng"),
      Ke(t.onixBisacCodes || []),
      g(t.onixTerritorialRights || "WORLD"),
      Se(t.onixAudienceCode || "01"),
      Mt(t.onixShortDescription || ""),
      As(t.onixPriceAmount || ""),
      ya(t.onixPriceCurrency || "USD"),
      Na(t.onixPubDate || ""),
      ka(t.onixCoverImageUrl || ""),
      Ca(t.manuscriptAuthorName || ""),
      Sa(t.manuscriptAddress || ""),
      Ta(t.manuscriptPhone || ""),
      Aa(t.manuscriptEmail || ""),
      Ft(t.authors?.length ? t.authors : [fa("main")]),
      Pa(t.publishingPlatform || "default"),
      Ps(t.publishTarget || "print"),
      Ot(t.sizeId || "trade6x9"),
      ns(t.customWidthIn || "6"),
      rs(t.customHeightIn || "9"),
      Fe(t.body?.length ? t.body : [ga(1)]),
      Bs(t.frontSections?.length ? t.frontSections : yn),
      Es(t.backSections?.length ? t.backSections : Nn),
      Wa(t.dedication || b),
      Rs(t.dedicationImageDataUri),
      Ka(t.dedicationShowLabel ?? !1),
      qa(t.epigraph || b),
      Ls(t.epigraphImageDataUri),
      Qa(t.epigraphShowLabel ?? !1),
      Fs(t.titlePageImageDataUri),
      Va(t.titlePageContent || b),
      Os(t.copyrightPageImageDataUri),
      Ga(t.copyrightPageContent || b),
      Ya(t.forewordAuthorName || ""),
      Xa(t.forewordContent || b),
      Ja(t.praise || b),
      Za(t.authorsNote || b),
      ei(t.preface || b),
      ti(t.howToUseThisBook || b),
      si(t.publisherName || ""),
      Hs(t.publisherLogoDataUri),
      ai(t.publisherIntro || b),
      ii(t.peerReviewNote || b),
      ni(t.copyrightHolder || ""),
      ri(t.listOfTables || b),
      oi(t.listOfGraphs || b),
      li(t.acknowledgments || b),
      ci(t.alsoByAuthor || b),
      di(t.appendix || b),
      ui(t.bibliography || b),
      hi(t.endnotes || b),
      mi(t.glossary || b),
      pi(t.answerKey || b),
      xi(t.indexContent || b),
      _s(t.frontCoverImageDataUri),
      bi(t.spineText || ""),
      Ws(t.spineImageDataUri),
      vi(t.backCoverImageDataUri),
      wi(t.backCoverBlurb || ""),
      ji(t.barcodeValue || ""),
      yi(t.barcodeFormat || "CODE128"),
      ki(t.qrValue || ""));
  }
  const [Vs, Gs] = l.useState(!1),
    [Ci, Si] = l.useState(null),
    [q, Vt] = l.useState(null),
    [Fn, Gt] = l.useState(!1),
    [Ti, Ys] = l.useState([]),
    [On, hs] = l.useState(null);
  l.useEffect(() => {
    let t = !1;
    return (
      (async () => {
        let i = await jl();
        if ((i || ((i = await ws()), await ts(i)), t)) return;
        Vt(i);
        const c = Nl()?.snapshot ?? (await un(i));
        t ||
          (c && (Qt(c), w.info("Restored your previous draft of this book.")),
          Gs(!0));
      })(),
      () => {
        t = !0;
      }
    );
  }, []);
  const Ai = l.useRef(qt);
  Ai.current = qt;
  const Pi = l.useRef(!1);
  Pi.current = Vs;
  const Di = l.useRef(null);
  Di.current = q;
  function ms() {
    return Pi.current ? yl(Di.current, Ai.current()) : !1;
  }
  (l.useEffect(() => {
    const t = () => {
      ms();
    };
    return (
      window.addEventListener("pagehide", t),
      () => window.removeEventListener("pagehide", t)
    );
  }, []),
    l.useEffect(() => {
      if (!Vs || !q) return;
      const t = setTimeout(() => {
          ms();
        }, 300),
        i = setTimeout(() => {
          pa(q, qt());
        }, 1500);
      return () => {
        (clearTimeout(t), clearTimeout(i));
      };
    }, [
      Vs,
      q,
      a,
      d,
      v,
      T,
      pe,
      M,
      h,
      We,
      O,
      Ce,
      $e,
      qe,
      C,
      Me,
      ie,
      Ut,
      Rt,
      Lt,
      U,
      he,
      Ue,
      Re,
      Le,
      me,
      Q,
      _,
      yt,
      Nt,
      D,
      S,
      W,
      ne,
      Qe,
      zt,
      re,
      Ve,
      _t,
      Ge,
      Ye,
      Xe,
      Je,
      At,
      Ze,
      et,
      tt,
      st,
      at,
      R,
      H,
      it,
      nt,
      rt,
      ot,
      lt,
      ct,
      dt,
      ut,
      ht,
      mt,
      pt,
      xt,
      gt,
      K,
      Wt,
      Oe,
      Ae,
      xe,
      ft,
      Kt,
      Pt,
    ]));
  const Pe = De.bookMaker.status.useQuery(void 0, { enabled: s }),
    ps = De.bookMaker.renderBook.useMutation(),
    Ii = De.bookMaker.renderManuscript.useMutation(),
    Bi = De.bookMaker.renderManuscriptDocx.useMutation(),
    Ei = De.bookMaker.renderEpub.useMutation(),
    Hn = De.bookMaker.renderCoverWrap.useMutation(),
    Xs = De.workflowProduct.checkout.useMutation(),
    zn = De.usage.log.useMutation(),
    Dt = D.find((t) => t.kind === "chapter" && t.id === I),
    xs = D.find((t) => t.kind === "part" && t.id === I),
    X =
      _ === "custom"
        ? {
            label: "Custom",
            width: (parseFloat(yt) || 6) * 72,
            height: (parseFloat(Nt) || 9) * 72,
          }
        : vs[_],
    le = Le.filter((t) => t.role === "main" && t.name.trim()).map((t) =>
      t.name.trim(),
    ),
    G = dc(le);
  (l.useEffect(() => {
    const t = setTimeout(async () => {
      if (!ft.trim()) {
        (Ks(null), qs(null));
        return;
      }
      try {
        const i = await bo(ft, Kt, { caption: ft });
        (Ks(jn(i, "image/png")), qs(null));
      } catch (i) {
        (Ks(null),
          qs(
            i instanceof Error ? i.message : "Couldn't generate that barcode",
          ));
      }
    }, 400);
    return () => clearTimeout(t);
  }, [ft, Kt]),
    l.useEffect(() => {
      const t = setTimeout(async () => {
        if (!Pt.trim()) {
          Qs(null);
          return;
        }
        try {
          const i = await vo(Pt, { size: 200 });
          Qs(jn(i, "image/png"));
        } catch {
          Qs(null);
        }
      }, 400);
      return () => clearTimeout(t);
    }, [Pt]));
  function _n() {
    const t = D.filter((r) => r.kind === "chapter").length + 1,
      i = ga(t);
    (Fe((r) => [...r, i]), F(i.id));
  }
  function Wn() {
    const t = D.filter((r) => r.kind === "part").length + 1,
      i = cc(t);
    (Fe((r) => [...r, i]), F(i.id));
  }
  async function Kn(t) {
    $a(!0);
    try {
      const { chapters: i, report: r } = await Sr(t),
        c = i.map(($) => ({
          id: crypto.randomUUID(),
          kind: "chapter",
          title: $.title,
          content: $.content,
        }));
      (Fe(($) => [...$, ...c]), F(c[0].id));
      const { summary: y, details: m } = Tr(r),
        x =
          c.length === 1
            ? `Imported "${c[0].title}" as a new chapter.`
            : `Imported ${c.length} chapters from "${t.name}".`,
        E = r.skippedImages.length > 0 || r.movedImages > 0 || r.shrunk > 0;
      (E ? w.warning : w.success)(x, {
        description: [y, ...m].join(`
`),
        duration: E ? 3e4 : 12e3,
        style: { whiteSpace: "pre-line" },
      });
    } catch (i) {
      (console.error(i),
        w.error(
          "Couldn't read that file — please make sure it's a real .docx or .txt file.",
        ));
    } finally {
      $a(!1);
    }
  }
  function $i(t) {
    const i = D.filter((m) => m.kind === "chapter").length;
    if (D.find((m) => m.id === t)?.kind === "chapter" && i === 1) {
      w.error("A book needs at least one chapter.");
      return;
    }
    const c = D.findIndex((m) => m.id === t),
      y = D.filter((m) => m.id !== t);
    (Fe(y), I === t && Ds(y[Math.max(0, c - 1)]?.id ?? "front-cover"));
  }
  function Js(t, i) {
    Fe((r) => r.map((c) => (c.id === t ? { ...c, title: i } : c)));
  }
  function gs(t, i) {
    Fe((r) =>
      kn(
        r,
        r.findIndex((c) => c.id === t),
        i,
      ),
    );
  }
  function qn(t, i) {
    Fe((r) =>
      r.map((c) =>
        c.kind === "chapter" && c.id === t ? { ...c, content: i } : c,
      ),
    );
  }
  function Yt(t, i) {
    Ft((r) => r.map((c) => (c.id === t ? { ...c, ...i } : c)));
  }
  function Qn(t) {
    Ft((i) => (i.length === 1 ? i : i.filter((r) => r.id !== t)));
  }
  function Mi(t, i, r) {
    (t === "front" ? Bs : Es)((y) =>
      y.map((m) => (m.id === i ? { ...m, enabled: r } : m)),
    );
  }
  function Ui(t, i, r) {
    (t === "front" ? Bs : Es)((y) =>
      kn(
        y,
        y.findIndex((m) => m.id === i),
        r,
      ),
    );
  }
  async function He(t, i) {
    const r = t.target.files?.[0];
    ((t.target.value = ""), r && i(await wn(r)));
  }
  async function Vn(t, i) {
    const r = t.target.files?.[0];
    ((t.target.value = ""), r && Yt(i, { photoDataUri: await wn(r) }));
  }
  const Xt = l.useCallback(() => {
    const t = [];
    let i;
    for (const x of D) {
      if (x.kind === "part") {
        i = x.title;
        continue;
      }
      ue(x.content) ||
        t.push({ title: x.title, blocks: Ie(x.content), partTitle: i });
    }
    if (t.length === 0) return null;
    const r = Le.filter((x) => x.name.trim()).map((x) => ({
      name: x.name.trim(),
      role: x.role,
      bio: ue(x.bio) ? void 0 : Ie(x.bio),
      photoDataUri: x.photoDataUri,
    }));
    function c(x) {
      return ue(x) ? void 0 : Ie(x);
    }
    function y(x) {
      const E = x
        .split(/\n{2,}/)
        .map(($) => $.trim())
        .filter(Boolean);
      return E.length
        ? E.map(($) => ({ type: "paragraph", runs: [{ text: $ }] }))
        : void 0;
    }
    const m = (x, E) => x.find(($) => $.id === E)?.enabled ?? !1;
    return {
      chapters: t,
      bookTitle: a.trim() || "Untitled Book",
      subtitle: d.trim() || void 0,
      edition: v.trim() || void 0,
      seriesName: T.trim() || void 0,
      bodyFontFamily: pe,
      direction: O,
      isbn: M.trim() || void 0,
      eisbn: h.trim() || void 0,
      authors: r.length ? r : void 0,
      trimWidthIn: X.width / 72,
      trimHeightIn: X.height / 72,
      gutterModel: L.gutterModel === "none" ? "kdp-scaled" : L.gutterModel,
      titlePageImageDataUri: Ge,
      titlePageContent: c(Ye),
      copyrightPageImageDataUri: Xe,
      copyrightPageContent: c(Je),
      dedication: m(S, "dedication") ? c(ne) : void 0,
      dedicationImageDataUri: m(S, "dedication") ? Qe : void 0,
      dedicationShowLabel: m(S, "dedication") ? zt : void 0,
      epigraph: m(S, "epigraph") ? c(re) : void 0,
      epigraphImageDataUri: m(S, "epigraph") ? Ve : void 0,
      epigraphShowLabel: m(S, "epigraph") ? _t : void 0,
      foreword:
        m(S, "foreword") && At.trim()
          ? { authorName: At.trim(), blocks: c(Ze) ?? [] }
          : void 0,
      praise: m(S, "praise") ? c(et) : void 0,
      authorsNote: m(S, "authors-note") ? c(tt) : void 0,
      preface: m(S, "preface") ? c(st) : void 0,
      howToUseThisBook: m(S, "how-to-use") ? c(at) : void 0,
      publisher:
        m(S, "publisher") && R.trim()
          ? { name: R.trim(), logoDataUri: H, intro: c(it) }
          : void 0,
      peerReviewNote: m(S, "peer-review") ? c(nt) : void 0,
      copyrightHolder: rt.trim() || (le.length ? G : void 0),
      includeToc: m(S, "toc"),
      includeListOfImages: m(S, "list-of-images"),
      listOfTables: m(S, "list-of-tables") ? c(ot) : void 0,
      listOfGraphs: m(S, "list-of-graphs") ? c(lt) : void 0,
      acknowledgments: m(W, "acknowledgments") ? c(ct) : void 0,
      alsoByAuthor: m(W, "also-by-author") ? c(dt) : void 0,
      appendix: m(W, "appendix") ? c(ut) : void 0,
      bibliography: m(W, "bibliography") ? c(ht) : void 0,
      endnotes: m(W, "endnotes") ? c(mt) : void 0,
      glossary: m(W, "glossary") ? c(pt) : void 0,
      answerKey: m(W, "answer-key") ? c(xt) : void 0,
      index: m(W, "index") ? c(gt) : void 0,
      frontCover:
        K || H || R.trim()
          ? {
              imageDataUri: K,
              publisherLogoDataUri: H,
              publisherName: R.trim() || void 0,
            }
          : void 0,
      backCover:
        Ae || xe.trim() || oe || ge || H || R.trim()
          ? {
              imageDataUri: Ae,
              blurb: y(xe),
              barcodeDataUri: oe ?? void 0,
              qrCodeDataUri: ge ?? void 0,
              publisherLogoDataUri: H,
              publisherName: R.trim() || void 0,
            }
          : void 0,
      frontMatterOrder: S.filter((x) => x.enabled).map((x) => x.id),
      backMatterOrder: W.filter((x) => x.enabled).map((x) => x.id),
    };
  }, [
    D,
    a,
    d,
    v,
    T,
    pe,
    M,
    h,
    We,
    O,
    Ce,
    $e,
    qe,
    L,
    C,
    Me,
    ie,
    Ut,
    Rt,
    Lt,
    U,
    he,
    Ue,
    Re,
    Le,
    X,
    S,
    W,
    ne,
    Qe,
    zt,
    re,
    Ve,
    _t,
    Ge,
    Ye,
    Xe,
    Je,
    At,
    Ze,
    et,
    tt,
    st,
    at,
    R,
    H,
    it,
    nt,
    rt,
    le,
    G,
    ot,
    lt,
    ct,
    dt,
    ut,
    ht,
    mt,
    pt,
    xt,
    gt,
    K,
    Ae,
    xe,
    oe,
    ge,
  ]);
  function ce(t, i = "application/pdf") {
    const r = atob(t),
      c = new Uint8Array(r.length);
    for (let y = 0; y < r.length; y++) c[y] = r.charCodeAt(y);
    return new Blob([c], { type: i });
  }
  function It(t, i) {
    const r = Gl(t);
    return r
      ? (w.error(`Nothing was used or charged. ${Xl(r, i)}`, { duration: 3e4 }),
        !0)
      : !1;
  }
  async function Gn() {
    const t = Xt();
    if (!t) {
      w.error("Write something in at least one chapter first.");
      return;
    }
    if (!It(t, "your book")) {
      ls(!0);
      try {
        const i = await ps.mutateAsync({ ...t, preview: !0 }),
          r = ce(i.pdfBase64);
        kt(URL.createObjectURL(r) + "#toolbar=0&navpanes=0");
      } catch (i) {
        (console.error(i),
          w.error("Couldn't generate a preview right now — please try again."));
      } finally {
        ls(!1);
      }
    }
  }
  async function Ri() {
    q && (await pa(q, qt()));
    const t = await ws();
    (await ts(t),
      Vt(t),
      Qt({}),
      w.success(
        'Started a new book — your other book is saved under "My Books".',
      ));
  }
  const [Yn, fs] = l.useState(!1),
    [Jt, Li] = l.useState(!1);
  async function Xn() {
    (Li(!0), Gs(!1));
    try {
      const t = await Tl(),
        i = await ws();
      (await ts(i),
        Vt(i),
        Qt({}),
        Ys([]),
        kt(null),
        fs(!1),
        w.success(
          t
            ? "Everything was erased from this device. You have a blank book."
            : "Erased here. Close the toolbox in your other tabs to finish removing the saved copy.",
        ));
    } finally {
      (Gs(!0), Li(!1));
    }
  }
  async function Jn() {
    (Ys(await hn()), hs(null), Gt(!0));
  }
  async function Zn(t) {
    if (t === q) {
      Gt(!1);
      return;
    }
    q && (await pa(q, qt()));
    const i = await un(t);
    (await ts(t), Vt(t), Qt(i ?? {}), Gt(!1), w.success("Switched books."));
  }
  async function er(t) {
    if ((await mn(t), t === q)) {
      const i = await ws();
      (await ts(i), Vt(i), Qt({}));
    }
    (Ys(await hn()), hs(null), w.success("Book deleted."));
  }
  function tr() {
    (ms(), (window.location.href = zr()));
  }
  async function Fi() {
    const t = Xt();
    if (t && It(t, "your book")) return;
    if (!s) {
      V(!0);
      return;
    }
    const i = Xt();
    if (!i) {
      w.error("Write something in at least one chapter first.");
      return;
    }
    if (!de && J <= 0) {
      V(!0);
      return;
    }
    Ia(!0);
    try {
      const r = await ps.mutateAsync({ ...i, preview: !1 }),
        c = ce(r.pdfBase64);
      (bt(c, `${(a || "book").replace(/[^\w-]+/g, "_")}.pdf`),
        zn.mutate({
          toolId: "book-writing-toolbox",
          category: "pdf-tools",
          deviceId: _r(),
        }),
        n.bookMaker.status.invalidate(),
        q && mn(q),
        kl());
    } catch (r) {
      (console.error(r),
        w.error(
          "Couldn't generate your book right now — nothing was charged. Please try again.",
        ));
    } finally {
      Ia(!1);
    }
  }
  function sr() {
    const t = Il({
        bookTitle: a || "Untitled Book",
        subtitle: d || void 0,
        authorNames: le,
        isbn: M || void 0,
        publisherName: R || void 0,
        seriesName: T || void 0,
        language: Ce.trim() || "eng",
        bisacCodes: $e
          .filter((r) => r.code.trim())
          .map((r) => ({
            code: r.code.trim(),
            label: r.label.trim() || void 0,
          })),
        territorialRights: qe,
        audienceCode: C,
        shortDescription: Me || void 0,
        longDescription: xe || void 0,
        priceAmount: ie || void 0,
        priceCurrency: Ut,
        pubDate: Rt || void 0,
        coverImageUrl: Lt || void 0,
      }),
      i = new Blob([t], { type: "application/xml" });
    (bt(i, `${(a || "book").replace(/[^\w-]+/g, "_")}-onix.xml`),
      w.success("ONIX metadata file downloaded."));
  }
  function Bt() {
    const t = [];
    let i;
    for (const r of D) {
      if (r.kind === "part") {
        i = r.title;
        continue;
      }
      ue(r.content) ||
        t.push({ title: r.title, blocks: Ie(r.content), partTitle: i });
    }
    return t;
  }
  async function ar() {
    if (!U.trim()) {
      w.error(
        "Your real legal name is required for a real submission-ready title page.",
      );
      return;
    }
    const t = Bt();
    if (t.length === 0) {
      w.error("Write something in at least one chapter first.");
      return;
    }
    St(!0);
    try {
      const i = await Bi.mutateAsync({
          bookTitle: a || "Untitled Book",
          byline: G || U.trim(),
          authorLegalName: U.trim(),
          authorAddress: he || void 0,
          authorPhone: Ue || void 0,
          authorEmail: Re || void 0,
          chapters: t,
          direction: O,
          preview: !0,
        }),
        r = ce(
          i.docxBase64,
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        );
      (bt(
        r,
        `${(a || "book").replace(/[^\w-]+/g, "_")}-manuscript-preview.docx`,
      ),
        w.success(
          "Preview downloaded (watermarked). A clean copy is included with the Book Writing Toolbox subscription.",
        ));
    } catch (i) {
      (console.error(i),
        w.error("Couldn't generate the manuscript file. Please try again."));
    } finally {
      St(!1);
    }
  }
  async function ir() {
    if (!s) {
      V(!0);
      return;
    }
    if (!U.trim()) {
      w.error(
        "Your real legal name is required for a real submission-ready title page.",
      );
      return;
    }
    const t = Bt();
    if (t.length === 0) {
      w.error("Write something in at least one chapter first.");
      return;
    }
    if (!de && J <= 0) {
      V(!0);
      return;
    }
    St(!0);
    try {
      const i = await Bi.mutateAsync({
          bookTitle: a || "Untitled Book",
          byline: G || U.trim(),
          authorLegalName: U.trim(),
          authorAddress: he || void 0,
          authorPhone: Ue || void 0,
          authorEmail: Re || void 0,
          chapters: t,
          direction: O,
          preview: !1,
        }),
        r = ce(
          i.docxBase64,
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        );
      (bt(r, `${(a || "book").replace(/[^\w-]+/g, "_")}-manuscript.docx`),
        n.bookMaker.status.invalidate(),
        w.success("Manuscript file downloaded."));
    } catch (i) {
      (console.error(i),
        w.error(
          "Couldn't generate the manuscript file right now. Nothing was charged.",
        ));
    } finally {
      St(!1);
    }
  }
  async function nr() {
    if (!U.trim()) {
      w.error(
        "Your real legal name is required for a real submission-ready title page.",
      );
      return;
    }
    const t = Bt();
    if (t.length === 0) {
      w.error("Write something in at least one chapter first.");
      return;
    }
    if (
      !It(
        {
          bookTitle: a,
          authorByline: G,
          manuscriptAuthorName: U,
          manuscriptAddress: he,
          chapters: t,
        },
        "your manuscript",
      )
    ) {
      ls(!0);
      try {
        const i = await Ii.mutateAsync({
            bookTitle: a || "Untitled Book",
            byline: G || U.trim(),
            authorLegalName: U.trim(),
            authorAddress: he || void 0,
            authorPhone: Ue || void 0,
            authorEmail: Re || void 0,
            chapters: t,
            direction: O,
            preview: !0,
          }),
          r = ce(i.pdfBase64);
        kt(URL.createObjectURL(r) + "#toolbar=0&navpanes=0");
      } catch (i) {
        (console.error(i),
          w.error("Couldn't generate a preview right now — please try again."));
      } finally {
        ls(!1);
      }
    }
  }
  async function rr() {
    if (!s) {
      V(!0);
      return;
    }
    if (!U.trim()) {
      w.error(
        "Your real legal name is required for a real submission-ready title page.",
      );
      return;
    }
    const t = Bt();
    if (t.length === 0) {
      w.error("Write something in at least one chapter first.");
      return;
    }
    if (
      !It(
        {
          bookTitle: a,
          authorByline: G,
          manuscriptAuthorName: U,
          manuscriptAddress: he,
          chapters: t,
        },
        "your manuscript",
      )
    ) {
      if (!de && J <= 0) {
        V(!0);
        return;
      }
      St(!0);
      try {
        const i = await Ii.mutateAsync({
            bookTitle: a || "Untitled Book",
            byline: G || U.trim(),
            authorLegalName: U.trim(),
            authorAddress: he || void 0,
            authorPhone: Ue || void 0,
            authorEmail: Re || void 0,
            chapters: t,
            direction: O,
            preview: !1,
          }),
          r = ce(i.pdfBase64);
        (bt(r, `${(a || "book").replace(/[^\w-]+/g, "_")}-manuscript.pdf`),
          n.bookMaker.status.invalidate(),
          w.success("Manuscript PDF downloaded."));
      } catch (i) {
        (console.error(i),
          w.error(
            "Couldn't generate the manuscript PDF right now. Nothing was charged.",
          ));
      } finally {
        St(!1);
      }
    }
  }
  async function Oi(t) {
    const i = Bt();
    if (i.length === 0) {
      w.error("Write something in at least one chapter first.");
      return;
    }
    if (t && !de) {
      if (!s) {
        V(!0);
        return;
      }
      if (J <= 0) {
        V(!0);
        return;
      }
    }
    Ma(!0);
    try {
      const r = S.find((x) => x.id === "dedication")?.enabled ?? !1,
        c = S.find((x) => x.id === "epigraph")?.enabled ?? !1,
        y = await Ei.mutateAsync({
          bookTitle: a || "Untitled Book",
          subtitle: d || void 0,
          authorNames: le,
          language: Ce.trim() || fi(i),
          isbn: M || void 0,
          eisbn: h || void 0,
          publisherName: R || void 0,
          coverImageDataUri: K,
          copyrightHolder: rt || void 0,
          dedicationBlocks: r && !ue(ne) ? Ie(ne) : void 0,
          epigraphBlocks: c && !ue(re) ? Ie(re) : void 0,
          chapters: i,
          stableId: We,
          direction: O,
          bodyFontFamily: pe,
          preview: !t,
        }),
        m = ce(y.epubBase64, "application/epub+zip");
      (bt(m, `${(a || "book").replace(/[^\w-]+/g, "_")}.epub`),
        t && n.bookMaker.status.invalidate(),
        w.success(
          t
            ? "EPUB downloaded."
            : "Preview downloaded (watermarked). A clean copy is included with the Book Writing Toolbox subscription.",
        ));
    } catch (r) {
      (console.error(r),
        w.error("Couldn't generate the EPUB. Please try again."));
    } finally {
      Ma(!1);
    }
  }
  const or = () => Oi(!0),
    lr = () => Oi(!1);
  function Hi(t) {
    return new Promise((i, r) => {
      const c = new Image();
      ((c.onload = () => i({ width: c.naturalWidth, height: c.naturalHeight })),
        (c.onerror = () => r(new Error("Couldn't read image dimensions"))),
        (c.src = t));
    });
  }
  async function cr() {
    const t = Xt();
    if (!t) {
      w.error("Write something in at least one chapter first.");
      return;
    }
    if (!(Q === "print" && It(t, "your book"))) {
      (Ra(!0), Fa(null), Ha(null));
      try {
        const i = K ? await Hi(K).catch(() => {}) : void 0;
        if (Q === "print") {
          const c = await ps.mutateAsync({ ...t, preview: !0 }),
            y = ce(c.pdfBase64),
            x = (await sn.load(await y.arrayBuffer())).getPageCount(),
            E =
              _ === "custom"
                ? {
                    label: "Custom",
                    width: (parseFloat(yt) || 6) * 72,
                    height: (parseFloat(Nt) || 9) * 72,
                  }
                : vs[_],
            $ =
              L.gutterModel === "flat-0.5"
                ? 0.5
                : L.gutterModel === "flat-0.75-inside"
                  ? 0.75
                  : ho(x),
            fe = mo(L.gutterModel, x),
            ze = E.width / 72 - fe.outsideMarginIn - fe.insideMarginIn,
            Xi = [];
          for (const bs of po(t)) {
            if (/^data:image\/svg/i.test(bs.dataUri)) continue;
            const ea = await Hi(bs.dataUri).catch(() => {});
            ea &&
              Xi.push({
                where: bs.where,
                widthPx: ea.width,
                heightPx: ea.height,
                widthFrac: bs.widthFrac,
              });
          }
          Fa([
            ...xo({
              trimSizeId: _,
              trimWidthIn: E.width / 72,
              trimHeightIn: E.height / 72,
              pageCount: x,
              currentMarginIn: $,
              isbn: M || void 0,
              coverWidthPx: i?.width,
              coverHeightPx: i?.height,
            }),
            go(Xi, ze),
          ]);
        }
        const r = Bt();
        if (r.length > 0) {
          const c = S.find((fe) => fe.id === "dedication")?.enabled ?? !1,
            y = S.find((fe) => fe.id === "epigraph")?.enabled ?? !1,
            m = await Ei.mutateAsync({
              bookTitle: a || "Untitled Book",
              subtitle: d || void 0,
              authorNames: le,
              language: Ce.trim() || fi(r),
              isbn: M || void 0,
              eisbn: h || void 0,
              publisherName: R || void 0,
              coverImageDataUri: K,
              copyrightHolder: rt || void 0,
              dedicationBlocks: c && !ue(ne) ? Ie(ne) : void 0,
              epigraphBlocks: y && !ue(re) ? Ie(re) : void 0,
              chapters: r,
              stableId: We,
              direction: O,
              bodyFontFamily: pe,
              preview: !de,
            }),
            x = ce(m.epubBase64, "application/epub+zip").size;
          let E = 0,
            $ = 0;
          for (const fe of r)
            for (const ze of fe.blocks)
              ze.type === "image" && ((E += 1), ze.alt?.trim() || ($ += 1));
          Ha(
            fo({
              fileSizeBytes: x,
              imagesWithoutAltCount: $,
              totalImageCount: E,
              coverWidthPx: i?.width,
              coverHeightPx: i?.height,
            }),
          );
        }
        w.success("Pre-flight check complete.");
      } catch (i) {
        (console.error(i),
          w.error(
            "Couldn't run the pre-flight check right now. Please try again.",
          ));
      } finally {
        Ra(!1);
      }
    }
  }
  async function zi() {
    const t = Xt();
    if (!t)
      return (w.error("Write something in at least one chapter first."), null);
    if (It(t, "your book")) return null;
    const i = await ps.mutateAsync({
        ...t,
        frontCover: void 0,
        backCover: void 0,
        preview: !0,
      }),
      c = (await sn.load(await ce(i.pdfBase64).arrayBuffer())).getPageCount();
    return (Ln(c), c);
  }
  async function dr() {
    us("measure");
    try {
      const t = await zi();
      t && w.success(`The interior is ${t} pages.`);
    } catch (t) {
      (console.error(t),
        w.error(
          "Couldn't measure the page count right now. Please try again.",
        ));
    } finally {
      us(null);
    }
  }
  async function _i(t) {
    if (!t && !s) {
      V(!0);
      return;
    }
    if (!t && !de) {
      V(!0);
      return;
    }
    (us(t ? "preview" : "download"), _a(null));
    try {
      const i = await zi();
      if (!i) return;
      const r = await Hn.mutateAsync({
        trimWidthIn: X.width / 72,
        trimHeightIn: X.height / 72,
        pageCount: i,
        paper: Ht,
        bookTitle: a.trim() || "Untitled Book",
        subtitle: d.trim() || void 0,
        authorNames: le,
        edition: v.trim() || void 0,
        spineText: Wt.trim() || void 0,
        blurb: xe.trim() || void 0,
        publisherName: R.trim() || void 0,
        frontImageDataUri: K,
        backImageDataUri: Ae,
        spineImageDataUri: Oe,
        barcodeDataUri: oe ?? void 0,
        frontText: za,
        bodyFontFamily: pe,
        direction: O,
        preview: t,
      });
      _a(r.warnings);
      const c = ce(r.pdfBase64);
      t
        ? kt(URL.createObjectURL(c) + "#toolbar=0&navpanes=0")
        : (bt(c, `${(a || "book").replace(/[^\w-]+/g, "_")}-cover.pdf`),
          w.success(
            "Cover PDF downloaded. Check the notes under the buttons before you upload it.",
          ));
    } catch (i) {
      console.error(i);
      const r =
        i instanceof Error &&
        /Nothing was used|not a|must be|could not be decoded|does not contain/i.test(
          i.message,
        )
          ? i.message
          : "Couldn't build the cover right now. Please try again.";
      w.error(r);
    } finally {
      us(null);
    }
  }
  async function ur() {
    if (!s) {
      (ms(), (window.location.href = Wr("book-writing-toolbox")));
      return;
    }
    try {
      const t = await Xs.mutateAsync({ product: "book-writing-toolbox" });
      window.location.href = t.url;
    } catch (t) {
      (console.error(t),
        w.error(
          t instanceof Error && t.message
            ? t.message
            : "Couldn't start checkout. Please try again in a moment.",
        ));
    }
  }
  function Wi() {
    return qi
      ? e.jsxs("div", {
          className:
            "flex items-center gap-2 rounded-md border border-primary/40 bg-primary/5 px-3 py-2 text-sm",
          "data-testid": "book-admin-unlimited",
          children: [
            e.jsx(ia, { className: "h-4 w-4 text-primary shrink-0" }),
            e.jsx("span", {
              children: "Admin account: clean downloads, no limit.",
            }),
          ],
        })
      : Zs
        ? e.jsxs("div", {
            className:
              "flex items-center gap-2 rounded-md border border-primary/40 bg-primary/5 px-3 py-2 text-sm",
            "data-testid": "book-toolbox-active",
            children: [
              e.jsx(ia, { className: "h-4 w-4 text-primary shrink-0" }),
              e.jsxs("span", {
                children: [
                  "Book Writing Toolbox",
                  Pe.data?.toolbox.trialing ? " (trial)" : "",
                  ": clean downloads included, as many as you like.",
                ],
              }),
            ],
          })
        : Ki
          ? e.jsxs("div", {
              className:
                "flex items-center gap-2 rounded-md border border-primary/40 bg-primary/5 px-3 py-2 text-sm",
              children: [
                e.jsx(ia, { className: "h-4 w-4 text-primary shrink-0" }),
                e.jsxs("span", {
                  children: [
                    "Clean downloads unlocked",
                    Qi
                      ? ` until ${Qi.toLocaleString(void 0, { hour: "numeric", minute: "2-digit", month: "short", day: "numeric" })}`
                      : "",
                    " -- download as many times as you like.",
                  ],
                }),
              ],
            })
          : e.jsxs("div", {
              className:
                "flex items-center justify-between gap-3 rounded-md border px-3 py-2 text-sm",
              "data-testid": "book-toolbox-offer",
              children: [
                e.jsxs("span", {
                  className: "flex items-center gap-2 text-muted-foreground",
                  children: [
                    e.jsx(tn, { className: "h-4 w-4 shrink-0" }),
                    "Previews are unlimited and watermarked. Clean downloads come with the Book Writing Toolbox: $29.99 a month, 7-day trial.",
                  ],
                }),
                e.jsx(u, {
                  size: "sm",
                  variant: "outline",
                  className: "shrink-0",
                  onClick: () => V(!0),
                  children: na("trial", "29.99"),
                }),
              ],
            });
  }
  const J = (Pe.data?.creditBalance ?? 0) + (Pe.data?.aiCreditBalance ?? 0),
    Ki = Pe.data?.hasEpubManuscriptAccess ?? !1,
    Zs = Pe.data?.toolbox.entitled ?? !1,
    de = Zs || Ki,
    qi = Pe.data?.isAdmin ?? !1,
    Qi = Pe.data?.epubManuscriptAccessUntil
      ? new Date(Pe.data.epubManuscriptAccessUntil)
      : null;
  function A(t, i, r, c) {
    return e.jsx(cn, { initialContent: i, onChange: r, placeholder: c }, t);
  }
  function hr() {
    if (Dt)
      return e.jsx(
        cn,
        {
          initialContent: Dt.content,
          onChange: (t) => qn(Dt.id, t),
          placeholder: "Start writing...",
        },
        Dt.id,
      );
    if (xs)
      return e.jsxs("div", {
        className: "max-w-md",
        children: [
          e.jsx(j, {
            className: "mb-1.5 block text-xs text-muted-foreground",
            children: "Part title",
          }),
          e.jsx(k, {
            "aria-label": "Part title",
            value: xs.title,
            onChange: (t) => Js(xs.id, t.target.value),
            placeholder: "Part One: ...",
          }),
          e.jsx("p", {
            className: "text-xs text-muted-foreground mt-2",
            children:
              "Every chapter below this Part (until the next one) is grouped under it, with a divider page before the first.",
          }),
        ],
      });
    switch (I) {
      case "identifiers": {
        const t = {
          "free-exclusive": `Leave blank and ${me === "default" ? "the platform" : L.label} will assign a free one automatically — it'll only work there though, so buy your own if you plan to use the same ISBN elsewhere too.`,
          "must-supply-own":
            "IngramSpark doesn't offer a free ISBN — you'll need to purchase your own (from Bowker, a local ISBN agency, or as a paid add-on through IngramSpark itself) and enter it here before submitting.",
          optional:
            "A print book and its ebook edition are usually assigned different ISBNs — that's why there are two fields, not because you need both. Leave either blank if it doesn't apply.",
          "not-applicable":
            "Kobo doesn't require an ISBN at all — leave this blank and it'll assign its own internal identifier when the book goes live.",
        };
        return e.jsxs("div", {
          className: "max-w-md space-y-4",
          children: [
            e.jsx("p", {
              className: "text-sm text-muted-foreground",
              children:
                "Enter your ISBN and e-ISBN once here — they automatically carry through everywhere they're needed: the Copyright Page, ONIX metadata, the Shunn manuscript exports, and the EPUB's own identifier. Nothing to re-enter in any of those places.",
            }),
            e.jsxs("div", {
              className: "grid grid-cols-2 gap-3",
              children: [
                e.jsxs("div", {
                  children: [
                    e.jsx(j, {
                      className: "mb-1.5 block text-xs text-muted-foreground",
                      children: "ISBN (print, optional)",
                    }),
                    e.jsx(k, {
                      "aria-label": "ISBN (print, optional)",
                      value: M,
                      onChange: (i) => ke(i.target.value),
                      placeholder:
                        L.isbnPolicy === "must-supply-own"
                          ? "978-... (required before submitting)"
                          : "978-...",
                    }),
                  ],
                }),
                e.jsxs("div", {
                  children: [
                    e.jsx(j, {
                      className: "mb-1.5 block text-xs text-muted-foreground",
                      children: "e-ISBN (ebook, optional)",
                    }),
                    e.jsx(k, {
                      "aria-label": "e-ISBN (ebook, optional)",
                      value: h,
                      onChange: (i) => ss(i.target.value),
                      placeholder: "978-...",
                    }),
                  ],
                }),
              ],
            }),
            e.jsx("p", {
              className: "text-xs text-muted-foreground",
              children: t[L.isbnPolicy],
            }),
          ],
        });
      }
      case "front-cover":
        return e.jsxs("div", {
          className: "space-y-4",
          children: [
            e.jsx("p", {
              className: "text-sm text-muted-foreground",
              children:
                "The cover someone sees first — a real full-bleed page, the literal first page of the downloaded PDF.",
            }),
            e.jsxs("div", {
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children: "Cover image",
                }),
                e.jsxs("div", {
                  className: "flex items-center gap-2",
                  children: [
                    e.jsxs(u, {
                      variant: "outline",
                      size: "sm",
                      className: "gap-1.5",
                      onClick: () =>
                        document.getElementById("front-cover-input")?.click(),
                      children: [
                        e.jsx(Be, { className: "h-3.5 w-3.5" }),
                        K ? "Change image" : "Upload image",
                      ],
                    }),
                    e.jsx("input", {
                      id: "front-cover-input",
                      type: "file",
                      accept: "image/*",
                      className: "hidden",
                      onChange: (t) => He(t, _s),
                    }),
                  ],
                }),
              ],
            }),
            K
              ? e.jsx(_e, {
                  src: K,
                  className: "rounded border max-w-[240px]",
                  onRemove: () => _s(void 0),
                  label: "Remove cover image",
                })
              : e.jsx("div", {
                  className:
                    "flex items-center justify-center h-64 w-[240px] rounded border border-dashed text-muted-foreground",
                  children: e.jsx(Kr, { className: "h-8 w-8" }),
                }),
            e.jsxs("p", {
              className: "text-xs text-muted-foreground",
              children: [
                'Title shown: "',
                a,
                '"',
                G ? ` by ${G}` : "",
                v ? ` (${v})` : "",
                " -- edit these from the Title Page section.",
              ],
            }),
          ],
        });
      case "spine":
        return e.jsxs("div", {
          className: "space-y-4 max-w-md",
          children: [
            e.jsx("p", {
              className: "text-sm text-muted-foreground",
              children:
                "The text that runs down the side of a printed book: last names only, title only (no subtitle), plus edition. It is printed on the one-piece print cover below (not as a page of the book), and only when the spine is wide enough: KDP allows spine text on books of more than 79 pages, with at least 0.0625 in clear on each side.",
            }),
            e.jsxs("div", {
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children: "Custom spine text (optional)",
                }),
                e.jsx(k, {
                  "aria-label": "Custom spine text (optional)",
                  value: Wt,
                  onChange: (t) => bi(t.target.value),
                  placeholder: `${a}${le.length ? ` — ${le.map((t) => t.split(" ").slice(-1)[0]).join(", ")}` : ""}`,
                }),
                e.jsxs("p", {
                  className: "text-xs text-muted-foreground mt-1",
                  children: [
                    "Edition (from the Title Page section) is also included automatically: ",
                    v || "none set",
                    ".",
                  ],
                }),
              ],
            }),
            e.jsxs("div", {
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children: "Image (optional)",
                }),
                e.jsxs("div", {
                  className: "flex items-center gap-2",
                  children: [
                    e.jsxs(u, {
                      variant: "outline",
                      size: "sm",
                      className: "gap-1.5",
                      onClick: () =>
                        document.getElementById("spine-image-input")?.click(),
                      children: [
                        e.jsx(Be, { className: "h-3.5 w-3.5" }),
                        Oe ? "Change image" : "Add image",
                      ],
                    }),
                    Oe &&
                      e.jsx(_e, {
                        src: Oe,
                        className: "h-10 w-10 object-cover rounded border",
                        onRemove: () => Ws(void 0),
                      }),
                    e.jsx("input", {
                      id: "spine-image-input",
                      type: "file",
                      accept: "image/*",
                      className: "hidden",
                      onChange: (t) => He(t, Ws),
                    }),
                  ],
                }),
              ],
            }),
            e.jsxs("div", {
              className: "border-t pt-4 space-y-3",
              children: [
                e.jsx("p", {
                  className: "text-xs text-muted-foreground",
                  children:
                    "Barcode and QR code are entered once, on the Back Cover, and reused here automatically — no need to enter them twice.",
                }),
                e.jsxs("div", {
                  className: "flex gap-4",
                  children: [
                    e.jsxs("div", {
                      children: [
                        e.jsx(j, {
                          className:
                            "mb-1.5 block text-xs text-muted-foreground",
                          children: "Barcode",
                        }),
                        oe
                          ? e.jsx("img", {
                              src: oe,
                              alt: "",
                              className: "bg-white rounded p-2 max-w-[160px]",
                            })
                          : e.jsx("p", {
                              className: "text-xs text-muted-foreground",
                              children: "Not set",
                            }),
                      ],
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsx(j, {
                          className:
                            "mb-1.5 block text-xs text-muted-foreground",
                          children: "QR code",
                        }),
                        ge
                          ? e.jsx("img", {
                              src: ge,
                              alt: "",
                              className: "bg-white rounded p-2 h-20 w-20",
                            })
                          : e.jsx("p", {
                              className: "text-xs text-muted-foreground",
                              children: "Not set",
                            }),
                      ],
                    }),
                  ],
                }),
                (oe || ge) &&
                  e.jsx(u, {
                    variant: "ghost",
                    size: "sm",
                    className: "text-muted-foreground",
                    onClick: () => F("back-cover"),
                    children: "Edit on Back Cover",
                  }),
              ],
            }),
            (() => {
              const t = X.width / 72,
                i = X.height / 72;
              let r = null;
              try {
                r = Te ? vn(t, i, Te, Ht) : null;
              } catch {
                r = null;
              }
              return e.jsxs("div", {
                className: "border-t pt-4 space-y-3",
                children: [
                  e.jsx("h3", {
                    className: "text-sm font-medium",
                    children: "Print cover (one-piece PDF)",
                  }),
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground",
                    children:
                      "Back cover, spine and front cover on one page with 0.125 in bleed, sized by KDP's published cover formula: width = 2 x trim width + spine + 2 x bleed, height = trim height + 2 x bleed, spine = page count x paper thickness. Uses your front, spine and back images (each fills its panel and the bleed), the blurb, and the barcode from the Back Cover; without a barcode the barcode area is left blank and white, and KDP places its own. Fonts are embedded. IngramSpark and Lulu make their own templates; check against theirs before using this file there.",
                  }),
                  e.jsxs("div", {
                    className: "max-w-xs",
                    children: [
                      e.jsx(j, {
                        className: "mb-1.5 block text-xs text-muted-foreground",
                        children: "Paper (sets the spine width)",
                      }),
                      e.jsxs(Z, {
                        value: Ht,
                        onValueChange: (c) => Un(c),
                        children: [
                          e.jsx(ee, {
                            "aria-label": "Paper",
                            children: e.jsx(te, {}),
                          }),
                          e.jsx(se, {
                            children: va.map((c) =>
                              e.jsxs(
                                N,
                                {
                                  value: c.id,
                                  children: [
                                    c.label,
                                    " (",
                                    c.thicknessIn,
                                    " in per page)",
                                  ],
                                },
                                c.id,
                              ),
                            ),
                          }),
                        ],
                      }),
                    ],
                  }),
                  e.jsxs("label", {
                    className: "flex items-center gap-2 text-xs",
                    children: [
                      e.jsx(rn, {
                        checked: za,
                        onCheckedChange: (c) => Rn(c === !0),
                      }),
                      "Print the title and author over the front image (turn off if your artwork already has them)",
                    ],
                  }),
                  e.jsxs("div", {
                    className: "text-xs rounded-md border p-2.5 space-y-1",
                    children: [
                      Te
                        ? r
                          ? e.jsx(e.Fragment, {
                              children: e.jsxs("p", {
                                children: [
                                  "Interior: ",
                                  Te,
                                  " pages",
                                  r.printed !== Te
                                    ? ` (prints as ${r.printed})`
                                    : "",
                                  ". Spine ",
                                  r.spineIn.toFixed(3),
                                  " in. Full cover ",
                                  r.widthIn.toFixed(3),
                                  " x ",
                                  r.heightIn.toFixed(3),
                                  " in.",
                                ],
                              }),
                            })
                          : e.jsx("p", {
                              children:
                                "This trim size is outside what the cover calculator accepts.",
                            })
                        : e.jsx("p", {
                            children:
                              "Page count not measured yet. Building the cover measures it from a real render of the interior.",
                          }),
                      e.jsx("p", {
                        className: "font-medium",
                        children:
                          "The spine width depends on the final page count. Any change to the text, trim size, font or front and back matter changes it, so build the cover again after your last change to the interior.",
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className: "flex flex-wrap gap-2",
                    children: [
                      e.jsxs(u, {
                        variant: "outline",
                        size: "sm",
                        className: "gap-1.5",
                        onClick: dr,
                        disabled: Tt !== null,
                        children: [
                          Tt === "measure"
                            ? e.jsx(z, {
                                className: "h-3.5 w-3.5 animate-spin",
                              })
                            : e.jsx(oa, { className: "h-3.5 w-3.5" }),
                          "Measure page count",
                        ],
                      }),
                      e.jsxs(u, {
                        variant: "outline",
                        size: "sm",
                        className: "gap-1.5",
                        onClick: () => _i(!0),
                        disabled: Tt !== null,
                        children: [
                          Tt === "preview"
                            ? e.jsx(z, {
                                className: "h-3.5 w-3.5 animate-spin",
                              })
                            : e.jsx(Zt, { className: "h-3.5 w-3.5" }),
                          "Preview print cover",
                        ],
                      }),
                      e.jsxs(u, {
                        size: "sm",
                        className: "gap-1.5",
                        onClick: () => _i(!1),
                        disabled: Tt !== null,
                        children: [
                          Tt === "download"
                            ? e.jsx(z, {
                                className: "h-3.5 w-3.5 animate-spin",
                              })
                            : de
                              ? e.jsx(en, { className: "h-3.5 w-3.5" })
                              : e.jsx(tn, { className: "h-3.5 w-3.5" }),
                          "Download print cover (PDF)",
                        ],
                      }),
                    ],
                  }),
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground",
                    children:
                      "Preview is unlimited (watermarked, with trim, fold, safe-area and barcode guides). The clean cover PDF is included with the Book Writing Toolbox ($29.99 a month, 7-day trial).",
                  }),
                  Us &&
                    Us.length > 0 &&
                    e.jsx("ul", {
                      className:
                        "text-xs list-disc pl-4 space-y-1 text-muted-foreground",
                      children: Us.map((c, y) =>
                        e.jsx("li", { children: c }, y),
                      ),
                    }),
                ],
              });
            })(),
          ],
        });
      case "publishing-metadata":
        return e.jsxs("div", {
          className: "space-y-4 max-w-2xl",
          children: [
            e.jsx("p", {
              className: "text-sm text-muted-foreground",
              children:
                "For ONIX export — the metadata format retailers and distributors actually read (IngramSpark, publisher systems, and similar). Title, subtitle, authors, ISBN, publisher, and edition are already collected elsewhere and reused here automatically.",
            }),
            e.jsxs("div", {
              className: "grid grid-cols-2 gap-4",
              children: [
                e.jsxs("div", {
                  children: [
                    e.jsx(j, {
                      className: "mb-1.5 block text-xs text-muted-foreground",
                      children: "Language (ISO 639-2, e.g. eng, fra, spa)",
                    }),
                    e.jsx(k, {
                      "aria-label": "Language (ISO 639-2, e.g. eng, fra, spa)",
                      value: Ce,
                      onChange: (t) => is(t.target.value),
                      placeholder: "eng",
                    }),
                  ],
                }),
                L.showsTerritorialRights &&
                  e.jsxs("div", {
                    children: [
                      e.jsx(j, {
                        className: "mb-1.5 block text-xs text-muted-foreground",
                        children: "Territorial rights",
                      }),
                      e.jsxs(Z, {
                        value: qe,
                        onValueChange: g,
                        children: [
                          e.jsx(ee, { children: e.jsx(te, {}) }),
                          e.jsxs(se, {
                            children: [
                              e.jsx(N, { value: "WORLD", children: "World" }),
                              e.jsx(N, {
                                value: "US",
                                children: "United States only",
                              }),
                              e.jsx(N, {
                                value: "GB",
                                children: "United Kingdom only",
                              }),
                              e.jsx(N, {
                                value: "US GB CA AU NZ",
                                children: "US, UK, Canada, Australia, NZ",
                              }),
                            ],
                          }),
                        ],
                      }),
                    ],
                  }),
                e.jsxs("div", {
                  children: [
                    e.jsx(j, {
                      className: "mb-1.5 block text-xs text-muted-foreground",
                      children: "Audience",
                    }),
                    e.jsxs(Z, {
                      value: C,
                      onValueChange: Se,
                      children: [
                        e.jsx(ee, { children: e.jsx(te, {}) }),
                        e.jsxs(se, {
                          children: [
                            e.jsx(N, {
                              value: "01",
                              children: "General / trade",
                            }),
                            e.jsx(N, {
                              value: "02",
                              children: "Children / juvenile",
                            }),
                            e.jsx(N, { value: "03", children: "Young adult" }),
                            e.jsx(N, {
                              value: "04",
                              children: "Primary / secondary education",
                            }),
                            e.jsx(N, {
                              value: "05",
                              children: "College / higher education",
                            }),
                            e.jsx(N, {
                              value: "06",
                              children: "Professional / scholarly",
                            }),
                          ],
                        }),
                      ],
                    }),
                  ],
                }),
                e.jsxs("div", {
                  children: [
                    e.jsx(j, {
                      className: "mb-1.5 block text-xs text-muted-foreground",
                      children: "Publication date",
                    }),
                    e.jsx(k, {
                      "aria-label": "Publication date",
                      type: "date",
                      value: Rt,
                      onChange: (t) => Na(t.target.value),
                    }),
                  ],
                }),
                e.jsxs("div", {
                  children: [
                    e.jsx(j, {
                      className: "mb-1.5 block text-xs text-muted-foreground",
                      children: "Price",
                    }),
                    e.jsx(k, {
                      "aria-label": "Price",
                      value: ie,
                      onChange: (t) => As(t.target.value),
                      placeholder: "14.99",
                    }),
                  ],
                }),
                e.jsxs("div", {
                  children: [
                    e.jsx(j, {
                      className: "mb-1.5 block text-xs text-muted-foreground",
                      children: "Currency",
                    }),
                    e.jsxs(Z, {
                      value: Ut,
                      onValueChange: ya,
                      children: [
                        e.jsx(ee, { children: e.jsx(te, {}) }),
                        e.jsxs(se, {
                          children: [
                            e.jsx(N, { value: "USD", children: "USD" }),
                            e.jsx(N, { value: "GBP", children: "GBP" }),
                            e.jsx(N, { value: "EUR", children: "EUR" }),
                            e.jsx(N, { value: "CAD", children: "CAD" }),
                            e.jsx(N, { value: "AUD", children: "AUD" }),
                          ],
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            }),
            e.jsxs("div", {
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children:
                    "Short description (a sentence or two, for retailer listings)",
                }),
                e.jsx(aa, {
                  "aria-label":
                    "Short description (a sentence or two, for retailer listings)",
                  value: Me,
                  onChange: (t) => Mt(t.target.value),
                  rows: 2,
                  placeholder: "A one-line hook for the book.",
                }),
              ],
            }),
            e.jsxs("p", {
              className: "text-xs text-muted-foreground -mt-2",
              children: [
                "The long description reuses the Back Cover blurb automatically — ",
                xe.trim() ? "already set." : "not set yet.",
              ],
            }),
            e.jsxs("div", {
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children:
                    "Cover image URL (optional, only if hosted elsewhere)",
                }),
                e.jsx(k, {
                  "aria-label":
                    "Cover image URL (optional, only if hosted elsewhere)",
                  value: Lt,
                  onChange: (t) => ka(t.target.value),
                  placeholder: "https://your-site.com/cover.jpg",
                }),
                e.jsx("p", {
                  className: "text-xs text-muted-foreground mt-1",
                  children:
                    "Book Writing Toolbox doesn't host files, so there's nothing to link to automatically. If you've uploaded your cover somewhere else (a publisher site, cloud storage), paste that URL here and ONIX will reference it for retailers.",
                }),
              ],
            }),
            e.jsxs("div", {
              children: [
                e.jsxs("div", {
                  className: "flex items-center justify-between mb-1.5",
                  children: [
                    e.jsx(j, {
                      className: "text-xs text-muted-foreground",
                      children: "BISAC subject codes",
                    }),
                    e.jsxs(u, {
                      variant: "ghost",
                      size: "sm",
                      className: "h-7 text-xs gap-1",
                      onClick: () => Ke((t) => [...t, { code: "", label: "" }]),
                      children: [
                        e.jsx(ra, { className: "h-3.5 w-3.5" }),
                        " Add code",
                      ],
                    }),
                  ],
                }),
                $e.length === 0 &&
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground",
                    children:
                      "None added yet. Look up real codes at bisg.org/bisac-subject-codes-list.",
                  }),
                e.jsx("div", {
                  className: "space-y-2",
                  children: $e.map((t, i) =>
                    e.jsxs(
                      "div",
                      {
                        className: "flex gap-2 items-center",
                        children: [
                          e.jsx(k, {
                            className: "w-32",
                            value: t.code,
                            onChange: (r) =>
                              Ke((c) =>
                                c.map((y, m) =>
                                  m === i ? { ...y, code: r.target.value } : y,
                                ),
                              ),
                            placeholder: "FIC031000",
                          }),
                          e.jsx(k, {
                            value: t.label,
                            onChange: (r) =>
                              Ke((c) =>
                                c.map((y, m) =>
                                  m === i ? { ...y, label: r.target.value } : y,
                                ),
                              ),
                            placeholder: "FICTION / Thrillers / Suspense",
                          }),
                          e.jsx(u, {
                            variant: "ghost",
                            size: "icon",
                            className: "h-8 w-8 shrink-0 text-destructive",
                            onClick: () =>
                              Ke((r) => r.filter((c, y) => y !== i)),
                            children: e.jsx($t, { className: "h-4 w-4" }),
                          }),
                        ],
                      },
                      i,
                    ),
                  ),
                }),
              ],
            }),
            e.jsxs("div", {
              className: "border-t pt-4",
              children: [
                e.jsxs(u, {
                  variant: "outline",
                  className: "gap-1.5",
                  onClick: sr,
                  children: [
                    e.jsx(es, { className: "h-4 w-4" }),
                    "Export ONIX (.xml)",
                  ],
                }),
                e.jsx("p", {
                  className: "text-xs text-muted-foreground mt-1.5",
                  children:
                    "A real ONIX 3.0 metadata file, instant — no subscription needed, since it's pure metadata with no typesetting involved.",
                }),
              ],
            }),
          ],
        });
      case "manuscript-format":
        return e.jsxs("div", {
          className: "space-y-4 max-w-2xl",
          children: [
            e.jsx("p", {
              className: "text-sm text-muted-foreground",
              children:
                "A real Shunn Standard Manuscript Format .docx — the specific convention literary agents and publishers expect for a submission: 12pt Times New Roman, double-spaced, 1in margins, indented paragraphs, a running head on every page, and an honest word count computed from your actual chapters. Deliberately plain — no cover, no color, no tables — since that's the real, correct convention, not a limitation.",
            }),
            e.jsx("p", {
              className: "text-xs text-muted-foreground",
              children:
                "The book's own title and byline (from the Title Page section) are used automatically. The contact details below are your real, legal identity for submission purposes — separate from a pen name, since a real author may want those to differ.",
            }),
            e.jsxs("div", {
              className: "grid grid-cols-2 gap-4 max-w-lg",
              children: [
                e.jsxs("div", {
                  className: "col-span-2",
                  children: [
                    e.jsx(j, {
                      className: "mb-1.5 block text-xs text-muted-foreground",
                      children: "Your real legal name",
                    }),
                    e.jsx(k, {
                      "aria-label": "Your real legal name",
                      value: U,
                      onChange: (t) => Ca(t.target.value),
                      placeholder: "Jane A. Smith",
                    }),
                  ],
                }),
                e.jsxs("div", {
                  className: "col-span-2",
                  children: [
                    e.jsx(j, {
                      className: "mb-1.5 block text-xs text-muted-foreground",
                      children: "Mailing address",
                    }),
                    e.jsx(aa, {
                      "aria-label": "Mailing address",
                      value: he,
                      onChange: (t) => Sa(t.target.value),
                      rows: 2,
                      placeholder: `123 Main Street
Anytown, ST 12345`,
                    }),
                  ],
                }),
                e.jsxs("div", {
                  children: [
                    e.jsx(j, {
                      className: "mb-1.5 block text-xs text-muted-foreground",
                      children: "Phone",
                    }),
                    e.jsx(k, {
                      "aria-label": "Phone",
                      value: Ue,
                      onChange: (t) => Ta(t.target.value),
                      placeholder: "(555) 123-4567",
                    }),
                  ],
                }),
                e.jsxs("div", {
                  children: [
                    e.jsx(j, {
                      className: "mb-1.5 block text-xs text-muted-foreground",
                      children: "Email",
                    }),
                    e.jsx(k, {
                      "aria-label": "Email",
                      value: Re,
                      onChange: (t) => Aa(t.target.value),
                      placeholder: "jane@example.com",
                    }),
                  ],
                }),
              ],
            }),
            e.jsxs("div", {
              className: "border-t pt-4 space-y-3",
              children: [
                e.jsxs("div", {
                  children: [
                    e.jsxs("div", {
                      className: "flex gap-2",
                      children: [
                        e.jsxs(u, {
                          variant: "outline",
                          size: "sm",
                          className: "gap-1.5",
                          onClick: ar,
                          disabled: Ct,
                          children: [
                            Ct
                              ? e.jsx(z, { className: "h-4 w-4 animate-spin" })
                              : e.jsx(Zt, { className: "h-4 w-4" }),
                            "Preview",
                          ],
                        }),
                        e.jsxs(u, {
                          variant: "outline",
                          size: "sm",
                          className: "gap-1.5",
                          onClick: ir,
                          disabled: Ct,
                          children: [
                            Ct
                              ? e.jsx(z, { className: "h-4 w-4 animate-spin" })
                              : e.jsx(es, { className: "h-4 w-4" }),
                            "Export Manuscript (.docx)",
                          ],
                        }),
                      ],
                    }),
                    e.jsx("p", {
                      className: "text-xs text-muted-foreground mt-1.5",
                      children:
                        "Preview is unlimited (watermarked). The real download is included with the Book Writing Toolbox ($29.99 a month, 7-day trial).",
                    }),
                  ],
                }),
                e.jsxs("div", {
                  children: [
                    e.jsxs("div", {
                      className: "flex gap-2",
                      children: [
                        e.jsxs(u, {
                          variant: "outline",
                          size: "sm",
                          className: "gap-1.5",
                          onClick: nr,
                          disabled: os,
                          children: [
                            os
                              ? e.jsx(z, { className: "h-4 w-4 animate-spin" })
                              : e.jsx(Zt, { className: "h-4 w-4" }),
                            "Preview",
                          ],
                        }),
                        e.jsxs(u, {
                          variant: "outline",
                          className: "gap-1.5",
                          onClick: rr,
                          disabled: Ct,
                          children: [
                            Ct
                              ? e.jsx(z, { className: "h-4 w-4 animate-spin" })
                              : e.jsx(es, { className: "h-4 w-4" }),
                            "Export Manuscript (.pdf)",
                          ],
                        }),
                      ],
                    }),
                    e.jsxs("p", {
                      className: "text-xs text-muted-foreground mt-1.5",
                      children: [
                        "Preview is unlimited (watermarked). The real download is included with the Book Writing Toolbox ($29.99 a month, 7-day trial)",
                        !de && J > 0
                          ? `; you also have ${J} earlier credit${J === 1 ? "" : "s"}`
                          : "",
                        ".",
                      ],
                    }),
                  ],
                }),
                e.jsx("p", {
                  className: "text-xs text-muted-foreground",
                  children:
                    "Your legal name is required for either format, so the title page is real.",
                }),
                Wi(),
              ],
            }),
          ],
        });
      case "epub":
        return e.jsxs("div", {
          className: "space-y-4 max-w-2xl",
          children: [
            e.jsx("p", {
              className: "text-sm text-muted-foreground",
              children: `A real EPUB 3 file — reflowable, not fixed-page, so it works properly on any e-reader or phone. Built to real accessibility standards (EPUB Accessibility 1.1 / WCAG AA): structural navigation is always included, and if every image in the book has alt text (set via the "Alt text" button on each image in the editor), the file honestly claims full WCAG AA conformance. A book with an unlabeled image still gets a real, valid EPUB — it just won't claim compliance it hasn't earned.`,
            }),
            e.jsx("p", {
              className: "text-xs text-muted-foreground",
              children:
                "Title, subtitle, authors, language and territorial rights (from Publishing Metadata), ISBN, publisher, and the front cover image are all reused automatically — nothing to enter twice.",
            }),
            e.jsxs("div", {
              className: "border-t pt-4 space-y-3",
              children: [
                e.jsxs("div", {
                  children: [
                    e.jsxs("div", {
                      className: "flex flex-wrap gap-2",
                      children: [
                        e.jsxs(u, {
                          variant: "outline",
                          size: "sm",
                          className: "gap-1.5",
                          onClick: lr,
                          disabled: ds,
                          children: [
                            ds
                              ? e.jsx(z, { className: "h-4 w-4 animate-spin" })
                              : e.jsx(Zt, { className: "h-4 w-4" }),
                            "Preview EPUB (watermarked)",
                          ],
                        }),
                        e.jsxs(u, {
                          variant: "outline",
                          className: "gap-1.5",
                          onClick: or,
                          disabled: ds,
                          children: [
                            ds
                              ? e.jsx(z, { className: "h-4 w-4 animate-spin" })
                              : e.jsx(es, { className: "h-4 w-4" }),
                            "Export EPUB (.epub)",
                          ],
                        }),
                      ],
                    }),
                    e.jsxs("p", {
                      className: "text-xs text-muted-foreground mt-1.5",
                      children: [
                        "Preview is unlimited (watermarked). The clean EPUB is included with the Book Writing Toolbox ($29.99 a month, 7-day trial)",
                        !de && J > 0
                          ? `; you also have ${J} earlier credit${J === 1 ? "" : "s"}`
                          : "",
                        ".",
                      ],
                    }),
                  ],
                }),
                Wi(),
              ],
            }),
          ],
        });
      case "preflight":
        return e.jsxs("div", {
          className: "space-y-4 max-w-2xl",
          children: [
            e.jsx("p", {
              className: "text-sm text-muted-foreground",
              children:
                Q === "print"
                  ? "Real checks against KDP's published print requirements and common EPUB retailer expectations — not a guess. Runs a real preview render to get the book's actual page count, and builds a real EPUB to check its actual file size and accessibility completeness, rather than estimating either from word count."
                  : "Real checks against common EPUB retailer expectations — not a guess. Print checks are skipped in Ebook only mode. Builds a real EPUB to check its actual file size and accessibility completeness, rather than estimating from word count.",
            }),
            e.jsxs("div", {
              children: [
                e.jsxs(u, {
                  variant: "outline",
                  className: "gap-1.5",
                  onClick: cr,
                  disabled: Ua,
                  children: [
                    Ua
                      ? e.jsx(z, { className: "h-4 w-4 animate-spin" })
                      : e.jsx(es, { className: "h-4 w-4" }),
                    "Run Pre-flight Check",
                  ],
                }),
                e.jsx("p", {
                  className: "text-xs text-muted-foreground mt-1.5",
                  children:
                    "Unlimited — uses the same preview render Preview itself uses, no charge.",
                }),
              ],
            }),
            La &&
              e.jsxs("div", {
                className: "border-t pt-4",
                children: [
                  e.jsx("h3", {
                    className: "text-sm font-medium mb-2",
                    children: "KDP / Print (PDF)",
                  }),
                  e.jsx("div", {
                    className: "space-y-2",
                    children: La.map((t) =>
                      e.jsxs(
                        "div",
                        {
                          className: "flex gap-2 text-sm",
                          children: [
                            e.jsx("span", {
                              className: `shrink-0 mt-0.5 h-4 w-4 rounded-full flex items-center justify-center text-[10px] font-bold ${t.status === "pass" ? "bg-green-500/20 text-green-500" : t.status === "warning" ? "bg-yellow-500/20 text-yellow-500" : "bg-red-500/20 text-red-500"}`,
                              children:
                                t.status === "pass"
                                  ? "✓"
                                  : t.status === "warning"
                                    ? "!"
                                    : "✕",
                            }),
                            e.jsxs("div", {
                              children: [
                                e.jsxs("span", {
                                  className: "font-medium",
                                  children: [t.label, ":"],
                                }),
                                " ",
                                e.jsx("span", {
                                  className: "text-muted-foreground",
                                  children: t.detail,
                                }),
                              ],
                            }),
                          ],
                        },
                        t.id,
                      ),
                    ),
                  }),
                ],
              }),
            Oa &&
              e.jsxs("div", {
                className: "border-t pt-4",
                children: [
                  e.jsx("h3", {
                    className: "text-sm font-medium mb-2",
                    children: "EPUB Retailers",
                  }),
                  e.jsx("div", {
                    className: "space-y-2",
                    children: Oa.map((t) =>
                      e.jsxs(
                        "div",
                        {
                          className: "flex gap-2 text-sm",
                          children: [
                            e.jsx("span", {
                              className: `shrink-0 mt-0.5 h-4 w-4 rounded-full flex items-center justify-center text-[10px] font-bold ${t.status === "pass" ? "bg-green-500/20 text-green-500" : t.status === "warning" ? "bg-yellow-500/20 text-yellow-500" : "bg-red-500/20 text-red-500"}`,
                              children:
                                t.status === "pass"
                                  ? "✓"
                                  : t.status === "warning"
                                    ? "!"
                                    : "✕",
                            }),
                            e.jsxs("div", {
                              children: [
                                e.jsxs("span", {
                                  className: "font-medium",
                                  children: [t.label, ":"],
                                }),
                                " ",
                                e.jsx("span", {
                                  className: "text-muted-foreground",
                                  children: t.detail,
                                }),
                              ],
                            }),
                          ],
                        },
                        t.id,
                      ),
                    ),
                  }),
                ],
              }),
          ],
        });
      case "title-page":
        return e.jsxs("div", {
          className: "space-y-4 max-w-2xl",
          children: [
            e.jsxs("div", {
              className: "max-w-md",
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children: "Book title",
                }),
                e.jsx(k, {
                  "aria-label": "Book title",
                  value: a,
                  onChange: (t) => o(t.target.value),
                  placeholder: "Book title",
                }),
              ],
            }),
            e.jsxs("div", {
              className: "max-w-md",
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children: "Subtitle (optional)",
                }),
                e.jsx(k, {
                  "aria-label": "Subtitle (optional)",
                  value: d,
                  onChange: (t) => p(t.target.value),
                  placeholder: "A short subtitle",
                }),
              ],
            }),
            e.jsxs("div", {
              className: "max-w-md",
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children: "Edition (optional)",
                }),
                e.jsx(k, {
                  "aria-label": "Edition (optional)",
                  value: v,
                  onChange: (t) => f(t.target.value),
                  placeholder: "e.g. 2nd Edition, Volume 3",
                }),
              ],
            }),
            e.jsxs("div", {
              className: "max-w-md",
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children: "Series (optional)",
                }),
                e.jsx(k, {
                  "aria-label": "Series (optional)",
                  value: T,
                  onChange: (t) => Ee(t.target.value),
                  placeholder: "e.g. The Ashworth House Novels, Book 2",
                }),
              ],
            }),
            e.jsxs("div", {
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children: "Image (optional)",
                }),
                e.jsxs("div", {
                  className: "flex items-center gap-2",
                  children: [
                    e.jsxs(u, {
                      variant: "outline",
                      size: "sm",
                      className: "gap-1.5",
                      onClick: () =>
                        document
                          .getElementById("title-page-image-input")
                          ?.click(),
                      children: [
                        e.jsx(Be, { className: "h-3.5 w-3.5" }),
                        Ge ? "Change image" : "Add image",
                      ],
                    }),
                    Ge &&
                      e.jsx(_e, {
                        src: Ge,
                        className: "h-10 w-10 object-cover rounded border",
                        onRemove: () => Fs(void 0),
                      }),
                    e.jsx("input", {
                      id: "title-page-image-input",
                      type: "file",
                      accept: "image/*",
                      className: "hidden",
                      onChange: (t) => He(t, Fs),
                    }),
                  ],
                }),
              ],
            }),
            e.jsx("p", {
              className: "text-xs text-muted-foreground",
              children:
                "Authors are managed from the Authors section — only main authors and illustrators appear on the title page.",
            }),
            e.jsxs("div", {
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children: "Additional text on the title page (optional)",
                }),
                A("title-page-content", Ye, Va, ""),
              ],
            }),
          ],
        });
      case "authors":
        return e.jsxs("div", {
          className: "space-y-6 max-w-xl",
          children: [
            e.jsx("p", {
              className: "text-sm text-muted-foreground",
              children:
                "Main authors are named on the title page and each get their own About page, same as Illustrators and Editors. Contributing writers share one page together — just a name, photo, and short intro each.",
            }),
            Le.map((t) =>
              e.jsxs(
                "div",
                {
                  className: "rounded-md border p-3 space-y-2.5",
                  children: [
                    e.jsxs("div", {
                      className: "flex items-center justify-between gap-2",
                      children: [
                        e.jsx(k, {
                          value: t.name,
                          onChange: (i) => Yt(t.id, { name: i.target.value }),
                          placeholder: "Name",
                          className: "max-w-[200px]",
                        }),
                        e.jsxs("div", {
                          className: "flex items-center gap-2",
                          children: [
                            e.jsxs(Z, {
                              value: t.role,
                              onValueChange: (i) => Yt(t.id, { role: i }),
                              children: [
                                e.jsx(ee, {
                                  className: "w-[160px]",
                                  children: e.jsx(te, {}),
                                }),
                                e.jsxs(se, {
                                  children: [
                                    e.jsx(N, {
                                      value: "main",
                                      children: "Main author",
                                    }),
                                    e.jsx(N, {
                                      value: "contributing",
                                      children: "Contributing writer",
                                    }),
                                    e.jsx(N, {
                                      value: "illustrator",
                                      children: "Illustrator",
                                    }),
                                    e.jsx(N, {
                                      value: "editor",
                                      children: "Editor",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            e.jsx(u, {
                              size: "icon",
                              variant: "ghost",
                              className: "h-8 w-8 text-destructive",
                              disabled: Le.length === 1,
                              onClick: () => Qn(t.id),
                              children: e.jsx($t, { className: "h-3.5 w-3.5" }),
                            }),
                          ],
                        }),
                      ],
                    }),
                    e.jsx("div", {
                      className: "max-w-lg",
                      children: A(
                        `author-bio-${t.id}`,
                        t.bio,
                        (i) => Yt(t.id, { bio: i }),
                        t.role === "contributing"
                          ? "Short 1-2 line intro..."
                          : "Full bio for their own About page...",
                      ),
                    }),
                    e.jsxs("div", {
                      className: "flex items-center gap-2",
                      children: [
                        e.jsxs(u, {
                          variant: "outline",
                          size: "sm",
                          className: "gap-1.5",
                          onClick: () =>
                            document
                              .getElementById(`author-photo-${t.id}`)
                              ?.click(),
                          children: [
                            e.jsx(Be, { className: "h-3.5 w-3.5" }),
                            t.photoDataUri ? "Change photo" : "Add photo",
                          ],
                        }),
                        t.photoDataUri &&
                          e.jsx(_e, {
                            src: t.photoDataUri,
                            className:
                              "h-10 w-10 rounded-full object-cover border",
                            onRemove: () => Yt(t.id, { photoDataUri: void 0 }),
                            label: "Remove photo",
                          }),
                        e.jsx("input", {
                          id: `author-photo-${t.id}`,
                          type: "file",
                          accept: "image/*",
                          className: "hidden",
                          onChange: (i) => Vn(i, t.id),
                        }),
                      ],
                    }),
                  ],
                },
                t.id,
              ),
            ),
            e.jsxs(u, {
              variant: "ghost",
              size: "sm",
              className: "gap-1.5 text-muted-foreground",
              onClick: () => Ft((t) => [...t, fa("contributing")]),
              children: [
                e.jsx(ra, { className: "h-4 w-4" }),
                " Add another person",
              ],
            }),
          ],
        });
      case "copyright-page":
        return e.jsxs("div", {
          className: "space-y-4 max-w-2xl",
          children: [
            e.jsxs("div", {
              className: "max-w-md",
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children: "Copyright holder",
                }),
                e.jsx(k, {
                  "aria-label": "Copyright holder",
                  value: rt,
                  onChange: (t) => ni(t.target.value),
                  placeholder: G || "Defaults to main author name(s)",
                }),
              ],
            }),
            e.jsxs("p", {
              className: "text-xs text-muted-foreground",
              children: [
                "ISBN",
                M.trim() ? `: ${M.trim()}` : " — not set yet",
                h.trim() ? `, e-ISBN: ${h.trim()}` : "",
                " -- entered once from",
                " ",
                e.jsx("button", {
                  type: "button",
                  className: "underline hover:text-foreground",
                  onClick: () => F("identifiers"),
                  children: "Book Identifiers",
                }),
                ", shown here automatically.",
              ],
            }),
            e.jsxs("div", {
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children: "Logo or image (optional)",
                }),
                e.jsxs("div", {
                  className: "flex items-center gap-2",
                  children: [
                    e.jsxs(u, {
                      variant: "outline",
                      size: "sm",
                      className: "gap-1.5",
                      onClick: () =>
                        document
                          .getElementById("copyright-page-image-input")
                          ?.click(),
                      children: [
                        e.jsx(Be, { className: "h-3.5 w-3.5" }),
                        Xe ? "Change image" : "Add image",
                      ],
                    }),
                    Xe &&
                      e.jsx(_e, {
                        src: Xe,
                        className: "h-10 w-10 object-contain rounded border",
                        onRemove: () => Os(void 0),
                      }),
                    e.jsx("input", {
                      id: "copyright-page-image-input",
                      type: "file",
                      accept: "image/*",
                      className: "hidden",
                      onChange: (t) => He(t, Os),
                    }),
                  ],
                }),
              ],
            }),
            e.jsx("p", {
              className: "text-xs text-muted-foreground",
              children:
                "Copyright year is set automatically to the current year.",
            }),
            e.jsxs("div", {
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children:
                    "Additional text (optional — printing history, permissions, etc.)",
                }),
                A("copyright-page-content", Je, Ga, ""),
              ],
            }),
          ],
        });
      case "dedication":
        return e.jsxs("div", {
          className: "max-w-2xl space-y-3",
          children: [
            e.jsxs("div", {
              className:
                "flex items-center justify-between rounded-md border px-3 py-2 max-w-md",
              children: [
                e.jsxs("div", {
                  children: [
                    e.jsx(j, {
                      className: "text-xs",
                      children: 'Show "Dedication" label on the page',
                    }),
                    e.jsx("p", {
                      className: "text-xs text-muted-foreground",
                      children:
                        "Real books usually leave this unlabeled — off by default.",
                    }),
                  ],
                }),
                e.jsx(nn, { checked: zt, onCheckedChange: Ka }),
              ],
            }),
            e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                e.jsxs(u, {
                  variant: "outline",
                  size: "sm",
                  className: "gap-1.5",
                  onClick: () =>
                    document.getElementById("dedication-image-input")?.click(),
                  children: [
                    e.jsx(Be, { className: "h-3.5 w-3.5" }),
                    Qe ? "Change image" : "Add image (optional)",
                  ],
                }),
                Qe &&
                  e.jsx(_e, {
                    src: Qe,
                    className: "h-10 w-10 object-cover rounded border",
                    onRemove: () => Rs(void 0),
                  }),
                e.jsx("input", {
                  id: "dedication-image-input",
                  type: "file",
                  accept: "image/*",
                  className: "hidden",
                  onChange: (t) => He(t, Rs),
                }),
              ],
            }),
            A("dedication", ne, Wa, "e.g. For everyone who..."),
          ],
        });
      case "epigraph":
        return e.jsxs("div", {
          className: "max-w-2xl space-y-3",
          children: [
            e.jsx("p", {
              className: "text-xs text-muted-foreground",
              children:
                "A short quote (or a few) on its own page, before the book starts.",
            }),
            e.jsxs("div", {
              className:
                "flex items-center justify-between rounded-md border px-3 py-2 max-w-md",
              children: [
                e.jsxs("div", {
                  children: [
                    e.jsx(j, {
                      className: "text-xs",
                      children: 'Show "Epigraph" label on the page',
                    }),
                    e.jsx("p", {
                      className: "text-xs text-muted-foreground",
                      children:
                        "Real books usually leave this unlabeled — off by default.",
                    }),
                  ],
                }),
                e.jsx(nn, { checked: _t, onCheckedChange: Qa }),
              ],
            }),
            e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                e.jsxs(u, {
                  variant: "outline",
                  size: "sm",
                  className: "gap-1.5",
                  onClick: () =>
                    document.getElementById("epigraph-image-input")?.click(),
                  children: [
                    e.jsx(Be, { className: "h-3.5 w-3.5" }),
                    Ve ? "Change image" : "Add image (optional)",
                  ],
                }),
                Ve &&
                  e.jsx(_e, {
                    src: Ve,
                    className: "h-10 w-10 object-cover rounded border",
                    onRemove: () => Ls(void 0),
                  }),
                e.jsx("input", {
                  id: "epigraph-image-input",
                  type: "file",
                  accept: "image/*",
                  className: "hidden",
                  onChange: (t) => He(t, Ls),
                }),
              ],
            }),
            A(
              "epigraph",
              re,
              qa,
              '"Every old house remembers." — attributed to no one in particular',
            ),
          ],
        });
      case "foreword":
        return e.jsxs("div", {
          className: "space-y-3 max-w-2xl",
          children: [
            e.jsx("p", {
              className: "text-xs text-muted-foreground",
              children:
                "Written by someone other than the author — distinct from Preface.",
            }),
            e.jsxs("div", {
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children: "Their name (and title, if relevant)",
                }),
                e.jsx(k, {
                  "aria-label": "Their name (and title, if relevant)",
                  value: At,
                  onChange: (t) => Ya(t.target.value),
                  placeholder: "e.g. Jane Smith, Editor of...",
                  className: "max-w-md",
                }),
              ],
            }),
            A("foreword", Ze, Xa, "The foreword itself..."),
          ],
        });
      case "authors-note":
        return e.jsx("div", {
          className: "max-w-2xl",
          children: A(
            "authors-note",
            tt,
            Za,
            "A shorter, more personal note than the preface...",
          ),
        });
      case "praise":
        return e.jsxs("div", {
          className: "max-w-2xl",
          children: [
            e.jsx("p", {
              className: "text-xs text-muted-foreground mb-2",
              children:
                "Named endorsement quotes, shown before anything else — one paragraph per quote works well.",
            }),
            A(
              "praise",
              et,
              Ja,
              '"A genuinely unsettling debut." — The Fictional Review',
            ),
          ],
        });
      case "preface":
        return e.jsx("div", {
          className: "max-w-2xl",
          children: A("preface", st, ei, "This book began as..."),
        });
      case "how-to-use":
        return e.jsx("div", {
          className: "max-w-2xl",
          children: A(
            "how-to-use",
            at,
            ti,
            "How this book is organized, and how to get the most from it...",
          ),
        });
      case "publisher":
        return e.jsxs("div", {
          className: "max-w-2xl space-y-3",
          children: [
            e.jsxs("div", {
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children: "Publisher name",
                }),
                e.jsx(k, {
                  "aria-label": "Publisher name",
                  value: R,
                  onChange: (t) => si(t.target.value),
                  placeholder: "Leave blank to skip this page",
                  className: "max-w-md",
                }),
              ],
            }),
            e.jsxs("div", {
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children: "About the publisher (optional)",
                }),
                A("publisher-intro", it, ai, ""),
              ],
            }),
            e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                e.jsxs(u, {
                  variant: "outline",
                  size: "sm",
                  className: "gap-1.5",
                  onClick: () =>
                    document.getElementById("publisher-logo-input")?.click(),
                  children: [
                    e.jsx(Be, { className: "h-3.5 w-3.5" }),
                    H ? "Change logo" : "Add logo",
                  ],
                }),
                H &&
                  e.jsx(_e, {
                    src: H,
                    className: "h-10 w-10 object-contain border rounded",
                    onRemove: () => Hs(void 0),
                  }),
                e.jsx("input", {
                  id: "publisher-logo-input",
                  type: "file",
                  accept: "image/*",
                  className: "hidden",
                  onChange: (t) => He(t, Hs),
                }),
              ],
            }),
          ],
        });
      case "peer-review":
        return e.jsx("div", {
          className: "max-w-2xl",
          children: A(
            "peer-review",
            nt,
            ii,
            "e.g. This manuscript was reviewed by...",
          ),
        });
      case "toc":
        return e.jsxs("div", {
          className: "max-w-md",
          children: [
            e.jsx("p", {
              className: "text-sm text-muted-foreground mb-3",
              children:
                "Auto-generated, with real computed page numbers in the actual PDF. This is a live preview of the structure so far, not the final page numbers.",
            }),
            D.length === 0
              ? e.jsx("p", {
                  className: "text-sm text-muted-foreground italic",
                  children: "No chapters yet.",
                })
              : e.jsx("ul", {
                  className: "text-sm space-y-1",
                  children: D.map((t) =>
                    t.kind === "part"
                      ? e.jsx(
                          "li",
                          {
                            className: "font-medium pt-2 first:pt-0",
                            children: t.title || "Untitled Part",
                          },
                          t.id,
                        )
                      : e.jsxs(
                          "li",
                          {
                            className: `pl-3 ${ue(t.content) ? "text-muted-foreground italic" : ""}`,
                            children: [
                              t.title || "Untitled Chapter",
                              ue(t.content) ? " (empty)" : "",
                            ],
                          },
                          t.id,
                        ),
                  ),
                }),
          ],
        });
      case "list-of-images": {
        const t = [];
        for (const i of D)
          if (!(i.kind !== "chapter" || ue(i.content)))
            for (const r of Ie(i.content))
              r.type === "image" &&
                r.caption &&
                t.push({ chapterTitle: i.title, caption: r.caption });
        return e.jsxs("div", {
          className: "max-w-md",
          children: [
            e.jsx("p", {
              className: "text-sm text-muted-foreground mb-3",
              children: `Auto-generated from your chapters' captioned images (add a caption via the image toolbar's "Caption" button). This is a live preview of what's been found so far.`,
            }),
            t.length === 0
              ? e.jsx("p", {
                  className: "text-sm text-muted-foreground italic",
                  children: "No captioned images found yet.",
                })
              : e.jsx("ul", {
                  className: "text-sm space-y-1.5",
                  children: t.map((i, r) =>
                    e.jsxs(
                      "li",
                      {
                        children: [
                          e.jsxs("span", {
                            className: "text-muted-foreground",
                            children: [i.chapterTitle, ":"],
                          }),
                          " ",
                          i.caption,
                        ],
                      },
                      r,
                    ),
                  ),
                }),
          ],
        });
      }
      case "list-of-tables":
        return e.jsxs("div", {
          className: "max-w-2xl",
          children: [
            e.jsx("p", {
              className: "text-xs text-muted-foreground mb-1.5",
              children: "Not auto-generated yet — enter your own list.",
            }),
            A("list-of-tables", ot, ri, "Table 1. ..."),
          ],
        });
      case "list-of-graphs":
        return e.jsxs("div", {
          className: "max-w-2xl",
          children: [
            e.jsx("p", {
              className: "text-xs text-muted-foreground mb-1.5",
              children: "Not auto-generated yet — enter your own list.",
            }),
            A("list-of-graphs", lt, oi, "Figure 1. ..."),
          ],
        });
      case "acknowledgments":
        return e.jsx("div", {
          className: "max-w-2xl",
          children: A("acknowledgments", ct, li, "Thanks to everyone who..."),
        });
      case "also-by-author":
        return e.jsx("div", {
          className: "max-w-2xl",
          children: A(
            "also-by-author",
            dt,
            ci,
            "Other titles by this author...",
          ),
        });
      case "appendix":
        return e.jsx("div", {
          className: "max-w-2xl",
          children: A("appendix", ut, di, ""),
        });
      case "bibliography":
        return e.jsx("div", {
          className: "max-w-2xl",
          children: A("bibliography", ht, ui, ""),
        });
      case "endnotes":
        return e.jsxs("div", {
          className: "max-w-2xl",
          children: [
            e.jsx("p", {
              className: "text-xs text-muted-foreground mb-1.5",
              children:
                "Numbered notes — linking these to a specific spot in your chapter text isn't built yet; this renders as a plain numbered page.",
            }),
            A("endnotes", mt, hi, ""),
          ],
        });
      case "glossary":
        return e.jsx("div", {
          className: "max-w-2xl",
          children: A("glossary", pt, mi, "Term — definition..."),
        });
      case "answer-key":
        return e.jsx("div", {
          className: "max-w-2xl",
          children: A("answer-key", xt, pi, ""),
        });
      case "index":
        return e.jsxs("div", {
          className: "max-w-2xl",
          children: [
            e.jsx("p", {
              className: "text-xs text-muted-foreground mb-1.5",
              children:
                "Not auto-generated yet — enter your own index entries.",
            }),
            A("index", gt, xi, ""),
          ],
        });
      case "back-cover":
        return e.jsxs("div", {
          className: "space-y-6 max-w-md",
          children: [
            e.jsx("p", {
              className: "text-sm text-muted-foreground",
              children:
                "Same as the front cover — a real full-bleed page, the literal last page of the downloaded PDF. The barcode and QR code below are genuinely generated using this site's own real generators, and those exact images are what actually appear on the page.",
            }),
            e.jsxs("div", {
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children: "Cover image (optional)",
                }),
                e.jsxs("div", {
                  className: "flex items-center gap-2",
                  children: [
                    e.jsxs(u, {
                      variant: "outline",
                      size: "sm",
                      className: "gap-1.5",
                      onClick: () =>
                        document.getElementById("back-cover-input")?.click(),
                      children: [
                        e.jsx(Be, { className: "h-3.5 w-3.5" }),
                        Ae ? "Change image" : "Upload image",
                      ],
                    }),
                    e.jsx("input", {
                      id: "back-cover-input",
                      type: "file",
                      accept: "image/*",
                      className: "hidden",
                      onChange: (t) => He(t, vi),
                    }),
                  ],
                }),
              ],
            }),
            e.jsxs("div", {
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children: "Back cover blurb",
                }),
                e.jsx(aa, {
                  "aria-label": "Back cover blurb",
                  value: xe,
                  onChange: (t) => wi(t.target.value),
                  placeholder: "A short description to hook a reader...",
                  rows: 4,
                }),
              ],
            }),
            e.jsxs("div", {
              className: "border-t pt-4",
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children: "Barcode (e.g. ISBN)",
                }),
                e.jsxs("div", {
                  className: "flex gap-2",
                  children: [
                    e.jsx(k, {
                      value: ft,
                      onChange: (t) => ji(t.target.value),
                      placeholder: "978...",
                      className: "flex-1",
                    }),
                    e.jsxs(Z, {
                      value: Kt,
                      onValueChange: (t) => yi(t),
                      children: [
                        e.jsx(ee, {
                          className: "w-[140px]",
                          children: e.jsx(te, {}),
                        }),
                        e.jsx(se, {
                          children: wo.map((t) =>
                            e.jsx(
                              N,
                              { value: t.value, children: t.value },
                              t.value,
                            ),
                          ),
                        }),
                      ],
                    }),
                  ],
                }),
                Ni &&
                  e.jsx("p", {
                    className: "text-xs text-destructive mt-1.5",
                    children: Ni,
                  }),
                oe &&
                  e.jsx("img", {
                    src: oe,
                    alt: "",
                    className: "mt-2 bg-white rounded p-2",
                  }),
              ],
            }),
            e.jsxs("div", {
              className: "border-t pt-4",
              children: [
                e.jsx(j, {
                  className: "mb-1.5 block text-xs text-muted-foreground",
                  children:
                    "QR code (optional — link to your site, socials, etc.)",
                }),
                e.jsx(k, {
                  "aria-label":
                    "QR code (optional — link to your site, socials, etc.)",
                  value: Pt,
                  onChange: (t) => ki(t.target.value),
                  placeholder: "https://...",
                }),
                ge &&
                  e.jsx("img", {
                    src: ge,
                    alt: "",
                    className: "mt-2 bg-white rounded p-2 h-32 w-32",
                  }),
              ],
            }),
            e.jsx("p", {
              className: "text-xs text-muted-foreground border-t pt-4",
              children:
                "Publisher logo (set from the About the Publisher section) and edition also appear on the front cover.",
            }),
          ],
        });
      default:
        return null;
    }
  }
  const mr =
    Dt?.title ??
    xs?.title ??
    [
      { id: "front-cover", label: "Front Cover" },
      { id: "spine", label: "Spine" },
      ...S,
      ...W,
      { id: "back-cover", label: "Back Cover" },
    ].find((t) => t.id === I)?.label ??
    "";
  function Vi({ section: t, region: i }) {
    return e.jsxs("div", {
      className: `flex items-center gap-1.5 rounded-md px-1.5 py-0.5 ${I === t.id ? "bg-secondary" : "hover:bg-muted"}`,
      children: [
        e.jsx(rn, {
          checked: t.enabled,
          onCheckedChange: (r) => Mi(i, t.id, !!r),
          onClick: (r) => r.stopPropagation(),
          className: "shrink-0 border-primary/70",
        }),
        e.jsx("button", {
          onClick: () => F(t.id),
          className: `flex-1 text-left text-sm py-1 truncate ${t.enabled ? "" : "text-muted-foreground"}`,
          children: t.label,
        }),
        e.jsxs("div", {
          className: "flex items-center shrink-0",
          children: [
            e.jsx(u, {
              size: "icon",
              variant: "ghost",
              className: "h-6 w-6",
              onClick: () => Ui(i, t.id, -1),
              children: e.jsx(la, { className: "h-3.5 w-3.5" }),
            }),
            e.jsx(u, {
              size: "icon",
              variant: "ghost",
              className: "h-6 w-6",
              onClick: () => Ui(i, t.id, 1),
              children: e.jsx(sa, { className: "h-3.5 w-3.5" }),
            }),
          ],
        }),
      ],
    });
  }
  function Gi({ region: t }) {
    const i = Al(t === "front" ? S : W);
    return i.length === 0
      ? null
      : e.jsxs("select", {
          "aria-label":
            t === "front"
              ? "Add a front-matter section"
              : "Add a back-matter section",
          className:
            "mx-1.5 my-1 h-8 rounded-md border bg-background px-2 text-sm text-muted-foreground",
          value: "",
          onChange: (r) => {
            const c = r.target.value;
            c && (Mi(t, c, !0), F(c));
          },
          children: [
            e.jsx("option", { value: "", children: "+ Add section…" }),
            i.map((r) =>
              e.jsx("option", { value: r.id, children: r.label }, r.id),
            ),
          ],
        });
  }
  const Yi = e.jsxs(e.Fragment, {
    children: [
      e.jsx("button", {
        onClick: () => F("identifiers"),
        className: `text-left text-sm rounded-md px-2.5 py-1.5 ${I === "identifiers" ? "bg-secondary font-medium" : "hover:bg-muted text-muted-foreground"}`,
        children: "Book Identifiers",
      }),
      e.jsx("div", { className: "my-1 border-t" }),
      e.jsx("button", {
        onClick: () => F("front-cover"),
        className: `text-left text-sm rounded-md px-2.5 py-1.5 ${I === "front-cover" ? "bg-secondary font-medium" : "hover:bg-muted text-muted-foreground"}`,
        children: "Front Cover",
      }),
      Q === "print" &&
        e.jsxs(e.Fragment, {
          children: [
            e.jsx("button", {
              onClick: () => F("spine"),
              className: `text-left text-sm rounded-md px-2.5 py-1.5 ${I === "spine" ? "bg-secondary font-medium" : "hover:bg-muted text-muted-foreground"}`,
              children: "Spine",
            }),
            e.jsx("button", {
              onClick: () => F("back-cover"),
              className: `text-left text-sm rounded-md px-2.5 py-1.5 ${I === "back-cover" ? "bg-secondary font-medium" : "hover:bg-muted text-muted-foreground"}`,
              children: "Back Cover",
            }),
          ],
        }),
      e.jsx("button", {
        onClick: () => F("publishing-metadata"),
        className: `text-left text-sm rounded-md px-2.5 py-1.5 ${I === "publishing-metadata" ? "bg-secondary font-medium" : "hover:bg-muted text-muted-foreground"}`,
        children: "Publishing Metadata",
      }),
      e.jsx("button", {
        onClick: () => F("manuscript-format"),
        className: `text-left text-sm rounded-md px-2.5 py-1.5 ${I === "manuscript-format" ? "bg-secondary font-medium" : "hover:bg-muted text-muted-foreground"}`,
        children: "Manuscript Format",
      }),
      e.jsx("button", {
        onClick: () => F("epub"),
        className: `text-left text-sm rounded-md px-2.5 py-1.5 ${I === "epub" ? "bg-secondary font-medium" : "hover:bg-muted text-muted-foreground"}`,
        children: "EPUB",
      }),
      e.jsx("button", {
        onClick: () => F("preflight"),
        className: `text-left text-sm rounded-md px-2.5 py-1.5 ${I === "preflight" ? "bg-secondary font-medium" : "hover:bg-muted text-muted-foreground"}`,
        children: "Pre-flight Check",
      }),
      e.jsx("div", { className: "my-1 border-t" }),
      e.jsxs("div", {
        className: "flex items-center gap-1",
        children: [
          e.jsx(u, {
            variant: "outline",
            size: "icon",
            className: "h-8 w-8 shrink-0",
            title: "Add a chapter",
            onClick: _n,
            children: e.jsx(ra, { className: "h-4 w-4" }),
          }),
          e.jsx(u, {
            variant: "outline",
            size: "icon",
            className: "h-8 w-8 shrink-0",
            title: "Add a part",
            onClick: Wn,
            children: e.jsx(oa, { className: "h-4 w-4" }),
          }),
          e.jsxs(u, {
            variant: "outline",
            size: "sm",
            className: "justify-start gap-1.5 px-2",
            disabled: Ea,
            onClick: () =>
              document.getElementById("chapter-import-input")?.click(),
            children: [
              Ea
                ? e.jsx(z, { className: "h-4 w-4 shrink-0 animate-spin" })
                : e.jsx(Po, { className: "h-4 w-4 shrink-0" }),
              " Import",
            ],
          }),
          e.jsx("input", {
            id: "chapter-import-input",
            type: "file",
            accept:
              ".docx,.txt,text/plain,application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            className: "hidden",
            onChange: (t) => {
              const i = t.target.files?.[0];
              ((t.target.value = ""), i && Kn(i));
            },
          }),
        ],
      }),
      e.jsx("div", { className: "my-1 border-t" }),
      xn(S, I).map((t) => e.jsx(Vi, { section: t, region: "front" }, t.id)),
      e.jsx(Gi, { region: "front" }),
      e.jsx("div", { className: "my-2 border-t" }),
      D.map((t, i) =>
        t.kind === "part"
          ? e.jsxs(
              "div",
              {
                style: { minHeight: "2rem" },
                className: `flex items-center gap-1 rounded-md px-1 mt-1 ${t.id === I ? "bg-secondary" : "hover:bg-muted"}`,
                children: [
                  e.jsx(oa, {
                    className:
                      "h-3.5 w-3.5 text-muted-foreground shrink-0 ml-1.5",
                  }),
                  e.jsx(k, {
                    value: t.title,
                    onChange: (r) => Js(t.id, r.target.value),
                    onFocus: () => F(t.id),
                    className:
                      "h-8 border-none shadow-none bg-transparent px-1.5 text-sm font-medium focus-visible:ring-1",
                  }),
                  e.jsxs("div", {
                    className: "flex items-center shrink-0",
                    children: [
                      e.jsx(u, {
                        size: "icon",
                        variant: "ghost",
                        className: "h-6 w-6",
                        disabled: i === 0,
                        onClick: () => gs(t.id, -1),
                        children: e.jsx(la, { className: "h-3.5 w-3.5" }),
                      }),
                      e.jsx(u, {
                        size: "icon",
                        variant: "ghost",
                        className: "h-6 w-6",
                        disabled: i === D.length - 1,
                        onClick: () => gs(t.id, 1),
                        children: e.jsx(sa, { className: "h-3.5 w-3.5" }),
                      }),
                      e.jsx(u, {
                        size: "icon",
                        variant: "ghost",
                        className: "h-6 w-6 text-destructive",
                        onClick: () => $i(t.id),
                        children: e.jsx($t, { className: "h-3.5 w-3.5" }),
                      }),
                    ],
                  }),
                ],
              },
              t.id,
            )
          : e.jsxs(
              "div",
              {
                style: { minHeight: "2rem" },
                className: `flex items-center gap-1 rounded-md px-1 ${t.id === I ? "bg-secondary" : "hover:bg-muted"}`,
                children: [
                  e.jsx(k, {
                    value: t.title,
                    onChange: (r) => Js(t.id, r.target.value),
                    onFocus: () => F(t.id),
                    className:
                      "h-8 border-none shadow-none bg-transparent px-2 text-sm focus-visible:ring-1",
                  }),
                  e.jsxs("div", {
                    className: "flex items-center shrink-0",
                    children: [
                      e.jsx(u, {
                        size: "icon",
                        variant: "ghost",
                        className: "h-6 w-6",
                        disabled: i === 0,
                        onClick: () => gs(t.id, -1),
                        children: e.jsx(la, { className: "h-3.5 w-3.5" }),
                      }),
                      e.jsx(u, {
                        size: "icon",
                        variant: "ghost",
                        className: "h-6 w-6",
                        disabled: i === D.length - 1,
                        onClick: () => gs(t.id, 1),
                        children: e.jsx(sa, { className: "h-3.5 w-3.5" }),
                      }),
                      e.jsx(u, {
                        size: "icon",
                        variant: "ghost",
                        className: "h-6 w-6 text-destructive",
                        onClick: () => $i(t.id),
                        children: e.jsx($t, { className: "h-3.5 w-3.5" }),
                      }),
                    ],
                  }),
                ],
              },
              t.id,
            ),
      ),
      e.jsx("div", { className: "my-2 border-t" }),
      xn(W, I).map((t) => e.jsx(Vi, { section: t, region: "back" }, t.id)),
      e.jsx(Gi, { region: "back" }),
    ],
  });
  return e.jsxs("div", {
    className: "flex flex-col h-[calc(100vh-4rem)] -mx-4 md:-mx-8",
    children: [
      e.jsxs("div", {
        className:
          "flex flex-wrap items-center gap-3 border-b px-4 py-3 bg-background",
        children: [
          e.jsxs(Bl, {
            open: Bn,
            onOpenChange: Is,
            children: [
              e.jsx(El, {
                asChild: !0,
                children: e.jsx(u, {
                  variant: "outline",
                  size: "icon",
                  className: "md:hidden shrink-0",
                  "aria-label": "Open the book sections menu",
                  title: "Open the book sections menu",
                  children: e.jsx(Or, { className: "h-4 w-4" }),
                }),
              }),
              e.jsxs(Ul, {
                side: "left",
                className: "w-72 p-0 flex flex-col gap-0",
                children: [
                  e.jsxs("div", {
                    className:
                      "flex-1 overflow-y-auto p-2 flex flex-col gap-0.5",
                    children: [
                      e.jsx(Rl, {
                        className: "px-2 py-2",
                        children: e.jsx(Ll, {
                          className: "text-sm",
                          children: "Book sections",
                        }),
                      }),
                      Yi,
                    ],
                  }),
                  e.jsx("div", {
                    className: "shrink-0 border-t p-2",
                    children: e.jsxs(u, {
                      variant: "ghost",
                      size: "sm",
                      className:
                        "w-full justify-start gap-1.5 text-muted-foreground",
                      onClick: () => {
                        (Is(!1), Ms(!0));
                      },
                      children: [
                        e.jsx(Ji, { className: "h-4 w-4" }),
                        "Help & FAQ",
                      ],
                    }),
                  }),
                ],
              }),
            ],
          }),
          e.jsx(Zi, {
            className: "h-5 w-5 text-muted-foreground shrink-0 hidden sm:block",
          }),
          e.jsx("span", {
            className: "font-semibold truncate max-w-[160px] sm:max-w-[280px]",
            children: a || "Untitled Book",
          }),
          e.jsx(u, {
            variant: "ghost",
            size: "icon",
            className: "h-8 w-8 shrink-0",
            title: "Start a new book — this one stays saved under My Books",
            onClick: Ri,
            children: e.jsx(ln, { className: "h-4 w-4" }),
          }),
          e.jsx(u, {
            variant: "ghost",
            size: "icon",
            className: "h-8 w-8 shrink-0",
            title: "My Books — switch between your saved books",
            onClick: Jn,
            children: e.jsx(Ro, { className: "h-4 w-4" }),
          }),
          e.jsxs(u, {
            variant: "outline",
            size: "sm",
            className: "h-8 shrink-0 gap-1.5 px-2",
            title:
              "Erase this book and everything this toolbox saved on this device",
            onClick: () => fs(!0),
            "data-testid": "book-erase-open",
            children: [
              e.jsx(Do, { className: "h-4 w-4" }),
              e.jsx("span", {
                className: "hidden sm:inline",
                children: "Clear everything",
              }),
            ],
          }),
          e.jsx(ko, {
            compact: !0,
            read: () => {
              const t = Co(M),
                i =
                  _ === "custom"
                    ? { width: Number(yt), height: Number(Nt) }
                    : So(_),
                r =
                  me === "kdp" || me === "ingramspark" || me === "lulu"
                    ? me
                    : void 0;
              return {
                title: a.trim() === "Untitled Book" ? "" : a.trim(),
                subtitle: d.trim(),
                author: Le[0]?.name.trim() ?? "",
                isbn13: t.valid && t.isbn13 ? t.isbn13 : "",
                trimWidthIn:
                  Number.isFinite(i.width) && i.width >= 2 && i.width <= 14
                    ? i.width
                    : null,
                trimHeightIn:
                  Number.isFinite(i.height) && i.height >= 2 && i.height <= 14
                    ? i.height
                    : null,
                ...(r ? { platform: r } : {}),
                listPrice: /^\d{1,6}([.,]\d{1,2})?$/.test(ie.trim())
                  ? ie.trim()
                  : "",
              };
            },
            apply: (t) => {
              (t.title && o(t.title),
                t.subtitle && p(t.subtitle),
                t.author &&
                  Ft((i) =>
                    i.map((r, c) => (c === 0 ? { ...r, name: t.author } : r)),
                  ),
                t.isbn13 && ke(t.isbn13),
                t.trimWidthIn &&
                  t.trimHeightIn &&
                  (Ot("custom"),
                  ns(String(t.trimWidthIn)),
                  rs(String(t.trimHeightIn))),
                t.listPrice && As(t.listPrice.replace(",", ".")));
            },
          }),
          e.jsxs(Z, {
            value: me,
            onValueChange: (t) => Pa(t),
            children: [
              e.jsx(ee, {
                className: "w-[110px] sm:w-[170px] ml-auto",
                title:
                  "Which platform you're publishing to — activates that platform's own real trim sizes, ISBN policy, and margin requirements",
                children: e.jsx(te, {}),
              }),
              e.jsx(se, {
                children: Object.entries(an).map(([t, i]) =>
                  e.jsx(N, { value: t, children: i.label }, t),
                ),
              }),
            ],
          }),
          e.jsxs(Z, {
            value: Q,
            onValueChange: (t) => Ps(t),
            children: [
              e.jsx(ee, {
                className: "w-[110px] sm:w-[160px]",
                title:
                  "What you're publishing to — hides print-only sections and controls for ebook-only, without deleting anything in them",
                children: e.jsx(te, {}),
              }),
              e.jsxs(se, {
                children: [
                  e.jsx(N, { value: "print", children: "Print + Ebook" }),
                  e.jsx(N, { value: "ebook", children: "Ebook only" }),
                ],
              }),
            ],
          }),
          Q === "print" &&
            e.jsxs(Z, {
              value: _,
              onValueChange: (t) => Ot(t),
              children: [
                e.jsx(ee, {
                  className: "w-[130px] sm:w-[200px]",
                  children: e.jsx(te, {}),
                }),
                e.jsxs(se, {
                  children: [
                    Object.entries(vs)
                      .filter(
                        ([t]) => !L.validSizeIds || L.validSizeIds.includes(t),
                      )
                      .map(([t, i]) =>
                        e.jsx(N, { value: t, children: i.label }, t),
                      ),
                    L.allowsCustomSize &&
                      e.jsx(N, { value: "custom", children: "Custom size..." }),
                  ],
                }),
              ],
            }),
          Q === "print" &&
            _ === "custom" &&
            e.jsxs("div", {
              className: "flex items-center gap-1 shrink-0",
              children: [
                e.jsx(k, {
                  type: "number",
                  step: "0.01",
                  min: "1",
                  value: yt,
                  onChange: (t) => ns(t.target.value),
                  className: "w-[64px] h-9 px-2",
                  title: "Width (inches)",
                }),
                e.jsx("span", {
                  className: "text-muted-foreground text-sm",
                  children: "x",
                }),
                e.jsx(k, {
                  type: "number",
                  step: "0.01",
                  min: "1",
                  value: Nt,
                  onChange: (t) => rs(t.target.value),
                  className: "w-[64px] h-9 px-2",
                  title: "Height (inches)",
                }),
                e.jsx("span", {
                  className: "text-xs text-muted-foreground",
                  children: "in",
                }),
              ],
            }),
          e.jsxs(Z, {
            value: pe,
            onValueChange: (t) => Da(t),
            onOpenChange: (t) => {
              t &&
                fn.forEach((i) => {
                  nc(i);
                });
            },
            children: [
              e.jsx(ee, {
                className: "w-[110px] sm:w-[190px]",
                title:
                  "Book font (embedded in PDF and EPUB, previewed live in the editor)",
                "aria-label": "Book font",
                children: e.jsx(te, {}),
              }),
              e.jsx(se, {
                children: ["serif", "sans", "display"].map((t) =>
                  e.jsxs(
                    "div",
                    {
                      children: [
                        e.jsx("div", {
                          className:
                            "px-2 py-1 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground",
                          children: rc[t],
                        }),
                        Ss.filter((i) => i.group === t).map((i) =>
                          e.jsxs(
                            N,
                            {
                              value: i.id,
                              children: [
                                e.jsx("span", {
                                  style: { fontFamily: bn(i.id) },
                                  className: "text-base",
                                  children: i.name,
                                }),
                                e.jsx("span", {
                                  className:
                                    "ml-2 text-xs text-muted-foreground",
                                  children: i.note,
                                }),
                              ],
                            },
                            i.id,
                          ),
                        ),
                      ],
                    },
                    t,
                  ),
                ),
              }),
            ],
          }),
          e.jsxs(Z, {
            value: O,
            onValueChange: (t) => as(t),
            children: [
              e.jsx(ee, {
                className: "w-[104px] sm:w-[190px]",
                title:
                  "Reading direction of the book (PDF, EPUB and Word). Automatic follows the text: Arabic and Hebrew books run right to left.",
                "aria-label": "Reading direction",
                "data-testid": "book-direction-select",
                children: e.jsx(te, {}),
              }),
              e.jsxs(se, {
                children: [
                  e.jsxs(N, {
                    value: "auto",
                    children: [
                      "Auto: ",
                      gi === "rtl" ? "right to left" : "left to right",
                    ],
                  }),
                  e.jsx(N, { value: "ltr", children: "Left to right" }),
                  e.jsx(N, { value: "rtl", children: "Right to left" }),
                ],
              }),
            ],
          }),
          Q === "print" &&
            e.jsxs(e.Fragment, {
              children: [
                e.jsxs(u, {
                  variant: "outline",
                  onClick: () => Ba(!0),
                  className: "gap-1.5",
                  "aria-label": "Cover Preview",
                  title: "Cover Preview",
                  children: [
                    e.jsx(Zi, { className: "h-4 w-4" }),
                    e.jsx("span", {
                      className: "hidden sm:inline",
                      children: "Cover Preview",
                    }),
                  ],
                }),
                e.jsxs(u, {
                  variant: "outline",
                  onClick: Gn,
                  disabled: os,
                  className: "gap-1.5",
                  "aria-label": "Preview",
                  title: "Preview",
                  children: [
                    os
                      ? e.jsx(z, { className: "h-4 w-4 animate-spin" })
                      : e.jsx(Zt, { className: "h-4 w-4" }),
                    e.jsx("span", {
                      className: "hidden sm:inline",
                      children: "Preview",
                    }),
                  ],
                }),
                e.jsxs(u, {
                  onClick: Fi,
                  disabled: cs,
                  className: "gap-1.5",
                  "aria-label": "Download the book PDF",
                  title: "Download the book PDF",
                  children: [
                    cs
                      ? e.jsx(z, { className: "h-4 w-4 animate-spin" })
                      : e.jsx(en, { className: "h-4 w-4" }),
                    e.jsxs("span", {
                      className: "hidden sm:inline",
                      children: [
                        "Download",
                        s && !de && J > 0 ? ` (${J} left)` : "",
                      ],
                    }),
                  ],
                }),
              ],
            }),
        ],
      }),
      !qi &&
        !Zs &&
        e.jsxs("div", {
          className:
            "flex flex-wrap items-center justify-between gap-2 border-b bg-muted/40 px-3 py-2 text-sm",
          "data-testid": "book-toolbox-banner",
          children: [
            e.jsx("span", {
              className: "text-muted-foreground",
              children:
                "Previews are unlimited and watermarked. Clean PDF, EPUB and manuscript downloads come with the Book Writing Toolbox.",
            }),
            e.jsx(u, {
              size: "sm",
              onClick: () => V(!0),
              "data-testid": "book-toolbox-banner-cta",
              children: na("trial", "29.99"),
            }),
          ],
        }),
      e.jsxs("div", {
        className: "flex flex-1 min-h-0",
        children: [
          e.jsxs("div", {
            className:
              "hidden md:flex w-64 shrink-0 border-r bg-muted/20 flex-col",
            children: [
              e.jsx("div", {
                className: "flex-1 overflow-y-auto p-2 flex flex-col gap-0.5",
                children: Yi,
              }),
              e.jsx("div", {
                className: "shrink-0 border-t p-2",
                children: e.jsxs(u, {
                  variant: "ghost",
                  size: "sm",
                  className:
                    "w-full justify-start gap-1.5 text-muted-foreground",
                  onClick: () => Ms(!0),
                  children: [e.jsx(Ji, { className: "h-4 w-4" }), "Help & FAQ"],
                }),
              }),
            ],
          }),
          e.jsx("div", {
            className: "flex-1 overflow-y-auto px-4 sm:px-6 py-6 sm:py-8",
            children: e.jsxs("div", {
              className: "max-w-[680px] mx-auto",
              children: [
                !Dt &&
                  e.jsx("h2", {
                    className: "text-lg font-semibold mb-4",
                    children: mr,
                  }),
                e.jsx("div", {
                  style: { fontFamily: bn(pe) },
                  dir: zs,
                  "data-testid": "book-editor-font",
                  "data-book-font": pe,
                  "data-book-direction": zs,
                  children: hr(),
                }),
              ],
            }),
          }),
        ],
      }),
      e.jsx(be, {
        open: Fn,
        onOpenChange: Gt,
        children: e.jsxs(ve, {
          className: "max-w-md",
          children: [
            e.jsxs(we, {
              children: [
                e.jsx(je, { children: "My Books" }),
                e.jsx(Et, {
                  children:
                    "Switch to another saved book, or start a new one. Nothing here is lost when you switch.",
                }),
              ],
            }),
            e.jsxs("div", {
              className: "space-y-1 max-h-[50vh] overflow-y-auto",
              children: [
                Ti.length === 0 &&
                  e.jsx("p", {
                    className: "text-sm text-muted-foreground py-4 text-center",
                    children: "No other saved books yet.",
                  }),
                Ti.map((t) =>
                  e.jsxs(
                    "div",
                    {
                      className: `flex items-center gap-2 rounded-md border p-2.5 ${t.id === q ? "border-primary bg-primary/5" : ""}`,
                      children: [
                        e.jsxs("button", {
                          type: "button",
                          className: "flex-1 min-w-0 text-left",
                          onClick: () => Zn(t.id),
                          children: [
                            e.jsxs("div", {
                              className:
                                "text-sm font-medium truncate flex items-center gap-1.5",
                              children: [
                                t.title,
                                t.id === q &&
                                  e.jsx("span", {
                                    className:
                                      "text-xs font-normal text-primary shrink-0",
                                    children: "(current)",
                                  }),
                              ],
                            }),
                            e.jsxs("div", {
                              className: "text-xs text-muted-foreground",
                              children: ["Edited ", oc(t.updatedAt)],
                            }),
                          ],
                        }),
                        On === t.id
                          ? e.jsxs("div", {
                              className: "flex items-center gap-1 shrink-0",
                              children: [
                                e.jsx(u, {
                                  variant: "destructive",
                                  size: "sm",
                                  className: "h-7 text-xs px-2",
                                  onClick: () => er(t.id),
                                  children: "Delete",
                                }),
                                e.jsx(u, {
                                  variant: "ghost",
                                  size: "sm",
                                  className: "h-7 text-xs px-2",
                                  onClick: () => hs(null),
                                  children: "Cancel",
                                }),
                              ],
                            })
                          : e.jsx(u, {
                              variant: "ghost",
                              size: "icon",
                              className:
                                "h-7 w-7 shrink-0 text-muted-foreground",
                              title: "Delete this book",
                              onClick: () => hs(t.id),
                              children: e.jsx($t, { className: "h-3.5 w-3.5" }),
                            }),
                      ],
                    },
                    t.id,
                  ),
                ),
              ],
            }),
            e.jsx(vt, {
              children: e.jsxs(u, {
                variant: "outline",
                className: "gap-1.5",
                onClick: () => {
                  (Gt(!1), Ri());
                },
                children: [e.jsx(ln, { className: "h-4 w-4" }), "New Book"],
              }),
            }),
          ],
        }),
      }),
      e.jsx(be, {
        open: Mn,
        onOpenChange: Ms,
        children: e.jsxs(ve, {
          className: "max-w-2xl max-h-[85vh] overflow-y-auto",
          children: [
            e.jsxs(we, {
              children: [
                e.jsx(je, { children: "Help & FAQ" }),
                e.jsx(Et, {
                  children:
                    "How to use Book Writing Toolbox, and answers to real questions about publishing platforms, pricing, and privacy.",
                }),
              ],
            }),
            on["book-writing-toolbox"] &&
              e.jsx(Fl, {
                content: on["book-writing-toolbox"],
                toolName: "Book Writing Toolbox",
              }),
            e.jsx(No, { entries: yo("book-writing-toolbox") }),
          ],
        }),
      }),
      e.jsx(be, {
        open: $n,
        onOpenChange: Ba,
        children: e.jsxs(ve, {
          className: "max-w-4xl",
          children: [
            e.jsxs(we, {
              children: [
                e.jsx(je, { children: "Cover Preview" }),
                e.jsx(Et, {
                  children:
                    "How the front cover, spine, and back cover connect together, as a real wraparound cover would.",
                }),
              ],
            }),
            (() => {
              const i = X.width / X.height,
                r = Math.round(380 * i),
                c = r / (X.width / 72);
              let y =
                24 * (va.find((ze) => ze.id === Ht)?.thicknessIn ?? 0.002252);
              try {
                Te && (y = vn(X.width / 72, X.height / 72, Te, Ht).spineIn);
              } catch {}
              const m = Math.max(2, Math.round(y * c)),
                x = !!K,
                E = !!Ae,
                $ = !!Oe,
                fe =
                  Wt.trim() ||
                  `${a}${le.length ? ` — ${le.map((ze) => ze.split(" ").slice(-1)[0]).join(", ")}` : ""}`;
              return e.jsx("div", {
                className: "flex justify-center overflow-x-auto py-4",
                children: e.jsxs("div", {
                  className: "relative flex shadow-2xl",
                  style: { height: 380 },
                  children: [
                    e.jsx("div", {
                      className: "absolute inset-0 z-10 pointer-events-none",
                      style: {
                        backgroundImage: `url("${lc}")`,
                        backgroundRepeat: "repeat",
                      },
                    }),
                    e.jsxs("div", {
                      className:
                        "relative flex flex-col p-4 text-left overflow-hidden",
                      style: {
                        width: r,
                        backgroundImage: E
                          ? `linear-gradient(to bottom, rgba(0,0,0,0.15), rgba(0,0,0,0.55)), url(${Ae})`
                          : void 0,
                        backgroundSize: "cover",
                        backgroundPosition: "center",
                        backgroundColor: E ? void 0 : "#f5f5f0",
                      },
                      children: [
                        e.jsx("p", {
                          className: `text-[10px] leading-snug mt-8 ${E ? "text-white" : "text-neutral-800"}`,
                          children: xe || "Back cover blurb goes here.",
                        }),
                        e.jsxs("div", {
                          className:
                            "mt-auto flex flex-col items-center gap-1.5",
                          children: [
                            e.jsxs("div", {
                              className: "flex items-end justify-center gap-3",
                              children: [
                                oe &&
                                  e.jsx("img", {
                                    src: oe,
                                    alt: "",
                                    className: "bg-white rounded p-1 max-h-16",
                                  }),
                                ge &&
                                  e.jsx("img", {
                                    src: ge,
                                    alt: "",
                                    className: "bg-white rounded p-1 h-12 w-12",
                                  }),
                              ],
                            }),
                            H &&
                              e.jsx("img", {
                                src: H,
                                alt: "",
                                className: "max-h-6",
                              }),
                            R.trim() &&
                              e.jsx("p", {
                                className: `text-[8px] uppercase tracking-wide ${E ? "text-white/90" : "text-neutral-600"}`,
                                children: R.trim(),
                              }),
                          ],
                        }),
                      ],
                    }),
                    e.jsx("div", {
                      className:
                        "relative flex items-center justify-center overflow-hidden border-x border-black/20",
                      style: {
                        width: m,
                        backgroundImage: $
                          ? `linear-gradient(to bottom, rgba(0,0,0,0.15), rgba(0,0,0,0.55)), url(${Oe})`
                          : void 0,
                        backgroundSize: "cover",
                        backgroundPosition: "center",
                        backgroundColor: $ ? void 0 : "#e5e5e0",
                      },
                      children: e.jsxs("p", {
                        className: `text-[9px] font-semibold whitespace-nowrap ${$ ? "text-white" : "text-neutral-800"}`,
                        style: {
                          writingMode: "vertical-rl",
                          transform: "rotate(180deg)",
                        },
                        children: [fe, v ? ` — ${v}` : ""],
                      }),
                    }),
                    e.jsxs("div", {
                      className:
                        "relative flex flex-col items-center justify-center text-center p-4 overflow-hidden",
                      style: {
                        width: r,
                        backgroundImage: x
                          ? `linear-gradient(to bottom, rgba(0,0,0,0.15), rgba(0,0,0,0.55)), url(${K})`
                          : void 0,
                        backgroundSize: "cover",
                        backgroundPosition: "center",
                        backgroundColor: x ? void 0 : "#f5f5f0",
                      },
                      children: [
                        e.jsx("h3", {
                          className: `text-lg font-bold leading-tight ${x ? "text-white" : "text-neutral-900"}`,
                          children: a || "Untitled Book",
                        }),
                        d &&
                          e.jsx("p", {
                            className: `text-xs italic mt-1 ${x ? "text-white/90" : "text-neutral-700"}`,
                            children: d,
                          }),
                        G &&
                          e.jsx("p", {
                            className: `text-xs mt-2 ${x ? "text-white/90" : "text-neutral-700"}`,
                            children: G,
                          }),
                        H &&
                          e.jsx("img", {
                            src: H,
                            alt: "",
                            className: "max-h-6 mt-auto",
                          }),
                        R.trim() &&
                          e.jsx("p", {
                            className: `text-[8px] uppercase tracking-wide ${H ? "" : "mt-auto"} ${x ? "text-white/90" : "text-neutral-600"}`,
                            children: R.trim(),
                          }),
                      ],
                    }),
                  ],
                }),
              });
            })(),
            e.jsxs("p", {
              className: "text-xs text-muted-foreground text-center",
              children: [
                Te
                  ? `Spine drawn to scale for ${Te} interior pages on the paper chosen in the Spine section (KDP's formula). It is only final once the final page count is known.`
                  : "Page count not measured yet, so the spine is drawn at KDP's 24-page minimum. Use Measure page count in the Spine section for the real width.",
                " ",
                "For the print-ready file, use Download print cover in the Spine section.",
              ],
            }),
          ],
        }),
      }),
      e.jsx(be, {
        open: !!$s,
        onOpenChange: (t) => !t && kt(null),
        children: e.jsxs(ve, {
          className: "max-w-3xl h-[85vh] flex flex-col",
          children: [
            e.jsxs(we, {
              className: "flex-row items-center justify-between",
              children: [
                e.jsx(je, { children: "Preview" }),
                e.jsx(u, {
                  size: "icon",
                  variant: "ghost",
                  onClick: () => kt(null),
                  children: e.jsx(js, { className: "h-4 w-4" }),
                }),
              ],
            }),
            $s &&
              e.jsx("iframe", {
                src: $s,
                className: "flex-1 w-full rounded border",
                title: "Book preview",
              }),
          ],
        }),
      }),
      e.jsx(be, {
        open: Yn,
        onOpenChange: (t) => !Jt && fs(t),
        children: e.jsxs(ve, {
          className: "max-w-md",
          "data-testid": "book-erase-dialog",
          children: [
            e.jsxs(we, {
              children: [
                e.jsx(je, {
                  children: "Erase everything and start a new book?",
                }),
                e.jsx(Et, {
                  children:
                    "The current book on this device will be erased: every chapter, cover and imported image, and every book under My Books. This cannot be undone. Nothing is stored on our servers except while your files are being built, so there is no other copy.",
                }),
              ],
            }),
            e.jsxs(vt, {
              className: "gap-2 sm:flex-wrap",
              children: [
                de &&
                  e.jsxs(u, {
                    variant: "outline",
                    onClick: () => {
                      Fi();
                    },
                    disabled: cs || Jt,
                    "data-testid": "book-erase-backup",
                    children: [
                      cs &&
                        e.jsx(z, { className: "h-4 w-4 animate-spin mr-1.5" }),
                      "Download a backup first",
                    ],
                  }),
                e.jsx(u, {
                  variant: "outline",
                  onClick: () => fs(!1),
                  disabled: Jt,
                  children: "Cancel",
                }),
                e.jsxs(u, {
                  variant: "destructive",
                  onClick: () => {
                    Xn();
                  },
                  disabled: Jt,
                  "data-testid": "book-erase-confirm",
                  children: [
                    Jt &&
                      e.jsx(z, { className: "h-4 w-4 animate-spin mr-1.5" }),
                    "Erase everything",
                  ],
                }),
              ],
            }),
          ],
        }),
      }),
      e.jsx(be, {
        open: Ci !== null,
        onOpenChange: (t) => !t && Si(null),
        children: e.jsxs(ve, {
          children: [
            e.jsxs(we, {
              children: [
                e.jsxs(je, { children: ["Sign in to ", Ci] }),
                e.jsx(Et, {
                  children:
                    "Exporting needs an account because your book is built into its final files on our server. Previewing does not need one.",
                }),
              ],
            }),
            e.jsx("p", {
              className: "text-sm text-muted-foreground",
              children:
                "We will take you to the sign-in page (Google or an emailed code) in this tab and bring you straight back here. Your book is kept in this browser tab while you sign in, so your chapters and settings will still be here when you return. Closing the tab clears that copy.",
            }),
            e.jsxs(vt, {
              children: [
                e.jsx(u, {
                  variant: "outline",
                  onClick: () => Si(null),
                  children: "Not now",
                }),
                e.jsx(u, { onClick: tr, children: "Continue to sign-in" }),
              ],
            }),
          ],
        }),
      }),
      e.jsx(be, {
        open: En,
        onOpenChange: V,
        children: e.jsxs(ve, {
          className: "max-w-md",
          "data-testid": "book-toolbox-subscribe",
          showCloseButton: !1,
          children: [
            e.jsx(Hr, {
              "aria-label": "Close",
              "data-testid": "book-toolbox-subscribe-close",
              className:
                "absolute top-3 right-3 flex h-9 w-9 items-center justify-center rounded-full border bg-muted text-foreground hover:bg-accent focus:outline-none focus:ring-2 focus:ring-ring",
              children: e.jsx(js, { className: "h-5 w-5" }),
            }),
            e.jsxs(we, {
              className: "pr-10",
              children: [
                e.jsx(je, { children: "Book Writing Toolbox: $29.99 a month" }),
                e.jsx(Et, {
                  children:
                    "7-day trial, then $29.99 a month. Cancel any time. Clean, watermark-free downloads of your book PDF, EPUB and manuscript are included. Previews stay watermarked. The $1 Day Pass and the $4.99 plan do not cover it.",
                }),
              ],
            }),
            e.jsx(vt, {
              children: e.jsxs(u, {
                onClick: () => {
                  ur();
                },
                disabled: Xs.isPending,
                "data-testid": "book-toolbox-subscribe-btn",
                children: [
                  Xs.isPending &&
                    e.jsx(z, { className: "h-4 w-4 animate-spin mr-1.5" }),
                  na(
                    jo({
                      signedIn: s,
                      entitled: !1,
                      trialEligible: Pe.data?.toolbox.trialEligible ?? !0,
                    }),
                    "29.99",
                  ),
                ],
              }),
            }),
          ],
        }),
      }),
    ],
  });
}
export { Sd as default };
//# sourceMappingURL=BookMaker-0ysxrwOr.js.map
