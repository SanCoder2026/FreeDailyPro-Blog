import { a1 as a } from "./index-B1CTyGtY.js";
function i(r) {
  return r.signedIn
    ? r.entitled
      ? r.hasSubscription
        ? "manage"
        : "open"
      : r.trialEligible === !1
        ? "subscribe"
        : "trial"
    : "trial";
}
function n(r, e) {
  switch (r) {
    case "trial":
      return `Start ${a}-day trial · $${e}/mo`;
    case "subscribe":
      return `Subscribe · $${e}/mo`;
    case "manage":
      return "Manage subscription";
    case "open":
      return "Open";
  }
}
export { i as a, n as w };
//# sourceMappingURL=workflowCta-WWwB7oO9.js.map
