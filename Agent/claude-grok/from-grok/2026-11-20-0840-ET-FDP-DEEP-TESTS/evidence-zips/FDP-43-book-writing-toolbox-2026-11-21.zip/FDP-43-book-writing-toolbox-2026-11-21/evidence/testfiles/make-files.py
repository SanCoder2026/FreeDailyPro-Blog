# Test files for FDP-43 Book Writing Toolbox (guest QA). Run with the venv python (python-docx, Pillow).
from docx import Document; from docx.shared import Pt, RGBColor, Inches
from PIL import Image, ImageDraw
import os
d = Document(); d.add_heading('Chapter One: The Harbour', 1)
p = d.add_paragraph('The tide came in at dawn. '); r = p.add_run('Bold words'); r.bold = True; p.add_run(' and '); r = p.add_run('italic words'); r.italic = True; p.add_run(' sat side by side.')
d.add_paragraph('Second paragraph with an accented name: Zoë Ångström-Łukasiewicz, café, naïve.')
d.add_heading('A sub-heading', 2); d.add_paragraph('First item', style='List Bullet'); d.add_paragraph('Second item', style='List Bullet')
t = d.add_table(rows=2, cols=2); t.cell(0,0).text='Year'; t.cell(0,1).text='Event'; t.cell(1,0).text='1901'; t.cell(1,1).text='Lighthouse built'
img = Image.new('RGB', (1200, 800), (40, 90, 140)); ImageDraw.Draw(img).text((40, 40), 'Interior image 1200x800', fill='white'); img.save('img_interior.png')
d.add_picture('img_interior.png', width=Inches(4)); d.add_paragraph('*  *  *'); d.add_paragraph('After the scene break the story continues. ' * 30)
d.save('C01_chapter.docx')
open('C02_chapter.txt', 'w').write('Chapter Two\n\n' + '\n\n'.join(['Plain text paragraph %d. ' % i + 'The quick brown fox jumps over the lazy dog. ' * 12 for i in range(1, 9)]))
open('C03_chapter.md', 'w').write('# Chapter Three\n\nSome **bold** markdown.\n')
open('C04_cjk.txt', 'w').write('第一章\n\n这是一个测试。日本語のテキスト。한국어 텍스트.\n')
open('C05_arabic.txt', 'w').write('الفصل الأول\n\n' + 'كان الصباح باردا في المدينة القديمة. ' * 20 + '\n')
open('C06_long.txt', 'w').write('\n\n'.join(['Long paragraph %d. ' % i + 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. ' * 20 for i in range(1, 400)]))
c = Image.new('RGB', (1800, 2700), (180, 40, 40)); ImageDraw.Draw(c).text((100, 100), 'FRONT COVER 1800x2700', fill='white'); c.save('cover_front_hi.jpg', quality=90)
Image.new('RGB', (300, 450), (30, 120, 60)).save('cover_front_lo.jpg', quality=85)
Image.new('RGB', (1800, 2700), (40, 40, 160)).save('cover_back.jpg', quality=85)
open('P01_not_a_project.json', 'w').write('{"hello": "world"}')
print(sorted(os.listdir('.')))
# Added for the import-splitting cases (C07/C08 were generated with the same python-docx calls):
#   C07_three_h1.docx: three Heading 1 chapters; C08_chapter_lines.txt: "Chapter 1", "Chapter Two: The Fog", "Chapter 3 - The End" lines.
