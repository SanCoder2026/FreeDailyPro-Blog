# FDP-43: inspect preview files this browser received (no execution). Writes live/verify.json.
# PDF: page count, page size, whether the watermark is text (pdftotext finds "PREVIEW") or a background tiling pattern, fonts embedded.
# DOCX: where "PREVIEW" appears (header vs body). JSON 500s for EPUB are counted.
import glob, json, os, re, subprocess, zipfile, pikepdf
B = '/workspace/deep/43-book-writing-toolbox/live/'; out = []
for f in sorted(glob.glob(B + 'responses/*') + glob.glob(B + 'downloads/*')):
    r = {'file': f.replace(B, '')}
    if f.endswith('.pdf'):
        p = pikepdf.open(f); r['pages'] = len(p.pages); mb = p.pages[0].MediaBox; r['size_pt'] = [round(float(mb[2]), 1), round(float(mb[3]), 1)]
        txt = subprocess.run(['pdftotext', f, '-'], capture_output=True, text=True).stdout; r['preview_in_text'] = 'PREVIEW' in txt.upper()
        r['tiling_pattern_pages'] = sum(1 for pg in p.pages if any(v.get('/PatternType') == 1 for v in (pg.Resources.get('/Pattern') or {}).values()))
        fonts = subprocess.run(['pdffonts', f], capture_output=True, text=True).stdout.splitlines()[2:]; r['fonts_embedded'] = all(l.split()[-5] == 'yes' for l in fonts if len(l.split()) > 5)
    elif f.endswith('.docx'):
        z = zipfile.ZipFile(f); r['watermark_parts'] = [n for n in z.namelist() if n.endswith('.xml') and re.search(rb'PREVIEW', z.read(n))]
        r['body_has_watermark'] = 'word/document.xml' in r['watermark_parts']
    elif f.endswith('.json') and 'renderEpub' in f:
        r['epub_error'] = json.load(open(f))[0]['error']['json']['data']['httpStatus']
    else: r['bytes'] = os.path.getsize(f)
    out.append(r)
json.dump(out, open(B + 'verify.json', 'w'), indent=1)
print(sum(1 for r in out if r.get('epub_error') == 500), 'EPUB 500s;', [r for r in out if r['file'].endswith(('.pdf', '.docx'))][:3])
