# Watermark robustness check on a PREVIEW file this browser received (analysis only; the result is kept as evidence and is not distributed).
# PDF: is the watermark text/annotation/pattern, and does neutralising the pattern leave the book intact? DOCX/EPUB: where does the watermark live?
import sys, re, zipfile, pikepdf
f = sys.argv[1]; out = sys.argv[2]
if f.endswith('.pdf'):
    p = pikepdf.open(f); n = 0
    for pg in p.pages:
        pats = pg.Resources.get('/Pattern') or {}
        for k in list(pats.keys()):
            if pats[k].get('/PatternType') == 1:
                s = pikepdf.Stream(p, b''); pats[k].write(b'')  # empty tile = nothing drawn
                n += 1
    p.save(out); print('pdf tiling patterns emptied:', n)
else:
    z = zipfile.ZipFile(f)
    for name in z.namelist():
        if re.search(r'\.(xml|xhtml|html|css|opf|ncx)$', name):
            t = z.read(name).decode('utf8', 'ignore')
            hits = [m.start() for m in re.finditer(r'(?i)preview|watermark', t)]
            if hits: print(name, len(hits), [t[max(0, h-120):h+120].replace('\n', ' ') for h in hits[:2]])
