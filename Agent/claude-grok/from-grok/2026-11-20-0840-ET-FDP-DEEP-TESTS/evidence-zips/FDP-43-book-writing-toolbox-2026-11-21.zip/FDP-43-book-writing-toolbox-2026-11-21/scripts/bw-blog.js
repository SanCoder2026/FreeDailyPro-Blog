// Rendered text of /blog/book-writing-toolbox (guest) for the accuracy check, plus a top screenshot.
const { chromium } = require('playwright'); const fs = require('fs'); const D = '/workspace/deep/43-book-writing-toolbox/';
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage();
 const r = await p.goto('https://www.freedailypro.com/blog/book-writing-toolbox', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000);
 const t = await p.evaluate(() => (document.querySelector('article') || document.querySelector('main')).innerText); fs.writeFileSync(D + 'curl/blog-rendered.txt', t);
 fs.writeFileSync(D + 'live/blog-render.json', JSON.stringify({ status: r.status(), title: await p.title(), chars: t.length, roots: await p.evaluate(() => document.querySelectorAll('#root').length) }, null, 1));
 await p.screenshot({ path: D + 'live/blog-top.png' }); console.log(r.status(), t.length); await b.close(); })();
