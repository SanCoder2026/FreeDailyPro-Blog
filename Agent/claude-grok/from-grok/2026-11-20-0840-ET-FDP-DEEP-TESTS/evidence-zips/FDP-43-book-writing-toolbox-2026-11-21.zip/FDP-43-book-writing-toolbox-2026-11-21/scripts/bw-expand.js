// Book Writing Toolbox: save page text (accordions below the editor expanded), JSON-LD, links. Guest, no edits.
const { chromium } = require('playwright'); const fs = require('fs'); const D='/workspace/deep/43-book-writing-toolbox/';
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); p.setDefaultTimeout(3000);
 await p.goto('https://www.freedailypro.com/tool/book-writing-toolbox', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(6000);
 const t0 = await p.evaluate(() => document.querySelector('main').innerText); fs.writeFileSync(D+'tool-visible.txt', t0);
 // only accordions in sections whose heading looks like FAQ / About / How
 let n=0; for (const name of ['About Book Writing Toolbox','Common questions','Details: when to use it, limits, privacy','Guides and next steps']) { await p.getByRole('button',{name, exact:true}).click().catch(()=>{}); n++; await p.waitForTimeout(600); }
 for (let k=0;k<2;k++){ const m = await p.evaluate(() => { let c=0; const sec=[...document.querySelectorAll('main button')].find(b=>b.innerText.trim()==='About Book Writing Toolbox'); const root=sec? sec.parentElement.parentElement.parentElement : null; if(!root) return -1; root.querySelectorAll('button[aria-expanded=false]').forEach(b=>{b.click();c++}); return c; }); n+=m; await p.waitForTimeout(800);} 
 await p.waitForTimeout(1500);
 const t = await p.evaluate(() => document.querySelector('main').innerText); fs.writeFileSync(D+'tool-expanded.txt', t);
 const ld = await p.evaluate(() => [...document.querySelectorAll('script[type="application/ld+json"]')].map(s => { try { return JSON.parse(s.textContent) } catch (e) { return s.textContent } }));
 fs.writeFileSync(D+'tool-expanded.txt.jsonld.json', JSON.stringify(ld, null, 1));
 const links = await p.evaluate(() => [...document.querySelectorAll('main a')].map(a => a.getAttribute('href') + ' | ' + a.innerText.trim().slice(0, 80)));
 fs.writeFileSync(D+'tool-links.txt', links.join('\n'));
 await p.getByRole('button',{name:'Help & FAQ',exact:true}).click().catch(()=>{}); await p.waitForTimeout(1500); fs.writeFileSync(D+'help-faq.txt', await p.evaluate(() => document.querySelector('main').innerText)); await p.screenshot({path:D+'live/help-faq.png'});
 const btns = await p.evaluate(() => [...document.querySelectorAll('main button, main [role=combobox], main input, main select')].map(x => (x.tagName+' '+(x.getAttribute('aria-label')||x.innerText||x.placeholder||x.type||'')).trim().slice(0,60)));
 fs.writeFileSync(D+'controls.txt', btns.join('\n'));
 console.log(n, t0.length, t.length, ld.length, btns.length); await b.close(); })();
