// FDP-43 Book Writing Toolbox live cases (guest, no sign-in). Usage: node bw-live.js [chromium|firefox|webkit] [ids comma list]
// Captures: counter after each step, dialogs, downloads, and the preview files returned to this browser by its own render requests (tRPC response bodies).
// Stops at the sign-in dialog ("Not now"); never clicks "Continue to sign-in", never types an email/card.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/43-book-writing-toolbox/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/book-writing-toolbox';
const engName = process.argv[2] || 'chromium'; const only = process.argv[3] ? process.argv[3].split(',') : null; const sfx = engName === 'chromium' ? '' : '-' + engName;
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
fs.mkdirSync(OUT + 'downloads', { recursive: true }); fs.mkdirSync(OUT + 'responses', { recursive: true }); fs.mkdirSync(OUT + 'cases', { recursive: true });
(async () => { const b = await pw[engName].launch(); const R = { t: now(), engine: engName, cases: {} };
 let c, p, net = [], resp = 0;
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); p = await c.newPage(); p.setDefaultTimeout(10000); net = [];
  p.on('request', r => { const u = r.url(); if (/\/api\/trpc\/(?!insight|funnel)/.test(u)) net.push({ t: Date.now(), m: r.method(), u: u.split('?')[0].replace(/.*\/api\/trpc\//, ''), len: (r.postData() || '').length }); });
  p.on('response', async r => { const u = r.url(); if (/bookMaker\.render/.test(u) && r.request().method() === 'POST') { try { const j = await r.json(); const s = JSON.stringify(j); resp++; const name = u.split('?')[0].replace(/.*trpc\//, '').replace(/[^\w.]/g, '_');
     const m = s.match(/"(pdfBase64|docxBase64|epubBase64)":"([A-Za-z0-9+\/=]+)"/); const pv = (r.request().postData() || '').match(/"preview":(true|false)/);
     if (m) { const ext = m[1].replace('Base64', ''); const f = `${OUT}responses/${engName}-${resp}-${name}-preview_${pv ? pv[1] : 'na'}.${ext}`; fs.writeFileSync(f, Buffer.from(m[2], 'base64')); }
     else fs.writeFileSync(`${OUT}responses/${engName}-${resp}-${name}.json`, s.slice(0, 20000)); } catch (e) {} } });
  await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(6000); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return `${u.usageToday}/${u.limit}`; }).catch(() => '?');
 const dialog = async () => { const d = p.locator('[role=dialog]:visible,[role=alertdialog]:visible'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 600) : null; };
 const toasts = async () => (await p.locator('[data-sonner-toast]').allInnerTexts().catch(() => [])).map(x => x.replace(/\s*\n\s*/g, ' ')).slice(-4);
 const sec = async n => { await p.getByRole('button', { name: n, exact: true }).first().click(); await p.waitForTimeout(800); };
 const btn = async (n, i = 0) => { await p.getByRole('button', { name: n, exact: true }).nth(i).click(); };
 const dl = async (fn, prefix, wait = 60000) => { const dp = p.waitForEvent('download', { timeout: wait }).catch(() => null); await fn(); const d = await dp; if (!d) return null; const f = OUT + 'downloads/' + prefix + '-' + d.suggestedFilename(); await d.saveAs(f); return { file: f.replace(BASE, ''), name: d.suggestedFilename(), size: fs.statSync(f).size }; };
 const write = async (text) => { const ed = p.locator('.ProseMirror').first(); await ed.click(); await p.keyboard.press('Control+A'); await p.keyboard.type(text); await p.waitForTimeout(600); };
 const setTitle = async (t, a) => { await sec('Title Page'); await p.getByLabel('Book title').fill(t); if (a) { await sec('Authors'); const i = p.locator('main input[type=text]:visible').first(); await i.fill(a).catch(() => {}); } };
 const chapter = async (text) => { await p.locator('button[title="Add a chapter"]').click(); await p.waitForTimeout(1000); await write(text); };
 const shot = async id => { await p.screenshot({ path: `${OUT}cases/${id}${sfx}.png` }); };
 const run = async (id, desc, fn) => { if (only && !only.includes(id)) return; const r = { desc, t: now() }; try { await open(); r.used0 = await used(); Object.assign(r, (await fn()) || {}); } catch (e) { r.err = e.message.slice(0, 300); }
  try { r.used1 = await used(); r.toasts = await toasts(); r.net = net.map(x => x.m + ' ' + x.u + (x.len ? ' (' + x.len + 'B)' : '')); await shot(id); } catch (e) {} R.cases[id] = r; console.log(id, JSON.stringify(r).slice(0, 400)); await c.close(); };
 const TEXT = 'It was a bright cold day in April, and the clocks were striking thirteen. ' + 'The harbour lights came on one by one as the fog rolled in from the sea. '.repeat(8);

 await run('B01', 'Write a chapter, Preview (top bar): what opens, is it watermarked, counter', async () => {
  await setTitle('The Harbour Test', 'Sam Tester'); await chapter(TEXT); const t0 = Date.now(); await btn('Preview'); await p.waitForTimeout(12000);
  const frames = await p.evaluate(() => [...document.querySelectorAll('iframe,embed,object')].map(x => (x.src || x.data || '').slice(0, 30))); return { frames, dialog: await dialog(), ms: Date.now() - t0 }; });
 await run('B02', 'Preview twice + Pre-flight: per-render charging?', async () => {
  await chapter(TEXT); await btn('Preview'); await p.waitForTimeout(9000); await p.keyboard.press('Escape'); const u1 = await used(); await btn('Preview'); await p.waitForTimeout(9000); await p.keyboard.press('Escape'); const u2 = await used();
  await sec('Pre-flight Check'); await btn('Run Pre-flight Check'); await p.waitForTimeout(20000); const t = await p.evaluate(() => document.querySelector('main').innerText); const i = t.indexOf('Run Pre-flight Check');
  return { afterPreview1: u1, afterPreview2: u2, preflight: t.slice(i, i + 2500) }; });
 await run('B03', 'Download (top bar) as guest: what gate shows; then Start trial -> stop at sign-in', async () => {
  await chapter(TEXT); await btn('Download the book PDF').catch(() => p.getByRole('button', { name: 'Download' }).first().click()); await p.waitForTimeout(2500); const d1 = await dialog(); await shot('B03a');
  let d2 = null; const sb = p.locator('[data-testid=book-toolbox-subscribe-btn]'); if (await sb.count()) { await sb.click(); await p.waitForTimeout(3000); d2 = await dialog(); await shot('B03b'); }
  const url = p.url().replace(/[?#].*/, ''); const nn = p.getByRole('button', { name: 'Not now' }); if (await nn.count()) await nn.click().catch(() => {}); await p.keyboard.press('Escape'); return { dialogDownload: d1, dialogAfterTrial: d2, urlAfter: url }; });
 await run('B04', 'Start 7-day trial strip button as guest', async () => {
  await btn('Start 7-day trial · $29.99/mo'); await p.waitForTimeout(3000); const d = await dialog(); const url = p.url().replace(/[?#].*/, ''); await shot('B04a'); const nn = p.getByRole('button', { name: 'Not now' }); if (await nn.count()) await nn.click().catch(() => {}); return { dialog: d, url }; });
 await run('B05', 'Manuscript Format: previews (.docx, .pdf) and Export buttons', async () => {
  await setTitle('The Harbour Test', 'Sam Tester'); await chapter(TEXT); await sec('Manuscript Format'); await p.getByLabel('Your real legal name').fill('Samuel Q. Tester');
  const a = await dl(() => btn('Preview', 1), 'B05-docx'); await p.waitForTimeout(1500); const b2 = await dl(() => btn('Preview', 2), 'B05-pdf'); await p.waitForTimeout(1500);
  await btn('Export Manuscript (.docx)'); await p.waitForTimeout(2000); const d = await dialog(); await p.keyboard.press('Escape'); return { previewDocx: a, previewPdf: b2, exportDialog: d }; });
 await run('B06', 'EPUB: Preview EPUB (watermarked) and Export', async () => {
  await setTitle('The Harbour Test', 'Sam Tester'); await chapter(TEXT); await sec('EPUB'); const a = await dl(() => btn('Preview EPUB (watermarked)'), 'B06'); await p.waitForTimeout(1500);
  await btn('Export EPUB (.epub)'); await p.waitForTimeout(2000); const d = await dialog(); await p.keyboard.press('Escape'); return { previewEpub: a, exportDialog: d }; });
 await run('B07', 'Covers: upload front/back, Cover Preview, Spine measure + Preview print cover + Download print cover', async () => {
  await setTitle('The Harbour Test', 'Sam Tester'); await chapter(TEXT);
  await sec('Front Cover'); await p.locator('main input[type=file][accept="image/*"]:visible, main input[type=file][accept="image/*"]').first().setInputFiles(TF + 'cover_front_hi.jpg').catch(e => null); await p.waitForTimeout(2000); await shot('B07a');
  await sec('Back Cover'); await p.getByLabel('Back cover blurb').fill('A gripping tale of fog and light.').catch(() => {});
  await btn('Cover Preview'); await p.waitForTimeout(4000); await shot('B07b'); const dcp = await dialog(); await p.keyboard.press('Escape');
  await sec('Spine'); await btn('Measure page count'); await p.waitForTimeout(12000); const tm = await toasts(); await btn('Preview print cover'); await p.waitForTimeout(15000); await shot('B07c');
  await btn('Download print cover (PDF)'); await p.waitForTimeout(2500); const d = await dialog(); await p.keyboard.press('Escape'); return { coverPreviewDialog: dcp, measureToasts: tm, downloadDialog: d }; });
 await run('B08', 'Import chapters: .docx, .txt, then .md (not in accept list)', async () => {
  const inp = p.locator('#chapter-import-input'); await inp.setInputFiles(TF + 'C01_chapter.docx'); await p.waitForTimeout(4000); const t1 = await toasts(); await shot('B08a');
  await inp.setInputFiles(TF + 'C02_chapter.txt'); await p.waitForTimeout(3000); const t2 = await toasts();
  await inp.setInputFiles(TF + 'C03_chapter.md'); await p.waitForTimeout(3000); const t3 = await toasts(); const side = await p.evaluate(() => document.querySelector('main').innerText.match(/Index[\s\S]{0,40}|Chapter[^\n]*/g));
  await btn('Preview'); await p.waitForTimeout(12000); await shot('B08b'); return { docx: t1, txt: t2, md: t3, side }; });
 await run('B09', 'CJK text in a chapter: Preview blocked with named-script message?', async () => {
  await chapter('第一章 这是一个测试。日本語のテキスト。한국어 텍스트. Some Latin too.'); await btn('Preview'); await p.waitForTimeout(6000); return { dialog: await dialog() }; });
 await run('B10', 'Arabic chapter with Right to left: Preview renders', async () => {
  await chapter('كان الصباح باردا في المدينة القديمة. '.repeat(15)); await p.getByRole('button', { name: 'Reading direction' }).click().catch(() => {}); await p.getByRole('option', { name: 'Right to left' }).click().catch(() => {}); await p.waitForTimeout(500);
  await btn('Preview'); await p.waitForTimeout(12000); return { dialog: await dialog() }; });
 await run('B11', 'Save book project, ONIX export, then Open project in a fresh context; invalid project file', async () => {
  await setTitle('The Harbour Test', 'Sam Tester'); await chapter(TEXT); const s = await dl(() => p.getByRole('button', { name: 'Save book project' }).click(), 'B11-save', 15000);
  await sec('Publishing Metadata'); const o = await dl(() => btn('Export ONIX (.xml)'), 'B11-onix', 15000);
  await c.close(); await open(); const inp = p.locator('input[type=file][accept=".json,application/json"]').first(); if (s) { await inp.setInputFiles(BASE + s.file); await p.waitForTimeout(3000); }
  const t1 = await toasts(); const d1 = await dialog(); if (d1) { await shot('B11a'); const ok = p.locator('[role=dialog] button').filter({ hasText: /Open|Replace|Continue|Load/ }); if (await ok.count()) await ok.first().click(); await p.waitForTimeout(2000); }
  const title = await p.evaluate(() => document.querySelector('main').innerText.match(/The Harbour Test/) ? 'restored' : 'not restored');
  await inp.setInputFiles(TF + 'P01_not_a_project.json').catch(() => {}); await p.waitForTimeout(2500); return { save: s, onix: o, openToasts: t1, openDialog: d1, title, badFile: await toasts() }; });
 await run('B12', 'Ebook-only platform hides print sections; trim list per platform', async () => {
  const pf = p.getByRole('button', { name: /Use default/ }).first(); await pf.click(); await p.waitForTimeout(800); const opts = await p.locator('[role=option]').allInnerTexts(); await shot('B12a');
  const eb = p.locator('[role=option]').filter({ hasText: /Draft2Digital|ebook/i }).first(); if (await eb.count()) await eb.click(); await p.waitForTimeout(1500);
  const side = await p.evaluate(() => [...document.querySelectorAll('main button')].map(x => x.innerText.trim()).filter(x => /Spine|Back Cover|Front Cover|EPUB|Manuscript/.test(x))); return { platforms: opts, sidebarAfterEbook: side }; });
 await run('B13', 'Long book (400 paragraphs): Preview time and page count', async () => {
  await chapter('x'); const ed = p.locator('.ProseMirror').first(); await ed.click(); await p.keyboard.press('Control+A');
  await p.evaluate(t => { const dt = new DataTransfer(); dt.setData('text/plain', t); document.querySelector('.ProseMirror').dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true })); }, fs.readFileSync(TF + 'C06_long.txt', 'utf8'));
  await p.waitForTimeout(2000); const t0 = Date.now(); await btn('Preview'); let ok = false; for (let i = 0; i < 60 && !ok; i++) { await p.waitForTimeout(1000); ok = await p.evaluate(() => !!document.querySelector('iframe[src^="blob:"],embed[src^="blob:"]')); } return { renderedMs: ok ? Date.now() - t0 : null }; });
 await run('B14', 'Clear everything + My Books', async () => {
  await setTitle('Book A', ''); await chapter(TEXT); await p.getByRole('button', { name: 'Clear everything' }).click(); await p.waitForTimeout(1200); const d = await dialog(); await shot('B14a'); await p.keyboard.press('Escape');
  const lib = p.locator('button[title*="My Books"], button[aria-label*="My Books"]'); let d2 = null; if (await lib.count()) { await lib.first().click(); await p.waitForTimeout(1200); d2 = await dialog(); await shot('B14b'); await p.keyboard.press('Escape'); }
  return { clearDialog: d, myBooks: d2 }; });
 R.end = now(); fs.writeFileSync(`${OUT}cases-${engName}${only ? '-subset' : ''}.json`, JSON.stringify(R, null, 1)); await b.close(); })();
