// FDP-43 follow-up cases (guest). Fixes from run 1: Radix selects are role=combobox; a modal preview hides the page from getByRole, so close it first.
// Usage: node bw-live2.js [chromium|firefox|webkit] [ids]. Never clicks "Continue to sign-in" or the subscribe/trial button.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/43-book-writing-toolbox/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/book-writing-toolbox';
const engName = process.argv[2] || 'chromium'; const only = process.argv[3] ? process.argv[3].split(',') : null; const sfx = engName === 'chromium' ? '' : '-' + engName;
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await pw[engName].launch(); const R = { t: now(), engine: engName, cases: {} }; let c, p, net = [], resp = 0;
 const open = async (ctx) => { c = ctx || await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); p = await c.newPage(); p.setDefaultTimeout(10000); net = [];
  p.on('request', r => { const u = r.url(); if (/\/api\/trpc\/(?!insight|funnel)/.test(u)) net.push(r.method() + ' ' + u.split('?')[0].replace(/.*\/api\/trpc\//, '')); });
  p.on('response', async r => { const u = r.url(); if (/bookMaker\.render/.test(u) && r.request().method() === 'POST') { try { const s = await r.text(); resp++; const name = u.split('?')[0].replace(/.*trpc\//, '').replace(/[^\w.]/g, '_');
   const m = s.match(/"(pdfBase64|docxBase64|epubBase64)":"([A-Za-z0-9+\/=]+)"/); const pv = (r.request().postData() || '').match(/"preview":(true|false)/);
   if (m) fs.writeFileSync(`${OUT}responses/r2-${engName}-${resp}-${name}-preview_${pv ? pv[1] : 'na'}.${m[1].replace('Base64', '')}`, Buffer.from(m[2], 'base64'));
   else fs.writeFileSync(`${OUT}responses/r2-${engName}-${resp}-${name}-status${r.status()}.json`, s.slice(0, 5000)); } catch (e) {} } });
  await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(6000); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return `${u.usageToday}/${u.limit}`; }).catch(() => '?');
 const dialog = async () => { const d = p.locator('[role=dialog]:visible,[role=alertdialog]:visible'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 600) : null; };
 const closeDlg = async () => { for (let i = 0; i < 2; i++) { if (await p.locator('[role=dialog]:visible').count()) { await p.keyboard.press('Escape'); await p.waitForTimeout(500); } } };
 const toasts = async () => (await p.locator('[data-sonner-toast]').allInnerTexts().catch(() => [])).map(x => x.replace(/\s*\n\s*/g, ' ').slice(0, 400)).slice(-4);
 const sec = async n => { await p.getByRole('button', { name: n, exact: true }).first().click(); await p.waitForTimeout(800); };
 const btn = async (n, i = 0) => { await p.getByRole('button', { name: n, exact: true }).nth(i).click(); };
 const combo = async (cur, opt) => { await p.getByRole('combobox').filter({ hasText: cur }).first().click(); await p.waitForTimeout(600); const opts = await p.getByRole('option').allInnerTexts(); if (opt) await p.getByRole('option').filter({ hasText: opt }).first().click(); else await p.keyboard.press('Escape'); await p.waitForTimeout(800); return opts; };
 const dl = async (fn, prefix, wait = 60000) => { const dp = p.waitForEvent('download', { timeout: wait }).catch(() => null); await fn(); const d = await dp; if (!d) return null; const f = OUT + 'downloads/' + prefix + '-' + d.suggestedFilename(); await d.saveAs(f); return { file: f.replace(BASE, ''), size: fs.statSync(f).size }; };
 const chapter = async (text) => { await p.locator('button[title="Add a chapter"]').click(); await p.waitForTimeout(1000); const ed = p.locator('.ProseMirror').first(); await ed.click(); await p.keyboard.press('Control+A'); await p.keyboard.type(text); await p.waitForTimeout(600); };
 const title = async t => { await sec('Title Page'); await p.getByLabel('Book title').fill(t); };
 const sidebar = () => p.evaluate(() => [...document.querySelectorAll('main input, main button')].map(x => (x.value || x.innerText || '').trim()).filter(t => /^(Chapter|The |Front|Spine|Back Cover|Manuscript|EPUB|C0)/.test(t)));
 const shot = async id => { await p.screenshot({ path: `${OUT}cases/${id}${sfx}.png` }); };
 const run = async (id, desc, fn) => { if (only && !only.includes(id)) return; const r = { desc, t: now() }; try { await open(); r.used0 = await used(); Object.assign(r, (await fn()) || {}); } catch (e) { r.err = e.message.slice(0, 300); }
  try { r.used1 = await used(); r.toasts = r.toasts || await toasts(); r.net = net; await shot(id); } catch (e) {} R.cases[id] = r; console.log(id, (r.err || 'ok')); await c.close(); };
 const TEXT = 'It was a bright cold day in April, and the clocks were striking thirteen. ' + 'The harbour lights came on one by one as the fog rolled in from the sea. '.repeat(8);

 await run('C01', 'Preview on screen (which viewer, watermark visible) + Preview EPUB twice', async () => {
  await title('The Harbour Test'); await chapter(TEXT); await btn('Preview'); await p.waitForTimeout(12000); await shot('C01a'); const d = await dialog(); await closeDlg();
  await sec('EPUB'); const e1 = await dl(() => btn('Preview EPUB (watermarked)'), 'C01-epub1', 45000); const t1 = await toasts(); await p.waitForTimeout(3000); const e2 = await dl(() => btn('Preview EPUB (watermarked)'), 'C01-epub2', 45000);
  return { previewDialog: d, epub1: e1, epub1Toasts: t1, epub2: e2, toasts: await toasts() }; });
 await run('C02', 'Manuscript exports and print-cover download as guest (gates)', async () => {
  await title('The Harbour Test'); await chapter(TEXT); await sec('Manuscript Format'); await p.getByLabel('Your real legal name').fill('Samuel Q. Tester');
  await btn('Export Manuscript (.docx)'); await p.waitForTimeout(2000); const d1 = await dialog(); await shot('C02a'); await closeDlg();
  await btn('Export Manuscript (.pdf)'); await p.waitForTimeout(2000); const d2 = await dialog(); await closeDlg();
  await sec('Spine'); await btn('Download print cover (PDF)'); await p.waitForTimeout(2000); const d3 = await dialog(); await closeDlg();
  await sec('EPUB'); await btn('Export EPUB (.epub)'); await p.waitForTimeout(2000); const d4 = await dialog(); await closeDlg(); return { manuscriptDocx: d1, manuscriptPdf: d2, printCover: d3, epub: d4 }; });
 await run('C03', 'Platforms and trims; Ebook only hides print sections', async () => {
  const plat = await combo('Use default', null); const trimsDefault = await combo('6 x 9 in', null);
  await combo('Use default', 'IngramSpark'); const trimsIngram = await combo('6 x 9', null); const isbnNote = await p.evaluate(() => (document.querySelector('main').innerText.match(/IngramSpark doesn.t offer[^\n]*/) || [''])[0]);
  const plat2 = await p.getByRole('combobox').first().innerText(); await p.getByRole('combobox').first().click(); await p.waitForTimeout(500); const eb = p.getByRole('option').filter({ hasText: /Draft2Digital|Apple|Kobo|ebook/i }).first(); const ebName = await eb.innerText().catch(() => null); if (ebName) await eb.click(); await p.waitForTimeout(1500);
  const side = await p.evaluate(() => [...document.querySelectorAll('main button')].map(x => x.innerText.trim()).filter(x => /^(Spine|Back Cover|Front Cover|EPUB|Manuscript Format|Pre-flight Check)$/.test(x)));
  const mode = await p.getByRole('combobox').filter({ hasText: /Print \+ Ebook|Ebook only/ }).first().innerText().catch(() => '?'); return { platforms: plat, trimsDefault: trimsDefault.length, trimsIngram: trimsIngram.length, trimsIngramList: trimsIngram, isbnNote, ebookPlatform: ebName, sidebarAfterEbook: side, mode }; });
 await run('C04', 'Arabic chapter + Right to left: Preview', async () => {
  await title('اختبار'); await chapter('كان الصباح باردا في المدينة القديمة. '.repeat(15)); await p.getByLabel('Reading direction').click(); await p.waitForTimeout(600); const dir = await p.getByRole('option').allInnerTexts(); await p.getByRole('option').filter({ hasText: 'Right to left' }).first().click(); await p.waitForTimeout(800); await btn('Preview'); await p.waitForTimeout(12000); const d = await dialog(); await closeDlg(); return { dirOptions: dir, dialog: d }; });
 await run('C05', 'Persistence: reload keeps chapter; My Books; project file open (valid + invalid) status text', async () => {
  await title('Persist Test'); await chapter('Persistence check paragraph unique-7731.'); await p.waitForTimeout(2500); await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(6000);
  const kept = await p.evaluate(() => document.body.innerText.includes('Persist Test')); const kept2 = await p.evaluate(() => [...document.querySelectorAll('.ProseMirror')].some(e => e.innerText.includes('unique-7731')));
  let books = null; const lib = p.locator('button[title^="My Books"]'); if (await lib.count()) { await lib.first().click(); await p.waitForTimeout(1200); books = await dialog(); await shot('C05a'); await closeDlg(); }
  const inp = p.locator('input[type=file][accept=".json,application/json"]').first(); await inp.setInputFiles(TF + 'P01_not_a_project.json'); await p.waitForTimeout(2000);
  const status = await p.evaluate(() => [...document.querySelectorAll('[data-testid=book-project-bar], [data-testid=book-project-bar] ~ *')].map(x => x.parentElement.innerText).join(' ').slice(0, 400));
  return { titleKeptAfterReload: kept, chapterKeptAfterReload: kept2, myBooks: books, invalidProjectStatus: status }; });
 await run('C06', 'Import splitting: .docx with 3 Heading 1, .txt with Chapter lines', async () => {
  const inp = p.locator('#chapter-import-input'); await inp.setInputFiles(TF + 'C07_three_h1.docx'); await p.waitForTimeout(4000); const t1 = await toasts();
  await inp.setInputFiles(TF + 'C08_chapter_lines.txt'); await p.waitForTimeout(4000); const t2 = await toasts();
  const chapters = await p.evaluate(() => [...document.querySelectorAll('main input')].map(i => i.value).filter(Boolean)); await shot('C06a'); return { docx: t1, txt: t2, chapterInputs: chapters }; });
 await run('C07', 'Covers: low-res front -> Pre-flight; hi-res front + back -> Pre-flight; Cover Preview dialog', async () => {
  await title('Cover Test'); await chapter(TEXT); await sec('Front Cover'); await p.locator('main input[type=file][accept="image/*"]').first().setInputFiles(TF + 'cover_front_lo.jpg'); await p.waitForTimeout(2500); await shot('C07a');
  await sec('Pre-flight Check'); await btn('Run Pre-flight Check'); await p.waitForTimeout(20000); const t = await p.evaluate(() => document.querySelector('main').innerText); const i = t.indexOf('Cover image resolution'); const lo = t.slice(i, i + 300);
  const ep = t.slice(t.indexOf('EPUB', t.indexOf('Interior image')), t.indexOf('EPUB', t.indexOf('Interior image')) + 800);
  await sec('Front Cover'); await p.locator('main input[type=file][accept="image/*"]').first().setInputFiles(TF + 'cover_front_hi.jpg'); await p.waitForTimeout(2500);
  await btn('Cover Preview'); await p.waitForTimeout(3000); const cp1 = await dialog(); await shot('C07b'); await closeDlg();
  await sec('Pre-flight Check'); await btn('Run Pre-flight Check'); await p.waitForTimeout(20000); const t2 = await p.evaluate(() => document.querySelector('main').innerText); const j = t2.indexOf('Cover image resolution');
  return { lowRes: lo, epubSection: ep, coverPreview: cp1, hiRes: t2.slice(j, j + 300), preflightFull: t2.slice(t2.indexOf('Run Pre-flight Check'), t2.indexOf('Run Pre-flight Check') + 3000) }; });
 await run('C08', 'Context with trial uses left: Preview, manuscript preview, Pre-flight, ONIX: does the counter move?', async () => {
  let tries = 0; while ((await used()).startsWith('10/') && tries < 12) { await c.close(); await open(); tries++; } const start = await used(); if (start.startsWith('10/')) return { note: 'no context with uses left after ' + tries + ' tries' };
  await title('Count Test'); await chapter(TEXT); await btn('Preview'); await p.waitForTimeout(10000); await closeDlg(); const a = await used();
  await sec('Manuscript Format'); await p.getByLabel('Your real legal name').fill('Samuel Q. Tester'); await dl(() => btn('Preview', 1), 'C08-ms', 30000); await p.waitForTimeout(2000); const bb = await used();
  await sec('Pre-flight Check'); await btn('Run Pre-flight Check'); await p.waitForTimeout(18000); const cc = await used();
  await sec('Publishing Metadata'); await dl(() => btn('Export ONIX (.xml)'), 'C08-onix', 10000); const dd = await used(); await p.reload(); await p.waitForTimeout(6000); const ee = await used();
  return { tries, start, afterPreview: a, afterManuscriptPreview: bb, afterPreflight: cc, afterOnix: dd, afterReload: ee }; });
 R.end = now(); fs.writeFileSync(`${OUT}cases2-${engName}${only ? '-' + only.join('') : ''}.json`, JSON.stringify(R, null, 1)); await b.close(); })();
