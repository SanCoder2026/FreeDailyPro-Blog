// FDP-43 run 3 (guest): what the shared download helper does on this Workflow Product.
// D01 at 0 trial uses: manuscript .docx preview and ONIX export (both go through ToolPage's download helper). D02 with uses left: per-page-load charging.
// D03 persistence after reload (open the chapter in the sidebar). Stops at any cap / pass dialog: never clicks a pass, never types an email.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/43-book-writing-toolbox/'; const OUT = BASE + 'live/'; const URL = 'https://www.freedailypro.com/tool/book-writing-toolbox';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const only = process.argv[2] ? process.argv[2].split(',') : null;
(async () => { const b = await pw.chromium.launch(); const R = { t: now(), cases: {} }; let c, p, net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); p = await c.newPage(); p.setDefaultTimeout(10000); net = [];
  p.on('request', r => { const u = r.url(); if (/\/api\/trpc\/(?!insight|funnel)/.test(u)) net.push(r.method() + ' ' + u.split('?')[0].replace(/.*\/api\/trpc\//, '')); });
  await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(6000); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return `${u.usageToday}/${u.limit}`; }).catch(() => '?');
 const dialog = async () => { const d = p.locator('[role=dialog]:visible,[role=alertdialog]:visible'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 700) : null; };
 const closeDlg = async () => { for (let i = 0; i < 3; i++) { if (await p.locator('[role=dialog]:visible,[role=alertdialog]:visible').count()) { await p.keyboard.press('Escape'); await p.waitForTimeout(500); } } };
 const sec = async n => { await p.getByRole('button', { name: n, exact: true }).first().click(); await p.waitForTimeout(800); };
 const btn = async (n, i = 0) => { await p.getByRole('button', { name: n, exact: true }).nth(i).click(); };
 const dl = async (fn, prefix, wait = 30000) => { const dp = p.waitForEvent('download', { timeout: wait }).catch(() => null); await fn(); const d = await dp; if (!d) return null; const f = OUT + 'downloads/' + prefix + '-' + d.suggestedFilename(); await d.saveAs(f); return { file: f.replace(BASE, ''), size: fs.statSync(f).size }; };
 const chapter = async (text) => { await p.locator('button[title="Add a chapter"]').click(); await p.waitForTimeout(1000); const ed = p.locator('.ProseMirror').first(); await ed.click(); await p.keyboard.type(text); await p.waitForTimeout(600); };
 const shot = async id => { await p.screenshot({ path: `${OUT}cases/${id}.png` }); };
 const msPrev = async (tag) => { await sec('Manuscript Format'); await p.getByLabel('Your real legal name').fill('Samuel Q. Tester'); const f = await dl(() => btn('Preview', 1), tag, 25000); await p.waitForTimeout(1500); const d = await dialog(); if (d) await shot(tag + '-dialog'); await closeDlg(); return { file: f, dialog: d, used: await used() }; };
 const onix = async (tag) => { await sec('Publishing Metadata'); const f = await dl(() => btn('Export ONIX (.xml)'), tag, 10000); await p.waitForTimeout(1200); const d = await dialog(); if (d) await shot(tag + '-dialog'); await closeDlg(); return { file: f, dialog: d, used: await used() }; };
 const run = async (id, desc, fn) => { if (only && !only.includes(id)) return; const r = { desc, t: now() }; try { Object.assign(r, (await fn()) || {}); } catch (e) { r.err = e.message.slice(0, 300); } try { r.net = net; await shot(id); } catch (e) {} R.cases[id] = r; console.log(id, JSON.stringify(r).slice(0, 600)); await c.close(); };
 const TEXT = 'The harbour lights came on one by one as the fog rolled in from the sea. '.repeat(6);
 await run('D01', 'At 0 trial uses: manuscript .docx preview, then ONIX export', async () => { let t = 0; await open(); while (!(await used()).startsWith('10/') && t < 8) { await c.close(); await open(); t++; }
  const u0 = await used(); await chapter(TEXT); const a = await msPrev('D01-ms'); const o = await onix('D01-onix'); return { start: u0, manuscriptPreview: a, onix: o }; });
 await run('D02', 'With uses left: manuscript .docx preview x2 in one page load, ONIX, reload, preview again', async () => { let t = 0; await open(); while ((await used()).startsWith('10/') && t < 12) { await c.close(); await open(); t++; }
  const u0 = await used(); if (u0.startsWith('10/')) return { note: 'no context with uses left', tries: t }; await chapter(TEXT);
  const a = await msPrev('D02-ms1'); const b2 = await msPrev('D02-ms2'); const o = await onix('D02-onix'); await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(6000); const afterReload = await used();
  const c2 = await msPrev('D02-ms3'); return { tries: t, start: u0, first: a, second: b2, onix: o, afterReload, afterReloadPreview: c2 }; });
 await run('D03', 'Persistence: chapter text after reload (open it from the sidebar)', async () => { await open(); await chapter('Persistence paragraph unique-7731.'); await p.waitForTimeout(3000); await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(6000);
  const names = await p.evaluate(() => [...document.querySelectorAll('main input')].map(i => i.value).filter(v => /^Chapter/.test(v))); let found = false;
  for (let i = 0; i < names.length && !found; i++) { await p.locator('main input').filter({ hasText: '' }).nth(0); const inp = p.locator(`main input[value="${names[i]}"]`).first(); await inp.click().catch(() => {}); await p.waitForTimeout(1000); found = await p.evaluate(() => [...document.querySelectorAll('.ProseMirror')].some(e => e.innerText.includes('unique-7731'))); }
  return { chapters: names, textFoundAfterReload: found }; });
 R.end = now(); fs.writeFileSync(`${OUT}cases3-chromium.json`, JSON.stringify(R, null, 1)); await b.close(); })();
