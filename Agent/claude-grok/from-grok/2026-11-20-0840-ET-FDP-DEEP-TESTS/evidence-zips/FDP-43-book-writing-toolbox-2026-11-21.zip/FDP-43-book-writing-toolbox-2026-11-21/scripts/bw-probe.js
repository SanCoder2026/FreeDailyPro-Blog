// Book Writing Toolbox probe (guest): add a chapter, type text, then visit each sidebar section and record its text + buttons + screenshot. No Download / trial clicks.
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const D = '/workspace/deep/43-book-writing-toolbox/live/'; fs.mkdirSync(D + 'probe', { recursive: true });
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await c.newPage(); p.setDefaultTimeout(8000);
 const R = { t: now(), steps: [] }; const net = [];
 p.on('request', r => { const u = r.url(); if (/trpc|\/api\//.test(u)) net.push({ m: r.method(), u: u.replace(/deviceId[^&,]*/g, 'deviceId=REDACTED').slice(0, 160), len: (r.postData() || '').length }); });
 await p.goto('https://www.freedailypro.com/tool/book-writing-toolbox', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(6000);
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 R.used0 = await used();
 await p.locator('button[title="Add a chapter"]').click(); await p.waitForTimeout(1500);
 const ed = p.locator('.ProseMirror').first(); R.editors = await p.locator('.ProseMirror').count();
 await ed.click(); await p.keyboard.type('It was a bright cold day in April. The clocks were striking thirteen. This is the first chapter of a test book.'); await p.waitForTimeout(800);
 await p.screenshot({ path: D + 'probe/00-chapter.png' });
 const main = () => p.evaluate(() => document.querySelector('main').innerText);
 for (const s of ['Book Identifiers', 'Front Cover', 'Spine', 'Back Cover', 'Publishing Metadata', 'Manuscript Format', 'EPUB', 'Pre-flight Check', 'Title Page', 'Help & FAQ']) {
  try { await p.getByRole('button', { name: s, exact: true }).first().click(); await p.waitForTimeout(1200);
   const btn = await p.evaluate(() => [...document.querySelectorAll('main button')].filter(x => x.offsetParent).map(x => (x.getAttribute('aria-label') || x.title || x.innerText).trim().slice(0, 70)).filter(Boolean));
   const t = await main(); const i = t.indexOf('Help & FAQ'); R.steps.push({ s, text: t.slice(i + 10, i + 3000), buttons: btn.slice(0, 80) });
   await p.screenshot({ path: D + 'probe/' + s.replace(/\W+/g, '_') + '.png' }); } catch (e) { R.steps.push({ s, err: e.message.slice(0, 150) }); } }
 R.used1 = await used(); R.net = net; R.ls = await p.evaluate(() => Object.keys(localStorage)); R.end = now();
 fs.writeFileSync(D + 'probe.json', JSON.stringify(R, null, 1)); console.log(R.used0, R.used1, R.editors, net.length); await b.close(); })();
