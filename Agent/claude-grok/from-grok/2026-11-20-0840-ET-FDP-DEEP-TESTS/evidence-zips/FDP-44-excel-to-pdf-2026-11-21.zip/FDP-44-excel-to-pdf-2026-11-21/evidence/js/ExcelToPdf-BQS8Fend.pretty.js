import { r as c, j as e } from "./vendor-react-D01g8YgM.js";
import { T as J } from "./ToolWithSidebar-C7kxZj7O.js";
import { F as X, P as q, D as Q, R as Y } from "./ToolPage-DwLoDncN.js";
import {
  ax as y,
  N as w,
  B as f,
  f as ee,
  ay as te,
} from "./index-B1CTyGtY.js";
import { f as I } from "./formatFileSize-B-JRDfN5.js";
import { p as u } from "./plural-FIChqbp4.js";
import { u as se } from "./useRunToken-sJpsnYiZ.js";
import { u as re, b as ae } from "./pdfFonts-Ckcqm3Ic.js";
import {
  DEFAULT_EXCEL_PDF_OPTIONS as ne,
  loadWorkbook as le,
  NotSpreadsheetError as L,
  convertWorkbookToPdf as oe,
  ExcelPdfCancelled as ie,
} from "./excelPdf-CkS3r6Jd.js";
import { I as A } from "./info-B8t_e6MS.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./backgroundSafe-DObGz9DE.js";
import "./pdfMetadata-CcxIhQF2.js";
import "./textToPdf-BuGdG5vq.js";
import "./xmlLite-D0-GZ86u.js";
const de = /\.(xlsx|xlsm|xls|csv|tsv)$/i,
  R = {
    pdf: "PDF",
    doc: "Word",
    docx: "Word",
    ppt: "PowerPoint",
    pptx: "PowerPoint",
    odt: "OpenDocument text",
    ods: "OpenDocument spreadsheet",
  };
function ce(r) {
  if (de.test(r)) return null;
  const n = (r.split(".").length > 1 ? r.split(".").pop() : "").toLowerCase(),
    s = R[n]
      ? `a ${R[n]} file`
      : /^(jpe?g|png|gif|webp|heic|bmp|tiff?|svg)$/.test(n)
        ? "an image"
        : n
          ? `a .${n} file`
          : "a file without a spreadsheet extension";
  return `“${r}” looks like ${s}, not a spreadsheet. This tool takes .xlsx, .xlsm, .xls or .csv files.`;
}
function me(r, n) {
  const s = `${n} character${n === 1 ? "" : "s"}`;
  return r === "Chinese" ? `CJK characters (${s})` : `${r} (${s})`;
}
function B(r, n) {
  if (n.length === 0) return null;
  const s =
    n.slice(0, 5).join(", ") +
    (n.length > 5 ? ` and ${n.length - 5} more` : "");
  return `${n.length} formula ${n.length === 1 ? "cell has" : "cells have"} no saved result and will print blank: ${s}. Open the file in Excel, save it, and convert again to fill ${n.length === 1 ? "it" : "them"}.${r > 0 ? ` ${r} simpler formula${r === 1 ? " was" : "s were"} calculated here.` : ""}`;
}
function _(r, n) {
  return r > 0 && n.length === 0
    ? `${r} formula ${r === 1 ? "cell had" : "cells had"} no saved result, so ${r === 1 ? "its" : "their"} value was calculated here. Check ${r === 1 ? "it" : "them"} against Excel.`
    : null;
}
const W = {
    what: `Converts an Excel spreadsheet (.xlsx, .xlsm, .xls) or a CSV file into a PDF table. Values are shown exactly as Excel displays them (dates, currency, percentages). Columns are sized to their content and long text wraps onto extra lines instead of being cut off; numbers are right-aligned; a title above the table is printed once, and the real column headings repeat on every page. Hidden sheets, hidden columns and filtered-out rows are left out, like Excel's own Save as PDF (you can include them). Each sheet starts on its own page, headed with its name.

Going the other direction? PDF to Excel pulls table data back out of a PDF into a real spreadsheet.`,
    tip: "This prints cell values with the workbook's own fills, font colours, bold, borders and alignment. Conditional formatting, charts and pictures are not reproduced (a note tells you how many charts or pictures were left out). A sheet wider than one page continues on following pages with its first column repeated. Chinese, Japanese, Korean, Hindi and other Indic scripts, Arabic, Hebrew, Thai and emoji are drawn as pictures so they look right, but that text cannot be selected or searched. If the sheet's exact printed look matters, use Save as PDF in Excel.",
  },
  pe = ["A4", "Letter"],
  he = [
    { id: "auto", label: "Automatic" },
    { id: "portrait", label: "Portrait" },
    { id: "landscape", label: "Landscape" },
  ],
  ue = [
    { id: 8, label: "Small" },
    { id: 9, label: "Normal" },
    { id: 11, label: "Large" },
  ],
  P = (r) => r.replace(/\.[^.]+$/, "");
function rt() {
  const [r, n] = c.useState(null),
    [s, v] = c.useState(null),
    [T, N] = c.useState(!1),
    [g, b] = c.useState(!1),
    [U, C] = c.useState(0),
    [o, j] = c.useState(null),
    [E, m] = c.useState(""),
    [i, k] = c.useState(() => ({
      ...ne,
      pageSize:
        typeof navigator < "u" && /^en-(US|CA)|^es-MX/i.test(navigator.language)
          ? "Letter"
          : "A4",
    })),
    l = se();
  c.useEffect(() => () => l.cancel(), [l]);
  const x = (t, a) => {
      (k((d) => ({ ...d, [t]: a })), j(null));
    },
    F = () => {
      (l.cancel(),
        n(null),
        v(null),
        N(!1),
        b(!1),
        j(null),
        m(""),
        C(0),
        k((t) => ({ ...t, includeHidden: !1 })));
    },
    M = c.useCallback(
      async (t) => {
        (l.cancel(),
          b(!1),
          j(null),
          m(""),
          v(null),
          n(null),
          k((h) => ({ ...h, includeHidden: !1 })));
        const a = t[0];
        if (!a) return;
        const d = ce(a.name);
        if (d) {
          m(d);
          return;
        }
        const p = l.start();
        (n(a), N(!0));
        try {
          const h = await le(a);
          if (!l.isCurrent(p)) return;
          v(h);
        } catch (h) {
          if (!l.isCurrent(p)) return;
          (console.error(h),
            n(null),
            m(h instanceof L ? h.message : "This file could not be read."));
        } finally {
          l.isCurrent(p) && N(!1);
        }
      },
      [l],
    ),
    G = async () => {
      if (!r || !s) return;
      const t = l.start();
      (b(!0), j(null), m(""), C(0));
      try {
        const a = await oe(s, i, P(r.name), {
          isCurrent: () => l.isCurrent(t),
          progress: (d) => l.isCurrent(t) && C(d * 100),
        });
        if (!l.isCurrent(t)) return;
        (j({
          blob: new Blob([a.bytes], { type: "application/pdf" }),
          r: a,
          forFile: r.name,
        }),
          ee.success(`Converted to PDF (${u(a.pages, "page")})`),
          te("excel-to-pdf", "pdf-tools"));
      } catch (a) {
        if (a instanceof ie || !l.isCurrent(t)) return;
        (console.error("Excel to PDF conversion failed:", a),
          m(
            a instanceof L
              ? a.message
              : "The conversion failed. The file may be damaged.",
          ));
      } finally {
        l.isCurrent(t) && b(!1);
      }
    },
    K =
      !!s &&
      s.sheets.some((t) => t.rows.some((a) => a.cells.some((d) => d?.style))),
    $ = s && !g ? re(s.text) : [],
    S = s ? s.sheets.filter((t) => t.hidden).length : 0,
    D = s
      ? s.sheets
          .filter((t) => !t.hidden)
          .reduce(
            (t, a) =>
              t +
              a.rows.filter(
                (d) =>
                  d.hidden &&
                  d.cells.some((p) => p && !p.covered && p.text.trim()),
              ).length,
            0,
          )
      : 0,
    O = D > 0,
    z = s
      ? s.sheets
          .filter((t) => !t.hidden)
          .reduce((t, a) => t + a.colHidden.filter(Boolean).length, 0)
      : 0,
    H = z > 0,
    V = S > 0 || H || O,
    Z = s ? s.sheets.filter((t) => !t.hidden).length : 0;
  return e.jsxs(J, {
    toolId: "excel-to-pdf",
    categoryId: "pdf-tools",
    whatItDoes: W.what,
    proTip: W.tip,
    children: [
      e.jsxs("div", {
        className:
          "mb-4 p-3 rounded-lg border bg-muted/50 text-xs text-muted-foreground flex flex-wrap gap-x-4 gap-y-1",
        children: [
          e.jsx("span", {
            children: "🔒 Runs entirely in your browser, never uploaded",
          }),
          e.jsx("span", {
            children:
              "📊 Prints values as Excel shows them; hidden data is left out",
          }),
        ],
      }),
      E &&
        e.jsxs("div", {
          role: "alert",
          className:
            "mb-4 p-3 rounded-lg border border-destructive/40 bg-destructive/5 text-sm flex gap-2",
          children: [
            e.jsx(y, { className: "h-4 w-4 mt-0.5 shrink-0 text-destructive" }),
            e.jsx("span", { children: E }),
          ],
        }),
      r
        ? e.jsxs("div", {
            className: "space-y-4",
            children: [
              e.jsxs("div", {
                className: "p-4 rounded-lg border bg-card",
                children: [
                  e.jsx("p", {
                    className: "text-sm font-medium break-all",
                    children: r.name,
                  }),
                  e.jsxs("p", {
                    className: "text-xs text-muted-foreground",
                    children: [
                      I(r.size),
                      s && ` · ${u(s.sheets.length, "sheet")}`,
                      T && " · reading…",
                    ],
                  }),
                ],
              }),
              $.length > 0 &&
                e.jsxs(w, {
                  role: "alert",
                  className: "text-sm flex gap-2",
                  children: [
                    e.jsx(y, {
                      className: "h-4 w-4 mt-0.5 shrink-0 text-primary",
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsxs("p", {
                          className: "font-medium",
                          children: [
                            "This file has ",
                            $.map((t) => me(t.name, t.count)).join(", "),
                            ".",
                          ],
                        }),
                        e.jsx("p", {
                          className: "text-muted-foreground",
                          children:
                            ae() !== null
                              ? "These are drawn as pictures so they look right, but that text cannot be selected or searched in the PDF."
                              : "This browser cannot draw them, so they will appear as “?” in the PDF.",
                        }),
                      ],
                    }),
                  ],
                }),
              s &&
                !g &&
                !o &&
                B(s.formulasCalculated ?? 0, s.formulasBlank ?? []) &&
                e.jsxs(w, {
                  role: "alert",
                  className: "text-sm flex gap-2",
                  children: [
                    e.jsx(y, {
                      className: "h-4 w-4 mt-0.5 shrink-0 text-primary",
                    }),
                    e.jsx("span", {
                      children: B(
                        s.formulasCalculated ?? 0,
                        s.formulasBlank ?? [],
                      ),
                    }),
                  ],
                }),
              s &&
                !g &&
                !o &&
                _(s.formulasCalculated ?? 0, s.formulasBlank ?? []) &&
                e.jsxs("p", {
                  role: "status",
                  className: "text-xs text-muted-foreground flex gap-1",
                  children: [
                    e.jsx(A, { className: "h-3.5 w-3.5 mt-0.5 shrink-0" }),
                    " ",
                    _(s.formulasCalculated ?? 0, s.formulasBlank ?? []),
                  ],
                }),
              s &&
                !g &&
                !o &&
                e.jsxs("fieldset", {
                  className: "space-y-3",
                  children: [
                    e.jsx("legend", {
                      className: "text-sm font-medium mb-1",
                      children: "Page setup",
                    }),
                    e.jsxs("div", {
                      className: "flex flex-wrap items-center gap-2",
                      role: "group",
                      "aria-label": "Page size",
                      children: [
                        e.jsx("span", {
                          className: "text-sm text-muted-foreground w-24",
                          children: "Page size",
                        }),
                        pe.map((t) =>
                          e.jsx(
                            f,
                            {
                              size: "sm",
                              variant: i.pageSize === t ? "default" : "outline",
                              "aria-pressed": i.pageSize === t,
                              onClick: () => x("pageSize", t),
                              children: t === "Letter" ? "US Letter" : t,
                            },
                            t,
                          ),
                        ),
                      ],
                    }),
                    e.jsxs("div", {
                      className: "flex flex-wrap items-center gap-2",
                      role: "group",
                      "aria-label": "Orientation",
                      children: [
                        e.jsx("span", {
                          className: "text-sm text-muted-foreground w-24",
                          children: "Orientation",
                        }),
                        he.map((t) =>
                          e.jsx(
                            f,
                            {
                              size: "sm",
                              variant:
                                i.orientation === t.id ? "default" : "outline",
                              "aria-pressed": i.orientation === t.id,
                              onClick: () => x("orientation", t.id),
                              children: t.label,
                            },
                            t.id,
                          ),
                        ),
                      ],
                    }),
                    e.jsxs("div", {
                      className: "flex flex-wrap items-center gap-2",
                      role: "group",
                      "aria-label": "Text size",
                      children: [
                        e.jsx("span", {
                          className: "text-sm text-muted-foreground w-24",
                          children: "Text size",
                        }),
                        ue.map((t) =>
                          e.jsx(
                            f,
                            {
                              size: "sm",
                              variant:
                                i.fontSize === t.id ? "default" : "outline",
                              "aria-pressed": i.fontSize === t.id,
                              onClick: () => x("fontSize", t.id),
                              children: t.label,
                            },
                            t.id,
                          ),
                        ),
                      ],
                    }),
                    e.jsxs("label", {
                      className: "flex items-center gap-2 text-sm",
                      children: [
                        e.jsx("input", {
                          type: "checkbox",
                          checked: i.gridLines,
                          onChange: (t) => x("gridLines", t.target.checked),
                        }),
                        "Grid lines between cells",
                      ],
                    }),
                    K &&
                      e.jsxs("label", {
                        className: "flex items-start gap-2 text-sm",
                        children: [
                          e.jsx("input", {
                            type: "checkbox",
                            className: "mt-1",
                            checked: i.keepFormatting,
                            onChange: (t) =>
                              x("keepFormatting", t.target.checked),
                          }),
                          e.jsxs("span", {
                            children: [
                              "Keep colours, bold and borders",
                              e.jsx("span", {
                                className:
                                  "block text-xs text-muted-foreground",
                                children:
                                  "Uses the fills, font colours, bold, borders and alignment from your workbook. Untick for a plain, uniform printout.",
                              }),
                            ],
                          }),
                        ],
                      }),
                    V &&
                      e.jsxs("label", {
                        className: "flex items-start gap-2 text-sm",
                        children: [
                          e.jsx("input", {
                            type: "checkbox",
                            className: "mt-1",
                            checked: i.includeHidden,
                            onChange: (t) =>
                              x("includeHidden", t.target.checked),
                          }),
                          e.jsxs("span", {
                            children: [
                              "Include hidden data",
                              e.jsxs("span", {
                                className:
                                  "block text-xs text-muted-foreground",
                                children: [
                                  "This file has ",
                                  [
                                    S > 0 && u(S, "hidden sheet"),
                                    H && u(z, "hidden column"),
                                    O && `${u(D, "hidden or filtered row")}`,
                                  ]
                                    .filter(Boolean)
                                    .join(", "),
                                  ". They are left out unless you tick this.",
                                ],
                              }),
                            ],
                          }),
                        ],
                      }),
                    s &&
                      Z === 0 &&
                      !i.includeHidden &&
                      e.jsxs("p", {
                        className: "text-xs text-muted-foreground flex gap-1",
                        children: [
                          e.jsx(A, { className: "h-3.5 w-3.5 mt-0.5" }),
                          " Every sheet in this file is hidden.",
                        ],
                      }),
                  ],
                }),
              e.jsx("div", {
                className: "flex flex-wrap gap-3",
                children: g
                  ? e.jsx("div", {
                      className: "w-full",
                      children: e.jsx(q, {
                        message: "Converting…",
                        progress: U,
                        onStop: () => {
                          (l.cancel(), b(!1));
                        },
                      }),
                    })
                  : o
                    ? e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(Q, {
                            blob: o.blob,
                            fileName: `${P(o.forFile)}.pdf`,
                          }),
                          e.jsx(f, {
                            variant: "outline",
                            onClick: F,
                            children: "Convert another file",
                          }),
                        ],
                      })
                    : e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(f, {
                            onClick: G,
                            disabled: !s || T,
                            children: "Convert to PDF",
                          }),
                          e.jsx(f, {
                            variant: "outline",
                            onClick: F,
                            children: "Choose a different file",
                          }),
                        ],
                      }),
              }),
              o &&
                e.jsxs("div", {
                  className: "space-y-3",
                  children: [
                    e.jsxs("p", {
                      className: "text-sm text-muted-foreground",
                      role: "status",
                      children: [
                        u(o.r.sheets, "sheet"),
                        " · ",
                        u(o.r.pages, "page"),
                        " · ",
                        I(o.blob.size),
                        " · ",
                        P(o.forFile),
                        ".pdf",
                      ],
                    }),
                    o.r.notes.map((t, a) =>
                      e.jsx(
                        w,
                        { role: "status", className: "text-sm", children: t },
                        a,
                      ),
                    ),
                    o.r.warnings.map((t, a) =>
                      e.jsx(
                        w,
                        { className: "text-sm", role: "alert", children: t },
                        a,
                      ),
                    ),
                    e.jsx(Y, { blob: o.blob, mimeType: "application/pdf" }),
                  ],
                }),
            ],
          })
        : e.jsx(X, {
            gateAtDownload: !0,
            onAttempt: () => m(""),
            accept: "*",
            onFiles: M,
            label: "Drop an Excel or CSV file",
            description:
              "Spreadsheet data (.xlsx, .xlsm, .xls, .csv) as a readable PDF table",
          }),
    ],
  });
}
export { rt as default };
//# sourceMappingURL=ExcelToPdf-BQS8Fend.js.map
