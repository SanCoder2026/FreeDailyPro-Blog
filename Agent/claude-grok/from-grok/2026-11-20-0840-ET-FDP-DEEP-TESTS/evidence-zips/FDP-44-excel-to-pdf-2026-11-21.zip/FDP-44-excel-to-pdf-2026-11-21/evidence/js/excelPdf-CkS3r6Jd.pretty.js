import { ap as he } from "./index-B1CTyGtY.js";
import { k as de, u as Mt, e as ue, P as pe } from "./index-BRvxULIc.js";
import { J as ae } from "./jszip.min-CT0ZA6V1.js";
import { y as me } from "./backgroundSafe-DObGz9DE.js";
import { P as we, r as ge } from "./pdfFonts-Ckcqm3Ic.js";
import { s as Fe } from "./pdfMetadata-CcxIhQF2.js";
import {
  decodeTextFile as xe,
  PAGE_SIZES as ye,
} from "./textToPdf-BuGdG5vq.js";
import {
  b as Ct,
  p as ut,
  a as I,
  k as _t,
  c as U,
  f as ve,
} from "./xmlLite-D0-GZ86u.js";
import "./vendor-react-D01g8YgM.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./fontkit.es-DA-3qwB1.js";
const be = 400;
function Ce(p) {
  const t = [];
  let d = 0;
  const c = {
    num: /^\d+(\.\d+)?([eE][+-]?\d+)?/,
    ref: /^(?:(?:'([^']+)'|([A-Za-z_][A-Za-z0-9_.]*))!)?\$?([A-Za-z]{1,3})\$?(\d+)(?::\$?([A-Za-z]{1,3})\$?(\d+))?(?![A-Za-z0-9_(])/,
    id: /^[A-Za-z_][A-Za-z0-9_.]*(?=\()/,
  };
  for (; d < p.length;) {
    const h = p.slice(d);
    if (/^\s/.test(h)) {
      d++;
      continue;
    }
    let e;
    if ((e = c.id.exec(h))) {
      (t.push({ t: "id", v: e[0].toUpperCase() }), (d += e[0].length));
      continue;
    }
    if ((e = c.ref.exec(h))) {
      (t.push({
        t: "ref",
        sheet: e[1] ?? e[2] ?? null,
        a: `${e[3]}${e[4]}`.toUpperCase(),
        b: e[5] ? `${e[5]}${e[6]}`.toUpperCase() : void 0,
      }),
        (d += e[0].length));
      continue;
    }
    if ((e = c.num.exec(h))) {
      (t.push({ t: "num", v: Number(e[0]) }), (d += e[0].length));
      continue;
    }
    if (/^[-+*/^(),]/.test(h)) {
      (t.push({ t: "op", v: h[0] }), d++);
      continue;
    }
    return null;
  }
  return t.length <= be ? t : null;
}
function Me(p) {
  let t = 0;
  for (const d of p.toUpperCase()) t = t * 26 + (d.charCodeAt(0) - 64);
  return t - 1;
}
function $e(p) {
  let t = "";
  for (let d = p + 1; d > 0; d = Math.floor((d - 1) / 26))
    t = String.fromCharCode(65 + ((d - 1) % 26)) + t;
  return t;
}
const se = (p) => {
  const t = /^([A-Z]+)(\d+)$/.exec(p);
  return { c: Me(t[1]), r: Number(t[2]) };
};
class tt extends Error {}
function Se(p, t, d) {
  const c = Ce(p.trim().replace(/^=/, ""));
  if (!c || c.length === 0) return null;
  const h = c;
  let e = 0;
  const g = () => h[e],
    a = (s) => g()?.t === "op" && g().v === s,
    x = (s, F) => {
      const w = d(s ?? t, F);
      if (w == null || w === "") return 0;
      if (typeof w == "number") return w;
      throw new tt();
    },
    i = (s, F, w) => {
      if (!w) {
        const z = d(s ?? t, F);
        return typeof z == "number" ? [z] : [];
      }
      const r = se(F),
        f = se(w),
        L = [];
      if ((Math.abs(f.c - r.c) + 1) * (Math.abs(f.r - r.r) + 1) > 5e3)
        throw new tt();
      for (let z = Math.min(r.r, f.r); z <= Math.max(r.r, f.r); z++)
        for (let st = Math.min(r.c, f.c); st <= Math.max(r.c, f.c); st++) {
          const dt = d(s ?? t, `${$e(st)}${z}`);
          typeof dt == "number" && L.push(dt);
        }
      return L;
    };
  function v() {
    let s = u();
    for (; a("+") || a("-");) {
      const F = h[e++].v,
        w = u();
      s = F === "+" ? s + w : s - w;
    }
    return s;
  }
  function u() {
    let s = l();
    for (; a("*") || a("/");) {
      const F = h[e++].v,
        w = l();
      if (F === "/" && w === 0) throw new tt();
      s = F === "*" ? s * w : s / w;
    }
    return s;
  }
  function l() {
    const s = o();
    return a("^") ? (e++, Math.pow(s, l())) : s;
  }
  function o() {
    return a("-") ? (e++, -o()) : a("+") ? (e++, o()) : m();
  }
  function y() {
    const s = [];
    if (a(")")) return (e++, s);
    for (;;) {
      const F = g();
      if (
        (F?.t === "ref" && F.b
          ? (e++, s.push(i(F.sheet, F.a, F.b)))
          : s.push(v()),
        a(","))
      ) {
        e++;
        continue;
      }
      if (a(")")) return (e++, s);
      throw new tt();
    }
  }
  function m() {
    const s = h[e++];
    if (!s) throw new tt();
    if (s.t === "num") return s.v;
    if (s.t === "ref") {
      if (s.b) throw new tt();
      return x(s.sheet, s.a);
    }
    if (s.t === "op" && s.v === "(") {
      const F = v();
      if (!a(")")) throw new tt();
      return (e++, F);
    }
    if (s.t === "id") {
      if (!a("(")) throw new tt();
      e++;
      const w = y().flatMap((r) => (Array.isArray(r) ? r : [r]));
      switch (s.v) {
        case "SUM":
          return w.reduce((r, f) => r + f, 0);
        case "AVERAGE":
          if (!w.length) throw new tt();
          return w.reduce((r, f) => r + f, 0) / w.length;
        case "MIN":
          return w.length ? Math.min(...w) : 0;
        case "MAX":
          return w.length ? Math.max(...w) : 0;
        case "COUNT":
          return w.length;
        case "ABS":
          if (w.length !== 1) throw new tt();
          return Math.abs(w[0]);
        case "ROUND": {
          if (w.length < 1 || w.length > 2) throw new tt();
          const r = Math.pow(10, w[1] ?? 0);
          return Math.round(w[0] * r) / r;
        }
        default:
          throw new tt();
      }
    }
    throw new tt();
  }
  try {
    const s = v();
    return e === h.length && Number.isFinite(s) ? s : null;
  } catch (s) {
    if (s instanceof tt) return null;
    throw s;
  }
}
const Ae = [
  "000000",
  "FFFFFF",
  "FF0000",
  "00FF00",
  "0000FF",
  "FFFF00",
  "FF00FF",
  "00FFFF",
  "000000",
  "FFFFFF",
  "FF0000",
  "00FF00",
  "0000FF",
  "FFFF00",
  "FF00FF",
  "00FFFF",
  "800000",
  "008000",
  "000080",
  "808000",
  "800080",
  "008080",
  "C0C0C0",
  "808080",
  "9999FF",
  "993366",
  "FFFFCC",
  "CCFFFF",
  "660066",
  "FF8080",
  "0066CC",
  "CCCCFF",
  "000080",
  "FF00FF",
  "FFFF00",
  "00FFFF",
  "800080",
  "800000",
  "008080",
  "0000FF",
  "00CCFF",
  "CCFFFF",
  "CCFFCC",
  "FFFF99",
  "99CCFF",
  "FF99CC",
  "CC99FF",
  "FFCC99",
  "3366FF",
  "33CCCC",
  "99CC00",
  "FFCC00",
  "FF9900",
  "FF6600",
  "666699",
  "969696",
  "003366",
  "339966",
  "003300",
  "333300",
  "993300",
  "993366",
  "333399",
  "333333",
];
function oe(p, t) {
  if (!t) return p;
  const d = parseInt(p.slice(0, 2), 16) / 255,
    c = parseInt(p.slice(2, 4), 16) / 255,
    h = parseInt(p.slice(4, 6), 16) / 255,
    e = Math.max(d, c, h),
    g = Math.min(d, c, h);
  let a = 0,
    x = 0,
    i = (e + g) / 2;
  if (e !== g) {
    const m = e - g;
    ((x = i > 0.5 ? m / (2 - e - g) : m / (e + g)),
      (a =
        e === d
          ? (c - h) / m + (c < h ? 6 : 0)
          : e === c
            ? (h - d) / m + 2
            : (d - c) / m + 4),
      (a /= 6));
  }
  i = t < 0 ? i * (1 + t) : i * (1 - t) + t;
  const v = (m, s, F) => (
    F < 0 && (F += 1),
    F > 1 && (F -= 1),
    F < 1 / 6
      ? m + (s - m) * 6 * F
      : F < 1 / 2
        ? s
        : F < 2 / 3
          ? m + (s - m) * (2 / 3 - F) * 6
          : m
  );
  let u = i,
    l = i,
    o = i;
  if (x !== 0) {
    const m = i < 0.5 ? i * (1 + x) : i + x - i * x,
      s = 2 * i - m;
    ((u = v(s, m, a + 1 / 3)), (l = v(s, m, a)), (o = v(s, m, a - 1 / 3)));
  }
  const y = (m) =>
    Math.max(0, Math.min(255, Math.round(m * 255)))
      .toString(16)
      .padStart(2, "0");
  return (y(u) + y(l) + y(o)).toUpperCase();
}
function Ie(p) {
  const t = [
    "FFFFFF",
    "000000",
    "EEECE1",
    "1F497D",
    "4F81BD",
    "C0504D",
    "9BBB59",
    "8064A2",
    "4BACC6",
    "F79646",
    "0000FF",
    "800080",
  ];
  if (!p) return t;
  try {
    const d = ve(ut(p), "a:clrScheme");
    if (!d) return t;
    const c = (x, i) => {
        const u = U(d, x)?.children[0];
        return (I(u, "lastClr") ?? I(u, "val") ?? i).toUpperCase();
      },
      h = c("a:dk1", "000000"),
      e = c("a:lt1", "FFFFFF"),
      g = c("a:dk2", "1F497D"),
      a = c("a:lt2", "EEECE1");
    return [
      e,
      h,
      a,
      g,
      ...[
        "a:accent1",
        "a:accent2",
        "a:accent3",
        "a:accent4",
        "a:accent5",
        "a:accent6",
        "a:hlink",
        "a:folHlink",
      ].map((x, i) => c(x, t[4 + i])),
    ];
  } catch {
    return t;
  }
}
function Ee(p, t) {
  const d = Ie(t),
    c = ut(p),
    h = (o) => {
      if (!o) return;
      const y = parseFloat(I(o, "tint") ?? "0") || 0,
        m = I(o, "rgb");
      if (m) return oe(m.slice(-6).toUpperCase(), y);
      const s = I(o, "theme");
      if (s !== void 0) return oe(d[parseInt(s, 10)] ?? "000000", y);
      const F = I(o, "indexed");
      if (F !== void 0) {
        const w = parseInt(F, 10);
        return w === 64 ? "000000" : w === 65 ? "FFFFFF" : (Ae[w] ?? "000000");
      }
      I(o, "auto");
    },
    e = _t(U(c, "fonts"), "font").map((o) => ({
      bold: !!U(o, "b") && I(U(o, "b"), "val") !== "0",
      italic: !!U(o, "i") && I(U(o, "i"), "val") !== "0",
      underline: !!U(o, "u") && I(U(o, "u"), "val") !== "none",
      strike: !!U(o, "strike") && I(U(o, "strike"), "val") !== "0",
      color: h(U(o, "color")),
    })),
    g = _t(U(c, "fills"), "fill").map((o) => {
      const y = U(o, "patternFill"),
        m = I(y, "patternType");
      if (!(!y || !m || m === "none"))
        return h(m === "solid" ? U(y, "fgColor") : U(y, "fgColor"));
    }),
    a = (o, y) => {
      const m = U(o, y),
        s = I(m, "style");
      if (!(!m || !s)) return { style: s, color: h(U(m, "color")) ?? "000000" };
    },
    x = _t(U(c, "borders"), "border").map((o) => ({
      top: a(o, "top"),
      bottom: a(o, "bottom"),
      left: a(o, "left") ?? a(o, "start"),
      right: a(o, "right") ?? a(o, "end"),
    })),
    i = new Map();
  for (const o of _t(U(c, "numFmts"), "numFmt"))
    i.set(parseInt(I(o, "numFmtId") ?? "-1", 10), I(o, "formatCode") ?? "");
  const v = new Set([6, 8, 38, 40]),
    u = (o) => {
      if (v.has(o)) return !0;
      const y = i.get(o);
      if (!y) return !1;
      const m = y.replace(/"[^"]*"/g, "").split(";");
      return m.length > 1 && /\[red\]/i.test(m[1]);
    };
  return {
    xfs: _t(U(c, "cellXfs"), "xf").map((o) => {
      const y = e[parseInt(I(o, "fontId") ?? "0", 10)],
        m = g[parseInt(I(o, "fillId") ?? "0", 10)],
        s = x[parseInt(I(o, "borderId") ?? "0", 10)],
        F = U(o, "alignment"),
        w = I(F, "horizontal"),
        r = I(F, "vertical"),
        f = {};
      return (
        y?.bold && (f.bold = !0),
        y?.italic && (f.italic = !0),
        y?.underline && (f.underline = !0),
        y?.strike && (f.strike = !0),
        y?.color && y.color !== "000000" && (f.color = y.color),
        m && m !== "FFFFFF" && (f.fill = m),
        w === "center" || w === "centerContinuous"
          ? (f.halign = "center")
          : w === "right"
            ? (f.halign = "right")
            : w === "left" && (f.halign = "left"),
        (r === "center" || r === "top" || r === "bottom") && (f.valign = r),
        I(F, "wrapText") === "1" && (f.wrap = !0),
        u(parseInt(I(o, "numFmtId") ?? "0", 10)) && (f.redNeg = !0),
        s?.top && (f.top = s.top),
        s?.bottom && (f.bottom = s.bottom),
        s?.left && (f.left = s.left),
        s?.right && (f.right = s.right),
        Object.keys(f).length ? f : void 0
      );
    }),
  };
}
const ke = (p) =>
  p.split("").reduce((t, d) => t * 26 + (d.charCodeAt(0) - 64), 0) - 1;
async function Re(p) {
  const t = new Map();
  try {
    const d = await ae.loadAsync(p),
      c = async (i) => d.file(i)?.async("string"),
      h = await c("xl/styles.xml"),
      e = await c("xl/workbook.xml"),
      g = await c("xl/_rels/workbook.xml.rels");
    if (!h || !e || !g) return t;
    const { xfs: a } = Ee(h, await c("xl/theme/theme1.xml"));
    if (!a.some(Boolean)) return t;
    const x = new Map();
    for (const i of Ct(ut(g), "Relationship"))
      x.set(I(i, "Id") ?? "", I(i, "Target") ?? "");
    for (const i of Ct(ut(e), "sheet")) {
      const v = I(i, "name") ?? "";
      let u = x.get(I(i, "r:id") ?? "") ?? "";
      if (!u) continue;
      u = u.replace(/^\//, "").replace(/^xl\//, "");
      const l = await c("xl/" + u);
      if (!l) continue;
      const o = new Map(),
        y = /<c\s+([^>]*?)\/?>/g;
      let m;
      for (; (m = y.exec(l));) {
        const s = m[1],
          F = /\bs="(\d+)"/.exec(s),
          w = /\br="([A-Z]+)(\d+)"/.exec(s);
        if (!F || !w) continue;
        const r = a[parseInt(F[1], 10)];
        r && o.set(`${parseInt(w[2], 10) - 1},${ke(w[1])}`, r);
      }
      o.size && t.set(v, o);
    }
  } catch {}
  return t;
}
class Nt extends Error {
  constructor(t) {
    (super(t), (this.name = "NotSpreadsheetError"));
  }
}
const qe = {
  pageSize: "A4",
  orientation: "auto",
  fontSize: 9,
  gridLines: !0,
  includeHidden: !1,
  keepFormatting: !0,
};
class _e extends Error {
  constructor() {
    super("cancelled");
  }
}
const re = (p) => p === "1" || p?.toLowerCase() === "true";
function Ne(p) {
  const t = new Set(),
    d = new Set(),
    c = (h, e) => new RegExp(`\\s${e}\\s*=\\s*"([^"]*)"`).exec(h)?.[1];
  for (const h of Array.from(p.matchAll(/<row\b[^>]*>/g))) {
    if (!re(c(h[0], "hidden"))) continue;
    const e = parseInt(c(h[0], "r") ?? "", 10);
    e > 0 && t.add(e - 1);
  }
  for (const h of Array.from(p.matchAll(/<col\b[^>]*>/g))) {
    if (!re(c(h[0], "hidden"))) continue;
    const e = parseInt(c(h[0], "min") ?? "", 10),
      g = Math.min(parseInt(c(h[0], "max") ?? "", 10) || e, 16384);
    if (e > 0) for (let a = e; a <= g; a++) d.add(a - 1);
  }
  return { rows: t, cols: d };
}
const ie = (p) =>
  p.split("").reduce((t, d) => t * 26 + (d.charCodeAt(0) - 64), 0) - 1;
function ze(p, t) {
  const d = new Map();
  if (!t) return d;
  const c = new Map();
  for (const h of Array.from(t.matchAll(/<Relationship\b[^>]*>/g))) {
    const e = /\bId="([^"]*)"/.exec(h[0])?.[1],
      g = /\bType="([^"]*)"/.exec(h[0])?.[1] ?? "",
      a = /\bTarget="([^"]*)"/.exec(h[0])?.[1];
    e && a && /\/hyperlink$/.test(g) && c.set(e, a.replace(/&amp;/g, "&"));
  }
  for (const h of Array.from(p.matchAll(/<hyperlink\b[^>]*>/g))) {
    const e = /\br:id="([^"]*)"/.exec(h[0])?.[1],
      g = /\bref="([A-Z]+)(\d+)(?::([A-Z]+)(\d+))?"/.exec(h[0]),
      a = e ? c.get(e) : void 0;
    if (!a || !g || !/^(https?:|mailto:)/i.test(a)) continue;
    const x = ie(g[1]),
      i = parseInt(g[2], 10) - 1,
      v = g[3] ? ie(g[3]) : x,
      u = g[4] ? parseInt(g[4], 10) - 1 : i;
    for (let l = i; l <= Math.min(u, i + 200); l++)
      for (let o = x; o <= Math.min(v, x + 50); o++) d.set(`${l},${o}`, a);
  }
  return d;
}
async function Le(p) {
  const t = new Map();
  try {
    const d = await ae.loadAsync(p),
      c = async (a) => d.file(a)?.async("string"),
      h = await c("xl/workbook.xml"),
      e = await c("xl/_rels/workbook.xml.rels");
    if (!h || !e) return t;
    const g = new Map();
    for (const a of Ct(ut(e), "Relationship"))
      g.set(I(a, "Id") ?? "", I(a, "Target") ?? "");
    for (const a of Ct(ut(h), "sheet")) {
      const x = I(a, "name") ?? "";
      let i = g.get(I(a, "r:id") ?? "") ?? "";
      if (!i) continue;
      i = i.replace(/^\//, "").replace(/^xl\//, "");
      const v = "xl/" + i,
        u = v.replace(/([^/]+)$/, "_rels/$1.rels"),
        l = await c(u);
      let o = 0,
        y = 0;
      const m = await c(v),
        s = m ? Ne(m) : { rows: new Set(), cols: new Set() };
      if (l)
        for (const F of Ct(ut(l), "Relationship")) {
          if (!/\/drawing$/.test(I(F, "Type") ?? "")) continue;
          const w =
              "xl/" +
              (I(F, "Target") ?? "")
                .replace(/^\.\.\//, "")
                .replace(/^\/xl\//, ""),
            r = await c(w);
          if (!r) continue;
          const f = ut(r);
          ((o += Ct(f, "c:chart").length), (y += Ct(f, "xdr:pic").length));
        }
      t.set(x, {
        charts: o,
        pictures: y,
        hiddenRows: s.rows,
        hiddenCols: s.cols,
        links: m ? ze(m, l) : new Map(),
      });
    }
  } catch {}
  return t;
}
function De(p, t) {
  let d = 0;
  const c = new Set(),
    h = new Set(),
    e = new Set(),
    g = (i) => i.v !== void 0 && i.v !== null && i.t !== "z",
    a = (i, v) => {
      const u = i ? t.Sheets[i] : void 0;
      if (!u) return;
      const l = u[v];
      return !l || (l.f && !g(l) && x(i, v, l), !g(l))
        ? null
        : l.t === "n" || l.t === "d"
          ? typeof l.v == "number"
            ? l.v
            : Number(l.v)
          : l.t === "b"
            ? l.v
              ? 1
              : 0
            : String(l.v);
    },
    x = (i, v, u) => {
      const l = `${i}!${v}`;
      if (h.has(l) || e.has(l)) return;
      e.add(l);
      const o = Se(u.f ?? "", i, a);
      if ((e.delete(l), h.add(l), o === null)) {
        c.add(l);
        return;
      }
      if (((u.v = o), (u.t = "n"), u.z))
        try {
          u.w = p.SSF.format(u.z, o);
        } catch {
          delete u.w;
        }
      else delete u.w;
      d++;
    };
  for (const i of t.SheetNames) {
    const v = t.Sheets[i];
    for (const u of Object.keys(v)) {
      if (u[0] === "!") continue;
      const l = v[u];
      l && l.f && !g(l) && x(i, u, l);
    }
  }
  return { calculated: d, blank: Array.from(c) };
}
async function tn(p) {
  const t = await he(() => import("./xlsx-CNerDvZX.js"), []),
    d = /\.(csv|tsv|txt)$/i.test(p.name),
    c = await p.arrayBuffer();
  let h;
  try {
    if (d) h = t.read(xe(c), { type: "string", raw: !0 });
    else {
      const u = new Uint8Array(c.slice(0, 4)),
        l = u[0] === 80 && u[1] === 75,
        o = u[0] === 208 && u[1] === 207;
      if (!l && !o) throw new Nt("This is not an Excel file.");
      h = t.read(c, { type: "array", cellStyles: !0, cellDates: !1 });
    }
  } catch (u) {
    throw u instanceof Nt
      ? u
      : new Nt(
          d
            ? "This CSV file could not be read."
            : "This is not an Excel file, or it is damaged or password-protected.",
        );
  }
  if (!h.SheetNames.length)
    throw new Nt("This file does not contain any sheets.");
  const { calculated: e, blank: g } = d
      ? { calculated: 0, blank: [] }
      : De(t, h),
    a = d ? new Map() : await Le(c),
    x = d ? new Map() : await Re(c),
    i = [];
  let v = "";
  return (
    h.SheetNames.forEach((u, l) => {
      const o = h.Sheets[u],
        y = h.Workbook?.Sheets?.[l]?.Hidden ?? 0,
        m = o["!ref"],
        s = x.get(u),
        F = [];
      let w = 0;
      const r = [];
      if (m) {
        const L = t.utils.decode_range(m);
        w = L.e.c + 1;
        const z = o["!merges"] ?? [],
          st = new Map(),
          dt = new Set(),
          zt = new Map(),
          pt = new Set();
        for (const b of z) {
          if ((st.set(`${b.s.r},${b.s.c}`, b.e.c - b.s.c + 1), b.e.r > b.s.r)) {
            pt.add(`${b.s.r},${b.s.c}`);
            for (let D = b.s.r + 1; D <= b.e.r; D++)
              zt.set(`${D},${b.s.c}`, {
                span: b.e.c - b.s.c + 1,
                last: D === b.e.r,
                base: s?.get(`${b.s.r},${b.s.c}`),
              });
          }
          for (let D = b.s.c; D <= b.e.c; D++)
            for (let J = b.s.r; J <= b.e.r; J++)
              (J !== b.s.r || D !== b.s.c) && dt.add(`${J},${D}`);
        }
        const $t = a.get(u);
        for (let b = 0; b < w; b++)
          r[b] = !!o["!cols"]?.[b]?.hidden || !!$t?.hiddenCols.has(b);
        for (let b = 0; b <= L.e.r; b++) {
          const D = [];
          for (let J = 0; J < w; J++) {
            const K = o[t.utils.encode_cell({ r: b, c: J })];
            let ot = "";
            (K &&
              K.v !== void 0 &&
              K.v !== null &&
              K.t !== "z" &&
              (ot = (K.w ?? t.utils.format_cell(K) ?? String(K.v)).toString()),
              (ot = ot.replace(
                /\r\n?/g,
                `
`,
              )));
            const ct = `${b},${J}`,
              n = zt.get(ct);
            let C = s?.get(ct);
            n
              ? (C = n.base
                  ? {
                      fill: n.base.fill,
                      left: n.base.left,
                      right: n.base.right,
                      bottom: n.last ? n.base.bottom : void 0,
                    }
                  : void 0)
              : pt.has(ct) && C?.bottom && (C = { ...C, bottom: void 0 });
            const j = !!(
              C &&
              (C.fill || C.top || C.bottom || C.left || C.right)
            );
            (ot.trim() === "" && !dt.has(`${b},${J}`) && !j
              ? D.push(null)
              : D.push({
                  text: ot.replace(/\s+$/, ""),
                  num: !!K && (K.t === "n" || K.t === "d") && !d,
                  span: n ? n.span : (st.get(ct) ?? 1),
                  covered: dt.has(ct) && !n,
                  style: C,
                  link: $t?.links.get(ct),
                }),
              ot &&
                (v +=
                  ot +
                  `
`));
          }
          F.push({
            hidden: !!o["!rows"]?.[b]?.hidden || !!$t?.hiddenRows.has(b),
            cells: D,
          });
        }
      }
      const f = a.get(u);
      (i.push({
        name: (d && p.name.replace(/\.[^.]+$/, "")) || u,
        hidden: y !== 0,
        colHidden: r,
        rows: F,
        ncols: w,
        charts: f?.charts ?? 0,
        pictures: f?.pictures ?? 0,
      }),
        (v +=
          u +
          `
`));
    }),
    {
      sheets: i,
      title: h.Props?.Title,
      author: h.Props?.Author,
      isCsv: d,
      text: v,
      formulasCalculated: e,
      formulasBlank: g,
    }
  );
}
const bt = 4,
  Kt = 3,
  ht = 36,
  ce = (p) => p.filter((t) => t && !t.covered && t.text.trim() !== "").length;
function Pe(p, t) {
  const d = [];
  let c = 0;
  const h = (r) =>
    p.rows.some((f) => f.cells[r] && f.cells[r].text.trim() !== "");
  for (let r = 0; r < p.ncols; r++) {
    if (p.colHidden[r] && !t) {
      h(r) && c++;
      continue;
    }
    d.push(r);
  }
  let e = 0;
  const g = [];
  for (const r of p.rows) {
    const f = r.cells.some(
      (z, st) => z && z.text.trim() !== "" && (t || !p.colHidden[st]),
    );
    if (r.hidden && !t) {
      f && e++;
      continue;
    }
    const L = d.map((z) => r.cells[z]);
    g.push(L.map((z) => (z ? { ...z } : null)));
  }
  g.forEach((r) => {
    for (let f = 0; f < r.length; f++) {
      const L = r[f];
      if (!L || L.covered || L.span <= 1) continue;
      let z = 1;
      for (; f + z < r.length && r[f + z]?.covered && z < L.span;) z++;
      L.span = z;
    }
  });
  const a = (r) => !r.some((f) => f && f.text.trim() !== "");
  let x = 0,
    i = g.length;
  for (; x < i && a(g[x]);) x++;
  for (; i > x && a(g[i - 1]);) i--;
  if (x >= i) return null;
  const v = [];
  for (let r = x; r < i; r++)
    a(g[r]) ? v[v.length - 1] !== null && v.push(null) : v.push(g[r]);
  const l = d
      .map((r, f) => v.some((L) => L && L[f] && L[f].text.trim() !== ""))
      .map((r, f) => (r ? f : -1))
      .filter((r) => r >= 0),
    o = v.map((r) => (r ? l.map((f) => r[f]) : null)),
    y = l.length,
    m = o.filter((r) => !!r),
    s = Math.max(...m.slice(0, 15).map(ce));
  let F = -1,
    w = 0;
  if (s >= 2) {
    const r = Math.max(2, Math.ceil(s * 0.6));
    for (let f = 0; f < o.length && f < 20; f++) {
      const L = o[f];
      if (L && ce(L) >= r) {
        F = f;
        break;
      }
    }
    F > 0 && (w = F);
  }
  return {
    name: p.name,
    rows: o,
    titleRows: w,
    headerRow: F,
    ncols: y,
    hiddenCols: c,
    hiddenRows: e,
  };
}
function Yt(p, t, d, c, h) {
  const e = [],
    g = (a) => p.width(a, c, "sans", h);
  for (const a of t.split(`
`)) {
    if (a.trim() === "") {
      e.push("");
      continue;
    }
    let x = "";
    for (const i of a.split(/ +/)) {
      if (!i) continue;
      const v = x ? x + " " + i : i;
      if ((x && g(v) > d ? (e.push(x), (x = i)) : (x = v), g(x) > d)) {
        let u = "";
        for (const l of x)
          (u && g(u + l) > d && (e.push(u), (u = "")), (u += l));
        x = u;
      }
    }
    e.push(x);
  }
  return e;
}
const Ue = Mt(0.45, 0.45, 0.45),
  Vt = Mt(0.1, 0.1, 0.1),
  Qt = Mt(0.72, 0.72, 0.72);
async function en(p, t, d, c = {}) {
  const h = () => {
      if (c.isCurrent && !c.isCurrent()) throw new _e();
    },
    e = [],
    g = [],
    a = [];
  let x = 0,
    i = 0,
    v = 0;
  for (const n of p.sheets) {
    if (n.hidden && !t.includeHidden) {
      n.rows.some((j) => j.cells.some((Z) => Z && Z.text.trim())) && x++;
      continue;
    }
    const C = Pe(n, t.includeHidden);
    if (!C) {
      a.push(n.name);
      continue;
    }
    ((i += C.hiddenCols), (v += C.hiddenRows), g.push({ p: C, src: n }));
  }
  if (g.length === 0)
    throw new Nt(
      x > 0
        ? "Every sheet with data is hidden. Turn on “Include hidden data” to print them."
        : "There is no data in this file.",
    );
  const u = await de.create(),
    l = new we(u, c.fallbackLoader, c.rasterEnv),
    o = p.text;
  (await l.prepare(o), l.scan(o));
  const y = t.fontSize,
    m = y * 1.25,
    [s, F] = ye[t.pageSize],
    w = [],
    r = (n, C, j, Z, O, mt, Lt, It = Vt, Et, wt = !1, Dt) => {
      const Pt = l.runs(j, "sans", Lt, wt);
      let M = 0;
      for (const Y of Pt) M += Y.font.widthOfTextAtSize(Y.text, mt);
      let at = Et !== void 0 ? Et - M : Dt !== void 0 ? Dt - M / 2 : Z;
      for (const Y of Pt)
        (l.drawRun(n, Y, { x: at, y: C - O - mt * 0.85, size: mt, color: It }),
          (at += Y.font.widthOfTextAtSize(Y.text, mt)));
    },
    f = t.keepFormatting,
    L = (n, C) => C || (f && !!n?.style?.bold),
    z = (n) =>
      Mt(
        parseInt(n.slice(0, 2), 16) / 255,
        parseInt(n.slice(2, 4), 16) / 255,
        parseInt(n.slice(4, 6), 16) / 255,
      ),
    st = (n) =>
      (0.299 * parseInt(n.slice(0, 2), 16) +
        0.587 * parseInt(n.slice(2, 4), 16) +
        0.114 * parseInt(n.slice(4, 6), 16)) /
      255,
    dt = (n) => {
      const C = f ? n?.style : void 0;
      return !!C?.redNeg &&
        !!n &&
        n.num &&
        /\d/.test(n.text) &&
        (/^\(.*\)$/.test(n.text) ||
          /^[-\u2212]/.test(n.text) ||
          /-$/.test(n.text))
        ? Mt(0.78, 0, 0)
        : !C?.color || (!C.fill && st(C.color) > 0.92)
          ? Vt
          : z(C.color);
    },
    zt = (n) => {
      const C =
          n.style === "thick"
            ? 1.6
            : n.style === "medium" ||
                n.style === "mediumDashed" ||
                n.style === "mediumDashDot"
              ? 1.1
              : n.style === "hair"
                ? 0.25
                : 0.6,
        j = /dash/i.test(n.style)
          ? [3, 2]
          : n.style === "dotted"
            ? [1, 1.5]
            : void 0;
      return { thickness: C, dash: j, color: z(n.color) };
    };
  let pt = 0,
    $t = 0;
  for (const { p: n, src: C } of g) {
    (h(), $t++, c.progress?.(($t - 1) / g.length));
    const j = n.rows
        .map(($, P) => ({ r: $, i: P }))
        .filter(({ i: $ }) => $ >= Math.max(0, n.headerRow) || n.headerRow < 0),
      Z = new Array(n.ncols).fill(0),
      O = new Array(n.ncols).fill(0),
      mt = new Array(n.ncols).fill(0),
      Lt = new Array(n.ncols).fill(0),
      It = bt * 2;
    for (const { r: $, i: P } of j) {
      if (!$) continue;
      const gt = P === n.headerRow;
      $.forEach((ft, Q) => {
        if (!(!ft || ft.covered || ft.span > 1 || !ft.text.trim())) {
          gt || (ft.num ? mt : Lt)[Q]++;
          for (const R of ft.text.split(`
`)) {
            const Ft = L(ft, gt);
            Z[Q] = Math.max(Z[Q], l.width(R, y, "sans", Ft) + It);
            for (const nt of R.split(/ +/))
              O[Q] = Math.max(
                O[Q],
                Math.min(l.width(nt, y, "sans", Ft) + It, 150),
              );
          }
        }
      });
    }
    const Et = mt.map(($, P) => $ > 0 && $ >= Lt[P] * 2.3);
    for (let $ = 0; $ < n.ncols; $++)
      ((O[$] = Math.max(O[$], 24)),
        (Z[$] = Math.max(Z[$], O[$])),
        (O[$] = Math.max(O[$], Math.min(Z[$], 64))));
    const wt = { w: Math.min(s, F), h: Math.max(s, F) },
      Dt = { w: wt.h, h: wt.w },
      Pt = Z.reduce(($, P) => $ + P, 0);
    let M = Dt;
    (t.orientation === "portrait" ||
      (t.orientation === "auto" && Pt <= wt.w - ht * 2)) &&
      (M = wt);
    const at = M.w - ht * 2,
      Y = [],
      qt = n.ncols > 1 && !Et[0];
    let lt = [],
      Ut = 0;
    for (let $ = 0; $ < n.ncols; $++) {
      const gt = qt && Y.length > 0 && lt.length === 0 ? O[0] : 0;
      (lt.length && Ut + O[$] + gt > at && (Y.push(lt), (lt = []), (Ut = 0)),
        qt &&
          Y.length > 0 &&
          lt.length === 0 &&
          $ !== 0 &&
          (lt.push(0), (Ut += O[0])),
        lt.push($),
        (Ut += O[$]));
    }
    (lt.length && Y.push(lt), Y.length > 1 && pt++);
    for (let $ = 0; $ < Y.length; $++) {
      const P = Y[$],
        gt = P.reduce((k, _) => k + Z[_], 0),
        ft = P.reduce((k, _) => k + O[_], 0);
      let Q;
      if (gt <= at) {
        const k = Math.min(1.35, at / gt);
        Q = P.map((_) => Z[_] * k);
      } else {
        Q = P.map((N) => O[N]);
        let k = at - ft;
        const _ = P.map((N, S) => ({ c: N, k: S })).sort(
          (N, S) => Z[N.c] - O[N.c] - (Z[S.c] - O[S.c]),
        );
        _.forEach(({ c: N, k: S }, G) => {
          const et = Z[N] - O[N],
            A = Math.min(et, k / (_.length - G));
          ((Q[S] = O[N] + A), (k -= A));
        });
      }
      const R = [ht];
      Q.forEach((k, _) => R.push(R[_] + k));
      const Ft = R[R.length - 1] - ht,
        nt = ht,
        jt = M.h - ht - 14;
      let H,
        X = 0,
        Gt = 0;
      const Wt = () => {
        H = u.addPage([M.w, M.h]);
        const k = { page: H, w: M.w, h: M.h };
        (w.push(k), (X = ht));
        const _ =
            Gt === 0 && $ === 0
              ? n.name
              : `${n.name} (${$ > 0 && Gt === 0 ? `columns, part ${$ + 1}` : "continued"})`,
          N = Yt(l, _, at, 13, !0)[0];
        (r(H, M.h, N, nt, X, 13, !0), (X += 22), Gt++);
      };
      Wt();
      const te = (k, _) => {
          const N = [];
          let S = 1;
          return (
            P.forEach((G, et) => {
              const A = k[G];
              if (!A || A.covered || !A.text) {
                N.push([]);
                return;
              }
              let rt = Q[et];
              if (A.span > 1)
                for (
                  let it = 1;
                  it < A.span && et + it < P.length && P[et + it] === G + it;
                  it++
                )
                  rt += Q[et + it];
              const T = Yt(l, A.text, rt - It, y, L(A, _));
              (N.push(T), (S = Math.max(S, T.length)));
            }),
            { lines: N, n: S }
          );
        },
        ee = (k, _, N, S, G, et, A, rt) => {
          const T = (rt - A) * m + Kt * 2;
          N &&
            H.drawRectangle({
              x: nt,
              y: M.h - S - T,
              width: Ft,
              height: T,
              color: Mt(0.93, 0.94, 0.95),
            });
          const it = (W, E) => {
            let B = Q[E];
            if (W && W.span > 1)
              for (
                let V = 1;
                V < W.span && E + V < P.length && P[E + V] === P[E] + V;
                V++
              )
                B += Q[E + V];
            return B;
          };
          if (
            (f &&
              P.forEach((W, E) => {
                const B = k[W];
                B?.covered ||
                  !B?.style?.fill ||
                  H.drawRectangle({
                    x: R[E],
                    y: M.h - S - T,
                    width: it(B, E),
                    height: T,
                    color: z(B.style.fill),
                  });
              }),
            P.forEach((W, E) => {
              const B = k[W],
                V = G[E].slice(A, rt),
                xt = !!B?.num,
                q = f ? B?.style : void 0,
                yt = L(B, _),
                vt = it(B, E),
                St =
                  q?.halign ??
                  (((xt && !N) || (Et[W] && (xt || (N && _)))) &&
                  (B?.span ?? 1) === 1
                    ? "right"
                    : "left"),
                Tt = q?.valign ?? "top",
                Bt = Math.max(0, rt - A - V.length),
                kt =
                  Tt === "center" ? (Bt * m) / 2 : Tt === "bottom" ? Bt * m : 0,
                Rt = dt(B);
              if (
                (V.forEach((At, fe) => {
                  const Ot = S + Kt + kt + fe * m;
                  if (
                    (St === "right"
                      ? r(
                          H,
                          M.h,
                          At,
                          R[E] + bt,
                          Ot,
                          y,
                          yt,
                          Rt,
                          R[E] + vt - bt,
                          !!q?.italic,
                        )
                      : St === "center"
                        ? r(
                            H,
                            M.h,
                            At,
                            R[E] + bt,
                            Ot,
                            y,
                            yt,
                            Rt,
                            void 0,
                            !!q?.italic,
                            R[E] + vt / 2,
                          )
                        : r(
                            H,
                            M.h,
                            At,
                            R[E] + bt,
                            Ot,
                            y,
                            yt,
                            Rt,
                            void 0,
                            !!q?.italic,
                          ),
                    q?.underline || q?.strike)
                  ) {
                    const Zt = l.width(At, y, "sans", yt),
                      Ht =
                        St === "right"
                          ? R[E] + vt - bt - Zt
                          : St === "center"
                            ? R[E] + vt / 2 - Zt / 2
                            : R[E] + bt,
                      Xt = M.h - Ot - y * 0.85;
                    (q.underline &&
                      H.drawLine({
                        start: { x: Ht, y: Xt - 1.3 },
                        end: { x: Ht + Zt, y: Xt - 1.3 },
                        thickness: 0.5,
                        color: Rt,
                      }),
                      q.strike &&
                        H.drawLine({
                          start: { x: Ht, y: Xt + y * 0.28 },
                          end: { x: Ht + Zt, y: Xt + y * 0.28 },
                          thickness: 0.5,
                          color: Rt,
                        }));
                  }
                }),
                B?.link && V.length)
              ) {
                const At = u.context.obj({
                  Type: "Annot",
                  Subtype: "Link",
                  Rect: [R[E], M.h - S - T, R[E] + vt, M.h - S],
                  Border: [0, 0, 0],
                  A: { S: pe.of("URI"), URI: ue.of(B.link) },
                });
                H.node.addAnnot(u.context.register(At));
              }
            }),
            t.gridLines)
          ) {
            H.drawLine({
              start: { x: nt, y: M.h - S - T },
              end: { x: nt + Ft, y: M.h - S - T },
              thickness: 0.4,
              color: Qt,
            });
            for (let W = 0; W <= P.length; W++)
              H.drawLine({
                start: { x: R[W], y: M.h - S },
                end: { x: R[W], y: M.h - S - T },
                thickness: 0.4,
                color: Qt,
              });
          } else
            H.drawLine({
              start: { x: nt, y: M.h - S - T },
              end: { x: nt + Ft, y: M.h - S - T },
              thickness: 0.3,
              color: Mt(0.85, 0.85, 0.85),
            });
          return (
            f &&
              P.forEach((W, E) => {
                const B = k[W],
                  V = B?.style;
                if (!V || B?.covered) return;
                const xt = it(B, E),
                  q = (yt, vt, St, Tt, Bt) => {
                    if (!yt) return;
                    const kt = zt(yt);
                    H.drawLine({
                      start: { x: vt, y: St },
                      end: { x: Tt, y: Bt },
                      thickness: kt.thickness,
                      color: kt.color,
                      dashArray: kt.dash,
                    });
                  };
                (A === 0 && q(V.top, R[E], M.h - S, R[E] + xt, M.h - S),
                  rt === et &&
                    q(V.bottom, R[E], M.h - S - T, R[E] + xt, M.h - S - T),
                  q(V.left, R[E], M.h - S, R[E], M.h - S - T),
                  q(V.right, R[E] + xt, M.h - S, R[E] + xt, M.h - S - T));
              }),
            T
          );
        },
        Jt = n.headerRow >= 0 ? n.rows[n.headerRow] : null,
        ne = () => {
          if (!Jt) return;
          const { lines: k, n: _ } = te(Jt, !0),
            N = ee(Jt, !0, !0, X, k, _, 0, _);
          (t.gridLines &&
            H.drawLine({
              start: { x: nt, y: M.h - X },
              end: { x: nt + Ft, y: M.h - X },
              thickness: 0.4,
              color: Qt,
            }),
            (X += N));
        };
      if ($ === 0) {
        for (let k = 0; k < n.titleRows; k++) {
          const _ = n.rows[k];
          if (!_) {
            X += m * 0.6;
            continue;
          }
          const N = _.filter((A) => A && !A.covered && A.text.trim())
              .map((A) => A.text.trim())
              .join("   "),
            S = k === n.rows.findIndex((A) => A),
            G = S ? y + 3 : y + 0.5,
            et = Yt(l, N, at, G, S);
          for (const A of et)
            (X + G * 1.3 > jt && Wt(),
              r(H, M.h, A, nt, X, G, S, Vt),
              (X += G * 1.35));
          X += S ? 2 : 0;
        }
        n.titleRows && (X += 6);
      }
      ne();
      const le = n.headerRow >= 0 ? n.headerRow + 1 : 0;
      for (let k = le; k < n.rows.length; k++) {
        k % 200 === 0 && (h(), await me());
        const _ = n.rows[k];
        if (!_) {
          X += m * 0.8;
          continue;
        }
        const N = /^\s*(grand\s+)?(sub)?totals?\b/i.test(
            _.find((A) => A && A.text.trim())?.text ?? "",
          ),
          { lines: S, n: G } = te(_, N),
          et = Math.max(1, Math.floor((jt - ht - 40) / m));
        for (let A = 0; A < G; A += et) {
          const rt = Math.min(G, A + et),
            T = (rt - A) * m + Kt * 2;
          (X + T > jt && (Wt(), ne()), (X += ee(_, N, !1, X, S, G, A, rt)));
        }
      }
    }
  }
  w.forEach((n, C) => {
    const j = `Page ${C + 1} of ${w.length}`,
      Z = l.width(j, 8, "sans");
    r(n.page, n.h, j, (n.w - Z) / 2, n.h - ht + 10, 8, !1, Ue);
  });
  const b = (n, C, j = C + "s") => `${n} ${n === 1 ? C : j}`,
    D = [];
  (x && D.push(`${b(x, "hidden sheet")}`),
    i && D.push(`${b(i, "hidden column")}`),
    v && D.push(`${b(v, "hidden or filtered row")}`),
    D.length &&
      e.push(
        `${D.length > 1 ? `${D.slice(0, -1).join(", ")} and ${D[D.length - 1]}` : D[0]} ${D.length === 1 && x + i + v === 1 ? "was" : "were"} left out.`,
      ));
  const J = g.reduce((n, C) => n + C.src.charts, 0),
    K = g.reduce((n, C) => n + C.src.pictures, 0);
  (J &&
    e.push(
      `${b(J, "chart")} ${J === 1 ? "was" : "were"} not included (only cell data is printed).`,
    ),
    K && e.push(`${b(K, "picture")} ${K === 1 ? "was" : "were"} not included.`),
    a.length &&
      e.push(
        `${a.length === 1 ? "Empty sheet" : "Empty sheets"} skipped: ${a.join(", ")}.`,
      ),
    pt &&
      e.push(
        `${b(pt, "sheet")} ${pt === 1 ? "is" : "are"} too wide for one page: the extra columns continue on following pages, with the first column repeated.`,
      ),
    Fe(u, { title: p.title, author: p.author, fallbackTitle: d }));
  const ot = [],
    ct = ge(l);
  return (
    ct && ot.push(ct),
    c.progress?.(1),
    await l.flushRasters(),
    {
      bytes: await u.save(),
      pages: w.length,
      sheets: g.length,
      notes: e,
      warnings: ot,
    }
  );
}
export {
  qe as DEFAULT_EXCEL_PDF_OPTIONS,
  _e as ExcelPdfCancelled,
  Nt as NotSpreadsheetError,
  en as convertWorkbookToPdf,
  tn as loadWorkbook,
  Pe as prepareSheet,
  Ne as readHiddenFromSheetXml,
  ze as readLinks,
  Le as readSheetExtras,
};
//# sourceMappingURL=excelPdf-CkS3r6Jd.js.map
