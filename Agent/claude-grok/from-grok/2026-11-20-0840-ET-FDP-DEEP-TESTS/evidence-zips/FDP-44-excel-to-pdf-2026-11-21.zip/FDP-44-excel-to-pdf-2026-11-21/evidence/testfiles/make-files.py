# Test workbooks for FDP-44 Excel to PDF (guest QA). Needs openpyxl + Pillow; LibreOffice (soffice) converts X01 to .xls and .ods afterwards.
import openpyxl, datetime, random, csv, zipfile
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.chart import BarChart, Reference
from openpyxl.drawing.image import Image as XLImage
from PIL import Image
thin = Side(style='thin', color='000000')
# X01: formatted finance sheet: merged title, header fill, bold, red font, borders, dates, currency, percent, long text, a chart and a picture
wb = openpyxl.Workbook(); ws = wb.active; ws.title = 'Budget 2026'
ws.merge_cells('A1:F1'); ws['A1'] = 'Q3 Budget Review – Acme Corp'; ws['A1'].font = Font(bold=True, size=14); ws['A1'].alignment = Alignment(horizontal='center')
hdr = ['Date', 'Department', 'Amount', 'Change', 'Owner', 'Notes']
for i, h in enumerate(hdr, 1):
    c = ws.cell(row=3, column=i, value=h); c.font = Font(bold=True, color='FFFFFF'); c.fill = PatternFill('solid', fgColor='1F4E78'); c.border = Border(top=thin, bottom=thin, left=thin, right=thin)
random.seed(4)
for r in range(4, 64):
    ws.cell(row=r, column=1, value=datetime.date(2026, 7, 1) + datetime.timedelta(days=r)).number_format = 'DD-MMM-YYYY'
    ws.cell(row=r, column=2, value=random.choice(['Sales', 'Marketing', 'R&D', 'Operations']))
    a = ws.cell(row=r, column=3, value=round(random.uniform(-5000, 25000), 2)); a.number_format = '"$"#,##0.00;[Red]-"$"#,##0.00'
    ws.cell(row=r, column=4, value=round(random.uniform(-0.3, 0.5), 4)).number_format = '0.0%'
    ws.cell(row=r, column=5, value=random.choice(['Zoë Ångström', 'José Núñez', 'Łukasz Żółć', 'Ana']))
    ws.cell(row=r, column=6, value=('Long note that should wrap inside the cell rather than being cut off at the column edge. ' * (2 if r % 7 == 0 else 0)) or 'ok')
    for col in range(1, 7): ws.cell(row=r, column=col).border = Border(left=thin, right=thin, bottom=thin)
ws['C64'] = '=SUM(C4:C63)'; ws['C64'].font = Font(bold=True, color='C00000'); ws['B64'] = 'TOTAL'; ws['B64'].font = Font(bold=True)
ch = BarChart(); ch.add_data(Reference(ws, min_col=3, min_row=3, max_row=10), titles_from_data=True); ws.add_chart(ch, 'H3')
Image.new('RGB', (120, 60), (200, 30, 30)).save('logo.png'); ws.add_image(XLImage('logo.png'), 'H20')
# second sheet visible, third hidden, a hidden column and hidden rows, plus an autofilter that filters rows
s2 = wb.create_sheet('Staff'); s2.append(['ID', 'Name', 'Salary', 'SECRET_COLUMN', 'City'])
for i in range(1, 21): s2.append([i, f'Person {i}', 40000 + i * 1000, f'secret-{i}', random.choice(['Pune', 'Berlin', 'Austin'])])
s2.column_dimensions['D'].hidden = True; s2.row_dimensions[5].hidden = True; s2.row_dimensions[6].hidden = True
s3 = wb.create_sheet('HiddenSheet'); s3['A1'] = 'HIDDEN-SHEET-CONTENT'; s3.sheet_state = 'hidden'
wb.save('X01_finance.xlsx')
# X02: wide sheet 30 columns, 300 rows
wb = openpyxl.Workbook(); ws = wb.active; ws.title = 'Wide'
ws.append(['Key'] + [f'Column {i}' for i in range(1, 30)])
for r in range(1, 301): ws.append([f'ROW-{r:03d}'] + [r * i for i in range(1, 30)])
wb.save('X02_wide.xlsx')
# X03: scripts: CJK, Arabic, Hebrew, Hindi, Thai, emoji, Greek, Cyrillic, € ₹
wb = openpyxl.Workbook(); ws = wb.active; ws.title = 'Scripts'
for row in [['Script', 'Text'], ['Chinese', '你好，世界'], ['Japanese', 'こんにちは'], ['Korean', '안녕하세요'], ['Arabic', 'مرحبا بالعالم'], ['Hebrew', 'שלום עולם'], ['Hindi', 'नमस्ते दुनिया'], ['Thai', 'สวัสดีชาวโลก'], ['Emoji', 'Launch 🚀 done ✅'], ['Greek', 'Καλημέρα'], ['Cyrillic', 'Привет мир'], ['Currency', '€1.234,56 / ₹1,23,456']]: ws.append(row)
wb.save('X03_scripts.xlsx')
# X04: formulas with no cached values (openpyxl never writes cached results)
wb = openpyxl.Workbook(); ws = wb.active; ws.append(['A', 'B', 'Sum', 'Vlookup']);
for i in range(1, 6): ws.append([i, i * 2, f'=A{i+1}+B{i+1}', f'=VLOOKUP(A{i+1},A2:B6,2,FALSE)'])
wb.save('X04_formulas_nocache.xlsx')
# X05: large 50,000 x 8
wb = openpyxl.Workbook(write_only=True); ws = wb.create_sheet('Big'); ws.append([f'H{i}' for i in range(8)])
for r in range(50000): ws.append([r, f'item {r}', r * 1.5, 'x', r % 7, 'abc', r * 2, 'end'])
wb.save('X05_large_50k.xlsx')
# CSV variants
open('X06_utf8_bom_semicolon.csv', 'w', encoding='utf-8-sig').write('Name;Amount;City\nZoë;1.234,56;Köln\nJosé;99,00;São Paulo\n')
open('X07_plain.csv', 'w').write('id,name,notes\n1,"Smith, John","He said ""hi"""\n2,Ann,"multi\nline"\n')
# X08: only hidden sheets except one empty? -> every sheet hidden is impossible in xlsx (one must be visible); make empty workbook instead
wb = openpyxl.Workbook(); wb.save('X08_empty.xlsx')
# Rejects: docx renamed, corrupt xlsx, random bytes .xlsx
open('X09_corrupt.xlsx', 'wb').write(open('X01_finance.xlsx', 'rb').read()[:3000])
open('X10_text.xlsx', 'w').write('this is not a spreadsheet')
print('ok')
