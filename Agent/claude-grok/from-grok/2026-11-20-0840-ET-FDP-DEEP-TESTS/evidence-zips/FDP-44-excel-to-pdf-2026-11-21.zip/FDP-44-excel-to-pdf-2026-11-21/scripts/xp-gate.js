// excel-to-pdf gate (guest). Part 1 needs a fresh context with trial uses left (tries up to 20): counts on page load / reload, file drop, Convert to PDF, Preview, Download (x2 same result), Drive/cloud (stop at sign-in, close popup);
// then Convert another file -> X02 -> Download and X07 -> Download in the SAME page load (per-page-load charging?); reload; X06 -> Download.
// Part 2 (context at 0): keyboard to the drop zone; X01 Convert at 0 -> notice + Preview first page size -> Download -> cap -> Day Pass (email prompt, types nothing); Drive/cloud at 0; Quick Buy day/monthly (stop at email / Stripe).
const { chromium } = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const crypto = require('crypto');
const BASE = '/workspace/deep/44-excel-to-pdf/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/excel-to-pdf';
fs.mkdirSync(OUT + 'downloads', { recursive: true });
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex').slice(0, 16);
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').slice(0, 160);
const part = process.argv[2] || '12';
(async () => { const b = await chromium.launch(); const R = { t: now(), tries: [] }; let c, p;
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); p = await c.newPage(); p.setDefaultTimeout(15000); await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 const strip = () => p.evaluate(() => (document.querySelector('main').innerText.match(/Trial:[^\n]*/) || [''])[0]);
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 const ocr = async (file) => { const r = { file, beforeDrop: await used() }; await p.locator('main input[type=file]').first().setInputFiles(TF + file); await p.waitForTimeout(2500); r.afterDrop = await used(); const t0 = Date.now(); await p.getByRole('button', { name: 'Convert to PDF' }).click();
   for (let i = 0; i < 240; i++) { await p.waitForTimeout(1000); if (await p.getByRole('button', { name: /Convert another file/ }).count() || await p.locator('main [role=alert]').count()) break; }
   await p.waitForTimeout(1500); r.ms = Date.now() - t0; r.afterConvert = await used(); r.status = await p.evaluate(() => [...document.querySelectorAll('main [role=status], main [role=alert]')].map(e => e.innerText.trim()).filter(Boolean).join(' | ').slice(0, 600)); r.summary = await p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*sheet[^\n]*page[^\n]*/i) || [''])[0]); r.dl = await p.evaluate(() => [...document.querySelectorAll('main button')].map(e => e.innerText).find(x => /^Download/.test(x)) || null); r.toasts = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim())); return r; };
 const act = async (name, loc) => { const r = { before: await used() }; if (!(await loc.count())) { r.missing = true; return r; }
   const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); const dl = p.waitForEvent('download', { timeout: 15000 }).catch(() => null); const url0 = p.url(); await loc.first().click(); const [pg, d] = await Promise.all([pop, dl]); await p.waitForTimeout(2500);
   r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null; r.t = now(); r.status = await p.evaluate(() => [...document.querySelectorAll('main [role=status], main [role=alert]')].map(e => e.innerText.trim()).filter(Boolean).join(' | ').slice(0, 300)); r.toasts = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim()));
   if (d) { r.download = d.suggestedFilename(); const f = OUT + 'downloads/gate-' + name + '-' + d.suggestedFilename(); await d.saveAs(f); r.bytes = fs.statSync(f).size; r.sha = sha(f); }
   if (pg) { await pg.waitForLoadState('domcontentloaded').catch(() => {}); r.popup = red(pg.url()); r.popupTitle = await pg.title().catch(() => null); await pg.screenshot({ path: OUT + 'popup-' + name + '.png' }).catch(() => {}); await pg.close(); }
   if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + '.png' });
   if (r.dialog && /Day Pass/.test(r.dialog) && !R.dayPassFromCap) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.dayPassFromCap = { from: name, dialog: await dialog(), emailField: await p.locator('input[type=email]').count(), url: red(p.url()) }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); } }
   await esc(); console.log(name, JSON.stringify(r).slice(0, 600)); return r; };
 const DL = () => p.getByRole('button', { name: /^Download/ });
 const reload = async () => { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); };
 const preview = async (shot) => { const pv = p.getByRole('button', { name: /Preview first page/ }); if (!(await pv.count())) return null; await pv.click(); await p.waitForTimeout(3500); const r = await p.evaluate(() => [...document.querySelectorAll('main img, main canvas')].filter(e => (e.alt || '').match(/preview/i) || e.tagName === 'CANVAS').map(e => ({ tag: e.tagName, alt: e.alt || '', nw: e.naturalWidth || e.width, nh: e.naturalHeight || e.height, cw: e.clientWidth }))); await p.screenshot({ path: OUT + shot, fullPage: false }); return r; };
 if (part.includes('1')) { for (let i = 0; i < 20; i++) { await open(); const u = await used(); R.tries.push(u); if (u < 10) { await p.waitForTimeout(6000); const u2 = await used(); R.tries.push('recheck ' + u2); if (u2 < 10) break; } await c.close(); c = null; }
  if (c) { const L = R.left = { t: now(), start: await used(), strip: await strip() };
   await reload(); L.reload1 = await used(); await reload(); L.reload2 = await used(); L.strip2 = await strip();
   L.oA = await ocr('X01_finance.xlsx'); L.previewA = await preview('left-preview.png'); L.afterPreview = await used(); L.dlA = await act('A', DL()); L.dlA2 = await act('A2', DL());
   L.drive = await act('drive', p.getByRole('button', { name: /Save to Google Drive/ })); L.cloud = await act('cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
   const another = async () => { await p.getByRole('button', { name: /Convert another file/ }).click(); await p.waitForTimeout(1000); };
   await another(); L.oB = await ocr('X02_wide.xlsx'); L.dlB = await act('B', DL()); await another(); L.oC = await ocr('X07_plain.csv'); L.dlC = await act('C', DL());
   await reload(); L.afterReload = await used(); L.oD = await ocr('X06_utf8_bom_semicolon.csv'); L.dlD = await act('D', DL());
   await reload(); L.end = await used(); L.t2 = now(); await p.screenshot({ path: OUT + 'left-end.png' }); await c.close(); c = null; } }
 if (part.includes('2')) { for (let i = 0; i < 4; i++) { await open(); if (await used() >= 10) break; await c.close(); }
  const Z = R.zero = { t: now(), start: await used(), strip: await strip() };
  let chooser = false; p.on('filechooser', () => { chooser = true; }); const seq = [];
  for (let i = 0; i < 40; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('role') || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 50).replace(/\n/g, ' '); }); seq.push(a); if (/Drop an Excel or CSV file/i.test(a)) { await p.keyboard.press('Enter'); await p.waitForTimeout(1200); seq.push('ENTER -> chooser=' + chooser); break; } }
  Z.kbd = { tabs: seq.length, last: seq.slice(-3), chooser };
  Z.o = await ocr('X01_finance.xlsx'); await p.screenshot({ path: OUT + 'zero-done.png', fullPage: false }); Z.preview = await preview('zero-preview.png'); Z.afterPreview = await used();
  Z.dl = await act('zero-dl', DL()); Z.drive = await act('zero-drive', p.getByRole('button', { name: /Save to Google Drive/ })); Z.cloud = await act('zero-cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
  Z.fcs = await act('zero-fcs', p.getByRole('link', { name: /File Conversion Studio with EXCEL/ })); Z.fcsPage = { url: red(p.url()), text: await p.evaluate(() => (document.querySelector('main')?.innerText || '').slice(0, 500)) }; await p.screenshot({ path: OUT + 'zero-fcs.png' });
  Z.end = await used();
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  const qb = p.getByRole('button', { name: 'Quick Buy' }); const u0 = p.url(); await qb.first().click(); await p.waitForTimeout(3000); Z.qbDay = { url: p.url() !== u0 ? red(p.url()) : null, dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await esc();
  if (p.url() !== u0) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); }
  await p.getByRole('button', { name: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); Z.qbMonth = { url: red(p.url()), dialog: await dialog(), title: await p.title(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' }); }
 R.t2 = now(); fs.writeFileSync(OUT + 'gate-' + part + '.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify({ tries: R.tries, left: !!R.left }, null, 1)); await b.close(); })();
