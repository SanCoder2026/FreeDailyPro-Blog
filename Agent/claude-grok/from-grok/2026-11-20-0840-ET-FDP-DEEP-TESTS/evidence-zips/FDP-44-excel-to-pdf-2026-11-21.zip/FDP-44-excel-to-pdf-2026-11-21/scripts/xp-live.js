// FDP-44 Excel to PDF functional cases (guest). Usage: node xp-live.js <chromium|firefox|webkit> [T01,T02,...] [nodl]
// Looks for a fresh context with trial uses left (one page load serves every case, because Download charges once per page load: itself a finding);
// at 0 it still converts and records the summary/notes, without downloads. Never clicks a pass, never types an email, never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/44-excel-to-pdf/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/excel-to-pdf';
const eng = process.argv[2] || 'chromium'; const only = process.argv[3] && process.argv[3] !== 'all' ? process.argv[3].split(',') : null; const nodl = process.argv[4] === 'nodl'; const sfx = eng === 'chromium' ? '' : '-' + eng;
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); fs.mkdirSync(OUT + 'downloads', { recursive: true }); fs.mkdirSync(OUT + 'cases', { recursive: true });
(async () => { const b = await pw[eng].launch(); let c, p; const R = { t: now(), engine: eng, tries: [], cases: {} };
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true, locale: 'en-US' }); p = await c.newPage(); p.setDefaultTimeout(15000); await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000); };
 const used = () => p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 for (let i = 0; i < 14; i++) { await open(); const u = await used(); R.tries.push(u); if (nodl) break; if (u < 10) { await p.waitForTimeout(5000); if ((await used()) < 10) break; } if (i < 13) await c.close(); }
 R.start = await used(); const canDl = R.start < 10 && !nodl;
 const texts = () => p.evaluate(() => [...document.querySelectorAll('main [role=status], main [role=alert]')].map(e => e.innerText.trim()).filter(t => t && !/remaining today|Opening Google/.test(t)));
 const toasts = () => p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim()));
 const reset = async () => { for (const n of [/Convert another file/, /Choose a different file/]) { const x = p.getByRole('button', { name: n }); if (await x.count()) { await x.first().click(); await p.waitForTimeout(800); return; } } };
 const pick = async (group, label) => { const g = p.locator(`[aria-label="${group}"]`); await g.getByRole('button', { name: label, exact: true }).click(); };
 const box = async (label, on) => { const l = p.getByLabel(label); if (!(await l.count())) return 'absent'; const st = await l.isChecked(); if (st !== on) await l.click(); return 'set ' + on; };
 const run = async (id, file, opts = {}) => { if (only && !only.includes(id)) return; const r = { file, opts, t: now() };
  try { await reset(); await p.locator('main input[type=file]').first().setInputFiles(TF + file); await p.waitForTimeout(2500);
   r.beforeConvert = await texts(); r.boxes = await p.evaluate(() => [...document.querySelectorAll('main label')].map(l => l.innerText.trim()).filter(t => /Grid|Keep|Include/.test(t)));
   if (opts.size) await pick('Page size', opts.size); if (opts.orient) await pick('Orientation', opts.orient); if (opts.text) await pick('Text size', opts.text);
   if ('grid' in opts) r.grid = await box('Grid lines between cells', opts.grid); if ('colours' in opts) r.colours = await box('Keep colours, bold and borders', opts.colours); if ('hidden' in opts) r.hidden = await box('Include hidden data', opts.hidden);
   const cv = p.getByRole('button', { name: 'Convert to PDF' }); r.convertEnabled = (await cv.count()) ? await cv.isEnabled() : false;
   if (r.convertEnabled) { const t0 = Date.now(); await cv.click(); for (let i = 0; i < 300; i++) { await p.waitForTimeout(500); if (await p.getByRole('button', { name: /Convert another file/ }).count() || (await texts()).some(t => /fail|could not|couldn|not a|isn't|is not/i.test(t))) break; } r.ms = Date.now() - t0; }
   r.after = await texts(); r.toasts = await toasts(); r.used = await used();
   if (canDl && await p.getByRole('button', { name: /^Download/ }).count()) { const dp = p.waitForEvent('download', { timeout: 20000 }).catch(() => null); await p.getByRole('button', { name: /^Download/ }).first().click(); const d = await dp; await p.waitForTimeout(800);
    if (d) { const f = OUT + 'downloads/' + id + sfx + '-' + d.suggestedFilename(); await d.saveAs(f); r.download = { name: d.suggestedFilename(), bytes: fs.statSync(f).size }; } r.usedAfterDl = await used(); r.dialog = await p.locator('[role=dialog]').count() ? (await p.locator('[role=dialog]').first().innerText()).slice(0, 200) : null; if (r.dialog) await p.keyboard.press('Escape'); }
  } catch (e) { r.err = e.message.slice(0, 250); }
  await p.screenshot({ path: OUT + 'cases/' + id + sfx + '.png' }).catch(() => {}); R.cases[id] = r; console.log(id, JSON.stringify(r).slice(0, 500)); };
 await run('T01', 'X01_finance.xlsx');
 await run('T02', 'X01_finance.xlsx', { hidden: true });
 await run('T03', 'X01_finance.xlsx', { size: 'A4', orient: 'Landscape', text: 'Large', grid: false, colours: false });
 await run('T04', 'X02_wide.xlsx');
 await run('T05', 'X02_wide.xlsx', { orient: 'Landscape', text: 'Small' });
 await run('T06', 'X03_scripts.xlsx');
 await run('T07', 'X04_formulas_nocache.xlsx');
 await run('T08', 'X05_large_50k.xlsx');
 await run('T09', 'X06_utf8_bom_semicolon.csv');
 await run('T10', 'X07_plain.csv');
 await run('T11', 'X08_empty.xlsx');
 await run('T12', 'X09_corrupt.xlsx');
 await run('T13', 'X10_text.xlsx');
 await run('T14', 'X11_finance.xls');
 await run('T15', 'X12_finance.ods');
 await run('T16', 'X13_word.docx');
 await run('T17', 'X14_finance.xlsm');
 await run('T18', 'X15_libreoffice_resaved.xlsx');
 R.end = now(); R.endUsed = await used(); await p.reload(); await p.waitForTimeout(5000); R.afterReload = await used();
 fs.writeFileSync(OUT + 'cases-' + eng + (only ? '-' + only.join('_') : '') + '.json', JSON.stringify(R, null, 1)); console.log('tries', R.tries, 'start', R.start, 'end', R.endUsed, R.afterReload); await b.close(); })();
