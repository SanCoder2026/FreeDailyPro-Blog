import { r as d, j as e } from "./vendor-react-D01g8YgM.js";
import {
  n as Le,
  T as ke,
  F as Ee,
  P as Ce,
  D as Re,
  R as Fe,
} from "./ToolPage-DwLoDncN.js";
import { p as Ne } from "./utils-s8ucLyj8.js";
import { toPng as He } from "./index-BJ-mfDgp.js";
import { k as De, S as Ie, e as Be, P as Oe } from "./index-BRvxULIc.js";
import { c as We } from "./pdfFonts-Ckcqm3Ic.js";
import { f as H, e as Ue, T as _e, B as K } from "./index-B1CTyGtY.js";
import { T as $e } from "./ToolInfoSection-C0i6Zbwo.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
function ze(w, b, g, j) {
  const v = [0];
  if (g <= 0) return v;
  const I = Array.from(new Set(b.filter((r) => r > 0 && r < j))).sort(
      (r, M) => r - M,
    ),
    C = [...w].filter((r) => r.bottom > r.top).sort((r, M) => r.top - M.top);
  let l = 0,
    u = 0;
  for (; (l + g < j || I.some((r) => r > l + 1)) && u++ < 1e5;) {
    let r = Math.min(l + g, j);
    const M = I.find((A) => A > l + 1 && A < r);
    if (M !== void 0) r = M;
    else {
      let A = !0,
        $ = 0;
      for (; A && $++ < 50;) {
        A = !1;
        for (const P of C)
          P.top < r &&
            P.bottom > r &&
            P.top > l + 1 &&
            P.bottom - P.top <= g &&
            ((r = P.top), (A = !0));
      }
      r <= l + 1 && (r = l + g);
    }
    (v.push(r), (l = r));
  }
  return v;
}
const Q = {
    what: "Converts HTML content into a PDF — paste HTML code directly, or drop a local .html file, and it's rendered and converted, rows, pictures and list items are kept whole across page breaks, text stays selectable for Western European characters and links stay clickable. Scripts in the pasted HTML never run.",
    how: "Paste your HTML into the box, or drop a .html file to load its content into the box automatically, then click Convert. Choose page size, orientation, margins and optional page numbers, then download.",
    tip: `This renders HTML you provide directly — it can't fetch and convert an arbitrary live webpage by URL, since most sites block that kind of cross-origin access from a browser for security reasons (the same restriction any browser-based tool runs into, not something specific to this one). If you want a specific webpage as a PDF, most browsers can already do that natively through the Print dialog's "Save as PDF" option. External images referenced by URL in your HTML may not appear if the source blocks cross-origin loading — images embedded as data URLs always work.`,
  },
  qe = `<div style="font-family: Arial, sans-serif; padding: 40px; max-width: 700px;">
  <div style="color: #0d9488; font-size: 2em; font-weight: bold; margin-bottom: 0.5em;">Sample Document</div>
  <p>Paste your own HTML here to convert it into a PDF.</p>
  <ul>
    <li>Real HTML rendering, not a screenshot of a live site</li>
    <li>Basic styling (inline styles and &lt;style&gt; tags) is supported</li>
  </ul>
</div>`,
  he = { A4: [595.28, 841.89], Letter: [612, 792], Legal: [612, 1008] },
  Ye =
    "<style>html{background:#fff;color:#000}body{margin:0;overflow-wrap:anywhere}</style>",
  me = 200,
  Ge = 4e3,
  pe =
    "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7",
  D = () => new Promise((w) => requestAnimationFrame(() => w())),
  Ve = (w, b) =>
    new Promise((g, j) => {
      const v = setTimeout(() => j(new Error("render timeout")), 2e4);
      ((w.onload = () => {
        (clearTimeout(v), g(w.contentDocument));
      }),
        (w.srcdoc = Ye + b));
    });
function kt() {
  const w = Le() !== null,
    [b, g] = d.useState(w ? "" : qe),
    [j, v] = d.useState(!1),
    [I, C] = d.useState(""),
    [l, u] = d.useState(null),
    [r, M] = d.useState("A4"),
    [A, $] = d.useState(!1),
    [P, ue] = d.useState(15),
    [J, fe] = d.useState(!1),
    [ee, te] = d.useState("document"),
    oe = d.useRef(null),
    B = d.useRef(!1);
  d.useEffect(
    () => () => {
      B.current = !0;
    },
    [],
  );
  const ge = d.useCallback((a) => {
      const h = a[0];
      if (!h) return;
      const x = new FileReader();
      ((x.onload = () => {
        (g(String(x.result ?? "")),
          te(h.name.replace(/\.html?$/i, "") || "document"),
          u(null));
      }),
        (x.onerror = () => H.error("Couldn't read this file")),
        x.readAsText(h));
    }, []),
    xe = async () => {
      if (!b.trim()) {
        H.error("Paste some HTML first");
        return;
      }
      const a = oe.current;
      if (a) {
        ((B.current = !1), v(!0), u(null));
        try {
          C("Preparing…");
          let [h, x] = he[r];
          A && ([h, x] = [x, h]);
          const L = (P / 25.4) * 72,
            re = h - 2 * L,
            ye = x - 2 * L,
            ne = Math.round((re / 72) * 96);
          ((a.style.width = ne + "px"), (a.style.height = "800px"));
          const m = await Ve(a, b);
          (await D(),
            await Promise.all(
              Array.from(m.images).map((t) =>
                t.complete
                  ? Promise.resolve()
                  : new Promise((n) => {
                      (t.addEventListener("load", () => n(), { once: !0 }),
                        t.addEventListener("error", () => n(), { once: !0 }),
                        setTimeout(n, 5e3));
                    }),
              ),
            ),
            m.querySelectorAll("img").forEach((t) => {
              (!t.complete || t.naturalWidth === 0) &&
                (t.removeAttribute("srcset"), t.setAttribute("src", pe));
            }),
            await D());
          const se = m.documentElement,
            O = m.body,
            E = Math.max(se.scrollWidth, O.scrollWidth, ne);
          ((a.style.width = E + "px"), await D());
          const y = re / E,
            we = Math.floor(ye / y),
            W = Math.max(se.scrollHeight, O.scrollHeight);
          ((a.style.height = W + "px"), await D());
          const ae = [],
            ie = [],
            R = m.defaultView.scrollY || 0;
          (m
            .querySelectorAll(
              "tr,img,svg,canvas,li,p,h1,h2,h3,h4,h5,h6,pre,blockquote,figure",
            )
            .forEach((t) => {
              const n = t.getBoundingClientRect();
              ae.push({ top: n.top + R, bottom: n.bottom + R });
            }),
            m.querySelectorAll("*").forEach((t) => {
              const n = m.defaultView.getComputedStyle(t),
                i =
                  n.getPropertyValue("break-before") ||
                  n.getPropertyValue("page-break-before");
              (i === "page" ||
                i === "always" ||
                i === "left" ||
                i === "right") &&
                ie.push(t.getBoundingClientRect().top + R);
            }));
          const c = ze(ae, ie, we, W);
          if (c.length > me) throw new Error("too many pages");
          const f = await De.create(),
            z = await f.embedFont(Ie.Helvetica),
            q = m.title?.trim();
          (f.setTitle(q || ee),
            f.setProducer("FreeDailyPro"),
            f.setCreator("FreeDailyPro"),
            q &&
              te((t) =>
                t === "document"
                  ? q.replace(/[\\/:*?"<>|]+/g, "_").slice(0, 80)
                  : t,
              ));
          const le = [],
            be = m.createTreeWalker(O, NodeFilter.SHOW_TEXT);
          let F;
          const Y = m.createRange();
          for (; (F = be.nextNode());) {
            const t = F.parentElement;
            if (!t || /^(SCRIPT|STYLE|NOSCRIPT|TITLE)$/.test(t.tagName))
              continue;
            const n = F.textContent ?? "",
              i = /\S+/g;
            let p;
            for (; (p = i.exec(n));) {
              if (!Array.from(p[0]).every((k) => We(k.codePointAt(0))))
                continue;
              (Y.setStart(F, p.index), Y.setEnd(F, p.index + p[0].length));
              const s = Y.getClientRects()[0];
              s &&
                s.width > 0 &&
                s.height > 0 &&
                le.push({
                  text: p[0],
                  x: s.left,
                  y: s.top + R,
                  w: s.width,
                  h: s.height,
                });
            }
          }
          const ce = [];
          m.querySelectorAll("a[href]").forEach((t) => {
            const n = t.href;
            if (!/^(https?:|mailto:)/i.test(n)) return;
            const i = t.getBoundingClientRect();
            i.width > 0 &&
              i.height > 0 &&
              ce.push({
                href: n,
                x: i.left,
                y: i.top + R,
                w: i.width,
                h: i.height,
              });
          });
          let S = null;
          for (let t = 0; t < c.length; t++) {
            if (B.current) {
              H.info("Stopped");
              return;
            }
            C(`Rendering page ${t + 1} of ${c.length}… keep this tab open`);
            const n = c[t],
              i = t + 1 < c.length ? c[t + 1] : W,
              p = Math.max(1, Math.ceil(i - n));
            if (!S || t >= S.endIdx) {
              let o = t;
              const T = c[t];
              for (; o + 1 < c.length && c[o + 1] - T < Ge;) o++;
              const Z = o + 1 < c.length ? c[o + 1] : W,
                N = Math.max(1, Math.ceil(Z - T)),
                U = Math.min(2, 8e3 / N, 8e3 / E),
                Me = await He(O.parentElement, {
                  cacheBust: !0,
                  imagePlaceholder: pe,
                  backgroundColor: "#ffffff",
                  pixelRatio: U,
                  width: E,
                  height: N,
                  style: {
                    transform: `translateY(${-T}px)`,
                    transformOrigin: "top left",
                    margin: "0",
                  },
                }),
                _ = new Image();
              (await new Promise((Se, je) => {
                ((_.onload = () => Se()),
                  (_.onerror = () => je(new Error("capture failed"))),
                  (_.src = Me));
              }),
                (S = { startY: T, endIdx: o + 1, img: _, ratio: U }));
            }
            const s = document.createElement("canvas");
            ((s.width = Math.max(1, Math.round(E * S.ratio))),
              (s.height = Math.max(1, Math.round(p * S.ratio))));
            const k = s.getContext("2d");
            ((k.fillStyle = "#fff"),
              k.fillRect(0, 0, s.width, s.height),
              k.drawImage(
                S.img,
                0,
                Math.round((n - S.startY) * S.ratio),
                s.width,
                s.height,
                0,
                0,
                s.width,
                s.height,
              ));
            const Pe = s.toDataURL("image/png"),
              Te = Uint8Array.from(atob(Pe.split(",")[1]), (o) =>
                o.charCodeAt(0),
              ),
              ve = await f.embedPng(Te),
              G = f.addPage([h, x]),
              de = p * y,
              V = x - L;
            G.drawImage(ve, { x: L, y: V - de, width: E * y, height: de });
            for (const o of le) {
              if (o.y < n - 0.5 || o.y + o.h > i + 0.5) continue;
              const T = Math.max(1, o.h * y * 0.8);
              G.drawText(o.text, {
                x: L + o.x * y,
                y: V - (o.y - n + o.h * 0.8) * y,
                size: T,
                font: z,
                opacity: 0,
              });
            }
            const X = [];
            for (const o of ce) {
              if (o.y < n - 0.5 || o.y + o.h > i + 0.5) continue;
              const T = L + o.x * y,
                Z = T + o.w * y,
                N = V - (o.y - n) * y,
                U = N - o.h * y;
              X.push(
                f.context.register(
                  f.context.obj({
                    Type: "Annot",
                    Subtype: "Link",
                    Rect: [T, U, Z, N],
                    Border: [0, 0, 0],
                    A: { Type: "Action", S: "URI", URI: Be.of(o.href) },
                  }),
                ),
              );
            }
            (X.length && G.node.set(Oe.of("Annots"), f.context.obj(X)),
              await D());
          }
          if (J) {
            const t = f.getPages();
            t.forEach((n, i) => {
              const p = `Page ${i + 1} of ${t.length}`,
                s = 9,
                k = z.widthOfTextAtSize(p, s);
              n.drawText(p, {
                x: (h - k) / 2,
                y: Math.max(12, L / 2 - s / 2),
                size: s,
                font: z,
                opacity: 0.6,
              });
            });
          }
          const Ae = await f.save();
          (u(Ne(Ae)),
            H.success(
              `Converted to PDF — ${c.length} page${c.length === 1 ? "" : "s"}`,
            ));
        } catch (h) {
          (console.error("HTML to PDF failed:", h),
            H.error(
              String(h?.message) === "too many pages"
                ? `This document is longer than ${me} pages — split it and convert in parts`
                : "Couldn't convert this HTML — check that it's valid and try again",
            ));
        } finally {
          (v(!1), C(""));
        }
      }
    };
  return e.jsxs(ke, {
    children: [
      e.jsxs("div", {
        className: "space-y-4",
        children: [
          e.jsxs("div", {
            className:
              "p-3 rounded-lg border bg-muted/50 text-xs text-muted-foreground flex flex-wrap gap-x-4 gap-y-1",
            children: [
              e.jsx("span", {
                children:
                  "🔒 Runs in your browser; your HTML is never uploaded (images or styles it links to are still fetched from their own sites)",
              }),
              e.jsx("span", {
                children:
                  "📋 Paste HTML or drop a local .html file — no live URL fetching",
              }),
              e.jsx("span", {
                children: "🛡️ Scripts in your HTML are not run",
              }),
            ],
          }),
          e.jsxs("div", {
            children: [
              e.jsx(Ue, { htmlFor: "h2p-html", children: "HTML Content" }),
              e.jsx(_e, {
                id: "h2p-html",
                value: b,
                onChange: (a) => {
                  (g(a.target.value), u(null));
                },
                rows: 12,
                className: "font-mono text-xs",
                placeholder: "Paste your HTML here, or drop a .html file below",
              }),
            ],
          }),
          e.jsx(Ee, {
            gateAtDownload: !0,
            accept: ".html,.htm",
            onFiles: ge,
            label: "Or drop a local .html file to load it",
            description: "Reads the file's content directly into the box above",
          }),
          e.jsxs("div", {
            className: "flex flex-wrap gap-4 items-end text-sm",
            children: [
              e.jsxs("label", {
                className: "flex flex-col gap-1",
                children: [
                  "Page size",
                  e.jsx("select", {
                    "aria-label": "Page size",
                    className: "border rounded px-2 py-1 bg-background",
                    value: r,
                    onChange: (a) => {
                      (M(a.target.value), u(null));
                    },
                    children: Object.keys(he).map((a) =>
                      e.jsx("option", { children: a }, a),
                    ),
                  }),
                ],
              }),
              e.jsxs("label", {
                className: "flex items-center gap-2",
                children: [
                  e.jsx("input", {
                    type: "checkbox",
                    checked: J,
                    onChange: (a) => {
                      (fe(a.target.checked), u(null));
                    },
                  }),
                  " Page numbers (footer)",
                ],
              }),
              e.jsxs("label", {
                className: "flex items-center gap-2",
                children: [
                  e.jsx("input", {
                    type: "checkbox",
                    checked: A,
                    onChange: (a) => {
                      ($(a.target.checked), u(null));
                    },
                  }),
                  " Landscape",
                ],
              }),
              e.jsxs("label", {
                className: "flex flex-col gap-1",
                children: [
                  "Margin (mm)",
                  e.jsx("input", {
                    type: "number",
                    "aria-label": "Margin in millimetres",
                    min: 0,
                    max: 50,
                    className: "border rounded px-2 py-1 w-20 bg-background",
                    value: P,
                    onChange: (a) => {
                      (ue(
                        Math.min(50, Math.max(0, Number(a.target.value) || 0)),
                      ),
                        u(null));
                    },
                  }),
                ],
              }),
            ],
          }),
          e.jsx("iframe", {
            ref: oe,
            title: "HTML render area",
            sandbox: "allow-same-origin",
            "aria-hidden": "true",
            tabIndex: -1,
            style: {
              position: "fixed",
              left: "-99999px",
              top: 0,
              width: 800,
              height: 800,
              border: 0,
              background: "#fff",
            },
          }),
          e.jsx("div", {
            className: "flex gap-3 items-center",
            children: j
              ? e.jsxs(e.Fragment, {
                  children: [
                    e.jsx(Ce, {}),
                    e.jsx("span", {
                      className: "text-xs text-muted-foreground",
                      children: I,
                    }),
                    e.jsx(K, {
                      variant: "outline",
                      onClick: () => {
                        B.current = !0;
                      },
                      children: "Stop",
                    }),
                  ],
                })
              : l
                ? e.jsxs(e.Fragment, {
                    children: [
                      e.jsx(Re, { blob: l, fileName: `${ee}.pdf` }),
                      e.jsx(K, {
                        variant: "outline",
                        onClick: () => u(null),
                        children: "Edit",
                      }),
                    ],
                  })
                : e.jsxs(e.Fragment, {
                    children: [
                      e.jsx(K, {
                        onClick: xe,
                        disabled: !b.trim(),
                        children: "Convert to PDF",
                      }),
                      !b.trim() &&
                        e.jsx("span", {
                          className: "text-xs text-muted-foreground",
                          role: "status",
                          children:
                            "Paste some HTML or drop a .html file to enable Convert.",
                        }),
                    ],
                  }),
          }),
          l && e.jsx(Fe, { blob: l, mimeType: "application/pdf" }),
        ],
      }),
      e.jsx($e, { whatIsIt: Q.what, howToUse: Q.how, tip: Q.tip }),
    ],
  });
}
export { kt as default };
//# sourceMappingURL=HtmlToPdf-DMdSWHCi.js.map
