// FDP-45 HTML to PDF, guest. Usage: node hp-live.js <zero|left|subset> [engine]
//  zero:   context at 0 -> sample convert, preview, Download/Drive/cloud dialogs, Day Pass (stops at email), Quick Buy day/monthly (stops at email/Stripe), keyboard.
//  left:   context with uses left -> every case in ONE page load with Download (per-page-load charging check), then reload + Download.
//  subset: firefox/webkit at 0, conversion toasts only.
// Never types an email/card, never clicks a pass "Continue", never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const crypto = require('crypto');
const BASE = '/workspace/deep/45-html-to-pdf/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/html-to-pdf';
const mode = process.argv[2] || 'left'; const eng = process.argv[3] || 'chromium'; const sfx = eng === 'chromium' ? '' : '-' + eng;
fs.mkdirSync(OUT + 'downloads', { recursive: true }); fs.mkdirSync(OUT + 'cases', { recursive: true });
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex').slice(0, 16);
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').slice(0, 160);
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p; const net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true, locale: 'en-US' }); p = await c.newPage(); p.setDefaultTimeout(15000);
  await p.addInitScript(() => { window.__t = []; new MutationObserver(ms => ms.forEach(m => m.addedNodes.forEach(n => { if (n.nodeType === 1 && n.matches && n.matches('[data-sonner-toast]')) setTimeout(() => window.__t.push(n.innerText.trim()), 50); }))).observe(document, { childList: true, subtree: true }); });
  p.on('request', r => { const d = r.postData() || ''; net.push({ t: Date.now(), m: r.method(), u: red(r.url()), len: d.length, hit: /INV-2026-045|Müller|Consulting hours|SCRIPT-RAN|Jane Doe/.test(d) }); });
  await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000); };
 const used = () => p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 const toasts = () => p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.trim()));
 const edit = async () => { const e = p.getByRole('button', { name: 'Edit', exact: true }); if (await e.count()) { await e.click(); await p.waitForTimeout(500); } };
 const setOpts = async (o = {}) => { await p.getByLabel('Page size').selectOption(o.size || 'A4'); const ls = p.getByLabel('Landscape'); if ((await ls.isChecked()) !== !!o.land) await ls.click();
  const pn = p.getByLabel('Page numbers (footer)'); if ((await pn.isChecked()) !== !!o.pn) await pn.click(); await p.getByLabel('Margin in millimetres').fill(String(o.margin ?? 15)); };
 const convert = async (id, src, o = {}) => { const r = { id, src, o, t: now(), before: await used() };
  try { await edit(); const tN = await p.evaluate(() => (window.__t || []).length);
   if (src === '') await p.locator('#h2p-html').fill(''); else if (o.drop) { await p.locator('main input[type=file]').first().setInputFiles(TF + src); await p.waitForTimeout(1500); } else if (src !== 'SAMPLE') await p.locator('#h2p-html').fill(fs.readFileSync(TF + src, 'utf8'));
   r.textareaHead = (await p.locator('#h2p-html').inputValue()).slice(0, 120); await setOpts(o); r.marginShown = await p.getByLabel('Margin in millimetres').inputValue();
   const cv = p.getByRole('button', { name: 'Convert to PDF' }); r.convertEnabled = await cv.isEnabled(); r.statusMsg = await p.evaluate(() => [...document.querySelectorAll('main [role=status]')].map(e => e.innerText.trim()).filter(t => t && !/remaining today/.test(t)));
   if (r.convertEnabled) { const t0 = Date.now(); await cv.click(); const prog = new Set();
    for (let i = 0; i < 600; i++) { await p.waitForTimeout(500); const txt = await p.evaluate(() => ((document.querySelector('main')?.innerText || 'APP-CRASH ' + document.body.innerText.slice(0,120)).match(/APP-CRASH[^\n]*|Rendering page[^\n]*|Preparing…/) || [''])[0]); if (txt) prog.add(txt.replace(/\d+ of/, 'N of'));
     if (await p.getByRole('button', { name: /^Download/ }).count() || (await p.evaluate(n => (window.__t || []).slice(n), tN)).some(t => /Couldn|longer than|Paste|Stopped/.test(t))) break; }
    r.ms = Date.now() - t0; r.progress = [...prog].slice(0, 4); }
   r.toasts = await p.evaluate(n => (window.__t || []).slice(n), tN); r.afterConvert = await used(); r.hasDownload = await p.getByRole('button', { name: /^Download/ }).count() > 0;
   r.previewBtn = await p.getByRole('button', { name: /Preview/ }).count();
   if (o.dl && r.hasDownload) { const dp = p.waitForEvent('download', { timeout: 20000 }).catch(() => null); await p.getByRole('button', { name: /^Download/ }).first().click(); const d = await dp; await p.waitForTimeout(1200);
    r.dialog = await dialog(); if (d) { const f = OUT + 'downloads/' + id + sfx + '-' + d.suggestedFilename(); await d.saveAs(f); r.download = { name: d.suggestedFilename(), bytes: fs.statSync(f).size, sha: sha(f) }; } r.afterDl = await used(); if (r.dialog) { await p.screenshot({ path: OUT + 'cases/' + id + '-dialog.png' }); await esc(); } }
  } catch (e) { r.err = e.message.slice(0, 300); }
  await p.screenshot({ path: OUT + 'cases/' + id + sfx + '.png' }).catch(() => {}); R.cases[id] = r; console.log(id, JSON.stringify(r).slice(0, 520)); return r; };
 const act = async (name, loc) => { const r = { before: await used() }; if (!(await loc.count())) { r.missing = true; return r; }
  const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); const dl = p.waitForEvent('download', { timeout: 10000 }).catch(() => null); const url0 = p.url(); await loc.first().click(); const [pg, d] = await Promise.all([pop, dl]); await p.waitForTimeout(2500);
  r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null; r.toasts = await toasts(); if (d) { r.download = d.suggestedFilename(); await d.saveAs(OUT + 'downloads/gate-' + name + '-' + d.suggestedFilename()); }
  if (pg) { await pg.waitForLoadState('domcontentloaded').catch(() => {}); r.popup = red(pg.url()); await pg.screenshot({ path: OUT + 'popup-' + name + '.png' }).catch(() => {}); await pg.close(); }
  if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + '.png' });
  if (r.dialog && /Day Pass/.test(r.dialog) && !R.dayPass) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.dayPass = { from: name, dialog: await dialog(), emailField: await p.locator('input[type=email]').count(), url: red(p.url()) }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); } }
  await esc(); console.log(name, JSON.stringify(r).slice(0, 500)); return r; };
 if (mode === 'left') { const NT = +(process.env.TRIES || 16); for (let i = 0; i < NT; i++) { await open(); const u = await used(); R.tries.push(u); if (u < 10) { await p.waitForTimeout(6000); if ((await used()) < 10) break; } if (i < NT - 1) await c.close(); }
  R.start = await used(); const dl = R.start < 10;
  await convert('L01', 'SAMPLE', { dl }); await convert('L01b-same', 'SAMPLE', { dl });
  R.drive = await act('drive', p.getByRole('button', { name: /Save to Google Drive/ })); R.cloud = await act('cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
  await convert('L02', 'H02_invoice.html', { dl }); await convert('L03', 'H03_breaks.html', { dl }); await convert('L04', 'H04_script.html', { dl }); await convert('L05', 'H05_metarefresh.html', { dl });
  await convert('L06', 'H06_scripts.html', { dl }); await convert('L07', 'H07_wide.html', { dl }); await convert('L08', 'H08_toolong.html', { dl }); await convert('L09', 'H09_cp1252.html', { dl, drop: true });
  await convert('L10', 'H10_resume.htm', { dl, drop: true, size: 'Letter', land: true, margin: 0, pn: true }); await convert('L11', 'H11_notes.txt', { dl, drop: true }); await convert('L12', 'H12_bigimage.html', { dl, size: 'Legal', margin: 50 });
  await convert('L13', 'H13_relative.html', { dl }); await convert('L14', 'H14_webfont.html', { dl }); await convert('L15', 'H02_invoice.html', { dl, margin: 99, pn: true }); await convert('L16', '', {});
  R.endUsed = await used(); await p.reload(); await p.waitForTimeout(5000); R.afterReload = await used(); await convert('L17-after-reload', 'H03_breaks.html', { dl: true }); R.final = await used(); }
 if (mode === 'zero' || mode === 'subset') { for (let i = 0; i < 5; i++) { await open(); const u = await used(); R.tries.push(u); if (u >= 10 || mode === 'subset') break; await c.close(); }
  R.start = await used();
  if (mode === 'zero') { let chooser = false; p.on('filechooser', () => { chooser = true; }); const seq = [];
   for (let i = 0; i < 45; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.id || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 40).replace(/\n/g, ' '); }); seq.push(a); if (/drop a local/i.test(a)) { await p.keyboard.press('Enter'); await p.waitForTimeout(1200); seq.push('ENTER chooser=' + chooser); break; } }
   R.kbd = { textareaReached: seq.some(s => /h2p-html/.test(s)), tabs: seq.length, last: seq.slice(-3) };
   await convert('Z01', 'SAMPLE', {}); await p.screenshot({ path: OUT + 'zero-done.png', fullPage: true });
   const pv = p.getByRole('button', { name: /Preview/ }); if (await pv.count()) { await pv.first().click(); await p.waitForTimeout(3000); R.preview = await p.evaluate(() => [...document.querySelectorAll('main img, main canvas, main iframe, main embed, main object')].map(e => ({ tag: e.tagName, alt: e.alt || e.title || '', nw: e.naturalWidth || e.width, nh: e.naturalHeight || e.height }))); await p.screenshot({ path: OUT + 'zero-preview.png' }); R.afterPreview = await used(); }
   R.dl = await act('zero-dl', p.getByRole('button', { name: /^Download/ })); R.drive = await act('zero-drive', p.getByRole('button', { name: /Save to Google Drive/ })); R.cloud = await act('zero-cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
   R.end = await used(); await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
   const u0 = p.url(); await p.getByRole('button', { name: 'Quick Buy' }).first().click(); await p.waitForTimeout(3000); R.qbDay = { url: p.url() !== u0 ? red(p.url()) : null, dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await esc();
   if (p.url() !== u0) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); }
   await p.getByRole('button', { name: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); R.qbMonth = { url: red(p.url()), title: await p.title(), dialog: await dialog() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' }); }
  else { await convert('S01', 'SAMPLE', {}); await convert('S02', 'H02_invoice.html', {}); await convert('S04', 'H04_script.html', {}); await convert('S06', 'H06_scripts.html', {}); await convert('S08', 'H08_toolong.html', {}); } }
 R.t2 = now(); R.net = { total: net.length, hits: net.filter(x => x.hit), posts: net.filter(x => x.m !== 'GET').map(x => ({ m: x.m, u: x.u, len: x.len })), hosts: [...new Set(net.map(x => { try { return new URL(x.u).host } catch (e) { return '?' } }))] };
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('tries', R.tries, 'start', R.start, 'end', R.endUsed, R.afterReload, R.final); await b.close(); })();
