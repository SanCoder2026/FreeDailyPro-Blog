// FDP-45: at 0 trial uses, convert each case and save the on-page "Preview first page" image (the normal guest path at 0). Usage: node hp-preview.js [engine]
const pw = require('playwright'); const fs = require('fs'); const OUT = '/workspace/deep/45-html-to-pdf/live/previews/'; const TF = '/workspace/deep/45-html-to-pdf/testfiles/'; fs.mkdirSync(OUT, { recursive: true });
const eng = process.argv[2] || 'chromium';
(async () => { const b = await pw[eng].launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(20000);
 await p.goto('https://www.freedailypro.com/tool/html-to-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); const R = {};
 for (const f of ['SAMPLE', 'H02_invoice.html', 'H04_script.html', 'H05_metarefresh.html', 'H06_scripts.html', 'H07_wide.html', 'H09_cp1252.html', 'H12_bigimage.html', 'H13_relative.html', 'H14_webfont.html']) { const r = R[f] = {};
  try { const e = p.getByRole('button', { name: 'Edit', exact: true }); if (await e.count()) await e.click();
   if (f === 'H09_cp1252.html') { await p.locator('main input[type=file]').first().setInputFiles(TF + f); await p.waitForTimeout(1500); } else if (f !== 'SAMPLE') await p.locator('#h2p-html').fill(fs.readFileSync(TF + f, 'utf8'));
   r.textarea = (await p.locator('#h2p-html').inputValue()).slice(0, 200);
   await p.getByRole('button', { name: 'Convert to PDF' }).click(); await p.getByRole('button', { name: /^Download/ }).waitFor({ timeout: 60000 });
   await p.getByRole('button', { name: /Preview/ }).first().click(); const img = p.locator('img[alt="First page preview"]'); await img.waitFor(); await p.waitForTimeout(800);
   r.size = await img.evaluate(e => [e.naturalWidth, e.naturalHeight]); await img.screenshot({ path: OUT + f.replace(/\..*/, '') + (eng === 'chromium' ? '' : '-' + eng) + '.png' });
  } catch (e) { r.err = e.message.slice(0, 200); } console.log(f, JSON.stringify(r).slice(0, 300)); }
 fs.writeFileSync(OUT + 'previews-' + eng + '.json', JSON.stringify(R, null, 1)); await b.close(); })();
