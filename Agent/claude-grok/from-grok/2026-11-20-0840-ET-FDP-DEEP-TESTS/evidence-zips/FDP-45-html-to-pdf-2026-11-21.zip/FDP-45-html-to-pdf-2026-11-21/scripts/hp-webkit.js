// FDP-45: WebKit hang check. For each file: convert at 0 (no download), wait up to 120 s for the Download button; if still rendering, press Stop and record what happens.
const pw = require('playwright'); const fs = require('fs'); const TF = '/workspace/deep/45-html-to-pdf/testfiles/'; const OUT = '/workspace/deep/45-html-to-pdf/live/';
const eng = process.argv[2] || 'webkit';
(async () => { const b = await pw[eng].launch(); const R = {};
 for (const f of ['H02b_invoice_noext.html', 'H14_webfont.html', 'H02_invoice.html', 'H10_resume.htm']) { const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(20000); const r = R[f] = {};
  const errs = []; p.on('console', m => { if (m.type() === 'error') errs.push(m.text().slice(0, 160)); }); p.on('pageerror', e => errs.push('pageerror ' + e.message.slice(0, 160)));
  try { await p.goto('https://www.freedailypro.com/tool/html-to-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); await p.locator('#h2p-html').fill(fs.readFileSync(TF + f, 'utf8'));
   const t0 = Date.now(); await p.getByRole('button', { name: 'Convert to PDF' }).click(); let done = false;
   for (let i = 0; i < 120; i++) { await p.waitForTimeout(1000); if (await p.getByRole('button', { name: /^Download/ }).count()) { done = true; break; } }
   r.done = done; r.ms = Date.now() - t0; r.status = await p.evaluate(() => (document.querySelector('main').innerText.match(/Rendering page[^\n]*|Preparing…/) || [''])[0]);
   if (!done) { await p.screenshot({ path: OUT + 'cases/WK-' + f.replace(/\..*/, '') + '-stuck.png' }); const st = p.getByRole('button', { name: 'Stop' }); r.stopVisible = await st.count(); if (r.stopVisible) { await st.click(); await p.waitForTimeout(8000); r.afterStop = { convertBack: await p.getByRole('button', { name: 'Convert to PDF' }).count(), status: await p.evaluate(() => (document.querySelector('main').innerText.match(/Rendering page[^\n]*/) || [''])[0]) }; await p.screenshot({ path: OUT + 'cases/WK-' + f.replace(/\..*/, '') + '-afterstop.png' }); } }
  } catch (e) { r.err = e.message.slice(0, 200); } r.errs = errs.filter(x => !/ads|google|doubleclick|fundingchoices|adsbygoogle/i.test(x)).slice(0, 6); console.log(f, JSON.stringify(r)); await c.close(); }
 fs.writeFileSync(OUT + 'hang-' + eng + '.json', JSON.stringify(R, null, 1)); await b.close(); })();
