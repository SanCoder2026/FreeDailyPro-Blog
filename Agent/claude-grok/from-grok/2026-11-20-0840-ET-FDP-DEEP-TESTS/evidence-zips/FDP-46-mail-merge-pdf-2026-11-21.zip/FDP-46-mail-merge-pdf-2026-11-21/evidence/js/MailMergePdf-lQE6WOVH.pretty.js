const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/drawTextAnywhere-DcuP6lHH.js",
      "assets/pdfFonts-Ckcqm3Ic.js",
      "assets/index-BRvxULIc.js",
      "assets/index-CnXdQaNG.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/index-DMQTJy3b.js",
      "assets/fontkit.es-DA-3qwB1.js",
    ]),
) => i.map((i) => d[i]);
import { r as T, j as t } from "./vendor-react-D01g8YgM.js";
import { J as ce } from "./jszip.min-CT0ZA6V1.js";
import {
  ap as me,
  e as _,
  B as E,
  T as W,
  I as Y,
  N as J,
  D as K,
  f as D,
} from "./index-B1CTyGtY.js";
import { b as de, T as pe, F as fe, d as X } from "./ToolPage-DwLoDncN.js";
import { T as he } from "./ToolInfoSection-C0i6Zbwo.js";
import { u as q } from "./useSessionState-BLsNNse9.js";
import { p as Q, a as ee } from "./csvParse-eP1CzDn2.js";
import { M as ue, s as we, m as ge } from "./mailMergeInput-CE4ApdO7.js";
import { k as te, S as se } from "./index-BRvxULIc.js";
import { needsPicture as xe } from "./drawTextAnywhere-DcuP6lHH.js";
import { s as be } from "./pdfFonts-Ckcqm3Ic.js";
import { p as oe } from "./utils-s8ucLyj8.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
const k = 500,
  ne = /\{\{\s*([^{}]+?)\s*\}\}/g;
function G(s) {
  const o = [],
    e = new Set(),
    r = new RegExp(ne.source, "g");
  let n;
  for (; (n = r.exec(s));) {
    const a = n[1].trim(),
      f = a.toLowerCase();
    e.has(f) || (e.add(f), o.push(a));
  }
  return o;
}
function re(s) {
  if (!s.length) return { headers: [], rows: [] };
  const o = s[0].map((r) => r.trim()),
    e = s.slice(1).filter((r) => r.some((n) => n.trim() !== ""));
  return { headers: o, rows: e };
}
function B(s, o) {
  const e = o.trim().toLowerCase().replace(/\s+/g, " ");
  return s.findIndex(
    (r) => r.trim().toLowerCase().replace(/\s+/g, " ") === e && r.trim() !== "",
  );
}
function ve(s, o) {
  return G(s).filter((e) => B(o, e) < 0);
}
function ie(s, o, e) {
  return s.replace(new RegExp(ne.source, "g"), (r, n) => {
    const a = B(o, n);
    return a < 0 ? r : (e[a] ?? "").trim();
  });
}
function je(s, o) {
  const e = G(s)
      .map((n) => B(o.headers, n))
      .filter((n) => n >= 0),
    r = [];
  return (
    o.rows.forEach((n, a) => {
      e.some((f) => (n[f] ?? "").trim() === "") && r.push(a + 1);
    }),
    r
  );
}
function Ne(s, o, e = new Set()) {
  const r = o ? B(s.headers, o) : -1;
  return s.rows.map((n, a) => {
    let f = (r >= 0 ? (n[r] ?? "") : "")
      .trim()
      .replace(/[\\/:*?"<>|\u0000-\u001f]+/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 60);
    f || (f = `record-${a + 1}`);
    let c = `${f}.pdf`;
    for (let g = 2; e.has(c.toLowerCase()); g++) c = `${f}-${g}.pdf`;
    return (e.add(c.toLowerCase()), c);
  });
}
async function Se(s, o, e) {
  const r = [];
  for (const n of s.replace(
    /\r\n?/g,
    `
`,
  ).split(`
`)) {
    if (n.trim() === "") {
      r.push("");
      continue;
    }
    let a = "";
    for (const f of n.split(/\s+/).filter(Boolean)) {
      let c = f;
      for (; (await e(c)) > o && c.length > 1;) {
        let x = c.length - 1;
        for (; x > 1 && (await e(c.slice(0, x))) > o;) x--;
        (a && (r.push(a), (a = "")), r.push(c.slice(0, x)), (c = c.slice(x)));
      }
      const g = a ? `${a} ${c}` : c;
      a && (await e(g)) > o ? (r.push(a), (a = c)) : (a = g);
    }
    r.push(a);
  }
  return r;
}
const V = {
    landscape: !1,
    fontSize: 12,
    align: "left",
    margin: 72,
    middle: !1,
    boldFirstLine: !1,
  },
  ae = {
    landscape: !0,
    fontSize: 24,
    align: "center",
    margin: 72,
    middle: !0,
    boldFirstLine: !0,
  };
function le(s) {
  return !Number.isFinite(s.fontSize) || s.fontSize < 6 || s.fontSize > 72
    ? "Type size has to be between 6 and 72."
    : !Number.isFinite(s.margin) || s.margin < 18 || s.margin > 144
      ? "Margin has to be between 0.25 and 2 inches."
      : null;
}
const Ce = 1.35;
async function ye(s, o, e, r, n) {
  const a = le(e);
  if (a) throw new Error(a);
  if (!o.rows.length) throw new Error("The table has no rows.");
  if (o.rows.length > k) throw new Error(`Up to ${k} rows at a time.`);
  const { drawTextAnywhere: f } = await me(
      async () => {
        const { drawTextAnywhere: p } =
          await import("./drawTextAnywhere-DcuP6lHH.js");
        return { drawTextAnywhere: p };
      },
      __vite__mapDeps([0, 1, 2, 3, 4, 5, 6]),
    ),
    c = Ne(o, r),
    g = e.landscape ? 792 : 612,
    x = e.landscape ? 612 : 792,
    O = g - 2 * e.margin,
    j = e.fontSize * Ce,
    z = Math.max(1, Math.floor((x - 2 * e.margin) / j)),
    F = await te.create(),
    A = [],
    P = [];
  let I = 0;
  const d = (p) => {
      const b = {};
      return {
        ready: (async () => {
          ((b.reg = await p.embedFont(se.Helvetica)),
            (b.bold = await p.embedFont(se.HelveticaBold)));
        })(),
        measure: (l, N) =>
          xe(l)
            ? l.length * e.fontSize
            : (N ? b.bold : b.reg).widthOfTextAtSize(be(l), e.fontSize),
      };
    },
    U = async (p, b, u) => {
      await u.ready;
      const l = b.replace(
        /\r\n?/g,
        `
`,
      ).split(`
`);
      let N = [];
      for (let h = 0; h < l.length; h++) {
        const C = e.boldFirstLine && h === 0,
          L = await Se(l[h], O, (S) => u.measure(S, C));
        for (const S of L) N.push({ t: S, bold: C });
      }
      const v = [];
      for (let h = 0; h < N.length; h += z) v.push(N.slice(h, h + z));
      v.length || v.push([]);
      for (const h of v) {
        const C = p.addPage([g, x]),
          L = h.length * j;
        let S = e.middle
          ? x / 2 + L / 2 - e.fontSize
          : x - e.margin - e.fontSize;
        for (const y of h) {
          if (y.t) {
            const $ = u.measure(y.t, y.bold),
              i = e.align === "center" ? g / 2 - $ / 2 : e.margin;
            await f(p, C, y.t, {
              x: i,
              y: S,
              size: e.fontSize,
              bold: y.bold,
              color: { r: 0, g: 0, b: 0 },
              rotateDegrees: 0,
            });
          }
          S -= j;
        }
      }
      return v.length;
    },
    R = d(F);
  for (let p = 0; p < o.rows.length; p++) {
    const b = ie(s, o.headers, o.rows[p]),
      u = await U(F, b, R);
    ((I += u), u > 1 && P.push(p + 1));
    const l = await te.create();
    (await U(l, b, d(l)),
      A.push({ name: c[p], blob: oe(await l.save()), pages: u }),
      n?.(p + 1, o.rows.length));
  }
  return {
    files: A,
    combined: oe(await F.save()),
    totalPages: I,
    overflowRows: P,
  };
}
const H = {
    what: "Turns a table of names and details plus a template into one page per person: letters, certificates, notices or award slips. Put {{Field}} in the template wherever a value from the table should go, for example Dear {{First Name}}. Download one PDF with every record, or a ZIP with a separate PDF for each. It runs in your browser, so the list is not uploaded.",
    how: "Paste your table (cells copied from Excel or Sheets work) or drop a CSV or Excel file. The first row has to be the column names. Write the template, using the same names inside double curly braces. Check the preview, step through a few records, then download.",
    tip: "Check for empty cells and misspelled field names in the notes under the preview before you print many pages. A field that is not in the table stays visible as {{Name}} so you can spot it.",
  },
  Te = `First Name,Last Name,Course,Date
Ana,Lopez,Intro to Gardening,Oct 24
Ben,Ng,Intro to Gardening,Oct 24`,
  Z = `Dear {{First Name}},

Thank you for joining {{Course}} on {{Date}}. We hope you enjoyed it.

Sincerely,
The Team`,
  Ee = `Certificate of Completion

This is to certify that

{{First Name}} {{Last Name}}

completed {{Course}} on {{Date}}`;
function ft() {
  const [s, o] = T.useState(""),
    [e, r] = T.useState(""),
    [n, a] = q("mm-kind", "letter"),
    [f, c] = q("mm-size", "12"),
    [g, x] = T.useState(""),
    [O, j] = T.useState(0),
    [z, F] = T.useState(!1),
    [A, P] = T.useState(""),
    { logUsageNow: I } = de(),
    d = T.useMemo(() => {
      if (!s.trim()) return null;
      const i = Q(s, ee(s));
      return re(i);
    }, [s]),
    R = { ...(n === "certificate" ? ae : V), fontSize: Number(f) },
    p = le(R),
    b = d ? ve(e, d.headers) : [],
    u = d ? je(e, d) : [],
    l = d?.rows.length ?? 0,
    N = !!d && l > 0 && e.trim().length > 0 && !p && l <= k,
    v = d && l ? Math.min(O, l - 1) : 0,
    h = d && l ? ie(e, d.headers, d.rows[v]) : "",
    C = (i) => {
      if ((o(i), j(0), !e.trim())) {
        const m = Q(i, ee(i)),
          w = re(m);
        w.rows.length > 0 && r(we(n, w.headers));
      }
    },
    L = async (i) => {
      const m = i[0];
      if (m)
        try {
          const w = await ge(m);
          (C(w.text), w.note && D.info(w.note));
        } catch (w) {
          (console.error(w),
            D.error(
              "Couldn't read that file. Use a CSV, a tab-separated text file or an Excel sheet.",
            ));
        }
    },
    S = (i) => {
      (a(i),
        c(String(i === "certificate" ? ae.fontSize : V.fontSize)),
        e.trim() || r(i === "certificate" ? Ee : Z));
    },
    y = () => {
      (o(Te), j(0), a("letter"), c(String(V.fontSize)), r(Z));
    },
    $ = async (i) => {
      if (!(!d || !N) && (await I())) {
        (F(!0), P(""));
        try {
          const m = await ye(e, d, R, g, (w, M) => P(`${w} of ${M}`));
          if (i === "one") X(m.combined, "merged-documents.pdf");
          else {
            const w = new ce();
            for (const M of m.files) w.file(M.name, M.blob);
            X(await w.generateAsync({ type: "blob" }), "merged-documents.zip");
          }
          m.overflowRows.length
            ? D.warning(
                `${m.overflowRows.length} record${m.overflowRows.length > 1 ? "s" : ""} ran onto more than one page (rows ${m.overflowRows.slice(0, 8).join(", ")}${m.overflowRows.length > 8 ? "..." : ""}). Shorten the text or lower the type size.`,
              )
            : D.success(`${l} document${l > 1 ? "s" : ""} ready.`);
        } catch (m) {
          (console.error(m),
            D.error(
              m instanceof Error && /rows|Type size|Margin/.test(m.message)
                ? m.message
                : "Could not build the PDFs. Try removing unusual symbols from the text.",
            ));
        } finally {
          (F(!1), P(""));
        }
      }
    };
  return t.jsxs(pe, {
    children: [
      t.jsxs("div", {
        className: "max-w-3xl mx-auto space-y-6",
        children: [
          t.jsxs("section", {
            className: "space-y-2",
            children: [
              t.jsxs("div", {
                className: "flex items-center justify-between gap-3 flex-wrap",
                children: [
                  t.jsx(_, {
                    htmlFor: "mm-csv",
                    className: "font-semibold",
                    children: "1. Your table (first row = column names)",
                  }),
                  t.jsx(E, {
                    variant: "outline",
                    size: "sm",
                    onClick: y,
                    children: "Use an example",
                  }),
                ],
              }),
              t.jsx(W, {
                id: "mm-csv",
                rows: 6,
                value: s,
                onChange: (i) => {
                  const m = i.target.value;
                  !s.trim() && m.length > 1 ? C(m) : (o(m), j(0));
                },
                placeholder:
                  "Paste cells from Excel or Sheets, or rows from a CSV file",
                className: "font-mono text-xs",
              }),
              t.jsx(fe, {
                accept: ue,
                maxSize: 20,
                onFiles: L,
                deferUsageLog: !0,
                label: "Or drop a CSV or Excel file",
                description:
                  "CSV (comma, semicolon or tab separated) or .xlsx; the first sheet is used",
              }),
              d &&
                t.jsxs("p", {
                  className: "text-xs text-muted-foreground",
                  "data-testid": "mm-count",
                  children: [
                    l,
                    " record",
                    l === 1 ? "" : "s",
                    ". Columns: ",
                    d.headers.filter(Boolean).join(", ") || "none",
                    ".",
                  ],
                }),
            ],
          }),
          t.jsxs("section", {
            className: "space-y-2",
            children: [
              t.jsxs("div", {
                className: "flex items-center justify-between gap-3 flex-wrap",
                children: [
                  t.jsxs(_, {
                    htmlFor: "mm-template",
                    className: "font-semibold",
                    children: ["2. Template (use ", "{{Column name}}", ")"],
                  }),
                  t.jsxs("div", {
                    className: "flex gap-2",
                    children: [
                      t.jsx(E, {
                        size: "sm",
                        variant: n === "letter" ? "default" : "outline",
                        onClick: () => S("letter"),
                        children: "Letter",
                      }),
                      t.jsx(E, {
                        size: "sm",
                        variant: n === "certificate" ? "default" : "outline",
                        onClick: () => S("certificate"),
                        children: "Certificate",
                      }),
                    ],
                  }),
                ],
              }),
              t.jsx(W, {
                id: "mm-template",
                rows: 9,
                value: e,
                onChange: (i) => r(i.target.value),
                placeholder: Z,
              }),
              t.jsxs("div", {
                className: "grid gap-3 sm:grid-cols-2",
                children: [
                  t.jsxs("div", {
                    className: "space-y-1",
                    children: [
                      t.jsx(_, {
                        htmlFor: "mm-size",
                        className: "text-xs",
                        children: "Type size",
                      }),
                      t.jsx(Y, {
                        id: "mm-size",
                        inputMode: "numeric",
                        value: f,
                        onChange: (i) => c(i.target.value),
                      }),
                    ],
                  }),
                  t.jsxs("div", {
                    className: "space-y-1",
                    children: [
                      t.jsx(_, {
                        htmlFor: "mm-namecol",
                        className: "text-xs",
                        children: "Name each file from column (ZIP)",
                      }),
                      t.jsx(Y, {
                        id: "mm-namecol",
                        value: g,
                        onChange: (i) => x(i.target.value),
                        placeholder: "First Name",
                      }),
                    ],
                  }),
                ],
              }),
              n === "certificate"
                ? t.jsx("p", {
                    className: "text-xs text-muted-foreground",
                    children:
                      "Certificate: wide page, centred text, first line in bold.",
                  })
                : t.jsx("p", {
                    className: "text-xs text-muted-foreground",
                    children:
                      "Letter: tall page, left aligned, one-inch margins.",
                  }),
            ],
          }),
          d &&
            e.trim() &&
            t.jsxs("section", {
              className: "space-y-2",
              "aria-live": "polite",
              children: [
                t.jsxs("div", {
                  className: "flex items-center justify-between gap-3",
                  children: [
                    t.jsxs("h3", {
                      className: "font-semibold text-sm",
                      children: [
                        "Preview of record ",
                        l ? v + 1 : 0,
                        " of ",
                        l,
                      ],
                    }),
                    t.jsxs("div", {
                      className: "flex gap-2",
                      children: [
                        t.jsx(E, {
                          size: "sm",
                          variant: "outline",
                          disabled: v <= 0,
                          onClick: () => j(v - 1),
                          children: "Previous",
                        }),
                        t.jsx(E, {
                          size: "sm",
                          variant: "outline",
                          disabled: v >= l - 1,
                          onClick: () => j(v + 1),
                          children: "Next",
                        }),
                      ],
                    }),
                  ],
                }),
                t.jsx("pre", {
                  className:
                    "whitespace-pre-wrap rounded border bg-muted/30 p-3 text-sm min-h-[6rem]",
                  "data-testid": "mm-preview",
                  children: h,
                }),
                b.length > 0 &&
                  t.jsxs("p", {
                    className: "text-sm text-red-700",
                    role: "alert",
                    children: [
                      "Not in your table: ",
                      b.map((i) => `{{${i}}}`).join(", "),
                      ". Columns are ",
                      d.headers.filter(Boolean).join(", "),
                      ".",
                    ],
                  }),
                u.length > 0 &&
                  t.jsxs(J, {
                    className: "text-sm",
                    children: [
                      "Empty value in rows: ",
                      u.slice(0, 10).join(", "),
                      u.length > 10 ? ` and ${u.length - 10} more` : "",
                      ".",
                    ],
                  }),
                G(e).length === 0 &&
                  t.jsxs(J, {
                    className: "text-sm",
                    children: [
                      "The template has no ",
                      "{{fields}}",
                      ", so every page will be the same.",
                    ],
                  }),
              ],
            }),
          l > k &&
            t.jsxs("p", {
              className: "text-sm text-red-700",
              role: "alert",
              children: ["Up to ", k, " rows at a time. Split the table."],
            }),
          p &&
            t.jsx("p", {
              className: "text-sm text-red-700",
              role: "alert",
              children: p,
            }),
          t.jsxs("div", {
            className: "flex flex-wrap gap-3",
            children: [
              t.jsxs(E, {
                className: "gap-2",
                disabled: !N || z,
                onClick: () => $("one"),
                children: [
                  t.jsx(K, { className: "h-4 w-4" }),
                  z ? `Building ${A}` : "Download one PDF",
                ],
              }),
              t.jsxs(E, {
                variant: "outline",
                className: "gap-2",
                disabled: !N || z,
                onClick: () => $("zip"),
                children: [
                  t.jsx(K, { className: "h-4 w-4" }),
                  "Download ZIP, one PDF each",
                ],
              }),
            ],
          }),
        ],
      }),
      t.jsx(he, { whatIsIt: H.what, howToUse: H.how, tip: H.tip }),
    ],
  });
}
export { ft as default };
//# sourceMappingURL=MailMergePdf-lQE6WOVH.js.map
