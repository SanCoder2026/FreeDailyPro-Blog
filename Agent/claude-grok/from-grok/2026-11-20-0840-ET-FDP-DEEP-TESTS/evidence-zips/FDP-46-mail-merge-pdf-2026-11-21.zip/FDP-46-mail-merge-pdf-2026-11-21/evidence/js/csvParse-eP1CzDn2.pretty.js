function m(n) {
  const t = new Uint8Array(n);
  if (t[0] === 255 && t[1] === 254)
    return {
      text: new TextDecoder("utf-16le").decode(t.subarray(2)),
      encoding: "UTF-16",
    };
  if (t[0] === 254 && t[1] === 255)
    return {
      text: new TextDecoder("utf-16be").decode(t.subarray(2)),
      encoding: "UTF-16",
    };
  try {
    return {
      text: new TextDecoder("utf-8", { fatal: !0 }).decode(t).replace(/^﻿/, ""),
      encoding: "UTF-8",
    };
  } catch {
    return {
      text: new TextDecoder("windows-1252").decode(t),
      encoding: "Windows-1252",
    };
  }
}
function w(n) {
  const t = [",", ";", "	", "|"],
    i = n.slice(0, 2e4);
  let s = ",",
    e = -1;
  for (const r of t) {
    const o = a(i, r).slice(0, 30);
    if (o.length === 0) continue;
    const c = o.map((u) => u.length),
      f = c.sort((u, d) => u - d)[Math.floor(c.length / 2)];
    if (f < 2) continue;
    const l = (c.filter((u) => u === f).length / c.length) * 100 + f;
    l > e && ((e = l), (s = r));
  }
  return s;
}
function a(n, t) {
  const i = [];
  let s = [],
    e = "",
    r = !1;
  for (let o = 0; o < n.length; o++) {
    const c = n[o];
    r
      ? c === '"'
        ? n[o + 1] === '"'
          ? ((e += '"'), o++)
          : (r = !1)
        : (e += c)
      : c === '"'
        ? (r = !0)
        : c === t
          ? (s.push(e), (e = ""))
          : c ===
                `
` || c === "\r"
            ? (c === "\r" &&
                n[o + 1] ===
                  `
` &&
                o++,
              s.push(e),
              (e = ""),
              i.push(s),
              (s = []))
            : (e += c);
  }
  return (
    (e !== "" || s.length > 0) && (s.push(e), i.push(s)),
    i.filter((o) => o.length > 1 || o[0] !== "")
  );
}
function p(n, t = ",", i = !1) {
  const s = (e) =>
    e.includes(t) || /["\r\n]/.test(e) ? `"${e.replace(/"/g, '""')}"` : e;
  return (
    (i ? "\uFEFF" : "") +
    n.map((e) => e.map(s).join(t)).join(`\r
`)
  );
}
function b(n) {
  const t = n.trim();
  return /^-?(0|[1-9]\d{0,14})(\.\d+)?$/.test(t) && t.length <= 15
    ? Number(t)
    : n;
}
const h = /^\+\d[\d ()./-]{5,24}$/;
function T(n, t = ",", i = !0) {
  const s = (e) => {
    const r = String(e ?? "");
    return typeof e == "number" || /^-?\d+([.,]\d+)?$/.test(r) || h.test(r)
      ? r
      : /^[=+\-@\t\r]/.test(r)
        ? `'${r}`
        : r;
  };
  return p(
    n.map((e) => e.map(s)),
    t,
    i,
  );
}
export { w as a, b, m as d, a as p, T as s, p as t };
//# sourceMappingURL=csvParse-eP1CzDn2.js.map
