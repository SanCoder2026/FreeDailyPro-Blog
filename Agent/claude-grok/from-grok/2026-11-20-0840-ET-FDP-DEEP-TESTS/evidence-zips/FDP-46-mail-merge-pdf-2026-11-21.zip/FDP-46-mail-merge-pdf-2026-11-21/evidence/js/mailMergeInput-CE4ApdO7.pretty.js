import { ap as l } from "./index-B1CTyGtY.js";
import { d as c, t as h } from "./csvParse-eP1CzDn2.js";
const T = ".csv,.tsv,.txt,.xlsx,.xlsm,.xls,.ods",
  m = /\.(xlsx|xlsm|xls|ods)$/i,
  f = (e) => m.test(e);
function x(e) {
  const r = e.map((t) => t.map((s) => String(s ?? "").trim())),
    n = r.reduce((t, s) => Math.max(t, s.length), 0);
  return h(
    r
      .filter((t) => t.some(Boolean))
      .map((t) => t.concat(Array(n - t.length).fill(""))),
    "	",
  );
}
async function _(e) {
  const r = await e.arrayBuffer();
  if (!f(e.name)) return { text: c(r).text, note: "" };
  const n = await l(() => import("./xlsx-CNerDvZX.js"), []),
    t = n.read(r, { type: "array" }),
    s = t.SheetNames.filter((d, i) => !t.Workbook?.Sheets?.[i]?.Hidden),
    o = (s.length ? s : t.SheetNames)[0];
  if (!o) throw new Error("That workbook has no sheets.");
  const a = n.utils.sheet_to_json(t.Sheets[o], {
    header: 1,
    raw: !1,
    defval: "",
  });
  return {
    text: x(a),
    note:
      t.SheetNames.length > 1
        ? `Read the sheet "${o}". Only the first sheet is used.`
        : "",
  };
}
function g(e, r) {
  const n = r.map((a) => a.trim()).filter(Boolean);
  if (n.length === 0) return "";
  const [t, ...s] = n,
    o = s.slice(0, 4).map((a) => `${a}: {{${a}}}`);
  return e === "certificate"
    ? [
        "Certificate",
        "",
        "This is to certify that",
        "",
        `{{${t}}}`,
        ...(o.length ? ["", ...o] : []),
      ].join(`
`)
    : [`Dear {{${t}}},`, ...(o.length ? ["", ...o] : [])].join(`
`);
}
export { T as M, _ as m, g as s };
//# sourceMappingURL=mailMergeInput-CE4ApdO7.js.map
