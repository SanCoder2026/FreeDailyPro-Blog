import { r as s } from "./vendor-react-D01g8YgM.js";
function i(r, a) {
  const e = `fdp-session-${r}`,
    [o, n] = s.useState(() => {
      try {
        const t = sessionStorage.getItem(e);
        if (t !== null) return JSON.parse(t);
      } catch {}
      return a;
    }),
    c = s.useCallback(
      (t) => {
        n(t);
        try {
          sessionStorage.setItem(e, JSON.stringify(t));
        } catch {}
      },
      [e],
    );
  return [o, c];
}
export { i as u };
//# sourceMappingURL=useSessionState-BLsNNse9.js.map
