# FDP-46 Mail Merge to PDF test files
import csv, io, openpyxl
names = [("Zoë","Ångström","Python Basics","2026-11-01"),("José","Núñez","Excel Pro","2026-11-02"),("Ann","Lee, Jr.","Data \"Viz\"","2026-11-03"),("Łukasz","Żółć","SQL","2026-11-04"),("Ann","Smith","Python Basics","2026-11-05"),("","Blank-First","SQL","2026-11-06")]
with open('M02_people.csv','w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(["First Name","Last Name","Course","Date"]); w.writerows(names)
open('M04_bom_semicolon.csv','w',encoding='utf-8-sig').write("Name;Amount;City\nZoë;1.234,56;Köln\nJosé;99,00;São Paulo\n")
wb=openpyxl.Workbook(); ws=wb.active; ws.title="People"; ws.append(["First Name","Last Name","Course","Date"])
for r in names[:5]: ws.append(list(r))
ws.row_dimensions[3].hidden=True  # José row hidden (filtered out)
ws2=wb.create_sheet("Second"); ws2.append(["X"]); ws2.append(["should not be used"])
wb.save('M03_people_hiddenrow.xlsx')
wb=openpyxl.Workbook(); ws=wb.active; ws.title="Secret"; ws.sheet_state="hidden"; ws.append(["Name"]); ws.append(["HIDDEN-SHEET-ROW"])
ws2=wb.create_sheet("Visible"); ws2.append(["Name"]); ws2.append(["Visible Person"]); wb.active=1; wb.save('M03b_hidden_first_sheet.xlsx')
with open('M06_501rows.csv','w',newline='') as f:
    w=csv.writer(f); w.writerow(["Name","ID"]); [w.writerow([f"Person {i}",i]) for i in range(1,502)]
with open('M14_500rows.csv','w',newline='') as f:
    w=csv.writer(f); w.writerow(["Name","ID"]); [w.writerow([f"Person {i}",i]) for i in range(1,501)]
with open('M07_scripts.csv','w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(["Name","Note"]); w.writerows([["王小明","中文"],["محمد","عربي"],["प्रिया शर्मा","नमस्ते"],["Emoji 🚀","ok ✅"],["Ελένη","Привет"]])
with open('M08_filenames.csv','w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(["Name","Text"]); w.writerows([["../../evil","a"],["a/b\\c:d","b"],["Ann","c"],["ann","d"],["","e"],["CON","f"],["x"*80,"g"],["  spaced   name ","h"]])
with open('M09_longtext.csv','w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(["Name","Body"]); w.writerows([["Short","ok"],["Long",("This is a long paragraph that repeats. "*120)],["Unbroken","X"*400]])
open('M13_braces_header.csv','w').write("{{Name}},Plain\nAlice,1\n")
open('M11_corrupt.xlsx','wb').write(b'PK\x03\x04garbage-not-a-zip'*10)
import docx; d=docx.Document(); d.add_paragraph("hi"); d.save('M12_word.docx')
print('ok')
