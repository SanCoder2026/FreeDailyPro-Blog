// FDP-46 Mail Merge to PDF, guest. Usage: node mm-live.js <zero|left|subset> [engine]   (TRIES env = fresh contexts to try for "left")
// zero: context at 0 -> example, preview/notes, Download one/ZIP/Drive/cloud dialogs, Day Pass (stops at email), Quick Buy (stops at email/Stripe), keyboard.
// left: context with uses left -> all cases in ONE page load with downloads (per-page-load check), then reload + download.
// Never types an email/card, never clicks a pass "Continue", never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const crypto = require('crypto');
const BASE = '/workspace/deep/46-mail-merge-pdf/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/mail-merge-pdf';
const mode = process.argv[2] || 'left'; const eng = process.argv[3] || 'chromium'; const sfx = eng === 'chromium' ? '' : '-' + eng;
fs.mkdirSync(OUT + 'downloads', { recursive: true }); fs.mkdirSync(OUT + 'cases', { recursive: true });
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex').slice(0, 16);
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').slice(0, 160);
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p; const net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true, locale: 'en-US' }); p = await c.newPage(); p.setDefaultTimeout(15000);
  await p.addInitScript(() => { window.__t = []; new MutationObserver(ms => ms.forEach(m => m.addedNodes.forEach(n => { if (n.nodeType === 1 && n.matches && n.matches('[data-sonner-toast]')) setTimeout(() => window.__t.push(n.innerText.trim()), 80); }))).observe(document, { childList: true, subtree: true }); });
  p.on('request', r => { const d = r.postData() || ''; net.push({ m: r.method(), u: red(r.url()), len: d.length, hit: /Ångström|Núñez|Blank-First|Person 4\d\d|evil/.test(d + r.url()) }); });
  await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000); };
 const used = () => p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 const state = () => p.evaluate(() => { const m = document.querySelector('main'); const pv = document.querySelector('[data-testid=mm-preview]'); const cnt = document.querySelector('[data-testid=mm-count]');
  const btn = n => { const x = [...m.querySelectorAll('button')].find(e => e.innerText.trim().startsWith(n)); return x ? (x.disabled ? 'disabled' : 'enabled') : 'absent'; };
  const notes = [...m.querySelectorAll('p, div')].map(e => e.innerText.trim()).filter(t => /^(Not in your table|Empty value|Up to \d+ rows|Type size has|Margin has)/.test(t)).filter((t, i, a) => a.indexOf(t) === i).slice(0, 6);
  return { count: cnt ? cnt.innerText.trim() : null, preview: pv ? pv.innerText.slice(0, 400) : null, recordLabel: (m.innerText.match(/Preview of record[^\n]*/) || [''])[0], notes, one: btn('Download one PDF'), zip: btn('Download ZIP'), template: document.querySelector('#mm-template')?.value.slice(0, 200) }; });
 const run = async (id, o = {}) => { const r = { id, o, t: now(), before: await used() }; const tN = await p.evaluate(() => (window.__t || []).length);
  try { if (o.clearTemplate) await p.locator('#mm-template').fill('');
   if (o.example) await p.getByRole('button', { name: 'Use an example' }).click();
   if (o.file) { await p.locator('main input[type=file]').first().setInputFiles(TF + o.file); await p.waitForTimeout(2500); }
   if (o.paste !== undefined) await p.locator('#mm-csv').fill(o.paste);
   if (o.kind) await p.getByRole('button', { name: o.kind, exact: true }).click();
   if (o.template !== undefined) await p.locator('#mm-template').fill(o.template);
   if (o.size !== undefined) await p.locator('#mm-size').fill(String(o.size));
   if (o.namecol !== undefined) await p.locator('#mm-namecol').fill(o.namecol);
   await p.waitForTimeout(700); r.state = await state();
   if (o.next) { for (let i = 0; i < o.next; i++) await p.getByRole('button', { name: 'Next', exact: true }).click(); r.afterNext = (await state()).preview?.slice(0, 160); r.afterNextLabel = (await state()).recordLabel; }
   if (o.dl) { const which = o.dl === 'zip' ? /^Download ZIP/ : /^Download one PDF/; const btn = p.getByRole('button', { name: which });
    if (await btn.isEnabled()) { const t0 = Date.now(); const pop = c.waitForEvent('page', { timeout: 4000 }).catch(() => null); const dp = p.waitForEvent('download', { timeout: o.wait || 60000 }).catch(() => null); await btn.click(); const d = await dp; r.ms = Date.now() - t0; await pop; await p.waitForTimeout(1500);
     r.dialog = await dialog(); if (d) { const f = OUT + 'downloads/' + id + sfx + '-' + d.suggestedFilename(); await d.saveAs(f); r.download = { name: d.suggestedFilename(), bytes: fs.statSync(f).size, sha: sha(f) }; }
     if (r.dialog) { await p.screenshot({ path: OUT + 'cases/' + id + sfx + '-dialog.png' }); if (/Day Pass/.test(r.dialog) && !R.dayPass) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.dayPass = { dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); } } await esc(); } }
    else r.dlDisabled = true; }
   r.afterDl = await used();
  } catch (e) { r.err = e.message.slice(0, 300); }
  await p.waitForTimeout(500); r.toasts = await p.evaluate(n => (window.__t || []).slice(n), tN);
  await p.screenshot({ path: OUT + 'cases/' + id + sfx + '.png', fullPage: !!o.full }).catch(() => {}); R.cases[id] = r; console.log(id, JSON.stringify(r).slice(0, 600)); return r; };
 const act = async (name, loc) => { const r = { before: await used() }; if (!(await loc.count())) { r.missing = true; return r; }
  const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); const url0 = p.url(); await loc.first().click(); const pg = await pop; await p.waitForTimeout(2500);
  r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null; if (pg) { await pg.waitForLoadState('domcontentloaded').catch(() => {}); r.popup = red(pg.url()); await pg.close(); }
  if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + '.png' }); await esc(); console.log(name, JSON.stringify(r).slice(0, 400)); return r; };
 const T2 = 'Dear {{First Name}} {{Last Name}},\n\nYou completed {{ course }} on {{Date}}.\n\nRegards, {{Frist}}';
 if (mode === 'left') { const NT = +(process.env.TRIES || 16); for (let i = 0; i < NT; i++) { await open(); const u = await used(); R.tries.push(u); if (u < 10) { await p.waitForTimeout(6000); if ((await used()) < 10) break; } if (i < NT - 1) await c.close(); }
  R.start = await used(); const dl = R.start < 10;
  await run('L01', { example: true, dl: dl && 'one' }); await run('L01z', { dl: dl && 'zip' });
  R.drive = await act('drive', p.getByRole('button', { name: /Save to Google Drive/ })); R.cloud = await act('cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
  await run('L02', { clearTemplate: true, file: 'M02_people.csv' }); await run('L02b', { template: T2, namecol: 'First Name', next: 5, dl: dl && 'zip' });
  await run('L03', { clearTemplate: true, file: 'M03_people_hiddenrow.xlsx', next: 1, dl: dl && 'one' }); await run('L03b', { clearTemplate: true, file: 'M03b_hidden_first_sheet.xlsx', dl: dl && 'one' });
  await run('L04', { clearTemplate: true, file: 'M04_bom_semicolon.csv', dl: dl && 'one' });
  await run('L05', { clearTemplate: true, paste: 'Name\tCity\nAlice\tParis\nBob\tLyon', dl: dl && 'one' });
  await run('L06', { clearTemplate: true, file: 'M06_501rows.csv', full: true });
  await run('L07', { clearTemplate: true, file: 'M07_scripts.csv', kind: 'Certificate', dl: dl && 'one' });
  await run('L08', { clearTemplate: true, file: 'M08_filenames.csv', kind: 'Letter', namecol: 'Name', dl: dl && 'zip' });
  await run('L09', { clearTemplate: true, file: 'M09_longtext.csv', template: '{{Name}}\n\n{{Body}}', dl: dl && 'one' });
  await run('L10a', { size: 5 }); await run('L10b', { size: 73 }); await run('L10c', { size: 12 });
  await run('L11', { file: 'M11_corrupt.xlsx' }); await run('L12', { file: 'M12_word.docx' }); await run('L13', { clearTemplate: true, file: 'M13_braces_header.csv', dl: dl && 'one' });
  await run('L14', { clearTemplate: true, file: 'M14_500rows.csv', namecol: 'Name', dl: dl && 'zip', wait: 180000 });
  R.endUsed = await used(); await p.reload(); await p.waitForTimeout(5000); R.afterReload = await used(); await run('L15-after-reload', { example: true, dl: 'one' }); R.final = await used(); }
 if (mode === 'zero' || mode === 'subset') { for (let i = 0; i < 5; i++) { await open(); const u = await used(); R.tries.push(u); if (u >= 10 || mode === 'subset') break; await c.close(); }
  R.start = await used();
  if (mode === 'zero') { const seq = []; for (let i = 0; i < 45; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.id || '') + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 40).replace(/\n/g, ' '); }); seq.push(a); if (/mm-template/.test(a)) break; } R.kbd = { reachedCsv: seq.some(s => /mm-csv/.test(s)), reachedTemplate: seq.some(s => /mm-template/.test(s)), tabs: seq.length };
   R.initial = await state(); await run('Z01', { example: true, next: 2, full: true }); await run('Z02', { dl: 'one' }); await run('Z03', { dl: 'zip' });
   R.drive = await act('zero-drive', p.getByRole('button', { name: /Save to Google Drive/ })); R.cloud = await act('zero-cloud', p.getByRole('button', { name: /Save to my cloud storage/ })); R.end = await used();
   await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); const u0 = p.url();
   await p.getByRole('button', { name: 'Quick Buy' }).first().click(); await p.waitForTimeout(3000); R.qbDay = { url: p.url() !== u0 ? red(p.url()) : null, dialog: await dialog() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await esc();
   if (p.url() !== u0) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); }
   await p.getByRole('button', { name: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); R.qbMonth = { url: red(p.url()), title: await p.title() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' }); }
  else { await run('S01', { example: true, next: 1 }); await run('S02', { clearTemplate: true, file: 'M02_people.csv', template: T2 }); await run('S03', { clearTemplate: true, file: 'M03_people_hiddenrow.xlsx' }); await run('S07', { clearTemplate: true, file: 'M07_scripts.csv' }); await run('S06', { clearTemplate: true, file: 'M06_501rows.csv' }); } }
 R.t2 = now(); R.net = { total: net.length, hits: net.filter(x => x.hit), posts: net.filter(x => x.m !== 'GET' && /freedailypro/.test(x.u)).map(x => ({ u: x.u, len: x.len })).slice(0, 20) };
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('tries', R.tries, 'start', R.start, 'end', R.endUsed, R.afterReload, R.final); await b.close(); })();
