// FDP-46 at 0: preview stepping. M02 with a misspelled field (record 6 has an empty First Name), M03 xlsx with a hidden row (is the hidden José row merged?).
const pw = require('playwright'); const fs = require('fs'); const TF = '/workspace/deep/46-mail-merge-pdf/testfiles/'; const OUT = '/workspace/deep/46-mail-merge-pdf/live/';
(async () => { const b = await pw.chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); p.setDefaultTimeout(15000);
 await p.goto('https://www.freedailypro.com/tool/mail-merge-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); const R = {};
 const pv = () => p.evaluate(() => ({ label: (document.querySelector('main').innerText.match(/Preview of record[^\n]*/) || [''])[0], text: document.querySelector('[data-testid=mm-preview]')?.innerText }));
 const step = async (key, n) => { R[key] = [await pv()]; for (let i = 0; i < n; i++) { await p.getByRole('button', { name: 'Next', exact: true }).click(); R[key].push(await pv()); } };
 await p.locator('main input[type=file]').first().setInputFiles(TF + 'M02_people.csv'); await p.waitForTimeout(2000);
 await p.locator('#mm-template').fill('Dear {{First Name}} {{Last Name}},\n\nYou completed {{ course }} on {{Date}}.\n\nRegards, {{Frist}}'); await step('M02', 5); await p.screenshot({ path: OUT + 'cases/N-M02-record6.png' });
 await p.locator('#mm-template').fill(''); await p.locator('#mm-csv').fill(''); await p.locator('main input[type=file]').first().setInputFiles(TF + 'M03_people_hiddenrow.xlsx'); await p.waitForTimeout(2000);
 R.M03count = await p.locator('[data-testid=mm-count]').innerText(); await step('M03', 4); await p.screenshot({ path: OUT + 'cases/N-M03-hiddenrow.png' });
 await p.locator('#mm-csv').fill(''); await p.locator('main input[type=file]').first().setInputFiles(TF + 'M11_corrupt.xlsx'); await p.waitForTimeout(1500); R.M11 = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText)); await p.screenshot({ path: OUT + 'cases/N-M11-corrupt.png' });
 fs.writeFileSync(OUT + 'next-at0.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1).slice(0, 3000)); await b.close(); })();
