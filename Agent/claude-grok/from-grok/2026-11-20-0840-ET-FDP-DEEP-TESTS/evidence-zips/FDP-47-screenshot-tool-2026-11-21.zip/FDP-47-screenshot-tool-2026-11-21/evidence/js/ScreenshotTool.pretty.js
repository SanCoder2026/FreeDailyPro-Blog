import { r as h, j as s } from "./vendor-react-D01g8YgM.js";
import { T as Ce, D as ke, d as Ht } from "./ToolPage-DwLoDncN.js";
import { v as Z, B as p, cv as Se, f as L } from "./index-B1CTyGtY.js";
import { S as Ot } from "./slider-nIHsxb_2.js";
import { T as Me } from "./ToolInfoSection-C0i6Zbwo.js";
import { u as Ne } from "./useShareGate-BYBawloP.js";
import { C as At } from "./camera-8PGplCT5.js";
import { S as $t } from "./scroll-text-C7oQyEPY.js";
import { M as Wt } from "./maximize-DddpxYaC.js";
import { C as Te } from "./crop-D1wtdRSb.js";
import { C as bt } from "./copy-DcUvE8ta.js";
import { M as Re } from "./mouse-pointer-2-CjjIHvUL.js";
import { P as Ie } from "./pencil-Bbpt-gye.js";
import { S as Ee } from "./square-DmBnvOHU.js";
import { R as De } from "./rotate-cw-BNziJsEZ.js";
import { U as Pe } from "./undo-2-CNrdKZ-W.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./share-2-B4TSO3Yd.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./useExportGate-BU4jIFHF.js";
const Ue = Z("Grid2x2", [
  [
    "rect",
    { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" },
  ],
  ["path", { d: "M3 12h18", key: "1i2n21" }],
  ["path", { d: "M12 3v18", key: "108xh3" }],
]);
const Le = Z("Highlighter", [
  ["path", { d: "m9 11-6 6v3h9l3-3", key: "1a3l36" }],
  [
    "path",
    {
      d: "m22 12-4.6 4.6a2 2 0 0 1-2.8 0l-5.2-5.2a2 2 0 0 1 0-2.8L14 4",
      key: "14a9rk",
    },
  ],
]);
const Bt = Z("Minimize", [
  ["path", { d: "M8 3v3a2 2 0 0 1-2 2H3", key: "hohbtr" }],
  ["path", { d: "M21 8h-3a2 2 0 0 1-2-2V3", key: "5jw1f3" }],
  ["path", { d: "M3 16h3a2 2 0 0 1 2 2v3", key: "198tvr" }],
  ["path", { d: "M16 21v-3a2 2 0 0 1 2-2h3", key: "ph8mxp" }],
]);
const ze = Z("MoveUpRight", [
  ["path", { d: "M13 5H19V11", key: "1n1gyv" }],
  ["path", { d: "M19 5L5 19", key: "72u4yj" }],
]);
const Fe = Z("ZoomIn", [
  ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }],
  ["line", { x1: "21", x2: "16.65", y1: "21", y2: "16.65", key: "13gj7c" }],
  ["line", { x1: "11", x2: "11", y1: "8", y2: "14", key: "1vmskp" }],
  ["line", { x1: "8", x2: "14", y1: "11", y2: "11", key: "durymu" }],
]);
const He = Z("ZoomOut", [
    ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }],
    ["line", { x1: "21", x2: "16.65", y1: "21", y2: "16.65", key: "13gj7c" }],
    ["line", { x1: "8", x2: "14", y1: "11", y2: "11", key: "durymu" }],
  ]),
  B = 96,
  A = B * 2,
  Yt = 12,
  _t = 3,
  jt = 16e3;
function Xt(k) {
  const { width: l, height: u, data: c } = k,
    i = new Uint8Array(u * A),
    m = new Int32Array(B),
    C = new Int32Array(B);
  for (let d = 0; d < B; d++)
    ((m[d] = Math.floor((d * l) / B)),
      (C[d] = Math.max(m[d] + 1, Math.floor(((d + 1) * l) / B))));
  for (let d = 0; d < u; d++) {
    const b = d * l * 4;
    for (let S = 0; S < B; S++) {
      let M = 255,
        I = 0;
      for (let $ = m[S]; $ < C[S]; $++) {
        const w = b + $ * 4,
          P = (c[w] * 77 + c[w + 1] * 151 + c[w + 2] * 28) >> 8;
        (P < M && (M = P), P > I && (I = P));
      }
      ((i[d * A + S] = M), (i[d * A + B + S] = I));
    }
  }
  return i;
}
const Q = (k, l, u, c) => {
    let i = 0;
    for (let m = 0; m < A; m++) i += Math.abs(k[l * A + m] - u[c * A + m]);
    return i / A;
  },
  Oe = (k, l) => {
    let u = 255,
      c = 0;
    for (let i = 0; i < A; i++) {
      const m = k[l * A + i];
      (m < u && (u = m), m > c && (c = m));
    }
    return c - u >= 24;
  };
function Ae(k, l, u) {
  let c = 0;
  for (; c < u && Q(k, c, l, c) <= _t;) c++;
  if (c === u) return { top: u, bottom: 0 };
  let i = 0;
  for (; i < u - c && Q(k, u - 1 - i, l, u - 1 - i) <= _t;) i++;
  return { top: c, bottom: i };
}
function Gt(k, l, u, c, i) {
  const m = c - u,
    C = Math.max(20, Math.floor(m * 0.15)),
    d = m - C,
    b = [];
  for (let o = u; o < c; o++) Oe(l, o) && b.push(o);
  if (b.length < 6 || d < 1) return { fail: "lost" };
  const S =
      b.length <= 48
        ? b
        : Array.from(
            { length: 48 },
            (o, v) => b[Math.floor((v * b.length) / 48)],
          ),
    M = new Array(d + 1).fill(1 / 0);
  for (let o = 1; o <= d; o++) {
    let v = 0,
      N = 0;
    for (const T of S) {
      if (T + o >= c) break;
      ((v += Math.min(Q(l, T, k, T + o), 40)), N++);
    }
    N >= Math.min(6, S.length) && (M[o] = v / N);
  }
  const I = (o) => {
      let v = 0,
        N = 0;
      for (const T of b) {
        if (T + o >= c) break;
        ((v += Math.min(Q(l, T, k, T + o), 40)), N++);
      }
      return N >= 6 ? v / N : 1 / 0;
    },
    $ = (o) => {
      let v = o,
        N = 1 / 0;
      for (let T = Math.max(1, o - 3); T <= Math.min(d, o + 3); T++) {
        const _ = I(T);
        _ < N && ((N = _), (v = T));
      }
      return v;
    };
  let w = 1;
  for (let o = 2; o <= d; o++) M[o] < M[w] && (w = o);
  if (((w = $(w)), !(M[w] <= Yt))) return { fail: "lost" };
  const P = [];
  for (let o = 1; o <= d; o++)
    Math.abs(o - w) > 3 && M[o] <= M[w] + 0.5 && P.push(o);
  let H = w;
  if (P.length > 0) {
    if (i === void 0) return { fail: "ambiguous" };
    const o = [w, ...P];
    if (
      ((H = $(o.reduce((v, N) => (Math.abs(N - i) < Math.abs(v - i) ? N : v)))),
      Math.abs(H - i) > Math.max(30, i * 0.5))
    )
      return { fail: "ambiguous" };
  }
  let g = 0,
    U = 0;
  for (const o of b) {
    if (o + H >= c) break;
    (U++, Q(l, o, k, o + H) <= Yt && g++);
  }
  return U < 6 || g / U < 0.85 ? { fail: "lost" } : { dy: H };
}
class $e {
  constructor(l = jt) {
    ((this.maxHeight = l),
      (this.strips = []),
      (this.end = 0),
      (this.offset = 0),
      (this.w = 0),
      (this.h = 0),
      (this.last = null),
      (this.lastSig = null),
      (this.lastBottom = 0),
      (this.frames = 0));
  }
  get height() {
    return this.last ? (this.frames > 1 ? this.offset + this.h : this.h) : 0;
  }
  get frameCount() {
    return this.frames;
  }
  rows(l, u, c) {
    const i = l.data.byteOffset + u * this.w * 4;
    return new Uint8ClampedArray(
      l.data.buffer.slice(i, i + (c - u) * this.w * 4),
    );
  }
  add(l) {
    if (!this.last || !this.lastSig)
      return (
        (this.w = l.width),
        (this.h = l.height),
        (this.last = l),
        (this.lastSig = Xt(l)),
        (this.strips = [this.rows(l, 0, l.height)]),
        (this.end = l.height),
        (this.offset = 0),
        (this.frames = 1),
        { status: "first" }
      );
    if (l.width !== this.w || l.height !== this.h) return { status: "resized" };
    const u = Xt(l),
      { top: c, bottom: i } = Ae(this.lastSig, u, this.h);
    if (c >= this.h || this.h - c - i < Math.max(40, this.h * 0.1))
      return { status: "same" };
    const m = c,
      C = this.h - i,
      d = Gt(this.lastSig, u, m, C, this.prevDy);
    if ("fail" in d) {
      const M = Gt(u, this.lastSig, m, C);
      return "dy" in M ? { status: "up", dy: M.dy } : { status: d.fail };
    }
    const b = d.dy;
    if (this.offset + b + this.h > this.maxHeight) return { status: "limit" };
    (this.frames === 1 &&
      ((this.end = this.h - i),
      (this.strips = [this.rows(this.last, 0, this.end)])),
      (this.offset += b));
    const S = this.offset + C;
    return (
      S > this.end &&
        (this.strips.push(this.rows(l, this.end - this.offset, C)),
        (this.end = S)),
      (this.lastBottom = i),
      (this.prevDy = b),
      this.frames++,
      (this.last = l),
      (this.lastSig = u),
      { status: "added", dy: b }
    );
  }
  result() {
    if (!this.last) return null;
    if (this.frames === 1)
      return { data: this.strips[0], width: this.w, height: this.h };
    const l = Math.max(this.h - this.lastBottom, this.end - this.offset),
      u = [...this.strips, this.rows(this.last, l, this.h)],
      c = u.reduce((C, d) => C + d.length, 0),
      i = new Uint8ClampedArray(c);
    let m = 0;
    for (const C of u) (i.set(C, m), (m += C.length));
    return { data: i, width: this.w, height: c / (this.w * 4) };
  }
}
const vt = {
    what: "Captures a screenshot of your screen, a specific window, or a browser tab, then lets you crop it down to just the region you want (or, for a long page, record it as you scroll and stitch the pieces into one tall image), rotate it, mark it up with a pencil, highlighter, arrows, boxes and text, hide private details by pixelating them, and copy or download the result.",
    how: `Optionally set a delay first, click Take Screenshot and choose what to capture in the browser's own sharing prompt, then drag to crop the captured image down to just the part you need — tap Fullscreen first if the screen feels too small to work with precisely, especially on mobile. From there, rotate if needed, and use the pencil or highlighter to mark it up before copying or downloading.

For a page taller than the screen, choose Capture whole page, share the tab or window, then scroll it slowly yourself and press Finish at the end. Each picture is lined up with the one before and joined, in your browser; whatever you didn't scroll past is not in the result.`,
    tip: `A website can't draw a selection box directly onto your screen before capturing, the way a native OS screenshot tool can — that's blocked by browser security, since otherwise any site could screen-record parts of your screen at will. The browser's own "choose what to share" prompt is unavoidable for the same reason — no website can remove or customize it. This tool works around that the practical way: capture the full screen/window/tab first, then crop and mark it up afterward, which gets you the same result. Copy to Clipboard needs a browser that supports writing images to the clipboard (Chrome, Edge, and Safari all do); Download always works as a fallback.

If you choose "Entire Screen" in that prompt, your browser itself typically drops to the background right after — this is normal OS/browser behavior, not a bug: since "entire screen" is meant to capture your whole desktop, the browser has to step out of the way so whatever's underneath is actually visible to capture, rather than just capturing a picture of itself. If you want to bring another window to the front first (to make sure it's the thing actually captured), set a short delay below before clicking Take Screenshot — that's specifically what the delay option is for.`,
  },
  We = ["arrow", "rect", "blur"],
  qt = {
    first:
      "Scroll the page you shared, slowly. Come back here and press Finish when you reach the end.",
    added: "",
    same: "",
    up: "That frame was above what is already captured, so nothing was added. Scroll down past the last captured part.",
    lost: "That jump could not be lined up: the page moved too far between frames, or its content changed. Scroll back up a little and go slower.",
    ambiguous:
      "That part of the page repeats or is blank, so it can not be lined up safely. Scroll back up a little and move on in smaller steps.",
    resized:
      "The shared window changed size, so that frame was skipped. Put it back to the original size.",
    limit: `Reached the maximum height (${jt.toLocaleString("en-US")} px). Capture finished.`,
  },
  Be = [0, 2, 5, 10],
  Zt = ["#ef4444", "#3b82f6", "#22c55e", "#000000", "#ffffff"],
  Vt = ["#fde047", "#86efac", "#93c5fd", "#f9a8d4"];
function Rs() {
  const { gateShare: k } = Ne(),
    [l, u] = h.useState("png"),
    [c, i] = h.useState("idle"),
    [m, C] = h.useState(0),
    [d, b] = h.useState(0),
    [S, M] = h.useState(!0),
    [I, $] = h.useState(!1),
    w = h.useRef(null),
    [P, H] = h.useState(null),
    [g, U] = h.useState(null),
    [o, v] = h.useState(null),
    [N, T] = h.useState(0),
    [_, ut] = h.useState(1),
    [f, W] = h.useState("select"),
    [X, Jt] = h.useState(Zt[0]),
    [tt, Kt] = h.useState(3),
    [Ct, Qt] = h.useState(Vt[0]),
    [kt, te] = h.useState(18),
    [et, V] = h.useState([]),
    st = h.useRef(null),
    G = h.useRef(null),
    [J, St] = h.useState({ frames: 0, height: 0, hint: "" }),
    [Mt, dt] = h.useState(null),
    z = h.useRef(null),
    q = h.useRef(null),
    nt = h.useRef(null),
    ee = h.useRef(null),
    Nt = h.useRef(null),
    E = h.useRef(null),
    rt = h.useRef(null),
    at = h.useRef(!1),
    K = h.useRef(null),
    [Y, ot] = h.useState(null),
    it = h.useRef(null);
  (h.useEffect(() => {
    M(typeof ClipboardItem < "u" && !!navigator.clipboard?.write);
  }, []),
    h.useEffect(() => {
      const t = () => $(!!document.fullscreenElement);
      return (
        document.addEventListener("fullscreenchange", t),
        () => document.removeEventListener("fullscreenchange", t)
      );
    }, []));
  const Tt = async () => {
    if (w.current)
      try {
        document.fullscreenElement
          ? await document.exitFullscreen()
          : await w.current.requestFullscreen();
      } catch (t) {
        (console.error("Fullscreen request failed:", t),
          L.error(
            "This browser doesn't support fullscreen here, or it needs to be enabled in settings.",
          ));
      }
  };
  h.useEffect(
    () => () => {
      (G.current && window.clearInterval(G.current),
        z.current?.getTracks().forEach((t) => t.stop()),
        q.current?.pause());
    },
    [],
  );
  const Rt = async (t = "single") => {
      if (typeof navigator > "u" || !navigator.mediaDevices?.getDisplayMedia) {
        L.error("Screen capture isn't supported in this browser");
        return;
      }
      let e;
      try {
        e = await navigator.mediaDevices.getDisplayMedia({ video: !0 });
      } catch {
        L.error("Screenshot wasn't taken (permission denied or cancelled)");
        return;
      }
      z.current = e;
      const n = document.createElement("video");
      ((n.srcObject = e), (q.current = n));
      try {
        (await n.play(),
          await new Promise((r) => {
            n.videoWidth > 0 ? r(null) : (n.onloadedmetadata = () => r(null));
          }));
      } catch {
        (L.error("Couldn't start the screen preview"),
          e.getTracks().forEach((r) => r.stop()),
          (z.current = null));
        return;
      }
      if (t === "scroll") {
        se(e, n);
        return;
      }
      if (m > 0) {
        i("counting-down");
        for (let r = m; r > 0; r--)
          if (
            (b(r),
            await new Promise((a) => setTimeout(a, 1e3)),
            !z.current?.active)
          ) {
            (L.error("Screen sharing was stopped before capture"),
              (q.current = null),
              i("idle"));
            return;
          }
      }
      await re(e, n);
    },
    It = () => {
      G.current && (window.clearInterval(G.current), (G.current = null));
    },
    se = (t, e) => {
      const n = new $e();
      st.current = n;
      const r = document.createElement("canvas"),
        a = r.getContext("2d", { willReadFrequently: !0 });
      (St({ frames: 0, height: 0, hint: qt.first }), i("scrolling"));
      const y = () => {
        if (!z.current?.active || !e.videoWidth) return;
        ((r.width = e.videoWidth),
          (r.height = e.videoHeight),
          a.drawImage(e, 0, 0));
        const j = a.getImageData(0, 0, r.width, r.height),
          x = n.add({ data: j.data, width: r.width, height: r.height });
        (St((D) => ({
          frames: n.frameCount,
          height: n.height,
          hint:
            x.status === "added" || x.status === "same"
              ? D.frames <= 1 && x.status === "same"
                ? D.hint
                : ""
              : qt[x.status],
        })),
          x.status === "limit" && mt());
      };
      ((G.current = window.setInterval(y, 600)),
        y(),
        t.getVideoTracks()[0]?.addEventListener("ended", () => mt()));
    },
    ne = () => {
      (It(),
        z.current?.getTracks().forEach((t) => t.stop()),
        (z.current = null),
        (q.current = null),
        (st.current = null),
        i("idle"));
    },
    mt = () => {
      It();
      const t = st.current;
      ((st.current = null),
        z.current?.getTracks().forEach((a) => a.stop()),
        (z.current = null),
        (q.current = null));
      const e = t?.result();
      if (!t || !e) {
        i("idle");
        return;
      }
      const n = document.createElement("canvas");
      ((n.width = e.width),
        (n.height = e.height),
        n
          .getContext("2d")
          .putImageData(
            new ImageData(new Uint8ClampedArray(e.data), e.width, e.height),
            0,
            0,
          ));
      const r = t.frameCount;
      n.toBlob((a) => {
        if (!a) {
          (L.error("Couldn't build the whole-page image"), i("idle"));
          return;
        }
        (H(URL.createObjectURL(a)),
          U(null),
          dt(
            r > 1
              ? `Stitched from ${r} frames into ${e.width.toLocaleString("en-US")} × ${e.height.toLocaleString("en-US")} px. Only what you scrolled past is in it. Fixed headers and footers appear once; videos and animations are a single frame; check the joins before sharing.`
              : "Only one frame was captured (the page was not scrolled), so this is a normal screenshot of what was on screen.",
          ),
          i("cropping"),
          L.success(
            r > 1 ? "Whole-page capture ready" : "Screenshot captured",
          ));
      }, "image/png");
    },
    re = async (t, e) => {
      const n = document.createElement("canvas");
      ((n.width = e.videoWidth),
        (n.height = e.videoHeight),
        n.getContext("2d").drawImage(e, 0, 0),
        t.getTracks().forEach((r) => r.stop()),
        (z.current = null),
        (q.current = null),
        n.toBlob((r) => {
          if (!r) {
            (L.error("Couldn't capture the screenshot"), i("idle"));
            return;
          }
          (H(URL.createObjectURL(r)),
            dt(null),
            U(null),
            i("cropping"),
            L.success("Screenshot captured"));
        }, "image/png"));
    },
    pt = (t) => {
      const e = t.getBoundingClientRect(),
        n = e.width / e.height,
        r = t.naturalWidth / t.naturalHeight;
      let a, y, j, x;
      return (
        r > n
          ? ((a = e.width),
            (y = e.width / r),
            (j = 0),
            (x = (e.height - y) / 2))
          : ((y = e.height),
            (a = e.height * r),
            (x = 0),
            (j = (e.width - a) / 2)),
        {
          x: j,
          y: x,
          width: a,
          height: y,
          boxWidth: e.width,
          boxHeight: e.height,
        }
      );
    },
    ft = (t, e) => {
      const n = nt.current;
      if (!n) return { x: 0, y: 0 };
      const r = n.getBoundingClientRect(),
        a = pt(n),
        y = t - r.left - a.x,
        j = e - r.top - a.y;
      return {
        x: Math.max(0, Math.min(a.width, y)),
        y: Math.max(0, Math.min(a.height, j)),
      };
    },
    Et = (t) => ft(t.clientX, t.clientY),
    ae = () => {
      const t = Nt.current?.getBoundingClientRect(),
        e = nt.current;
      if (!t || !e) return { x: 0, y: 0 };
      const n = e.getBoundingClientRect(),
        r = pt(e);
      return { x: n.left - t.left + r.x, y: n.top - t.top + r.y };
    },
    oe = (t) => {
      const e = Et(t);
      (v(e), U({ x: e.x, y: e.y, w: 0, h: 0 }));
    },
    ie = (t) => {
      if (!o) return;
      const e = Et(t);
      U({
        x: Math.min(o.x, e.x),
        y: Math.min(o.y, e.y),
        w: Math.abs(e.x - o.x),
        h: Math.abs(e.y - o.y),
      });
    },
    le = (t) => {
      if (t.touches.length === 0) return;
      const e = t.touches[0],
        n = ft(e.clientX, e.clientY);
      (v(n), U({ x: n.x, y: n.y, w: 0, h: 0 }));
    },
    ce = (t) => {
      if (!o || t.touches.length === 0) return;
      t.preventDefault();
      const e = t.touches[0],
        n = ft(e.clientX, e.clientY);
      U({
        x: Math.min(o.x, n.x),
        y: Math.min(o.y, n.y),
        w: Math.abs(n.x - o.x),
        h: Math.abs(n.y - o.y),
      });
    },
    lt = () => v(null),
    gt = () => {
      const t = nt.current;
      if (!t) return null;
      const e = document.createElement("canvas"),
        n = e.getContext("2d");
      if (g && g.w >= 4 && g.h >= 4) {
        const r = pt(t),
          a = t.naturalWidth / r.width,
          y = t.naturalHeight / r.height,
          j = Math.max(0, Math.round(g.x * a)),
          x = Math.max(0, Math.round(g.y * y)),
          D = Math.min(t.naturalWidth, Math.round((g.x + g.w) * a)),
          R = Math.min(t.naturalHeight, Math.round((g.y + g.h) * y));
        ((e.width = Math.max(1, D - j)),
          (e.height = Math.max(1, R - x)),
          n.drawImage(t, j, x, e.width, e.height, 0, 0, e.width, e.height));
      } else
        ((e.width = t.naturalWidth),
          (e.height = t.naturalHeight),
          n.drawImage(t, 0, 0));
      return e;
    },
    he = () => {
      const t = gt();
      t && me(t.toDataURL("image/png"));
    },
    ue = async () => {
      const t = gt();
      if (!t) return;
      const e = await new Promise((n) => t.toBlob(n, "image/png"));
      e && (await Dt(e));
    },
    Dt = (t) =>
      k(async () => {
        try {
          return (
            await navigator.clipboard.write([
              new ClipboardItem({ "image/png": t }),
            ]),
            L.success("Copied — paste it anywhere"),
            !0
          );
        } catch (e) {
          return (
            console.error("Clipboard write failed:", e),
            L.error("Couldn't copy to clipboard. Try Download instead."),
            !1
          );
        }
      }),
    de = () => {
      const t = gt();
      t &&
        t.toBlob(
          (e) => {
            e && Ht(e, yt());
          },
          l === "jpg" ? "image/jpeg" : "image/png",
          0.92,
        );
    },
    me = (t) => {
      const e = new Image();
      ((e.onload = () => {
        ((ee.current = e),
          (rt.current = { img: e, rot: 0 }),
          T(0),
          ut(1),
          V([]),
          W("select"),
          i("editing"));
      }),
        (e.src = t));
    };
  h.useEffect(() => {
    if (c !== "editing" || !rt.current) return;
    const { img: t, rot: e } = rt.current;
    ((rt.current = null), Pt(t, e));
  }, [c]);
  const Pt = (t, e) => {
      const n = E.current;
      if (!n) return;
      const r = e === 90 || e === 270;
      ((n.width = r ? t.naturalHeight : t.naturalWidth),
        (n.height = r ? t.naturalWidth : t.naturalHeight));
      const a = n.getContext("2d");
      (a.save(),
        a.translate(n.width / 2, n.height / 2),
        a.rotate((e * Math.PI) / 180),
        a.drawImage(t, -t.naturalWidth / 2, -t.naturalHeight / 2),
        a.restore());
    },
    pe = () => {
      const t = E.current;
      if (!t) return;
      const e = new Image();
      ((e.onload = () => {
        const n = (N + 90) % 360;
        (T(n), V([]), Pt(e, 90));
      }),
        (e.src = t.toDataURL("image/png")));
    },
    xt = () => {
      const t = E.current;
      t && V((e) => [...e, t.toDataURL("image/png")]);
    },
    fe = () => {
      const t = E.current;
      if (!t || et.length === 0) return;
      const e = et[et.length - 1];
      V((r) => r.slice(0, -1));
      const n = new Image();
      ((n.onload = () => {
        const r = t.getContext("2d");
        (r.clearRect(0, 0, t.width, t.height), r.drawImage(n, 0, 0));
      }),
        (n.src = e));
    },
    ct = (t) => {
      const e = E.current,
        n = e.getBoundingClientRect(),
        r = e.width / n.width,
        a = e.height / n.height;
      return { x: (t.clientX - n.left) * r, y: (t.clientY - n.top) * a };
    },
    ge = () => Math.max(2, tt * Math.max(1, (E.current?.width ?? 1e3) / 1e3)),
    xe = (t, e, n) => {
      const r = E.current;
      if (!r) return;
      const a = r.getContext("2d"),
        y = ge();
      if (
        ((a.lineCap = "round"),
        (a.lineJoin = "round"),
        (a.strokeStyle = X),
        (a.fillStyle = X),
        (a.lineWidth = y),
        t === "rect")
      )
        a.strokeRect(
          Math.min(e.x, n.x),
          Math.min(e.y, n.y),
          Math.abs(n.x - e.x),
          Math.abs(n.y - e.y),
        );
      else if (t === "arrow") {
        const j = n.x - e.x,
          x = n.y - e.y,
          D = Math.hypot(j, x);
        if (D < 2) return;
        const R = Math.min(D * 0.6, y * 5 + 6),
          O = Math.atan2(x, j),
          F = n.x - Math.cos(O) * R * 0.8,
          ht = n.y - Math.sin(O) * R * 0.8;
        (a.beginPath(),
          a.moveTo(e.x, e.y),
          a.lineTo(F, ht),
          a.stroke(),
          a.beginPath(),
          a.moveTo(n.x, n.y),
          a.lineTo(n.x - R * Math.cos(O - 0.45), n.y - R * Math.sin(O - 0.45)),
          a.lineTo(n.x - R * Math.cos(O + 0.45), n.y - R * Math.sin(O + 0.45)),
          a.closePath(),
          a.fill());
      } else if (t === "blur") {
        const j = Math.max(0, Math.round(Math.min(e.x, n.x))),
          x = Math.max(0, Math.round(Math.min(e.y, n.y))),
          D = Math.min(r.width - j, Math.round(Math.abs(n.x - e.x))),
          R = Math.min(r.height - x, Math.round(Math.abs(n.y - e.y)));
        if (D < 2 || R < 2) return;
        const O = Math.max(6, Math.round(Math.max(D, R) / 12)),
          F = document.createElement("canvas");
        ((F.width = Math.max(1, Math.ceil(D / O))),
          (F.height = Math.max(1, Math.ceil(R / O))));
        const ht = F.getContext("2d");
        ((ht.imageSmoothingEnabled = !0),
          ht.drawImage(r, j, x, D, R, 0, 0, F.width, F.height),
          (a.imageSmoothingEnabled = !1),
          a.drawImage(F, 0, 0, F.width, F.height, j, x, D, R),
          (a.imageSmoothingEnabled = !0));
      }
    },
    wt = () => {
      const t = Y;
      ot(null);
      const e = E.current;
      if (!t || !e || !t.value.trim()) return;
      xt();
      const n = e.getContext("2d"),
        r = Math.round(Math.max(16, tt * 5) * Math.max(1, e.width / 1e3));
      ((n.font = `600 ${r}px system-ui, "Segoe UI", Roboto, "Noto Sans", "Noto Sans Devanagari", sans-serif`),
        (n.textBaseline = "top"),
        (n.fillStyle = X),
        (n.lineWidth = Math.max(2, r / 9)),
        (n.lineJoin = "round"),
        (n.strokeStyle = X === "#ffffff" ? "#000000" : "#ffffff"),
        t.value
          .split(
            `
`,
          )
          .forEach((a, y) => {
            (n.strokeText(a, t.cx, t.cy + y * r * 1.2),
              n.fillText(a, t.cx, t.cy + y * r * 1.2));
          }));
    },
    we = (t) => {
      if (f === "select") return;
      if (f === "text") {
        (t.preventDefault(), Y && wt());
        const n = ct(t);
        ot({ cx: n.x, cy: n.y, left: t.clientX, top: t.clientY, value: "" });
        return;
      }
      if (We.includes(f)) {
        xt();
        const n = E.current,
          r = ct(t);
        ((K.current = {
          start: r,
          base: n.getContext("2d").getImageData(0, 0, n.width, n.height),
        }),
          (at.current = !0),
          t.target.setPointerCapture?.(t.pointerId));
        return;
      }
      (xt(), (at.current = !0));
      const e = ct(t);
      ((it.current = e), be(e));
    },
    ye = (t) => {
      if (f === "select" || !at.current) return;
      const e = ct(t);
      if (K.current) {
        (E.current.getContext("2d").putImageData(K.current.base, 0, 0),
          xe(f, K.current.start, e));
        return;
      }
      (Lt(it.current, e), (it.current = e));
    },
    Ut = () => {
      ((K.current = null), (at.current = !1), (it.current = null));
    },
    be = (t) => Lt(t, t),
    Lt = (t, e) => {
      if (!t) return;
      const n = E.current;
      if (!n) return;
      const r = n.getContext("2d");
      ((r.lineCap = "round"),
        (r.lineJoin = "round"),
        f === "pencil"
          ? ((r.globalAlpha = 1), (r.strokeStyle = X), (r.lineWidth = tt))
          : f === "highlighter" &&
            ((r.globalAlpha = 0.35), (r.strokeStyle = Ct), (r.lineWidth = kt)),
        r.beginPath(),
        r.moveTo(t.x, t.y),
        r.lineTo(e.x, e.y),
        r.stroke(),
        (r.globalAlpha = 1));
    },
    zt = () => {
      const t = E.current;
      return t
        ? new Promise((e) =>
            t.toBlob(
              (n) => e(n),
              l === "jpg" ? "image/jpeg" : "image/png",
              0.92,
            ),
          )
        : Promise.resolve(null);
    },
    yt = () => {
      const t = new Date(),
        e = (n) => String(n).padStart(2, "0");
      return `screenshot-${t.getFullYear()}${e(t.getMonth() + 1)}${e(t.getDate())}-${e(t.getHours())}${e(t.getMinutes())}${e(t.getSeconds())}.${l}`;
    },
    ve = async () => {
      const t = await zt();
      t && Ht(t, yt());
    },
    je = async () => {
      const t = await zt();
      t && (await Dt(t));
    },
    Ft = () => {
      (i("idle"), H(null), dt(null), U(null), V([]));
    };
  return s.jsxs(Ce, {
    children: [
      c === "idle" &&
        s.jsxs("div", {
          className:
            "text-center py-12 border-2 border-dashed border-border rounded-xl space-y-5",
          children: [
            s.jsx(At, { className: "h-10 w-10 mx-auto text-muted-foreground" }),
            s.jsx("p", {
              className: "text-muted-foreground max-w-md mx-auto px-4",
              children:
                "Capture a screenshot of your screen, a window, or a browser tab — entirely in your browser. Nothing is uploaded anywhere.",
            }),
            s.jsxs("div", {
              children: [
                s.jsx("p", {
                  className: "text-xs text-muted-foreground mb-2",
                  children:
                    'Delay before capturing — gives you time to switch to another window after picking "Entire Screen," since your browser itself drops to the background right after you choose that option',
                }),
                s.jsx("div", {
                  className: "flex items-center justify-center gap-2",
                  children: Be.map((t) =>
                    s.jsx(
                      p,
                      {
                        size: "sm",
                        variant: m === t ? "default" : "outline",
                        onClick: () => C(t),
                        children: t === 0 ? "None" : `${t}s`,
                      },
                      t,
                    ),
                  ),
                }),
              ],
            }),
            s.jsxs("div", {
              className: "flex flex-wrap items-center justify-center gap-3",
              children: [
                s.jsxs(p, {
                  onClick: () => Rt("single"),
                  size: "lg",
                  children: [
                    s.jsx(At, { className: "h-4 w-4 mr-2" }),
                    " Take Screenshot",
                  ],
                }),
                s.jsxs(p, {
                  onClick: () => Rt("scroll"),
                  size: "lg",
                  variant: "outline",
                  children: [
                    s.jsx($t, { className: "h-4 w-4 mr-2" }),
                    " Capture whole page (scroll)",
                  ],
                }),
              ],
            }),
            s.jsxs("details", {
              className:
                "mx-auto max-w-xl px-4 text-left text-xs text-muted-foreground",
              children: [
                s.jsx("summary", {
                  className: "cursor-pointer text-center",
                  children:
                    "How whole-page capture works, and what it can't capture",
                }),
                s.jsxs("div", {
                  className: "mt-2 space-y-2",
                  children: [
                    s.jsx("p", {
                      children:
                        "A website can't read or scroll another page for you, so there is no one-click full-page capture here. Instead, share the tab or window, then scroll it yourself, slowly. This tool takes a picture about twice a second, lines each one up with the last, and joins them into one tall image, all in your browser. Nothing is uploaded.",
                    }),
                    s.jsxs("p", {
                      children: [
                        "Not captured: anything you don't scroll past; content that only loads after a pause if you scroll on too quickly; side-to-side scrolling; videos and animations (they show as one frame); anything covering the page, such as other windows or pop-ups. Sticky headers and footers appear once. Long blank stretches or repeating patterns can't be lined up, and the tool says so instead of guessing. The image is capped at ",
                        jt.toLocaleString("en-US"),
                        " px tall.",
                      ],
                    }),
                  ],
                }),
              ],
            }),
          ],
        }),
      c === "scrolling" &&
        s.jsxs("div", {
          className:
            "text-center py-10 border-2 border-dashed border-border rounded-xl space-y-4 px-4",
          "data-testid": "scroll-capture",
          children: [
            s.jsx($t, { className: "h-9 w-9 mx-auto text-primary" }),
            s.jsx("p", {
              className: "text-sm font-medium",
              children: "Recording the page you shared",
            }),
            s.jsx("p", {
              className: "text-sm text-muted-foreground",
              role: "status",
              "aria-live": "polite",
              children:
                J.frames <= 1
                  ? "Switch to the shared tab or window and scroll down slowly."
                  : `Captured ${J.height.toLocaleString("en-US")} px so far from ${J.frames} frames.`,
            }),
            J.hint &&
              s.jsx("p", {
                className: "text-sm max-w-md mx-auto",
                role: "status",
                children: J.hint,
              }),
            s.jsxs("div", {
              className: "flex justify-center gap-3",
              children: [
                s.jsx(p, { onClick: mt, children: "Finish" }),
                s.jsx(p, {
                  variant: "outline",
                  onClick: ne,
                  children: "Cancel",
                }),
              ],
            }),
            s.jsx("p", {
              className: "text-xs text-muted-foreground",
              children:
                "Scroll steady and not too fast: each step must overlap the last. Press Finish here, or use the browser's Stop sharing, when you reach the end.",
            }),
          ],
        }),
      c === "counting-down" &&
        s.jsxs("div", {
          className:
            "text-center py-16 border-2 border-dashed border-border rounded-xl",
          children: [
            s.jsx("p", {
              className: "text-sm text-muted-foreground mb-3",
              children: "Set up your screen now — capturing in",
            }),
            s.jsx("p", {
              className: "text-6xl font-bold text-primary",
              children: d,
            }),
          ],
        }),
      c === "cropping" &&
        P &&
        s.jsxs("div", {
          ref: w,
          className: I
            ? "bg-background p-4 h-screen flex flex-col justify-center space-y-4"
            : "space-y-4",
          children: [
            s.jsx("div", {
              className: "flex justify-end",
              children: s.jsx(p, {
                size: "sm",
                variant: "outline",
                onClick: Tt,
                className: "gap-2",
                children: I
                  ? s.jsxs(s.Fragment, {
                      children: [
                        s.jsx(Bt, { className: "h-4 w-4" }),
                        " Exit Fullscreen",
                      ],
                    })
                  : s.jsxs(s.Fragment, {
                      children: [
                        s.jsx(Wt, { className: "h-4 w-4" }),
                        " Fullscreen (easier on mobile)",
                      ],
                    }),
              }),
            }),
            s.jsxs("div", {
              ref: Nt,
              className: `relative w-full rounded-lg border overflow-hidden bg-muted/30 cursor-crosshair select-none ${I ? "flex-1" : "max-h-[70vh]"}`,
              onMouseDown: oe,
              onMouseMove: ie,
              onMouseUp: lt,
              onMouseLeave: lt,
              onTouchStart: le,
              onTouchMove: ce,
              onTouchEnd: lt,
              onTouchCancel: lt,
              style: { touchAction: "none" },
              children: [
                s.jsx("img", {
                  ref: nt,
                  src: P,
                  alt: "Captured screenshot",
                  className: I
                    ? "w-full h-full object-contain pointer-events-none"
                    : "w-full max-h-[70vh] object-contain pointer-events-none",
                  draggable: !1,
                }),
                g &&
                  g.w >= 4 &&
                  g.h >= 4 &&
                  (() => {
                    const t = ae();
                    return s.jsx("div", {
                      className:
                        "absolute border-2 border-primary bg-primary/10 pointer-events-none",
                      style: {
                        left: t.x + g.x,
                        top: t.y + g.y,
                        width: g.w,
                        height: g.h,
                      },
                    });
                  })(),
              ],
            }),
            Mt &&
              s.jsx("p", {
                className: "text-xs text-muted-foreground text-center",
                "data-testid": "stitch-note",
                children: Mt,
              }),
            s.jsx("p", {
              className: "text-xs text-muted-foreground text-center",
              children:
                "Drag across the image to select just the region you want, then Crop to open the editor for rotating or marking it up — or Copy/Download the plain capture (or your selection) directly if that's all you need.",
            }),
            s.jsxs("div", {
              className: "flex items-center justify-center gap-3 flex-wrap",
              children: [
                s.jsxs(p, {
                  onClick: he,
                  className: "gap-2",
                  children: [s.jsx(Te, { className: "h-4 w-4" }), " Crop"],
                }),
                S &&
                  s.jsxs(p, {
                    variant: "outline",
                    onClick: ue,
                    className: "gap-2",
                    children: [s.jsx(bt, { className: "h-4 w-4" }), " Copy"],
                  }),
                s.jsx(p, {
                  variant: "outline",
                  onClick: de,
                  className: "gap-2",
                  children: "Download",
                }),
                s.jsx(p, {
                  variant: "outline",
                  onClick: Ft,
                  children: "Take Another",
                }),
              ],
            }),
          ],
        }),
      c === "editing" &&
        s.jsxs("div", {
          ref: w,
          className: I
            ? "bg-background p-4 h-screen overflow-auto space-y-4"
            : "space-y-4",
          children: [
            s.jsxs("div", {
              className:
                "flex items-center justify-center gap-2 flex-wrap border-b pb-3",
              children: [
                s.jsx(p, {
                  size: "sm",
                  variant: f === "select" ? "default" : "outline",
                  onClick: () => W("select"),
                  title: "Select / pan",
                  children: s.jsx(Re, { className: "h-4 w-4" }),
                }),
                s.jsx(p, {
                  size: "sm",
                  variant: f === "pencil" ? "default" : "outline",
                  onClick: () => W("pencil"),
                  title: "Pencil",
                  children: s.jsx(Ie, { className: "h-4 w-4" }),
                }),
                s.jsx(p, {
                  size: "sm",
                  variant: f === "highlighter" ? "default" : "outline",
                  onClick: () => W("highlighter"),
                  title: "Highlighter",
                  children: s.jsx(Le, { className: "h-4 w-4" }),
                }),
                s.jsx(p, {
                  size: "sm",
                  variant: f === "arrow" ? "default" : "outline",
                  onClick: () => W("arrow"),
                  title: "Arrow",
                  children: s.jsx(ze, { className: "h-4 w-4" }),
                }),
                s.jsx(p, {
                  size: "sm",
                  variant: f === "rect" ? "default" : "outline",
                  onClick: () => W("rect"),
                  title: "Box",
                  children: s.jsx(Ee, { className: "h-4 w-4" }),
                }),
                s.jsx(p, {
                  size: "sm",
                  variant: f === "text" ? "default" : "outline",
                  onClick: () => W("text"),
                  title: "Text",
                  children: s.jsx(Se, { className: "h-4 w-4" }),
                }),
                s.jsx(p, {
                  size: "sm",
                  variant: f === "blur" ? "default" : "outline",
                  onClick: () => W("blur"),
                  title: "Hide (pixelate) a region",
                  children: s.jsx(Ue, { className: "h-4 w-4" }),
                }),
                s.jsx("div", { className: "w-px h-6 bg-border mx-1" }),
                s.jsx(p, {
                  size: "sm",
                  variant: "outline",
                  onClick: pe,
                  title: "Rotate 90°",
                  children: s.jsx(De, { className: "h-4 w-4" }),
                }),
                s.jsx(p, {
                  size: "sm",
                  variant: "outline",
                  onClick: () => ut((t) => Math.max(0.5, t - 0.25)),
                  title: "Zoom out",
                  children: s.jsx(He, { className: "h-4 w-4" }),
                }),
                s.jsxs("span", {
                  className: "text-xs text-muted-foreground w-10 text-center",
                  children: [Math.round(_ * 100), "%"],
                }),
                s.jsx(p, {
                  size: "sm",
                  variant: "outline",
                  onClick: () => ut((t) => Math.min(3, t + 0.25)),
                  title: "Zoom in",
                  children: s.jsx(Fe, { className: "h-4 w-4" }),
                }),
                s.jsx(p, {
                  size: "sm",
                  variant: "outline",
                  onClick: fe,
                  disabled: et.length === 0,
                  title: "Undo last stroke",
                  children: s.jsx(Pe, { className: "h-4 w-4" }),
                }),
                s.jsx("div", { className: "w-px h-6 bg-border mx-1" }),
                s.jsx(p, {
                  size: "sm",
                  variant: "outline",
                  onClick: Tt,
                  title: I
                    ? "Exit fullscreen"
                    : "Fullscreen (easier on mobile)",
                  children: I
                    ? s.jsx(Bt, { className: "h-4 w-4" })
                    : s.jsx(Wt, { className: "h-4 w-4" }),
                }),
              ],
            }),
            (f === "pencil" || f === "arrow" || f === "rect" || f === "text") &&
              s.jsxs("div", {
                className: "flex items-center justify-center gap-3 flex-wrap",
                children: [
                  s.jsx("div", {
                    className: "flex items-center gap-1.5",
                    children: Zt.map((t) =>
                      s.jsx(
                        "button",
                        {
                          onClick: () => Jt(t),
                          className: `h-6 w-6 rounded-full border-2 ${X === t ? "border-primary" : "border-border"}`,
                          style: { backgroundColor: t },
                          "aria-label": `Pencil color ${t}`,
                        },
                        t,
                      ),
                    ),
                  }),
                  s.jsxs("div", {
                    className: "flex items-center gap-2 w-40",
                    children: [
                      s.jsx("span", {
                        className: "text-xs text-muted-foreground shrink-0",
                        children: "Thickness",
                      }),
                      s.jsx(Ot, {
                        value: [tt],
                        onValueChange: (t) => Kt(t[0]),
                        min: 1,
                        max: 12,
                        step: 1,
                      }),
                    ],
                  }),
                ],
              }),
            f === "highlighter" &&
              s.jsxs("div", {
                className: "flex items-center justify-center gap-3 flex-wrap",
                children: [
                  s.jsx("div", {
                    className: "flex items-center gap-1.5",
                    children: Vt.map((t) =>
                      s.jsx(
                        "button",
                        {
                          onClick: () => Qt(t),
                          className: `h-6 w-6 rounded-full border-2 ${Ct === t ? "border-primary" : "border-border"}`,
                          style: { backgroundColor: t },
                          "aria-label": `Highlighter color ${t}`,
                        },
                        t,
                      ),
                    ),
                  }),
                  s.jsxs("div", {
                    className: "flex items-center gap-2 w-40",
                    children: [
                      s.jsx("span", {
                        className: "text-xs text-muted-foreground shrink-0",
                        children: "Thickness",
                      }),
                      s.jsx(Ot, {
                        value: [kt],
                        onValueChange: (t) => te(t[0]),
                        min: 8,
                        max: 40,
                        step: 2,
                      }),
                    ],
                  }),
                ],
              }),
            f === "blur" &&
              s.jsx("p", {
                className: "text-center text-xs text-muted-foreground",
                children:
                  "Drag a box over anything you want to hide, such as a name or a number. It is pixelated into large blocks.",
              }),
            f === "text" &&
              s.jsx("p", {
                className: "text-center text-xs text-muted-foreground",
                children:
                  "Click where the text should go, type, then press Enter (Shift+Enter for a new line).",
              }),
            Y &&
              s.jsx("textarea", {
                autoFocus: !0,
                rows: 1,
                value: Y.value,
                onChange: (t) =>
                  ot((e) => e && { ...e, value: t.target.value }),
                onKeyDown: (t) => {
                  t.key === "Enter" && !t.shiftKey
                    ? (t.preventDefault(), wt())
                    : t.key === "Escape" && ot(null);
                },
                onBlur: () => {
                  Y.value.trim() && wt();
                },
                "aria-label": "Text to add",
                className:
                  "fixed z-50 border rounded px-1 text-base bg-white text-black shadow resize-none",
                style: { left: Y.left, top: Y.top, minWidth: 160 },
              }),
            s.jsx("div", {
              className:
                "w-full rounded-lg border max-h-[70vh] overflow-auto bg-muted/30 flex items-center justify-center",
              children: s.jsx("canvas", {
                ref: E,
                onPointerDown: we,
                onPointerMove: ye,
                onPointerUp: Ut,
                onPointerLeave: Ut,
                onMouseDown: (t) => {
                  f === "text" && t.preventDefault();
                },
                className: "touch-none",
                style: {
                  transform: `scale(${_})`,
                  transformOrigin: "center",
                  cursor:
                    f === "select"
                      ? "default"
                      : f === "text"
                        ? "text"
                        : "crosshair",
                  maxWidth: _ === 1 ? "100%" : void 0,
                },
              }),
            }),
            s.jsxs("div", {
              className: "flex items-center justify-center gap-3 flex-wrap",
              children: [
                S
                  ? s.jsxs(p, {
                      onClick: je,
                      className: "gap-2",
                      children: [
                        s.jsx(bt, { className: "h-4 w-4" }),
                        " Copy to Clipboard",
                      ],
                    })
                  : s.jsxs(p, {
                      disabled: !0,
                      title:
                        "Your browser doesn't support copying images to the clipboard",
                      className: "gap-2",
                      children: [
                        s.jsx(bt, { className: "h-4 w-4" }),
                        " Copy Not Supported",
                      ],
                    }),
                s.jsxs("select", {
                  className: "border rounded px-2 text-sm bg-background",
                  value: l,
                  onChange: (t) => u(t.target.value),
                  "aria-label": "File format",
                  children: [
                    s.jsx("option", { value: "png", children: "PNG" }),
                    s.jsx("option", {
                      value: "jpg",
                      children: "JPG (smaller)",
                    }),
                  ],
                }),
                s.jsx(ke, {
                  onClick: ve,
                  markHint: yt(),
                  label: `Download ${l.toUpperCase()}`,
                }),
                s.jsx(p, {
                  variant: "outline",
                  onClick: Ft,
                  children: "Take Another",
                }),
              ],
            }),
          ],
        }),
      s.jsx(Me, { whatIsIt: vt.what, howToUse: vt.how, tip: vt.tip }),
    ],
  });
}
export { Rs as default };
//# sourceMappingURL=ScreenshotTool-IZ7Q-6dY.js.map
