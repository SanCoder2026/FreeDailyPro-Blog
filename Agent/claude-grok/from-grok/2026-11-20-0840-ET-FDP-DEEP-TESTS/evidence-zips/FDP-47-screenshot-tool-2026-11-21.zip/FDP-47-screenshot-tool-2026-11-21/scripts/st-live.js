// FDP-47 Screenshot Capture & Editor, guest. Usage: node st-live.js <main|mobile|real|subset> [engine]
// Headless browsers on this Linux box cannot open a real screen-share picker (getDisplayMedia → NotSupported/NotReadable),
// so "main" replaces navigator.mediaDevices.getDisplayMedia IN THE TEST BROWSER ONLY with a canvas.captureStream() stub
// that paints a known test screen (single), a scrolling tall page (scroll) or a blank page (blank). Nothing on the site is changed.
// main: one page load: capture, Download (cropping), crop+Download, Copy, editor tools + PNG/JPG, whole-page stitch, blank hint,
//       countdown + stop; then reload/download until the cap dialog; Day Pass (stops at email) / Quick Buy (stops at Stripe).
// Never types an email/card, never clicks a pass "Continue", never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const crypto = require('crypto');
const BASE = '/workspace/deep/47-screenshot-tool/'; const OUT = BASE + 'live/'; const URL = 'https://www.freedailypro.com/tool/screenshot-tool';
const mode = process.argv[2] || 'main'; const eng = process.argv[3] || 'chromium'; const sfx = eng === 'chromium' ? '' : '-' + eng;
fs.mkdirSync(OUT + 'downloads', { recursive: true }); fs.mkdirSync(OUT + 'cases', { recursive: true });
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex').slice(0, 16);
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').slice(0, 160);
const STUB = () => {
  window.__stubMode = 'single';
  const fake = async () => {
    const mode = window.__stubMode; const W = 1280, H = 720; const cv = document.createElement('canvas'); cv.width = W; cv.height = H; const g = cv.getContext('2d'); let off = 0;
    const draw = () => {
      g.fillStyle = '#ffffff'; g.fillRect(0, 0, W, H);
      if (mode === 'single') {
        g.fillStyle = '#e53935'; g.fillRect(0, 0, W / 2, H / 2); g.fillStyle = '#43a047'; g.fillRect(W / 2, 0, W / 2, H / 2); g.fillStyle = '#1e88e5'; g.fillRect(0, H / 2, W / 2, H / 2); g.fillStyle = '#fdd835'; g.fillRect(W / 2, H / 2, W / 2, H / 2);
        g.fillStyle = '#ffffff'; g.fillRect(60, 60, 560, 90); g.fillStyle = '#000'; g.font = 'bold 44px sans-serif'; g.fillText('Jane Doe 555-0134', 80, 122);
        g.font = '28px sans-serif'; g.fillText('STUB SCREEN 1280x720', 760, 120); g.fillText('Account 4111 2222 3333 4444', 700, 600);
      } else if (mode === 'scroll') {
        for (let y = -(off % 60); y < H; y += 60) { const row = Math.floor((y + off) / 60); g.fillStyle = ['#fff3e0', '#e3f2fd', '#e8f5e9', '#fce4ec', '#ede7f6'][row % 5]; g.fillRect(0, y, W, 60); g.fillStyle = '#000'; g.font = '26px sans-serif'; g.fillText('Row ' + row + ' unique text ' + ((row * 7919) % 1000) + ' ' + 'abcdefghij'.slice(row % 7), 30 + (row * 37) % 300, y + 40); }
      } // blank: stays white
    };
    draw(); const iv = setInterval(() => { if (mode === 'scroll' && off < 2400) off += 100; draw(); }, 250);
    const s = cv.captureStream(15); window.__stubStream = s; window.__stubCount = (window.__stubCount || 0) + 1; s.getVideoTracks()[0].addEventListener('ended', () => clearInterval(iv)); return s;
  };
  if (window.__noDisplayMedia) { try { delete MediaDevices.prototype.getDisplayMedia; } catch (e) {} navigator.mediaDevices.getDisplayMedia = undefined; return; }
  if (navigator.mediaDevices) navigator.mediaDevices.getDisplayMedia = fake;
};
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, cases: {} }; let c, p; const net = [];
 const open = async (opts = {}) => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true, locale: 'en-US', ...(opts.ctx || {}) }); if (eng === 'chromium') await c.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://www.freedailypro.com' }).catch(() => {}); p = await c.newPage(); p.setDefaultTimeout(15000);
  await p.addInitScript(() => { window.__t = []; new MutationObserver(ms => ms.forEach(m => m.addedNodes.forEach(n => { if (n.nodeType === 1 && n.matches && n.matches('[data-sonner-toast]')) setTimeout(() => window.__t.push(n.innerText.trim()), 80); }))).observe(document, { childList: true, subtree: true }); });
  if (opts.noDM) await p.addInitScript(() => { window.__noDisplayMedia = true; }); if (opts.stub !== false) await p.addInitScript(STUB);
  p.on('request', r => { const d = r.postData() || ''; net.push({ m: r.method(), u: red(r.url()), len: d.length, big: d.length > 20000, hit: /data:image|iVBORw0KGgo|Jane Doe/.test(d) }); });
  await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000); };
 const used = () => p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 const toasts = n => p.evaluate(n => (window.__t || []).slice(n), n); const tn = () => p.evaluate(() => (window.__t || []).length);
 const btn = name => p.locator('main button').filter({ hasText: name });
 const shot = id => p.screenshot({ path: OUT + 'cases/' + id + sfx + '.png' }).catch(() => {});
 const download = async (id, loc) => { const r = { before: await used() }; const dp = p.waitForEvent('download', { timeout: 20000 }).catch(() => null); const t0 = await tn(); await loc.click(); const d = await dp; await p.waitForTimeout(1500);
  r.dialog = await dialog(); if (d) { const f = OUT + 'downloads/' + id + sfx + '-' + d.suggestedFilename(); await d.saveAs(f); r.download = { name: d.suggestedFilename(), bytes: fs.statSync(f).size, sha: sha(f), file: f }; }
  if (r.dialog) { await p.screenshot({ path: OUT + 'cases/' + id + sfx + '-dialog.png' }); if (/Day Pass|day pass/i.test(r.dialog) && !R.dayPass) { const bp = p.getByRole('button', { name: /Buy Day Pass|Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.dayPass = { dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'dlg-daypass' + sfx + '.png' }); } } await esc(); }
  r.after = await used(); r.toasts = await toasts(t0); return r; };
 const capture = async (stubMode, delay) => { await p.evaluate(m => { window.__stubMode = m; }, stubMode); if (delay !== undefined) await btn(delay).first().click(); const t0 = await tn(); await btn('Take Screenshot').first().click(); await p.waitForTimeout(delay && delay !== 'None' ? 3500 : 2500); return { toasts: await toasts(t0), used: await used(), img: await p.evaluate(() => { const i = document.querySelector('main img[alt="Captured screenshot"]'); return i ? { w: i.naturalWidth, h: i.naturalHeight } : null; }) }; };
 const again = async () => { const a = btn('Take Another'); if (await a.count()) { await a.first().click(); await p.waitForTimeout(800); } };
 const dragOnImg = async (fx0, fy0, fx1, fy1) => { const bb = await p.locator('main img[alt="Captured screenshot"]').boundingBox(); await p.mouse.move(bb.x + bb.width * fx0, bb.y + bb.height * fy0); await p.mouse.down(); await p.mouse.move(bb.x + bb.width * fx1, bb.y + bb.height * fy1, { steps: 8 }); await p.mouse.up(); };
 const dragOnCanvas = async (fx0, fy0, fx1, fy1) => { const bb = await p.locator('main canvas').first().boundingBox(); await p.mouse.move(bb.x + bb.width * fx0, bb.y + bb.height * fy0); await p.mouse.down(); await p.mouse.move(bb.x + bb.width * fx1, bb.y + bb.height * fy1, { steps: 10 }); await p.mouse.up(); await p.waitForTimeout(200); };
 const tool = t => p.locator(`main button[title="${t}"]`).first().click();
 const quickBuys = async () => { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); const u0 = p.url();
  await p.getByRole('button', { name: 'Quick Buy' }).first().click(); await p.waitForTimeout(3000); R.qbDay = { url: p.url() !== u0 ? red(p.url()) : null, dialog: await dialog(), email: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await esc();
  if (p.url() !== u0) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); }
  await p.getByRole('button', { name: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(7000); R.qbMonth = { url: red(p.url()), title: await p.title(), dialog: await dialog() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' }); };
 if (mode === 'main') { await open(); R.start = await used(); R.strip = await p.evaluate(() => (document.querySelector('main').innerText.match(/Trial:[^\n]*/) || [''])[0]);
  // keyboard reach
  const seq = []; for (let i = 0; i < 40; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('title') || e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 40).replace(/\n/g, ' '); }); seq.push(a); if (/Take Screenshot/.test(a)) break; } R.kbd = { reachedTake: seq.some(s => /Take Screenshot/.test(s)), tabs: seq.length };
  R.cases.C01 = await capture('single', 'None'); await shot('C01-cropping');
  R.cases.C02 = await download('C02-full', btn('Download').first()); await shot('C02');
  await dragOnImg(0.04, 0.07, 0.5, 0.22); await p.waitForTimeout(300); await shot('C03-selection'); R.cases.C03 = await download('C03-crop', btn('Download').first());
  { const t0 = await tn(); const r = { before: await used() }; const cbtn = btn('Copy'); if (await cbtn.count()) { await cbtn.first().click(); await p.waitForTimeout(2000); r.dialog = await dialog(); if (r.dialog) { await shot('C04-dialog'); await esc(); } r.clip = await p.evaluate(async () => { try { const it = await navigator.clipboard.read(); const bl = await it[0].getType('image/png'); const bm = await createImageBitmap(bl); return { types: it[0].types, w: bm.width, h: bm.height, bytes: bl.size }; } catch (e) { return 'ERR ' + e.message; } }); } else r.missing = true; r.after = await used(); r.toasts = await toasts(t0); R.cases.C04 = r; }
  // editor
  { const r = {}; await dragOnImg(0.0, 0.0, 1.0, 1.0); await btn('Crop').first().click(); await p.waitForTimeout(1500); r.canvas = await p.evaluate(() => { const c = document.querySelector('main canvas'); return c ? { w: c.width, h: c.height } : null; });
   await tool('Pencil'); await dragOnCanvas(0.55, 0.3, 0.9, 0.35); await tool('Highlighter'); await dragOnCanvas(0.55, 0.42, 0.9, 0.42); await tool('Arrow'); await dragOnCanvas(0.6, 0.8, 0.8, 0.6); await tool('Box'); await dragOnCanvas(0.52, 0.76, 0.98, 0.9);
   await tool('Hide (pixelate) a region'); await dragOnCanvas(0.04, 0.07, 0.5, 0.22); await dragOnCanvas(0.53, 0.78, 0.97, 0.86);
   await tool('Text'); { const bb = await p.locator('main canvas').first().boundingBox(); await p.mouse.click(bb.x + bb.width * 0.1, bb.y + bb.height * 0.6); await p.waitForTimeout(400); const ta = p.getByLabel('Text to add'); r.textBox = await ta.count(); if (r.textBox) { await ta.fill('Bug here ✓ नमस्ते مرحبا 你好'); await ta.press('Enter'); } }
   await p.waitForTimeout(500); r.undoEnabled = await p.locator('main button[title="Undo last stroke"]').isEnabled(); await shot('C05-editor');
   R.cases.C05 = r; R.cases.C05png = await download('C05-edited', p.locator('main button').filter({ hasText: /^Download PNG/ }).first());
   await p.locator('main select[aria-label="File format"]').selectOption('jpg'); R.cases.C05jpg = await download('C05-edited-jpg', p.locator('main button').filter({ hasText: /^Download JPG/ }).first());
   await tool('Rotate 90°'); await p.waitForTimeout(800); R.cases.C05rot = { canvas: await p.evaluate(() => { const c = document.querySelector('main canvas'); return { w: c.width, h: c.height }; }), undoAfterRotate: await p.locator('main button[title="Undo last stroke"]').isEnabled() }; await shot('C05-rotated'); }
  // whole page stitch
  await again(); { const r = { before: await used() }; await p.evaluate(() => { window.__stubMode = 'scroll'; }); const t0 = await tn(); await btn('Capture whole page').first().click(); await p.waitForTimeout(9000); r.status = await p.evaluate(() => document.querySelector('[data-testid=scroll-capture]')?.innerText.replace(/\n+/g, ' | ')); await shot('C06-scrolling');
   await btn('Finish').first().click(); await p.waitForTimeout(2500); r.note = await p.evaluate(() => document.querySelector('[data-testid=stitch-note]')?.innerText); r.img = await p.evaluate(() => { const i = document.querySelector('main img[alt="Captured screenshot"]'); return i ? { w: i.naturalWidth, h: i.naturalHeight } : null; }); r.toasts = await toasts(t0); await shot('C06-stitched'); R.cases.C06 = r; R.cases.C06dl = await download('C06-stitched', btn('Download').first()); }
  await again(); { const r = {}; await p.evaluate(() => { window.__stubMode = 'blank'; }); const t0 = await tn(); await btn('Capture whole page').first().click(); await p.waitForTimeout(5000); r.status = await p.evaluate(() => document.querySelector('[data-testid=scroll-capture]')?.innerText.replace(/\n+/g, ' | ')); await shot('C07-blank'); await btn('Finish').first().click(); await p.waitForTimeout(2000); r.note = await p.evaluate(() => document.querySelector('[data-testid=stitch-note]')?.innerText); r.toasts = await toasts(t0); r.stateText = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 300)); R.cases.C07 = r; await shot('C07-after'); }
  await again(); { const r = {}; await p.evaluate(() => { window.__stubMode = 'single'; }); await btn('5s').first().click(); const t0 = await tn(); await btn('Take Screenshot').first().click(); await p.waitForTimeout(1500); r.countdown = await p.evaluate(() => (document.querySelector('main').innerText.match(/Set up your screen now[^\n]*\n?[^\n]*/) || [''])[0]); await shot('C08-countdown'); await p.evaluate(() => window.__stubStream.getTracks().forEach(t => t.stop())); await p.waitForTimeout(5500); r.toasts = await toasts(t0); r.idle = await btn('Take Screenshot').count(); R.cases.C08 = r; }
  await btn('None').first().click(); R.cases.C09 = await capture('single'); R.cases.C09dl = await download('C09-again', btn('Download').first());
  R.endUsed = await used();
  // reload loop until cap dialog
  R.reloads = []; for (let i = 0; i < 4; i++) { await p.reload(); await p.waitForTimeout(5000); const u = await used(); await capture('single', 'None'); const d = await download('R' + (i + 1), btn('Download').first()); R.reloads.push({ usedAtLoad: u, ...d, file: undefined }); if (d.dialog) { const t0 = await tn(); const cb = btn('Copy'); if (await cb.count()) { await cb.first().click(); await p.waitForTimeout(2000); R.copyAtCap = { dialog: await dialog(), toasts: await toasts(t0), clip: await p.evaluate(async () => { try { const it = await navigator.clipboard.read(); const bl = await it[0].getType('image/png'); return bl.size; } catch (e) { return 'ERR ' + e.message; } }) }; await shot('R-copy-at-cap'); await esc(); }
     await dragOnImg(0, 0, 1, 1); await btn('Crop').first().click(); await p.waitForTimeout(1200); R.editorAtCap = await download('R-editor-at-cap', p.locator('main button').filter({ hasText: /^Download PNG/ }).first()); break; } }
  await quickBuys(); }
 if (mode === 'mobile') { R.devices = {}; for (const dn of ['iPhone 14 Pro Max', 'Pixel 7']) { await open({ ctx: { ...pw.devices[dn], acceptDownloads: true }, noDM: true }); const t0 = await tn(); const r = { strip: await p.evaluate(() => (document.querySelector('main').innerText.match(/Trial:[^\n]*/) || [''])[0]), passes: await p.getByRole('button', { name: 'Quick Buy' }).count() };
   r.upfrontNotice = await p.evaluate(() => /not (available|supported) on (phones|mobile)|desktop only|computer only|needs a computer/i.test(document.querySelector('main').innerText)); await btn('Take Screenshot').first().click(); await p.waitForTimeout(2000); r.toasts = await toasts(t0); r.used = await used(); await p.screenshot({ path: OUT + 'cases/M-' + dn.replace(/\W+/g, '-') + '.png' }); R.devices[dn] = r; console.log(dn, JSON.stringify(r)); await c.close(); } }
 if (mode === 'real') { await open({ stub: false }); const t0 = await tn(); await btn('Take Screenshot').first().click(); await p.waitForTimeout(3000); R.real = { toasts: await toasts(t0), used: await used() }; await shot('X-real-' + eng); }
 if (mode === 'subset') { await open(); R.start = await used(); R.cases.S01 = await capture('single', 'None'); await shot('S01'); await dragOnImg(0.04, 0.07, 0.5, 0.22); await btn('Crop').first().click(); await p.waitForTimeout(1200); await tool('Hide (pixelate) a region'); await dragOnCanvas(0.1, 0.1, 0.9, 0.9); await shot('S02-editor');
  R.cases.S02 = { canvas: await p.evaluate(() => { const c = document.querySelector('main canvas'); return c ? { w: c.width, h: c.height } : null; }), copyBtn: await p.evaluate(() => [...document.querySelectorAll('main button')].map(b => b.innerText.trim()).filter(t => /Copy/.test(t))) };
  R.cases.S03 = await download('S03', p.locator('main button').filter({ hasText: /^Download PNG/ }).first()); await again(); await p.evaluate(() => { window.__stubMode = 'scroll'; }); await btn('Capture whole page').first().click(); await p.waitForTimeout(8000); await btn('Finish').first().click(); await p.waitForTimeout(2500); R.cases.S04 = { note: await p.evaluate(() => document.querySelector('[data-testid=stitch-note]')?.innerText) }; await shot('S04'); R.end = await used(); }
 R.t2 = now(); R.net = { total: net.length, hits: net.filter(x => x.hit || x.big).map(x => ({ u: x.u, len: x.len })), posts: net.filter(x => x.m !== 'GET' && /freedailypro/.test(x.u)).map(x => ({ u: x.u, len: x.len })).slice(0, 20) };
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, (k, v) => k === 'net' ? undefined : v, 1).slice(0, 9000)); await b.close(); })();
