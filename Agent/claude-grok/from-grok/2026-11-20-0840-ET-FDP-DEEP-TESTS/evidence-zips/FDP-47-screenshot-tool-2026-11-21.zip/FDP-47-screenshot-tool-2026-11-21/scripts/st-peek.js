// FDP-47: open N fresh guest contexts and record the usage object only (no actions).
const pw = require('playwright');
(async () => { const b = await pw.chromium.launch(); const out = [];
 for (let i = 0; i < +(process.env.N || 6); i++) { const c = await b.newContext(); const p = await c.newPage(); await p.goto('https://www.freedailypro.com/tool/screenshot-tool', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(6000);
  out.push(await p.evaluate(() => { const o = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return o.usageToday + '/' + o.limit + ' ' + (document.querySelector('main').innerText.match(/Trial:[^\n]*/) || [''])[0]; })); await c.close(); }
 console.log(out.join('\n')); await b.close(); })();
