// Probe how getDisplayMedia behaves in headless Chromium with various flags (guest, no actions on the site beyond Take Screenshot).
const pw=require('playwright');
(async()=>{for (const args of [['--use-fake-ui-for-media-stream'],['--use-fake-ui-for-media-stream','--auto-select-desktop-capture-source=Entire screen'],['--auto-accept-this-tab-capture','--use-fake-ui-for-media-stream']]){
 const b=await pw.chromium.launch({args, headless: process.env.HEADFUL ? false : true}); const p=await (await b.newContext()).newPage();
 await p.goto('https://example.com'); const r=await p.evaluate(async()=>{try{const s=await navigator.mediaDevices.getDisplayMedia({video:true}); const t=s.getVideoTracks()[0]; const st=t.getSettings(); t.stop(); return 'OK '+t.label+' '+JSON.stringify(st)}catch(e){return 'ERR '+e.name+' '+e.message}});
 console.log(JSON.stringify(args), r); await b.close();}})();
