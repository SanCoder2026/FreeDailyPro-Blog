// Probe tab-capture auto-select flags for getDisplayMedia (guest, example.com only).
const pw=require('playwright');
(async()=>{for (const hl of [true,false]) for (const args of [['--auto-select-tab-capture-source-by-title=Example Domain'],['--auto-select-tab-capture-source-by-title=Example Domain','--use-fake-ui-for-media-stream'],['--auto-select-desktop-capture-source=Example Domain','--use-fake-ui-for-media-stream']]){
 if(!hl && !process.env.DISPLAY) continue;
 const b=await pw.chromium.launch({args,headless:hl}); const p=await (await b.newContext()).newPage();
 await p.goto('https://example.com'); const r=await Promise.race([p.evaluate(async()=>{try{const s=await navigator.mediaDevices.getDisplayMedia({video:true}); const t=s.getVideoTracks()[0]; const st=t.getSettings(); t.stop(); return 'OK '+t.label+' '+JSON.stringify(st)}catch(e){return 'ERR '+e.name+' '+e.message}}), new Promise(r=>setTimeout(()=>r('TIMEOUT'),15000))]);
 console.log(hl, JSON.stringify(args), r); await b.close();}})();
