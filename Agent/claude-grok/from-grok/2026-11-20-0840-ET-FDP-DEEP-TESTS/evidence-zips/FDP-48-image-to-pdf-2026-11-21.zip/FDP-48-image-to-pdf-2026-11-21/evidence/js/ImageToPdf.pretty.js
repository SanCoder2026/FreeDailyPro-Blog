const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/imagePdf-Dtz8PQyf.js",
      "assets/index-BRvxULIc.js",
      "assets/index-CnXdQaNG.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/index-DMQTJy3b.js",
      "assets/pdfMetadata-CcxIhQF2.js",
    ]),
) => i.map((i) => d[i]);
import {
  ap as De,
  f as de,
  N as V,
  ax as Ge,
  b as pe,
  e as H,
  I as ue,
  B as I,
  aJ as Me,
  ay as Ae,
} from "./index-B1CTyGtY.js";
import { r as a, j as e } from "./vendor-react-D01g8YgM.js";
import {
  T as Ee,
  F as ze,
  P as Oe,
  D as $e,
  R as Le,
} from "./ToolPage-DwLoDncN.js";
import { T as Ue } from "./ToolInfoSection-C0i6Zbwo.js";
import { R as _e } from "./ReorderableFileList-BhqJ-ECL.js";
import { f as Be } from "./formatFileSize-B-JRDfN5.js";
import { p as W } from "./plural-FIChqbp4.js";
import { u as Je } from "./useRunToken-sJpsnYiZ.js";
import { T as Ve } from "./TrialFooterNotice-L8nIgEAw.js";
import { c as He, r as We } from "./operations-B4LtHhm8.js";
import {
  normalizeImageFile as Xe,
  ImageReadError as he,
  parseCustomPageSize as Ze,
  buildImagePdf as qe,
  DEFAULT_IMAGE_PDF_OPTIONS as Ke,
  pdfNameForImages as Qe,
  ImagePdfCancelled as Ye,
} from "./imagePdf-Dtz8PQyf.js";
import { l as et, r as tt } from "./utils-s8ucLyj8.js";
import {
  S as st,
  a as at,
  b as rt,
  c as it,
  d as z,
} from "./select-ic5yaeGw.js";
import { C as ot } from "./checkbox-Ml1pfDb3.js";
import { T as nt } from "./ToolSteps-DWea1Jiy.js";
import { u as lt } from "./useDownloadedResult-C1FfMpBH.js";
import { f as mt } from "./reorderMath-CVj9Q6Gj.js";
import { I as ct } from "./info-B8t_e6MS.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./grip-vertical-Dzkp2Q5V.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./pdfMetadata-CcxIhQF2.js";
import "./pageView-BQIwVYOi.js";
import "./formAppearance-CdNbuISd.js";
import "./drawTextAnywhere-DcuP6lHH.js";
import "./ocrText-C_9cxcFa.js";
import "./ocrImage-CmXFNUud.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./imageRecompress-eXQFDUm-.js";
import "./textDiff-DxE9AzvO.js";
import "./utils-1EQcVBdK.js";
import "./decode-DrS85i4S.js";
import "./formFill-Dg9Myfyq.js";
import "./redactSearch-DQpyyh_t.js";
import "./nameDetect-DvHCRM0m.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
const X = {
    what: "Combines one or more images into a single PDF, one image per page (or two per page), fitted to A4, US Letter, a custom size, or the image's own size. Accepts JPG, PNG, WebP, GIF (first frame), BMP, SVG and HEIC (the format an iPhone saves by default). Phone photos are turned upright using the orientation the camera stored, so a portrait photo comes out portrait. JPG and PNG files are embedded as they are, without re-compressing them.",
    how: "Add your images; each shows a thumbnail so it is easy to tell them apart. Drag to reorder, rotate any that are sideways, then choose the page size, orientation, margin, and whether each image fits whole inside the page or fills it. Convert, check the strip of pages, and download. Nothing is uploaded; it all runs in your browser.",
    tip: "Photograph documents against a plain, well-lit background; the tool does not straighten or de-shadow a photo. “Fill the page” crops the edges of an image to cover the page, which suits photo prints but not documents. TIFF files are not supported yet (convert them to JPG or PNG first), and an animated GIF contributes only its first frame.",
  },
  dt =
    "image/png,image/jpeg,image/jpg,image/webp,image/heic,image/heif,image/gif,image/bmp,image/svg+xml,image/avif,.jfif,.heic,.heif,.webp,.gif,.bmp,.svg,.avif",
  pt = (r) =>
    r.type.startsWith("image/") ||
    /\.(jpe?g|jfif|png|webp|gif|bmp|svg|avif|heic|heif|tiff?)$/i.test(r.name);
function k({ label: r, children: x }) {
  return e.jsxs("div", {
    role: "group",
    "aria-label": r,
    className: "flex flex-wrap items-center gap-2",
    children: [
      e.jsx("span", {
        className: "text-sm text-muted-foreground w-24 shrink-0",
        children: r,
      }),
      x,
    ],
  });
}
function h({ value: r, current: x, onPick: j, children: b }) {
  return e.jsx(I, {
    type: "button",
    size: "sm",
    variant: x === r ? "default" : "outline",
    "aria-pressed": x === r,
    onClick: () => j(r),
    children: b,
  });
}
function Ns() {
  const [r, x] = a.useState([]),
    [j, b] = a.useState([]),
    [Z, q] = a.useState(!1),
    [K, ge] = a.useState(0),
    [d, fe] = a.useState(() =>
      typeof navigator < "u" && /^en-(US|CA)|^es-MX/i.test(navigator.language)
        ? "letter"
        : "a4",
    ),
    [P, Q] = a.useState("portrait"),
    [v, xe] = a.useState("in"),
    [O, Y] = a.useState("8.5"),
    [$, ee] = a.useState("11"),
    [N, L] = a.useState("normal"),
    [T, te] = a.useState("fit"),
    [R, je] = a.useState("auto"),
    [D, be] = a.useState(!1),
    [U, se] = a.useState("vertical"),
    [y, C] = a.useState(!1),
    [we, ae] = a.useState(0),
    [m, G] = a.useState(null),
    [M, A] = a.useState([]),
    [re, E] = a.useState(""),
    [_, ie] = a.useState([]),
    [oe, B] = a.useState([]),
    [Pe, ne] = a.useState(!1),
    ve = a.useRef(d).current,
    Ne = lt(m),
    c = Je();
  a.useEffect(() => () => c.cancel(), [c]);
  const J = a.useMemo(() => r.map((t) => URL.createObjectURL(t)), [r]);
  a.useEffect(() => () => J.forEach((t) => URL.revokeObjectURL(t)), [J]);
  const g = () => {
      (c.cancel(), C(!1), G(null), A([]), E(""));
    },
    ye = a.useCallback(async (t) => {
      const s = [],
        i = [],
        l = [];
      for (const n of t)
        pt(n)
          ? l.push(n)
          : s.push(
              `${n.name} is not an image and was skipped${/\.pdf$/i.test(n.name) ? ". To work with PDFs use PDF to JPG or Merge PDF" : ""}.`,
            );
      (q(!0), ge(l.length));
      const u = [];
      for (const n of l)
        try {
          if (/\.gif$/i.test(n.name) || n.type === "image/gif") {
            const { isAnimatedGif: p } = await De(
              async () => {
                const { isAnimatedGif: S } =
                  await import("./imagePdf-Dtz8PQyf.js");
                return { isAnimatedGif: S };
              },
              __vite__mapDeps([0, 1, 2, 3, 4, 5]),
            );
            p(new Uint8Array(await n.arrayBuffer())) &&
              i.push(
                `${n.name} is an animated GIF. A PDF page cannot move, so only its first frame is used.`,
              );
          }
          const o = await Xe(await He(n));
          u.push(
            o.name === n.name ? o : new File([o], n.name, { type: o.type }),
          );
        } catch (o) {
          const p = o instanceof he ? o.message : "could not be read";
          s.push(
            `${n.name}: ${p.charAt(0).toUpperCase()}${p.slice(1)}. It was not added.`,
          );
        }
      (q(!1),
        u.length &&
          (x((n) => {
            const o = mt(n, u);
            return (
              o.length > 0 &&
                de.warning(
                  `${o.length === 1 ? "This image is" : `${o.length} of these images are`} already in your list, added anyway.`,
                ),
              [...n, ...u]
            );
          }),
          b((n) => [...n, ...u.map(() => 0)])),
        ie(s),
        B((n) => [...n, ...i]),
        g());
    }, []),
    Ce = (t) => {
      (r.length <= 1 && B([]),
        x((s) => s.filter((i, l) => l !== t)),
        b((s) => s.filter((i, l) => l !== t)),
        g());
    },
    Fe = (t) => {
      const s = t.map((i) => j[r.indexOf(i)] ?? 0);
      (x(t), b(s), ne(!0), g());
    },
    Se = (t) => {
      (b((s) => s.map((i, l) => (l === t ? (i + 90) % 360 : i))), g());
    },
    w = d === "custom" ? Ze(O, $, v) : null,
    F = w && !w.ok ? w.message : "",
    ke = () => {
      if (d === "original") return "original";
      if (d === "custom") {
        if (!w || !w.ok) return null;
        const [s, i] = [w.widthPt, w.heightPt];
        return P === "landscape"
          ? { widthPt: Math.max(s, i), heightPt: Math.min(s, i) }
          : { widthPt: Math.min(s, i), heightPt: Math.max(s, i) };
      }
      const t = d === "a4" ? { w: 595.28, h: 841.89 } : { w: 612, h: 792 };
      return P === "landscape"
        ? { widthPt: t.h, heightPt: t.w }
        : { widthPt: t.w, heightPt: t.h };
    },
    Ie = async () => {
      if (r.length === 0) return;
      const t = ke();
      if (!t) return;
      const s = c.start();
      (C(!0), ae(0), E(""), G(null), A([]));
      try {
        const i = await Promise.all(r.map((o, p) => We(o, j[p] ?? 0)));
        if (!c.isCurrent(s)) return;
        const l = await qe(
          i,
          {
            ...Ke,
            pageSize: t,
            margin: N,
            fit: T,
            originalDpi: R,
            pair: D && r.length > 1 ? U : null,
          },
          {
            isCurrent: () => c.isCurrent(s),
            progress: (o, p) => c.isCurrent(s) && ae((o / p) * 100),
          },
        );
        if (!c.isCurrent(s)) return;
        const u = new Blob([l.bytes], { type: "application/pdf" }),
          n = r
            .filter((o) => !l.skipped.some((p) => p.name === o.name))
            .map((o) => o.name);
        (G({ blob: u, r: l, name: Qe(n.length ? n : r.map((o) => o.name)) }),
          de.success(`Converted ${W(l.images, "image")} to PDF`),
          Ae("image-to-pdf", "pdf-tools"),
          (async () => {
            try {
              const o = await et(
                  new File([u], "x.pdf", { type: "application/pdf" }),
                ),
                p = [];
              for (let S = 1; S <= Math.min(o.numPages, 40); S++) {
                const me = await o.getPage(S),
                  ce = me.getViewport({ scale: 1 }),
                  Re = await tt(me, 120 / Math.max(ce.width, ce.height), 0.7);
                if (!c.isCurrent(s)) return;
                p.push(URL.createObjectURL(Re));
              }
              c.isCurrent(s) && A(p);
            } catch {}
          })());
      } catch (i) {
        if (i instanceof Ye || !c.isCurrent(s)) return;
        (console.error("Image to PDF conversion failed:", i),
          E(
            i instanceof he
              ? i.message
              : "The conversion failed. Try fewer or smaller images.",
          ));
      } finally {
        c.isCurrent(s) && C(!1);
      }
    };
  a.useEffect(() => () => M.forEach((t) => URL.revokeObjectURL(t)), [M]);
  const Te = () => {
      (c.cancel(),
        x([]),
        B([]),
        b([]),
        ne(!1),
        G(null),
        A([]),
        ie([]),
        E(""),
        C(!1));
    },
    f = (t) => (s) => {
      (t(s), g());
    },
    le = f(je);
  return e.jsxs(Ee, {
    children: [
      e.jsx(nt, {
        toolId: "image-to-pdf",
        state: {
          hasFile: r.length > 0,
          ordered: Pe || j.some((t) => t !== 0),
          setupChosen:
            d !== ve ||
            P !== "portrait" ||
            N !== "normal" ||
            T !== "fit" ||
            R !== "auto" ||
            D,
          processing: y,
          resultReady: !!m && !y,
          downloaded: Ne,
        },
      }),
      e.jsx(ze, {
        gateAtDownload: !0,
        accept: dt,
        acceptLabel: "JPG, PNG, WebP, GIF, BMP, SVG, AVIF or HEIC image",
        multiple: !0,
        onFiles: ye,
        label: "Drop images here or take photos",
        description:
          "JPG, PNG, WebP, GIF, BMP, SVG or HEIC images (or camera photos), combined into one PDF",
      }),
      Z &&
        e.jsxs("p", {
          className: "mt-3 text-sm text-muted-foreground",
          role: "status",
          children: ["Preparing ", K > 1 ? `${K} images` : "images", "…"],
        }),
      oe.length > 0 &&
        e.jsxs(V, {
          role: "status",
          className: "mt-4 text-sm space-y-1",
          children: [
            e.jsxs("div", {
              className: "flex gap-2 font-medium",
              children: [
                e.jsx(ct, {
                  className: "h-4 w-4 mt-0.5 shrink-0 text-primary",
                }),
                "Good to know",
              ],
            }),
            oe.map((t, s) => e.jsx("p", { children: t }, s)),
          ],
        }),
      _.length > 0 &&
        e.jsxs(V, {
          role: "alert",
          className: "mt-4 text-sm space-y-1",
          children: [
            e.jsxs("div", {
              className: "flex gap-2 font-medium",
              children: [
                e.jsx(Ge, {
                  className: "h-4 w-4 mt-0.5 shrink-0 text-primary",
                }),
                "Some files were not added",
              ],
            }),
            _.map((t, s) => e.jsx("p", { children: t }, s)),
            _.some((t) => /\.pdf/i.test(t)) &&
              e.jsxs("p", {
                className: "text-muted-foreground",
                children: [
                  "Try ",
                  e.jsx(pe, {
                    href: "/tool/pdf-to-jpg",
                    className: "underline",
                    children: "PDF to JPG",
                  }),
                  " or ",
                  e.jsx(pe, {
                    href: "/tool/merge-pdf",
                    className: "underline",
                    children: "Merge PDF",
                  }),
                  ".",
                ],
              }),
          ],
        }),
      r.length > 0 &&
        e.jsxs("div", {
          className: "mt-6 space-y-4",
          children: [
            e.jsxs("fieldset", {
              className: "space-y-3",
              disabled: y,
              children: [
                e.jsx("legend", {
                  className: "text-sm font-medium mb-1",
                  children: "Page setup",
                }),
                e.jsxs("div", {
                  className: "flex flex-wrap items-center gap-2",
                  children: [
                    e.jsx(H, {
                      className: "text-sm text-muted-foreground w-24 shrink-0",
                      children: "Page size",
                    }),
                    e.jsx("div", {
                      className: "w-56",
                      children: e.jsxs(st, {
                        value: d,
                        onValueChange: (t) => {
                          (fe(t), g());
                        },
                        children: [
                          e.jsx(at, {
                            "aria-label": "Page size",
                            children: e.jsx(rt, {}),
                          }),
                          e.jsxs(it, {
                            children: [
                              e.jsx(z, { value: "a4", children: "A4" }),
                              e.jsx(z, {
                                value: "letter",
                                children: "US Letter",
                              }),
                              e.jsx(z, {
                                value: "original",
                                children: "Original image size",
                              }),
                              e.jsx(z, {
                                value: "custom",
                                children: "Custom size…",
                              }),
                            ],
                          }),
                        ],
                      }),
                    }),
                  ],
                }),
                d === "custom" &&
                  e.jsxs("div", {
                    className: "space-y-1",
                    children: [
                      e.jsxs("div", {
                        className:
                          "flex flex-wrap items-end gap-3 pl-0 sm:pl-[6.5rem]",
                        children: [
                          e.jsxs("div", {
                            children: [
                              e.jsx(H, {
                                htmlFor: "img-w",
                                className:
                                  "mb-1 block text-xs text-muted-foreground",
                                children: "Width",
                              }),
                              e.jsx(ue, {
                                id: "img-w",
                                inputMode: "decimal",
                                value: O,
                                onChange: (t) => {
                                  (Y(t.target.value), g());
                                },
                                className: "w-24",
                                "aria-invalid": !!F,
                              }),
                            ],
                          }),
                          e.jsx("span", {
                            className: "text-muted-foreground pb-2",
                            children: "×",
                          }),
                          e.jsxs("div", {
                            children: [
                              e.jsx(H, {
                                htmlFor: "img-h",
                                className:
                                  "mb-1 block text-xs text-muted-foreground",
                                children: "Height",
                              }),
                              e.jsx(ue, {
                                id: "img-h",
                                inputMode: "decimal",
                                value: $,
                                onChange: (t) => {
                                  (ee(t.target.value), g());
                                },
                                className: "w-24",
                                "aria-invalid": !!F,
                              }),
                            ],
                          }),
                          e.jsx("div", {
                            role: "group",
                            "aria-label": "Unit",
                            className: "flex gap-1 pb-0.5",
                            children: ["in", "mm", "cm"].map((t) =>
                              e.jsx(
                                I,
                                {
                                  type: "button",
                                  size: "sm",
                                  variant: v === t ? "default" : "outline",
                                  "aria-pressed": v === t,
                                  onClick: () => {
                                    if (t !== v) {
                                      const s = { in: 1, mm: 25.4, cm: 2.54 },
                                        i = (l) => {
                                          const u = Number(l.replace(",", "."));
                                          return Number.isFinite(u) && l.trim()
                                            ? String(
                                                Math.round(
                                                  (u / s[v]) * s[t] * 100,
                                                ) / 100,
                                              )
                                            : l;
                                        };
                                      (Y(i(O)), ee(i($)), xe(t), g());
                                    }
                                  },
                                  children: t,
                                },
                                t,
                              ),
                            ),
                          }),
                        ],
                      }),
                      F &&
                        e.jsx("p", {
                          role: "alert",
                          className:
                            "text-sm text-destructive pl-0 sm:pl-[6.5rem]",
                          children: F,
                        }),
                    ],
                  }),
                d !== "original" &&
                  e.jsxs(e.Fragment, {
                    children: [
                      e.jsxs(k, {
                        label: "Orientation",
                        children: [
                          e.jsx(h, {
                            value: "portrait",
                            current: P,
                            onPick: f(Q),
                            children: "Portrait",
                          }),
                          e.jsx(h, {
                            value: "landscape",
                            current: P,
                            onPick: f(Q),
                            children: "Landscape",
                          }),
                        ],
                      }),
                      e.jsxs(k, {
                        label: "Margin",
                        children: [
                          e.jsx(h, {
                            value: "none",
                            current: N,
                            onPick: f(L),
                            children: "None",
                          }),
                          e.jsx(h, {
                            value: "small",
                            current: N,
                            onPick: f(L),
                            children: "Small",
                          }),
                          e.jsx(h, {
                            value: "normal",
                            current: N,
                            onPick: f(L),
                            children: "Normal",
                          }),
                        ],
                      }),
                      e.jsxs(k, {
                        label: "Image on page",
                        children: [
                          e.jsx(h, {
                            value: "fit",
                            current: T,
                            onPick: f(te),
                            children: "Fit whole image",
                          }),
                          e.jsx(h, {
                            value: "fill",
                            current: T,
                            onPick: f(te),
                            children: "Fill the page (crops edges)",
                          }),
                        ],
                      }),
                    ],
                  }),
                d === "original" &&
                  e.jsxs(k, {
                    label: "Resolution",
                    children: [
                      e.jsx(h, {
                        value: "auto",
                        current: R,
                        onPick: le,
                        children: "Image's own",
                      }),
                      [72, 96, 150, 300].map((t) =>
                        e.jsxs(
                          h,
                          {
                            value: t,
                            current: R,
                            onPick: le,
                            children: [t, " dpi"],
                          },
                          t,
                        ),
                      ),
                    ],
                  }),
                r.length > 1 &&
                  d !== "original" &&
                  e.jsxs("label", {
                    className:
                      "flex items-start gap-2 border rounded-lg p-3 max-w-md cursor-pointer hover:bg-muted/40",
                    children: [
                      e.jsx(ot, {
                        checked: D,
                        onCheckedChange: (t) => {
                          (be(t === !0), g());
                        },
                        className: "mt-1",
                        "aria-label": "Pair images two per page",
                      }),
                      e.jsxs("div", {
                        children: [
                          e.jsx("div", {
                            className: "text-sm font-medium",
                            children: "Pair images two per page",
                          }),
                          e.jsx("div", {
                            className: "text-xs text-muted-foreground mt-0.5",
                            children:
                              "Images are paired in order (1st and 2nd share a page, and so on). An odd one out at the end gets its own page.",
                          }),
                        ],
                      }),
                    ],
                  }),
                D &&
                  r.length > 1 &&
                  d !== "original" &&
                  e.jsxs(k, {
                    label: "Arrangement",
                    children: [
                      e.jsx(h, {
                        value: "vertical",
                        current: U,
                        onPick: f(se),
                        children: "Side by side",
                      }),
                      e.jsx(h, {
                        value: "horizontal",
                        current: U,
                        onPick: f(se),
                        children: "Stacked",
                      }),
                    ],
                  }),
              ],
            }),
            e.jsxs("div", {
              children: [
                e.jsxs("p", {
                  className: "text-sm font-medium text-muted-foreground mb-2",
                  children: [
                    W(r.length, "image"),
                    ": drag to reorder, use the rotate button on any that are sideways",
                  ],
                }),
                e.jsx(_e, {
                  files: r,
                  onReorder: Fe,
                  onRemove: Ce,
                  thumbnailUrls: J,
                  thumbnailFit: "large",
                  thumbnailRotations: j,
                  rowActions: (t) =>
                    e.jsx(I, {
                      type: "button",
                      variant: "ghost",
                      size: "icon",
                      className: "h-11 w-11 sm:h-7 sm:w-7",
                      onClick: () => Se(t),
                      title: `Rotate 90° (currently ${j[t] ?? 0}°)`,
                      "aria-label": `Rotate ${r[t]?.name ?? "image"} 90 degrees (currently ${j[t] ?? 0}°)`,
                      children: e.jsx(Me, { className: "h-3.5 w-3.5" }),
                    }),
                }),
              ],
            }),
            re &&
              e.jsx("p", {
                role: "alert",
                className: "text-sm text-destructive",
                children: re,
              }),
            !m && !y && e.jsx(Ve, { toolId: "image-to-pdf" }),
            e.jsxs("div", {
              className: "flex flex-wrap gap-3 pt-4 border-t",
              children: [
                y
                  ? e.jsx(Oe, {
                      progress: we,
                      onStop: () => {
                        (c.cancel(), C(!1));
                      },
                    })
                  : m
                    ? e.jsx($e, { blob: m.blob, fileName: m.name })
                    : e.jsx(I, {
                        onClick: Ie,
                        disabled: Z || (d === "custom" && !!F),
                        children: "Convert to PDF",
                      }),
                e.jsx(I, {
                  variant: "outline",
                  onClick: Te,
                  children: "Clear all",
                }),
              ],
            }),
            m &&
              e.jsxs("div", {
                className: "space-y-3",
                children: [
                  e.jsxs("p", {
                    className: "text-sm text-muted-foreground",
                    role: "status",
                    children: [
                      W(m.r.pages, "page"),
                      " · ",
                      Be(m.blob.size),
                      " · ",
                      m.name,
                    ],
                  }),
                  m.r.skipped.length > 0 &&
                    e.jsxs(V, {
                      role: "alert",
                      className: "text-sm",
                      children: [
                        m.r.images,
                        " of ",
                        r.length,
                        " converted. Could not read: ",
                        m.r.skipped
                          .map((t) => `${t.name} (${t.reason})`)
                          .join(", "),
                        ".",
                      ],
                    }),
                  M.length > 0 &&
                    e.jsx("div", {
                      className: "flex gap-2 overflow-x-auto pb-2",
                      "aria-label": "Pages of the PDF",
                      children: M.map((t, s) =>
                        e.jsxs(
                          "figure",
                          {
                            className: "shrink-0",
                            children: [
                              e.jsx("img", {
                                src: t,
                                alt: `Page ${s + 1}`,
                                className: "max-h-40 rounded border bg-white",
                              }),
                              e.jsxs("figcaption", {
                                className:
                                  "text-xs text-muted-foreground text-center",
                                children: ["Page ", s + 1],
                              }),
                            ],
                          },
                          s,
                        ),
                      ),
                    }),
                  e.jsx(Le, { blob: m.blob, mimeType: "application/pdf" }),
                ],
              }),
          ],
        }),
      e.jsx(Ue, { whatIsIt: X.what, howToUse: X.how, tip: X.tip }),
    ],
  });
}
export { Ns as default };
//# sourceMappingURL=ImageToPdf-DEeXBJ-z.js.map
