import {
  k as D,
  p as $,
  r as N,
  o as O,
  q as R,
  s as T,
} from "./index-BRvxULIc.js";
import { s as U } from "./pdfMetadata-CcxIhQF2.js";
import "./index-CnXdQaNG.js";
import "./vendor-react-D01g8YgM.js";
import "./index-DMQTJy3b.js";
class P extends Error {
  constructor(t) {
    (super(t), (this.name = "ImageReadError"));
  }
}
function j(e) {
  if (e.length < 4 || e[0] !== 255 || e[1] !== 216) return 1;
  let t = 2;
  for (; t + 4 < e.length;) {
    if (e[t] !== 255) return 1;
    const n = e[t + 1];
    if (n === 217 || n === 218) return 1;
    const i = (e[t + 2] << 8) | e[t + 3];
    if (
      n === 225 &&
      e[t + 4] === 69 &&
      e[t + 5] === 120 &&
      e[t + 6] === 105 &&
      e[t + 7] === 102
    ) {
      const r = t + 10,
        a = e[r] === 73,
        o = (s) => (a ? e[s] | (e[s + 1] << 8) : (e[s] << 8) | e[s + 1]),
        c =
          r +
          ((s) =>
            a
              ? (e[s] |
                  (e[s + 1] << 8) |
                  (e[s + 2] << 16) |
                  (e[s + 3] << 24)) >>>
                0
              : ((e[s] << 24) |
                  (e[s + 1] << 16) |
                  (e[s + 2] << 8) |
                  e[s + 3]) >>>
                0)(r + 4);
      if (c + 2 > e.length) return 1;
      const p = o(c);
      for (let s = 0; s < p; s++) {
        const m = c + 2 + s * 12;
        if (m + 12 > e.length) return 1;
        if (o(m) === 274) {
          const h = o(m + 8);
          return h >= 1 && h <= 8 ? h : 1;
        }
      }
      return 1;
    }
    t += 2 + i;
  }
  return 1;
}
function k(e) {
  if (e[0] === 137 && e[1] === 80) {
    let t = 8;
    for (; t + 12 <= e.length;) {
      const n =
          ((e[t] << 24) | (e[t + 1] << 16) | (e[t + 2] << 8) | e[t + 3]) >>> 0,
        i = String.fromCharCode(e[t + 4], e[t + 5], e[t + 6], e[t + 7]);
      if (i === "pHYs" && e[t + 16] === 1) {
        const r =
          ((e[t + 8] << 24) |
            (e[t + 9] << 16) |
            (e[t + 10] << 8) |
            e[t + 11]) >>>
          0;
        return r > 0 ? Math.round(r * 0.0254) : null;
      }
      if (i === "IDAT" || i === "IEND") return null;
      t += 12 + n;
    }
    return null;
  }
  if (
    e[0] === 255 &&
    e[1] === 216 &&
    e[2] === 255 &&
    e[3] === 224 &&
    e[6] === 74 &&
    e[7] === 70
  ) {
    const t = e[13],
      n = (e[14] << 8) | e[15];
    if (n > 0 && t === 1) return n;
    if (n > 0 && t === 2) return Math.round(n * 2.54);
  }
  return null;
}
const z = (e) => e[0] === 137 && e[1] === 80 && e[2] === 78 && e[3] === 71,
  G = (e) => e[0] === 255 && e[1] === 216;
function F(e) {
  return new Promise((t, n) => {
    const i = URL.createObjectURL(e),
      r = new Image();
    ((r.onload = () => {
      (URL.revokeObjectURL(i), t(r));
    }),
      (r.onerror = () => {
        (URL.revokeObjectURL(i), n(new P("could not be read")));
      }),
      (r.src = i));
  });
}
const C = (e, t, n) =>
  new Promise((i, r) =>
    e.toBlob((a) => (a ? i(a) : r(new P("could not be converted"))), t, n),
  );
async function M(e) {
  const t = e.name.toLowerCase();
  if (/image\/tiff/.test(e.type) || /\.tiff?$/.test(t))
    throw new P("TIFF is not supported yet. Convert it to JPG or PNG first");
  const n = new Uint8Array(await e.slice(0, 65536).arrayBuffer());
  if (z(n))
    return e.type === "image/png"
      ? e
      : new File([e], e.name, { type: "image/png" });
  if (G(n)) {
    const p = j(n),
      s =
        e.type === "image/jpeg"
          ? e
          : new File([e], e.name, { type: "image/jpeg" });
    if (p === 1) return s;
    const m = document.createElement("canvas");
    try {
      const h = await createImageBitmap(e, { imageOrientation: "from-image" });
      ((m.width = h.width),
        (m.height = h.height),
        m.getContext("2d").drawImage(h, 0, 0),
        h.close?.());
    } catch {
      const h = await F(e);
      ((m.width = h.naturalWidth),
        (m.height = h.naturalHeight),
        m.getContext("2d").drawImage(h, 0, 0));
    }
    return new File([await C(m, "image/jpeg", 0.95)], e.name, {
      type: "image/jpeg",
    });
  }
  const i = e.type === "image/svg+xml" || /\.svg$/.test(t),
    r = await F(e);
  let a = r.naturalWidth,
    o = r.naturalHeight;
  if (
    (i &&
      (!a || !o
        ? ((a = 1200), (o = 900))
        : a < 1600 && ((o = Math.round((o * 1600) / a)), (a = 1600))),
    !a || !o)
  )
    throw new P("could not be read");
  const l = document.createElement("canvas");
  return (
    (l.width = a),
    (l.height = o),
    l.getContext("2d").drawImage(r, 0, 0, a, o),
    new File(
      [await C(l, "image/png")],
      e.name.replace(/\.[^.]+$/, "") + ".png",
      { type: "image/png" },
    )
  );
}
const A = { none: 0, small: 18, normal: 36 },
  L = { a4: { w: 595.28, h: 841.89 }, letter: { w: 612, h: 792 } },
  K = {
    pageSize: "a4",
    margin: "normal",
    fit: "fit",
    originalDpi: "auto",
    pair: null,
  };
class B extends Error {
  constructor() {
    super("cancelled");
  }
}
function _(e, t, n, i) {
  const r =
      i === "fill" ? Math.max(e.w / t, e.h / n) : Math.min(e.w / t, e.h / n, 1),
    a = t * r,
    o = n * r;
  return { x: e.x + (e.w - a) / 2, y: e.y + (e.h - o) / 2, w: a, h: o };
}
function x(e, t, n, i) {
  const r = _(n, t.width, t.height, i);
  (i === "fill" && e.pushOperators($(), N(n.x, n.y, n.w, n.h), O(), R()),
    e.drawImage(t, { x: r.x, y: r.y, width: r.w, height: r.h }),
    i === "fill" && e.pushOperators(T()));
}
async function Q(e, t, n = {}) {
  const i = () => {
      if (n.isCurrent && !n.isCurrent()) throw new B();
    },
    r = n.normalize ?? M,
    a = await D.create(),
    o = [],
    l = [];
  for (let g = 0; g < e.length; g++) {
    i();
    const u = e[g];
    try {
      const d = await r(u),
        I = new Uint8Array(await d.arrayBuffer()),
        f = z(I) ? await a.embedPng(I) : await a.embedJpg(I);
      l.push({ name: u.name, img: f, dpi: k(I) });
    } catch (d) {
      o.push({
        name: u.name,
        reason: d instanceof P ? d.message : "could not be read",
      });
    }
    n.progress?.(g + 1, e.length);
  }
  if (l.length === 0) throw new P("None of the images could be read.");
  const c = A[t.margin],
    p = t.pair ? Math.min(6, c) : 0,
    s = (g) => {
      if (t.pageSize === "original") {
        const u =
          t.originalDpi === "auto"
            ? g?.dpi && g.dpi >= 50 && g.dpi <= 1200
              ? g.dpi
              : 96
            : t.originalDpi;
        return { w: (g.img.width * 72) / u, h: (g.img.height * 72) / u };
      }
      return typeof t.pageSize == "object"
        ? { w: t.pageSize.widthPt, h: t.pageSize.heightPt }
        : L[t.pageSize];
    },
    m = t.pair && t.pageSize !== "original" ? 2 : 1;
  for (let g = 0; g < l.length; g += m) {
    i();
    const u = l.slice(g, g + m);
    if (t.pageSize === "original" || u.length === 1) {
      const S = u[0],
        w = s(S),
        y = a.addPage([w.w, w.h]);
      t.pageSize === "original"
        ? y.drawImage(S.img, { x: 0, y: 0, width: w.w, height: w.h })
        : x(y, S.img, { x: c, y: c, w: w.w - c * 2, h: w.h - c * 2 }, t.fit);
      continue;
    }
    const d = s(),
      I = a.addPage([d.w, d.h]),
      f = d.w - c * 2,
      v = d.h - c * 2,
      E =
        t.pair === "vertical"
          ? [
              { x: c, y: c, w: f / 2, h: v },
              { x: c + f / 2, y: c, w: f / 2, h: v },
            ]
          : [
              { x: c, y: c + v / 2, w: f, h: v / 2 },
              { x: c, y: c, w: f, h: v / 2 },
            ];
    u.forEach((S, w) => {
      const y = E[w];
      x(
        I,
        S.img,
        { x: y.x + p, y: y.y + p, w: y.w - p * 2, h: y.h - p * 2 },
        t.fit,
      );
    });
  }
  const h = e[0].name.replace(/\.[^.]+$/, "");
  return (
    U(a, { title: t.title ?? h, fallbackTitle: h }),
    {
      bytes: await a.save(),
      pages: a.getPageCount(),
      images: l.length,
      skipped: o,
    }
  );
}
function V(e) {
  if (e.length === 0) return "images.pdf";
  const t = (n) => n.replace(/\.[^.]+$/, "") || "images";
  return e.length === 1
    ? `${t(e[0])}.pdf`
    : `${t(e[0])}-and-${e.length - 1}-more.pdf`;
}
function X(e, t, n) {
  const i = Number(e.replace(",", ".")),
    r = Number(t.replace(",", "."));
  if (!e.trim() || !t.trim() || !Number.isFinite(i) || !Number.isFinite(r))
    return { ok: !1, message: "Enter the page width and height as numbers." };
  const a = n === "in" ? 72 : n === "mm" ? 72 / 25.4 : 72 / 2.54,
    o = (l) => (l * a) / 72;
  if (o(i) < 1 || o(r) < 1 || o(i) > 200 || o(r) > 200) {
    const [l, c] =
      n === "in"
        ? ["1", "200 in"]
        : n === "mm"
          ? ["25.4", "5080 mm"]
          : ["2.54", "508 cm"];
    return {
      ok: !1,
      message: `The page must be between ${l} ${n === "in" ? "in" : n} and ${c} on each side.`,
    };
  }
  return { ok: !0, widthPt: i * a, heightPt: r * a };
}
function Z(e) {
  const t = Array.from(e.slice(0, 6), (a) => String.fromCharCode(a)).join("");
  if (t !== "GIF87a" && t !== "GIF89a") return !1;
  let n = 13;
  const i = e[10];
  i & 128 && (n += 3 * (1 << ((i & 7) + 1)));
  let r = 0;
  for (; n < e.length;) {
    const a = e[n++];
    if (a === 59) break;
    if (a === 44) {
      if (++r > 1) return !0;
      const o = e[n + 8];
      for (
        n += 9, o & 128 && (n += 3 * (1 << ((o & 7) + 1))), n++;
        n < e.length && e[n] !== 0;
      )
        n += e[n] + 1;
      n++;
    } else if (a === 33) {
      for (n++; n < e.length && e[n] !== 0;) n += e[n] + 1;
      n++;
    } else break;
  }
  return !1;
}
export {
  K as DEFAULT_IMAGE_PDF_OPTIONS,
  B as ImagePdfCancelled,
  P as ImageReadError,
  A as MARGIN_PT,
  L as PRESET_PT,
  Q as buildImagePdf,
  Z as isAnimatedGif,
  M as normalizeImageFile,
  X as parseCustomPageSize,
  V as pdfNameForImages,
  _ as placeImage,
  k as readImageDpi,
  j as readJpegOrientation,
};
//# sourceMappingURL=imagePdf-Dtz8PQyf.js.map
