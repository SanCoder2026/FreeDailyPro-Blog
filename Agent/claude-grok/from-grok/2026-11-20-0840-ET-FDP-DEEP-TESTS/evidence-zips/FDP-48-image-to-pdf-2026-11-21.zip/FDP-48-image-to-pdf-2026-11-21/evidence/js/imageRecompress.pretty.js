import {
  P as b,
  b as k,
  f as I,
  a as E,
  e as Y,
  d as K,
  z as C,
  B as X,
  k as _,
  g as $,
} from "./index-BRvxULIc.js";
const J = new Set([
    "FlateDecode",
    "LZWDecode",
    "ASCII85Decode",
    "ASCIIHexDecode",
    "RunLengthDecode",
    "Fl",
    "LZW",
    "A85",
    "AHx",
    "RL",
  ]),
  Q = {
    Fl: "FlateDecode",
    LZW: "LZWDecode",
    A85: "ASCII85Decode",
    AHx: "ASCIIHexDecode",
    RL: "RunLengthDecode",
    DCT: "DCTDecode",
    CCF: "CCITTFaxDecode",
  };
function F(e) {
  const n = e.lookup(b.of("Filter")),
    i = e.lookup(b.of("DecodeParms")) ?? e.lookup(b.of("DP")),
    t = [],
    o = [],
    c = (s) => Q[s] ?? s;
  if (n instanceof b)
    (t.push(c(n.decodeText())),
      o.push(
        i instanceof k ? i : i instanceof I ? i.lookupMaybe(0, k) : void 0,
      ));
  else if (n instanceof I)
    for (let s = 0; s < n.size(); s++) {
      const r = n.lookup(s);
      (t.push(r instanceof b ? c(r.decodeText()) : "?"),
        o.push(
          i instanceof I
            ? i.lookupMaybe(s, k)
            : s === 0 && i instanceof k
              ? i
              : void 0,
        ));
    }
  return { names: t, parms: o };
}
function V(e) {
  if (!e.names.length) return "raw";
  const n = e.names[e.names.length - 1];
  return (n === "DCTDecode" ? e.names.slice(0, -1) : e.names).every((t) =>
    J.has(t),
  )
    ? n === "DCTDecode"
      ? "jpeg"
      : "raw"
    : null;
}
const T = (e, n, i) => {
  const t = e?.lookup(b.of(n));
  return t instanceof E ? t.asNumber() : i;
};
function tt(e, n, i) {
  const t = e + n - i,
    o = Math.abs(t - e),
    c = Math.abs(t - n),
    s = Math.abs(t - i);
  return o <= c && o <= s ? e : c <= s ? n : i;
}
function et(e, n) {
  const i = T(n, "Predictor", 1);
  if (i <= 1) return e;
  const t = T(n, "Colors", 1),
    o = T(n, "BitsPerComponent", 8),
    c = T(n, "Columns", 1),
    s = Math.max(1, Math.ceil((t * o) / 8)),
    r = Math.ceil((t * o * c) / 8);
  if (i === 2) {
    if (o !== 8) return e;
    const u = e.slice();
    for (let f = 0; f * r < u.length; f++) {
      const d = f * r;
      for (let p = s; p < r && d + p < u.length; p++)
        u[d + p] = (u[d + p] + u[d + p - s]) & 255;
    }
    return u;
  }
  const a = Math.floor(e.length / (r + 1)),
    l = new Uint8Array(a * r);
  for (let u = 0; u < a; u++) {
    const f = e[u * (r + 1)],
      d = u * (r + 1) + 1,
      p = u * r,
      g = p - r;
    for (let m = 0; m < r; m++) {
      const h = e[d + m],
        y = m >= s ? l[p + m - s] : 0,
        S = u > 0 ? l[g + m] : 0,
        x = u > 0 && m >= s ? l[g + m - s] : 0;
      l[p + m] =
        f === 0
          ? h
          : f === 1
            ? h + y
            : f === 2
              ? h + S
              : f === 3
                ? h + ((y + S) >> 1)
                : h + tt(y, S, x);
    }
  }
  return l;
}
const nt = (e, n, i, t) => {
  const o = e.dict.context.obj({ Filter: n });
  return X(C.of(o, t)).decode();
};
function j(e, n = F(e.dict)) {
  let i = e.getContents();
  for (let t = 0; t < n.names.length; t++) {
    const o = n.names[t];
    if (o === "DCTDecode") break;
    ((i = nt(e, o, void 0, i)),
      (o === "FlateDecode" || o === "LZWDecode") && (i = et(i, n.parms[t])));
  }
  return i;
}
function ot(e, n) {
  if (!(e instanceof I) || e.size() !== 4) return null;
  const i = e.lookup(0);
  if (!(i instanceof b) || !["Indexed", "I"].includes(i.decodeText()))
    return null;
  const t = n(e.lookup(1)),
    o = e.lookup(2);
  if (!t || !(o instanceof E)) return null;
  const c = e.lookup(3);
  let s = null;
  if (c instanceof Y || c instanceof K) s = c.asBytes();
  else if (c instanceof C)
    try {
      s = j(c);
    } catch {
      s = null;
    }
  const r = o.asNumber() + 1;
  if (!s || s.length < r * t) return null;
  const a = new Uint8Array(r * 3);
  for (let l = 0; l < r; l++)
    for (let u = 0; u < 3; u++) a[l * 3 + u] = t === 3 ? s[l * 3 + u] : s[l];
  return { palette: a, hival: r - 1 };
}
function st(e, n, i, t, o) {
  if (o === 8) return e;
  const c = Math.ceil((n * t * o) / 8),
    s = new Uint8Array(n * i * t),
    r = (1 << o) - 1;
  let a = 0;
  for (let l = 0; l < i; l++)
    for (let u = 0; u < n * t; u++) {
      const f = u * o,
        d = e[l * c + (f >> 3)] ?? 0;
      s[a++] = (d >> (8 - o - (f & 7))) & r;
    }
  return s;
}
function it(e) {
  const n = e
      .map((o, c) => c)
      .sort(
        (o, c) => e[c].bytes - e[o].bytes || e[o].distortion - e[c].distortion,
      ),
    i = [];
  for (const o of n) {
    const c = i[i.length - 1];
    if (c === void 0) {
      i.push(o);
      continue;
    }
    if (!(e[o].bytes >= e[c].bytes)) {
      if (e[o].distortion < e[c].distortion) {
        (i.pop(), i.push(o));
        continue;
      }
      i.push(o);
    }
  }
  const t = [];
  for (const o of i) {
    for (; t.length >= 2;) {
      const c = e[t[t.length - 2]],
        s = e[t[t.length - 1]],
        r = e[o],
        a = (s.distortion - c.distortion) / Math.max(1, c.bytes - s.bytes);
      if ((r.distortion - s.distortion) / Math.max(1, s.bytes - r.bytes) <= a)
        t.pop();
      else break;
    }
    t.push(o);
  }
  return t;
}
function ct(e, n, i = 0) {
  const t = e.map(it),
    o = t.map(() => 0);
  let c = i;
  t.forEach((r, a) => {
    c += e[a][r[0]].bytes;
  });
  const s = [];
  (t.forEach((r, a) => {
    for (let l = 1; l < r.length; l++) {
      const u = e[a][r[l - 1]],
        f = e[a][r[l]];
      s.push({
        item: a,
        slope: (f.distortion - u.distortion) / Math.max(1, u.bytes - f.bytes),
      });
    }
  }),
    s.sort((r, a) => r.slope - a.slope || r.item - a.item));
  for (const r of s) {
    if (c <= n) break;
    const a = t[r.item],
      l = e[r.item][a[o[r.item]]],
      u = e[r.item][a[o[r.item] + 1]];
    ((c -= l.bytes - u.bytes), o[r.item]++);
  }
  return { choice: t.map((r, a) => r[o[a]]), total: c, fits: c <= n };
}
function rt(e, n, i, t) {
  const o = 6.502500000000001,
    c = (0.03 * 255) ** 2,
    s = 8;
  let r = 0,
    a = 0;
  for (let l = 0; l + s <= t; l += s)
    for (let u = 0; u + s <= i; u += s) {
      let f = 0,
        d = 0;
      for (let h = 0; h < s; h++)
        for (let y = 0; y < s; y++) {
          const S = (l + h) * i + u + y;
          ((f += e[S]), (d += n[S]));
        }
      ((f /= s * s), (d /= s * s));
      let p = 0,
        g = 0,
        m = 0;
      for (let h = 0; h < s; h++)
        for (let y = 0; y < s; y++) {
          const S = (l + h) * i + u + y,
            x = e[S] - f,
            D = n[S] - d;
          ((p += x * x), (g += D * D), (m += x * D));
        }
      ((p /= s * s - 1),
        (g /= s * s - 1),
        (m /= s * s - 1),
        (r +=
          ((2 * f * d + o) * (2 * m + c)) /
          ((f * f + d * d + o) * (p + g + c))),
        a++);
    }
  return a ? Math.max(0, 1 - r / a) : 0;
}
function at(e) {
  const n = new Uint8Array(e.length / 4);
  for (let i = 0, t = 0; t < n.length; i += 4, t++)
    n[t] = (e[i] * 299 + e[i + 1] * 587 + e[i + 2] * 114) / 1e3;
  return n;
}
const lt = 640,
  M = [
    { maxSide: 3e3, quality: 0.9 },
    { maxSide: 2400, quality: 0.85 },
    { maxSide: 2e3, quality: 0.8 },
    { maxSide: 1600, quality: 0.75 },
    { maxSide: 1400, quality: 0.7 },
    { maxSide: 1200, quality: 0.65 },
    { maxSide: 1e3, quality: 0.6 },
    { maxSide: 800, quality: 0.55 },
    { maxSide: 650, quality: 0.5 },
    { maxSide: 500, quality: 0.4 },
    { maxSide: 400, quality: 0.3 },
    { maxSide: 300, quality: 0.25 },
  ],
  w = (() => {
    const e = [];
    for (let i = 0; i < M.length - 1; i++) {
      const t = M[i],
        o = M[i + 1];
      for (let c = 0; c < 4; c++) {
        const s = c / 4;
        e.push({
          maxSide: Math.round(t.maxSide * Math.pow(o.maxSide / t.maxSide, s)),
          quality:
            Math.round((t.quality + (o.quality - t.quality) * s) * 1e3) / 1e3,
        });
      }
    }
    return (e.push(M[M.length - 1]), e);
  })(),
  dt = { maxSide: 1600, quality: 0.75 },
  pt = { maxSide: 1540, quality: 0.75 },
  mt = { maxSide: 1100, quality: 0.6 },
  q = 20 * 1024,
  U = 0.95,
  P = (e, n) => {
    const i = e.lookup(b.of(n));
    return i instanceof E ? i.asNumber() : void 0;
  };
function v(e) {
  if (e instanceof b) {
    const n = e.decodeText();
    return n === "DeviceRGB" || n === "RGB" || n === "CalRGB"
      ? 3
      : n === "DeviceGray" || n === "G" || n === "CalGray"
        ? 1
        : null;
  }
  if (e instanceof I && e.size() >= 1) {
    const n = e.lookup(0);
    if (!(n instanceof b)) return null;
    const i = n.decodeText();
    if (i === "ICCBased" && e.size() === 2) {
      const t = e.lookup(1);
      if (t instanceof C) {
        const o = P(t.dict, "N");
        return o === 3 ? 3 : o === 1 ? 1 : null;
      }
      return null;
    }
    if (i === "CalRGB") return 3;
    if (i === "CalGray") return 1;
    if (i === "DeviceRGB" || i === "DeviceGray") return v(n);
  }
  return null;
}
function H(e) {
  const n = [];
  let i = 0,
    t = 0,
    o = 0;
  for (const [c, s] of e.context.enumerateIndirectObjects()) {
    if (
      !(s instanceof C) ||
      s.dict.lookup(b.of("Subtype"))?.toString() !== "/Image"
    )
      continue;
    const a = s.getContentsSize();
    i += a;
    const l = ut(e, c, s);
    l && a >= q ? n.push(l) : !l && a >= q && ((t += a), o++);
  }
  return { images: n, totalStoredBytes: i, skippedBytes: t, skippedCount: o };
}
function ut(e, n, i) {
  const t = i.dict,
    o = F(t),
    c = V(o);
  if (!c) return null;
  const s = t.lookup(b.of("ImageMask"));
  if (
    (s instanceof $ && s.asBoolean()) ||
    t.has(b.of("Decode")) ||
    t.has(b.of("Mask"))
  )
    return null;
  const r = P(t, "Width"),
    a = P(t, "Height");
  if (!r || !a) return null;
  const l = t.lookup(b.of("ColorSpace")),
    u = P(t, "BitsPerComponent") ?? 8;
  let f = v(l),
    d;
  if (!f) {
    const p = ot(l, v);
    p && c === "raw" && [1, 2, 4, 8].includes(u) && ((d = p.palette), (f = 3));
  }
  return !f ||
    (c === "jpeg" && u !== 8) ||
    (c === "raw" && ![1, 2, 4, 8].includes(u)) ||
    (c === "raw" && u !== 8 && !d && f !== 1)
    ? null
    : {
        ref: n,
        width: r,
        height: a,
        components: f,
        kind: c,
        storedBytes: i.getContentsSize(),
        bpc: u,
        palette: d,
      };
}
function z(e, n) {
  try {
    const i = F(e.dict),
      t = j(e, i);
    if (n.kind === "jpeg") return t;
    const o = n.palette ? 1 : n.components,
      c = st(t, n.width, n.height, o, n.bpc);
    if (c.length < n.width * n.height * o) return null;
    const s = n.width * n.height;
    if (n.palette) {
      const r = new Uint8Array(s * 3);
      for (let a = 0; a < s; a++) {
        const l = Math.min(c[a], n.palette.length / 3 - 1) * 3;
        ((r[a * 3] = n.palette[l]),
          (r[a * 3 + 1] = n.palette[l + 1]),
          (r[a * 3 + 2] = n.palette[l + 2]));
      }
      return r;
    }
    if (n.bpc !== 8) {
      const r = 255 / ((1 << n.bpc) - 1),
        a = new Uint8Array(s);
      for (let l = 0; l < s; l++) a[l] = Math.round(c[l] * r);
      return a;
    }
    return c.length === s * n.components ? c : c.subarray(0, s * n.components);
  } catch {
    return null;
  }
}
class O extends Error {
  constructor() {
    (super("Compression stopped"), (this.name = "CompressStopped"));
  }
}
async function W(e, n, i, t = {}) {
  const o = await _.load(e, { updateMetadata: !1 }),
    { images: c } = H(o);
  let s = 0;
  for (let a = 0; a < c.length; a++) {
    if (t.shouldStop?.()) throw new O();
    t.onProgress?.(a, c.length);
    const l = c[a],
      u = o.context.lookup(l.ref);
    if (!(u instanceof C)) continue;
    const f = z(u, l);
    if (!f) continue;
    const d = typeof n == "function" ? n(l, a) : n;
    if (!d) continue;
    let p = null;
    try {
      p = await i.reencode(l, f, d);
    } catch {
      p = null;
    }
    if (!p || p.bytes.length >= l.storedBytes * U) continue;
    const g = o.context.obj({
        Type: "XObject",
        Subtype: "Image",
        Width: p.width,
        Height: p.height,
        ColorSpace: "DeviceRGB",
        BitsPerComponent: 8,
        Filter: "DCTDecode",
      }),
      m = u.dict.get(b.of("SMask"));
    m && g.set(b.of("SMask"), m);
    const h = u.dict.get(b.of("Interpolate"));
    (h && g.set(b.of("Interpolate"), h),
      o.context.assign(l.ref, C.of(g, p.bytes)),
      s++);
  }
  return (
    t.onProgress?.(c.length, c.length),
    {
      bytes: await o.save({ useObjectStreams: !0 }),
      replaced: s,
      considered: c.length,
    }
  );
}
async function gt(e, n, i, t = {}) {
  const o = w.length,
    c = 1 + Math.ceil(Math.log2(o));
  let s = 0;
  const r = async (g) => (t.onPass?.(++s, c), W(e, w[g], i, t));
  let a = null;
  const l = await r(0);
  if (l.bytes.length <= n) return { ...l, fits: !0, setting: w[0] };
  let u = 1,
    f = o - 1,
    d = null;
  for (; u <= f;) {
    const g = (u + f) >> 1,
      m = await r(g);
    (g === o - 1 && (d = { ...m, setting: w[g] }),
      m.bytes.length <= n
        ? ((a = { ...m, setting: w[g] }), (f = g - 1))
        : (u = g + 1));
  }
  return a
    ? { ...a, fits: !0 }
    : { ...(d ?? { ...(await r(o - 1)), setting: w[o - 1] }), fits: !1 };
}
const ft = 4;
async function yt(e, n, i, t = {}, o = {}) {
  if (!i.profile) return null;
  const c = await _.load(e, { updateMetadata: !1 }),
    { images: s } = H(c);
  if (s.length === 0) return null;
  const r = [];
  for (let h = 0; h < w.length; h += ft) r.push(w[h]);
  const a = w[w.length - 1];
  r[r.length - 1] !== a && r.push(a);
  const l = r.filter((h) => h.maxSide >= (o.minMaxSide ?? 0));
  l.length === 0 && l.push(r[0]);
  const u = [],
    f = [];
  t.onPass?.(1, 2);
  for (let h = 0; h < s.length; h++) {
    if (t.shouldStop?.()) throw new O();
    t.onProgress?.(h, s.length);
    const y = s[h],
      S = [{ bytes: y.storedBytes, distortion: 0 }],
      x = [null],
      D = c.context.lookup(y.ref),
      R = D instanceof C ? z(D, y) : null;
    if (R) {
      let A = [];
      try {
        A = await i.profile(y, R, l);
      } catch {
        A = [];
      }
      A.forEach((B, Z) => {
        B &&
          B.bytes < y.storedBytes * U &&
          (S.push({ bytes: B.bytes, distortion: B.distortion }), x.push(l[Z]));
      });
    }
    (u.push(S), f.push(x));
  }
  t.onProgress?.(s.length, s.length);
  const d = s.reduce((h, y) => h + y.storedBytes, 0),
    p = e.length - d;
  t.onPass?.(2, 2);
  let g = n,
    m = null;
  for (let h = 0; h < 3; h++) {
    const y = ct(u, g, p),
      S = await W(e, (x, D) => f[D][y.choice[D]], i, t);
    if (((m = { ...S, fits: S.bytes.length <= n }), m.fits || !y.fits)) break;
    g -= Math.ceil((S.bytes.length - n) * 1.1) + 1024;
  }
  return m;
}
async function L(e, n) {
  let i;
  if (e.kind === "jpeg")
    i = await createImageBitmap(new Blob([n], { type: "image/jpeg" }), {
      imageOrientation: "none",
    });
  else {
    const t = new Uint8ClampedArray(e.width * e.height * 4);
    if (e.components === 3)
      for (let o = 0, c = 0; o < n.length; o += 3, c += 4)
        ((t[c] = n[o]),
          (t[c + 1] = n[o + 1]),
          (t[c + 2] = n[o + 2]),
          (t[c + 3] = 255));
    else
      for (let o = 0, c = 0; o < n.length; o++, c += 4)
        ((t[c] = t[c + 1] = t[c + 2] = n[o]), (t[c + 3] = 255));
    i = await createImageBitmap(new ImageData(t, e.width, e.height));
  }
  return i;
}
function G(e, n, i) {
  const t = document.createElement("canvas");
  ((t.width = n), (t.height = i));
  const o = t.getContext("2d");
  if (!o) throw new Error("Canvas not supported in this browser");
  ((o.fillStyle = "#fff"), o.fillRect(0, 0, n, i), o.drawImage(e, 0, 0, n, i));
  const c = at(o.getImageData(0, 0, n, i).data);
  return ((t.width = t.height = 0), c);
}
const bt = {
  async profile(e, n, i) {
    const t = await L(e, n),
      o = Math.min(1, lt / Math.max(t.width, t.height)),
      c = Math.max(8, Math.round(t.width * o)),
      s = Math.max(8, Math.round(t.height * o)),
      r = G(t, c, s),
      a = [];
    for (const l of i) {
      const u = await N(t, l);
      if (!u) {
        a.push(null);
        continue;
      }
      const f = await createImageBitmap(
          new Blob([u.bytes], { type: "image/jpeg" }),
        ),
        d = G(f, c, s);
      (f.close(),
        a.push({ bytes: u.bytes.length, distortion: rt(r, d, c, s) }));
    }
    return (t.close(), a);
  },
  async reencode(e, n, i) {
    const t = await L(e, n),
      o = await N(t, i);
    return (t.close(), o);
  },
};
async function N(e, n) {
  const i = Math.min(1, n.maxSide / Math.max(e.width, e.height)),
    t = Math.max(1, Math.round(e.width * i)),
    o = Math.max(1, Math.round(e.height * i)),
    c = document.createElement("canvas");
  ((c.width = t), (c.height = o));
  const s = c.getContext("2d");
  if (!s) return null;
  ((s.fillStyle = "#fff"), s.fillRect(0, 0, t, o), s.drawImage(e, 0, 0, t, o));
  const r = await new Promise((a) => c.toBlob(a, "image/jpeg", n.quality));
  return (
    (c.width = c.height = 0),
    r
      ? { bytes: new Uint8Array(await r.arrayBuffer()), width: t, height: o }
      : null
  );
}
export {
  dt as B,
  O as C,
  mt as S,
  H as a,
  bt as b,
  V as c,
  j as d,
  W as e,
  F as f,
  yt as g,
  gt as h,
  pt as i,
  ot as r,
  st as u,
};
//# sourceMappingURL=imageRecompress-eXQFDUm-.js.map
