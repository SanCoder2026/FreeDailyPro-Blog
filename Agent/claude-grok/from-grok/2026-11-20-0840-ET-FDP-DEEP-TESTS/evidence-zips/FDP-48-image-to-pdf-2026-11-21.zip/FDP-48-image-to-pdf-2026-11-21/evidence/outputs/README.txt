L12 (8 × 6000×4000 images, 16.7 MB, 4 pages) was downloaded at 10/10 but is left out to keep the zip under 20 MB; sha and size are in evidence/json/left.json. Re-make it with testfiles/P14_big.jpg.
