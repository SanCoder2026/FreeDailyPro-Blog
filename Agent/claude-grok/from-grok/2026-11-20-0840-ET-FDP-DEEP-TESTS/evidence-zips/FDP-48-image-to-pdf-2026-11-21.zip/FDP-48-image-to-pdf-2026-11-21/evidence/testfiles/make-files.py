# FDP-48 extra test files (the rest are copied from FDP-34 testfiles, see README).
from PIL import Image, ImageDraw, ImageFont, ImageCms
import io, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
F = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 60)
def page(txt, size=(1240, 1754), bg='white'):
    im = Image.new('RGB', size, bg); d = ImageDraw.Draw(im); d.rectangle([10, 10, size[0]-10, size[1]-10], outline='black', width=8); d.text((80, 80), txt, font=F, fill='black'); d.text((80, size[1]-160), 'BOTTOM ' + txt, font=F, fill='red'); return im
# CMYK JPEG with Adobe marker (Photoshop/print exports) - colours must not invert
im = page('CMYK RED BLOCK'); d = ImageDraw.Draw(im); d.rectangle([100, 300, 600, 800], fill=(220, 20, 20)); d.rectangle([640, 300, 1140, 800], fill=(20, 60, 220))
im.convert('CMYK').save('P16_cmyk.jpg', quality=90)
# 16-bit PNG (scanners)
Image.new('I;16', (800, 600), 30000).save('P17_16bit.png')
# grayscale + palette PNG
page('GRAYSCALE').convert('L').save('P18_gray.png'); page('PALETTE').convert('P').save('P19_palette.png')
# progressive JPEG
page('PROGRESSIVE').save('P20_progressive.jpg', progressive=True, quality=85)
# 300 dpi scan (A4 at 300 dpi = 2480x3508) for "Original image size" dpi handling
page('300 DPI SCAN', (2480, 3508)).save('P21_scan_300dpi.jpg', dpi=(300, 300), quality=80)
# very wide panorama (20000 x 800): Original size at 96 dpi -> 15000 pt > PDF 14400 pt limit
Image.new('RGB', (20000, 800), (90, 160, 220)).save('P22_panorama_20000.jpg', quality=70)
# landscape + portrait receipts for pairing / mixed sizes
for i in range(1, 8): page('RECEIPT %d' % i, (900, 1600) if i % 2 else (1600, 900)).save('R%02d_receipt.jpg' % i, quality=80)
# a PDF and a docx-like non image
open('P23_document.pdf', 'wb').write(b'%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n')
# EXIF orientation 6 JPEG made here as well, with a 300 dpi JFIF density (does the dpi survive the upright re-encode?)
im = page('ORIENT 6 PORTRAIT TOP', (1754, 1240)); ex = Image.Exif(); ex[0x0112] = 6; im.save('P24_orient6_300dpi.jpg', exif=ex, dpi=(300, 300), quality=85)
print('ok')
