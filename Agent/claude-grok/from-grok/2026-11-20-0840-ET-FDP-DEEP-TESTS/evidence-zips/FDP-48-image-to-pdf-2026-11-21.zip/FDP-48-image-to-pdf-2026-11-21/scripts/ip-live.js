// FDP-48 Image to PDF, guest. Usage: node ip-live.js <zero|left|subset> [engine]   (TRIES env = fresh contexts to try for "left")
// zero: context at 0 -> add images, Convert, page strip, Download/Drive/cloud dialogs, Day Pass (stops at email), Quick Buy (stops at Stripe), keyboard.
// left: context with uses left -> all cases in ONE page load with downloads (per-page-load check), then reload + download.
// Never types an email/card, never clicks a pass "Continue", never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const crypto = require('crypto');
const BASE = '/workspace/deep/48-image-to-pdf/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/image-to-pdf';
const mode = process.argv[2] || 'left'; const eng = process.argv[3] || 'chromium'; const sfx = eng === 'chromium' ? '' : '-' + eng;
fs.mkdirSync(OUT + 'downloads', { recursive: true }); fs.mkdirSync(OUT + 'cases', { recursive: true });
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex').slice(0, 16);
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').slice(0, 160);
const R_ = n => Array.from({ length: n }, (_, i) => 'R0' + (i + 1) + '_receipt.jpg');
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p; const net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true, locale: 'en-US' }); p = await c.newPage(); p.setDefaultTimeout(20000);
  await p.addInitScript(() => { window.__t = []; const seen = new WeakSet(); setInterval(() => { document.querySelectorAll('[data-sonner-toast]').forEach(n => { if (!seen.has(n)) { seen.add(n); window.__t.push((n.innerText || '').trim()); } }); }, 150); });
  p.on('request', r => { const d = r.postData() || ''; net.push({ m: r.method(), u: red(r.url()), len: d.length, big: d.length > 20000, hit: /RECEIPT|JFIF|%PDF/.test(d) }); });
  await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000); };
 const used = () => p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 const state = () => p.evaluate(() => { const m = document.querySelector('main'); const t = m.innerText;
  const grab = re => (t.match(re) || [''])[0];
  return { status: grab(/\d+ pages? · [^\n]+/), notAdded: [...m.querySelectorAll('[role=alert]')].map(e => e.innerText.replace(/\n+/g, ' | ')).slice(0, 4), goodToKnow: grab(/Good to know[\s\S]{0,300}/).replace(/\n+/g, ' | '), thumbs: m.querySelectorAll('[aria-label="Pages of the PDF"] img').length, items: m.querySelectorAll('button[aria-label^="Rotate "]').length,
   convert: (() => { const x = [...m.querySelectorAll('button')].find(e => e.innerText.trim() === 'Convert to PDF'); return x ? (x.disabled ? 'disabled' : 'enabled') : 'absent'; })(), download: [...m.querySelectorAll('button')].some(e => /^Download/.test(e.innerText.trim())) }; });
 const pick = async (label, opt) => { await p.getByRole('combobox', { name: label }).click(); await p.getByRole('option', { name: opt, exact: true }).click(); await p.waitForTimeout(300); };
 const tog = async name => { await p.locator('main button', { hasText: new RegExp('^' + name.replace(/[()]/g, '\\$&') + '$') }).first().click(); await p.waitForTimeout(200); };
 const run = async (id, o = {}) => { const r = { id, o, t: now(), before: await used() }; const tN = await p.evaluate(() => (window.__t || []).length);
  try { if (o.clear) { const cl = p.locator('main button', { hasText: /^Clear all$/ }); if (await cl.count()) await cl.first().click(); await p.waitForTimeout(500); }
   if (o.files) { await p.locator('main input[type=file]').first().setInputFiles(o.files.map(f => TF + f)); await p.waitForTimeout(o.prepWait || 4000); }
   if (o.size) await pick('Page size', o.size);
   if (o.custom) { await p.locator('#img-w').fill(o.custom[0]); await p.locator('#img-h').fill(o.custom[1]); if (o.custom[2]) await p.getByRole('combobox', { name: 'Unit' }).click().then(() => p.getByRole('option', { name: o.custom[2] }).click()).catch(e => r.unitErr = e.message.slice(0, 80)); await p.waitForTimeout(400); r.customMsg = await p.evaluate(() => [...document.querySelectorAll('main p')].map(e => e.innerText).filter(t => /The page must be|Enter the page width/.test(t))[0] || null); }
   for (const t of (o.toggles || [])) await tog(t);
   if (o.pair) { await p.getByRole('checkbox', { name: 'Pair images two per page' }).click(); await p.waitForTimeout(300); if (o.pair !== true) await tog(o.pair); }
   if (o.rotate !== undefined) { await p.locator('main button[aria-label^="Rotate "]').nth(o.rotate).click(); await p.waitForTimeout(300); }
   r.pre = await state();
   if (o.convert !== false && r.pre.convert === 'enabled') { const t0 = Date.now(); await p.locator('main button', { hasText: /^Convert to PDF$/ }).first().click(); await p.waitForFunction(() => /\d+ pages? · /.test(document.querySelector('main').innerText) || [...document.querySelectorAll('main [role=alert]')].length > 0, null, { timeout: o.wait || 120000 }).catch(() => {}); r.convertMs = Date.now() - t0; await p.waitForTimeout(2500); r.after = await state(); }
   if (o.dl && r.after && r.after.download) { const btn = p.locator('main button', { hasText: /^Download/ }).first(); const dp = p.waitForEvent('download', { timeout: 30000 }).catch(() => null); await btn.click(); const d = await dp; await p.waitForTimeout(1500);
     r.dialog = await dialog(); if (d) { const f = OUT + 'downloads/' + id + sfx + '-' + d.suggestedFilename(); await d.saveAs(f); r.download = { name: d.suggestedFilename(), bytes: fs.statSync(f).size, sha: sha(f) }; }
     if (r.dialog) { await p.screenshot({ path: OUT + 'cases/' + id + sfx + '-dialog.png' }); if (/Day Pass/.test(r.dialog) && !R.dayPass) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.dayPass = { dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'dlg-daypass' + sfx + '.png' }); } } await esc(); } }
   r.afterDl = await used();
  } catch (e) { r.err = e.message.slice(0, 300); }
  await p.waitForTimeout(400); r.toasts = await p.evaluate(n => (window.__t || []).slice(n), tN);
  await p.screenshot({ path: OUT + 'cases/' + id + sfx + '.png', fullPage: !!o.full }).catch(() => {}); R.cases[id] = r; console.log(id, JSON.stringify(r).slice(0, 700)); return r; };
 const act = async (name, loc) => { const r = { before: await used() }; if (!(await loc.count())) { r.missing = true; console.log(name, 'missing'); return r; }
  const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); const url0 = p.url(); await loc.first().click(); const pg = await pop; await p.waitForTimeout(2500);
  r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null; if (pg) { await pg.waitForLoadState('domcontentloaded').catch(() => {}); r.popup = red(pg.url()); await pg.close(); }
  if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + sfx + '.png' }); await esc(); console.log(name, JSON.stringify(r).slice(0, 400)); return r; };
 if (mode === 'left') { const NT = +(process.env.TRIES || 16); for (let i = 0; i < NT; i++) { await open(); const u = await used(); R.tries.push(u); if (u < 10) { await p.waitForTimeout(6000); if ((await used()) < 10) break; } if (i < NT - 1) await c.close(); }
  R.start = await used(); const dl = R.start < 10;
  await run('L01', { files: R_(3), dl });
  R.drive = await act('drive', p.getByRole('button', { name: /Save to Google Drive/ })); R.cloud = await act('cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
  await run('L02', { clear: true, files: ['P02_orient6_gps.jpg', 'P24_orient6_300dpi.jpg'], dl });
  await run('L02r', { rotate: 1, dl });
  await run('L03', { clear: true, files: ['P16_cmyk.jpg', 'P17_16bit.png', 'P18_gray.png', 'P19_palette.png', 'P20_progressive.jpg', 'P01_logo_transparent.png'], dl });
  await run('L04', { clear: true, files: ['P03.webp', 'P05.avif', 'P06_anim.gif', 'P07.bmp', 'P09.svg', 'P10_nosize_script.svg', 'P11_iphone.heic', 'P15_photo été #1.png'], prepWait: 8000, dl });
  await run('L05', { clear: true, files: ['P08.tiff', 'P12_notimage.png', 'P13_truncated.jpg', 'P23_document.pdf', 'R01_receipt.jpg'], dl });
  await run('L06', { clear: true, files: ['P21_scan_300dpi.jpg'], size: 'Original image size', dl });
  await run('L07', { clear: true, files: ['P24_orient6_300dpi.jpg'], size: 'Original image size', dl });
  await run('L08', { clear: true, files: ['P22_panorama_20000.jpg'], size: 'Original image size', dl });
  await run('L09', { clear: true, files: R_(7), size: 'A4', toggles: ['Landscape', 'None', 'Fill the page (crops edges)'], pair: true, dl });
  await run('L10a', { clear: true, files: ['R01_receipt.jpg'], size: 'Custom size…', custom: ['0', '5'], convert: false });
  await run('L10b', { custom: ['300', '5'], convert: false });
  await run('L10c', { custom: ['10,5', '14,8', 'cm'], dl });
  await run('L11', { clear: true, files: ['R01_receipt.jpg', 'R01_receipt.jpg'], convert: false });
  await run('L12', { clear: true, files: Array(8).fill('P14_big.jpg'), size: 'A4', prepWait: 8000, dl, wait: 180000 });
  await run('L13', { clear: true, files: Array(60).fill(0).map((_, i) => R_(7)[i % 7]), prepWait: 15000, dl, wait: 240000 });
  R.endUsed = await used(); await p.reload(); await p.waitForTimeout(5000); R.afterReload = await used(); await run('L14-after-reload', { files: R_(2), dl: true }); R.final = await used(); }
 if (mode === 'gps') { const NT = +(process.env.TRIES || 40); for (let i = 0; i < NT; i++) { await open(); const u = await used(); R.tries.push(u); if (u < 10) { await p.waitForTimeout(6000); if ((await used()) < 10) break; } if (i < NT - 1) await c.close(); }
  R.start = await used(); await run('G01', { files: ['P25_gps_orient1.jpg'], dl: R.start < 10 }); await run('G02', { clear: true, files: ['R01_receipt.jpg'], dl: R.start < 10 }); R.final = await used(); }
 if (mode === 'zero' || mode === 'subset') { for (let i = 0; i < 8; i++) { await open(); await p.waitForTimeout(3000); const u = await used(); R.tries.push(u); if (u >= 10 || mode === 'subset') break; await c.close(); }
  R.start = await used();
  if (mode === 'zero') { const seq = []; for (let i = 0; i < 45; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 40).replace(/\n/g, ' '); }); seq.push(a); if (/Open from Google Drive/.test(a)) break; } R.kbd = { seq: seq.slice(-6), reachedDrop: seq.some(s => /Drop images|browse/i.test(s)), tabs: seq.length };
   await run('Z01', { files: R_(3), full: true }); await run('Z02', { convert: false, dl: true }); R.cases.Z02b = await (async () => { const r = {}; const btn = p.locator('main button', { hasText: /^Download/ }).first(); if (await btn.count()) { await btn.click(); await p.waitForTimeout(2000); r.dialog = await dialog(); await p.screenshot({ path: OUT + 'cases/Z02-dialog.png' }); if (r.dialog && /Day Pass/.test(r.dialog)) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.dayPass = { dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'dlg-daypass.png' }); } } await esc(); } r.after = await used(); return r; })();
   R.thumbs = await p.evaluate(() => [...document.querySelectorAll('main [aria-label="Pages of the PDF"] img')].map(i => i.naturalWidth + 'x' + i.naturalHeight));
   R.drive = await act('zero-drive', p.getByRole('button', { name: /Save to Google Drive/ })); R.cloud = await act('zero-cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
   R.openDrive = await act('zero-open-drive', p.getByRole('button', { name: /Open from Google Drive/ })); R.end = await used();
   await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); const u0 = p.url();
   await p.getByRole('button', { name: 'Quick Buy' }).first().click(); await p.waitForTimeout(3000); R.qbDay = { url: p.url() !== u0 ? red(p.url()) : null, dialog: await dialog() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await esc();
   if (p.url() !== u0) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); }
   await p.getByRole('button', { name: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); R.qbMonth = { url: red(p.url()), title: await p.title() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' }); }
  else { await run('S01', { files: R_(3) }); await run('S02', { clear: true, files: ['P02_orient6_gps.jpg', 'P16_cmyk.jpg', 'P11_iphone.heic', 'P05.avif', 'P06_anim.gif'], prepWait: 8000 }); await run('S03', { clear: true, files: ['P21_scan_300dpi.jpg'], size: 'Original image size' }); await run('S04', { clear: true, files: R_(5), pair: true }); } }
 R.t2 = now(); R.net = { total: net.length, hits: net.filter(x => x.hit || x.big).map(x => ({ u: x.u, len: x.len })), posts: net.filter(x => x.m !== 'GET' && /freedailypro/.test(x.u)).map(x => ({ u: x.u, len: x.len })).slice(0, 20) };
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('tries', R.tries, 'start', R.start, 'end', R.endUsed, R.afterReload, R.final); await b.close(); })();
