// FDP-48: render the 5 Image to PDF pair landing pages (guest, no actions) and record H1, visible "free" wording, trial strip and accept list.
const pw = require('playwright'); const fs = require('fs');
(async () => { const b = await pw.chromium.launch(); const out = {};
 for (const s of ['png-to-pdf', 'jpg-to-pdf', 'heic-to-pdf', 'webp-to-pdf', 'gif-to-pdf']) { const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage();
  await p.goto('https://www.freedailypro.com/tool/image-to-pdf/' + s, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000);
  out[s] = await p.evaluate(() => { const m = document.querySelector('main'); const t = m.innerText; return { title: document.title, h1: document.querySelector('h1')?.innerText, frees: (t.match(/[^.\n]*\bfree\b[^.\n]*/gi) || []).slice(0, 6), strip: (t.match(/Trial:[^\n]*/) || [''])[0], accept: document.querySelector('main input[type=file]')?.getAttribute('accept'), intro: t.slice(0, 600) }; });
  await p.screenshot({ path: '/workspace/deep/48-image-to-pdf/live/cases/pair-' + s + '.png' }); await c.close(); }
 fs.writeFileSync('/workspace/deep/48-image-to-pdf/live/pairs.json', JSON.stringify(out, null, 1)); for (const [k, v] of Object.entries(out)) console.log(k, '|', v.title, '|', v.h1, '|', v.strip, '|', JSON.stringify(v.frees)); await b.close(); })();
