// FDP-48 at 0: what "Preview first page" shows (size of the rendered preview), guest.
const pw = require('playwright');
(async () => { const b = await pw.chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage();
 await p.goto('https://www.freedailypro.com/tool/image-to-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(8000);
 const u = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 await p.locator('main input[type=file]').first().setInputFiles('/workspace/deep/48-image-to-pdf/testfiles/R01_receipt.jpg'); await p.waitForTimeout(2500);
 await p.locator('main button', { hasText: /^Convert to PDF$/ }).click(); await p.waitForTimeout(3000);
 await p.locator('main button', { hasText: /Preview first page/ }).click(); await p.waitForTimeout(3000);
 const r = await p.evaluate(() => [...document.querySelectorAll('img, canvas, iframe, embed, object')].filter(e => e.offsetWidth > 150).map(e => e.tagName + ' ' + (e.naturalWidth || e.width) + 'x' + (e.naturalHeight || e.height) + ' ' + (e.src || e.data || '').slice(0, 40)));
 console.log('used', u, JSON.stringify(r)); await p.screenshot({ path: '/workspace/deep/48-image-to-pdf/live/cases/Z03-preview-at0.png' }); await b.close(); })();
