// FDP-48: minimal WebKit probe (does adding/converting crash Playwright WebKit?)
const { webkit } = require('playwright'); const T='/workspace/deep/48-image-to-pdf/testfiles/';
(async()=>{ const b=await webkit.launch(); const c=await b.newContext({viewport:{width:1440,height:900}}); const p=await c.newPage(); const log=[];
 p.on('crash',()=>log.push('CRASH')); p.on('pageerror',e=>log.push('pageerror '+e.message.slice(0,150)));
 await p.goto('https://www.freedailypro.com/tool/image-to-pdf',{waitUntil:'domcontentloaded'}); await p.waitForTimeout(5000); log.push('loaded');
 for (const f of [['P01_logo_transparent.png'],['R01_receipt.jpg']]) { try { await p.locator('input[type=file]').first().setInputFiles(f.map(x=>T+x)); await p.waitForTimeout(3000); log.push('added '+f+' items='+await p.locator('main [aria-label="Pages of the PDF"] img, main li').count());
  await p.locator('main button',{hasText:/^Convert to PDF$/}).first().click(); await p.waitForTimeout(5000); log.push('after convert: '+(await p.evaluate(()=>(document.querySelector('main').innerText.match(/\d+ pages? · [^\n]+/)||[''])[0]))); } catch(e){ log.push('err '+e.message.slice(0,120)); break; } }
 await p.screenshot({path:'/workspace/deep/48-image-to-pdf/live/cases/WK-probe.png'}).catch(()=>{}); console.log(JSON.stringify(log,null,1)); require('fs').writeFileSync('/workspace/deep/48-image-to-pdf/live/subset-webkit-probe.json',JSON.stringify(log,null,1)); await b.close(); })();
