// FDP-48: does this Playwright WebKit build crash decoding a plain JPEG offline? (isolates test-env vs site)
const { webkit } = require('playwright'); const fs=require('fs');
(async()=>{ const b=await webkit.launch(); const p=await b.newPage(); let crash=false; p.on('crash',()=>crash=true);
 const j=fs.readFileSync('/workspace/deep/48-image-to-pdf/testfiles/R01_receipt.jpg').toString('base64');
 await p.setContent('<img id=i src="data:image/jpeg;base64,'+j+'"><canvas id=c></canvas>'); await p.waitForTimeout(2000).catch(()=>{});
 let r=null; if(!crash) r=await p.evaluate(async()=>{const i=document.getElementById('i'); await i.decode().catch(e=>0); const c=document.getElementById('c'); c.width=50;c.height=50; c.getContext('2d').drawImage(i,0,0,50,50); const bm=await createImageBitmap(i).then(x=>x.width).catch(e=>'bm err'); return [i.naturalWidth,bm];}).catch(e=>'eval err '+e.message.slice(0,80));
 console.log(JSON.stringify({crash,r})); await b.close(); })();
