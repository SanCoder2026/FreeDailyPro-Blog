import { r as c, j as a } from "./vendor-react-D01g8YgM.js";
import {
  b as ge,
  T as we,
  F as xe,
  f as ke,
  d as be,
} from "./ToolPage-DwLoDncN.js";
import {
  v as te,
  f as v,
  B as u,
  I,
  aL as ve,
  aA as Ne,
  e as ee,
  N as je,
  D as ye,
} from "./index-B1CTyGtY.js";
import { T as Pe } from "./ToolInfoSection-C0i6Zbwo.js";
import { l as Ce } from "./utils-s8ucLyj8.js";
import { r as Te } from "./pdfThumbnails-4ijNer1F.js";
import { a as $e } from "./pdfMetadata-CcxIhQF2.js";
import { k as ae, P as y } from "./index-BRvxULIc.js";
import { r as De, w as Fe } from "./pdfBookmarks-BjfxtCfb.js";
import { A as Ie } from "./arrow-down-DgkjpMkc.js";
import { T as Me } from "./trash-2-CmoDM6Qu.js";
import { C as Se } from "./chevron-left-CWH4XvTX.js";
import { C as Oe } from "./chevron-right-7IYXE5RL.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
const Ue = te("IndentDecrease", [
  ["path", { d: "M21 12H11", key: "wd7e0v" }],
  ["path", { d: "M21 18H11", key: "4wu86t" }],
  ["path", { d: "M21 6H11", key: "6dy1d6" }],
  ["path", { d: "m7 8-4 4 4 4", key: "o5hrat" }],
]);
const Ee = te("IndentIncrease", [
  ["path", { d: "M21 12H11", key: "wd7e0v" }],
  ["path", { d: "M21 18H11", key: "4wu86t" }],
  ["path", { d: "M21 6H11", key: "6dy1d6" }],
  ["path", { d: "m3 8 4 4-4 4", key: "1a3j6y" }],
]);
let ze = 0;
const re = () => `bm${++ze}`;
function se(i) {
  return i.map((s) => ({
    id: re(),
    title: s.title,
    page: s.pageIndex === null ? null : s.pageIndex + 1,
    children: se(s.children),
  }));
}
function P(i) {
  return i.reduce((s, r) => s + 1 + P(r.children), 0);
}
function ne(i, s = 0, r = []) {
  return (
    i.forEach((t, n) => {
      (r.push({
        node: t,
        depth: s,
        canUp: n > 0,
        canDown: n < i.length - 1,
        canIndent: n > 0,
        canOutdent: s > 0,
      }),
        ne(t.children, s + 1, r));
    }),
    r
  );
}
function H(i, s) {
  for (const r of i) {
    if (r.id === s) return r;
    const t = H(r.children, s);
    if (t) return t;
  }
  return null;
}
function b(i, s, r) {
  const t = i.findIndex((n) => n.id === s);
  return t >= 0
    ? r(i, t)
    : i.map((n) => {
        const o = b(n.children, s, r);
        return o === n.children ? n : { ...n, children: o };
      });
}
const R = (i, s, r) =>
    b(i, s, (t, n) => t.map((o, h) => (h === n ? { ...o, ...r } : o))),
  Ae = (i, s) => b(i, s, (r, t) => r.filter((n, o) => o !== t)),
  Be = (i, s) =>
    b(i, s, (r, t) => {
      if (t === 0) return r;
      const n = [...r];
      return (([n[t - 1], n[t]] = [n[t], n[t - 1]]), n);
    }),
  Re = (i, s) =>
    b(i, s, (r, t) => {
      if (t >= r.length - 1) return r;
      const n = [...r];
      return (([n[t + 1], n[t]] = [n[t], n[t + 1]]), n);
    }),
  Le = (i, s) =>
    b(i, s, (r, t) => {
      if (t === 0) return r;
      const n = r[t - 1],
        o = r.filter((h, d) => d !== t);
      return ((o[t - 1] = { ...n, children: [...n.children, r[t]] }), o);
    });
function ie(i, s) {
  const r = i.findIndex((t) => t.children.some((n) => n.id === s));
  if (r >= 0) {
    const t = i[r],
      n = t.children.find((h) => h.id === s),
      o = [...i];
    return (
      (o[r] = { ...t, children: t.children.filter((h) => h.id !== s) }),
      o.splice(r + 1, 0, n),
      o
    );
  }
  return i.map((t) => {
    const n = ie(t.children, s);
    return n === t.children ? t : { ...t, children: n };
  });
}
function He(i, s, r) {
  return !r || !H(i, r)
    ? [...i, s]
    : b(i, r, (t, n) => {
        const o = [...t];
        return (o.splice(n + 1, 0, s), o);
      });
}
function oe(i, s) {
  const r = [];
  let t = 0,
    n = 0;
  const o = (d) => {
    for (const m of d)
      (m.page !== null &&
        (!Number.isInteger(m.page) || m.page < 1 || m.page > s) &&
        r.push(
          `"${m.title || "Untitled"}" points at page ${m.page}, but the file has pages 1 to ${s}.`,
        ),
        m.page === null && t++,
        m.title.trim() || n++,
        o(m.children));
  };
  o(i);
  const h = [];
  return (
    t &&
      h.push(
        `${t} bookmark${t === 1 ? " has" : "s have"} no target page. ${t === 1 ? "It" : "They"} will be saved as ${t === 1 ? "a heading" : "headings"} ${t === 1 ? "that does" : "that do"} not jump anywhere. Enter a page number to fix that.`,
      ),
    n &&
      h.push(
        `${n} bookmark${n === 1 ? " has" : "s have"} no title and will be saved as "Untitled".`,
      ),
    { errors: r, warnings: h }
  );
}
function le(i, s) {
  return i.map((r) => ({
    title: r.title.trim(),
    page: r.page === null ? null : (s[r.page - 1] ?? null),
    children: le(r.children, s),
  }));
}
async function _e(i) {
  try {
    const s = await ae.load(i, { ignoreEncryption: !0, updateMetadata: !1 });
    return s.isEncrypted
      ? { error: "encrypted" }
      : { nodes: se(De(s)), pageCount: s.getPageCount() };
  } catch {
    return { error: "invalid" };
  }
}
async function Je(i, s) {
  const r = await ae.load(i, { updateMetadata: !1 }),
    { errors: t } = oe(s, r.getPageCount());
  if (t.length) throw new Error(t[0]);
  return (
    r.catalog.delete(y.of("Outlines")),
    s.length > 0
      ? (Fe(r, le(s, r.getPages())),
        r.catalog.set(y.of("PageMode"), y.of("UseOutlines")))
      : r.catalog.get(y.of("PageMode"))?.toString() === "/UseOutlines" &&
        r.catalog.delete(y.of("PageMode")),
    r.save()
  );
}
const L = {
  what: "Shows the bookmarks (outline) of a PDF as a tree you can edit: rename, delete, reorder, indent and outdent them, and add new ones that point at a page number. A preview of the target page helps you check each one. The edited outline is written into a copy of the PDF.",
  how: "Drop a PDF. Edit the titles and page numbers in the list, use the arrows and indent buttons to arrange them, and click the eye button to see the page a bookmark points at. To add a bookmark, type a title and page number and click Add. Then download the PDF.",
  tip: "Bookmarks are saved so each one opens its page fitted to the window; a zoom or scroll position stored in the original bookmark is not kept. Your original file is never changed. Clearing the list and downloading removes all bookmarks.",
};
function $t() {
  const { logUsageNow: i } = ge(),
    [s, r] = c.useState(null),
    [t, n] = c.useState(0),
    [o, h] = c.useState([]),
    [d, m] = c.useState([]),
    [N, x] = c.useState(null),
    [M, S] = c.useState(""),
    [_, O] = c.useState("1"),
    [g, C] = c.useState(1),
    [J, Y] = c.useState(null),
    [ce, T] = c.useState(!1),
    [K, V] = c.useState(!1),
    [de, me] = c.useState(0),
    $ = c.useRef(null),
    U = c.useRef(null),
    W = c.useMemo(() => ne(d), [d]),
    { errors: D, warnings: ue } = c.useMemo(() => oe(d, t), [d, t]),
    E = () => {
      ($.current?.loadingTask.destroy(), ($.current = null));
    };
  c.useEffect(() => E, []);
  const he = c.useCallback(async (e) => {
    const l = e[0];
    if (!l) return;
    const f = await l.arrayBuffer(),
      k = await _e(f);
    if ("error" in k) {
      v.error(
        k.error === "encrypted"
          ? "This PDF is password-protected. Unlock it first (try Unlock PDF), then come back."
          : "This PDF could not be read. It may be damaged (try Repair PDF).",
      );
      return;
    }
    (E(),
      (U.current = f),
      r(l),
      n(k.pageCount),
      h(k.nodes),
      m(k.nodes),
      x(null),
      S(""),
      O("1"),
      C(1),
      Y(null),
      T(!1));
    try {
      (($.current = await Ce(
        new File([f], l.name, { type: "application/pdf" }),
      )),
        me((A) => A + 1));
    } catch {
      T(!0);
    }
  }, []);
  c.useEffect(() => {
    const e = $.current;
    if (!e || !s || g < 1 || g > t) return;
    let l = !1;
    return (
      Te(e, g, 520).then(
        (f) => {
          l || (Y(f), T(!1));
        },
        () => {
          l || T(!0);
        },
      ),
      () => {
        l = !0;
      }
    );
  }, [g, t, s, de]);
  const z = (e) => {
      e !== null && e >= 1 && e <= t && C(e);
    },
    w = (e) => m((l) => e(l)),
    Z = (e) => {
      const l = e.trim();
      if (!/^\d+$/.test(l)) return null;
      const f = Number(l);
      return f >= 1 && f <= t ? f : null;
    },
    q = Z(_),
    G = () => {
      if (!M.trim()) {
        v.error("Type a title for the new bookmark.");
        return;
      }
      if (q === null) {
        v.error(`Enter a page number from 1 to ${t}.`);
        return;
      }
      const e = { id: re(), title: M.trim(), page: q, children: [] };
      (w((l) => He(l, e, N)), x(e.id), S(""));
    },
    pe = async () => {
      if (!(!s || !U.current)) {
        if (D.length) {
          v.error(D[0]);
          return;
        }
        if (await i()) {
          V(!0);
          try {
            const e = await Je(U.current, d);
            (be(
              new Blob([new Uint8Array(e)], { type: "application/pdf" }),
              `${$e(s.name)}-bookmarks.pdf`,
            ),
              v.success(
                d.length
                  ? `${P(d)} bookmark${P(d) === 1 ? "" : "s"} saved in the new file`
                  : "Bookmarks removed in the new file",
              ));
          } catch (e) {
            (console.error(e),
              v.error(
                e instanceof Error && /page \d+/.test(e.message)
                  ? e.message
                  : "The bookmarks could not be written. The file may be damaged; try Repair PDF first.",
              ));
          } finally {
            V(!1);
          }
        }
      }
    },
    F = JSON.stringify(o) !== JSON.stringify(d),
    Q = N ? H(d, N) : null;
  return a.jsxs(we, {
    children: [
      s
        ? a.jsxs("div", {
            className:
              "grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,20rem)]",
            children: [
              a.jsxs("div", {
                className: "space-y-4 min-w-0",
                children: [
                  a.jsxs("div", {
                    className:
                      "p-3 rounded-lg border bg-card flex flex-wrap items-center justify-between gap-2",
                    children: [
                      a.jsxs("p", {
                        className: "text-sm font-medium break-all",
                        children: [
                          s.name,
                          ": ",
                          t,
                          " page",
                          t === 1 ? "" : "s",
                          ", ",
                          P(d),
                          " bookmark",
                          P(d) === 1 ? "" : "s",
                        ],
                      }),
                      a.jsxs("div", {
                        className: "flex gap-1",
                        children: [
                          a.jsx(u, {
                            size: "sm",
                            variant: "ghost",
                            disabled: !F,
                            onClick: () => {
                              (m(o), x(null));
                            },
                            children: "Undo all changes",
                          }),
                          a.jsx(u, {
                            size: "sm",
                            variant: "ghost",
                            disabled: d.length === 0,
                            onClick: () => {
                              (m([]), x(null));
                            },
                            children: "Remove all",
                          }),
                          a.jsx(u, {
                            size: "sm",
                            variant: "ghost",
                            onClick: () => {
                              (E(), r(null), m([]), h([]));
                            },
                            children: "New file",
                          }),
                        ],
                      }),
                    ],
                  }),
                  W.length === 0
                    ? a.jsxs("p", {
                        className:
                          "text-sm text-muted-foreground rounded-lg border border-dashed p-4",
                        children: [
                          "This file has no bookmarks",
                          F ? " now" : "",
                          ". Add one below.",
                        ],
                      })
                    : a.jsx("ul", {
                        className: "space-y-2",
                        "aria-label": "Bookmarks",
                        children: W.map(
                          ({
                            node: e,
                            depth: l,
                            canUp: f,
                            canDown: k,
                            canIndent: A,
                            canOutdent: fe,
                          }) =>
                            a.jsxs(
                              "li",
                              {
                                style: { marginLeft: Math.min(l, 5) * 14 },
                                className: `rounded-lg border p-2 ${N === e.id ? "border-primary bg-primary/5" : "bg-card"}`,
                                children: [
                                  a.jsxs("div", {
                                    className:
                                      "flex flex-wrap items-center gap-2",
                                    children: [
                                      a.jsx(I, {
                                        "aria-label": `Title of bookmark, level ${l + 1}`,
                                        className: "flex-1 min-w-[9rem]",
                                        value: e.title,
                                        placeholder: "Untitled",
                                        onFocus: () => x(e.id),
                                        onChange: (p) =>
                                          w((j) =>
                                            R(j, e.id, {
                                              title: p.target.value,
                                            }),
                                          ),
                                      }),
                                      a.jsx(I, {
                                        "aria-label": `Page for ${e.title || "bookmark"}`,
                                        inputMode: "numeric",
                                        className: "w-20",
                                        placeholder: "Page",
                                        value: e.page ?? "",
                                        "aria-invalid":
                                          e.page !== null &&
                                          (e.page < 1 || e.page > t),
                                        onFocus: () => x(e.id),
                                        onChange: (p) => {
                                          const j = p.target.value.trim();
                                          if (j === "") {
                                            w((B) =>
                                              R(B, e.id, { page: null }),
                                            );
                                            return;
                                          }
                                          if (!/^\d+$/.test(j)) return;
                                          const X = Number(j);
                                          (w((B) => R(B, e.id, { page: X })),
                                            z(X));
                                        },
                                      }),
                                    ],
                                  }),
                                  a.jsxs("div", {
                                    className: "flex flex-wrap gap-1 mt-1",
                                    children: [
                                      a.jsx(u, {
                                        size: "icon",
                                        variant: "ghost",
                                        className: "h-9 w-9",
                                        "aria-label": `Show page for ${e.title || "bookmark"}`,
                                        disabled: e.page === null,
                                        onClick: () => {
                                          (x(e.id), z(e.page));
                                        },
                                        children: a.jsx(ve, {
                                          className: "h-4 w-4",
                                        }),
                                      }),
                                      a.jsx(u, {
                                        size: "icon",
                                        variant: "ghost",
                                        className: "h-9 w-9",
                                        "aria-label": `Move ${e.title || "bookmark"} up`,
                                        disabled: !f,
                                        onClick: () => w((p) => Be(p, e.id)),
                                        children: a.jsx(Ne, {
                                          className: "h-4 w-4",
                                        }),
                                      }),
                                      a.jsx(u, {
                                        size: "icon",
                                        variant: "ghost",
                                        className: "h-9 w-9",
                                        "aria-label": `Move ${e.title || "bookmark"} down`,
                                        disabled: !k,
                                        onClick: () => w((p) => Re(p, e.id)),
                                        children: a.jsx(Ie, {
                                          className: "h-4 w-4",
                                        }),
                                      }),
                                      a.jsx(u, {
                                        size: "icon",
                                        variant: "ghost",
                                        className: "h-9 w-9",
                                        "aria-label": `Outdent ${e.title || "bookmark"}`,
                                        disabled: !fe,
                                        onClick: () => w((p) => ie(p, e.id)),
                                        children: a.jsx(Ue, {
                                          className: "h-4 w-4",
                                        }),
                                      }),
                                      a.jsx(u, {
                                        size: "icon",
                                        variant: "ghost",
                                        className: "h-9 w-9",
                                        "aria-label": `Indent ${e.title || "bookmark"}`,
                                        disabled: !A,
                                        onClick: () => w((p) => Le(p, e.id)),
                                        children: a.jsx(Ee, {
                                          className: "h-4 w-4",
                                        }),
                                      }),
                                      a.jsx(u, {
                                        size: "icon",
                                        variant: "ghost",
                                        className: "h-9 w-9 text-destructive",
                                        "aria-label": `Delete ${e.title || "bookmark"}${e.children.length ? " and its sub-bookmarks" : ""}`,
                                        onClick: () => {
                                          (w((p) => Ae(p, e.id)),
                                            N === e.id && x(null));
                                        },
                                        children: a.jsx(Me, {
                                          className: "h-4 w-4",
                                        }),
                                      }),
                                    ],
                                  }),
                                ],
                              },
                              e.id,
                            ),
                        ),
                      }),
                  a.jsxs("div", {
                    className: "rounded-lg border p-3 space-y-2",
                    children: [
                      a.jsx("p", {
                        className: "text-sm font-medium",
                        children: "Add a bookmark",
                      }),
                      a.jsxs("div", {
                        className: "flex flex-wrap gap-2 items-end",
                        children: [
                          a.jsxs("div", {
                            className: "flex-1 min-w-[9rem]",
                            children: [
                              a.jsx(ee, {
                                htmlFor: "bm-title",
                                children: "Title",
                              }),
                              a.jsx(I, {
                                id: "bm-title",
                                value: M,
                                onChange: (e) => S(e.target.value),
                                onKeyDown: (e) => {
                                  e.key === "Enter" && G();
                                },
                              }),
                            ],
                          }),
                          a.jsxs("div", {
                            className: "w-24",
                            children: [
                              a.jsxs(ee, {
                                htmlFor: "bm-page",
                                children: ["Page (1-", t, ")"],
                              }),
                              a.jsx(I, {
                                id: "bm-page",
                                inputMode: "numeric",
                                value: _,
                                onChange: (e) => {
                                  O(e.target.value);
                                  const l = Z(e.target.value);
                                  l && z(l);
                                },
                              }),
                            ],
                          }),
                          a.jsxs(u, {
                            onClick: G,
                            className: "gap-1",
                            children: [
                              a.jsx(ke, { className: "h-4 w-4" }),
                              "Add",
                            ],
                          }),
                        ],
                      }),
                      a.jsx("p", {
                        className: "text-xs text-muted-foreground",
                        children: Q
                          ? `The new bookmark goes right after "${Q.title || "Untitled"}", at the same level.`
                          : "The new bookmark goes at the end of the list.",
                      }),
                    ],
                  }),
                  D.map((e) =>
                    a.jsx(
                      "p",
                      {
                        role: "alert",
                        className: "text-sm text-destructive",
                        children: e,
                      },
                      e,
                    ),
                  ),
                  ue.map((e) =>
                    a.jsx(je, { className: "text-xs", children: e }, e),
                  ),
                  a.jsxs("div", {
                    className: "flex flex-wrap gap-3",
                    children: [
                      a.jsxs(u, {
                        onClick: pe,
                        disabled: K || D.length > 0 || !F,
                        className: "gap-2",
                        children: [
                          a.jsx(ye, { className: "h-4 w-4" }),
                          K ? "Writing..." : "Download PDF with new bookmarks",
                        ],
                      }),
                      !F &&
                        a.jsx("p", {
                          className:
                            "text-xs text-muted-foreground self-center",
                          children: "Make a change to enable the download.",
                        }),
                    ],
                  }),
                ],
              }),
              a.jsxs("aside", {
                className: "space-y-2 min-w-0 lg:sticky lg:top-4 self-start",
                "aria-label": "Page preview",
                children: [
                  a.jsxs("div", {
                    className: "flex items-center justify-between gap-2",
                    children: [
                      a.jsx(u, {
                        size: "icon",
                        variant: "outline",
                        "aria-label": "Previous page",
                        disabled: g <= 1,
                        onClick: () => C((e) => Math.max(1, e - 1)),
                        children: a.jsx(Se, { className: "h-4 w-4" }),
                      }),
                      a.jsxs("p", {
                        className: "text-sm font-medium",
                        "aria-live": "polite",
                        children: ["Page ", g, " of ", t],
                      }),
                      a.jsx(u, {
                        size: "icon",
                        variant: "outline",
                        "aria-label": "Next page",
                        disabled: g >= t,
                        onClick: () => C((e) => Math.min(t, e + 1)),
                        children: a.jsx(Oe, { className: "h-4 w-4" }),
                      }),
                    ],
                  }),
                  a.jsx("div", {
                    className:
                      "rounded-lg border bg-muted/30 p-2 flex items-center justify-center min-h-[16rem]",
                    children: ce
                      ? a.jsx("p", {
                          className:
                            "text-sm text-muted-foreground text-center",
                          children:
                            "This page could not be shown. You can still edit the bookmarks.",
                        })
                      : J
                        ? a.jsx("img", {
                            src: J,
                            alt: `Page ${g}`,
                            className:
                              "max-h-[32rem] w-auto max-w-full border bg-white",
                          })
                        : a.jsx("p", {
                            className: "text-sm text-muted-foreground",
                            children: "Loading page...",
                          }),
                  }),
                  a.jsxs(u, {
                    variant: "outline",
                    size: "sm",
                    className: "w-full",
                    onClick: () => O(String(g)),
                    children: ["Use page ", g, " for the new bookmark"],
                  }),
                ],
              }),
            ],
          })
        : a.jsx(xe, {
            accept: ".pdf",
            onFiles: he,
            deferUsageLog: !0,
            label: "Drop a PDF file",
            description: "Edit its bookmarks (outline)",
          }),
      a.jsx(Pe, { whatIsIt: L.what, howToUse: L.how, tip: L.tip }),
    ],
  });
}
export { $t as default };
//# sourceMappingURL=PdfBookmarksEditor-P1ChXVF9.js.map
