const o =
    "Add cloud storage, $4.99 per month, 1 GB, optional, cancel any time.",
  t = "Save to my cloud storage",
  a = "Saved only when you choose. Your file stays on your device until then.",
  n =
    "After your cloud storage ends, your files stay available to download for 7 days, then they are permanently deleted.",
  r =
    "Cancel any time. Your cloud storage stays active until the end of the period you paid for, and it will not renew. We do not issue prorated refunds.",
  s =
    "Optional add-on. Add cloud storage for $4.99 per month: 1 GB of private space for the files you choose to save, share a file with anyone through a download link. Not included in any other plan or pass. Cancel any time; it runs to the end of the paid month and does not renew.";
function d(e) {
  return e >= 1e9
    ? `${(e / 1e9).toFixed(2)} GB`
    : e >= 1e6
      ? `${(e / 1e6).toFixed(1)} MB`
      : `${Math.max(1, Math.round(e / 1e3))} KB`;
}
const i = "support@freedailypro.com";
export { i as C, o as a, r as b, n as c, s as d, t as e, d as f, a as g };
//# sourceMappingURL=cloudStorage-BzUdFuQl.js.map
