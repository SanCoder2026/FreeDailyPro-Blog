# FDP-49: inspect downloaded PDFs: outline tree, flags, orphaned titles, forms/links/metadata, page labels, badge
import pikepdf, sys, glob, re, zlib, os
def tree(pdf):
    out=[]
    with pdf.open_outline() as o:
        def walk(items, d):
            for it in items:
                dest = it.destination; pg = None
                try:
                    if isinstance(dest, pikepdf.Array): pg = [i for i,p in enumerate(pdf.pages) if p.obj.objgen == dest[0].objgen][0]+1
                except Exception: pass
                ob = it.obj
                out.append(('  '*d)+f"{it.title!r} p={pg} dest={str(dest)[:40] if dest is not None and pg is None else ''} A={str(ob.get('/A'))[:50] if '/A' in ob else ''} C={ob.get('/C')} F={ob.get('/F')} Count={ob.get('/Count')}")
                walk(it.children, d+1)
        walk(o.root, 0)
    return out
for f in sorted(glob.glob(sys.argv[1] if len(sys.argv)>1 else '*.pdf')):
    pdf = pikepdf.open(f); raw = open(f,'rb').read()
    print('==', f, len(raw), 'pages', len(pdf.pages), 'PageMode', pdf.Root.get('/PageMode'), 'PageLabels', '/PageLabels' in pdf.Root, 'AcroForm', '/AcroForm' in pdf.Root, 'Names', '/Names' in pdf.Root)
    print('   docinfo', {k:str(v)[:40] for k,v in pdf.docinfo.items()})
    for l in tree(pdf): print('   ', l)
    # orphaned outline dicts: any object with /Title not reachable from the outline
    reach=set()
    if '/Outlines' in pdf.Root:
        st=[pdf.Root.Outlines]
        while st:
            x=st.pop()
            for k in ('/First','/Next'):
                if k in x and x[k].objgen not in reach: reach.add(x[k].objgen); st.append(x[k])
    orphans=[str(o.get('/Title')) for o in pdf.objects if isinstance(o,pikepdf.Dictionary) and '/Title' in o and ('/Parent' in o or '/Dest' in o or '/A' in o) and o.objgen not in reach]
    print('   orphan outline titles:', orphans[:12], len(orphans))
    a=[ (str(an.get('/Subtype')), str(an.get('/T','')), str(an.get('/V','')), str(an.get('/A',{}).get('/URI','')) if '/A' in an else '') for pg in pdf.pages for an in pg.get('/Annots',[]) ]
    print('   annots p-all:', a)
    txt=[]
    for pg in pdf.pages[:1]:
        try: txt.append(pikepdf.unparse_content_stream(pikepdf.parse_content_stream(pg))[:0])
        except Exception as e: pass
    print('   FDP badge text in page1 stream:', b'FreeDailyPro' in pdf.pages[0].Contents.read_bytes() if not isinstance(pdf.pages[0].Contents, pikepdf.Array) else 'array', '| raw has FreeDailyPro:', b'FreeDailyPro' in raw)
