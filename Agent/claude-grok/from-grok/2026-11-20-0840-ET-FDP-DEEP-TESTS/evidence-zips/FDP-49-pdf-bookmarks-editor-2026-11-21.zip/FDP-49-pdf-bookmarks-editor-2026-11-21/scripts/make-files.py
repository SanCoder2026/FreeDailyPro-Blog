# FDP-49 test PDFs (pikepdf + Pillow-free text pages via reportlab-less raw content)
import pikepdf, os
from pikepdf import Pdf, Dictionary, Array, Name, String, OutlineItem
def pages(n, label='Page'):
    pdf = Pdf.new()
    font = pdf.make_indirect(Dictionary(Type=Name.Font, Subtype=Name.Type1, BaseFont=Name.Helvetica))
    for i in range(n):
        c = f"BT /F1 48 Tf 72 700 Td ({label} {i+1}) Tj ET".encode()
        pdf.add_blank_page(page_size=(612, 792))
        pg = pdf.pages[-1]; pg.Contents = pdf.make_stream(c); pg.Resources = Dictionary(Font=Dictionary(F1=font))
    return pdf
# B01 nested outline, unicode, a sensitive title to delete later
p = pages(12)
with p.open_outline() as o:
    ch1 = OutlineItem('Chapter 1 – Introduction', 0); ch1.children += [OutlineItem('1.1 Background', 1), OutlineItem('1.2 Scope', 2)]
    ch1.children[0].children.append(OutlineItem('1.1.1 Deep level', 1))
    ch2 = OutlineItem('Chapitre 2 – Résumé 日本語 العربية 😀', 3)
    conf = OutlineItem('CONFIDENTIAL – Layoff list Q4 (delete me)', 5)
    ch3 = OutlineItem('Chapter 3 – Results', 7); ch3.children.append(OutlineItem('3.1 Tables', 8))
    o.root.extend([ch1, ch2, conf, ch3, OutlineItem('Appendix', 11)])
p.docinfo['/Title'] = 'B01 nested'; p.docinfo['/Author'] = 'QA Author'
p.save('B01_nested_unicode.pdf')
# B02 no outline
pages(5).save('B02_no_outline.pdf')
# B03 named dests, GoTo action with named D, URI action, XYZ zoom
p = pages(6)
names = Array([String('sec-a'), Array([p.pages[2].obj, Name.Fit]), String('sec-b'), Array([p.pages[4].obj, Name.XYZ, 0, 400, 2])])
p.Root.Names = Dictionary(Dests=Dictionary(Names=names))
with p.open_outline() as o:
    o.root.append(OutlineItem('Named dest sec-a (page 3)', 0))
    o.root.append(OutlineItem('XYZ zoom 200% page 2', 1))
    o.root.append(OutlineItem('Website link (URI)', 0))
    o.root.append(OutlineItem('GoTo named sec-b (page 5)', 0))
# patch after save via raw objects
p.save('_tmp.pdf'); q = Pdf.open('_tmp.pdf')
it = q.Root.Outlines.First
it.Dest = String('sec-a'); it = it.Next
it.Dest = Array([q.pages[1].obj, Name.XYZ, 0, 500, 2]); it = it.Next
del it['/Dest']; it.A = Dictionary(S=Name.URI, URI=String('https://example.com/')); it = it.Next
del it['/Dest']; it.A = Dictionary(S=Name.GoTo, D=String('sec-b'))
q.save('B03_named_uri_xyz.pdf'); q.close(); os.remove('_tmp.pdf')
# B04 user password, B05 owner password only (opens without a password)
pages(3).save('B04_user_password.pdf', encryption=pikepdf.Encryption(user='u123', owner='o123'))
pages(3).save('B05_owner_only.pdf', encryption=pikepdf.Encryption(user='', owner='o123', allow=pikepdf.Permissions(modify_other=False)))
# B06 not a pdf
open('B06_not_pdf.pdf','w').write('hello this is not a pdf')
# B07 300 pages, 300 bookmarks (10 chapters x 29 sections)
p = pages(300)
with p.open_outline() as o:
    for c in range(10):
        it = OutlineItem(f'Chapter {c+1}', c*30)
        it.children.extend(OutlineItem(f'Section {c+1}.{s+1}', c*30+s+1) for s in range(29))
        o.root.append(it)
p.save('B07_300_bookmarks.pdf')
# B08 closed items + colour/bold flags; B09 page labels (roman front matter)
p = pages(8)
with p.open_outline() as o:
    a = OutlineItem('Closed parent (bold red)', 0); a.children += [OutlineItem('child A', 1), OutlineItem('child B', 2)]
    o.root.extend([a, OutlineItem('Italic blue', 3)])
p.save('_t.pdf'); q = Pdf.open('_t.pdf'); f = q.Root.Outlines.First
f.Count = -2; f.C = Array([1, 0, 0]); f.F = 2; f.Next.C = Array([0, 0, 1]); f.Next.F = 1
q.Root.PageLabels = Dictionary(Nums=Array([0, Dictionary(S=Name.r), 3, Dictionary(S=Name.D)]))
q.save('B08_closed_colour_labels.pdf'); q.close(); os.remove('_t.pdf')
# B10 form field + link annotation + metadata (preservation check)
p = pages(3)
with p.open_outline() as o: o.root.append(OutlineItem('Start', 0))
p.save('_t.pdf'); q = Pdf.open('_t.pdf')
fld = q.make_indirect(Dictionary(Type=Name.Annot, Subtype=Name.Widget, FT=Name.Tx, T=String('name_field'), V=String('Jane Doe'), Rect=Array([72,600,300,630]), P=q.pages[0].obj))
lnk = q.make_indirect(Dictionary(Type=Name.Annot, Subtype=Name.Link, Rect=Array([72,500,300,530]), A=Dictionary(S=Name.URI, URI=String('https://example.org/'))))
q.pages[0].Annots = Array([fld, lnk]); q.Root.AcroForm = Dictionary(Fields=Array([fld]))
q.docinfo['/Title'] = 'Form + link'; q.docinfo['/Author'] = 'QA Author'; q.docinfo['/Keywords'] = 'keep-me'
q.save('B10_form_link_meta.pdf', object_stream_mode=pikepdf.ObjectStreamMode.generate); q.close(); os.remove('_t.pdf')
# B11 cyclic outline (Next points back to First)
p = pages(3)
with p.open_outline() as o: o.root.extend([OutlineItem('Loop A', 0), OutlineItem('Loop B', 1)])
p.save('_t.pdf'); q = Pdf.open('_t.pdf'); q.Root.Outlines.First.Next.Next = q.Root.Outlines.First
q.save('B11_cyclic_outline.pdf'); q.close(); os.remove('_t.pdf')
# B12 truncated pdf
b = open('B01_nested_unicode.pdf','rb').read(); open('B12_truncated.pdf','wb').write(b[:len(b)//2])
print(sorted(os.listdir('.')))
