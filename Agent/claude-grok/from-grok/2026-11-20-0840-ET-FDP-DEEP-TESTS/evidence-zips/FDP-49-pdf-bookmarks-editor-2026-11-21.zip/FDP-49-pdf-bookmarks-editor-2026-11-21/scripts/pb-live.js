// FDP-49 PDF Bookmarks Editor, guest. Usage: node pb-live.js <zero|left|subset> [engine]   (TRIES env = fresh contexts to try for "left")
// zero: context at the cap -> load/edit, Download (dialog), Drive popup, Day Pass (stops at email), Quick Buy monthly (stops at Stripe), keyboard.
// left: context with uses left -> many cases with downloads in ONE page load (per-page-load check), then reload + download.
// Never types an email/card, never clicks a pass "Continue", never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const crypto = require('crypto');
const BASE = '/workspace/deep/49-pdf-bookmarks-editor/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/pdf-bookmarks-editor';
const mode = process.argv[2] || 'left'; const eng = process.argv[3] || 'chromium'; const sfx = eng === 'chromium' ? '' : '-' + eng;
fs.mkdirSync(OUT + 'downloads', { recursive: true }); fs.mkdirSync(OUT + 'cases', { recursive: true });
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex').slice(0, 16);
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').slice(0, 160);
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p; const net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true, locale: 'en-US' }); p = await c.newPage(); p.setDefaultTimeout(15000);
  await p.addInitScript(() => { window.__t = []; const seen = new WeakSet(); setInterval(() => { document.querySelectorAll('[data-sonner-toast]').forEach(n => { if (!seen.has(n)) { seen.add(n); window.__t.push((n.innerText || '').trim()); } }); }, 150); });
  p.on('request', r => { const d = r.postData() || ''; if (r.method() === 'POST') net.push({ t: Date.now(), u: red(r.url()).replace(/dev[:%][^&"]*/g, 'dev:REDACTED'), len: d.length, pdf: /%PDF|Layoff|CONFIDENTIAL/.test(d) }); });
  await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000); };
 const used = () => p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 const state = () => p.evaluate(() => { const m = document.querySelector('main'); const t = m.innerText;
  const rows = [...m.querySelectorAll('ul[aria-label=Bookmarks] > li')].map(li => { const ins = li.querySelectorAll('input'); return [(ins[0]?.getAttribute('aria-label') || '').replace('Title of bookmark, level ', 'L'), ins[0]?.value, ins[1]?.value]; });
  const dl = [...m.querySelectorAll('button')].find(e => /^Download PDF|^Writing/.test(e.innerText.trim()));
  return { head: (t.match(/[^\n]+: \d+ pages?, \d+ bookmarks?/) || [''])[0], rows, msgs: (t.match(/(bookmarks? (has|have) no[^\n]*|[^\n]*points at page[^\n]*|[^\n]*saved as "Untitled"[^\n]*|This file has no bookmarks[^\n]*|Make a change[^\n]*)/g) || []), dl: dl ? (dl.disabled ? 'disabled' : 'enabled') : 'absent',
   extra: [...m.querySelectorAll('button')].map(x => x.innerText.trim()).filter(s => /Drive|cloud|Copy|Print|Save|Share/i.test(s)) }; });
 const load = async f => { const cn = p.getByRole('button', { name: 'Cancel', exact: true }); if (await cn.count()) { await cn.first().click().catch(() => {}); await p.waitForTimeout(400); } const nf = p.locator('main button', { hasText: /^New file$/ }); if (await nf.count()) { await nf.first().click(); await p.waitForTimeout(500); } await p.locator('main input[type=file]').first().setInputFiles(TF + f); await p.waitForTimeout(3500); };
 const row = name => p.locator('ul[aria-label=Bookmarks] > li').filter({ has: p.locator(`input[value="${name}"]`) }).first();
 const btn = async lbl => { await p.getByRole('button', { name: lbl, exact: true }).first().click(); await p.waitForTimeout(250); };
 const add = async (title, page) => { await p.locator('#bm-title').fill(title); await p.locator('#bm-page').fill(String(page)); await p.locator('main button', { hasText: /^Add$/ }).first().click(); await p.waitForTimeout(300); };
 const download = async (id, r) => { const bt = p.locator('main button', { hasText: /^Download PDF with new bookmarks$/ }).first(); r.dlState = (await bt.isDisabled()) ? 'disabled' : 'enabled'; if (r.dlState === 'disabled') return;
  const dp = p.waitForEvent('download', { timeout: 20000 }).catch(() => null); await bt.click(); const d = await dp; await p.waitForTimeout(1500);
  r.dialog = await dialog(); if (d) { const f = OUT + 'downloads/' + id + sfx + '-' + d.suggestedFilename(); await d.saveAs(f); r.download = { name: d.suggestedFilename(), bytes: fs.statSync(f).size, sha: sha(f) }; }
  if (r.dialog) { await p.screenshot({ path: OUT + 'cases/' + id + sfx + '-dialog.png' }); if (/Day Pass|day pass/i.test(r.dialog) && !R.dayPass && mode === 'zero') { const bp = p.getByRole('button', { name: /Buy Day Pass|Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.dayPass = { dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'dlg-daypass' + sfx + '.png' }); } } await esc(); } };
 const run = async (id, fn) => { const r = { id, t: now(), before: await used() }; const tN = await p.evaluate(() => (window.__t || []).length);
  try { await fn(r); } catch (e) { r.err = e.message.slice(0, 300); }
  r.afterUsed = await used(); await p.waitForTimeout(300); r.toasts = await p.evaluate(n => (window.__t || []).slice(n), tN); r.state = await state().catch(() => null);
  await p.screenshot({ path: OUT + 'cases/' + id + sfx + '.png' }).catch(() => {}); R.cases[id] = r; console.log(id, JSON.stringify(r).slice(0, 900)); return r; };
 const act = async (name, loc) => { const r = { before: await used() }; if (!(await loc.count())) { r.missing = true; console.log(name, 'missing'); return r; }
  const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); const url0 = p.url(); await loc.first().click(); const pg = await pop; await p.waitForTimeout(2500);
  r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null; if (pg) { await pg.waitForLoadState('domcontentloaded').catch(() => {}); r.popup = red(pg.url()); await pg.close(); }
  if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + sfx + '.png' }); await esc(); console.log(name, JSON.stringify(r).slice(0, 400)); return r; };
 const L01 = async r => { await load('B01_nested_unicode.pdf'); r.loaded = await state(); await btn('Delete CONFIDENTIAL – Layoff list Q4 (delete me)'); await row('Chapter 1 – Introduction').locator('input').first().fill('Chapter 1 – Intro (renamed)'); await add('New bookmark p10', 10); r.edited = await state(); await download('L01', r); };
 if (mode === 'zero' || mode === 'subset') { for (let i = 0; i < 8; i++) { await open(); await p.waitForTimeout(2000); const u = await used(); R.tries.push(u); if (u >= 2 || mode === 'subset') break; await c.close(); }
  R.start = await used();
  if (mode === 'zero') { const seq = []; for (let i = 0; i < 40; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 40).replace(/\n/g, ' '); }); seq.push(a); if (/Open from Google Drive/.test(a)) break; } R.kbd = { seq: seq.slice(-5), tabs: seq.length };
   R.openDrive = await act('zero-open-drive', p.getByRole('button', { name: /Open from Google Drive/ }));
   await run('Z01', L01);
   R.preview = await p.evaluate(() => { const i = document.querySelector('main img[alt^="Page "]'); return i ? [i.alt, i.naturalWidth, i.naturalHeight] : null; });
   R.end = await used();
   await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); const u0 = p.url();
   await p.getByRole('button', { name: 'Quick Buy' }).first().click(); await p.waitForTimeout(3000); R.qbDay = { url: p.url() !== u0 ? red(p.url()) : null, dialog: await dialog(), email: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await esc();
   if (p.url() !== u0) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); }
   await p.getByRole('button', { name: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); R.qbMonth = { url: red(p.url()), title: await p.title() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' }); }
  else { await run('S01', L01); await run('S02', async r => { await load('B07_300_bookmarks.pdf'); r.loaded = (await state()).head; await btn('Remove all'); await download('S02', r); }); } }
 if (mode === 'left2') { const NT = +(process.env.TRIES || 30); for (let i = 0; i < NT; i++) { await open(); const u = await used(); R.tries.push(u); if (u < 2) { await p.waitForTimeout(5000); if ((await used()) < 2) break; } if (i < NT - 1) await c.close(); }
  R.start = await used(); await run('M01', L01);
  await run('M02-pw', async r => { await load('B04_user_password.pdf'); r.dlg1 = await dialog(); const pwf = p.locator('[role=dialog] input[type=password]'); await pwf.fill('wrong'); await p.getByRole('button', { name: 'Unlock' }).click(); await p.waitForTimeout(1500); r.dlgWrong = await dialog(); await pwf.fill('u123'); await p.getByRole('button', { name: 'Unlock' }).click(); await p.waitForTimeout(3000); r.dlgAfter = await dialog(); r.loaded = await state(); await add('Unlocked add', 2); await download('M02', r); });
  for (const [id, f] of [['M06', 'B06_not_pdf.pdf'], ['M12', 'B12_truncated.pdf']]) await run(id, async r => { await load(f); r.loaded = await state(); });
  await run('L07', async r => { const t0 = Date.now(); await load('B07_300_bookmarks.pdf'); r.loadMs = Date.now() - t0; r.loaded = (await state()).head; await btn('Remove all'); r.edited = await state(); await download('L07', r); });
  await run('L08', async r => { await load('B08_closed_colour_labels.pdf'); r.loaded = await state(); await btn('Move Italic blue up'); await btn('Indent child B'); await btn('Outdent child A'); r.edited = await state(); await download('L08', r); });
  await run('L09', async r => { await load('B10_form_link_meta.pdf'); r.loaded = await state(); await add('Second', 2); await download('L09', r); });
  await run('L10', async r => { await load('B11_cyclic_outline.pdf'); r.loaded = await state(); await add('Third', 3); await download('L10', r); });
  await run('L11', async r => { await load('B01_nested_unicode.pdf'); await row('Appendix').locator('input').nth(1).fill('13'); await p.waitForTimeout(300); r.outOfRange = await state(); r.dlDisabled = await p.locator('main button', { hasText: /^Download PDF/ }).first().isDisabled(); await row('Appendix').locator('input').nth(1).fill(''); await p.waitForTimeout(200); await p.locator('ul[aria-label=Bookmarks] > li').last().locator('input').first().fill(''); await p.waitForTimeout(300); r.emptyTitleNoPage = await state(); await add('Bad page', 99); await add('', 3); r.afterBadAdds = await state(); await download('L11', r); });
  await run('L13', async r => { await load('B01_nested_unicode.pdf'); await btn('Delete Chapter 1 – Introduction and its sub-bookmarks'); r.afterDeleteParent = await state(); r.confirmDialog = await dialog(); r.undoEnabled = !(await p.getByRole('button', { name: 'Undo all changes' }).isDisabled()); await download('L13', r); });
  await run('L16-removeall-B01', async r => { await load('B01_nested_unicode.pdf'); await btn('Remove all'); await download('L16', r); });
  R.end = await used(); }
 if (mode === 'left') { const NT = +(process.env.TRIES || 30); for (let i = 0; i < NT; i++) { await open(); const u = await used(); R.tries.push(u); if (u < 2) { await p.waitForTimeout(5000); if ((await used()) < 2) break; } if (i < NT - 1) await c.close(); }
  R.start = await used(); if (R.start >= 2) { console.log('no context with uses left', R.tries); }
  await run('L01', L01);
  R.afterL01 = { net: net.filter(n => /usage/.test(n.u)).map(n => n.u.slice(0, 90)) };
  await run('L01b-redownload', async r => { await download('L01b', r); });
  await run('L02', async r => { await load('B02_no_outline.pdf'); r.loaded = await state(); await add('Intro', 1); await add('End', 5); await download('L02', r); });
  await run('L03', async r => { await load('B03_named_uri_xyz.pdf'); r.loaded = await state(); await add('Added p6', 6); await download('L03', r); });
  for (const [id, f] of [['L04', 'B04_user_password.pdf'], ['L05', 'B05_owner_only.pdf'], ['L06', 'B06_not_pdf.pdf'], ['L12', 'B12_truncated.pdf']]) await run(id, async r => { await load(f); r.loaded = await state(); });
  await run('L07', async r => { const t0 = Date.now(); await load('B07_300_bookmarks.pdf'); r.loadMs = Date.now() - t0; r.loaded = (await state()).head; await btn('Remove all'); r.edited = await state(); await download('L07', r); });
  await run('L08', async r => { await load('B08_closed_colour_labels.pdf'); r.loaded = await state(); await btn('Move Italic blue up'); await btn('Indent child B'); await btn('Outdent child A'); r.edited = await state(); await download('L08', r); });
  await run('L09', async r => { await load('B10_form_link_meta.pdf'); r.loaded = await state(); await add('Second', 2); await download('L09', r); });
  await run('L10', async r => { await load('B11_cyclic_outline.pdf'); r.loaded = await state(); await add('Third', 3); await download('L10', r); });
  await run('L11', async r => { await load('B01_nested_unicode.pdf'); await row('Appendix').locator('input').nth(1).fill('13'); await p.waitForTimeout(300); r.outOfRange = await state(); r.dlTry = {}; await row('Appendix').locator('input').nth(1).fill(''); await row('Appendix').locator('input').first().fill(''); await p.waitForTimeout(300); r.emptyTitleNoPage = await state(); await add('Bad page', 99); await add('', 3); r.afterBadAdds = await state(); await download('L11', r); });
  await run('L13', async r => { await load('B01_nested_unicode.pdf'); await btn('Delete Chapter 1 – Introduction and its sub-bookmarks'); r.afterDeleteParent = await state(); r.undoEnabled = !(await p.getByRole('button', { name: 'Undo all changes' }).isDisabled()); await download('L13', r); });
  R.endLoad = await used();
  await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); R.afterReload = await used();
  await run('L14-after-reload', async r => { await load('B02_no_outline.pdf'); await add('After reload', 2); await download('L14', r); });
  await run('L15-after-reload-2', async r => { await load('B02_no_outline.pdf'); await add('After reload 2', 3); await download('L15', r); });
  R.end = await used(); }
 R.t2 = now(); R.net = net; fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('tries', R.tries.join(','), 'start', R.start, 'end', R.end); await b.close(); })();
