// FDP-49 probe: load B01 in a guest context and dump the editor DOM (no download)
const { chromium } = require('playwright'); const fs = require('fs');
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage();
 await p.goto('https://www.freedailypro.com/tool/pdf-bookmarks-editor', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 await p.locator('main input[type=file]').first().setInputFiles('/workspace/deep/49-pdf-bookmarks-editor/testfiles/B01_nested_unicode.pdf'); await p.waitForTimeout(4000);
 const t = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 2500));
 const inputs = await p.evaluate(() => [...document.querySelectorAll('main input')].map(i => [i.getAttribute('aria-label'), i.value, i.type, i.id, i.placeholder]));
 const btns = await p.evaluate(() => [...document.querySelectorAll('main button')].map(x => (x.getAttribute('aria-label') || x.innerText.trim()).slice(0, 60) + (x.disabled ? ' [disabled]' : '')));
 const img = await p.evaluate(() => { const i = document.querySelector('main img[alt^="Page "]'); return i ? [i.alt, i.naturalWidth, i.naturalHeight] : null; });
 console.log(t, '\n', JSON.stringify(inputs), '\n', JSON.stringify(btns), '\n', img, await p.evaluate(() => localStorage.getItem('fdp-usage-v1')).then(s => s.replace(/dev:[^"]+/, 'dev:REDACTED')));
 await p.screenshot({ path: '/workspace/deep/49-pdf-bookmarks-editor/live/probe.png', fullPage: false }); await b.close(); })();
