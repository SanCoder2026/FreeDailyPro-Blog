import { r as l, j as e } from "./vendor-react-D01g8YgM.js";
import { T as L } from "./ToolWithSidebar-C7kxZj7O.js";
import { F as I, P as _, D as W } from "./ToolPage-DwLoDncN.js";
import {
  B as w,
  ax as U,
  b as k,
  N as z,
  f as B,
  ay as G,
} from "./index-B1CTyGtY.js";
import { C as v } from "./card-KXKUZKW8.js";
import { f as V } from "./formatFileSize-B-JRDfN5.js";
import { p as i } from "./plural-FIChqbp4.js";
import { u as H } from "./useRunToken-sJpsnYiZ.js";
import { l as Z } from "./utils-s8ucLyj8.js";
import { a as q } from "./pdfMetadata-CcxIhQF2.js";
import { OCR_LANGUAGES as J } from "./ocrText-C_9cxcFa.js";
import { L as D, i as K } from "./lockedPdfError-Js5vQrN8.js";
import {
  DEFAULT_RUN_OPTIONS as Q,
  convertPdfToExcelDocument as X,
  ExcelConversionCancelled as Y,
} from "./pdfToExcel-38p0cUiA.js";
import { I as ee } from "./info-B8t_e6MS.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-DQo6ttmA.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./pdfPageContent-BLgAwNtO.js";
import "./ocrImage-CmXFNUud.js";
import "./tablesToExcel-C1ZZUvmI.js";
import "./pdfLayout-BswErtWz.js";
import "./xlsx-CNerDvZX.js";
const P = {
    what: `Finds the tables in a PDF and writes them to an Excel workbook you can actually calculate with. Numbers, currency, percentages and dates are written as real values (not text), so SUM, sorting and filters work; a table that carries on over a page break becomes one table, with the repeated heading row dropped; columns of right-aligned amounts stay in one column. Only the tables are written, not the paragraphs around them.

Going the other direction? Excel to PDF converts spreadsheet data into a PDF table.`,
    tip: "A table is a run of at least three rows whose columns line up, so a table with only one or two rows, or one with merged cells or text wrapped over several lines inside a cell, may come out as separate rows or not be found; check the preview. Dates like 09/02/2026 can be day-first or month-first: the tool works it out from the other dates in the column, and when it cannot it leaves them as text until you choose the order. Codes, ZIP codes and numbers with leading zeros are kept as text on purpose. Scanned tables depend on scan quality, so check numbers read with OCR against the original. Charts and images in the PDF are not carried over.",
  },
  te = [
    { id: "table", label: "One sheet per table" },
    { id: "page", label: "One sheet per page" },
    { id: "single", label: "Everything on one sheet" },
  ],
  se = [
    { id: "auto", label: "Work it out from the file" },
    { id: "dmy", label: "Day first (31/12/2026)" },
    { id: "mdy", label: "Month first (12/31/2026)" },
  ];
function Ve() {
  const [m, y] = l.useState(null),
    [O, x] = l.useState(!1),
    [S, h] = l.useState(""),
    [C, b] = l.useState(0),
    [E, g] = l.useState(null),
    [j, f] = l.useState(""),
    [r, T] = l.useState(Q),
    s = H(),
    N = l.useRef(null),
    p = l.useCallback(() => {
      const t = N.current;
      ((N.current = null), t && t.terminate().catch(() => {}));
    }, []);
  l.useEffect(
    () => () => {
      (s.cancel(), p());
    },
    [s, p],
  );
  const u = (t, a) => {
      (T((n) => ({ ...n, [t]: a })), g(null));
    },
    R = l.useCallback(
      (t) => {
        (s.cancel(), p(), x(!1), y(t[0] || null), g(null), f(""));
      },
      [s, p],
    ),
    F = () => {
      (s.cancel(), p(), x(!1), y(null), g(null), f(""), b(0), h(""));
    },
    M = () => {
      (s.cancel(), p(), x(!1), h(""), b(0));
    },
    A = async () => {
      if (!m) return;
      const t = s.start();
      (x(!0), g(null), f(""), b(0), h("Opening the PDF…"));
      try {
        const a = await Z(m);
        if (!s.isCurrent(t)) return;
        const n = await X(a, r, {
          isCurrent: () => s.isCurrent(t),
          status: (d) => s.isCurrent(t) && h(d),
          progress: (d) => s.isCurrent(t) && b(d),
          registerWorker: (d) => {
            s.isCurrent(t) && (N.current = d);
          },
        });
        if (!s.isCurrent(t)) return;
        (g({ outcome: n, forFile: m.name }),
          n.kind === "ok" &&
            (B.success(`Found ${i(n.summary.tables, "table")}`),
            G("pdf-to-excel", "pdf-tools")));
      } catch (a) {
        if (a instanceof Y || !s.isCurrent(t)) return;
        if ((console.error(a), K(a))) {
          f(D);
          return;
        }
        const n = a instanceof Error && a.message ? a.message : "";
        f(
          n && !/Invalid PDF|password/i.test(n)
            ? `Extraction failed: ${n}`
            : "Extraction failed. The PDF may be damaged or password-protected.",
        );
      } finally {
        s.isCurrent(t) && (x(!1), h(""));
      }
    },
    c = E?.outcome,
    o = c?.summary;
  return e.jsx(L, {
    toolId: "pdf-to-excel",
    categoryId: "pdf-tools",
    whatItDoes: P.what,
    proTip: P.tip,
    children: m
      ? e.jsxs("div", {
          className: "space-y-4",
          children: [
            e.jsxs("div", {
              className: "p-4 rounded-lg border bg-card",
              children: [
                e.jsx("p", {
                  className: "text-sm font-medium break-all",
                  children: m.name,
                }),
                e.jsx("p", {
                  className: "text-xs text-muted-foreground mt-0.5",
                  children: V(m.size),
                }),
              ],
            }),
            O
              ? e.jsx(_, {
                  message: S || "Working…",
                  onStop: M,
                  progress: C > 0 ? C * 100 : void 0,
                })
              : e.jsxs(e.Fragment, {
                  children: [
                    e.jsxs("fieldset", {
                      className: "space-y-3 rounded-lg border p-3 min-w-0",
                      children: [
                        e.jsx("legend", {
                          className: "px-1 text-sm font-medium",
                          children: "Options",
                        }),
                        e.jsxs("div", {
                          children: [
                            e.jsx("p", {
                              className: "mb-1 text-sm",
                              children: "Sheets",
                            }),
                            e.jsx("div", {
                              className: "flex flex-wrap gap-2",
                              role: "group",
                              "aria-label": "How to arrange the sheets",
                              children: te.map((t) =>
                                e.jsx(
                                  w,
                                  {
                                    type: "button",
                                    size: "sm",
                                    variant:
                                      r.sheetMode === t.id
                                        ? "default"
                                        : "outline",
                                    "aria-pressed": r.sheetMode === t.id,
                                    onClick: () => u("sheetMode", t.id),
                                    children: t.label,
                                  },
                                  t.id,
                                ),
                              ),
                            }),
                          ],
                        }),
                        e.jsxs("label", {
                          className: "flex items-center gap-2 text-sm",
                          children: [
                            e.jsx("input", {
                              type: "checkbox",
                              checked:
                                r.joinContinued && r.sheetMode !== "page",
                              disabled: r.sheetMode === "page",
                              onChange: (t) =>
                                u("joinContinued", t.target.checked),
                            }),
                            "Join a table that continues on the next page",
                          ],
                        }),
                        e.jsxs("label", {
                          className: "flex items-center gap-2 text-sm",
                          children: [
                            e.jsx("input", {
                              type: "checkbox",
                              checked: r.convertValues,
                              onChange: (t) =>
                                u("convertValues", t.target.checked),
                            }),
                            "Write numbers and dates as real values (so they can be summed and sorted)",
                          ],
                        }),
                        r.convertValues &&
                          e.jsxs("div", {
                            className:
                              "flex flex-wrap items-center gap-2 text-sm pl-6",
                            children: [
                              e.jsx("label", {
                                htmlFor: "date-order",
                                className: "text-muted-foreground",
                                children: "Dates like 09/02/2026 are:",
                              }),
                              e.jsx("select", {
                                id: "date-order",
                                value: r.dateOrder,
                                onChange: (t) => u("dateOrder", t.target.value),
                                className:
                                  "h-9 rounded-md border bg-background px-2 text-sm",
                                children: se.map((t) =>
                                  e.jsx(
                                    "option",
                                    { value: t.id, children: t.label },
                                    t.id,
                                  ),
                                ),
                              }),
                            ],
                          }),
                        e.jsxs("label", {
                          className: "flex items-center gap-2 text-sm",
                          children: [
                            e.jsx("input", {
                              type: "checkbox",
                              checked: r.ocr,
                              onChange: (t) => u("ocr", t.target.checked),
                            }),
                            "Read scanned pages with OCR (pages with no selectable text)",
                          ],
                        }),
                        r.ocr &&
                          e.jsxs("div", {
                            className:
                              "flex flex-wrap items-center gap-2 text-sm pl-6",
                            children: [
                              e.jsx("label", {
                                htmlFor: "ocr-language",
                                className: "text-muted-foreground",
                                children: "Language of scanned pages:",
                              }),
                              e.jsx("select", {
                                id: "ocr-language",
                                value: r.ocrLanguage,
                                onChange: (t) =>
                                  u("ocrLanguage", t.target.value),
                                className:
                                  "h-9 rounded-md border bg-background px-2 text-sm",
                                children: J.map((t) =>
                                  e.jsx(
                                    "option",
                                    { value: t.id, children: t.label },
                                    t.id,
                                  ),
                                ),
                              }),
                            ],
                          }),
                      ],
                    }),
                    j &&
                      e.jsx(v, {
                        className:
                          "p-3 border-red-300 bg-red-50 dark:bg-red-950/30",
                        role: "alert",
                        children: e.jsxs("div", {
                          className: "flex gap-2",
                          children: [
                            e.jsx(U, {
                              className: "h-4 w-4 text-red-600 shrink-0 mt-0.5",
                            }),
                            e.jsxs("p", {
                              className:
                                "text-sm text-red-800 dark:text-red-300",
                              children: [
                                j,
                                j === D &&
                                  e.jsxs(e.Fragment, {
                                    children: [
                                      " ",
                                      e.jsx(k, {
                                        href: "/tool/unlock-pdf",
                                        className: "underline",
                                        children: "Open Unlock PDF",
                                      }),
                                      ".",
                                    ],
                                  }),
                              ],
                            }),
                          ],
                        }),
                      }),
                    c?.kind === "none" &&
                      o &&
                      e.jsxs(v, {
                        className: "p-4 space-y-2",
                        role: "status",
                        children: [
                          e.jsx("p", {
                            className: "text-sm font-medium",
                            children:
                              c.reason === "no-text"
                                ? "No readable text was found in this PDF."
                                : "No tables were found in this PDF.",
                          }),
                          e.jsx("p", {
                            className: "text-sm text-muted-foreground",
                            children:
                              c.reason === "no-text"
                                ? r.ocr
                                  ? "The pages look like pictures and OCR could not read any text from them. A clearer scan may help, and the language setting must match the document."
                                  : "The pages have no selectable text (they look like scans). Turn on “Read scanned pages with OCR” above and extract again."
                                : `Looked at ${i(o.pages, "page")}. A table needs at least three rows whose columns line up; ordinary paragraphs, lists and two-column text are not treated as tables.`,
                          }),
                          e.jsxs("p", {
                            className: "text-sm text-muted-foreground",
                            children: [
                              "For a document that is mostly text, try ",
                              e.jsx(k, {
                                href: "/tool/pdf-to-word",
                                className: "underline text-primary",
                                children: "PDF to Word",
                              }),
                              " or ",
                              e.jsx(k, {
                                href: "/tool/extract-pdf",
                                className: "underline text-primary",
                                children: "Extract Pages & Text",
                              }),
                              ".",
                            ],
                          }),
                        ],
                      }),
                    c?.kind === "ok" && o
                      ? e.jsxs("div", {
                          className: "space-y-4",
                          children: [
                            e.jsxs(v, {
                              className: "p-4 space-y-2",
                              "aria-live": "polite",
                              children: [
                                e.jsxs("p", {
                                  className: "text-sm font-medium",
                                  children: [
                                    i(o.tables, "table"),
                                    " found · ",
                                    i(o.rows, "row"),
                                    " in ",
                                    i(o.sheets, "sheet"),
                                  ],
                                }),
                                e.jsx("p", {
                                  className: "text-xs text-muted-foreground",
                                  children:
                                    o.numericCells > 0 || o.dateCells > 0
                                      ? `${i(o.numericCells, "number")}${o.dateCells ? ` and ${i(o.dateCells, "date")}` : ""} written as real values.`
                                      : r.convertValues
                                        ? "No numeric or date columns were recognised, so everything is text."
                                        : "Everything was written as text, as chosen.",
                                }),
                                o.joined.map(([t, a]) =>
                                  e.jsxs(
                                    "p",
                                    {
                                      className:
                                        "text-xs text-muted-foreground",
                                      children: [
                                        "A table that continues over pages ",
                                        t,
                                        "–",
                                        a,
                                        " was joined into one.",
                                      ],
                                    },
                                    `${t}-${a}`,
                                  ),
                                ),
                                o.notes.map((t) =>
                                  e.jsxs(
                                    z,
                                    {
                                      className: "text-xs flex gap-1.5",
                                      children: [
                                        e.jsx(ee, {
                                          className:
                                            "h-3.5 w-3.5 shrink-0 mt-0.5",
                                        }),
                                        t,
                                      ],
                                    },
                                    t,
                                  ),
                                ),
                              ],
                            }),
                            e.jsxs("div", {
                              className: "flex flex-wrap gap-3",
                              children: [
                                e.jsx(W, {
                                  blob: c.blob,
                                  fileName: `${q(E.forFile)}.xlsx`,
                                  label: "Download Excel File",
                                }),
                                e.jsx(w, {
                                  variant: "outline",
                                  onClick: F,
                                  children: "Convert Another",
                                }),
                              ],
                            }),
                            e.jsx("div", {
                              className: "space-y-3",
                              "aria-label": "Preview of the workbook",
                              children: c.preview.map((t) =>
                                e.jsxs(
                                  "details",
                                  {
                                    open: c.preview.length <= 3,
                                    className: "rounded-lg border p-3",
                                    children: [
                                      e.jsxs("summary", {
                                        className:
                                          "cursor-pointer text-sm font-medium",
                                        children: [
                                          t.name,
                                          " — ",
                                          i(t.rowCount, "row"),
                                          " × ",
                                          i(t.columnCount, "column"),
                                          t.tableCount > 1
                                            ? ` (${t.tableCount} tables)`
                                            : "",
                                        ],
                                      }),
                                      e.jsxs("div", {
                                        className: "mt-2 overflow-x-auto",
                                        children: [
                                          e.jsx("table", {
                                            className:
                                              "text-xs border-collapse",
                                            children: e.jsx("tbody", {
                                              children: t.rows.map((a, n) =>
                                                e.jsx(
                                                  "tr",
                                                  {
                                                    className:
                                                      n < t.headerRows
                                                        ? "font-semibold bg-muted/50"
                                                        : "",
                                                    children: a.map((d, $) =>
                                                      e.jsx(
                                                        "td",
                                                        {
                                                          className: `border px-1.5 py-0.5 whitespace-nowrap ${d.numeric ? "text-right tabular-nums" : ""}`,
                                                          children: d.text,
                                                        },
                                                        $,
                                                      ),
                                                    ),
                                                  },
                                                  n,
                                                ),
                                              ),
                                            }),
                                          }),
                                          t.rowCount > t.rows.length &&
                                            e.jsxs("p", {
                                              className:
                                                "mt-1 text-xs text-muted-foreground",
                                              children: [
                                                "Showing the first ",
                                                t.rows.length,
                                                " of ",
                                                t.rowCount,
                                                " rows.",
                                              ],
                                            }),
                                        ],
                                      }),
                                    ],
                                  },
                                  t.name,
                                ),
                              ),
                            }),
                          ],
                        })
                      : e.jsxs("div", {
                          className: "flex gap-3",
                          children: [
                            e.jsx(w, {
                              onClick: A,
                              children: "Extract Tables",
                            }),
                            e.jsx(w, {
                              variant: "outline",
                              onClick: F,
                              children: "Reset",
                            }),
                          ],
                        }),
                  ],
                }),
          ],
        })
      : e.jsx(I, {
          gateAtDownload: !0,
          accept: ".pdf",
          onFiles: R,
          label: "Drop a PDF with tables",
          description:
            "Extract table data to Excel — processed entirely in your browser",
        }),
  });
}
export { Ve as default };
//# sourceMappingURL=PdfToExcel-DmJuyFug.js.map
