import { O as f } from "./utils-s8ucLyj8.js";
function T(o, t) {
  const i = o.replace(/^[A-Z]{6}\+/, "").toLowerCase(),
    r =
      !!t?.bold ||
      /bold|heavy|black|semibold|demibold|extrabold|-bd\b|,bd\b/.test(i),
    e = !!t?.italic || /italic|oblique|-it\b|,it\b|-ital\b/.test(i);
  return { bold: r, italic: e };
}
function G(o) {
  const t = o
    .replace(/^[A-Z]{6}\+/, "")
    .toLowerCase()
    .replace(/[\s_]/g, "");
  if (/arial|helvetica|liberationsans|arimo|nimbussans/.test(t)) return "Arial";
  if (/timesnewroman|times|liberationserif|tinos|nimbusroman/.test(t))
    return "Times New Roman";
  if (/couriernew|courier|liberationmono|cousine|nimbusmono/.test(t))
    return "Courier New";
  if (/calibri|carlito/.test(t)) return "Calibri";
  if (/cambria|caladea/.test(t)) return "Cambria";
  if (/verdana/.test(t)) return "Verdana";
  if (/tahoma/.test(t)) return "Tahoma";
  if (/georgia/.test(t)) return "Georgia";
  if (/trebuchet/.test(t)) return "Trebuchet MS";
  if (/segoeui/.test(t)) return "Segoe UI";
  if (/consolas/.test(t)) return "Consolas";
  if (/garamond/.test(t)) return "Garamond";
  if (/palatino|bookantiqua/.test(t)) return "Palatino Linotype";
  if (/centurygothic/.test(t)) return "Century Gothic";
}
const d = (o) =>
  Math.max(0, Math.min(255, Math.round(o)))
    .toString(16)
    .padStart(2, "0");
function L(o, t) {
  const i = t?.[0];
  if (typeof i == "string") {
    const e = /^#?([0-9a-f]{6})$/i.exec(i.trim());
    return e ? e[1].toLowerCase() : void 0;
  }
  const r = (t ?? []).filter((e) => typeof e == "number" && Number.isFinite(e));
  if (o === f.setFillGray && r.length >= 1) {
    const e = r[0] <= 1 ? r[0] * 255 : r[0];
    return d(e) + d(e) + d(e);
  }
  if (o === f.setFillRGBColor && r.length >= 3) {
    const e = r.every((s) => s <= 1) ? 255 : 1;
    return d(r[0] * e) + d(r[1] * e) + d(r[2] * e);
  }
  if (o === f.setFillCMYKColor && r.length >= 4) {
    const [e, s, u, m] = r;
    return (
      d(255 * (1 - e) * (1 - m)) +
      d(255 * (1 - s) * (1 - m)) +
      d(255 * (1 - u) * (1 - m))
    );
  }
}
const C = (o, t, i) => [o[0] * t + o[2] * i + o[4], o[1] * t + o[3] * i + o[5]];
function B(o, t) {
  const i = [
      C(o, t[0], t[1]),
      C(o, t[2], t[1]),
      C(o, t[2], t[3]),
      C(o, t[0], t[3]),
    ],
    r = i.map((s) => s[0]),
    e = i.map((s) => s[1]);
  return [Math.min(...r), Math.min(...e), Math.max(...r), Math.max(...e)];
}
const k = (o) => /\s/.test(o);
function R(o) {
  const t = [],
    i = [];
  let r;
  for (let e = 0; e < o.fnArray.length; e++) {
    const s = o.fnArray[e],
      u = o.argsArray[e];
    if (s === f.save) i.push(r);
    else if (s === f.restore) r = i.pop();
    else if (
      s === f.setFillGray ||
      s === f.setFillRGBColor ||
      s === f.setFillCMYKColor
    )
      r = L(s, u ?? []);
    else if (
      s === f.setFillColorSpace ||
      s === f.setFillColor ||
      s === f.setFillColorN
    )
      r = void 0;
    else if (s === f.showText || f.showSpacedText === s) {
      const m = u?.[0];
      if (!Array.isArray(m)) continue;
      const x = r === "000000" ? void 0 : r;
      for (const b of m)
        if (b && typeof b == "object" && typeof b.unicode == "string")
          for (const M of Array.from(b.unicode)) k(M) || t.push(x);
    }
  }
  return t;
}
const O = (o) => Array.from(o).filter((t) => !k(t)).length;
function V(o, t) {
  if (o.reduce((s, u) => s + O(u), 0) !== t.length) return;
  const r = [];
  let e = 0;
  for (const s of o) {
    const u = O(s);
    (r.push(u > 0 ? t[e] : void 0), (e += u));
  }
  return r;
}
function j(o) {
  if (!o || o.subtype !== "Widget" || o.pushButton) return "";
  const t = o.fieldValue;
  return o.checkBox
    ? t != null && t !== "" && t !== "Off" && t !== !1
      ? "☒"
      : "☐"
    : o.radioButton
      ? t != null && t !== "Off" && t === o.buttonValue
        ? "◉"
        : "○"
      : Array.isArray(t)
        ? t.filter((i) => typeof i == "string" && i).join(", ")
        : typeof t == "string"
          ? t.replace(/\r\n|\r|\n/g, " ").trim()
          : "";
}
async function I(o) {
  const t = o.getViewport({ scale: 1 }),
    i = t.transform,
    r = t.width,
    e = t.height;
  let s = !1;
  const [u, m, x] = await Promise.all([
      o.getTextContent(),
      o.getOperatorList(),
      o
        .getAnnotations({ intent: "display" })
        .catch(
          (n) => (
            (s = !0),
            console.warn(
              "readPageContent: couldn't read links and form fields",
              n,
            ),
            []
          ),
        ),
    ]),
    b = new Map(),
    M = (n) => {
      let h = b.get(n);
      if (h) return h;
      let a = "",
        p = {};
      try {
        const l = o.commonObjs.has(n) ? o.commonObjs.get(n) : null;
        l &&
          ((a = String(l.name ?? "")),
          (p = { bold: !!l.bold, italic: !!l.italic }));
      } catch {}
      return ((h = { ...T(a, p), font: a ? G(a) : void 0 }), b.set(n, h), h);
    },
    A = u.items
      .filter((n) => typeof n.str == "string" && Array.isArray(n.transform))
      .map((n) => ({ it: n, str: n.str })),
    P = V(
      A.map((n) => n.str),
      R(m),
    ),
    w = [];
  A.forEach((n, h) => {
    if (n.str.trim().length === 0) return;
    const a = n.it.transform,
      [p, v] = C(i, a[4], a[5]),
      l = i[0] * a[0] + i[2] * a[1],
      c = i[1] * a[0] + i[3] * a[1],
      y = Math.hypot(a[2], a[3]) || Math.hypot(a[0], a[1]) || 10,
      F = Math.abs(c) > 0.08 * Math.abs(l) || l < 0,
      g = M(n.it.fontName);
    w.push({
      str: n.str,
      x: p,
      baseline: v,
      width: typeof n.it.width == "number" ? n.it.width : 0,
      size: y,
      bold: g.bold,
      italic: g.italic,
      font: g.font,
      color: P?.[h],
      rotated: F || void 0,
    });
  });
  const S = w.length > 0;
  for (const n of x) {
    if (!n?.rect) continue;
    const [h, a, p, v] = B(i, n.rect);
    if (n.subtype === "Link") {
      const l = n.url || n.unsafeUrl;
      if (!l || !/^(https?:|mailto:|tel:)/i.test(l)) continue;
      for (const c of w) {
        if (c.rotated || c.synthetic) continue;
        const y = c.x,
          F = c.x + c.width,
          g = Math.min(F, p + 1) - Math.max(y, h - 1);
        c.baseline >= a - 2 &&
          c.baseline - c.size * 0.7 <= v + 2 &&
          g > 0 &&
          g >= Math.min(c.width, p - h) * 0.5 &&
          (c.link = l);
      }
    } else if (n.subtype === "Widget") {
      const l = j(n);
      if (!l) continue;
      const c = v - a,
        y = Math.max(8, Math.min(11, c * 0.7));
      w.push({
        str: l,
        x: h + 2,
        baseline: a + c / 2 + y * 0.32,
        width: l.length * y * 0.5,
        size: y,
        bold: !1,
        italic: !1,
        synthetic: !0,
      });
    }
  }
  return {
    widthPt: r,
    heightPt: e,
    items: w,
    hasText: S,
    annotationsFailed: s || void 0,
  };
}
export { I as r };
//# sourceMappingURL=pdfPageContent-BLgAwNtO.js.map
