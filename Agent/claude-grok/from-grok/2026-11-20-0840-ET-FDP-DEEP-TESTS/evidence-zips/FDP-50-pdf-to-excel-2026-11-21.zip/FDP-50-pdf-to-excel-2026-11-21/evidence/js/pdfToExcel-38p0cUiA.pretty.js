import { s as O } from "./index-DQo6ttmA.js";
import { r as $ } from "./pdfPageContent-BLgAwNtO.js";
import { e as I, r as S } from "./utils-s8ucLyj8.js";
import { preprocessForOcr as W } from "./ocrImage-CmXFNUud.js";
import { D, o as F, d as L, b as v } from "./tablesToExcel-C1ZZUvmI.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./pdfLayout-BswErtWz.js";
import "./xlsx-CNerDvZX.js";
class w extends Error {
  constructor() {
    super("cancelled");
  }
}
const j = { ...D, ocr: !0, ocrLanguage: "eng" },
  z = 3;
async function q(g, o, t) {
  const i = () => {
      if (!t.isCurrent()) throw new w();
    },
    n = g.numPages,
    c = [],
    d = new Set();
  let u = 0,
    a = null,
    l = 0;
  try {
    for (let r = 0; r < n; r++) {
      (t.status(`Reading page ${r + 1} of ${n}…`), t.progress(r / n));
      const p = await g.getPage(r + 1);
      i();
      const s = await $(p);
      if ((i(), s.hasText || !o.ocr)) {
        (s.hasText || u++, c.push(s));
        continue;
      }
      if (!a) {
        t.status("Starting OCR (first use downloads the language data)…");
        try {
          a = await O.createWorker(o.ocrLanguage, 1, {
            logger: (e) => {
              !t.isCurrent() ||
                typeof e.progress != "number" ||
                (e.status === "recognizing text"
                  ? (t.progress((l + e.progress) / n),
                    t.status(
                      `Reading scanned page ${l + 1} of ${n} with OCR… ${Math.round(e.progress * 100)}%`,
                    ))
                  : /loading|initializ/i.test(e.status ?? "") &&
                    t.status(
                      `Starting OCR, preparing the language data… ${Math.round(e.progress * 100)}%`,
                    ));
            },
          });
        } catch (e) {
          throw t.isCurrent()
            ? (console.error("OCR engine failed to start", e),
              new Error(
                "The OCR engine couldn't start. It downloads its language data the first time it is used, so it needs an internet connection; check yours and try again.",
              ))
            : new w();
        }
        if (!t.isCurrent())
          throw (await a.terminate().catch(() => {}), (a = null), new w());
        (t.registerWorker(a),
          await a.setParameters({ tessedit_pageseg_mode: O.PSM.AUTO }),
          i());
      }
      ((l = r), t.status(`Reading scanned page ${r + 1} of ${n} with OCR…`));
      const x = s.widthPt * s.heightPt,
        R = await I(p).catch(() => ({ images: [], failed: 0 }));
      i();
      const m = R.images
          .filter(
            (e) =>
              e.position.widthPt * e.position.heightPt >= 0.5 * x &&
              !e.fromRender,
          )
          .sort(
            (e, C) =>
              C.position.widthPt * C.position.heightPt -
              e.position.widthPt * e.position.heightPt,
          )[0],
        E = m ? m.blob : await S(p, 3, 0.92);
      i();
      const f = await W(E);
      i();
      const h = await createImageBitmap(f),
        { width: b, height: y } = h;
      (h.close?.(), i());
      const _ = (await a.recognize(f, {}, { text: !0, blocks: !0 })).data;
      i();
      const P = F(_, s.widthPt / b, s.heightPt / y);
      P.length >= z
        ? (d.add(r + 1), c.push({ ...s, items: P, hasText: !0 }))
        : (u++, c.push(s));
    }
    (t.status("Finding tables…"), t.progress(0.9));
    const T = L(c, d, o);
    return (
      t.status("Building the workbook…"),
      t.progress(0.97),
      v(
        T,
        {
          pages: n,
          ocrPages: d.size,
          unreadPages: u,
          ocrEnabled: o.ocr,
          anyText: c.some((r) => r.hasText),
        },
        o,
      )
    );
  } finally {
    if (a) {
      t.registerWorker(null);
      try {
        await a.terminate();
      } catch {}
    }
  }
}
export {
  j as DEFAULT_RUN_OPTIONS,
  w as ExcelConversionCancelled,
  q as convertPdfToExcelDocument,
};
//# sourceMappingURL=pdfToExcel-38p0cUiA.js.map
