# FDP-50: dump each downloaded workbook: sheets, dims, cell types/formats for the first rows, formulas present?
import openpyxl, glob, sys, zipfile, re
for f in sorted(glob.glob(sys.argv[1] if len(sys.argv) > 1 else '*.xlsx')):
    z = zipfile.ZipFile(f); xml = ''.join(z.read(n).decode('utf8', 'ignore') for n in z.namelist() if n.startswith('xl/worksheets/'))
    wb = openpyxl.load_workbook(f)
    print('==', f, '| sheets', wb.sheetnames, '| formulas(<f>)', len(re.findall(r'<f>', xml)), '| autofilter', 'autoFilter' in xml)
    for ws in wb.worksheets[:3]:
        print('  [%s] %s' % (ws.title, ws.dimensions))
        for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, int(sys.argv[2]) if len(sys.argv) > 2 else 6)):
            print('   ', ' | '.join(f"{c.value!r}:{c.data_type}{'/'+c.number_format if c.data_type=='n' or c.is_date else ''}" for c in row))
