// FDP-50 PDF to Excel, guest. Usage: node px-live.js <zero|left|subset> [engine]   (TRIES env = fresh contexts to try for "left")
// zero: context at the cap -> extract (preview at 0), Download/Drive/cloud dialogs, Day Pass (stops at email), Quick Buy (stops at Stripe), keyboard.
// left: context with uses left -> many cases with downloads in ONE page load (per-page-load check), then reload + downloads.
// Never types an email/card, never clicks a pass "Continue", never clicks ads. The only password typed is the test PDF's own (u123).
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const crypto = require('crypto');
const BASE = '/workspace/deep/50-pdf-to-excel/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/pdf-to-excel';
const mode = process.argv[2] || 'left'; const eng = process.argv[3] || 'chromium'; const sfx = eng === 'chromium' ? '' : '-' + eng;
fs.mkdirSync(OUT + 'downloads', { recursive: true }); fs.mkdirSync(OUT + 'cases', { recursive: true });
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex').slice(0, 16);
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').replace(/dev[:%][^&"]*/g, 'dev:REDACTED').slice(0, 160);
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p; const net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true, locale: 'en-US' }); p = await c.newPage(); p.setDefaultTimeout(15000);
  await p.addInitScript(() => { window.__t = []; const seen = new WeakSet(); setInterval(() => { document.querySelectorAll('[data-sonner-toast]').forEach(n => { if (!seen.has(n)) { seen.add(n); window.__t.push((n.innerText || '').trim()); } }); }, 150); });
  p.on('request', r => { const d = r.postData() || ''; if (r.method() === 'POST') net.push({ t: Date.now(), u: red(r.url()), len: d.length, doc: /%PDF|Jane Doe|Payment ref|Invoice Amount/.test(d) }); else if (/jsdelivr|tesseract|traineddata/.test(r.url())) net.push({ t: Date.now(), u: red(r.url()), get: true }); });
  await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000); };
 const used = () => p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 const state = () => p.evaluate(() => { const m = document.querySelector('main'); const t = m.innerText;
  const s = t.indexOf('Options'); const e = t.indexOf('NEXT STEP'); const body = t.slice(s >= 0 ? s : 0, e > 0 ? e : s + 4000);
  return { summary: (body.match(/\d+ tables? found[^\n]*/) || [''])[0], after: body.slice(body.search(/\d+ tables? found|No tables|Extraction failed|no selectable|could not read/), body.search(/Download Excel File|Convert Another|Extract Tables/)).slice(0, 900),
   preview: [...m.querySelectorAll('[aria-label="Preview of the workbook"] table')].map(tb => ({ cap: tb.closest('details')?.querySelector('summary')?.innerText?.trim(), rows: [...tb.querySelectorAll('tr')].slice(0, 9).map(tr => [...tr.children].map(td => td.innerText.trim())) })).slice(0, 6),
   buttons: [...m.querySelectorAll('button')].map(x => x.innerText.trim()).filter(x => /Download|Drive|cloud|Extract|Convert Another|Reset|Unlock/.test(x)) }; });
 const reset = async () => { for (const n of ['Convert Another', 'Reset']) { const bt = p.locator('main button', { hasText: new RegExp('^' + n + '$') }); if (await bt.count()) { await bt.first().click(); await p.waitForTimeout(500); } } const cn = p.getByRole('button', { name: 'Cancel', exact: true }); if (await cn.count()) await cn.first().click().catch(() => {}); };
 const extract = async (f, o = {}, r = {}) => { await reset(); await p.locator('main input[type=file]').first().setInputFiles(TF + f); await p.waitForTimeout(1500);
  if (o.pw) { r.pwDialog = await dialog(); const pf = p.locator('[role=dialog] input[type=password]'); if (await pf.count()) { await pf.fill(o.pw); await p.getByRole('button', { name: 'Unlock' }).click(); await p.waitForTimeout(2500); } }
  if (o.sheet) { await p.locator('main button', { hasText: new RegExp('^' + o.sheet + '$') }).first().click(); await p.waitForTimeout(200); }
  for (const [lbl, val] of (o.checks || [])) { const cb = p.getByLabel(lbl); if ((await cb.isChecked()) !== val) await cb.click(); }
  if (o.date) await p.locator('#date-order').selectOption({ label: o.date });
  const t0 = Date.now(); await p.getByRole('button', { name: 'Extract Tables' }).click();
  await p.waitForFunction(() => /tables? found|No tables|Extraction failed|no selectable text|could not read any text|couldn't start/i.test(document.querySelector('main').innerText), null, { timeout: o.wait || 60000 }).catch(() => r.timeout = true);
  r.ms = Date.now() - t0; await p.waitForTimeout(800); r.state = await state(); };
 const download = async (id, r) => { const bt = p.locator('main button', { hasText: /^Download Excel File/ }).first(); if (!(await bt.count())) { r.dl = 'absent'; return; }
  const dp = p.waitForEvent('download', { timeout: 15000 }).catch(() => null); await bt.click(); const d = await dp; await p.waitForTimeout(1500);
  r.dialog = await dialog(); if (d) { const f = OUT + 'downloads/' + id + sfx + '-' + d.suggestedFilename(); await d.saveAs(f); r.download = { name: d.suggestedFilename(), bytes: fs.statSync(f).size, sha: sha(f) }; }
  if (r.dialog) { await p.screenshot({ path: OUT + 'cases/' + id + sfx + '-dialog.png' }); if (mode === 'zero' && !R.dayPass) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.dayPass = { dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'dlg-daypass' + sfx + '.png' }); } } await esc(); } };
 const run = async (id, f, o = {}, dl = true) => { const r = { id, f, o, t: now(), before: await used() }; const tN = await p.evaluate(() => (window.__t || []).length);
  try { await extract(f, o, r); if (dl) await download(id, r); } catch (e) { r.err = e.message.slice(0, 300); }
  r.afterUsed = await used(); r.toasts = await p.evaluate(n => (window.__t || []).slice(n), tN);
  await p.screenshot({ path: OUT + 'cases/' + id + sfx + '.png', fullPage: !!o.full }).catch(() => {}); R.cases[id] = r; console.log(id, JSON.stringify(r).slice(0, 700)); return r; };
 const act = async (name, loc) => { const r = { before: await used() }; if (!(await loc.count())) { r.missing = true; console.log(name, 'missing'); return r; }
  const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); const url0 = p.url(); await loc.first().click(); const pg = await pop; await p.waitForTimeout(2500);
  r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null; if (pg) { await pg.waitForLoadState('domcontentloaded').catch(() => {}); r.popup = red(pg.url()); await pg.close(); }
  if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + sfx + '.png' }); await esc(); console.log(name, JSON.stringify(r).slice(0, 400)); return r; };
 if (mode === 'zero' || mode === 'subset') { for (let i = 0; i < 8; i++) { await open(); await p.waitForTimeout(2000); const u = await used(); R.tries.push(u); if (u >= 10 || mode === 'subset') break; await c.close(); }
  R.start = await used();
  if (mode === 'zero') { const seq = []; for (let i = 0; i < 40; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 40).replace(/\n/g, ' '); }); seq.push(a); if (/Open from Google Drive/.test(a)) break; } R.kbd = { seq: seq.slice(-5), tabs: seq.length };
   await run('Z01', 'T02_header_words.pdf', { full: true }); await run('Z02', 'T01_bank_3pages_us.pdf', {});
   R.drive = await act('zero-drive', p.getByRole('button', { name: /Save to Google Drive/ })); R.cloud = await act('zero-cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
   await reset(); R.openDrive = await act('zero-open-drive', p.getByRole('button', { name: /Open from Google Drive/ })); R.end = await used();
   await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); const u0 = p.url();
   await p.getByRole('button', { name: 'Quick Buy' }).first().click(); await p.waitForTimeout(3000); R.qbDay = { url: p.url() !== u0 ? red(p.url()) : null, dialog: await dialog(), email: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await esc();
   if (p.url() !== u0) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); }
   await p.getByRole('button', { name: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); R.qbMonth = { url: red(p.url()), title: await p.title() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' }); }
  else { await run('S01', 'T01_bank_3pages_us.pdf'); await run('S02', 'T02_header_words.pdf'); await run('S03', 'T03_german.pdf'); } }
 if (mode === 'left') { const NT = +(process.env.TRIES || 30); for (let i = 0; i < NT; i++) { await open(); const u = await used(); R.tries.push(u); if (u < 10) { await p.waitForTimeout(5000); if ((await used()) < 10) break; } if (i < NT - 1) await c.close(); }
  R.start = await used();
  await run('L01', 'T01_bank_3pages_us.pdf');
  R.drive = await act('drive', p.getByRole('button', { name: /Save to Google Drive/ })); R.cloud = await act('cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
  await run('L01b-redl', 'T01_bank_3pages_us.pdf');
  for (const [id, f, o] of [['L02', 'T02_header_words.pdf'], ['L03', 'T03_german.pdf'], ['L04', 'T04_french.pdf'], ['L05', 'T05_prose_and_table.pdf'], ['L06', 'T06_two_rows.pdf'], ['L07', 'T07_identifiers.pdf'],
    ['L08', 'T08_scanned.pdf', { wait: 180000 }], ['L08b-ocr-off', 'T08_scanned.pdf', { checks: [['Read scanned pages with OCR (pages with no selectable text)', false]] }], ['L09', 'T09_user_password.pdf', { pw: 'u123' }], ['L10', 'T10_no_tables.pdf'],
    ['L11', 'T11_formula_text.pdf'], ['L12', 'T12_cr_dr_codes.pdf'], ['L13', 'T13_multiline.pdf'], ['L14', 'T14_40pages.pdf', { wait: 120000 }], ['L15', 'T15_dates.pdf'], ['L15b-dayfirst', 'T15_dates.pdf', { date: 'Day first (31/12/2026)' }],
    ['L16-perpage', 'T01_bank_3pages_us.pdf', { sheet: 'One sheet per page' }], ['L17-single', 'T01_bank_3pages_us.pdf', { sheet: 'Everything on one sheet' }], ['L18-novalues', 'T01_bank_3pages_us.pdf', { checks: [['Write numbers and dates as real values (so they can be summed and sorted)', false]] }], ['L19', 'T16_truncated.pdf']])
   await run(id, f, o || {});
  R.endLoad = await used(); await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); R.afterReload = await used();
  await run('L20-after-reload', 'T02_header_words.pdf'); await run('L21-after-reload-2', 'T03_german.pdf'); R.end = await used(); }
 R.t2 = now(); R.net = net; fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('tries', R.tries.join(','), 'start', R.start, 'end', R.end); await b.close(); })();
