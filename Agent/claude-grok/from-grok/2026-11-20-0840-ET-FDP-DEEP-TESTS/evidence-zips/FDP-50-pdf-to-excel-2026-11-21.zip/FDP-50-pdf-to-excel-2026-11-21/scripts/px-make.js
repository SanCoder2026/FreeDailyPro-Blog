// FDP-50: build test PDFs with real text tables via Chromium page.pdf (fonts embedded, selectable text)
const { chromium } = require('playwright'); const fs = require('fs'); const T = '/workspace/deep/50-pdf-to-excel/testfiles/';
const css = `<style>body{font:11px Helvetica,Arial,sans-serif;margin:30px} table{border-collapse:collapse;margin:14px 0} td,th{padding:3px 10px;border-bottom:1px solid #ccc} td.r,th.r{text-align:right} h1{font-size:16px} th{white-space:nowrap} .page{page-break-after:always} .cols{column-count:2;column-gap:30px}</style>`;
const tbl = (head, rows, right = []) => `<table><tr>${head.map((h, i) => `<th class="${right.includes(i) ? 'r' : ''}">${h}</th>`).join('')}</tr>${rows.map(r => `<tr>${r.map((c, i) => `<td class="${right.includes(i) ? 'r' : ''}">${c}</td>`).join('')}</tr>`).join('')}</table>`;
const files = {};
// T01 bank statement over 3 pages, header repeated each page, parentheses negatives, $
{ let pages = ''; let bal = 5000; let n = 0;
  for (let p = 0; p < 3; p++) { const rows = []; for (let i = 0; i < 25; i++) { n++; const d = `${String(1 + (n % 12)).padStart(2, '0')}/${String(1 + (n % 28)).padStart(2, '0')}/2026`; const amt = ((n * 37) % 500) + 0.25; const neg = n % 3 === 0; bal += neg ? -amt : amt; rows.push([d, 'Payment ref ' + (1000 + n), neg ? `($${amt.toFixed(2)})` : `$${amt.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, `$${bal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`]); }
    pages += `<div class="page"><h1>Acme Bank statement page ${p + 1}</h1><p>Account holder: Jane Doe. This statement lists all card and transfer activity.</p>${tbl(['Date', 'Description', 'Amount', 'Balance'], rows, [2, 3])}</div>`; }
  files['T01_bank_3pages_us.pdf'] = pages; }
// T02 numeric columns whose headers contain id-like words
files['T02_header_words.pdf'] = `<h1>Invoices</h1>` + tbl(['Customer', 'Invoice Amount', 'Account Balance', 'Order Total', 'Unit price (no VAT)', 'Number of units', 'Qty'], [['Alpha', '1,200.00', '3,400.50', '99.95', '12.50', '4', '4'], ['Beta', '850.00', '1,250.75', '45.10', '7.25', '10', '10'], ['Gamma', '2,000.00', '0.00', '120.00', '30.00', '2', '2'], ['Delta', '15.00', '500.00', '8.00', '1.00', '1', '1']], [1, 2, 3, 4, 5, 6]);
// T03 German formats
files['T03_german.pdf'] = `<h1>Kontoauszug</h1>` + tbl(['Datum', 'Text', 'Menge', 'Betrag', 'Anteil'], [['21.11.2026', 'Miete', '1.500', '1.234,56 €', '12,5 %'], ['22.11.2026', 'Strom', '2.000', '-89,90 €', '3,0 %'], ['23.11.2026', 'Gehalt', '1', '3.456,00 €', '84,5 %'], ['24.11.2026', 'Wasser', '750', '45,10 €', '0,5 %']], [2, 3, 4]);
// T04 French spaces as thousands
files['T04_french.pdf'] = `<h1>Relevé</h1>` + tbl(['Date', 'Libellé', 'Montant'], [['21/11/2026', 'Loyer', '1 234,56 €'], ['22/11/2026', 'Salaire', '3 456,00 €'], ['23/11/2026', 'Courses', '-89,90 €'], ['24/11/2026', 'Eau', '45,10 €']], [2]);
// T05 table inside prose + two-column text
files['T05_prose_and_table.pdf'] = `<h1>Annual report</h1><div class="cols">${'<p>Revenue grew strongly across all regions this year, led by new customers in Europe and steady renewals in North America. Costs were held flat. </p>'.repeat(6)}</div>` + tbl(['Region', 'Revenue', 'Growth'], [['Europe', '1,250,000', '12.5%'], ['Americas', '2,100,000', '4.0%'], ['Asia', '650,000', '22.1%'], ['Other', '90,000', '-3.2%']], [1, 2]) + `<p>Notes: figures are unaudited.</p>`;
// T06 two-row table
files['T06_two_rows.pdf'] = `<h1>Tiny</h1>` + tbl(['Item', 'Price'], [['Tea', '3.50']], [1]);
// T07 identifiers
files['T07_identifiers.pdf'] = `<h1>Customers</h1>` + tbl(['Name', 'ZIP', 'Phone', 'Card', 'Code', 'Spend'], [['Ann', '02134', '555-0134', '4111 1111 1111 1111', '00123', '10.00'], ['Bob', '10001', '555-0199', '5500 0000 0000 0004', '00456', '20.50'], ['Cy', '94105', '555-0123', '3400 0000 0000 009', '07890', '5.25'], ['Di', '60601', '555-0100', '6011 0000 0000 0004', '01000', '100.00']], [5]);
// T10 prose only
files['T10_no_tables.pdf'] = `<h1>Letter</h1>` + '<p>Dear customer, thank you for your order. We will ship it soon and send a tracking number by email when it leaves our warehouse.</p>'.repeat(10);
// T11 formula-like text
files['T11_formula_text.pdf'] = `<h1>Export</h1>` + tbl(['Field', 'Value', 'Note'], [['A', '=SUM(1+1)', 'formula-like'], ['B', '+1-555-0100', 'phone'], ['C', '@SUM(A1)', 'at sign'], ['D', '=HYPERLINK("http://example.com","x")', 'link']]);
// T12 bank suffixes / currency codes
files['T12_cr_dr_codes.pdf'] = `<h1>Ledger</h1>` + tbl(['Date', 'Entry', 'Amount', 'Fee'], [['2026-11-01', 'Deposit', '1,234.00 CR', 'USD 1.50'], ['2026-11-02', 'Withdrawal', '200.00 DR', 'USD 0.75'], ['2026-11-03', 'Deposit', '50.00 CR', 'USD 0.25'], ['2026-11-04', 'Transfer', '75.25 DR', 'USD 0.50']], [2, 3]);
// T13 multi-line cell
files['T13_multiline.pdf'] = `<h1>Items</h1><table style="width:400px">` + `<tr><th>Item</th><th>Description</th><th class=r>Price</th></tr>` + [['A1', 'A short one', '1.00'], ['A2', 'This description is long enough that it wraps over two or three lines inside its cell in the PDF', '2.00'], ['A3', 'Short', '3.00'], ['A4', 'Another long description that wraps onto a second line here', '4.00']].map(r => `<tr><td>${r[0]}</td><td style="width:220px">${r[1]}</td><td class=r>${r[2]}</td></tr>`).join('') + '</table>';
// T14 large: 40 pages x 40 rows continued
{ let s = ''; let n = 0; for (let p = 0; p < 40; p++) { const rows = []; for (let i = 0; i < 40; i++) { n++; rows.push([String(n), 'SKU-' + (5000 + n), (n * 1.37).toFixed(2), String(n % 9 + 1)]); } s += `<div class="page">${tbl(['Line', 'Item', 'Price', 'Qty'], rows, [2, 3])}</div>`; } files['T14_40pages.pdf'] = s; }
// T15 date formats
files['T15_dates.pdf'] = `<h1>Dates</h1>` + tbl(['Text date', 'Short year', 'Ambiguous', 'ISO'], [['Nov 21, 2026', '21/11/49', '03/04/2026', '2026-11-21'], ['21 Nov 2026', '21/11/50', '05/06/2026', '2026-01-02'], ['Dec 1, 2026', '01/12/26', '07/08/2026', '2026-12-31'], ['1 Jan 2027', '15/01/27', '09/10/2026', '2027-02-28']]);
(async () => { const b = await chromium.launch(); const p = await b.newPage();
 for (const [f, h] of Object.entries(files)) { await p.setContent(`<html><head>${css}</head><body>${h}</body></html>`); await p.pdf({ path: T + f, format: 'Letter', printBackground: true }); }
 // T08: scanned version of T01 page 1 (image-only PDF)
 await p.setViewportSize({ width: 850, height: 1100 }); await p.setContent(`<html><head>${css}</head><body>${files['T01_bank_3pages_us.pdf'].split('</div>')[0]}</div></body></html>`); await p.screenshot({ path: T + '_scan.png' });
 const img = fs.readFileSync(T + '_scan.png').toString('base64'); await p.setContent(`<html><body style="margin:0"><img src="data:image/png;base64,${img}" style="width:8.5in"></body></html>`); await p.pdf({ path: T + 'T08_scanned.pdf', format: 'Letter', margin: { top: 0, bottom: 0, left: 0, right: 0 } }); fs.unlinkSync(T + '_scan.png');
 await b.close(); console.log(fs.readdirSync(T)); })();
