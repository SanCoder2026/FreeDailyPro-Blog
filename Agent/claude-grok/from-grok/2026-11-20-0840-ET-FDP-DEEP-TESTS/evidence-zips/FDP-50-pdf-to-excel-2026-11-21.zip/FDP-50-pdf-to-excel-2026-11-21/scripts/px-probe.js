// FDP-50 probe: load T02 in a guest context, Extract, dump controls + preview (no download)
const { chromium } = require('playwright');
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage();
 await p.goto('https://www.freedailypro.com/tool/pdf-to-excel', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 await p.locator('main input[type=file]').first().setInputFiles('/workspace/deep/50-pdf-to-excel/testfiles/T02_header_words.pdf'); await p.waitForTimeout(2500);
 console.log(JSON.stringify(await p.evaluate(() => [...document.querySelectorAll('main input,main select,main button,main [role=radio],main [role=checkbox],main [role=combobox]')].map(x => [x.tagName, x.type || x.getAttribute('role'), x.id, x.getAttribute('aria-label') || x.innerText?.trim().slice(0, 40) || x.value, x.checked ?? x.getAttribute('aria-checked')]))));
 await p.getByRole('button', { name: 'Extract Tables' }).click(); await p.waitForTimeout(6000);
 const t = await p.evaluate(() => document.querySelector('main').innerText); console.log(t.slice(t.indexOf('Options'), t.indexOf('Options') + 2500));
 console.log(JSON.stringify(await p.evaluate(() => [...document.querySelectorAll('main button')].map(x => x.innerText.trim().slice(0, 40)).filter(Boolean))));
 console.log(await p.evaluate(() => localStorage.getItem('fdp-usage-v1').replace(/dev:[^"]+/, 'dev:R')));
 await p.screenshot({ path: '/workspace/deep/50-pdf-to-excel/live/probe.png', fullPage: true }); await b.close(); })();
