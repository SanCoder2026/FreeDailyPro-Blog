// FDP-50: WebKit gate check. Fresh WebKit contexts: read fdp-usage-v1, extract T02, click Download; record dialog / download / usage requests.
const pw = require('playwright'); const fs = require('fs'); const OUT = '/workspace/deep/50-pdf-to-excel/live/';
const eng = process.argv[2] || 'webkit'; const N = +(process.argv[3] || 3);
(async () => { const b = await pw[eng].launch(); const res = [];
 for (let i = 0; i < N; i++) { const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await c.newPage(); const net = [];
  p.on('request', r => { if (/usage|access|entitle/.test(r.url())) net.push(r.method() + ' ' + r.url().replace(/dev[:%][^&"]*/g, 'dev:REDACTED').replace(/input=[^&]*/, 'input=…').slice(0, 110)); });
  await p.goto('https://www.freedailypro.com/tool/pdf-to-excel', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(6000);
  const ls0 = await p.evaluate(() => (localStorage.getItem('fdp-usage-v1') || '').replace(/dev:[^"]+/, 'dev:REDACTED'));
  const strip = await p.evaluate(() => (document.querySelector('main').innerText.match(/Trial:[^\n]*/) || [''])[0]);
  await p.locator('main input[type=file]').first().setInputFiles('/workspace/deep/50-pdf-to-excel/testfiles/T02_header_words.pdf'); await p.waitForTimeout(1500);
  await p.getByRole('button', { name: 'Extract Tables' }).click(); await p.waitForTimeout(4000);
  const dp = p.waitForEvent('download', { timeout: 12000 }).catch(() => null); await p.locator('main button', { hasText: /^Download Excel File/ }).first().click(); const d = await dp; await p.waitForTimeout(2000);
  const dlg = await p.locator('[role=dialog]').count() ? (await p.locator('[role=dialog]').first().innerText()).slice(0, 120).replace(/\n/g, ' | ') : null;
  let saved = null; if (d) { saved = OUT + `downloads/WKG${i}-${eng}-` + d.suggestedFilename(); await d.saveAs(saved); }
  const ls1 = await p.evaluate(() => (localStorage.getItem('fdp-usage-v1') || '').replace(/dev:[^"]+/, 'dev:REDACTED'));
  await p.screenshot({ path: OUT + `cases/WKG${i}-${eng}.png` }); res.push({ i, strip, ls0, ls1, dialog: dlg, downloaded: !!d, saved: saved && saved.split('/').pop(), net }); console.log(JSON.stringify(res[res.length - 1]).slice(0, 900)); await c.close(); }
 fs.writeFileSync(OUT + `gate-${eng}.json`, JSON.stringify(res, null, 1)); await b.close(); })();
