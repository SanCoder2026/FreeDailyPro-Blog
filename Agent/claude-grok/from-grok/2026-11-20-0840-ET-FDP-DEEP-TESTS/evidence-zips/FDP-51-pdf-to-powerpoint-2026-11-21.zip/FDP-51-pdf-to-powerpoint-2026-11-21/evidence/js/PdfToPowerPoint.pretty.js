const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/pptxgen.es-Bib50waG.js",
      "assets/index-B1CTyGtY.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/index-BJxTAPRn.css",
      "assets/jszip.min-CT0ZA6V1.js",
      "assets/jszip.min-C-FLQHAz.js",
      "assets/_commonjs-dynamic-modules-TDtrdbi3.js",
    ]),
) => i.map((i) => d[i]);
import { r as k, j as l } from "./vendor-react-D01g8YgM.js";
import { T as q } from "./ToolWithSidebar-C7kxZj7O.js";
import { F as U, P as V, D as W } from "./ToolPage-DwLoDncN.js";
import { u as Z, P as J } from "./PdfPageThumbnails-DeGIJGYt.js";
import { ap as Q, B as T, ay as H, f as X } from "./index-B1CTyGtY.js";
import { f as _ } from "./formatFileSize-B-JRDfN5.js";
import { p as v } from "./plural-FIChqbp4.js";
import { b as K } from "./imageInfo--eYLCpIB.js";
import { l as Y } from "./utils-s8ucLyj8.js";
import { T as F, D as ee, P as te } from "./SlideUi-CQJgwyDz.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./legacyDeck-Dmz2TtSU.js";
import "./trpcVanilla-BSVQBMYf.js";
import "./pptxRasterize-CxkExeBE.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./domCapture-Ci6fgcjv.js";
import "./backgroundSafe-DObGz9DE.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./fontkit.es-DA-3qwB1.js";
import "./domTextLines-YXN485C_.js";
import "./pdfMetadata-CcxIhQF2.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./xmlLite-D0-GZ86u.js";
import "./chevron-left-CWH4XvTX.js";
import "./chevron-right-7IYXE5RL.js";
const ae = 0.9,
  oe = [
    [
      /^(arial|arialmt|helvetica|helveticaneue|liberationsans|nimbussans)/i,
      "Arial",
    ],
    [
      /^(timesnewroman|timesnewromanps|times|liberationserif|nimbusroman)/i,
      "Times New Roman",
    ],
    [/^(couriernew|courier|liberationmono|nimbusmono)/i, "Courier New"],
    [/^(calibri|carlito)/i, "Calibri"],
    [/^(cambria|caladea)/i, "Cambria"],
    [/^georgia/i, "Georgia"],
    [/^verdana/i, "Verdana"],
    [/^tahoma/i, "Tahoma"],
    [/^trebuchet/i, "Trebuchet MS"],
    [/^segoeui/i, "Segoe UI"],
    [/^consolas/i, "Consolas"],
    [/^garamond/i, "Garamond"],
    [/^palatino|^bookantiqua/i, "Palatino Linotype"],
    [/^centurygothic/i, "Century Gothic"],
    [/^comicsans/i, "Comic Sans MS"],
    [/^impact/i, "Impact"],
    [/^symbol$/i, "Symbol"],
  ],
  ie = new Set([
    "Arial",
    "Times New Roman",
    "Courier New",
    "Calibri",
    "Cambria",
    "Georgia",
    "Verdana",
    "Tahoma",
    "Trebuchet MS",
    "Segoe UI",
    "Consolas",
    "Garamond",
    "Palatino Linotype",
    "Century Gothic",
    "Comic Sans MS",
    "Impact",
    "Symbol",
    "Calibri Light",
  ]);
function se(t, i) {
  const o = (t ?? "").replace(/^[A-Z]{6}\+/, ""),
    p = /^(g_d\d+_f\d+|f\d+|[A-Za-z]\d+)$/.test(o),
    r = /bold|black|heavy|semibold|demi/i.test(o),
    d = /italic|oblique|slanted/i.test(o),
    m = o
      .replace(
        /[-,](bold|italic|oblique|regular|roman|light|medium|semibold|demibold|black|heavy|book|condensed|narrow)+.*$/i,
        "",
      )
      .replace(/(MT|PS|PSMT|Std|Pro)$/g, "")
      .replace(/[_]/g, " ")
      .trim(),
    a = m.replace(/[\s-]/g, "");
  for (const [s, e] of oe)
    if (s.test(a)) return { face: e, bold: r, italic: d, common: !0 };
  if (!m || p) {
    const s = (i ?? "").toLowerCase();
    return {
      face: s.includes("mono")
        ? "Courier New"
        : s.includes("serif") && !s.includes("sans")
          ? "Times New Roman"
          : "Arial",
      bold: r,
      italic: d,
      common: !0,
    };
  }
  const n = m.replace(/([a-z])([A-Z])/g, "$1 $2");
  return { face: n, bold: r, italic: d, common: ie.has(n) };
}
function ne(t, i, o, p, r) {
  const d = Math.max(0, Math.floor(r.x)),
    m = Math.max(0, Math.floor(r.y)),
    a = Math.min(o, Math.ceil(r.x + r.w)),
    n = Math.min(p, Math.ceil(r.y + r.h));
  let s = 0,
    e = 0,
    c = 0,
    h = 0;
  for (let x = m; x < n; x++)
    for (let b = d; b < a; b++) {
      const g = (x * o + b) * 4;
      Math.abs(t[g] - i[g]) +
        Math.abs(t[g + 1] - i[g + 1]) +
        Math.abs(t[g + 2] - i[g + 2]) >
        120 && ((s += t[g]), (e += t[g + 1]), (c += t[g + 2]), h++);
    }
  if (h === 0) return { color: "000000", changed: 0 };
  const u = (x) =>
    Math.round(x / h)
      .toString(16)
      .padStart(2, "0");
  return { color: (u(s) + u(e) + u(c)).toUpperCase(), changed: h };
}
function re(t) {
  return /\s$/.test(t);
}
function le(t) {
  return /^\s/.test(t);
}
function G(t) {
  const i = [];
  return (
    t.forEach((o, p) => {
      let r = o.text;
      if (p > 0) {
        const a = t[p - 1];
        o.x - (a.x + a.width) > o.fontSize * 0.15 &&
          !re(a.text) &&
          !le(r) &&
          (r = " " + r);
      }
      const d = i[i.length - 1];
      d &&
      d.face === o.face &&
      d.bold === o.bold &&
      d.italic === o.italic &&
      d.color === o.color &&
      Math.abs(d.size - o.fontSize) < 0.6
        ? (d.text += r)
        : i.push({
            text: r,
            face: o.face,
            size: Math.round(o.fontSize * 2) / 2,
            bold: o.bold,
            italic: o.italic,
            color: o.color,
          });
    }),
    i.length &&
      (i[i.length - 1].text = i[i.length - 1].text.replace(/\s+$/, "")),
    i.filter((o) => o.text.length > 0)
  );
}
function ce(t) {
  const i = [],
    o = t.filter((a) => Math.abs(a.angle) < 0.5 && a.text.length > 0);
  for (const a of t.filter((n) => Math.abs(n.angle) >= 0.5 && n.text.trim())) {
    const n = (a.angle * Math.PI) / 180,
      s = a.width,
      e = a.fontSize * 1.2,
      c = a.x + Math.cos(n) * (s / 2) + Math.sin(n) * 0.3 * a.fontSize,
      h = a.baseline + Math.sin(n) * (s / 2) - Math.cos(n) * 0.3 * a.fontSize;
    i.push({
      x: c - s / 2,
      y: h - e / 2,
      w: s,
      h: e,
      lines: [G([a])],
      align: "left",
      lineGap: 0,
      rotate: ((a.angle % 360) + 360) % 360,
    });
  }
  const p = [...o].sort((a, n) => a.baseline - n.baseline || a.x - n.x),
    r = [],
    d = new Set();
  for (const a of p) {
    if (d.has(a)) continue;
    const n = p.filter(
      (c) =>
        !d.has(c) &&
        Math.abs(c.baseline - a.baseline) <= Math.max(1, a.fontSize * 0.3),
    );
    n.sort((c, h) => c.x - h.x);
    let s = [];
    const e = () => {
      if (!s.length) return;
      if (
        s
          .map((h) => h.text)
          .join("")
          .trim()
      ) {
        const h = s[0],
          u = s[s.length - 1];
        r.push({
          items: s,
          x: h.x,
          right: u.x + u.width,
          baseline: h.baseline,
          size: Math.max(...s.map((x) => x.fontSize)),
        });
      }
      s = [];
    };
    for (const c of n) {
      d.add(c);
      const h = s[s.length - 1];
      (h &&
        c.x - (h.x + h.width) > Math.max(h.fontSize, c.fontSize) * 2.2 &&
        e(),
        s.push(c));
    }
    e();
  }
  r.sort((a, n) => a.baseline - n.baseline || a.x - n.x);
  const m = [];
  for (const a of r) {
    let n;
    for (const s of m) {
      const e = s.lines[s.lines.length - 1],
        c = a.baseline - e.baseline,
        h = Math.abs(a.size - e.size) <= Math.max(0.8, e.size * 0.1),
        u = c > 0 && c <= e.size * 1.75,
        x = a.x < e.right && a.right > e.x,
        b = Math.abs(a.x - e.x) <= e.size * 0.6,
        g = Math.abs((a.x + a.right) / 2 - (e.x + e.right) / 2) <= e.size * 0.6,
        y = Math.abs(a.right - e.right) <= e.size * 0.6;
      if (h && u && x && (b || g || y)) {
        n = s;
        break;
      }
    }
    n ? n.lines.push(a) : m.push({ lines: [a] });
  }
  for (const a of m) {
    const n = a.lines,
      s = Math.max(...n.map((b) => b.size)),
      e = Math.min(...n.map((b) => b.x)),
      c = Math.max(...n.map((b) => b.right)),
      h = n.slice(1).map((b, g) => b.baseline - n[g].baseline),
      u = h.length ? h.reduce((b, g) => b + g, 0) / h.length : 0;
    let x = "left";
    if (n.length > 1) {
      const b = n.map((f) => f.x),
        g = n.map((f) => f.right),
        y = n.map((f) => (f.x + f.right) / 2),
        w = (f) => Math.max(...f) - Math.min(...f);
      w(b) > s * 0.3 &&
        (w(y) <= s * 0.3 ? (x = "center") : w(g) <= s * 0.3 && (x = "right"));
    }
    i.push({
      x: e,
      y: n[0].baseline - s * ae,
      w: c - e,
      h: (n.length - 1) * u + s * 1.2,
      lines: n.map((b) => G(b.items)),
      align: x,
      lineGap: u,
      rotate: 0,
    });
  }
  return i.sort((a, n) => a.y - n.y || a.x - n.x);
}
function L(t, i) {
  let o = t / 72,
    p = i / 72;
  const r = Math.max(o, p),
    d = r < 4 ? 4 / r : r > 56 ? 56 / r : 1;
  return (
    (o *= d),
    (p *= d),
    { w: Math.round(o * 1e3) / 1e3, h: Math.round(p * 1e3) / 1e3 }
  );
}
function de(t, i, o) {
  const p = t.w / t.h,
    r = i / o;
  if (Math.abs(p - r) / p < 0.005)
    return { slideW: t.w, slideH: t.h, k: t.w / i, ox: 0, oy: 0, exact: !0 };
  const d = Math.min(t.w / i, t.h / o);
  return {
    slideW: t.w,
    slideH: t.h,
    k: d,
    ox: (t.w - i * d) / 2,
    oy: (t.h - o * d) / 2,
    exact: !1,
  };
}
async function he(t, i = {}) {
  if (t.length === 0) throw new Error("This PDF has no pages to convert.");
  const { default: o } = await Q(
      async () => {
        const { default: s } = await import("./pptxgen.es-Bib50waG.js");
        return { default: s };
      },
      __vite__mapDeps([0, 1, 2, 3, 4, 5, 6]),
    ),
    p = L(t[0].widthPt, t[0].heightPt),
    r = new o();
  (r.defineLayout({ name: "PDF_PAGE", width: p.w, height: p.h }),
    (r.layout = "PDF_PAGE"),
    (r.author = ""),
    (r.company = ""),
    (r.subject = ""),
    (r.title = i.title?.trim() || "Converted PDF"));
  let d = 0,
    m = 0;
  const a = new Set();
  for (const s of t) {
    const e = de(p, s.widthPt, s.heightPt),
      c = r.addSlide(),
      h = `image/jpeg;base64,${K(s.image)}`;
    ((c.background = { color: "FFFFFF" }),
      e.exact
        ? (c.background = { data: h })
        : (m++,
          c.addImage({
            data: h,
            x: e.ox,
            y: e.oy,
            w: s.widthPt * e.k,
            h: s.heightPt * e.k,
            altText: "Page picture",
          })));
    for (const u of s.blocks) {
      const x = [];
      if (
        (u.lines.forEach((g, y) => {
          g.forEach((w, f) => {
            (/^(Arial|Times New Roman|Courier New|Calibri|Cambria|Georgia|Verdana|Tahoma|Trebuchet MS|Segoe UI|Consolas|Garamond|Palatino Linotype|Century Gothic|Comic Sans MS|Impact|Symbol)$/.test(
              w.face,
            ) || a.add(w.face),
              x.push({
                text: w.text,
                options: {
                  fontFace: w.face,
                  fontSize: Math.max(4, Math.round(w.size * e.k * 72 * 2) / 2),
                  bold: w.bold || void 0,
                  italic: w.italic || void 0,
                  color: w.color,
                  breakLine:
                    f === g.length - 1 && y < u.lines.length - 1 ? !0 : void 0,
                },
              }));
          });
        }),
        !x.length)
      )
        continue;
      const b =
        u.lines.length > 1 && u.lineGap > 0
          ? Math.max(
              0.7,
              Math.min(
                3,
                u.lineGap / (Math.max(...u.lines[0].map((g) => g.size)) * 1.2),
              ),
            )
          : void 0;
      (c.addText(x, {
        x: e.ox + u.x * e.k,
        y: e.oy + u.y * e.k,
        w: Math.max(0.1, (u.w * 1.04 + 4) * e.k),
        h: Math.max(0.1, u.h * e.k),
        margin: 0,
        wrap: !1,
        valign: "top",
        align: u.align,
        fit: "none",
        rotate: u.rotate || void 0,
        lineSpacingMultiple: b,
        paraSpaceAfter: 0,
      }),
        d++);
    }
  }
  return {
    bytes: new Uint8Array(await r.write({ outputType: "uint8array" })),
    slides: t.length,
    textBoxes: d,
    refitted: m,
    unusualFonts: Array.from(a).sort(),
  };
}
function pe(t, i) {
  return [
    t[0] * i[0] + t[2] * i[1],
    t[1] * i[0] + t[3] * i[1],
    t[0] * i[2] + t[2] * i[3],
    t[1] * i[2] + t[3] * i[3],
    t[0] * i[4] + t[2] * i[5] + t[4],
    t[1] * i[4] + t[3] * i[5] + t[5],
  ];
}
async function me(t, i) {
  const o = t.getViewport({ scale: 1 }),
    p = await t.getTextContent(),
    r = p.styles ?? {},
    d = [];
  for (const m of p.items) {
    if (typeof m.str != "string" || !m.transform || m.str === "") continue;
    const a = pe(o.transform, m.transform),
      n = Math.hypot(a[0], a[1]);
    if (!(n > 0.5)) continue;
    const s = (Math.atan2(a[1], a[0]) * 180) / Math.PI,
      e = m.fontName ?? "",
      c = se(i?.(e), r[e]?.fontFamily);
    d.push({
      text: m.str,
      x: a[4],
      baseline: a[5],
      width: Math.abs(m.width ?? 0) * (o.scale || 1),
      fontSize: n,
      angle: Math.abs(s) < 0.5 ? 0 : s,
      face: c.face,
      bold: c.bold,
      italic: c.italic,
      color: "000000",
    });
  }
  return { items: d, width: o.width, height: o.height };
}
class O extends Error {
  constructor() {
    (super("Cancelled"), (this.name = "PdfDeckCancelled"));
  }
}
async function $(t, i) {
  const o = await new Promise((p) => t.toBlob(p, "image/jpeg", i));
  if (!o) throw new Error("A page picture could not be saved");
  return new Uint8Array(await o.arrayBuffer());
}
async function D(t, i, o) {
  const p = t.getViewport({ scale: i }),
    r = document.createElement("canvas");
  ((r.width = Math.max(1, Math.round(p.width))),
    (r.height = Math.max(1, Math.round(p.height))));
  const d = r.getContext("2d", { willReadFrequently: !o });
  if (!d) throw new Error("Canvas is not supported in this browser");
  return (
    (d.fillStyle = "#ffffff"),
    d.fillRect(0, 0, r.width, r.height),
    o && ((d.fillText = () => {}), (d.strokeText = () => {})),
    await t.render({
      canvasContext: d,
      viewport: p,
      canvas: r,
      intent: "print",
    }).promise,
    r
  );
}
async function ue(t, i) {
  const o = await Y(t),
    p = o.numPages,
    r = i.pixelWidth ?? 1920,
    d = i.jpegQuality ?? 0.88,
    m = [];
  let a = 0,
    n = 0,
    s = 0;
  try {
    for (let e = 1; e <= p; e++) {
      if (i.signal?.aborted) throw new O();
      i.onProgress?.({ page: e, total: p });
      const c = await o.getPage(e),
        h = c.getViewport({ scale: 1 }),
        u = Math.min(3, Math.max(0.5, r / Math.max(h.width, h.height)));
      if (i.mode === "picture") {
        const P = await D(c, u, !1);
        (m.push({
          widthPt: h.width,
          heightPt: h.height,
          image: await $(P, d),
          blocks: [],
        }),
          (P.width = P.height = 0),
          c.cleanup());
        continue;
      }
      const x = await D(c, u, !1),
        b = (P) => {
          try {
            const S = c.commonObjs;
            return S.has(P) ? S.get(P)?.name : void 0;
          } catch {
            return;
          }
        },
        { items: g } = await me(c, b),
        y = await D(c, u, !0),
        w = x
          .getContext("2d", { willReadFrequently: !0 })
          .getImageData(0, 0, x.width, x.height),
        f = y
          .getContext("2d", { willReadFrequently: !0 })
          .getImageData(0, 0, y.width, y.height),
        M = [];
      for (const P of g) {
        if (!P.text.trim()) {
          M.push(P);
          continue;
        }
        const S = (P.angle * Math.PI) / 180,
          C = P.fontSize,
          E = [
            [0, -C * 0.9],
            [P.width, -C * 0.9],
            [0, C * 0.3],
            [P.width, C * 0.3],
          ].map(([j, A]) => [
            P.x + Math.cos(S) * j - Math.sin(S) * A,
            P.baseline + Math.sin(S) * j + Math.cos(S) * A,
          ]),
          N = E.map((j) => j[0] * u),
          z = E.map((j) => j[1] * u),
          B = {
            x: Math.min(...N),
            y: Math.min(...z),
            w: Math.max(...N) - Math.min(...N),
            h: Math.max(...z) - Math.min(...z),
          },
          I = ne(w.data, f.data, w.width, w.height, B);
        if (I.changed === 0) {
          n++;
          continue;
        }
        (a++, M.push({ ...P, color: I.color }));
      }
      (g.filter((P) => P.text.trim()).length === 0 && s++,
        m.push({
          widthPt: h.width,
          heightPt: h.height,
          image: await $(y, d),
          blocks: ce(M),
        }),
        (x.width = x.height = 0),
        (y.width = y.height = 0),
        c.cleanup());
    }
  } finally {
    o.loadingTask.destroy();
  }
  return { pages: m, editableItems: a, leftInPicture: n, pagesWithoutText: s };
}
const R = {
    what: "Turns each page of a PDF into a slide in a PowerPoint presentation (.pptx). Picture per slide gives the exact look of each page as one picture, which is the safest way to show a PDF in a presentation. Editable text puts the page's text into real text boxes you can change, with the page's pictures, lines and colours behind them as the slide background. The slide size follows the shape of the PDF pages.",
    tip: "Editable text is a best effort and never an exact copy. Line breaks, spacing, columns and fonts are approximated: fonts that PowerPoint does not have are swapped for a close one, and text that the PDF draws as shapes, or that sits inside a scanned picture, stays in the background picture and cannot be edited. If a page matters more than editing it, use Picture per slide. Tables are not rebuilt as tables; their text arrives as separate text boxes. PDFs protected with a password need unlocking first.",
  },
  fe = [
    {
      id: "picture",
      label: "Picture per slide",
      what: "Each page becomes one picture on its slide. It looks exactly like the PDF, and the text cannot be edited.",
    },
    {
      id: "editable",
      label: "Editable text",
      what: "Best effort: the text goes into text boxes you can edit, over a picture of the page without its text. Spacing, line breaks and fonts are approximate.",
    },
  ];
function pt() {
  const [t, i] = k.useState(null),
    [o, p] = k.useState("picture"),
    [r, d] = k.useState(!1),
    [m, a] = k.useState(null),
    [n, s] = k.useState(""),
    [e, c] = k.useState(null),
    h = k.useRef(null),
    { thumbnails: u, loading: x } = Z(t);
  (k.useEffect(() => () => h.current?.abort(), []),
    k.useEffect(() => c(null), [o]));
  const b = k.useCallback((f) => {
      (h.current?.abort(), c(null), s(""), i(f[0] ?? null));
    }, []),
    g = () => {
      (h.current?.abort(), i(null), c(null), s(""));
    },
    y = async () => {
      if (!t) return;
      const f = new AbortController();
      ((h.current = f), c(null), s(""), d(!0), a({ page: 0, total: 0 }));
      try {
        const M = await ue(t, { mode: o, signal: f.signal, onProgress: a });
        a(null);
        const P = await he(M.pages, { title: t.name.replace(/\.pdf$/i, "") });
        (c({
          blob: new Blob([new Uint8Array(P.bytes)], { type: te }),
          name: t.name.replace(/\.pdf$/i, "") + ".pptx",
          render: M,
          deck: P,
          mode: o,
          size: L(M.pages[0].widthPt, M.pages[0].heightPt),
        }),
          H("pdf-to-powerpoint", "powerpoint-slides"),
          X.success("PDF converted to PowerPoint"));
      } catch (M) {
        M instanceof O ||
          (console.error("PDF to PowerPoint failed:", M),
          s(
            M instanceof Error && M.name === "QuotaExceededError"
              ? "The browser ran out of memory. Try a PDF with fewer pages."
              : M instanceof Error
                ? M.message
                : "This PDF could not be converted.",
          ));
      } finally {
        (d(!1), a(null), (h.current = null));
      }
    },
    w = u.length;
  return l.jsxs(q, {
    toolId: "pdf-to-powerpoint",
    categoryId: "powerpoint-slides",
    whatItDoes: R.what,
    proTip: R.tip,
    children: [
      n && l.jsx(F, { alert: !0, className: "mb-4", children: n }),
      t
        ? l.jsxs("div", {
            className: "space-y-4",
            children: [
              l.jsxs("div", {
                className: "p-4 rounded-lg border bg-card space-y-1",
                children: [
                  l.jsx("p", {
                    className: "text-sm font-medium break-all",
                    children: t.name,
                  }),
                  l.jsxs("p", {
                    className: "text-xs text-muted-foreground",
                    children: [_(t.size), w > 0 && ` · ${v(w, "page")}`],
                  }),
                ],
              }),
              !e &&
                l.jsxs("section", {
                  "aria-label": "Pages of your PDF",
                  children: [
                    x && l.jsx(J, {}),
                    w > 0 &&
                      l.jsxs(l.Fragment, {
                        children: [
                          l.jsx("div", {
                            className: "flex gap-2 overflow-x-auto pb-2",
                            children: u
                              .slice(0, 12)
                              .map((f) =>
                                l.jsxs(
                                  "figure",
                                  {
                                    className: "shrink-0 w-28",
                                    children: [
                                      l.jsx("img", {
                                        src: f.url,
                                        alt: `Page ${f.pageNumber}`,
                                        className:
                                          "w-full rounded border bg-white",
                                      }),
                                      l.jsxs("figcaption", {
                                        className:
                                          "text-xs text-muted-foreground text-center",
                                        children: ["Page ", f.pageNumber],
                                      }),
                                    ],
                                  },
                                  f.pageNumber,
                                ),
                              ),
                          }),
                          w > 12 &&
                            l.jsxs("p", {
                              className: "text-xs text-muted-foreground",
                              children: [
                                "The first 12 pages are shown; all ",
                                w,
                                " are converted.",
                              ],
                            }),
                        ],
                      }),
                  ],
                }),
              !r &&
                !e &&
                l.jsxs("div", {
                  className: "space-y-3",
                  children: [
                    l.jsxs("div", {
                      children: [
                        l.jsx("p", {
                          className: "text-sm font-medium mb-2",
                          id: "ptp-mode",
                          children: "How to convert",
                        }),
                        l.jsx("div", {
                          className: "grid gap-2 sm:grid-cols-2",
                          role: "group",
                          "aria-labelledby": "ptp-mode",
                          children: fe.map((f) =>
                            l.jsxs(
                              "button",
                              {
                                type: "button",
                                "aria-pressed": o === f.id,
                                onClick: () => p(f.id),
                                className: `text-left rounded-lg border-2 p-3 transition-colors ${o === f.id ? "border-primary bg-primary/5" : "border-border bg-card"}`,
                                children: [
                                  l.jsx("span", {
                                    className: "block text-sm font-medium",
                                    children: f.label,
                                  }),
                                  l.jsx("span", {
                                    className:
                                      "block text-xs text-muted-foreground mt-0.5",
                                    children: f.what,
                                  }),
                                ],
                              },
                              f.id,
                            ),
                          ),
                        }),
                      ],
                    }),
                    o === "editable" &&
                      l.jsx(F, {
                        children:
                          "Editable text is approximate. Fonts PowerPoint does not have are swapped for a close one, text a PDF draws as shapes stays in the picture, and scanned pages have no text to edit. After converting you see exactly how many pieces of text became editable.",
                      }),
                    w > 40 &&
                      l.jsxs(F, {
                        children: [
                          "A PDF with ",
                          w,
                          " pages takes a while to convert and makes a large file. Editable text takes about twice as long as Picture per slide.",
                        ],
                      }),
                  ],
                }),
              l.jsx("div", {
                className: "flex flex-wrap gap-3 items-start",
                children: r
                  ? l.jsx(V, {
                      message:
                        m && m.total > 0
                          ? `Page ${m.page} / ${m.total}`
                          : "Opening the PDF...",
                      progress:
                        m && m.total > 0
                          ? (Math.max(0, m.page - 1) / m.total) * 100
                          : void 0,
                      onStop: () => h.current?.abort(),
                    })
                  : e
                    ? l.jsxs(l.Fragment, {
                        children: [
                          l.jsx(W, { blob: e.blob, fileName: e.name }),
                          l.jsx(T, {
                            variant: "outline",
                            onClick: () => c(null),
                            children: "Change how to convert",
                          }),
                          l.jsx(T, {
                            variant: "outline",
                            onClick: g,
                            children: "Convert another file",
                          }),
                        ],
                      })
                    : l.jsxs(l.Fragment, {
                        children: [
                          l.jsx(T, {
                            onClick: y,
                            disabled: x && w === 0,
                            children: "Convert to PowerPoint",
                          }),
                          l.jsx(T, {
                            variant: "outline",
                            onClick: g,
                            children: "Choose a different file",
                          }),
                        ],
                      }),
              }),
              e &&
                l.jsxs("section", {
                  "aria-label": "The presentation",
                  className: "space-y-3",
                  children: [
                    l.jsxs("p", {
                      className: "text-sm text-muted-foreground",
                      role: "status",
                      children: [
                        e.name,
                        " · ",
                        v(e.deck.slides, "slide"),
                        " · ",
                        e.size.w.toFixed(1),
                        " × ",
                        e.size.h.toFixed(1),
                        " inches · ",
                        _(e.blob.size),
                        " · ",
                        e.mode === "picture"
                          ? "Picture per slide"
                          : "Editable text",
                      ],
                    }),
                    e.mode === "editable" &&
                      l.jsxs(F, {
                        children: [
                          l.jsx("p", {
                            className: "font-medium mb-1",
                            children: "What became editable",
                          }),
                          l.jsxs("ul", {
                            className: "list-disc pl-5 space-y-0.5",
                            children: [
                              l.jsxs("li", {
                                children: [
                                  v(
                                    e.render.editableItems,
                                    "piece of text",
                                    "pieces of text",
                                  ),
                                  " became text you can edit, in ",
                                  v(e.deck.textBoxes, "text box", "text boxes"),
                                  ".",
                                ],
                              }),
                              e.render.leftInPicture > 0 &&
                                l.jsxs("li", {
                                  children: [
                                    v(
                                      e.render.leftInPicture,
                                      "piece of text",
                                      "pieces of text",
                                    ),
                                    " could not be separated from the page and stayed in the background picture.",
                                  ],
                                }),
                              e.render.pagesWithoutText > 0 &&
                                l.jsxs("li", {
                                  children: [
                                    v(e.render.pagesWithoutText, "page"),
                                    " had no text at all (a scan or a picture), so ",
                                    e.render.pagesWithoutText === 1
                                      ? "it is"
                                      : "they are",
                                    " a picture only.",
                                  ],
                                }),
                              e.deck.unusualFonts.length > 0 &&
                                l.jsxs("li", {
                                  children: [
                                    "Fonts PowerPoint may not have: ",
                                    e.deck.unusualFonts.slice(0, 6).join(", "),
                                    ". It will show a substitute unless they are installed.",
                                  ],
                                }),
                              e.deck.refitted > 0 &&
                                l.jsxs("li", {
                                  children: [
                                    v(e.deck.refitted, "page"),
                                    " ",
                                    e.deck.refitted === 1 ? "has" : "have",
                                    " a different shape from the first page and ",
                                    e.deck.refitted === 1 ? "is" : "are",
                                    " fitted inside the slide with space around.",
                                  ],
                                }),
                              l.jsx("li", {
                                children:
                                  "Line breaks, spacing and columns are approximate. Check the slides before you rely on them.",
                              }),
                            ],
                          }),
                        ],
                      }),
                    e.mode === "picture" &&
                      e.deck.refitted > 0 &&
                      l.jsxs(F, {
                        children: [
                          v(e.deck.refitted, "page"),
                          " ",
                          e.deck.refitted === 1 ? "has" : "have",
                          " a different shape from the first page and ",
                          e.deck.refitted === 1 ? "is" : "are",
                          " fitted inside the slide with space around.",
                        ],
                      }),
                    l.jsx(ee, {
                      blob: e.blob,
                      label: "Preview of the presentation",
                    }),
                  ],
                }),
            ],
          })
        : l.jsx(U, {
            gateAtDownload: !0,
            onAttempt: () => s(""),
            accept: ".pdf",
            onFiles: b,
            label: "Drop a PDF file",
            description: "Each page becomes a slide, in your browser",
          }),
    ],
  });
}
export { pt as default };
//# sourceMappingURL=PdfToPowerPoint-DjPnFh-o.js.map
