const n = [
    /^untitled(\s+document)?(\s*\d+)?$/i,
    /^new document$/i,
    /^document\s*\d*$/i,
    /^microsoft\s+(word|excel|powerpoint)\s*-\s*/i,
    /^powerpoint presentation$/i,
    /^slide\s*\d+$/i,
  ],
  o = [
    /^anonymous$/i,
    /^\(?anonymous\)?$/i,
    /^unknown$/i,
    /^unspecified$/i,
    /^author$/i,
  ];
function s(e) {
  const t = e?.trim();
  if (t) return n.some((i) => i.test(t)) ? void 0 : t;
}
function r(e) {
  const t = e?.trim();
  if (t) return o.some((i) => i.test(t)) ? void 0 : t;
}
const a = (e) => e.replace(/\.pdf$/i, "");
function u(e, t) {
  e.setTitle(s(t.title) ?? t.fallbackTitle);
  const i = r(t.author);
  (i && e.setAuthor(i),
    e.setProducer("FreeDailyPro"),
    e.setCreator("FreeDailyPro"));
}
export { a, s as b, r as m, u as s };
//# sourceMappingURL=pdfMetadata-CcxIhQF2.js.map
