# FDP-51: inspect .pptx outputs (slide size, slides, pictures, text boxes, text, fonts, watermark text, core props)
import sys, glob, json, os, zipfile, re
from pptx import Presentation
from pptx.util import Emu
out = {}
for f in sorted(sys.argv[1:]):
    try:
        p = Presentation(f)
    except Exception as e:
        out[os.path.basename(f)] = {'error': str(e)[:200]}; continue
    r = {'bytes': os.path.getsize(f), 'size_in': [round(p.slide_width / 914400, 3), round(p.slide_height / 914400, 3)], 'slides': len(p.slides),
         'core': {'title': p.core_properties.title, 'author': p.core_properties.author, 'creator_app': None}, 'per_slide': []}
    z = zipfile.ZipFile(f); app = z.read('docProps/app.xml').decode('utf8', 'ignore') if 'docProps/app.xml' in z.namelist() else ''
    r['core']['creator_app'] = (re.findall(r'<Application>(.*?)</Application>', app) or [None])[0]
    r['media'] = [(n, z.getinfo(n).file_size) for n in z.namelist() if n.startswith('ppt/media/')][:6]; r['n_media'] = len([n for n in z.namelist() if n.startswith('ppt/media/')])
    allxml = ''.join(z.read(n).decode('utf8', 'ignore') for n in z.namelist() if n.endswith('.xml'))
    r['watermark_text'] = bool(re.search(r'FreeDailyPro', allxml)); r['fdp_mentions'] = re.findall(r'[^<>]{0,30}FreeDailyPro[^<>]{0,30}', allxml)[:3]
    for i, s in enumerate(p.slides):
        pics = [sh for sh in s.shapes if sh.shape_type == 13]; tbs = [sh for sh in s.shapes if sh.has_text_frame and sh.text_frame.text.strip()]
        fonts = set(); sizes = set(); colors = set()
        for sh in tbs:
            for para in sh.text_frame.paragraphs:
                for run in para.runs:
                    if run.font.name: fonts.add(run.font.name)
                    if run.font.size: sizes.add(round(run.font.size.pt, 1))
                    try:
                        if run.font.color and run.font.color.rgb: colors.add(str(run.font.color.rgb))
                    except Exception: pass
        bg = s.background.fill.type if s.background else None
        r['per_slide'].append({'n': i + 1, 'shapes': len(s.shapes), 'pictures': len(pics), 'pic_box_in': [[round(Emu(x).inches, 2) for x in (pp.left, pp.top, pp.width, pp.height)] for pp in pics][:2],
                               'textboxes': len(tbs), 'text': ' / '.join(sh.text_frame.text.strip().replace('\n', ' ⏎ ') for sh in tbs)[:400], 'fonts': sorted(fonts), 'sizes': sorted(sizes)[:8], 'colors': sorted(colors)[:6]})
        if i >= 5 and len(p.slides) > 8: r['per_slide'].append('… (%d more)' % (len(p.slides) - 6)); break
    out[os.path.basename(f)] = r
print(json.dumps(out, indent=1, ensure_ascii=False))
