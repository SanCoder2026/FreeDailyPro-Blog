# FDP-51: build "real-world" PDFs with TrueType text via LibreOffice: a 16:9 deck made in python-pptx, and a Writer document from HTML
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from PIL import Image, ImageDraw
import subprocess
img = Image.new('RGB', (600, 360), '#e8742a'); d = ImageDraw.Draw(img); d.ellipse((60, 60, 300, 300), fill='white'); img.save('_chart.png')
p = Presentation(); p.slide_width = Inches(13.333); p.slide_height = Inches(7.5)
for i in range(1, 5):
    s = p.slides.add_slide(p.slide_layouts[6])
    tb = s.shapes.add_textbox(Inches(0.6), Inches(0.4), Inches(12), Inches(1.2)); r = tb.text_frame.paragraphs[0].add_run(); r.text = f'Slide {i}: Product Launch Plan'; r.font.size = Pt(40); r.font.bold = True; r.font.name = 'Liberation Sans'; r.font.color.rgb = RGBColor(0x1A, 0x4F, 0xA0)
    body = s.shapes.add_textbox(Inches(0.6), Inches(1.8), Inches(6.5), Inches(4)); tf = body.text_frame
    for j, t in enumerate(['Revenue up 12% year on year', 'New customers: 1,250', 'Churn down to 2.1%', 'Next review on 15 Dec 2026']):
        para = tf.paragraphs[0] if j == 0 else tf.add_paragraph(); rr = para.add_run(); rr.text = '• ' + t; rr.font.size = Pt(24); rr.font.name = 'Liberation Serif' if j == 3 else 'Liberation Sans'
        if j == 2: rr.font.color.rgb = RGBColor(0xC0, 0, 0)
        if j == 1: rr.font.italic = True
    s.shapes.add_picture('_chart.png', Inches(7.6), Inches(1.8), Inches(5), Inches(3))
    if i == 3:
        t = s.shapes.add_table(3, 3, Inches(0.6), Inches(5.6), Inches(6), Inches(1.2)).table
        for a, row in enumerate([['Region', 'Q3', 'Q4'], ['Europe', '1.2M', '1.4M'], ['Americas', '2.1M', '2.3M']]):
            for b, v in enumerate(row): t.cell(a, b).text = v
    ft = s.shapes.add_textbox(Inches(0.6), Inches(6.8), Inches(8), Inches(0.4)); fr = ft.text_frame.paragraphs[0].add_run(); fr.text = f'Confidential · page {i}'; fr.font.size = Pt(11); fr.font.name = 'DejaVu Sans'
p.save('_deck.pptx')
open('_doc.html', 'w').write('<html><body style="font-family:Liberation Serif"><h1 style="font-family:Liberation Sans;color:#1a4fa0">Project memo</h1><p>This memo explains the plan for the next quarter. <b>Bold point</b> and <i>italic aside</i>.</p><h2>Goals</h2><ul><li>Ship version 2</li><li>Hire two engineers</li></ul><table border=1><tr><th>Item</th><th>Cost</th></tr><tr><td>Laptops</td><td>$4,800</td></tr><tr><td>Licences</td><td>$1,200</td></tr></table><p>' + 'Long paragraph text that wraps over several lines so the line breaks can be checked in the slide output. ' * 6 + '</p></body></html>')
subprocess.run(['soffice', '--headless', '--convert-to', 'pdf', '_deck.pptx'], check=True, capture_output=True)
subprocess.run(['soffice', '--headless', '--convert-to', 'pdf:writer_pdf_Export', '_doc.html'], check=True, capture_output=True)
import os; os.rename('_deck.pdf', 'P11_deck_from_pptx.pdf'); os.rename('_doc.pdf', 'P12_memo_from_writer.pdf'); os.rename('_deck.pptx', 'P11_source_deck.pptx')
for f in ['_chart.png', '_doc.html']: os.remove(f)
