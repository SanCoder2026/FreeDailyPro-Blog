// FDP-51: render the two category hubs (guest) and check whether PDF to PowerPoint is listed in <main>
const { chromium } = require('playwright'); const fs = require('fs');
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); const R = {};
 for (const c of ['pdf-tools', 'powerpoint-slides']) { await p.goto('https://www.freedailypro.com/category/' + c, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
  R[c] = await p.evaluate(() => { const hrefs = [...document.querySelectorAll('main a[href*="/tool/"]')].map(a => a.getAttribute('href')); return { n: hrefs.length, ppt: hrefs.filter(h => /pdf-to-powerpoint/.test(h)), pdfTo: [...new Set(hrefs.filter(h => /\/tool\/pdf-to-/.test(h)))], h1: document.querySelector('h1')?.innerText }; }); }
 console.log(JSON.stringify(R, null, 1)); fs.writeFileSync('/workspace/deep/51-pdf-to-powerpoint/live/category-hubs.json', JSON.stringify(R, null, 1)); await b.close(); })();
