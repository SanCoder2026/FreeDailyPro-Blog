// FDP-51 PDF to PowerPoint, guest. Usage: node px51-live.js <zero|left|subset> [engine]   (TRIES env = fresh contexts to try for "left")
// zero: context at the cap -> convert (preview at 0), Download/Drive/cloud/open-Drive, Day Pass (stops at email), Quick Buy (stops at Stripe), keyboard.
// left: context with uses left -> many conversions + downloads in ONE page load (per-page-load check), then reload + downloads.
// Never types an email/card, never clicks a pass "Continue", never clicks ads. The only password typed is the test PDF's own (u123).
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const crypto = require('crypto');
const BASE = '/workspace/deep/51-pdf-to-powerpoint/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/pdf-to-powerpoint';
const mode = process.argv[2] || 'left'; const eng = process.argv[3] || 'chromium'; const sfx = eng === 'chromium' ? '' : '-' + eng;
fs.mkdirSync(OUT + 'downloads', { recursive: true }); fs.mkdirSync(OUT + 'cases', { recursive: true });
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex').slice(0, 16);
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').replace(/dev[:%][^&"]*/g, 'dev:REDACTED').slice(0, 160);
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p; const net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true, locale: 'en-US' }); p = await c.newPage(); p.setDefaultTimeout(15000);
  await p.addInitScript(() => { window.__t = []; const seen = new WeakSet(); setInterval(() => { document.querySelectorAll('[data-sonner-toast]').forEach(n => { if (!seen.has(n)) { seen.add(n); window.__t.push((n.innerText || '').trim()); } }); }, 150); });
  p.on('request', r => { const d = r.postData() || ''; if (r.method() === 'POST') net.push({ t: Date.now(), u: red(r.url()), len: d.length, doc: /%PDF|Quarterly Review|Product Launch|PK\x03\x04/.test(d) }); else if (/jsdelivr|unpkg|cdnjs|tesseract|font/.test(r.url())) net.push({ t: Date.now(), u: red(r.url()), get: true }); });
  await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000); };
 const used = () => p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 const mainTxt = () => p.evaluate(() => document.querySelector('main').innerText);
 const state = async () => { const t = await mainTxt(); const s = t.search(/remaining today\n/); const e = t.indexOf('NEXT STEP'); return { text: t.slice(s > 0 ? s + 16 : 0, e > 0 ? e : undefined).slice(0, 1400), summary: (t.match(/[^\n]*\.pptx · [^\n]*/) || [''])[0] }; };
 const reset = async () => { for (const n of ['Convert another file', 'Choose a different file']) { const bt = p.locator('main button', { hasText: new RegExp('^' + n + '$') }); if (await bt.count()) { await bt.first().click(); await p.waitForTimeout(600); } } };
 const convert = async (f, o = {}, r = {}) => { await reset(); await p.locator('main input[type=file]').first().setInputFiles(TF + f); await p.waitForTimeout(2500);
  r.dialogOnLoad = await dialog(); r.loadText = (await state()).text.slice(0, 500);
  if (o.pw) { const pf = p.locator('main input[type=password], [role=dialog] input[type=password]'); r.pwField = await pf.count(); if (r.pwField) { await pf.first().fill(o.pw); await p.keyboard.press('Enter'); await p.waitForTimeout(3000); r.afterPw = (await state()).text.slice(0, 400); } }
  const cv = p.getByRole('button', { name: /Convert to PowerPoint/ }); if (!(await cv.count())) { r.noConvert = true; return; }
  if (o.mode) await p.locator('main button', { hasText: new RegExp('^' + o.mode) }).first().click();
  const t0 = Date.now(); await cv.click();
  if (o.stopAfter) { await p.waitForTimeout(o.stopAfter); const st = p.getByRole('button', { name: /^Stop/ }); r.stopBtn = await st.count(); r.progress = (await state()).text.slice(0, 300); if (r.stopBtn) await st.first().click(); await p.waitForTimeout(1500); r.ms = Date.now() - t0; r.state = await state(); return; }
  await p.waitForFunction(() => { const m = document.querySelector('main'); return /\.pptx · /.test(m.innerText) || [...m.querySelectorAll('[role=alert]')].some(a => !/trial uses/i.test(a.innerText)); }, null, { timeout: o.wait || 90000 }).catch(() => r.timeout = true);
  r.ms = Date.now() - t0; await p.waitForTimeout(800); r.state = await state(); };
 const download = async (id, r) => { const bt = p.locator('main button', { hasText: /^Download$/ }).first(); if (!(await bt.count())) { r.dl = 'absent'; return; }
  const dp = p.waitForEvent('download', { timeout: 15000 }).catch(() => null); await bt.click(); const d = await dp; await p.waitForTimeout(1500);
  r.dialog = await dialog(); if (d) { const f = OUT + 'downloads/' + id + sfx + '-' + d.suggestedFilename(); await d.saveAs(f); r.download = { name: d.suggestedFilename(), bytes: fs.statSync(f).size, sha: sha(f) }; }
  if (r.dialog) { await p.screenshot({ path: OUT + 'cases/' + id + sfx + '-dialog.png' }); if (mode === 'zero' && !R.dayPass) { const bp = p.getByRole('button', { name: /Buy Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.dayPass = { dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'dlg-daypass' + sfx + '.png' }); } } await esc(); } };
 const run = async (id, f, o = {}, dl = true) => { const r = { id, f, o, t: now(), before: await used() }; const tN = await p.evaluate(() => (window.__t || []).length);
  try { await convert(f, o, r); if (dl && !o.stopAfter && !r.noConvert) await download(id, r); } catch (e) { r.err = e.message.slice(0, 300); }
  r.afterUsed = await used(); r.toasts = await p.evaluate(n => (window.__t || []).slice(n), tN);
  await p.screenshot({ path: OUT + 'cases/' + id + sfx + '.png', fullPage: !!o.full }).catch(() => {}); R.cases[id] = r; console.log(id, JSON.stringify(r).slice(0, 600)); return r; };
 const act = async (name, loc) => { const r = { before: await used() }; if (!(await loc.count())) { r.missing = true; console.log(name, 'missing'); return r; }
  const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); const url0 = p.url(); await loc.first().click(); const pg = await pop; await p.waitForTimeout(2500);
  r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null; if (pg) { await pg.waitForLoadState('domcontentloaded').catch(() => {}); r.popup = red(pg.url()); await pg.close(); }
  if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + sfx + '.png' }); await esc(); console.log(name, JSON.stringify(r).slice(0, 400)); return r; };
 if (mode === 'zero' || mode === 'subset') { for (let i = 0; i < 8; i++) { await open(); await p.waitForTimeout(2000); const u = await used(); R.tries.push(u); if (u >= 10 || mode === 'subset') break; await c.close(); }
  R.start = await used();
  if (mode === 'zero') { const seq = []; for (let i = 0; i < 40; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 40).replace(/\n/g, ' '); }); seq.push(a); if (/Drop a PDF|Open from Google Drive/.test(a)) break; } R.kbd = { seq: seq.slice(-5), tabs: seq.length };
   await run('Z01', 'P01_text_deck_letter.pdf', { full: true }); await run('Z02', 'P02_slides_16x9.pdf', { mode: 'Editable text' });
   R.zeroGetPass = await act('zero-getpass', p.getByRole('button', { name: /Get a Day Pass to download/ }));
   R.drive = await act('zero-drive', p.getByRole('button', { name: /Save to Google Drive/ })); R.cloud = await act('zero-cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
   await reset(); R.openDrive = await act('zero-open-drive', p.getByRole('button', { name: /Open from Google Drive/ })); R.end = await used();
   await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); const u0 = p.url();
   await p.getByRole('button', { name: 'Quick Buy' }).first().click(); await p.waitForTimeout(3000); R.qbDay = { url: p.url() !== u0 ? red(p.url()) : null, dialog: await dialog(), email: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await esc();
   if (p.url() !== u0) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); }
   await p.getByRole('button', { name: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); R.qbMonth = { url: red(p.url()), title: await p.title() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' }); }
  else { await run('S01', 'P02_slides_16x9.pdf'); await run('S02', 'P11_deck_from_pptx.pdf', { mode: 'Editable text' }); await run('S03', 'P08_multilingual.pdf', { mode: 'Editable text' }); } }
 if (mode === 'left2') { const NT = +(process.env.TRIES || 30); for (let i = 0; i < NT; i++) { await open(); const u = await used(); R.tries.push(u); if (u < 10) { await p.waitForTimeout(5000); if ((await used()) < 10) break; } if (i < NT - 1) await c.close(); }
  R.start = await used();
  for (const [id, f, o] of [['M01-edit', 'P11_deck_from_pptx.pdf', { mode: 'Editable text' }], ['M02-pic', 'P11_deck_from_pptx.pdf', { mode: 'Picture per slide' }], ['M03-edit', 'P12_memo_from_writer.pdf', { mode: 'Editable text' }], ['M04-stop', 'P07_60pages_16x9.pdf', { mode: 'Editable text', stopAfter: 400 }], ['M05-after-stop', 'P12_memo_from_writer.pdf', { mode: 'Picture per slide' }]]) await run(id, f, o);
  R.end = await used(); }
 if (mode === 'left') { const NT = +(process.env.TRIES || 30); for (let i = 0; i < NT; i++) { await open(); const u = await used(); R.tries.push(u); if (u < 10) { await p.waitForTimeout(5000); if ((await used()) < 10) break; } if (i < NT - 1) await c.close(); }
  R.start = await used();
  await run('L01', 'P02_slides_16x9.pdf');
  R.drive = await act('drive', p.getByRole('button', { name: /Save to Google Drive/ })); R.cloud = await act('cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
  await run('L01b-redl', 'P02_slides_16x9.pdf');
  for (const [id, f, o] of [['L02-edit', 'P02_slides_16x9.pdf', { mode: 'Editable text' }], ['L03-edit', 'P01_text_deck_letter.pdf', { mode: 'Editable text' }], ['L04-pic', 'P01_text_deck_letter.pdf', { mode: 'Picture per slide' }],
    ['L05-edit', 'P03_images_text.pdf', { mode: 'Editable text' }], ['L06-edit-scan', 'P04_scanned_slide.pdf', { mode: 'Editable text' }], ['L07-pw', 'P05_password_u123.pdf', { pw: 'u123', mode: 'Editable text' }], ['L08-damaged', 'P06_damaged.pdf'],
    ['L09-60p-pic', 'P07_60pages_16x9.pdf', { mode: 'Picture per slide', wait: 240000 }], ['L10-60p-edit', 'P07_60pages_16x9.pdf', { mode: 'Editable text', wait: 240000 }], ['L11-stop', 'P07_60pages_16x9.pdf', { mode: 'Picture per slide', stopAfter: 1500 }],
    ['L12-multi-edit', 'P08_multilingual.pdf', { mode: 'Editable text' }], ['L13-mixed-pic', 'P09_mixed_sizes.pdf', { mode: 'Picture per slide' }], ['L14-mixed-edit', 'P09_mixed_sizes.pdf', { mode: 'Editable text' }], ['L15-fake', 'P10_fake.pdf']])
   await run(id, f, o || {});
  R.endLoad = await used(); await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000); R.afterReload = await used();
  await run('L20-after-reload', 'P01_text_deck_letter.pdf', { mode: 'Editable text' }); await run('L21-after-reload-2', 'P03_images_text.pdf', { mode: 'Picture per slide' }); R.end = await used(); }
 R.t2 = now(); R.net = net; fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('tries', R.tries.join(','), 'start', R.start, 'end', R.end); await b.close(); })();
