// FDP-51 probe: load P02 in a guest context, dump controls, convert (picture) and show the result area (no download)
const { chromium } = require('playwright'); const fs = require('fs'); const O = '/workspace/deep/51-pdf-to-powerpoint/';
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); const js = [];
 p.on('response', r => { if (/\/assets\/.*\.js$/.test(r.url())) js.push(r.url()); });
 await p.goto('https://www.freedailypro.com/tool/pdf-to-powerpoint', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 console.log(await p.evaluate(() => localStorage.getItem('fdp-usage-v1').replace(/dev:[^"]+/, 'dev:R')));
 await p.locator('main input[type=file]').first().setInputFiles(O + 'testfiles/P02_slides_16x9.pdf'); await p.waitForTimeout(3000);
 const ctl = () => p.evaluate(() => [...document.querySelectorAll('main input,main select,main button,main [role=radio],main [role=checkbox],main [role=tab]')].map(x => [x.tagName, x.type || x.getAttribute('role'), x.id, x.getAttribute('aria-label') || x.innerText?.trim().slice(0, 40) || x.value, x.checked ?? x.getAttribute('aria-checked') ?? x.getAttribute('aria-pressed')]));
 console.log(JSON.stringify(await ctl())); let t = await p.evaluate(() => document.querySelector('main').innerText); console.log(t.slice(t.indexOf('Drop'), t.indexOf('NEXT STEP')));
 await p.screenshot({ path: O + 'live/probe-loaded.png', fullPage: false });
 await p.getByRole('button', { name: /Convert to PowerPoint/ }).click(); await p.waitForTimeout(8000);
 t = await p.evaluate(() => document.querySelector('main').innerText); console.log('---AFTER---\n' + t.slice(0, t.indexOf('NEXT STEP')));
 console.log(JSON.stringify(await ctl())); console.log(await p.evaluate(() => localStorage.getItem('fdp-usage-v1').replace(/dev:[^"]+/, 'dev:R')));
 await p.screenshot({ path: O + 'live/probe.png', fullPage: true }); fs.writeFileSync(O + 'js/chunks.txt', [...new Set(js)].join('\n')); await b.close(); })();
