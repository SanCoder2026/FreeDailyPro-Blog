import { r as w, j as e } from "./vendor-react-D01g8YgM.js";
import { p as we } from "./utils-s8ucLyj8.js";
import {
  b as Ne,
  f as Ee,
  P as Ce,
  D as Se,
  R as Te,
  T as De,
  F as fe,
} from "./ToolPage-DwLoDncN.js";
import {
  e as D,
  B as U,
  I as ee,
  aA as Be,
  T as ke,
  N as Le,
  aG as xe,
  f as W,
  aH as Re,
  dq as Oe,
  dr as We,
  bf as Pe,
} from "./index-B1CTyGtY.js";
import { C as se } from "./checkbox-Ml1pfDb3.js";
import { C as ce } from "./card-KXKUZKW8.js";
import { R as Ge } from "./ReorderableFileList-BhqJ-ECL.js";
import {
  S as ne,
  a as ie,
  b as le,
  c as re,
  d as X,
} from "./select-ic5yaeGw.js";
import { normalizeImageFile as ue } from "./imagePdf-Dtz8PQyf.js";
import {
  k as _e,
  u as Q,
  p as Ue,
  r as Je,
  o as He,
  q as Ze,
  s as Ve,
} from "./index-BRvxULIc.js";
import { T as Ye } from "./pdfText-bjh9eBB-.js";
import { P as qe } from "./productCatalog-CL4Qj03q.js";
import { b as me, s as Ke, d as be } from "./localFiles-BJNBw6au.js";
import { A as Xe } from "./arrow-down-DgkjpMkc.js";
import { T as Qe } from "./trash-2-CmoDM6Qu.js";
import { I as ye } from "./image-plus-XffUX0hB.js";
import { a as et } from "./bookAssembly-DmpTM49o.js";
import { f as tt } from "./reorderMath-CVj9Q6Gj.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-DhOoIDuZ.js";
import "./formatFileSize-B-JRDfN5.js";
import "./grip-vertical-Dzkp2Q5V.js";
import "./index-BdQq_4o_.js";
import "./chevron-up-BDUcPssj.js";
import "./pdfMetadata-CcxIhQF2.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./fontkit.es-DA-3qwB1.js";
import "./numberInput-5hjoxJ5z.js";
import "./codeGeneration-D1g4LVfX.js";
import "./JsBarcode-QeG8kXh7.js";
import "./browser-CMr8NRjw.js";
import "./qrHelpers-av3Dz-dA.js";
import "./pageView-BQIwVYOi.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./formAppearance-CdNbuISd.js";
import "./drawTextAnywhere-DcuP6lHH.js";
const he = "freedailypro-magazine",
  st = [
    {
      id: "list",
      label: "List",
      blurb: "Title and author, page number on the right.",
    },
    {
      id: "dotted",
      label: "Dotted leaders",
      blurb: "A dotted line joins each title to its page number.",
    },
    {
      id: "grid",
      label: "Two-column grid",
      blurb: "Compact: two columns of titles, for issues with many articles.",
    },
  ],
  Ie = [
    {
      id: "classic",
      label: "Classic",
      blurb: "2 columns, comfortable text.",
      columns: 2,
      gutter: 18,
      bodySize: 10,
    },
    {
      id: "narrow",
      label: "Narrow columns",
      blurb: "3 narrow columns, small text.",
      columns: 3,
      gutter: 14,
      bodySize: 9,
    },
    {
      id: "wide",
      label: "Wide reader",
      blurb: "1 wide column, larger text.",
      columns: 1,
      gutter: 18,
      bodySize: 11,
    },
    {
      id: "compact",
      label: "Compact",
      blurb: "3 columns, tight gaps, for long issues.",
      columns: 3,
      gutter: 10,
      bodySize: 8.5,
    },
  ],
  de = (o) => Ie.find((s) => s.id === o),
  te = (o, s = 2e5) => (typeof o == "string" ? o.slice(0, s) : ""),
  pe = (o) =>
    typeof o == "string" &&
    /^data:image\/(png|jpeg|jpg);base64,[A-Za-z0-9+/=]+$/.test(o)
      ? o
      : "";
function at(o, s = new Date()) {
  return JSON.stringify(
    { app: he, version: 1, savedAt: s.toISOString(), ...o },
    null,
    2,
  );
}
function nt(o) {
  let s;
  try {
    s = JSON.parse(o);
  } catch {
    return {
      ok: !1,
      error: "That file is not a saved issue (it could not be read as JSON).",
    };
  }
  const a = s;
  if (!a || typeof a != "object" || a.app !== he)
    return {
      ok: !1,
      error: "That file is not a saved FreeDailyPro magazine issue.",
    };
  if (a.version !== 1)
    return {
      ok: !1,
      error:
        "That issue file is from a newer version and cannot be opened here.",
    };
  if (!Array.isArray(a.articles))
    return { ok: !1, error: "That issue file has no articles." };
  if (a.articles.length > 200)
    return { ok: !1, error: "That issue has more than 200 articles." };
  const p = a.articles.map((u) => {
      const m = u && typeof u == "object" ? u : {};
      return {
        title: te(m.title, 300),
        author: te(m.author, 200),
        body: te(m.body),
        image: pe(m.image),
      };
    }),
    i = a.tocStyle === "dotted" || a.tocStyle === "grid" ? a.tocStyle : "list",
    l = a.columnTemplate === "newsletter" ? "narrow" : a.columnTemplate,
    d = typeof l == "string" && de(l) ? l : "";
  return {
    ok: !0,
    issue: {
      app: he,
      version: 1,
      savedAt: te(a.savedAt, 40),
      title: te(a.title, 300),
      issue: te(a.issue, 100),
      columns: a.columns === 1 || a.columns === 3 ? a.columns : 2,
      page: a.page === "a4" ? "a4" : "letter",
      accent:
        typeof a.accent == "string" && /^#[0-9a-f]{6}$/i.test(a.accent)
          ? a.accent
          : "#4f46e5",
      cover: a.cover !== !1,
      contents: a.contents !== !1,
      tocStyle: i,
      columnTemplate: d,
      coverImage: pe(a.coverImage),
      logo: pe(a.logo),
      articles: p,
    },
  };
}
function it(o, s, a) {
  const p = a.right - a.left;
  if (s === "grid") {
    const d = (p - 24) / 2,
      u = 30,
      m = Math.ceil(Math.min(o.length, (a.maxRows ?? 30) * 2) / 2);
    return o.slice(0, m * 2).map((b, N) => {
      const v = Math.floor(N / m);
      return {
        entry: b,
        x: a.left + v * (d + 24),
        y: a.top - (N % m) * u,
        width: d,
        dots: !1,
      };
    });
  }
  const i = 34;
  return o
    .slice(0, a.maxRows ?? 30)
    .map((l, d) => ({
      entry: l,
      x: a.left,
      y: a.top - d * i,
      width: p,
      dots: s === "dotted",
    }));
}
const ze =
    "\\uD83C[\\uDC00-\\uDFFF]|\\uD83D[\\uDC00-\\uDFFF]|\\uD83E[\\uDC00-\\uDFFF]|[\\u2600-\\u27BF\\u2B00-\\u2BFF\\u20E3]",
  lt = new RegExp(`${ze}|\\uDB40[\\uDC20-\\uDC7F]|[\\uFE0F\\u200D]`, "g");
function rt(o) {
  return new RegExp(ze).test(o);
}
function ot(o) {
  return o
    .replace(lt, "")
    .replace(/[ \t]{2,}/g, " ")
    .replace(/ +([.,;:!?])/g, "$1");
}
function oe(o) {
  const s = o
      .replace(/!\[([^\]]*)\]\([^)]*\)/g, "$1")
      .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
      .replace(/`([^`]*)`/g, "$1"),
    a = [];
  let p = !1,
    i = !1,
    l = "";
  const d = () => {
      if (!l) return;
      const m = a[a.length - 1];
      (m && m.bold === p && m.italic === i
        ? (m.text += l)
        : a.push({ text: l, bold: p, italic: i }),
        (l = ""));
    },
    u = (m, b) => s.indexOf(m, b) > b;
  for (let m = 0; m < s.length; m++) {
    const b = s[m];
    if (b === "\\" && m + 1 < s.length && /[\\*_`#\[\]()>-]/.test(s[m + 1])) {
      l += s[++m];
      continue;
    }
    if (b === "*" || b === "_") {
      const N = s[m - 1] ?? " ";
      if (b === "_" && /\w/.test(N) && !i && !p) {
        l += b;
        continue;
      }
      let v = 1;
      for (; s[m + v] === b;) v++;
      const f = Math.min(v, 3),
        k = b.repeat(f);
      if (!(f === 3 ? p && i : f === 2 ? p : i)) {
        const B = s[m + f] ?? " ";
        if (/\s/.test(B) || !u(k.length === 3 ? b.repeat(1) : k, m + f)) {
          ((l += b.repeat(v)), (m += v - 1));
          continue;
        }
        (d(), f >= 2 && (p = !0), (f === 1 || f === 3) && (i = !0));
      } else (d(), f >= 2 && (p = !1), (f === 1 || f === 3) && (i = !1));
      ((m += f - 1), v > f && ((l += b.repeat(v - f)), (m += v - f)));
      continue;
    }
    l += b;
  }
  return (d(), a.filter((m) => m.text.length > 0));
}
function ct(o) {
  const s = o.replace(
      /\r\n?/g,
      `
`,
    ).split(`
`),
    a = [];
  let p = [];
  const i = () => {
    if (!p.length) return;
    const d = oe(p.join(" ").replace(/\s+/g, " ").trim());
    (d.length && a.push({ kind: "para", spans: d }), (p = []));
  };
  let l = null;
  for (const d of s) {
    const u = d.replace(/\s+$/, "");
    if (!u.trim()) {
      (i(), (l = null));
      continue;
    }
    if (
      /^\s*([-*_])(\s*\1){2,}\s*$/.test(u) ||
      /^\s*(={3,}|-{3,})\s*$/.test(u)
    ) {
      (i(), (l = null));
      continue;
    }
    const m = /^\s{0,3}(#{1,6})\s+(.*?)\s*#*\s*$/.exec(u);
    if (m) {
      (i(), (l = null));
      const f = oe(m[2]).map((k) => ({ ...k, bold: !0 }));
      f.length &&
        a.push({ kind: "heading", level: Math.min(m[1].length, 3), spans: f });
      continue;
    }
    const b = /^\s*[-*+]\s+(.*)$/.exec(u),
      N = /^\s*(\d{1,4})[.)]\s+(.*)$/.exec(u);
    if (b || N) {
      i();
      const f = oe((b ? b[1] : N[2]).trim()),
        k = b
          ? { kind: "bullet", spans: f }
          : { kind: "number", n: Number(N[1]), spans: f };
      (a.push(k), (l = k));
      continue;
    }
    const v = u.replace(/^\s{0,3}>\s?/, "");
    if (l && /^\s+\S/.test(u)) {
      l.spans.push({ text: " ", bold: !1, italic: !1 }, ...oe(v.trim()));
      continue;
    }
    ((l = null), p.push(v.trim()));
  }
  return (i(), a);
}
function dt(o) {
  const s = [];
  let a = null,
    p = !1;
  for (const i of o)
    for (const l of i.text.split(/(\s+)/))
      if (l) {
        if (/^\s+$/.test(l)) {
          ((a = null), (p = !0));
          continue;
        }
        (a ||
          ((a = { pieces: [], spaceBefore: p && s.length > 0 }),
          s.push(a),
          (p = !1)),
          a.pieces.push({ text: l, bold: i.bold, italic: i.italic }));
      }
  return s;
}
function je(o, s, a, p = s) {
  const i = [];
  let l = [],
    d = 0,
    u = p;
  const m = (N, v, f) => {
      const k = l[l.length - 1];
      k && k.bold === v && k.italic === f
        ? (k.text += N)
        : l.push({ text: N, bold: v, italic: f });
    },
    b = () => {
      (i.push(l), (l = []), (d = 0), (u = s));
    };
  for (const N of dt(o)) {
    const v = N.pieces.reduce((S, B) => S + a(B.text, B.bold, B.italic), 0),
      f = l.length && N.spaceBefore ? a(" ", !1, !1) : 0;
    l.length && d + f + v > u && b();
    const k = l.length && N.spaceBefore ? a(" ", !1, !1) : 0;
    if (v > u) {
      for (const S of N.pieces)
        for (const B of S.text) {
          const z = a(B, S.bold, S.italic);
          (l.length && d + z > u && b(), m(B, S.bold, S.italic), (d += z));
        }
      continue;
    }
    k && (m(" ", !1, !1), (d += k));
    for (const S of N.pieces) m(S.text, S.bold, S.italic);
    d += v;
  }
  return (l.length && i.push(l), i);
}
const T = 46,
  ut = 18,
  mt = 10,
  ve = 6;
function pt(o) {
  const s = /^#?([0-9a-f]{6})$/i.exec(o.trim()),
    a = s ? parseInt(s[1], 16) : 5195493;
  return Q(((a >> 16) & 255) / 255, ((a >> 8) & 255) / 255, (a & 255) / 255);
}
function ht(o, s) {
  const a = [];
  let p = 0,
    i = 0,
    l = s.firstTop;
  for (const d of o) {
    const u = d.lead ?? s.lead,
      m = l === (p === 0 ? s.firstTop : s.top) ? 0 : d.gapBefore;
    if (l - m - u < s.bottom) {
      (i++,
        i >= s.columns && ((i = 0), p++),
        (l = p === 0 ? s.firstTop : s.top),
        a.push({ ...d, page: p, col: i, y: l - u }),
        (l -= u));
      continue;
    }
    ((l -= m), a.push({ ...d, page: p, col: i, y: l - u }), (l -= u));
  }
  return a;
}
function gt(o, s, a, p) {
  const i = Math.max(a / o, p / s),
    l = o * i,
    d = s * i;
  return { x: (a - l) / 2, y: (p - d) / 2, width: l, height: d };
}
const ft = { 1: 15, 2: 13, 3: 11.5 };
async function xt(o, s) {
  const a = o.map((h) => ({ ...h, body: ot(h.body) })),
    p = await _e.create(),
    i = await Ye.create(
      p,
      [s.title, s.issue, ...a.flatMap((h) => [h.title, h.author, h.body])]
        .join(`
`) + "•—",
    ),
    l = pt(s.accent),
    [d, u] = qe[s.page],
    m = s.gutter ?? ut,
    b = s.bodySize ?? mt,
    N = Math.round(b * 1.4 * 2) / 2,
    v = (d - T * 2 - m * (s.columns - 1)) / s.columns,
    f = T + 14,
    k = u - T - 22,
    S = Q(0.45, 0.45, 0.5),
    B = new Map();
  for (const h of a)
    if (h.image)
      try {
        B.set(
          h,
          h.image.isPng
            ? await p.embedPng(h.image.bytes)
            : await p.embedJpg(h.image.bytes),
        );
      } catch {}
  let z = null;
  if (s.logo)
    try {
      z = s.logo.isPng
        ? await p.embedPng(s.logo.bytes)
        : await p.embedJpg(s.logo.bytes);
    } catch {}
  let J = null;
  if (s.cover && s.coverImage)
    try {
      J = s.coverImage.isPng
        ? await p.embedPng(s.coverImage.bytes)
        : await p.embedJpg(s.coverImage.bytes);
    } catch {}
  let C = (s.cover ? 1 : 0) + (s.contents ? 1 : 0);
  const E = a.map((h) => {
    const x = i.wrap(h.title, 26, d - T * 2, !0).slice(0, 3),
      g = B.get(h);
    let F = x.length * 31 + (h.author.trim() ? 18 : 0) + 14,
      y = 0,
      I = 0;
    g &&
      ((I = d - T * 2),
      (y = Math.min(I * (g.height / g.width), 220)),
      (I = Math.min(I, y * (g.width / g.height))),
      (F += y + 14));
    const $ = [],
      R = (L) => (_, r, j) => i.set.width(_, L, "sans", r, j);
    for (const L of ct(h.body))
      if (L.kind === "heading") {
        const _ = ft[L.level];
        je(L.spans, v, R(_)).forEach((r, j) =>
          $.push({
            segs: r,
            size: _,
            indent: 0,
            gapBefore: j === 0 ? ve + 4 : 0,
            lead: Math.round(_ * 1.3),
          }),
        );
      } else {
        const _ = L.kind === "para" ? 0 : 14,
          r =
            L.kind === "bullet"
              ? "•"
              : L.kind === "number"
                ? `${L.n}.`
                : void 0;
        je(L.spans, v - _, R(b)).forEach((j, A) =>
          $.push({
            segs: j,
            size: b,
            indent: _,
            marker: A === 0 ? r : void 0,
            gapBefore: A === 0 ? (r ? 2 : ve) : 0,
            lead: N,
          }),
        );
      }
    const V = ht($, {
        columns: s.columns,
        firstTop: k - F,
        top: k,
        bottom: f,
        lead: N,
      }),
      O = Math.max(1, ...V.map((L) => L.page + 1)),
      q = C;
    return (
      (C += O),
      {
        a: h,
        titleLines: x,
        im: g,
        imgW: I,
        imgH: y,
        placed: V,
        pageCount: O,
        start: q,
      }
    );
  });
  if (s.cover) {
    const h = p.addPage([d, u]);
    if ((h.drawRectangle({ x: 0, y: 0, width: d, height: u, color: l }), J)) {
      const g = gt(J.width, J.height, d, u);
      (h.pushOperators(Ue(), Je(0, 0, d, u), He(), Ze()),
        h.drawImage(J, g),
        h.pushOperators(Ve()),
        h.drawRectangle({
          x: 0,
          y: 0,
          width: d,
          height: u,
          color: Q(0, 0, 0),
          opacity: 0.28,
        }),
        h.drawRectangle({
          x: 0,
          y: u * 0.6 - 140,
          width: d,
          height: 230,
          color: Q(0, 0, 0),
          opacity: 0.45,
        }));
    }
    if (z) {
      const g = Math.min(150 / z.width, 60 / z.height, 1);
      h.drawImage(z, {
        x: T + 10,
        y: u - T - z.height * g,
        width: z.width * g,
        height: z.height * g,
      });
    }
    const x = i.wrap(s.title || "Magazine", 44, d - 100, !0).slice(0, 3);
    (x.forEach((g, F) =>
      i.draw(h, g, {
        x: T + 10,
        y: u * 0.6 - F * 52,
        size: 44,
        bold: !0,
        color: Q(1, 1, 1),
      }),
    ),
      s.issue.trim() &&
        i.draw(h, s.issue, {
          x: T + 10,
          y: u * 0.6 - x.length * 52 - 10,
          size: 16,
          color: Q(1, 1, 1),
        }));
  }
  if (s.contents) {
    const h = p.addPage([d, u]);
    i.draw(h, "In this issue", {
      x: T,
      y: u - T - 24,
      size: 24,
      bold: !0,
      color: l,
    });
    const x = it(
      E.map((g) => ({
        title:
          g.a.title.length > (s.tocStyle === "grid" ? 32 : 60)
            ? g.a.title.slice(0, s.tocStyle === "grid" ? 30 : 58) + "…"
            : g.a.title,
        author: g.a.author.trim(),
        page: g.start + 1,
      })),
      s.tocStyle ?? "list",
      { left: T, right: d - T, top: u - T - 72 },
    );
    for (const g of x) {
      const F = String(g.entry.page),
        y = g.entry.title;
      if (
        (i.draw(h, y, { x: g.x, y: g.y, size: 12, bold: !0 }),
        g.entry.author &&
          i.draw(h, g.entry.author, { x: g.x, y: g.y - 13, size: 9, color: S }),
        i.drawRight(h, F, {
          rightX: g.x + g.width,
          y: g.y,
          size: 12,
          bold: !0,
          color: l,
        }),
        g.dots)
      ) {
        const I = g.x + i.width(y, 12, !0) + 6,
          $ = g.x + g.width - i.width(F, 12, !0) - 6;
        $ > I &&
          h.drawLine({
            start: { x: I, y: g.y + 3 },
            end: { x: $, y: g.y + 3 },
            thickness: 1,
            color: S,
            dashArray: [1, 3],
          });
      }
    }
  }
  for (const h of E) {
    const x = [];
    for (let y = 0; y < h.pageCount; y++) {
      const I = p.addPage([d, u]);
      x.push(I);
      const $ = String(h.start + y + 1);
      if ((i.draw(I, s.title, { x: T, y: u - T + 4, size: 8, color: S }), z)) {
        const R = Math.min(40 / z.width, 16 / z.height, 1);
        I.drawImage(z, {
          x: d - T - z.width * R,
          y: u - T + 3,
          width: z.width * R,
          height: z.height * R,
        });
      }
      (I.drawLine({
        start: { x: T, y: u - T },
        end: { x: d - T, y: u - T },
        thickness: 0.6,
        color: l,
      }),
        i.draw(I, $, {
          x: (d - i.width($, 9)) / 2,
          y: T - 8,
          size: 9,
          color: S,
        }));
    }
    const g = x[0];
    let F = k;
    (h.titleLines.forEach((y) => {
      ((F -= 31),
        i.draw(g, y, {
          x: T,
          y: F + 6,
          size: 26,
          bold: !0,
          color: Q(0.1, 0.1, 0.12),
        }));
    }),
      h.a.author.trim() &&
        ((F -= 18),
        i.draw(g, `By ${h.a.author.trim()}`, {
          x: T,
          y: F + 4,
          size: 10,
          color: l,
        })),
      (F -= 14),
      h.im &&
        g.drawImage(h.im, {
          x: T,
          y: F - h.imgH,
          width: h.imgW,
          height: h.imgH,
        }));
    for (const y of h.placed) {
      const I = x[y.page],
        $ = T + y.col * (v + m),
        R = Q(0.15, 0.15, 0.18);
      y.marker &&
        i.draw(I, y.marker, { x: $ + 2, y: y.y + 3, size: y.size, color: l });
      let V = $ + y.indent;
      for (const O of y.segs)
        for (const q of i.set.runs(O.text, "sans", O.bold, O.italic))
          (i.set.drawRun(I, q, { x: V, y: y.y + 3, size: y.size, color: R }),
            (V += q.font.widthOfTextAtSize(q.text, y.size)));
    }
  }
  return (
    await i.finish(),
    p.setTitle(s.title || "Magazine"),
    p.setProducer("FreeDailyPro"),
    { bytes: await p.save(), pageCount: p.getPageCount(), note: i.note() }
  );
}
const bt = [
  {
    id: "feature",
    name: "Feature issue",
    blurb:
      "2 columns, a cover and contents: an editor's letter, a cover story and a back page.",
    columns: 2,
    page: "letter",
    accent: "#0f766e",
    cover: !0,
    contents: !0,
    slots: [
      {
        title: "From the editor",
        hint: "A short welcome and what is in this issue.",
      },
      { title: "Cover story", hint: "The main feature of the issue." },
      {
        title: "Back page",
        hint: "A closing column, a calendar or a reader letter.",
      },
    ],
  },
  {
    id: "photo",
    name: "Photo feature",
    blurb: "1 wide column with a picture under each headline.",
    columns: 1,
    page: "letter",
    accent: "#be123c",
    cover: !0,
    contents: !1,
    slots: [
      {
        title: "Feature story",
        hint: "The story behind the pictures. Add a picture to this article for a full-width image.",
      },
      { title: "Gallery notes", hint: "Captions and credits." },
    ],
  },
  {
    id: "report",
    name: "Report",
    blurb: "2 columns, a contents page and headings, A4.",
    columns: 2,
    page: "a4",
    accent: "#1d4ed8",
    cover: !0,
    contents: !0,
    slots: [
      {
        title: "Summary",
        hint: "Key findings in a few sentences. Markdown works: # Heading, **bold**, - bullets.",
      },
      { title: "Details", hint: "The main body of the report." },
      { title: "Next steps", hint: "What happens next, and who does it." },
    ],
  },
];
let yt = 1;
const ae = () => ({ id: yt++, title: "", author: "", body: "" });
function jt() {
  const [o, s] = w.useState(() => [ae()]),
    [a, p] = w.useState(""),
    [i, l] = w.useState(""),
    [d, u] = w.useState("2"),
    [m, b] = w.useState("letter"),
    [N, v] = w.useState("#4f46e5"),
    [f, k] = w.useState(!0),
    [S, B] = w.useState(!0),
    [z, J] = w.useState(!1),
    [Z, C] = w.useState(null),
    [E, M] = w.useState(null),
    [h, x] = w.useState(""),
    [g, F] = w.useState("list"),
    [y, I] = w.useState(""),
    [$, R] = w.useState(""),
    [V, O] = w.useState(""),
    { logExportNow: q } = Ne(),
    L = (t) => {
      (u(String(t.columns)), b(t.page), v(t.accent), k(t.cover), B(t.contents));
      const n = o.some((c) => c.title.trim() || c.body.trim() || c.image);
      (n || s(t.slots.map((c) => ({ ...ae(), title: c.title, hint: c.hint }))),
        C(null),
        x(""),
        W.success(
          n
            ? `${t.name} layout applied. Your articles were kept.`
            : `${t.name} template ready. Write each article, then Build Magazine.`,
        ));
    },
    _ = (t) => {
      I(t);
      const n = t ? de(t) : void 0;
      (n && u(String(n.columns)), C(null));
    },
    r = async (t) => {
      if (!t) return;
      const n = Re(await t.text());
      if (!n.ok) {
        (O(n.error), W.error(n.error));
        return;
      }
      j(n.profile);
    },
    j = (t) => {
      const n = Oe(t);
      (n && v(n),
        t.logo && R(t.logo),
        C(null),
        O(`Brand loaded${t.name ? `: ${t.name}` : ""}.`));
    },
    A = () => {
      (Ke(
        `${(a || "magazine").replace(/[^\w-]+/g, "_")}.issue.json`,
        at({
          title: a,
          issue: i,
          columns: Number(d),
          page: m,
          accent: N,
          cover: f,
          contents: S,
          tocStyle: g,
          columnTemplate: y,
          logo: $,
          coverImage: E ? me(E.bytes, E.isPng) : "",
          articles: o.map((t) => ({
            title: t.title,
            author: t.author,
            body: t.body,
            image: t.image ? me(t.image.bytes, t.image.isPng) : "",
          })),
        }),
      ),
        O("Issue saved to your device. Open it again with Open saved issue."));
    },
    P = async (t) => {
      if (!t) return;
      const n = nt(await t.text());
      if (!n.ok) {
        (O(n.error), W.error(n.error));
        return;
      }
      const c = n.issue;
      (p(c.title),
        l(c.issue),
        u(String(c.columns)),
        b(c.page),
        v(c.accent),
        k(c.cover),
        B(c.contents),
        F(c.tocStyle),
        I(c.columnTemplate),
        R(c.logo));
      const G = be(c.coverImage);
      (M(G ? { ...G, url: c.coverImage } : null),
        s(
          c.articles.length
            ? c.articles.map((H) => {
                const ge = be(H.image);
                return {
                  ...ae(),
                  title: H.title,
                  author: H.author,
                  body: H.body,
                  image: ge ? { ...ge, url: H.image } : void 0,
                };
              })
            : [ae()],
        ),
        C(null),
        x(""),
        O(
          `Opened an issue with ${c.articles.length} article${c.articles.length === 1 ? "" : "s"}.`,
        ));
    },
    Y = (t, n) => {
      (x(""),
        s((c) => c.map((G) => (G.id === t ? { ...G, ...n } : G))),
        C(null));
    },
    K = (t, n) =>
      s((c) => {
        const G = t + n;
        if (G < 0 || G >= c.length) return c;
        const H = c.slice();
        return (([H[t], H[G]] = [H[G], H[t]]), H);
      }),
    Ae = async (t, n) => {
      if (n)
        try {
          const c = await ue(n);
          Y(t, {
            image: {
              bytes: new Uint8Array(await c.arrayBuffer()),
              isPng: c.type === "image/png",
              url: URL.createObjectURL(c),
            },
          });
        } catch {
          W.error("That image couldn't be read. Try a JPG or PNG.");
        }
    },
    Me = async (t) => {
      if (t)
        try {
          const n = await ue(t);
          (M({
            bytes: new Uint8Array(await n.arrayBuffer()),
            isPng: n.type === "image/png",
            url: URL.createObjectURL(n),
          }),
            C(null));
        } catch {
          W.error("That image couldn't be read. Try a JPG or PNG.");
        }
    },
    Fe = async (t, n) => {
      if (n) {
        if (!/\.(txt|md)$/i.test(n.name)) {
          W.error("Import a .txt or .md file, or paste the text.");
          return;
        }
        Y(t, {
          body: await n.text(),
          title:
            o.find((c) => c.id === t)?.title ||
            n.name.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " "),
        });
      }
    },
    $e = async () => {
      const t = o
        .filter((n) => n.title.trim() && n.body.trim())
        .map((n) => ({
          title: n.title.trim(),
          author: n.author.trim(),
          body: n.body,
          image: n.image
            ? { bytes: n.image.bytes, isPng: n.image.isPng }
            : void 0,
        }));
      if (!t.length) {
        x(
          "Add at least one article with a title and text, then press Build Magazine.",
        );
        return;
      }
      if (f && !a.trim()) {
        x("Enter a magazine title, or turn off the cover page.");
        return;
      }
      (x(""), J(!0));
      try {
        const n = {
            title: a.trim(),
            issue: i.trim(),
            columns: Number(d),
            page: m,
            cover: f,
            contents: S,
            accent: N,
            coverImage: f && E ? { bytes: E.bytes, isPng: E.isPng } : void 0,
            tocStyle: g,
            logo: We($) ?? void 0,
            ...(y ? { gutter: de(y)?.gutter, bodySize: de(y)?.bodySize } : {}),
          },
          c = await xt(t, n);
        (C({
          blob: we(c.bytes),
          pages: c.pageCount,
          key: Pe({ articles: t, opts: n }),
        }),
          W.success("Magazine ready!"),
          c.note && W.warning(c.note));
      } catch (n) {
        (console.error(n),
          W.error(
            n instanceof Error ? n.message : "Could not build the magazine",
          ));
      } finally {
        J(!1);
      }
    };
  return e.jsxs("div", {
    className: "space-y-6",
    "data-testid": "magazine-builder",
    children: [
      e.jsxs("div", {
        children: [
          e.jsx(D, {
            className: "mb-2 block",
            children: "Start from a template (optional)",
          }),
          e.jsx("div", {
            className: "grid sm:grid-cols-3 gap-2",
            role: "group",
            "aria-label": "Starter templates",
            children: bt.map((t) =>
              e.jsxs(
                U,
                {
                  type: "button",
                  variant: "outline",
                  className:
                    "h-auto py-2 flex-col items-start text-left whitespace-normal",
                  onClick: () => L(t),
                  children: [
                    e.jsx("span", {
                      className: "text-sm font-medium",
                      children: t.name,
                    }),
                    e.jsx("span", {
                      className: "text-xs font-normal text-muted-foreground",
                      children: t.blurb,
                    }),
                  ],
                },
                t.id,
              ),
            ),
          }),
        ],
      }),
      e.jsxs("div", {
        className: "grid sm:grid-cols-2 gap-4",
        children: [
          e.jsxs("div", {
            children: [
              e.jsx(D, { children: "Magazine Title" }),
              e.jsx(ee, {
                "aria-label": "Magazine Title",
                value: a,
                onChange: (t) => {
                  (p(t.target.value), C(null), x(""));
                },
                placeholder: "e.g. The Weekend Reader",
              }),
            ],
          }),
          e.jsxs("div", {
            children: [
              e.jsx(D, { children: "Issue (optional)" }),
              e.jsx(ee, {
                "aria-label": "Issue (optional)",
                value: i,
                onChange: (t) => {
                  (l(t.target.value), C(null), x(""));
                },
                placeholder: "e.g. October 2026",
              }),
            ],
          }),
        ],
      }),
      e.jsxs("div", {
        children: [
          e.jsx(D, { className: "mb-2 block", children: "Articles" }),
          e.jsx("div", {
            className: "space-y-3",
            children: o.map((t, n) =>
              e.jsxs(
                ce,
                {
                  className: "p-3 space-y-2",
                  children: [
                    e.jsxs("div", {
                      className: "flex items-center gap-2",
                      children: [
                        e.jsxs("span", {
                          className:
                            "text-xs text-muted-foreground w-6 shrink-0",
                          children: [n + 1, "."],
                        }),
                        e.jsx(ee, {
                          "aria-label": `Article ${n + 1} title`,
                          value: t.title,
                          onChange: (c) => Y(t.id, { title: c.target.value }),
                          placeholder: "Article title",
                        }),
                        e.jsx(ee, {
                          "aria-label": `Article ${n + 1} author`,
                          value: t.author,
                          onChange: (c) => Y(t.id, { author: c.target.value }),
                          placeholder: "Author (optional)",
                          className: "max-w-[200px]",
                        }),
                        e.jsx(U, {
                          type: "button",
                          size: "icon",
                          variant: "ghost",
                          "aria-label": `Move article ${n + 1} up`,
                          disabled: n === 0,
                          onClick: () => {
                            (K(n, -1), C(null));
                          },
                          children: e.jsx(Be, { className: "h-4 w-4" }),
                        }),
                        e.jsx(U, {
                          type: "button",
                          size: "icon",
                          variant: "ghost",
                          "aria-label": `Move article ${n + 1} down`,
                          disabled: n === o.length - 1,
                          onClick: () => {
                            (K(n, 1), C(null));
                          },
                          children: e.jsx(Xe, { className: "h-4 w-4" }),
                        }),
                        e.jsx(U, {
                          type: "button",
                          size: "icon",
                          variant: "ghost",
                          "aria-label": `Remove article ${n + 1}`,
                          onClick: () => {
                            (s((c) => c.filter((G) => G.id !== t.id)), C(null));
                          },
                          children: e.jsx(Qe, { className: "h-4 w-4" }),
                        }),
                      ],
                    }),
                    e.jsx(ke, {
                      "aria-label": `Article ${n + 1} text`,
                      value: t.body,
                      onChange: (c) => Y(t.id, { body: c.target.value }),
                      rows: 6,
                      placeholder:
                        t.hint ??
                        "Article text. Leave a blank line between paragraphs. Markdown works: # Heading, **bold**, *italic*, - bullets, 1. numbers.",
                    }),
                    rt(t.body) &&
                      e.jsx(Le, {
                        className: "text-xs",
                        role: "status",
                        children:
                          "Emoji can't be printed in the PDF and will be left out.",
                      }),
                    e.jsxs("div", {
                      className: "flex items-center gap-4 flex-wrap",
                      children: [
                        e.jsxs("label", {
                          className:
                            "inline-flex items-center gap-2 text-xs cursor-pointer text-muted-foreground hover:text-foreground",
                          children: [
                            e.jsx(ye, { className: "h-4 w-4" }),
                            t.image ? "Change picture" : "Add picture",
                            e.jsx("input", {
                              type: "file",
                              accept: "image/*",
                              className: "hidden",
                              onChange: (c) => {
                                (Ae(t.id, c.target.files?.[0]),
                                  (c.target.value = ""));
                              },
                            }),
                          ],
                        }),
                        t.image &&
                          e.jsxs(e.Fragment, {
                            children: [
                              e.jsx("img", {
                                src: t.image.url,
                                alt: "",
                                className:
                                  "h-10 w-14 object-cover rounded border",
                              }),
                              e.jsx("button", {
                                type: "button",
                                className: "text-xs underline",
                                onClick: () => Y(t.id, { image: void 0 }),
                                children: "Remove",
                              }),
                            ],
                          }),
                        e.jsxs("label", {
                          className:
                            "text-xs cursor-pointer text-muted-foreground hover:text-foreground underline",
                          children: [
                            "Load text from .txt/.md",
                            e.jsx("input", {
                              type: "file",
                              accept: ".txt,.md,text/plain",
                              className: "hidden",
                              onChange: (c) => {
                                (Fe(t.id, c.target.files?.[0]),
                                  (c.target.value = ""));
                              },
                            }),
                          ],
                        }),
                        e.jsxs("span", {
                          className: "text-xs text-muted-foreground ml-auto",
                          children: [
                            t.body.trim()
                              ? t.body.trim().split(/\s+/).length
                              : 0,
                            " words",
                          ],
                        }),
                      ],
                    }),
                  ],
                },
                t.id,
              ),
            ),
          }),
          e.jsxs(U, {
            type: "button",
            variant: "outline",
            className: "mt-3 gap-1",
            onClick: () => {
              (s((t) => [...t, ae()]), C(null));
            },
            children: [e.jsx(Ee, { className: "h-4 w-4" }), " Add article"],
          }),
        ],
      }),
      e.jsxs(ce, {
        className: "p-4 space-y-4",
        children: [
          e.jsx("p", { className: "text-sm font-medium", children: "Layout" }),
          e.jsxs("div", {
            className: "grid sm:grid-cols-3 gap-3",
            children: [
              e.jsxs("div", {
                children: [
                  e.jsx(D, { className: "text-xs", children: "Text columns" }),
                  e.jsxs(ne, {
                    value: d,
                    onValueChange: (t) => {
                      (u(t), C(null));
                    },
                    children: [
                      e.jsx(ie, {
                        "aria-label": "Text columns",
                        children: e.jsx(le, {}),
                      }),
                      e.jsxs(re, {
                        children: [
                          e.jsx(X, { value: "1", children: "1 column" }),
                          e.jsx(X, { value: "2", children: "2 columns" }),
                          e.jsx(X, { value: "3", children: "3 columns" }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx(D, { className: "text-xs", children: "Page size" }),
                  e.jsxs(ne, {
                    value: m,
                    onValueChange: (t) => {
                      (b(t), C(null));
                    },
                    children: [
                      e.jsx(ie, {
                        "aria-label": "Page size",
                        children: e.jsx(le, {}),
                      }),
                      e.jsxs(re, {
                        children: [
                          e.jsx(X, { value: "letter", children: "US Letter" }),
                          e.jsx(X, { value: "a4", children: "A4" }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx(D, { className: "text-xs", children: "Accent colour" }),
                  e.jsx(ee, {
                    "aria-label": "Accent colour",
                    type: "color",
                    value: N,
                    onChange: (t) => {
                      (v(t.target.value), C(null));
                    },
                    className: "h-9 p-1",
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("div", {
            className: "flex items-center gap-2",
            children: [
              e.jsx(se, {
                id: "mb-cover",
                checked: f,
                onCheckedChange: () => {
                  (k((t) => !t), C(null));
                },
              }),
              e.jsx(D, {
                htmlFor: "mb-cover",
                className: "font-normal cursor-pointer",
                children: "Cover page",
              }),
            ],
          }),
          f &&
            e.jsxs("div", {
              className: "flex items-center gap-3 flex-wrap pl-6",
              children: [
                e.jsxs("label", {
                  className:
                    "inline-flex items-center gap-2 text-xs cursor-pointer text-muted-foreground hover:text-foreground",
                  children: [
                    e.jsx(ye, { className: "h-4 w-4" }),
                    E ? "Change cover image" : "Add cover image (optional)",
                    e.jsx("input", {
                      type: "file",
                      accept: "image/*",
                      "aria-label": "Cover image",
                      className: "hidden",
                      onChange: (t) => {
                        (Me(t.target.files?.[0]), (t.target.value = ""));
                      },
                    }),
                  ],
                }),
                E &&
                  e.jsxs(e.Fragment, {
                    children: [
                      e.jsx("img", {
                        src: E.url,
                        alt: "",
                        className: "h-10 w-8 object-cover rounded border",
                      }),
                      e.jsx("button", {
                        type: "button",
                        className: "text-xs underline",
                        onClick: () => {
                          (M(null), C(null));
                        },
                        children: "Remove",
                      }),
                    ],
                  }),
                e.jsx("span", {
                  className: "text-xs text-muted-foreground",
                  children: "The title and issue are printed over the picture.",
                }),
              ],
            }),
          e.jsxs("div", {
            className: "flex items-center gap-2",
            children: [
              e.jsx(se, {
                id: "mb-toc",
                checked: S,
                onCheckedChange: () => {
                  (B((t) => !t), C(null));
                },
              }),
              e.jsx(D, {
                htmlFor: "mb-toc",
                className: "font-normal cursor-pointer",
                children: '"In this issue" page with page numbers',
              }),
            ],
          }),
          e.jsxs("div", {
            className: "grid sm:grid-cols-2 gap-3",
            children: [
              e.jsxs("div", {
                children: [
                  e.jsx(D, {
                    className: "text-xs",
                    children: "Column template",
                  }),
                  e.jsxs(ne, {
                    value: y || "none",
                    onValueChange: (t) => _(t === "none" ? "" : t),
                    children: [
                      e.jsx(ie, {
                        "aria-label": "Column template",
                        children: e.jsx(le, {}),
                      }),
                      e.jsxs(re, {
                        children: [
                          e.jsx(X, {
                            value: "none",
                            children: "Custom (use the column count above)",
                          }),
                          Ie.map((t) =>
                            e.jsxs(
                              X,
                              {
                                value: t.id,
                                children: [t.label, ": ", t.blurb],
                              },
                              t.id,
                            ),
                          ),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx(D, {
                    className: "text-xs",
                    children: "Contents page style",
                  }),
                  e.jsxs(ne, {
                    value: g,
                    onValueChange: (t) => {
                      (F(t), C(null));
                    },
                    children: [
                      e.jsx(ie, {
                        "aria-label": "Contents page style",
                        children: e.jsx(le, {}),
                      }),
                      e.jsx(re, {
                        children: st.map((t) =>
                          e.jsxs(
                            X,
                            { value: t.id, children: [t.label, ": ", t.blurb] },
                            t.id,
                          ),
                        ),
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
      e.jsxs(ce, {
        className: "p-4 space-y-3",
        "data-testid": "magazine-brand-card",
        children: [
          e.jsx("p", {
            className: "text-sm font-medium",
            children: "Brand and saved issues",
          }),
          e.jsxs("div", {
            className: "flex gap-2 flex-wrap items-center",
            children: [
              xe() &&
                e.jsx("button", {
                  type: "button",
                  className:
                    "inline-flex items-center rounded-md border px-3 h-9 text-sm hover:bg-accent",
                  "data-testid": "use-open-profile",
                  onClick: () => j(xe()),
                  children: "Use my open business profile",
                }),
              e.jsxs("label", {
                className: "inline-flex",
                children: [
                  e.jsx("span", {
                    className:
                      "inline-flex items-center rounded-md border px-3 h-9 text-sm cursor-pointer hover:bg-accent",
                    children: "Load brand profile",
                  }),
                  e.jsx("input", {
                    type: "file",
                    accept: ".json,application/json",
                    className: "hidden",
                    "aria-label": "Load brand profile file",
                    onChange: (t) => {
                      const n = t.target.files?.[0];
                      ((t.target.value = ""), r(n));
                    },
                  }),
                ],
              }),
              e.jsxs("label", {
                className: "inline-flex",
                children: [
                  e.jsx("span", {
                    className:
                      "inline-flex items-center rounded-md border px-3 h-9 text-sm cursor-pointer hover:bg-accent",
                    children: $ ? "Change logo" : "Add logo",
                  }),
                  e.jsx("input", {
                    type: "file",
                    accept: "image/png,image/jpeg",
                    className: "hidden",
                    "aria-label": "Logo",
                    onChange: async (t) => {
                      const n = t.target.files?.[0];
                      if (((t.target.value = ""), !!n))
                        try {
                          const c = await ue(n);
                          (R(
                            me(
                              new Uint8Array(await c.arrayBuffer()),
                              c.type === "image/png",
                            ),
                          ),
                            C(null));
                        } catch {
                          W.error(
                            "That logo couldn't be read. Try a PNG or JPG.",
                          );
                        }
                    },
                  }),
                ],
              }),
              $ &&
                e.jsx("button", {
                  type: "button",
                  className: "text-xs underline",
                  onClick: () => {
                    (R(""), C(null));
                  },
                  children: "Remove logo",
                }),
              e.jsx(U, {
                type: "button",
                variant: "outline",
                size: "sm",
                onClick: A,
                children: "Save issue to this device",
              }),
              e.jsxs("label", {
                className: "inline-flex",
                children: [
                  e.jsx("span", {
                    className:
                      "inline-flex items-center rounded-md border px-3 h-9 text-sm cursor-pointer hover:bg-accent",
                    children: "Open saved issue",
                  }),
                  e.jsx("input", {
                    type: "file",
                    accept: ".json,application/json",
                    className: "hidden",
                    "aria-label": "Open saved issue file",
                    onChange: (t) => {
                      const n = t.target.files?.[0];
                      ((t.target.value = ""), P(n));
                    },
                  }),
                ],
              }),
            ],
          }),
          V &&
            e.jsx("p", {
              role: "status",
              className: "text-xs text-muted-foreground",
              children: V,
            }),
          e.jsx("p", {
            className: "text-xs text-muted-foreground",
            children:
              "Saved files stay on your device; nothing is stored on our servers.",
          }),
        ],
      }),
      e.jsxs("div", {
        className: "flex gap-3",
        children: [
          z
            ? e.jsx(Ce, { message: "Building magazine..." })
            : Z
              ? e.jsx(Se, {
                  blob: Z.blob,
                  fileName: `${(a || "magazine").replace(/[^\w-]+/g, "_")}.pdf`,
                  label: `Download Magazine (${Z.pages} pages)`,
                  gate: () => q(Z.key),
                })
              : e.jsx(U, { onClick: $e, children: "Build Magazine" }),
          Z &&
            e.jsx(U, {
              variant: "outline",
              onClick: () => C(null),
              children: "Edit",
            }),
        ],
      }),
      h &&
        e.jsx("p", {
          role: "alert",
          className: "text-xs text-destructive -mt-3",
          children: h,
        }),
      Z && e.jsx(Te, { blob: Z.blob, mimeType: "application/pdf" }),
    ],
  });
}
function vt() {
  const [o, s] = w.useState([]),
    [a, p] = w.useState(""),
    [i, l] = w.useState(""),
    [d, u] = w.useState(!0),
    [m, b] = w.useState(!0),
    [N, v] = w.useState(!0),
    [f, k] = w.useState({ masthead: !1, contributors: !1 }),
    [S, B] = w.useState({ masthead: "", contributors: "" }),
    [z, J] = w.useState(!1),
    [Z, C] = w.useState(""),
    [E, M] = w.useState(null),
    [h, x] = w.useState(""),
    { logExportNow: g } = Ne(),
    [F, y] = w.useState(0),
    I = w.useCallback((r) => {
      const j = r.filter((A) => {
        const P = A.name.toLowerCase();
        return (
          P.endsWith(".pdf") ||
          P.endsWith(".docx") ||
          P.endsWith(".txt") ||
          /^image\/(png|jpe?g|webp|heic|heif)$/.test(A.type) ||
          /\.(heic|heif|webp)$/.test(P)
        );
      });
      (j.length < r.length &&
        W.warning(
          "Some files were skipped — Magazine Maker accepts PDF, Word (.docx), .txt and image files (PNG, JPEG, WebP, HEIC)",
        ),
        s((A) => {
          const P = tt(
            A.map((K) => K.file),
            j,
          );
          P.length > 0 &&
            W.warning(
              `${P.length === 1 ? "One file is" : `${P.length} files are`} already in your list — added anyway.`,
            );
          const Y = (K) =>
            K.name
              .replace(/\.[^.]+$/, "")
              .replace(/\s*\(\d+\)$/, "")
              .replace(/_/g, " ")
              .trim();
          return [...A, ...j.map((K) => ({ file: K, title: Y(K) }))];
        }),
        M(null),
        x(""));
    }, []),
    $ = (r) => {
      (s((j) => r.map((A) => j.find((P) => P.file === A))), M(null), x(""));
    },
    R = (r) => {
      (s((j) => j.filter((A, P) => P !== r)), M(null), x(""));
    },
    V = (r, j) => {
      (s((A) => A.map((P, Y) => (Y === r ? { ...P, title: j } : P))),
        M(null),
        x(""));
    },
    O = (r, j) => {
      if (!(!f[r] || !S[r].trim())) return { kind: r, heading: j, body: S[r] };
    },
    q = async () => {
      if (o.length === 0) {
        x(
          "Add at least one article file first (PDF, Word or image), then press Assemble Issue.",
        );
        return;
      }
      if (d && !a.trim()) {
        x("Enter an issue title, or turn off the cover page.");
        return;
      }
      (x(""), J(!0), M(null), x(""));
      try {
        const { bytes: r, totalPages: j } = await et({
            bookTitle: a,
            author: i,
            bookSize: "letter",
            sections: o,
            frontMatter: {
              title: d ? { kind: "title", heading: a, body: "" } : void 0,
              masthead: O("masthead", "Masthead"),
              contributors: O("contributors", "Contributors"),
            },
            backMatter: {},
            includeToc: m,
            includeListOfImages: N,
            onProgress: C,
          }),
          A = Pe({
            issueTitle: a,
            editor: i,
            includeCover: d,
            includeToc: m,
            includeListOfImages: N,
            masthead: f.masthead ? S.masthead : null,
            contributors: f.contributors ? S.contributors : null,
            sections: o.map((P) => [
              P.file.name,
              P.file.size,
              P.file.lastModified,
              P.title,
            ]),
          });
        (M({ blob: we(r), key: A }), y(j), W.success("Issue assembled!"));
      } catch (r) {
        (console.error("Magazine assembly failed:", r),
          W.error(
            r instanceof Error
              ? r.message
              : "Something went wrong assembling this issue",
          ));
      } finally {
        (J(!1), C(""));
      }
    },
    L = () => {
      (s([]), M(null), x(""), y(0));
    },
    _ = (r) => k((j) => ({ ...j, [r]: !j[r] }));
  return e.jsxs("div", {
    className: "space-y-6",
    children: [
      e.jsxs("div", {
        children: [
          e.jsx(D, { children: "Issue Title" }),
          e.jsx(ee, {
            "aria-label": "Issue Title",
            value: a,
            onChange: (r) => {
              (p(r.target.value), M(null), x(""));
            },
            placeholder: "e.g. The Autumn Issue",
          }),
        ],
      }),
      e.jsxs("div", {
        children: [
          e.jsx(D, { children: "Editor" }),
          e.jsx(ee, {
            "aria-label": "Editor",
            value: i,
            onChange: (r) => {
              (l(r.target.value), M(null), x(""));
            },
            placeholder: "Editor name",
          }),
        ],
      }),
      e.jsxs("div", {
        children: [
          e.jsx(D, {
            className: "mb-2 block",
            children: "Articles & Sections",
          }),
          o.length === 0
            ? e.jsx(fe, {
                gateAtDownload: !0,
                accept:
                  ".pdf,.docx,.txt,image/png,image/jpeg,image/jpg,image/webp,.heic,.heif",
                multiple: !0,
                onFiles: I,
                label: "Drop your article files",
                description:
                  "PDF, Word (.docx/.txt), or images — add as many as you need",
              })
            : e.jsxs("div", {
                className: "space-y-4",
                children: [
                  e.jsx(Ge, {
                    files: o.map((r) => r.file),
                    onReorder: $,
                    onRemove: R,
                  }),
                  e.jsx("div", {
                    className: "space-y-2",
                    children: o.map((r, j) =>
                      e.jsxs(
                        "div",
                        {
                          className: "flex items-center gap-2",
                          children: [
                            e.jsxs("span", {
                              className:
                                "text-xs text-muted-foreground w-6 shrink-0",
                              children: [j + 1, "."],
                            }),
                            e.jsx(ee, {
                              "aria-label": `Article title, file ${j + 1}`,
                              value: r.title,
                              onChange: (A) => V(j, A.target.value),
                              placeholder:
                                "Article title (appears in Table of Contents)",
                              className: "text-sm",
                            }),
                          ],
                        },
                        `${r.file.name}-${r.file.size}-${j}`,
                      ),
                    ),
                  }),
                  e.jsx(fe, {
                    gateAtDownload: !0,
                    accept:
                      ".pdf,.docx,.txt,image/png,image/jpeg,image/jpg,image/webp,.heic,.heif",
                    multiple: !0,
                    onFiles: I,
                    label: "Add another file",
                    description: "",
                  }),
                ],
              }),
        ],
      }),
      e.jsxs(ce, {
        className: "p-4 space-y-4",
        children: [
          e.jsx("p", {
            className: "text-sm font-medium",
            children: "Front Matter",
          }),
          e.jsxs("div", {
            className: "flex items-center gap-2",
            children: [
              e.jsx(se, {
                checked: d,
                onCheckedChange: () => {
                  (u((r) => !r), M(null), x(""));
                },
                id: "cover",
              }),
              e.jsx(D, {
                htmlFor: "cover",
                className: "font-normal cursor-pointer",
                children: "Cover Page (uses the issue title and editor above)",
              }),
            ],
          }),
          ["masthead", "contributors"].map((r) => {
            const j = { masthead: "Masthead", contributors: "Contributors" };
            return e.jsxs(
              "div",
              {
                className: "space-y-2",
                children: [
                  e.jsxs("div", {
                    className: "flex items-center gap-2",
                    children: [
                      e.jsx(se, {
                        checked: f[r],
                        onCheckedChange: () => {
                          (_(r), M(null), x(""));
                        },
                        id: r,
                      }),
                      e.jsx(D, {
                        htmlFor: r,
                        className: "font-normal cursor-pointer",
                        children: j[r],
                      }),
                    ],
                  }),
                  f[r] &&
                    e.jsx(ke, {
                      "aria-label": j[r],
                      value: S[r],
                      onChange: (A) => {
                        (B((P) => ({ ...P, [r]: A.target.value })),
                          M(null),
                          x(""));
                      },
                      placeholder:
                        r === "masthead"
                          ? "Publisher, editorial team, contact info..."
                          : "List your writers, photographers, and other contributors...",
                      rows: 3,
                    }),
                ],
              },
              r,
            );
          }),
          e.jsxs("div", {
            className: "flex items-center gap-2 pt-2 border-t",
            children: [
              e.jsx(se, {
                checked: m,
                onCheckedChange: () => {
                  (b((r) => !r), M(null), x(""));
                },
                id: "toc",
              }),
              e.jsx(D, {
                htmlFor: "toc",
                className: "font-normal cursor-pointer",
                children:
                  "Table of Contents (auto-generated from your article titles)",
              }),
            ],
          }),
          e.jsxs("div", {
            className: "flex items-center gap-2",
            children: [
              e.jsx(se, {
                checked: N,
                onCheckedChange: () => {
                  (v((r) => !r), M(null), x(""));
                },
                id: "loi",
              }),
              e.jsx(D, {
                htmlFor: "loi",
                className: "font-normal cursor-pointer",
                children:
                  "List of Images (auto-generated from images found in your PDF sections)",
              }),
            ],
          }),
        ],
      }),
      e.jsx("div", {
        className: "flex gap-3",
        children: z
          ? e.jsx(Ce, { message: Z || "Assembling..." })
          : E
            ? e.jsxs(e.Fragment, {
                children: [
                  e.jsx(Se, {
                    blob: E.blob,
                    gate: () => g(E.key),
                    fileName: `${(a || "magazine").replace(/[^\w-]+/g, "_")}.pdf`,
                    label: `Download Issue (${F} pages)`,
                  }),
                  e.jsx(U, {
                    variant: "outline",
                    onClick: L,
                    children: "New Issue",
                  }),
                ],
              })
            : e.jsx(U, { onClick: q, children: "Assemble Issue" }),
      }),
      h &&
        e.jsx("p", {
          role: "alert",
          className: "text-xs text-destructive -mt-3",
          children: h,
        }),
      E && e.jsx(Te, { blob: E.blob, mimeType: "application/pdf" }),
    ],
  });
}
function Ss() {
  const [o, s] = w.useState("articles");
  return e.jsxs(De, {
    children: [
      e.jsxs("div", {
        className: "flex gap-2 mb-6",
        role: "tablist",
        children: [
          e.jsx(U, {
            role: "tab",
            "aria-selected": o === "articles",
            variant: o === "articles" ? "default" : "outline",
            onClick: () => s("articles"),
            children: "Write articles",
          }),
          e.jsx(U, {
            role: "tab",
            "aria-selected": o === "files",
            variant: o === "files" ? "default" : "outline",
            onClick: () => s("files"),
            children: "Combine files",
          }),
        ],
      }),
      o === "articles" ? e.jsx(jt, {}) : e.jsx(vt, {}),
    ],
  });
}
export { Ss as default };
//# sourceMappingURL=MagazineMaker-BxIyBOvc.js.map
