# FDP-52: test inputs for Magazine Maker (articles, pictures, cover, logo, combine-mode files, saved-issue/brand JSON)
from PIL import Image, ImageDraw
import subprocess, json, os, shutil
def pic(name, w, h, c, label):
    im = Image.new('RGB', (w, h), c); d = ImageDraw.Draw(im); d.rectangle((w*0.1, h*0.1, w*0.9, h*0.9), outline='white', width=8); d.text((w*0.15, h*0.45), label, fill='white'); im.save(name)
pic('img_wide.jpg', 1600, 900, '#2a6f97', 'WIDE 16:9 PHOTO'); pic('img_tall.png', 600, 1400, '#8a2be2', 'TALL PORTRAIT'); pic('cover.jpg', 1700, 2200, '#264653', 'COVER PHOTO'); pic('logo.png', 400, 160, '#e76f51', 'ACME LOGO')
Image.open('img_wide.jpg').save('img_wide.webp', 'WEBP'); open('fake_image.jpg', 'w').write('not an image')
long = "# Spring Gala recap\n\nThe **annual gala** raised a record amount this year, with *over 300 guests* attending the evening at the riverside hall.\n\n## Highlights\n\n- Silent auction: 42 lots\n- Keynote by the founder\n- Live jazz trio\n\n1. Doors opened at 6 pm\n2. Dinner at 7 pm\n3. Awards at 9 pm\n\n" + "\n\n".join(f"Paragraph {i}: Volunteers set up tables, lights and the stage from early morning, and the team thanked every sponsor by name during the closing remarks. Guests stayed late to talk with the scholarship winners and to plan next year's event." for i in range(1, 26)) + "\n\nEmoji test 🎉🙂 should be left out."
open('article_long.md', 'w').write(long)
open('article_unicode.txt', 'w').write("Café, naïve, Zürich, São Paulo — “curly quotes” and ‘single’ … €50 ±2 °C.\n\nहिंदी में एक वाक्य यहाँ है।\n\n日本語の文章もここにあります。\n\nنص عربي للاختبار.\n\nΕλληνικά και Русский текст.")
open('article_plain.txt', 'w').write("Club news\n\nOur chess club met every Tuesday this term. Twelve new members joined and the junior team won the county cup.\n\nNext term we will run a beginners' workshop.")
html = "<html><body><h1>A Letter From the CEO</h1><p>This quarter we shipped two products and hired <b>twelve</b> people.</p><ul><li>Product A launched</li><li>Product B beta</li></ul>" + "<p>Thank you all for a strong quarter. " * 30 + "</p></body></html>"
open('_ceo.html', 'w').write(html); subprocess.run(['soffice', '--headless', '--convert-to', 'docx:MS Word 2007 XML', '_ceo.html'], check=True, capture_output=True); os.rename('_ceo.docx', 'ceo_letter.docx'); os.remove('_ceo.html')
shutil.copy('/workspace/deep/51-pdf-to-powerpoint/testfiles/P12_memo_from_writer.pdf', 'memo_A4.pdf'); shutil.copy('/workspace/deep/50-pdf-to-excel/testfiles/T01_bank_3pages_us.pdf', 'column_letter_3p.pdf')
shutil.copy('/workspace/deep/51-pdf-to-powerpoint/testfiles/P11_deck_from_pptx.pdf', 'photo_deck_16x9.pdf'); shutil.copy('/workspace/deep/51-pdf-to-powerpoint/testfiles/P05_password_u123.pdf', 'password_u123.pdf'); shutil.copy('/workspace/deep/51-pdf-to-powerpoint/testfiles/P06_damaged.pdf', 'damaged.pdf')
open('bad.json', 'w').write('{not json'); json.dump({'app': 'something-else', 'version': 1, 'articles': []}, open('wrong_app.issue.json', 'w'))
json.dump({'name': 'Acme Test Brand', 'colors': {'primary': '#c00000', 'secondary': '#222222'}}, open('brand_guess.json', 'w'))
print(sorted(os.listdir('.')))
