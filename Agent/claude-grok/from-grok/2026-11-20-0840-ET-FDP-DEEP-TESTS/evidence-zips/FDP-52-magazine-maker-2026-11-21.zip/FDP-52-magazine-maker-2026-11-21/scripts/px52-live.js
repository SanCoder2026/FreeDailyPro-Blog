// FDP-52 Magazine Maker, guest. Usage: node px52-live.js <zero|left|subset> [engine]   (TRIES env = fresh contexts to try for "left")
// zero: context at the cap (2/2) -> build in both modes, preview, Download/Drive dialogs, Day Pass (stops at email), Quick Buy (stops at Stripe), templates, saved-issue and brand files.
// left: context with uses left -> download, re-download, edit + download (per-export check), cap, reload.
// Never types an email/card, never clicks a pass "Continue", never clicks ads. The only password typed is the test PDF's own (u123).
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process'); const crypto = require('crypto');
const BASE = '/workspace/deep/52-magazine-maker/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/magazine-maker';
const mode = process.argv[2] || 'left'; const eng = process.argv[3] || 'chromium'; const sfx = eng === 'chromium' ? '' : '-' + eng;
fs.mkdirSync(OUT + 'downloads', { recursive: true }); fs.mkdirSync(OUT + 'cases', { recursive: true });
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim(); const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex').slice(0, 16);
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').replace(/dev[:%][^&"]*/g, 'dev:REDACTED').slice(0, 160);
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p; const net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true, locale: 'en-US' }); p = await c.newPage(); p.setDefaultTimeout(10000);
  await p.addInitScript(() => { window.__t = []; const seen = new WeakSet(); setInterval(() => { document.querySelectorAll('[data-sonner-toast]').forEach(n => { if (!seen.has(n)) { seen.add(n); window.__t.push((n.innerText || '').trim()); } }); }, 150); });
  p.on('request', r => { const d = r.postData() || ''; if (r.method() === 'POST') net.push({ t: Date.now(), u: red(r.url()), len: d.length, doc: /%PDF|Spring Gala|chess club|CEO|Volunteers set up|JFIF|PNG/.test(d) }); else if (/font|jsdelivr|unpkg|heic|mammoth|docx/i.test(r.url())) net.push({ t: Date.now(), u: red(r.url()), get: true }); });
  await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit + (u.tier ? ' ' + u.tier : ''); });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(300); } };
 const toasts = (n) => p.evaluate(n => (window.__t || []).slice(n), n); const tcount = () => p.evaluate(() => (window.__t || []).length);
 const sel = async (label, option) => { await p.getByRole('combobox', { name: label }).or(p.locator(`main button[aria-label="${label}"]`)).first().click(); await p.waitForTimeout(400); const opts = await p.getByRole('option').allInnerTexts(); if (option) await p.getByRole('option', { name: option }).first().click(); else await esc(); await p.waitForTimeout(300); return opts; };
 const tab = async (n) => { await p.locator('main button', { hasText: new RegExp('^' + n + '$') }).first().click(); await p.waitForTimeout(1000); };
 const fillArticle = async (i, a) => { if (i > 1) await p.getByRole('button', { name: 'Add article' }).click(); await p.waitForTimeout(300);
  await p.getByLabel(`Article ${i} title`, { exact: true }).fill(a.title); if (a.author) await p.getByLabel(`Article ${i} author`, { exact: true }).fill(a.author);
  if (a.text) await p.getByLabel(`Article ${i} text`, { exact: true }).fill(a.text);
  if (a.load) { const ins = p.locator('main input[type=file][accept=".txt,.md,text/plain"]'); await ins.nth(i - 1).setInputFiles(TF + a.load); await p.waitForTimeout(800); }
  if (a.pic) { const ins = p.locator('main input[type=file][accept="image/*"]:not([aria-label="Cover image"])'); await ins.nth(i - 1).setInputFiles(TF + a.pic); await p.waitForTimeout(1200); } };
 const resultInfo = () => p.evaluate(() => { const m = document.querySelector('main'); const dl = [...m.querySelectorAll('button')].map(x => x.innerText.trim()).filter(t => /^Download|Edit$|Save to/.test(t));
  const prev = [...m.querySelectorAll('iframe,embed,object,canvas,img')].filter(e => !e.closest('[data-ad-placement]') && (e.tagName !== 'IMG' || /^blob:|^data:/.test(e.src))).map(e => e.tagName + ':' + (e.src || e.data || '').slice(0, 30) + ':' + Math.round(e.getBoundingClientRect().width) + 'x' + Math.round(e.getBoundingClientRect().height));
  const alerts = [...m.querySelectorAll('[role=alert]')].map(a => a.innerText.trim()).filter(Boolean); return { dl, prev: prev.slice(0, 8), alerts }; });
 const build = async (id, btn) => { const n = await tcount(); const t0 = Date.now(); await p.getByRole('button', { name: btn }).click();
  await p.waitForFunction(() => /^Download/.test([...document.querySelectorAll('main button')].map(x => x.innerText.trim()).join('\n').split('\n').find(t => /^Download/.test(t)) || '') || [...document.querySelectorAll('main [role=alert]')].some(a => a.innerText.trim()), null, { timeout: 90000 }).catch(() => {});
  const r = { id, ms: Date.now() - t0, used: await used(), info: await resultInfo(), toasts: await toasts(n) }; await p.waitForTimeout(1500); await p.screenshot({ path: OUT + 'cases/' + id + sfx + '.png', fullPage: true }); return r; };
 const download = async (id, r) => { const bt = p.locator('main button', { hasText: /^Download/ }).first(); if (!(await bt.count())) { r.dl = 'absent'; return r; } r.before = await used(); const n = await tcount();
  const dp = p.waitForEvent('download', { timeout: 15000 }).catch(() => null); await bt.click(); const d = await dp; await p.waitForTimeout(2000);
  r.dialog = await dialog(); if (d) { const f = OUT + 'downloads/' + id + sfx + '-' + d.suggestedFilename(); await d.saveAs(f); r.download = { name: d.suggestedFilename(), bytes: fs.statSync(f).size, sha: sha(f) }; }
  r.after = await used(); r.dlToasts = await toasts(n);
  if (r.dialog) { await p.screenshot({ path: OUT + 'cases/' + id + sfx + '-dialog.png' }); if (mode === 'zero' && !R.dayPass) { const bp = p.getByRole('button', { name: /Buy Day Pass|Day Pass/ }); if (await bp.count()) { await bp.first().click(); await p.waitForTimeout(2500); R.dayPass = { dialog: await dialog(), emailField: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'dlg-daypass' + sfx + '.png' }); } } await esc(); }
  return r; };
 const act = async (name, loc) => { const r = { before: await used() }; if (!(await loc.count())) { r.missing = true; return r; }
  const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); const url0 = p.url(); await loc.first().click(); const pg = await pop; await p.waitForTimeout(2500);
  r.dialog = await dialog(); r.after = await used(); r.url = p.url() !== url0 ? red(p.url()) : null; if (pg) { await pg.waitForLoadState('domcontentloaded').catch(() => {}); r.popup = red(pg.url()); await pg.close(); }
  if (r.dialog) await p.screenshot({ path: OUT + 'dlg-' + name + sfx + '.png' }); await esc(); console.log(name, JSON.stringify(r).slice(0, 300)); return r; };
 const save = (k, r) => { R.cases[k] = r; console.log(k, JSON.stringify(r).slice(0, 700)); };
 const writeIssue = async (cols, page) => { await p.getByLabel('Magazine Title', { exact: true }).fill('Riverside Club Quarterly'); await p.getByLabel('Issue (optional)', { exact: true }).fill('Spring 2026');
  await fillArticle(1, { title: 'Spring Gala recap: a record night for the scholarship fund and our volunteers who made it happen', author: 'Ana Ruiz', load: 'article_long.md', pic: 'img_wide.jpg' });
  await fillArticle(2, { title: 'Voices from our members', author: 'Kenji Sato', load: 'article_unicode.txt', pic: 'img_tall.png' });
  await fillArticle(3, { title: 'Club news', text: fs.readFileSync(TF + 'article_plain.txt', 'utf8') });
  if (cols) R.colOpts = await sel('Text columns', cols); if (page) R.pageOpts = await sel('Page size', page);
  await p.locator('main input[aria-label="Cover image"]').setInputFiles(TF + 'cover.jpg'); await p.locator('main input[aria-label="Logo"]').setInputFiles(TF + 'logo.png'); await p.waitForTimeout(1000); };
 const combineIssue = async (files, pwd) => { await tab('Combine files'); await p.getByLabel('Issue Title', { exact: true }).fill('The Autumn Issue'); await p.getByLabel('Editor', { exact: true }).fill('Jordan Blake');
  const r = { load: [] }; for (const f of files) { const n = await tcount(); await p.locator('main input[type=file][accept^=".pdf"]').first().setInputFiles(TF + f); await p.waitForTimeout(2500);
   const dg = await dialog(); if (dg && /password/i.test(dg)) { const pf = p.locator('[role=dialog] input[type=password]'); if (await pf.count() && pwd) { await pf.fill(pwd); await p.keyboard.press('Enter'); await p.waitForTimeout(2500); } else await esc(); }
   r.load.push({ f, dialog: dg && dg.slice(0, 200), toasts: await toasts(n) }); }
  const titles = p.locator('main input[aria-label^="Article title, file"]'); const nT = await titles.count(); r.titleFields = nT; for (let i = 0; i < nT; i++) { const v = await titles.nth(i).inputValue(); r['title' + (i + 1)] = v; }
  if (nT) await titles.nth(0).fill('A Letter From the CEO'); return r; };
 if (mode === 'zero' || mode === 'subset') { for (let i = 0; i < 6; i++) { await open(); await p.waitForTimeout(1500); const u = await used(); R.tries.push(u); if (/^2\/2/.test(u) || mode === 'subset') break; await c.close(); }
  R.start = await used();
  if (mode === 'zero') { const seq = []; for (let i = 0; i < 45; i++) { await p.keyboard.press('Tab'); const a = await p.evaluate(() => { const e = document.activeElement; return e.tagName + ' ' + (e.getAttribute('aria-label') || e.innerText || '').trim().slice(0, 40).replace(/\n/g, ' '); }); seq.push(a); if (/Magazine Title/.test(a)) break; } R.kbd = { seq: seq.slice(-4), tabs: seq.length };
   R.colTemplates = await sel('Column template'); R.tocStyles = await sel('Contents page style');
   // W01: full Write-articles issue, 2 columns Letter
   await writeIssue(); let r = await build('Z-W01-write', 'Build Magazine'); r = await download('Z-W01-write', r); save('Z-W01-write', r);
   R.zeroDrive = await act('zero-drive', p.getByRole('button', { name: /Save to Google Drive/ })); R.zeroCloud = await act('zero-cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
   // Save issue (file) and re-open it
   { const dp = p.waitForEvent('download', { timeout: 8000 }).catch(() => null); await p.getByRole('button', { name: 'Edit', exact: true }).click().catch(() => {}); await p.getByRole('button', { name: 'Save issue to this device' }).click(); const d = await dp; if (d) { const f = OUT + 'downloads/Z-save-' + d.suggestedFilename(); await d.saveAs(f); R.saveIssue = { name: d.suggestedFilename(), bytes: fs.statSync(f).size, used: await used(), dialog: await dialog() }; } else R.saveIssue = { none: true, dialog: await dialog() }; await esc(); }
   for (const [k, f] of [['openBad', 'bad.json'], ['openWrongApp', 'wrong_app.issue.json'], ['brandGuess', 'brand_guess.json'], ['brandBad', 'bad.json']]) { const n = await tcount(); const inp = k.startsWith('open') ? 'Open saved issue file' : 'Load brand profile file'; await p.locator(`main input[aria-label="${inp}"]`).setInputFiles(TF + f); await p.waitForTimeout(1200); R[k] = { toasts: await toasts(n), alerts: (await resultInfo()).alerts }; console.log(k, JSON.stringify(R[k])); }
   if (R.saveIssue && R.saveIssue.name) { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); const n = await tcount(); await p.locator('main input[aria-label="Open saved issue file"]').setInputFiles(OUT + 'downloads/Z-save-' + R.saveIssue.name); await p.waitForTimeout(1500);
    R.reopen = { toasts: await toasts(n), title: await p.getByLabel('Magazine Title', { exact: true }).inputValue(), a1: await p.getByLabel('Article 1 title', { exact: true }).inputValue(), a3text: (await p.getByLabel('Article 3 text', { exact: true }).inputValue().catch(() => '')).slice(0, 40), pics: await p.locator('main img[src^="blob:"],main img[src^="data:"]').count() }; console.log('reopen', JSON.stringify(R.reopen)); }
   // W02: 3 columns A4 rebuild, dotted contents
   await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); await writeIssue('3 columns', 'A4'); await sel('Contents page style', /Dotted/); r = await build('Z-W02-3col-a4', 'Build Magazine'); save('Z-W02-3col-a4', r);
   // Templates
   for (const t of ['Feature issue', 'Photo feature', 'Report']) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); const n = await tcount(); await p.locator('main button', { hasText: t }).first().click(); await p.waitForTimeout(1200);
    const st = { toasts: await toasts(n), title: await p.getByLabel('Magazine Title', { exact: true }).inputValue(), articles: await p.locator('main textarea[aria-label^="Article"]').count(), firstText: (await p.locator('main textarea[aria-label^="Article"]').first().inputValue()).slice(0, 120) };
    const rb = await build('Z-T-' + t.replace(/ /g, ''), 'Build Magazine'); save('Z-T-' + t.replace(/ /g, ''), { ...st, ...rb }); }
   // Emoji-only / empty validation
   await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); r = await build('Z-W03-empty', 'Build Magazine'); save('Z-W03-empty', r);
   // Bad picture
   { const n = await tcount(); await p.locator('main input[type=file][accept="image/*"]:not([aria-label="Cover image"])').first().setInputFiles(TF + 'fake_image.jpg'); await p.waitForTimeout(1200); R.badPic = { toasts: await toasts(n) }; }
   // C01: Combine files
   await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
   let cr = await combineIssue(['ceo_letter.docx', 'column_letter_3p.pdf', 'memo_A4.pdf', 'photo_deck_16x9.pdf', 'img_wide.jpg', 'img_wide.webp', 'article_plain.txt', 'password_u123.pdf', 'damaged.pdf'], 'u123');
   for (const k of ['masthead', 'contributors']) await p.locator('main button#' + k).click(); await p.waitForTimeout(400);
   const tas = p.locator('main textarea'); cr.textareas = await tas.count(); for (let i = 0; i < cr.textareas; i++) await tas.nth(i).fill(i === 0 ? 'Publisher: Riverside Club\nContact: editor@example.com' : 'Writers: Ana Ruiz, Kenji Sato');
   r = await build('Z-C01-combine', 'Assemble Issue'); r = await download('Z-C01-combine', { ...cr, ...r }); save('Z-C01-combine', r);
   R.openDrive = await act('zero-open-drive', p.getByRole('button', { name: /Open from Google Drive/ }));
   R.end = await used();
   await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); const u0 = p.url();
   await p.getByRole('button', { name: 'Quick Buy' }).first().click(); await p.waitForTimeout(3000); R.qbDay = { url: p.url() !== u0 ? red(p.url()) : null, dialog: await dialog(), email: await p.locator('input[type=email]').count() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await esc();
   if (p.url() !== u0) { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); }
   await p.getByRole('button', { name: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); R.qbMonth = { url: red(p.url()), title: await p.title() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' }); }
  else { await writeIssue(); let r = await build('S01-write', 'Build Magazine'); r = await download('S01-write', r); save('S01-write', r);
   await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); const cr = await combineIssue(['ceo_letter.docx', 'memo_A4.pdf', 'img_wide.jpg']); r = await build('S02-combine', 'Assemble Issue'); r = await download('S02-combine', { ...cr, ...r }); save('S02-combine', r); } }
 if (mode === 'left4') { const NT = +(process.env.TRIES || 15); for (let i = 0; i < NT; i++) { await open(); const u = await used(); R.tries.push(u); if (!/^2\//.test(u)) { await p.waitForTimeout(5000); if (!/^2\//.test(await used())) break; } if (i < NT - 1) await c.close(); }
  R.start = await used();
  const cr = await combineIssue(['ceo_letter.docx', 'column_letter_3p.pdf', 'memo_A4.pdf', 'photo_deck_16x9.pdf', 'img_wide.jpg', 'article_plain.txt', 'password_u123.pdf'], 'u123');
  for (const k of ['masthead', 'contributors']) await p.locator('main button#' + k).click(); await p.waitForTimeout(400); const tas = p.locator('main textarea'); cr.textareas = await tas.count(); for (let i = 0; i < cr.textareas; i++) await tas.nth(i).fill(i === 0 ? 'Publisher: Riverside Club\nContact: editor@example.com' : 'Writers: Ana Ruiz, Kenji Sato');
  let r = await build('K01-combine', 'Assemble Issue'); r = await download('K01-combine', { ...cr, ...r }); save('K01-combine', r); R.end = await used(); }
 if (mode === 'left3') { const NT = +(process.env.TRIES || 15); for (let i = 0; i < NT; i++) { await open(); const u = await used(); R.tries.push(u); if (!/^2\//.test(u)) { await p.waitForTimeout(5000); if (!/^2\//.test(await used())) break; } if (i < NT - 1) await c.close(); }
  R.start = await used();
  await fillArticle(1, { title: 'Short note', text: 'One short article for the per-export check.' }); await p.getByLabel('Magazine Title', { exact: true }).fill('Per export check'); let r = await build('E01', 'Build Magazine'); r = await download('E01', r); save('E01', r);
  if (r.download) { await p.getByRole('button', { name: 'Edit', exact: true }).click(); await p.getByLabel('Article 1 title', { exact: true }).fill('Short note edited'); r = await build('E02-edited', 'Build Magazine'); r = await download('E02-edited', r); save('E02-edited', r); }
  R.end = await used(); }
 if (mode === 'left') { const NT = +(process.env.TRIES || 30); for (let i = 0; i < NT; i++) { await open(); const u = await used(); R.tries.push(u); if (!/^2\//.test(u)) { await p.waitForTimeout(5000); if (!/^2\//.test(await used())) break; } if (i < NT - 1) await c.close(); }
  R.start = await used();
  await writeIssue(); let r = await build('L01-write', 'Build Magazine'); r = await download('L01-write', r); save('L01-write', r);
  R.drive = await act('drive', p.getByRole('button', { name: /Save to Google Drive/ })); R.cloud = await act('cloud', p.getByRole('button', { name: /Save to my cloud storage/ }));
  r = await download('L01b-redownload', {}); save('L01b-redownload', r);
  await p.getByRole('button', { name: 'Edit', exact: true }).click(); await p.getByLabel('Article 3 title', { exact: true }).fill('Club news (edited)'); r = await build('L02-edited', 'Build Magazine'); r = await download('L02-edited', r); save('L02-edited', r);
  await p.getByRole('button', { name: 'Edit', exact: true }).click(); await p.getByLabel('Issue (optional)', { exact: true }).fill('Spring 2026 b'); r = await build('L03-edited-again', 'Build Magazine'); r = await download('L03-edited-again', r); save('L03-edited-again', r);
  await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); const cr = await combineIssue(['ceo_letter.docx', 'column_letter_3p.pdf', 'memo_A4.pdf', 'img_wide.jpg']); r = await build('L04-combine', 'Assemble Issue'); r = await download('L04-combine', { ...cr, ...r }); save('L04-combine', r);
  R.end = await used(); }
 R.t2 = now(); R.net = net; fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('tries', R.tries.join(','), 'start', R.start, 'end', R.end); await b.close(); })();
