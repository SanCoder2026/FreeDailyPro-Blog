// FDP-52 probe: dump controls in Write articles and Combine files modes (guest, no build/download)
const { chromium } = require('playwright'); const fs = require('fs'); const O = '/workspace/deep/52-magazine-maker/';
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); p.setDefaultTimeout(8000);
 await p.goto('https://www.freedailypro.com/tool/magazine-maker', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 const ctl = () => p.evaluate(() => [...document.querySelectorAll('main input,main select,main textarea,main button,main [role=radio],main [role=checkbox],main [role=tab],main [role=combobox]')].filter(x => !x.closest('[data-ad-placement]')).map(x => [x.tagName, x.type || x.getAttribute('role'), x.id, x.getAttribute('aria-label') || x.getAttribute('placeholder') || x.innerText?.trim().slice(0, 50) || x.value, x.accept || '', x.checked ?? x.getAttribute('aria-checked') ?? x.getAttribute('aria-pressed') ?? x.getAttribute('aria-selected') ?? x.getAttribute('data-state')]));
 const R = { write: await ctl() };
 await p.getByRole('tab', { name: 'Combine files' }).click().catch(async () => { await p.locator('main button', { hasText: /^Combine files$/ }).first().click(); }); await p.waitForTimeout(1500);
 R.combine = await ctl(); R.combineText = await p.evaluate(() => document.querySelector('main').innerText.split('Combine files')[1]?.slice(0, 2500));
 await p.screenshot({ path: O + 'live/probe-combine.png', fullPage: true });
 fs.writeFileSync(O + 'live/probe.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R).slice(0, 6000)); await b.close(); })();
