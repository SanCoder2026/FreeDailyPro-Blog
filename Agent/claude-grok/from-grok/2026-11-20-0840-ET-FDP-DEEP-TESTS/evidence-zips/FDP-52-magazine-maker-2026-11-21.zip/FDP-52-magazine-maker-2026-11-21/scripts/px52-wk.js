// FDP-52 WebKit checks: (1) gate in fresh contexts (short Write-articles issue -> Download), (2) Combine files with one file type at a time (tab crash isolation)
const pw = require('playwright'); const fs = require('fs'); const O = '/workspace/deep/52-magazine-maker/live/'; const TF = '/workspace/deep/52-magazine-maker/testfiles/';
const eng = process.argv[2] || 'webkit';
(async () => { const b = await pw[eng].launch(); const R = { gate: [], combine: [] };
 const ctx = async () => { const c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true }); const p = await c.newPage(); p.setDefaultTimeout(10000); const net = [];
  p.on('request', r => { if (/usage|access/.test(r.url())) net.push(r.method() + ' ' + r.url().replace(/dev[:%][^&"]*/g, 'dev:REDACTED').replace(/input=[^&]*/, 'input=…').slice(0, 100)); });
  await p.goto('https://www.freedailypro.com/tool/magazine-maker', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(6000); return { c, p, net }; };
 const ls = p => p.evaluate(() => (localStorage.getItem('fdp-usage-v1') || '').replace(/dev:[^"]+/, 'dev:REDACTED'));
 for (let i = 0; i < 3; i++) { const { c, p, net } = await ctx(); const r = { i, ls0: await ls(p), strip: await p.evaluate(() => (document.querySelector('main').innerText.match(/Trial:[^\n]*/) || [''])[0]) };
  try { await p.getByLabel('Magazine Title', { exact: true }).fill('Gate check ' + i); await p.getByLabel('Article 1 title', { exact: true }).fill('Note'); await p.getByLabel('Article 1 text', { exact: true }).fill('Short text for the gate check number ' + i + '.');
   await p.getByRole('button', { name: 'Build Magazine' }).click(); await p.waitForTimeout(3000);
   const dp = p.waitForEvent('download', { timeout: 12000 }).catch(() => null); await p.locator('main button', { hasText: /^Download Magazine/ }).first().click(); const d = await dp; await p.waitForTimeout(2500);
   r.dialog = (await p.locator('[role=dialog]').count()) ? (await p.locator('[role=dialog]').first().innerText()).slice(0, 100).replace(/\n/g, ' | ') : null; r.downloaded = !!d;
   if (d) { const f = O + `downloads/WKG${i}-${eng}-` + d.suggestedFilename(); await d.saveAs(f); r.saved = f.split('/').pop(); }
   r.ls1 = await ls(p); await p.screenshot({ path: O + `cases/WKG${i}-${eng}.png` }); } catch (e) { r.err = e.message.slice(0, 160); }
  r.net = net; R.gate.push(r); console.log('gate', JSON.stringify(r).slice(0, 700)); await c.close().catch(() => {}); }
 for (const f of ['memo_A4.pdf', 'img_wide.jpg', 'ceo_letter.docx', 'article_plain.txt']) { const { c, p } = await ctx(); const r = { f };
  try { await p.locator('main button', { hasText: /^Combine files$/ }).first().click(); await p.waitForTimeout(800); await p.getByLabel('Issue Title', { exact: true }).fill('WK combine'); await p.locator('main input[type=file][accept^=".pdf"]').first().setInputFiles(TF + f); await p.waitForTimeout(2500);
   const t0 = Date.now(); await p.getByRole('button', { name: 'Assemble Issue' }).click();
   await p.waitForFunction(() => [...document.querySelectorAll('main button')].some(x => /^Download/.test(x.innerText.trim())) || [...document.querySelectorAll('main [role=alert]')].some(a => a.innerText.trim()), null, { timeout: 45000 }).catch(e => { r.waitErr = e.message.slice(0, 80); });
   r.ms = Date.now() - t0; r.btns = (await p.locator('main button').allInnerTexts()).filter(t => /^Download|Assemble/.test(t)); } catch (e) { r.err = e.message.slice(0, 160); }
  R.combine.push(r); console.log('combine', JSON.stringify(r)); await c.close().catch(() => {}); }
 fs.writeFileSync(O + `wk-checks-${eng}.json`, JSON.stringify(R, null, 1)); await b.close(); })();
