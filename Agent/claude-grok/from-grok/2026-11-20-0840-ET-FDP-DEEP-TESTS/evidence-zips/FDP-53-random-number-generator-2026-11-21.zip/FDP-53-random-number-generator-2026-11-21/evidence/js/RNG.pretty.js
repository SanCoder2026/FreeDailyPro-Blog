import { r as d, j as r } from "./vendor-react-D01g8YgM.js";
import { u as we } from "./useShareGate-BYBawloP.js";
import { T as ye, d as Ne } from "./ToolPage-DwLoDncN.js";
import {
  bf as je,
  B as z,
  e as w,
  I as B,
  N as ve,
  f as ne,
} from "./index-B1CTyGtY.js";
import { S as ae } from "./switch-CQRPxs-N.js";
import { C as Se } from "./card-KXKUZKW8.js";
import { C as $e } from "./CalcSteps-CMhW1YVy.js";
import { T as Me } from "./ToolInfoSection-C0i6Zbwo.js";
import { M as S, r as W, a as ce, p as Ce } from "./random-DRWu2o-X.js";
import "./useExportGate-BU4jIFHF.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-DhOoIDuZ.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
function Ie(e) {
  let t = 1779033703,
    s = 3144134277,
    o = 1013904242,
    a = 2773480762;
  for (let p = 0; p < e.length; p++) {
    const u = e.charCodeAt(p);
    ((t = s ^ Math.imul(t ^ u, 597399067)),
      (s = o ^ Math.imul(s ^ u, 2869860233)),
      (o = a ^ Math.imul(o ^ u, 951274213)),
      (a = t ^ Math.imul(a ^ u, 2716044179)));
  }
  ((t = Math.imul(o ^ (t >>> 18), 597399067)),
    (s = Math.imul(a ^ (s >>> 22), 2869860233)),
    (o = Math.imul(t ^ (o >>> 17), 951274213)),
    (a = Math.imul(s ^ (a >>> 19), 2716044179)));
  let l = (t ^ s ^ o ^ a) >>> 0,
    h = (s ^ t) >>> 0,
    c = (o ^ t) >>> 0,
    x = (a ^ t) >>> 0;
  const b = () => {
    const p = (((l + h) | 0) + x) | 0;
    return (
      (x = (x + 1) | 0),
      (l = h ^ (h >>> 9)),
      (h = (c + (c << 3)) | 0),
      (c = (c << 21) | (c >>> 11)),
      (c = (c + p) | 0),
      p >>> 0
    );
  };
  for (let p = 0; p < 12; p++) b();
  return (p) => {
    for (let u = 0; u < p.length; u++) p[u] = b();
  };
}
function Le(e) {
  return e
    ? "Generator: seeded (sfc32 from your seed text). The same seed gives the same numbers every time. This is NOT cryptographically secure: anyone with the seed can reproduce the list, so do not use it for raffles, passwords or anything secret. Clear the seed to use the secure generator."
    : "Generator: your browser's crypto.getRandomValues, a cryptographically secure source, with rejection sampling so every value in the range is equally likely (no modulo bias). Nothing is sent or stored; the numbers exist only on this page.";
}
const Q = 10;
function Z(e, t) {
  const s = e.trim().replace(/[,_\s]/g, "");
  if (!s) return { error: `Enter a ${t}.` };
  const o = /^(-?)(\d+)(?:\.(\d+))?$/.exec(s);
  if (!o)
    return {
      error: `${t[0].toUpperCase()}${t.slice(1)} must be a number such as 12 or 0.5.`,
    };
  const a = o[3] ?? "",
    l = BigInt(o[2] + a);
  return { int: o[1] ? -l : l, scale: a.length };
}
const A = BigInt(0),
  L = BigInt(1),
  Te = BigInt(10),
  R = (e) => {
    let t = L;
    for (let s = 0; s < e; s++) t *= Te;
    return t;
  },
  de = (e, t) => {
    const s = e / t;
    return e % t !== A && e < A != t < A ? s - L : s;
  },
  De = (e, t) => -de(-e, t);
function H(e, t) {
  const s = e < A,
    o = (s ? -e : e).toString().padStart(t + 1, "0"),
    a = t ? `${o.slice(0, o.length - t)}.${o.slice(o.length - t)}` : o;
  return (s && /[1-9]/.test(a) ? "-" : "") + a;
}
function Be(e, t, s, o, a) {
  const l = typeof a == "number" ? a : Number(a.trim());
  if (!Number.isInteger(l) || l < 0 || l > Q)
    return {
      ok: !1,
      error: `Decimal places must be a whole number from 0 to ${Q}.`,
      field: "dp",
    };
  const h = Z(e, "minimum");
  if ("error" in h) return { ok: !1, error: h.error, field: "min" };
  const c = Z(t, "maximum");
  if ("error" in c) return { ok: !1, error: c.error, field: "max" };
  const x = Z(s, "amount");
  if ("error" in x || x.scale > 0)
    return {
      ok: !1,
      error: "How many must be a whole number.",
      field: "count",
    };
  if (x.int < L)
    return { ok: !1, error: "How many must be at least 1.", field: "count" };
  const b = h.int * R(c.scale) > c.int * R(h.scale),
    p = b ? c : h,
    u = b ? h : c,
    P = (v, X) =>
      v.scale <= l
        ? v.int * R(l - v.scale)
        : (X ? De : de)(v.int, R(v.scale - l)),
    $ = P(p, !0),
    F = P(u, !1),
    O = p.scale > l || u.scale > l;
  if ($ > F)
    return {
      ok: !1,
      error: `No number with ${l} decimal place${l === 1 ? "" : "s"} lies between ${e.trim()} and ${t.trim()}. Allow more decimal places or widen the range.`,
      field: "max",
    };
  const _ = x.int > BigInt(S),
    T = Number(_ ? BigInt(S) : x.int),
    q = F - $ + L;
  return o && BigInt(T) > q
    ? {
        ok: !1,
        error: `Only ${q} different value${q === L ? "" : "s"} with ${l} decimal place${l === 1 ? "" : "s"} exist between ${H($, l)} and ${H(F, l)}, so ${T} unique numbers is not possible. Lower "How many", widen the range, allow more decimal places or turn off "No duplicates".`,
        field: "unique",
      }
    : {
        ok: !0,
        lo: $,
        hi: F,
        dp: l,
        count: T,
        swapped: b,
        capped: _,
        trimmed: O,
        size: q,
      };
}
function Fe(e, t, s, o) {
  let a = W({ min: e.lo, max: e.hi, count: e.count, unique: t }, o);
  return (
    s && (a = [...a].sort((l, h) => (l < h ? -1 : l > h ? 1 : 0))),
    a.map((l) => H(l, e.dp))
  );
}
function qe(e, t, s) {
  const o = e.size.toString(2).length;
  return [
    {
      label: "Count the possible values",
      formula: e.dp
        ? "(max - min) x 10^decimals + 1 values on the grid"
        : "max - min + 1",
      inputs: {
        min: H(e.lo, e.dp),
        max: H(e.hi, e.dp),
        "decimal places": e.dp,
      },
      result: e.size.toString(),
    },
    {
      label: "Draw one position",
      formula: s
        ? "random 32-bit words from the seeded generator, keep the low bits, retry when the value is past the range"
        : "random 32-bit words from crypto.getRandomValues, keep the low bits, retry when the value is past the range (rejection sampling)",
      inputs: { "bits per draw": o },
      result: "every position equally likely",
    },
    {
      label: "Turn it into a number",
      formula: e.dp ? "min + position / 10^decimals" : "min + position",
      inputs: {
        unique: t ? "yes, no repeats" : "no, repeats allowed",
        amount: e.count,
      },
      result: `${e.count} number${e.count === 1 ? "" : "s"}`,
    },
  ];
}
const le = 1e6;
function Ae(e) {
  const t = /^\s*(\d*)\s*d\s*(\d+)\s*([+-]\s*\d+)?\s*$/i.exec(e);
  if (!t)
    return { ok: !1, error: "Write dice as NdM, such as 2d6, d20 or 3d8+2." };
  const s = t[1] === "" ? 1 : Number(t[1]),
    o = Number(t[2]),
    a = t[3] ? Number(t[3].replace(/\s/g, "")) : 0;
  return s < 1 || s > S
    ? {
        ok: !1,
        error: `Roll between 1 and ${S.toLocaleString("en-US")} dice at a time.`,
      }
    : o < 2
      ? { ok: !1, error: "A die needs at least 2 sides." }
      : o > le
        ? {
            ok: !1,
            error: `A die can have up to ${le.toLocaleString("en-US")} sides.`,
          }
        : { ok: !0, dice: s, sides: o, modifier: a };
}
function Oe(e, t) {
  const s = Array.from(
      { length: e.dice },
      () => Number(ce(BigInt(e.sides), t)) + 1,
    ),
    o = s.reduce((h, c) => h + c, 0),
    a = o + e.modifier,
    l = e.modifier
      ? ` ${e.modifier > 0 ? "+" : "-"} ${Math.abs(e.modifier)}`
      : "";
  return {
    rolls: s,
    sum: o,
    total: a,
    text: `${e.dice}d${e.sides}${e.modifier ? (e.modifier > 0 ? "+" : "-") + Math.abs(e.modifier) : ""}: ${s.join(", ")} = ${o}${l}${e.modifier ? ` = ${a}` : ""}`,
  };
}
function Ue(e, t) {
  const s = Array.from({ length: e }, () =>
      ce(BigInt(2), t) === A ? "Heads" : "Tails",
    ),
    o = s.filter((a) => a === "Heads").length;
  return { flips: s, heads: o, tails: e - o };
}
function Ee(e, t) {
  const s = Number(e.trim()),
    o = Number(t.trim());
  return !Number.isInteger(o) || o < 2
    ? { ok: !1, error: "The pool must be a whole number of at least 2." }
    : o > 1e5
      ? { ok: !1, error: "The pool can have up to 100,000 numbers." }
      : !Number.isInteger(s) || s < 1
        ? { ok: !1, error: "Pick at least 1 number." }
        : s > o
          ? {
              ok: !1,
              error: `You cannot pick ${s} different numbers from a pool of ${o}. Lower the picks or raise the pool.`,
            }
          : { ok: !0, pick: s, of: o };
}
function He(e, t) {
  return W({ min: L, max: BigInt(e.of), count: e.pick, unique: !0 }, t)
    .map(Number)
    .sort((s, o) => s - o);
}
function Pe(e) {
  const t = Math.min(e.pick, e.of - e.pick);
  let s = L,
    o = L;
  for (let a = 1; a <= t; a++) ((s *= BigInt(e.of - t + a)), (o *= BigInt(a)));
  return s / o;
}
const me = 1e4;
function _e(e) {
  return e
    .split(/\r?\n/)
    .map((t) => t.trim())
    .filter(Boolean);
}
function ze(e, t) {
  const s = _e(e);
  if (s.length === 0)
    return { ok: !1, error: "Paste or type your list, one item per line." };
  if (s.length > me)
    return {
      ok: !1,
      error: `The list can have up to ${me.toLocaleString("en-US")} lines.`,
    };
  const o = t.trim().toLowerCase();
  if (o === "" || o === "all") return { ok: !0, items: s, pick: s.length };
  const a = Number(o);
  return !Number.isInteger(a) || a < 1
    ? {
        ok: !1,
        error:
          "How many to pick must be a whole number of at least 1, or leave it empty to shuffle the whole list.",
      }
    : a > s.length
      ? {
          ok: !1,
          error: `You asked for ${a} but the list has ${s.length} line${s.length === 1 ? "" : "s"}. Lower the number or add lines.`,
        }
      : { ok: !0, items: s, pick: a };
}
function Re(e, t) {
  return W(
    { min: A, max: BigInt(e.items.length - 1), count: e.pick, unique: !0 },
    t,
  ).map((o) => e.items[Number(o)]);
}
const J = {
    what: "Generates random numbers in a range you set, with optional decimals, and has presets for dice (such as 2d6), coin flips, lottery tickets (pick 6 of 49) and picking or shuffling items from a list you paste.",
    how: 'Pick a mode. In Numbers, set the minimum, maximum and how many, choose decimal places (0 for whole numbers), and turn on "no duplicates" or "sort" if you need them. In Dice, type NdM such as 2d6, d20 or 3d8+2. In Lottery, set how many numbers to pick from how big a pool. In List, paste one item per line and pick some or shuffle them all. Whole numbers go up to very large ranges, and up to 10,000 results at a time. If the minimum is higher than the maximum the two are swapped for you. The numbers appear straight away; copying or downloading them never takes a trial use.',
    tip: "By default the numbers come from your browser's crypto.getRandomValues, a cryptographically secure source, and every value in the range is equally likely. The optional seed switches to a repeatable generator that is NOT secure (anyone with the seed can recreate the list), so use it for reproducible classroom draws or test data, never for a raffle or a secret.",
  },
  G = 500,
  Ge = [
    ["numbers", "Numbers"],
    ["dice", "Dice"],
    ["coin", "Coin"],
    ["lottery", "Lottery"],
    ["list", "List"],
  ];
function St() {
  const { gateShare: e } = we(),
    [t, s] = d.useState("numbers"),
    [o, a] = d.useState("1"),
    [l, h] = d.useState("100"),
    [c, x] = d.useState("1"),
    [b, p] = d.useState("0"),
    [u, P] = d.useState(!1),
    [$, F] = d.useState(!1),
    [O, _] = d.useState("2d6"),
    [T, q] = d.useState("1"),
    [v, X] = d.useState("6"),
    [Y, ue] = d.useState("49"),
    [U, he] = d.useState(""),
    [V, pe] = d.useState(""),
    [K, fe] = d.useState(""),
    [f, ee] = d.useState(null),
    te = Number(b),
    y = d.useMemo(() => {
      if (te === 0) {
        const i = Ce(o, l, c, u);
        if (i.ok)
          return {
            ok: !0,
            lo: i.min,
            hi: i.max,
            dp: 0,
            count: i.count,
            swapped: i.swapped,
            capped: i.capped,
            trimmed: !1,
            size: i.max - i.min + BigInt(1),
          };
        const m =
          /decimal/.test(i.error) && /\d\.\d/.test(`${o}${l}`)
            ? " To draw numbers with decimals, set Decimal places above 0."
            : "";
        return { ok: !1, error: i.error + m, field: i.field };
      }
      return Be(o, l, c, u, b);
    }, [o, l, c, u, b, te]),
    g = d.useMemo(() => Ae(O), [O]),
    M = d.useMemo(() => {
      const i = Number(T.trim());
      return Number.isInteger(i) && i >= 1 && i <= S
        ? { ok: !0, n: i }
        : {
            ok: !1,
            error: `Enter a whole number of flips from 1 to ${S.toLocaleString("en-US")}.`,
          };
    }, [T]),
    N = d.useMemo(() => Ee(v, Y), [v, Y]),
    k = d.useMemo(() => ze(U, V), [U, V]),
    C = K.trim() !== "",
    re = { numbers: y, dice: g, coin: M, lottery: N, list: k }[t],
    D = (i) => (t === "numbers" && !y.ok && y.field === i ? y.error : ""),
    ge = () => {
      if (!re.ok) return;
      const i = C ? Ie(K) : void 0,
        m = [];
      let I;
      if (t === "numbers" && y.ok) {
        const n = y,
          j =
            n.dp === 0 && !n.trimmed
              ? (() => {
                  let E = W(
                    { min: n.lo, max: n.hi, count: n.count, unique: u },
                    i,
                  );
                  return (
                    $ &&
                      (E = [...E].sort((oe, ie) =>
                        oe < ie ? -1 : oe > ie ? 1 : 0,
                      )),
                    E.map(String)
                  );
                })()
              : Fe(n, u, $, i);
        (n.swapped &&
          m.push("Minimum was higher than maximum, so the two were swapped."),
          n.trimmed &&
            m.push(
              `With ${n.dp} decimal place${n.dp === 1 ? "" : "s"} the range was trimmed to the numbers that fit: the smallest possible is rounded up and the largest rounded down, so nothing falls outside what you typed.`,
            ),
          n.capped &&
            m.push(
              `You asked for more than ${S.toLocaleString("en-US")}, so ${S.toLocaleString("en-US")} numbers were generated.`,
            ),
          (I = {
            items: j,
            headline: `${j.length.toLocaleString("en-US")} number${j.length === 1 ? "" : "s"}`,
            text: j.join(", "),
            file: j.join(`
`),
            notes: m,
            steps: qe(n, u, C),
            seeded: C,
          }));
      } else if (t === "dice" && g.ok) {
        const n = Oe(g, i);
        I = {
          items: n.rolls.map(String),
          headline: `Total ${n.total.toLocaleString("en-US")}`,
          text: n.text,
          file: n.text,
          notes: g.modifier
            ? [
                `Dice add up to ${n.sum.toLocaleString("en-US")}, then ${g.modifier > 0 ? "plus" : "minus"} ${Math.abs(g.modifier)}.`,
              ]
            : [],
          steps: [
            {
              label: "Roll each die",
              formula: `each die is a whole number from 1 to ${g.sides}, every face equally likely`,
              inputs: { dice: g.dice, sides: g.sides },
              result:
                n.rolls.slice(0, 20).join(", ") +
                (n.rolls.length > 20 ? ", ..." : ""),
            },
            {
              label: "Add up",
              formula: "sum of the dice + modifier",
              inputs: { sum: n.sum, modifier: g.modifier },
              result: n.total,
            },
          ],
          seeded: C,
        };
      } else if (t === "coin" && M.ok) {
        const n = Ue(M.n, i);
        I = {
          items: n.flips.slice(0, G),
          headline: `${n.heads} heads, ${n.tails} tails`,
          text:
            M.n === 1
              ? n.flips[0]
              : `${n.flips.join(", ")}
Heads ${n.heads}, Tails ${n.tails}`,
          file:
            n.flips.join(`
`) +
            `
Heads ${n.heads}, Tails ${n.tails}`,
          notes: [],
          steps: [],
          seeded: C,
        };
      } else if (t === "lottery" && N.ok) {
        const n = He(N, i);
        I = {
          items: n.map(String),
          headline: `${N.pick} of ${N.of}, sorted`,
          text: n.join(", "),
          file: n.join(`
`),
          notes: [
            `Any one ticket of this size has a 1 in ${Pe(N).toLocaleString("en-US")} chance. A random pick is no more likely to win than any other ticket, and it does not predict a real draw.`,
          ],
          steps: [],
          seeded: C,
        };
      } else if (t === "list" && k.ok) {
        const n = Re(k, i);
        (new Set(k.items).size < k.items.length &&
          m.push(
            "Some lines are the same. Each line counts as its own entry, so a repeated line has a better chance of being drawn.",
          ),
          (I = {
            items: n,
            headline:
              k.pick === k.items.length
                ? `Shuffled ${n.length} item${n.length === 1 ? "" : "s"}`
                : `${n.length} picked from ${k.items.length}`,
            text: n.join(`
`),
            file: n.join(`
`),
            notes: m,
            steps: [],
            seeded: C,
          }));
      } else return;
      ee(I);
    },
    se = je({ items: f?.items, text: f?.text }),
    xe = () =>
      f &&
      e(async () => {
        try {
          return (
            await navigator.clipboard.writeText(f.text),
            ne.success("Copied to clipboard"),
            !0
          );
        } catch {
          return (
            ne.error(
              "Could not copy. Select the numbers and copy them by hand.",
            ),
            !1
          );
        }
      }, se),
    be = () =>
      f &&
      void e(
        async () => (
          Ne(
            new Blob(
              [
                f.file +
                  `
`,
              ],
              { type: "text/plain;charset=utf-8" },
            ),
            "random-numbers.txt",
            { free: !0 },
          ),
          !0
        ),
        se,
      ),
    ke = f?.items.slice(0, G) ?? [];
  return r.jsxs(ye, {
    children: [
      r.jsx("div", {
        className: "flex flex-wrap gap-2",
        role: "group",
        "aria-label": "What to generate",
        children: Ge.map(([i, m]) =>
          r.jsx(
            z,
            {
              type: "button",
              size: "sm",
              variant: t === i ? "default" : "outline",
              "aria-pressed": t === i,
              onClick: () => {
                (s(i), ee(null));
              },
              children: m,
            },
            i,
          ),
        ),
      }),
      t === "numbers" &&
        r.jsxs(r.Fragment, {
          children: [
            r.jsxs("div", {
              className: "grid grid-cols-1 md:grid-cols-4 gap-4 mt-4",
              children: [
                [
                  ["Min", "rng-min", o, a, "min"],
                  ["Max", "rng-max", l, h, "max"],
                  ["How many", "rng-count", c, x, "count"],
                ].map(([i, m, I, n, j]) =>
                  r.jsxs(
                    "div",
                    {
                      children: [
                        r.jsx(w, {
                          htmlFor: m,
                          className: "mb-2 block",
                          children: i,
                        }),
                        r.jsx(B, {
                          id: m,
                          inputMode: "decimal",
                          value: I,
                          onChange: (E) => n(E.target.value),
                          "aria-invalid": !!D(j),
                          "aria-describedby": D(j) ? `${m}-err` : void 0,
                        }),
                        D(j) &&
                          r.jsx("p", {
                            id: `${m}-err`,
                            role: "alert",
                            className: "text-xs text-destructive mt-1",
                            children: D(j),
                          }),
                      ],
                    },
                    m,
                  ),
                ),
                r.jsxs("div", {
                  children: [
                    r.jsx(w, {
                      htmlFor: "rng-dp",
                      className: "mb-2 block",
                      children: "Decimal places",
                    }),
                    r.jsx("select", {
                      id: "rng-dp",
                      value: b,
                      onChange: (i) => p(i.target.value),
                      className:
                        "w-full border rounded-md px-3 py-2 bg-background text-sm h-9",
                      "aria-invalid": !!D("dp"),
                      children: Array.from({ length: Q + 1 }, (i, m) =>
                        r.jsx(
                          "option",
                          {
                            value: m,
                            children: m === 0 ? "0 (whole numbers)" : m,
                          },
                          m,
                        ),
                      ),
                    }),
                  ],
                }),
              ],
            }),
            y.ok &&
              y.swapped &&
              r.jsx("p", {
                className: "text-xs text-muted-foreground mt-2",
                children:
                  "Minimum is higher than maximum, so the two will be swapped before drawing.",
              }),
            y.ok &&
              y.capped &&
              r.jsxs("p", {
                className: "text-xs text-muted-foreground mt-2",
                children: [
                  "The most you can generate at once is ",
                  S.toLocaleString("en-US"),
                  ".",
                ],
              }),
            r.jsxs("div", {
              className: "flex items-center gap-2 mt-4",
              children: [
                r.jsx(ae, { id: "rng-unique", checked: u, onCheckedChange: P }),
                r.jsx(w, {
                  htmlFor: "rng-unique",
                  className: "text-sm",
                  children: "No duplicates (unique numbers only)",
                }),
              ],
            }),
            D("unique") &&
              r.jsx("p", {
                role: "alert",
                className: "text-xs text-destructive mt-1",
                children: D("unique"),
              }),
            r.jsxs("div", {
              className: "flex items-center gap-2 mt-2",
              children: [
                r.jsx(ae, { id: "rng-sort", checked: $, onCheckedChange: F }),
                r.jsx(w, {
                  htmlFor: "rng-sort",
                  className: "text-sm",
                  children: "Sort the results",
                }),
              ],
            }),
          ],
        }),
      t === "dice" &&
        r.jsxs("div", {
          className: "mt-4 max-w-sm",
          children: [
            r.jsx(w, {
              htmlFor: "rng-dice",
              className: "mb-2 block",
              children: "Dice (NdM, such as 2d6, d20 or 3d8+2)",
            }),
            r.jsx(B, {
              id: "rng-dice",
              value: O,
              onChange: (i) => _(i.target.value),
              "aria-invalid": !g.ok,
              "aria-describedby": g.ok ? void 0 : "rng-dice-err",
            }),
            !g.ok &&
              r.jsx("p", {
                id: "rng-dice-err",
                role: "alert",
                className: "text-xs text-destructive mt-1",
                children: g.error,
              }),
          ],
        }),
      t === "coin" &&
        r.jsxs("div", {
          className: "mt-4 max-w-sm",
          children: [
            r.jsx(w, {
              htmlFor: "rng-flips",
              className: "mb-2 block",
              children: "How many flips",
            }),
            r.jsx(B, {
              id: "rng-flips",
              inputMode: "numeric",
              value: T,
              onChange: (i) => q(i.target.value),
              "aria-invalid": !M.ok,
              "aria-describedby": M.ok ? void 0 : "rng-flips-err",
            }),
            !M.ok &&
              r.jsx("p", {
                id: "rng-flips-err",
                role: "alert",
                className: "text-xs text-destructive mt-1",
                children: M.error,
              }),
          ],
        }),
      t === "lottery" &&
        r.jsxs("div", {
          className: "mt-4",
          children: [
            r.jsxs("div", {
              className: "grid grid-cols-2 gap-4 max-w-sm",
              children: [
                r.jsxs("div", {
                  children: [
                    r.jsx(w, {
                      htmlFor: "rng-pick",
                      className: "mb-2 block",
                      children: "Numbers to pick",
                    }),
                    r.jsx(B, {
                      id: "rng-pick",
                      inputMode: "numeric",
                      value: v,
                      onChange: (i) => X(i.target.value),
                      "aria-invalid": !N.ok,
                    }),
                  ],
                }),
                r.jsxs("div", {
                  children: [
                    r.jsx(w, {
                      htmlFor: "rng-pool",
                      className: "mb-2 block",
                      children: "Out of (1 to this)",
                    }),
                    r.jsx(B, {
                      id: "rng-pool",
                      inputMode: "numeric",
                      value: Y,
                      onChange: (i) => ue(i.target.value),
                      "aria-invalid": !N.ok,
                    }),
                  ],
                }),
              ],
            }),
            !N.ok &&
              r.jsx("p", {
                role: "alert",
                className: "text-xs text-destructive mt-1",
                children: N.error,
              }),
            r.jsx("p", {
              className: "text-xs text-muted-foreground mt-2",
              children:
                "Six from 49 is the classic ticket. The numbers come out different and sorted.",
            }),
          ],
        }),
      t === "list" &&
        r.jsxs("div", {
          className: "mt-4 space-y-3",
          children: [
            r.jsxs("div", {
              children: [
                r.jsx(w, {
                  htmlFor: "rng-list",
                  className: "mb-2 block",
                  children: "Your list, one item per line",
                }),
                r.jsx("textarea", {
                  id: "rng-list",
                  value: U,
                  onChange: (i) => he(i.target.value),
                  rows: 6,
                  className:
                    "w-full border rounded-md px-3 py-2 bg-background text-sm",
                  placeholder: `Ana
Ben
Cy`,
                  "aria-invalid": !k.ok && U.trim() !== "",
                }),
                r.jsx("p", {
                  className: "text-xs text-muted-foreground mt-1",
                  children:
                    "The list stays in your browser; nothing is uploaded.",
                }),
              ],
            }),
            r.jsxs("div", {
              className: "max-w-xs",
              children: [
                r.jsx(w, {
                  htmlFor: "rng-listpick",
                  className: "mb-2 block",
                  children: "How many to pick (empty shuffles the whole list)",
                }),
                r.jsx(B, {
                  id: "rng-listpick",
                  inputMode: "numeric",
                  value: V,
                  onChange: (i) => pe(i.target.value),
                }),
              ],
            }),
            !k.ok &&
              U.trim() !== "" &&
              r.jsx("p", {
                role: "alert",
                className: "text-xs text-destructive",
                children: k.error,
              }),
          ],
        }),
      r.jsxs("div", {
        className: "mt-4 max-w-sm",
        children: [
          r.jsx(w, {
            htmlFor: "rng-seed",
            className: "mb-2 block",
            children: "Seed (optional, repeatable draws)",
          }),
          r.jsx(B, {
            id: "rng-seed",
            value: K,
            onChange: (i) => fe(i.target.value),
            placeholder: "Leave empty for secure random",
          }),
        ],
      }),
      C &&
        r.jsx(ve, {
          className: "mt-2 text-sm",
          role: "status",
          testId: "rng-seed-warning",
          children:
            "With a seed the same numbers come out every time, and the generator is not cryptographically secure. Do not use a seed for a raffle, a password or anything secret. Clear the seed to use the secure generator.",
        }),
      r.jsx(z, {
        className: "mt-4",
        onClick: ge,
        disabled: !re.ok,
        children:
          t === "dice"
            ? "Roll"
            : t === "coin"
              ? "Flip"
              : t === "list"
                ? "Draw"
                : "Generate",
      }),
      f &&
        r.jsxs(Se, {
          className: "mt-6 p-6",
          "data-testid": "rng-results",
          children: [
            r.jsx("p", {
              className: "text-sm text-muted-foreground mb-3",
              "data-testid": "rng-headline",
              children: f.headline,
            }),
            r.jsx("div", {
              className: "flex flex-wrap gap-2 mb-4",
              children: ke.map((i, m) =>
                r.jsx(
                  "span",
                  {
                    className:
                      "inline-flex items-center justify-center min-w-[3rem] px-3 py-2 rounded-lg bg-primary/10 text-primary font-bold text-lg break-all",
                    children: i,
                  },
                  m,
                ),
              ),
            }),
            f.items.length > G &&
              r.jsxs("p", {
                className: "text-xs text-muted-foreground mb-3",
                children: [
                  "Showing the first ",
                  G,
                  " of ",
                  f.items.length.toLocaleString("en-US"),
                  ". Copy or download to get them all.",
                ],
              }),
            f.notes.map((i, m) =>
              r.jsx(
                "p",
                {
                  className: "text-xs text-muted-foreground mb-2",
                  children: i,
                },
                m,
              ),
            ),
            r.jsx("p", {
              className: "text-xs text-muted-foreground mb-3",
              "data-testid": "rng-method",
              children: Le(f.seeded),
            }),
            r.jsxs("div", {
              className: "flex flex-wrap gap-2",
              children: [
                r.jsx(z, {
                  size: "sm",
                  variant: "outline",
                  onClick: xe,
                  children: "Copy Results",
                }),
                r.jsx(z, {
                  size: "sm",
                  variant: "outline",
                  onClick: be,
                  children: "Download .txt",
                }),
              ],
            }),
            f.steps.length > 0 &&
              r.jsx("div", {
                className: "mt-4",
                children: r.jsx($e, {
                  steps: f.steps,
                  title: "How this was generated",
                }),
              }),
          ],
        }),
      r.jsx(Me, { whatIsIt: J.what, howToUse: J.how, tip: J.tip }),
    ],
  });
}
export { St as default };
//# sourceMappingURL=RandomNumberGenerator-cHv4w4le.js.map
