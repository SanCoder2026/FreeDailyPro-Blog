function m(
  o,
  s = (e) => {
    crypto.getRandomValues(e);
  },
) {
  if (o <= BigInt(0)) throw new Error("n must be positive");
  if (o === BigInt(1)) return BigInt(0);
  const e = o.toString(2).length,
    f = Math.ceil(e / 32),
    u = (BigInt(1) << BigInt(e)) - BigInt(1),
    r = new Uint32Array(f);
  for (;;) {
    s(r);
    let t = BigInt(0);
    for (let a = 0; a < f; a++) t = (t << BigInt(32)) | BigInt(r[a]);
    if (((t &= u), t < o)) return t;
  }
}
const p = BigInt(1e5);
function d({ min: o, max: s, count: e, unique: f }, u) {
  const r = s - o + BigInt(1);
  if (!f) return Array.from({ length: e }, () => o + m(r, u));
  if (BigInt(e) > r)
    throw new Error(`Range only has ${r} possible unique values`);
  if (r <= p) {
    const i = Array.from({ length: Number(r) }, (n, l) => o + BigInt(l));
    for (let n = 0; n < e; n++) {
      const l = n + Number(m(BigInt(i.length - n), u));
      [i[n], i[l]] = [i[l], i[n]];
    }
    return i.slice(0, e);
  }
  const t = new Set(),
    a = [];
  for (; a.length < e;) {
    const i = o + m(r, u),
      n = i.toString();
    t.has(n) || (t.add(n), a.push(i));
  }
  return a;
}
function I(o, s) {
  const e = o.trim().replace(/[,_\s]/g, "");
  return e
    ? /^-?\d+[.]\d+$/.test(e)
      ? {
          error: `${s[0].toUpperCase()}${s.slice(1)} must be a whole number (no decimals).`,
        }
      : /^-?\d+$/.test(e)
        ? { value: BigInt(e) }
        : {
            error: `${s[0].toUpperCase()}${s.slice(1)} must be a whole number.`,
          }
    : { error: `Enter a ${s}.` };
}
const B = 1e4;
function h(o, s, e, f) {
  const u = I(o, "minimum");
  if ("error" in u) return { ok: !1, error: u.error, field: "min" };
  const r = I(s, "maximum");
  if ("error" in r) return { ok: !1, error: r.error, field: "max" };
  const t = I(e, "amount");
  if ("error" in t) return { ok: !1, error: t.error, field: "count" };
  if (t.value < BigInt(1))
    return { ok: !1, error: "How many must be at least 1.", field: "count" };
  const a = u.value > r.value,
    i = a ? r.value : u.value,
    n = a ? u.value : r.value,
    l = t.value > BigInt(B),
    c = Number(l ? BigInt(B) : t.value),
    g = n - i + BigInt(1);
  return f && BigInt(c) > g
    ? {
        ok: !1,
        error: `Only ${g} unique value${g === BigInt(1) ? "" : "s"} exist between ${i} and ${n}, so ${c} unique numbers is not possible. Lower "How many", widen the range or turn off "No duplicates".`,
        field: "unique",
      }
    : { ok: !0, min: i, max: n, count: c, swapped: a, capped: l };
}
export { B as M, m as a, h as p, d as r };
//# sourceMappingURL=random-DRWu2o-X.js.map
