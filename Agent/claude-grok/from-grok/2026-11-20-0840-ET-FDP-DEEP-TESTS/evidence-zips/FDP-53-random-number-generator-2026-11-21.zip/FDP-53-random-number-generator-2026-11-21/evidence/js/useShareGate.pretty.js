import { r as u } from "./vendor-react-D01g8YgM.js";
import { u as i } from "./useExportGate-BU4jIFHF.js";
import { h as f } from "./ToolPage-DwLoDncN.js";
async function h(t, a) {
  if (!t.counted) return (await a()) !== !1;
  if (!(await t.checkExport())) return !1;
  const r = (await a()) !== !1;
  return (r && (await t.charge()), r);
}
function E() {
  const { checkExport: t } = i(),
    { known: a, paid: r, toolId: o, tryUse: c, tryUseExport: s } = f();
  return {
    gateShare: u.useCallback(
      (n, e) =>
        h(
          {
            toolId: o,
            counted: a && !r,
            checkExport: () => t(e),
            charge: () => (e ? s(e) : c()),
          },
          n,
        ),
      [o, a, r, t, c, s],
    ),
  };
}
export { E as u };
//# sourceMappingURL=useShareGate-BYBawloP.js.map
