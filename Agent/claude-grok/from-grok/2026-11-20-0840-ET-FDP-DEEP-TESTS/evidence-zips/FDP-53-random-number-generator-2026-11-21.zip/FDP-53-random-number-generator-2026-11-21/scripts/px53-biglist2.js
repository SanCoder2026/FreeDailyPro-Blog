// FDP-53: List mode responsiveness with 2,000 / 5,000 / 10,000 / 10,001 lines (fresh page each), set via input event; measures main-thread stall (guest)
const { chromium } = require('playwright'); const fs = require('fs'); const O = '/workspace/deep/53-random-number-generator/live/';
(async () => { const b = await chromium.launch(); const R = {};
 for (const n of [2000, 5000, 10000, 10001]) { const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); p.setDefaultTimeout(120000);
  await p.goto('https://www.freedailypro.com/tool/random-number-generator', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000);
  await p.locator('main [aria-label="What to generate"] button', { hasText: /^List$/ }).click(); await p.waitForTimeout(300);
  const t0 = Date.now(); await p.evaluate(n => { const t = document.querySelector('#rng-list'); const set = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set; set.call(t, Array.from({ length: n }, (_, i) => 'n' + i).join('\n')); t.dispatchEvent(new Event('input', { bubbles: true })); }, n);
  const setMs = Date.now() - t0; const t1 = Date.now(); await p.evaluate(() => new Promise(r => requestAnimationFrame(() => setTimeout(r, 0)))); const settleMs = Date.now() - t1;
  const st = await p.evaluate(() => ({ dis: [...document.querySelectorAll('main button')].find(x => x.innerText.trim() === 'Draw').disabled, errs: [...document.querySelectorAll('main [id$=-err],main [role=alert],main .text-destructive')].map(e => e.innerText.trim()) }));
  let drawMs = null, head = null; if (!st.dis) { const t2 = Date.now(); await p.locator('main button', { hasText: /^Draw$/ }).click(); await p.locator('[data-testid=rng-headline]').waitFor(); drawMs = Date.now() - t2; head = await p.locator('[data-testid=rng-headline]').innerText(); }
  // one keystroke after load
  const t3 = Date.now(); await p.locator('#rng-list').press('End'); await p.keyboard.type('x'); const keyMs = Date.now() - t3;
  R[n] = { setMs, settleMs, ...st, drawMs, head, keyMs }; console.log(n, JSON.stringify(R[n])); await p.context().close(); }
 fs.writeFileSync(O + 'biglist.json', JSON.stringify(R, null, 1)); await b.close(); })();
