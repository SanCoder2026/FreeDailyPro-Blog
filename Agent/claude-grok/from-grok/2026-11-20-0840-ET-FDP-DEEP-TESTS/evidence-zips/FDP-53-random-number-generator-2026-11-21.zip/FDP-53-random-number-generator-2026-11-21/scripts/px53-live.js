// FDP-53 Random Number Generator, guest. Usage: node px53-live.js <func|gate> [engine]  (TRIES env = fresh contexts to try for a context with uses left)
// func: functional battery in all 5 modes (numbers, dice, coin, lottery, list), edge cases, seed repeatability, uniformity, Copy/Download outputs.
// gate: cap context -> Copy/Download (dialog?); context with uses left -> Generate/Copy/Download/re-Copy/reload, watching fdp-usage-v1 and usage POSTs.
// Never signs in, never types an email/card, never clicks ads or pass "Continue".
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/53-random-number-generator/'; const OUT = BASE + 'live/'; const URL = 'https://www.freedailypro.com/tool/random-number-generator';
const mode = process.argv[2] || 'func'; const eng = process.argv[3] || 'chromium'; const sfx = eng === 'chromium' ? '' : '-' + eng;
fs.mkdirSync(OUT + 'downloads', { recursive: true }); fs.mkdirSync(OUT + 'cases', { recursive: true });
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').replace(/dev[:%][^&"]*/g, 'dev:REDACTED').slice(0, 160);
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, cases: {}, tries: [] }; let c, p, net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true, locale: 'en-US', permissions: eng === 'chromium' ? ['clipboard-read', 'clipboard-write'] : [] }); p = await c.newPage(); p.setDefaultTimeout(8000); net = [];
  await p.addInitScript(() => { window.__t = []; const seen = new WeakSet(); setInterval(() => { document.querySelectorAll('[data-sonner-toast]').forEach(n => { if (!seen.has(n)) { seen.add(n); window.__t.push((n.innerText || '').trim()); } }); }, 120); });
  p.on('request', r => { if (r.method() === 'POST') net.push({ t: now(), u: red(r.url()), len: (r.postData() || '').length, body: red((r.postData() || '').slice(0, 160)) }); });
  await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit + ' ' + (u.tier || ''); });
 const strip = () => p.evaluate(() => (document.querySelector('main').innerText.match(/[^\n]*(trial use|uses left|uses today|remaining)[^\n]*/gi) || []).slice(0, 4));
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 400) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(250); } };
 const toasts = n => p.evaluate(n => (window.__t || []).slice(n), n); const tc = () => p.evaluate(() => (window.__t || []).length);
 const tab = async n => { await p.locator('main [aria-label="What to generate"] button', { hasText: new RegExp('^' + n + '$') }).click(); await p.waitForTimeout(300); };
 const fill = async (id, v) => { await p.locator('#' + id).fill(String(v)); };
 const sw = async (id, on) => { const s = p.locator('#' + id); if (((await s.getAttribute('aria-checked')) === 'true') !== on) await s.click(); };
 const res = () => p.evaluate(() => { const r = document.querySelector('[data-testid=rng-results]'); const m = document.querySelector('main');
  const errs = [...m.querySelectorAll('[id$=-err],[role=alert],.text-destructive')].map(e => e.innerText.trim()).filter(Boolean);
  const btn = [...m.querySelectorAll('button')].find(x => /^(Generate|Roll|Flip|Draw)$/.test(x.innerText.trim()));
  if (!r) return { none: true, errs, btnDisabled: btn ? btn.disabled : null };
  return { headline: r.querySelector('[data-testid=rng-headline]').innerText, chips: [...r.querySelectorAll('span')].map(s => s.innerText), notes: [...r.querySelectorAll('p.text-xs')].map(x => x.innerText).filter(t => !/^Generator:/.test(t)), method: (r.querySelector('[data-testid=rng-method]') || {}).innerText, steps: /How this was generated/.test(r.innerText), errs, btnDisabled: btn ? btn.disabled : null }; });
 const go = async () => { const bt = p.locator('main button', { hasText: /^(Generate|Roll|Flip|Draw)$/ }).first(); if (!(await bt.isDisabled())) await bt.click(); await p.waitForTimeout(500); return res(); };
 const copy = async () => { const n = await tc(); const before = await used(); await p.locator('main button', { hasText: 'Copy Results' }).click(); await p.waitForTimeout(1500); let clip = null; try { clip = eng === 'chromium' ? await p.evaluate(() => navigator.clipboard.readText()) : null; } catch (e) { clip = 'ERR ' + e.message.slice(0, 60); }
  const r = { before, after: await used(), toasts: await toasts(n), dialog: await dialog(), clipLen: clip ? clip.length : null, clipHead: clip ? clip.slice(0, 120) : null }; if (r.dialog) { await p.screenshot({ path: OUT + 'cases/copy-dialog' + sfx + '.png' }); await esc(); } return r; };
 const dl = async id => { const n = await tc(); const before = await used(); const dp = p.waitForEvent('download', { timeout: 8000 }).catch(() => null); await p.locator('main button', { hasText: 'Download .txt' }).click(); const d = await dp; await p.waitForTimeout(1500);
  const r = { before, after: await used(), toasts: await toasts(n), dialog: await dialog() }; if (d) { const f = OUT + 'downloads/' + id + sfx + '-' + d.suggestedFilename(); await d.saveAs(f); const s = fs.readFileSync(f, 'utf8'); r.file = { name: d.suggestedFilename(), bytes: s.length, lines: s.split('\n').length, head: s.slice(0, 100) }; }
  if (r.dialog) { await p.screenshot({ path: OUT + 'cases/dl-dialog-' + id + sfx + '.png' }); await esc(); } return r; };
 const shot = id => p.screenshot({ path: OUT + 'cases/' + id + sfx + '.png', fullPage: false });
 const C = async (id, fn) => { try { R.cases[id] = await fn(); } catch (e) { R.cases[id] = { err: e.message.split('\n')[0].slice(0, 200) }; } console.log(id, JSON.stringify(R.cases[id]).slice(0, 300)); };
 if (mode === 'func') { await open(); R.start = { used: await used(), strip: await strip() };
  await C('N01-default', async () => { const r = await go(); await shot('N01'); return r; });
  await C('N02-20of1-100-unique-sorted', async () => { await fill('rng-count', 20); await sw('rng-unique', true); await sw('rng-sort', true); const r = await go(); await shot('N02'); const v = r.chips.map(Number); r.check = { n: v.length, unique: new Set(v).size, sorted: v.every((x, i) => !i || v[i - 1] <= x), inRange: v.every(x => x >= 1 && x <= 100) }; return r; });
  await C('N02-copy', copy); await C('N02-dl', () => dl('N02'));
  await C('N03-6unique-1to5', async () => { await fill('rng-min', 1); await fill('rng-max', 5); await fill('rng-count', 6); const r = await res(); await shot('N03'); return r; });
  await C('N04-swapped', async () => { await sw('rng-unique', false); await fill('rng-min', 50); await fill('rng-max', 10); await fill('rng-count', 5); return go(); });
  await C('N05-decimals-0.5-1.5-dp3', async () => { await fill('rng-min', '0.5'); await fill('rng-max', '1.5'); await fill('rng-count', 10); await p.selectOption('#rng-dp', '3'); const r = await go(); const v = r.chips.map(Number); r.check = { inRange: v.every(x => x >= 0.5 && x <= 1.5), dp3: r.chips.every(s => /^\d\.\d{3}$/.test(s)) }; return r; });
  await C('N06-decimal-in-whole-mode', async () => { await p.selectOption('#rng-dp', '0'); await fill('rng-min', '1.5'); await fill('rng-max', '10'); return res(); });
  await C('N07-trim-dp1-0.05-0.95', async () => { await p.selectOption('#rng-dp', '1'); await fill('rng-min', '0.05'); await fill('rng-max', '0.95'); await fill('rng-count', 30); const r = await go(); const v = r.chips.map(Number); r.check = { min: Math.min(...v), max: Math.max(...v) }; return r; });
  await C('N08-cap-20000', async () => { await p.selectOption('#rng-dp', '0'); await fill('rng-min', 1); await fill('rng-max', 1000000); await fill('rng-count', 20000); const t0 = Date.now(); const r = await go(); r.ms = Date.now() - t0; r.chips = r.chips.length; await shot('N08'); return r; });
  await C('N08-dl', () => dl('N08'));
  await C('N09-bigint-range', async () => { await fill('rng-min', '-99999999999999999999'); await fill('rng-max', '99999999999999999999'); await fill('rng-count', 3); return go(); });
  await C('N10-commas-and-text', async () => { await fill('rng-min', '1,000'); await fill('rng-max', '2_000'); await fill('rng-count', 3); const a = await go(); await fill('rng-max', 'abc'); const b2 = await res(); await fill('rng-max', ''); const c2 = await res(); await fill('rng-count', '0'); await fill('rng-max', '10'); const d2 = await res(); return { commas: a, text: b2, empty: c2, count0: d2 }; });
  await C('N11-seed-repeat', async () => { await fill('rng-min', 1); await fill('rng-max', 1000); await fill('rng-count', 10); await fill('rng-seed', 'class-7B'); const a = await go(); const warn = await p.locator('[data-testid=rng-seed-warning]').innerText().catch(() => null); const b2 = await go(); await fill('rng-seed', 'class-7C'); const c2 = await go(); await fill('rng-seed', ''); const d2 = await go(); const e2 = await go(); await shot('N11');
   return { same: a.chips.join() === b2.chips.join(), diffSeed: a.chips.join() !== c2.chips.join(), unseededDiffer: d2.chips.join() !== e2.chips.join(), a: a.chips, method: a.method, warn, unseededMethod: d2.method }; });
  await C('N12-uniform-1-6-x10000', async () => { await fill('rng-min', 1); await fill('rng-max', 6); await fill('rng-count', 10000); await go(); const s = await dl('N12'); const txt = fs.readFileSync(OUT + 'downloads/N12' + sfx + '-random-numbers.txt', 'utf8').trim().split('\n').map(Number); const k = [1, 2, 3, 4, 5, 6].map(x => txt.filter(v => v === x).length); const e = txt.length / 6; return { n: txt.length, counts: k, chi2: +k.reduce((a, o) => a + (o - e) ** 2 / e, 0).toFixed(2), crit5pct_df5: 11.07 }; });
  await tab('Dice');
  for (const [id, v] of [['D01-2d6', '2d6'], ['D02-d20', 'd20'], ['D03-3d8+2', '3d8+2'], ['D04-0d6', '0d6'], ['D05-2d1', '2d1'], ['D06-junk', 'two dice'], ['D07-10000d6', '10000d6'], ['D08-10001d6', '10001d6'], ['D09-1d1000001', '1d1000001'], ['D10-2d6-3', '2d6-3']]) await C(id, async () => { await fill('rng-dice', v); const r = await go(); if (r.chips) { r.nChips = r.chips.length; r.chips = r.chips.slice(0, 12); } if (id === 'D03-3d8+2') await shot('D03'); return r; });
  await tab('Coin');
  for (const [id, v] of [['C01-1', 1], ['C02-100', 100], ['C03-10000', 10000], ['C04-10001', 10001], ['C05-0', 0]]) await C(id, async () => { await fill('rng-flips', v); const r = await go(); if (r.chips) { r.nChips = r.chips.length; r.chips = r.chips.slice(0, 6); } if (id === 'C02-100') await shot('C02'); return r; });
  await C('C03-dl', async () => { await fill('rng-flips', 10000); await go(); return dl('C03'); });
  await tab('Lottery');
  for (const [id, a, o] of [['L01-6of49', 6, 49], ['L02-5of69', 5, 69], ['L03-50of49', 50, 49], ['L04-1of1', 1, 1], ['L05-6of100001', 6, 100001], ['L06-99999of100000', 99999, 100000]]) await C(id, async () => { await fill('rng-pick', a); await fill('rng-pool', o); const t0 = Date.now(); const r = await go(); r.ms = Date.now() - t0; if (r.chips) { r.nChips = r.chips.length; r.chips = r.chips.slice(0, 8); } if (id === 'L01-6of49') await shot('L01'); return r; });
  await tab('List');
  await C('T01-pick2-dupes', async () => { await fill('rng-list', 'Ana\nBen\nChloé\n山田\nأحمد\nBen\n😀 Emoji'); await fill('rng-listpick', 2); const r = await go(); await shot('T01'); return r; });
  await C('T02-shuffle-all', async () => { await fill('rng-listpick', ''); return go(); });
  await C('T02-copy', copy);
  await C('T03-pick9-of-7', async () => { await fill('rng-listpick', 9); return res(); });
  await C('T04-empty', async () => { await fill('rng-list', ''); await fill('rng-listpick', ''); return res(); });
  await C('T05-all-word', async () => { await fill('rng-list', 'a\nb\nc'); await fill('rng-listpick', 'all'); return go(); });
  await C('T06-10001-lines', async () => { await fill('rng-list', Array.from({ length: 10001 }, (_, i) => 'n' + i).join('\n')); return res(); });
  await C('T07-500plus-display', async () => { await fill('rng-list', Array.from({ length: 800 }, (_, i) => 'n' + i).join('\n')); await fill('rng-listpick', ''); const r = await go(); r.chips = r.chips.length; return r; });
  R.end = { used: await used(), strip: await strip() }; R.net = net;
 } else { const TRIES = +(process.env.TRIES || 8);
  // cap context first
  await open(); R.cap = { used: await used(), strip: await strip() };
  await fill('rng-count', 5); R.cap.gen = await go(); R.cap.afterGen = await used(); R.cap.copy = await copy(); R.cap.dl = await dl('cap'); R.cap.copy2 = await copy(); R.cap.net = net; await shot('gate-cap'); await c.close();
  for (let i = 0; i < TRIES; i++) { await open(); const u = await used(); R.tries.push(u); const [a, l] = u.split(' ')[0].split('/').map(Number); if (a < l) break; await c.close(); c = null; }
  if (c) { const L = R.left = { start: await used(), strip: await strip() };
   await fill('rng-count', 5); L.gen1 = (await go()).chips; L.afterGen1 = await used(); L.copy1 = await copy(); L.copy1b = await copy(); L.dl1 = await dl('left1');
   L.gen2 = (await go()).chips; L.afterGen2 = await used(); L.copy2 = await copy(); L.dl2 = await dl('left2');
   await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); L.afterReload = await used(); await fill('rng-count', 5); await go(); L.copy3 = await copy(); L.dl3 = await dl('left3'); L.end = await used(); L.strip2 = await strip(); L.net = net; await shot('gate-left'); }
 }
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', R.start || R.cap && R.cap.used, R.end || (R.left && R.left.end)); await b.close(); })();
