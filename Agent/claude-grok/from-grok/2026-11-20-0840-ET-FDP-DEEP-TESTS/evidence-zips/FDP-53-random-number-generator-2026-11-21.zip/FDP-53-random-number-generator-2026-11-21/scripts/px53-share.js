// FDP-53: header star (favourite), share icon, "Share this tool", "Create Shortcut" — record dialogs/toasts/popups only; never posts or signs in (guest)
const { chromium } = require('playwright'); const fs = require('fs'); const O = '/workspace/deep/53-random-number-generator/live/';
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 }, permissions: ['clipboard-read', 'clipboard-write'] }); const p = await c.newPage(); p.setDefaultTimeout(6000); const R = {};
 await p.addInitScript(() => { window.__t = []; const seen = new WeakSet(); setInterval(() => { document.querySelectorAll('[data-sonner-toast]').forEach(n => { if (!seen.has(n)) { seen.add(n); window.__t.push((n.innerText || '').trim()); } }); }, 120); navigator.share = undefined; });
 await p.goto('https://www.freedailypro.com/tool/random-number-generator', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 const step = async (id, loc) => { const n = await p.evaluate(() => window.__t.length); const pop = c.waitForEvent('page', { timeout: 3000 }).catch(() => null); try { await loc.first().click(); } catch (e) { R[id] = { err: e.message.split('\n')[0] }; return; } const pg = await pop; await p.waitForTimeout(1500);
  const d = p.locator('[role=dialog]'); const dlg = (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 400) : null; let clip = null; try { clip = (await p.evaluate(() => navigator.clipboard.readText())).slice(0, 120); } catch (e) { }
  R[id] = { dialog: dlg, toasts: await p.evaluate(n => window.__t.slice(n), n), popup: pg ? pg.url().replace(/(client_id|state|redirect_uri)=[^&]*/g, '$1=REDACTED').slice(0, 120) : null, clip, url: p.url() }; if (dlg) await p.screenshot({ path: O + 'cases/share-' + id + '.png' }); if (pg) await pg.close(); for (let i = 0; i < 2; i++) await p.keyboard.press('Escape'); await p.waitForTimeout(300); console.log(id, JSON.stringify(R[id])); };
 await step('star', p.locator('h1 ~ button, h1 + * button').first().or(p.locator('main button[aria-label*="avorite" i], main button[aria-label*="avourite" i]')));
 await step('shareIcon', p.locator('main button[aria-label*="hare" i]').first());
 await step('shareThisTool', p.locator('main button', { hasText: 'Share this tool' }));
 await step('createShortcut', p.locator('main button', { hasText: 'Create Shortcut' }));
 R.headerButtons = await p.evaluate(() => [...document.querySelectorAll('main button')].slice(0, 6).map(x => (x.getAttribute('aria-label') || x.innerText).trim().slice(0, 40)));
 fs.writeFileSync(O + 'share.json', JSON.stringify(R, null, 1)); await b.close(); })();
