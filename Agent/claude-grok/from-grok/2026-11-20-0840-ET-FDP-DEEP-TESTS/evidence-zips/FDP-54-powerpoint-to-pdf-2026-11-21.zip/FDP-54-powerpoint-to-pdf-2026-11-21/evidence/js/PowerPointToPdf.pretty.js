import { r as s, j as e } from "./vendor-react-D01g8YgM.js";
import { S as _ } from "./SlideUi-CQJgwyDz.js";
import { T as q } from "./ToolWithSidebar-C7kxZj7O.js";
import { b as Q, P as U, D as H, R as M } from "./ToolPage-DwLoDncN.js";
import { ax as W, L as J, B as x, ay as Y, f as G } from "./index-B1CTyGtY.js";
import { C as T } from "./checkbox-Ml1pfDb3.js";
import { J as Z } from "./jszip.min-CT0ZA6V1.js";
import { f as L } from "./formatFileSize-B-JRDfN5.js";
import { p as N } from "./plural-FIChqbp4.js";
import {
  shouldDefaultToFastQuality as X,
  getPptxPreview as K,
  PPTX_LARGE_FILE_WARNING_BYTES as V,
  convertPowerPointToPdfRasterDetailed as ee,
  PptxConversionCancelled as te,
} from "./pptxRasterize-CxkExeBE.js";
import "./legacyDeck-Dmz2TtSU.js";
import "./trpcVanilla-BSVQBMYf.js";
import "./xmlLite-D0-GZ86u.js";
import "./chevron-left-CWH4XvTX.js";
import "./chevron-right-7IYXE5RL.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-DhOoIDuZ.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./domCapture-Ci6fgcjv.js";
import "./backgroundSafe-DObGz9DE.js";
import "./utils-s8ucLyj8.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./fontkit.es-DA-3qwB1.js";
import "./domTextLines-YXN485C_.js";
import "./pdfMetadata-CcxIhQF2.js";
const E = {
    what: "Converts a PowerPoint presentation (.pptx) into a PDF by taking a real visual snapshot of each slide: its background (solid, gradient or picture), colours, shapes, pictures, tables and charts. One PDF page per slide, sized to match your presentation's actual dimensions (standard or widescreen), not forced to A4 or Letter. Hidden slides are left out unless you ask for them, and speaker notes are not printed.",
    tip: "Each page is a picture of the slide. By default an invisible copy of the slide's text is placed over each picture so the PDF can be searched and copied (you can turn that off for the smallest file); Chinese, Japanese, Hindi, Arabic and similar text is shown correctly in the picture but is not part of the searchable layer. SmartArt, 3D effects, animations and embedded video or audio are approximated or left out, and a font PowerPoint used that your browser doesn't have gets a close substitute. For very large decks, Fast quality converts quicker and makes a smaller file. Old .ppt files: open them in PowerPoint and save as .pptx first.",
  },
  re = [
    { id: "fast", label: "Fast", hint: "Quicker, smaller file" },
    { id: "default", label: "Default", hint: "Balanced" },
    {
      id: "sharp",
      label: "Sharp",
      hint: "Best detail, larger file, slower on big decks",
    },
  ];
function Ve() {
  const [o, d] = s.useState(null),
    [u, k] = s.useState(null),
    [C, b] = s.useState(!1),
    [g, v] = s.useState(!1),
    [l, m] = s.useState(null),
    [a, f] = s.useState(null),
    [w, O] = s.useState(!0),
    [S, n] = s.useState(""),
    [c, P] = s.useState(null),
    [y, F] = s.useState(!1),
    [D, j] = s.useState(null),
    p = s.useRef(null),
    { logUsageNow: A } = Q(),
    I = s.useCallback(async (t) => {
      p.current?.abort();
      const r = t[0] || null;
      if ((n(""), f(null), m(null), v(!1), b(!1), r)) {
        const i = r.name.toLowerCase();
        if (i.endsWith(".ppt"))
          return (
            d(null),
            void n(
              "Old .ppt files are not supported. Open it in PowerPoint and use Save As → PowerPoint Presentation (.pptx), then drop it here.",
            )
          );
        if (i.endsWith(".odp"))
          return (
            d(null),
            void n(
              "OpenDocument (.odp) files are not supported. Open it in PowerPoint or LibreOffice and save it as .pptx, then drop it here.",
            )
          );
        try {
          if (!(await Z.loadAsync(r)).file("ppt/presentation.xml"))
            throw new Error("not a presentation");
        } catch {
          return (
            d(null),
            void n(
              "This is not a .pptx file. It may be damaged, or another kind of file renamed to .pptx.",
            )
          );
        }
      }
      (d(r), k(r && X(r) ? "fast" : "default"));
    }, []);
  s.useEffect(() => {
    if (!o) {
      (P(null), j(null));
      return;
    }
    let t = !0;
    return (
      P(null),
      j(null),
      F(!0),
      K(o)
        .then((r) => {
          t && P(r);
        })
        .catch((r) => {
          t &&
            (console.error("PowerPoint preview failed:", r),
            j(r instanceof Error ? r.message : "Couldn't preview this file"));
        })
        .finally(() => {
          t && F(!1);
        }),
      () => {
        t = !1;
      }
    );
  }, [o]);
  const R = () => {
      p.current?.abort();
    },
    $ = async () => {
      if (!o || !u || !(await A())) return;
      const r = new AbortController();
      ((p.current = r), v(!0), m({ current: 0, total: 0 }));
      try {
        const i = await ee(o, {
          quality: u,
          includeHidden: C,
          searchableText: w,
          signal: r.signal,
          onProgress: (h, B) => m({ current: h, total: B }),
        });
        (f(i),
          Y("powerpoint-to-pdf", "powerpoint-slides"),
          G.success("PowerPoint converted to PDF!"));
      } catch (i) {
        if (!(i instanceof te)) {
          console.error("PowerPoint to PDF conversion failed:", i);
          const h =
            i instanceof Error && i.name === "QuotaExceededError"
              ? "Ran out of memory converting this deck — try Fast quality, or a smaller file"
              : i instanceof Error
                ? i.message
                : "Couldn't convert this file — make sure it's a valid .pptx presentation";
          n(h);
        }
      } finally {
        (v(!1), m(null), (p.current = null));
      }
    },
    z = !!o && o.size > V;
  return e.jsxs(q, {
    toolId: "powerpoint-to-pdf",
    categoryId: "powerpoint-slides",
    whatItDoes: E.what,
    proTip: E.tip,
    children: [
      S &&
        e.jsxs("div", {
          role: "alert",
          className:
            "mb-4 p-3 rounded-lg border border-destructive/40 bg-destructive/5 text-sm flex gap-2",
          children: [
            e.jsx(W, { className: "h-4 w-4 mt-0.5 shrink-0 text-destructive" }),
            e.jsx("span", { children: S }),
          ],
        }),
      o
        ? e.jsxs("div", {
            className: "space-y-4",
            children: [
              e.jsxs("div", {
                className: "p-4 rounded-lg border bg-card space-y-1",
                children: [
                  e.jsx("p", {
                    className: "text-sm font-medium break-all",
                    children: o.name,
                  }),
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground",
                    children: L(o.size),
                  }),
                ],
              }),
              y &&
                e.jsxs("div", {
                  className:
                    "flex items-center gap-2 text-sm text-muted-foreground py-6 justify-center border rounded-lg bg-card",
                  children: [
                    e.jsx(J, { className: "h-4 w-4 animate-spin" }),
                    "Loading preview...",
                  ],
                }),
              D &&
                !y &&
                e.jsxs("p", {
                  className: "text-sm text-muted-foreground",
                  children: [
                    "Couldn't generate a preview (",
                    D,
                    "). You can still try converting.",
                  ],
                }),
              c &&
                !y &&
                !a &&
                e.jsxs("div", {
                  className: "space-y-1",
                  children: [
                    e.jsx("img", {
                      src: c.dataUrl,
                      alt: "Preview of the first slide",
                      className: "w-full rounded-lg border",
                    }),
                    e.jsxs("p", {
                      className: "text-xs text-muted-foreground",
                      children: [
                        N(c.slideCount, "slide"),
                        c.hiddenSlideCount > 0 &&
                          ` (${c.hiddenSlideCount} hidden)`,
                        ", first slide shown above",
                      ],
                    }),
                  ],
                }),
              z &&
                !g &&
                !a &&
                e.jsx("p", {
                  className: "text-sm text-muted-foreground",
                  children:
                    "Large file — conversion stays in this tab and may take a while.",
                }),
              !g &&
                !a &&
                e.jsxs("div", {
                  className: "space-y-3",
                  children: [
                    e.jsxs("div", {
                      children: [
                        e.jsx("p", {
                          className: "text-sm font-medium mb-2",
                          id: "ppt-quality-label",
                          children: "Quality",
                        }),
                        e.jsx("div", {
                          className: "flex flex-wrap gap-2",
                          role: "group",
                          "aria-labelledby": "ppt-quality-label",
                          children: re.map((t) =>
                            e.jsx(
                              x,
                              {
                                type: "button",
                                size: "sm",
                                variant: u === t.id ? "default" : "outline",
                                "aria-pressed": u === t.id,
                                onClick: () => k(t.id),
                                title: t.hint,
                                children: t.label,
                              },
                              t.id,
                            ),
                          ),
                        }),
                      ],
                    }),
                    e.jsxs("label", {
                      htmlFor: "ppt-include-hidden",
                      className:
                        "flex items-center gap-2 text-sm cursor-pointer w-fit",
                      children: [
                        e.jsx(T, {
                          id: "ppt-include-hidden",
                          "aria-label": "Include hidden slides",
                          checked: C,
                          onCheckedChange: (t) => b(t === !0),
                        }),
                        "Include hidden slides",
                      ],
                    }),
                    e.jsxs("label", {
                      htmlFor: "ppt-searchable",
                      className:
                        "flex items-start gap-2 text-sm cursor-pointer w-fit",
                      children: [
                        e.jsx(T, {
                          id: "ppt-searchable",
                          "aria-label": "Make the text searchable and copyable",
                          className: "mt-0.5",
                          checked: w,
                          onCheckedChange: (t) => O(t === !0),
                        }),
                        e.jsxs("span", {
                          children: [
                            "Make the text searchable and copyable",
                            e.jsx("span", {
                              className: "block text-xs text-muted-foreground",
                              children:
                                "Adds an invisible text layer over each slide picture. Turn off for the smallest file.",
                            }),
                          ],
                        }),
                      ],
                    }),
                  ],
                }),
              e.jsx("div", {
                className: "flex gap-3",
                children: g
                  ? e.jsx(U, {
                      message:
                        l && l.total > 0
                          ? `Slide ${l.current} / ${l.total}`
                          : "Parsing...",
                      progress:
                        l && l.total > 0 ? (l.current / l.total) * 100 : void 0,
                      onStop: R,
                    })
                  : a
                    ? e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(H, {
                            blob: a.blob,
                            fileName: o.name.replace(/\.pptx$/i, ".pdf"),
                          }),
                          e.jsx(x, {
                            variant: "outline",
                            onClick: () => {
                              (d(null), f(null), b(!1));
                            },
                            children: "Convert another file",
                          }),
                        ],
                      })
                    : e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(x, { onClick: $, children: "Convert to PDF" }),
                          e.jsx(x, {
                            variant: "outline",
                            onClick: () => {
                              (p.current?.abort(), d(null), f(null), n(""));
                            },
                            children: "Choose a different file",
                          }),
                        ],
                      }),
              }),
              a &&
                e.jsxs("div", {
                  className: "space-y-3",
                  children: [
                    e.jsxs("p", {
                      className: "text-sm text-muted-foreground",
                      role: "status",
                      children: [
                        N(a.pages, "page"),
                        " · ",
                        L(a.blob.size),
                        " · ",
                        o.name.replace(/\.pptx$/i, ""),
                        ".pdf",
                        a.hiddenLeftOut > 0 &&
                          ` · ${N(a.hiddenLeftOut, "hidden slide")} left out`,
                        w
                          ? ` · ${a.textLines > 0 ? "searchable text added" : "no text found to make searchable"}`
                          : "",
                      ],
                    }),
                    e.jsx("div", {
                      className: "flex gap-2 overflow-x-auto pb-2",
                      "aria-label": "Pages of the PDF",
                      children: a.thumbs.map((t, r) =>
                        e.jsxs(
                          "figure",
                          {
                            className: "shrink-0 w-40",
                            children: [
                              t.dataUrl &&
                                e.jsx("img", {
                                  src: t.dataUrl,
                                  alt: `Page ${r + 1} (slide ${t.slideNumber})`,
                                  className: "w-full rounded border",
                                }),
                              e.jsxs("figcaption", {
                                className:
                                  "text-xs text-muted-foreground text-center",
                                children: ["Page ", r + 1],
                              }),
                            ],
                          },
                          r,
                        ),
                      ),
                    }),
                    e.jsx(M, { blob: a.blob, mimeType: "application/pdf" }),
                  ],
                }),
            ],
          })
        : e.jsx(_, {
            gateAtDownload: !0,
            onAttempt: () => n(""),
            onFiles: I,
            label: "Drop a PowerPoint file",
            description:
              "Convert each slide to a PDF page, visually, in your browser",
          }),
    ],
  });
}
export { Ve as default };
//# sourceMappingURL=PowerPointToPdf-Cog7wXZW.js.map
