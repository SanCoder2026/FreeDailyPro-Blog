import { r as l, j as i } from "./vendor-react-D01g8YgM.js";
import { N as H, B as T, L as B } from "./index-B1CTyGtY.js";
import { F as K } from "./ToolPage-DwLoDncN.js";
import { n as F, O as Q, a as W, c as z } from "./legacyDeck-Dmz2TtSU.js";
import { openPptxViewer as I } from "./pptxRasterize-CxkExeBE.js";
import { J as ee } from "./jszip.min-CT0ZA6V1.js";
import { p as P } from "./xmlLite-D0-GZ86u.js";
import { p as te } from "./plural-FIChqbp4.js";
import { C as re } from "./chevron-left-CWH4XvTX.js";
import { C as ne } from "./chevron-right-7IYXE5RL.js";
const se = "[Content_Types].xml",
  je =
    "application/vnd.openxmlformats-officedocument.presentationml.presentation";
class E extends Error {
  constructor(t) {
    (super(t), (this.name = "PptxError"));
  }
}
async function D(e) {
  let t;
  try {
    const n = e instanceof Blob ? await e.arrayBuffer() : e;
    t = await ee.loadAsync(n);
  } catch {
    throw new E(
      "This is not a .pptx file. It may be damaged, or another kind of file renamed to .pptx.",
    );
  }
  if (!t.file("ppt/presentation.xml") || !t.file(se))
    throw new E(
      "This is not a .pptx file. It may be damaged, or another kind of file renamed to .pptx.",
    );
  return t;
}
const L = (e) => e.name.slice(e.name.indexOf(":") + 1),
  S = (e, t) => (e ? e.children.filter((n) => L(n) === t) : []),
  y = (e, t) => S(e, t)[0];
function C(e, t) {
  if (e)
    for (const n of e.children) {
      if (L(n) === t) return n;
      const r = C(n, t);
      if (r) return r;
    }
}
function oe(e, t, n = []) {
  if (!e) return n;
  for (const r of e.children) (L(r) === t && n.push(r), oe(r, t, n));
  return n;
}
function $(e, t, n) {
  if (e)
    for (const [r, o] of Object.entries(e.attrs)) {
      const s = r.includes(":");
      if (r.slice(r.indexOf(":") + 1) === t && (n === void 0 || n === s))
        return o;
    }
}
function q(e) {
  const t = e.lastIndexOf("/");
  return t < 0 ? "" : e.slice(0, t);
}
function ie(e, t) {
  if (t.startsWith("/")) return t.slice(1);
  const n = (e === "" ? [] : q(e).split("/").filter(Boolean)).concat(
      t.split("/"),
    ),
    r = [];
  for (const o of n)
    o === "" || o === "." || (o === ".." ? r.pop() : r.push(o));
  return r.join("/");
}
function ae(e) {
  if (e === "") return "_rels/.rels";
  const t = q(e),
    n = e.slice(t.length + (t ? 1 : 0));
  return `${t ? t + "/" : ""}_rels/${n}.rels`;
}
function Ce(e) {
  if (e === "_rels/.rels") return "";
  const t = e.match(/^(.*?)\/?_rels\/([^/]+)\.rels$/);
  return t ? `${t[1] ? t[1] + "/" : ""}${t[2]}` : null;
}
function le(e) {
  return Object.values(e.files)
    .filter((t) => !t.dir)
    .map((t) => t.name);
}
function U(e, t, n) {
  if (e.file(t)) return t;
  let r = t;
  try {
    r = decodeURI(t);
  } catch {}
  if (r !== t && e.file(r)) return r;
  const o = n ?? new Map(le(e).map((s) => [s.toLowerCase(), s]));
  return o.get(t.toLowerCase()) ?? o.get(r.toLowerCase()) ?? null;
}
function ce(e, t) {
  const n = P(e);
  return S(n, "Relationship").map((r) => {
    const o = r.attrs.Target ?? "",
      s = (r.attrs.TargetMode ?? "").toLowerCase() === "external";
    return {
      id: r.attrs.Id ?? "",
      type: r.attrs.Type ?? "",
      target: o,
      external: s,
      path: s ? "" : ie(t, o),
    };
  });
}
async function M(e, t) {
  const n = e.file(ae(t));
  return n ? ce(await n.async("string"), t) : [];
}
const A = (e) => e.slice(e.lastIndexOf("/") + 1);
async function _(e, t) {
  const n = e.file(t);
  return n ? P(await n.async("string")) : null;
}
async function X(e) {
  const t = await _(e, "ppt/presentation.xml");
  if (!t)
    throw new E(
      "This is not a .pptx file. It may be damaged, or another kind of file renamed to .pptx.",
    );
  const n = await M(e, "ppt/presentation.xml"),
    r = new Map(n.map((c) => [c.id, c])),
    o = C(t, "sldIdLst"),
    s = [];
  for (const c of S(o, "sldId")) {
    const m = $(c, "id", !0) ?? "",
      f = r.get(m);
    if (!f || f.external) continue;
    const h = U(e, f.path);
    if (!h) continue;
    const w = await _(e, h),
      x = await M(e, h),
      g = x.find((a) => A(a.type) === "notesSlide"),
      b = x.filter((a) => A(a.type) === "comments");
    s.push({
      number: s.length + 1,
      path: h,
      rId: m,
      sldId: $(c, "id", !1) ?? "",
      hidden: w?.attrs.show === "0" || w?.attrs.show === "false",
      notesPath: g ? U(e, g.path) : null,
      commentPaths: b.map((a) => U(e, a.path)).filter((a) => !!a),
      rels: x,
    });
  }
  return s;
}
const ue = new Set(["sldNum", "dt", "ftr", "hdr"]);
function R(e) {
  let t = "";
  for (const n of e.children) {
    const r = L(n);
    r === "r"
      ? (t += y(n, "t")?.text ?? "")
      : r === "br"
        ? (t += `
`)
        : r === "fld" &&
          (/slidenum|datetime/i.test(n.attrs.type ?? "") ||
            (t += y(n, "t")?.text ?? ""));
  }
  return t
    .replace(
      /\r\n?/g,
      `
`,
    )
    .replace(
      /\u000b/g,
      `
`,
    );
}
function fe(e, t) {
  const n = [];
  for (const r of S(e, "p")) {
    const o = R(r)
      .replace(
        /[ \t]+\n/g,
        `
`,
      )
      .trim();
    if (!o) continue;
    const s = y(r, "pPr"),
      c = Math.max(0, Math.min(8, parseInt(s?.attrs.lvl ?? "0", 10) || 0)),
      m = !!(y(s, "buChar") || y(s, "buAutoNum") || y(s, "buBlip")),
      f = !!y(s, "buNone");
    n.push({ text: o, level: c, bullet: m || (t && !f) });
  }
  return n;
}
function Z(e, t, n) {
  const r = P(e),
    o = C(C(r, "cSld"), "spTree"),
    s = {
      number: t,
      hidden: n,
      title: "",
      paragraphs: [],
      tables: [],
      unreadObjects: 0,
    },
    c = [],
    m = (f) => {
      for (const h of f?.children ?? []) {
        const w = L(h);
        if (w === "grpSp") m(h);
        else if (w === "sp") {
          const x = C(y(y(h, "nvSpPr"), "nvPr"), "ph"),
            g = x?.attrs.type ?? (x ? "body" : "");
          if (ue.has(g)) continue;
          const b = y(h, "txBody");
          if (!b) continue;
          if (g === "title" || g === "ctrTitle") {
            const a = S(b, "p")
              .map((u) =>
                R(u)
                  .replace(/\s*\n\s*/g, " ")
                  .trim(),
              )
              .filter(Boolean)
              .join(" ");
            a && c.push(a);
          } else {
            const a = !!x && g !== "subTitle";
            s.paragraphs.push(...fe(b, a));
          }
        } else if (w === "graphicFrame") {
          const x = C(y(h, "graphic"), "graphicData"),
            g = x?.attrs.uri ?? "",
            b = C(x, "tbl");
          if (b) {
            const a = S(b, "tr").map((u) =>
              S(u, "tc").map((j) => {
                const v = y(j, "txBody");
                return v
                  ? S(v, "p")
                      .map((d) =>
                        R(d)
                          .replace(/\s*\n\s*/g, " ")
                          .trim(),
                      )
                      .filter(Boolean)
                      .join(" ")
                  : "";
              }),
            );
            a.some((u) => u.some(Boolean)) && s.tables.push(a);
          } else /chart|diagram/i.test(g) && s.unreadObjects++;
        }
      }
    };
  if ((m(o), (s.title = c.join(" ")), !s.title && s.paragraphs.length > 0)) {
    const f = s.paragraphs[0];
    !f.bullet &&
      f.level === 0 &&
      !f.text.includes(`
`) &&
      f.text.length <= 100 &&
      ((s.title = f.text), (s.titleGuessed = !0), s.paragraphs.shift());
  }
  return s;
}
function Ne(e) {
  const t = P(e),
    n = C(C(t, "cSld"), "spTree"),
    r = [],
    o = (s) => {
      for (const c of s?.children ?? []) {
        const m = L(c);
        if (m === "grpSp") o(c);
        else if (m === "sp") {
          const f = C(y(y(c, "nvSpPr"), "nvPr"), "ph");
          if (!f || f.attrs.type !== "body") continue;
          const h = y(c, "txBody");
          if (!h) continue;
          for (const w of S(h, "p")) r.push(R(w).replace(/[ \t]+$/gm, ""));
        }
      }
    };
  for (o(n); r.length && !r[r.length - 1].trim();) r.pop();
  for (; r.length && !r[0].trim();) r.shift();
  return r.join(`
`);
}
async function Se(e, t) {
  const n = t ?? (await X(e)),
    r = [];
  for (const o of n)
    r.push(Z(await e.file(o.path).async("string"), o.number, o.hidden));
  return r;
}
function Le(e) {
  const [t, n] = l.useState(null);
  return (
    l.useEffect(() => {
      if (!e) {
        n(null);
        return;
      }
      const r = URL.createObjectURL(e);
      return (n(r), () => URL.revokeObjectURL(r));
    }, [e]),
    t
  );
}
function O({ children: e, alert: t = !1, className: n }) {
  return i.jsx(H, {
    className: n,
    children: i.jsx("div", {
      role: t ? "alert" : "status",
      className: "text-sm",
      children: e,
    }),
  });
}
function Ee({ onFiles: e, accept: t, acceptLabel: n, ...r }) {
  const [o, s] = l.useState(!1),
    [c, m] = l.useState(""),
    [f, h] = l.useState(""),
    w = async (x) => {
      (m(""), h(""));
      const g = [],
        b = [];
      for (const a of x) {
        if (!F(a)) {
          g.push(a);
          continue;
        }
        s(!0);
        try {
          const u = await z(a, "pptx");
          (g.push(u.file),
            b.push(
              `${a.name} was converted to .pptx on our server (deleted right after). ${u.note}`,
            ));
        } catch (u) {
          h(
            `${a.name}: ${u instanceof Error ? u.message : "could not be converted."}`,
          );
        } finally {
          s(!1);
        }
      }
      (b.length && m(b.join(" ")), g.length && (await e(g)));
    };
  return i.jsxs(i.Fragment, {
    children: [
      i.jsx(K, {
        gateAtDownload: !0,
        ...r,
        accept: W,
        acceptLabel: Q,
        onFiles: w,
      }),
      o &&
        i.jsx(O, {
          className: "mt-3",
          children:
            "Converting to .pptx on our server. This takes a few seconds; the file is deleted as soon as it is done.",
        }),
      c && !o && i.jsx(O, { className: "mt-3", children: c }),
      f && i.jsx(O, { alert: !0, className: "mt-3", children: f }),
    ],
  });
}
async function Re(e) {
  if ((e.name.toLowerCase(), F(e)))
    return "This file needs converting to .pptx first. Drop it on the file box of a PowerPoint tool, or use Presentation Converter.";
  try {
    return (await D(e), null);
  } catch (t) {
    return t instanceof E
      ? t.message
      : "This is not a .pptx file. It may be damaged, or another kind of file renamed to .pptx.";
  }
}
function Pe(e) {
  const [t, n] = l.useState({
    loading: !1,
    error: null,
    slideCount: 0,
    hiddenCount: 0,
    firstSlideUrl: null,
  });
  return (
    l.useEffect(() => {
      if (!e) {
        n({
          loading: !1,
          error: null,
          slideCount: 0,
          hiddenCount: 0,
          firstSlideUrl: null,
        });
        return;
      }
      let r = !0,
        o = null;
      return (
        n({
          loading: !0,
          error: null,
          slideCount: 0,
          hiddenCount: 0,
          firstSlideUrl: null,
        }),
        (async () => {
          try {
            const s = await I(e);
            if (s.slideCount === 0)
              throw new Error("No slides found in this presentation");
            const c = await s.render(0, 640, { quality: 0.75 });
            if (!r) return;
            ((o = URL.createObjectURL(c)),
              n({
                loading: !1,
                error: null,
                slideCount: s.slideCount,
                hiddenCount: s.hidden.filter(Boolean).length,
                firstSlideUrl: o,
              }));
          } catch (s) {
            r &&
              n({
                loading: !1,
                error:
                  s instanceof Error
                    ? s.message
                    : "Could not preview this file",
                slideCount: 0,
                hiddenCount: 0,
                firstSlideUrl: null,
              });
          }
        })(),
        () => {
          ((r = !1), o && URL.revokeObjectURL(o));
        }
      );
    }, [e]),
    t
  );
}
function Ue({ file: e, intake: t, extra: n }) {
  return i.jsxs("div", {
    className: "space-y-2",
    children: [
      t.loading &&
        i.jsxs("div", {
          className:
            "flex items-center gap-2 text-sm text-muted-foreground py-6 justify-center border rounded-lg bg-card",
          children: [
            i.jsx(B, { className: "h-4 w-4 animate-spin" }),
            " Loading preview...",
          ],
        }),
      t.error &&
        !t.loading &&
        i.jsxs("p", {
          className: "text-sm text-muted-foreground",
          children: [
            "Could not draw a preview (",
            t.error,
            "). You can still try.",
          ],
        }),
      t.firstSlideUrl &&
        i.jsxs("figure", {
          children: [
            i.jsx("img", {
              src: t.firstSlideUrl,
              alt: `First slide of ${e.name}`,
              className: "w-full max-w-xl rounded-lg border",
            }),
            i.jsxs("figcaption", {
              className: "text-xs text-muted-foreground mt-1",
              children: [
                te(t.slideCount, "slide"),
                t.hiddenCount > 0 && ` (${t.hiddenCount} hidden)`,
                ", first slide shown",
                n,
              ],
            }),
          ],
        }),
    ],
  });
}
function Oe({
  blob: e,
  label: t = "Preview of the PowerPoint file",
  maxThumbs: n = 40,
}) {
  const [r, o] = l.useState(null),
    [s, c] = l.useState(0),
    [m, f] = l.useState(null),
    [h, w] = l.useState([]),
    [x, g] = l.useState(null),
    [b, a] = l.useState(!1),
    u = l.useRef([]),
    j = () => {
      (u.current.forEach((d) => URL.revokeObjectURL(d)), (u.current = []));
    };
  if (
    (l.useEffect(() => j, []),
    l.useEffect(() => {
      if (!e) {
        (o(null), f(null), w([]), g(null));
        return;
      }
      let d = !0;
      return (
        a(!0),
        (async () => {
          try {
            const p = await I(e);
            if (!d) return;
            (o(p),
              g(null),
              c((N) => Math.max(0, Math.min(N, p.slideCount - 1))),
              w(Array.from({ length: Math.min(p.slideCount, n) }, () => null)));
          } catch (p) {
            d &&
              (o(null),
              g(p instanceof Error ? p.message : "Could not draw a preview"));
          } finally {
            d && a(!1);
          }
        })(),
        () => {
          d = !1;
        }
      );
    }, [e, n]),
    l.useEffect(() => {
      if (!r || r.slideCount === 0) return;
      let d = !0;
      return (
        (async () => {
          try {
            const p = await r.render(Math.min(s, r.slideCount - 1), 960, {
              quality: 0.82,
            });
            if (!d) return;
            const N = URL.createObjectURL(p);
            (u.current.push(N), f(N));
          } catch (p) {
            d &&
              g(p instanceof Error ? p.message : "Could not draw this slide");
          }
        })(),
        () => {
          d = !1;
        }
      );
    }, [r, s]),
    l.useEffect(() => {
      if (!r) return;
      let d = !0;
      return (
        (async () => {
          const p = Math.min(r.slideCount, n);
          for (let N = 0; N < p; N++) {
            if (!d) return;
            try {
              const J = await r.render(N, 240, { quality: 0.6 });
              if (!d) return;
              const k = URL.createObjectURL(J);
              (u.current.push(k), w((V) => V.map((Y, G) => (G === N ? k : Y))));
            } catch {}
          }
        })(),
        () => {
          d = !1;
        }
      );
    }, [r, n]),
    !e)
  )
    return null;
  const v = r?.slideCount ?? 0;
  return i.jsxs("section", {
    "aria-label": t,
    className: "space-y-2",
    children: [
      x &&
        i.jsxs("p", {
          className: "text-sm text-muted-foreground",
          children: [
            "Could not draw a preview (",
            x,
            "). The file itself is still fine to download.",
          ],
        }),
      b &&
        !r &&
        i.jsxs("div", {
          className:
            "flex items-center gap-2 text-sm text-muted-foreground py-6 justify-center border rounded-lg bg-card",
          children: [
            i.jsx(B, { className: "h-4 w-4 animate-spin" }),
            " Drawing preview...",
          ],
        }),
      r &&
        i.jsxs(i.Fragment, {
          children: [
            i.jsx("div", {
              className: "relative max-w-3xl",
              children: m
                ? i.jsx("img", {
                    src: m,
                    alt: `Slide ${s + 1} of ${v}`,
                    className: "w-full rounded-lg border bg-white",
                    "data-testid": "deck-preview-main",
                  })
                : i.jsxs("div", {
                    className:
                      "aspect-video rounded-lg border bg-card flex items-center justify-center text-sm text-muted-foreground",
                    children: [
                      i.jsx(B, { className: "h-4 w-4 animate-spin mr-2" }),
                      " Drawing slide...",
                    ],
                  }),
            }),
            i.jsxs("div", {
              className: "flex items-center gap-2 text-sm",
              children: [
                i.jsx(T, {
                  type: "button",
                  size: "sm",
                  variant: "outline",
                  "aria-label": "Previous slide",
                  disabled: s <= 0,
                  onClick: () => c((d) => Math.max(0, d - 1)),
                  children: i.jsx(re, { className: "h-4 w-4" }),
                }),
                i.jsxs("span", {
                  className: "tabular-nums text-muted-foreground",
                  "aria-live": "polite",
                  children: ["Slide ", s + 1, " of ", v],
                }),
                i.jsx(T, {
                  type: "button",
                  size: "sm",
                  variant: "outline",
                  "aria-label": "Next slide",
                  disabled: s >= v - 1,
                  onClick: () => c((d) => Math.min(v - 1, d + 1)),
                  children: i.jsx(ne, { className: "h-4 w-4" }),
                }),
              ],
            }),
            v > 1 &&
              i.jsx("div", {
                className: "flex gap-2 overflow-x-auto pb-2",
                role: "list",
                "aria-label": "All slides",
                children: h.map((d, p) =>
                  i.jsx(
                    "button",
                    {
                      type: "button",
                      role: "listitem",
                      onClick: () => c(p),
                      "aria-label": `Show slide ${p + 1}`,
                      "aria-current": p === s ? "true" : void 0,
                      className: `shrink-0 w-32 rounded border overflow-hidden bg-card text-xs text-muted-foreground ${p === s ? "ring-2 ring-primary" : ""}`,
                      children: d
                        ? i.jsx("img", { src: d, alt: "", className: "w-full" })
                        : i.jsx("span", {
                            className:
                              "flex aspect-video items-center justify-center",
                            children: p + 1,
                          }),
                    },
                    p,
                  ),
                ),
              }),
            v > n &&
              i.jsxs("p", {
                className: "text-xs text-muted-foreground",
                children: [
                  "Small pictures are shown for the first ",
                  n,
                  " slides; use the arrows to reach the rest.",
                ],
              }),
          ],
        }),
    ],
  });
}
function Te(e, t = 240) {
  const [n, r] = l.useState({
      loading: !1,
      error: null,
      count: 0,
      hidden: [],
      titles: [],
    }),
    [o, s] = l.useState({}),
    c = l.useRef(null),
    m = l.useRef([]),
    f = l.useRef(new Set()),
    h = l.useRef([]),
    w = l.useRef(!1),
    x = l.useRef(0);
  (l.useEffect(() => {
    const a = ++x.current;
    if (
      ((m.current = []),
      (f.current = new Set()),
      (w.current = !1),
      (c.current = null),
      h.current.forEach((u) => URL.revokeObjectURL(u)),
      (h.current = []),
      s({}),
      !e)
    ) {
      r({ loading: !1, error: null, count: 0, hidden: [], titles: [] });
      return;
    }
    return (
      r({ loading: !0, error: null, count: 0, hidden: [], titles: [] }),
      (async () => {
        try {
          const u = await I(e);
          if (a !== x.current) return;
          let j = u.hidden.map(() => "");
          try {
            const v = await D(e),
              d = await X(v);
            j = [];
            for (const p of d)
              j.push(
                Z(await v.file(p.path).async("string"), p.number, p.hidden)
                  .title,
              );
          } catch {}
          if (a !== x.current) return;
          ((c.current = u),
            r({
              loading: !1,
              error: null,
              count: u.slideCount,
              hidden: u.hidden,
              titles: j,
            }));
        } catch (u) {
          a === x.current &&
            r({
              loading: !1,
              error:
                u instanceof Error ? u.message : "Could not draw this file",
              count: 0,
              hidden: [],
              titles: [],
            });
        }
      })(),
      () => {
        x.current++;
      }
    );
  }, [e]),
    l.useEffect(
      () => () => {
        (x.current++, h.current.forEach((a) => URL.revokeObjectURL(a)));
      },
      [],
    ));
  const g = l.useRef(() => {});
  g.current = async () => {
    if (w.current) return;
    w.current = !0;
    const a = x.current;
    try {
      for (; m.current.length && a === x.current;) {
        const u = m.current.shift(),
          j = c.current;
        if (!(!j || u >= j.slideCount))
          try {
            const v = await j.render(u, t, { quality: 0.6 });
            if (a !== x.current) return;
            const d = URL.createObjectURL(v);
            (h.current.push(d), s((p) => ({ ...p, [u]: d })));
          } catch {}
      }
    } finally {
      w.current = !1;
    }
  };
  const b = l.useRef((a) => {
    f.current.has(a) || (f.current.add(a), m.current.push(a), g.current());
  }).current;
  return (
    l.useEffect(() => {
      n.count > 0 && g.current();
    }, [n.count]),
    { ...n, thumbs: o, request: b }
  );
}
function Be({ deck: e, index: t, label: n, className: r = "" }) {
  const o = l.useRef(null),
    s = e.thumbs[t];
  return (
    l.useEffect(() => {
      if (s || e.count === 0) return;
      const c = o.current;
      if (!c || typeof IntersectionObserver > "u") {
        e.request(t);
        return;
      }
      const m = new IntersectionObserver(
        (f) => {
          f.some((h) => h.isIntersecting) && (e.request(t), m.disconnect());
        },
        { rootMargin: "300px" },
      );
      return (m.observe(c), () => m.disconnect());
    }, [s, t, e.count]),
    i.jsx("div", {
      ref: o,
      className: `aspect-video w-full overflow-hidden rounded border bg-white ${r}`,
      children: s
        ? i.jsx("img", {
            src: s,
            alt: n,
            className: "h-full w-full object-contain",
            draggable: !1,
          })
        : i.jsx("span", {
            className:
              "flex h-full w-full items-center justify-center text-xs text-muted-foreground",
            "aria-label": n,
            children: t + 1,
          }),
    })
  );
}
function Ie({ label: e, value: t, onChange: n, options: r, id: o }) {
  return i.jsxs("div", {
    children: [
      i.jsx("p", { className: "text-sm font-medium mb-2", id: o, children: e }),
      i.jsx("div", {
        className: "flex flex-wrap gap-2",
        role: "group",
        "aria-labelledby": o,
        children: r.map((s) =>
          i.jsx(
            T,
            {
              type: "button",
              size: "sm",
              variant: t === s.id ? "default" : "outline",
              "aria-pressed": t === s.id,
              title: s.hint,
              onClick: () => n(s.id),
              children: s.label,
            },
            s.id,
          ),
        ),
      }),
    ],
  });
}
function ke(e, t) {
  return e instanceof Error && e.name === "QuotaExceededError"
    ? "The browser ran out of memory. Try a smaller file."
    : e instanceof Error && e.message
      ? e.message
      : t;
}
export {
  y as A,
  oe as B,
  se as C,
  Oe as D,
  $ as E,
  Ue as I,
  je as P,
  Ee as S,
  O as T,
  X as a,
  Ne as b,
  Re as c,
  M as d,
  A as e,
  ae as f,
  U as g,
  ce as h,
  E as i,
  ie as j,
  S as k,
  D as l,
  Te as m,
  Ie as n,
  Ce as o,
  le as p,
  Be as q,
  Z as r,
  ke as s,
  q as t,
  Pe as u,
  Le as v,
  Se as w,
  _ as x,
  C as y,
  L as z,
};
//# sourceMappingURL=SlideUi-CQJgwyDz.js.map
