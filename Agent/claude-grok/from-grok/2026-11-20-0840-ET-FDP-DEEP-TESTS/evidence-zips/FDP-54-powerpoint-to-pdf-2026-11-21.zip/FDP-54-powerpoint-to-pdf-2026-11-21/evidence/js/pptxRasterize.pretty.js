const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/aiden0z-pptx-renderer.es-B1eM_8bb.js",
      "assets/jszip.min-CT0ZA6V1.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/jszip.min-C-FLQHAz.js",
      "assets/_commonjs-dynamic-modules-TDtrdbi3.js",
    ]),
) => i.map((i) => d[i]);
import { ap as W } from "./index-B1CTyGtY.js";
import { k as J, e as $ } from "./index-BRvxULIc.js";
import { captureElementImage as q } from "./domCapture-Ci6fgcjv.js";
import { u as S, y as _, r as G, i as Y } from "./backgroundSafe-DObGz9DE.js";
import { p as Z } from "./utils-s8ucLyj8.js";
import { P as V, e as X } from "./pdfFonts-Ckcqm3Ic.js";
import { c as K } from "./domTextLines-YXN485C_.js";
import { s as tt } from "./pdfMetadata-CcxIhQF2.js";
import { J as et } from "./jszip.min-CT0ZA6V1.js";
import "./vendor-react-D01g8YgM.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
const nt = {
    fast: { width: 1280, jpegQuality: 0.8 },
    default: { width: 1920, jpegQuality: 0.88 },
    sharp: { width: 2560, jpegQuality: 0.92 },
  },
  A = 96,
  C = 72;
class O extends Error {
  constructor() {
    (super("Conversion cancelled"), (this.name = "PptxConversionCancelled"));
  }
}
function P(t) {
  if (t?.aborted) throw new O();
}
async function v(t) {
  const {
      parseZip: e,
      buildPresentation: n,
      renderSlide: i,
      RECOMMENDED_ZIP_LIMITS: d,
    } = await W(
      async () => {
        const {
          parseZip: c,
          buildPresentation: p,
          renderSlide: r,
          RECOMMENDED_ZIP_LIMITS: o,
        } = await import("./aiden0z-pptx-renderer.es-B1eM_8bb.js");
        return {
          parseZip: c,
          buildPresentation: p,
          renderSlide: r,
          RECOMMENDED_ZIP_LIMITS: o,
        };
      },
      __vite__mapDeps([0, 1, 2, 3, 4]),
    ),
    l = await t.arrayBuffer();
  try {
    const c = await e(l, d);
    return { presentation: n(c), renderSlide: i };
  } catch (c) {
    throw new Error(
      c instanceof Error && /zip|central directory/i.test(c.message)
        ? "This doesn't look like a valid .pptx file"
        : "Couldn't read this presentation — it may be corrupted or use unsupported features",
    );
  }
}
async function it(t, e) {
  try {
    const n = new Image();
    ((n.src = t), await Y(n));
    const i = document.createElement("canvas");
    return (
      (i.width = e),
      (i.height = Math.max(
        1,
        Math.round((n.naturalHeight / n.naturalWidth) * e),
      )),
      i.getContext("2d").drawImage(n, 0, 0, i.width, i.height),
      i.toDataURL("image/jpeg", 0.6)
    );
  } catch {
    return "";
  }
}
async function F(t, e, n, i, d, l, c) {
  return ct(await R(t, e, n, i, d, l, c, "image/jpeg"));
}
async function R(t, e, n, i, d, l, c, p) {
  const r = (s) =>
      G(
        s,
        () => !!c?.aborted,
        () => {
          throw new O();
        },
      ),
    o = document.createElement("div");
  ((o.style.position = "fixed"),
    (o.style.left = "-99999px"),
    (o.style.top = "0"),
    (o.style.width = `${t.width}px`),
    (o.style.height = `${t.height}px`),
    (o.style.overflow = "hidden"),
    document.body.appendChild(o));
  const g = new Set(),
    u = e(t, n, { mediaUrlCache: new Map(), chartInstances: g }),
    h = document.createElement("div");
  ((h.style.width = `${t.width}px`),
    (h.style.height = `${t.height}px`),
    (h.style.position = "relative"),
    (h.style.background = "#ffffff"));
  try {
    if (
      (h.appendChild(u.element),
      o.appendChild(h),
      await r(Promise.resolve(u.ready)),
      g.forEach((s) => {
        try {
          (s.setOption({ animation: !1 }),
            s.resize({ animation: { duration: 0 } }));
        } catch {}
      }),
      await r(_().then(_)),
      g.size > 0)
    ) {
      const s = performance.now() + 120;
      for (; performance.now() < s;) await r(_());
    }
    if (l) {
      l.words = K(h);
      const s = h.getBoundingClientRect();
      l.links = [];
      for (const a of Array.from(h.querySelectorAll("a[href]"))) {
        const w = a.getAttribute("href") ?? "";
        if (/^(https?:|mailto:)/i.test(w))
          for (const m of Array.from(a.getClientRects()))
            m.width > 1 &&
              m.height > 1 &&
              l.links.push({
                url: w,
                x: m.left - s.left,
                y: m.top - s.top,
                w: m.width,
                h: m.height,
              });
      }
    }
    return await r(
      q(h, {
        mime: p,
        width: t.width,
        height: t.height,
        pixelRatio: i / t.width,
        quality: d,
        skipFonts: !0,
      }),
    );
  } finally {
    (u.dispose(), o.remove());
  }
}
async function rt(t) {
  try {
    const i = (
      await (await et.loadAsync(t)).file("docProps/core.xml")?.async("string")
    )?.match(/<dc:title>([\s\S]*?)<\/dc:title>/);
    return (
      (i &&
        i[1]
          .replace(/&amp;/g, "&")
          .replace(/&lt;/g, "<")
          .replace(/&gt;/g, ">")
          .replace(/&quot;/g, '"')
          .replace(/&apos;/g, "'")
          .trim()) ||
      void 0
    );
  } catch {
    return;
  }
}
async function ot(t, e = {}) {
  const n = S();
  try {
    return await st(t, e);
  } finally {
    n();
  }
}
async function st(t, e) {
  const {
      quality: n = "default",
      includeHidden: i = !1,
      searchableText: d = !0,
      onProgress: l,
      signal: c,
    } = e,
    p = nt[n];
  l?.(0, 0, "parsing");
  const { presentation: r, renderSlide: o } = await v(t);
  P(c);
  const g = r.slides.filter((y) => i || !y.hidden);
  if (g.length === 0)
    throw new Error(
      r.slides.length > 0
        ? 'Every slide in this presentation is hidden — check "Include hidden slides" to convert them'
        : "No slides found in this presentation",
    );
  const u = (r.width / A) * C,
    h = (r.height / A) * C,
    s = C / A,
    a = await J.create(),
    w = d ? new V(a) : null,
    m = [];
  let k = 0;
  for (let y = 0; y < g.length; y++) {
    (P(c), l?.(y + 1, g.length, "rendering"));
    const E = { words: [], links: [] },
      L = await F(r, o, g[y], p.width, p.jpegQuality, d ? E : void 0, c);
    P(c);
    const z = ht(L),
      I = a.addPage([u, h]),
      H = await a.embedJpg(z);
    I.drawImage(H, { x: 0, y: 0, width: u, height: h });
    for (const f of E.links) {
      const b = a.context.obj({
        Type: "Annot",
        Subtype: "Link",
        Rect: [f.x * s, h - (f.y + f.h) * s, (f.x + f.w) * s, h - f.y * s],
        Border: [0, 0, 0],
        A: { Type: "Action", S: "URI", URI: $.of(f.url) },
      });
      I.node.addAnnot(a.context.register(b));
    }
    if (w && E.words.length) {
      await w.prepare(E.words.map((f) => f.text).join(" "));
      for (const f of E.words) {
        const b = Array.from(f.text)
          .filter((x) => w.canDraw(x))
          .join("");
        if (!b.trim()) continue;
        const B = w.runs(b, "sans"),
          D = B.reduce((x, j) => x + j.font.widthOfTextAtSize(j.text, 1), 0);
        if (D <= 0) continue;
        const U = Math.min(
          Math.max((f.w * s) / D, f.h * s * 0.4),
          f.h * s * 1.3,
        );
        let M = f.x * s;
        const Q = h - (f.y + f.h * 0.8) * s;
        for (const x of B)
          x.font instanceof X ||
            (I.drawText(x.text, {
              x: M,
              y: Q,
              size: U,
              font: x.font,
              opacity: 0,
            }),
            (M += x.font.widthOfTextAtSize(x.text, U)));
        k++;
      }
    }
    m.push({
      slideNumber: r.slides.indexOf(g[y]) + 1,
      dataUrl: await it(L, 240),
    });
  }
  (P(c),
    tt(a, {
      title: await rt(t),
      fallbackTitle: t.name.replace(/\.[^.]+$/, ""),
    }));
  const N = await a.save();
  return {
    blob: Z(N),
    pages: g.length,
    slides: r.slides.length,
    hiddenLeftOut: i ? 0 : r.slides.filter((y) => y.hidden).length,
    thumbs: m,
    textLines: k,
  };
}
async function _t(t, e = {}) {
  return (await ot(t, e)).blob;
}
const at = 640,
  dt = 0.75;
async function At(t) {
  const e = S();
  try {
    return await lt(t);
  } finally {
    e();
  }
}
async function lt(t) {
  const { presentation: e, renderSlide: n } = await v(t);
  if (e.slides.length === 0)
    throw new Error("No slides found in this presentation");
  const i = e.slides[0];
  return {
    dataUrl: await F(e, n, i, at, dt),
    slideCount: e.slides.length,
    hiddenSlideCount: e.slides.filter((l) => l.hidden).length,
  };
}
function ct(t) {
  let e = "";
  for (let n = 0; n < t.length; n += 32768)
    e += String.fromCharCode.apply(null, Array.from(t.subarray(n, n + 32768)));
  return `data:image/jpeg;base64,${btoa(e)}`;
}
function ht(t) {
  const e = t.slice(t.indexOf(",") + 1),
    n = atob(e),
    i = new Uint8Array(n.length);
  for (let d = 0; d < n.length; d++) i[d] = n.charCodeAt(d);
  return i;
}
function Ct(t) {
  const n = typeof window < "u" && window.innerWidth < 768;
  return t.size > 157286400 || n;
}
const Rt = 40 * 1024 * 1024,
  T = (t) => (t === "png" ? "image/png" : "image/jpeg");
async function kt(t, e) {
  const n = S();
  try {
    const {
      format: i,
      width: d,
      includeHidden: l = !1,
      jpegQuality: c = 0.9,
      onProgress: p,
      signal: r,
    } = e;
    p?.(0, 0);
    const { presentation: o, renderSlide: g } = await v(t);
    P(r);
    const u = o.slides.filter((a) => l || !a.hidden);
    if (u.length === 0)
      throw new Error(
        o.slides.length > 0
          ? 'Every slide in this presentation is hidden. Tick "Include hidden slides" to convert them.'
          : "No slides found in this presentation",
      );
    const h = Math.max(1, Math.round((d * o.height) / o.width)),
      s = [];
    for (let a = 0; a < u.length; a++) {
      (P(r), p?.(a + 1, u.length));
      const w = await R(o, g, u[a], d, c, void 0, r, T(i));
      (P(r),
        s.push({
          slideNumber: o.slides.indexOf(u[a]) + 1,
          hidden: !!u[a].hidden,
          blob: new Blob([new Uint8Array(w)], { type: T(i) }),
          width: d,
          height: h,
        }));
    }
    return {
      images: s,
      slides: o.slides.length,
      hiddenLeftOut: l ? 0 : o.slides.filter((a) => a.hidden).length,
    };
  } finally {
    n();
  }
}
async function Lt(t) {
  const { presentation: e, renderSlide: n } = await v(t);
  return {
    slideCount: e.slides.length,
    hidden: e.slides.map((i) => !!i.hidden),
    slideWidth: e.width,
    slideHeight: e.height,
    async render(i, d, l = {}) {
      const c = S();
      try {
        const p = l.format ?? "jpg",
          r = await R(
            e,
            n,
            e.slides[i],
            d,
            l.quality ?? 0.8,
            void 0,
            l.signal,
            T(p),
          );
        return new Blob([new Uint8Array(r)], { type: T(p) });
      } finally {
        c();
      }
    },
  };
}
export {
  Rt as PPTX_LARGE_FILE_WARNING_BYTES,
  O as PptxConversionCancelled,
  _t as convertPowerPointToPdfRaster,
  ot as convertPowerPointToPdfRasterDetailed,
  At as getPptxPreview,
  Lt as openPptxViewer,
  kt as renderPptxSlideImages,
  Ct as shouldDefaultToFastQuality,
};
//# sourceMappingURL=pptxRasterize-CxkExeBE.js.map
