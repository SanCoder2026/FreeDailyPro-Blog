# FDP-54 test decks: python-pptx + LibreOffice conversions
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE
from pptx.dml.color import RGBColor
from PIL import Image, ImageDraw
import subprocess, os, zipfile, shutil
img = Image.new('RGB', (1200, 800), (30, 90, 160)); d = ImageDraw.Draw(img)
for i in range(0, 1200, 60): d.line([(i, 0), (1200 - i, 800)], fill=(250, 200, 40), width=6)
d.ellipse([400, 200, 800, 600], fill=(220, 40, 60)); img.save('pic.jpg', quality=90)
def deck(w, h):
    p = Presentation(); p.slide_width = w; p.slide_height = h; return p
# 1. rich 16:9 deck
p = deck(Inches(13.333), Inches(7.5))
s = p.slides.add_slide(p.slide_layouts[0]); s.shapes.title.text = 'Quarterly Review Q3 2026'; s.placeholders[1].text = 'Riverside Club · Board pack'
bg = s.background.fill; bg.gradient(); bg.gradient_angle = 45
bg.gradient_stops[0].color.rgb = RGBColor(0x10, 0x2a, 0x43); bg.gradient_stops[1].color.rgb = RGBColor(0x2e, 0xc4, 0xb6)
s.notes_slide.notes_text_frame.text = 'SPEAKER NOTE SECRET: do not print'
s = p.slides.add_slide(p.slide_layouts[1]); s.shapes.title.text = 'Agenda and highlights'
tf = s.placeholders[1].text_frame; tf.text = 'Membership grew 12% year on year'
for t in ['Café revenue up — naïve forecast beaten', 'Volunteer hours: 1,240', 'Visit https://www.example.org/report for details']: tf.add_paragraph().text = t
r = tf.paragraphs[3].runs[0]; r.hyperlink.address = 'https://www.example.org/report'
s = p.slides.add_slide(p.slide_layouts[5]); s.shapes.title.text = 'Revenue by quarter (chart)'
cd = CategoryChartData(); cd.categories = ['Q1', 'Q2', 'Q3', 'Q4']; cd.add_series('2025', (12, 15, 18, 21)); cd.add_series('2026', (14, 17, 23, 26))
s.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, Inches(1), Inches(1.6), Inches(7), Inches(5), cd)
pd = CategoryChartData(); pd.categories = ['Dues', 'Café', 'Events']; pd.add_series('Mix', (50, 30, 20))
s.shapes.add_chart(XL_CHART_TYPE.PIE, Inches(8.3), Inches(1.6), Inches(4.5), Inches(5), pd)
s = p.slides.add_slide(p.slide_layouts[5]); s.shapes.title.text = 'Budget table'
tb = s.shapes.add_table(4, 3, Inches(1), Inches(1.8), Inches(11), Inches(3)).table
for i, row in enumerate([['Item', 'Budget', 'Actual'], ['Venue', '$4,000', '$3,850'], ['Catering', '$2,500', '$2,910'], ['Total', '$6,500', '$6,760']]):
    for j, v in enumerate(row): tb.cell(i, j).text = v
s = p.slides.add_slide(p.slide_layouts[6]); s.shapes.add_picture('pic.jpg', Inches(0), Inches(0), width=Inches(13.333), height=Inches(7.5))
tx = s.shapes.add_textbox(Inches(1), Inches(6), Inches(11), Inches(1)); tx.text_frame.text = 'Full-bleed picture slide'; tx.text_frame.paragraphs[0].runs[0].font.size = Pt(36); tx.text_frame.paragraphs[0].runs[0].font.color.rgb = RGBColor(255, 255, 255)
s = p.slides.add_slide(p.slide_layouts[1]); s.shapes.title.text = 'HIDDEN SLIDE — internal salaries'; s.placeholders[1].text = 'Confidential numbers'
s._element.set('show', '0')
s = p.slides.add_slide(p.slide_layouts[1]); s.shapes.title.text = 'Languages: नमस्ते 日本語 العربية'
tf = s.placeholders[1].text_frame; tf.text = 'हिन्दी पाठ यहाँ है'; tf.add_paragraph().text = '日本語のテキストです'; tf.add_paragraph().text = 'هذا نص عربي'; tf.add_paragraph().text = 'Emoji 🎉🚀 and Ελληνικά, Русский'
s = p.slides.add_slide(p.slide_layouts[1]); s.shapes.title.text = 'Closing — thank you'; s.placeholders[1].text = 'Questions? board@riverside.example'
p.save('rich_16x9.pptx')
# 2. 4:3 deck, plain
p = deck(Inches(10), Inches(7.5))
for i in range(3):
    s = p.slides.add_slide(p.slide_layouts[1]); s.shapes.title.text = f'Standard 4:3 slide {i+1}'; s.placeholders[1].text = 'Small print check: ' + 'lorem ipsum ' * 12
p.save('standard_4x3.pptx')
# 3. 60-slide deck with pictures
p = deck(Inches(13.333), Inches(7.5))
for i in range(60):
    s = p.slides.add_slide(p.slide_layouts[5]); s.shapes.title.text = f'Slide {i+1} of 60'; s.shapes.add_picture('pic.jpg', Inches(3), Inches(1.6), height=Inches(5))
p.save('long_60.pptx')
# 4. text-free deck (picture only)
p = deck(Inches(13.333), Inches(7.5)); s = p.slides.add_slide(p.slide_layouts[6]); s.shapes.add_picture('pic.jpg', 0, 0, width=p.slide_width, height=p.slide_height); p.save('picture_only.pptx')
# bad files
open('notes.txt', 'w').write('hello'); shutil.copy('notes.txt', 'renamed_text.pptx')
b = open('rich_16x9.pptx', 'rb').read(); open('truncated.pptx', 'wb').write(b[:len(b)//2])
with zipfile.ZipFile('zip_not_pptx.pptx', 'w') as z: z.writestr('hello.txt', 'x')
# LibreOffice conversions
for flt, ext in [('ppt', 'ppt'), ('odp', 'odp')]:
    subprocess.run(['soffice', '--headless', '--convert-to', ext, 'rich_16x9.pptx'], capture_output=True, timeout=180)
subprocess.run(['soffice', '--headless', '--convert-to', 'ppsx:Impress MS PowerPoint 2007 XML AutoPlay', 'standard_4x3.pptx'], capture_output=True, timeout=180)
for f in sorted(os.listdir('.')): print(f, os.path.getsize(f))
