// FDP-54: click "Open from Google Drive" (guest) and record what opens; closes the popup it opened, never signs in. Also tab count to the drop zone.
const { chromium } = require('playwright'); const fs = require('fs'); const O = '/workspace/deep/54-powerpoint-to-pdf/live/';
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); const R = {};
 await p.goto('https://www.freedailypro.com/tool/powerpoint-to-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 const pop = c.waitForEvent('page', { timeout: 8000 }).catch(() => null); await p.locator('main button', { hasText: 'Open from Google Drive' }).click(); const pg = await pop; await p.waitForTimeout(2500);
 R.drive = { popup: pg ? (await pg.url()).replace(/(client_id|state|redirect_uri|opparams|dsh|nonce)=[^&]*/g, '$1=REDACTED').replace(/#.*/, '#REDACTED').slice(0, 140) : null, dialog: (await p.locator('[role=dialog]').count()) ? (await p.locator('[role=dialog]').first().innerText()).slice(0, 200) : null };
 if (pg) { await pg.waitForTimeout(1500); await pg.screenshot({ path: O + 'cases/drive-popup.png' }); R.drive.title = await pg.title(); await pg.close(); }
 await p.keyboard.press('Escape'); await p.goto('https://www.freedailypro.com/tool/powerpoint-to-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); await p.locator('body').click({ position: { x: 5, y: 300 } });
 let n = 0; for (; n < 60; n++) { await p.keyboard.press('Tab'); const t = await p.evaluate(() => { const a = document.activeElement; return (a.getAttribute('aria-label') || a.innerText || '').slice(0, 40); }); if (/Drop a PowerPoint/i.test(t)) break; } R.tabsToDrop = n + 1;
 const ok = await p.evaluate(() => document.activeElement.getBoundingClientRect().height); R.dropFocusedHeight = ok;
 fs.writeFileSync(O + 'drive.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R)); await b.close(); })();
