// FDP-54: drop the same valid .pptx renamed to .pptm/.potx/.pps/.key plus a real .ppsx — record message, preview, network (guest, at any count; no Convert)
const { chromium } = require('playwright'); const fs = require('fs'); const O = '/workspace/deep/54-powerpoint-to-pdf/'; const R = {};
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); const net = [];
 p.on('request', r => { if (r.method() === 'POST' && /presentation|convert|office/.test(r.url())) net.push(r.url().slice(0, 90) + ' ' + (r.postData() || '').length); });
 await p.addInitScript(() => { window.__t = []; const seen = new WeakSet(); setInterval(() => { document.querySelectorAll('[data-sonner-toast]').forEach(n => { if (!seen.has(n)) { seen.add(n); window.__t.push((n.innerText || '').trim()); } }); }, 120); });
 await p.goto('https://www.freedailypro.com/tool/powerpoint-to-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 for (const f of ['standard_4x3.ppsx', 'renamed_ext.pptm', 'renamed_ext.potx', 'renamed_ext.pps', 'renamed_ext.key']) { const n0 = net.length; const t0 = await p.evaluate(() => window.__t.length);
  await p.locator('main input[type=file]').first().setInputFiles(O + 'testfiles/' + f); await p.waitForTimeout(9000);
  R[f] = await p.evaluate(t0 => { const m = document.querySelector('main'); return { alert: [...m.querySelectorAll('[role=alert]')].map(a => a.innerText.trim()), preview: (m.innerText.match(/[^\n]*first slide shown above/) || [null])[0], toasts: window.__t.slice(t0) }; }, t0); R[f].net = net.slice(n0);
  console.log(f, JSON.stringify(R[f])); await p.screenshot({ path: O + 'live/cases/ext-' + f.replace(/\./g, '_') + '.png' });
  const bt = p.locator('main button', { hasText: /^(Choose a different file)$/ }); if (await bt.count()) await bt.click(); await p.waitForTimeout(500); }
 fs.writeFileSync(O + 'live/ext.json', JSON.stringify(R, null, 1)); await b.close(); })();
