import { r as c, j as e } from "./vendor-react-D01g8YgM.js";
import { J as ye } from "./jszip.min-CT0ZA6V1.js";
import { T as Ce } from "./ToolWithSidebar-C7kxZj7O.js";
import { b as Se, F as Pe, P as Fe, D as oe } from "./ToolPage-DwLoDncN.js";
import { R as De } from "./ReorderableFileList-BhqJ-ECL.js";
import { f as O, e as j, I as k, B as ae, ay as ke } from "./index-B1CTyGtY.js";
import { C as q } from "./checkbox-Ml1pfDb3.js";
import {
  S as Le,
  a as Be,
  b as Ie,
  c as Te,
  d as $e,
} from "./select-ic5yaeGw.js";
import { l as Ae } from "./operations-B4LtHhm8.js";
import { P as Ee } from "./PdfPageStrip-Dr4IJevd.js";
import { l as Oe } from "./utils-s8ucLyj8.js";
import { u as p } from "./useSessionState-BLsNNse9.js";
import {
  v as Re,
  p as ne,
  e as ze,
  f as Me,
  D as re,
  s as Ue,
  b as Ve,
  B as We,
} from "./batesNumbering-Pmx-EMyr.js";
import { f as _e } from "./reorderMath-CVj9Q6Gj.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./formatFileSize-B-JRDfN5.js";
import "./grip-vertical-Dzkp2Q5V.js";
import "./index-DhOoIDuZ.js";
import "./index-BdQq_4o_.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./pdfMetadata-CcxIhQF2.js";
import "./pageView-BQIwVYOi.js";
import "./formAppearance-CdNbuISd.js";
import "./drawTextAnywhere-DcuP6lHH.js";
import "./ocrText-C_9cxcFa.js";
import "./ocrImage-CmXFNUud.js";
import "./imageRecompress-eXQFDUm-.js";
import "./plural-FIChqbp4.js";
import "./textDiff-DxE9AzvO.js";
import "./utils-1EQcVBdK.js";
import "./decode-DrS85i4S.js";
import "./formFill-Dg9Myfyq.js";
import "./redactSearch-DQpyyh_t.js";
import "./nameDetect-DvHCRM0m.js";
import "./pdfThumbnails-4ijNer1F.js";
import "./chevron-left-CWH4XvTX.js";
import "./chevron-right-7IYXE5RL.js";
const ie = {
    what: "Stamps a running document number on every page of one or more PDFs, such as ABC000001, ABC000002 and so on, the way a legal production is numbered. Choose a prefix, a starting number and where the stamp goes, and add a second line such as CONFIDENTIAL if you need one. You also get an index (CSV) listing the first and last number of every document.",
    tip: 'Number every file in one run with "Keep counting across files" on, so no two pages in the production share a number. Put the files in the order they will be produced before you start, because the numbers follow the list. Look at the preview before you download, and check a few pages of each file to be sure the stamp does not cover anything important.',
  },
  le = {
    "bottom-right": "Bottom right",
    "bottom-center": "Bottom center",
    "bottom-left": "Bottom left",
    "top-right": "Top right",
    "top-center": "Top center",
    "top-left": "Top left",
  },
  R = (a) => `${a.name}-${a.size}-${a.lastModified}`;
function Ze({ blob: a, positions: g }) {
  const [x, L] = c.useState([]),
    v = g.join("|");
  return (
    c.useEffect(() => {
      let y = !1;
      return (
        L([]),
        (async () => {
          let d = null;
          try {
            d = await Oe(
              new File([a], "numbered.pdf", { type: "application/pdf" }),
            );
            const B = await d.getPage(1),
              w = B.getViewport({ scale: 1 }),
              I = B.getViewport({ scale: 1100 / w.width }),
              o = document.createElement("canvas");
            ((o.width = Math.floor(I.width)),
              (o.height = Math.floor(I.height)));
            const z = o.getContext("2d");
            if (!z) return;
            await B.render({
              canvasContext: z,
              viewport: I,
              canvas: o,
              intent: "print",
            }).promise;
            const C = [];
            for (const T of g) {
              const b = Math.floor(o.width * 0.5),
                S = Math.floor(o.height * 0.1),
                $ = T.endsWith("right")
                  ? o.width - b
                  : T.endsWith("center")
                    ? Math.floor((o.width - b) / 2)
                    : 0,
                U = T.startsWith("top") ? 0 : o.height - S,
                u = document.createElement("canvas");
              ((u.width = b),
                (u.height = S),
                u.getContext("2d")?.drawImage(o, $, U, b, S, 0, 0, b, S),
                C.push(u.toDataURL("image/png")));
            }
            y || L(C);
          } catch {
          } finally {
            d?.loadingTask.destroy();
          }
        })(),
        () => {
          y = !0;
        }
      );
    }, [a, v]),
    x.length
      ? e.jsxs("div", {
          className: "space-y-2",
          "data-testid": "bates-zoom",
          children: [
            e.jsx("p", {
              className: "text-xs text-muted-foreground",
              children: "Close-up of the stamp on page 1",
            }),
            x.map((y, d) =>
              e.jsx(
                "img",
                {
                  src: y,
                  alt: `Close-up of the stamp on page 1, ${le[g[d]].toLowerCase()}`,
                  className: "w-full max-w-md rounded border",
                },
                d,
              ),
            ),
          ],
        })
      : null
  );
}
function os() {
  const [a, g] = c.useState([]),
    [x, L] = c.useState(new Map()),
    [v, y] = p("bates-prefix", ""),
    [d, B] = p("bates-suffix", ""),
    [w, I] = p("bates-start", "1"),
    [o, z] = p("bates-digits", "6"),
    [C, T] = p("bates-position", re.position),
    [b, S] = p("bates-size", "10"),
    [$, U] = p("bates-continuous", !0),
    [u, ce] = p("bates-legend", ""),
    [V, de] = p("bates-legend-pos", re.legendPosition),
    [G, me] = p("bates-box", !0),
    [H, pe] = p("bates-autoraise", !0),
    [W, _] = c.useState(!1),
    [ue, Z] = c.useState(0),
    [h, A] = c.useState(null),
    M = c.useRef(!1),
    { logUsageNow: he } = Se(),
    P = {
      prefix: v,
      suffix: d,
      start: Number(w),
      digits: Number(o),
      fontSize: Number(b),
      position: C,
      continuous: $,
      legend: u,
      legendPosition: V,
      whiteBox: G,
    },
    N = Re({
      ...P,
      start: w.trim() === "" ? NaN : P.start,
      digits: o.trim() === "" ? NaN : P.digits,
    }),
    m = () => A(null),
    Q = c.useCallback((t) => {
      Ae(t).then((s) => {
        const r =
          s.status === "ok"
            ? { status: "ok", pageCount: s.pageCount }
            : { status: s.status };
        L((i) => new Map(i).set(R(t), r));
      });
    }, []),
    fe = c.useCallback(
      (t) => {
        const s = t.filter(
          (r) => r.type === "application/pdf" || /\.pdf$/i.test(r.name),
        );
        (s.length !== t.length && O.error("Only PDF files are accepted"),
          g((r) => {
            const i = _e(r, s);
            return (
              i.length &&
                O.warning(
                  `${i.map((E) => `"${E.name}"`).join(", ")} already in the list. Added anyway, remove it below if that was not intended.`,
                ),
              [...r, ...s]
            );
          }),
          A(null),
          s.forEach(Q));
      },
      [Q],
    ),
    ge = (t) => {
      (g((s) => s.filter((r, i) => i !== t)), A(null));
    },
    l = a.filter((t) => x.get(R(t))?.status === "ok"),
    K = a.filter((t) => !x.has(R(t))).length,
    X = a.length - l.length - K,
    ee = () =>
      l.map((t) => ({ name: t.name, pageCount: x.get(R(t)).pageCount })),
    F = c.useMemo(() => (N ? null : ne(ee(), P)), [a, x, v, d, w, o, $, N]),
    D = F ? ze(Number(o), F.neededDigits, H) : Number(o),
    J = !!F && D > Number(o),
    te = { ...P, digits: D },
    n = c.useMemo(
      () => (F ? (J ? ne(ee(), { ...P, digits: D }) : F) : null),
      [F, J, D],
    ),
    xe = N ? "" : Me(v, Number(w), D, d),
    be = async () => {
      if (!(N || !n || l.length === 0)) {
        if (K > 0) {
          O.error("Wait until every file has been checked");
          return;
        }
        if (await he()) {
          ((M.current = !1), _(!0), Z(0));
          try {
            const t = [];
            for (let f = 0; f < l.length; f++) {
              if ((t.push(await Ue(l[f], n.entries[f].first, te)), M.current))
                return;
              Z(((f + 1) / l.length) * 100);
            }
            const s = Ve(n),
              r = n.entries[0],
              i = n.entries[n.entries.length - 1];
            let E, Y;
            if (l.length === 1) ((E = t[0]), (Y = r.outputName));
            else {
              const f = new ye();
              (t.forEach((Ne, ve) => f.file(n.entries[ve].outputName, Ne)),
                f.file("bates-index.csv", s),
                (E = await f.generateAsync({
                  type: "blob",
                  compression: "STORE",
                })),
                (Y = "bates-numbered.zip"));
            }
            (A({
              blob: E,
              fileName: Y,
              preview: t[0],
              indexCsv: s,
              summary: `${n.totalPages} ${n.totalPages === 1 ? "page" : "pages"} numbered, ${r.firstLabel} to ${te.continuous ? i.lastLabel : "the end of each file"}`,
            }),
              ke("bates-numbering", "pdf-tools"),
              O.success("Numbers added"));
          } catch (t) {
            if (M.current) return;
            (console.error("Bates numbering failed:", t),
              O.error(
                "Could not number one of the files. It may be damaged or protected.",
              ));
          } finally {
            _(!1);
          }
        }
      }
    },
    je = () => {
      ((M.current = !0), _(!1), Z(0));
    },
    we = (t) => {
      const s = x.get(R(t));
      if (!s)
        return e.jsx("span", {
          className: "text-xs text-muted-foreground",
          children: "Checking…",
        });
      if (s.status === "ok") {
        const r = n?.entries[l.indexOf(t)];
        return e.jsxs("span", {
          className: "text-xs text-muted-foreground whitespace-nowrap",
          children: [
            s.pageCount,
            " ",
            s.pageCount === 1 ? "page" : "pages",
            r ? `, ${r.firstLabel} to ${r.lastLabel}` : "",
          ],
        });
      }
      return e.jsx("span", {
        className: "text-xs text-destructive",
        children:
          s.status === "encrypted"
            ? "Locked. Unlock it first, then add it again."
            : "Damaged. Left out.",
      });
    },
    se = (t, s, r) =>
      e.jsxs(Le, {
        value: t,
        onValueChange: (i) => {
          (s(i), m());
        },
        children: [
          e.jsx(Be, { id: r, className: "w-40", children: e.jsx(Ie, {}) }),
          e.jsx(Te, {
            children: We.map((i) =>
              e.jsx($e, { value: i, children: le[i] }, i),
            ),
          }),
        ],
      });
  return e.jsxs(Ce, {
    toolId: "bates-numbering",
    categoryId: "pdf-tools",
    whatItDoes: ie.what,
    proTip: ie.tip,
    children: [
      e.jsx(Pe, {
        accept: ".pdf",
        multiple: !0,
        onFiles: fe,
        label: "Drop PDF files here or click to browse",
        description: "Add the documents in the order they will be produced",
        deferUsageLog: !0,
      }),
      a.length > 0 &&
        e.jsxs("div", {
          className: "mt-6 space-y-5",
          children: [
            e.jsxs("div", {
              children: [
                e.jsxs("p", {
                  className: "text-sm font-medium text-muted-foreground mb-3",
                  children: [
                    a.length,
                    " ",
                    a.length === 1 ? "file" : "files",
                    n
                      ? `, ${n.totalPages} ${n.totalPages === 1 ? "page" : "pages"}`
                      : "",
                    X > 0 ? `, ${X} left out` : "",
                  ],
                }),
                e.jsx(De, {
                  files: a,
                  onReorder: (t) => {
                    (g(t), m());
                  },
                  onRemove: ge,
                  renderItemExtra: (t) => we(a[t]),
                }),
              ],
            }),
            e.jsxs("div", {
              className: "space-y-4",
              children: [
                e.jsxs("div", {
                  className: "flex gap-4 flex-wrap",
                  children: [
                    e.jsxs("div", {
                      children: [
                        e.jsx(j, {
                          htmlFor: "bates-prefix",
                          children: "Prefix",
                        }),
                        e.jsx(k, {
                          id: "bates-prefix",
                          className: "w-32",
                          maxLength: 30,
                          value: v,
                          placeholder: "ABC",
                          onChange: (t) => {
                            (y(t.target.value), m());
                          },
                        }),
                      ],
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsx(j, {
                          htmlFor: "bates-start",
                          children: "Start at",
                        }),
                        e.jsx(k, {
                          id: "bates-start",
                          type: "number",
                          min: 0,
                          className: "w-28",
                          value: w,
                          onChange: (t) => {
                            (I(t.target.value), m());
                          },
                        }),
                      ],
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsx(j, {
                          htmlFor: "bates-digits",
                          children: "Digits",
                        }),
                        e.jsx(k, {
                          id: "bates-digits",
                          type: "number",
                          min: 1,
                          max: 10,
                          className: "w-20",
                          value: o,
                          onChange: (t) => {
                            (z(t.target.value), m());
                          },
                        }),
                      ],
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsx(j, {
                          htmlFor: "bates-suffix",
                          children: "Suffix",
                        }),
                        e.jsx(k, {
                          id: "bates-suffix",
                          className: "w-28",
                          maxLength: 30,
                          value: d,
                          placeholder: "optional",
                          onChange: (t) => {
                            (B(t.target.value), m());
                          },
                        }),
                      ],
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsx(j, {
                          htmlFor: "bates-position",
                          children: "Position",
                        }),
                        se(C, T, "bates-position"),
                      ],
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsx(j, {
                          htmlFor: "bates-size",
                          children: "Size (pt)",
                        }),
                        e.jsx(k, {
                          id: "bates-size",
                          type: "number",
                          min: 6,
                          max: 24,
                          className: "w-20",
                          value: b,
                          onChange: (t) => {
                            (S(t.target.value), m());
                          },
                        }),
                      ],
                    }),
                  ],
                }),
                e.jsxs("div", {
                  className: "flex gap-4 flex-wrap items-end",
                  children: [
                    e.jsxs("div", {
                      children: [
                        e.jsx(j, {
                          htmlFor: "bates-legend",
                          children: "Second line (optional)",
                        }),
                        e.jsx(k, {
                          id: "bates-legend",
                          className: "w-64",
                          maxLength: 60,
                          value: u,
                          placeholder: "CONFIDENTIAL",
                          onChange: (t) => {
                            (ce(t.target.value), m());
                          },
                        }),
                      ],
                    }),
                    u.trim() &&
                      e.jsxs("div", {
                        children: [
                          e.jsx(j, {
                            htmlFor: "bates-legend-pos",
                            children: "Second line position",
                          }),
                          se(V, de, "bates-legend-pos"),
                        ],
                      }),
                  ],
                }),
                e.jsxs("label", {
                  className: "flex items-center gap-2 text-sm cursor-pointer",
                  children: [
                    e.jsx(q, {
                      checked: $,
                      onCheckedChange: (t) => {
                        (U(t === !0), m());
                      },
                    }),
                    "Keep counting across files (otherwise each file starts again at the first number)",
                  ],
                }),
                e.jsxs("label", {
                  className: "flex items-center gap-2 text-sm cursor-pointer",
                  children: [
                    e.jsx(q, {
                      checked: G,
                      onCheckedChange: (t) => {
                        (me(t === !0), m());
                      },
                    }),
                    "Put a white box behind the stamp so it stays readable",
                  ],
                }),
                e.jsxs("label", {
                  className: "flex items-center gap-2 text-sm cursor-pointer",
                  children: [
                    e.jsx(q, {
                      checked: H,
                      onCheckedChange: (t) => {
                        (pe(t === !0), m());
                      },
                    }),
                    "Add digits automatically when the numbers run out of room",
                  ],
                }),
                N
                  ? e.jsx("p", {
                      role: "alert",
                      className: "text-sm text-destructive",
                      children: N,
                    })
                  : e.jsxs("p", {
                      className: "text-xs text-muted-foreground",
                      children: [
                        "First number: ",
                        e.jsx("span", { className: "font-mono", children: xe }),
                        J
                          ? `. Digits raised from ${o} to ${D} so every number has the same width.`
                          : "",
                        n?.widthExceeded
                          ? ". Some numbers are longer than the digits you chose, so they will be wider than the first ones. Raise Digits or turn on the option above to keep them the same width."
                          : "",
                      ],
                    }),
              ],
            }),
            n &&
              n.entries.length > 0 &&
              !h &&
              !W &&
              e.jsxs("div", {
                className: "rounded-lg border bg-card p-4 overflow-x-auto",
                "data-testid": "bates-plan",
                children: [
                  e.jsx("p", {
                    className: "text-sm font-medium mb-2",
                    children: "Index preview",
                  }),
                  e.jsxs("table", {
                    className: "text-sm w-full",
                    children: [
                      e.jsx("thead", {
                        children: e.jsxs("tr", {
                          className: "text-left text-muted-foreground",
                          children: [
                            e.jsx("th", {
                              className: "pr-4 font-normal",
                              children: "Document",
                            }),
                            e.jsx("th", {
                              className: "pr-4 font-normal",
                              children: "Pages",
                            }),
                            e.jsx("th", {
                              className: "pr-4 font-normal",
                              children: "Begin",
                            }),
                            e.jsx("th", {
                              className: "font-normal",
                              children: "End",
                            }),
                          ],
                        }),
                      }),
                      e.jsx("tbody", {
                        children: n.entries.map((t) =>
                          e.jsxs(
                            "tr",
                            {
                              children: [
                                e.jsx("td", {
                                  className: "pr-4 py-0.5 break-all",
                                  children: t.name,
                                }),
                                e.jsx("td", {
                                  className: "pr-4",
                                  children: t.pageCount,
                                }),
                                e.jsx("td", {
                                  className: "pr-4 font-mono",
                                  children: t.firstLabel,
                                }),
                                e.jsx("td", {
                                  className: "font-mono",
                                  children: t.lastLabel,
                                }),
                              ],
                            },
                            t.outputName,
                          ),
                        ),
                      }),
                    ],
                  }),
                ],
              }),
            h &&
              !W &&
              e.jsxs("div", {
                className: "space-y-3",
                children: [
                  e.jsx("p", {
                    className: "text-sm text-muted-foreground",
                    role: "status",
                    children: h.summary,
                  }),
                  e.jsx(Ee, { blob: h.preview }),
                  e.jsx(Ze, {
                    blob: h.preview,
                    positions: Array.from(
                      new Set([C, ...(u.trim() ? [V] : [])]),
                    ),
                  }),
                ],
              }),
            e.jsxs("div", {
              className: "flex items-center gap-3 flex-wrap",
              children: [
                W
                  ? e.jsx(Fe, {
                      message: "Adding numbers…",
                      progress: ue,
                      onStop: je,
                    })
                  : h
                    ? e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(oe, {
                            blob: h.blob,
                            fileName: h.fileName,
                            label:
                              a.length > 1
                                ? "Download numbered files (ZIP)"
                                : "Download numbered PDF",
                          }),
                          l.length === 1 &&
                            e.jsx(oe, {
                              blob: new Blob([h.indexCsv], {
                                type: "text/csv",
                              }),
                              fileName: "bates-index.csv",
                              label: "Download index (CSV)",
                            }),
                        ],
                      })
                    : e.jsx(ae, {
                        onClick: be,
                        disabled: !!N || l.length === 0 || K > 0,
                        className: "btn-glow",
                        children:
                          l.length === 0
                            ? "Add at least one PDF"
                            : `Add numbers to ${l.length} ${l.length === 1 ? "file" : "files"}`,
                      }),
                e.jsx(ae, {
                  variant: "outline",
                  onClick: () => {
                    (g([]), L(new Map()), A(null));
                  },
                  children: "Clear all",
                }),
              ],
            }),
          ],
        }),
    ],
  });
}
export { os as default };
//# sourceMappingURL=BatesNumbering-BkxVMHGO.js.map
