const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/drawTextAnywhere-DcuP6lHH.js",
      "assets/pdfFonts-Ckcqm3Ic.js",
      "assets/index-BRvxULIc.js",
      "assets/index-CnXdQaNG.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/index-DMQTJy3b.js",
      "assets/fontkit.es-DA-3qwB1.js",
    ]),
) => i.map((i) => d[i]);
import { ap as _ } from "./index-B1CTyGtY.js";
import { k as v, u as A } from "./index-BRvxULIc.js";
import { p as E } from "./pageView-BQIwVYOi.js";
import { a as D } from "./pdfMetadata-CcxIhQF2.js";
import { p as L } from "./utils-s8ucLyj8.js";
const j = [
    "bottom-right",
    "bottom-center",
    "bottom-left",
    "top-right",
    "top-center",
    "top-left",
  ],
  H = {
    prefix: "",
    suffix: "",
    start: 1,
    digits: 6,
    position: "bottom-right",
    fontSize: 10,
    continuous: !0,
    legend: "",
    legendPosition: "bottom-left",
    whiteBox: !0,
  },
  w = 30,
  T = 60;
function y(t, e, n, i = "") {
  const r = String(Math.max(0, Math.trunc(e))).padStart(
    Math.max(1, Math.trunc(n)),
    "0",
  );
  return `${t}${r}${i}`;
}
function U(t) {
  return !Number.isInteger(t.start) || t.start < 0
    ? "The starting number has to be a whole number, 0 or higher."
    : !Number.isInteger(t.digits) || t.digits < 1 || t.digits > 10
      ? "Digits has to be a whole number from 1 to 10."
      : !Number.isFinite(t.fontSize) || t.fontSize < 6 || t.fontSize > 24
        ? "Type size has to be between 6 and 24."
        : t.prefix.length > w || t.suffix.length > w
          ? `The prefix and suffix can be up to ${w} characters each.`
          : t.legend.length > T
            ? `The legend can be up to ${T} characters.`
            : /[\r\n]/.test(t.prefix + t.suffix + t.legend)
              ? "Prefix, suffix and legend have to stay on one line."
              : t.legend.trim() && t.legendPosition === t.position
                ? "Put the legend in a different place from the number."
                : null;
}
function z(t) {
  const e = new Set();
  return t.map((n) => {
    const i = D(n) || "document";
    let r = `${i}-bates.pdf`;
    for (let s = 2; e.has(r.toLowerCase()); s++) r = `${i}-bates-${s}.pdf`;
    return (e.add(r.toLowerCase()), r);
  });
}
function V(t, e) {
  const n = z(t.map((o) => o.name));
  let i = e.start,
    r = !1,
    s = 1,
    u = 0;
  return {
    entries: t.map((o, f) => {
      const c = e.continuous ? i : e.start,
        a = c + o.pageCount - 1;
      return (
        e.continuous && (i = a + 1),
        (u += o.pageCount),
        String(a).length > e.digits && (r = !0),
        (s = Math.max(s, String(Math.max(0, Math.trunc(a))).length)),
        {
          name: o.name,
          outputName: n[f],
          pageCount: o.pageCount,
          first: c,
          last: a,
          firstLabel: y(e.prefix, c, e.digits, e.suffix),
          lastLabel: y(e.prefix, a, e.digits, e.suffix),
        }
      );
    }),
    totalPages: u,
    widthExceeded: r,
    neededDigits: s,
  };
}
function $(t) {
  let e = String(t);
  return (
    /^[=+\-@\t\r]/.test(e) && (e = `'${e}`),
    /[",\n\r]/.test(e) ? `"${e.replace(/"/g, '""')}"` : e
  );
}
function W(t) {
  const e = [
    ["Document", "Numbered file", "Pages", "Begin Bates", "End Bates"],
  ];
  for (const n of t.entries)
    e.push([
      n.name,
      n.outputName,
      String(n.pageCount),
      n.firstLabel,
      n.lastLabel,
    ]);
  return (
    e.map((n) => n.map($).join(",")).join(`\r
`) +
    `\r
`
  );
}
function k(t, e, n) {
  return n ? Math.min(10, Math.max(t, e)) : t;
}
const p = 36,
  C = A(1, 1, 1);
function I(t, e, n, i, r) {
  const s = t.endsWith("center")
      ? e / 2 - i / 2
      : t.endsWith("right")
        ? e - p - i
        : p,
    u = t.startsWith("top") ? n - p - r * 0.8 : p;
  return { x: s, y: u };
}
async function q(t, e, n) {
  const i = new Uint8Array(await t.arrayBuffer()),
    r = await v.load(i),
    { drawTextAnywhere: s, measureTextAnywhere: u } = await _(
      async () => {
        const { drawTextAnywhere: a, measureTextAnywhere: h } =
          await import("./drawTextAnywhere-DcuP6lHH.js");
        return { drawTextAnywhere: a, measureTextAnywhere: h };
      },
      __vite__mapDeps([0, 1, 2, 3, 4, 5, 6]),
    ),
    m = r.getPages(),
    o = n.legend.trim(),
    f = 2,
    c = async (a, h, B, S) => {
      const g = E(a),
        M = await u(r, h, n.fontSize, S),
        { x, y: b } = I(B, g.width, g.height, M, n.fontSize);
      if (n.whiteBox) {
        const l = g.toStored(x - f, b - f),
          d = g.toStored(x + M + f, b + n.fontSize + f);
        a.drawRectangle({
          x: Math.min(l.x, d.x),
          y: Math.min(l.y, d.y),
          width: Math.abs(l.x - d.x),
          height: Math.abs(l.y - d.y),
          color: C,
        });
      }
      const { x: P, y: N } = g.toStored(x, b);
      await s(r, a, h, {
        x: P,
        y: N,
        size: n.fontSize,
        color: { r: 0, g: 0, b: 0 },
        bold: S,
        rotateDegrees: g.rotation,
      });
    };
  for (let a = 0; a < m.length; a++)
    (await c(m[a], y(n.prefix, e + a, n.digits, n.suffix), n.position, !0),
      o && (await c(m[a], o, n.legendPosition, !0)));
  return L(await r.save());
}
export {
  j as B,
  H as D,
  I as a,
  W as b,
  k as e,
  y as f,
  V as p,
  q as s,
  z as u,
  U as v,
};
//# sourceMappingURL=batesNumbering-Pmx-EMyr.js.map
