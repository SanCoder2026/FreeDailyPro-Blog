// FDP-55: click "Open from Google Drive" as guest, record popup host (redacted), close only the popup we opened.
const { chromium } = require('playwright'); const OUT='/workspace/deep/55-bates-numbering/live/';
(async()=>{ const b=await chromium.launch(); const c=await b.newContext({viewport:{width:1366,height:900}}); const p=await c.newPage();
 await p.goto('https://www.freedailypro.com/tool/bates-numbering',{waitUntil:'domcontentloaded'}); await p.waitForTimeout(4500);
 const pp=c.waitForEvent('page',{timeout:12000}).catch(()=>null); await p.getByRole('button',{name:/Open from Google Drive/}).click(); const pop=await pp; const r={};
 if(pop){ await pop.waitForLoadState('domcontentloaded').catch(()=>{}); await pop.waitForTimeout(2500); const u=new URL(pop.url()); r.popup=u.origin+u.pathname; r.title=await pop.title(); await pop.screenshot({path:OUT+'cases/drive-popup.png'}); await pop.close(); }
 else { await p.waitForTimeout(2000); r.inPage=await p.evaluate(()=>[...document.querySelectorAll('[role=dialog]')].map(d=>d.innerText.slice(0,300))); await p.screenshot({path:OUT+'cases/drive-click.png'}); }
 require('fs').writeFileSync(OUT+'drive.json',JSON.stringify(r,null,1)); console.log(JSON.stringify(r)); await b.close(); })();
