// FDP-55 Bates Numbering, guest. Usage: node px55-live.js <probe|left|cases> [engine]  (TRIES env = fresh contexts to try for one with uses left; CASES=B01,B02 subset)
// probe: as-is context -> file statuses (locked/damaged/fake/duplicate), index preview, validation messages, run (cap dialog?), Quick Buy (stop at email / Stripe).
// left: context with uses left -> run 1, download; change prefix -> run 2 in same load; reload -> run 3. Tracks fdp-usage-v1 + usage POSTs.
// cases: context with uses left -> numbering battery with downloads (PDF / ZIP / CSV).
// Never signs in, never types email/card, never clicks pass "Continue" or ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/55-bates-numbering/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/bates-numbering';
const mode = process.argv[2] || 'probe'; const eng = process.argv[3] || 'chromium'; const sfx = (eng === 'chromium' ? '' : '-' + eng) + (process.env.SUF || '');
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').replace(/dev[:%][^&"]*/g, 'dev:REDACTED').slice(0, 160);
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p, net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true, locale: 'en-US' }); p = await c.newPage(); p.setDefaultTimeout(10000); net = [];
  await p.addInitScript(() => { window.__t = []; const seen = new WeakSet(); setInterval(() => { document.querySelectorAll('[data-sonner-toast]').forEach(n => { if (!seen.has(n)) { seen.add(n); window.__t.push((n.innerText || '').trim()); } }); }, 120); });
  p.on('request', r => { const u = r.url(); if (r.method() === 'POST' && !/google|doubleclick|insight\.hit|funnel\.hit|analytics/.test(u)) net.push({ t: now(), u: red(u), len: (r.postData() || '').length }); });
  await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 450) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(250); } };
 const toasts = n => p.evaluate(n => (window.__t || []).slice(n), n); const tc = () => p.evaluate(() => (window.__t || []).length);
 const state = () => p.evaluate(() => { const m = document.querySelector('main'); const t = m.innerText; const tb = [...m.querySelectorAll('table')].map(x => x.innerText.replace(/\t/g, ' | ').split('\n').filter(Boolean)); return { alerts: [...m.querySelectorAll('[role=alert]')].map(a => a.innerText.trim()).filter(Boolean), status: [...m.querySelectorAll('[role=status]')].map(a => a.innerText.trim()).filter(Boolean), list: (t.match(/[^\n]*(pages?, [^\n]*to [^\n]*|Locked\.[^\n]*|Damaged\.[^\n]*|Checking…)/g) || []).slice(0, 12), index: tb, run: [...m.querySelectorAll('button')].map(x => x.innerText.trim()).filter(x => /^(Add numbers|Add at least|Download)/.test(x)), runDisabled: [...m.querySelectorAll('button')].filter(x => /^(Add numbers|Add at least)/.test(x.innerText.trim())).map(x => x.disabled), strip: m.querySelectorAll('canvas,img[alt*="age"]').length }; });
 const add = async (files, unlock) => { const n = await tc(); await p.locator('main input[type=file]').first().setInputFiles(files.map(f => TF + f)); await p.waitForTimeout(2500); const dl = []; for (let i = 0; i < 4; i++) { const d = await dialog(); if (!d) break; dl.push(d); await p.screenshot({ path: OUT + 'cases/add-dialog-' + Date.now() + sfx + '.png' }); const pwIn = p.locator('[role=dialog] input[type=password]'); if (unlock && await pwIn.count()) { await pwIn.fill(unlock); await p.keyboard.press('Enter'); } else { const cancel = p.locator('[role=dialog] button', { hasText: /^(Cancel|Skip|Close)$/ }); if (await cancel.count()) await cancel.first().click(); else await esc(); } await p.waitForTimeout(2000); } const s = await state(); s.toasts = await toasts(n); s.dialogs = dl; return s; };
 const clear = async () => { const bt = p.locator('main button', { hasText: /^Clear all$/ }); if (await bt.count()) { await bt.click(); await p.waitForTimeout(500); } };
 const setv = async (id, v) => { await p.locator('#' + id).fill(String(v)); await p.waitForTimeout(200); };
 const pick = async (id, opt) => { await p.locator('#' + id).click(); await p.waitForTimeout(300); await p.getByRole('option', { name: opt, exact: true }).click(); await p.waitForTimeout(300); };
 const chk = async (text, on) => { const l = p.locator('main label', { hasText: text }).locator('button[role=checkbox]'); const st = await l.getAttribute('data-state'); if ((st === 'checked') !== on) await l.click(); await p.waitForTimeout(200); };
 const run = async (id) => { const n = await tc(); const before = await used(); const bt = p.locator('main button', { hasText: /^Add numbers to/ }); if (!(await bt.count()) || await bt.isDisabled()) return { notRunnable: await state() }; await bt.click(); await p.waitForTimeout(1500); let d = await dialog();
  if (!d) await p.waitForFunction(() => /Download numbered/.test(document.querySelector('main').innerText) || document.querySelector('[role=dialog]'), null, { timeout: 120000 }).catch(() => { }); await p.waitForTimeout(1500); d = d || await dialog();
  const r = { before, after: await used(), toasts: await toasts(n), dialog: d, ...(await state()) }; await p.screenshot({ path: OUT + 'cases/' + id + sfx + '.png', fullPage: true }); if (d) { await p.screenshot({ path: OUT + 'cases/' + id + sfx + '-dialog.png' }); await esc(); } return r; };
 const dlAll = async (id) => { const out = []; const bts = p.locator('main button, main a', { hasText: /^Download (numbered|index)/ }); const k = await bts.count(); for (let i = 0; i < k; i++) { const n = await tc(); const before = await used(); const dp = p.waitForEvent('download', { timeout: 15000 }).catch(() => null); const label = await bts.nth(i).innerText(); await bts.nth(i).click(); const d = await dp; await p.waitForTimeout(1500);
   const r = { label, before, after: await used(), toasts: await toasts(n), dialog: await dialog() }; if (d) { const f = OUT + 'downloads/' + id + sfx + '-' + d.suggestedFilename(); await d.saveAs(f); r.file = { name: d.suggestedFilename(), bytes: fs.statSync(f).size }; } if (r.dialog) await esc(); out.push(r); } return out; };
 const C = async (id, fn) => { try { R.cases[id] = await fn(); } catch (e) { R.cases[id] = { err: e.message.split('\n')[0].slice(0, 200) }; } console.log(id, JSON.stringify(R.cases[id]).slice(0, 500)); };
 const findLeft = async () => { const TRIES = +(process.env.TRIES || 10); for (let i = 0; i < TRIES; i++) { await open(); const u = await used(); R.tries.push(u); const [a, l] = u.split('/').map(Number); if (a < l) return true; await c.close(); } return false; };
 if (mode === 'probe') { await open(); R.start = { used: await used(), accept: await p.locator('main input[type=file]').first().getAttribute('accept'), multiple: await p.locator('main input[type=file]').first().getAttribute('multiple') };
  await C('P01-mixed', () => add(['contract_letter_5p.pdf', 'password_u123.pdf', 'damaged.pdf', 'emails_a4_3p.pdf']));
  await C('P02-fake-and-txt', async () => { const s = await add(['fake.pdf']); return s; });
  await C('P03-duplicate', async () => add(['contract_letter_5p.pdf']));
  await clear(); await add(['contract_letter_5p.pdf', 'emails_a4_3p.pdf']);
  await C('P04-validation', async () => { const out = {}; for (const [id, v, k] of [['bates-start', '-1', 'start-neg'], ['bates-start', '1.5', 'start-dec'], ['bates-digits', '11', 'digits11'], ['bates-digits', '0', 'digits0'], ['bates-size', '30', 'size30'], ['bates-prefix', 'X'.repeat(31), 'prefix31']]) { const old = await p.locator('#' + id).inputValue(); await setv(id, v); out[k] = await state(); await setv(id, old); } await setv('bates-legend', 'CONFIDENTIAL'); await pick('bates-legend-pos', await p.locator('#bates-position').innerText()).catch(e => out.legendSame = 'pick-failed ' + e.message.slice(0, 60)); out.legendSame = out.legendSame || await state(); await setv('bates-legend', ''); return out; });
  await C('P05-overflow', async () => { await setv('bates-start', '999995'); await chk('Add digits automatically', false); const a = await state(); await chk('Add digits automatically', true); const b2 = await state(); await setv('bates-start', '1'); return { autoraiseOff: a, autoraiseOn: b2 }; });
  await C('P06-run-at-cap', () => run('P06'));
  await C('QB-day', async () => { await esc(); await p.locator('main button', { hasText: 'Quick Buy' }).first().click(); await p.waitForTimeout(2500); const d = await dialog(); await p.screenshot({ path: OUT + 'cases/quickbuy-day' + sfx + '.png' }); await esc(); return { dialog: d }; });
  await C('QB-month', async () => { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); await p.locator('main button', { hasText: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); return { url: red(p.url()), title: await p.title() }; });
  R.net = net;
 } else if (mode === 'left') { if (await findLeft()) { const L = R.left = { start: await used() };
   await add(['contract_letter_5p.pdf', 'emails_a4_3p.pdf']); await setv('bates-prefix', 'ABC'); await C('L01-run', () => run('L01')); await C('L01-dl', () => dlAll('L01'));
   await setv('bates-prefix', 'XYZ'); await C('L02-run-same-load', () => run('L02')); await C('L02-dl', () => dlAll('L02'));
   await clear(); await add(['one_page.pdf']); await C('L03-run-same-load', () => run('L03')); await C('L03-dl', () => dlAll('L03'));
   await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); L.afterReload = await used(); await add(['landscape_2p.pdf']); await C('L04-run-after-reload', () => run('L04')); await C('L04-dl', () => dlAll('L04'));
   L.end = await used(); L.net = net; } }
 else { if (await findLeft()) { R.start = await used(); const only = (process.env.CASES || '').split(',').filter(Boolean);
   const plan = [
    ['B01-two-files-continuous', ['contract_letter_5p.pdf', 'emails_a4_3p.pdf'], { prefix: 'ABC', legend: 'CONFIDENTIAL' }],
    ['B02-restart-each-file', ['contract_letter_5p.pdf', 'emails_a4_3p.pdf'], { prefix: 'DEF', cont: false }],
    ['B03-rotated', ['rotated_3p.pdf'], { prefix: 'ROT', pos: 'Top right' }],
    ['B04-offset-cropbox', ['offset_cropbox_2p.pdf'], { prefix: 'OFF' }],
    ['B05-dark-nobox', ['dark_2p.pdf'], { prefix: 'DRK', box: false }],
    ['B06-footer-collision', ['footer_2p.pdf'], { prefix: 'FTR' }],
    ['B07-overflow-autoraise', ['twelve_12p.pdf'], { prefix: 'OVF', start: 999995 }],
    ['B08-unicode-prefix-suffix', ['one_page.pdf'], { prefix: 'Ü案件-', suffix: '-é', size: 14 }],
    ['B09-dupnames-landscape', ['contract_letter_5p.pdf', 'dup/contract_letter_5p.pdf', 'landscape_2p.pdf'], { prefix: 'DUP' }],
    ['B10-one-good-one-locked', ['one_page.pdf', 'password_u123.pdf'], { prefix: 'LCK' }],
    ['B12-unlocked-inline', ['one_page.pdf', 'password_u123.pdf'], { prefix: 'UNL', unlock: 'u123' }],
    ['B11-csv-injection-name', ['one_page.pdf'], { prefix: '=SUM(1)' }]];
   for (const [id, files, o] of plan.filter(x => !only.length || only.includes(x[0].slice(0, 3)))) await C(id, async () => { await clear(); const s = await add(files, o.unlock); await setv('bates-prefix', o.prefix ?? ''); await setv('bates-suffix', o.suffix ?? ''); await setv('bates-start', o.start ?? 1); await setv('bates-digits', o.digits ?? 6); await setv('bates-size', o.size ?? 10); await setv('bates-legend', o.legend ?? '');
     if (o.pos) await pick('bates-position', o.pos); else await pick('bates-position', 'Bottom right').catch(() => { }); await chk('Keep counting across files', o.cont ?? true); await chk('Put a white box', o.box ?? true);
     const r = await run(id); r.added = { list: s.list, toasts: s.toasts }; if (r.run && r.run.some(x => /Download/.test(x))) r.dl = await dlAll(id); return r; });
   R.end = await used(); R.net = net; } }
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', JSON.stringify(R.tries), JSON.stringify(R.start || '').slice(0, 200)); await b.close(); })();
