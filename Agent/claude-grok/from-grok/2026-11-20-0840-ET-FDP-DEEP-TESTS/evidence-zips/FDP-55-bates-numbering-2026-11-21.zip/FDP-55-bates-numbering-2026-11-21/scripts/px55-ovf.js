// FDP-55: screenshot the digit-overflow hint with autoraise off and on (no run, no trial use).
const { chromium } = require('playwright'); const OUT='/workspace/deep/55-bates-numbering/live/cases/';
(async()=>{ const b=await chromium.launch(); const c=await b.newContext({viewport:{width:1366,height:900}}); const p=await c.newPage();
 await p.goto('https://www.freedailypro.com/tool/bates-numbering',{waitUntil:'domcontentloaded'}); await p.waitForTimeout(4500);
 await p.locator('main input[type=file]').first().setInputFiles(['/workspace/deep/55-bates-numbering/testfiles/twelve_12p.pdf']); await p.waitForTimeout(3000);
 await p.fill('#bates-start','999995'); await p.keyboard.press('Tab');
 const cb=p.getByLabel(/Add digits automatically/); const res={};
 for (const on of [false,true]) { if ((await cb.isChecked())!==on) await cb.click(); await p.waitForTimeout(800);
  res[on?'on':'off']=await p.evaluate(()=>[...document.querySelectorAll('main p')].map(x=>x.innerText).filter(t=>/First number/.test(t)));
  const el=p.locator('main p',{hasText:'First number'}).first(); await el.scrollIntoViewIfNeeded(); await p.screenshot({path:OUT+'overflow-autoraise-'+(on?'on':'off')+'.png'}); }
 console.log(JSON.stringify(res)); await b.close(); })();
