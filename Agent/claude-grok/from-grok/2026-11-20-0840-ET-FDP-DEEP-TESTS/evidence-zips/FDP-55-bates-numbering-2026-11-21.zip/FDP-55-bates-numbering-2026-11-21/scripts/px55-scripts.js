// List JS chunks and UI on bates-numbering (guest, no actions)
const { chromium } = require('playwright'); const fs=require('fs');
(async()=>{const b=await chromium.launch(); const c=await b.newContext({viewport:{width:1366,height:900}}); const p=await c.newPage(); const s=[];
p.on('response',r=>{const u=r.url(); if(/\/assets\/.*\.js$/.test(u)) s.push(u)});
await p.goto('https://www.freedailypro.com/tool/bates-numbering',{waitUntil:'domcontentloaded',timeout:45000}); await p.waitForTimeout(6000);
const t=await p.evaluate(()=>document.querySelector('main').innerText);
fs.writeFileSync('/workspace/deep/55-bates-numbering/tool-expanded.txt',t); fs.writeFileSync('/workspace/deep/55-bates-numbering/js/chunks.txt',s.join('\n'));
await p.screenshot({path:'/workspace/deep/55-bates-numbering/live/initial.png'}); console.log(s.length, JSON.stringify(await p.evaluate(()=>localStorage.getItem('fdp-usage-v1')))); await b.close();})();
