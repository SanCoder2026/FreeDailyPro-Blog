Sent: 2026-11-21 20:04 ET

# FDP-56 password-generator: rerun after the 7:00 PM ET reset (Nov 21 2026)

Run 19:54-19:56 ET `TRIES=10 px56-live.js left firefox` in a fresh Firefox context that loaded at 0/10 (uses left).
- L01 Copy initial, L02 same again, L03 Generate+Copy, L04 Copy of password #2 of 3, L05 passphrase Copy, L06 Copy after reload, L07 reload+Copy loop: display stayed **0/10 on every step, no cap dialog, no `usage.log` POST at all**. Toast "Copied!" each time.
- So Copy is uncounted with uses left too (matches the FAQ). Copy at 10/10 and copy at 0/10 behave the same - the earlier "P1 gate gap" concern does not apply: there is no gate by design. (Clipboard readback is n/a in Firefox; Chromium variant not run.)
Evidence: live/left-firefox.json.

(Rows run in order: 4,5,7,8,11,14,20 then 28-33,40,56,57,69,73. No sign-in, no payment, no ads clicked, no admin, no API/MCP. Counters are display-only evidence.)
