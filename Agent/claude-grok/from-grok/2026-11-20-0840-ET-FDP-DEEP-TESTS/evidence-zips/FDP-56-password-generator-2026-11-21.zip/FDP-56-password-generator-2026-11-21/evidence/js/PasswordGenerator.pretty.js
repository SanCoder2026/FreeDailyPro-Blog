import { r as l, j as e } from "./vendor-react-D01g8YgM.js";
import {
  f as A,
  B as S,
  aq as ne,
  aL as ie,
  aF as le,
  e as d,
  b9 as ce,
  b as de,
} from "./index-B1CTyGtY.js";
import { u as he } from "./useShareGate-BYBawloP.js";
import { T as pe } from "./ToolPage-DwLoDncN.js";
import { S as V } from "./slider-nIHsxb_2.js";
import { S as g } from "./switch-CQRPxs-N.js";
import { T as me } from "./ToolInfoSection-C0i6Zbwo.js";
import { C as ue } from "./copy-DcUvE8ta.js";
import "./useExportGate-BU4jIFHF.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
function v(s) {
  if (s <= 0) return 0;
  const t = Math.floor(4294967296 / s) * s,
    a = new Uint32Array(1);
  do crypto.getRandomValues(a);
  while (a[0] >= t);
  return a[0] % s;
}
const q = "!@#$%^&*()_+-=[]{}|;:,.<>?",
  ge = /[Il1O0o|]/g;
function x(s) {
  const t = (r) => (s.excludeSimilar ? r.replace(ge, "") : r),
    a = [];
  return (
    s.upper && a.push(t("ABCDEFGHIJKLMNOPQRSTUVWXYZ")),
    s.lower && a.push(t("abcdefghijklmnopqrstuvwxyz")),
    s.numbers && a.push(t("0123456789")),
    s.symbols && a.push(t(Array.from(new Set(s.symbolSet || q)).join(""))),
    a.filter(Boolean)
  );
}
function U(s) {
  return Array.from(new Set(x(s).join("")));
}
function we(s) {
  const t = x(s);
  if (!t.length) return "";
  const a = U(s),
    r = t.map((o) => new Set(o));
  if (s.length < t.length)
    return Array.from({ length: s.length }, () => a[v(a.length)]).join("");
  for (let o = 0; o < 1e6; o++) {
    const n = Array.from({ length: s.length }, () => a[v(a.length)]);
    if (r.every((h) => n.some((p) => h.has(p)))) return n.join("");
  }
  throw new Error("Could not generate a password with these settings.");
}
const R = BigInt(0),
  xe = BigInt(1),
  fe = (s, t) => {
    let a = xe;
    const r = BigInt(s);
    for (let o = 0; o < t; o++) a *= r;
    return a;
  };
function be(s) {
  if (s <= R) return 0;
  const t = s.toString(2);
  return t.length <= 53
    ? Math.log2(Number(s))
    : Math.log2(Number(BigInt("0b" + t.slice(0, 53)))) + (t.length - 53);
}
function Z(s) {
  const t = x(s),
    a = U(s).length;
  if (!t.length || a < 1 || s.length < t.length) return R;
  let r = R;
  for (let o = 0; o < 1 << t.length; o++) {
    const n = new Set();
    let h = 0;
    t.forEach(($, m) => {
      if (o & (1 << m)) {
        h++;
        for (const M of $) n.add(M);
      }
    });
    const p = fe(a - n.size, s.length);
    r += h % 2 === 0 ? p : -p;
  }
  return r;
}
function K(s, t) {
  return s > 1 ? t * Math.log2(s) : 0;
}
function ye(s) {
  return be(Z(s));
}
function je(s) {
  const t = U(s).length,
    a = K(t, s.length),
    r = ye(s),
    o = [
      `${s.length} characters, each one of ${t} possible characters: ${s.length} x log2(${t}) = ${a.toFixed(1)} bits.`,
    ];
  return (
    a - r >= 0.05 &&
      o.push(
        `Requiring every chosen type to appear rules out some passwords, so the exact figure is ${r.toFixed(1)} bits (log2 of the ${Z(s).toLocaleString("en-US")} passwords that qualify).`,
      ),
    { alphabetSize: t, naiveBits: a, bits: r, lines: o }
  );
}
function Se(s, t) {
  const a = K(7776, s),
    r = t ? Math.log2(100 * s) : 0,
    o = [
      `${s} words, each one of 7,776 on the EFF list: ${s} x log2(7,776) = ${a.toFixed(1)} bits.`,
    ];
  return (
    t &&
      o.push(
        `The two-digit number goes after a random word: ${s} places x 100 numbers, log2(${100 * s}) = ${r.toFixed(1)} bits.`,
      ),
    o.push(
      "Capital letters and the separator are fixed by your choice, so they add no bits.",
    ),
    { alphabetSize: 7776, naiveBits: a + r, bits: a + r, lines: o }
  );
}
const ve = 1e10,
  Ne =
    "Assumes an attacker trying 10 billion guesses a second against a fast-hashed copy of the password and getting there after trying half of all possibilities. A site that stores passwords with a slow hash (bcrypt, Argon2) is far slower to attack; a site that leaks them in plain text makes this number meaningless. It holds only for a password drawn at random like this one: a password you edit, reuse or recognise from a breach is not covered.";
function ke(s) {
  const t = Math.pow(2, s - 1) / ve;
  if (t < 1) return "less than a second";
  if (t >= 31557600 * 1e12)
    return "over a trillion years (the universe is about 13.8 billion years old)";
  const a = [
    [31557600 * 1e9, "billion years"],
    [31557600 * 1e6, "million years"],
    [31557600 * 1e3, "thousand years"],
    [31557600, "years"],
    [86400, "days"],
    [3600, "hours"],
    [60, "minutes"],
    [1, "seconds"],
  ];
  for (const [r, o] of a)
    if (t >= r) {
      const n = t / r;
      return `about ${n >= 100 ? Math.round(n).toLocaleString("en-US") : n.toFixed(n >= 10 ? 0 : 1)} ${o}`;
    }
  return "seconds";
}
function Ce(s) {
  return s >= 100
    ? { label: "Very Strong", color: "text-green-600" }
    : s >= 70
      ? { label: "Strong", color: "text-green-500" }
      : s >= 45
        ? { label: "Medium", color: "text-yellow-500" }
        : { label: "Weak", color: "text-red-500" };
}
function Fe(s, t, a, r, o) {
  const n = Array.from({ length: t }, () => s[v(s.length)]).map((h) =>
    r ? h[0].toUpperCase() + h.slice(1) : h,
  );
  return (o && (n[v(n.length)] += String(v(100)).padStart(2, "0")), n.join(a));
}
const O = {
  what: "Generates a random, secure password of a length and character set you choose, for use with a new account or to replace a weak existing password — a genuinely random password is one you couldn't have guessed yourself, which is exactly what makes it harder for anyone else to guess too.",
  how: "A password appears as soon as the page opens. Set the length and which character types to include (uppercase, lowercase, numbers, symbols), or switch to a passphrase of random words, then press Generate for a new one. The entropy line shows the arithmetic behind the strength. Seeing or copying a password never takes a trial use.",
  tip: "Longer passwords are generally more secure than shorter ones with more symbol complexity — a 16-character password of mixed letters and numbers is often stronger than a 10-character one packed with symbols, since password strength grows much faster with length than with character variety. Check it against Password Strength afterward if you want a real cracking-time estimate rather than just trusting length alone.",
};
function ns() {
  const { gateShare: s } = he(),
    [t, a] = l.useState([16]),
    [r, o] = l.useState(!0),
    [n, h] = l.useState(!0),
    [p, $] = l.useState(!0),
    [m, M] = l.useState(!0),
    [T, Y] = l.useState(!1),
    [N, J] = l.useState(q),
    [c, z] = l.useState("password"),
    [f, Q] = l.useState([5]),
    [I, X] = l.useState("-"),
    [L, ee] = l.useState(!1),
    [k, se] = l.useState(!0),
    [C, te] = l.useState(1),
    [F, E] = l.useState([]),
    [b, ae] = l.useState(!1),
    [_, G] = l.useState(-1),
    B = l.useRef(null),
    y = {
      length: t[0],
      upper: r,
      lower: n,
      numbers: p,
      symbols: m,
      excludeSimilar: T,
      symbolSet: N,
    },
    [W, D] = l.useState(null),
    w = W?.bits ?? 0,
    j = [r, n, p, m].filter(Boolean).length,
    re = c === "password" && m && !N.trim(),
    H = l.useCallback(async () => {
      if (!(c === "password" && !x(y).length)) {
        if (c === "password" && t[0] < x(y).length) {
          A.error(
            `Use a length of at least ${x(y).length} to include every selected type.`,
          );
          return;
        }
        if (c === "passphrase") {
          if (!B.current)
            try {
              B.current = (
                await (await fetch("/dict/eff-large-wordlist.txt")).text()
              )
                .trim()
                .split(/\s+/);
            } catch {
              A.error(
                "Couldn't load the word list. Check your connection and try again.",
              );
              return;
            }
          (D(Se(f[0], k)),
            E(Array.from({ length: C }, () => Fe(B.current, f[0], I, L, k))));
        } else (D(je(y)), E(Array.from({ length: C }, () => we(y))));
        G(-1);
      }
    }, [c, t, r, n, p, m, T, N, f, I, L, k, C]);
  l.useEffect(() => {
    H();
  }, []);
  const P = Ce(w),
    oe = (i) =>
      s(async () => {
        try {
          return (
            await navigator.clipboard.writeText(F[i]),
            G(i),
            A.success("Copied!"),
            !0
          );
        } catch {
          return (
            A.error("Couldn't copy. Select the text and copy it by hand."),
            !1
          );
        }
      });
  return e.jsxs(pe, {
    children: [
      e.jsxs("div", {
        className: "space-y-6",
        children: [
          e.jsxs("div", {
            className: "flex gap-2",
            role: "group",
            "aria-label": "Type",
            children: [
              e.jsx(S, {
                size: "sm",
                variant: c === "password" ? "default" : "outline",
                "aria-pressed": c === "password",
                onClick: () => {
                  (z("password"), E([]));
                },
                children: "Password",
              }),
              e.jsx(S, {
                size: "sm",
                variant: c === "passphrase" ? "default" : "outline",
                "aria-pressed": c === "passphrase",
                onClick: () => {
                  (z("passphrase"), E([]));
                },
                children: "Passphrase (words)",
              }),
            ],
          }),
          F.length > 0 &&
            e.jsxs("div", {
              className: "space-y-2",
              children: [
                F.map((i, u) =>
                  e.jsxs(
                    "div",
                    {
                      className:
                        "p-4 rounded-lg border bg-card flex items-center gap-3",
                      children: [
                        e.jsx("code", {
                          className: "flex-1 text-lg font-mono break-all",
                          "data-testid": "password-output",
                          children: b ? "•".repeat(Math.min(i.length, 40)) : i,
                        }),
                        e.jsxs(S, {
                          variant: "outline",
                          size: "sm",
                          className: "gap-1.5",
                          onClick: () => oe(u),
                          "aria-label":
                            `Copy password ${F.length > 1 ? u + 1 : ""}`.trim(),
                          children: [
                            _ === u
                              ? e.jsx(ne, { className: "h-4 w-4" })
                              : e.jsx(ue, { className: "h-4 w-4" }),
                            " ",
                            _ === u ? "Copied" : "Copy",
                          ],
                        }),
                      ],
                    },
                    u,
                  ),
                ),
                e.jsxs("div", {
                  className:
                    "flex flex-wrap items-center gap-x-4 gap-y-1 text-sm",
                  children: [
                    e.jsxs("span", {
                      className: `font-medium ${P.color}`,
                      "data-testid": "pw-strength",
                      children: ["Strength: ", P.label],
                    }),
                    e.jsxs("span", {
                      className: "text-muted-foreground",
                      "data-testid": "pw-bits",
                      children: [w.toFixed(1), " bits of entropy"],
                    }),
                    e.jsxs(S, {
                      variant: "ghost",
                      size: "sm",
                      className: "gap-1.5 ml-auto",
                      onClick: () => ae(!b),
                      "aria-pressed": b,
                      children: [
                        b
                          ? e.jsx(ie, { className: "h-4 w-4" })
                          : e.jsx(le, { className: "h-4 w-4" }),
                        b ? "Show" : "Hide",
                      ],
                    }),
                  ],
                }),
                e.jsx("div", {
                  role: "meter",
                  "aria-label": "Password entropy in bits, out of 128",
                  "aria-valuemin": 0,
                  "aria-valuemax": 128,
                  "aria-valuenow": Math.min(128, Math.round(w)),
                  "aria-valuetext": `${w.toFixed(1)} bits, ${P.label}`,
                  className: "h-2 rounded-full bg-muted overflow-hidden",
                  "data-testid": "pw-meter",
                  children: e.jsx("div", {
                    className: "h-full rounded-full bg-primary transition-all",
                    style: { width: `${Math.min(100, (w / 128) * 100)}%` },
                  }),
                }),
                e.jsxs("div", {
                  className: "text-xs text-muted-foreground space-y-1",
                  "data-testid": "pw-maths",
                  children: [
                    W?.lines.map((i) => e.jsx("p", { children: i }, i)),
                    e.jsxs("p", {
                      children: [
                        "At 10 billion guesses a second, an attacker would need on average ",
                        ke(w),
                        " to reach this one.",
                      ],
                    }),
                    e.jsxs("details", {
                      children: [
                        e.jsx("summary", {
                          className: "cursor-pointer",
                          children: "What the crack time assumes",
                        }),
                        e.jsxs("p", {
                          className: "mt-1",
                          children: [
                            Ne,
                            " Entropy measures how hard a password is to guess, not whether it is safe to reuse: use a different password for every account.",
                          ],
                        }),
                      ],
                    }),
                  ],
                }),
                e.jsx("p", {
                  className: "text-xs text-muted-foreground",
                  "data-testid": "pw-local",
                  children:
                    "Made in this browser with crypto.getRandomValues (your device's secure random source, with no bias towards any character). It is never sent anywhere and never stored: leave the page and it is gone.",
                }),
              ],
            }),
          c === "password"
            ? e.jsxs(e.Fragment, {
                children: [
                  e.jsxs("div", {
                    className: "space-y-2",
                    children: [
                      e.jsxs(d, {
                        id: "pw-length-label",
                        children: ["Length: ", t[0]],
                      }),
                      e.jsx(V, {
                        "aria-label": "Password length",
                        value: t,
                        onValueChange: a,
                        min: 4,
                        max: 64,
                        step: 1,
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className: "grid grid-cols-2 gap-4",
                    children: [
                      e.jsxs("div", {
                        className: "flex items-center gap-2",
                        children: [
                          e.jsx(g, {
                            id: "pw-upper",
                            checked: r,
                            onCheckedChange: o,
                            disabled: r && j === 1,
                            "aria-label": "Uppercase letters",
                          }),
                          e.jsx(d, {
                            htmlFor: "pw-upper",
                            children: "Uppercase (A-Z)",
                          }),
                        ],
                      }),
                      e.jsxs("div", {
                        className: "flex items-center gap-2",
                        children: [
                          e.jsx(g, {
                            id: "pw-lower",
                            checked: n,
                            onCheckedChange: h,
                            disabled: n && j === 1,
                            "aria-label": "Lowercase letters",
                          }),
                          e.jsx(d, {
                            htmlFor: "pw-lower",
                            children: "Lowercase (a-z)",
                          }),
                        ],
                      }),
                      e.jsxs("div", {
                        className: "flex items-center gap-2",
                        children: [
                          e.jsx(g, {
                            id: "pw-numbers",
                            checked: p,
                            onCheckedChange: $,
                            disabled: p && j === 1,
                            "aria-label": "Numbers",
                          }),
                          e.jsx(d, {
                            htmlFor: "pw-numbers",
                            children: "Numbers (0-9)",
                          }),
                        ],
                      }),
                      e.jsxs("div", {
                        className: "flex items-center gap-2",
                        children: [
                          e.jsx(g, {
                            id: "pw-symbols",
                            checked: m,
                            onCheckedChange: M,
                            disabled: m && j === 1,
                            "aria-label": "Symbols",
                          }),
                          e.jsx(d, {
                            htmlFor: "pw-symbols",
                            children: "Symbols",
                          }),
                        ],
                      }),
                      e.jsxs("div", {
                        className: "flex items-center gap-2 col-span-2",
                        children: [
                          e.jsx(g, {
                            id: "pw-similar",
                            checked: T,
                            onCheckedChange: Y,
                            "aria-label": "Exclude look-alike characters",
                          }),
                          e.jsx(d, {
                            htmlFor: "pw-similar",
                            children:
                              "Exclude look-alike characters (I l 1 O 0 o |)",
                          }),
                        ],
                      }),
                    ],
                  }),
                  e.jsxs("p", {
                    className: "text-xs text-muted-foreground",
                    children: [
                      "At least one character type must stay on",
                      j === 1 ? " (the last one is locked)" : "",
                      ".",
                    ],
                  }),
                  re &&
                    e.jsx("p", {
                      role: "alert",
                      className: "text-xs text-destructive",
                      children:
                        "The symbols box is empty, so the default symbols are used.",
                    }),
                  m &&
                    e.jsxs("div", {
                      className: "space-y-1",
                      children: [
                        e.jsx(d, {
                          className: "text-xs",
                          children:
                            "Symbols to use (remove any a website rejects)",
                        }),
                        e.jsx("input", {
                          className:
                            "border rounded px-2 py-1 w-full bg-background font-mono text-sm",
                          value: N,
                          onChange: (i) => J(i.target.value),
                          "aria-label": "Allowed symbols",
                        }),
                      ],
                    }),
                ],
              })
            : e.jsxs(e.Fragment, {
                children: [
                  e.jsxs("div", {
                    className: "space-y-2",
                    children: [
                      e.jsxs(d, { children: ["Words: ", f[0]] }),
                      e.jsx(V, {
                        "aria-label": "Number of words",
                        value: f,
                        onValueChange: Q,
                        min: 3,
                        max: 10,
                        step: 1,
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className: "flex flex-wrap items-center gap-4 text-sm",
                    children: [
                      e.jsxs("label", {
                        className: "flex items-center gap-1.5",
                        children: [
                          "Separator ",
                          e.jsx("select", {
                            "aria-label": "Separator",
                            className: "border rounded px-2 py-1 bg-background",
                            value: I,
                            onChange: (i) => X(i.target.value),
                            children: [
                              ["-", "hyphen -"],
                              [" ", "space"],
                              [".", "dot ."],
                              ["_", "underscore _"],
                              ["", "none"],
                            ].map(([i, u]) =>
                              e.jsx("option", { value: i, children: u }, u),
                            ),
                          }),
                        ],
                      }),
                      e.jsxs("div", {
                        className: "flex items-center gap-2",
                        children: [
                          e.jsx(g, {
                            id: "pw-cap",
                            checked: L,
                            onCheckedChange: ee,
                            "aria-label": "Capitalise words",
                          }),
                          e.jsx(d, {
                            htmlFor: "pw-cap",
                            children: "Capitalise words",
                          }),
                        ],
                      }),
                      e.jsxs("div", {
                        className: "flex items-center gap-2",
                        children: [
                          e.jsx(g, {
                            id: "pw-num",
                            checked: k,
                            onCheckedChange: se,
                            "aria-label": "Add a number",
                          }),
                          e.jsx(d, {
                            htmlFor: "pw-num",
                            children: "Add a number",
                          }),
                        ],
                      }),
                    ],
                  }),
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground",
                    children:
                      "Words come from the EFF's long word list (7,776 words), picked with your browser's secure random generator. Words and separators are your choice; the entropy line shows what each adds.",
                  }),
                ],
              }),
          e.jsxs("div", {
            className: "flex flex-wrap items-center gap-3",
            children: [
              e.jsxs(S, {
                onClick: H,
                className: "gap-2",
                children: [
                  e.jsx(ce, { className: "h-4 w-4" }),
                  " Generate ",
                  c === "password" ? "Password" : "Passphrase",
                ],
              }),
              e.jsxs("div", {
                className: "flex items-center gap-1.5 text-sm",
                children: [
                  e.jsx(d, {
                    htmlFor: "pw-howmany",
                    className: "text-sm font-normal",
                    children: "How many",
                  }),
                  " ",
                  e.jsx("select", {
                    id: "pw-howmany",
                    "aria-label": "How many passwords",
                    className: "border rounded px-2 py-1 bg-background",
                    value: C,
                    onChange: (i) => te(Number(i.target.value)),
                    children: [1, 3, 5, 10].map((i) =>
                      e.jsx("option", { value: i, children: i }, i),
                    ),
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("p", {
            className: "text-xs text-muted-foreground",
            "data-testid": "pw-checker-link",
            children: [
              "Already have a password and want to know how it holds up? ",
              e.jsx(de, {
                href: "/tool/password-strength",
                className: "underline",
                children: "Check its strength",
              }),
              ", which looks for common words, names, keyboard runs and repeats. This page makes new ones.",
            ],
          }),
        ],
      }),
      e.jsx(me, { whatIsIt: O.what, howToUse: O.how, tip: O.tip }),
    ],
  });
}
export { ns as default };
//# sourceMappingURL=PasswordGenerator-BODnXk3M.js.map
