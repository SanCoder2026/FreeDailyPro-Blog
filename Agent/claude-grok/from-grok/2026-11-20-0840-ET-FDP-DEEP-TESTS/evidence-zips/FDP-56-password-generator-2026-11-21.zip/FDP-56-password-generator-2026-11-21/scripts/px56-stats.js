// FDP-56 desk: run the site's own generator functions (copied verbatim from PasswordGenerator-BODnXk3M.js lines 42-190) in Node to check uniformity and the entropy maths.
const crypto = require('crypto').webcrypto; globalThis.crypto = crypto;
function v(s) {
  if (s <= 0) return 0;
  const t = Math.floor(4294967296 / s) * s,
    a = new Uint32Array(1);
  do crypto.getRandomValues(a);
  while (a[0] >= t);
  return a[0] % s;
}
const q = "!@#$%^&*()_+-=[]{}|;:,.<>?",
  ge = /[Il1O0o|]/g;
function x(s) {
  const t = (r) => (s.excludeSimilar ? r.replace(ge, "") : r),
    a = [];
  return (
    s.upper && a.push(t("ABCDEFGHIJKLMNOPQRSTUVWXYZ")),
    s.lower && a.push(t("abcdefghijklmnopqrstuvwxyz")),
    s.numbers && a.push(t("0123456789")),
    s.symbols && a.push(t(Array.from(new Set(s.symbolSet || q)).join(""))),
    a.filter(Boolean)
  );
}
function U(s) {
  return Array.from(new Set(x(s).join("")));
}
function we(s) {
  const t = x(s);
  if (!t.length) return "";
  const a = U(s),
    r = t.map((o) => new Set(o));
  if (s.length < t.length)
    return Array.from({ length: s.length }, () => a[v(a.length)]).join("");
  for (let o = 0; o < 1e6; o++) {
    const n = Array.from({ length: s.length }, () => a[v(a.length)]);
    if (r.every((h) => n.some((p) => h.has(p)))) return n.join("");
  }
  throw new Error("Could not generate a password with these settings.");
}
const R = BigInt(0),
  xe = BigInt(1),
  fe = (s, t) => {
    let a = xe;
    const r = BigInt(s);
    for (let o = 0; o < t; o++) a *= r;
    return a;
  };
function be(s) {
  if (s <= R) return 0;
  const t = s.toString(2);
  return t.length <= 53
    ? Math.log2(Number(s))
    : Math.log2(Number(BigInt("0b" + t.slice(0, 53)))) + (t.length - 53);
}
function Z(s) {
  const t = x(s),
    a = U(s).length;
  if (!t.length || a < 1 || s.length < t.length) return R;
  let r = R;
  for (let o = 0; o < 1 << t.length; o++) {
    const n = new Set();
    let h = 0;
    t.forEach(($, m) => {
      if (o & (1 << m)) {
        h++;
        for (const M of $) n.add(M);
      }
    });
    const p = fe(a - n.size, s.length);
    r += h % 2 === 0 ? p : -p;
  }
  return r;
}
function K(s, t) {
  return s > 1 ? t * Math.log2(s) : 0;
}
function ye(s) {
  return be(Z(s));
}
function je(s) {
  const t = U(s).length,
    a = K(t, s.length),
    r = ye(s),
    o = [
      `${s.length} characters, each one of ${t} possible characters: ${s.length} x log2(${t}) = ${a.toFixed(1)} bits.`,
    ];
  return (
    a - r >= 0.05 &&
      o.push(
        `Requiring every chosen type to appear rules out some passwords, so the exact figure is ${r.toFixed(1)} bits (log2 of the ${Z(s).toLocaleString("en-US")} passwords that qualify).`,
      ),
    { alphabetSize: t, naiveBits: a, bits: r, lines: o }
  );
}
function Se(s, t) {
  const a = K(7776, s),
    r = t ? Math.log2(100 * s) : 0,
    o = [
      `${s} words, each one of 7,776 on the EFF list: ${s} x log2(7,776) = ${a.toFixed(1)} bits.`,
    ];
  return (
    t &&
      o.push(
        `The two-digit number goes after a random word: ${s} places x 100 numbers, log2(${100 * s}) = ${r.toFixed(1)} bits.`,
      ),
    o.push(
      "Capital letters and the separator are fixed by your choice, so they add no bits.",
    ),
    { alphabetSize: 7776, naiveBits: a + r, bits: a + r, lines: o }
  );
}
const ve = 1e10,
  Ne =
    "Assumes an attacker trying 10 billion guesses a second against a fast-hashed copy of the password and getting there after trying half of all possibilities. A site that stores passwords with a slow hash (bcrypt, Argon2) is far slower to attack; a site that leaks them in plain text makes this number meaningless. It holds only for a password drawn at random like this one: a password you edit, reuse or recognise from a breach is not covered.";
function ke(s) {
  const t = Math.pow(2, s - 1) / ve;
  if (t < 1) return "less than a second";
  if (t >= 31557600 * 1e12)
    return "over a trillion years (the universe is about 13.8 billion years old)";
  const a = [
    [31557600 * 1e9, "billion years"],
    [31557600 * 1e6, "million years"],
    [31557600 * 1e3, "thousand years"],
    [31557600, "years"],
    [86400, "days"],
    [3600, "hours"],
    [60, "minutes"],
    [1, "seconds"],
  ];
  for (const [r, o] of a)
    if (t >= r) {
      const n = t / r;
      return `about ${n >= 100 ? Math.round(n).toLocaleString("en-US") : n.toFixed(n >= 10 ? 0 : 1)} ${o}`;
    }
  return "seconds";
}
function Ce(s) {
  return s >= 100
    ? { label: "Very Strong", color: "text-green-600" }
    : s >= 70
      ? { label: "Strong", color: "text-green-500" }
      : s >= 45
        ? { label: "Medium", color: "text-yellow-500" }
        : { label: "Weak", color: "text-red-500" };
}
function Fe(s, t, a, r, o) {
  const n = Array.from({ length: t }, () => s[v(s.length)]).map((h) =>
    r ? h[0].toUpperCase() + h.slice(1) : h,
  );
  return (o && (n[v(n.length)] += String(v(100)).padStart(2, "0")), n.join(a));
}
const out = {};
const def = { length: 16, upper: true, lower: true, numbers: true, symbols: true, excludeSimilar: false, symbolSet: q };
// 1) character frequency over 100k passwords (chi-square vs uniform over the 88-char alphabet; requirement redraw makes small groups slightly more frequent)
const A = U(def); const cnt = Object.fromEntries(A.map(c => [c, 0])); const N = 100000; const pos0 = Object.fromEntries(A.map(c => [c, 0]));
for (let i = 0; i < N; i++) { const p = we(def); for (const ch of p) cnt[ch]++; pos0[p[0]]++; }
const exp = N * 16 / A.length; let chi = 0; for (const c of A) chi += (cnt[c] - exp) ** 2 / exp;
const groups = { upper: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', lower: 'abcdefghijklmnopqrstuvwxyz', numbers: '0123456789', symbols: q };
out.alphabet = A.length; out.chiSquare_df = [Math.round(chi), A.length - 1];
out.groupShare = Object.fromEntries(Object.entries(groups).map(([k, g]) => [k, +( [...g].reduce((s, c) => s + cnt[c], 0) / (N * 16) ).toFixed(4)]));
out.expectedShareUniform = Object.fromEntries(Object.entries(groups).map(([k, g]) => [k, +(g.length / A.length).toFixed(4)]));
out.minMaxCharCount = [Math.min(...Object.values(cnt)), Math.max(...Object.values(cnt)), Math.round(exp)];
// 2) exact count check by brute force for a tiny case: length 4, numbers+symbols set "!@" (12 chars) -> count strings containing >=1 digit and >=1 of !@
const tiny = { length: 4, upper: false, lower: false, numbers: true, symbols: true, excludeSimilar: false, symbolSet: '!@' };
const ta = U(tiny); let bf = 0; const rec = (s) => { if (s.length === 4) { if (/[0-9]/.test(s) && /[!@]/.test(s)) bf++; return; } for (const c of ta) rec(s + c); }; rec('');
out.tinyBruteForce = bf; out.tinySiteZ = Z(tiny).toString();
// 3) exclude-similar alphabet, spaces-only symbol box, letters in symbol box
out.excludeSimilarAlphabet = U({ ...def, excludeSimilar: true }).length;
out.spacesOnlySymbolBox = { alphabetHasSpace: U({ ...def, symbolSet: '   ' }).includes(' '), sample: we({ ...def, symbolSet: '   ' }) };
out.lettersInSymbolBox = { alphabet: U({ ...def, symbolSet: 'abc#' }).length, sample: we({ ...def, symbolSet: 'abc#' }) };
// 4) passphrase entropy lines
out.passphrase5num = Se(5, true).bits.toFixed(2); out.passphrase3 = Se(3, false).bits.toFixed(2);
console.log(JSON.stringify(out, null, 1));
