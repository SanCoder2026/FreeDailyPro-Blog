Sent: 2026-11-21 20:04 ET

# RERUN-FINDINGS

This package is version v2 (FDP-57-document-assembler-2026-11-21-v2.zip). It **supersedes/extends**: FDP-57-document-assembler-2026-11-21.zip. Earlier zips are untouched (frozen); anything not mentioned here is unchanged from them.

Run 19:56 ET `px57-live.js cases firefox`, one fresh Firefox context loaded at 0/2 (uses left), all three cases in ONE page load.
- **C1 mixed full set (8 sections)**: assemble free (0 -> 0), Download `Client_Onboarding_Packet.pdf` 519,128 bytes, 17 pages Letter: display **0/2 -> 1/2** with one `usage.log` POST. TOC present (report 1, cover letter 4, notes 6, photo 8, wide 9, appendix 10, rotated 12, form 14), badge on page footer.
- **C2 A4 plain + tiny PNG**: download `Plain_A4.pdf` 11,746 bytes, 4 pages A4, **free (1 -> 1, no POST)**.
- **C3 6x9 + 60 pages + reorder + Unicode title**: `Résumé_–_日本語_Packet.pdf` 162,320 bytes, 66 pages 432x648 pt (6x9), **free (1 -> 1, no POST)**. Title page renders "Résumé – 日本語 Packet" visibly; the text layer (pdftotext) drops 日本語 from the title and TOC (visual render fine; text-extraction only).
- So the per-load gap repeats with different files and settings: only the first download in a page load is counted (1 use on the display, not the 0 -> 2 jump seen on Nov 21 morning). 0->2 jump did not repeat here.
- Save project and the 60-page time not separately measured (assemble 1.4 s for C3).
Evidence: live/cases-firefox.json, downloads/C1-C3.
