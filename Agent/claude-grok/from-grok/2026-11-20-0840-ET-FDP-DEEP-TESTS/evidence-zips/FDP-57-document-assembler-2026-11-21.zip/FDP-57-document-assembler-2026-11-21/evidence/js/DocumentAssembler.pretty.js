import { r, j as e } from "./vendor-react-D01g8YgM.js";
import { p as H } from "./utils-s8ucLyj8.js";
import {
  T as X,
  F as $,
  P as ee,
  D as te,
  R as oe,
} from "./ToolPage-DwLoDncN.js";
import { f as u, B as b, e as d, I as y } from "./index-B1CTyGtY.js";
import { C as v } from "./checkbox-Ml1pfDb3.js";
import {
  S as se,
  a as ae,
  b as re,
  c as ie,
  d as ne,
} from "./select-ic5yaeGw.js";
import { C as le } from "./card-KXKUZKW8.js";
import { T as ce } from "./ToolInfoSection-C0i6Zbwo.js";
import { R as me } from "./ReorderableFileList-BhqJ-ECL.js";
import { P as de } from "./ProjectBar-D1TcmmzI.js";
import { u as pe } from "./useProject-B_EqpXu3.js";
import { P as C, p as ue, b as fe } from "./packetPages-B5OPcNs2.js";
import { B as O, a as ge } from "./bookAssembly-DmpTM49o.js";
import { f as he } from "./reorderMath-CVj9Q6Gj.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-DhOoIDuZ.js";
import "./index-BdQq_4o_.js";
import "./chevron-up-BDUcPssj.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./formatFileSize-B-JRDfN5.js";
import "./grip-vertical-Dzkp2Q5V.js";
import "./tableName-DsXKRx8V.js";
import "./EmbedContext-CCnUNY-R.js";
import "./folder-open-CaGDudCA.js";
import "./trash-2-CmoDM6Qu.js";
import "./browser-CMr8NRjw.js";
import "./message-square-BmDwXxeT.js";
import "./flask-conical-DwAwxK3z.js";
import "./file-plus-2-CM-hUmGm.js";
import "./csv-DBvSFDe9.js";
import "./ids-D-BGTcEX.js";
import "./passCode-CB5SR9ne.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./pdfText-bjh9eBB-.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./fontkit.es-DA-3qwB1.js";
import "./sessionOps-CUoW2K-t.js";
import "./budgetOps-CUSjXK0_.js";
import "./imagePdf-Dtz8PQyf.js";
import "./pdfMetadata-CcxIhQF2.js";
import "./pageView-BQIwVYOi.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./formAppearance-CdNbuISd.js";
import "./drawTextAnywhere-DcuP6lHH.js";
import "./codeGeneration-D1g4LVfX.js";
import "./JsBarcode-QeG8kXh7.js";
import "./qrHelpers-av3Dz-dA.js";
function xe(n) {
  return n.fileCount === 0
    ? { field: "files", message: "Add at least one file first." }
    : n.includeCover && !n.title.trim()
      ? {
          field: "title",
          message: "Add a document title, or turn off the cover page.",
        }
      : null;
}
function je(n) {
  return (
    (n instanceof Error ? n.message.trim() : "") ||
    "Something went wrong assembling this document. Check that each file opens normally, then try again."
  );
}
const w = {
  what: "Combines multiple documents — PDF, Word, or images, in any mix — into one properly assembled document, with a real Table of Contents and correct page numbering. The general-purpose version of Book Writing Toolbox/Magazine Maker/Catalog Maker, for anything that doesn't fit those specific formats: reports, compiled appendices, mixed document packets, anything you need combined into one clean file.",
  how: "Upload your files and give each a title, drag them into the order you want, optionally add a cover page, then generate. Every page — regardless of its original size — is uniformly fit to your chosen page size.",
  tip: "This is deliberately the plainest of the four assembly tools — no book- or magazine-specific front matter, just a cover, a Table of Contents, and your content, cleanly paginated.",
};
function It() {
  const [n, c] = r.useState([]),
    [m, S] = r.useState(""),
    [T, z] = r.useState(""),
    [k, _] = r.useState("letter"),
    [h, M] = r.useState(!0),
    [N, W] = r.useState(!0),
    [P, K] = r.useState(!1),
    [D, A] = r.useState(!1),
    [U, F] = r.useState(""),
    [f, i] = r.useState(null),
    [B, I] = r.useState(0),
    [j, l] = r.useState(""),
    [G, E] = r.useState(!1),
    R = r.useRef(null),
    L = r.useCallback((t) => {
      const o = t.filter((s) => {
        const a = s.name.toLowerCase();
        return (
          a.endsWith(".pdf") ||
          a.endsWith(".docx") ||
          a.endsWith(".txt") ||
          s.type === "image/png" ||
          s.type === "image/jpeg"
        );
      });
      (o.length < t.length &&
        u.warning(
          "Some files were skipped — Document Assembler accepts PDF, Word (.docx/.txt), and PNG/JPEG images",
        ),
        c((s) => {
          const a = he(
            s.map((p) => p.file),
            o,
          );
          a.length > 0 &&
            u.warning(
              `${a.length === 1 ? "One file is" : `${a.length} files are`} already in your list — added anyway.`,
            );
          const g = (p) =>
            p.name
              .replace(/\.[^.]+$/, "")
              .replace(/\s*\(\d+\)$/, "")
              .replace(/_/g, " ")
              .trim();
          return [...s, ...o.map((p) => ({ file: p, title: g(p) }))];
        }),
        i(null),
        l(""));
    }, []),
    [x] = pe(),
    V = async (t) => {
      const o = ue(t, x);
      if (!o) {
        u.error(
          `Your project has no ${C[t].toLowerCase()} yet. Add some in the matching tool, or open a project file.`,
        );
        return;
      }
      try {
        const s = await fe(
            o.title,
            o.lines,
            x.paper === "a4" ? "a4" : "letter",
          ),
          a = new File([new Uint8Array(s)], `${o.title}.pdf`, {
            type: "application/pdf",
          });
        (c((g) => [...g, { file: a, title: o.title }]),
          E(!0),
          l(""),
          !m.trim() && x.name.trim() && S(x.name.trim()),
          i(null));
      } catch (s) {
        (console.error("Packet page failed", s),
          u.error("Couldn't build that page. Try again."));
      }
    },
    Y = (t) => {
      (c((o) => t.map((s) => o.find((a) => a.file === s))), i(null));
    },
    Z = (t) => {
      (c((o) => o.filter((s, a) => a !== t)), i(null));
    },
    J = (t, o) => {
      (c((s) => s.map((a, g) => (g === t ? { ...a, title: o } : a))), i(null));
    },
    Q = async () => {
      const t = xe({ fileCount: n.length, includeCover: h, title: m });
      if (t) {
        (l(t.message), t.field === "title" && R.current?.focus());
        return;
      }
      (l(""), A(!0), i(null));
      try {
        const { bytes: o, totalPages: s } = await ge({
          bookTitle: m,
          author: T,
          bookSize: k,
          sections: n,
          frontMatter: {
            title: h ? { kind: "title", heading: m, body: "" } : void 0,
          },
          backMatter: {},
          includeToc: N,
          includeListOfImages: P,
          onProgress: F,
        });
        (i(H(o)), I(s), u.success("Document assembled!"));
      } catch (o) {
        console.error("Document assembly failed:", o);
        const s = je(o);
        (l(s), u.error(s));
      } finally {
        (A(!1), F(""));
      }
    },
    q = () => {
      (c([]), i(null), I(0), l(""), E(!1));
    };
  return e.jsxs(X, {
    children: [
      e.jsxs("div", {
        className: "space-y-6",
        children: [
          e.jsxs("div", {
            className: "p-3 rounded-lg border bg-muted/20 space-y-2",
            "data-testid": "da-project",
            children: [
              e.jsx("p", {
                className: "text-sm font-medium",
                children: "Add pages from my project",
              }),
              e.jsx("div", {
                className: "flex flex-wrap gap-2",
                children: Object.keys(C).map((t) =>
                  e.jsx(
                    b,
                    {
                      type: "button",
                      size: "sm",
                      variant: "outline",
                      onClick: () => V(t),
                      "data-testid": `da-add-${t}`,
                      children: C[t],
                    },
                    t,
                  ),
                ),
              }),
              e.jsx("p", {
                className: "text-xs text-muted-foreground",
                children:
                  "Each becomes a section you can reorder, retitle or remove, next to your own files.",
              }),
            ],
          }),
          e.jsxs("div", {
            children: [
              e.jsx(d, { children: "Document Title" }),
              e.jsx(y, {
                ref: R,
                "aria-label": "Document Title",
                "aria-invalid": !!j && !m.trim() && h,
                value: m,
                onChange: (t) => {
                  (S(t.target.value), i(null), l(""));
                },
                placeholder: "e.g. Q3 Compiled Report",
              }),
            ],
          }),
          e.jsxs("div", {
            children: [
              e.jsx(d, { children: "Author / Prepared By (optional)" }),
              e.jsx(y, {
                "aria-label": "Author / Prepared By (optional)",
                value: T,
                onChange: (t) => {
                  (z(t.target.value), i(null));
                },
              }),
            ],
          }),
          e.jsxs("div", {
            children: [
              e.jsx(d, { children: "Page Size" }),
              e.jsxs(se, {
                value: k,
                onValueChange: (t) => {
                  (_(t), i(null));
                },
                children: [
                  e.jsx(ae, {
                    className: "w-full max-w-full [&>span]:truncate",
                    children: e.jsx(re, {}),
                  }),
                  e.jsx(ie, {
                    children: Object.keys(O).map((t) =>
                      e.jsx(ne, { value: t, children: O[t].label }, t),
                    ),
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("div", {
            children: [
              e.jsx(d, { className: "mb-2 block", children: "Files" }),
              n.length === 0
                ? e.jsx($, {
                    gateAtDownload: !0,
                    accept: ".pdf,.docx,.txt,image/png,image/jpeg,image/jpg",
                    multiple: !0,
                    onFiles: L,
                    label: "Drop your files",
                    description:
                      "PDF, Word (.docx/.txt), or images — add as many as you need",
                  })
                : e.jsxs("div", {
                    className: "space-y-4",
                    children: [
                      e.jsx(me, {
                        files: n.map((t) => t.file),
                        onReorder: Y,
                        onRemove: Z,
                      }),
                      e.jsx("div", {
                        className: "space-y-2",
                        children: n.map((t, o) =>
                          e.jsxs(
                            "div",
                            {
                              className: "flex items-center gap-2",
                              children: [
                                e.jsxs("span", {
                                  className:
                                    "text-xs text-muted-foreground w-6 shrink-0",
                                  children: [o + 1, "."],
                                }),
                                e.jsx(y, {
                                  value: t.title,
                                  onChange: (s) => J(o, s.target.value),
                                  placeholder:
                                    "Section title (appears in Table of Contents)",
                                  className: "text-sm",
                                }),
                              ],
                            },
                            `${t.file.name}-${t.file.size}-${o}`,
                          ),
                        ),
                      }),
                      e.jsx($, {
                        gateAtDownload: !0,
                        accept:
                          ".pdf,.docx,.txt,image/png,image/jpeg,image/jpg",
                        multiple: !0,
                        onFiles: L,
                        label: "Add another file",
                        description: "",
                      }),
                    ],
                  }),
            ],
          }),
          e.jsxs(le, {
            className: "p-4 space-y-4",
            children: [
              e.jsxs("div", {
                className: "flex items-center gap-2",
                children: [
                  e.jsx(v, {
                    checked: h,
                    onCheckedChange: () => {
                      (M((t) => !t), i(null), l(""));
                    },
                    id: "cover",
                  }),
                  e.jsx(d, {
                    htmlFor: "cover",
                    className: "font-normal cursor-pointer",
                    children: "Cover Page",
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "flex items-center gap-2",
                children: [
                  e.jsx(v, {
                    checked: N,
                    onCheckedChange: () => {
                      (W((t) => !t), i(null));
                    },
                    id: "toc",
                  }),
                  e.jsx(d, {
                    htmlFor: "toc",
                    className: "font-normal cursor-pointer",
                    children: "Table of Contents (auto-generated)",
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "flex items-center gap-2",
                children: [
                  e.jsx(v, {
                    checked: P,
                    onCheckedChange: () => {
                      (K((t) => !t), i(null));
                    },
                    id: "loi",
                  }),
                  e.jsx(d, {
                    htmlFor: "loi",
                    className: "font-normal cursor-pointer",
                    children: "List of Images",
                  }),
                ],
              }),
            ],
          }),
          j &&
            e.jsx("p", {
              role: "alert",
              className: "text-sm text-destructive",
              "data-testid": "da-error",
              children: j,
            }),
          f &&
            !D &&
            e.jsxs("p", {
              role: "status",
              className: "text-sm text-muted-foreground",
              "data-testid": "da-done",
              children: [
                "Your document is ready: ",
                B,
                " pages. Download it below.",
              ],
            }),
          e.jsx("div", {
            className: "flex gap-3",
            children: D
              ? e.jsx(ee, { message: U || "Assembling..." })
              : f
                ? e.jsxs(e.Fragment, {
                    children: [
                      e.jsx(te, {
                        blob: f,
                        fileName: `${(m || "document")
                          .replace(/[\\/:*?"<>|\u0000-\u001f]+/g, "_")
                          .replace(/\s+/g, "_")
                          .slice(0, 100)}.pdf`,
                        label: `Download Document (${B} pages)`,
                      }),
                      e.jsx(b, {
                        variant: "outline",
                        onClick: q,
                        children: "New Document",
                      }),
                    ],
                  })
                : e.jsx(b, { onClick: Q, children: "Assemble Document" }),
          }),
          f && e.jsx(oe, { blob: f, mimeType: "application/pdf" }),
        ],
      }),
      e.jsx(de, { passKeyNote: G }),
      e.jsx(ce, { whatIsIt: w.what, howToUse: w.how, tip: w.tip }),
    ],
  });
}
export { It as default };
//# sourceMappingURL=DocumentAssembler-6CoK9VPz.js.map
