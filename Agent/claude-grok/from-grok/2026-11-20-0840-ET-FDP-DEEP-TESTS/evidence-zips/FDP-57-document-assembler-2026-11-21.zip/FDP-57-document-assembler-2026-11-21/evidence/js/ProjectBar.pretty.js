import { r as S, j as e } from "./vendor-react-D01g8YgM.js";
import {
  t as M,
  B as T,
  L as ee,
  f as L,
  dQ as Te,
  b9 as Pe,
  M as xe,
  ck as fe,
  X as me,
  D as Le,
} from "./index-B1CTyGtY.js";
import { am as De, U as Ee, d as Ie } from "./ToolPage-DwLoDncN.js";
import {
  l as Se,
  u as oe,
  s as ke,
  m as Ne,
  G as Ue,
} from "./useProject-B_EqpXu3.js";
import { c as te } from "./tableName-DsXKRx8V.js";
import { u as _e } from "./EmbedContext-CCnUNY-R.js";
import { C as ze } from "./useUploadApi-cn-OKK9Q.js";
import { F as Be } from "./folder-open-CaGDudCA.js";
import { T as ue } from "./trash-2-CmoDM6Qu.js";
import { Q as Re } from "./browser-CMr8NRjw.js";
import { C as Oe } from "./copy-DcUvE8ta.js";
import { M as ge } from "./message-square-BmDwXxeT.js";
import { F as Fe } from "./flask-conical-DwAwxK3z.js";
import { F as Ke } from "./file-plus-2-CM-hUmGm.js";
const ae = (t) =>
    t
      .normalize("NFD")
      .replace(/[̀-ͯ]/g, "")
      .toLowerCase()
      .replace(/\s+/g, " ")
      .trim(),
  ne = (t) => t.filter((s) => s.status !== "declined"),
  le = (t) =>
    (t ?? "")
      .split(/[;|+]/)
      .map((s) => s.trim())
      .filter(Boolean);
function Ce(t, s) {
  const i = ae(s),
    a = t.filter((n) => ae(n.name) === i);
  return a.length === 1 ? a[0] : void 0;
}
function $e(t) {
  const s = new Map();
  for (const i of ne(t)) {
    const a = ae(i.together ?? "");
    a && s.set(a, [...(s.get(a) ?? []), i]);
  }
  return (
    Array.from(s.keys()).forEach((i) => {
      s.get(i).length < 2 && s.delete(i);
    }),
    s
  );
}
function pe(t) {
  const s = new Map(),
    i = (a, n) => {
      a !== n &&
        ((s.get(a) ?? s.set(a, new Set()).get(a)).add(n),
        (s.get(n) ?? s.set(n, new Set()).get(n)).add(a));
    };
  for (const a of ne(t))
    for (const n of le(a.apart)) {
      const o = Ce(ne(t), n);
      o && i(a.id, o.id);
    }
  return s;
}
function Ge(t) {
  const s = [],
    i = (d) => te(d.table).toLowerCase(),
    a = (d) => te(d.table);
  for (const d of Array.from($e(t).values())) {
    const u = d.filter((l) => i(l));
    Array.from(new Set(u.map(i))).length > 1
      ? s.push(
          `${d.map((l) => l.name).join(" + ")} should sit together but are at ${Array.from(new Set(u.map(a))).join(", ")}.`,
        )
      : u.length &&
        u.length < d.length &&
        s.push(
          `${d.map((l) => l.name).join(" + ")} should sit together but ${d.length - u.length} of them ${d.length - u.length === 1 ? "has" : "have"} no table yet.`,
        );
  }
  const n = new Map(ne(t).map((d) => [d.id, d])),
    o = new Set();
  return (
    pe(t).forEach((d, u) =>
      d.forEach((h) => {
        const l = [u, h].sort().join("|");
        if (o.has(l)) return;
        o.add(l);
        const f = n.get(u),
          g = n.get(h);
        f &&
          g &&
          i(f) &&
          i(f) === i(g) &&
          s.push(
            `${f.name} and ${g.name} should be kept apart but both sit at ${a(f)}.`,
          );
      }),
    ),
    s
  );
}
function St(t) {
  const s = [];
  Array.from($e(t).entries()).forEach(([o, d]) => {
    const u = d.map((l) => l.name).join(" + "),
      h = (d[0].together ?? "").trim();
    s.push(ae(h) === ae(u) ? u : `${h}: ${u}`);
  });
  const i = [],
    a = new Map(ne(t).map((o) => [o.id, o])),
    n = new Set();
  return (
    pe(t).forEach((o, d) =>
      o.forEach((u) => {
        const h = [d, u].sort().join("|");
        if (n.has(h)) return;
        n.add(h);
        const l = a.get(d),
          f = a.get(u);
        l && f && i.push(`${l.name} + ${f.name}`);
      }),
    ),
    { together: s, apart: i }
  );
}
function kt(t, s, i) {
  const a = [],
    n = t.map((h) => {
      if (h.status === "declined") return h;
      const { together: l, apart: f, ...g } = h;
      return g;
    }),
    o = (h) => {
      const l = Ce(n, h);
      return (l || a.push(`No single guest is named "${h}".`), l);
    },
    d = new Map(n.map((h, l) => [h.id, l])),
    u = (h) =>
      h
        .split(/\r?\n/)
        .map((l) => l.trim())
        .filter(Boolean);
  for (const h of u(s)) {
    const l = /^([^:+]+):\s*(.+)$/.exec(h),
      f = le(l ? l[2] : h),
      g = f.map(o).filter((w) => !!w);
    if (f.length < 2) {
      a.push(`"${h}" needs at least two names joined with +.`);
      continue;
    }
    if (g.length < 2) continue;
    const k = (l ? l[1].trim() : g.map((w) => w.name).join(" + ")).slice(
      0,
      300,
    );
    for (const w of g) n[d.get(w.id)] = { ...n[d.get(w.id)], together: k };
  }
  for (const h of u(i)) {
    const l = le(h),
      f = l.map(o).filter((g) => !!g);
    if (l.length < 2) {
      a.push(`"${h}" needs at least two names joined with +.`);
      continue;
    }
    for (const g of f) {
      const k = d.get(g.id),
        w = f.filter((E) => E.id !== g.id).map((E) => E.name),
        D = le(n[k].apart),
        b = Array.from(new Set([...D, ...w]));
      n[k] = { ...n[k], apart: b.join("; ").slice(0, 300) };
    }
  }
  return { guests: n, problems: a };
}
const G = (t) => 1 + Math.max(0, Math.floor(t.plusOnes ?? 0)),
  V = (t) => te(t).toLowerCase(),
  ie = (t) => t.filter((s) => s.status !== "declined"),
  Ae = (t, s) =>
    t.localeCompare(s, void 0, { numeric: !0, sensitivity: "base" });
function Ve(t, s) {
  const i = new Map();
  for (let a = 1; a <= Math.max(0, s); a++) i.set(`table ${a}`, `Table ${a}`);
  for (const a of ie(t)) {
    const n = te(a.table);
    n && !i.has(V(n)) && i.set(V(n), n);
  }
  return Array.from(i.values()).sort(Ae);
}
function Nt(t) {
  const s = new Map();
  for (const i of t.split(/[,;\n]+/)) {
    const a = /^(.+?)\s*[=:]\s*(\d{1,3})$/.exec(i.trim());
    if (!a) continue;
    const n = Number(a[2]);
    n >= 1 && n <= 500 && s.set(V(a[1]), n);
  }
  return s;
}
function He(t, s, i, a = new Map()) {
  const n = ie(t),
    o = Ve(t, s),
    d = new Set(o.map(V));
  return (
    Array.from(a.keys()).forEach((u) => {
      d.has(u) || o.push(u.replace(/\b\w/g, (h) => h.toUpperCase()));
    }),
    o.sort(Ae),
    o.map((u) => {
      const h = a.get(V(u)) ?? i,
        l = n.filter((g) => V(g.table) === V(u)),
        f = l.reduce((g, k) => g + G(k), 0);
      return { name: u, guests: l, used: f, capacity: h, free: h - f };
    })
  );
}
const Me = (t) => ie(t).filter((s) => !s.table?.trim());
function Ct(t, s, i) {
  const a = Math.max(i, ...t.map((d) => d.capacity)),
    n = [];
  for (const d of t)
    d.free < 0 &&
      n.push({
        level: "error",
        message: `${d.name} is over by ${-d.free} seat${d.free === -1 ? "" : "s"}.`,
      });
  for (const d of ie(s))
    G(d) > a &&
      n.push({
        level: "error",
        message: `${d.name}'s party of ${G(d)} is larger than a table of ${a}.`,
      });
  for (const d of Ge(s)) n.push({ level: "warning", message: d });
  const o = Me(s).length;
  return (
    o &&
      n.push({
        level: "warning",
        message: `${o} guest${o === 1 ? " has" : "s have"} no table yet.`,
      }),
    n
  );
}
const ye = (t) =>
  (t ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
function Qe(t, s, i, a = new Map()) {
  const n = He(t, s, i, a),
    o = new Map(n.map((m) => [m.name, m.free])),
    d = new Map(n.map((m) => [m.name, m.capacity])),
    u = n.map((m) => m.name),
    h = [],
    l = pe(t),
    f = new Map(n.map((m) => [m.name, new Set(m.guests.map((p) => p.id))])),
    g = (m, p) => {
      const $ = f.get(m);
      return $
        ? p.some((A) => {
            const P = l.get(A.id);
            return !!P && Array.from($).some((B) => P.has(B));
          })
        : !1;
    },
    k = (m) =>
      m.some((p, $) => m.slice($ + 1).some((A) => l.get(p.id)?.has(A.id))),
    w = (m) => m.reduce((p, $) => p + G($), 0),
    D = new Map(),
    b = new Map(),
    E = [];
  for (const m of Me(t)) {
    const p = ye(m.together);
    p
      ? D.set(p, [...(D.get(p) ?? []), m])
      : m.organisation?.trim()
        ? b.set(V(m.organisation), [...(b.get(V(m.organisation)) ?? []), m])
        : E.push([m]);
  }
  const y = (m) => {
      const p = new Map();
      for (const A of ie(t))
        ye(A.together) === m &&
          A.table?.trim() &&
          p.set(V(A.table), (p.get(V(A.table)) ?? 0) + 1);
      const $ = Array.from(p.entries()).sort((A, P) => P[1] - A[1])[0];
      return $ ? u.find((A) => V(A) === $[0]) : void 0;
    },
    C = (m, p) => w(p.members) - w(m.members),
    N = Array.from(D.entries()).map(([m, p]) => ({
      members: p,
      label: p[0].together?.trim(),
      preferred: y(m),
    })),
    U = [...Array.from(b.values()), ...E].map((m) => ({ members: m })),
    v = [...N.sort(C), ...U.sort(C)],
    O = v.reduce((m, p) => m + w(p.members), 0),
    Q = n.reduce((m, p) => m + p.used, 0),
    W = Math.min(
      u.length,
      Math.max(O > 1 ? 2 : 1, Math.ceil((Q + O) / Math.max(1, i))),
    ),
    _ = new Set(n.filter((m) => m.used > 0).map((m) => m.name));
  for (const m of u) {
    if (_.size >= W) break;
    _.add(m);
  }
  const q = (m) =>
      ((d.get(m) ?? 1) - (o.get(m) ?? 0)) / Math.max(1, d.get(m) ?? 1),
    x = (m, p) => {
      const $ = (P) => (o.get(P) ?? 0) >= m && !g(P, p);
      let A;
      for (const P of u)
        _.has(P) && $(P) && (A === void 0 || q(P) < q(A)) && (A = P);
      return A ?? u.find($);
    },
    r = new Map(),
    I = (m, p) => {
      (o.set(p, (o.get(p) ?? 0) - w(m)),
        m.forEach(($) => {
          (r.set($.id, p), f.get(p)?.add($.id));
        }));
    },
    F = (m) => {
      for (const p of m) {
        const $ = x(G(p), [p]);
        $
          ? I([p], $)
          : h.push(
              `${p.name} has no table: ${G(p) > Math.max(0, ...u.map((A) => d.get(A) ?? 0)) ? "the party is larger than any table" : "every table with room has someone they should be kept apart from"}.`,
            );
      }
    },
    X = (m) => {
      const p = [...m].sort((P, B) => G(B) - G(P)),
        $ = [],
        A = Math.max(0, ...u.map((P) => o.get(P) ?? 0));
      for (; p.length && w(p) > A;) {
        const P = u
          .filter((j) => (o.get(j) ?? 0) > 0)
          .sort(
            (j, z) =>
              (o.get(z) ?? 0) - (o.get(j) ?? 0) || u.indexOf(j) - u.indexOf(z),
          )[0];
        if (!P) break;
        const B = [];
        let c = o.get(P) ?? 0;
        for (let j = 0; j < p.length; j++) {
          const z = p[j];
          G(z) <= c &&
            !g(P, [...B, z]) &&
            !k([...B, z]) &&
            (B.push(z), (c -= G(z)), p.splice(j, 1), j--);
        }
        if (!B.length) break;
        (I(B, P), $.push(B));
      }
      return (p.length && $.push(p), $);
    };
  for (const m of v) {
    const { members: p, label: $ } = m,
      A = w(p),
      P = $ !== void 0 && (p.length > 1 || m.preferred !== void 0),
      B = p.map((K) => K.name).join(" + ");
    if (p.length === 1 && !P) {
      F(p);
      continue;
    }
    if ($ !== void 0 && k(p)) {
      (h.push(
        `${B} are in one group but some of them are marked to be kept apart, so they were seated separately.`,
      ),
        F(p));
      continue;
    }
    if (m.preferred && (o.get(m.preferred) ?? 0) >= A && !g(m.preferred, p)) {
      I(p, m.preferred);
      continue;
    }
    const c = k(p) ? void 0 : x(A, p);
    if (c) {
      I(p, c);
      continue;
    }
    const j = X(p),
      z = j.filter((K) => K.every((Z) => r.has(Z.id))),
      R = j.filter((K) => !z.includes(K)).flat(),
      H = R.length > 1 ? x(w(R), R) : void 0;
    if ((H && !k(R) ? I(R, H) : F(R), $ !== void 0)) {
      const K = Array.from(
          new Set(p.map((ce) => r.get(ce.id)).filter(Boolean)),
        ),
        Z = Math.max(0, ...u.map((ce) => d.get(ce) ?? 0)),
        he =
          A > Z
            ? `${A} seats are more than a table of ${Z}`
            : "no single table has room for them";
      h.push(
        `${B} could not sit together (${he})${K.length ? `; they are at ${K.join(" and ")}` : ""}.`,
      );
    }
  }
  return { map: r, unmet: h };
}
function We(t, s, i, a = new Map()) {
  return Qe(t, s, i, a).map;
}
function $t(t, s) {
  const i = [["Table", "Guest", "Organisation", "Seats", "Dietary", "Access"]];
  for (const a of t)
    for (const n of a.guests)
      i.push([
        a.name,
        n.name,
        n.organisation ?? "",
        String(G(n)),
        n.dietary ?? "",
        n.access ?? "",
      ]);
  for (const a of s)
    i.push([
      "",
      a.name,
      a.organisation ?? "",
      String(G(a)),
      a.dietary ?? "",
      a.access ?? "",
    ]);
  return i;
}
function At(t, s) {
  const i = t
    .filter((a) => a.guests.length)
    .map(
      (a) => `${a.name} (${a.used}/${a.capacity})
${a.guests.map((n) => `  ${n.name}${n.plusOnes ? ` +${n.plusOnes}` : ""}`)
  .join(`
`)}`,
    );
  return (
    s.length &&
      i.push(`Not seated
${s.map((a) => `  ${a.name}`).join(`
`)}`),
    i.join(`

`)
  );
}
function ve(t) {
  return Object.values(t.data).some((s) => Array.isArray(s) && s.length > 0);
}
const Y = (t, s, i = {}) => ({
  id: t,
  name: s,
  status: "confirmed",
  needsStay: !1,
  ...i,
});
function qe() {
  const t = Se({
      name: "Sample offsite",
      currency: "USD",
      locale: "en-US",
      timeZone: "America/New_York",
      paper: "letter",
    }),
    s = [
      Y("g_sample01", "Maya Patel", {
        email: "maya.patel@example.com",
        organisation: "Northwind",
        role: "Head of Product",
        dietary: "vegetarian",
        needsStay: !0,
        arrival: "2026-11-12",
        departure: "2026-11-14",
      }),
      Y("g_sample02", "Lukas Meyer", {
        email: "lukas.meyer@example.com",
        organisation: "Northwind",
        role: "Engineer",
        needsStay: !0,
        arrival: "2026-11-12",
        departure: "2026-11-14",
      }),
      Y("g_sample03", "Amara Okafor", {
        email: "amara.okafor@example.com",
        organisation: "Contoso",
        role: "Designer",
        dietary: "no nuts",
        access: "step-free access",
        needsStay: !0,
        arrival: "2026-11-12",
        departure: "2026-11-13",
      }),
      Y("g_sample04", "Haruto Tanaka", {
        email: "haruto.tanaka@example.com",
        organisation: "Contoso",
        role: "Sales Lead",
        dietary: "halal",
      }),
      Y("g_sample05", "Sofia Rossi", {
        email: "sofia.rossi@example.com",
        organisation: "Fabrikam",
        role: "Operations",
        status: "invited",
      }),
      Y("g_sample06", "Chen Wei", {
        email: "chen.wei@example.com",
        organisation: "Fabrikam",
        role: "Analyst",
        status: "waitlist",
      }),
      Y("g_sample07", "Fatima Al-Sayed", {
        email: "fatima.alsayed@example.com",
        organisation: "Northwind",
        role: "Finance",
        dietary: "vegan",
        needsStay: !0,
        arrival: "2026-11-12",
        departure: "2026-11-14",
      }),
      Y("g_sample08", "Daniel Smith", {
        email: "daniel.smith@example.com",
        organisation: "Contoso",
        role: "Support",
        status: "declined",
      }),
    ],
    i = We(
      s.filter((g) => g.status === "confirmed"),
      2,
      8,
    );
  s.forEach((g) => {
    const k = i.get(g.id);
    k && (g.table = k);
  });
  const a = [
      {
        id: "s_sample01",
        title: "Welcome and goals",
        day: "2026-11-13",
        start: "09:00",
        end: "09:30",
        room: "Main hall",
        presenter: "Maya Patel",
      },
      {
        id: "s_sample02",
        title: "Roadmap workshop",
        day: "2026-11-13",
        start: "09:45",
        end: "11:30",
        track: "Product",
        room: "Room A",
        presenter: "Lukas Meyer",
      },
      {
        id: "s_sample03",
        title: "Customer panel",
        day: "2026-11-13",
        start: "13:00",
        end: "14:00",
        track: "Sales",
        room: "Main hall",
        link: "https://example.com/live",
      },
      {
        id: "s_sample04",
        title: "Team dinner",
        day: "2026-11-13",
        start: "19:00",
        room: "Terrace",
      },
      {
        id: "s_sample05",
        title: "Planning sprint",
        day: "2026-11-14",
        start: "09:30",
        end: "12:00",
        track: "Product",
        room: "Room A",
      },
      {
        id: "s_sample06",
        title: "Wrap-up",
        day: "2026-11-14",
        start: "12:00",
        end: "12:30",
        room: "Main hall",
      },
    ],
    n = [
      {
        id: "v_sample01",
        name: "Harbour Hotel",
        category: "Accommodation",
        contact: "Priya Nair",
        email: "events@harbour.example.com",
      },
      {
        id: "v_sample02",
        name: "Greenleaf Catering",
        category: "Catering",
        contact: "Tomas Silva",
        email: "orders@greenleaf.example.com",
      },
      {
        id: "v_sample03",
        name: "ClearView AV",
        category: "Audio visual",
        email: "hire@clearview.example.com",
      },
    ],
    o = [
      {
        id: "q_sample01",
        vendor: "Greenleaf Catering",
        item: "Lunch and dinner, 8 guests",
        amount: 1840,
        currency: "USD",
        status: "received",
        validUntil: "2026-10-31",
      },
      {
        id: "q_sample02",
        vendor: "Silver Table Events",
        item: "Lunch and dinner, 8 guests",
        amount: 2110,
        currency: "USD",
        status: "received",
        validUntil: "2026-10-31",
      },
      {
        id: "q_sample03",
        vendor: "ClearView AV",
        item: "Projector, mics, 2 days",
        amount: 760,
        currency: "USD",
        status: "accepted",
      },
    ],
    d = [
      {
        id: "e_sample01",
        date: "2026-10-01",
        description: "Venue deposit",
        kind: "cost",
        category: "Venue",
        vendor: "Harbour Hotel",
        amount: 1200,
        currency: "USD",
        taxType: "sales_tax",
        taxRate: 8.25,
        taxIncluded: !1,
      },
      {
        id: "e_sample02",
        date: "2026-10-05",
        description: "AV hire",
        kind: "cost",
        category: "Audio visual",
        vendor: "ClearView AV",
        amount: 760,
        currency: "USD",
        taxType: "sales_tax",
        taxRate: 8.25,
        taxIncluded: !1,
      },
      {
        id: "e_sample03",
        date: "2026-10-09",
        description: "Client fee",
        kind: "income",
        category: "Fees",
        amount: 5e3,
        currency: "USD",
        taxType: "none",
        taxIncluded: !1,
      },
    ],
    u = [
      {
        id: "r_sample01",
        guest: "Maya Patel",
        hotel: "Harbour Hotel",
        roomType: "King",
        checkIn: "2026-11-12",
        checkOut: "2026-11-14",
      },
      {
        id: "r_sample02",
        guest: "Lukas Meyer",
        hotel: "Harbour Hotel",
        roomType: "Twin",
        checkIn: "2026-11-12",
        checkOut: "2026-11-14",
        sharedWith: "Fatima Al-Sayed",
      },
      {
        id: "r_sample03",
        guest: "Amara Okafor",
        hotel: "Harbour Hotel",
        roomType: "Accessible king",
        checkIn: "2026-11-12",
        checkOut: "2026-11-13",
      },
      {
        id: "r_sample04",
        guest: "Fatima Al-Sayed",
        hotel: "Harbour Hotel",
        roomType: "Twin",
        checkIn: "2026-11-12",
        checkOut: "2026-11-14",
        sharedWith: "Lukas Meyer",
      },
    ],
    h = [
      {
        id: "t_sample01",
        title: "Confirm venue and AV",
        due: "2026-10-23",
        done: !0,
        owner: "Maya Patel",
        category: "Venue",
      },
      {
        id: "t_sample02",
        title: "Send agenda to guests",
        due: "2026-10-30",
        done: !1,
        owner: "Lukas Meyer",
        category: "Guests",
      },
      {
        id: "t_sample03",
        title: "Final headcount to caterer",
        due: "2026-11-06",
        done: !1,
        category: "Catering",
      },
    ],
    l = [
      { id: "b_sample01", category: "Venue", planned: 1500, currency: "USD" },
      {
        id: "b_sample02",
        category: "Audio visual",
        planned: 900,
        currency: "USD",
      },
      {
        id: "b_sample03",
        category: "Catering",
        planned: 1800,
        currency: "USD",
      },
      {
        id: "b_sample04",
        category: "Contingency",
        planned: 400,
        currency: "USD",
      },
    ],
    f = [
      {
        id: "x_sample01",
        company: "Northwind Supplies",
        booth: "A1",
        contact: "Priya Nair",
        status: "paid",
        fee: 900,
        paid: 900,
        currency: "USD",
        needs: "Power, wifi",
      },
      {
        id: "x_sample02",
        company: "Contoso Labs",
        booth: "A2",
        contact: "Daniel Cho",
        status: "booked",
        fee: 900,
        paid: 300,
        currency: "USD",
        needs: "Two tables",
      },
      {
        id: "x_sample03",
        company: "Fabrikam Studio",
        status: "enquiry",
        currency: "USD",
      },
    ];
  return (
    (t.data = {
      guests: s,
      sessions: a,
      vendors: n,
      quotes: o,
      expenses: d,
      rooms: u,
      tasks: h,
      budgets: l,
      exhibitors: f,
    }),
    t
  );
}
const de = (t) =>
  t >= 1e9
    ? `${(t / 1e9).toFixed(2)} GB`
    : t >= 1e6
      ? `${(t / 1e6).toFixed(1)} MB`
      : `${Math.max(1, Math.round(t / 1e3))} KB`;
function Ye() {
  const [t, s] = oe(),
    i = M.useUtils(),
    a = M.eventSuite.storage.list.useQuery(void 0, { retry: !1 }),
    n = M.eventSuite.storage.prepareSave.useMutation(),
    o = M.eventSuite.storage.confirmSave.useMutation(),
    d = M.eventSuite.storage.open.useMutation(),
    u = M.eventSuite.storage.remove.useMutation(),
    [h, l] = S.useState(null),
    [f, g] = S.useState(null),
    k = async (y) => {
      l("save");
      try {
        const C = ke(t),
          N = new Blob([C], { type: "application/json" }),
          U = await n.mutateAsync({
            projectId: y ? void 0 : (f ?? void 0),
            name: t.name,
            sizeBytes: N.size,
          });
        if (
          !(
            await fetch(U.uploadUrl, {
              method: "PUT",
              headers: { "Content-Type": "application/json" },
              body: N,
            })
          ).ok
        )
          throw new Error("The upload did not finish. Please try again.");
        (await o.mutateAsync({ projectId: U.projectId, name: t.name }),
          g(U.projectId),
          await i.eventSuite.storage.list.invalidate(),
          L.success("Saved to your account"));
      } catch (C) {
        L.error(
          C instanceof Error ? C.message : "Could not save. Please try again.",
        );
      } finally {
        l(null);
      }
    },
    w = async (y) => {
      if (
        window.confirm(
          "Open this saved project? The one open now is replaced unless you saved it.",
        )
      ) {
        l(y);
        try {
          const C = await d.mutateAsync({ projectId: y }),
            N = Ne(C.json);
          if (!N.ok) throw new Error(N.error);
          (s.reset(N.project), g(y), L.success(`Opened ${C.name}`));
        } catch (C) {
          L.error(
            C instanceof Error ? C.message : "Could not open that project.",
          );
        } finally {
          l(null);
        }
      }
    },
    D = async (y, C) => {
      if (
        window.confirm(
          `Delete "${C}" from your account? This cannot be undone.`,
        )
      ) {
        l(y);
        try {
          (await u.mutateAsync({ projectId: y }),
            f === y && g(null),
            await i.eventSuite.storage.list.invalidate());
        } catch (N) {
          L.error(
            N instanceof Error ? N.message : "Could not delete that project.",
          );
        } finally {
          l(null);
        }
      }
    };
  if (a.isError) return null;
  const b = a.data,
    E = b ? Math.min(100, Math.round((b.usedBytes / b.limitBytes) * 100)) : 0;
  return e.jsxs("section", {
    className: "mt-3 rounded-lg border bg-card p-4 text-sm",
    "data-testid": "account-projects",
    children: [
      e.jsxs("div", {
        className: "flex flex-wrap items-center gap-2",
        children: [
          e.jsx("h3", {
            className: "font-semibold",
            children: "Saved to your account",
          }),
          b &&
            e.jsxs("span", {
              className: "text-xs text-muted-foreground",
              children: [de(b.usedBytes), " of ", de(b.limitBytes), " used"],
            }),
          e.jsxs("div", {
            className: "ml-auto flex gap-2",
            children: [
              e.jsxs(T, {
                size: "sm",
                onClick: () => {
                  k(!1);
                },
                disabled: h !== null,
                "data-testid": "account-save",
                children: [
                  h === "save"
                    ? e.jsx(ee, { className: "h-3.5 w-3.5 mr-1 animate-spin" })
                    : e.jsx(ze, { className: "h-3.5 w-3.5 mr-1" }),
                  f ? "Save changes" : "Save to account",
                ],
              }),
              f &&
                e.jsx(T, {
                  size: "sm",
                  variant: "outline",
                  onClick: () => {
                    k(!0);
                  },
                  disabled: h !== null,
                  children: "Save as new copy",
                }),
            ],
          }),
        ],
      }),
      b &&
        e.jsx("div", {
          className: "mt-2 h-1.5 w-full overflow-hidden rounded bg-muted",
          "aria-hidden": !0,
          children: e.jsx("div", {
            className: "h-full bg-primary",
            style: { width: `${E}%` },
          }),
        }),
      a.isLoading &&
        e.jsx("p", {
          className: "mt-3 text-xs text-muted-foreground",
          children: "Loading your saved projects",
        }),
      b &&
        b.projects.length === 0 &&
        e.jsx("p", {
          className: "mt-3 text-xs text-muted-foreground",
          children:
            "Nothing saved yet. Save this project to open it from any device.",
        }),
      b &&
        b.projects.length > 0 &&
        e.jsx("ul", {
          className: "mt-3 divide-y",
          children: b.projects.map((y) =>
            e.jsxs(
              "li",
              {
                className: "flex items-center gap-2 py-2",
                children: [
                  e.jsxs("span", {
                    className: "min-w-0 flex-1 truncate",
                    children: [
                      e.jsx("strong", { children: y.name }),
                      e.jsxs("span", {
                        className: "ml-2 text-xs text-muted-foreground",
                        children: [
                          de(y.sizeBytes),
                          ", ",
                          new Date(y.updatedAt).toLocaleDateString(),
                        ],
                      }),
                    ],
                  }),
                  e.jsxs(T, {
                    size: "sm",
                    variant: "outline",
                    disabled: h !== null,
                    onClick: () => {
                      w(y.id);
                    },
                    children: [
                      h === y.id
                        ? e.jsx(ee, {
                            className: "h-3.5 w-3.5 mr-1 animate-spin",
                          })
                        : e.jsx(Be, { className: "h-3.5 w-3.5 mr-1" }),
                      "Open",
                    ],
                  }),
                  e.jsx(T, {
                    size: "sm",
                    variant: "ghost",
                    "aria-label": `Delete ${y.name}`,
                    disabled: h !== null,
                    onClick: () => {
                      D(y.id, y.name);
                    },
                    children: e.jsx(ue, { className: "h-3.5 w-3.5" }),
                  }),
                ],
              },
              y.id,
            ),
          ),
        }),
      e.jsx("p", {
        className: "mt-3 text-xs text-muted-foreground",
        children:
          "Kept for as long as your Event Suite plan runs. If it ends, saved projects are erased, so download a copy first with Save project.",
      }),
    ],
  });
}
const je = () => ({
  venue: "",
  address: "",
  mapUrl: "",
  notes: "",
  announcements: [],
});
function Ze(t, s) {
  const i = [...t.data.sessions].sort((o, d) =>
      `${o.day} ${o.start}`.localeCompare(`${d.day} ${d.start}`),
    ),
    a = i[0],
    n = i[i.length - 1];
  return {
    event: {
      name: t.name,
      timeZone: t.timeZone,
      startsAt: a ? `${a.day} ${a.start}` : "",
      endsAt: n ? `${n.day} ${n.end || n.start}` : "",
      venue: s.venue,
      address: s.address,
      mapUrl: s.mapUrl,
      notes: s.notes,
    },
    programme: i.map((o) => ({
      id: o.id,
      time: o.end ? `${o.day} ${o.start}-${o.end}` : `${o.day} ${o.start}`,
      title: o.title,
      room: o.room ?? "",
      speaker: o.presenter ?? "",
      note: o.notes ?? "",
    })),
    announcements: s.announcements.filter((o) => o.text.trim()),
    guests: t.data.guests.map((o) => ({
      id: o.id,
      name: o.name,
      ticket: o.table
        ? /^Table \d/.test(te(o.table))
          ? te(o.table)
          : `Table ${o.table}`
        : (o.role ?? ""),
      status: o.status,
    })),
    passKey: t.passKey,
  };
}
const Xe = (t, s, i) => `${t}/apps/${s}/${i}`,
  Je = !0,
  J = "w-full rounded-md border bg-background px-3 py-2 text-sm",
  et = { guest: "Guest app", door: "Door Check app", booth: "Booth Leads app" },
  tt = {
    guest:
      "Anyone with this link can see the programme, venue and announcements. They cannot see the guest list.",
    door: "Give this only to door staff. It shows the guest list and lets them check guests in.",
    booth:
      "One link per exhibitor. Leads captured with it belong to that exhibitor. You see only the count.",
  },
  st = (t) => `fdp-live-${t.slice(0, 12)}`;
function at({ text: t }) {
  const [s, i] = S.useState("");
  return (
    S.useEffect(() => {
      let a = !0;
      return (
        Re.toDataURL(t, { margin: 1, width: 160 })
          .then((n) => {
            a && i(n);
          })
          .catch(() => {}),
        () => {
          a = !1;
        }
      );
    }, [t]),
    s
      ? e.jsx("img", {
          src: s,
          alt: "QR code for this link",
          width: 96,
          height: 96,
          className: "rounded border bg-white",
        })
      : e.jsx("div", { className: "h-24 w-24" })
  );
}
function nt() {
  const [t] = oe(),
    s = M.useUtils(),
    i = M.eventSuite.live.list.useQuery(void 0, { retry: !1 }),
    a = M.eventSuite.live.publish.useMutation(),
    n = M.eventSuite.live.addLink.useMutation(),
    o = M.eventSuite.live.revokeLink.useMutation(),
    d = M.eventSuite.live.rotateLink.useMutation(),
    u = M.eventSuite.live.remove.useMutation(),
    [h, l] = S.useState(null),
    [f, g] = S.useState(je()),
    [k, w] = S.useState(""),
    [D, b] = S.useState(!1),
    E = st(t.passKey);
  S.useEffect(() => {
    try {
      l(localStorage.getItem(E));
    } catch {
      l(null);
    }
  }, [E]);
  const y = i.data?.events.find((x) => x.id === h) ?? null,
    C = M.eventSuite.live.detail.useQuery(
      { eventId: y?.id ?? "" },
      { enabled: !!y, retry: !1 },
    ),
    N = M.eventSuite.live.open.useQuery(
      { eventId: y?.id ?? "" },
      { enabled: !!y, retry: !1 },
    );
  if (
    (S.useEffect(() => {
      if (!N.data) return;
      const x = N.data.event;
      g({
        venue: x.venue,
        address: x.address,
        mapUrl: x.mapUrl,
        notes: x.notes,
        announcements: N.data.announcements,
      });
    }, [N.data]),
    i.isError)
  )
    return null;
  const U = typeof window < "u" ? window.location.origin : "",
    v = async () => {
      await Promise.all([
        s.eventSuite.live.list.invalidate(),
        s.eventSuite.live.detail.invalidate(),
        s.eventSuite.live.open.invalidate(),
        s.eventSuite.storage.list.invalidate(),
      ]);
    },
    O = async (x, r) => {
      b(!0);
      try {
        (await x(), await v(), r && L.success(r));
      } catch (I) {
        L.error(
          I instanceof Error
            ? I.message
            : "Something went wrong. Please try again.",
        );
      } finally {
        b(!1);
      }
    },
    Q = () =>
      O(
        async () => {
          const x = await a.mutateAsync({ eventId: y?.id, snapshot: Ze(t, f) });
          try {
            localStorage.setItem(E, x.eventId);
          } catch {}
          l(x.eventId);
        },
        y
          ? "Updated. The apps show the change within a minute."
          : "Published. Share the links below.",
      ),
    W = (x) => {
      navigator.clipboard?.writeText(x).then(
        () => L.success("Link copied"),
        () => L.error("Could not copy. Select the link and copy it."),
      );
    },
    _ = (x) => g((r) => ({ ...r, ...x })),
    q = C.data?.links.filter((x) => !x.revoked) ?? [];
  return e.jsxs("section", {
    className: "mt-3 rounded-lg border bg-card p-4 text-sm",
    "data-testid": "publish-event",
    children: [
      e.jsxs("div", {
        className: "flex flex-wrap items-center gap-2",
        children: [
          e.jsxs("h3", {
            className: "font-semibold flex items-center gap-1",
            children: [e.jsx(Te, { className: "h-4 w-4" }), "Event apps"],
          }),
          e.jsx("span", {
            className: "text-xs text-muted-foreground",
            children:
              "Publish this project to the Guest, Door Check and Booth Leads apps.",
          }),
        ],
      }),
      e.jsxs("div", {
        className: "mt-3 grid gap-2 sm:grid-cols-2",
        children: [
          e.jsxs("label", {
            className: "text-xs",
            children: [
              "Venue",
              e.jsx("input", {
                className: J,
                value: f.venue,
                maxLength: 160,
                onChange: (x) => _({ venue: x.target.value }),
              }),
            ],
          }),
          e.jsxs("label", {
            className: "text-xs",
            children: [
              "Address",
              e.jsx("input", {
                className: J,
                value: f.address,
                maxLength: 240,
                onChange: (x) => _({ address: x.target.value }),
              }),
            ],
          }),
          e.jsxs("label", {
            className: "text-xs",
            children: [
              "Map link (https)",
              e.jsx("input", {
                className: J,
                value: f.mapUrl,
                maxLength: 500,
                onChange: (x) => _({ mapUrl: x.target.value }),
              }),
            ],
          }),
          e.jsxs("label", {
            className: "text-xs",
            children: [
              "Notes for guests",
              e.jsx("input", {
                className: J,
                value: f.notes,
                maxLength: 1e3,
                onChange: (x) => _({ notes: x.target.value }),
              }),
            ],
          }),
        ],
      }),
      e.jsxs("div", {
        className: "mt-3",
        children: [
          e.jsx("div", {
            className: "text-xs font-medium",
            children: "Announcements",
          }),
          f.announcements.map((x, r) =>
            e.jsxs(
              "div",
              {
                className: "mt-1 flex gap-2",
                children: [
                  e.jsx("input", {
                    className: J,
                    value: x.text,
                    maxLength: 600,
                    placeholder: "Short message for guests",
                    onChange: (I) =>
                      _({
                        announcements: f.announcements.map((F, X) =>
                          X === r ? { ...F, text: I.target.value } : F,
                        ),
                      }),
                  }),
                  e.jsx(T, {
                    size: "sm",
                    variant: "ghost",
                    "aria-label": "Remove announcement",
                    onClick: () =>
                      _({
                        announcements: f.announcements.filter(
                          (I, F) => F !== r,
                        ),
                      }),
                    children: e.jsx(ue, { className: "h-3.5 w-3.5" }),
                  }),
                ],
              },
              x.id,
            ),
          ),
          f.announcements.length < 20 &&
            e.jsx(T, {
              size: "sm",
              variant: "outline",
              className: "mt-1",
              onClick: () =>
                _({
                  announcements: [
                    ...f.announcements,
                    {
                      id: `a${Date.now().toString(36)}`,
                      at: new Date().toISOString(),
                      text: "",
                    },
                  ],
                }),
              children: "Add announcement",
            }),
        ],
      }),
      e.jsxs("div", {
        className: "mt-3 flex flex-wrap items-center gap-2",
        children: [
          e.jsxs(T, {
            size: "sm",
            onClick: () => {
              Q();
            },
            disabled: D,
            "data-testid": "publish-go",
            children: [
              D
                ? e.jsx(ee, { className: "h-3.5 w-3.5 mr-1 animate-spin" })
                : e.jsx(Pe, { className: "h-3.5 w-3.5 mr-1" }),
              y ? "Update published event" : "Publish event",
            ],
          }),
          y &&
            e.jsxs("span", {
              className: "text-xs text-muted-foreground",
              children: [
                "Version ",
                y.version,
                ", ",
                Math.max(1, Math.round(y.sizeBytes / 1e3)),
                " KB",
              ],
            }),
          y &&
            e.jsxs(T, {
              size: "sm",
              variant: "ghost",
              className: "ml-auto",
              disabled: D,
              onClick: () => {
                window.confirm(
                  "Delete this published event? The links stop working and its check-ins and booth leads are erased. This cannot be undone.",
                ) &&
                  O(async () => {
                    await u.mutateAsync({ eventId: y.id });
                    try {
                      localStorage.removeItem(E);
                    } catch {}
                    (l(null), g(je()));
                  }, "Published event deleted");
              },
              children: [
                e.jsx(ue, { className: "h-3.5 w-3.5 mr-1" }),
                "Delete",
              ],
            }),
        ],
      }),
      e.jsx("p", {
        className: "mt-2 text-xs text-muted-foreground",
        children:
          "Publishing sends the programme and venue, and guest names with their status (no emails, phone numbers or dietary details). Door staff links also carry the key that checks passes.",
      }),
      y &&
        C.data &&
        e.jsxs("div", {
          className: "mt-4",
          children: [
            e.jsxs("div", {
              className: "text-xs text-muted-foreground",
              children: [C.data.checkedIn, " checked in so far."],
            }),
            e.jsx("ul", {
              className: "mt-2 space-y-3",
              children: q.map((x) => {
                const r = Xe(U, x.role, x.token);
                return e.jsxs(
                  "li",
                  {
                    className: "flex gap-3 rounded-md border p-3",
                    children: [
                      e.jsx(at, { text: r }),
                      e.jsxs("div", {
                        className: "min-w-0 flex-1",
                        children: [
                          e.jsxs("div", {
                            className: "font-medium",
                            children: [
                              et[x.role],
                              x.label ? `: ${x.label}` : "",
                              x.leads !== null &&
                                e.jsxs("span", {
                                  className:
                                    "ml-2 text-xs font-normal text-muted-foreground",
                                  children: [
                                    x.leads,
                                    " lead",
                                    x.leads === 1 ? "" : "s",
                                  ],
                                }),
                            ],
                          }),
                          e.jsx("div", {
                            className: "text-xs text-muted-foreground",
                            children: tt[x.role],
                          }),
                          e.jsx("div", {
                            className: "mt-1 break-all text-xs",
                            children: r,
                          }),
                          e.jsxs("div", {
                            className: "mt-2 flex flex-wrap gap-2",
                            children: [
                              e.jsxs(T, {
                                size: "sm",
                                variant: "outline",
                                onClick: () => W(r),
                                children: [
                                  e.jsx(Oe, { className: "h-3.5 w-3.5 mr-1" }),
                                  "Copy link",
                                ],
                              }),
                              e.jsx(T, {
                                size: "sm",
                                variant: "outline",
                                disabled: D,
                                onClick: () => {
                                  window.confirm(
                                    "Replace this link? The old one stops working and everyone who has it needs the new one.",
                                  ) &&
                                    O(
                                      () => d.mutateAsync({ token: x.token }),
                                      "New link made",
                                    );
                                },
                                children: "Replace link",
                              }),
                              e.jsx(T, {
                                size: "sm",
                                variant: "ghost",
                                disabled: D,
                                onClick: () => {
                                  window.confirm(
                                    "Stop this link now? Nobody can use it again.",
                                  ) &&
                                    O(
                                      () => o.mutateAsync({ token: x.token }),
                                      "Link stopped",
                                    );
                                },
                                children: "Stop link",
                              }),
                            ],
                          }),
                        ],
                      }),
                    ],
                  },
                  x.token,
                );
              }),
            }),
            e.jsxs("div", {
              className: "mt-3 flex flex-wrap gap-2",
              children: [
                e.jsx("input", {
                  className: `${J} max-w-xs`,
                  value: k,
                  maxLength: 80,
                  placeholder: "Exhibitor or booth name",
                  onChange: (x) => w(x.target.value),
                }),
                e.jsx(T, {
                  size: "sm",
                  variant: "outline",
                  disabled: D || !k.trim(),
                  onClick: () => {
                    O(async () => {
                      (await n.mutateAsync({
                        eventId: y.id,
                        role: "booth",
                        label: k,
                      }),
                        w(""));
                    }, "Booth link added");
                  },
                  children: "Add booth link",
                }),
                e.jsx(T, {
                  size: "sm",
                  variant: "outline",
                  disabled: D,
                  onClick: () => {
                    O(
                      () => n.mutateAsync({ eventId: y.id, role: "door" }),
                      "Door link added",
                    );
                  },
                  children: "Add door link",
                }),
              ],
            }),
          ],
        }),
      e.jsx("p", {
        className: "mt-3 text-xs text-muted-foreground",
        children:
          "Kept until you delete it or your Event Suite Premium plan ends. It counts toward your 1 GB.",
      }),
    ],
  });
}
const re = "w-full rounded-md border bg-background px-3 py-2 text-sm",
  we = (t) =>
    new Date(t).toLocaleString(void 0, {
      dateStyle: "medium",
      timeStyle: "short",
    });
function ot() {
  const [t] = oe(),
    s = M.useUtils(),
    i = M.eventSuite.mail.status.useQuery(void 0, { retry: !1 }),
    a = M.eventSuite.mail.send.useMutation(),
    n = M.eventSuite.mail.cancel.useMutation(),
    o = M.eventSuite.mail.prepareAttachments.useMutation(),
    d = S.useRef(null),
    [u, h] = S.useState([]),
    [l, f] = S.useState(""),
    [g, k] = S.useState(!1),
    [w, D] = S.useState("all"),
    [b, E] = S.useState(""),
    [y, C] = S.useState(`Dear {name},

You are invited to our event. Please reply to this email to let us know if you can come.

We hope to see you there.`),
    [N, U] = S.useState(!1),
    [v, O] = S.useState(""),
    [Q, W] = S.useState(!1),
    [_, q] = S.useState(!0),
    x = M.eventSuite.text.responses.useQuery(
      { eventName: t.name },
      { retry: !1 },
    ),
    r = S.useMemo(
      () => t.data.guests.filter((c) => !!c.email?.trim()),
      [t.data.guests],
    ),
    I = S.useMemo(
      () =>
        new Set(
          (x.data ?? [])
            .filter((c) => c.status === "accepted" && c.channel === "email")
            .map((c) => c.email.toLowerCase()),
        ),
      [x.data],
    ),
    F = S.useMemo(
      () =>
        w === "all"
          ? r
          : w === "rsvp-email"
            ? r.filter((c) => I.has((c.email ?? "").trim().toLowerCase()))
            : r.filter((c) => c.status === w),
      [r, w, I],
    ),
    X = i.data ? i.data.dailyLimit - i.data.sentLast24h : null;
  if (i.isError) return null;
  const m = i.data?.maxAttachments ?? 3,
    p = i.data?.maxAttachmentBytes ?? 1e7,
    $ = u.reduce((c, j) => c + j.size, 0),
    A = (c) => {
      if (!c) return;
      const j = [...u, ...Array.from(c)];
      (j.length > m
        ? L.error(`Attach at most ${m} files.`)
        : j.reduce((z, R) => z + R.size, 0) > p
          ? L.error(`Attachments can total at most ${Math.round(p / 1e6)} MB.`)
          : h(j),
        d.current && (d.current.value = ""));
    },
    P = async () => {
      k(!0);
      try {
        let c;
        if (u.length) {
          const H = await o.mutateAsync({
            files: u.map((K) => ({ name: K.name, sizeBytes: K.size })),
          });
          ((c = H.mailId),
            await Promise.all(
              H.uploads.map(async (K, Z) => {
                if (
                  !(
                    await fetch(K.url, {
                      method: "PUT",
                      headers: { "Content-Type": "application/octet-stream" },
                      body: u[Z],
                    })
                  ).ok
                )
                  throw new Error(
                    `Could not upload ${u[Z].name}. Please try again.`,
                  );
              }),
            ));
        }
        const j = await a.mutateAsync({
            mailId: c,
            attachments: u.length
              ? u.map((H) => ({ name: H.name, sizeBytes: H.size }))
              : void 0,
            replyTo: l.trim() || void 0,
            rsvp: _,
            subject: b,
            body: y,
            eventName: t.name,
            recipients: F.map((H) => ({ name: H.name, email: H.email })),
            sendAt: N && v ? new Date(v).toISOString() : null,
            confirmedPermission: !0,
          }),
          z = j.skipped.invalid + j.skipped.duplicates + j.skipped.optedOut,
          R = z ? ` ${z} skipped (invalid, repeated or unsubscribed).` : "";
        (j.queued
          ? L.success(
              `Sending to ${j.count} guest${j.count === 1 ? "" : "s"} now. With attachments this takes a minute or two.${R}`,
            )
          : j.scheduled
            ? L.success(
                `Scheduled for ${j.count} guest${j.count === 1 ? "" : "s"}.${R}`,
              )
            : j.failed
              ? L.error(`${j.sent} sent, ${j.failed} could not be sent.${R}`)
              : L.success(
                  `Sent to ${j.sent} guest${j.sent === 1 ? "" : "s"}.${R}`,
                ),
          W(!1),
          h([]),
          await s.eventSuite.mail.status.invalidate());
      } catch (c) {
        L.error(
          c instanceof Error ? c.message : "Could not send. Please try again.",
        );
      } finally {
        k(!1);
      }
    },
    B =
      F.length > 0 &&
      b.trim().length >= 3 &&
      y.trim().length >= 10 &&
      Q &&
      (!N || !!v) &&
      !g;
  return e.jsxs("section", {
    className: "mt-3 rounded-lg border bg-card p-4 text-sm",
    "data-testid": "email-guests",
    children: [
      e.jsxs("div", {
        className: "flex flex-wrap items-center gap-2",
        children: [
          e.jsxs("h3", {
            className: "flex items-center gap-2 font-semibold",
            children: [
              e.jsx(xe, { className: "h-4 w-4", "aria-hidden": !0 }),
              "Email your guests",
            ],
          }),
          X !== null &&
            e.jsxs("span", {
              className: "text-xs text-muted-foreground",
              children: [
                X,
                " of ",
                i.data.dailyLimit,
                " emails left in the last 24 hours",
              ],
            }),
        ],
      }),
      e.jsxs("label", {
        className: "mt-3 block",
        children: [
          e.jsx("span", {
            className: "text-xs text-muted-foreground",
            children: "Guests' replies come to",
          }),
          e.jsx("input", {
            className: re,
            type: "email",
            value: l,
            onChange: (c) => f(c.target.value),
            placeholder: i.data?.replyTo || "your email",
            "data-testid": "email-reply-to",
          }),
        ],
      }),
      e.jsxs("div", {
        className: "mt-3 grid gap-3 sm:grid-cols-2",
        children: [
          e.jsxs("label", {
            className: "block",
            children: [
              e.jsx("span", {
                className: "text-xs text-muted-foreground",
                children: "Send to",
              }),
              e.jsxs("select", {
                className: re,
                value: w,
                onChange: (c) => D(c.target.value),
                "data-testid": "email-audience",
                children: [
                  e.jsxs("option", {
                    value: "all",
                    children: ["All guests with an email (", r.length, ")"],
                  }),
                  e.jsxs("option", {
                    value: "rsvp-email",
                    children: [
                      "Chose email reminders (",
                      r.filter((c) =>
                        I.has((c.email ?? "").trim().toLowerCase()),
                      ).length,
                      ")",
                    ],
                  }),
                  Ue.map((c) =>
                    e.jsxs(
                      "option",
                      {
                        value: c,
                        children: [
                          c[0].toUpperCase() + c.slice(1),
                          " (",
                          r.filter((j) => j.status === c).length,
                          ")",
                        ],
                      },
                      c,
                    ),
                  ),
                ],
              }),
            ],
          }),
          e.jsxs("label", {
            className: "block",
            children: [
              e.jsx("span", {
                className: "text-xs text-muted-foreground",
                children: "Subject",
              }),
              e.jsx("input", {
                className: re,
                value: b,
                maxLength: 150,
                onChange: (c) => E(c.target.value),
                placeholder: "You are invited",
                "data-testid": "email-subject",
              }),
            ],
          }),
        ],
      }),
      e.jsxs("label", {
        className: "mt-3 block",
        children: [
          e.jsxs("span", {
            className: "text-xs text-muted-foreground",
            children: [
              "Message. ",
              "{name}",
              " becomes each guest's first name.",
            ],
          }),
          e.jsx("textarea", {
            className: `${re} min-h-[140px]`,
            value: y,
            maxLength: 5e3,
            onChange: (c) => C(c.target.value),
            "data-testid": "email-body",
          }),
        ],
      }),
      e.jsxs("label", {
        className: "mt-3 flex items-start gap-2 text-xs",
        children: [
          e.jsx("input", {
            type: "checkbox",
            className: "mt-0.5",
            checked: _,
            onChange: (c) => q(c.target.checked),
            "data-testid": "email-rsvp",
          }),
          e.jsxs("span", {
            children: [
              "Add a personal RSVP link for each guest. They can accept or decline and choose email or text reminders. Put ",
              "{rsvp}",
              " in the message where the link should go, or it is added at the end.",
            ],
          }),
        ],
      }),
      e.jsxs("div", {
        className: "mt-3 flex flex-wrap items-center gap-2",
        children: [
          e.jsx("input", {
            ref: d,
            type: "file",
            multiple: !0,
            className: "hidden",
            onChange: (c) => A(c.target.files),
            "data-testid": "email-files",
          }),
          e.jsxs(T, {
            size: "sm",
            variant: "outline",
            type: "button",
            onClick: () => d.current?.click(),
            disabled: u.length >= m,
            children: [
              e.jsx(fe, { className: "h-3.5 w-3.5 mr-1" }),
              "Attach files",
            ],
          }),
          e.jsxs("span", {
            className: "text-xs text-muted-foreground",
            children: [
              "Up to ",
              m,
              " files, ",
              Math.round(p / 1e6),
              " MB in total. Every guest gets the same files.",
            ],
          }),
        ],
      }),
      u.length > 0 &&
        e.jsxs("ul", {
          className: "mt-2 text-xs",
          "data-testid": "email-file-list",
          children: [
            u.map((c, j) =>
              e.jsxs(
                "li",
                {
                  className: "flex items-center gap-2 py-0.5",
                  children: [
                    e.jsx(fe, {
                      className: "h-3 w-3 text-muted-foreground",
                      "aria-hidden": !0,
                    }),
                    e.jsx("span", {
                      className: "min-w-0 flex-1 truncate",
                      children: c.name,
                    }),
                    e.jsxs("span", {
                      className: "text-muted-foreground",
                      children: [(c.size / 1e6).toFixed(2), " MB"],
                    }),
                    e.jsx("button", {
                      type: "button",
                      "aria-label": `Remove ${c.name}`,
                      onClick: () => h(u.filter((z, R) => R !== j)),
                      children: e.jsx(me, { className: "h-3 w-3" }),
                    }),
                  ],
                },
                `${c.name}-${j}`,
              ),
            ),
            e.jsxs("li", {
              className: "text-muted-foreground",
              children: ["Total ", ($ / 1e6).toFixed(2), " MB"],
            }),
          ],
        }),
      e.jsxs("div", {
        className: "mt-3 flex flex-wrap items-center gap-3",
        children: [
          e.jsxs("label", {
            className: "flex items-center gap-2",
            children: [
              e.jsx("input", {
                type: "radio",
                checked: !N,
                onChange: () => U(!1),
              }),
              "Send now",
            ],
          }),
          e.jsxs("label", {
            className: "flex items-center gap-2",
            children: [
              e.jsx("input", {
                type: "radio",
                checked: N,
                onChange: () => U(!0),
              }),
              "Send later (a reminder)",
            ],
          }),
          N &&
            e.jsx("input", {
              type: "datetime-local",
              className: "rounded-md border bg-background px-2 py-1",
              value: v,
              onChange: (c) => O(c.target.value),
              "data-testid": "email-send-at",
            }),
        ],
      }),
      e.jsxs("label", {
        className: "mt-3 flex items-start gap-2 text-xs text-muted-foreground",
        children: [
          e.jsx("input", {
            type: "checkbox",
            className: "mt-0.5",
            checked: Q,
            onChange: (c) => W(c.target.checked),
            "data-testid": "email-permission",
          }),
          e.jsx("span", {
            children:
              "I have permission to email these guests about this event. Replies come to the email address above, and every message has an unsubscribe link.",
          }),
        ],
      }),
      e.jsxs("div", {
        className: "mt-3 flex items-center gap-3",
        children: [
          e.jsxs(T, {
            size: "sm",
            onClick: () => {
              P();
            },
            disabled: !B,
            "data-testid": "email-send",
            children: [
              g
                ? e.jsx(ee, { className: "h-3.5 w-3.5 mr-1 animate-spin" })
                : e.jsx(xe, { className: "h-3.5 w-3.5 mr-1" }),
              N ? "Schedule" : "Send",
              " to ",
              F.length,
              " guest",
              F.length === 1 ? "" : "s",
            ],
          }),
          r.length === 0 &&
            e.jsx("span", {
              className: "text-xs text-muted-foreground",
              children:
                "Add guests with email addresses in Guest Manager first.",
            }),
        ],
      }),
      i.data &&
        i.data.scheduled.length > 0 &&
        e.jsxs("div", {
          className: "mt-4",
          children: [
            e.jsx("h4", {
              className:
                "text-xs font-semibold uppercase tracking-wide text-muted-foreground",
              children: "Scheduled",
            }),
            e.jsx("ul", {
              className: "mt-1 divide-y",
              children: i.data.scheduled.map((c) =>
                e.jsxs(
                  "li",
                  {
                    className: "flex items-center gap-2 py-1.5",
                    children: [
                      e.jsxs("span", {
                        className: "min-w-0 flex-1 truncate",
                        children: [
                          e.jsx("strong", { children: c.subject }),
                          e.jsxs("span", {
                            className: "ml-2 text-xs text-muted-foreground",
                            children: [
                              c.recipientCount,
                              " guests, ",
                              we(c.sendAt),
                            ],
                          }),
                        ],
                      }),
                      e.jsx(T, {
                        size: "sm",
                        variant: "ghost",
                        "aria-label": `Cancel ${c.subject}`,
                        onClick: async () => {
                          (await n.mutateAsync({ id: c.id }),
                            await s.eventSuite.mail.status.invalidate());
                        },
                        children: e.jsx(me, { className: "h-3.5 w-3.5" }),
                      }),
                    ],
                  },
                  c.id,
                ),
              ),
            }),
          ],
        }),
      i.data &&
        i.data.recent.length > 0 &&
        e.jsxs("div", {
          className: "mt-4",
          children: [
            e.jsx("h4", {
              className:
                "text-xs font-semibold uppercase tracking-wide text-muted-foreground",
              children: "Recently sent",
            }),
            e.jsx("ul", {
              className: "mt-1 text-xs text-muted-foreground",
              children: i.data.recent.map((c) =>
                e.jsxs(
                  "li",
                  {
                    children: [
                      c.subject,
                      ": ",
                      c.status === "sent"
                        ? `${c.sentCount} sent`
                        : "could not be sent",
                      ", ",
                      we(c.at),
                    ],
                  },
                  c.id,
                ),
              ),
            }),
          ],
        }),
      e.jsx("p", {
        className: "mt-3 text-xs text-muted-foreground",
        children:
          "We keep the guest list and any attachments only until the message has been sent. Reminders are sent within a minute of the time you choose.",
      }),
    ],
  });
}
function it(t, s) {
  const i = new Map(s.map((o) => [o.email.trim().toLowerCase(), o.status]));
  let a = 0;
  return {
    guests: t.map((o) => {
      const d = o.email ? i.get(o.email.trim().toLowerCase()) : void 0;
      if (!d || d === "pending" || o.status === "attended") return o;
      const u = d === "accepted" ? "confirmed" : "declined";
      return o.status === u ? o : (a++, { ...o, status: u });
    }),
    changed: a,
  };
}
const se = "w-full rounded-md border bg-background px-3 py-2 text-sm",
  be = (t) =>
    new Date(t).toLocaleString(void 0, {
      dateStyle: "medium",
      timeStyle: "short",
    });
function rt() {
  const [t, s] = oe(),
    i = M.useUtils(),
    a = M.eventSuite.text.status.useQuery({ eventName: t.name }, { retry: !1 }),
    n = M.eventSuite.text.responses.useQuery(
      { eventName: t.name },
      { retry: !1 },
    ),
    o = M.eventSuite.text.connect.useMutation(),
    d = M.eventSuite.text.disconnect.useMutation(),
    u = M.eventSuite.text.send.useMutation(),
    h = M.eventSuite.text.cancel.useMutation(),
    [l, f] = S.useState({
      accountSid: "",
      apiKeySid: "",
      apiKeySecret: "",
      phone: "",
    }),
    [g, k] = S.useState(
      "Dear {name}, a reminder that our event is coming up. We look forward to seeing you.",
    ),
    [w, D] = S.useState("us"),
    [b, E] = S.useState(!1),
    [y, C] = S.useState(""),
    [N, U] = S.useState(!1),
    v = a.data,
    O = S.useMemo(
      () => `${g.replace(/\{name\}/gi, "Ann")} Reply STOP to opt out.`,
      [g],
    );
  if (a.isError || !v) return null;
  const Q = () => {
      const r = it(
        t.data.guests,
        (n.data ?? []).map((I) => ({ email: I.email, status: I.status })),
      );
      (r.changed && s.setRecords("guests", r.guests),
        L.success(
          r.changed
            ? `Updated ${r.changed} guest${r.changed === 1 ? "" : "s"} in your guest list.`
            : "Your guest list already matches their answers.",
        ));
    },
    W = async () => {
      try {
        const r = await o.mutateAsync(l);
        (L.success(`Connected ${r.phone}.`),
          f({ accountSid: "", apiKeySid: "", apiKeySecret: "", phone: "" }),
          await i.eventSuite.text.status.invalidate());
      } catch (r) {
        L.error(
          r instanceof Error
            ? r.message
            : "Could not connect. Please try again.",
        );
      }
    },
    _ = async () => {
      window.confirm(
        "Disconnect your Twilio number? We delete your stored key and cancel waiting texts.",
      ) &&
        (await d.mutateAsync(),
        await i.eventSuite.text.status.invalidate(),
        L.success(
          "Disconnected. Your key has been deleted from FreeDailyPro.",
        ));
    },
    q = async () => {
      try {
        const r = await u.mutateAsync({
          eventName: t.name,
          text: g,
          zone: w,
          sendAt: b && y ? new Date(y).toISOString() : null,
        });
        (L.success(
          r.scheduled
            ? `Scheduled for ${r.count} guest${r.count === 1 ? "" : "s"}.`
            : `Sending to ${r.count} guest${r.count === 1 ? "" : "s"}. It starts within a minute and takes about a second per guest.`,
        ),
          await i.eventSuite.text.status.invalidate());
      } catch (r) {
        L.error(
          r instanceof Error ? r.message : "Could not send. Please try again.",
        );
      }
    },
    x =
      !!v.connection &&
      v.counts.byText > 0 &&
      g.trim().length >= 5 &&
      g.length <= v.maxChars &&
      (!b || !!y) &&
      !u.isPending;
  return e.jsxs("section", {
    className: "mt-3 rounded-lg border bg-card p-4 text-sm",
    "data-testid": "text-reminders",
    children: [
      e.jsxs("h3", {
        className: "flex items-center gap-2 font-semibold",
        children: [
          e.jsx(ge, { className: "h-4 w-4", "aria-hidden": !0 }),
          "RSVP answers and text reminders",
        ],
      }),
      e.jsx("p", {
        className: "mt-2 text-xs text-muted-foreground",
        "data-testid": "rsvp-counts",
        children:
          v.counts.invited === 0
            ? "Send an invitation with the RSVP link switched on. Guests' answers appear here."
            : `${v.counts.invited} invited: ${v.counts.accepted} coming, ${v.counts.declined} not coming, ${v.counts.waiting} not answered. ${v.counts.byText} chose text reminders and ${v.counts.byEmail} chose email.`,
      }),
      v.counts.invited > 0 &&
        e.jsx(T, {
          size: "sm",
          variant: "outline",
          className: "mt-2",
          onClick: Q,
          "data-testid": "rsvp-apply",
          children: "Update my guest list from their answers",
        }),
      e.jsxs("div", {
        className: "mt-4 border-t pt-3",
        children: [
          e.jsx("h4", {
            className:
              "text-xs font-semibold uppercase tracking-wide text-muted-foreground",
            children: "Your Twilio number",
          }),
          v.ready
            ? v.connection
              ? e.jsxs("div", {
                  className: "mt-1 flex flex-wrap items-center gap-3",
                  children: [
                    e.jsxs("span", {
                      children: [
                        "Connected: ",
                        e.jsx("strong", { children: v.connection.phone }),
                        " (account ending ",
                        v.connection.accountEnd,
                        ")",
                      ],
                    }),
                    e.jsx(T, {
                      size: "sm",
                      variant: "ghost",
                      onClick: () => {
                        _();
                      },
                      "data-testid": "text-disconnect",
                      children: "Disconnect",
                    }),
                  ],
                })
              : e.jsxs("div", {
                  className: "mt-1",
                  children: [
                    e.jsx("p", {
                      className: "text-xs text-muted-foreground",
                      children:
                        "Texts are sent from your own Twilio number, so Twilio bills you and approves your messages. FreeDailyPro never sees your Twilio password or Auth Token.",
                    }),
                    e.jsx("p", {
                      className: "text-xs text-muted-foreground",
                      children:
                        "You are the sender: only invite people who expect to hear from you. Guests choose text themselves on the RSVP page and can reply STOP at any time. See the Terms of Service for details.",
                    }),
                    e.jsxs("button", {
                      type: "button",
                      className: "mt-1 text-xs underline",
                      onClick: () => U(!N),
                      children: [N ? "Hide" : "Show", " the setup steps"],
                    }),
                    N &&
                      e.jsxs("ol", {
                        className:
                          "mt-2 list-decimal space-y-1 pl-5 text-xs text-muted-foreground",
                        "data-testid": "text-help",
                        children: [
                          e.jsx("li", {
                            children:
                              "Create an account at twilio.com and buy a phone number that can send text messages.",
                          }),
                          e.jsx("li", {
                            children:
                              "Register that number for US messaging in Twilio (called A2P 10DLC, or toll-free verification). Twilio walks you through it. Until it is approved, US carriers may block your texts.",
                          }),
                          e.jsxs("li", {
                            children: [
                              "In the Twilio Console, create an API key of the ",
                              e.jsx("strong", { children: "Standard" }),
                              " type. Copy its SID (starts with SK) and its secret.",
                            ],
                          }),
                          e.jsxs("li", {
                            children: [
                              "Copy your Account SID (starts with AC) from the Console home page. Do ",
                              e.jsx("strong", { children: "not" }),
                              " use your Auth Token.",
                            ],
                          }),
                          e.jsx("li", {
                            children:
                              "Paste the four details below. We keep the secret encrypted, only to send your texts, and delete it when you disconnect or your plan ends.",
                          }),
                        ],
                      }),
                    e.jsxs("div", {
                      className: "mt-2 grid gap-2 sm:grid-cols-2",
                      children: [
                        e.jsx("input", {
                          className: se,
                          placeholder: "Account SID (AC...)",
                          value: l.accountSid,
                          onChange: (r) =>
                            f({ ...l, accountSid: r.target.value }),
                          autoComplete: "off",
                          "data-testid": "twilio-account",
                        }),
                        e.jsx("input", {
                          className: se,
                          placeholder: "Twilio phone number, +1 555 123 4567",
                          value: l.phone,
                          onChange: (r) => f({ ...l, phone: r.target.value }),
                          autoComplete: "off",
                          "data-testid": "twilio-phone",
                        }),
                        e.jsx("input", {
                          className: se,
                          placeholder: "API key SID (SK...)",
                          value: l.apiKeySid,
                          onChange: (r) =>
                            f({ ...l, apiKeySid: r.target.value }),
                          autoComplete: "off",
                          "data-testid": "twilio-key",
                        }),
                        e.jsx("input", {
                          className: se,
                          type: "password",
                          placeholder: "API key secret",
                          value: l.apiKeySecret,
                          onChange: (r) =>
                            f({ ...l, apiKeySecret: r.target.value }),
                          autoComplete: "new-password",
                          "data-testid": "twilio-secret",
                        }),
                      ],
                    }),
                    e.jsxs(T, {
                      size: "sm",
                      className: "mt-2",
                      onClick: () => {
                        W();
                      },
                      disabled:
                        o.isPending ||
                        !l.accountSid ||
                        !l.apiKeySid ||
                        !l.apiKeySecret ||
                        !l.phone,
                      "data-testid": "twilio-connect",
                      children: [
                        o.isPending &&
                          e.jsx(ee, {
                            className: "h-3.5 w-3.5 mr-1 animate-spin",
                          }),
                        "Connect my number",
                      ],
                    }),
                  ],
                })
            : e.jsx("p", {
                className: "mt-1 text-xs text-muted-foreground",
                children:
                  "Text reminders are not switched on yet. Email reminders work now.",
              }),
        ],
      }),
      v.connection &&
        e.jsxs("div", {
          className: "mt-4 border-t pt-3",
          children: [
            e.jsxs("h4", {
              className:
                "text-xs font-semibold uppercase tracking-wide text-muted-foreground",
              children: [
                "Text the ",
                v.counts.byText,
                " guest",
                v.counts.byText === 1 ? "" : "s",
                " who chose text",
              ],
            }),
            e.jsx("textarea", {
              className: `${se} mt-1 min-h-[80px]`,
              value: g,
              maxLength: v.maxChars + 200,
              onChange: (r) => k(r.target.value),
              "data-testid": "text-body",
            }),
            e.jsxs("p", {
              className: "mt-1 text-xs text-muted-foreground",
              "data-testid": "text-preview",
              children: [
                g.length,
                "/",
                v.maxChars,
                " characters. ",
                "{name}",
                " becomes the first name. Guests see: ",
                O,
              ],
            }),
            e.jsxs("div", {
              className: "mt-2 flex flex-wrap items-center gap-3",
              children: [
                e.jsxs("label", {
                  className: "flex items-center gap-2 text-xs",
                  children: [
                    "Guests' time zone",
                    e.jsx("select", {
                      className: "rounded-md border bg-background px-2 py-1",
                      value: w,
                      onChange: (r) => D(r.target.value),
                      "data-testid": "text-zone",
                      children: v.zones.map((r) =>
                        e.jsx(
                          "option",
                          { value: r.key, children: r.label },
                          r.key,
                        ),
                      ),
                    }),
                  ],
                }),
                e.jsxs("label", {
                  className: "flex items-center gap-2",
                  children: [
                    e.jsx("input", {
                      type: "radio",
                      checked: !b,
                      onChange: () => E(!1),
                    }),
                    "Send now",
                  ],
                }),
                e.jsxs("label", {
                  className: "flex items-center gap-2",
                  children: [
                    e.jsx("input", {
                      type: "radio",
                      checked: b,
                      onChange: () => E(!0),
                    }),
                    "Send later",
                  ],
                }),
                b &&
                  e.jsx("input", {
                    type: "datetime-local",
                    className: "rounded-md border bg-background px-2 py-1",
                    value: y,
                    onChange: (r) => C(r.target.value),
                    "data-testid": "text-send-at",
                  }),
              ],
            }),
            e.jsxs("p", {
              className: "mt-1 text-xs text-muted-foreground",
              children: [
                "Texts only go out between 8am and 9pm for your guests. ",
                v.sentLast24h,
                " of ",
                v.dailyLimit,
                " texts used in the last 24 hours. Only guests who agreed on their RSVP page are texted, and anyone who replies STOP is never texted again.",
              ],
            }),
            e.jsxs(T, {
              size: "sm",
              className: "mt-2",
              onClick: () => {
                q();
              },
              disabled: !x,
              "data-testid": "text-send",
              children: [
                u.isPending
                  ? e.jsx(ee, { className: "h-3.5 w-3.5 mr-1 animate-spin" })
                  : e.jsx(ge, { className: "h-3.5 w-3.5 mr-1" }),
                b ? "Schedule" : "Send",
                " to ",
                v.counts.byText,
                " guest",
                v.counts.byText === 1 ? "" : "s",
              ],
            }),
            v.scheduled.length > 0 &&
              e.jsx("ul", {
                className: "mt-3 divide-y",
                children: v.scheduled.map((r) =>
                  e.jsxs(
                    "li",
                    {
                      className: "flex items-center gap-2 py-1.5",
                      children: [
                        e.jsxs("span", {
                          className: "min-w-0 flex-1 truncate",
                          children: [
                            r.recipientCount,
                            " guests, ",
                            be(r.sendAt),
                          ],
                        }),
                        e.jsx(T, {
                          size: "sm",
                          variant: "ghost",
                          "aria-label": "Cancel this text",
                          onClick: async () => {
                            (await h.mutateAsync({ id: r.id }),
                              await i.eventSuite.text.status.invalidate());
                          },
                          children: e.jsx(me, { className: "h-3.5 w-3.5" }),
                        }),
                      ],
                    },
                    r.id,
                  ),
                ),
              }),
            v.recent.length > 0 &&
              e.jsx("ul", {
                className: "mt-3 text-xs text-muted-foreground",
                children: v.recent.map((r) =>
                  e.jsxs(
                    "li",
                    {
                      children: [
                        r.status === "sending"
                          ? "Sending now"
                          : r.status === "sent"
                            ? `${r.sentCount} sent${r.failedCount ? `, ${r.failedCount} could not be sent` : ""}`
                            : "Could not be sent",
                        ", ",
                        be(r.at),
                      ],
                    },
                    r.id,
                  ),
                ),
              }),
            e.jsx("p", {
              className: "mt-3 text-xs text-muted-foreground",
              children:
                "Guests' replies are emailed to you. Delivery details are in your Twilio console.",
            }),
          ],
        }),
    ],
  });
}
const lt = (t) =>
  t
    .replace(/[^\w.-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60) || "project";
function Mt({
  passKeyNote: t = !0,
  neutralName: s,
  onSaved: i,
  onOpened: a,
} = {}) {
  const [n, o] = oe(),
    d = S.useRef(null),
    u = _e(),
    { premium: h, entitled: l } = De(),
    f = () => {
      (Ie(
        new Blob([ke(n)], { type: "application/json" }),
        `${lt(n.name)}.fdp-project.json`,
      ),
        i?.());
    },
    g = async (C) => {
      if (!C) return;
      const N = Ne(await C.text());
      if (!N.ok) {
        L.error(N.error);
        return;
      }
      (o.reset(N.project), a?.());
      const U = N.issues.filter((v) => v.level === "error").length;
      L.success(
        U
          ? `Project opened. ${U} entr${U === 1 ? "y" : "ies"} could not be read.`
          : "Project opened",
      );
    },
    [k, w] = S.useState(null),
    D = () => {
      (w(null),
        o.reset(
          Se({
            currency: n.currency,
            locale: n.locale,
            timeZone: n.timeZone,
            paper: n.paper,
          }),
        ));
    },
    b = () => {
      (w(null), o.reset(qe()));
    },
    E = () => {
      ve(n) ? w("fresh") : D();
    },
    y = () => {
      ve(n) ? w("sample") : b();
    };
  return u
    ? null
    : e.jsxs(e.Fragment, {
        children: [
          e.jsxs("div", {
            className:
              "flex flex-wrap items-center gap-2 mt-4 text-xs text-muted-foreground",
            "data-testid": "project-bar",
            children: [
              e.jsxs("span", {
                children: [
                  "Project: ",
                  e.jsx("strong", {
                    className: "text-foreground",
                    children: s && n.name === "My event" ? s : n.name,
                  }),
                  ". ",
                  l
                    ? "Kept in this tab until you save it to your account."
                    : "Kept in this tab only, then erased.",
                ],
              }),
              e.jsxs(T, {
                variant: "outline",
                size: "sm",
                onClick: f,
                "aria-describedby": t ? "project-file-note" : void 0,
                children: [
                  e.jsx(Le, { className: "h-3.5 w-3.5 mr-1" }),
                  "Save project",
                ],
              }),
              e.jsxs(T, {
                variant: "outline",
                size: "sm",
                onClick: () => d.current?.click(),
                children: [
                  e.jsx(Ee, { className: "h-3.5 w-3.5 mr-1" }),
                  "Open project",
                ],
              }),
              e.jsxs(T, {
                variant: "ghost",
                size: "sm",
                onClick: y,
                children: [
                  e.jsx(Fe, { className: "h-3.5 w-3.5 mr-1" }),
                  "Try a sample",
                ],
              }),
              e.jsxs(T, {
                variant: "ghost",
                size: "sm",
                onClick: E,
                children: [
                  e.jsx(Ke, { className: "h-3.5 w-3.5 mr-1" }),
                  "New project",
                ],
              }),
              t &&
                e.jsx("span", {
                  id: "project-file-note",
                  className: "w-full",
                  "data-testid": "project-file-note",
                  children:
                    "The saved file includes a pass key: the secret that signs the QR codes on guest passes. It does not unlock any plan or paid feature, but anyone holding the file can make passes that check in, so share it only with people you trust with your door.",
                }),
              k &&
                e.jsxs("span", {
                  className:
                    "flex flex-wrap items-center gap-2 w-full rounded border bg-muted/40 px-2 py-1.5 text-foreground",
                  role: "alertdialog",
                  "aria-label": "Replace the open project?",
                  "data-testid": "project-confirm",
                  children: [
                    k === "sample"
                      ? "Load the sample project? The open one is replaced unless you saved it."
                      : "Start a new empty project? The open one is cleared unless you saved it.",
                    e.jsx(T, {
                      size: "sm",
                      onClick: k === "sample" ? b : D,
                      "data-testid": "project-confirm-yes",
                      children: k === "sample" ? "Load sample" : "Start new",
                    }),
                    e.jsx(T, {
                      size: "sm",
                      variant: "ghost",
                      onClick: () => w(null),
                      children: "Cancel",
                    }),
                  ],
                }),
              e.jsx("input", {
                ref: d,
                type: "file",
                accept: ".json,application/json",
                className: "hidden",
                onChange: (C) => {
                  (g(C.target.files?.[0]), (C.target.value = ""));
                },
              }),
            ],
          }),
          l && e.jsx(Ye, {}),
          h && Je && e.jsx(nt, {}),
          h && e.jsx(ot, {}),
          h && e.jsx(rt, {}),
        ],
      });
}
export {
  Mt as P,
  ie as a,
  He as b,
  G as c,
  kt as d,
  Qe as e,
  At as f,
  $t as g,
  Nt as p,
  St as r,
  Ct as s,
  Me as u,
};
//# sourceMappingURL=ProjectBar-D1TcmmzI.js.map
