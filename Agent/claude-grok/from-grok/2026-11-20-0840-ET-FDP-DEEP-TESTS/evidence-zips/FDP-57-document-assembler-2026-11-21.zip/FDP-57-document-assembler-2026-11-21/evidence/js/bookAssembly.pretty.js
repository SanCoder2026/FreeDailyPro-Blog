const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/docxRead-O6CRn7oc.js",
      "assets/jszip.min-CT0ZA6V1.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/jszip.min-C-FLQHAz.js",
      "assets/_commonjs-dynamic-modules-TDtrdbi3.js",
      "assets/xmlLite-D0-GZ86u.js",
      "assets/docxToPdf-K5O8yYaD.js",
      "assets/index-BRvxULIc.js",
      "assets/index-CnXdQaNG.js",
      "assets/index-DMQTJy3b.js",
      "assets/docxModel-CrYTKRGY.js",
      "assets/pdfFonts-Ckcqm3Ic.js",
      "assets/fontkit.es-DA-3qwB1.js",
      "assets/pdfMetadata-CcxIhQF2.js",
      "assets/textToPdf-BuGdG5vq.js",
    ]),
) => i.map((i) => d[i]);
import { ap as q } from "./index-B1CTyGtY.js";
import {
  A as X,
  u as P,
  k as L,
  P as C,
  f as J,
  t as rt,
  b as Y,
  e as tt,
  d as wt,
} from "./index-BRvxULIc.js";
import { f as ut } from "./fontkit.es-DA-3qwB1.js";
import { a as mt } from "./utils-s8ucLyj8.js";
import { R as et, a as xt, b as st } from "./pdfFonts-Ckcqm3Ic.js";
import { normalizeImageFile as bt } from "./imagePdf-Dtz8PQyf.js";
import { p as yt } from "./pageView-BQIwVYOi.js";
import { m as pt, r as Pt, w as St } from "./pdfBookmarks-BjfxtCfb.js";
import { r as Tt, a as kt, d as At } from "./formAppearance-CdNbuISd.js";
import { g as _t, b as Mt } from "./codeGeneration-D1g4LVfX.js";
const at = new WeakMap(),
  N = new WeakMap();
let it = !1;
const It = (t, a) =>
  !a.has(t) && t > 32 && !(t >= 8203 && t <= 8207) && t !== 65279;
function ot(t, a) {
  const i = [];
  for (const l of Array.from(t)) {
    const s = l.codePointAt(0),
      e = It(s, a),
      n = i[i.length - 1];
    n && (n.raster === e || (!e && /\s/.test(l) && n.raster))
      ? (n.text += l)
      : i.push({ text: l, raster: e });
  }
  return i;
}
function ct(t, a, i = st()) {
  if (!i) return;
  N.set(t, []);
  for (const s of a) {
    const e = new Set(s.font.getCharacterSet()),
      n = {
        doc: t,
        bold: s.bold,
        italic: s.italic,
        chars: e,
        orig: s.font.widthOfTextAtSize.bind(s.font),
      };
    (at.set(s.font, n),
      (s.font.widthOfTextAtSize = (r, o) => {
        let c = 0;
        for (const f of ot(r, e))
          c += f.raster
            ? i.measure(f.text, "serif", s.bold, s.italic) * o
            : n.orig(f.text, o);
        return c;
      }));
  }
  if (it) return;
  it = !0;
  const l = X.prototype.drawText;
  X.prototype.drawText = function (s, e = {}) {
    const n = e.font ? at.get(e.font) : void 0;
    if (!n || !N.get(n.doc)) return l.call(this, s, e);
    const r = ot(s, n.chars);
    if (!r.some((g) => g.raster)) return l.call(this, s, e);
    const o = e.size ?? 12,
      c = e.color ?? P(0, 0, 0),
      f =
        c.red !== void 0
          ? [c.red, c.green ?? 0, c.blue ?? 0]
          : [c.gray ?? 0, c.gray ?? 0, c.gray ?? 0];
    let h = e.x ?? 0;
    for (const g of r)
      g.raster
        ? (N.get(n.doc).push({
            page: this,
            text: g.text,
            x: h,
            y: e.y ?? 0,
            size: o,
            bold: n.bold,
            italic: n.italic,
            color: f,
          }),
          (h += i.measure(g.text, "serif", n.bold, n.italic) * o))
        : (g.text.trim() && l.call(this, g.text, { ...e, x: h }),
          (h += n.orig(g.text, o)));
    return this;
  };
}
async function lt(t, a = st()) {
  const i = N.get(t) ?? [];
  if ((N.set(t, []), !a)) return 0;
  const l = new Map();
  let s = 0;
  for (const e of i) {
    const n = `${e.bold}|${e.italic}|${e.color.join(",")}|${e.text}`;
    let r = l.get(n);
    r ||
      ((r = a
        .render(e.text, "serif", e.bold, e.italic, e.color)
        .then(async (o) => ({
          img: await t.embedPng(o.png),
          widthEm: o.widthEm,
        }))),
      l.set(n, r));
    try {
      const { img: o, widthEm: c } = await r;
      e.page.drawImage(o, {
        x: e.x - 2 * (1 / 20) * e.size,
        y: e.y - (et - xt) * e.size,
        width: c * e.size,
        height: et * e.size,
      });
    } catch {
      s++;
    }
  }
  return s;
}
const Kt = Object.freeze(
    Object.defineProperty(
      { __proto__: null, enableUniversalText: ct, flushBookRasters: lt },
      Symbol.toStringTag,
      { value: "Module" },
    ),
  ),
  Ct = {
    massMarket4_25x7: {
      label: "4.25 x 7 in — mass-market pocket size",
      width: 306,
      height: 504,
    },
    massMarket5x8: {
      label: "5 x 8 in — mass-market paperback",
      width: 360,
      height: 576,
    },
    notebook5_06x7_81: {
      label: "5.06 x 7.81 in — compact / notebook format",
      width: 364.32,
      height: 562.32,
    },
    trade5_25x8: {
      label: "5.25 x 8 in — trade paperback",
      width: 378,
      height: 576,
    },
    digest5_5x8_5: {
      label: "5.5 x 8.5 in — digest / trade",
      width: 396,
      height: 612,
    },
    trade6x9: {
      label: "6 x 9 in — standard paperback trim",
      width: 432,
      height: 648,
    },
    expanded6_14x9_21: {
      label: "6.14 x 9.21 in — expanded distribution",
      width: 442.08,
      height: 663.12,
    },
    large6_69x9_61: {
      label: "6.69 x 9.61 in — large trim",
      width: 481.68,
      height: 691.92,
    },
    large7x10: {
      label: "7 x 10 in — large trim, workbooks / nonfiction",
      width: 504,
      height: 720,
    },
    large7_44x9_69: {
      label: "7.44 x 9.69 in — large trim",
      width: 535.68,
      height: 697.68,
    },
    large7_5x9_25: {
      label: "7.5 x 9.25 in — large trim",
      width: 540,
      height: 666,
    },
    large8x10: {
      label: "8 x 10 in — large trim, children's / photo books",
      width: 576,
      height: 720,
    },
    landscape8_25x6: {
      label: "8.25 x 6 in — landscape",
      width: 594,
      height: 432,
    },
    square8_25x8_25: {
      label: "8.25 x 8.25 in — square, picture books",
      width: 594,
      height: 594,
    },
    square8_5x8_5: { label: "8.5 x 8.5 in — square", width: 612, height: 612 },
    letter: {
      label: "US Letter (8.5 x 11 in) — for document-style content",
      width: 612,
      height: 792,
    },
    a4: {
      label: "A4 (210 x 297 mm) — for document-style content",
      width: 595.28,
      height: 841.89,
    },
  },
  Qt = {
    default: {
      label: "Use default (no specific platform)",
      allowsCustomSize: !0,
      gutterModel: "kdp-scaled",
      isbnPolicy: "optional",
      showsTerritorialRights: !0,
      forcesEbookOnly: !1,
    },
    kdp: {
      label: "Amazon KDP",
      allowsCustomSize: !0,
      gutterModel: "kdp-scaled",
      isbnPolicy: "free-exclusive",
      showsTerritorialRights: !0,
      forcesEbookOnly: !1,
    },
    ingramspark: {
      label: "IngramSpark",
      allowsCustomSize: !0,
      gutterModel: "flat-0.5",
      isbnPolicy: "must-supply-own",
      showsTerritorialRights: !0,
      forcesEbookOnly: !1,
    },
    bn_press: {
      label: "Barnes & Noble Press",
      validSizeIds: [
        "massMarket4_25x7",
        "massMarket5x8",
        "trade5_25x8",
        "digest5_5x8_5",
        "trade6x9",
        "expanded6_14x9_21",
      ],
      allowsCustomSize: !1,
      gutterModel: "flat-0.75-inside",
      isbnPolicy: "free-exclusive",
      showsTerritorialRights: !1,
      forcesEbookOnly: !1,
    },
    lulu: {
      label: "Lulu",
      allowsCustomSize: !0,
      gutterModel: "flat-0.5",
      isbnPolicy: "free-exclusive",
      showsTerritorialRights: !0,
      forcesEbookOnly: !1,
    },
    draft2digital: {
      label: "Ebook (Draft2Digital)",
      validSizeIds: [],
      allowsCustomSize: !1,
      gutterModel: "none",
      isbnPolicy: "optional",
      showsTerritorialRights: !1,
      forcesEbookOnly: !0,
    },
    apple_books: {
      label: "Apple Books",
      validSizeIds: [],
      allowsCustomSize: !1,
      gutterModel: "none",
      isbnPolicy: "optional",
      showsTerritorialRights: !1,
      forcesEbookOnly: !0,
    },
    kobo: {
      label: "Kobo Writing Life",
      validSizeIds: [],
      allowsCustomSize: !1,
      gutterModel: "none",
      isbnPolicy: "not-applicable",
      showsTerritorialRights: !1,
      forcesEbookOnly: !0,
    },
  };
async function j(t) {
  const a = await fetch(t);
  if (!a.ok) throw new Error(`Couldn't load font file: ${t}`);
  return a.arrayBuffer();
}
async function vt(t) {
  t.registerFontkit(ut);
  const [a, i, l] = await Promise.all([
      j("/fonts/literata/literata-regular.woff"),
      j("/fonts/literata/literata-bold.woff"),
      j("/fonts/literata/literata-italic.woff"),
    ]),
    [s, e, n] = await Promise.all([
      t.embedFont(a, { subset: !0 }),
      t.embedFont(i, { subset: !0 }),
      t.embedFont(l, { subset: !0 }),
    ]);
  return (
    ct(t, [
      { font: s, bold: !1, italic: !1 },
      { font: e, bold: !0, italic: !1 },
      { font: n, bold: !1, italic: !0 },
    ]),
    { regular: s, bold: e, italic: n }
  );
}
async function zt(t) {
  if (t.name.toLowerCase().endsWith(".docx")) {
    const { readDocx: e, NotDocxError: n } = await q(
        async () => {
          const { readDocx: f, NotDocxError: h } =
            await import("./docxRead-O6CRn7oc.js");
          return { readDocx: f, NotDocxError: h };
        },
        __vite__mapDeps([0, 1, 2, 3, 4, 5]),
      ),
      { convertDocxDocumentToPdf: r } = await q(
        async () => {
          const { convertDocxDocumentToPdf: f } =
            await import("./docxToPdf-K5O8yYaD.js");
          return { convertDocxDocumentToPdf: f };
        },
        __vite__mapDeps([6, 7, 8, 2, 9, 10, 11, 12, 13]),
      );
    let o;
    try {
      o = await e(t);
    } catch (f) {
      throw new Error(
        f instanceof n
          ? `"${t.name}" isn't a valid Word (.docx) file`
          : `"${t.name}" couldn't be read — it may be damaged or password-protected`,
      );
    }
    return (await r(o, { fallbackTitle: t.name.replace(/\.docx$/i, "") }))
      .bytes;
  }
  const { convertTextToPdfDocument: i, decodeTextFile: l } = await q(
      async () => {
        const { convertTextToPdfDocument: e, decodeTextFile: n } =
          await import("./textToPdf-BuGdG5vq.js");
        return { convertTextToPdfDocument: e, decodeTextFile: n };
      },
      __vite__mapDeps([14, 7, 8, 2, 9, 11, 12, 13]),
    ),
    s = l(await t.arrayBuffer());
  if (!s.trim())
    throw new Error(`"${t.name}" doesn't contain any readable text`);
  return (await i(s, { pageSize: "A4" })).bytes;
}
async function Et(t) {
  const a = await L.create(),
    i = await bt(t),
    l = new Uint8Array(await i.arrayBuffer()),
    e = i.type === "image/png" ? await a.embedPng(l) : await a.embedJpg(l),
    n = { width: 595.28, height: 841.89 },
    r = 36,
    o = n.width - r * 2,
    c = n.height - r * 2,
    f = Math.min(o / e.width, c / e.height, 1),
    h = e.width * f,
    g = e.height * f;
  return (
    a
      .addPage([n.width, n.height])
      .drawImage(e, {
        x: (n.width - h) / 2,
        y: (n.height - g) / 2,
        width: h,
        height: g,
      }),
    a.save()
  );
}
async function Ft(t, a) {
  const i = await L.load(t);
  if (i.getForm().getFields().length === 0) return t;
  const l = await Tt(i);
  return (
    kt(i),
    i.getForm().flatten({ updateFieldAppearances: !1 }),
    At(i),
    l.length && console.warn(`Some form fields in ${a} could not be drawn:`, l),
    new Uint8Array(await i.save({ updateFieldAppearances: !1 }))
  );
}
async function Ot(t) {
  const a = t.name.toLowerCase();
  if (a.endsWith(".pdf"))
    return Ft(new Uint8Array(await t.arrayBuffer()), t.name);
  if (a.endsWith(".docx") || a.endsWith(".txt")) return zt(t);
  if (t.type === "image/png" || t.type === "image/jpeg") return Et(t);
  throw new Error(
    `"${t.name}" isn't a supported file type — use PDF, Word (.docx/.txt), or an image`,
  );
}
async function Dt(t, a, i, l) {
  const s = yt(a),
    e = a.getCropBox(),
    n = await t.embedPage(a, {
      left: e.x,
      bottom: e.y,
      right: e.x + e.width,
      top: e.y + e.height,
    }),
    r = Math.min(i / s.width, l / s.height),
    o = n.width * r,
    c = n.height * r,
    f = s.width * r,
    h = s.height * r,
    g = (i - f) / 2,
    u = (l - h) / 2,
    b = s.rotation,
    m =
      b === 90
        ? { x: g, y: u + o }
        : b === 180
          ? { x: g + o, y: u + c }
          : b === 270
            ? { x: g + c, y: u }
            : { x: g, y: u },
    d = t.addPage([i, l]);
  d.drawPage(n, { x: m.x, y: m.y, width: o, height: c, rotate: rt(-b) });
  const y = (v, I) => {
      const z = (v - e.x) * r,
        k = (I - e.y) * r;
      switch (b) {
        case 90:
          return { x: m.x + k, y: m.y - z };
        case 180:
          return { x: m.x - z, y: m.y - k };
        case 270:
          return { x: m.x - k, y: m.y + z };
        default:
          return { x: m.x + z, y: m.y + k };
      }
    },
    T = a.node.lookupMaybe(C.of("Annots"), J),
    W = [];
  if (T)
    for (let v = 0; v < T.size(); v++) {
      const I = a.doc.context.lookupMaybe(T.get(v), Y);
      if (!I || I.get(C.of("Subtype"))?.toString() !== "/Link") continue;
      const k = I.lookupMaybe(C.of("A"), Y)?.lookup(C.of("URI")),
        A = I.lookupMaybe(C.of("Rect"), J);
      if (!(k instanceof tt || k instanceof wt) || !A || A.size() < 4) continue;
      const E = [0, 1, 2, 3].map(($) => Number(A.get($).asNumber?.() ?? 0)),
        F = y(E[0], E[1]),
        O = y(E[2], E[3]);
      W.push(
        t.context.register(
          t.context.obj({
            Type: "Annot",
            Subtype: "Link",
            Border: [0, 0, 0],
            Rect: [
              Math.min(F.x, O.x),
              Math.min(F.y, O.y),
              Math.max(F.x, O.x),
              Math.max(F.y, O.y),
            ],
            A: { Type: "Action", S: "URI", URI: tt.of(k.decodeText()) },
          }),
        ),
      );
    }
  return (W.length && d.node.set(C.of("Annots"), t.context.obj(W)), d);
}
async function R(t, a, i, l, s) {
  const e = t.addPage([i.width, i.height]),
    n = Math.min(72, i.width * 0.12);
  let r = i.height - n;
  if (a.image) {
    const h = a.image.isPng
        ? await t.embedPng(a.image.bytes)
        : await t.embedJpg(a.image.bytes),
      g = Math.min(140, i.width * 0.4),
      u = Math.min(1, g / h.width),
      b = h.width * u,
      m = h.height * u;
    (e.drawImage(h, { x: (i.width - b) / 2, y: r - m, width: b, height: m }),
      (r -= m + 24));
  }
  a.heading &&
    (e.drawText(a.heading, {
      x: n,
      y: r,
      size: 20,
      font: s,
      color: P(0.1, 0.1, 0.1),
    }),
    (r -= 40));
  const o = 12,
    c = o * 1.6,
    f = i.width - n * 2;
  for (const h of a.body.split(`
`)) {
    const g = h.split(" ");
    let u = "";
    for (const b of g) {
      const m = u ? `${u} ${b}` : b;
      l.widthOfTextAtSize(m, o) > f && u
        ? (e.drawText(u, {
            x: n,
            y: r,
            size: o,
            font: l,
            color: P(0.15, 0.15, 0.15),
          }),
          (r -= c),
          (u = b))
        : (u = m);
    }
    (u &&
      (e.drawText(u, {
        x: n,
        y: r,
        size: o,
        font: l,
        color: P(0.15, 0.15, 0.15),
      }),
      (r -= c)),
      (r -= c * 0.5));
  }
}
async function dt(t, a) {
  return a.isPng ? t.embedPng(a.bytes) : t.embedJpg(a.bytes);
}
async function Rt(t, a, i, l, s, e, n) {
  const r = t.addPage([s.width, s.height]);
  if (a?.image) {
    const o = await dt(t, a.image),
      c = Math.max(s.width / o.width, s.height / o.height),
      f = o.width * c,
      h = o.height * c;
    r.drawImage(o, {
      x: (s.width - f) / 2,
      y: (s.height - h) / 2,
      width: f,
      height: h,
    });
    const g = Math.min(170, s.height * 0.3);
    r.drawRectangle({
      x: 0,
      y: 0,
      width: s.width,
      height: g,
      color: P(0, 0, 0),
      opacity: 0.55,
    });
    const u = Math.min(26, s.width * 0.09),
      b = n.widthOfTextAtSize(i, u);
    if (
      (r.drawText(i, {
        x: (s.width - b) / 2,
        y: g * 0.55,
        size: u,
        font: n,
        color: P(1, 1, 1),
      }),
      l)
    ) {
      const m = u * 0.55,
        d = e.widthOfTextAtSize(l, m);
      r.drawText(l, {
        x: (s.width - d) / 2,
        y: g * 0.3,
        size: m,
        font: e,
        color: P(0.9, 0.9, 0.9),
      });
    }
  } else {
    const o = Math.min(28, s.width * 0.1),
      c = n.widthOfTextAtSize(i, o);
    if (
      (r.drawText(i, {
        x: (s.width - c) / 2,
        y: s.height / 2 + 20,
        size: o,
        font: n,
        color: P(0.1, 0.1, 0.1),
      }),
      l)
    ) {
      const h = e.widthOfTextAtSize(l, 14);
      r.drawText(l, {
        x: (s.width - h) / 2,
        y: s.height / 2 - 20,
        size: 14,
        font: e,
        color: P(0.35, 0.35, 0.35),
      });
    }
  }
}
async function ht(t) {
  if (t.barcode?.value?.trim())
    try {
      return await _t(t.barcode.value, t.barcode.format, {
        caption: t.barcode.caption,
      });
    } catch (a) {
      return (console.warn("Couldn't generate a barcode:", a), null);
    }
  if (t.qrUrl?.trim())
    try {
      return await Mt(t.qrUrl, { size: 240 });
    } catch (a) {
      return (console.warn("Couldn't generate a QR code:", a), null);
    }
  return null;
}
async function Wt(t, a, i, l, s) {
  const e = t.addPage([i.width, i.height]),
    n = Math.min(60, i.width * 0.1);
  if (a.image) {
    const o = await dt(t, a.image),
      c = Math.max(i.width / o.width, i.height / o.height),
      f = o.width * c,
      h = o.height * c;
    if (
      (e.drawImage(o, {
        x: (i.width - f) / 2,
        y: (i.height - h) / 2,
        width: f,
        height: h,
      }),
      a.blurb)
    ) {
      const g = Math.min(280, i.height * 0.45);
      e.drawRectangle({
        x: 0,
        y: i.height - g,
        width: i.width,
        height: g,
        color: P(1, 1, 1),
        opacity: 0.85,
      });
    }
  }
  if (a.blurb) {
    let o = i.height - n;
    const c = 13,
      f = c * 1.6,
      h = i.width - n * 2;
    for (const g of a.blurb.split(`
`)) {
      const u = g.split(" ");
      let b = "";
      for (const m of u) {
        const d = b ? `${b} ${m}` : m;
        l.widthOfTextAtSize(d, c) > h && b
          ? (e.drawText(b, {
              x: n,
              y: o,
              size: c,
              font: l,
              color: P(0.15, 0.15, 0.15),
            }),
            (o -= f),
            (b = m))
          : (b = d);
      }
      (b &&
        (e.drawText(b, {
          x: n,
          y: o,
          size: c,
          font: l,
          color: P(0.15, 0.15, 0.15),
        }),
        (o -= f)),
        (o -= f * 0.5));
    }
  }
  const r = await ht(a);
  if (r) {
    const o = await t.embedPng(r),
      c = Math.min(140, i.width * 0.35),
      f = Math.min(1, c / o.width),
      h = o.width * f,
      g = o.height * f;
    (a.image &&
      e.drawRectangle({
        x: i.width - n - h - 10,
        y: n - 10,
        width: h + 20,
        height: g + 20,
        color: P(1, 1, 1),
        opacity: 0.9,
      }),
      e.drawImage(o, { x: i.width - n - h, y: n, width: h, height: g }));
  }
}
async function Bt(t, a, i, l, s) {
  const e = Math.max(18, a.widthIn * 72),
    n = t.addPage([e, i]),
    r = 12;
  if (a.image) {
    const c = a.image.isPng
        ? await t.embedPng(a.image.bytes)
        : await t.embedJpg(a.image.bytes),
      f = e - r * 2,
      h = Math.min(1, f / c.width),
      g = c.width * h,
      u = c.height * h;
    n.drawImage(c, { x: (e - g) / 2, y: i - r - u, width: g, height: u });
  }
  if (a.text?.trim()) {
    const c = Math.min(16, e * 0.5),
      f = s.widthOfTextAtSize(a.text.trim(), c);
    n.drawText(a.text.trim(), {
      x: e / 2 + c * 0.35,
      y: (i - f) / 2,
      size: c,
      font: s,
      color: P(0.1, 0.1, 0.1),
      rotate: rt(90),
    });
  }
  const o = await ht(a);
  if (o) {
    const c = await t.embedPng(o),
      f = e - r * 2,
      h = Math.min(1, f / c.width),
      g = c.width * h,
      u = c.height * h;
    n.drawImage(c, { x: (e - g) / 2, y: r, width: g, height: u });
  }
}
function nt(t) {
  const a = [
    [1e3, "m"],
    [900, "cm"],
    [500, "d"],
    [400, "cd"],
    [100, "c"],
    [90, "xc"],
    [50, "l"],
    [40, "xl"],
    [10, "x"],
    [9, "ix"],
    [5, "v"],
    [4, "iv"],
    [1, "i"],
  ];
  let i = t,
    l = "";
  for (const [s, e] of a) for (; i >= s;) ((l += e), (i -= s));
  return l;
}
function G(t, a, i) {
  const s = i.widthOfTextAtSize(a, 10);
  t.drawText(a, {
    x: t.getWidth() / 2 - s / 2,
    y: 28,
    size: 10,
    font: i,
    color: P(0.4, 0.4, 0.4),
  });
}
async function Zt(t) {
  const {
      sections: a,
      frontMatter: i,
      backMatter: l,
      includeToc: s,
      includeListOfImages: e,
      onProgress: n,
    } = t,
    r = (w) => n?.(w),
    o = Ct[t.bookSize];
  r("Converting sections to PDF...");
  const c = [];
  for (const w of a) c.push(await Ot(w.file));
  const f = [],
    h = [];
  for (const w of c) {
    const x = await L.load(w);
    (f.push(x.getPageCount()),
      h.push(
        x
          .getPages()
          .map((p) => ({ width: p.getWidth(), height: p.getHeight() })),
      ));
  }
  const g = [];
  let u = 1;
  for (const w of f) (g.push(u), (u += w));
  const b = 0.85,
    m = [];
  if (e) {
    r("Scanning for images...");
    for (let w = 0; w < a.length; w++) {
      const x = new File([new Uint8Array(c[w])], "section.pdf", {
          type: "application/pdf",
        }),
        p = await mt(x);
      for (const S of p) {
        const _ = h[w][S.pageNumber - 1];
        (S.position &&
          _ &&
          S.position.widthPt >= _.width * b &&
          S.position.heightPt >= _.height * b) ||
          m.push({
            globalPageNumber: g[w] + (S.pageNumber - 1),
            sectionIdx: w,
          });
      }
    }
  }
  const d = await L.create(),
    { regular: y, bold: T } = await vt(d),
    W = d.getPageCount();
  let v = -1;
  i.title &&
    (r("Adding front cover..."),
    (v = d.getPageCount()),
    await Rt(d, t.frontCover, t.bookTitle, t.author, o, y, T));
  let I = -1;
  t.spine &&
    t.spine.widthIn > 0 &&
    (r("Adding spine..."),
    (I = d.getPageCount()),
    await Bt(d, t.spine, o.height, y, T));
  let z = -1;
  (i.copyright &&
    (r("Adding copyright page..."),
    (z = d.getPageCount()),
    await R(d, i.copyright, o, y, T)),
    i.masthead && (r("Adding masthead..."), await R(d, i.masthead, o, y, T)),
    i.dedication &&
      (r("Adding dedication..."), await R(d, i.dedication, o, y, T)),
    i.preface && (r("Adding preface..."), await R(d, i.preface, o, y, T)),
    i.acknowledgments &&
      (r("Adding acknowledgments..."), await R(d, i.acknowledgments, o, y, T)),
    i.contributors &&
      (r("Adding contributors..."), await R(d, i.contributors, o, y, T)));
  let k = -1;
  s && a.length > 0 && ((k = d.getPageCount()), d.addPage([o.width, o.height]));
  let A = -1;
  e && m.length > 0 && ((A = d.getPageCount()), d.addPage([o.width, o.height]));
  const E = d.getPageCount() - W;
  r("Merging sections...");
  const F = [],
    O = [];
  for (let w = 0; w < c.length; w++) {
    const x = await L.load(c[w]),
      p = new Map(),
      S = x.getPages();
    for (let M = 0; M < S.length; M++)
      p.set(M, await Dt(d, S[M], o.width, o.height));
    const _ = p.get(0);
    (O.push(_),
      F.push({
        title: a[w].title || a[w].file.name,
        page: _,
        children: pt(Pt(x), p),
      }));
  }
  l.aboutAuthor &&
    (r("Adding About the Author..."), await R(d, l.aboutAuthor, o, y, T));
  let $ = -1;
  t.backCover &&
    (t.backCover.image ||
      t.backCover.blurb ||
      t.backCover.qrUrl ||
      t.backCover.barcode?.value) &&
    (r("Adding back cover..."),
    ($ = d.getPageCount()),
    await Wt(d, t.backCover, o, y));
  const U = d.getPages(),
    gt = new Set([v, I, k, z, $]);
  if (
    (U.forEach((w, x) => {
      gt.has(x) || (x < E ? G(w, nt(x + 1), y) : G(w, String(x - E + 1), y));
    }),
    A >= 0 && G(U[A], nt(A + 1), y),
    k >= 0)
  ) {
    r("Building table of contents...");
    const w = U[k],
      x = Math.min(72, o.width * 0.12);
    let p = w.getHeight() - x;
    (w.drawText("Table of Contents", {
      x,
      y: p,
      size: 20,
      font: T,
      color: P(0.1, 0.1, 0.1),
    }),
      (p -= 40));
    const S = 12,
      _ = 14;
    a.forEach((M, B) => {
      if (p < x) return;
      const H = String(g[B]),
        V = y.widthOfTextAtSize(H, S),
        K = w.getWidth() - x * 2 - V - _;
      let D = M.title || M.file.name;
      if (y.widthOfTextAtSize(D, S) > K) {
        for (; D.length > 1 && y.widthOfTextAtSize(D + "…", S) > K;)
          D = D.slice(0, -1);
        D += "…";
      }
      (w.drawText(D, { x, y: p, size: S, font: y, color: P(0.15, 0.15, 0.15) }),
        w.drawText(H, {
          x: w.getWidth() - x - V,
          y: p,
          size: S,
          font: y,
          color: P(0.15, 0.15, 0.15),
        }));
      const Q = d.context.register(
          d.context.obj({
            Type: "Annot",
            Subtype: "Link",
            Border: [0, 0, 0],
            Rect: [x, p - 4, w.getWidth() - x, p + S + 2],
            Dest: [O[B].ref, C.of("Fit")],
          }),
        ),
        Z = w.node.lookupMaybe(C.of("Annots"), J);
      (Z ? Z.push(Q) : w.node.set(C.of("Annots"), d.context.obj([Q])),
        (p -= 24));
    });
  }
  if (A >= 0) {
    const w = U[A],
      x = Math.min(72, o.width * 0.12);
    let p = w.getHeight() - x;
    (w.drawText("List of Images", {
      x,
      y: p,
      size: 20,
      font: T,
      color: P(0.1, 0.1, 0.1),
    }),
      (p -= 40),
      m.length === 0
        ? w.drawText("No images found in the assembled document.", {
            x,
            y: p,
            size: 12,
            font: y,
            color: P(0.4, 0.4, 0.4),
          })
        : m.forEach((S, _) => {
            if (p < x) return;
            const M = `Figure ${_ + 1} — ${(a[S.sectionIdx].title || a[S.sectionIdx].file.name).slice(0, 50)}`,
              B = String(S.globalPageNumber);
            w.drawText(M, {
              x,
              y: p,
              size: 12,
              font: y,
              color: P(0.15, 0.15, 0.15),
            });
            const H = y.widthOfTextAtSize(B, 12);
            (w.drawText(B, {
              x: w.getWidth() - x - H,
              y: p,
              size: 12,
              font: y,
              color: P(0.15, 0.15, 0.15),
            }),
              (p -= 22));
          }));
  }
  (r("Finishing up..."),
    St(d, F),
    d.setTitle(t.bookTitle || ""),
    d.setAuthor(t.author || ""),
    d.setProducer("FreeDailyPro"),
    d.setCreator("FreeDailyPro"),
    await lt(d));
  const ft = await d.save();
  return { bytes: new Uint8Array(ft), totalPages: d.getPageCount() };
}
export { Ct as B, Qt as P, Zt as a, Kt as b, lt as f, vt as l };
//# sourceMappingURL=bookAssembly-DmpTM49o.js.map
