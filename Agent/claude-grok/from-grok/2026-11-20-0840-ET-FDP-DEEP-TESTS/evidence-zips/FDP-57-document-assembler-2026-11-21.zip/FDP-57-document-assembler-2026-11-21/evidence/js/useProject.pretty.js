import { r as Z } from "./vendor-react-D01g8YgM.js";
import { t as U } from "./csv-DBvSFDe9.js";
import { cs as z } from "./index-B1CTyGtY.js";
import { n as J, i as X } from "./ids-D-BGTcEX.js";
import { n as F, i as Y } from "./passCode-CB5SR9ne.js";
const k = (t) => ({ ok: !0, value: t }),
  m = (t) => ({ ok: !1, message: t }),
  H = /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g;
function v(t, e = 500) {
  const n = t
    .replace(H, "")
    .replace(/^'(?=[=+\-@\t\r])/, "")
    .trim();
  return n.length > e ? m(`is longer than ${e} characters`) : k(n);
}
function W(t) {
  const e = v(t, 254);
  if (!e.ok) return e;
  const n = e.value.toLowerCase();
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(n)
    ? k(n)
    : m("is not a valid email address");
}
function Q(t) {
  const e = v(t, 40);
  if (!e.ok) return e;
  const n = e.value;
  if (!/^[+()\d\s.\-xX#*]+$/.test(n)) return m("is not a valid phone number");
  const r = n.replace(/\D/g, "").length;
  return r >= 5 && r <= 20 ? k(n) : m("is not a valid phone number");
}
function ee(t) {
  const e = v(t, 500);
  if (!e.ok) return e;
  try {
    const n = new URL(e.value);
    return n.protocol === "https:" || n.protocol === "http:"
      ? k(n.toString())
      : m("must start with http:// or https://");
  } catch {
    return m("is not a valid web address");
  }
}
function _(t) {
  const e = v(t, 60);
  if (!e.ok) return e;
  try {
    return (new Intl.DateTimeFormat("en", { timeZone: e.value }), k(e.value));
  } catch {
    return m(
      "is not a recognised time zone (use a name like America/New_York)",
    );
  }
}
function te(t) {
  const e = /^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/.exec(t.trim());
  if (!e) return m("must be a date written year-month-day, like 2026-10-31");
  const n = Number(e[1]),
    r = Number(e[2]),
    i = Number(e[3]),
    s = new Date(Date.UTC(n, r - 1, i));
  return n < 1900 ||
    n > 2200 ||
    s.getUTCFullYear() !== n ||
    s.getUTCMonth() !== r - 1 ||
    s.getUTCDate() !== i
    ? m("is not a real calendar date")
    : k(`${e[1]}-${String(r).padStart(2, "0")}-${String(i).padStart(2, "0")}`);
}
function ne(t) {
  const e = /^(\d{1,2})(?::(\d{2}))?\s*(am|pm)?$/i.exec(t.trim());
  if (!e) return m("must be a time like 14:30 or 2:30 PM");
  let n = Number(e[1]);
  const r = e[2] ? Number(e[2]) : 0,
    i = e[3]?.toLowerCase();
  if (r > 59) return m("must be a time like 14:30 or 2:30 PM");
  if (i) {
    if (n < 1 || n > 12) return m("must be a time like 14:30 or 2:30 PM");
    n = (n % 12) + (i === "pm" ? 12 : 0);
  } else if (n > 23) return m("must be a time like 14:30 or 2:30 PM");
  return k(`${String(n).padStart(2, "0")}:${String(r).padStart(2, "0")}`);
}
function N(t) {
  let e = t.trim();
  if (!e) return null;
  let n = !1;
  if (
    (/^\(.*\)$/.test(e) && ((n = !0), (e = e.slice(1, -1))),
    (e = e.replace(/[\s  ']/g, "")),
    /^[-−]/.test(e.replace(/^[^\d.,+\-−]+/, "")) && (n = n || !0),
    (e = e.replace(/[^\d.,]/g, "")),
    !e || !/\d/.test(e))
  )
    return null;
  const r = (e.match(/\./g) ?? []).length,
    i = (e.match(/,/g) ?? []).length;
  let s;
  if (r && i) {
    const a = e.lastIndexOf(".") > e.lastIndexOf(",") ? "." : ",",
      u = a === "." ? "," : ".";
    ((s = e.split(u).join("")), a === "," && (s = s.replace(",", ".")));
  } else
    i
      ? (s =
          i > 1 || /^\d{1,3}(,\d{3})+$/.test(e)
            ? e.replace(/,/g, "")
            : e.replace(",", "."))
      : r > 1
        ? (s = /^\d{1,3}(\.\d{3})+$/.test(e) ? e.replace(/\./g, "") : "")
        : (s = e);
  if (!s) return null;
  const d = Number(s);
  return Number.isFinite(d) ? (n ? -d : d) : null;
}
function j(t, e = -1e12, n = 1e12) {
  const r = N(t);
  return r === null
    ? m("is not a number")
    : r < e || r > n
      ? m(`must be between ${e} and ${n}`)
      : k(Math.round(r * 1e6) / 1e6);
}
function re(t, e = 0, n = 1e5) {
  const r = N(t);
  return r === null || !Number.isInteger(r)
    ? m("must be a whole number")
    : r < e || r > n
      ? m(`must be between ${e} and ${n}`)
      : k(r);
}
const ae = new Set(["yes", "y", "true", "1", "x", "✓", "✔", "on"]),
  se = new Set(["no", "n", "false", "0", "off"]);
function ie(t) {
  const e = t.trim().toLowerCase();
  return ae.has(e) ? k(!0) : se.has(e) ? k(!1) : m("must be yes or no");
}
function M(t) {
  const e = t.trim().toUpperCase();
  return /^[A-Z]{3}$/.test(e)
    ? k(e)
    : m("must be a three-letter currency code like USD or EUR");
}
function oe(t, e, n = {}) {
  const r = t
      .trim()
      .toLowerCase()
      .replace(/[\s_-]+/g, " "),
    i = e.find((d) => d.replace(/_/g, " ") === r);
  if (i) return k(i);
  const s = n[r];
  return s ? k(s) : m(`must be one of: ${e.join(", ")}`);
}
const le = ["invited", "confirmed", "declined", "waitlist", "attended"],
  de = ["requested", "received", "accepted", "rejected"],
  ue = ["flexible", "moderate", "strict"],
  ce = ["cost", "income"],
  L = ["none", "sales_tax", "vat", "gst"],
  me = ["paid", "pledged"],
  pe = ["enquiry", "booked", "paid", "cancelled"],
  ye = [
    "guests",
    "sessions",
    "vendors",
    "quotes",
    "expenses",
    "rooms",
    "tasks",
    "budgets",
    "exhibitors",
  ],
  fe = ["letter", "a4"],
  G = () => ({
    guests: [],
    sessions: [],
    vendors: [],
    quotes: [],
    expenses: [],
    rooms: [],
    tasks: [],
    budgets: [],
    exhibitors: [],
  }),
  b = {
    key: "id",
    header: "ID",
    kind: "id",
    aliases: ["Id", "Reference", "Ref"],
  },
  x = {
    key: "notes",
    header: "Notes",
    kind: "longtext",
    aliases: ["Note", "Comments", "Comment", "Remarks"],
  },
  T = {
    guests: {
      kind: "guests",
      label: "Guests",
      idPrefix: "g",
      columns: [
        b,
        {
          key: "name",
          header: "Name",
          kind: "text",
          required: !0,
          aliases: ["Full name", "Guest", "Guest name", "Attendee"],
        },
        {
          key: "email",
          header: "Email",
          kind: "email",
          aliases: ["E-mail", "Email address"],
        },
        {
          key: "phone",
          header: "Phone",
          kind: "phone",
          aliases: ["Mobile", "Telephone", "Phone number", "Cell"],
        },
        {
          key: "organisation",
          header: "Organisation",
          kind: "text",
          aliases: ["Organization", "Company", "Employer"],
        },
        {
          key: "role",
          header: "Role",
          kind: "text",
          aliases: ["Title", "Job title", "Position"],
        },
        {
          key: "status",
          header: "Status",
          kind: "enum",
          values: le,
          default: "invited",
          aliases: ["RSVP", "Reply", "Response", "Attendance", "Rsvp status"],
          synonyms: {
            yes: "confirmed",
            accepted: "confirmed",
            attending: "confirmed",
            going: "confirmed",
            no: "declined",
            "not attending": "declined",
            pending: "invited",
            "wait list": "waitlist",
            "checked in": "attended",
            present: "attended",
          },
        },
        {
          key: "dietary",
          header: "Dietary",
          kind: "text",
          aliases: ["Diet", "Dietary needs", "Dietary requirements", "Food"],
        },
        {
          key: "access",
          header: "Access needs",
          kind: "text",
          aliases: ["Accessibility", "Access", "Mobility"],
        },
        {
          key: "needsStay",
          header: "Needs stay",
          kind: "bool",
          default: !1,
          aliases: [
            "Needs room",
            "Accommodation",
            "Stay",
            "Hotel needed",
            "Room",
            "Hotel",
            "Needs room?",
          ],
        },
        {
          key: "arrival",
          header: "Arrival",
          kind: "date",
          aliases: ["Arrival date", "Arrives"],
        },
        {
          key: "departure",
          header: "Departure",
          kind: "date",
          aliases: ["Departure date", "Departs"],
        },
        {
          key: "arrivalTime",
          header: "Arrival time",
          kind: "time",
          aliases: [
            "Lands",
            "Landing time",
            "Arrives at",
            "Flight arrival time",
          ],
        },
        {
          key: "arrivalFlight",
          header: "Arrival flight",
          kind: "text",
          aliases: [
            "Arrival flight number",
            "Inbound flight",
            "Flight in",
            "Arrival service",
          ],
        },
        {
          key: "departureTime",
          header: "Departure time",
          kind: "time",
          aliases: ["Takes off", "Departs at", "Flight departure time"],
        },
        {
          key: "departureFlight",
          header: "Departure flight",
          kind: "text",
          aliases: [
            "Departure flight number",
            "Outbound flight",
            "Flight out",
            "Departure service",
          ],
        },
        {
          key: "table",
          header: "Table",
          kind: "text",
          aliases: ["Seat", "Table number"],
        },
        {
          key: "together",
          header: "Group",
          kind: "text",
          aliases: [
            "Seat together",
            "Keep together",
            "Seating group",
            "Party",
            "Seat with",
          ],
        },
        {
          key: "apart",
          header: "Keep apart from",
          kind: "text",
          aliases: [
            "Keep apart",
            "Seat apart from",
            "Not with",
            "Do not seat with",
            "Avoid",
          ],
        },
        {
          key: "plusOnes",
          header: "Plus ones",
          kind: "int",
          aliases: ["Guests", "Plus one", "Additional guests"],
        },
        x,
      ],
    },
    sessions: {
      kind: "sessions",
      label: "Agenda sessions",
      idPrefix: "s",
      columns: [
        b,
        {
          key: "title",
          header: "Title",
          kind: "text",
          required: !0,
          aliases: ["Session", "Session title", "Name", "Topic"],
        },
        {
          key: "day",
          header: "Day",
          kind: "date",
          required: !0,
          aliases: ["Date"],
        },
        {
          key: "start",
          header: "Start",
          kind: "time",
          required: !0,
          aliases: ["Start time", "From"],
        },
        {
          key: "end",
          header: "End",
          kind: "time",
          aliases: ["End time", "To", "Until"],
        },
        {
          key: "track",
          header: "Track",
          kind: "text",
          aliases: ["Stream", "Category"],
        },
        {
          key: "room",
          header: "Room",
          kind: "text",
          aliases: ["Location", "Venue", "Hall"],
        },
        {
          key: "presenter",
          header: "Presenter",
          kind: "text",
          aliases: ["Speaker", "Speakers", "Host", "Facilitator"],
        },
        {
          key: "link",
          header: "Link",
          kind: "url",
          aliases: ["Join link", "URL", "Stream link", "Meeting link"],
        },
        {
          key: "timeZone",
          header: "Time zone",
          kind: "timezone",
          aliases: ["Timezone", "TZ"],
        },
        x,
      ],
    },
    vendors: {
      kind: "vendors",
      label: "Vendors",
      idPrefix: "v",
      columns: [
        b,
        {
          key: "name",
          header: "Name",
          kind: "text",
          required: !0,
          aliases: ["Vendor", "Company", "Supplier"],
        },
        {
          key: "category",
          header: "Category",
          kind: "text",
          aliases: ["Type", "Service"],
        },
        {
          key: "contact",
          header: "Contact",
          kind: "text",
          aliases: ["Contact person", "Contact name"],
        },
        {
          key: "email",
          header: "Email",
          kind: "email",
          aliases: ["E-mail", "Email address"],
        },
        {
          key: "phone",
          header: "Phone",
          kind: "phone",
          aliases: ["Telephone", "Mobile", "Phone number"],
        },
        x,
      ],
    },
    quotes: {
      kind: "quotes",
      label: "Quotes",
      idPrefix: "q",
      columns: [
        b,
        {
          key: "vendor",
          header: "Vendor",
          kind: "text",
          required: !0,
          aliases: ["Supplier", "Company"],
        },
        {
          key: "item",
          header: "Item",
          kind: "text",
          required: !0,
          aliases: ["Service", "Description", "Product"],
        },
        {
          key: "amount",
          header: "Amount",
          kind: "number",
          required: !0,
          min: 0,
          aliases: ["Price", "Quote", "Total", "Cost"],
        },
        {
          key: "currency",
          header: "Currency",
          kind: "currency",
          aliases: ["Cur"],
        },
        {
          key: "validUntil",
          header: "Valid until",
          kind: "date",
          aliases: ["Expires", "Valid to", "Expiry"],
        },
        {
          key: "status",
          header: "Status",
          kind: "enum",
          values: de,
          default: "requested",
          synonyms: {
            pending: "requested",
            asked: "requested",
            sent: "requested",
            approved: "accepted",
            won: "accepted",
            declined: "rejected",
            lost: "rejected",
          },
        },
        {
          key: "rating",
          header: "Rating",
          kind: "number",
          aliases: ["Vendor rating", "Stars"],
        },
        {
          key: "depositPct",
          header: "Deposit %",
          kind: "percent",
          aliases: ["Deposit", "Deposit percent"],
        },
        {
          key: "cancellation",
          header: "Cancellation",
          kind: "enum",
          values: ue,
          aliases: ["Cancellation terms"],
          synonyms: {
            easy: "flexible",
            free: "flexible",
            partial: "moderate",
            medium: "moderate",
            "non-refundable": "strict",
            nonrefundable: "strict",
            none: "strict",
            hard: "strict",
          },
        },
        x,
      ],
    },
    expenses: {
      kind: "expenses",
      label: "Expenses and income",
      idPrefix: "e",
      columns: [
        b,
        { key: "date", header: "Date", kind: "date", required: !0 },
        {
          key: "description",
          header: "Description",
          kind: "text",
          required: !0,
          aliases: ["Item", "Details", "Memo"],
        },
        {
          key: "kind",
          header: "Type",
          kind: "enum",
          values: ce,
          default: "cost",
          aliases: ["Kind", "Direction"],
          synonyms: {
            expense: "cost",
            spend: "cost",
            payment: "cost",
            revenue: "income",
            receipt: "income",
            sale: "income",
          },
        },
        {
          key: "category",
          header: "Category",
          kind: "text",
          aliases: ["Group"],
        },
        {
          key: "vendor",
          header: "Vendor",
          kind: "text",
          aliases: ["Supplier", "Paid to", "Payee", "Client"],
        },
        {
          key: "amount",
          header: "Amount",
          kind: "number",
          required: !0,
          aliases: ["Total", "Cost", "Price"],
        },
        {
          key: "currency",
          header: "Currency",
          kind: "currency",
          aliases: ["Cur"],
        },
        {
          key: "taxType",
          header: "Tax type",
          kind: "enum",
          values: L,
          default: "none",
          aliases: ["Tax"],
          synonyms: {
            "sales tax": "sales_tax",
            "no tax": "none",
            gst: "gst",
            vat: "vat",
          },
        },
        {
          key: "taxRate",
          header: "Tax rate %",
          kind: "percent",
          aliases: ["Tax rate", "Rate", "Tax %"],
        },
        {
          key: "taxIncluded",
          header: "Tax included",
          kind: "bool",
          default: !1,
          aliases: ["Includes tax", "Inclusive"],
        },
        {
          key: "status",
          header: "Income status",
          kind: "enum",
          values: me,
          aliases: ["Payment status", "Pledge status"],
          synonyms: {
            received: "paid",
            settled: "paid",
            promised: "pledged",
            committed: "pledged",
            unpaid: "pledged",
            outstanding: "pledged",
          },
        },
        {
          key: "receipt",
          header: "Receipt",
          kind: "text",
          aliases: [
            "Receipt number",
            "Receipt no",
            "Invoice number",
            "Invoice",
          ],
        },
        x,
      ],
    },
    rooms: {
      kind: "rooms",
      label: "Rooming list",
      idPrefix: "r",
      columns: [
        b,
        {
          key: "guest",
          header: "Guest",
          kind: "text",
          required: !0,
          aliases: ["Name", "Guest name", "Occupant"],
        },
        { key: "hotel", header: "Hotel", kind: "text", aliases: ["Property"] },
        {
          key: "roomType",
          header: "Room type",
          kind: "text",
          aliases: ["Type", "Room"],
        },
        {
          key: "checkIn",
          header: "Check in",
          kind: "date",
          required: !0,
          aliases: ["Check-in", "Arrival", "In"],
        },
        {
          key: "checkOut",
          header: "Check out",
          kind: "date",
          required: !0,
          aliases: ["Check-out", "Departure", "Out"],
        },
        {
          key: "sharedWith",
          header: "Shared with",
          kind: "text",
          aliases: ["Sharing with", "Roommate"],
        },
        x,
      ],
    },
    tasks: {
      kind: "tasks",
      label: "Tasks",
      idPrefix: "t",
      columns: [
        b,
        {
          key: "title",
          header: "Task",
          kind: "text",
          required: !0,
          aliases: ["Title", "Item", "To do", "Name", "Description"],
        },
        {
          key: "due",
          header: "Due",
          kind: "date",
          aliases: ["Due date", "Deadline", "Date", "By"],
        },
        {
          key: "done",
          header: "Done",
          kind: "bool",
          default: !1,
          aliases: ["Complete", "Completed", "Finished", "Status"],
        },
        {
          key: "owner",
          header: "Owner",
          kind: "text",
          aliases: ["Assigned to", "Responsible", "Who"],
        },
        {
          key: "category",
          header: "Category",
          kind: "text",
          aliases: ["Group", "Area"],
        },
        x,
      ],
    },
    exhibitors: {
      kind: "exhibitors",
      label: "Exhibitors",
      idPrefix: "x",
      columns: [
        b,
        {
          key: "company",
          header: "Company",
          kind: "text",
          required: !0,
          aliases: [
            "Exhibitor",
            "Name",
            "Organisation",
            "Organization",
            "Business",
          ],
        },
        {
          key: "booth",
          header: "Booth",
          kind: "text",
          aliases: ["Stand", "Booth number", "Stand number", "Space"],
        },
        {
          key: "contact",
          header: "Contact",
          kind: "text",
          aliases: ["Contact person", "Contact name"],
        },
        {
          key: "email",
          header: "Email",
          kind: "email",
          aliases: ["E-mail", "Email address"],
        },
        {
          key: "phone",
          header: "Phone",
          kind: "phone",
          aliases: ["Telephone", "Mobile", "Phone number"],
        },
        {
          key: "status",
          header: "Status",
          kind: "enum",
          values: pe,
          default: "enquiry",
          synonyms: {
            lead: "enquiry",
            inquiry: "enquiry",
            interested: "enquiry",
            reserved: "booked",
            confirmed: "booked",
            signed: "booked",
            deposit: "booked",
            "paid in full": "paid",
            settled: "paid",
            withdrawn: "cancelled",
            declined: "cancelled",
            cancelled: "cancelled",
            canceled: "cancelled",
          },
        },
        {
          key: "fee",
          header: "Fee",
          kind: "number",
          aliases: ["Booth fee", "Price", "Amount", "Cost"],
        },
        {
          key: "paid",
          header: "Paid",
          kind: "number",
          aliases: [
            "Paid so far",
            "Received",
            "Payment received",
            "Deposit paid",
          ],
        },
        {
          key: "currency",
          header: "Currency",
          kind: "currency",
          aliases: ["Cur"],
        },
        {
          key: "needs",
          header: "Needs",
          kind: "longtext",
          aliases: ["Requirements", "Requests", "Power and wifi", "Extras"],
        },
        x,
      ],
    },
    budgets: {
      kind: "budgets",
      label: "Budget lines",
      idPrefix: "b",
      columns: [
        b,
        {
          key: "category",
          header: "Category",
          kind: "text",
          required: !0,
          aliases: ["Item", "Line", "Name", "Budget line"],
        },
        {
          key: "planned",
          header: "Planned",
          kind: "number",
          required: !0,
          aliases: ["Budget", "Budgeted", "Amount", "Allocated"],
        },
        {
          key: "currency",
          header: "Currency",
          kind: "currency",
          aliases: ["Cur"],
        },
        x,
      ],
    },
  },
  w = (t) => t.toLowerCase().replace(/[^a-z0-9]+/g, ""),
  ke = 2e4;
function he(t, e) {
  switch (t.kind) {
    case "id": {
      const n = v(e, 40);
      return n.ok
        ? X(n.value)
          ? n
          : { ok: !1, message: "may only use letters, digits, _ and -" }
        : n;
    }
    case "text":
      return v(e, 300);
    case "longtext":
      return v(e, 2e3);
    case "email":
      return W(e);
    case "phone":
      return Q(e);
    case "url":
      return ee(e);
    case "int":
      return re(e, 0, 1e3);
    case "number": {
      if (t.min !== void 0) {
        const n = N(e);
        if (n !== null && n < t.min)
          return {
            ok: !1,
            message:
              t.min === 0
                ? "must not be negative"
                : `must be at least ${t.min}`,
          };
      }
      return j(e);
    }
    case "percent":
      return j(e, 0, 100);
    case "bool":
      return ie(e);
    case "date":
      return te(e);
    case "time":
      return ne(e);
    case "currency":
      return M(e);
    case "timezone":
      return _(e);
    case "enum":
      return oe(e, t.values ?? [], t.synonyms ?? {});
  }
}
function ge(t, e, n) {
  return t === "rooms" &&
    typeof e.checkIn == "string" &&
    typeof e.checkOut == "string" &&
    e.checkOut <= e.checkIn
    ? "Check out must be after check in"
    : (t === "guests" &&
        typeof e.arrival == "string" &&
        typeof e.departure == "string" &&
        e.departure < e.arrival &&
        (n("Departure", "is before the arrival date, so it was dropped"),
        delete e.departure),
      t === "expenses" &&
        (e.taxType === "none" &&
          e.taxRate !== void 0 &&
          (n("Tax rate %", "was ignored because the tax type is none"),
          delete e.taxRate),
        e.taxType !== "none" &&
          e.taxRate === void 0 &&
          n("Tax rate %", "is blank, so no tax is calculated for this row")),
      null);
}
function V(t, e, n, r, i, s) {
  const d = T[t],
    a = {};
  let u = !1;
  const f = (o, l) =>
    i.push({ row: r, column: o, level: "warning", message: l });
  for (const o of d.columns) {
    const l = e(o).trim();
    if (l === "") {
      o.required
        ? (i.push({
            row: r,
            column: o.header,
            level: "error",
            message: "is required",
          }),
          (u = !0))
        : o.default !== void 0 && (a[o.key] = o.default);
      continue;
    }
    const c = he(o, l);
    c.ok
      ? (a[o.key] = c.value)
      : o.required
        ? (i.push({
            row: r,
            column: o.header,
            value: l,
            level: "error",
            message: c.message,
          }),
          (u = !0))
        : (i.push({
            row: r,
            column: o.header,
            value: l,
            level: "warning",
            message: `${c.message}, so it was left blank`,
          }),
          o.default !== void 0 && (a[o.key] = o.default));
  }
  if (u) return null;
  const y = ge(t, a, f);
  if (y) return (i.push({ row: r, level: "error", message: y }), null);
  d.columns.some((o) => o.key === "currency") &&
    a.currency === void 0 &&
    (a.currency = n.currency);
  let p = typeof a.id == "string" ? a.id : "";
  return (
    p &&
      s.has(p) &&
      (f("ID", "is used by an earlier row, so a new one was made"), (p = "")),
    p || (p = J(d.idPrefix)),
    s.add(p),
    (a.id = p),
    a
  );
}
function Ue(t) {
  const e = t.column ? t.column.toLowerCase() : "",
    n =
      t.value !== void 0
        ? ` '${t.value.length > 40 ? t.value.slice(0, 40) + "…" : t.value}'`
        : "";
  return `Row ${t.row}: ${e ? e + n + " " : ""}${t.message}`;
}
function Fe(t, e, n) {
  const r = T[t],
    i = [],
    s = {
      records: [],
      issues: i,
      rowsRead: 0,
      rowsSkipped: 0,
      unknownColumns: [],
    },
    d = z(e);
  if (d.length === 0)
    return (
      i.push({ row: 1, level: "error", message: "The file is empty." }),
      s
    );
  const a = new Map();
  for (const l of r.columns) {
    a.set(w(l.header), l);
    for (const c of l.aliases ?? []) a.has(w(c)) || a.set(w(c), l);
  }
  const u = new Map();
  d[0].forEach((l, c) => {
    const h = a.get(w(l));
    h && !u.has(h) ? u.set(h, c) : l.trim() && s.unknownColumns.push(l.trim());
  });
  const f = r.columns.filter((l) => l.required && !u.has(l));
  if (f.length)
    return (
      i.push({
        row: 1,
        level: "error",
        message: `The file is missing the required column${f.length > 1 ? "s" : ""}: ${f.map((l) => l.header).join(", ")}.`,
      }),
      s
    );
  const y = n.maxRows ?? ke,
    p = new Set(),
    o = d.slice(1);
  return (
    o.length > y &&
      i.push({
        row: y + 2,
        level: "warning",
        message: `Only the first ${y} rows were read.`,
      }),
    o.slice(0, y).forEach((l, c) => {
      s.rowsRead++;
      const h = V(
        t,
        (E) => {
          const C = u.get(E);
          return C === void 0 ? "" : (l[C] ?? "");
        },
        n,
        c + 2,
        i,
        p,
      );
      h ? s.records.push(h) : s.rowsSkipped++;
    }),
    s
  );
}
function be(t) {
  return t == null
    ? ""
    : typeof t == "boolean"
      ? t
        ? "yes"
        : "no"
      : typeof t == "number" || typeof t == "string"
        ? t
        : String(t);
}
function _e(t, e) {
  const n = T[t],
    r = n.columns.map((s) => ({ key: s.key, header: s.header })),
    i = e.map((s) => {
      const d = {};
      for (const a of n.columns) d[a.key] = be(s[a.key]);
      return d;
    });
  return U(i, r);
}
function Me(t) {
  return U(
    [],
    T[t].columns.map((e) => ({ key: e.key, header: e.header })),
  );
}
function Le(t, e) {
  const n = [`${t.records.length} ${e} imported`];
  t.rowsSkipped &&
    n.push(`${t.rowsSkipped} row${t.rowsSkipped === 1 ? "" : "s"} skipped`);
  const r = t.issues.filter((i) => i.level === "warning").length;
  return (r && n.push(`${r} warning${r === 1 ? "" : "s"}`), n.join(", ") + ".");
}
const xe = { taxType: "none", taxRate: null, taxIncluded: !1 },
  Se = (t) => typeof t == "object" && t !== null && !Array.isArray(t);
function Te(t) {
  if (!Se(t)) return;
  const e = L.includes(String(t.taxType)) ? t.taxType : "none",
    n =
      typeof t.taxRate == "number"
        ? t.taxRate
        : typeof t.taxRate == "string"
          ? Number(t.taxRate)
          : NaN,
    r =
      e !== "none" && Number.isFinite(n) && n > 0 && n <= 100
        ? Math.round(n * 1e3) / 1e3
        : null;
  return {
    taxType: r === null ? "none" : e,
    taxRate: r,
    taxIncluded: t.taxIncluded === !0 && r !== null,
  };
}
function Ge(t, e) {
  if (t === "none") return null;
  const n = e.trim().replace(/%$/, "");
  if (!n) return "Enter the tax rate, or choose No tax.";
  const r = Number(n);
  return !Number.isFinite(r) || r <= 0 || r > 100
    ? "The tax rate must be above 0 and at most 100."
    : null;
}
function Ve(t, e) {
  return !e || e.taxType === "none" || e.taxRate === null
    ? t
    : {
        ...t,
        taxType: e.taxType,
        taxRate: e.taxRate,
        taxIncluded: e.taxIncluded,
      };
}
const ve = [
  {
    type: "Wedding",
    guestGroups: [
      "Bride's family",
      "Groom's family",
      "Friends",
      "Wedding party",
    ],
    ticketTiers: [],
    taxIncludedUsually: !1,
    tip: "Vendors usually quote before tax, so costs start with tax added on top.",
  },
  {
    type: "Birthday",
    guestGroups: ["Family", "Friends", "Work"],
    ticketTiers: [],
    taxIncludedUsually: !1,
    tip: "Mostly private spending: set a tax rate only if you reclaim it.",
  },
  {
    type: "Corporate event",
    guestGroups: ["Staff", "Clients", "Partners", "Speakers"],
    ticketTiers: [],
    taxIncludedUsually: !1,
    tip: "Companies often reclaim VAT or GST, so keep costs before tax and the tax separate.",
  },
  {
    type: "Conference",
    guestGroups: ["Delegates", "Speakers", "Sponsors", "Press", "Volunteers"],
    ticketTiers: ["Early bird", "Standard", "Student", "Group"],
    taxIncludedUsually: !0,
    tip: "Ticket prices are often shown with tax included; costs from vendors usually are not.",
  },
  {
    type: "Exhibition or trade show",
    guestGroups: ["Exhibitors", "Visitors", "Speakers", "Press", "Staff"],
    ticketTiers: ["Visitor", "Trade", "Exhibitor"],
    taxIncludedUsually: !1,
    tip: "Stand fees are normally quoted before tax.",
  },
  {
    type: "Fundraiser",
    guestGroups: ["Table hosts", "Donors", "Sponsors", "Volunteers"],
    ticketTiers: ["Individual seat", "Table of ten", "Sponsor"],
    taxIncludedUsually: !0,
    tip: "Donations are usually outside tax; leave tax off income lines that are gifts.",
  },
];
function Ce(t) {
  return ve.find((e) => e.type === t);
}
function Ke(t, e, n) {
  const r = Ce(t);
  return e === "none" || n === null
    ? xe
    : { taxType: e, taxRate: n, taxIncluded: r?.taxIncludedUsually ?? !1 };
}
const we = 1,
  Pe = 25e6,
  R = 2e4;
function K() {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
  } catch {
    return "UTC";
  }
}
function A(t = {}) {
  return {
    name: t.name ?? "My event",
    currency: t.currency ?? "USD",
    locale: t.locale ?? "en-US",
    timeZone: t.timeZone ?? K(),
    paper: t.paper ?? "letter",
    passKey: t.passKey ?? F(),
    data: G(),
  };
}
function Ee(t, e = new Date()) {
  const n = {
    app: "freedailypro",
    kind: "project",
    version: 1,
    saved: e.toISOString(),
    project: t,
  };
  return JSON.stringify(n, null, 2);
}
const P = (t) => typeof t == "object" && t !== null && !Array.isArray(t);
function S(t) {
  return t == null
    ? ""
    : typeof t == "boolean"
      ? t
        ? "yes"
        : "no"
      : typeof t == "number"
        ? Number.isFinite(t)
          ? String(t)
          : ""
        : typeof t == "string"
          ? t
          : "";
}
function Re(t) {
  if (t.length > Pe)
    return { ok: !1, error: "That file is too large to be a project file." };
  let e;
  try {
    e = JSON.parse(t);
  } catch {
    return {
      ok: !1,
      error: "That isn't a project file (it isn't valid JSON).",
    };
  }
  if (
    !P(e) ||
    e.app !== "freedailypro" ||
    e.kind !== "project" ||
    !P(e.project)
  )
    return { ok: !1, error: "That isn't a FreeDailyPro project file." };
  if (typeof e.version != "number" || e.version > we)
    return {
      ok: !1,
      error:
        "That project file was made by a newer version. Reload the page and try again.",
    };
  const n = e.project,
    r = [],
    i = (c) => r.push({ row: 0, level: "warning", message: c }),
    s = v(S(n.name), 120),
    d = M(S(n.currency)),
    a = _(S(n.timeZone)),
    u = /^[A-Za-z]{2,3}(-[A-Za-z0-9]{2,8})*$/.test(S(n.locale))
      ? S(n.locale)
      : "en-US",
    f = fe.includes(S(n.paper)) ? S(n.paper) : "letter";
  let y = S(n.passKey);
  Y(y) ||
    ((y = F()),
    i(
      "The pass key was missing or damaged, so a new one was made. Passes printed before will not check in.",
    ));
  const p = {
      name: s.ok && s.value ? s.value : "My event",
      currency: d.ok ? d.value : "USD",
      locale: u,
      timeZone: a.ok ? a.value : K(),
      paper: f,
      passKey: y,
      data: G(),
    },
    o = Te(n.finance);
  o && (p.finance = o);
  const l = P(n.data) ? n.data : {};
  for (const c of ye) {
    const h = l[c];
    if (h === void 0) continue;
    if (!Array.isArray(h)) {
      i(
        `The ${T[c].label.toLowerCase()} list was not a list, so it was ignored.`,
      );
      continue;
    }
    const E = new Set(),
      C = [];
    (h.slice(0, R).forEach((q, $) => {
      if (!P(q)) {
        r.push({
          row: $ + 1,
          level: "error",
          message: `${T[c].label}: entry is not a record`,
        });
        return;
      }
      const B = r.length,
        O = V(c, (g) => S(q[g.key]), { currency: p.currency }, $ + 1, r, E);
      for (let g = B; g < r.length; g++)
        r[g] = {
          ...r[g],
          message: `${T[c].label}: ${r[g].column ? r[g].column + " " : ""}${r[g].message}`,
        };
      O && C.push(O);
    }),
      h.length > R &&
        i(`Only the first ${R} ${T[c].label.toLowerCase()} were read.`),
      (p.data[c] = C));
  }
  return { ok: !0, project: p, issues: r };
}
const I = "fdp-project-v1";
function Ie(t) {
  let e = null;
  const n = new Set(),
    r = () => {
      if (t)
        try {
          const a = t.getItem(I);
          if (a) {
            const u = Re(a);
            if (u.ok) return u.project;
          }
        } catch {}
      return A();
    },
    i = (a) => {
      if (t)
        try {
          t.setItem(I, Ee(a));
        } catch {}
    },
    s = (a) => {
      ((e = a), i(a), Array.from(n).forEach((u) => u()));
    },
    d = {
      get: () => (e ??= r()),
      set: (a) => s(typeof a == "function" ? a(d.get()) : a),
      setRecords: (a, u) =>
        d.set((f) => ({ ...f, data: { ...f.data, [a]: u } })),
      upsertRecords: (a, u) =>
        d.set((f) => {
          const y = [...f.data[a]];
          for (const p of u) {
            const o = y.findIndex((l) => l.id === p.id);
            o >= 0 ? (y[o] = p) : y.push(p);
          }
          return { ...f, data: { ...f.data, [a]: y } };
        }),
      reset: (a) => {
        if (!a && t)
          try {
            t.removeItem(I);
          } catch {}
        s(a ?? A());
      },
      subscribe: (a) => (
        n.add(a),
        () => {
          n.delete(a);
        }
      ),
    };
  return d;
}
let D = null;
function De() {
  if (!D) {
    let t = null;
    try {
      t = typeof sessionStorage < "u" ? sessionStorage : null;
    } catch {
      t = null;
    }
    D = Ie(t);
  }
  return D;
}
const Ae = A({ passKey: "server-render-placeholder-key" });
function Be() {
  const t = De();
  return [Z.useSyncExternalStore(t.subscribe, t.get, () => Ae), t];
}
export {
  ue as C,
  pe as E,
  le as G,
  T as L,
  de as Q,
  L as T,
  Q as a,
  te as b,
  W as c,
  Le as d,
  _e as e,
  v as f,
  Ue as g,
  Ce as h,
  Fe as i,
  Ge as j,
  Ke as k,
  A as l,
  Re as m,
  N as p,
  Ee as s,
  Me as t,
  Be as u,
  Ve as w,
};
//# sourceMappingURL=useProject-B_EqpXu3.js.map
