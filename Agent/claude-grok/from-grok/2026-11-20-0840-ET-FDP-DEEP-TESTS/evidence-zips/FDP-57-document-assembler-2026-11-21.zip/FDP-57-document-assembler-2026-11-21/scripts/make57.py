# FDP-57 Document Assembler test files (reportlab, pikepdf, python-docx, PIL)
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter, A4, landscape
import pikepdf, docx, io
from docx.shared import Inches
from PIL import Image, ImageDraw

def pdf(name, pages, size=letter, title='Doc', link=False, outline=False):
    c = canvas.Canvas(name, pagesize=size); w, h = size
    for i in range(1, pages+1):
        c.setFont('Helvetica-Bold', 22); c.drawString(72, h-90, f'{title} page {i} of {pages}')
        c.setFont('Helvetica', 11)
        for k in range(20): c.drawString(72, h-130-k*16, f'{title} body line {k+1}: searchable text for assembly testing.')
        if link and i == 1:
            c.drawString(72, 120, 'Visit https://example.com/assembler-link'); c.linkURL('https://example.com/assembler-link', (72, 115, 330, 132), relative=0)
        if outline:
            c.bookmarkPage(f'p{i}'); c.addOutlineEntry(f'{title} chapter {i}', f'p{i}', level=0)
        c.showPage()
    c.save()

pdf('report_letter_3p.pdf', 3, letter, 'Report', link=True, outline=True)
pdf('appendix_a4_landscape_2p.pdf', 2, landscape(A4), 'Appendix')
pdf('rotated_2p.pdf', 2, letter, 'Rotated')
p = pikepdf.open('rotated_2p.pdf', allow_overwriting_input=True); p.pages[1].Rotate = 90; p.save('rotated_2p.pdf')
pdf('long_60p.pdf', 60, letter, 'Long')
# form PDF
c = canvas.Canvas('form_filled.pdf', pagesize=letter); c.setFont('Helvetica-Bold', 18); c.drawString(72, 700, 'Form page')
f = c.acroForm; c.setFont('Helvetica', 11); c.drawString(72, 655, 'Name:')
f.textfield(name='name', value='Asha Rao FILLED', x=130, y=645, width=250, height=22)
f.checkbox(name='agree', checked=True, x=130, y=610, size=16); c.drawString(155, 612, 'Agree (checked)'); c.showPage(); c.save()
# docx
d = docx.Document(); d.add_heading('Cover Letter DOCX', 0); pp = d.add_paragraph('Dear team, this is '); pp.add_run('bold text').bold = True; pp.add_run(' and '); pp.add_run('italic').italic = True
d.add_paragraph('Bullet one', style='List Bullet'); d.add_paragraph('Bullet two', style='List Bullet')
t = d.add_table(rows=2, cols=3); t.style = 'Table Grid'
for r in range(2):
    for k in range(3): t.cell(r, k).text = f'R{r+1}C{k+1}'
d.add_paragraph('Unicode: café naïve — 日本語 テスト — हिन्दी — Ελληνικά — Русский')
img = Image.new('RGB', (400, 200), (30, 120, 200)); ImageDraw.Draw(img).text((20, 80), 'DOCX IMAGE', fill='white'); bio = io.BytesIO(); img.save(bio, 'PNG'); bio.seek(0)
d.add_picture(bio, width=Inches(3)); d.add_page_break(); d.add_heading('Second page heading', 1); d.add_paragraph('Text on docx page 2.'); d.save('cover_letter.docx')
open('notes_utf8.txt', 'w', encoding='utf-8').write('Notes TXT title line\n\nUTF-8 text: café, naïve, 日本語, हिन्दी, emoji 🙂, “smart quotes”.\n' + '\n'.join(f'Line {i}: plain notes text.' for i in range(1, 80)))
open('notes_cp1252.txt', 'wb').write('Windows-1252 text: café naïve “quotes” – en dash € euro\n'.encode('cp1252'))
open('empty.txt', 'w').write('   \n\n  ')
open('fake.docx', 'w').write('this is not a docx')
open('old.doc', 'w').write('legacy doc')
# images
im = Image.new('RGB', (1200, 800), (240, 240, 240)); dr = ImageDraw.Draw(im); dr.rectangle((0, 0, 1199, 120), fill=(200, 30, 30)); dr.text((40, 40), 'TOP (red band) - EXIF orientation 6 photo', fill='white')
ex = Image.Exif(); ex[0x0112] = 6; im.save('photo_exif6.jpg', exif=ex, quality=90)
w = Image.new('RGBA', (4000, 1000), (0, 0, 0, 0)); ImageDraw.Draw(w).rectangle((100, 100, 3900, 900), fill=(20, 160, 90, 255)); w.save('wide_transparent.png')
Image.new('RGB', (50, 50), (200, 0, 200)).save('tiny.png')
Image.new('RGB', (300, 300), (0, 0, 200)).save('blue.webp')
open('renamed_text.png', 'w').write('not an image')
print('ok')
