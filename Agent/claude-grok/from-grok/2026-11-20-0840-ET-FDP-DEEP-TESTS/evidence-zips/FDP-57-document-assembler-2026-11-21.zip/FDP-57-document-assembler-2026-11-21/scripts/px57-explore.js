// FDP-57 explore (guest, as-is context): add 3 files, assemble at the cap, inspect the preview element and buttons. No download clicked.
const { chromium } = require('playwright'); const fs = require('fs'); const OUT = '/workspace/deep/57-document-assembler/live/'; const TF = '/workspace/deep/57-document-assembler/testfiles/';
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage();
 await p.goto('https://www.freedailypro.com/tool/document-assembler', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 const used = await p.evaluate(() => localStorage.getItem('fdp-usage-v1').replace(/dev:[^"]*/, 'dev:REDACTED'));
 await p.locator('main input[type=file]').first().setInputFiles(['report_letter_3p.pdf', 'cover_letter.docx', 'photo_exif6.jpg'].map(f => TF + f)); await p.waitForTimeout(2000);
 await p.locator('main input[placeholder^="e.g."]').first().fill('Explore Packet');
 await p.getByRole('button', { name: 'Assemble Document' }).click(); await p.waitForTimeout(12000);
 const info = await p.evaluate(() => { const m = document.querySelector('main'); return { done: m.querySelector('[data-testid=da-done]')?.innerText, err: m.querySelector('[data-testid=da-error]')?.innerText,
  buttons: [...m.querySelectorAll('button,a')].map(x => x.innerText.trim()).filter(t => /Download|New Document|Save|Drive|cloud|Share|Print|Open/i.test(t)),
  frames: [...m.querySelectorAll('iframe,embed,object')].map(x => ({ tag: x.tagName, src: (x.src || x.data || '').slice(0, 40), w: x.clientWidth, h: x.clientHeight })),
  canv: [...m.querySelectorAll('canvas')].map(x => [x.width, x.height]).slice(0, 8), imgs: [...m.querySelectorAll('img')].filter(i => i.src.startsWith('blob:') || i.src.startsWith('data:')).map(i => [i.naturalWidth, i.naturalHeight]).slice(0, 8) }; });
 await p.screenshot({ path: OUT + 'cases/explore-after-assemble.png', fullPage: true });
 fs.writeFileSync(OUT + 'explore.json', JSON.stringify({ used, info }, null, 1)); console.log(used, JSON.stringify(info)); await b.close(); })();
