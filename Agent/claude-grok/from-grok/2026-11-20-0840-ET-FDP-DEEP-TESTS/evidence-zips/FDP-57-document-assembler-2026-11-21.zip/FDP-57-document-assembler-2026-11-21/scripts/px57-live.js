// FDP-57 Document Assembler, guest. Usage: node px57-live.js <probe|left|cases> [engine]  (TRIES env = fresh contexts to try; CASES=C1,C2 subset; SUF suffix)
// probe: as-is context -> validation, bad files, project buttons, assemble at the cap, Download at the cap (dialog?), Save to Drive / cloud (stop at sign-in), Quick Buy (stop at email / Stripe).
// left: context with uses left -> Assemble+Download, Download again, re-assemble same load + Download, reload + Assemble + Download. Tracks fdp-usage-v1 + usage POSTs.
// cases: one fresh context with uses left; every case is assembled and downloaded in the SAME page load (also shows the per-page-load gate).
// Never signs in, never types email/card, never clicks pass "Continue" or ads. Closes only popups it opened.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/57-document-assembler/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/document-assembler';
const mode = process.argv[2] || 'probe'; const eng = process.argv[3] || 'chromium'; const sfx = (eng === 'chromium' ? '' : '-' + eng) + (process.env.SUF || '');
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh|scope)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').replace(/dev[:%][^&"]*/g, 'dev:REDACTED').slice(0, 160);
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p, net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, acceptDownloads: true, locale: 'en-US' }); p = await c.newPage(); p.setDefaultTimeout(10000); net = [];
  await p.addInitScript(() => { window.__t = []; const seen = new WeakSet(); setInterval(() => { document.querySelectorAll('[data-sonner-toast]').forEach(n => { if (!seen.has(n)) { seen.add(n); window.__t.push((n.innerText || '').trim()); } }); }, 120); });
  p.on('request', r => { const u = r.url(); if (r.method() === 'POST' && !/google|doubleclick|insight\.hit|funnel\.hit|analytics|admaster|media\.net/.test(u)) net.push({ t: now(), u: red(u), len: (r.postData() || '').length }); });
  await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 450) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(250); } };
 const toasts = n => p.evaluate(n => (window.__t || []).slice(n), n); const tc = () => p.evaluate(() => (window.__t || []).length);
 const st = () => p.evaluate(() => { const m = document.querySelector('main'); return { done: m.querySelector('[data-testid=da-done]')?.innerText || null, err: m.querySelector('[data-testid=da-error]')?.innerText || null, sections: [...m.querySelectorAll('input[placeholder^="Section title"]')].map(i => i.value), strip: (m.innerText.match(/Trial:[^\n]*/) || [null])[0], btns: [...m.querySelectorAll('button')].map(x => x.innerText.trim()).filter(t => /^Download|Day Pass|Save to|New Document|Assemble/.test(t)) }; });
 const add = async (files) => { const n = await tc(); await p.locator('main input[type=file][multiple]').first().setInputFiles(files.map(f => TF + f)); await p.waitForTimeout(1800); return { toasts: await toasts(n), ...(await st()) }; };
 const setTitle = async (t) => { await p.locator('main input[placeholder^="e.g."]').first().fill(t); };
 const setAuthor = async (t) => { const i = p.locator('main input').nth(1); await p.locator('main input[placeholder^="e.g."]').first().locator('xpath=following::input[1]').fill(t); };
 const chk = async (id, on) => { const l = p.locator('#' + id); if (((await l.getAttribute('data-state')) === 'checked') !== on) await l.click(); await p.waitForTimeout(150); };
 const size = async (label) => { await p.locator('main button[role=combobox]').first().click(); await p.waitForTimeout(300); await p.getByRole('option', { name: new RegExp('^' + label.replace(/[.()]/g, '\\$&')) }).first().click(); await p.waitForTimeout(300); };
 const newDoc = async () => { const bt = p.getByRole('button', { name: 'New Document' }); if (await bt.count()) { await bt.click(); await p.waitForTimeout(500); } for (let k = 0; k < 30; k++) { const rm = p.locator('main button[aria-label^="Remove "]'); if (!(await rm.count())) break; await rm.first().click(); await p.waitForTimeout(120); } };
 const assemble = async (id) => { const n = await tc(); const before = await used(); const t0 = Date.now(); await p.getByRole('button', { name: 'Assemble Document' }).click();
  await p.waitForFunction(() => document.querySelector('[data-testid=da-done]') || document.querySelector('[data-testid=da-error]') || document.querySelector('[role=dialog]'), null, { timeout: 180000 }).catch(() => { }); await p.waitForTimeout(800);
  const r = { ms: Date.now() - t0, before, after: await used(), toasts: await toasts(n), dialog: await dialog(), ...(await st()) }; await p.screenshot({ path: OUT + 'cases/' + id + sfx + '.png', fullPage: true }); if (r.dialog) { await p.screenshot({ path: OUT + 'cases/' + id + sfx + '-dialog.png' }); await esc(); } return r; };
 const download = async (id) => { const n = await tc(); const before = await used(); const nb = net.length; const bt = p.locator('main button', { hasText: /^Download Document/ }); if (!(await bt.count())) return { none: true };
  const dp = p.waitForEvent('download', { timeout: 30000 }).catch(() => null); await bt.first().click(); const d = await dp; await p.waitForTimeout(2500); const r = { before, after: await used(), toasts: await toasts(n), dialog: await dialog(), posts: net.slice(nb).map(x => x.u) };
  if (d) { const f = OUT + 'downloads/' + id + sfx + '-' + d.suggestedFilename(); await d.saveAs(f); r.file = { name: d.suggestedFilename(), bytes: fs.statSync(f).size }; } if (r.dialog) { await p.screenshot({ path: OUT + 'cases/' + id + sfx + '-dl-dialog.png' }); await esc(); } return r; };
 const C = async (id, fn) => { try { R.cases[id] = await fn(); } catch (e) { R.cases[id] = { err: e.message.split('\n')[0].slice(0, 200) }; await esc().catch(() => { }); } console.log(id, JSON.stringify(R.cases[id]).slice(0, 700)); };
 const findLeft = async (max) => { const TRIES = +(max || process.env.TRIES || 10); for (let i = 0; i < TRIES; i++) { await open(); const u = await used(); R.tries.push(u); const [a, l] = u.split('/').map(Number); if (a < l) return true; await c.close(); } return false; };
 if (mode === 'probe') { await open(); R.start = { used: await used(), accept: await p.locator('main input[type=file][multiple]').first().getAttribute('accept'), ...(await st()) };
  await C('P01-assemble-empty', async () => { await p.getByRole('button', { name: 'Assemble Document' }).click(); await p.waitForTimeout(800); return st(); });
  await C('P02-skip-types', () => add(['blue.webp', 'old.doc', 'report_letter_3p.pdf']));
  await C('P03-cover-no-title', async () => { await p.getByRole('button', { name: 'Assemble Document' }).click(); await p.waitForTimeout(800); return { ...(await st()), focused: await p.evaluate(() => document.activeElement?.getAttribute('placeholder')) }; });
  for (const [id, f] of [['P04-fake-docx', 'fake.docx'], ['P05-empty-txt', 'empty.txt'], ['P06-password-pdf', 'password_u123.pdf'], ['P07-damaged-pdf', 'damaged.pdf'], ['P08-renamed-png', 'renamed_text.png']])
   await C(id, async () => { await newDoc(); const a = await add(['report_letter_3p.pdf', f]); await setTitle('Error test'); const r = await assemble(id); return { added: a.toasts, ...r }; });
  await C('P09-duplicate', async () => { await newDoc(); const a = await add(['report_letter_3p.pdf']); const b2 = await add(['report_letter_3p.pdf']); return { first: a.sections, second: b2 }; });
  await C('P10-project-agenda-empty', async () => { const n = await tc(); await p.getByRole('button', { name: 'Agenda', exact: true }).click(); await p.waitForTimeout(1200); return { toasts: await toasts(n), ...(await st()) }; });
  await C('P11-try-sample-then-guestlist', async () => { const n = await tc(); await p.getByRole('button', { name: 'Try a sample' }).click(); await p.waitForTimeout(1500); const d = await dialog(); if (d) { await p.screenshot({ path: OUT + 'cases/P11-sample-dialog' + sfx + '.png' }); const ok = p.locator('[role=dialog] button', { hasText: /Load|Try|Yes|Open|Continue/ }); if (await ok.count()) await ok.first().click(); else await esc(); await p.waitForTimeout(1500); }
   await p.getByRole('button', { name: 'Guest list', exact: true }).click(); await p.waitForTimeout(2500); return { dialog: d, toasts: await toasts(n), ...(await st()) }; });
  await C('P12-assemble-at-cap', async () => { await newDoc(); await add(['report_letter_3p.pdf', 'cover_letter.docx', 'photo_exif6.jpg']); await setTitle('Cap Packet'); return assemble('P12'); });
  await C('P13-preview-first-page', async () => { const bt = p.getByRole('button', { name: /Preview first page/ }); if (!(await bt.count())) return { none: true }; await bt.click(); await p.waitForTimeout(3000); const d = await dialog(); await p.screenshot({ path: OUT + 'cases/P13-preview' + sfx + '.png' }); const info = await p.evaluate(() => [...document.querySelectorAll('[role=dialog] img, [role=dialog] canvas, main img[src^=blob], main canvas')].map(x => [x.tagName, x.naturalWidth || x.width, x.naturalHeight || x.height])); await esc(); return { dialog: d, info }; });
  await C('P14-download-at-cap', () => download('P14'));
  await C('P15-save-drive', async () => { const pp = c.waitForEvent('page', { timeout: 10000 }).catch(() => null); const before = await used(); await p.getByRole('button', { name: 'Save to Google Drive' }).click(); const pop = await pp; const r = { before }; if (pop) { await pop.waitForLoadState('domcontentloaded').catch(() => { }); await pop.waitForTimeout(2000); const u = new URL(pop.url()); r.popup = u.origin + u.pathname; await pop.screenshot({ path: OUT + 'cases/P15-drive-popup' + sfx + '.png' }); await pop.close(); } else { r.dialog = await dialog(); await p.screenshot({ path: OUT + 'cases/P15-drive' + sfx + '.png' }); await esc(); } r.after = await used(); return r; });
  await C('P16-save-cloud', async () => { const before = await used(); await p.getByRole('button', { name: 'Save to my cloud storage' }).click(); await p.waitForTimeout(2500); const r = { before, dialog: await dialog(), after: await used() }; await p.screenshot({ path: OUT + 'cases/P16-cloud' + sfx + '.png' }); await esc(); return r; });
  await C('P17-save-project', async () => { const before = await used(); const dp = p.waitForEvent('download', { timeout: 8000 }).catch(() => null); await p.getByRole('button', { name: 'Save project' }).click(); const d = await dp; await p.waitForTimeout(1500); const r = { before, after: await used(), dialog: await dialog() }; if (d) { const f = OUT + 'downloads/P17' + sfx + '-' + d.suggestedFilename(); await d.saveAs(f); r.file = { name: d.suggestedFilename(), bytes: fs.statSync(f).size }; } await esc(); return r; });
  await C('QB-day', async () => { await p.locator('main button', { hasText: 'Quick Buy' }).first().click(); await p.waitForTimeout(2500); const d = await dialog(); await p.screenshot({ path: OUT + 'cases/quickbuy-day' + sfx + '.png' }); await esc(); return { dialog: d }; });
  await C('QB-month', async () => { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); await p.locator('main button', { hasText: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); return { url: red(p.url()), title: await p.title() }; });
  R.net = net;
 } else if (mode === 'left') { if (await findLeft()) { const L = R.left = { start: await used() };
   await add(['report_letter_3p.pdf', 'cover_letter.docx', 'photo_exif6.jpg']); await setTitle('Left Packet');
   await C('L01-assemble', () => assemble('L01')); await C('L01-download', () => download('L01')); await C('L01-download-again', () => download('L01b'));
   await setTitle('Left Packet Two'); await C('L02-reassemble-same-load', () => assemble('L02')); await C('L02-download', () => download('L02'));
   await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); L.afterReload = await used(); await add(['appendix_a4_landscape_2p.pdf']); await setTitle('After reload');
   await C('L03-assemble-after-reload', () => assemble('L03')); await C('L03-download', () => download('L03'));
   L.end = await used(); L.net = net; } }
 else { const only = (process.env.CASES || '').split(',').filter(Boolean);
   const plan = [
    ['C1', 'mixed-full', ['report_letter_3p.pdf', 'cover_letter.docx', 'notes_utf8.txt', 'photo_exif6.jpg', 'wide_transparent.png', 'appendix_a4_landscape_2p.pdf', 'rotated_2p.pdf', 'form_filled.pdf'], { title: 'Client Onboarding Packet', author: 'QA Tester', loi: true }],
    ['C2', 'a4-plain', ['report_letter_3p.pdf', 'tiny.png'], { title: 'Plain A4', size: 'A4', cover: false, toc: false }],
    ['C3', 'trim6x9-long-reorder-unicode', ['long_60p.pdf', 'notes_cp1252.txt', 'report_letter_3p.pdf'], { title: 'Résumé – 日本語 Packet', size: '6 x 9 in', moveUpLast: true, retitle: [0, 'Résumé – 日本語 section'] }]];
   if (!(await findLeft(process.env.TRIES || 10))) { R.skipped = 'no context with uses left'; } else { R.start = await used();
   for (const [id, name, files, o] of plan.filter(x => !only.length || only.includes(x[0]))) await C(id + '-' + name, async () => {
     await newDoc(); const s = await add(files); await setTitle(o.title); if (o.author) await setAuthor(o.author); if (o.size) await size(o.size);
     await chk('cover', o.cover ?? true); await chk('toc', o.toc ?? true); await chk('loi', o.loi ?? false);
     if (o.moveUpLast) { await p.locator('main button[aria-label="Move up"]').last().click(); await p.waitForTimeout(300); }
     if (o.retitle) { await p.locator('main input[placeholder^="Section title"]').nth(o.retitle[0]).fill(o.retitle[1]); }
     const a = await assemble(id); const d = await download(id); return { added: s.toasts, sectionsBefore: s.sections, sectionsAfter: (await st()).sections, assemble: a, download: d }; });
   R.end = await used(); R.net = net; }
 }
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', JSON.stringify(R.tries), JSON.stringify(R.start || '').slice(0, 300)); await b.close(); })();
