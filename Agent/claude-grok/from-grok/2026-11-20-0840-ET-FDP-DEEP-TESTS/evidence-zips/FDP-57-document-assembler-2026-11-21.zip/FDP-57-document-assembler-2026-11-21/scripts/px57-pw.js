// FDP-57: password PDF add flow (guest, as-is context). Types only the test file's own password (u123).
const { chromium } = require('playwright'); const fs = require('fs'); const OUT = '/workspace/deep/57-document-assembler/live/'; const TF = '/workspace/deep/57-document-assembler/testfiles/';
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); const R = {};
 await p.addInitScript(() => { window.__t = []; const seen = new WeakSet(); setInterval(() => { document.querySelectorAll('[data-sonner-toast]').forEach(n => { if (!seen.has(n)) { seen.add(n); window.__t.push((n.innerText || '').trim()); } }); }, 120); });
 await p.goto('https://www.freedailypro.com/tool/document-assembler', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 const dlg = async () => { const d = p.locator('[role=dialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ') : null; };
 const secs = () => p.$$eval('main input[placeholder^="Section title"]', a => a.map(i => i.value));
 await p.locator('main input[type=file][multiple]').first().setInputFiles([TF + 'report_letter_3p.pdf', TF + 'password_u123.pdf']); await p.waitForTimeout(2500);
 R.dialog1 = await dlg(); await p.screenshot({ path: OUT + 'cases/P06-password-dialog.png' });
 await p.locator('[role=dialog] button', { hasText: /Skip/ }).first().click().catch(e => R.skipErr = e.message.slice(0, 80)); await p.waitForTimeout(1500); R.afterSkip = { secs: await secs(), toasts: await p.evaluate(() => window.__t) };
 await p.locator('main input[type=file][multiple]').first().setInputFiles([TF + 'password_u123.pdf']); await p.waitForTimeout(2500); R.dialog2 = await dlg();
 await p.locator('[role=dialog] input[type=password]').fill('wrongpw'); await p.keyboard.press('Enter'); await p.waitForTimeout(2000); R.wrong = await dlg();
 await p.locator('[role=dialog] input[type=password]').fill('u123'); await p.keyboard.press('Enter'); await p.waitForTimeout(2500); R.afterUnlock = { dialog: await dlg(), secs: await secs(), toasts: await p.evaluate(() => window.__t) };
 await p.locator('main input[placeholder^="e.g."]').first().fill('PW test'); await p.getByRole('button', { name: 'Assemble Document' }).click(); await p.waitForTimeout(6000);
 R.assemble = await p.evaluate(() => ({ done: document.querySelector('[data-testid=da-done]')?.innerText, err: document.querySelector('[data-testid=da-error]')?.innerText }));
 fs.writeFileSync(OUT + 'password.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R)); await b.close(); })();
