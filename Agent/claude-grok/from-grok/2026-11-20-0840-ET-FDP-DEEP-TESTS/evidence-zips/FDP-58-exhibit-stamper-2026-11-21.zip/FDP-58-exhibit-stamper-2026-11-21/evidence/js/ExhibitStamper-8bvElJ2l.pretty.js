const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/drawTextAnywhere-DcuP6lHH.js",
      "assets/pdfFonts-Ckcqm3Ic.js",
      "assets/index-BRvxULIc.js",
      "assets/index-CnXdQaNG.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/index-DMQTJy3b.js",
      "assets/fontkit.es-DA-3qwB1.js",
    ]),
) => i.map((i) => d[i]);
import { r as x, j as e } from "./vendor-react-D01g8YgM.js";
import { J as ue } from "./jszip.min-CT0ZA6V1.js";
import { T as xe } from "./ToolWithSidebar-C7kxZj7O.js";
import { b as fe, F as ge, P as be, D as Y } from "./ToolPage-DwLoDncN.js";
import { R as je } from "./ReorderableFileList-BhqJ-ECL.js";
import {
  ap as we,
  f as E,
  e as v,
  I as L,
  B as ee,
  ay as Se,
} from "./index-B1CTyGtY.js";
import { C as te } from "./checkbox-Ml1pfDb3.js";
import { S as J, a as q, b as H, c as K, d as D } from "./select-ic5yaeGw.js";
import { l as ve } from "./operations-B4LtHhm8.js";
import { P as ye } from "./PdfPageStrip-Dr4IJevd.js";
import { u as f } from "./useSessionState-BLsNNse9.js";
import { u as Ne, a as Ce, B as Te } from "./batesNumbering-Pmx-EMyr.js";
import { k as Pe, u as se } from "./index-BRvxULIc.js";
import { p as ke } from "./pageView-BQIwVYOi.js";
import { p as Fe } from "./utils-s8ucLyj8.js";
import { f as $e } from "./reorderMath-CVj9Q6Gj.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./formatFileSize-B-JRDfN5.js";
import "./grip-vertical-Dzkp2Q5V.js";
import "./index-DhOoIDuZ.js";
import "./index-BdQq_4o_.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./fontkit.es-DA-3qwB1.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./pdfMetadata-CcxIhQF2.js";
import "./formAppearance-CdNbuISd.js";
import "./drawTextAnywhere-DcuP6lHH.js";
import "./ocrText-C_9cxcFa.js";
import "./ocrImage-CmXFNUud.js";
import "./imageRecompress-eXQFDUm-.js";
import "./plural-FIChqbp4.js";
import "./textDiff-DxE9AzvO.js";
import "./utils-1EQcVBdK.js";
import "./decode-DrS85i4S.js";
import "./formFill-Dg9Myfyq.js";
import "./redactSearch-DQpyyh_t.js";
import "./nameDetect-DvHCRM0m.js";
import "./pdfThumbnails-4ijNer1F.js";
import "./chevron-left-CWH4XvTX.js";
import "./chevron-right-7IYXE5RL.js";
const k = {
  scheme: "letters",
  start: "A",
  prefix: "Exhibit ",
  pages: "first",
  position: "top-right",
  fontSize: 14,
};
function Ee(s) {
  let a = Math.max(0, Math.trunc(s)),
    r = "";
  do
    ((r = String.fromCharCode(65 + (a % 26)) + r),
      (a = Math.floor(a / 26) - 1));
  while (a >= 0);
  return r;
}
function ae(s) {
  const a = s.trim().toUpperCase();
  if (!/^[A-Z]{1,4}$/.test(a)) return null;
  let r = 0;
  for (const n of a) r = r * 26 + (n.charCodeAt(0) - 64);
  return r - 1;
}
function De(s) {
  return s.scheme === "letters" && ae(s.start) === null
    ? "Start with letters only, such as A (up to 4 letters)."
    : s.scheme === "numbers" &&
        (!/^\d{1,5}$/.test(s.start.trim()) || Number(s.start) < 0)
      ? "Start with a whole number, such as 1."
      : !Number.isFinite(s.fontSize) || s.fontSize < 8 || s.fontSize > 36
        ? "Type size has to be between 8 and 36."
        : s.prefix.length > 30 || s.suffix.length > 30
          ? "The text before and after can be up to 30 characters."
          : /[\r\n]/.test(s.prefix + s.suffix)
            ? "The text before and after has to stay on one line."
            : null;
}
function Ae(s, a) {
  const r =
      s.scheme === "letters"
        ? (ae(s.start) ?? 0)
        : Math.trunc(Number(s.start) || 1),
    n = s.scheme === "letters" ? Ee(r + a) : String(r + a);
  return `${s.prefix}${n}${s.suffix}`;
}
function ze(s, a) {
  const r = Ne(s.map((n) => n.name).map((n) => n.replace(/\.pdf$/i, "")));
  return s.map((n, h) => ({
    name: n.name,
    outputName: r[h].replace(/-bates(?=(-\d+)?\.pdf$)/, "-exhibit"),
    pageCount: n.pageCount,
    label: Ae(a, h),
  }));
}
function Ie(s, a, r, n) {
  return a.pages === "first"
    ? r === 0
      ? s
      : null
    : a.pageOf
      ? `${s}, page ${r + 1} of ${n}`
      : s;
}
function Be(s) {
  let a = String(s);
  return (
    /^[=+\-@\t\r]/.test(a) && (a = `'${a}`),
    /[",\n\r]/.test(a) ? `"${a.replace(/"/g, '""')}"` : a
  );
}
function Le(s) {
  const a = [["Exhibit", "Document", "Stamped file", "Pages", "Description"]];
  for (const r of s)
    a.push([r.label, r.name, r.outputName, String(r.pageCount), ""]);
  return (
    a.map((r) => r.map(Be).join(",")).join(`\r
`) +
    `\r
`
  );
}
const O = 4;
async function Oe(s, a, r) {
  const n = new Uint8Array(await s.arrayBuffer()),
    h = await Pe.load(n),
    { drawTextAnywhere: M, measureTextAnywhere: F } = await we(
      async () => {
        const { drawTextAnywhere: d, measureTextAnywhere: j } =
          await import("./drawTextAnywhere-DcuP6lHH.js");
        return { drawTextAnywhere: d, measureTextAnywhere: j };
      },
      __vite__mapDeps([0, 1, 2, 3, 4, 5, 6]),
    ),
    y = h.getPages();
  for (let d = 0; d < y.length; d++) {
    const j = Ie(a, r, d, y.length);
    if (!j) continue;
    const w = y[d],
      g = ke(w),
      N = await F(h, j, r.fontSize, !0),
      { x: $, y: C } = Ce(r.position, g.width, g.height, N, r.fontSize);
    if (r.whiteBox) {
      const T = g.toStored($ - O, C - O),
        S = g.toStored($ + N + O, C + r.fontSize + O);
      w.drawRectangle({
        x: Math.min(T.x, S.x),
        y: Math.min(T.y, S.y),
        width: Math.abs(T.x - S.x),
        height: Math.abs(T.y - S.y),
        color: se(1, 1, 1),
        borderColor: se(0, 0, 0),
        borderWidth: 1,
      });
    }
    const { x: _, y: z } = g.toStored($, C);
    await M(h, w, j, {
      x: _,
      y: z,
      size: r.fontSize,
      color: { r: 0, g: 0, b: 0 },
      bold: !0,
      rotateDegrees: g.rotation,
    });
  }
  return Fe(await h.save());
}
const re = {
    what: 'Stamps an exhibit label such as "Exhibit A" on the first page, or every page, of each PDF in a set, and gives you an index (CSV) of which document is which exhibit, with a blank description column to fill in. Label with letters or numbers, add your own text before and after, and choose where the stamp goes.',
    tip: "Put the files in exhibit order before you start, because the labels follow the list. Check the preview to be sure the stamp does not cover anything important, and use a different corner if it does. Court and agency rules on exhibits differ, so check the format your forum asks for.",
  },
  Me = {
    "bottom-right": "Bottom right",
    "bottom-center": "Bottom center",
    "bottom-left": "Bottom left",
    "top-right": "Top right",
    "top-center": "Top center",
    "top-left": "Top left",
  },
  A = (s) => `${s.name}-${s.size}-${s.lastModified}`;
function Gt() {
  const [s, a] = x.useState([]),
    [r, n] = x.useState(new Map()),
    [h, M] = f("exh-scheme", k.scheme),
    [F, y] = f("exh-start", k.start),
    [d, j] = f("exh-prefix", k.prefix),
    [w, g] = f("exh-suffix", ""),
    [N, $] = f("exh-pages", k.pages),
    [C, _] = f("exh-pageof", !1),
    [z, T] = f("exh-pos", k.position),
    [S, ie] = f("exh-size", String(k.fontSize)),
    [X, ne] = f("exh-box", !0),
    [R, V] = x.useState(!1),
    [oe, U] = x.useState(0),
    [b, I] = x.useState(null),
    B = x.useRef(!1),
    { logUsageNow: le } = fe(),
    W = {
      scheme: h,
      start: F,
      prefix: d,
      suffix: w,
      pages: N,
      position: z,
      fontSize: Number(S),
      whiteBox: X,
      pageOf: C,
    },
    P = De(W),
    m = () => I(null),
    G = x.useCallback((t) => {
      ve(t).then((i) => {
        const o =
          i.status === "ok"
            ? { status: "ok", pageCount: i.pageCount }
            : { status: i.status };
        n((u) => new Map(u).set(A(t), o));
      });
    }, []),
    ce = x.useCallback(
      (t) => {
        const i = t.filter(
          (o) => o.type === "application/pdf" || /\.pdf$/i.test(o.name),
        );
        (i.length !== t.length && E.error("Only PDF files are accepted"),
          a((o) => {
            const u = $e(o, i);
            return (
              u.length &&
                E.warning(
                  `${u.map((p) => `"${p.name}"`).join(", ")} already in the list. Added anyway, remove it below if that was not intended.`,
                ),
              [...o, ...i]
            );
          }),
          I(null),
          i.forEach(G));
      },
      [G],
    ),
    c = s.filter((t) => r.get(A(t))?.status === "ok"),
    Z = s.filter((t) => !r.has(A(t))).length,
    Q = s.length - c.length - Z,
    l = x.useMemo(
      () =>
        P
          ? null
          : ze(
              c.map((t) => ({
                name: t.name,
                pageCount: r.get(A(t)).pageCount,
              })),
              W,
            ),
      [s, r, h, F, d, w, P],
    ),
    he = async () => {
      if (!(P || !l || c.length === 0)) {
        if (Z > 0) {
          E.error("Wait until every file has been checked");
          return;
        }
        if (await le()) {
          ((B.current = !1), V(!0), U(0));
          try {
            const t = [];
            for (let p = 0; p < c.length; p++) {
              if ((t.push(await Oe(c[p], l[p].label, W)), B.current)) return;
              U(((p + 1) / c.length) * 100);
            }
            const i = Le(l);
            let o, u;
            if (c.length === 1) ((o = t[0]), (u = l[0].outputName));
            else {
              const p = new ue();
              (t.forEach((pe, de) => p.file(l[de].outputName, pe)),
                p.file("exhibit-index.csv", i),
                (o = await p.generateAsync({
                  type: "blob",
                  compression: "STORE",
                })),
                (u = "exhibits-stamped.zip"));
            }
            (I({
              blob: o,
              fileName: u,
              preview: t[0],
              indexCsv: i,
              summary: `${l.length} ${l.length === 1 ? "document" : "documents"} stamped, ${l[0].label} to ${l[l.length - 1].label}`,
            }),
              Se("exhibit-stamper", "pdf-tools"),
              E.success("Exhibit labels added"));
          } catch (t) {
            if (B.current) return;
            (console.error("Exhibit stamping failed:", t),
              E.error(
                "Could not stamp one of the files. It may be damaged or protected.",
              ));
          } finally {
            V(!1);
          }
        }
      }
    },
    me = (t) => {
      const i = r.get(A(t));
      if (!i)
        return e.jsx("span", {
          className: "text-xs text-muted-foreground",
          children: "Checking…",
        });
      if (i.status === "ok") {
        const o = l?.[c.indexOf(t)];
        return e.jsxs("span", {
          className: "text-xs text-muted-foreground whitespace-nowrap",
          children: [
            i.pageCount,
            " ",
            i.pageCount === 1 ? "page" : "pages",
            o ? `, ${o.label}` : "",
          ],
        });
      }
      return e.jsx("span", {
        className: "text-xs text-destructive",
        children:
          i.status === "encrypted"
            ? "Locked. Unlock it first, then add it again."
            : "Damaged. Left out.",
      });
    };
  return e.jsxs(xe, {
    toolId: "exhibit-stamper",
    categoryId: "pdf-tools",
    whatItDoes: re.what,
    proTip: re.tip,
    children: [
      e.jsx(ge, {
        accept: ".pdf",
        multiple: !0,
        onFiles: ce,
        label: "Drop PDF files here or click to browse",
        description: "Add the documents in exhibit order",
        deferUsageLog: !0,
      }),
      s.length > 0 &&
        e.jsxs("div", {
          className: "mt-6 space-y-5",
          children: [
            e.jsxs("div", {
              children: [
                e.jsxs("p", {
                  className: "text-sm font-medium text-muted-foreground mb-3",
                  children: [
                    s.length,
                    " ",
                    s.length === 1 ? "file" : "files",
                    Q > 0 ? `, ${Q} left out` : "",
                  ],
                }),
                e.jsx(je, {
                  files: s,
                  onReorder: (t) => {
                    (a(t), m());
                  },
                  onRemove: (t) => {
                    (a((i) => i.filter((o, u) => u !== t)), m());
                  },
                  renderItemExtra: (t) => me(s[t]),
                }),
              ],
            }),
            e.jsxs("div", {
              className: "space-y-4",
              children: [
                e.jsxs("div", {
                  className: "flex gap-4 flex-wrap items-end",
                  children: [
                    e.jsxs("div", {
                      children: [
                        e.jsx(v, {
                          htmlFor: "exh-scheme",
                          children: "Label with",
                        }),
                        e.jsxs(J, {
                          value: h,
                          onValueChange: (t) => {
                            const i = t;
                            (M(i), y(i === "letters" ? "A" : "1"), m());
                          },
                          children: [
                            e.jsx(q, {
                              id: "exh-scheme",
                              className: "w-36",
                              children: e.jsx(H, {}),
                            }),
                            e.jsxs(K, {
                              children: [
                                e.jsx(D, {
                                  value: "letters",
                                  children: "Letters (A, B, C)",
                                }),
                                e.jsx(D, {
                                  value: "numbers",
                                  children: "Numbers (1, 2, 3)",
                                }),
                              ],
                            }),
                          ],
                        }),
                      ],
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsx(v, {
                          htmlFor: "exh-start",
                          children: "Start at",
                        }),
                        e.jsx(L, {
                          id: "exh-start",
                          className: "w-24",
                          value: F,
                          onChange: (t) => {
                            (y(t.target.value), m());
                          },
                        }),
                      ],
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsx(v, {
                          htmlFor: "exh-prefix",
                          children: "Text before",
                        }),
                        e.jsx(L, {
                          id: "exh-prefix",
                          className: "w-36",
                          maxLength: 30,
                          value: d,
                          onChange: (t) => {
                            (j(t.target.value), m());
                          },
                        }),
                      ],
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsx(v, {
                          htmlFor: "exh-suffix",
                          children: "Text after",
                        }),
                        e.jsx(L, {
                          id: "exh-suffix",
                          className: "w-28",
                          maxLength: 30,
                          value: w,
                          placeholder: "optional",
                          onChange: (t) => {
                            (g(t.target.value), m());
                          },
                        }),
                      ],
                    }),
                  ],
                }),
                e.jsxs("div", {
                  className: "flex gap-4 flex-wrap items-end",
                  children: [
                    e.jsxs("div", {
                      children: [
                        e.jsx(v, { htmlFor: "exh-pages", children: "Stamp" }),
                        e.jsxs(J, {
                          value: N,
                          onValueChange: (t) => {
                            ($(t), m());
                          },
                          children: [
                            e.jsx(q, {
                              id: "exh-pages",
                              className: "w-40",
                              children: e.jsx(H, {}),
                            }),
                            e.jsxs(K, {
                              children: [
                                e.jsx(D, {
                                  value: "first",
                                  children: "First page only",
                                }),
                                e.jsx(D, {
                                  value: "all",
                                  children: "Every page",
                                }),
                              ],
                            }),
                          ],
                        }),
                      ],
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsx(v, { htmlFor: "exh-pos", children: "Position" }),
                        e.jsxs(J, {
                          value: z,
                          onValueChange: (t) => {
                            (T(t), m());
                          },
                          children: [
                            e.jsx(q, {
                              id: "exh-pos",
                              className: "w-40",
                              children: e.jsx(H, {}),
                            }),
                            e.jsx(K, {
                              children: Te.map((t) =>
                                e.jsx(D, { value: t, children: Me[t] }, t),
                              ),
                            }),
                          ],
                        }),
                      ],
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsx(v, {
                          htmlFor: "exh-size",
                          children: "Size (pt)",
                        }),
                        e.jsx(L, {
                          id: "exh-size",
                          type: "number",
                          min: 8,
                          max: 36,
                          className: "w-20",
                          value: S,
                          onChange: (t) => {
                            (ie(t.target.value), m());
                          },
                        }),
                      ],
                    }),
                  ],
                }),
                N === "all" &&
                  e.jsxs("label", {
                    className: "flex items-center gap-2 text-sm cursor-pointer",
                    children: [
                      e.jsx(te, {
                        checked: C,
                        onCheckedChange: (t) => {
                          (_(t === !0), m());
                        },
                      }),
                      'Add "page 2 of 5" after the label',
                    ],
                  }),
                e.jsxs("label", {
                  className: "flex items-center gap-2 text-sm cursor-pointer",
                  children: [
                    e.jsx(te, {
                      checked: X,
                      onCheckedChange: (t) => {
                        (ne(t === !0), m());
                      },
                    }),
                    "Draw a box with a white background around the stamp",
                  ],
                }),
                P &&
                  e.jsx("p", {
                    role: "alert",
                    className: "text-sm text-destructive",
                    children: P,
                  }),
              ],
            }),
            l &&
              l.length > 0 &&
              !b &&
              !R &&
              e.jsxs("div", {
                className: "rounded-lg border bg-card p-4 overflow-x-auto",
                "data-testid": "exhibit-plan",
                children: [
                  e.jsx("p", {
                    className: "text-sm font-medium mb-2",
                    children: "Index preview",
                  }),
                  e.jsxs("table", {
                    className: "text-sm w-full",
                    children: [
                      e.jsx("thead", {
                        children: e.jsxs("tr", {
                          className: "text-left text-muted-foreground",
                          children: [
                            e.jsx("th", {
                              className: "pr-4 font-normal",
                              children: "Exhibit",
                            }),
                            e.jsx("th", {
                              className: "pr-4 font-normal",
                              children: "Document",
                            }),
                            e.jsx("th", {
                              className: "font-normal",
                              children: "Pages",
                            }),
                          ],
                        }),
                      }),
                      e.jsx("tbody", {
                        children: l.map((t) =>
                          e.jsxs(
                            "tr",
                            {
                              children: [
                                e.jsx("td", {
                                  className: "pr-4 py-0.5 font-mono",
                                  children: t.label,
                                }),
                                e.jsx("td", {
                                  className: "pr-4 break-all",
                                  children: t.name,
                                }),
                                e.jsx("td", { children: t.pageCount }),
                              ],
                            },
                            t.outputName,
                          ),
                        ),
                      }),
                    ],
                  }),
                ],
              }),
            b &&
              !R &&
              e.jsxs("div", {
                className: "space-y-3",
                children: [
                  e.jsx("p", {
                    className: "text-sm text-muted-foreground",
                    role: "status",
                    children: b.summary,
                  }),
                  e.jsx(ye, { blob: b.preview }),
                ],
              }),
            e.jsxs("div", {
              className: "flex items-center gap-3 flex-wrap",
              children: [
                R
                  ? e.jsx(be, {
                      message: "Adding labels…",
                      progress: oe,
                      onStop: () => {
                        ((B.current = !0), V(!1), U(0));
                      },
                    })
                  : b
                    ? e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(Y, {
                            blob: b.blob,
                            fileName: b.fileName,
                            label:
                              s.length > 1
                                ? "Download stamped files (ZIP)"
                                : "Download stamped PDF",
                          }),
                          c.length === 1 &&
                            e.jsx(Y, {
                              blob: new Blob([b.indexCsv], {
                                type: "text/csv",
                              }),
                              fileName: "exhibit-index.csv",
                              label: "Download index (CSV)",
                            }),
                        ],
                      })
                    : e.jsx(ee, {
                        onClick: he,
                        disabled: !!P || c.length === 0 || Z > 0,
                        className: "btn-glow",
                        children:
                          c.length === 0
                            ? "Add at least one PDF"
                            : `Stamp ${c.length} ${c.length === 1 ? "file" : "files"}`,
                      }),
                e.jsx(ee, {
                  variant: "outline",
                  onClick: () => {
                    (a([]), n(new Map()), I(null));
                  },
                  children: "Clear all",
                }),
              ],
            }),
          ],
        }),
    ],
  });
}
export { Gt as default };
//# sourceMappingURL=ExhibitStamper-8bvElJ2l.js.map
