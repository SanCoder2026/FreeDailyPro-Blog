import { E as st, u as ct, S as T } from "./index-BRvxULIc.js";
import { f as U } from "./fontkit.es-DA-3qwB1.js";
var W = { exports: {} },
  X;
function ft() {
  return (
    X ||
      ((X = 1),
      (function (f) {
        var i = (function (r) {
          var n = Object.prototype,
            o = n.hasOwnProperty,
            c =
              Object.defineProperty ||
              function (e, t, a) {
                e[t] = a.value;
              },
            d,
            g = typeof Symbol == "function" ? Symbol : {},
            w = g.iterator || "@@iterator",
            $ = g.asyncIterator || "@@asyncIterator",
            p = g.toStringTag || "@@toStringTag";
          function u(e, t, a) {
            return (
              Object.defineProperty(e, t, {
                value: a,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              }),
              e[t]
            );
          }
          try {
            u({}, "");
          } catch {
            u = function (t, a, l) {
              return (t[a] = l);
            };
          }
          function h(e, t, a, l) {
            var s = t && t.prototype instanceof M ? t : M,
              v = Object.create(s.prototype),
              b = new H(l || []);
            return (c(v, "_invoke", { value: at(e, a, b) }), v);
          }
          r.wrap = h;
          function m(e, t, a) {
            try {
              return { type: "normal", arg: e.call(t, a) };
            } catch (l) {
              return { type: "throw", arg: l };
            }
          }
          var A = "suspendedStart",
            R = "suspendedYield",
            _ = "executing",
            F = "completed",
            k = {};
          function M() {}
          function j() {}
          function C() {}
          var B = {};
          u(B, w, function () {
            return this;
          });
          var D = Object.getPrototypeOf,
            G = D && D(D(q([])));
          G && G !== n && o.call(G, w) && (B = G);
          var N = (C.prototype = M.prototype = Object.create(B));
          ((j.prototype = C),
            c(N, "constructor", { value: C, configurable: !0 }),
            c(C, "constructor", { value: j, configurable: !0 }),
            (j.displayName = u(C, p, "GeneratorFunction")));
          function Q(e) {
            ["next", "throw", "return"].forEach(function (t) {
              u(e, t, function (a) {
                return this._invoke(t, a);
              });
            });
          }
          ((r.isGeneratorFunction = function (e) {
            var t = typeof e == "function" && e.constructor;
            return t
              ? t === j || (t.displayName || t.name) === "GeneratorFunction"
              : !1;
          }),
            (r.mark = function (e) {
              return (
                Object.setPrototypeOf
                  ? Object.setPrototypeOf(e, C)
                  : ((e.__proto__ = C), u(e, p, "GeneratorFunction")),
                (e.prototype = Object.create(N)),
                e
              );
            }),
            (r.awrap = function (e) {
              return { __await: e };
            }));
          function I(e, t) {
            function a(v, b, y, E) {
              var S = m(e[v], e, b);
              if (S.type === "throw") E(S.arg);
              else {
                var K = S.arg,
                  x = K.value;
                return x && typeof x == "object" && o.call(x, "__await")
                  ? t.resolve(x.__await).then(
                      function (L) {
                        a("next", L, y, E);
                      },
                      function (L) {
                        a("throw", L, y, E);
                      },
                    )
                  : t.resolve(x).then(
                      function (L) {
                        ((K.value = L), y(K));
                      },
                      function (L) {
                        return a("throw", L, y, E);
                      },
                    );
              }
            }
            var l;
            function s(v, b) {
              function y() {
                return new t(function (E, S) {
                  a(v, b, E, S);
                });
              }
              return (l = l ? l.then(y, y) : y());
            }
            c(this, "_invoke", { value: s });
          }
          (Q(I.prototype),
            u(I.prototype, $, function () {
              return this;
            }),
            (r.AsyncIterator = I),
            (r.async = function (e, t, a, l, s) {
              s === void 0 && (s = Promise);
              var v = new I(h(e, t, a, l), s);
              return r.isGeneratorFunction(t)
                ? v
                : v.next().then(function (b) {
                    return b.done ? b.value : v.next();
                  });
            }));
          function at(e, t, a) {
            var l = A;
            return function (v, b) {
              if (l === _) throw new Error("Generator is already running");
              if (l === F) {
                if (v === "throw") throw b;
                return ot();
              }
              for (a.method = v, a.arg = b; ;) {
                var y = a.delegate;
                if (y) {
                  var E = V(y, a);
                  if (E) {
                    if (E === k) continue;
                    return E;
                  }
                }
                if (a.method === "next") a.sent = a._sent = a.arg;
                else if (a.method === "throw") {
                  if (l === A) throw ((l = F), a.arg);
                  a.dispatchException(a.arg);
                } else a.method === "return" && a.abrupt("return", a.arg);
                l = _;
                var S = m(e, t, a);
                if (S.type === "normal") {
                  if (((l = a.done ? F : R), S.arg === k)) continue;
                  return { value: S.arg, done: a.done };
                } else
                  S.type === "throw" &&
                    ((l = F), (a.method = "throw"), (a.arg = S.arg));
              }
            };
          }
          function V(e, t) {
            var a = t.method,
              l = e.iterator[a];
            if (l === d)
              return (
                (t.delegate = null),
                (a === "throw" &&
                  e.iterator.return &&
                  ((t.method = "return"),
                  (t.arg = d),
                  V(e, t),
                  t.method === "throw")) ||
                  (a !== "return" &&
                    ((t.method = "throw"),
                    (t.arg = new TypeError(
                      "The iterator does not provide a '" + a + "' method",
                    )))),
                k
              );
            var s = m(l, e.iterator, t.arg);
            if (s.type === "throw")
              return (
                (t.method = "throw"),
                (t.arg = s.arg),
                (t.delegate = null),
                k
              );
            var v = s.arg;
            if (!v)
              return (
                (t.method = "throw"),
                (t.arg = new TypeError("iterator result is not an object")),
                (t.delegate = null),
                k
              );
            if (v.done)
              ((t[e.resultName] = v.value),
                (t.next = e.nextLoc),
                t.method !== "return" && ((t.method = "next"), (t.arg = d)));
            else return v;
            return ((t.delegate = null), k);
          }
          (Q(N),
            u(N, p, "Generator"),
            u(N, w, function () {
              return this;
            }),
            u(N, "toString", function () {
              return "[object Generator]";
            }));
          function it(e) {
            var t = { tryLoc: e[0] };
            (1 in e && (t.catchLoc = e[1]),
              2 in e && ((t.finallyLoc = e[2]), (t.afterLoc = e[3])),
              this.tryEntries.push(t));
          }
          function z(e) {
            var t = e.completion || {};
            ((t.type = "normal"), delete t.arg, (e.completion = t));
          }
          function H(e) {
            ((this.tryEntries = [{ tryLoc: "root" }]),
              e.forEach(it, this),
              this.reset(!0));
          }
          r.keys = function (e) {
            var t = Object(e),
              a = [];
            for (var l in t) a.push(l);
            return (
              a.reverse(),
              function s() {
                for (; a.length;) {
                  var v = a.pop();
                  if (v in t) return ((s.value = v), (s.done = !1), s);
                }
                return ((s.done = !0), s);
              }
            );
          };
          function q(e) {
            if (e != null) {
              var t = e[w];
              if (t) return t.call(e);
              if (typeof e.next == "function") return e;
              if (!isNaN(e.length)) {
                var a = -1,
                  l = function s() {
                    for (; ++a < e.length;)
                      if (o.call(e, a))
                        return ((s.value = e[a]), (s.done = !1), s);
                    return ((s.value = d), (s.done = !0), s);
                  };
                return (l.next = l);
              }
            }
            throw new TypeError(typeof e + " is not iterable");
          }
          r.values = q;
          function ot() {
            return { value: d, done: !0 };
          }
          return (
            (H.prototype = {
              constructor: H,
              reset: function (e) {
                if (
                  ((this.prev = 0),
                  (this.next = 0),
                  (this.sent = this._sent = d),
                  (this.done = !1),
                  (this.delegate = null),
                  (this.method = "next"),
                  (this.arg = d),
                  this.tryEntries.forEach(z),
                  !e)
                )
                  for (var t in this)
                    t.charAt(0) === "t" &&
                      o.call(this, t) &&
                      !isNaN(+t.slice(1)) &&
                      (this[t] = d);
              },
              stop: function () {
                this.done = !0;
                var e = this.tryEntries[0],
                  t = e.completion;
                if (t.type === "throw") throw t.arg;
                return this.rval;
              },
              dispatchException: function (e) {
                if (this.done) throw e;
                var t = this;
                function a(E, S) {
                  return (
                    (v.type = "throw"),
                    (v.arg = e),
                    (t.next = E),
                    S && ((t.method = "next"), (t.arg = d)),
                    !!S
                  );
                }
                for (var l = this.tryEntries.length - 1; l >= 0; --l) {
                  var s = this.tryEntries[l],
                    v = s.completion;
                  if (s.tryLoc === "root") return a("end");
                  if (s.tryLoc <= this.prev) {
                    var b = o.call(s, "catchLoc"),
                      y = o.call(s, "finallyLoc");
                    if (b && y) {
                      if (this.prev < s.catchLoc) return a(s.catchLoc, !0);
                      if (this.prev < s.finallyLoc) return a(s.finallyLoc);
                    } else if (b) {
                      if (this.prev < s.catchLoc) return a(s.catchLoc, !0);
                    } else if (y) {
                      if (this.prev < s.finallyLoc) return a(s.finallyLoc);
                    } else
                      throw new Error("try statement without catch or finally");
                  }
                }
              },
              abrupt: function (e, t) {
                for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                  var l = this.tryEntries[a];
                  if (
                    l.tryLoc <= this.prev &&
                    o.call(l, "finallyLoc") &&
                    this.prev < l.finallyLoc
                  ) {
                    var s = l;
                    break;
                  }
                }
                s &&
                  (e === "break" || e === "continue") &&
                  s.tryLoc <= t &&
                  t <= s.finallyLoc &&
                  (s = null);
                var v = s ? s.completion : {};
                return (
                  (v.type = e),
                  (v.arg = t),
                  s
                    ? ((this.method = "next"), (this.next = s.finallyLoc), k)
                    : this.complete(v)
                );
              },
              complete: function (e, t) {
                if (e.type === "throw") throw e.arg;
                return (
                  e.type === "break" || e.type === "continue"
                    ? (this.next = e.arg)
                    : e.type === "return"
                      ? ((this.rval = this.arg = e.arg),
                        (this.method = "return"),
                        (this.next = "end"))
                      : e.type === "normal" && t && (this.next = t),
                  k
                );
              },
              finish: function (e) {
                for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                  var a = this.tryEntries[t];
                  if (a.finallyLoc === e)
                    return (this.complete(a.completion, a.afterLoc), z(a), k);
                }
              },
              catch: function (e) {
                for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                  var a = this.tryEntries[t];
                  if (a.tryLoc === e) {
                    var l = a.completion;
                    if (l.type === "throw") {
                      var s = l.arg;
                      z(a);
                    }
                    return s;
                  }
                }
                throw new Error("illegal catch attempt");
              },
              delegateYield: function (e, t, a) {
                return (
                  (this.delegate = {
                    iterator: q(e),
                    resultName: t,
                    nextLoc: a,
                  }),
                  this.method === "next" && (this.arg = d),
                  k
                );
              },
            }),
            r
          );
        })(f.exports);
        try {
          regeneratorRuntime = i;
        } catch {
          typeof globalThis == "object"
            ? (globalThis.regeneratorRuntime = i)
            : Function("r", "regeneratorRuntime = r")(i);
        }
      })(W)),
    W.exports
  );
}
ft();
const ut = {
    sans: [
      T.Helvetica,
      T.HelveticaBold,
      T.HelveticaOblique,
      T.HelveticaBoldOblique,
    ],
    serif: [
      T.TimesRoman,
      T.TimesRomanBold,
      T.TimesRomanItalic,
      T.TimesRomanBoldItalic,
    ],
    mono: [T.Courier, T.CourierBold, T.CourierOblique, T.CourierBoldOblique],
  },
  lt =
    /times|serif(?!.*sans)|georgia|garamond|cambria|palatino|book\s*antiqua|bookman|century|constantia|baskerville|didot|minion|caslon|tinos|liberation\s*serif|noto\s*serif|literata|merriweather|playfair/i,
  ht =
    /courier|consolas|lucida\s*console|monaco|menlo|mono|cousine|fixed|typewriter/i;
function kt(f) {
  return f
    ? ht.test(f)
      ? "mono"
      : /sans/i.test(f)
        ? "sans"
        : lt.test(f)
          ? "serif"
          : "sans"
    : "sans";
}
const P = {
    "▸": "-",
    "▶": "-",
    "▹": "-",
    "‣": "-",
    "●": "-",
    "◦": "-",
    "▪": "-",
    "▫": "-",
    "■": "-",
    "□": "-",
    "☒": "[x]",
    "☑": "[x]",
    "☐": "[ ]",
    "✓": "v",
    "✔": "v",
    "✗": "x",
    "✘": "x",
    "→": "->",
    "←": "<-",
    "↑": "^",
    "↓": "v",
    "➔": "->",
    "➤": "->",
    "⇒": "=>",
    " ": " ",
    " ": " ",
    " ": " ",
    " ": " ",
    " ": " ",
    " ": " ",
    " ": " ",
    " ": " ",
    "​": "",
    "‌": "",
    "‍": "",
    "⁠": "",
    "\uFEFF": "",
    "­": "",
    "‐": "-",
    "‑": "-",
    "‒": "-",
    "−": "-",
    "∕": "/",
  },
  O = (f) => f < 128 || st.WinAnsi.canEncodeUnicodeCodePoint(f);
function dt(f) {
  const i = f
    .replace(/\t/g, " ")
    .replace(/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/g, "");
  let r = "";
  for (const n of i) {
    const o = n.codePointAt(0);
    r += O(o) ? n : (P[n] ?? "?");
  }
  return r;
}
function Et(f) {
  return dt(f).replace(/[\n\r]+/g, " ");
}
const vt = [
  {
    name: "Chinese",
    ranges: [
      [19968, 40959],
      [13312, 19903],
      [131072, 173791],
      [63744, 64255],
      [12288, 12351],
      [65280, 65519],
    ],
  },
  {
    name: "Japanese",
    ranges: [
      [12352, 12543],
      [12784, 12799],
    ],
  },
  {
    name: "Korean",
    ranges: [
      [44032, 55215],
      [4352, 4607],
      [12592, 12687],
    ],
  },
  { name: "Hindi / Devanagari", ranges: [[2304, 2431]] },
  { name: "Bengali", ranges: [[2432, 2559]] },
  { name: "Gurmukhi (Punjabi)", ranges: [[2560, 2687]] },
  { name: "Gujarati", ranges: [[2688, 2815]] },
  { name: "Odia", ranges: [[2816, 2943]] },
  { name: "Tamil", ranges: [[2944, 3071]] },
  { name: "Telugu", ranges: [[3072, 3199]] },
  { name: "Kannada", ranges: [[3200, 3327]] },
  { name: "Malayalam", ranges: [[3328, 3455]] },
  { name: "Sinhala", ranges: [[3456, 3583]] },
  { name: "Thai", ranges: [[3584, 3711]] },
  { name: "Lao", ranges: [[3712, 3839]] },
  { name: "Tibetan", ranges: [[3840, 4095]] },
  { name: "Myanmar", ranges: [[4096, 4255]] },
  { name: "Khmer", ranges: [[6016, 6143]] },
  {
    name: "Arabic",
    ranges: [
      [1536, 1791],
      [1872, 1919],
      [2208, 2303],
      [64336, 65023],
      [65136, 65279],
    ],
  },
  {
    name: "Hebrew",
    ranges: [
      [1424, 1535],
      [64285, 64335],
    ],
  },
  {
    name: "Armenian / Georgian",
    ranges: [
      [1328, 1423],
      [4256, 4351],
    ],
  },
  {
    name: "Emoji",
    ranges: [
      [126976, 129791],
      [9728, 10175],
      [11008, 11263],
      [65039, 65039],
    ],
  },
];
function Tt(f) {
  const i = new Map();
  for (const r of f) {
    const n = r.codePointAt(0);
    if (!(n < 1328 || O(n) || P[r] !== void 0)) {
      for (const o of vt)
        if (o.ranges.some(([c, d]) => n >= c && n <= d)) {
          i.set(o.name, (i.get(o.name) ?? 0) + 1);
          break;
        }
    }
  }
  return Array.from(i, ([r, n]) => ({ name: r, count: n })).sort(
    (r, n) => n.count - r.count,
  );
}
const mt = async () => {
    const f = await fetch("/fonts/DejaVuSans-subset.ttf");
    if (!f.ok) throw new Error("font not available");
    return new Uint8Array(await f.arrayBuffer());
  },
  pt = async () => {
    const f = await fetch("/fonts/FreeSans-devanagari-subset.ttf");
    if (!f.ok) throw new Error("font not available");
    return new Uint8Array(await f.arrayBuffer());
  },
  Y = (f) => f >= 2304 && f <= 2431,
  Z = (f) => async () => {
    const i = await fetch(f);
    if (!i.ok) throw new Error("font not available");
    return new Uint8Array(await i.arrayBuffer());
  },
  At = {
    regular: Z("/fonts/FDPSans-Regular-latin.ttf"),
    bold: Z("/fonts/FDPSans-Bold-latin.ttf"),
  };
class tt {
  constructor(i, r, n, o) {
    ((this.family = i),
      (this.bold = r),
      (this.italic = n),
      (this.env = o),
      (this.raster = !0));
  }
  widthOfTextAtSize(i, r) {
    return this.env.measure(i, this.family, this.bold, this.italic) * r;
  }
}
const rt = 1.15,
  J = 1.6,
  gt = {
    sans: '"Helvetica Neue", Helvetica, Arial, "Segoe UI", "Noto Sans", "PingFang SC", "Hiragino Sans", "Microsoft YaHei", "Noto Sans CJK SC", sans-serif',
    serif:
      '"Times New Roman", Times, "Noto Serif", "Songti SC", "Hiragino Mincho ProN", "SimSun", "Noto Serif CJK SC", serif',
    mono: '"Courier New", Courier, "Noto Sans Mono", "PingFang SC", "Noto Sans Mono CJK SC", monospace',
  },
  wt = /[\u0590-\u08ff\ufb1d-\ufdff\ufe70-\ufeff]/;
function bt() {
  if (typeof document > "u") return null;
  const f = () => document.createElement("canvas");
  let i = null;
  const r = (o, c, d, g) =>
      `${g ? "italic " : ""}${d ? "bold " : ""}${o}px ${gt[c]}`,
    n = (o, c, d, g) => (
      (i ??= f().getContext("2d")),
      i
        ? ((i.font = r(100, c, d, g)), i.measureText(o).width / 100)
        : o.length * 0.6
    );
  return {
    measure: n,
    async render(o, c, d, g, w) {
      const u = n(o, c, d, g),
        h = f(),
        m = Math.max(1, Math.ceil(u * 20 * 4) + 16);
      ((h.width = Math.min(m, 16e3)), (h.height = Math.ceil(J * 20 * 4)));
      const A = h.getContext("2d");
      if (!A) throw new Error("canvas unavailable");
      ((A.font = r(80, c, d, g)),
        (A.fillStyle = `rgb(${Math.round(w[0] * 255)},${Math.round(w[1] * 255)},${Math.round(w[2] * 255)})`),
        (A.textBaseline = "alphabetic"));
      let R = !1;
      for (const F of o) {
        if (wt.test(F)) {
          R = !0;
          break;
        }
        if (!nt(F)) break;
      }
      ((A.direction = R ? "rtl" : "ltr"),
        (A.textAlign = R ? "right" : "left"),
        A.fillText(o, R ? h.width - 8 : 8, rt * 20 * 4));
      const _ = await new Promise((F, k) =>
        h.toBlob(
          (M) => (M ? F(M) : k(new Error("toBlob failed"))),
          "image/png",
        ),
      );
      return {
        png: new Uint8Array(await _.arrayBuffer()),
        widthEm: h.width / 80,
      };
    },
  };
}
class Ft {
  constructor(
    i,
    r = mt,
    n = bt(),
    o = typeof document < "u" ? pt : null,
    c = null,
  ) {
    ((this.pdf = i),
      (this.loadFallback = r),
      (this.rasterEnv = n),
      (this.loadDeva = o),
      (this.embedSans = c),
      (this.std = new Map()),
      (this.fallback = null),
      (this.fallbackTried = !1),
      (this.deva = null),
      (this.devaTried = !1),
      (this.latin = null),
      (this.latinTried = !1),
      (this.replaced = new Map()),
      (this.rasterChars = 0),
      (this.rasterFonts = new Map()),
      (this.rasterQueue = []),
      (this.rasterImages = new Map()));
  }
  rasterFont(i, r, n) {
    const o = `${i}${r ? "b" : ""}${n ? "i" : ""}`;
    let c = this.rasterFonts.get(o);
    return (
      c || ((c = new tt(i, r, n, this.rasterEnv)), this.rasterFonts.set(o, c)),
      c
    );
  }
  drawRun(i, r, n) {
    const o = Array.isArray(n.color) ? ct(...n.color) : n.color;
    if (r.font instanceof tt) {
      const c = o,
        d =
          c.red !== void 0
            ? [c.red, c.green ?? 0, c.blue ?? 0]
            : [c.gray ?? 0, c.gray ?? 0, c.gray ?? 0];
      this.rasterQueue.push({
        page: i,
        text: r.text,
        font: r.font,
        x: n.x,
        y: n.y,
        size: n.size,
        color: d,
      });
    } else
      i.drawText(r.text, {
        x: n.x,
        y: n.y,
        size: n.size,
        font: r.font,
        color: o,
      });
  }
  async flushRasters() {
    const i = this.rasterQueue;
    this.rasterQueue = [];
    for (const r of i) {
      const n = `${r.font.family}|${r.font.bold}|${r.font.italic}|${r.color.map((c) => c.toFixed(2)).join(",")}|${r.text}`;
      let o = this.rasterImages.get(n);
      o ||
        ((o = this.rasterEnv
          .render(r.text, r.font.family, r.font.bold, r.font.italic, r.color)
          .then(async (c) => ({
            img: await this.pdf.embedPng(c.png),
            widthEm: c.widthEm,
          }))),
        this.rasterImages.set(n, o));
      try {
        const { img: c, widthEm: d } = await o;
        r.page.drawImage(c, {
          x: r.x - 2 * (1 / 20) * r.size,
          y: r.y - (J - rt) * r.size,
          width: d * r.size,
          height: J * r.size,
        });
      } catch (c) {
        console.warn("Text could not be drawn as a picture", c);
        for (const d of r.text)
          this.replaced.set(d, (this.replaced.get(d) ?? 0) + 1);
      }
    }
  }
  get replacedCount() {
    let i = 0;
    for (const r of Array.from(this.replaced.values())) i += r;
    return i;
  }
  standard(i, r = !1, n = !1) {
    const o = `${i}${r ? "b" : ""}${n ? "i" : ""}`;
    let c = this.std.get(o);
    return (
      c ||
        ((c = this.pdf.embedStandardFont(ut[i][(r ? 1 : 0) + (n ? 2 : 0)])),
        this.std.set(o, c)),
      c
    );
  }
  async prepare(i) {
    if (
      this.loadDeva &&
      !this.deva &&
      !this.devaTried &&
      /[\u0900-\u097f]/.test(i)
    ) {
      this.devaTried = !0;
      try {
        this.pdf.registerFontkit(U);
        const n = await this.pdf.embedFont(await this.loadDeva(), {
          subset: !1,
        });
        this.deva = { font: n, chars: new Set(n.getCharacterSet()) };
      } catch (n) {
        console.warn("Devanagari font could not be loaded", n);
      }
    }
    if (this.embedSans && !this.latin && !this.latinTried) {
      this.latinTried = !0;
      try {
        this.pdf.registerFontkit(U);
        const n = async (o) => {
          const c = await this.pdf.embedFont(await o(), { subset: !0 });
          return { font: c, chars: new Set(c.getCharacterSet()) };
        };
        this.latin = {
          regular: await n(this.embedSans.regular),
          bold: await n(this.embedSans.bold),
        };
      } catch (n) {
        console.warn(
          "Embedded Latin font could not be loaded; using the built-in font",
          n,
        );
      }
    }
    if (this.fallback || this.fallbackTried) return;
    let r = !1;
    for (const n of i) {
      const o = n.codePointAt(0);
      if (
        !O(o) &&
        P[n] === void 0 &&
        o > 31 &&
        !(
          this.latin &&
          (this.latin.regular.chars.has(o) || this.latin.bold.chars.has(o))
        )
      ) {
        r = !0;
        break;
      }
    }
    if (r) {
      this.fallbackTried = !0;
      try {
        this.pdf.registerFontkit(U);
        const n = await this.pdf.embedFont(await this.loadFallback(), {
          subset: !1,
        });
        this.fallback = { font: n, chars: new Set(n.getCharacterSet()) };
      } catch (n) {
        console.warn("Fallback font could not be loaded", n);
      }
    }
  }
  canDraw(i) {
    const r = i.codePointAt(0);
    return (
      O(r) ||
      !!this.fallback?.chars.has(r) ||
      !!this.latin?.regular.chars.has(r) ||
      (Y(r) && !!this.deva?.chars.has(r)) ||
      P[i] !== void 0
    );
  }
  scan(i) {
    for (const r of i) {
      const n = r.codePointAt(0);
      if (!(
        n < 32 ||
        n === 127 ||
        O(n) ||
        this.fallback?.chars.has(n) ||
        this.latin?.regular.chars.has(n) ||
        (Y(n) && this.deva?.chars.has(n)) ||
        P[r] !== void 0
      )) {
        if (this.rasterEnv) {
          et(n) || this.rasterChars++;
          continue;
        }
        this.replaced.set(r, (this.replaced.get(r) ?? 0) + 1);
      }
    }
  }
  runs(i, r, n = !1, o = !1) {
    let c;
    const d = () => (c ??= this.standard(r, n, o)),
      g = [],
      w = (u, h) => {
        if (!u) return;
        const m = g[g.length - 1];
        m && m.font === h ? (m.text += u) : g.push({ text: u, font: h });
      },
      $ =
        this.latin && r === "sans" && !o
          ? n
            ? this.latin.bold
            : this.latin.regular
          : null,
      p = [];
    for (const u of i) {
      const h = u.codePointAt(0);
      if (h < 32 || h === 127) continue;
      const m = nt(u);
      $?.chars.has(h)
        ? p.push({ ch: u, kind: "latin", neutral: m })
        : O(h)
          ? p.push({ ch: u, kind: "base", neutral: m })
          : Y(h) && this.deva?.chars.has(h)
            ? p.push({ ch: u, kind: "deva", neutral: !1 })
            : (h === 8204 || h === 8205) && this.deva?.chars.has(h)
              ? p.push({ ch: u, kind: "deva", neutral: !0 })
              : this.fallback?.chars.has(h)
                ? p.push({ ch: u, kind: "dejavu", neutral: m })
                : P[u] !== void 0
                  ? p.push({ ch: u, kind: "sub", neutral: m })
                  : et(h)
                    ? p.push({ ch: u, kind: "skip", neutral: !0 })
                    : p.push({
                        ch: u,
                        kind: this.rasterEnv ? "raster" : "q",
                        neutral: !1,
                      });
    }
    if (this.deva) {
      let u = -1;
      for (let h = 0; h < p.length; h++)
        if (p[h].kind === "deva") {
          if (u >= 0)
            for (let m = u + 1; m < h; m++)
              (p[m].kind === "base" || p[m].kind === "latin") &&
                p[m].ch === " " &&
                this.deva.chars.has(32) &&
                (p[m].kind = "deva");
          u = h;
        }
    }
    if (this.rasterEnv) {
      let u = -1;
      for (let h = 0; h < p.length; h++)
        if (p[h].kind === "raster") {
          if (u >= 0)
            for (let m = u + 1; m < h; m++)
              (p[m].neutral || p[m].kind === "skip") && (p[m].kind = "raster");
          u = h;
        }
    }
    for (const u of p)
      switch (u.kind) {
        case "base":
          w(u.ch, d());
          break;
        case "latin":
          w(u.ch, $.font);
          break;
        case "dejavu":
          w(u.ch, this.fallback.font);
          break;
        case "deva":
          w(u.ch, this.deva.font);
          break;
        case "sub":
          w(P[u.ch], d());
          break;
        case "raster":
          w(u.ch, this.rasterFont(r, n, o));
          break;
        case "q":
          w("?", d());
          break;
      }
    return g;
  }
  width(i, r, n, o = !1, c = !1) {
    let d = 0;
    for (const g of this.runs(i, n, o, c))
      d += g.font.widthOfTextAtSize(g.text, r);
    return d;
  }
}
const et = (f) =>
    (f >= 8203 && f <= 8207) ||
    (f >= 8232 && f <= 8238) ||
    (f >= 8288 && f <= 8292) ||
    f === 65279 ||
    (f >= 65024 && f <= 65039),
  nt = (f) =>
    /[\s\d!-/:-@[-`{-~\u00a1-\u00bf\u2000-\u206f\u3000-\u303f\uff00-\uff0f\uff1a-\uff20]/.test(
      f,
    );
function Ct(f) {
  const i = f.replacedCount;
  if (i === 0) return null;
  const r = Array.from(f.replaced.keys()).slice(0, 6).join(" ");
  return `${i} ${i === 1 ? "character" : "characters"} (${r}${f.replaced.size > 6 ? " …" : ""}) could not be drawn and ${i === 1 ? "was" : "were"} replaced with “?”.`;
}
export {
  Ft as P,
  J as R,
  P as S,
  rt as a,
  bt as b,
  O as c,
  kt as d,
  tt as e,
  pt as f,
  wt as g,
  At as h,
  dt as i,
  Ct as r,
  Et as s,
  Tt as u,
};
//# sourceMappingURL=pdfFonts-Ckcqm3Ic.js.map
