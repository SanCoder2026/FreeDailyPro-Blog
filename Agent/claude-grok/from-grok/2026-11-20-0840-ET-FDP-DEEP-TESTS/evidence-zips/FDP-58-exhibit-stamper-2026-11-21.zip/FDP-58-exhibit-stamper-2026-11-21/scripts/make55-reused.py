# FDP-55 Bates test PDFs (reportlab + pikepdf)
from reportlab.lib.pagesizes import letter, A4, landscape
from reportlab.pdfgen import canvas
import pikepdf, os, shutil
def doc(name, n, size=letter, dark=False, margin_text=False, label=''):
    c = canvas.Canvas(name, pagesize=size); w, h = size
    for i in range(n):
        if dark: c.setFillColorRGB(0.05, 0.05, 0.1); c.rect(0, 0, w, h, fill=1, stroke=0); c.setFillColorRGB(1, 1, 1)
        c.setFont('Helvetica-Bold', 22); c.drawString(72, h - 100, f'{label or name} page {i+1} of {n}')
        c.setFont('Helvetica', 11)
        for k in range(30): c.drawString(72, h - 140 - k * 16, f'Line {k+1}: discovery document text for production testing.')
        if margin_text:
            c.setFont('Helvetica', 9); c.drawString(w - 200, 20, 'FOOTER TEXT AT THE MARGIN 123'); c.drawString(20, 20, 'LEFT FOOTER')
        c.showPage()
    c.save()
doc('contract_letter_5p.pdf', 5, label='Contract')
doc('emails_a4_3p.pdf', 3, A4, label='Emails')
doc('landscape_2p.pdf', 2, landscape(letter), label='Landscape')
doc('dark_2p.pdf', 2, dark=True, label='Dark scan')
doc('footer_2p.pdf', 2, margin_text=True, label='Footer')
doc('one_page.pdf', 1, label='Single')
# rotated pages: page 1 /Rotate 90, page 2 /Rotate 270, page 3 /Rotate 180
doc('tmp_rot.pdf', 3, label='Rotated')
p = pikepdf.open('tmp_rot.pdf'); p.pages[0].Rotate = 90; p.pages[1].Rotate = 270; p.pages[2].Rotate = 180; p.save('rotated_3p.pdf'); os.remove('tmp_rot.pdf')
# offset MediaBox and smaller CropBox
doc('tmp_off.pdf', 2, label='Offset box')
p = pikepdf.open('tmp_off.pdf')
for pg in p.pages:
    pg.MediaBox = pikepdf.Array([100, 100, 712, 892]); pg.CropBox = pikepdf.Array([150, 150, 662, 842])
p.save('offset_cropbox_2p.pdf'); os.remove('tmp_off.pdf')
# same file name in another folder (duplicate output name)
os.makedirs('dup', exist_ok=True); doc('dup/contract_letter_5p.pdf', 2, label='Second contract')
# 12-page doc for digits overflow (start 999995, 6 digits)
doc('twelve_12p.pdf', 12, label='Twelve')
# text renamed to pdf
open('fake.pdf', 'w').write('not a pdf at all')
for f in sorted(os.listdir('.')): print(f, os.path.getsize(f) if os.path.isfile(f) else 'dir')
