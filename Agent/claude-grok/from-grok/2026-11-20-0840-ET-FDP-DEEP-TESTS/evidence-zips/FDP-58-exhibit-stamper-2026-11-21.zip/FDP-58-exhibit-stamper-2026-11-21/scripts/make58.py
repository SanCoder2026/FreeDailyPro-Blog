# FDP-58 extra test files (reportlab). Reuses FDP-55 files (make55-reused.py) for the rest.
from reportlab.pdfgen import canvas; from reportlab.lib.pagesizes import letter
import os; D=os.path.dirname(os.path.abspath(__file__)); os.makedirs(D+'/many',exist_ok=True)
for i in range(1,29):
    c=canvas.Canvas(f'{D}/many/doc{i:02d}.pdf',pagesize=letter); c.setFont('Helvetica',18); c.drawString(72,400,f'Document {i:02d}'); c.save()
c=canvas.Canvas(D+'/header_top_right.pdf',pagesize=letter); w,h=letter
c.setFont('Helvetica-Bold',11); c.drawRightString(w-36,h-40,'Case No. 2026-CV-01234  |  Filed 11/21/2026'); c.setFont('Helvetica',12); c.drawString(72,600,'Header text at the top-right margin.'); c.showPage(); c.drawString(72,600,'Page 2'); c.save()
