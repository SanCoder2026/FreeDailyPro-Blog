import { r as c, j as t } from "./vendor-react-D01g8YgM.js";
import { u as F } from "./useShareGate-BYBawloP.js";
import { b as D, T as L } from "./ToolPage-DwLoDncN.js";
import { e as m, I as k, B as j, k as $, f as v } from "./index-B1CTyGtY.js";
import { h as H } from "./textUtils-DaDvKhN-.js";
import { T as U } from "./ToolInfoSection-C0i6Zbwo.js";
import { S as w, a as y, b, c as T, d as o } from "./select-ic5yaeGw.js";
import "./useExportGate-BU4jIFHF.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
const S = {
    fun: {
      instagram: [
        "Today's little joy: {topic} ✨",
        "Save this one: {topic} 🤍",
        "Swipe for the details on {topic} 🎉",
      ],
      tiktok: [
        "POV: {topic} 👀",
        "Okay, but have you tried this? {topic} 🎬",
        "Stay till the end: {topic} 😄",
      ],
      x: [
        "Today: {topic} 🎉",
        "{topic}. Thoughts?",
        "Small win to share: {topic} ✨",
      ],
      linkedin: [
        "Sharing something I'm excited about: {topic}",
        "A quick update: {topic}",
        "Here's what I've been up to: {topic}",
      ],
    },
    professional: {
      instagram: [
        "{topic}. Details below.",
        "Introducing: {topic}.",
        "Now available: {topic}.",
      ],
      tiktok: [
        "Quick overview: {topic}.",
        "What to know: {topic}.",
        "Behind the scenes: {topic}.",
      ],
      x: ["{topic}.", "New: {topic}.", "Worth a look: {topic}."],
      linkedin: [
        "I'm pleased to share an update: {topic}.",
        "A topic on my mind this week: {topic}. Here is what I've learned, and I'd value your perspective.",
        "Update: {topic}. If this is relevant to your work, let's connect.",
      ],
    },
    bold: {
      instagram: [
        "{topic}. No half measures. 🔥",
        "Make it count: {topic} 💥",
        "This is the moment: {topic} 🚀",
      ],
      tiktok: [
        "Stop scrolling. {topic} 🔥",
        "Watch this: {topic} 💥",
        "{topic}. Let's go. 🚀",
      ],
      x: [
        "{topic}. Full stop. 🔥",
        "Not asking. Announcing: {topic} 💥",
        "Here it is: {topic} 🚀",
      ],
      linkedin: [
        "{topic}. Here's why it matters.",
        "Stop waiting. {topic}.",
        "A direct take: {topic}.",
      ],
    },
    genz: {
      instagram: [
        "not me being obsessed with this: {topic} 😭",
        "main character energy: {topic} ✨",
        "bestie, look: {topic} 💅",
      ],
      tiktok: [
        "it's giving: {topic} 💀",
        "wait this is actually good: {topic} 😳",
        "me every day: {topic} fr fr",
      ],
      x: [
        "{topic}. that's it that's the tweet.",
        "no thoughts, just: {topic}",
        "plot twist: {topic} 👀",
      ],
      linkedin: [
        "Sharing something I'm excited about: {topic}",
        "A quick update: {topic}",
        "Here's what I've been up to: {topic}",
      ],
    },
  },
  C = {
    instagram: "Link in bio.",
    tiktok: "Follow for more.",
    x: "",
    linkedin: "What do you think?",
  },
  I = { instagram: 5, tiktok: 4, x: 2, linkedin: 3 },
  W = { tiktok: ["#fyp"] };
function B(p, a = "instagram", d = "fun", r = {}) {
  const i = a in I ? a : "instagram",
    h = d in S ? d : "fun",
    u = p.trim().replace(/[.!?…]+$/, ""),
    s = (r.detail ?? "").trim(),
    g = H(p, 12),
    l = [...(W[i] ?? []), ...g].slice(0, I[i]);
  return S[h][i].map((x) => {
    let n = x.replace(/\{topic\}/g, u);
    return (
      s &&
        (n += `
${/[.!?]$/.test(s) ? s : s + "."}`),
      r.cta &&
        C[i] &&
        (n += `
${C[i]}`),
      l.length && i !== "x"
        ? `${n}

${l.join(" ")}`
        : n
    );
  });
}
const f = {
  what: "Generates draft social media captions in four tones (fun, professional, bold, Gen-Z) from a topic and an optional specific detail, as a starting point to edit into your own voice.",
  how: "Describe your post or topic, generate a caption draft, and edit it to match your own tone before posting.",
  tip: "Treat generated captions as a first draft, not a final post — the captions that perform best usually have a specific, personal detail that a generic starting point won't include on its own.",
};
function kt() {
  const { gateShare: p } = F(),
    [a, d] = c.useState(""),
    [r, i] = c.useState("instagram"),
    [h, u] = c.useState("fun"),
    [s, g] = c.useState(""),
    [l, x] = c.useState(!1),
    [n, N] = c.useState([]),
    { logUsageNow: A } = D(),
    G = async () => {
      !a.trim() || !(await A()) || N(B(a, r, h, { detail: s, cta: l }));
    };
  return t.jsxs(L, {
    children: [
      t.jsxs("div", {
        className: "space-y-4",
        children: [
          t.jsxs("div", {
            children: [
              t.jsx(m, { children: "Topic / Description" }),
              t.jsx(k, {
                "aria-label": "Topic / Description",
                value: a,
                onChange: (e) => d(e.target.value),
                placeholder: "What's your post about?",
              }),
            ],
          }),
          t.jsxs("div", {
            children: [
              t.jsx(m, { children: "A specific detail (optional)" }),
              t.jsx(k, {
                "aria-label": "A specific detail (optional)",
                value: s,
                onChange: (e) => g(e.target.value),
                placeholder: "e.g. 20% off until Friday, or what surprised you",
              }),
            ],
          }),
          t.jsxs("div", {
            className: "flex gap-3",
            children: [
              t.jsxs("div", {
                className: "flex-1",
                children: [
                  t.jsx(m, { children: "Platform" }),
                  t.jsxs(w, {
                    value: r,
                    onValueChange: (e) => i(e),
                    children: [
                      t.jsx(y, { children: t.jsx(b, {}) }),
                      t.jsxs(T, {
                        children: [
                          t.jsx(o, {
                            value: "instagram",
                            children: "Instagram",
                          }),
                          t.jsx(o, { value: "tiktok", children: "TikTok" }),
                          t.jsx(o, { value: "x", children: "X (Twitter)" }),
                          t.jsx(o, { value: "linkedin", children: "LinkedIn" }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              t.jsxs("div", {
                className: "flex-1",
                children: [
                  t.jsx(m, { children: "Tone" }),
                  t.jsxs(w, {
                    value: h,
                    onValueChange: (e) => u(e),
                    children: [
                      t.jsx(y, { children: t.jsx(b, {}) }),
                      t.jsxs(T, {
                        children: [
                          t.jsx(o, { value: "fun", children: "Fun" }),
                          t.jsx(o, {
                            value: "professional",
                            children: "Professional",
                          }),
                          t.jsx(o, { value: "bold", children: "Bold" }),
                          t.jsx(o, { value: "genz", children: "Gen-Z" }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          t.jsxs("label", {
            className: "flex items-center gap-2 text-sm cursor-pointer",
            children: [
              t.jsx("input", {
                type: "checkbox",
                checked: l,
                onChange: (e) => x(e.target.checked),
              }),
              " Add a call to action",
            ],
          }),
          t.jsxs(j, {
            onClick: G,
            disabled: !a.trim(),
            className: "gap-2",
            children: [
              t.jsx($, { className: "h-4 w-4" }),
              " Generate Captions",
            ],
          }),
          n.length > 0 &&
            t.jsx("div", {
              className: "space-y-3",
              children: n.map((e, O) =>
                t.jsxs(
                  "div",
                  {
                    className:
                      "p-4 rounded-lg border bg-card text-sm whitespace-pre-wrap flex items-start justify-between gap-3",
                    children: [
                      t.jsxs("span", {
                        children: [
                          e,
                          t.jsxs("span", {
                            className:
                              "block text-xs text-muted-foreground mt-1",
                            children: [
                              e.length,
                              " characters",
                              r === "x" && e.length > 280
                                ? " - over the 280 limit, shorten the topic"
                                : "",
                            ],
                          }),
                        ],
                      }),
                      t.jsx(j, {
                        size: "sm",
                        variant: "outline",
                        onClick: () => {
                          p(async () => {
                            try {
                              return (
                                await navigator.clipboard.writeText(e),
                                v.success("Copied!"),
                                !0
                              );
                            } catch {
                              return (
                                v.error(
                                  "Couldn't copy. Select the text and copy it by hand.",
                                ),
                                !1
                              );
                            }
                          });
                        },
                        children: "Copy",
                      }),
                    ],
                  },
                  O,
                ),
              ),
            }),
        ],
      }),
      t.jsx(U, { whatIsIt: f.what, howToUse: f.how, tip: f.tip }),
    ],
  });
}
export { kt as default };
//# sourceMappingURL=CaptionGenerator-C4DMCLiD.js.map
