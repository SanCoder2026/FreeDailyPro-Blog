const f = new Set(
    "a an and are as at be but by for from has have he her his i if in into is it its me my no not of on or our she so than that the their them then there these they this to up us was we were what when which who will with you your".split(
      " ",
    ),
  ),
  d = new RegExp("[\\p{L}\\p{N}]+(?:['’][\\p{L}]+)?", "gu"),
  L = new RegExp("[\\p{L}\\p{N}]+", "gu"),
  y = new RegExp("^[\\p{Script=Latin}\\p{N}]+$", "u");
function m(t) {
  return t.toLowerCase().normalize("NFC").match(d) ?? [];
}
const x = new RegExp(
  "[.!?,;:\\u2026]+(?=\\s|$)|[\\r\\n]+|\\s[-\\u2013\\u2014]+\\s|[\\u2013\\u2014]",
  "u",
);
function A(t, l) {
  const c = m(t).length,
    a = l.phraseLength,
    i = new Map();
  for (const s of t.split(x)) {
    const o = m(s);
    for (let n = 0; n + a <= o.length; n++) {
      const r = o.slice(n, n + a);
      if (
        (l.skipCommon && (f.has(r[0]) || f.has(r[a - 1]))) ||
        (a === 1 && r[0].length < 3 && y.test(r[0]))
      )
        continue;
      const h = r.join(" ");
      i.set(h, (i.get(h) ?? 0) + 1);
    }
  }
  return {
    rows: Array.from(i, ([s, o]) => ({
      phrase: s,
      count: o,
      density: ((o / Math.max(1, c)) * 100).toFixed(2),
    }))
      .sort((s, o) => o.count - s.count || s.phrase.localeCompare(o.phrase))
      .slice(0, l.limit ?? 20),
    totalWords: c,
  };
}
const b = [
    [/c\+\+/gi, "cplusplus"],
    [/c#/gi, "csharp"],
    [/f#/gi, "fsharp"],
    [/&/g, "and"],
    [/\.net\b/gi, "dotnet"],
  ],
  g = (t) => t.charAt(0).toUpperCase() + t.slice(1),
  E = 100,
  T = [
    {
      id: "any",
      label: "Any platform",
      max: null,
      note: "No platform limit applied.",
    },
    {
      id: "instagram",
      label: "Instagram (30 hashtags per post)",
      max: 30,
      note: "Instagram allows up to 30 hashtags per post.",
    },
    {
      id: "youtube",
      label: "YouTube (15 hashtags per video)",
      max: 15,
      note: "YouTube ignores all hashtags on a video that has more than 15.",
    },
    {
      id: "other",
      label: "LinkedIn, X, TikTok (no fixed limit)",
      max: null,
      note: "These apps publish no fixed hashtag count, so none is applied. A few focused tags usually read best.",
    },
  ],
  R = (t) =>
    t
      .normalize("NFD")
      .replace(new RegExp("\\p{M}+", "gu"), "")
      .replace(/ß/g, "ss")
      .replace(/ø/gi, "o")
      .replace(/æ/gi, "ae")
      .replace(/œ/gi, "oe")
      .replace(/đ/gi, "d")
      .replace(/ł/gi, "l");
function C(t, l = 15, c = {}) {
  let a = c.ascii ? R(t) : t;
  for (const [e, p] of b) a = a.replace(e, ` ${p} `);
  const i = (a.match(L) ?? []).map((e) => e.toLowerCase());
  if (i.length === 0) return [];
  const u = i.filter((e) => !f.has(e)),
    s = u.length ? u : i,
    o = (e) => e.map(g).join(""),
    n = [];
  (n.push(o(s)), s.forEach((e) => n.push(g(e))));
  for (let e = 0; e + 1 < s.length; e++) n.push(o(s.slice(e, e + 2)));
  const r = g(s[0]);
  for (const e of [
    "Tips",
    "Life",
    "Daily",
    "Community",
    "Lovers",
    "Ideas",
    "Inspiration",
  ])
    n.push(r + e);
  const h = [];
  for (const e of n) {
    const p = "#" + e.slice(0, E);
    e.length >= 2 &&
      !h.some((w) => w.toLowerCase() === p.toLowerCase()) &&
      h.push(p);
  }
  return h.slice(0, l);
}
export { E as M, T as P, C as h, A as k };
//# sourceMappingURL=textUtils-DaDvKhN-.js.map
