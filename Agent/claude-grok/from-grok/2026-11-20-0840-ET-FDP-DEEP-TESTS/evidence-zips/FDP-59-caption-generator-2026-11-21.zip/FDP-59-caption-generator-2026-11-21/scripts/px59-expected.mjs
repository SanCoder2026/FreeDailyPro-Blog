// FDP-59: recompute expected captions from the site's own template code (copied from CaptionGenerator-C4DMCLiD.js) and compare with live cases.json
import { h as H } from '/tmp/textUtils59.mjs';
import fs from 'fs';
const S = {
    fun: {
      instagram: [
        "Today's little joy: {topic} ✨",
        "Save this one: {topic} 🤍",
        "Swipe for the details on {topic} 🎉",
      ],
      tiktok: [
        "POV: {topic} 👀",
        "Okay, but have you tried this? {topic} 🎬",
        "Stay till the end: {topic} 😄",
      ],
      x: [
        "Today: {topic} 🎉",
        "{topic}. Thoughts?",
        "Small win to share: {topic} ✨",
      ],
      linkedin: [
        "Sharing something I'm excited about: {topic}",
        "A quick update: {topic}",
        "Here's what I've been up to: {topic}",
      ],
    },
    professional: {
      instagram: [
        "{topic}. Details below.",
        "Introducing: {topic}.",
        "Now available: {topic}.",
      ],
      tiktok: [
        "Quick overview: {topic}.",
        "What to know: {topic}.",
        "Behind the scenes: {topic}.",
      ],
      x: ["{topic}.", "New: {topic}.", "Worth a look: {topic}."],
      linkedin: [
        "I'm pleased to share an update: {topic}.",
        "A topic on my mind this week: {topic}. Here is what I've learned, and I'd value your perspective.",
        "Update: {topic}. If this is relevant to your work, let's connect.",
      ],
    },
    bold: {
      instagram: [
        "{topic}. No half measures. 🔥",
        "Make it count: {topic} 💥",
        "This is the moment: {topic} 🚀",
      ],
      tiktok: [
        "Stop scrolling. {topic} 🔥",
        "Watch this: {topic} 💥",
        "{topic}. Let's go. 🚀",
      ],
      x: [
        "{topic}. Full stop. 🔥",
        "Not asking. Announcing: {topic} 💥",
        "Here it is: {topic} 🚀",
      ],
      linkedin: [
        "{topic}. Here's why it matters.",
        "Stop waiting. {topic}.",
        "A direct take: {topic}.",
      ],
    },
    genz: {
      instagram: [
        "not me being obsessed with this: {topic} 😭",
        "main character energy: {topic} ✨",
        "bestie, look: {topic} 💅",
      ],
      tiktok: [
        "it's giving: {topic} 💀",
        "wait this is actually good: {topic} 😳",
        "me every day: {topic} fr fr",
      ],
      x: [
        "{topic}. that's it that's the tweet.",
        "no thoughts, just: {topic}",
        "plot twist: {topic} 👀",
      ],
      linkedin: [
        "Sharing something I'm excited about: {topic}",
        "A quick update: {topic}",
        "Here's what I've been up to: {topic}",
      ],
    },
  },
  C = {
    instagram: "Link in bio.",
    tiktok: "Follow for more.",
    x: "",
    linkedin: "What do you think?",
  },
  I = { instagram: 5, tiktok: 4, x: 2, linkedin: 3 },
  W = { tiktok: ["#fyp"] };
function B(p, a = "instagram", d = "fun", r = {}) {
  const i = a in I ? a : "instagram",
    h = d in S ? d : "fun",
    u = p.trim().replace(/[.!?…]+$/, ""),
    s = (r.detail ?? "").trim(),
    g = H(p, 12),
    l = [...(W[i] ?? []), ...g].slice(0, I[i]);
  return S[h][i].map((x) => {
    let n = x.replace(/\{topic\}/g, u);
    return (
      s &&
        (n += `
${/[.!?]$/.test(s) ? s : s + "."}`),
      r.cta &&
        C[i] &&
        (n += `
${C[i]}`),
      l.length && i !== "x"
        ? `${n}

${l.join(" ")}`
        : n
    );
  });
}

const P={'Instagram':'instagram','TikTok':'tiktok','X (Twitter)':'x','LinkedIn':'linkedin'}, T={'Fun':'fun','Professional':'professional','Bold':'bold','Gen-Z':'genz'};
const R=JSON.parse(fs.readFileSync('/workspace/deep/59-caption-generator/live/'+(process.argv[2]||'cases.json')));
const out={};
for (const [id,v] of Object.entries(R.cases)) { const o=v.input; const exp=B(o.topic,P[o.platform],T[o.tone],{detail:o.detail||'',cta:!!o.cta}); const live=(v.captions||[]).map(c=>c.text);
  out[id]={match: JSON.stringify(exp)===JSON.stringify(live), lenOK: (v.captions||[]).every((c,i)=>c.count.startsWith(String(exp[i].length))), live};
  console.log(id, out[id].match, out[id].lenOK); }
fs.writeFileSync('/workspace/deep/59-caption-generator/live/expected-compare.json', JSON.stringify(out,null,1));
