// FDP-59 Social Caption Generator, guest. Usage: node px59-live.js <probe|left|cases> [engine]  (TRIES env = fresh contexts to try for one with uses left; SUF suffix)
// probe: as-is context (usually 10/10) -> strip/Quick Buy presence, disabled button, Generate at cap (cap dialog?), Copy at cap.
// left: context with uses left -> G01 generate, copy, G02 tone change, G03 platform change, copy, reload, G04. Tracks fdp-usage-v1 + POSTs.
// cases: context with uses left -> 12 input cases in ONE load; captions saved for comparison with expected (px59-expected.mjs).
// Never signs in, never types email/card, never clicks pass "Continue" or ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/59-caption-generator/'; const OUT = BASE + 'live/'; const URL = 'https://www.freedailypro.com/tool/caption-generator';
const mode = process.argv[2] || 'probe'; const eng = process.argv[3] || 'chromium'; const sfx = (eng === 'chromium' ? '' : '-' + eng) + (process.env.SUF || '');
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').replace(/dev[:%][^&"]*/g, 'dev:REDACTED').slice(0, 160);
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p, net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, locale: 'en-US' }); if (eng === 'chromium') await c.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://www.freedailypro.com' }); p = await c.newPage(); p.setDefaultTimeout(10000); net = [];
  await p.addInitScript(() => { window.__t = []; window.__clip = []; const seen = new WeakSet(); setInterval(() => { document.querySelectorAll('[data-sonner-toast]').forEach(n => { if (!seen.has(n)) { seen.add(n); window.__t.push((n.innerText || '').trim()); } }); }, 120);
   try { const w = navigator.clipboard.writeText.bind(navigator.clipboard); navigator.clipboard.writeText = async s => { window.__clip.push(s); return w(s).catch(() => { }); }; } catch (e) { } });
  p.on('request', r => { const u = r.url(); if (r.method() === 'POST' && !/google|doubleclick|insight\.hit|funnel\.hit|analytics/.test(u)) net.push({ t: now(), u: red(u), len: (r.postData() || '').length }); });
  await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 450) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(250); } };
 const toasts = n => p.evaluate(n => (window.__t || []).slice(n), n); const tc = () => p.evaluate(() => (window.__t || []).length);
 const caps = () => p.evaluate(() => [...document.querySelectorAll('main div.bg-card.whitespace-pre-wrap')].map(d => { const s = d.querySelector('span'); return { text: s.childNodes[0].textContent, count: (s.querySelector('span') || {}).innerText }; }));
 const strip = () => p.evaluate(() => { const t = document.querySelector('main').innerText; return { trial: (t.match(/Trial[^\n]*/) || [null])[0], quickBuy: (t.match(/Quick Buy/g) || []).length, alerts: [...document.querySelectorAll('main [role=alert],main [role=status]')].map(a => a.innerText.trim()).filter(Boolean) }; });
 const pick = async (k, opt) => { const cb = p.locator('main [role=combobox]').nth(k); if ((await cb.innerText()).trim() === opt) return; await cb.click(); await p.waitForTimeout(300); await p.getByRole('option', { name: opt, exact: true }).click(); await p.waitForTimeout(300); };
 const setForm = async o => { await p.getByLabel('Topic / Description').fill(o.topic ?? ''); await p.getByLabel('A specific detail (optional)').fill(o.detail ?? ''); await pick(0, o.platform || 'Instagram'); await pick(1, o.tone || 'Fun'); const cb = p.locator('main label', { hasText: 'Add a call to action' }).locator('input'); if ((await cb.isChecked()) !== !!o.cta) await cb.click(); };
 const gen = async id => { const n = await tc(); const before = await used(); const bt = p.locator('main button', { hasText: 'Generate Captions' }); const disabled = await bt.isDisabled(); if (disabled) return { disabled, before }; await bt.click(); await p.waitForTimeout(1500); const d = await dialog(); const r = { before, after: await used(), dialog: d, toasts: await toasts(n), captions: await caps(), ...(await strip()) }; await p.screenshot({ path: OUT + 'cases/' + id + sfx + '.png', fullPage: false }); if (d) await esc(); return r; };
 const copy = async (i, id) => { const n = await tc(); const before = await used(); const bts = p.locator('main div.bg-card.whitespace-pre-wrap button', { hasText: 'Copy' }); if (!(await bts.count())) return { noCopy: true }; await bts.nth(i).click(); await p.waitForTimeout(1500); const d = await dialog(); const r = { before, after: await used(), dialog: d, toasts: await toasts(n), clip: await p.evaluate(() => window.__clip.slice(-1)[0] || null) }; if (d) { await p.screenshot({ path: OUT + 'cases/' + id + sfx + '-dialog.png' }); await esc(); } return r; };
 const C = async (id, fn) => { try { R.cases[id] = await fn(); } catch (e) { R.cases[id] = { err: e.message.split('\n')[0].slice(0, 200) }; } console.log(id, JSON.stringify(R.cases[id]).slice(0, 500)); };
 const findLeft = async () => { if (process.env.ANY) { await open(); R.tries.push(await used()); R.anyContext = true; return true; } const TRIES = +(process.env.TRIES || 10); for (let i = 0; i < TRIES; i++) { await open(); const u = await used(); R.tries.push(u); const [a, l] = u.split('/').map(Number); if (a < l) return true; await c.close(); } return false; };
 if (mode === 'probe') { await open(); R.start = { used: await used(), ...(await strip()), disabledEmpty: await p.locator('main button', { hasText: 'Generate Captions' }).isDisabled() };
  await p.getByLabel('Topic / Description').fill('   '); R.start.disabledSpaces = await p.locator('main button', { hasText: 'Generate Captions' }).isDisabled();
  await setForm({ topic: 'Oat milk latte now on the menu', detail: 'Half price until Friday, 7am to 10am', cta: true });
  await C('P01-generate-at-cap', () => gen('P01'));
  await C('P01b-copy-at-cap', () => copy(0, 'P01b')); await C('P01c-copy2-at-cap', () => copy(2, 'P01c'));
  await C('P02-quickbuy', async () => { await esc(); const q = p.locator('button', { hasText: /Quick Buy|Buy Day Pass/ }); return { quickBuyButtons: await q.count() }; });
  R.net = net;
 } else if (mode === 'left') { if (await findLeft()) { const L = R.left = { start: await used(), ...(await strip()) };
   await setForm({ topic: 'Oat milk latte now on the menu', detail: 'Half price until Friday, 7am to 10am', cta: true });
   await C('L01-gen', () => gen('L01')); await C('L01-copy1', () => copy(0, 'L01c')); await C('L01-copy2', () => copy(1, 'L01d'));
   await pick(1, 'Bold'); await C('L02-gen-tone-same-load', () => gen('L02'));
   await pick(0, 'LinkedIn'); await C('L03-gen-platform-same-load', () => gen('L03')); await C('L03-copy', () => copy(2, 'L03c'));
   await C('L03b-gen-identical-again', () => gen('L03b'));
   await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); L.afterReload = await used(); L.formAfterReload = await p.getByLabel('Topic / Description').inputValue();
   await setForm({ topic: 'Spring menu launch' }); await C('L04-gen-after-reload', () => gen('L04')); await C('L04-copy', () => copy(0, 'L04c'));
   L.end = await used(); L.net = net; } }
 else { if (await findLeft()) { R.start = await used(); const plan = JSON.parse(fs.readFileSync(BASE + 'testfiles/cases.json'));
   for (const [id, o] of plan) await C(id, async () => { await setForm(o); const r = await gen(id); r.input = o; return r; });
   R.end = await used(); R.net = net; } }
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', JSON.stringify(R.tries), JSON.stringify(R.start || '').slice(0, 300)); await b.close(); })();
