import { r as g, j as p } from "./vendor-react-D01g8YgM.js";
import { b as A, T, d as v } from "./ToolPage-DwLoDncN.js";
import { T as U, B as h } from "./index-B1CTyGtY.js";
import { T as j } from "./ToolInfoSection-C0i6Zbwo.js";
import { c as N } from "./copyText-DPnES92p.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
const w = {
    what: "Converts text between different capitalization styles — uppercase, lowercase, Title Case, Sentence case, and others — without retyping anything by hand. Useful for fixing text that was pasted in from somewhere with inconsistent capitalization, or matching a specific style requirement for a heading, title, or form field.",
    how: 'Paste your text, select the case style you want, and copy or download the converted result. Each button converts the text you typed, not the previous result, so you can try several styles in a row; "Restore original" brings your text back.',
    tip: `Title Case tools generally lowercase small connecting words (like "a," "the," and "and") automatically — check the result against your specific style guide if you need exact control over which words get capitalized, since different publications and style guides don't always agree on which short words should stay lowercase.`,
  },
  S = new Set([
    "a",
    "an",
    "the",
    "and",
    "but",
    "or",
    "for",
    "nor",
    "on",
    "at",
    "to",
    "by",
    "in",
    "of",
    "up",
    "as",
  ]),
  C = new RegExp("[\\p{L}\\p{N}]+(?:['’][\\p{L}\\p{N}]+)*", "gu"),
  x = new RegExp("\\p{Ll}", "u"),
  L = new RegExp("\\p{Lu}", "u"),
  y = new RegExp("\\p{Ll}[\\p{L}'’]*\\p{Lu}", "u"),
  b = new RegExp("\\p{L}", "u"),
  _ = new RegExp("^([OD])(['’])(\\p{L})", "u"),
  O = new RegExp("^Mc(\\p{L})", "u");
function I(e) {
  const [r, ...t] = Array.from(e),
    n = r.toLocaleUpperCase();
  let o = (n.length > 1 ? n[0] + n.slice(1).toLowerCase() : n) + t.join("");
  return (
    (o = o.replace(_, (a, s, c, l) => s + c + l.toLocaleUpperCase())),
    (o = o.replace(O, (a, s) => "Mc" + s.toLocaleUpperCase())),
    o
  );
}
function k(e, r, t) {
  const n = Array.from(e).filter((a) => b.test(a));
  if (
    t &&
    n.length >= 2 &&
    (n.every(
      (s) => s === s.toLocaleUpperCase() && s !== s.toLocaleLowerCase(),
    ) ||
      y.test(e))
  )
    return e;
  const o = e.toLocaleLowerCase();
  return !r && S.has(o) ? o : I(o);
}
function M(e) {
  const r = x.test(e) && L.test(e);
  return e
    .split(
      `
`,
    )
    .map((t) => {
      const n = Array.from(t.matchAll(C));
      if (n.length === 0) return t;
      let o = "",
        a = 0;
      return (
        n.forEach((s, c) => {
          const l = s.index ?? 0;
          ((o += t.slice(a, l) + k(s[0], c === 0 || c === n.length - 1, r)),
            (a = l + s[0].length));
        }),
        o + t.slice(a)
      );
    }).join(`
`);
}
function z(e, r) {
  if (!r) return !1;
  const t = Array.from(e).filter((o) => b.test(o));
  return t.length < 2
    ? !1
    : t.every(
        (o) => o === o.toLocaleUpperCase() && o !== o.toLocaleLowerCase(),
      ) || y.test(e);
}
function P(e) {
  const r = x.test(e) && L.test(e);
  let t = "",
    n = 0,
    o = !0;
  for (const a of Array.from(e.matchAll(C))) {
    const s = a.index ?? 0,
      c = e.slice(n, s);
    ((t += c), /[.!?]["'\u201d\u2019)\]]*\s|\n/.test(c) && (o = !0));
    const l = a[0],
      u = l.toLocaleLowerCase();
    let f;
    (u === "i"
      ? (f = "I")
      : /^i['\u2019](?:m|ll|ve|d)$/.test(u)
        ? (f = "I" + u.slice(1))
        : z(l, r)
          ? (f = l)
          : (f = o ? B(u) : u),
      (t += f),
      (o = !1),
      (n = s + l.length));
  }
  return t + e.slice(n);
}
function B(e) {
  const [r, ...t] = Array.from(e),
    n = r.toLocaleUpperCase();
  return (n.length > 1 ? n[0] + n.slice(1).toLowerCase() : n) + t.join("");
}
function W(e) {
  return Array.from(
    new Intl.Segmenter(void 0, { granularity: "grapheme" }).segment(e),
    (t) => t.segment,
  )
    .map((t, n) => {
      const o = n % 2 === 0 ? t.toLowerCase() : t.toUpperCase();
      return o.length === t.length ? o : t;
    })
    .join("");
}
const $ = new RegExp("([\\p{Ll}\\p{N}])(\\p{Lu})", "gu"),
  D = new RegExp("(\\p{Lu})(\\p{Lu}\\p{Ll})", "gu");
function m(e) {
  return (
    e
      .replace(/['\u2019]/g, "")
      .replace(/\u0130/g, "I")
      .replace(/i\u0307/g, "i")
      .match(new RegExp("[\\p{L}\\p{N}\\p{M}]+", "gu"))
      ?.flatMap((r) =>
        r
          .replace($, "$1 $2")
          .replace(D, "$1 $2")
          .split(" ")
          .map((t) => t.toLocaleLowerCase()),
      ) ?? []
  );
}
const E = (e) => e[0].toLocaleUpperCase() + e.slice(1),
  F = (e) => m(e).join("_"),
  H = (e) => m(e).join("-"),
  K = (e) => m(e).map(E).join(""),
  q = (e) => m(e).join("_").toLocaleUpperCase();
function X(e) {
  const r = m(e);
  return r.length === 0 ? "" : r[0] + r.slice(1).map(E).join("");
}
function Y(e, r) {
  return e ?? r;
}
function Ee() {
  const [e, r] = g.useState(""),
    [t, n] = g.useState(null),
    { logUsageNow: o } = A(),
    a = g.useRef(e);
  a.current = e;
  const s = g.useRef(t);
  s.current = t;
  const c = [
      { label: "UPPERCASE", fn: (i) => i.toUpperCase() },
      { label: "lowercase", fn: (i) => i.toLowerCase() },
      { label: "Title Case", fn: M },
      { label: "Sentence case", fn: P },
      { label: "aLtErNaTiNg", fn: W },
      { label: "camelCase", fn: X },
      { label: "PascalCase", fn: K },
      { label: "snake_case", fn: F },
      { label: "kebab-case", fn: H },
      { label: "CONSTANT_CASE", fn: q },
    ],
    l = () => {
      N(e, "Copied!");
    },
    u = async (i) => {
      if (!(await o())) return;
      const d = Y(s.current, a.current);
      ((s.current = d), n(d), r(i(d)));
    },
    f = () =>
      v(
        new Blob([e], { type: "text/plain;charset=utf-8" }),
        "converted-text.txt",
        { free: !0 },
      ),
    R = () => {
      t !== null && (r(t), n(null));
    };
  return p.jsxs(T, {
    children: [
      p.jsx(U, {
        placeholder: "Type or paste your text here...",
        value: e,
        onChange: (i) => {
          (r(i.target.value), n(null));
        },
        className: "min-h-[150px] text-base",
      }),
      p.jsxs("div", {
        className: "flex flex-wrap gap-2 mt-4",
        children: [
          c.map((i) =>
            p.jsx(
              h,
              {
                variant: "outline",
                size: "sm",
                onClick: () => u(i.fn),
                children: i.label,
              },
              i.label,
            ),
          ),
          p.jsx(h, { size: "sm", onClick: l, disabled: !e, children: "Copy" }),
          p.jsx(h, {
            size: "sm",
            variant: "outline",
            onClick: f,
            disabled: !e,
            children: "Download .txt",
          }),
          t !== null &&
            p.jsx(h, {
              size: "sm",
              variant: "ghost",
              onClick: R,
              children: "Restore original",
            }),
        ],
      }),
      p.jsx(j, { whatIsIt: w.what, howToUse: w.how, tip: w.tip }),
    ],
  });
}
export {
  X as camelCase,
  m as caseWords,
  q as constantCase,
  Y as conversionSource,
  Ee as default,
  H as kebabCase,
  K as pascalCase,
  P as sentenceCase,
  F as snakeCase,
  M as titleCase,
};
//# sourceMappingURL=CaseConverter-CbuegihP.js.map
