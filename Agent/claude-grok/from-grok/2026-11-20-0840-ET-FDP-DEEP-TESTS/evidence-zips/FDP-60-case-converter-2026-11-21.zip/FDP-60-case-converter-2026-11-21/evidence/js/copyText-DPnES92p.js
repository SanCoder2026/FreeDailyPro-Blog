import{f as e}from"./index-B1CTyGtY.js";const a="Daily limit reached";function c(t){return t instanceof Error&&t.message===a}async function n(t,r){try{await navigator.clipboard.writeText(t)}catch(o){return c(o)||e.error("Couldn't copy. Select the text and copy it by hand."),!1}return r&&e.success(r),!0}export{a as C,n as c};
//# sourceMappingURL=copyText-DPnES92p.js.map
