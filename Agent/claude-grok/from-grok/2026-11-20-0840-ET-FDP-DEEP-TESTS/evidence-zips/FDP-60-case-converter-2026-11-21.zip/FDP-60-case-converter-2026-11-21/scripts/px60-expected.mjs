// FDP-60: recompute expected output from the site's own conversion code (copied from CaseConverter-CbuegihP.js) and compare with live cases.json
import fs from 'fs';
const S = new Set([
    "a",
    "an",
    "the",
    "and",
    "but",
    "or",
    "for",
    "nor",
    "on",
    "at",
    "to",
    "by",
    "in",
    "of",
    "up",
    "as",
  ]),
  C = new RegExp("[\\p{L}\\p{N}]+(?:['’][\\p{L}\\p{N}]+)*", "gu"),
  x = new RegExp("\\p{Ll}", "u"),
  L = new RegExp("\\p{Lu}", "u"),
  y = new RegExp("\\p{Ll}[\\p{L}'’]*\\p{Lu}", "u"),
  b = new RegExp("\\p{L}", "u"),
  _ = new RegExp("^([OD])(['’])(\\p{L})", "u"),
  O = new RegExp("^Mc(\\p{L})", "u");
function I(e) {
  const [r, ...t] = Array.from(e),
    n = r.toLocaleUpperCase();
  let o = (n.length > 1 ? n[0] + n.slice(1).toLowerCase() : n) + t.join("");
  return (
    (o = o.replace(_, (a, s, c, l) => s + c + l.toLocaleUpperCase())),
    (o = o.replace(O, (a, s) => "Mc" + s.toLocaleUpperCase())),
    o
  );
}
function k(e, r, t) {
  const n = Array.from(e).filter((a) => b.test(a));
  if (
    t &&
    n.length >= 2 &&
    (n.every(
      (s) => s === s.toLocaleUpperCase() && s !== s.toLocaleLowerCase(),
    ) ||
      y.test(e))
  )
    return e;
  const o = e.toLocaleLowerCase();
  return !r && S.has(o) ? o : I(o);
}
function M(e) {
  const r = x.test(e) && L.test(e);
  return e
    .split(
      `
`,
    )
    .map((t) => {
      const n = Array.from(t.matchAll(C));
      if (n.length === 0) return t;
      let o = "",
        a = 0;
      return (
        n.forEach((s, c) => {
          const l = s.index ?? 0;
          ((o += t.slice(a, l) + k(s[0], c === 0 || c === n.length - 1, r)),
            (a = l + s[0].length));
        }),
        o + t.slice(a)
      );
    }).join(`
`);
}
function z(e, r) {
  if (!r) return !1;
  const t = Array.from(e).filter((o) => b.test(o));
  return t.length < 2
    ? !1
    : t.every(
        (o) => o === o.toLocaleUpperCase() && o !== o.toLocaleLowerCase(),
      ) || y.test(e);
}
function P(e) {
  const r = x.test(e) && L.test(e);
  let t = "",
    n = 0,
    o = !0;
  for (const a of Array.from(e.matchAll(C))) {
    const s = a.index ?? 0,
      c = e.slice(n, s);
    ((t += c), /[.!?]["'\u201d\u2019)\]]*\s|\n/.test(c) && (o = !0));
    const l = a[0],
      u = l.toLocaleLowerCase();
    let f;
    (u === "i"
      ? (f = "I")
      : /^i['\u2019](?:m|ll|ve|d)$/.test(u)
        ? (f = "I" + u.slice(1))
        : z(l, r)
          ? (f = l)
          : (f = o ? B(u) : u),
      (t += f),
      (o = !1),
      (n = s + l.length));
  }
  return t + e.slice(n);
}
function B(e) {
  const [r, ...t] = Array.from(e),
    n = r.toLocaleUpperCase();
  return (n.length > 1 ? n[0] + n.slice(1).toLowerCase() : n) + t.join("");
}
function W(e) {
  return Array.from(
    new Intl.Segmenter(void 0, { granularity: "grapheme" }).segment(e),
    (t) => t.segment,
  )
    .map((t, n) => {
      const o = n % 2 === 0 ? t.toLowerCase() : t.toUpperCase();
      return o.length === t.length ? o : t;
    })
    .join("");
}
const $ = new RegExp("([\\p{Ll}\\p{N}])(\\p{Lu})", "gu"),
  D = new RegExp("(\\p{Lu})(\\p{Lu}\\p{Ll})", "gu");
function m(e) {
  return (
    e
      .replace(/['\u2019]/g, "")
      .replace(/\u0130/g, "I")
      .replace(/i\u0307/g, "i")
      .match(new RegExp("[\\p{L}\\p{N}\\p{M}]+", "gu"))
      ?.flatMap((r) =>
        r
          .replace($, "$1 $2")
          .replace(D, "$1 $2")
          .split(" ")
          .map((t) => t.toLocaleLowerCase()),
      ) ?? []
  );
}
const E = (e) => e[0].toLocaleUpperCase() + e.slice(1),
  F = (e) => m(e).join("_"),
  H = (e) => m(e).join("-"),
  K = (e) => m(e).map(E).join(""),
  q = (e) => m(e).join("_").toLocaleUpperCase();
function X(e) {
  const r = m(e);
  return r.length === 0 ? "" : r[0] + r.slice(1).map(E).join("");
}
function Y(e, r) {
  return e ?? r;
}

const F2={'UPPERCASE':s=>s.toUpperCase(),'lowercase':s=>s.toLowerCase(),'Title Case':M,'Sentence case':P,'aLtErNaTiNg':W,'camelCase':X,'PascalCase':K,'snake_case':F,'kebab-case':H,'CONSTANT_CASE':q};
const R=JSON.parse(fs.readFileSync('/workspace/deep/60-case-converter/live/'+(process.argv[2]||'cases.json')));
const out={};
for (const [id,v] of Object.entries(R.cases)) { if(!v.input) continue; const exp=F2[v.label](v.input); out[id]={match:exp===v.value,input:v.input,label:v.label,live:v.value,expected:exp}; console.log(id,out[id].match,JSON.stringify(v.value)); }
fs.writeFileSync('/workspace/deep/60-case-converter/live/expected-compare.json',JSON.stringify(out,null,1));
