// FDP-60 Case Converter, guest. Usage: node px60-live.js <probe|left|cases> [engine]  (TRIES = fresh contexts to try for uses left; ANY=1 first context; SUF suffix)
// probe: as-is context -> strip/Quick Buy, convert at cap (cap dialog?), Copy, Download .txt.
// left: uses left -> L00 click on empty box, L01 convert, L02 other style, L03 new text same load, copy, download, restore, reload, L04.
// cases: uses left (or ANY) -> inputs from testfiles/cases.json in ONE load; textarea value saved for px60-expected.mjs.
// Never signs in, never types email/card, never clicks pass "Continue" or ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/60-case-converter/'; const OUT = BASE + 'live/'; const URL = 'https://www.freedailypro.com/tool/case-converter';
const mode = process.argv[2] || 'probe'; const eng = process.argv[3] || 'chromium'; const sfx = (eng === 'chromium' ? '' : '-' + eng) + (process.env.SUF || '');
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').replace(/dev[:%][^&"]*/g, 'dev:REDACTED').slice(0, 160);
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p, net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 900 }, locale: 'en-US', acceptDownloads: true }); if (eng === 'chromium') await c.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://www.freedailypro.com' }); p = await c.newPage(); p.setDefaultTimeout(10000); net = [];
  await p.addInitScript(() => { window.__t = []; window.__clip = []; const seen = new WeakSet(); setInterval(() => { document.querySelectorAll('[data-sonner-toast]').forEach(n => { if (!seen.has(n)) { seen.add(n); window.__t.push((n.innerText || '').trim()); } }); }, 120);
   try { const w = navigator.clipboard.writeText.bind(navigator.clipboard); navigator.clipboard.writeText = async s => { window.__clip.push(s); return w(s).catch(() => { }); }; } catch (e) { } });
  p.on('request', r => { const u = r.url(); if (r.method() === 'POST' && /freedailypro\.com\/api/.test(u) && !/insight\.hit|funnel\.hit/.test(u)) net.push({ t: now(), u: red(u), len: (r.postData() || '').length }); });
  await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 450) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(250); } };
 const toasts = n => p.evaluate(n => (window.__t || []).slice(n), n); const tc = () => p.evaluate(() => (window.__t || []).length);
 const ta = () => p.locator('main textarea').first();
 const strip = () => p.evaluate(() => { const t = document.querySelector('main').innerText; return { trial: (t.match(/Trial[^\n]*/) || [null])[0], quickBuy: (t.match(/Quick Buy/g) || []).length, restore: /Restore original/.test(t) }; });
 const conv = async (label, id) => { const n = await tc(); const before = await used(); const nposts = net.length; await p.locator('main button', { hasText: new RegExp('^' + label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '$') }).first().click(); await p.waitForTimeout(1200); const d = await dialog(); const r = { label, before, after: await used(), dialog: d, toasts: await toasts(n), posts: net.slice(nposts).map(x => x.t + ' ' + x.u.slice(0, 70)), value: await ta().inputValue(), ...(await strip()) }; if (id) await p.screenshot({ path: OUT + 'cases/' + id + sfx + '.png' }); if (d) { await p.screenshot({ path: OUT + 'cases/' + (id || label) + sfx + '-dialog.png' }); await esc(); } return r; };
 const copy = async () => { const n = await tc(); const before = await used(); await p.locator('main button', { hasText: /^Copy$/ }).click(); await p.waitForTimeout(1200); return { before, after: await used(), dialog: await dialog(), toasts: await toasts(n), clip: await p.evaluate(() => window.__clip.slice(-1)[0] ?? null) }; };
 const dl = async id => { const before = await used(); const dp = p.waitForEvent('download', { timeout: 10000 }).catch(() => null); await p.locator('main button', { hasText: 'Download .txt' }).click(); const d = await dp; await p.waitForTimeout(1000); const r = { before, after: await used(), dialog: await dialog() }; if (d) { const f = OUT + 'downloads/' + id + sfx + '-' + d.suggestedFilename(); await d.saveAs(f); r.file = { name: d.suggestedFilename(), bytes: fs.statSync(f).size, text: fs.readFileSync(f, 'utf8').slice(0, 200) }; } if (r.dialog) await esc(); return r; };
 const C = async (id, fn) => { try { R.cases[id] = await fn(); } catch (e) { R.cases[id] = { err: e.message.split('\n')[0].slice(0, 200) }; } console.log(id, JSON.stringify(R.cases[id]).slice(0, 400)); };
 const findLeft = async () => { if (process.env.ANY) { await open(); R.tries.push(await used()); R.anyContext = true; return true; } const TRIES = +(process.env.TRIES || 10); for (let i = 0; i < TRIES; i++) { await open(); const u = await used(); R.tries.push(u); const [a, l] = u.split('/').map(Number); if (a < l) return true; await c.close(); } return false; };
 if (mode === 'probe') { await open(); R.start = { used: await used(), ...(await strip()), copyDisabledEmpty: await p.locator('main button', { hasText: /^Copy$/ }).isDisabled() };
  await ta().fill('visit NYC with your iPhone'); await C('P01-convert-at-cap', () => conv('Title Case', 'P01')); await C('P02-copy-at-cap', () => copy()); await C('P03-download-at-cap', () => dl('P03'));
  R.net = net;
 } else if (mode === 'left') { if (await findLeft()) { const L = R.left = { start: await used(), ...(await strip()) };
   await C('L00-empty-click', () => conv('UPPERCASE', 'L00'));
   await ta().fill('the lord of the rings by j.r.r. tolkien'); await C('L01-title', () => conv('Title Case', 'L01'));
   await C('L02-snake-same-load', () => conv('snake_case', 'L02'));
   await C('L02b-restore', async () => { await p.locator('main button', { hasText: 'Restore original' }).click(); await p.waitForTimeout(500); return { value: await ta().inputValue(), ...(await strip()) }; });
   await ta().fill('a brand new text in the same load'); await C('L03-upper-new-text', () => conv('UPPERCASE', 'L03'));
   await C('L03-copy', () => copy()); await C('L03-download', () => dl('L03'));
   await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); L.afterReload = await used(); L.valueAfterReload = await ta().inputValue();
   await ta().fill('after reload'); await C('L04-pascal-after-reload', () => conv('PascalCase', 'L04')); await C('L05-camel-same-load', () => conv('camelCase'));
   L.end = await used(); L.net = net; } }
 else { if (await findLeft()) { R.start = await used(); const plan = JSON.parse(fs.readFileSync(BASE + 'testfiles/cases.json'));
   for (const [id, text, label] of plan) await C(id, async () => { await ta().fill(text); const r = await conv(label); r.input = text; return r; });
   await C('Z-big-200k', async () => { const big = 'the quick brown fox jumps over the lazy dog. '.repeat(4500); await ta().fill(big); const t0 = Date.now(); const r = await conv('Title Case'); return { ms: Date.now() - t0, len: r.value.length, head: r.value.slice(0, 90), before: r.before, after: r.after }; });
   R.end = await used(); R.net = net; } }
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', JSON.stringify(R.tries), JSON.stringify(R.start || '').slice(0, 300)); await b.close(); })();
