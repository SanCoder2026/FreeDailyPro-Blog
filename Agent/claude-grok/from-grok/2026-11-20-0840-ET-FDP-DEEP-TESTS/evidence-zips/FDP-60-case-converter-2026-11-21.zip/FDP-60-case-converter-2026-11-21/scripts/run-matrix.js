#!/usr/bin/env node
/*
 FreeDailyPro device / platform / locale / a11y matrix runner (Playwright, Node).
 Usage:  node run-matrix.js <config.json> [--only=devices,locales,geo,a11y] [--devices="iPhone SE,Pixel 7"]
 Safety: only loads pages, types into inputs and reads values. Never clicks ads, buy/pass/checkout,
 copy or download buttons. Every fresh context may count against guest trial uses, so keep functional
 steps to typing only (typing does not spend a trial use on tools that charge on export).
 Env:  WebKit on this box needs GIO_EXTRA_MODULES pointing at a dir with libgiognutls.so (see README).
*/
const fs = require('fs'), path = require('path');
const pw = require('playwright');
const cfgPath = process.argv[2];
if (!cfgPath) { console.error('usage: node run-matrix.js config.json [--only=devices,locales,geo,a11y]'); process.exit(1); }
const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
const only = (process.argv.find(a => a.startsWith('--only=')) || '').replace('--only=', '').split(',').filter(Boolean);
const want = s => !only.length || only.includes(s);
const devFilter = (process.argv.find(a => a.startsWith('--devices=')) || '').replace('--devices=', '').split(',').filter(Boolean);
const OUT = cfg.outDir; fs.mkdirSync(OUT, { recursive: true });
const AXE = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8');
if (!process.env.GIO_EXTRA_MODULES && fs.existsSync(path.join(__dirname, 'giomods'))) process.env.GIO_EXTRA_MODULES = path.join(__dirname, 'giomods');
const D = pw.devices;
const DEVICES = cfg.devices || [
  { name: 'iPhone SE', engine: 'webkit', dev: 'iPhone SE' },
  { name: 'iPhone 14 Pro Max', engine: 'webkit', dev: 'iPhone 14 Pro Max' },
  { name: 'Pixel 7', engine: 'chromium', dev: 'Pixel 7' },
  { name: 'Galaxy S9+', engine: 'chromium', dev: 'Galaxy S9+' },
  { name: 'iPad Mini', engine: 'webkit', dev: 'iPad Mini' },
  { name: 'iPad Pro 11 landscape', engine: 'webkit', dev: 'iPad Pro 11 landscape' },
  { name: 'Desktop 1366x768 Chromium', engine: 'chromium', vp: [1366, 768] },
  { name: 'Desktop 1920x1080 Chromium', engine: 'chromium', vp: [1920, 1080] },
  { name: 'Desktop 1440x900 Firefox', engine: 'firefox', vp: [1440, 900] },
  { name: 'Desktop 1440x900 WebKit', engine: 'webkit', vp: [1440, 900] },
];
const slug = s => s.replace(/[^a-z0-9]+/gi, '-').replace(/^-|-$/g, '').toLowerCase();
const browsers = {};
async function browser(engine) { if (!browsers[engine]) browsers[engine] = await pw[engine].launch(); return browsers[engine]; }
function ctxOpts(d, extra = {}) {
  let o = d.dev ? { ...D[d.dev] } : { viewport: { width: d.vp[0], height: d.vp[1] }, deviceScaleFactor: 1 };
  if (d.engine === 'firefox') delete o.isMobile; // firefox does not support isMobile
  return { ...o, ...extra };
}
const INIT = () => {
  window.__cls = 0; window.__shifts = [];
  try { if (!(PerformanceObserver.supportedEntryTypes || []).includes('layout-shift')) throw new Error('no layout-shift'); new PerformanceObserver(l => { for (const e of l.getEntries()) if (!e.hadRecentInput) { window.__cls += e.value; window.__shifts.push({ v: +e.value.toFixed(4), t: Math.round(e.startTime), src: (e.sources || []).map(s => s.node ? (s.node.className || s.node.nodeName || '').toString().slice(0, 50) : '').slice(0, 3) }); } }).observe({ type: 'layout-shift', buffered: true }); window.__clsSupported = true; } catch (e) { window.__clsSupported = false; }
};
// In-page measurement. cfg.key: aria labels / selectors of the main controls.
function measure(args) {
  const { keySel, resultSel, trialRe, adSel, mainSel } = args;
  const vw = innerWidth, vh = innerHeight;
  const R = e => { const r = e.getBoundingClientRect(); return { x: Math.round(r.x), y: Math.round(r.y + scrollY), w: Math.round(r.width), h: Math.round(r.height) }; };
  const vis = e => { const r = e.getBoundingClientRect(); const s = getComputedStyle(e); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const inter = (a, b) => a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
  const main = document.querySelector(mainSel) || document.body;
  const keys = [...document.querySelectorAll(keySel)].filter(vis);
  const res = [...document.querySelectorAll(resultSel)].filter(vis);
  const interactive = [...main.querySelectorAll('input:not([type=hidden]),button,select,textarea,[role=tab],[role=button],a[href]')].filter(vis)
    .filter(e => !e.closest('nav,header,footer,.ad-container,ins'));
  const label = e => (e.getAttribute('aria-label') || e.innerText || e.value || e.placeholder || e.name || e.tagName).toString().trim().replace(/\s+/g, ' ').slice(0, 40);
  const small = interactive.map(e => ({ el: e.tagName.toLowerCase() + (e.type ? '[' + e.type + ']' : ''), label: label(e), ...R(e) }))
    .filter(r => (r.w < 44 || r.h < 44) && !(r.el === 'a' && r.h >= 16 && r.w > 60)); // inline text links reported separately
  const smallLinks = interactive.filter(e => e.tagName === 'A').map(e => ({ label: label(e), ...R(e) })).filter(r => r.h < 24);
  const inputs = keys.filter(e => /INPUT|SELECT|TEXTAREA/.test(e.tagName)).map(e => ({ label: label(e), fontSize: parseFloat(getComputedStyle(e).fontSize), ...R(e) }));
  let trialEl = null;
  for (const e of document.querySelectorAll('body *')) { if (e.children.length <= 4 && vis(e) && new RegExp(trialRe, 'i').test(e.textContent) && e.textContent.length < 300) { trialEl = e; break; } }
  const above = r => r && r.y < vh && r.y + r.h > 0;
  const firstKey = keys[0] ? R(keys[0]) : null, firstRes = res[0] ? R(res[0]) : null, trialR = trialEl ? R(trialEl) : null;
  const ads = [...document.querySelectorAll(adSel)].filter(vis).map(e => ({ tag: e.tagName.toLowerCase(), cls: (e.className + '').slice(0, 40), id: e.id, pos: getComputedStyle(e).position, anchor: e.getAttribute('data-anchor-status') || e.closest('[data-anchor-status]')?.getAttribute('data-anchor-status') || '', ...R(e) }));
  const keyR = [...keys, ...res].map(e => ({ label: label(e), ...R(e) }));
  const overlaps = [];
  for (const a of ads) for (const k of keyR) if (inter(a, k)) overlaps.push({ ad: a.tag + '.' + a.cls + '#' + a.id, key: k.label, ad_box: [a.x, a.y, a.w, a.h], key_box: [k.x, k.y, k.w, k.h] });
  const fixed = [...document.querySelectorAll('body *')].filter(e => { const p = getComputedStyle(e).position; return (p === 'fixed' || p === 'sticky') && vis(e); })
    .map(e => { const r = e.getBoundingClientRect(); return { tag: e.tagName.toLowerCase(), cls: (e.className + '').slice(0, 50), pos: getComputedStyle(e).position, text: (e.innerText || '').trim().replace(/\s+/g, ' ').slice(0, 60), vx: Math.round(r.x), vy: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) }; })
    .filter(f => f.w * f.h > 0 && !fixedParent(f));
  function fixedParent() { return false; }
  // coverage of viewport by fixed elements (not counting full-width top header < 80px)
  const coverBottom = fixed.filter(f => f.pos === 'fixed' && f.vy + f.h >= vh - 2 && f.vy > vh / 2).reduce((m, f) => Math.max(m, vh - f.vy), 0);
  const coverTop = fixed.filter(f => f.vy <= 0 + 2 && f.h < vh / 2).reduce((m, f) => Math.max(m, f.h), 0);
  return {
    vw, vh, scrollWidth: document.documentElement.scrollWidth, bodyScrollWidth: document.body.scrollWidth,
    overflowX: document.documentElement.scrollWidth > vw,
    overflowCulprits: document.documentElement.scrollWidth > vw ? [...document.querySelectorAll('body *')].filter(e => { const r = e.getBoundingClientRect(); return r.right > vw + 1 && vis(e); }).slice(0, 8).map(e => e.tagName.toLowerCase() + '.' + (e.className + '').slice(0, 50) + ' right=' + Math.round(e.getBoundingClientRect().right)) : [],
    docHeight: document.documentElement.scrollHeight,
    inputs, smallTargets: small, smallLinks,
    aboveFold: { trial: above(trialR), trialText: trialEl ? trialEl.textContent.trim().replace(/\s+/g, ' ').slice(0, 160) : null, trialBox: trialR, input: above(firstKey), inputBox: firstKey, result: above(firstRes), resultBox: firstRes },
    ads, overlaps, fixed, coverTop, coverBottom,
    cls: window.__clsSupported ? +window.__cls.toFixed(4) : null, shifts: (window.__shifts || []).slice(0, 10),
    lang: document.documentElement.lang, dir: document.documentElement.dir || getComputedStyle(document.documentElement).direction,
  };
}
async function hydrate(page) {
  await page.waitForLoadState('domcontentloaded');
  await page.waitForLoadState('networkidle', { timeout: 20000 }).catch(() => {});
  await page.waitForTimeout(cfg.settleMs || 3000);
}
async function runFunctional(page) {
  const out = [];
  for (const st of cfg.functional || []) {
    try {
      const inp = page.locator(st.fill).first();
      await inp.scrollIntoViewIfNeeded();
      await inp.click({ trial: false });
      await inp.fill('');
      await inp.pressSequentially(String(st.value), { delay: 30 });
      await page.waitForTimeout(st.waitMs || 800);
      const got = st.expectValueOf ? await page.locator(st.expectValueOf).first().inputValue() : await page.locator(st.expectTextIn).first().innerText();
      const ok = st.match === 'includes' ? got.includes(st.expect) : st.match === 'digits' ? got.replace(/\D/g, '') === st.expect : got.trim() === st.expect;
      out.push({ step: st.name, typed: st.value, expect: st.expect, got: got.trim().slice(0, 120), pass: ok });
    } catch (e) { out.push({ step: st.name, error: e.message.split('\n')[0], pass: false }); }
  }
  return out;
}
async function axe(page) {
  await page.addScriptTag({ content: AXE });
  const r = await page.evaluate(async () => { const r = await axe.run(document, { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'best-practice'] }, resultTypes: ['violations'] }); return r.violations.map(v => ({ id: v.id, impact: v.impact, count: v.nodes.length, help: v.help, sample: v.nodes.slice(0, 3).map(n => n.target.join(' ')) })); });
  return r;
}
const MARGS = () => ({ keySel: cfg.keySelectors, resultSel: cfg.resultSelectors, trialRe: cfg.trialRegex || 'uses/day|remaining today', adSel: cfg.adSelectors || 'ins.adsbygoogle,.ad-container,iframe[id^=aswift],iframe[id^=google_ads]', mainSel: cfg.mainSelector || 'main' });

async function deviceRun(d, opts = {}) {
  const b = await browser(d.engine);
  const ctx = await b.newContext(ctxOpts(d, opts.ctx || {}));
  await ctx.addInitScript(INIT);
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text().slice(0, 200)); });
  page.on('pageerror', e => errors.push('pageerror: ' + e.message.slice(0, 200)));
  const t0 = Date.now();
  let status = null, finalUrl = null;
  try { const resp = await page.goto(opts.url || cfg.url, { waitUntil: 'domcontentloaded', timeout: 60000 }); status = resp && resp.status(); } catch (e) { errors.push('goto: ' + e.message.split('\n')[0]); }
  await hydrate(page); finalUrl = page.url();
  const tag = slug((opts.prefix || '') + d.name);
  const dir = opts.dir || path.join(OUT, 'devices');
  fs.mkdirSync(dir, { recursive: true });
  const shots = { fold: path.join(dir, tag + '-fold.png'), full: path.join(dir, tag + '-full.png') };
  await page.screenshot({ path: shots.fold });
  const m = await page.evaluate(measure, MARGS());
  let functional = [];
  if (!opts.noFunctional) functional = await runFunctional(page);
  await page.evaluate(() => scrollTo(0, 0));
  await page.waitForTimeout(500);
  await page.screenshot({ path: shots.full, fullPage: true }).catch(e => errors.push('fullshot: ' + e.message.split('\n')[0]));
  const m2 = await page.evaluate(measure, MARGS()); // after interaction: CLS total + any new ad overlaps
  let extra = {};
  if (opts.extract) extra = await page.evaluate(opts.extract, opts.extractArgs || {});
  let a11y = null; if (opts.axe) a11y = await axe(page);
  const ua = await page.evaluate(() => navigator.userAgent);
  await ctx.close();
  return { device: d.name, engine: d.engine, ua, status, finalUrl, ms: Date.now() - t0, m, clsAfter: m2.cls, overlapsAfter: m2.overlaps, adsAfter: m2.ads, functional, errors: [...new Set(errors)], shots, extra, a11y };
}
// Locale extraction (runs in page)
function localeExtract(args) {
  const t = s => (s || '').trim().replace(/\s+/g, ' ');
  const main = document.querySelector('main') || document.body;
  const txt = t(main.innerText);
  const freeRe = /\b(free|gratis|gratuit|gratuite|kostenlos|grátis|gratuito|gratuita|cuma-cuma)\b|無料|免费|免費|무료|मुफ़्त|मुफ्त/gi;
  const frees = [...txt.matchAll(freeRe)].map(m => txt.slice(Math.max(0, m.index - 40), m.index + 40));
  const enWords = (txt.match(/\b(the|and|you|your|with|this|from|number|numeral|date|copy|table|how|what|year)\b/gi) || []).length;
  const words = (txt.match(/\S+/g) || []).length;
  const labels = [...main.querySelectorAll('button,label,[role=tab],summary,h2,h3,option')].filter(e => e.getBoundingClientRect().width > 0 || e.tagName === 'OPTION').map(e => t(e.innerText || e.getAttribute('aria-label'))).filter(Boolean).slice(0, 60);
  const englishLabels = labels.filter(l => /^[\x20-\x7E·—–]+$/.test(l) && /[a-z]{3,}/i.test(l) && /\b(the|and|copy|table|download|print|clear|date|number|numeral|year|order|separator|how|about|common|questions|share|guides|years|day|month)\b/i.test(l));
  const prices = [...new Set((document.body.innerText.match(/(?:[$€£₹¥₩]|R\$|Rp)\s?\d[\d.,]*|\d[\d.,]*\s?(?:€|USD|EUR|INR)/g) || []))].slice(0, 10);
  const ph = [...document.querySelectorAll('input')].map(i => i.placeholder).filter(Boolean);
  const radios = [...document.querySelectorAll('input[type=radio]')].map(r => ({ label: t(r.closest('label')?.innerText || r.parentElement?.innerText), checked: r.checked }));
  const dayV = document.querySelector('input[aria-label=Day]')?.value, monV = document.querySelector('input[aria-label=Month]')?.value;
  const dateInputsOrder = [...document.querySelectorAll('input')].filter(i => /day|month|year|tag|mes|mois|jour|dia|día|año|ano|jahr|monat|日|月|年|일|월|년|दिन|माह|महीना|वर्ष|hari|bulan|tahun/i.test(i.getAttribute('aria-label') || '')).map(i => i.getAttribute('aria-label'));
  const dateResult = t([...document.querySelectorAll('input,output,div,span')].map(e => e.value || (e.children.length === 0 ? e.textContent : '')).find(v => /^[IVXLCDM]+[.·/\- ][IVXLCDM]+[.·/\- ][IVXLCDM]+$/.test((v || '').trim())) || '');
  const consent = !!document.querySelector('.fc-consent-root,#qc-cmp2-container,[id*=cookie i][role=dialog],[class*=consent i],iframe[src*="fundingchoices"],[aria-label*=consent i]');
  const consentText = t([...document.querySelectorAll('.fc-consent-root,[class*=consent i],[role=dialog]')].map(e => e.innerText).join(' | ')).slice(0, 200);
  const faqQ = [...document.querySelectorAll('summary,[data-faq] h3,details > summary, button[aria-expanded]')].map(e => t(e.innerText)).filter(s => s.length > 10).slice(0, 4);
  return {
    htmlLang: document.documentElement.lang, dir: document.documentElement.getAttribute('dir') || getComputedStyle(document.documentElement).direction,
    title: document.title, h1: t(document.querySelector('h1')?.innerText), meta: document.querySelector('meta[name=description]')?.content || '',
    canonical: document.querySelector('link[rel=canonical]')?.href || '', hreflangs: [...document.querySelectorAll('link[rel=alternate][hreflang]')].map(l => [l.hreflang, l.href]),
    faqSample: faqQ, labelsSample: labels.slice(0, 25), englishLabels: englishLabels.slice(0, 25), englishWordRatio: words ? +(enWords / words).toFixed(3) : 0, words,
    frees: frees.slice(0, 8), prices, placeholders: ph, radios, dateDefault: { day: dayV, month: monV, inputsOrder: dateInputsOrder }, dateResult, consent, consentText,
    numberSample: (txt.match(/\b\d{1,3}(?:[.,\u00a0 ]\d{3})+\b/g) || []).slice(0, 8),
  };
}
(async () => {
  const stamp = require('child_process').execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
  const result = { started: stamp, url: cfg.url, devices: [], locales: [], geo: [], a11y: [] };
  if (want('devices')) for (const d of DEVICES.filter(x => !devFilter.length || devFilter.includes(x.name))) {
    console.log('device', d.name);
    try { result.devices.push(await deviceRun(d)); } catch (e) { result.devices.push({ device: d.name, engine: d.engine, fatal: e.message.split('\n')[0] }); }
  }
  if (want('locales')) {
    // discover hreflang alternates from server HTML
    const html = await (await fetch(cfg.url)).text();
    const alts = [...html.matchAll(/<link[^>]+hreflang="([^"]+)"[^>]+href="([^"]+)"/g)].map(m => ({ hl: m[1], href: m[2] })).filter(a => a.hl !== 'x-default');
    const extraLocales = (cfg.extraLocaleUrls || []).map(u => ({ hl: 'probe:' + u.split('/')[3], href: u }));
    for (const a of [...alts, ...extraLocales]) {
      for (const d of [{ name: 'Pixel 7', engine: 'chromium', dev: 'Pixel 7' }, { name: 'Desktop 1366x768', engine: 'chromium', vp: [1366, 768] }]) {
        console.log('locale', a.hl, d.name);
        const isMobile = d.dev ? true : false;
        try {
          const r = await deviceRun(d, { url: a.href, prefix: 'locale-' + a.hl.replace(':', '-') + '-', dir: path.join(OUT, 'locales'), noFunctional: true, extract: localeExtract });
          result.locales.push({ hreflang: a.hl, href: a.href, device: d.name, status: r.status, finalUrl: r.finalUrl, errors: r.errors, overflowX: r.m.overflowX, scrollWidth: r.m.scrollWidth, vw: r.m.vw, shots: r.shots, ...(isMobile ? { mobileOnly: true } : r.extra), extraMobile: isMobile ? { englishWordRatio: r.extra.englishWordRatio } : undefined });
        } catch (e) { result.locales.push({ hreflang: a.hl, href: a.href, device: d.name, fatal: e.message.split('\n')[0] }); }
      }
    }
  }
  if (want('geo')) for (const g of cfg.geoContexts || [
    { name: 'en-US America/New_York (baseline)', locale: 'en-US', tz: 'America/New_York', geo: { latitude: 40.71, longitude: -74.0 } },
    { name: 'de-DE Europe/Berlin', locale: 'de-DE', tz: 'Europe/Berlin', geo: { latitude: 52.52, longitude: 13.40 } },
    { name: 'fr-FR Europe/Paris', locale: 'fr-FR', tz: 'Europe/Paris', geo: { latitude: 48.85, longitude: 2.35 } },
    { name: 'hi-IN Asia/Kolkata', locale: 'hi-IN', tz: 'Asia/Kolkata', geo: { latitude: 28.61, longitude: 77.21 } },
    { name: 'ar-SA Asia/Riyadh', locale: 'ar-SA', tz: 'Asia/Riyadh', geo: { latitude: 24.71, longitude: 46.68 } },
    { name: 'ja-JP Asia/Tokyo', locale: 'ja-JP', tz: 'Asia/Tokyo', geo: { latitude: 35.68, longitude: 139.69 } },
  ]) {
    console.log('geo', g.name);
    const d = { name: 'Desktop 1366x768', engine: 'chromium', vp: [1366, 768] };
    try {
      const r = await deviceRun(d, { prefix: 'geo-' + slug(g.name) + '-', dir: path.join(OUT, 'geo'), noFunctional: true, extract: localeExtract, ctx: { locale: g.locale, timezoneId: g.tz, geolocation: g.geo, permissions: ['geolocation'], extraHTTPHeaders: { 'Accept-Language': g.locale + ',' + g.locale.split('-')[0] + ';q=0.9' } } });
      result.geo.push({ ctx: g.name, status: r.status, finalUrl: r.finalUrl, htmlLang: r.extra.htmlLang, prices: r.extra.prices, consent: r.extra.consent, consentText: r.extra.consentText, dateDefault: r.extra.dateDefault, radios: r.extra.radios, dateResult: r.extra.dateResult, numberSample: r.extra.numberSample, title: r.extra.title, trial: r.m.aboveFold.trialText, errors: r.errors, shots: r.shots });
    } catch (e) { result.geo.push({ ctx: g.name, fatal: e.message.split('\n')[0] }); }
  }
  if (want('a11y')) for (const d of [{ name: 'Desktop 1366x768 Chromium', engine: 'chromium', vp: [1366, 768] }, { name: 'Pixel 7', engine: 'chromium', dev: 'Pixel 7' }]) {
    console.log('a11y', d.name);
    try { const r = await deviceRun(d, { prefix: 'a11y-', dir: path.join(OUT, 'a11y'), noFunctional: true, axe: true }); result.a11y.push({ device: d.name, violations: r.a11y }); } catch (e) { result.a11y.push({ device: d.name, fatal: e.message.split('\n')[0] }); }
  }
  for (const b of Object.values(browsers)) await b.close();
  result.finished = require('child_process').execSync('date "+%Y-%m-%d %H:%M:%S %Z"').toString().trim();
  const outFile = path.join(OUT, 'matrix-results' + (only.length ? '-' + only.join('-') : '') + (devFilter.length ? '-' + slug(devFilter.join('-')) : '') + '.json');
  fs.writeFileSync(outFile, JSON.stringify(result, null, 1));
  console.log('wrote', outFile);
})();
