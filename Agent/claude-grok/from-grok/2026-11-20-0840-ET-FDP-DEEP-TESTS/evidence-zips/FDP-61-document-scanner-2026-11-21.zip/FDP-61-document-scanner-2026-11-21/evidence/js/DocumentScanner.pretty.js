const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/operations-B4LtHhm8.js",
      "assets/index-B1CTyGtY.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/index-BJxTAPRn.css",
      "assets/pdfFonts-Ckcqm3Ic.js",
      "assets/index-BRvxULIc.js",
      "assets/index-CnXdQaNG.js",
      "assets/index-DMQTJy3b.js",
      "assets/fontkit.es-DA-3qwB1.js",
      "assets/pdfBookmarks-BjfxtCfb.js",
      "assets/pdfMetadata-CcxIhQF2.js",
      "assets/pageView-BQIwVYOi.js",
      "assets/formAppearance-CdNbuISd.js",
      "assets/drawTextAnywhere-DcuP6lHH.js",
      "assets/ocrText-C_9cxcFa.js",
      "assets/ocrImage-CmXFNUud.js",
      "assets/jszip.min-CT0ZA6V1.js",
      "assets/jszip.min-C-FLQHAz.js",
      "assets/_commonjs-dynamic-modules-TDtrdbi3.js",
      "assets/utils-s8ucLyj8.js",
      "assets/imageRecompress-eXQFDUm-.js",
      "assets/formatFileSize-B-JRDfN5.js",
      "assets/plural-FIChqbp4.js",
      "assets/textDiff-DxE9AzvO.js",
      "assets/utils-1EQcVBdK.js",
      "assets/decode-DrS85i4S.js",
      "assets/formFill-Dg9Myfyq.js",
      "assets/redactSearch-DQpyyh_t.js",
      "assets/nameDetect-DvHCRM0m.js",
    ]),
) => i.map((i) => d[i]);
import {
  aw as _e,
  B as h,
  N as he,
  e as ze,
  f as U,
  ap as Ge,
} from "./index-B1CTyGtY.js";
import { r as i, j as n } from "./vendor-react-D01g8YgM.js";
import { b as Xe, T as Ye, F as qe, d as J } from "./ToolPage-DwLoDncN.js";
import { S as Je } from "./slider-nIHsxb_2.js";
import {
  i as Ve,
  j as Ze,
  k as Ke,
  m as Qe,
  n as et,
  s as tt,
  o as at,
  p as ge,
  q as nt,
  t as ot,
  u as st,
  v as rt,
} from "./operations-YdcesJcx.js";
import { k as it } from "./index-BRvxULIc.js";
import { s as ct } from "./fileHandoff-RQJcoDih.js";
import { OCR_LANGUAGES as lt } from "./ocrText-C_9cxcFa.js";
import { T as dt } from "./ToolSteps-DWea1Jiy.js";
import { u as ht } from "./useDownloadedResult-C1FfMpBH.js";
import { R as ue } from "./rotate-cw-BNziJsEZ.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./utils-1EQcVBdK.js";
import "./decode-DrS85i4S.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
function Qt() {
  const [p, C] = i.useState("select"),
    [B, me] = i.useState("document"),
    [V, A] = i.useState(null),
    [u, y] = i.useState(null),
    [w, O] = i.useState(null),
    [N, E] = i.useState(null),
    [m, P] = i.useState(null),
    [Z, K] = i.useState(null),
    [S, pe] = i.useState([60]),
    [M, Q] = i.useState(!0),
    [L, D] = i.useState(0),
    [$, xe] = i.useState(!0),
    [_, fe] = i.useState(() =>
      Ve(typeof navigator < "u" ? navigator.language : ""),
    ),
    [x, I] = i.useState([]),
    [we, ye] = i.useState(""),
    [ee, be] = i.useState(""),
    [te, ve] = i.useState(""),
    [b, je] = i.useState(!1),
    [ae, Re] = i.useState("eng"),
    [F, z] = i.useState(""),
    [, Ce] = _e(),
    { logUsageNow: G } = Xe(),
    v = i.useRef(null),
    ne = i.useRef(null),
    k = i.useRef(null),
    oe = i.useRef(null),
    X = i.useRef(null),
    j = i.useRef(null),
    [gt, ut] = i.useState(null),
    [mt, pt] = i.useState(null),
    Ne = ht(p === "enhance" ? N : null),
    ke = i.useCallback(async (t) => {
      const e = t[0];
      if (!e) return;
      (me(e.name.replace(/\.[^.]+$/, "")), y(null));
      let a = "",
        r = 0,
        o = 0;
      try {
        const s = Ze(await e.arrayBuffer()),
          c = await createImageBitmap(e, { imageOrientation: "none" }),
          l = Ke(s, c.width, c.height),
          g = document.createElement("canvas");
        ((g.width = l.width), (g.height = l.height));
        const d = g.getContext("2d");
        (d.setTransform(...l.m), d.drawImage(c, 0, 0), c.close?.());
        const f = await new Promise((R) => g.toBlob(R, "image/png"));
        f && ((a = URL.createObjectURL(f)), (r = l.width), (o = l.height));
      } catch (s) {
        console.warn("Orientation fix skipped", s);
      }
      if (!a) {
        a = URL.createObjectURL(e);
        const s = new Image();
        (await new Promise((c) => {
          ((s.onload = s.onerror = () => c()), (s.src = a));
        }),
          (r = s.naturalWidth),
          (o = s.naturalHeight));
      }
      (be(
        r > 0 && Qe(r, o)
          ? `This photo is small (${r} x ${o} px). Text may look blurry or pixelated. A photo with at least 600 px on the short side, ideally much more, gives a better scan.`
          : "",
      ),
        A(a),
        C("crop"));
    }, []),
    T = (t) => {
      const e = t.getBoundingClientRect(),
        a = e.width / e.height,
        r = t.naturalWidth / t.naturalHeight;
      let o, s, c, l;
      return (
        r > a
          ? ((o = e.width),
            (s = e.width / r),
            (c = 0),
            (l = (e.height - s) / 2))
          : ((s = e.height),
            (o = e.height * r),
            (l = 0),
            (c = (e.width - o) / 2)),
        { x: c, y: l, width: o, height: s }
      );
    },
    Y = (t, e, a) => {
      const r = t.current;
      if (!r) return { x: 0, y: 0 };
      const o = r.getBoundingClientRect(),
        s = T(r),
        c = e - o.left - s.x,
        l = a - o.top - s.y;
      return {
        x: Math.max(0, Math.min(s.width, c)),
        y: Math.max(0, Math.min(s.height, l)),
      };
    },
    q = (t, e) => Y(t, e.clientX, e.clientY),
    se = (t, e) => {
      const a = t.current?.getBoundingClientRect(),
        r = e.current;
      if (!a || !r) return { x: 0, y: 0 };
      const o = r.getBoundingClientRect(),
        s = T(r);
      return { x: o.left - a.left + s.x, y: o.top - a.top + s.y };
    },
    Pe = (t) => {
      const e = q(v, t);
      (O(e), y({ x: e.x, y: e.y, w: 0, h: 0 }));
    },
    Se = (t) => {
      if (!w) return;
      const e = q(v, t);
      y({
        x: Math.min(w.x, e.x),
        y: Math.min(w.y, e.y),
        w: Math.abs(e.x - w.x),
        h: Math.abs(e.y - w.y),
      });
    },
    W = () => O(null),
    Me = (t) => {
      if (t.touches.length === 0) return;
      const e = t.touches[0],
        a = Y(v, e.clientX, e.clientY);
      (O(a), y({ x: a.x, y: a.y, w: 0, h: 0 }));
    },
    Le = (t) => {
      if (!w || t.touches.length === 0) return;
      t.preventDefault();
      const e = t.touches[0],
        a = Y(v, e.clientX, e.clientY);
      y({
        x: Math.min(w.x, a.x),
        y: Math.min(w.y, a.y),
        w: Math.abs(a.x - w.x),
        h: Math.abs(a.y - w.y),
      });
    },
    De = () => {
      const t = v.current;
      if (!t) return;
      const e = document.createElement("canvas"),
        a = e.getContext("2d");
      if (u && u.w >= 4 && u.h >= 4) {
        const r = T(t),
          o = t.naturalWidth / r.width,
          s = t.naturalHeight / r.height;
        ((e.width = Math.round(u.w * o)),
          (e.height = Math.round(u.h * s)),
          a.drawImage(
            t,
            u.x * o,
            u.y * s,
            u.w * o,
            u.h * s,
            0,
            0,
            e.width,
            e.height,
          ));
      } else
        ((e.width = t.naturalWidth),
          (e.height = t.naturalHeight),
          a.drawImage(t, 0, 0));
      (E(e.toDataURL("image/png")), C("straighten"));
    };
  i.useEffect(() => {
    p === "straighten" && P(null);
  }, [p, N]);
  const Ie = () => {
      const t = k.current;
      if (!t) return;
      const e = T(t);
      if (e.width === 0 || e.height === 0) return;
      const a = {
        topLeft: { x: 0, y: 0 },
        topRight: { x: e.width, y: 0 },
        bottomRight: { x: e.width, y: e.height },
        bottomLeft: { x: 0, y: e.height },
      };
      let r = null;
      try {
        const o = document.createElement("canvas"),
          s = Math.min(1, 600 / Math.max(t.naturalWidth, t.naturalHeight));
        ((o.width = Math.round(t.naturalWidth * s)),
          (o.height = Math.round(t.naturalHeight * s)));
        const c = o.getContext("2d", { willReadFrequently: !0 });
        c.drawImage(t, 0, 0, o.width, o.height);
        const l = nt(c.getImageData(0, 0, o.width, o.height));
        if (l) {
          const g = (d) => ({
            x: (d.x / o.width) * e.width,
            y: (d.y / o.height) * e.height,
          });
          r = {
            topLeft: g(l.topLeft),
            topRight: g(l.topRight),
            bottomRight: g(l.bottomRight),
            bottomLeft: g(l.bottomLeft),
          };
        }
      } catch (o) {
        console.warn("Page detection failed", o);
      }
      (ye(
        r
          ? "Page found automatically. Check the corners and drag any that are off."
          : "Couldn't find the page edges automatically. Drag the four corners onto the page's corners. If you skip, the scan is a straight copy of this image, only cleaned up, not straightened.",
      ),
        P(r ?? a));
    },
    Fe = () => {
      if (!N) return;
      const t = new Image();
      ((t.onload = () => {
        const e = document.createElement("canvas");
        ((e.width = t.naturalHeight), (e.height = t.naturalWidth));
        const a = e.getContext("2d");
        (a.translate(e.width / 2, e.height / 2),
          a.rotate(Math.PI / 2),
          a.drawImage(t, -t.naturalWidth / 2, -t.naturalHeight / 2),
          E(e.toDataURL("image/png")));
      }),
        (t.src = N));
    },
    Te = (t) => (e) => {
      (e.stopPropagation(), K(t));
    },
    Ue = (t) => {
      if (!Z) return;
      const e = q(k, t);
      P((a) => a && { ...a, [Z]: e });
    },
    re = () => K(null),
    Be = () => {
      const t = k.current;
      if (!t || !m) return;
      const e = T(t),
        a = t.naturalWidth / e.width,
        r = t.naturalHeight / e.height,
        o = {
          topLeft: { x: m.topLeft.x * a, y: m.topLeft.y * r },
          topRight: { x: m.topRight.x * a, y: m.topRight.y * r },
          bottomRight: { x: m.bottomRight.x * a, y: m.bottomRight.y * r },
          bottomLeft: { x: m.bottomLeft.x * a, y: m.bottomLeft.y * r },
        },
        s = (f, R) => Math.hypot(R.x - f.x, R.y - f.y),
        c = Math.round(
          (s(o.topLeft, o.topRight) + s(o.bottomLeft, o.bottomRight)) / 2,
        ),
        l = Math.round(
          (s(o.topLeft, o.bottomLeft) + s(o.topRight, o.bottomRight)) / 2,
        ),
        g = ot(t, o, Math.max(1, c), Math.max(1, l)),
        d = new Image();
      ((d.onload = () => {
        ((X.current = d), D(0), C("enhance"));
      }),
        (d.src = g.toDataURL("image/png")));
    },
    Ee = () => {
      const t = k.current;
      t && ((X.current = t), D(0), C("enhance"));
    },
    ie = i.useCallback(() => {
      const t = X.current,
        e = j.current;
      if (!t || !e) return;
      let a = t,
        r = !0;
      if ($) {
        const d = document.createElement("canvas");
        ((d.width = t.naturalWidth), (d.height = t.naturalHeight));
        const f = d.getContext("2d", { willReadFrequently: !0 });
        f.drawImage(t, 0, 0);
        const R = f.getImageData(0, 0, d.width, d.height);
        ((r = et(
          R,
          Math.max(16, Math.round(Math.max(d.width, d.height) / 40)),
        )),
          f.putImageData(R, 0, 0),
          (a = d));
      }
      const o = {};
      let s = tt(a, S[0], M, o),
        c = !1;
      try {
        const d = s.getContext("2d", { willReadFrequently: !0 });
        if (at(d.getImageData(0, 0, s.width, s.height).data)) {
          const f = document.createElement("canvas");
          ((f.width = t.naturalWidth),
            (f.height = t.naturalHeight),
            f.getContext("2d").drawImage(t, 0, 0),
            (s = f),
            (c = !0));
        }
      } catch {}
      ve(
        c
          ? "These settings made the page almost black, so the original photo is shown instead. Try turning off Grayscale or Remove shadows."
          : o.lowContrast
            ? "This page has almost no contrast (a plain or flat coloured sheet), so shadow removal and contrast were skipped and the page was only brightened to stay readable."
            : o.darkPage
              ? "This page is dark, so it was brightened instead of stretched towards black. Text that is lighter than the page may be faint."
              : r
                ? ""
                : "Shadow removal was skipped because the page has no uneven lighting to even out.",
      );
      const l = L === 90 || L === 270;
      ((e.width = l ? s.height : s.width), (e.height = l ? s.width : s.height));
      const g = e.getContext("2d");
      (g.save(),
        g.translate(e.width / 2, e.height / 2),
        g.rotate((L * Math.PI) / 180),
        g.drawImage(s, -s.width / 2, -s.height / 2),
        g.restore());
    }, [S, L, M, $]);
  i.useEffect(() => {
    p === "enhance" && ie();
  }, [p, ie]);
  const $e = () => D((t) => (t + 90) % 360),
    H = (t) =>
      new Promise((e, a) =>
        t.toBlob(
          (r) => (r ? e(r) : a(new Error("encode failed"))),
          "image/jpeg",
          0.92,
        ),
      ),
    We = async () => {
      const t = j.current;
      !t ||
        !(await G("download")) ||
        t.toBlob((e) => {
          e && J(e, `scanned_${B}.png`);
        }, "image/png");
    },
    ce = async (t) => {
      const e = await it.create();
      if (b) {
        const a = [];
        for (const s of t.slice(0, 2))
          a.push(await e.embedJpg(new Uint8Array(await s.arrayBuffer())));
        const r = st(
            a.map((s) => ({ w: s.width, h: s.height })),
            _,
          ),
          o = e.addPage([r.pageW, r.pageH]);
        return (
          a.forEach((s, c) => o.drawImage(s, r.boxes[c])),
          e.setProducer("FreeDailyPro"),
          new Blob([new Uint8Array(await e.save())], {
            type: "application/pdf",
          })
        );
      }
      for (const a of t) {
        const r = await e.embedJpg(new Uint8Array(await a.arrayBuffer())),
          o = rt(r.width, r.height, _);
        e.addPage([o.pageW, o.pageH]).drawImage(r, {
          x: (o.pageW - o.drawW) / 2,
          y: (o.pageH - o.drawH) / 2,
          width: o.drawW,
          height: o.drawH,
        });
      }
      return (
        e.setProducer("FreeDailyPro"),
        new Blob([new Uint8Array(await e.save())], { type: "application/pdf" })
      );
    },
    He = async () => {
      const t = j.current;
      if (!(!t || !(await G("download"))))
        try {
          J(
            await ce([...x, await H(t)]),
            `scanned_${B}${x.length ? `_${x.length + 1}pages` : ""}.pdf`,
          );
        } catch (e) {
          (console.error(e), U.error("Couldn't build the PDF."));
        }
    },
    Ae = async () => {
      const t = j.current;
      if (!(!t || !(await G("download"))))
        try {
          z(
            "Reading the text (the first time this downloads the language data)...",
          );
          const e = await ce([...x, await H(t)]),
            { ocrPdf: a } = await Ge(
              async () => {
                const { ocrPdf: o } =
                  await import("./operations-B4LtHhm8.js").then((s) => s.Z);
                return { ocrPdf: o };
              },
              __vite__mapDeps([
                0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17,
                18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28,
              ]),
            ),
            r = await a(
              new File([e], "scan.pdf", { type: "application/pdf" }),
              (o) => z(o),
              { language: ae },
            );
          (r.pagesOcrd === 0
            ? U.warning(
                "No readable text was found, so the PDF has no text layer. Try a sharper photo or another language.",
              )
            : U.success(
                `Searchable PDF ready (${r.pagesOcrd} page${r.pagesOcrd === 1 ? "" : "s"} read).`,
              ),
            J(r.pagesOcrd === 0 ? e : r.blob, `scanned_${B}_searchable.pdf`));
        } catch (e) {
          (console.error(e),
            U.error(
              e instanceof Error && e.name === "OcrStartError"
                ? e.message
                : "Couldn't make the searchable PDF.",
            ));
        } finally {
          z("");
        }
    },
    le = async (t) => {
      const e = j.current;
      if (!e) return;
      const a = [...x, await H(e)];
      (ct(
        "scan-convert",
        a.map(
          (r, o) =>
            new File([r], `${B}-page-${o + 1}.jpg`, { type: "image/jpeg" }),
        ),
      ),
        Ce(`/tools/${t}`));
    },
    Oe = async () => {
      const t = j.current;
      if (!t) return;
      const e = await H(t);
      (I((a) => [...a, e]),
        C("select"),
        A(null),
        E(null),
        P(null),
        y(null),
        D(0),
        U.success(
          b
            ? "Front added. Now scan the back side."
            : "Page added. Scan the next one.",
        ));
    },
    de = () => {
      (I([]), C("select"), A(null), E(null), P(null), y(null), D(0));
    };
  return n.jsxs(Ye, {
    children: [
      n.jsx(dt, {
        toolId: "document-scanner",
        state: {
          hasPhoto: p !== "select",
          cropped: p === "straighten" || p === "enhance",
          straightened: p === "enhance",
          cleanedUp: p === "enhance" && (!M || !$ || S[0] !== 60 || L !== 0),
          downloaded: Ne,
        },
      }),
      p === "select" &&
        n.jsxs("div", {
          className: "space-y-4",
          children: [
            n.jsxs("label", {
              className:
                "flex items-center justify-center gap-2 text-sm min-h-10",
              "data-testid": "scan-idmode",
              children: [
                n.jsx("input", {
                  type: "checkbox",
                  className: "h-5 w-5",
                  checked: b,
                  onChange: (t) => je(t.target.checked),
                }),
                " ID card or two-sided card: front and back on one page, true size",
              ],
            }),
            x.length > 0 &&
              n.jsxs("div", {
                className: "space-y-2",
                "data-testid": "scan-pages",
                children: [
                  n.jsx("p", {
                    className: "text-sm text-center",
                    children: b
                      ? "Front added. Choose the photo of the back side."
                      : `${x.length} page${x.length > 1 ? "s" : ""} added so far. Choose the next page's photo.`,
                  }),
                  n.jsx("ul", {
                    className: "max-w-sm mx-auto space-y-1",
                    children: x.map((t, e) =>
                      n.jsxs(
                        "li",
                        {
                          className: "flex items-center gap-2 text-sm",
                          children: [
                            n.jsxs("span", {
                              className: "flex-1",
                              children: ["Page ", e + 1],
                            }),
                            n.jsx(h, {
                              size: "sm",
                              variant: "outline",
                              className: "min-h-10",
                              disabled: e === 0,
                              onClick: () => I((a) => ge(a, e, -1)),
                              "aria-label": `Move page ${e + 1} up`,
                              children: "Up",
                            }),
                            n.jsx(h, {
                              size: "sm",
                              variant: "outline",
                              className: "min-h-10",
                              disabled: e === x.length - 1,
                              onClick: () => I((a) => ge(a, e, 1)),
                              "aria-label": `Move page ${e + 1} down`,
                              children: "Down",
                            }),
                            n.jsx(h, {
                              size: "sm",
                              variant: "ghost",
                              className: "min-h-10",
                              onClick: () =>
                                I((a) => a.filter((r, o) => o !== e)),
                              "aria-label": `Remove page ${e + 1}`,
                              children: "Remove",
                            }),
                          ],
                        },
                        e,
                      ),
                    ),
                  }),
                ],
              }),
            n.jsx(qe, {
              accept: "image/*",
              onFiles: ke,
              label: "Drop a document photo to scan",
              description: "Upload a photo of a document to enhance",
              deferUsageLog: !0,
            }),
          ],
        }),
      p === "crop" &&
        V &&
        n.jsxs("div", {
          className: "space-y-4",
          children: [
            n.jsxs("div", {
              ref: ne,
              className:
                "relative w-full rounded-lg border max-h-[500px] overflow-hidden bg-muted/30 cursor-crosshair select-none",
              onMouseDown: Pe,
              onMouseMove: Se,
              onMouseUp: W,
              onMouseLeave: W,
              onTouchStart: Me,
              onTouchMove: Le,
              onTouchEnd: W,
              onTouchCancel: W,
              style: { touchAction: "none" },
              children: [
                n.jsx("img", {
                  ref: v,
                  src: V,
                  alt: "Document photo",
                  className:
                    "w-full max-h-[500px] object-contain pointer-events-none",
                  draggable: !1,
                }),
                u &&
                  u.w >= 4 &&
                  u.h >= 4 &&
                  (() => {
                    const t = se(ne, v);
                    return n.jsx("div", {
                      className:
                        "absolute border-2 border-primary bg-primary/10 pointer-events-none",
                      style: {
                        left: t.x + u.x,
                        top: t.y + u.y,
                        width: u.w,
                        height: u.h,
                      },
                    });
                  })(),
              ],
            }),
            n.jsx("p", {
              className: "text-xs text-muted-foreground text-center",
              children:
                "Drag to crop out anything that isn't the document, or continue to use the whole photo.",
            }),
            ee &&
              n.jsx(he, {
                className: "text-xs text-center",
                role: "status",
                children: ee,
              }),
            n.jsxs("div", {
              className: "flex items-center justify-center gap-3 flex-wrap",
              children: [
                n.jsx(h, { onClick: De, children: "Continue" }),
                n.jsx(h, {
                  variant: "outline",
                  onClick: de,
                  children: "Take Another",
                }),
              ],
            }),
          ],
        }),
      p === "straighten" &&
        N &&
        n.jsxs("div", {
          className: "space-y-4",
          children: [
            n.jsxs("div", {
              ref: oe,
              className:
                "relative w-full rounded-lg border max-h-[500px] overflow-hidden bg-muted/30 select-none",
              onPointerMove: Ue,
              onPointerUp: re,
              onPointerLeave: re,
              children: [
                n.jsx("img", {
                  ref: k,
                  src: N,
                  alt: "Cropped document",
                  onLoad: Ie,
                  className:
                    "w-full max-h-[500px] object-contain pointer-events-none",
                  draggable: !1,
                }),
                m &&
                  (() => {
                    const t = se(oe, k),
                      e = ["topLeft", "topRight", "bottomRight", "bottomLeft"];
                    return n.jsxs(n.Fragment, {
                      children: [
                        n.jsx("svg", {
                          className: "absolute inset-0 pointer-events-none",
                          style: { left: t.x, top: t.y },
                          children: n.jsx("polygon", {
                            points: e
                              .map((a) => `${m[a].x},${m[a].y}`)
                              .join(" "),
                            fill: "rgba(59,130,246,0.15)",
                            stroke: "rgb(59,130,246)",
                            strokeWidth: 2,
                          }),
                        }),
                        e.map((a) =>
                          n.jsx(
                            "div",
                            {
                              onPointerDown: Te(a),
                              className:
                                "absolute h-5 w-5 rounded-full bg-primary border-2 border-white shadow cursor-grab active:cursor-grabbing touch-none",
                              style: {
                                left: t.x + m[a].x - 10,
                                top: t.y + m[a].y - 10,
                              },
                            },
                            a,
                          ),
                        ),
                      ],
                    });
                  })(),
              ],
            }),
            n.jsx("p", {
              className: "text-xs text-muted-foreground text-center",
              children: m
                ? we ||
                  "Drag the four corner handles onto the document's corners to straighten it. Skip if it's already straight-on."
                : "Loading...",
            }),
            n.jsxs("div", {
              className: "flex items-center justify-center gap-3 flex-wrap",
              children: [
                n.jsx(h, {
                  onClick: Be,
                  disabled: !m,
                  className: "gap-2",
                  children: "Straighten",
                }),
                n.jsx(h, {
                  variant: "outline",
                  onClick: Ee,
                  children: "Skip — Already Straight",
                }),
                n.jsxs(h, {
                  variant: "outline",
                  onClick: Fe,
                  className: "gap-2",
                  "aria-label": "Rotate the photo 90 degrees clockwise",
                  children: [n.jsx(ue, { className: "h-4 w-4" }), " Rotate 90"],
                }),
              ],
            }),
          ],
        }),
      p === "enhance" &&
        n.jsxs("div", {
          className: "space-y-4",
          children: [
            n.jsx("canvas", {
              ref: j,
              className:
                "w-full max-h-96 object-contain rounded-lg border mx-auto block",
            }),
            te &&
              n.jsx(he, {
                className: "text-xs text-center",
                role: "status",
                children: te,
              }),
            n.jsxs("div", {
              className: "max-w-sm mx-auto space-y-3",
              children: [
                n.jsxs("div", {
                  className: "flex items-center justify-center gap-2",
                  children: [
                    n.jsx(h, {
                      size: "sm",
                      variant: M ? "default" : "outline",
                      onClick: () => Q(!0),
                      children: "Grayscale",
                    }),
                    n.jsx(h, {
                      size: "sm",
                      variant: M ? "outline" : "default",
                      onClick: () => Q(!1),
                      children: "Keep Color",
                    }),
                  ],
                }),
                n.jsxs("label", {
                  className: "flex items-center gap-2 text-sm justify-center",
                  children: [
                    n.jsx("input", {
                      type: "checkbox",
                      checked: $,
                      onChange: (t) => xe(t.target.checked),
                    }),
                    " Remove shadows / even out lighting",
                  ],
                }),
                n.jsxs("label", {
                  className: "flex items-center gap-2 text-sm justify-center",
                  children: [
                    "PDF page",
                    n.jsxs("select", {
                      className: "border rounded px-1 bg-background",
                      value: _,
                      onChange: (t) => fe(t.target.value),
                      children: [
                        n.jsx("option", { value: "a4", children: "A4" }),
                        n.jsx("option", {
                          value: "letter",
                          children: "US Letter",
                        }),
                        n.jsx("option", {
                          value: "fit",
                          children: "Fit the scan (150 dpi)",
                        }),
                      ],
                    }),
                  ],
                }),
                n.jsxs("div", {
                  children: [
                    n.jsxs(ze, {
                      className: "text-xs",
                      children: ["Contrast: ", S[0]],
                    }),
                    n.jsx(Je, {
                      value: S,
                      onValueChange: pe,
                      min: 0,
                      max: 120,
                      step: 5,
                    }),
                  ],
                }),
              ],
            }),
            n.jsx("div", {
              className: "flex gap-2 justify-center",
              children: n.jsxs(h, {
                size: "sm",
                variant: "outline",
                onClick: $e,
                className: "gap-2",
                children: [n.jsx(ue, { className: "h-4 w-4" }), " Rotate"],
              }),
            }),
            n.jsxs("div", {
              className: "flex gap-3 justify-center flex-wrap",
              children: [
                n.jsxs(h, {
                  onClick: () => {
                    He();
                  },
                  className: "gap-2",
                  children: [
                    "Download PDF",
                    b
                      ? x.length
                        ? " (front + back, one page)"
                        : ""
                      : x.length
                        ? ` (${x.length + 1} pages)`
                        : "",
                  ],
                }),
                n.jsx(h, {
                  variant: "outline",
                  onClick: () => {
                    We();
                  },
                  children: "Download PNG",
                }),
                !(b && x.length >= 1) &&
                  n.jsx(h, {
                    variant: "outline",
                    onClick: () => {
                      Oe();
                    },
                    children: b
                      ? "Add front & scan back"
                      : "Add page & scan next",
                  }),
                n.jsx(h, { variant: "outline", onClick: de, children: "New" }),
              ],
            }),
            n.jsxs("div", {
              className: "max-w-sm mx-auto space-y-2 rounded-lg border p-3",
              "data-testid": "scan-more",
              children: [
                n.jsxs("label", {
                  className: "flex items-center gap-2 text-sm",
                  children: [
                    "Text language",
                    n.jsx("select", {
                      className: "border rounded px-1 bg-background h-9",
                      value: ae,
                      onChange: (t) => Re(t.target.value),
                      "aria-label": "Text language for the searchable PDF",
                      children: lt.map((t) =>
                        n.jsx(
                          "option",
                          { value: t.id, children: t.label },
                          t.id,
                        ),
                      ),
                    }),
                  ],
                }),
                n.jsxs("div", {
                  className: "flex flex-wrap gap-2",
                  children: [
                    n.jsx(h, {
                      variant: "outline",
                      className: "min-h-10",
                      disabled: !!F,
                      onClick: () => {
                        Ae();
                      },
                      "data-testid": "scan-searchable",
                      children: "Download searchable PDF",
                    }),
                    n.jsx(h, {
                      variant: "outline",
                      className: "min-h-10",
                      disabled: !!F,
                      onClick: () => {
                        le("image-to-word");
                      },
                      "data-testid": "scan-to-word",
                      children: "Edit as Word",
                    }),
                    n.jsx(h, {
                      variant: "outline",
                      className: "min-h-10",
                      disabled: !!F,
                      onClick: () => {
                        le("image-to-excel");
                      },
                      "data-testid": "scan-to-excel",
                      children: "Edit as Excel",
                    }),
                  ],
                }),
                F &&
                  n.jsx("p", {
                    role: "status",
                    className: "text-xs text-muted-foreground",
                    children: F,
                  }),
              ],
            }),
          ],
        }),
    ],
  });
}
export { Qt as default };
//# sourceMappingURL=DocumentScanner-D0BCo7Kc.js.map
