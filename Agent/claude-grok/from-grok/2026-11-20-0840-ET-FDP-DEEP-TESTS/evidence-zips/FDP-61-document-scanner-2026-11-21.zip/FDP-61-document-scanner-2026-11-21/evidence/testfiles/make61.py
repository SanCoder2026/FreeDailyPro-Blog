# Builds FDP-61 synthetic document photos. Run: /workspace/deep/venv-pdf/bin/python make61.py
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import random
F = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'; FB = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
random.seed(61)
def page(title, n, w=850, h=1100, bg=(250,250,246), ink=(20,20,20)):
    im = Image.new('RGB', (w, h), bg); d = ImageDraw.Draw(im)
    d.text((70, 60), title, font=ImageFont.truetype(FB, 44), fill=ink)
    d.text((70, 130), f'PAGE {n} - INVOICE 2026-{n:03d}', font=ImageFont.truetype(F, 30), fill=ink)
    f = ImageFont.truetype(F, 24)
    lines = ['The quick brown fox jumps over the lazy dog.', 'Total due: $1,234.56 by December 15, 2026.', 'Signed by Santosh Test, Acme Office Supplies.', 'Reference number FDP-SCAN-0061-' + str(n)]
    y = 220
    for i in range(16): d.text((70, y), lines[i % 4], font=f, fill=ink); y += 50
    d.rectangle((60, 50, w-60, h-50), outline=ink, width=3)
    return im
def desk(w=2000, h=1500, dark=True):
    base = Image.new('RGB', (w, h), (70, 45, 30) if dark else (225, 225, 220)); d = ImageDraw.Draw(base)
    for i in range(0, h, 9): c = random.randint(-12, 12); d.line((0, i, w, i), fill=tuple(max(0, min(255, v + c)) for v in base.getpixel((0, 0))), width=4)
    return base
def coeffs(src, dst):
    import numpy as np
    A = []; B = []
    for (x, y), (u, v) in zip(dst, src):
        A += [[x, y, 1, 0, 0, 0, -u*x, -u*y], [0, 0, 0, x, y, 1, -v*x, -v*y]]; B += [u, v]
    return np.linalg.solve(np.array(A, float), np.array(B, float)).tolist()
def place(pg, bgim, quad, shadow=False):
    w, h = pg.size; c = coeffs([(0,0),(w,0),(w,h),(0,h)], quad)
    warped = pg.transform(bgim.size, Image.PERSPECTIVE, c, Image.BICUBIC)
    mask = Image.new('L', pg.size, 255).transform(bgim.size, Image.PERSPECTIVE, c, Image.BICUBIC)
    out = bgim.copy(); out.paste(warped, (0, 0), mask)
    if shadow:
        sh = Image.new('L', out.size, 0); ImageDraw.Draw(sh).ellipse((900, 300, 1900, 1400), fill=90); sh = sh.filter(ImageFilter.GaussianBlur(120))
        out = Image.composite(Image.new('RGB', out.size, (0,0,0)), out, sh)
    return out
Q = [(520, 170), (1480, 230), (1530, 1380), (430, 1310)]
for n in (1, 2, 3):
    place(page('ACME OFFICE SUPPLIES', n), desk(), [(x + n*10, y) for x, y in Q]).save(f'p{n}-tilted.jpg', quality=90)
place(page('SHADOW TEST', 4), desk(), Q, shadow=True).save('p4-shadow.jpg', quality=90)
place(page('FLAT LIGHT DESK', 5), desk(dark=False), Q).save('p5-lightdesk.jpg', quality=90)  # edge finder should fail (bright desk)
page('STRAIGHT SCAN', 6).save('p6-straight.png')
im = place(page('EXIF ROTATED', 7), desk(), Q).rotate(90, expand=True)  # stored sideways, EXIF says rotate back
ex = Image.Exif(); ex[0x0112] = 6; im.save('p7-exif-orient6.jpg', quality=90, exif=ex)  # 6 = viewer rotates 90 CW to display upright
page('SMALL', 8).resize((300, 390)).save('p8-small-300px.jpg', quality=85)
page('LOW CONTRAST', 9, bg=(200, 205, 230), ink=(185, 190, 215)).save('p9-lowcontrast.png')
page('DARK PAGE', 10, bg=(40, 40, 50), ink=(200, 200, 200)).save('p10-darkpage.png')
def card(side):
    im = Image.new('RGB', (856, 540), (230, 240, 255) if side == 'FRONT' else (255, 240, 230)); d = ImageDraw.Draw(im)
    d.rounded_rectangle((5, 5, 851, 535), 30, outline=(0, 0, 80), width=6); d.text((50, 50), f'ID CARD {side}', font=ImageFont.truetype(FB, 54), fill=(0, 0, 80))
    d.text((50, 200), 'NAME: TEST PERSON', font=ImageFont.truetype(F, 40), fill=(0, 0, 0)); d.text((50, 280), 'NO: 0061-' + side, font=ImageFont.truetype(F, 40), fill=(0, 0, 0)); return im
for s in ('FRONT', 'BACK'): place(card(s), desk(1600, 1200), [(300, 250), (1250, 280), (1230, 880), (280, 860)]).save(f'id-{s.lower()}.jpg', quality=90)
big = place(page('BIG 6000PX', 11).resize((2550, 3300)), desk(6000, 4500), [(x*3, y*3) for x, y in Q]); big.save('p11-big-6000.jpg', quality=88)
open('notanimage.jpg', 'w').write('this is text, not a picture')
print('ok')
