// FDP-61 Document Scanner (Premium), guest. Usage: node px61-live.js <zero|left|leftB|msgs> [engine]   env TRIES, ANY=1, SUF
// zero: as-is context (normally at the Premium cap 2/2): full scan flow on p1, then each gated button -> dialog; Quick Buy -> stop at email prompt/Stripe; Edit as Word handoff.
// left: context with Premium uses left: 3-page PDF (reorder+remove) [use 1], PNG of same page [use 2], then searchable PDF -> expect cap.
// leftB: uses left: ID card front+back PDF [use 1], searchable PDF of p6 (Letter) [use 2].
// msgs: status messages (small, low contrast, dark, light desk, EXIF, not-an-image, big 6000px), no downloads.
// Never signs in, never types an email or card, never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/61-document-scanner/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const URL = 'https://www.freedailypro.com/tool/document-scanner';
const mode = process.argv[2] || 'zero'; const eng = process.argv[3] || 'chromium'; const sfx = (eng === 'chromium' ? '' : '-' + eng) + (process.env.SUF || '');
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').replace(/dev[:%][^&"]*/g, 'dev:REDACTED').slice(0, 160);
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p, net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 1000 }, locale: 'en-US', acceptDownloads: true }); p = await c.newPage(); p.setDefaultTimeout(15000); net = [];
  await p.addInitScript(() => { window.__t = []; const seen = new WeakSet(); setInterval(() => { document.querySelectorAll('[data-sonner-toast]').forEach(n => { if (!seen.has(n)) { seen.add(n); window.__t.push((n.innerText || '').trim()); } }); }, 120); });
  p.on('request', r => { const u = r.url(); if (r.method() === 'POST' && /freedailypro\.com\/api/.test(u) && !/insight\.hit|funnel\.hit/.test(u)) net.push({ t: now(), u: red(u) }); });
  await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit + (u.tier ? ' ' + u.tier : ''); });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(250); } };
 const toasts = n => p.evaluate(n => (window.__t || []).slice(n), n); const tc = () => p.evaluate(() => (window.__t || []).length);
 const status = () => p.evaluate(() => [...document.querySelectorAll('main [role=status]')].map(e => e.innerText.trim()).filter(Boolean));
 const shot = n => p.screenshot({ path: OUT + 'cases/' + n + sfx + '.png' });
 const btn = t => p.locator('main button', { hasText: t }).first();
 const upload = async f => { await p.locator('main input[type=file][accept="image/*"]').first().setInputFiles(TF + f); await p.waitForTimeout(2500); };
 const crop = async (frac) => { const img = p.locator('main img[alt="Document photo"]'); const bb = await img.boundingBox(); if (frac) { const [x0, y0, x1, y1] = frac; await p.mouse.move(bb.x + bb.width * x0, bb.y + bb.height * y0); await p.mouse.down(); await p.mouse.move(bb.x + bb.width * x1, bb.y + bb.height * y1, { steps: 8 }); await p.mouse.up(); } await btn(/^Continue$/).click(); await p.waitForTimeout(2000); };
 const straighten = async (skip) => { const st = await status(); await p.waitForTimeout(800); const m = await p.locator('main').getByText(/Page found automatically|Couldn.t find the page edges|Drag the four corner handles/).first().innerText().catch(() => null); const corners = await p.evaluate(() => { const pg = document.querySelector('main svg polygon'); return pg ? pg.getAttribute('points') : null; }); if (process.env.SHOTS) await shot('S-' + Date.now()); if (skip) await btn('Skip').click(); else await btn(/^Straighten$/).click(); await p.waitForTimeout(2500); return { msg: m, corners, st }; };
 const canvasInfo = () => p.evaluate(() => { const cv = document.querySelector('main canvas'); return cv ? { w: cv.width, h: cv.height } : null; });
 const scan = async (f, frac, skip) => { await upload(f); const s0 = await status(); await crop(frac); const s1 = await straighten(skip); return { file: f, uploadStatus: s0, straighten: s1, enhanceStatus: await status(), canvas: await canvasInfo() }; };
 const dl = async (label, id) => { const n = await tc(); const before = await used(); const np = net.length; const dp = p.waitForEvent('download', { timeout: label.source && /searchable/.test(label.source) ? 180000 : 15000 }).catch(() => null); await btn(label).click(); const d = await dp; await p.waitForTimeout(1500); const r = { before, after: await used(), dialog: await dialog(), toasts: await toasts(n), posts: net.slice(np).map(x => x.u.slice(0, 80)) }; if (d) { const f = OUT + 'downloads/' + id + sfx + '-' + d.suggestedFilename(); await d.saveAs(f); r.file = { name: d.suggestedFilename(), bytes: fs.statSync(f).size, path: f.replace(BASE, '') }; } if (r.dialog) { await shot(id + '-dialog'); await esc(); } return r; };
 const C = async (id, fn) => { try { R.cases[id] = await fn(); } catch (e) { R.cases[id] = { err: e.message.split('\n')[0].slice(0, 200) }; await shot(id + '-err').catch(() => { }); } console.log(id, JSON.stringify(R.cases[id]).slice(0, 500)); };
 const findLeft = async () => { if (process.env.ANY) { await open(); R.tries.push(await used()); return true; } const TRIES = +(process.env.TRIES || 10); for (let i = 0; i < TRIES; i++) { await open(); const u = await used(); R.tries.push(u); const [a, l] = u.split(' ')[0].split('/').map(Number); if (a < l) return true; await c.close(); } return false; };
 const strip = () => p.evaluate(() => { const t = document.querySelector('main').innerText; return (t.match(/Trial[^\n]*/) || [null])[0]; });
 if (mode === 'zero') { await open(); R.start = { used: await used(), strip: await strip() }; await shot('Z00-initial');
  await C('Z01-scan-p1', async () => { const r = await scan('p1-tilted.jpg', [0.05, 0.03, 0.95, 0.97]); await shot('Z01-enhance'); return r; });
  await C('Z02-pdf-at-cap', () => dl(/^Download PDF/, 'Z02'));
  await C('Z03-png-at-cap', () => dl('Download PNG', 'Z03'));
  await C('Z04-searchable-at-cap', () => dl('Download searchable PDF', 'Z04'));
  await C('Z05-canvas-dataurl', () => p.evaluate(() => { const cv = document.querySelector('main canvas'); try { return { len: cv.toDataURL('image/png').length, w: cv.width, h: cv.height }; } catch (e) { return { err: e.message }; } }));
  await C('Z06-add-page-at-cap', async () => { const n = await tc(); await btn('Add page').click(); await p.waitForTimeout(1500); return { used: await used(), dialog: await dialog(), toasts: await toasts(n), text: (await p.locator('main [data-testid=scan-pages]').innerText().catch(() => null)) }; });
  await C('Z07-scan-p2', () => scan('p2-tilted.jpg', null));
  await C('Z08-edit-as-word', async () => { const before = await used(); await btn('Edit as Word').click(); await p.waitForTimeout(6000); const t = await p.evaluate(() => document.querySelector('main').innerText); await shot('Z08-word-handoff'); return { before, url: p.url(), dialog: await dialog(), usedNow: await used(), text: t.slice(0, 1200) }; });
  await C('Z09-edit-as-excel', async () => { await p.goto(URL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); await scan('p6-straight.png', null, true); await btn('Edit as Excel').click(); await p.waitForTimeout(6000); await shot('Z09-excel-handoff'); return { url: p.url(), h1: await p.locator('h1').first().innerText().catch(() => null) }; });
  R.end = await used(); R.net = net;
 } else if (mode === 'quickbuy') { await open(); R.start = await used();
  for (const [i, lab] of [[0, 'day'], [1, 'monthly']]) await C('Q-' + lab, async () => { const pg = await c.newPage(); await pg.goto(URL, { waitUntil: 'domcontentloaded' }); await pg.waitForTimeout(4500); const pp = c.waitForEvent('page', { timeout: 8000 }).catch(() => null); await pg.locator('main button', { hasText: 'Quick Buy' }).nth(i).click(); await pg.waitForTimeout(6000); const np = await pp; const tgt = np || pg; await tgt.waitForTimeout(2000); await tgt.screenshot({ path: OUT + 'quickbuy-' + lab + sfx + '.png' }); const d = await pg.locator('[role=dialog]').first().innerText().catch(() => null); return { url: red(tgt.url()), dialog: d ? d.replace(/\s*\n\s*/g, ' | ').slice(0, 400) : null }; });
 } else if (mode === 'left') { if (await findLeft()) { R.start = { used: await used(), strip: await strip() };
   await C('L01-p1', async () => { const r = await scan('p1-tilted.jpg', null); await shot('L01-enhance'); const n = await tc(); await btn('Add page').click(); await p.waitForTimeout(1500); r.add = { used: await used(), toasts: await toasts(n) }; return r; });
   await C('L02-p2', async () => { const r = await scan('p2-tilted.jpg', null); const n = await tc(); await btn('Add page').click(); await p.waitForTimeout(1500); r.add = { used: await used(), toasts: await toasts(n) }; return r; });
   await C('L03-reorder-remove', async () => { const t0 = await p.locator('main [data-testid=scan-pages]').innerText(); await p.locator('main button[aria-label="Move page 2 up"]').click(); await p.waitForTimeout(300); await shot('L03-list'); return { list: t0.replace(/\n/g, ' | ') }; });
   await C('L04-p3-shadow-letter', async () => { const r = await scan('p4-shadow.jpg', null); await p.locator('main select').first().selectOption('letter'); await p.waitForTimeout(800); await shot('L04-enhance'); r.pdfLabel = await btn(/^Download PDF/).innerText(); return r; });
   await C('L05-pdf-3pages', () => dl(/^Download PDF/, 'L05'));
   await C('L06-png-same', () => dl('Download PNG', 'L06'));
   await C('L07-searchable-after', () => dl('Download searchable PDF', 'L07'));
   R.end = await used(); R.net = net; } }
 else if (mode === 'leftB') { if (await findLeft()) { R.start = { used: await used(), strip: await strip() };
   await C('B01-id-front', async () => { await p.locator('main [data-testid=scan-idmode] input').check(); const r = await scan('id-front.jpg', null); const n = await tc(); await btn('Add page').click(); await p.waitForTimeout(1500); r.add = { toasts: await toasts(n), text: await p.locator('main [data-testid=scan-pages]').innerText().catch(() => null) }; await shot('B01-after-front'); return r; });
   await C('B02-id-back', async () => { const r = await scan('id-back.jpg', null); await shot('B02-enhance'); return r; });
   await C('B03-id-pdf', () => dl(/^Download PDF/, 'B03'));
   await C('B04-new-p6-fit', async () => { await btn(/^New$/).click(); await p.waitForTimeout(800); await p.locator('main [data-testid=scan-idmode] input').uncheck().catch(() => { }); const r = await scan('p6-straight.png', null, true); await p.locator('main select').first().selectOption('fit'); r.langs = await p.locator('main [data-testid=scan-more] select').first().evaluate(s => [...s.options].map(o => o.value).join(',')).catch(() => null); return r; });
   await C('B05-searchable', () => dl('Download searchable PDF', 'B05'));
   await C('B06-png-after', () => dl('Download PNG', 'B06'));
   R.end = await used(); R.net = net; } }
 else if (mode === 'perload') { if (await findLeft()) { R.start = { used: await used(), strip: await strip() };
   for (const [id, f] of [['P1', 'p1-tilted.jpg'], ['P2', 'p2-tilted.jpg'], ['P3', 'p3-tilted.jpg'], ['P4', 'p4-shadow.jpg']]) {
    await C(id + '-scan', () => scan(f, null)); await C(id + '-pdf', () => dl(/^Download PDF/, id)); R.cases[id + '-pdf'].strip = await strip(); await btn(/^New$/).click(); await p.waitForTimeout(800); }
   await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); R.afterReload = { used: await used(), strip: await strip() };
   await C('P5-scan-after-reload', () => scan('p6-straight.png', null, true)); await C('P5-pdf', () => dl(/^Download PDF/, 'P5'));
   R.end = await used(); R.net = net; } }
 else if (mode === 'idcard') { if (await findLeft()) { R.start = { used: await used(), strip: await strip() };
   await C('I01-front', async () => { await p.locator('main [data-testid=scan-idmode] input').check(); const r = await scan('id-front.jpg', null); r.addLabel = await btn(/^Add front/).innerText(); const n = await tc(); await btn(/^Add front/).click(); await p.waitForTimeout(1500); r.add = { toasts: await toasts(n), text: await p.locator('main [data-testid=scan-pages]').innerText().catch(() => null) }; await shot('I01-after-front'); return r; });
   await C('I02-back', async () => { const r = await scan('id-back.jpg', null); r.pdfLabel = await btn(/^Download PDF/).innerText(); r.addLabel = await btn(/^Add/).innerText().catch(() => null); await shot('I02-enhance'); return r; });
   await C('I03-id-pdf', () => dl(/^Download PDF/, 'I03'));
   R.end = await used(); R.net = net; } }
 else if (mode === 'msgs') { await open(); R.start = await used();
  for (const [id, f, skip] of [['M01', 'p8-small-300px.jpg'], ['M02', 'p9-lowcontrast.png', true], ['M03', 'p10-darkpage.png', true], ['M04', 'p5-lightdesk.jpg'], ['M05', 'p7-exif-orient6.jpg'], ['M06', 'p11-big-6000.jpg'], ['M07', 'p4-shadow.jpg']]) {
   await C(id, async () => { const t0 = Date.now(); const r = await scan(f, null, skip); r.ms = Date.now() - t0; await shot(id); await btn(/^New$/).click(); await p.waitForTimeout(800); return r; }); }
  await C('M08-not-image', async () => { const n = await tc(); await upload('notanimage.jpg'); await shot('M08'); return { toasts: await toasts(n), status: await status(), cropVisible: await p.locator('main img[alt="Document photo"]').count() }; });
  R.end = await used(); R.net = net; }
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', JSON.stringify(R.tries), JSON.stringify(R.start || '').slice(0, 300), R.end); await b.close(); })();
