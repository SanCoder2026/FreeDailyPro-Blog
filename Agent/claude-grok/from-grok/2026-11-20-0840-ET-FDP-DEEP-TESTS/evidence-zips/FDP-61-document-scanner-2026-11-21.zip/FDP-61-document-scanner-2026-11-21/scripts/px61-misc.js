// FDP-61 misc (guest): Google Drive button (stop at sign-in), camera button attrs, Share, Edit as Excel handoff URL, corner handles keyboard reach. No sign-in, no downloads.
const { chromium } = require('playwright'); const fs = require('fs'); const O = '/workspace/deep/61-document-scanner/live/'; const TF = '/workspace/deep/61-document-scanner/testfiles/'; const URL = 'https://www.freedailypro.com/tool/document-scanner';
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh|scope|origin|login_hint)=[^&]*/g, '$1=REDACTED').slice(0, 200);
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 1000 } }); const p = await c.newPage(); p.setDefaultTimeout(15000); const R = {};
 const go = async () => { await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 await go();
 R.camera = await p.evaluate(() => [...document.querySelectorAll('main input[type=file]')].map(i => ({ accept: i.accept, capture: i.getAttribute('capture'), multiple: i.multiple })));
 try { const fc = p.waitForEvent('filechooser', { timeout: 5000 }).then(f => ({ multiple: f.isMultiple() })).catch(() => null); await p.locator('main button', { hasText: 'Take photo with camera' }).click(); R.cameraChooser = await fc; } catch (e) { R.cameraChooser = e.message.slice(0, 100); }
 try { const pp = c.waitForEvent('page', { timeout: 8000 }).catch(() => null); await p.locator('main button', { hasText: 'Open from Google Drive' }).click(); await p.waitForTimeout(5000); const np = await pp; if (np) { await np.waitForTimeout(3000); R.drive = { popup: red(np.url()), title: await np.title().catch(() => null) }; await np.screenshot({ path: O + 'drive-popup.png' }); await np.close(); } else { R.drive = { samePage: red(p.url()), dialog: await p.locator('[role=dialog]').first().innerText().catch(() => null) }; await p.screenshot({ path: O + 'drive-click.png' }); } } catch (e) { R.drive = e.message.slice(0, 150); }
 await go();
 try { await p.locator('main button', { hasText: 'Share this tool' }).click(); await p.waitForTimeout(1500); R.share = (await p.locator('[role=dialog],[role=menu]').first().innerText().catch(() => null)); await p.screenshot({ path: O + 'share.png' }); await p.keyboard.press('Escape'); } catch (e) { R.share = e.message.slice(0, 100); }
 await go(); await p.locator('main input[type=file][accept="image/*"]').first().setInputFiles(TF + 'p1-tilted.jpg'); await p.waitForTimeout(2500); await p.locator('main button', { hasText: /^Continue$/ }).click(); await p.waitForTimeout(2500);
 R.handles = await p.evaluate(() => [...document.querySelectorAll('main .cursor-grab')].map(h => ({ tab: h.tabIndex, role: h.getAttribute('role'), label: h.getAttribute('aria-label') })));
 await p.locator('main').screenshot({ path: O + 'straighten-step.png' }).catch(() => { });
 const box = p.locator('main div.select-none').first(); await box.screenshot({ path: O + 'cases/straighten-handles.png' }).catch(() => { });
 R.straightenMsg = await p.locator('main').getByText(/Page found automatically|Couldn.t find/).first().innerText().catch(() => null);
 await p.locator('main button', { hasText: /^Straighten$/ }).click(); await p.waitForTimeout(2500);
 await p.locator('main button', { hasText: 'Edit as Excel' }).click(); await p.waitForTimeout(5000); R.excel = { url: p.url(), h1: await p.locator('h1').first().innerText().catch(() => null) }; await p.screenshot({ path: O + 'cases/Z09-excel-handoff.png' });
 const r2 = await (await c.newPage()).goto('https://www.freedailypro.com/tool/image-to-word'); R.correctPathStatus = r2.status();
 fs.writeFileSync(O + 'misc.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
