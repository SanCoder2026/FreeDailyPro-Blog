// FDP-61: phone flow at the cap (no downloads): iPhone 13 (WebKit) and Pixel 7 (Chromium): upload, touch-drag a crop, Continue, Straighten, Enhance screenshot, Download PDF -> dialog.
const pw = require('playwright'); const fs = require('fs'); const O = '/workspace/deep/61-document-scanner/live/'; const TF = '/workspace/deep/61-document-scanner/testfiles/';
(async () => { const R = {}; for (const [eng, dev] of [['webkit', 'iPhone 13'], ['chromium', 'Pixel 7']]) { const b = await pw[eng].launch(); const c = await b.newContext({ ...pw.devices[dev] }); const p = await c.newPage(); p.setDefaultTimeout(15000); const r = R[dev] = {};
 try { await p.goto('https://www.freedailypro.com/tool/document-scanner', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500);
  r.used = await p.evaluate(() => JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}').usageToday);
  await p.locator('main input[type=file][accept="image/*"]').first().setInputFiles(TF + 'p1-tilted.jpg'); await p.waitForTimeout(3000);
  const img = p.locator('main img[alt="Document photo"]'); await img.scrollIntoViewIfNeeded(); const bb = await img.boundingBox();
  const cdp = eng === 'chromium' ? await c.newCDPSession(p) : null;
  if (cdp) { const tp = (type, x, y) => cdp.send('Input.dispatchTouchEvent', { type, touchPoints: type === 'touchEnd' ? [] : [{ x, y }] }); await tp('touchStart', bb.x + bb.width * .1, bb.y + bb.height * .05); for (let i = 1; i <= 8; i++) await tp('touchMove', bb.x + bb.width * (.1 + .08 * i), bb.y + bb.height * (.05 + .11 * i)); await tp('touchEnd'); r.touchCrop = await p.evaluate(() => !!document.querySelector('main .border-primary.pointer-events-none')); }
  await p.screenshot({ path: O + 'cases/mobile-crop-' + eng + '.png' });
  await p.locator('main button', { hasText: /^Continue$/ }).click(); await p.waitForTimeout(2500); await p.screenshot({ path: O + 'cases/mobile-straighten-' + eng + '.png' });
  await p.locator('main button', { hasText: /^Straighten$/ }).click(); await p.waitForTimeout(2500); await p.locator('main canvas').scrollIntoViewIfNeeded(); await p.screenshot({ path: O + 'cases/mobile-enhance-' + eng + '.png' });
  r.canvas = await p.evaluate(() => { const c = document.querySelector('main canvas'); return [c.width, c.height]; });
  await p.locator('main button', { hasText: /^Download PDF/ }).click(); await p.waitForTimeout(2000); r.dialog = await p.locator('[role=dialog]').first().innerText().then(t => t.slice(0, 80)).catch(() => null); await p.screenshot({ path: O + 'cases/mobile-dialog-' + eng + '.png' });
  r.sw = await p.evaluate(() => document.documentElement.scrollWidth); } catch (e) { r.err = e.message.slice(0, 200); }
 console.log(dev, JSON.stringify(r)); await b.close(); } fs.writeFileSync(O + 'mobile.json', JSON.stringify(R, null, 1)); })();
