// FDP-61: EXIF orientation 6 and not-an-image at the Crop step, per engine (guest, no downloads)
const pw = require('playwright'); const fs = require('fs'); const O = '/workspace/deep/61-document-scanner/live/'; const TF = '/workspace/deep/61-document-scanner/testfiles/';
(async () => { const R = {}; for (const eng of ['chromium', 'firefox', 'webkit']) { const b = await pw[eng].launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 1000 } })).newPage(); p.setDefaultTimeout(15000);
 try { for (const f of ['p7-exif-orient6.jpg', 'notanimage.jpg']) { await p.goto('https://www.freedailypro.com/tool/document-scanner', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4000);
  await p.locator('main input[type=file][accept="image/*"]').first().setInputFiles(TF + f); await p.waitForTimeout(3000); const img = p.locator('main img[alt="Document photo"]');
  const info = await img.evaluate(i => ({ nw: i.naturalWidth, nh: i.naturalHeight, src: i.src.slice(0, 30) })).catch(e => 'noimg');
  const box = p.locator('main div.cursor-crosshair').first(); if (await box.count()) await box.screenshot({ path: O + 'cases/orient-' + f.split('.')[0] + '-' + eng + '.png' });
  const txt = await p.evaluate(() => document.querySelector('main').innerText.match(/Drag to crop[^\n]*|This photo[^\n]*|Couldn[^\n]*|not an image[^\n]*/gi));
  R[eng + ' ' + f] = { info, txt, toasts: await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(n => n.innerText)) }; } } catch (e) { R[eng] = e.message.slice(0, 200); }
 console.log(eng, JSON.stringify(R)); await b.close(); } fs.writeFileSync(O + 'orient.json', JSON.stringify(R, null, 1)); })();
