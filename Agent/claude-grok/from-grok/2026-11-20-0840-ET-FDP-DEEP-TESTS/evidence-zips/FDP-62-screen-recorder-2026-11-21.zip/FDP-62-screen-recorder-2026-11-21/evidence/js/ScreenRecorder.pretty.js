import { r as a, j as t } from "./vendor-react-D01g8YgM.js";
import { T as _e, D as He } from "./ToolPage-DwLoDncN.js";
import {
  v as Ge,
  N as Ie,
  ds as Ee,
  a$ as Oe,
  B as I,
  a_ as Qe,
  f as V,
} from "./index-B1CTyGtY.js";
import { C as Je } from "./card-KXKUZKW8.js";
import { T as Ke } from "./ToolInfoSection-C0i6Zbwo.js";
import { g as ye } from "./mediaPermissions-Bds5TGtW.js";
import { C as Ze } from "./crop-D1wtdRSb.js";
import { M as et } from "./maximize-DddpxYaC.js";
import { P as tt } from "./pause-D6USnVqY.js";
import { S as rt } from "./square-DmBnvOHU.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
const nt = Ge("MicOff", [
    ["line", { x1: "2", x2: "22", y1: "2", y2: "22", key: "a6p6uj" }],
    ["path", { d: "M18.89 13.23A7.12 7.12 0 0 0 19 12v-2", key: "80xlxr" }],
    ["path", { d: "M5 10v2a7 7 0 0 0 12 5", key: "p2k8kg" }],
    ["path", { d: "M15 9.34V5a3 3 0 0 0-5.68-1.33", key: "1gzdoj" }],
    ["path", { d: "M9 9v3a3 3 0 0 0 5.12 2.12", key: "r2i35w" }],
    ["line", { x1: "12", x2: "12", y1: "19", y2: "22", key: "x3vr5v" }],
  ]),
  J = (r) => Math.max(2, Math.round(r / 2) * 2);
function ot(r, n, c, d) {
  if (!(r > 0) || !(n > 0) || !(c > 0) || !(d > 0))
    return { x: 0, y: 0, w: Math.max(r, 1), h: Math.max(n, 1) };
  const T = Math.min(r / c, n / d),
    E = c * T,
    R = d * T;
  return { x: (r - E) / 2, y: (n - R) / 2, w: E, h: R };
}
function at(r, n, c) {
  const d = ot(n.w, n.h, c.w, c.h),
    T = c.w / d.w,
    E = c.h / d.h,
    R = Math.max(r.x, d.x),
    K = Math.max(r.y, d.y),
    Z = Math.min(r.x + r.w, d.x + d.w),
    ee = Math.min(r.y + r.h, d.y + d.h),
    O = (re) => Math.max(0, Math.floor(re / 2) * 2);
  let C = O((R - d.x) * T),
    p = O((K - d.y) * E),
    A = J(Math.max(0, Z - R) * T),
    w = J(Math.max(0, ee - K) * E);
  const le = Math.max(2, Math.floor(c.w / 2) * 2),
    te = Math.max(2, Math.floor(c.h / 2) * 2);
  return (
    (A = Math.min(A, le)),
    (w = Math.min(w, te)),
    (C = Math.min(C, c.w - A)),
    (p = Math.min(p, c.h - w)),
    (C = Math.max(0, Math.floor(C / 2) * 2)),
    (p = Math.max(0, Math.floor(p / 2) * 2)),
    { x: C, y: p, w: A, h: w }
  );
}
class st {
  constructor() {
    ((this.startedAt = null), (this.banked = 0));
  }
  start(n) {
    ((this.startedAt = n), (this.banked = 0));
  }
  pause(n) {
    this.startedAt !== null &&
      ((this.banked += n - this.startedAt), (this.startedAt = null));
  }
  resume(n) {
    this.startedAt === null && (this.startedAt = n);
  }
  elapsedMs(n) {
    return this.banked + (this.startedAt === null ? 0 : n - this.startedAt);
  }
  stop(n) {
    return (this.pause(n), this.banked);
  }
  reset() {
    ((this.startedAt = null), (this.banked = 0));
  }
}
const Pe = (r) => Math.floor(r / 1e3),
  ct = (r) => Math.round(r / 1e3);
function it() {
  const r = [
    "video/mp4;codecs=avc1.42E01E,mp4a.40.2",
    "video/mp4;codecs=avc1,mp4a.40.2",
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm",
    "video/mp4",
  ];
  for (const n of r)
    if (typeof MediaRecorder < "u" && MediaRecorder.isTypeSupported(n))
      return n;
  return "";
}
const be = {
    what: "Records your screen, a specific application window, or a browser tab directly from your browser, with optional microphone audio. After choosing what to share, optionally drag to select just a region of it to record, instead of the whole thing.",
    how: `Click start recording and choose what to share (screen, window, or tab) in the browser's sharing prompt. A live preview appears — drag to select just the region you want recorded, or click "Record Full Capture" to skip that and record everything. Use the pause and stop controls as needed, then download the finished recording.`,
    tip: "Turn on the microphone toggle before you start recording if you want narration included — it can't be added retroactively to a recording that's already finished. Recording just a selected region re-draws each frame through a canvas before recording it, which uses a bit more processing than recording the raw capture directly — for very long recordings on an older machine, recording the full capture (and trimming the start and end afterward with the Trim Video tool if needed) may perform better.",
  },
  lt = (r) => {
    const n = new Date(),
      c = (d) => String(d).padStart(2, "0");
    return `screen-recording-${n.getFullYear()}-${c(n.getMonth() + 1)}-${c(n.getDate())}_${c(n.getHours())}-${c(n.getMinutes())}.${r}`;
  };
function Bt() {
  const [r, n] = a.useState("idle"),
    [c, d] = a.useState(!0),
    [T, E] = a.useState([]),
    [R, K] = a.useState(""),
    [Z, ee] = a.useState(0),
    O = a.useRef(null),
    C = async () => {
      try {
        if (
          !navigator.mediaDevices ||
          !("enumerateDevices" in navigator.mediaDevices)
        )
          return;
        const e = await navigator.mediaDevices.enumerateDevices();
        E(
          e
            .filter((o) => o.kind === "audioinput" && o.deviceId)
            .map((o, s) => ({
              id: o.deviceId,
              label: o.label || `Microphone ${s + 1}`,
            })),
        );
      } catch {}
    };
  a.useEffect(() => {
    c && C();
  }, [c]);
  const [p, A] = a.useState(!0),
    [w, le] = a.useState(!0),
    [te, re] = a.useState(0),
    f = a.useRef(null),
    [Me, je] = a.useState(null),
    [z, ke] = a.useState(null),
    [de, Y] = a.useState(0),
    P = a.useRef(null),
    q = a.useRef(null),
    v = a.useRef(null),
    ne = a.useRef([]),
    B = a.useRef(null),
    oe = a.useRef(null),
    W = a.useRef(null),
    D = a.useRef(null),
    y = a.useRef(new st()),
    S = a.useRef(null),
    b = a.useRef(null),
    _ = a.useRef(null),
    ae = a.useRef(null);
  (a.useEffect(() => {
    if (r !== "selecting") return;
    const e = oe.current;
    e && P.current && ((e.srcObject = P.current), e.play().catch(() => {}));
  }, [r]),
    a.useEffect(() => {
      if (r !== "recording" && r !== "paused") return;
      const e = B.current;
      e &&
        _.current &&
        e.srcObject !== _.current &&
        ((e.srcObject = _.current), e.play().catch(() => {}));
    }, [r]));
  const [m, X] = a.useState(null),
    [M, ue] = a.useState(null),
    Re = () => {
      (D.current && clearInterval(D.current),
        (D.current = setInterval(
          () => Y(Pe(y.current.elapsedMs(performance.now()))),
          250,
        )));
    },
    me = () => {
      D.current && (clearInterval(D.current), (D.current = null));
    },
    se = a.useRef(null),
    [he, pe] = a.useState(!1),
    Fe = async () => {
      if (p) {
        (f.current?.getTracks().forEach((e) => e.stop()),
          (f.current = null),
          pe(!1),
          A(!1));
        return;
      }
      try {
        const e = await navigator.mediaDevices.getUserMedia({
          video: { width: 640, height: 480 },
        });
        ((f.current = e), A(!0), pe(!0));
      } catch (e) {
        (A(!1), V.error(ye(e, "camera"), { duration: 8e3 }));
      }
    };
  (a.useEffect(() => {
    he &&
      se.current &&
      f.current &&
      ((se.current.srcObject = f.current), se.current.play().catch(() => {}));
  }, [he, r]),
    a.useEffect(
      () => () => {
        try {
          v.current &&
            v.current.state !== "inactive" &&
            ((v.current.onstop = null), v.current.stop());
        } catch {}
        (b.current && (b.current.postMessage("stop"), (b.current = null)),
          S.current && cancelAnimationFrame(S.current),
          D.current && clearInterval(D.current),
          P.current?.getTracks().forEach((e) => e.stop()),
          q.current?.getTracks().forEach((e) => e.stop()),
          f.current?.getTracks().forEach((e) => e.stop()));
      },
      [],
    ));
  const H = () => {
      (O.current && cancelAnimationFrame(O.current),
        (O.current = null),
        ee(0),
        P.current?.getTracks().forEach((e) => e.stop()),
        q.current?.getTracks().forEach((e) => e.stop()),
        f.current?.getTracks().forEach((e) => e.stop()),
        (f.current = null),
        pe(!1),
        (P.current = null),
        (q.current = null));
    },
    $e = async () => {
      if (typeof navigator > "u" || !navigator.mediaDevices?.getDisplayMedia) {
        V.error("Screen recording isn't supported in this browser");
        return;
      }
      try {
        const e = await navigator.mediaDevices.getDisplayMedia({
          video: { frameRate: 30 },
          audio: !0,
        });
        ((P.current = e),
          X(null),
          (e.getVideoTracks()[0].onended = () => {
            v.current && v.current.state !== "inactive"
              ? Te()
              : (H(), n("idle"));
          }),
          n("selecting"));
      } catch {
        V.error(
          "Screen recording wasn't started (permission denied or cancelled)",
        );
      }
    },
    fe = (e, o) => {
      const s = W.current?.getBoundingClientRect();
      return s
        ? {
            x: Math.max(0, Math.min(s.width, e - s.left)),
            y: Math.max(0, Math.min(s.height, o - s.top)),
          }
        : { x: 0, y: 0 };
    },
    Se = (e) => fe(e.clientX, e.clientY),
    Ue = (e) => {
      const o = Se(e);
      (ue(o), X({ x: o.x, y: o.y, w: 0, h: 0 }));
    },
    Le = (e) => {
      if (!M) return;
      const o = Se(e);
      X({
        x: Math.min(M.x, o.x),
        y: Math.min(M.y, o.y),
        w: Math.abs(o.x - M.x),
        h: Math.abs(o.y - M.y),
      });
    },
    ce = () => ue(null),
    Ve = (e) => {
      if (e.touches.length === 0) return;
      const o = e.touches[0],
        s = fe(o.clientX, o.clientY);
      (ue(s), X({ x: s.x, y: s.y, w: 0, h: 0 }));
    },
    ze = (e) => {
      if (!M || e.touches.length === 0) return;
      e.preventDefault();
      const o = e.touches[0],
        s = fe(o.clientX, o.clientY);
      X({
        x: Math.min(M.x, s.x),
        y: Math.min(M.y, s.y),
        w: Math.abs(s.x - M.x),
        h: Math.abs(s.y - M.y),
      });
    },
    Ne = async (e) => {
      const o = P.current;
      if (o)
        try {
          let s = null,
            F = null;
          if (c)
            try {
              const i = await navigator.mediaDevices.getUserMedia({
                audio: R ? { deviceId: { exact: R } } : !0,
              });
              ((q.current = i),
                C(),
                (F = new AudioContext()),
                (s = F.createMediaStreamDestination()),
                o.getAudioTracks().length > 0 &&
                  F.createMediaStreamSource(o).connect(s));
              const h = F.createMediaStreamSource(i);
              h.connect(s);
              const g = F.createAnalyser();
              ((g.fftSize = 512), h.connect(g));
              const N = new Uint8Array(g.fftSize),
                U = () => {
                  g.getByteTimeDomainData(N);
                  let L = 0;
                  for (let j = 0; j < N.length; j++)
                    L += ((N[j] - 128) / 128) ** 2;
                  (ee(Math.min(1, Math.sqrt(L / N.length) * 4)),
                    (O.current = requestAnimationFrame(U)));
                };
              U();
            } catch (i) {
              V.error(
                `${ye(i, "microphone")} Recording video + system audio only.`,
                { duration: 8e3 },
              );
            }
          let G;
          const Ae = !!(
            e &&
            m &&
            m.w >= 20 &&
            m.h >= 20 &&
            oe.current &&
            W.current
          );
          let u = null;
          if (p)
            try {
              const h =
                (f.current &&
                f.current.getVideoTracks().some((g) => g.readyState === "live")
                  ? f.current
                  : null) ??
                (await navigator.mediaDevices.getUserMedia({
                  video: { width: 640, height: 480 },
                }));
              ((f.current = h),
                (u = document.createElement("video")),
                (u.muted = !0),
                (u.playsInline = !0),
                (u.srcObject = h),
                await u.play().catch(() => {}));
              for (let g = 0; g < 20 && !u.videoWidth; g++)
                await new Promise((N) => setTimeout(N, 100));
              u.videoWidth ||
                (V.error(
                  "The camera is on but sent no picture. Recording the screen without it.",
                  { duration: 8e3 },
                ),
                (u = null));
            } catch (i) {
              V.error(
                `${ye(i, "camera")} Recording the screen without the camera.`,
                { duration: 8e3 },
              );
            }
          if (w) {
            for (let i = 3; i > 0; i--)
              (re(i), await new Promise((h) => setTimeout(h, 1e3)));
            re(0);
          }
          if (Ae || u) {
            const i = oe.current,
              h = J;
            let g = 0,
              N = 0,
              U = h(
                i?.videoWidth ||
                  o.getVideoTracks()[0].getSettings().width ||
                  1280,
              ),
              L = h(
                i?.videoHeight ||
                  o.getVideoTracks()[0].getSettings().height ||
                  720,
              );
            if (Ae && i && W.current && m) {
              const l = at(
                m,
                { w: W.current.clientWidth, h: W.current.clientHeight },
                { w: i.videoWidth, h: i.videoHeight },
              );
              ((g = l.x), (N = l.y), (U = l.w), (L = l.h));
            }
            const j = document.createElement("video");
            ((j.muted = !0),
              (j.playsInline = !0),
              (j.srcObject = o),
              await j.play().catch(() => {}),
              (ae.current = j));
            const k = document.createElement("canvas"),
              De = Math.min(1, 3840 / U, 2160 / L);
            ((k.width = J(U * De)), (k.height = J(L * De)));
            const x = k.getContext("2d"),
              xe = () => {
                if (
                  (x.drawImage(j, g, N, U, L, 0, 0, k.width, k.height),
                  u && u.videoWidth)
                ) {
                  const l = Math.round(Math.min(k.width, k.height) * 0.24),
                    Q = Math.round(l * 0.12),
                    we = k.width - Q - l / 2,
                    ve = k.height - Q - l / 2,
                    ie = Math.min(u.videoWidth, u.videoHeight);
                  (x.save(),
                    x.beginPath(),
                    x.arc(we, ve, l / 2, 0, Math.PI * 2),
                    x.clip(),
                    x.drawImage(
                      u,
                      (u.videoWidth - ie) / 2,
                      (u.videoHeight - ie) / 2,
                      ie,
                      ie,
                      we - l / 2,
                      ve - l / 2,
                      l,
                      l,
                    ),
                    x.restore(),
                    x.beginPath(),
                    x.arc(we, ve, l / 2, 0, Math.PI * 2),
                    (x.lineWidth = Math.max(2, l * 0.03)),
                    (x.strokeStyle = "#fff"),
                    x.stroke());
                }
              };
            xe();
            try {
              const l =
                  "let t=setInterval(()=>postMessage(0),33);onmessage=()=>{clearInterval(t);close()}",
                Q = new Worker(
                  URL.createObjectURL(
                    new Blob([l], { type: "text/javascript" }),
                  ),
                );
              ((Q.onmessage = xe), (b.current = Q));
            } catch {
              const l = () => {
                (xe(), (S.current = requestAnimationFrame(l)));
              };
              l();
            }
            const Ye = k.captureStream(30),
              qe = s ? s.stream.getAudioTracks() : o.getAudioTracks();
            G = new MediaStream([...Ye.getVideoTracks(), ...qe]);
          } else {
            const i = s ? s.stream.getAudioTracks() : o.getAudioTracks();
            G = new MediaStream([...o.getVideoTracks(), ...i]);
          }
          ((_.current = G), B.current && (B.current.srcObject = G));
          const ge = it();
          ne.current = [];
          const $ = new MediaRecorder(G, ge ? { mimeType: ge } : void 0);
          (($.ondataavailable = (i) => {
            i.data.size > 0 && ne.current.push(i.data);
          }),
            ($.onstop = () => {
              const i = new Blob(ne.current, { type: ge || "video/webm" });
              (ke(i),
                je(
                  (h) => (h && URL.revokeObjectURL(h), URL.createObjectURL(i)),
                ),
                (ne.current = []),
                S.current &&
                  (cancelAnimationFrame(S.current), (S.current = null)),
                b.current &&
                  (b.current.postMessage("stop"), (b.current = null)),
                ae.current &&
                  ((ae.current.srcObject = null), (ae.current = null)),
                (_.current = null),
                F && F.close().catch(() => {}),
                H(),
                me());
            }),
            ($.onstart = () => {
              (y.current.start(performance.now()), Re());
            }),
            ($.onpause = () => y.current.pause(performance.now())),
            ($.onresume = () => y.current.resume(performance.now())),
            (v.current = $),
            y.current.reset(),
            $.start(),
            n("recording"),
            Y(0));
        } catch (s) {
          (console.error("Failed to start recording:", s),
            V.error("Couldn't start recording. Try again."),
            H(),
            n("idle"));
        }
    },
    Be = () => {
      (v.current?.pause(),
        y.current.pause(performance.now()),
        n("paused"),
        me(),
        Y(Pe(y.current.elapsedMs(performance.now()))));
    },
    We = () => {
      (v.current?.resume(),
        y.current.resume(performance.now()),
        n("recording"),
        Re());
    },
    Te = () => {
      const e = v.current;
      if (!e || e.state === "inactive") return;
      const o = y.current.stop(performance.now());
      (me(),
        Y(ct(o)),
        S.current && (cancelAnimationFrame(S.current), (S.current = null)),
        b.current && (b.current.postMessage("stop"), (b.current = null)),
        B.current && (B.current.srcObject = null));
      try {
        e.stop();
      } catch (s) {
        (console.error("Recorder stop failed:", s), H());
      }
      n("stopped");
    },
    Xe = () => {
      (n("idle"), je(null), ke(null), y.current.reset(), Y(0), X(null));
    },
    Ce = (e) => {
      const o = Math.floor(e / 60)
          .toString()
          .padStart(2, "0"),
        s = (e % 60).toString().padStart(2, "0");
      return `${o}:${s}`;
    };
  return t.jsxs(_e, {
    children: [
      r === "idle" &&
        typeof navigator < "u" &&
        !navigator.mediaDevices?.getDisplayMedia &&
        t.jsx(Ie, {
          className: "mb-4 text-sm",
          children:
            "Screen recording works in desktop browsers (Chrome, Edge, Firefox, Safari on a computer). Phone browsers don't allow it — on your phone, use the built-in screen recorder (swipe down for Control Centre on iPhone, or Quick Settings on Android), then bring the video back here to trim, compress or convert it.",
        }),
      r === "idle" &&
        t.jsxs("div", {
          className:
            "text-center py-12 border-2 border-dashed border-border rounded-xl",
          children: [
            t.jsx(Ee, {
              className: "h-10 w-10 mx-auto text-muted-foreground mb-4",
            }),
            t.jsx("p", {
              className: "text-muted-foreground mb-4",
              children:
                "Record your screen, a window, or a browser tab — entirely in your browser. Nothing is uploaded anywhere.",
            }),
            t.jsxs("div", {
              className:
                "flex flex-wrap items-center justify-center gap-2 mb-4",
              children: [
                t.jsxs("button", {
                  onClick: Fe,
                  className: `flex items-center gap-2 px-3 py-1.5 rounded-full border text-sm transition-colors ${p ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground"}`,
                  "aria-pressed": p,
                  children: ["Camera bubble ", p ? "on" : "off"],
                }),
                t.jsxs("button", {
                  onClick: () => le(!w),
                  className: `flex items-center gap-2 px-3 py-1.5 rounded-full border text-sm transition-colors ${w ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground"}`,
                  "aria-pressed": w,
                  children: ["3-2-1 countdown ", w ? "on" : "off"],
                }),
                t.jsxs("button", {
                  onClick: () => d(!c),
                  className: `flex items-center gap-2 px-3 py-1.5 rounded-full border text-sm transition-colors ${c ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground"}`,
                  children: [
                    c
                      ? t.jsx(Oe, { className: "h-3.5 w-3.5" })
                      : t.jsx(nt, { className: "h-3.5 w-3.5" }),
                    c ? "Microphone on" : "Microphone off",
                  ],
                }),
              ],
            }),
            c &&
              T.length > 1 &&
              t.jsxs("div", {
                className:
                  "flex items-center justify-center gap-2 mb-4 text-sm",
                children: [
                  t.jsx("label", {
                    htmlFor: "mic-select",
                    children: "Microphone",
                  }),
                  t.jsxs("select", {
                    id: "mic-select",
                    value: R,
                    onChange: (e) => K(e.target.value),
                    className:
                      "border rounded px-2 py-1 bg-background max-w-[260px]",
                    children: [
                      t.jsx("option", { value: "", children: "Default" }),
                      T.map((e) =>
                        t.jsx(
                          "option",
                          { value: e.id, children: e.label },
                          e.id,
                        ),
                      ),
                    ],
                  }),
                ],
              }),
            p &&
              he &&
              t.jsxs("div", {
                className: "flex flex-col items-center gap-1 mb-4",
                children: [
                  t.jsx("video", {
                    ref: se,
                    muted: !0,
                    playsInline: !0,
                    autoPlay: !0,
                    className:
                      "h-24 w-24 rounded-full object-cover border-2 border-white shadow",
                    style: { transform: "scaleX(-1)" },
                  }),
                  t.jsx("p", {
                    className: "text-xs text-muted-foreground",
                    children:
                      "This round picture will sit in the bottom-right corner of your recording.",
                  }),
                ],
              }),
            t.jsxs(I, {
              onClick: $e,
              size: "lg",
              children: [
                t.jsx(Ee, { className: "h-4 w-4 mr-2" }),
                " Start Recording",
              ],
            }),
          ],
        }),
      te > 0 &&
        t.jsx("div", {
          role: "status",
          "aria-live": "assertive",
          className:
            "fixed inset-0 z-50 flex items-center justify-center bg-black/60 text-white",
          children: t.jsx("span", {
            className: "text-9xl font-bold",
            "data-testid": "countdown",
            children: te,
          }),
        }),
      r === "selecting" &&
        t.jsxs("div", {
          className: "space-y-4",
          children: [
            t.jsxs("div", {
              ref: W,
              className:
                "relative w-full rounded-lg border bg-black max-h-[400px] overflow-hidden cursor-crosshair select-none",
              onMouseDown: Ue,
              onMouseMove: Le,
              onMouseUp: ce,
              onMouseLeave: ce,
              onTouchStart: Ve,
              onTouchMove: ze,
              onTouchEnd: ce,
              onTouchCancel: ce,
              style: { touchAction: "none" },
              children: [
                t.jsx("video", {
                  ref: oe,
                  autoPlay: !0,
                  muted: !0,
                  className: "w-full max-h-[400px] pointer-events-none",
                }),
                m &&
                  m.w >= 4 &&
                  m.h >= 4 &&
                  t.jsx("div", {
                    className:
                      "absolute border-2 border-primary bg-primary/10 pointer-events-none",
                    style: { left: m.x, top: m.y, width: m.w, height: m.h },
                  }),
              ],
            }),
            t.jsx("p", {
              className: "text-xs text-muted-foreground text-center",
              children:
                "Drag across the preview above to select just the region you want to record, or record the full capture without selecting anything.",
            }),
            t.jsxs("div", {
              className: "flex items-center justify-center gap-3 flex-wrap",
              children: [
                m &&
                  m.w >= 20 &&
                  m.h >= 20 &&
                  t.jsxs(I, {
                    onClick: () => Ne(!0),
                    className: "gap-2",
                    children: [
                      t.jsx(Ze, { className: "h-4 w-4" }),
                      " Record Selected Region",
                    ],
                  }),
                t.jsxs(I, {
                  variant: "outline",
                  onClick: () => Ne(!1),
                  className: "gap-2",
                  children: [
                    t.jsx(et, { className: "h-4 w-4" }),
                    " Record Full Capture",
                  ],
                }),
                t.jsx(I, {
                  variant: "ghost",
                  onClick: () => {
                    (H(), n("idle"));
                  },
                  children: "Cancel",
                }),
              ],
            }),
          ],
        }),
      (r === "recording" || r === "paused") &&
        t.jsxs("div", {
          className: "space-y-4",
          children: [
            t.jsx("video", {
              ref: B,
              autoPlay: !0,
              muted: !0,
              className: "w-full rounded-lg border bg-black max-h-[400px]",
            }),
            t.jsxs("div", {
              className: "flex items-center justify-center gap-4",
              children: [
                t.jsxs(Je, {
                  className: "px-4 py-2 flex items-center gap-2",
                  children: [
                    t.jsx("span", {
                      className: `w-2.5 h-2.5 rounded-full ${r === "recording" ? "bg-red-500 animate-pulse" : "bg-amber-500"}`,
                    }),
                    t.jsx("span", {
                      className: "font-mono font-medium",
                      children: Ce(de),
                    }),
                  ],
                }),
                c &&
                  q.current &&
                  t.jsxs("div", {
                    className: "flex items-center gap-2",
                    title: "Microphone level",
                    children: [
                      t.jsx(Oe, { className: "h-3.5 w-3.5" }),
                      t.jsx("div", {
                        className: "h-2 w-24 rounded bg-muted overflow-hidden",
                        role: "meter",
                        "aria-label": "Microphone level",
                        "aria-valuemin": 0,
                        "aria-valuemax": 100,
                        "aria-valuenow": Math.round(Z * 100),
                        "data-testid": "mic-meter",
                        children: t.jsx("div", {
                          className:
                            "h-full bg-green-500 transition-[width] duration-75",
                          style: { width: `${Z * 100}%` },
                        }),
                      }),
                    ],
                  }),
                de >= 1800 &&
                  t.jsx("span", {
                    className: "text-xs text-amber-600",
                    children:
                      "Long recording: stop and save soon so the file stays manageable.",
                  }),
                r === "recording"
                  ? t.jsxs(I, {
                      variant: "outline",
                      onClick: Be,
                      children: [
                        t.jsx(tt, { className: "h-4 w-4 mr-2" }),
                        " Pause",
                      ],
                    })
                  : t.jsxs(I, {
                      variant: "outline",
                      onClick: We,
                      children: [
                        t.jsx(Qe, { className: "h-4 w-4 mr-2" }),
                        " Resume",
                      ],
                    }),
                t.jsxs(I, {
                  variant: "destructive",
                  onClick: Te,
                  children: [t.jsx(rt, { className: "h-4 w-4 mr-2" }), " Stop"],
                }),
              ],
            }),
          ],
        }),
      r === "stopped" &&
        Me &&
        t.jsxs("div", {
          className: "space-y-4",
          children: [
            t.jsx("video", {
              src: Me,
              controls: !0,
              className: "w-full rounded-lg border max-h-[400px]",
            }),
            t.jsxs("div", {
              className: "flex items-center justify-center gap-3",
              children: [
                t.jsx(He, {
                  blob: z,
                  fileName: lt(z?.type.includes("mp4") ? "mp4" : "webm"),
                  label: "Download Recording",
                }),
                t.jsx(I, {
                  variant: "outline",
                  onClick: Xe,
                  children: "Record Another",
                }),
              ],
            }),
            z &&
              z.size > 200 * 1024 * 1024 &&
              t.jsxs(Ie, {
                className: "text-xs text-center",
                children: [
                  "This recording is ",
                  (z.size / 1024 / 1024).toFixed(0),
                  " MB. Compress it before sharing.",
                ],
              }),
            t.jsxs("p", {
              className: "text-xs text-center text-muted-foreground",
              children: [
                "Next: ",
                t.jsx("a", {
                  className: "underline",
                  href: "/tool/trim-video",
                  children: "Trim it",
                }),
                " · ",
                t.jsx("a", {
                  className: "underline",
                  href: "/tool/video-to-gif",
                  children: "Make a GIF",
                }),
                " · ",
                t.jsx("a", {
                  className: "underline",
                  href: "/tool/compress-video",
                  children: "Make it smaller",
                }),
                " (download first, then open the tool)",
              ],
            }),
            t.jsxs("p", {
              className: "text-xs text-muted-foreground text-center",
              children: [
                "Recorded ",
                Ce(de),
                " — downloads as",
                " ",
                z?.type.includes("mp4")
                  ? "MP4, which plays almost everywhere."
                  : "WebM, the format your browser recorded in. WebM plays in all modern browsers; use Convert Video if you need an MP4 for older software.",
              ],
            }),
          ],
        }),
      t.jsx(Ke, { whatIsIt: be.what, howToUse: be.how, tip: be.tip }),
    ],
  });
}
export { Bt as default };
//# sourceMappingURL=ScreenRecorder-CejnW5HL.js.map
