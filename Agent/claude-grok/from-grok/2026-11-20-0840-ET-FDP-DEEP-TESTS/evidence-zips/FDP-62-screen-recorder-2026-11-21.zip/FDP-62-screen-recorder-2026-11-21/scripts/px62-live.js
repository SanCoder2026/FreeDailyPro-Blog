// FDP-62 Screen Recorder (Premium), guest. Usage: node px62-live.js <zero|quickbuy|left|perload|nodm|deny> [engine]   env TRIES, ANY=1, SUF
// Headless browsers here have no real screen picker, so getDisplayMedia is replaced IN THE TEST BROWSER ONLY by a canvas.captureStream stub
// (1280x720, 4 colour quadrants, a moving bar and a frame counter, plus a 440 Hz "system audio" track). Mic/camera use the browser's fake devices.
// zero: as-is context (normally at the cap): full record (countdown, pause/resume, stop), region record, Download -> cap dialog.
// left: Premium uses left: full take -> Download [use], Record Another -> region take with camera bubble -> Download, reload -> take -> Download.
// perload: uses left: 4 takes in one load, Download each; then reload.  nodm: no getDisplayMedia (phone-like).  deny: mic+camera refused.
// Never signs in, never types an email or card, never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/62-screen-recorder/'; const OUT = BASE + 'live/'; const URL = 'https://www.freedailypro.com/tool/screen-recorder';
const mode = process.argv[2] || 'zero'; const eng = process.argv[3] || 'chromium'; const sfx = (eng === 'chromium' ? '' : '-' + eng) + (process.env.SUF || '');
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').replace(/dev[:%][^&"]*/g, 'dev:REDACTED').slice(0, 160);
const STUB = () => { if (window.__noDM) { try { delete MediaDevices.prototype.getDisplayMedia; } catch (e) { } return; }
 const fake = async (opts) => { window.__dmOpts = JSON.stringify(opts || {}); const W = 1280, H = 720; const cv = document.createElement('canvas'); cv.width = W; cv.height = H; const g = cv.getContext('2d'); let n = 0;
  const draw = () => { n++; const q = [['#e53935', 0, 0], ['#43a047', W / 2, 0], ['#1e88e5', 0, H / 2], ['#fdd835', W / 2, H / 2]]; q.forEach(([c, x, y]) => { g.fillStyle = c; g.fillRect(x, y, W / 2, H / 2); });
   g.fillStyle = '#000'; g.fillRect((n * 8) % W, 330, 40, 60); g.fillStyle = '#fff'; g.fillRect(40, 40, 520, 80); g.fillStyle = '#000'; g.font = 'bold 48px sans-serif'; g.fillText('FRAME ' + n, 60, 100); };
  draw(); const iv = setInterval(draw, 66); const s = cv.captureStream(15);
  try { const ac = new AudioContext(); const o = ac.createOscillator(); o.frequency.value = 440; const d = ac.createMediaStreamDestination(); o.connect(d); o.start(); s.addTrack(d.stream.getAudioTracks()[0]); } catch (e) { }
  window.__stub = s; s.getVideoTracks()[0].addEventListener('ended', () => clearInterval(iv)); return s; };
 if (navigator.mediaDevices) navigator.mediaDevices.getDisplayMedia = fake; };
(async () => {
 const launch = eng === 'chromium' ? { args: ['--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream', '--autoplay-policy=no-user-gesture-required'] } : eng === 'firefox' ? { firefoxUserPrefs: { 'media.navigator.streams.fake': true, 'media.navigator.permission.disabled': true, 'media.autoplay.default': 0 } } : {};
 const b = await pw[eng].launch(launch); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p, net = [];
 const open = async (o = {}) => { c = await b.newContext({ viewport: { width: 1366, height: 1000 }, locale: 'en-US', acceptDownloads: true }); if (eng === 'chromium' && !o.deny) await c.grantPermissions(['camera', 'microphone'], { origin: 'https://www.freedailypro.com' }); p = await c.newPage(); p.setDefaultTimeout(15000); net = [];
  if (o.noDM) await p.addInitScript(() => { window.__noDM = true; }); if (o.deny) await p.addInitScript(() => { const e = () => Promise.reject(new DOMException('Permission denied', 'NotAllowedError')); navigator.mediaDevices.getUserMedia = e; });
  await p.addInitScript(STUB); await p.addInitScript(() => { window.__t = []; const seen = new WeakSet(); setInterval(() => { document.querySelectorAll('[data-sonner-toast]').forEach(n => { if (!seen.has(n)) { seen.add(n); window.__t.push((n.innerText || '').trim()); } }); }, 120); });
  p.on('request', r => { const u = r.url(); if (r.method() === 'POST' && /freedailypro\.com\/api/.test(u) && !/insight\.hit|funnel\.hit/.test(u)) net.push({ t: now(), u: red(u), len: (r.postData() || '').length }); });
  await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 500) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(250); } };
 const toasts = n => p.evaluate(n => (window.__t || []).slice(n), n); const tc = () => p.evaluate(() => (window.__t || []).length);
 const shot = n => p.screenshot({ path: OUT + 'cases/' + n + sfx + '.png' }); const btn = t => p.locator('main button', { hasText: t }).first();
 const mainText = () => p.evaluate(() => document.querySelector('main').innerText.slice(0, 1500));
 const toggle = async (label, want) => { const bt = btn(label); const t = await bt.innerText(); if (/ on$/.test(t.trim()) !== want) await bt.click(); await p.waitForTimeout(400); return (await bt.innerText()).trim(); };
 const take = async (id, o = {}) => { const n = await tc(); const r = { toggles: {} };
  if (o.cam !== undefined) r.toggles.cam = await toggle('Camera bubble', o.cam); if (o.cd !== undefined) r.toggles.cd = await toggle('3-2-1 countdown', o.cd); if (o.mic !== undefined) r.toggles.mic = await toggle('Microphone', o.mic);
  await p.waitForTimeout(800); await btn('Start Recording').click(); await p.waitForTimeout(2500); r.dmOpts = await p.evaluate(() => window.__dmOpts || null); r.preview = (await mainText()).match(/Drag[^\n]*|Record Full Capture|Record Selected Region/g); await shot(id + '-preview');
  if (o.region) { const v = p.locator('main video').first(); const bb = await v.boundingBox(); await p.mouse.move(bb.x + bb.width * 0.1, bb.y + bb.height * 0.1); await p.mouse.down(); await p.mouse.move(bb.x + bb.width * 0.5, bb.y + bb.height * 0.5, { steps: 8 }); await p.mouse.up(); await p.waitForTimeout(500); r.regionBtn = await btn('Record Selected Region').isVisible().catch(() => false); await shot(id + '-region'); await btn('Record Selected Region').click(); }
  else await btn('Record Full Capture').click();
  const t0 = Date.now(); await p.waitForTimeout(1500); r.countdownText = (await mainText()).match(/^\s*[123]\s*$/m)?.[0] || null; await p.waitForTimeout(o.cd === false ? 500 : 3000);
  await p.waitForTimeout(o.secs || 4000); await shot(id + '-recording'); r.recUi = (await mainText()).match(/\d+:\d\d|Pause|Resume|Stop|Microphone level|Long recording[^\n]*/g); r.meter = await p.locator('main [data-testid=mic-meter]').getAttribute('aria-valuenow').catch(() => null);
  if (o.pause) { await btn(/Pause/).click(); await p.waitForTimeout(3000); r.pausedTimer = (await mainText()).match(/\d+:\d\d/g); await btn(/Resume/).click(); await p.waitForTimeout(2000); }
  await btn(/Stop/).click(); await p.waitForTimeout(2500); r.wallMs = Date.now() - t0; r.after = (await mainText()).match(/Recorded[^\n]*|This recording is[^\n]*/g); r.toasts = await toasts(n); await shot(id + '-stopped'); return r; };
 const dl = async id => { const n = await tc(); const before = await used(); const np = net.length; const dp = p.waitForEvent('download', { timeout: 15000 }).catch(() => null); await btn('Download Recording').click(); const d = await dp; await p.waitForTimeout(1500); const r = { before, after: await used(), dialog: await dialog(), toasts: await toasts(n), posts: net.slice(np).map(x => x.u.slice(0, 80)) };
  if (d) { const f = OUT + 'downloads/' + id + sfx + '-' + d.suggestedFilename(); await d.saveAs(f); r.file = { name: d.suggestedFilename(), bytes: fs.statSync(f).size }; try { r.probe = cp.execSync(`ffprobe -v error -show_entries format=duration,format_name:stream=codec_name,width,height -of compact "${f}"`).toString().trim().replace(/\n/g, ' | '); } catch (e) { r.probe = 'ffprobe error'; } } if (r.dialog) { await shot(id + '-dialog'); await esc(); } return r; };
 const C = async (id, fn) => { try { R.cases[id] = await fn(); } catch (e) { R.cases[id] = { err: e.message.split('\n')[0].slice(0, 200) }; await shot(id + '-err').catch(() => { }); } console.log(id, JSON.stringify(R.cases[id]).slice(0, 600)); };
 const findLeft = async () => { if (process.env.ANY) { await open(); R.tries.push(await used()); return true; } const TRIES = +(process.env.TRIES || 10); for (let i = 0; i < TRIES; i++) { await open(); const u = await used(); R.tries.push(u); const [a, l] = u.split('/').map(Number); if (a < l) return true; await c.close(); } return false; };
 const strip = () => p.evaluate(() => (document.querySelector('main').innerText.match(/Trial[^\n]*/) || [null])[0]);
 const again = async () => { await btn('Record Another').click(); await p.waitForTimeout(1500); };
 if (mode === 'zero') { await open(); R.start = { used: await used(), strip: await strip(), defaults: (await mainText()).match(/(Camera bubble|3-2-1 countdown|Microphone) (on|off)/g), micSelect: await p.locator('main select').count() }; await shot('Z00-initial');
  await C('Z01-full-pause', () => take('Z01', { pause: true, secs: 4000 }));
  await C('Z02-download-at-cap', () => dl('Z02'));
  await C('Z03-region-nocam-nocd', async () => { await again(); return take('Z03', { region: true, cam: false, cd: false, secs: 3000 }); });
  await C('Z04-download-at-cap', () => dl('Z04'));
  await C('Z05-video-src', () => p.evaluate(async () => { const v = document.querySelector('main video[controls]'); return v ? { src: v.src.slice(0, 20), dur: v.duration, w: v.videoWidth, h: v.videoHeight } : null; }));
  R.end = await used(); R.net = net;
 } else if (mode === 'quickbuy') { await open(); R.start = await used();
  for (const [i, lab] of [[0, 'day'], [1, 'monthly']]) await C('Q-' + lab, async () => { const pg = await c.newPage(); await pg.goto(URL, { waitUntil: 'domcontentloaded' }); await pg.waitForTimeout(4500); await pg.locator('main button', { hasText: 'Quick Buy' }).nth(i).click(); await pg.waitForTimeout(7000); await pg.screenshot({ path: OUT + 'quickbuy-' + lab + sfx + '.png' }); const d = await pg.locator('[role=dialog]').first().innerText().catch(() => null); return { url: red(pg.url()), dialog: d ? d.replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null }; });
 } else if (mode === 'left') { if (await findLeft()) { R.start = { used: await used(), strip: await strip() };
   await C('L01-full-cam-mic-pause', () => take('L01', { pause: true, secs: 5000 })); await C('L02-dl', () => dl('L02'));
   await C('L03-region-cam', async () => { await again(); return take('L03', { region: true, cd: false, secs: 3000 }); }); await C('L04-dl', () => dl('L04'));
   await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); R.afterReload = { used: await used(), strip: await strip() };
   await C('L05-after-reload', () => take('L05', { cd: false, cam: false, mic: false, secs: 3000 })); await C('L06-dl', () => dl('L06'));
   R.end = await used(); R.net = net; } }
 else if (mode === 'perload') { if (await findLeft()) { R.start = { used: await used(), strip: await strip() };
   for (const id of ['P1', 'P2', 'P3', 'P4']) { await C(id + '-take', () => take(id, { cd: false, cam: false, secs: 2000 })); await C(id + '-dl', () => dl(id)); R.cases[id + '-dl'].strip = await strip(); await again(); }
   await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); R.afterReload = { used: await used(), strip: await strip() };
   await C('P5-take', () => take('P5', { cd: false, cam: false, secs: 2000 })); await C('P5-dl', () => dl('P5')); R.end = await used(); R.net = net; } }
 else if (mode === 'stopcheck') { await open(); for (const [id, mic] of [['S1-mic-on', true], ['S2-mic-off', false]]) await C(id, async () => { await toggle('Camera bubble', false); await toggle('3-2-1 countdown', false); await toggle('Microphone', mic); await btn('Start Recording').click(); await p.waitForTimeout(2500); await btn('Record Full Capture').click(); await p.waitForTimeout(3000); const t0 = Date.now(); let how = 'normal'; try { await btn(/Stop/).click({ timeout: 4000 }); } catch (e) { how = 'needed force: ' + e.message.split('\n').slice(0, 6).join(' / ').slice(0, 300); await btn(/Stop/).click({ force: true }); } const ms = Date.now() - t0; await p.waitForTimeout(2000); const r = { stopMs: ms, how, after: (await mainText()).match(/Recorded[^\n]*/g) }; await shot(id); await again(); return r; }); }
 else if (mode === 'nodm') { await open({ noDM: true }); R.text = await mainText(); await C('N01-start', async () => { const n = await tc(); const b0 = btn('Start Recording'); const vis = await b0.isVisible().catch(() => false); const dis = vis ? await b0.isDisabled() : null; if (vis && !dis) await b0.click().catch(() => { }); await p.waitForTimeout(1500); await shot('N01'); return { startVisible: vis, disabled: dis, toasts: await toasts(n), text: (await mainText()).slice(0, 700) }; }); }
 else if (mode === 'deny') { await open({ deny: true }); await C('D01-take-denied', () => take('D01', { secs: 2500, cd: false })); }
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', JSON.stringify(R.tries), JSON.stringify(R.start || '').slice(0, 300), R.end); await b.close(); })();
