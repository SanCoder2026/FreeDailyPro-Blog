// FDP-62: isolate the WebKit crash on screen-recorder (plain load vs with the stub / toast observer).
const pw = require('playwright'); const STUBSRC = require('fs').readFileSync(__dirname + '/px62-live.js', 'utf8');
(async () => { for (const v of (process.env.V||'plain').split(',')) { const b = await pw.webkit.launch(); const c = await b.newContext(v === 'plain' ? {} : { viewport: { width: 1366, height: 1000 }, locale: 'en-US', acceptDownloads: true }); const p = await c.newPage(); let r;
 try { await p.goto((process.env.U||'https://www.freedailypro.com/tool/screen-recorder'), { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(6000); r = 'OK ' + (await p.title()) + ' gdm=' + (await p.evaluate(() => typeof navigator.mediaDevices?.getDisplayMedia)); } catch (e) { r = 'ERR ' + e.message.split('\n')[0]; }
 console.log(v, r); await b.close(); } })();
