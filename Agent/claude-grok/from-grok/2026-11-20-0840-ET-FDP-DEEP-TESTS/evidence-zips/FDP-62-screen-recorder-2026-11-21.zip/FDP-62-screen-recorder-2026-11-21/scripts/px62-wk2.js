// FDP-62: does Playwright Linux WebKit crash on navigator.mediaDevices.enumerateDevices() on a neutral page? (isolates env vs site)
const pw = require('playwright');
(async () => { for (const call of ['enumerateDevices', 'permissions-mic', 'none']) { const b = await pw.webkit.launch(); const p = await (await b.newContext()).newPage(); let r;
 try { await p.goto('https://example.com'); r = await p.evaluate(async c => { if (c === 'enumerateDevices') return JSON.stringify((await navigator.mediaDevices.enumerateDevices()).map(d => d.kind)); if (c === 'permissions-mic') return (await navigator.permissions.query({ name: 'microphone' })).state; return 'ok'; }, call); await p.waitForTimeout(2000); r += ' alive'; } catch (e) { r = 'ERR ' + e.message.split('\n')[0]; }
 console.log(call, r); await b.close(); } })();
