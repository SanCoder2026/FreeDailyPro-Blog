import { r as v, j as h } from "./vendor-react-D01g8YgM.js";
import { u as Y } from "./useShareGate-BYBawloP.js";
import { T as B, F } from "./ToolPage-DwLoDncN.js";
import { B as D, f as U } from "./index-B1CTyGtY.js";
import { T as K } from "./ToolInfoSection-C0i6Zbwo.js";
import { C as X } from "./copy-DcUvE8ta.js";
import "./useExportGate-BU4jIFHF.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
const I = (n, i, c) =>
  "#" + [n, i, c].map((a) => a.toString(16).padStart(2, "0")).join("");
function G(n, i, c) {
  const a = n / 255,
    u = i / 255,
    l = c / 255,
    d = 1 - Math.max(a, u, l);
  if (d >= 1) return { c: 0, m: 0, y: 0, k: 100 };
  const p = (x) => Math.round(((1 - x - d) / (1 - d)) * 100);
  return { c: p(a), m: p(u), y: p(l), k: Math.round(d * 100) };
}
const z = (n, i, c) => {
  const { c: a, m: u, y: l, k: d } = G(n, i, c);
  return `cmyk(${a}%, ${u}%, ${l}%, ${d}%)`;
};
function H(n, i, c, a = 8, u = 40) {
  const l = Math.max(1, Math.floor(Math.sqrt((i * c) / 6e4))),
    d = new Map();
  let p = 0;
  for (let e = 0; e < c; e += l)
    for (let m = 0; m < i; m += l) {
      const g = (e * i + m) * 4;
      if (n[g + 3] < 128) continue;
      const j = ((n[g] >> 4) << 8) | ((n[g + 1] >> 4) << 4) | (n[g + 2] >> 4),
        C = d.get(j);
      (C
        ? (C.n++, (C.r += n[g]), (C.g += n[g + 1]), (C.b += n[g + 2]))
        : d.set(j, { n: 1, r: n[g], g: n[g + 1], b: n[g + 2] }),
        p++);
    }
  if (!p) return [];
  const x = Array.from(d.values()).sort((e, m) => m.n - e.n),
    k = [],
    w = (e, m) => Math.hypot(e[0] - m[0], e[1] - m[1], e[2] - m[2]);
  for (const e of x) {
    const m = [
        Math.round(e.r / e.n),
        Math.round(e.g / e.n),
        Math.round(e.b / e.n),
      ],
      g = k.find((j) => w(j.rgb, m) < u);
    if (g) {
      g.n += e.n;
      continue;
    }
    k.length < a && k.push({ rgb: m, n: e.n });
  }
  return k
    .sort((e, m) => m.n - e.n)
    .map((e) => ({ hex: I(...e.rgb), rgb: e.rgb, share: e.n / p }))
    .filter((e, m) => m === 0 || e.share >= 0.005);
}
function q(n, i, c, a, u) {
  if (n.width <= 0 || n.height <= 0 || i <= 0 || c <= 0) return null;
  const l = Math.min(n.width / i, n.height / c),
    d = i * l,
    p = c * l,
    x = (n.width - d) / 2,
    k = (n.height - p) / 2,
    w = (a - n.left - x) / l,
    e = (u - n.top - k) / l;
  return w < 0 || e < 0 || w >= i || e >= c
    ? null
    : { x: Math.floor(w), y: Math.floor(e) };
}
function W(n, i, c, a, u, l) {
  const d = c * 2 + 1,
    p = n - c,
    x = i - c,
    k = Math.max(0, p),
    w = Math.max(0, x),
    e = Math.min(a, p + d),
    m = Math.min(u, x + d);
  return {
    sx: k,
    sy: w,
    sw: Math.max(0, e - k),
    sh: Math.max(0, m - w),
    dx: (k - p) * l,
    dy: (w - x) * l,
    dw: Math.max(0, e - k) * l,
    dh: Math.max(0, m - w) * l,
    size: d * l,
  };
}
const R = 7,
  b = 8;
function Z(n, i, c) {
  ((n /= 255), (i /= 255), (c /= 255));
  const a = Math.max(n, i, c),
    u = Math.min(n, i, c);
  let l = 0,
    d = 0;
  const p = (a + u) / 2;
  if (a !== u) {
    const x = a - u;
    ((d = p > 0.5 ? x / (2 - a - u) : x / (a + u)),
      a === n
        ? (l = (i - c) / x + (i < c ? 6 : 0))
        : a === i
          ? (l = (c - n) / x + 2)
          : (l = (n - i) / x + 4),
      (l /= 6));
  }
  return `hsl(${Math.round(l * 360)}, ${Math.round(d * 100)}%, ${Math.round(p * 100)}%)`;
}
const $ = {
  what: "Lets you click anywhere on an uploaded image to pick and copy the exact color at that point, useful for matching a color from a photo or existing design.",
  how: "Upload an image. Move over it to see a magnifier (each pixel drawn 8 times larger, with its edges marked), click the color you want, and its hex, RGB, HSL and CMYK values are shown for copying. The most common colors in the image are listed as a palette under the picture; click one to see its values. With the picture focused, the arrow keys move the picked pixel one step (hold Shift for ten).",
  tip: "A single pixel's color can shift subtly across a gradient, a photo or JPEG artifacts, so use the magnifier to land on the exact pixel. CMYK here is a simple conversion from RGB with no printer profile, so a print shop's own conversion may differ a little. The image and the palette stay in your browser.",
};
function Ct() {
  const { gateShare: n } = Y(),
    [i, c] = v.useState(null),
    [a, u] = v.useState(null),
    [l, d] = v.useState([]),
    p = v.useRef(null),
    x = v.useRef(null),
    k = v.useRef(null),
    [w, e] = v.useState(null),
    m = v.useCallback((t) => {
      const o = t[0];
      if (!o) return;
      const s = URL.createObjectURL(o);
      (c(s), u(null), d([]));
    }, []),
    g = (t, o, s, y, r) => ({
      hex: I(t, o, s),
      rgb: `rgb(${t}, ${o}, ${s})`,
      hsl: Z(t, o, s),
      cmyk: z(t, o, s),
      x: y,
      y: r,
    }),
    j = (t, o) => {
      const s = p.current?.getContext("2d", { willReadFrequently: !0 });
      if (!s) return;
      const y = s.getImageData(t, o, 1, 1).data;
      u(g(y[0], y[1], y[2], t, o));
    },
    C = (t) => {
      const o = t.currentTarget,
        s = p.current;
      if (!s) return;
      ((s.width = o.naturalWidth), (s.height = o.naturalHeight));
      const y = s.getContext("2d");
      y?.drawImage(o, 0, 0);
      try {
        const r = y?.getImageData(0, 0, s.width, s.height);
        d(r ? H(r.data, r.width, r.height, 8) : []);
      } catch {
        d([]);
      }
    },
    L = (t, o) => {
      const s = p.current;
      return s ? q(s.getBoundingClientRect(), s.width, s.height, t, o) : null;
    },
    P = (t) => {
      const o = L(t.clientX, t.clientY);
      o && j(o.x, o.y);
    },
    A = (t, o) => {
      const s = p.current,
        y = x.current,
        r = y?.getContext("2d");
      if (!s || !y || !r) return;
      const f = W(t, o, R, s.width, s.height, b);
      ((r.imageSmoothingEnabled = !1),
        (r.fillStyle = "#888"),
        r.fillRect(0, 0, f.size, f.size),
        f.sw > 0 &&
          f.sh > 0 &&
          r.drawImage(s, f.sx, f.sy, f.sw, f.sh, f.dx, f.dy, f.dw, f.dh),
        (r.lineWidth = 1),
        (r.strokeStyle = "rgba(0,0,0,0.28)"),
        r.beginPath());
      for (let T = 0; T <= R * 2 + 1; T++) {
        const S = T * b + 0.5;
        (r.moveTo(S, 0),
          r.lineTo(S, f.size),
          r.moveTo(0, S),
          r.lineTo(f.size, S));
      }
      r.stroke();
      const M = R * b;
      ((r.strokeStyle = "#000"),
        (r.lineWidth = 2),
        r.strokeRect(M + 1, M + 1, b - 2, b - 2),
        (r.strokeStyle = "#fff"),
        (r.lineWidth = 1),
        r.strokeRect(M - 0.5, M - 0.5, b + 1, b + 1));
      const N = s
        .getContext("2d", { willReadFrequently: !0 })
        .getImageData(t, o, 1, 1).data;
      return I(N[0], N[1], N[2]);
    },
    E = (t) => {
      const o = L(t.clientX, t.clientY),
        s = k.current;
      if (!o || !s) {
        e(null);
        return;
      }
      const y = A(o.x, o.y),
        r = s.getBoundingClientRect(),
        f = (R * 2 + 1) * b;
      let M = t.clientX - r.left + 18,
        N = t.clientY - r.top + 18;
      (M + f > r.width && (M = t.clientX - r.left - f - 18),
        N + f + 20 > r.height && (N = t.clientY - r.top - f - 38),
        e({ left: Math.max(0, M), top: Math.max(0, N), hex: y ?? "" }));
    },
    O = (t) => {
      const o = p.current;
      if (!o) return;
      const s = t.shiftKey ? 10 : 1,
        y = t.key === "ArrowLeft" ? -s : t.key === "ArrowRight" ? s : 0,
        r = t.key === "ArrowUp" ? -s : t.key === "ArrowDown" ? s : 0;
      if (!y && !r && t.key !== "Enter") return;
      t.preventDefault();
      const f = Math.min(
          o.width - 1,
          Math.max(0, (a?.x ?? Math.floor(o.width / 2)) + y),
        ),
        M = Math.min(
          o.height - 1,
          Math.max(0, (a?.y ?? Math.floor(o.height / 2)) + r),
        );
      j(f, M);
    },
    _ = (t) =>
      n(async () => {
        try {
          return (
            await navigator.clipboard.writeText(t),
            U.success(`Copied ${t}`),
            !0
          );
        } catch {
          return (
            U.error("Couldn't copy. Select the text and copy it by hand."),
            !1
          );
        }
      });
  return h.jsxs(B, {
    children: [
      i
        ? h.jsxs("div", {
            className: "space-y-4",
            children: [
              h.jsxs("div", {
                ref: k,
                className:
                  "relative rounded-lg border overflow-hidden bg-[repeating-conic-gradient(#eee_0%_25%,transparent_0%_50%)] bg-[length:16px_16px]",
                children: [
                  h.jsx("img", {
                    src: i,
                    onLoad: C,
                    className: "hidden",
                    alt: "",
                  }),
                  h.jsx("canvas", {
                    ref: p,
                    onClick: P,
                    onPointerMove: E,
                    onPointerLeave: () => e(null),
                    onKeyDown: O,
                    tabIndex: 0,
                    role: "img",
                    "aria-label":
                      "Your image. Click a point to pick its color, or use the arrow keys to move the picked pixel.",
                    className:
                      "w-full h-auto cursor-crosshair max-h-[500px] object-contain mx-auto block touch-none",
                  }),
                  h.jsxs("div", {
                    className:
                      "absolute pointer-events-none rounded border-2 border-white shadow-lg bg-black/80",
                    style: {
                      left: w?.left ?? 0,
                      top: w?.top ?? 0,
                      display: w ? "block" : "none",
                    },
                    "aria-hidden": "true",
                    children: [
                      h.jsx("canvas", {
                        ref: x,
                        width: (R * 2 + 1) * b,
                        height: (R * 2 + 1) * b,
                        className: "block",
                      }),
                      h.jsx("p", {
                        className:
                          "text-center text-[10px] font-mono text-white py-0.5",
                        children: w?.hex,
                      }),
                    ],
                  }),
                ],
              }),
              l.length > 0 &&
                h.jsxs("div", {
                  children: [
                    h.jsx("p", {
                      className: "text-xs text-muted-foreground mb-1.5",
                      children:
                        "Main colors in this image (click one to see its values)",
                    }),
                    h.jsx("div", {
                      className: "flex flex-wrap gap-2",
                      role: "group",
                      "aria-label": "Main colors in this image",
                      children: l.map((t) =>
                        h.jsxs(
                          "button",
                          {
                            type: "button",
                            onClick: () => u(g(t.rgb[0], t.rgb[1], t.rgb[2])),
                            "aria-label": `Use palette color ${t.hex}, ${Math.max(1, Math.round(t.share * 100))} percent of the image`,
                            className:
                              "flex items-center gap-2 rounded-lg border bg-card px-2 py-1.5 text-xs hover:bg-accent focus-visible:ring-2 focus-visible:ring-ring",
                            children: [
                              h.jsx("span", {
                                className: "h-6 w-6 rounded border shrink-0",
                                style: { backgroundColor: t.hex },
                              }),
                              h.jsx("span", {
                                className: "font-mono",
                                children: t.hex,
                              }),
                              h.jsxs("span", {
                                className: "text-muted-foreground",
                                children: [
                                  Math.max(1, Math.round(t.share * 100)),
                                  "%",
                                ],
                              }),
                            ],
                          },
                          t.hex,
                        ),
                      ),
                    }),
                  ],
                }),
              a &&
                h.jsx("div", {
                  className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
                  children: [
                    ["HEX", a.hex],
                    ["RGB", a.rgb],
                    ["HSL", a.hsl],
                    ["CMYK", a.cmyk],
                  ].map(([t, o]) =>
                    h.jsxs(
                      "div",
                      {
                        className:
                          "p-3 rounded-lg border bg-card flex items-center gap-3",
                        children: [
                          t === "HEX" &&
                            h.jsx("div", {
                              className: "w-8 h-8 rounded shrink-0 border",
                              style: { backgroundColor: a.hex },
                            }),
                          h.jsxs("div", {
                            className: "min-w-0 flex-1",
                            children: [
                              h.jsx("p", {
                                className: "text-[10px] text-muted-foreground",
                                children: t,
                              }),
                              h.jsx("p", {
                                className: "text-sm font-mono truncate",
                                children: o,
                              }),
                            ],
                          }),
                          h.jsx(D, {
                            size: "icon",
                            variant: "ghost",
                            "aria-label": `Copy ${t} value ${o}`,
                            title: `Copy ${t}`,
                            onClick: () => _(o),
                            children: h.jsx(X, { className: "h-3.5 w-3.5" }),
                          }),
                        ],
                      },
                      t,
                    ),
                  ),
                }),
              h.jsx(D, {
                variant: "outline",
                onClick: () => {
                  (c(null), u(null), d([]), e(null));
                },
                children: "Upload Different Image",
              }),
            ],
          })
        : h.jsx(F, {
            gateAtDownload: !0,
            accept: "image/*",
            onFiles: m,
            label: "Drop an image to pick colors from",
            description:
              "Click anywhere on the image to sample that pixel's color",
          }),
      h.jsx(K, { whatIsIt: $.what, howToUse: $.how, tip: $.tip }),
    ],
  });
}
export { Ct as default };
//# sourceMappingURL=ColorPickerImage-DP4amtAo.js.map
