# FDP-63 test images with known pixels. Run: /workspace/deep/venv-pdf/bin/python make63.py
from PIL import Image, ImageDraw
im = Image.new('RGB', (800, 600)); d = ImageDraw.Draw(im)
Q = {'tl': (0x33, 0x66, 0xcc), 'tr': (0xe5, 0x39, 0x35), 'bl': (0x43, 0xa0, 0x47), 'br': (0xfd, 0xd8, 0x35)}
d.rectangle((0, 0, 399, 299), fill=Q['tl']); d.rectangle((400, 0, 799, 299), fill=Q['tr']); d.rectangle((0, 300, 399, 599), fill=Q['bl']); d.rectangle((400, 300, 799, 599), fill=Q['br'])
im.putpixel((200, 150), (1, 2, 3))  # single odd pixel in the blue quadrant centre
d.rectangle((600, 450, 600, 450), fill=(0, 0, 0)); d.rectangle((0, 0, 0, 0), fill=(255, 255, 255)); d.rectangle((799, 599, 799, 599), fill=(18, 52, 86))
im.save('quad-800x600.png'); im.save('quad-800x600-q60.jpg', quality=60)
big = im.resize((4000, 3000), Image.NEAREST); big.putpixel((1000, 750), (1, 2, 3)); big.save('quad-4000x3000.png')
a = Image.new('RGBA', (400, 300), (255, 0, 0, 64)); a.save('alpha-red-25pct.png')
tall = Image.new('RGB', (300, 3000), (10, 20, 30)); ImageDraw.Draw(tall).rectangle((0, 1500, 299, 2999), fill=(200, 100, 50)); tall.save('tall-300x3000.png')
ex = Image.new('RGB', (600, 300), (0, 0, 255)); ImageDraw.Draw(ex).rectangle((0, 0, 299, 299), fill=(255, 0, 0))  # stored: left red, right blue
e = Image.Exif(); e[0x0112] = 6; ex.save('exif6-red-left-stored.jpg', quality=95, exif=e)  # displayed rotated 90 CW: red on top
Image.new('RGB', (1, 1), (128, 128, 128)).save('one-pixel.png')
open('notanimage.png', 'w').write('not an image')
print('ok')
