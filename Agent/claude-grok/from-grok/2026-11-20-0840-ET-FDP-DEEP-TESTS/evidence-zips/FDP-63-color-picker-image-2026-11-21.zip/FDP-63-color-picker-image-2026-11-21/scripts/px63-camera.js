// FDP-63: "Take photo with camera" with Chromium's fake camera (test browser only). Guest; records usage counter and posts.
const { chromium } = require('playwright'); const fs = require('fs'); const O = '/workspace/deep/63-color-picker-image/live/';
(async () => { const b = await chromium.launch({ args: ['--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream'] }); const c = await b.newContext({ viewport: { width: 1366, height: 1000 }, permissions: ['camera'] }); const p = await c.newPage(); const R = { posts: [] };
 p.on('request', r => { if (r.method() === 'POST' && /usage/.test(r.url())) R.posts.push(r.url()); });
 await p.goto('https://www.freedailypro.com/tool/color-picker-image', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500);
 const used = () => p.evaluate(() => { try { const u = JSON.parse(localStorage.getItem('fdp-usage-v1')); return u.usageToday + '/' + u.limit; } catch { return null; } });
 R.before = await used(); await p.locator('main button', { hasText: /Take photo/i }).first().click(); await p.waitForTimeout(3500); await p.screenshot({ path: O + 'cases/camera-open.png' });
 R.buttons = (await p.locator('main button, [role=dialog] button').allInnerTexts()).map(s => s.trim()).filter(s => s && s.length < 40).slice(0, 25);
 const cap = p.locator('button', { hasText: /^(Capture|Take|Snap|Use photo|Take photo)$/i }).last(); if (await cap.count()) { await cap.click(); await p.waitForTimeout(3000); }
 R.canvas = await p.locator('main canvas[role=img]').evaluate(e => [e.width, e.height]).catch(() => null); R.after = await used(); await p.screenshot({ path: O + 'cases/camera-captured.png' });
 fs.writeFileSync(O + 'camera.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R)); await b.close(); })();
