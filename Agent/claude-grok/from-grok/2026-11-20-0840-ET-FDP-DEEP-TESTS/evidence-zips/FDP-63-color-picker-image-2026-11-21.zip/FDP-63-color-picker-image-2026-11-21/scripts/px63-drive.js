// FDP-63: "Open from Google Drive" on the empty state (guest). Stops at whatever opens; never types or signs in.
const { chromium } = require('playwright'); const fs = require('fs'); const O = '/workspace/deep/63-color-picker-image/live/';
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 1000 } }); const p = await c.newPage(); const R = {};
 await p.goto('https://www.freedailypro.com/tool/color-picker-image', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500);
 const pop = c.waitForEvent('page', { timeout: 12000 }).catch(() => null); await p.locator('main button', { hasText: 'Open from Google Drive' }).click(); const np = await pop; await p.waitForTimeout(3000);
 if (np) { await np.waitForLoadState('domcontentloaded').catch(() => {}); await np.waitForTimeout(3000); const u = new URL(np.url()); R.popupHost = u.host + u.pathname; R.title = await np.title().catch(() => null); R.text = (await np.locator('body').innerText().catch(() => '')).slice(0, 200); await np.screenshot({ path: O + 'cases/drive-popup.png' }).catch(() => {}); await np.close(); }
 R.pageMsg = (await p.locator('[role=dialog], [role=alert], [role=status], [data-sonner-toast]').allInnerTexts().catch(() => [])).filter(Boolean).join(' | ').slice(0, 300); await p.screenshot({ path: O + 'cases/drive-after.png' });
 fs.writeFileSync(O + 'drive.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R)); await b.close(); })();
