// FDP-63 extras (guest): non-image upload message, alpha pick, Firefox copy-at-cap dialog, Google Drive button (stop at sign-in, no typing)
const pw = require('playwright'); const fs = require('fs'); const TF = '/workspace/deep/63-color-picker-image/testfiles/'; const O = '/workspace/deep/63-color-picker-image/live/';
const URL = 'https://www.freedailypro.com/tool/color-picker-image';
(async () => { const R = {}; const bn = process.argv[2] || 'chromium'; const b = await pw[bn].launch(); const c = await b.newContext({ viewport: { width: 1366, height: 1000 } }); const p = await c.newPage(); p.setDefaultTimeout(12000);
 await p.goto(URL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500);
 R.usage = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
 const cv = p.locator('main canvas[role=img]');
 const hex = () => p.evaluate(() => { const b = document.querySelector('main button[aria-label^="Copy HEX value"]'); return b ? b.getAttribute('aria-label') : null; });
 await p.locator('main input[type=file]').first().setInputFiles(TF + 'notanimage.png'); await p.waitForTimeout(3000);
 R.notimage = { canvas: await cv.evaluate(e => [e.width, e.height]).catch(() => null), alerts: await p.locator('[role=alert], [role=status], .text-destructive, [data-sonner-toast]').allInnerTexts().catch(() => []) };
 await cv.scrollIntoViewIfNeeded().catch(() => {}); await p.screenshot({ path: O + 'cases/C08-notimage-' + bn + '.png' });
 if (bn === 'chromium') {
  await p.locator('main button', { hasText: 'Upload Different Image' }).click(); await p.waitForTimeout(600);
  await p.locator('main input[type=file]').first().setInputFiles(TF + 'alpha-red-25pct.png'); await p.waitForTimeout(2500); await cv.scrollIntoViewIfNeeded(); const bb = await cv.boundingBox(); await p.mouse.click(bb.x + bb.width / 2, bb.y + bb.height / 2); await p.waitForTimeout(500); R.alpha = await hex(); await p.screenshot({ path: O + 'cases/C04-alpha.png' });
  // Drive button
  const drive = p.locator('main button', { hasText: /Google Drive/i }).first(); R.driveCount = await drive.count();
  if (R.driveCount) { await p.locator('main button', { hasText: 'Upload Different Image' }).click().catch(() => {}); await p.waitForTimeout(500); const pop = c.waitForEvent('page', { timeout: 10000 }).catch(() => null); await p.locator('main button', { hasText: /Google Drive/i }).first().click(); const np = await pop; await p.waitForTimeout(2500);
   if (np) { await np.waitForLoadState('domcontentloaded').catch(() => {}); await np.waitForTimeout(2500); R.drivePopup = np.url().replace(/[?#].*$/, '?[params redacted]'); R.drivePopupTitle = await np.title().catch(() => null); await np.screenshot({ path: O + 'cases/drive-popup.png' }).catch(() => {}); await np.close(); }
   else { R.drivePopup = null; R.driveText = (await p.locator('[role=dialog], [role=alert], [data-sonner-toast]').allInnerTexts().catch(() => [])).join(' | '); await p.screenshot({ path: O + 'cases/drive-click.png' }); } }
 } else {
  // Firefox: at cap? try a copy and record dialog
  await p.locator('main button', { hasText: 'Upload Different Image' }).click(); await p.waitForTimeout(600);
  await p.locator('main input[type=file]').first().setInputFiles(TF + 'quad-800x600.png'); await p.waitForTimeout(2500); await cv.scrollIntoViewIfNeeded(); const bb = await cv.boundingBox(); await p.mouse.click(bb.x + bb.width / 2 - 100, bb.y + bb.height / 2 - 100); await p.waitForTimeout(500); R.hex = await hex();
  await p.locator('main button[aria-label^="Copy HEX value"]').click().catch(e => R.err = String(e)); await p.waitForTimeout(1500); R.dialog = (await p.locator('[role=dialog]').allInnerTexts()).join(' | ').replace(/\s*\n\s*/g, ' | ').slice(0, 300); R.usageAfter = await p.evaluate(() => localStorage.getItem('fdp-usage-v1')); await p.screenshot({ path: O + 'cases/firefox-copy-at-cap.png' });
 }
 fs.writeFileSync(O + 'extra-' + bn + '.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R).replace(/dev:[0-9a-f]+/g, 'dev:[redacted]')); await b.close(); })();
