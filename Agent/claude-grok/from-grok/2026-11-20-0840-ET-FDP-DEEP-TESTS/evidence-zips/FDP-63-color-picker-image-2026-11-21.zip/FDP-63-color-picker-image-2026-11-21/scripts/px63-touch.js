// FDP-63: tap-to-pick on Pixel 7 emulation (Chromium, hasTouch) and iPhone 14 (WebKit). Guest; no copies.
const pw = require('playwright'); const fs = require('fs'); const TF = '/workspace/deep/63-color-picker-image/testfiles/'; const O = '/workspace/deep/63-color-picker-image/live/';
(async () => { const R = {}; for (const [bn, dev] of [['chromium', 'Pixel 7'], ['webkit', 'iPhone 14 Pro Max']]) { const b = await pw[bn].launch(); const c = await b.newContext({ ...pw.devices[dev] }); const p = await c.newPage();
 await p.goto('https://www.freedailypro.com/tool/color-picker-image', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500);
 await p.locator('main input[type=file]').first().setInputFiles(TF + 'quad-800x600.png'); await p.waitForTimeout(2500); const cv = p.locator('main canvas[role=img]'); await cv.scrollIntoViewIfNeeded(); const bb = await cv.boundingBox();
 await p.touchscreen.tap(bb.x + bb.width * 0.75, bb.y + bb.height * 0.25); await p.waitForTimeout(700);
 R[dev] = { box: [Math.round(bb.width), Math.round(bb.height)], hex: await p.evaluate(() => { const b = document.querySelector('main button[aria-label^="Copy HEX value"]'); return b && b.getAttribute('aria-label'); }) };
 await p.screenshot({ path: O + 'cases/touch-' + dev.replace(/ /g, '-').toLowerCase() + '.png' }); await b.close(); }
 fs.writeFileSync(O + 'touch.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R)); })();
