import { r as a, j as e } from "./vendor-react-D01g8YgM.js";
import { f as W } from "./formatFileSize-B-JRDfN5.js";
import {
  p as he,
  T as G,
  F as ve,
  o as xe,
  q as ge,
  r as Z,
  R as be,
  D as we,
} from "./ToolPage-DwLoDncN.js";
import { a as je } from "./BatchRunner-CHpN_wvN.js";
import { e as $, B as n, f as ye } from "./index-B1CTyGtY.js";
import {
  S as Se,
  a as Ae,
  b as Ce,
  c as ke,
  d as Ne,
} from "./select-ic5yaeGw.js";
import { T as H } from "./ToolInfoSection-C0i6Zbwo.js";
import { u as Fe } from "./UsageAndUpgradeStrip-B1CY210m.js";
import {
  checkFileSize as Oe,
  resetFFmpegEngine as P,
  loadFFmpeg as K,
  fetchFile as Y,
  ffmpegOutputToBlob as J,
} from "./ffmpegEngine-DH91Xnxx.js";
import {
  i as X,
  b as Te,
  c as Ie,
  A as E,
  d as q,
  m as Pe,
  U as Ee,
  N as ze,
  g as ee,
  h as te,
  j as Le,
} from "./operations-DLxdtd8A.js";
import { p as se } from "./audioFile-CL1ltBQd.js";
import { v as oe } from "./containers-CEblVBL8.js";
import { u as Me } from "./useConverterPair-rg6H4-hf.js";
import { F as Re, A as De, s as Ue } from "./uiHelpers-DY6mT0h-.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./batch-Bbh00IAr.js";
import "./trash-2-CmoDM6Qu.js";
import "./square-DmBnvOHU.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./chevron-up-BDUcPssj.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./timeFormat-Va_Xba1f.js";
import "./sniffRate-BQP3kobv.js";
import "./progress-Y72GQ7li.js";
const f = {
    what: "Converts an audio file between common formats (MP3, WAV, OGG, M4A, FLAC), and also takes the sound track out of a video (MP4, MOV, MKV, WebM, AVI and similar) and converts it in the same step, since different platforms and devices expect different audio formats. Runs entirely in your browser — the audio never leaves your device.",
    how: `Upload your audio file, or a video to take its sound from (a file that is neither is turned away straight away, and nothing is used from your trial), choose the format you want to convert it to, and download the converted file once processing finishes. To convert a whole folder, choose Several files and drop them all: they are converted with the same settings and downloaded as one ZIP. "Same as original" keeps a lossy file's bitrate, and uses 192 kbps for a lossless (WAV, FLAC) source. Use Convert again to turn the same file into another format without re-uploading.`,
    tip: "MP3 is the safest default for the widest compatibility. WAV and FLAC are uncompressed or losslessly compressed, so they sound identical to the source but produce much larger files — use those when quality matters more than size, like archiving a master recording.",
  },
  _e = ["mp3", "ogg", "m4a"];
function zt() {
  const [h, ae] = a.useState("one"),
    [s, v] = a.useState(null),
    l = Me("audio-converter"),
    [r, re] = a.useState(l ? he(l) : "mp3"),
    [j, y] = a.useState(!1),
    [c, ie] = a.useState("match"),
    [p, C] = a.useState(null),
    [z, k] = a.useState(!1),
    [S, N] = a.useState(!1),
    [L, F] = a.useState(""),
    [x, M] = a.useState(!1),
    [ne, R] = a.useState(0),
    [le, A] = a.useState(""),
    [g, d] = a.useState(null),
    { isPro: D, isLoading: ce, isAdmin: de } = Fe(),
    b = a.useRef(null),
    U = a.useRef(null),
    ue = a.useCallback((t) => {
      const o = t[0];
      if (o) {
        if ((v(o), d(null), F(""), C(null), N(!1), y(!1), k(!0), X(o.name))) {
          Promise.all([Te(o), oe(o)])
            .then(([i, u]) => {
              (C(i), u === !1 && y(!0));
            })
            .finally(() => k(!1));
          return;
        }
        se(o)
          .then((i) => {
            i.readable ? C(i.duration) : N(!0);
          })
          .finally(() => k(!1));
      }
    }, []),
    _ = _e.includes(r),
    O = (s ? Ie(s, r, c, p) : null)?.kbps ?? null,
    V = s && p && _ && O ? (O * 1e3 * p) / 8 : null;
  a.useEffect(() => {
    d(null);
  }, [c]);
  const T = s ? Oe([s], D || ce, de) : null,
    me = () => {
      (U.current?.abort(), b.current && P(b.current));
    },
    pe = async () => {
      if (!s || S || j) return;
      (M(!0), R(0));
      const t = new AbortController();
      U.current = t;
      try {
        A("Loading audio engine...");
        const o = await K((m) => A(m));
        ((b.current = o), A("Reading audio file..."));
        const i = await Y(s),
          u = E.find((m) => m.value === r);
        A(`Converting to ${u.label}...`);
        const I = await te(o, s, i, r, c, p, R, t.signal),
          w = J(I, u.mime);
        (d(w), F(Le(s, w.size, r, c, p, W)), ye.success("Audio converted!"));
      } catch (o) {
        o instanceof Error &&
        /matches no streams|does not contain any stream|no audio/i.test(
          o.message,
        )
          ? y(!0)
          : Ue(o);
      } finally {
        (b.current && P(b.current), M(!1));
      }
    },
    fe = async (t, o) => {
      const i = X(t.name);
      if (i && (await oe(t)) === !1)
        throw new Error(
          "This video has no sound track, so there is nothing to convert.",
        );
      const u = i ? { readable: !0, duration: null } : await se(t);
      if (!u.readable)
        throw new Error(
          "Couldn't read this file. It may be damaged or not audio.",
        );
      const I = E.find((m) => m.value === r),
        w = await K();
      try {
        const m = await te(w, t, await Y(t), r, c, u.duration, () => {}, o);
        return { blob: J(m, I.mime), fileName: ee(t.name, r) };
      } finally {
        P(w);
      }
    },
    B = e.jsxs("div", {
      className: "space-y-4",
      children: [
        e.jsxs("div", {
          children: [
            e.jsx($, { children: "Output Format" }),
            e.jsxs(Se, {
              value: r,
              onValueChange: (t) => {
                (re(t), d(null));
              },
              children: [
                e.jsx(Ae, {
                  className: "w-40",
                  "aria-label": "Output format",
                  children: e.jsx(Ce, {}),
                }),
                e.jsx(ke, {
                  children: E.map((t) =>
                    e.jsx(Ne, { value: t.value, children: t.label }, t.value),
                  ),
                }),
              ],
            }),
          ],
        }),
        _ &&
          e.jsxs("div", {
            children: [
              e.jsx($, { children: "Quality" }),
              e.jsx("div", {
                className: "flex flex-wrap gap-2 mt-1",
                role: "group",
                "aria-label": "Quality",
                children: ["match", ...Object.keys(q)].map((t) =>
                  e.jsx(
                    n,
                    {
                      size: "sm",
                      variant: c === t ? "default" : "outline",
                      "aria-pressed": c === t,
                      onClick: () => {
                        (ie(t), d(null));
                      },
                      children:
                        t === "match"
                          ? h === "one" && s
                            ? Pe(s, p)
                            : "Same as original (each file's own bitrate; lossless sources use 192 kbps)"
                          : q[t],
                    },
                    t,
                  ),
                ),
              }),
              h === "one" &&
                V &&
                e.jsxs("p", {
                  className: "text-xs text-muted-foreground mt-1",
                  "data-testid": "convert-estimate",
                  children: ["About ", O, " kbps · estimated size ", W(V)],
                }),
            ],
          }),
      ],
    }),
    Q = e.jsx("div", {
      className: "flex items-center gap-2 mb-4",
      role: "radiogroup",
      "aria-label": "How many files",
      children: [
        ["one", "One file"],
        ["many", "Several files (ZIP)"],
      ].map(([t, o]) =>
        e.jsx(
          n,
          {
            size: "sm",
            variant: h === t ? "default" : "outline",
            role: "radio",
            "aria-checked": h === t,
            disabled: x,
            onClick: () => ae(t),
            children: o,
          },
          t,
        ),
      ),
    });
  return h === "many"
    ? e.jsxs(G, {
        children: [
          Q,
          e.jsx(je, {
            accept: "audio/*,video/*",
            noun: "audio",
            process: fe,
            zipName: "converted-audio.zip",
            runLabel: "Convert all",
            maxSizeMb: 500,
            children: B,
          }),
          e.jsx(H, { whatIsIt: f.what, howToUse: f.how, tip: f.tip }),
        ],
      })
    : e.jsxs(G, {
        children: [
          !s && Q,
          s
            ? e.jsxs("div", {
                className: "space-y-4",
                children: [
                  e.jsx("div", {
                    className: "p-4 rounded-lg border bg-card",
                    children: e.jsx("p", {
                      className: "text-sm font-medium",
                      children: s.name,
                    }),
                  }),
                  T && e.jsx(Re, { check: T, isPro: D }),
                  S &&
                    e.jsxs("div", {
                      role: "alert",
                      "data-testid": "convert-load-error",
                      className:
                        "p-3 rounded-lg border border-destructive/50 text-sm text-destructive flex items-center justify-between gap-3",
                      children: [
                        e.jsx("span", { children: Ee }),
                        e.jsx(n, {
                          size: "sm",
                          variant: "outline",
                          onClick: () => {
                            (v(null), N(!1));
                          },
                          children: "Choose another",
                        }),
                      ],
                    }),
                  Z(l, s.name) &&
                    e.jsx("p", {
                      className: "text-xs text-muted-foreground",
                      "data-testid": "pair-mismatch",
                      children: Z(l, s.name),
                    }),
                  j &&
                    e.jsxs("div", {
                      role: "alert",
                      "data-testid": "convert-no-audio",
                      className:
                        "p-3 rounded-lg border border-destructive/50 text-sm text-destructive flex items-center justify-between gap-3",
                      children: [
                        e.jsxs("span", {
                          children: [
                            ze,
                            " There is nothing to convert. Nothing was used from your trial.",
                          ],
                        }),
                        e.jsx(n, {
                          size: "sm",
                          variant: "outline",
                          onClick: () => {
                            (v(null), y(!1));
                          },
                          children: "Choose another",
                        }),
                      ],
                    }),
                  !S && !j && B,
                  x &&
                    e.jsx(De, { progress: ne, statusMessage: le, onStop: me }),
                  g &&
                    L &&
                    e.jsx("p", {
                      className: "text-sm",
                      "data-testid": "convert-summary",
                      children: L,
                    }),
                  g && e.jsx(be, { blob: g }),
                  e.jsx("div", {
                    className: "flex flex-wrap gap-3",
                    children: g
                      ? e.jsxs(e.Fragment, {
                          children: [
                            e.jsx(we, { blob: g, fileName: ee(s.name, r) }),
                            e.jsx(n, {
                              variant: "outline",
                              onClick: () => {
                                (d(null), F(""));
                              },
                              "data-testid": "convert-again",
                              children: "Convert again",
                            }),
                            e.jsx(n, {
                              variant: "outline",
                              onClick: () => {
                                (v(null), d(null));
                              },
                              children: "New file",
                            }),
                          ],
                        })
                      : e.jsxs(e.Fragment, {
                          children: [
                            e.jsx(n, {
                              onClick: pe,
                              disabled:
                                x || z || S || j || T?.severity !== "ok",
                              children: x
                                ? "Converting..."
                                : z
                                  ? "Checking file..."
                                  : "Convert",
                            }),
                            e.jsx(n, {
                              variant: "outline",
                              onClick: () => v(null),
                              disabled: x,
                              children: "Reset",
                            }),
                          ],
                        }),
                  }),
                ],
              })
            : e.jsx(ve, {
                gateAtDownload: !0,
                accept: "audio/*,video/*",
                maxSize: 500,
                onFiles: ue,
                label: l
                  ? `Drop ${xe(l.from)} file to convert to ${ge(l.to).label}`
                  : "Drop an audio file to convert",
                description:
                  "Convert between audio formats, or drop a video to take its sound",
              }),
          e.jsx(H, { whatIsIt: f.what, howToUse: f.how, tip: f.tip }),
        ],
      });
}
export { zt as default };
//# sourceMappingURL=AudioConverter-CCPU340M.js.map
