#!/bin/bash
# FDP-64 test files (ffmpeg): known durations, bitrates, tags and cover art
set -e; cd "$(dirname "$0")/testfiles"
ffmpeg -loglevel error -y -f lavfi -i "sine=frequency=440:duration=12" -f lavfi -i "sine=frequency=660:duration=12" -filter_complex amerge=inputs=2 -ar 44100 -c:a pcm_s16le tone-12s.wav
ffmpeg -loglevel error -y -f lavfi -i "color=c=red:s=300x300:d=1" -frames:v 1 cover.png
ffmpeg -loglevel error -y -i tone-12s.wav -i cover.png -map 0 -map 1 -c:a libmp3lame -b:a 128k -c:v mjpeg -disposition:v attached_pic -id3v2_version 3 -metadata title="FDP Tone" -metadata artist="QA Artist" tagged-128k.mp3
ffmpeg -loglevel error -y -i tone-12s.wav -i cover.png -map 0 -map 1 -c:a flac -c:v png -disposition:v attached_pic -metadata title="FDP Tone" -metadata artist="QA Artist" tagged.flac
ffmpeg -loglevel error -y -i tone-12s.wav -c:a aac -b:a 96k -metadata title="FDP Tone" tone-96k.m4a
ffmpeg -loglevel error -y -i tone-12s.wav -c:a libvorbis -q:a 3 tone.ogg
ffmpeg -loglevel error -y -i tone-12s.wav -c:a wmav2 -b:a 128k tone.wma
ffmpeg -loglevel error -y -f lavfi -i "testsrc=s=320x240:d=6" -f lavfi -i "sine=frequency=523:duration=6" -c:v libx264 -pix_fmt yuv420p -c:a aac -shortest clip-with-audio.mp4
ffmpeg -loglevel error -y -f lavfi -i "testsrc=s=320x240:d=4" -c:v libx264 -pix_fmt yuv420p -an clip-no-audio.mp4
printf 'this is plain text, not audio\n%.0s' {1..200} > notaudio.mp3
for i in 1 2 3 4 5 6; do ffmpeg -loglevel error -y -f lavfi -i "sine=frequency=$((300+i*50)):duration=3" -ar 44100 -c:a pcm_s16le batch-$i.wav; done
ffmpeg -loglevel error -y -f lavfi -i "anoisesrc=color=pink:duration=12:amplitude=0.3" -f lavfi -i "anoisesrc=color=pink:duration=12:amplitude=0.3:seed=7" -filter_complex amerge=inputs=2 -ar 44100 -c:a libvorbis -q:a 4 music-like-q4.ogg
ffmpeg -loglevel error -y -f lavfi -i "anoisesrc=color=pink:duration=12:amplitude=0.2" -ar 48000 -ac 1 -c:a libvorbis -b:a 48k voice-48k-mono.ogg
