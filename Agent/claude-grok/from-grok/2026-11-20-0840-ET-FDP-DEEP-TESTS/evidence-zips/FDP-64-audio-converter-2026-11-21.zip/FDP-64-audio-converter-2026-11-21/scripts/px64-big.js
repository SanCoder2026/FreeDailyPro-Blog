// FDP-64: 63 MB WAV on the trial (page says "over 500 MB may take longer"; code soft limit 50 MB trial, 200 MB hard). Guest; no download. Also M4A quality estimates.
const { chromium } = require('playwright'); const fs = require('fs'); const O = '/workspace/deep/64-audio-converter/live/';
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 1000 } })).newPage(); p.setDefaultTimeout(15000); const R = {};
 await p.goto('https://www.freedailypro.com/tool/audio-converter', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4000);
 await p.locator('main input[type=file]').first().setInputFiles('/workspace/deep/64-audio-converter/big-60mb.wav'); await p.waitForTimeout(5000);
 const t = await p.evaluate(() => document.querySelector('main').innerText); const i = t.indexOf('big-60mb'); R.big = t.slice(i, i + 600); R.convertEnabled = await p.locator('main button', { hasText: /^Convert$/ }).isEnabled().catch(() => null); await p.screenshot({ path: O + 'cases/big-63mb.png' });
 await p.goto('https://www.freedailypro.com/tool/audio-converter', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); await p.locator('main input[type=file]').first().setInputFiles('/workspace/deep/64-audio-converter/testfiles/tone-12s.wav'); await p.waitForTimeout(3000);
 await p.locator('main [aria-label="Output format"]').click(); await p.locator('[role=option]', { hasText: 'M4A' }).click(); await p.waitForTimeout(400); R.m4a = {};
 for (const q of ['Same as original', 'High (largest file)', 'Standard', 'Small (smaller file)']) { await p.locator('main button', { hasText: q }).first().click(); await p.waitForTimeout(300); R.m4a[q] = await p.evaluate(() => (document.querySelector('main').innerText.match(/About \d[^\n]*/) || [null])[0]); }
 fs.writeFileSync(O + 'big.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); await b.close(); })();
