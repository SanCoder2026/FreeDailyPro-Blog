import { r as p, j as t } from "./vendor-react-D01g8YgM.js";
import { r as w, c as y } from "./colorUtils-V4qYQx5D.js";
import { T as v } from "./ToolPage-DwLoDncN.js";
import { e as h, I as x } from "./index-B1CTyGtY.js";
import { T as j } from "./ToolInfoSection-C0i6Zbwo.js";
import { u as b } from "./useLogToolUsage-BdvvKW0n.js";
import { c as C } from "./copyText-DPnES92p.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
const n = {
  what: "Converts a color between HEX, RGB, HSL, HSV, HWB, CMYK, LAB and OKLCH, and shows the nearest CSS color name, since different design tools and code contexts expect different color formats.",
  how: "Enter a color in any supported format (HEX, rgb(), hsl(), oklch() or a name), and its equivalent values in the other formats are displayed automatically. If what you type isn't a color, the last good result stays on screen with a message. If a value was out of range, such as rgb(300, 0, 0), a note says what it was clamped to.",
  tip: "HSL is often the easiest format to work with when you want to tweak a color's lightness or saturation without changing its underlying hue — adjust one HSL value and convert back to hex when you're happy with it.",
};
function Z() {
  const [i, l] = p.useState("#6366f1"),
    c = p.useRef(null),
    { shown: e, invalid: s, notices: m, last: u } = w(i, c.current);
  c.current = u;
  const f = !s && i.trim() !== "" ? e : null,
    { blocked: d } = b(!!f, 3e3, { ownActions: !0 }),
    g = [
      ["HEX", e?.hex],
      ["RGB", e?.rgb],
      ["HSL", e?.hsl],
      ["HSV / HSB", e?.hsv],
      ["HWB", e?.hwb],
      ["CMYK (screen estimate)", e?.cmyk],
      ["LAB (D50, as in CSS lab())", e?.lab],
      ["OKLCH", e?.oklch],
      ["Nearest CSS name", e?.name],
      ["CSS", e?.css],
    ];
  return t.jsxs(v, {
    children: [
      t.jsxs("div", {
        className: "grid grid-cols-1 md:grid-cols-2 gap-8",
        children: [
          t.jsxs("div", {
            className: "space-y-3",
            children: [
              t.jsxs("div", {
                children: [
                  t.jsx(h, {
                    children:
                      "Color (HEX, rgb(), hsl(), or a name like tomato)",
                  }),
                  t.jsxs("div", {
                    className: "flex gap-2",
                    children: [
                      t.jsx(x, {
                        value: i,
                        onChange: (o) => l(o.target.value),
                        placeholder: "#6366f1",
                        className: "font-mono",
                        "aria-invalid": s,
                      }),
                      t.jsx("input", {
                        type: "color",
                        "aria-label": "Pick a color",
                        value: e ? e.hex.slice(0, 7) : "#000000",
                        onChange: (o) => l(o.target.value),
                        className: "h-9 w-12 rounded border bg-transparent p-1",
                      }),
                    ],
                  }),
                  s &&
                    t.jsxs("p", {
                      role: "alert",
                      className: "text-sm text-destructive mt-1",
                      children: [
                        "Not a valid colour. Try #ff6600, rgb(255, 102, 0), hsl(24, 100%, 50%), oklch(70% 0.2 50) or a name like orange.",
                        e
                          ? ` Still showing the last valid colour, ${e.hex}.`
                          : "",
                      ],
                    }),
                  m.length > 0 &&
                    t.jsx("p", {
                      role: "status",
                      className:
                        "text-sm text-amber-700 dark:text-amber-400 mt-1",
                      children: m.join(" "),
                    }),
                ],
              }),
              g.map(([o, a]) =>
                t.jsxs(
                  "div",
                  {
                    children: [
                      t.jsx(h, {
                        className: "text-xs text-muted-foreground",
                        children: o,
                      }),
                      t.jsxs("div", {
                        className: "flex gap-2",
                        children: [
                          t.jsx(x, {
                            readOnly: !0,
                            "aria-label": o,
                            value: a ?? "",
                            className: `font-mono ${s ? "opacity-60" : ""}`,
                          }),
                          t.jsx("button", {
                            type: "button",
                            className:
                              "text-xs text-primary hover:underline shrink-0 disabled:opacity-40",
                            disabled: !a || d,
                            "aria-label": `Copy ${o}`,
                            onClick: () => {
                              C(a ?? "", "Copied");
                            },
                            children: "Copy",
                          }),
                        ],
                      }),
                    ],
                  },
                  o,
                ),
              ),
            ],
          }),
          t.jsxs("div", {
            className: "flex flex-col items-center justify-center gap-4",
            children: [
              t.jsx("div", {
                className: `w-48 h-48 rounded-2xl border shadow-lg ${s ? "opacity-60" : ""}`,
                style: { backgroundColor: e?.hex ?? "transparent" },
              }),
              e &&
                !d &&
                t.jsx("dl", {
                  className: "text-xs text-muted-foreground space-y-1",
                  "data-testid": "cc-contrast",
                  children: [
                    ["white", "#ffffff"],
                    ["black", "#000000"],
                  ].map(([o, a]) => {
                    const r = y(e.hex, a) ?? 0;
                    return t.jsxs(
                      "div",
                      {
                        className: "flex gap-2",
                        children: [
                          t.jsxs("dt", { children: ["Contrast on ", o, ":"] }),
                          t.jsxs("dd", {
                            className: "font-mono",
                            children: [
                              r.toFixed(2),
                              ":1 (",
                              r >= 7
                                ? "AAA"
                                : r >= 4.5
                                  ? "AA"
                                  : r >= 3
                                    ? "AA large text only"
                                    : "fails AA",
                              ")",
                            ],
                          }),
                        ],
                      },
                      o,
                    );
                  }),
                }),
            ],
          }),
        ],
      }),
      t.jsx(j, { whatIsIt: n.what, howToUse: n.how, tip: n.tip }),
    ],
  });
}
export { Z as default };
//# sourceMappingURL=ColorConverter-Fmg0nTvn.js.map
