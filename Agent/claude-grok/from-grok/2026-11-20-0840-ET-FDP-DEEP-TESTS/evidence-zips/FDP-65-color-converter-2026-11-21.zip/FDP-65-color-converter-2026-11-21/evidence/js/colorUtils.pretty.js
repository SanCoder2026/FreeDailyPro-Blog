for (
  var At = { grad: 0.9, turn: 360, rad: 360 / (2 * Math.PI) },
    N = function (t) {
      return typeof t == "string" ? t.length > 0 : typeof t == "number";
    },
    g = function (t, e, a) {
      return (
        e === void 0 && (e = 0),
        a === void 0 && (a = Math.pow(10, e)),
        Math.round(a * t) / a + 0
      );
    },
    m = function (t, e, a) {
      return (
        e === void 0 && (e = 0),
        a === void 0 && (a = 1),
        t > a ? a : t > e ? t : e
      );
    },
    Ft = function (t) {
      return (t = isFinite(t) ? t % 360 : 0) < 0 ? t + 360 : t;
    },
    tt = function (t, e) {
      return (e === void 0 && (e = 0), g(t, e) % 360);
    },
    bt = function (t) {
      return {
        r: m(t.r, 0, 255),
        g: m(t.g, 0, 255),
        b: m(t.b, 0, 255),
        a: m(t.a),
      };
    },
    K = function (t) {
      return { r: g(t.r), g: g(t.g), b: g(t.b), a: g(t.a, 3) };
    },
    Bt = /^#([0-9a-f]{3,8})$/i,
    z = function (t, e) {
      var a = t.charCodeAt(e);
      return (15 & a) + 9 * (a >> 6);
    },
    I = function (t, e) {
      return (z(t, e) << 4) | z(t, e + 1);
    },
    zt = [],
    P = 0;
  P < 256;
  P++
)
  zt.push((P < 16 ? "0" : "") + P.toString(16));
var O = function (t) {
    return zt[m(t, 0, 255)];
  },
  Ht = function (t) {
    var e = t.r,
      a = t.g,
      n = t.b,
      r = t.a,
      o = Math.max(e, a, n),
      i = o - Math.min(e, a, n),
      u = i
        ? o === e
          ? (a - n) / i
          : o === a
            ? 2 + (n - e) / i
            : 4 + (e - a) / i
        : 0;
    return {
      h: 60 * (u < 0 ? u + 6 : u),
      s: o ? (i / o) * 100 : 0,
      v: (o / 255) * 100,
      a: r,
    };
  },
  Ct = function (t) {
    var e = t.h,
      a = t.s,
      n = t.v,
      r = t.a;
    ((e = (e / 360) * 6), (a /= 100), (n /= 100));
    var o = Math.floor(e),
      i = n * (1 - a),
      u = n * (1 - (e - o) * a),
      s = n * (1 - (1 - e + o) * a),
      h = o % 6;
    return {
      r: 255 * [n, u, i, i, s, n][h],
      g: 255 * [s, n, n, u, i, i][h],
      b: 255 * [i, i, s, n, n, u][h],
      a: r,
    };
  },
  gt = function (t) {
    return { h: Ft(t.h), s: m(t.s, 0, 100), l: m(t.l, 0, 100), a: m(t.a) };
  },
  pt = function (t) {
    return { h: tt(t.h), s: g(t.s), l: g(t.l), a: g(t.a, 3) };
  },
  mt = function (t) {
    return Ct(
      ((a = (e = t).s),
      {
        h: e.h,
        s:
          (a *= ((n = e.l) < 50 ? n : 100 - n) / 100) > 0
            ? ((2 * a) / (n + a)) * 100
            : 0,
        v: n + a,
        a: e.a,
      }),
    );
    var e, a, n;
  },
  H = function (t) {
    return {
      h: (e = Ht(t)).h,
      s:
        (r = ((200 - (a = e.s)) * (n = e.v)) / 100) > 0 && r < 200
          ? ((a * n) / 100 / (r <= 100 ? r : 200 - r)) * 100
          : 0,
      l: r / 2,
      a: e.a,
    };
    var e, a, n, r;
  },
  Gt =
    /^hsla?\(\s*([+-]?(?:\d*\.\d+|\d+))(deg|rad|grad|turn)?\s*,\s*([+-]?(?:\d*\.\d+|\d+))%\s*,\s*([+-]?(?:\d*\.\d+|\d+))%\s*(?:,\s*([+-]?(?:\d*\.\d+|\d+))(%)?\s*)?\)$/i,
  Dt =
    /^hsla?\(\s*([+-]?(?:\d*\.\d+|\d+))(deg|rad|grad|turn)?\s+([+-]?(?:\d*\.\d+|\d+))%\s+([+-]?(?:\d*\.\d+|\d+))%\s*(?:\/\s*([+-]?(?:\d*\.\d+|\d+))(%)?\s*)?\)$/i,
  Vt =
    /^rgba?\(\s*([+-]?(?:\d*\.\d+|\d+))(%)?\s*,\s*([+-]?(?:\d*\.\d+|\d+))(%)?\s*,\s*([+-]?(?:\d*\.\d+|\d+))(%)?\s*(?:,\s*([+-]?(?:\d*\.\d+|\d+))(%)?\s*)?\)$/i,
  Wt =
    /^rgba?\(\s*([+-]?(?:\d*\.\d+|\d+))(%)?\s+([+-]?(?:\d*\.\d+|\d+))(%)?\s+([+-]?(?:\d*\.\d+|\d+))(%)?\s*(?:\/\s*([+-]?(?:\d*\.\d+|\d+))(%)?\s*)?\)$/i,
  et = {
    string: [
      [
        function (t) {
          if (!Bt.test(t)) return null;
          var e = t.length;
          return e <= 5
            ? {
                r: 17 * z(t, 1),
                g: 17 * z(t, 2),
                b: 17 * z(t, 3),
                a: e === 5 ? g((17 * z(t, 4)) / 255, 2) : 1,
              }
            : e === 7 || e === 9
              ? {
                  r: I(t, 1),
                  g: I(t, 3),
                  b: I(t, 5),
                  a: e === 9 ? g(I(t, 7) / 255, 2) : 1,
                }
              : null;
        },
        "hex",
      ],
      [
        function (t) {
          var e = Vt.exec(t) || Wt.exec(t);
          return e
            ? e[2] !== e[4] || e[4] !== e[6]
              ? null
              : bt({
                  r: Number(e[1]) / (e[2] ? 100 / 255 : 1),
                  g: Number(e[3]) / (e[4] ? 100 / 255 : 1),
                  b: Number(e[5]) / (e[6] ? 100 / 255 : 1),
                  a: e[7] === void 0 ? 1 : Number(e[7]) / (e[8] ? 100 : 1),
                })
            : null;
        },
        "rgb",
      ],
      [
        function (t) {
          var e = Gt.exec(t) || Dt.exec(t);
          if (!e) return null;
          var a,
            n,
            r = gt({
              h:
                ((a = e[1]),
                (n = e[2]),
                n === void 0 && (n = "deg"),
                Number(a) * (At[n] || 1)),
              s: Number(e[3]),
              l: Number(e[4]),
              a: e[5] === void 0 ? 1 : Number(e[5]) / (e[6] ? 100 : 1),
            });
          return mt(r);
        },
        "hsl",
      ],
    ],
    object: [
      [
        function (t) {
          var e = t.r,
            a = t.g,
            n = t.b,
            r = t.a,
            o = r === void 0 ? 1 : r;
          return N(e) && N(a) && N(n)
            ? bt({ r: Number(e), g: Number(a), b: Number(n), a: Number(o) })
            : null;
        },
        "rgb",
      ],
      [
        function (t) {
          var e = t.h,
            a = t.s,
            n = t.l,
            r = t.a,
            o = r === void 0 ? 1 : r;
          if (!N(e) || !N(a) || !N(n)) return null;
          var i = gt({
            h: Number(e),
            s: Number(a),
            l: Number(n),
            a: Number(o),
          });
          return mt(i);
        },
        "hsl",
      ],
      [
        function (t) {
          var e = t.h,
            a = t.s,
            n = t.v,
            r = t.a,
            o = r === void 0 ? 1 : r;
          if (!N(e) || !N(a) || !N(n)) return null;
          var i = (function (u) {
            return {
              h: Ft(u.h),
              s: m(u.s, 0, 100),
              v: m(u.v, 0, 100),
              a: m(u.a),
            };
          })({ h: Number(e), s: Number(a), v: Number(n), a: Number(o) });
          return Ct(i);
        },
        "hsv",
      ],
    ],
  },
  vt = function (t, e) {
    for (var a = 0; a < e.length; a++) {
      var n = e[a][0](t);
      if (n) return [n, e[a][1]];
    }
    return [null, void 0];
  },
  Kt = function (t) {
    return typeof t == "string"
      ? vt(t.trim(), et.string)
      : typeof t == "object" && t !== null
        ? vt(t, et.object)
        : [null, void 0];
  },
  J = function (t, e) {
    var a = H(t);
    return { h: a.h, s: m(a.s + 100 * e, 0, 100), l: a.l, a: a.a };
  },
  Q = function (t) {
    return (299 * t.r + 587 * t.g + 114 * t.b) / 1e3 / 255;
  },
  yt = function (t, e) {
    var a = H(t);
    return { h: a.h, s: a.s, l: m(a.l + 100 * e, 0, 100), a: a.a };
  },
  at = (function () {
    function t(e) {
      ((this.parsed = Kt(e)[0]),
        (this.rgba = this.parsed || { r: 0, g: 0, b: 0, a: 1 }));
    }
    return (
      (t.prototype.isValid = function () {
        return this.parsed !== null;
      }),
      (t.prototype.brightness = function () {
        return g(Q(this.rgba), 2);
      }),
      (t.prototype.isDark = function () {
        return Q(this.rgba) < 0.5;
      }),
      (t.prototype.isLight = function () {
        return Q(this.rgba) >= 0.5;
      }),
      (t.prototype.toHex = function () {
        return (
          (e = K(this.rgba)),
          (a = e.r),
          (n = e.g),
          (r = e.b),
          (i = (o = e.a) < 1 ? O(g(255 * o)) : ""),
          "#" + O(a) + O(n) + O(r) + i
        );
        var e, a, n, r, o, i;
      }),
      (t.prototype.toRgb = function () {
        return K(this.rgba);
      }),
      (t.prototype.toRgbString = function () {
        return (
          (e = K(this.rgba)),
          (a = e.r),
          (n = e.g),
          (r = e.b),
          (o = e.a) < 1
            ? "rgba(" + a + ", " + n + ", " + r + ", " + o + ")"
            : "rgb(" + a + ", " + n + ", " + r + ")"
        );
        var e, a, n, r, o;
      }),
      (t.prototype.toHsl = function () {
        return pt(H(this.rgba));
      }),
      (t.prototype.toHslString = function () {
        return (
          (e = pt(H(this.rgba))),
          (a = e.h),
          (n = e.s),
          (r = e.l),
          (o = e.a) < 1
            ? "hsla(" + a + ", " + n + "%, " + r + "%, " + o + ")"
            : "hsl(" + a + ", " + n + "%, " + r + "%)"
        );
        var e, a, n, r, o;
      }),
      (t.prototype.toHsv = function () {
        return (
          (e = Ht(this.rgba)),
          { h: tt(e.h), s: g(e.s), v: g(e.v), a: g(e.a, 3) }
        );
        var e;
      }),
      (t.prototype.invert = function () {
        return v({
          r: 255 - (e = this.rgba).r,
          g: 255 - e.g,
          b: 255 - e.b,
          a: e.a,
        });
        var e;
      }),
      (t.prototype.saturate = function (e) {
        return (e === void 0 && (e = 0.1), v(J(this.rgba, e)));
      }),
      (t.prototype.desaturate = function (e) {
        return (e === void 0 && (e = 0.1), v(J(this.rgba, -e)));
      }),
      (t.prototype.grayscale = function () {
        return v(J(this.rgba, -1));
      }),
      (t.prototype.lighten = function (e) {
        return (e === void 0 && (e = 0.1), v(yt(this.rgba, e)));
      }),
      (t.prototype.darken = function (e) {
        return (e === void 0 && (e = 0.1), v(yt(this.rgba, -e)));
      }),
      (t.prototype.rotate = function (e) {
        return (e === void 0 && (e = 15), this.hue(H(this.rgba).h + e));
      }),
      (t.prototype.alpha = function (e) {
        return typeof e == "number"
          ? v({ r: (a = this.rgba).r, g: a.g, b: a.b, a: e })
          : g(this.rgba.a, 3);
        var a;
      }),
      (t.prototype.hue = function (e) {
        var a = H(this.rgba);
        return typeof e == "number"
          ? v({ h: e, s: a.s, l: a.l, a: a.a })
          : tt(a.h);
      }),
      (t.prototype.isEqual = function (e) {
        return this.toHex() === v(e).toHex();
      }),
      t
    );
  })(),
  v = function (t) {
    return t instanceof at ? t : new at(t);
  },
  Mt = [],
  Jt = function (t) {
    t.forEach(function (e) {
      Mt.indexOf(e) < 0 && (e(at, et), Mt.push(e));
    });
  },
  Qt = function (t, e) {
    var a = {
        white: "#ffffff",
        bisque: "#ffe4c4",
        blue: "#0000ff",
        cadetblue: "#5f9ea0",
        chartreuse: "#7fff00",
        chocolate: "#d2691e",
        coral: "#ff7f50",
        antiquewhite: "#faebd7",
        aqua: "#00ffff",
        azure: "#f0ffff",
        whitesmoke: "#f5f5f5",
        papayawhip: "#ffefd5",
        plum: "#dda0dd",
        blanchedalmond: "#ffebcd",
        black: "#000000",
        gold: "#ffd700",
        goldenrod: "#daa520",
        gainsboro: "#dcdcdc",
        cornsilk: "#fff8dc",
        cornflowerblue: "#6495ed",
        burlywood: "#deb887",
        aquamarine: "#7fffd4",
        beige: "#f5f5dc",
        crimson: "#dc143c",
        cyan: "#00ffff",
        darkblue: "#00008b",
        darkcyan: "#008b8b",
        darkgoldenrod: "#b8860b",
        darkkhaki: "#bdb76b",
        darkgray: "#a9a9a9",
        darkgreen: "#006400",
        darkgrey: "#a9a9a9",
        peachpuff: "#ffdab9",
        darkmagenta: "#8b008b",
        darkred: "#8b0000",
        darkorchid: "#9932cc",
        darkorange: "#ff8c00",
        darkslateblue: "#483d8b",
        gray: "#808080",
        darkslategray: "#2f4f4f",
        darkslategrey: "#2f4f4f",
        deeppink: "#ff1493",
        deepskyblue: "#00bfff",
        wheat: "#f5deb3",
        firebrick: "#b22222",
        floralwhite: "#fffaf0",
        ghostwhite: "#f8f8ff",
        darkviolet: "#9400d3",
        magenta: "#ff00ff",
        green: "#008000",
        dodgerblue: "#1e90ff",
        grey: "#808080",
        honeydew: "#f0fff0",
        hotpink: "#ff69b4",
        blueviolet: "#8a2be2",
        forestgreen: "#228b22",
        lawngreen: "#7cfc00",
        indianred: "#cd5c5c",
        indigo: "#4b0082",
        fuchsia: "#ff00ff",
        brown: "#a52a2a",
        maroon: "#800000",
        mediumblue: "#0000cd",
        lightcoral: "#f08080",
        darkturquoise: "#00ced1",
        lightcyan: "#e0ffff",
        ivory: "#fffff0",
        lightyellow: "#ffffe0",
        lightsalmon: "#ffa07a",
        lightseagreen: "#20b2aa",
        linen: "#faf0e6",
        mediumaquamarine: "#66cdaa",
        lemonchiffon: "#fffacd",
        lime: "#00ff00",
        khaki: "#f0e68c",
        mediumseagreen: "#3cb371",
        limegreen: "#32cd32",
        mediumspringgreen: "#00fa9a",
        lightskyblue: "#87cefa",
        lightblue: "#add8e6",
        midnightblue: "#191970",
        lightpink: "#ffb6c1",
        mistyrose: "#ffe4e1",
        moccasin: "#ffe4b5",
        mintcream: "#f5fffa",
        lightslategray: "#778899",
        lightslategrey: "#778899",
        navajowhite: "#ffdead",
        navy: "#000080",
        mediumvioletred: "#c71585",
        powderblue: "#b0e0e6",
        palegoldenrod: "#eee8aa",
        oldlace: "#fdf5e6",
        paleturquoise: "#afeeee",
        mediumturquoise: "#48d1cc",
        mediumorchid: "#ba55d3",
        rebeccapurple: "#663399",
        lightsteelblue: "#b0c4de",
        mediumslateblue: "#7b68ee",
        thistle: "#d8bfd8",
        tan: "#d2b48c",
        orchid: "#da70d6",
        mediumpurple: "#9370db",
        purple: "#800080",
        pink: "#ffc0cb",
        skyblue: "#87ceeb",
        springgreen: "#00ff7f",
        palegreen: "#98fb98",
        red: "#ff0000",
        yellow: "#ffff00",
        slateblue: "#6a5acd",
        lavenderblush: "#fff0f5",
        peru: "#cd853f",
        palevioletred: "#db7093",
        violet: "#ee82ee",
        teal: "#008080",
        slategray: "#708090",
        slategrey: "#708090",
        aliceblue: "#f0f8ff",
        darkseagreen: "#8fbc8f",
        darkolivegreen: "#556b2f",
        greenyellow: "#adff2f",
        seagreen: "#2e8b57",
        seashell: "#fff5ee",
        tomato: "#ff6347",
        silver: "#c0c0c0",
        sienna: "#a0522d",
        lavender: "#e6e6fa",
        lightgreen: "#90ee90",
        orange: "#ffa500",
        orangered: "#ff4500",
        steelblue: "#4682b4",
        royalblue: "#4169e1",
        turquoise: "#40e0d0",
        yellowgreen: "#9acd32",
        salmon: "#fa8072",
        saddlebrown: "#8b4513",
        sandybrown: "#f4a460",
        rosybrown: "#bc8f8f",
        darksalmon: "#e9967a",
        lightgoldenrodyellow: "#fafad2",
        snow: "#fffafa",
        lightgrey: "#d3d3d3",
        lightgray: "#d3d3d3",
        dimgray: "#696969",
        dimgrey: "#696969",
        olivedrab: "#6b8e23",
        olive: "#808000",
      },
      n = {};
    for (var r in a) n[a[r]] = r;
    var o = {};
    ((t.prototype.toName = function (i) {
      if (!(this.rgba.a || this.rgba.r || this.rgba.g || this.rgba.b))
        return "transparent";
      var u,
        s,
        h = n[this.toHex()];
      if (h) return h;
      if (i?.closest) {
        var c = this.toRgb(),
          f = 1 / 0,
          d = "black";
        if (!o.length) for (var b in a) o[b] = new t(a[b]).toRgb();
        for (var l in a) {
          var p =
            ((u = c),
            (s = o[l]),
            Math.pow(u.r - s.r, 2) +
              Math.pow(u.g - s.g, 2) +
              Math.pow(u.b - s.b, 2));
          p < f && ((f = p), (d = l));
        }
        return d;
      }
    }),
      e.string.push([
        function (i) {
          var u = i.toLowerCase(),
            s = u === "transparent" ? "#0000" : a[u];
          return s ? new t(s).toRgb() : null;
        },
        "name",
      ]));
  },
  S = function (t) {
    return typeof t == "string" ? t.length > 0 : typeof t == "number";
  },
  y = function (t, e, a) {
    return (
      e === void 0 && (e = 0),
      a === void 0 && (a = Math.pow(10, e)),
      Math.round(a * t) / a + 0
    );
  },
  R = function (t, e, a) {
    return (
      e === void 0 && (e = 0),
      a === void 0 && (a = 1),
      t > a ? a : t > e ? t : e
    );
  },
  Rt = function (t) {
    return {
      c: R(t.c, 0, 100),
      m: R(t.m, 0, 100),
      y: R(t.y, 0, 100),
      k: R(t.k, 0, 100),
      a: R(t.a),
    };
  },
  wt = function (t) {
    return {
      c: y(t.c, 2),
      m: y(t.m, 2),
      y: y(t.y, 2),
      k: y(t.k, 2),
      a: y(t.a, 3),
    };
  };
function qt(t) {
  return {
    r: y(255 * (1 - t.c / 100) * (1 - t.k / 100)),
    g: y(255 * (1 - t.m / 100) * (1 - t.k / 100)),
    b: y(255 * (1 - t.y / 100) * (1 - t.k / 100)),
    a: t.a,
  };
}
function kt(t) {
  var e = 1 - Math.max(t.r / 255, t.g / 255, t.b / 255),
    a = (1 - t.r / 255 - e) / (1 - e),
    n = (1 - t.g / 255 - e) / (1 - e),
    r = (1 - t.b / 255 - e) / (1 - e);
  return {
    c: isNaN(a) ? 0 : y(100 * a),
    m: isNaN(n) ? 0 : y(100 * n),
    y: isNaN(r) ? 0 : y(100 * r),
    k: y(100 * e),
    a: t.a,
  };
}
function Ut(t) {
  var e = t.c,
    a = t.m,
    n = t.y,
    r = t.k,
    o = t.a,
    i = o === void 0 ? 1 : o;
  return S(e) && S(a) && S(n) && S(r)
    ? qt(
        Rt({
          c: Number(e),
          m: Number(a),
          y: Number(n),
          k: Number(r),
          a: Number(i),
        }),
      )
    : null;
}
var Xt =
    /^device-cmyk\(\s*([+-]?(?:\d*\.\d+|\d+))(%)?\s+([+-]?(?:\d*\.\d+|\d+))(%)?\s+([+-]?(?:\d*\.\d+|\d+))(%)?\s+([+-]?(?:\d*\.\d+|\d+))(%)?\s*(?:\/\s*([+-]?(?:\d*\.\d+|\d+))(%)?\s*)?\)$/i,
  Yt = function (t) {
    var e = Xt.exec(t);
    return e
      ? qt(
          Rt({
            c: Number(e[1]) * (e[2] ? 1 : 100),
            m: Number(e[3]) * (e[4] ? 1 : 100),
            y: Number(e[5]) * (e[6] ? 1 : 100),
            k: Number(e[7]) * (e[8] ? 1 : 100),
            a: e[9] === void 0 ? 1 : Number(e[9]) / (e[10] ? 100 : 1),
          }),
        )
      : null;
  },
  Zt = function (t, e) {
    ((t.prototype.toCmyk = function () {
      return wt(kt(this.rgba));
    }),
      (t.prototype.toCmykString = function () {
        return (
          (a = wt(kt(this.rgba))),
          (n = a.c),
          (r = a.m),
          (o = a.y),
          (i = a.k),
          (u = a.a) < 1
            ? "device-cmyk(" +
              n +
              "% " +
              r +
              "% " +
              o +
              "% " +
              i +
              "% / " +
              u +
              ")"
            : "device-cmyk(" + n + "% " + r + "% " + o + "% " + i + "%)"
        );
        var a, n, r, o, i, u;
      }),
      e.object.push([Ut, "cmyk"]),
      e.string.push([Yt, "cmyk"]));
  },
  _t = { grad: 0.9, turn: 360, rad: 360 / (2 * Math.PI) },
  U = function (t) {
    return typeof t == "string" ? t.length > 0 : typeof t == "number";
  },
  E = function (t, e, a) {
    return (
      e === void 0 && (e = 0),
      a === void 0 && (a = Math.pow(10, e)),
      Math.round(a * t) / a + 0
    );
  },
  X = function (t, e, a) {
    return (
      e === void 0 && (e = 0),
      a === void 0 && (a = 1),
      t > a ? a : t > e ? t : e
    );
  },
  Lt = function (t) {
    return {
      h: ((e = t.h), (e = isFinite(e) ? e % 360 : 0) < 0 ? e + 360 : e),
      w: X(t.w, 0, 100),
      b: X(t.b, 0, 100),
      a: X(t.a),
    };
    var e;
  },
  Nt = function (t) {
    return {
      h: ((e = t.h), a === void 0 && (a = 0), E(e, a) % 360),
      w: E(t.w),
      b: E(t.b),
      a: E(t.a, 3),
    };
    var e, a;
  },
  xt = function (t) {
    return {
      h: (function (e) {
        var a = e.r,
          n = e.g,
          r = e.b,
          o = e.a,
          i = Math.max(a, n, r),
          u = i - Math.min(a, n, r),
          s = u
            ? i === a
              ? (n - r) / u
              : i === n
                ? 2 + (r - a) / u
                : 4 + (a - n) / u
            : 0;
        return {
          h: 60 * (s < 0 ? s + 6 : s),
          s: i ? (u / i) * 100 : 0,
          v: (i / 255) * 100,
          a: o,
        };
      })(t).h,
      w: (Math.min(t.r, t.g, t.b) / 255) * 100,
      b: 100 - (Math.max(t.r, t.g, t.b) / 255) * 100,
      a: t.a,
    };
  },
  jt = function (t) {
    if (t.w + t.b >= 100) {
      var e = (t.w / (t.w + t.b)) * 255;
      return { r: e, g: e, b: e, a: t.a };
    }
    return (function (a) {
      var n = a.h,
        r = a.s,
        o = a.v,
        i = a.a;
      ((n = (n / 360) * 6), (r /= 100), (o /= 100));
      var u = Math.floor(n),
        s = o * (1 - r),
        h = o * (1 - (n - u) * r),
        c = o * (1 - (1 - n + u) * r),
        f = u % 6;
      return {
        r: 255 * [o, h, s, s, c, o][f],
        g: 255 * [c, o, o, h, s, s][f],
        b: 255 * [s, s, c, o, o, h][f],
        a: i,
      };
    })({ h: t.h, s: 100 - (t.w / (100 - t.b)) * 100, v: 100 - t.b, a: t.a });
  },
  t0 = function (t) {
    var e = t.h,
      a = t.w,
      n = t.b,
      r = t.a,
      o = r === void 0 ? 1 : r;
    if (!U(e) || !U(a) || !U(n)) return null;
    var i = Lt({ h: Number(e), w: Number(a), b: Number(n), a: Number(o) });
    return jt(i);
  },
  e0 =
    /^hwb\(\s*([+-]?(?:\d*\.\d+|\d+))(deg|rad|grad|turn)?\s+([+-]?(?:\d*\.\d+|\d+))%\s+([+-]?(?:\d*\.\d+|\d+))%\s*(?:\/\s*([+-]?(?:\d*\.\d+|\d+))(%)?\s*)?\)$/i,
  a0 = function (t) {
    var e = e0.exec(t);
    if (!e) return null;
    var a,
      n,
      r = Lt({
        h:
          ((a = e[1]),
          (n = e[2]),
          n === void 0 && (n = "deg"),
          Number(a) * (_t[n] || 1)),
        w: Number(e[3]),
        b: Number(e[4]),
        a: e[5] === void 0 ? 1 : Number(e[5]) / (e[6] ? 100 : 1),
      });
    return jt(r);
  },
  n0 = function (t, e) {
    ((t.prototype.toHwb = function () {
      return Nt(xt(this.rgba));
    }),
      (t.prototype.toHwbString = function () {
        return (
          (a = Nt(xt(this.rgba))),
          (n = a.h),
          (r = a.w),
          (o = a.b),
          (i = a.a) < 1
            ? "hwb(" + n + " " + r + "% " + o + "% / " + i + ")"
            : "hwb(" + n + " " + r + "% " + o + "%)"
        );
        var a, n, r, o, i;
      }),
      e.string.push([a0, "hwb"]),
      e.object.push([t0, "hwb"]));
  },
  Y = function (t) {
    return typeof t == "string" ? t.length > 0 : typeof t == "number";
  },
  q = function (t, e, a) {
    return (
      e === void 0 && (e = 0),
      a === void 0 && (a = Math.pow(10, e)),
      Math.round(a * t) / a + 0
    );
  },
  w = function (t, e, a) {
    return (
      e === void 0 && (e = 0),
      a === void 0 && (a = 1),
      t > a ? a : t > e ? t : e
    );
  },
  Z = function (t) {
    var e = t / 255;
    return e < 0.04045 ? e / 12.92 : Math.pow((e + 0.055) / 1.055, 2.4);
  },
  _ = function (t) {
    return (
      255 * (t > 0.0031308 ? 1.055 * Math.pow(t, 1 / 2.4) - 0.055 : 12.92 * t)
    );
  },
  nt = 96.422,
  rt = 100,
  ot = 82.521,
  r0 = function (t) {
    var e,
      a,
      n = {
        x: 0.9555766 * (e = t).x + -0.0230393 * e.y + 0.0631636 * e.z,
        y: -0.0282895 * e.x + 1.0099416 * e.y + 0.0210077 * e.z,
        z: 0.0122982 * e.x + -0.020483 * e.y + 1.3299098 * e.z,
      };
    return (
      (a = {
        r: _(0.032404542 * n.x - 0.015371385 * n.y - 0.004985314 * n.z),
        g: _(-0.00969266 * n.x + 0.018760108 * n.y + 41556e-8 * n.z),
        b: _(556434e-9 * n.x - 0.002040259 * n.y + 0.010572252 * n.z),
        a: t.a,
      }),
      { r: w(a.r, 0, 255), g: w(a.g, 0, 255), b: w(a.b, 0, 255), a: w(a.a) }
    );
  },
  o0 = function (t) {
    var e = Z(t.r),
      a = Z(t.g),
      n = Z(t.b);
    return (function (r) {
      return {
        x: w(r.x, 0, nt),
        y: w(r.y, 0, rt),
        z: w(r.z, 0, ot),
        a: w(r.a),
      };
    })(
      (function (r) {
        return {
          x: 1.0478112 * r.x + 0.0228866 * r.y + -0.050127 * r.z,
          y: 0.0295424 * r.x + 0.9904844 * r.y + -0.0170491 * r.z,
          z: -0.0092345 * r.x + 0.0150436 * r.y + 0.7521316 * r.z,
          a: r.a,
        };
      })({
        x: 100 * (0.4124564 * e + 0.3575761 * a + 0.1804375 * n),
        y: 100 * (0.2126729 * e + 0.7151522 * a + 0.072175 * n),
        z: 100 * (0.0193339 * e + 0.119192 * a + 0.9503041 * n),
        a: t.a,
      }),
    );
  },
  L = 216 / 24389,
  C = 24389 / 27,
  i0 = function (t) {
    var e = t.l,
      a = t.a,
      n = t.b,
      r = t.alpha,
      o = r === void 0 ? 1 : r;
    if (!Y(e) || !Y(a) || !Y(n)) return null;
    var i = (function (u) {
      return { l: w(u.l, 0, 400), a: u.a, b: u.b, alpha: w(u.alpha) };
    })({ l: Number(e), a: Number(a), b: Number(n), alpha: Number(o) });
    return u0(i);
  },
  u0 = function (t) {
    var e = (t.l + 16) / 116,
      a = t.a / 500 + e,
      n = e - t.b / 200;
    return r0({
      x: (Math.pow(a, 3) > L ? Math.pow(a, 3) : (116 * a - 16) / C) * nt,
      y: (t.l > 8 ? Math.pow((t.l + 16) / 116, 3) : t.l / C) * rt,
      z: (Math.pow(n, 3) > L ? Math.pow(n, 3) : (116 * n - 16) / C) * ot,
      a: t.alpha,
    });
  },
  s0 = function (t, e) {
    ((t.prototype.toLab = function () {
      return (
        (n = o0(this.rgba)),
        (o = n.y / rt),
        (i = n.z / ot),
        (r = (r = n.x / nt) > L ? Math.cbrt(r) : (C * r + 16) / 116),
        (a = {
          l: 116 * (o = o > L ? Math.cbrt(o) : (C * o + 16) / 116) - 16,
          a: 500 * (r - o),
          b: 200 * (o - (i = i > L ? Math.cbrt(i) : (C * i + 16) / 116)),
          alpha: n.a,
        }),
        { l: q(a.l, 2), a: q(a.a, 2), b: q(a.b, 2), alpha: q(a.alpha, 3) }
      );
      var a, n, r, o, i;
    }),
      (t.prototype.delta = function (a) {
        a === void 0 && (a = "#FFF");
        var n = a instanceof t ? a : new t(a),
          r =
            (function (o, i) {
              var u = o.l,
                s = o.a,
                h = o.b,
                c = i.l,
                f = i.a,
                d = i.b,
                b = 180 / Math.PI,
                l = Math.PI / 180,
                p = Math.pow(Math.pow(s, 2) + Math.pow(h, 2), 0.5),
                M = Math.pow(Math.pow(f, 2) + Math.pow(d, 2), 0.5),
                it = (u + c) / 2,
                ut = Math.pow((p + M) / 2, 7),
                st = 0.5 * (1 - Math.pow(ut / (ut + Math.pow(25, 7)), 0.5)),
                T = s * (1 + st),
                A = f * (1 + st),
                B = Math.pow(Math.pow(T, 2) + Math.pow(h, 2), 0.5),
                G = Math.pow(Math.pow(A, 2) + Math.pow(d, 2), 0.5),
                D = (B + G) / 2,
                x = T === 0 && h === 0 ? 0 : Math.atan2(h, T) * b,
                $ = A === 0 && d === 0 ? 0 : Math.atan2(d, A) * b;
              (x < 0 && (x += 360), $ < 0 && ($ += 360));
              var V = $ - x,
                W = Math.abs($ - x);
              W > 180 && $ <= x ? (V += 360) : W > 180 && $ > x && (V -= 360);
              var k = x + $;
              W <= 180 ? (k /= 2) : (k = (x + $ < 360 ? k + 360 : k - 360) / 2);
              var Pt =
                  1 -
                  0.17 * Math.cos(l * (k - 30)) +
                  0.24 * Math.cos(2 * l * k) +
                  0.32 * Math.cos(l * (3 * k + 6)) -
                  0.2 * Math.cos(l * (4 * k - 63)),
                Ot = c - u,
                ft = G - B,
                ct = 2 * Math.sin((l * V) / 2) * Math.pow(B * G, 0.5),
                St =
                  1 +
                  (0.015 * Math.pow(it - 50, 2)) /
                    Math.pow(20 + Math.pow(it - 50, 2), 0.5),
                ht = 1 + 0.045 * D,
                dt = 1 + 0.015 * D * Pt,
                Et = 30 * Math.exp(-1 * Math.pow((k - 275) / 25, 2)),
                lt = Math.pow(D, 7),
                Tt =
                  -2 *
                  Math.pow(lt / (lt + Math.pow(25, 7)), 0.5) *
                  Math.sin(2 * l * Et);
              return Math.pow(
                Math.pow(Ot / 1 / St, 2) +
                  Math.pow(ft / 1 / ht, 2) +
                  Math.pow(ct / 1 / dt, 2) +
                  (Tt * ft * ct) / (1 * ht * 1 * dt),
                0.5,
              );
            })(this.toLab(), n.toLab()) / 100;
        return w(q(r, 3));
      }),
      e.object.push([i0, "lab"]));
  };
Jt([Qt, Zt, n0, s0]);
function j(t) {
  let e = t.trim();
  if (!e) return null;
  (/^[0-9a-f]{3,8}$/i.test(e) &&
    [3, 4, 6, 8].includes(e.length) &&
    (e = "#" + e),
    /^\d{1,3}\s*[, ]\s*\d{1,3}\s*[, ]\s*\d{1,3}$/.test(e) &&
      (e = `rgb(${e.replace(/\s+/g, ",").replace(/,+/g, ",")})`));
  const a = It(e);
  if (a) return a.color;
  const n = v(e);
  return n.isValid() ? n : null;
}
const f0 = (t) =>
    t <= 0.0031308 ? 12.92 * t : 1.055 * Math.pow(t, 1 / 2.4) - 0.055,
  c0 = (t) => (t <= 0.04045 ? t / 12.92 : Math.pow((t + 0.055) / 1.055, 2.4));
function h0(t, e, a) {
  const [n, r, o] = [t, e, a].map((l) => c0(l / 255)),
    i = Math.cbrt(0.4122214708 * n + 0.5363325363 * r + 0.0514459929 * o),
    u = Math.cbrt(0.2119034982 * n + 0.6806995451 * r + 0.1073969566 * o),
    s = Math.cbrt(0.0883024619 * n + 0.2817188376 * r + 0.6299787005 * o),
    h = 0.2104542553 * i + 0.793617785 * u - 0.0040720468 * s,
    c = 1.9779984951 * i - 2.428592205 * u + 0.4505937099 * s,
    f = 0.0259040371 * i + 0.7827717662 * u - 0.808675766 * s,
    d = Math.hypot(c, f),
    b = d < 4e-4 ? 0 : ((Math.atan2(f, c) * 180) / Math.PI + 360) % 360;
  return { l: h, c: d, h: b };
}
function d0(t, e, a) {
  const n = e * Math.cos((a * Math.PI) / 180),
    r = e * Math.sin((a * Math.PI) / 180),
    o = Math.pow(t + 0.3963377774 * n + 0.2158037573 * r, 3),
    i = Math.pow(t - 0.1055613458 * n - 0.0638541728 * r, 3),
    u = Math.pow(t - 0.0894841775 * n - 1.291485548 * r, 3),
    s = [
      4.0767416621 * o - 3.3077115913 * i + 0.2309699292 * u,
      -1.2684380046 * o + 2.6097574011 * i - 0.3413193965 * u,
      -0.0041960863 * o - 0.7034186147 * i + 1.707614701 * u,
    ],
    h = s.every((b) => b >= -5e-4 && b <= 1.0005),
    [c, f, d] = s.map((b) =>
      Math.round(
        Math.min(1, Math.max(0, f0(Math.min(1, Math.max(0, b))))) * 255,
      ),
    );
  return { r: c, g: f, b: d, inGamut: h };
}
function It(t) {
  const e =
    /^oklch\(\s*([\d.]+)(%?)\s+([\d.]+)(%?)\s+(-?[\d.]+)(deg)?\s*(?:\/\s*([\d.]+)(%?))?\s*\)$/i.exec(
      t.trim(),
    );
  if (!e) return null;
  const a = parseFloat(e[1]) / (e[2] ? 100 : 1),
    n = parseFloat(e[3]) * (e[4] ? 0.4 / 100 : 1),
    r = parseFloat(e[5]),
    o =
      e[7] === void 0
        ? 1
        : Math.min(1, Math.max(0, parseFloat(e[7]) / (e[8] ? 100 : 1)));
  if (![a, n, r].every(Number.isFinite) || a < 0 || a > 1.0001 || n < 0)
    return null;
  const { r: i, g: u, b: s, inGamut: h } = d0(a, n, r);
  return { color: v({ r: i, g: u, b: s, a: o }), inGamut: h };
}
const F = (t) => +t.toFixed(1);
function l0(t) {
  const e = t.trim(),
    a = [],
    n = It(e);
  if (n)
    return (
      n.inGamut ||
        a.push(
          "This OKLCH colour is outside the sRGB range, so it is shown clipped to the nearest colour a screen can display.",
        ),
      a
    );
  let r = "",
    o = [];
  const i = /^(rgba?|hsla?|hwb)\(\s*([^)]*)\)$/i.exec(e);
  if (
    (i
      ? ((r = i[1].toLowerCase().replace(/a$/, "")),
        (o = i[2].split(/[\s,\/]+/).filter(Boolean)))
      : /^-?\d{1,4}\s*[, ]\s*-?\d{1,4}\s*[, ]\s*-?\d{1,4}$/.test(e) &&
        ((r = "rgb"), (o = e.split(/[\s,]+/))),
    !r)
  )
    return a;
  const u = (c) => parseFloat(c),
    s = (c, f, d, b, l, p = 1) => {
      const M = u(f) * p;
      Number.isFinite(M) &&
        (M > b
          ? a.push(`Clamped ${c} ${F(M)}${l}→${b}${l}.`)
          : M < d && a.push(`Clamped ${c} ${F(M)}${l}→${d}${l}.`));
    },
    h =
      r === "rgb"
        ? ["red", "green", "blue"]
        : r === "hsl"
          ? ["hue", "saturation", "lightness"]
          : ["hue", "whiteness", "blackness"];
  if (
    (r === "rgb"
      ? o
          .slice(0, 3)
          .forEach((c, f) =>
            c.endsWith("%") ? s(h[f], c, 0, 100, "%") : s(h[f], c, 0, 255, ""),
          )
      : o.slice(1, 3).forEach((c, f) => s(h[f + 1], c, 0, 100, "%")),
    o[3] !== void 0)
  ) {
    const c = o[3],
      f = c.endsWith("%") ? u(c) / 100 : u(c);
    Number.isFinite(f) &&
      (f > 1 || f < 0) &&
      a.push(`Clamped alpha ${F(f)}→${f > 1 ? 1 : 0}.`);
  }
  return a;
}
function b0(t) {
  const e = j(t);
  if (!e) return null;
  const { r: a, g: n, b: r, a: o } = e.toRgb(),
    i = e.toHsl(),
    u = e.toHsv(),
    s = e.toCmyk(),
    h = e.toHwb(),
    c = o < 1 ? `, ${+o.toFixed(3)}` : "",
    f = e.toHex();
  return {
    hex: f,
    rgb: o < 1 ? `rgba(${a}, ${n}, ${r}${c})` : `rgb(${a}, ${n}, ${r})`,
    hsl:
      o < 1
        ? `hsla(${Math.round(i.h)}, ${Math.round(i.s)}%, ${Math.round(i.l)}%${c})`
        : `hsl(${Math.round(i.h)}, ${Math.round(i.s)}%, ${Math.round(i.l)}%)`,
    hsv: `hsv(${Math.round(u.h)}, ${Math.round(u.s)}%, ${Math.round(u.v)}%)`,
    cmyk: `cmyk(${s.c}%, ${s.m}%, ${s.y}%, ${s.k}%)`,
    lab: ((d) =>
      `lab(${F(d.l)}% ${F(d.a)} ${F(d.b)}${o < 1 ? ` / ${+o.toFixed(3)}` : ""})`)(
      e.toLab(),
    ),
    oklch: ((d) =>
      `oklch(${F(d.l * 100)}% ${+d.c.toFixed(3)} ${F(d.h)}${o < 1 ? ` / ${+o.toFixed(3)}` : ""})`)(
      h0(a, n, r),
    ),
    hwb: `hwb(${Math.round(h.h)} ${Math.round(h.w)}% ${Math.round(h.b)}%${o < 1 ? ` / ${+o.toFixed(3)}` : ""})`,
    name: e.toName({ closest: !0 }) ?? "",
    css: `color: ${f};`,
  };
}
function $t(t, e) {
  const a = j(t),
    n = j(e);
  if (!a || !n) return null;
  const r = (c, f) => {
      const { r: d, g: b, b: l, a: p } = c.toRgb();
      return v({
        r: d * p + f.r * (1 - p),
        g: b * p + f.g * (1 - p),
        b: l * p + f.b * (1 - p),
      });
    },
    o = r(n, { r: 255, g: 255, b: 255 }),
    i = r(a, o.toRgb()),
    u = (c) => {
      const { r: f, g: d, b } = c.toRgb(),
        l = (p) => {
          const M = p / 255;
          return M <= 0.03928 ? M / 12.92 : Math.pow((M + 0.055) / 1.055, 2.4);
        };
      return 0.2126 * l(f) + 0.7152 * l(d) + 0.0722 * l(b);
    },
    s = u(i),
    h = u(o);
  return (Math.max(s, h) + 0.05) / (Math.min(s, h) + 0.05);
}
function g0(t, e, a = 4.5) {
  const n = j(t),
    r = j(e);
  if (!n || !r || ($t(t, e) ?? 0) >= a) return null;
  const o = r.isLight();
  for (let i = 1; i <= 100; i++) {
    const u = (o ? n.darken(i / 100) : n.lighten(i / 100)).toHex();
    if (($t(u, e) ?? 0) >= a) return u;
  }
  return o ? "#000000" : "#ffffff";
}
function p0(t) {
  return (Math.floor(t * 100 + 1e-9) / 100).toFixed(2);
}
function m0(t, e) {
  const a = b0(t),
    n = a ?? e;
  return {
    shown: n,
    invalid: t.trim() !== "" && !a,
    notices: a ? l0(t) : [],
    last: n,
  };
}
export { $t as c, p0 as d, j as p, m0 as r, g0 as s };
//# sourceMappingURL=colorUtils-V4qYQx5D.js.map
