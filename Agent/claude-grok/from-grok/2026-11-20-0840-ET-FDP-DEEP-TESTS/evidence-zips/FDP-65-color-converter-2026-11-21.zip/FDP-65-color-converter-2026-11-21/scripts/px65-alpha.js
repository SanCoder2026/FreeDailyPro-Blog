// FDP-65: 4/8-digit hex alpha round trip, colour-picker input, Firefox copy at the cap (guest, no sign-in)
const pw = require('playwright'); const fs = require('fs'); const O = '/workspace/deep/65-color-converter/live/';
(async () => { const R = {}; const b = await pw.chromium.launch(); const p = await (await b.newContext()).newPage(); await p.goto('https://www.freedailypro.com/tool/color-converter', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4000);
 const rows = () => p.evaluate(() => { const g = l => document.querySelector(`main input[readonly][aria-label="${l}"]`).value; return [g('HEX'), g('RGB')]; });
 for (const v of ['#ff6600aa', '#F60A', '#ff660001', '#ff6600fe', '#12345678', '#ff66001a', '#ff6600cc']) { await p.locator('main input').first().fill(v); await p.waitForTimeout(300); R[v] = await rows(); }
 // round trip: paste the HEX output back
 await p.locator('main input').first().fill('#ff6600aa'); await p.waitForTimeout(300); const out = (await rows())[0]; await p.locator('main input').first().fill(out); await p.waitForTimeout(300); R.roundTrip = [out, (await rows())[0]];
 // colour picker
 await p.locator('main input[type=color]').evaluate(e => { e.value = '#00ff00'; e.dispatchEvent(new Event('input', { bubbles: true })); e.dispatchEvent(new Event('change', { bubbles: true })); }); await p.waitForTimeout(400); R.picker = { input: await p.locator('main input').first().inputValue(), hex: (await rows())[0] };
 // alpha colour then picker: alpha kept?
 await p.locator('main input').first().fill('#ff660080'); await p.waitForTimeout(300); R.pickerValueWithAlpha = await p.locator('main input[type=color]').inputValue();
 await b.close(); const fb = await pw.firefox.launch(); let fr = null; for (let i = 0; i < 15; i++) { const c = await fb.newContext(); const q = await c.newPage(); await q.goto('https://www.freedailypro.com/tool/color-converter', { waitUntil: 'domcontentloaded', timeout: 45000 }); await q.waitForTimeout(4000); const u = await q.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
  if (u === '10/10') { await q.locator('main button[aria-label="Copy HEX"]').click(); await q.waitForTimeout(1500); fr = { used: u, dialog: (await q.locator('[role=dialog]').allInnerTexts()).join('|').slice(0, 200), toasts: await q.locator('[data-sonner-toast]').allInnerTexts(), strip: await q.evaluate(() => (document.querySelector('main').innerText.match(/Trial[^\n]*/) || [null])[0]) }; await q.screenshot({ path: O + 'cases/firefox-cap-copy.png' }); await c.close(); break; } await c.close(); }
 R.firefoxCap = fr; await fb.close(); fs.writeFileSync(O + 'alpha.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1)); })();
