// FDP-65 HEX / RGB / HSL Converter (Professional), guest. Usage: node px65-live.js <zero|left|cases|uncapped> [engine]   env TRIES, SUF
// zero: a context at the cap: type a colour, Copy buttons -> cap dialog? clipboard? ; Ctrl+C from a read-only output field -> clipboard? dialog?
// left: uses left: does typing/converting log? Copy x3 (POST per copy?), new colour + copy, Ctrl+C from field, reload + copy.
// cases (no copies): input formats and outputs vs. the page copy. Never signs in, never types an email or card, never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/65-color-converter/'; const OUT = BASE + 'live/'; const TOOL = 'https://www.freedailypro.com/tool/color-converter';
const mode = process.argv[2] || 'zero'; const eng = process.argv[3] || 'chromium'; const sfx = (eng === 'chromium' ? '' : '-' + eng) + (process.env.SUF || '');
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
fs.mkdirSync(OUT + 'cases', { recursive: true });
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p, h, net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 1000 }, locale: 'en-US' }); if (eng === 'chromium') await c.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://www.freedailypro.com' }); p = await c.newPage(); p.setDefaultTimeout(12000); net = [];
  p.on('request', r => { const u = r.url(); if (r.method() === 'POST' && /freedailypro\.com\/api/.test(u) && !/insight\.hit|funnel\.hit/.test(u)) net.push({ t: now(), u: u.slice(0, 70) }); });
  await p.goto(TOOL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 // helper page on the same origin without the tool's clipboard wrapper, to set/read the clipboard (test only)
 const helper = async () => { if (!h) { h = await c.newPage(); await h.goto('https://www.freedailypro.com/robots.txt'); } };
 const clipSet = async s => { if (eng !== 'chromium') return; await helper(); await h.bringToFront(); await h.evaluate(s => navigator.clipboard.writeText(s), s).catch(() => { }); await p.bringToFront(); };
 const clipGet = async () => { if (eng !== 'chromium') return null; await helper(); await h.bringToFront(); const v = await h.evaluate(() => navigator.clipboard.readText()).catch(e => 'ERR ' + e.message.slice(0, 40)); await p.bringToFront(); return v; };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(250); } };
 const shot = n => p.screenshot({ path: OUT + 'cases/' + n + sfx + '.png' });
 const toasts = () => p.locator('[data-sonner-toast]').allInnerTexts().catch(() => []);
 const setColor = async v => { const i = p.locator('main input').first(); await i.fill(v); await p.waitForTimeout(500); };
 const rows = () => p.evaluate(() => { const o = {}; document.querySelectorAll('main input[readonly][aria-label]').forEach(i => o[i.getAttribute('aria-label')] = i.value); const a = document.querySelector('main [role=alert]'); const s = document.querySelector('main p[role=status]'); o._alert = a && a.innerText; o._notice = s && s.innerText; const ct = document.querySelector('[data-testid=cc-contrast]'); o._contrast = ct && ct.innerText.replace(/\n/g, ' '); return o; });
 const strip = () => p.evaluate(() => (document.querySelector('main').innerText.match(/Trial[^\n]*/) || [null])[0]);
 const copyBtn = async label => { await clipSet('SENTINEL'); const np = net.length; const before = await used(); await p.locator(`main button[aria-label="Copy ${label}"]`).click(); await p.waitForTimeout(1500); const r = { before, after: await used(), posts: net.slice(np).length, dialog: await dialog(), toasts: await toasts(), clip: await clipGet() }; if (r.dialog) { await shot('copy-' + label.replace(/\W+/g, '') + '-dialog'); await esc(); } return r; };
 const ctrlC = async label => { await clipSet('SENTINEL'); const np = net.length; const before = await used(); const f = p.locator(`main input[readonly][aria-label="${label}"]`); await f.click(); await p.keyboard.press('Control+A'); await p.keyboard.press('Control+C'); await p.waitForTimeout(1500); const r = { before, after: await used(), posts: net.slice(np).length, dialog: await dialog(), clip: await clipGet() }; if (r.dialog) { await shot('ctrlc-dialog'); await esc(); } return r; };
 const C = async (id, fn) => { try { R.cases[id] = await fn(); } catch (e) { R.cases[id] = { err: e.message.split('\n')[0].slice(0, 200) }; await shot(id + '-err').catch(() => { }); } console.log(id, JSON.stringify(R.cases[id]).slice(0, 600)); };
 const find = async want => { const TRIES = +(process.env.TRIES || 10); for (let i = 0; i < TRIES; i++) { await open(); const u = await used(); R.tries.push(u); const [a, l] = u.split('/').map(Number); if (want === 'cap' ? a >= l : a < l) return true; h = null; await c.close(); } return false; };
 if (mode === 'zero') { R.found = await find('cap'); R.start = { used: await used(), strip: await strip() }; await shot('Z00');
  await C('Z01-type', async () => { const np = net.length; await setColor('#ff6600'); await p.waitForTimeout(4000); return { rows: await rows(), posts: net.slice(np).length, used: await used() }; });
  for (const l of ['HEX', 'RGB', 'OKLCH']) await C('Z02-copy-' + l, () => copyBtn(l));
  await C('Z03-ctrlC-HEX-field', () => ctrlC('HEX'));
  await C('Z04-ctrlC-RGB-field', () => ctrlC('RGB'));
  R.end = await used(); R.net = net;
 } else if (mode === 'left') { R.found = await find('left'); if (!R.found) { console.log('none', R.tries.join(',')); fs.writeFileSync(OUT + 'left' + sfx + '.json', JSON.stringify(R, null, 1)); await b.close(); return; } R.start = { used: await used(), strip: await strip() };
  await C('L01-type-wait', async () => { const np = net.length; await setColor('#ff6600'); await p.waitForTimeout(5000); return { posts: net.slice(np).length, used: await used() }; });
  for (const l of ['HEX', 'RGB', 'HSL']) await C('L02-copy-' + l, () => copyBtn(l));
  await C('L03-new-colour-copy', async () => { await setColor('rebeccapurple'); return copyBtn('HEX'); });
  await C('L04-ctrlC-field', () => ctrlC('CSS'));
  await C('L05-reload-copy', async () => { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); await setColor('tomato'); return copyBtn('HEX'); });
  R.end = await used(); R.net = net;
 } else if (mode === 'cases') { await open(); R.start = { used: await used() };
  for (const v of ['#f60', 'f60', '#ff660080', '#F60A', 'rgb(255, 102, 0)', 'rgba(255,102,0,0.5)', 'rgb(300, 0, 0)', 'hsl(24, 100%, 50%)', 'hsla(24 100% 50% / 50%)', 'hwb(24 0% 0%)', '255 102 0', '255,102,0', 'tomato', 'rebeccapurple', 'transparent', 'oklch(70% 0.2 50)', 'lab(60% 50 70)', 'color(display-p3 1 0.4 0)', '#12345', 'notacolor', '#000000', '#ffffff', '#808080'])
   await C('C:' + v, async () => { await setColor(v); return rows(); });
  await setColor('rgb(300, 0, 0)'); await shot('C-clamp'); await setColor('notacolor'); await shot('C-invalid');
  R.end = await used(); R.net = net; }
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', JSON.stringify(R.tries), JSON.stringify(R.start || ''), R.end); await b.close(); })();
