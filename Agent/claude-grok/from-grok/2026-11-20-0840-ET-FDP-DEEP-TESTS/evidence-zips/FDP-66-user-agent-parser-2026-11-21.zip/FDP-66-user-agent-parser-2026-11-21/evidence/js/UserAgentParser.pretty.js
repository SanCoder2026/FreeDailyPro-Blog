import { g as Ce, r as R, j as A } from "./vendor-react-D01g8YgM.js";
import { T as Be } from "./ToolPage-DwLoDncN.js";
import { T as Me, B as Re } from "./index-B1CTyGtY.js";
import { C as Pe } from "./card-KXKUZKW8.js";
import { T as Ve } from "./ToolInfoSection-C0i6Zbwo.js";
import { u as je } from "./useLogToolUsage-BdvvKW0n.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./copyText-DPnES92p.js";
var D = { exports: {} },
  qe = D.exports,
  Ee;
function ze() {
  return (
    Ee ||
      ((Ee = 1),
      (function (w, c) {
        (function (p, a) {
          var v = "1.0.41",
            g = "",
            E = "?",
            k = "function",
            f = "undefined",
            x = "object",
            U = "string",
            W = "major",
            e = "model",
            r = "name",
            i = "type",
            o = "vendor",
            t = "version",
            N = "architecture",
            P = "console",
            n = "mobile",
            l = "tablet",
            y = "smarttv",
            T = "wearable",
            V = "embedded",
            Q = 500,
            F = "Amazon",
            B = "Apple",
            be = "ASUS",
            ce = "BlackBerry",
            G = "Browser",
            Y = "Chrome",
            Oe = "Edge",
            Z = "Firefox",
            $ = "Google",
            we = "Honor",
            de = "Huawei",
            Ne = "Lenovo",
            K = "LG",
            ee = "Microsoft",
            ie = "Motorola",
            oe = "Nvidia",
            ue = "OnePlus",
            j = "Opera",
            re = "OPPO",
            q = "Samsung",
            me = "Sharp",
            z = "Sony",
            te = "Xiaomi",
            se = "Zebra",
            pe = "Facebook",
            he = "Chromium OS",
            ge = "Mac OS",
            fe = " Browser",
            Se = function (d, u) {
              var b = {};
              for (var h in d)
                u[h] && u[h].length % 2 === 0
                  ? (b[h] = u[h].concat(d[h]))
                  : (b[h] = d[h]);
              return b;
            },
            X = function (d) {
              for (var u = {}, b = 0; b < d.length; b++)
                u[d[b].toUpperCase()] = d[b];
              return u;
            },
            ve = function (d, u) {
              return typeof d === U ? H(u).indexOf(H(d)) !== -1 : !1;
            },
            H = function (d) {
              return d.toLowerCase();
            },
            _e = function (d) {
              return typeof d === U
                ? d.replace(/[^\d\.]/g, g).split(".")[0]
                : a;
            },
            ae = function (d, u) {
              if (typeof d === U)
                return (
                  (d = d.replace(/^\s\s*/, g)),
                  typeof u === f ? d : d.substring(0, Q)
                );
            },
            I = function (d, u) {
              for (var b = 0, h, C, S, m, s, _; b < u.length && !s;) {
                var ne = u[b],
                  ye = u[b + 1];
                for (h = C = 0; h < ne.length && !s && ne[h];)
                  if (((s = ne[h++].exec(d)), s))
                    for (S = 0; S < ye.length; S++)
                      ((_ = s[++C]),
                        (m = ye[S]),
                        typeof m === x && m.length > 0
                          ? m.length === 2
                            ? typeof m[1] == k
                              ? (this[m[0]] = m[1].call(this, _))
                              : (this[m[0]] = m[1])
                            : m.length === 3
                              ? typeof m[1] === k && !(m[1].exec && m[1].test)
                                ? (this[m[0]] = _
                                    ? m[1].call(this, _, m[2])
                                    : a)
                                : (this[m[0]] = _ ? _.replace(m[1], m[2]) : a)
                              : m.length === 4 &&
                                (this[m[0]] = _
                                  ? m[3].call(this, _.replace(m[1], m[2]))
                                  : a)
                          : (this[m] = _ || a));
                b += 2;
              }
            },
            L = function (d, u) {
              for (var b in u)
                if (typeof u[b] === x && u[b].length > 0) {
                  for (var h = 0; h < u[b].length; h++)
                    if (ve(u[b][h], d)) return b === E ? a : b;
                } else if (ve(u[b], d)) return b === E ? a : b;
              return u.hasOwnProperty("*") ? u["*"] : d;
            },
            Ue = {
              "1.0": "/8",
              1.2: "/1",
              1.3: "/3",
              "2.0": "/412",
              "2.0.2": "/416",
              "2.0.3": "/417",
              "2.0.4": "/419",
              "?": "/",
            },
            xe = {
              ME: "4.90",
              "NT 3.11": "NT3.51",
              "NT 4.0": "NT4.0",
              2e3: "NT 5.0",
              XP: ["NT 5.1", "NT 5.2"],
              Vista: "NT 6.0",
              7: "NT 6.1",
              8: "NT 6.2",
              8.1: "NT 6.3",
              10: ["NT 6.4", "NT 10.0"],
              RT: "ARM",
            },
            ke = {
              browser: [
                [/\b(?:crmo|crios)\/([\w\.]+)/i],
                [t, [r, "Chrome"]],
                [/edg(?:e|ios|a)?\/([\w\.]+)/i],
                [t, [r, "Edge"]],
                [
                  /(opera mini)\/([-\w\.]+)/i,
                  /(opera [mobiletab]{3,6})\b.+version\/([-\w\.]+)/i,
                  /(opera)(?:.+version\/|[\/ ]+)([\w\.]+)/i,
                ],
                [r, t],
                [/opios[\/ ]+([\w\.]+)/i],
                [t, [r, j + " Mini"]],
                [/\bop(?:rg)?x\/([\w\.]+)/i],
                [t, [r, j + " GX"]],
                [/\bopr\/([\w\.]+)/i],
                [t, [r, j]],
                [/\bb[ai]*d(?:uhd|[ub]*[aekoprswx]{5,6})[\/ ]?([\w\.]+)/i],
                [t, [r, "Baidu"]],
                [/\b(?:mxbrowser|mxios|myie2)\/?([-\w\.]*)\b/i],
                [t, [r, "Maxthon"]],
                [
                  /(kindle)\/([\w\.]+)/i,
                  /(lunascape|maxthon|netfront|jasmine|blazer|sleipnir)[\/ ]?([\w\.]*)/i,
                  /(avant|iemobile|slim(?:browser|boat|jet))[\/ ]?([\d\.]*)/i,
                  /(?:ms|\()(ie) ([\w\.]+)/i,
                  /(flock|rockmelt|midori|epiphany|silk|skyfire|ovibrowser|bolt|iron|vivaldi|iridium|phantomjs|bowser|qupzilla|falkon|rekonq|puffin|brave|whale(?!.+naver)|qqbrowserlite|duckduckgo|klar|helio|(?=comodo_)?dragon)\/([-\w\.]+)/i,
                  /(heytap|ovi|115)browser\/([\d\.]+)/i,
                  /(weibo)__([\d\.]+)/i,
                ],
                [r, t],
                [/quark(?:pc)?\/([-\w\.]+)/i],
                [t, [r, "Quark"]],
                [/\bddg\/([\w\.]+)/i],
                [t, [r, "DuckDuckGo"]],
                [/(?:\buc? ?browser|(?:juc.+)ucweb)[\/ ]?([\w\.]+)/i],
                [t, [r, "UC" + G]],
                [
                  /microm.+\bqbcore\/([\w\.]+)/i,
                  /\bqbcore\/([\w\.]+).+microm/i,
                  /micromessenger\/([\w\.]+)/i,
                ],
                [t, [r, "WeChat"]],
                [/konqueror\/([\w\.]+)/i],
                [t, [r, "Konqueror"]],
                [/trident.+rv[: ]([\w\.]{1,9})\b.+like gecko/i],
                [t, [r, "IE"]],
                [/ya(?:search)?browser\/([\w\.]+)/i],
                [t, [r, "Yandex"]],
                [/slbrowser\/([\w\.]+)/i],
                [t, [r, "Smart Lenovo " + G]],
                [/(avast|avg)\/([\w\.]+)/i],
                [[r, /(.+)/, "$1 Secure " + G], t],
                [/\bfocus\/([\w\.]+)/i],
                [t, [r, Z + " Focus"]],
                [/\bopt\/([\w\.]+)/i],
                [t, [r, j + " Touch"]],
                [/coc_coc\w+\/([\w\.]+)/i],
                [t, [r, "Coc Coc"]],
                [/dolfin\/([\w\.]+)/i],
                [t, [r, "Dolphin"]],
                [/coast\/([\w\.]+)/i],
                [t, [r, j + " Coast"]],
                [/miuibrowser\/([\w\.]+)/i],
                [t, [r, "MIUI" + fe]],
                [/fxios\/([\w\.-]+)/i],
                [t, [r, Z]],
                [/\bqihoobrowser\/?([\w\.]*)/i],
                [t, [r, "360"]],
                [/\b(qq)\/([\w\.]+)/i],
                [[r, /(.+)/, "$1Browser"], t],
                [/(oculus|sailfish|huawei|vivo|pico)browser\/([\w\.]+)/i],
                [[r, /(.+)/, "$1" + fe], t],
                [/samsungbrowser\/([\w\.]+)/i],
                [t, [r, q + " Internet"]],
                [/metasr[\/ ]?([\d\.]+)/i],
                [t, [r, "Sogou Explorer"]],
                [/(sogou)mo\w+\/([\d\.]+)/i],
                [[r, "Sogou Mobile"], t],
                [
                  /(electron)\/([\w\.]+) safari/i,
                  /(tesla)(?: qtcarbrowser|\/(20\d\d\.[-\w\.]+))/i,
                  /m?(qqbrowser|2345(?=browser|chrome|explorer))\w*[\/ ]?v?([\w\.]+)/i,
                ],
                [r, t],
                [/(lbbrowser|rekonq)/i, /\[(linkedin)app\]/i],
                [r],
                [
                  /ome\/([\w\.]+) \w* ?(iron) saf/i,
                  /ome\/([\w\.]+).+qihu (360)[es]e/i,
                ],
                [t, r],
                [/((?:fban\/fbios|fb_iab\/fb4a)(?!.+fbav)|;fbav\/([\w\.]+);)/i],
                [[r, pe], t],
                [
                  /(Klarna)\/([\w\.]+)/i,
                  /(kakao(?:talk|story))[\/ ]([\w\.]+)/i,
                  /(naver)\(.*?(\d+\.[\w\.]+).*\)/i,
                  /(daum)apps[\/ ]([\w\.]+)/i,
                  /safari (line)\/([\w\.]+)/i,
                  /\b(line)\/([\w\.]+)\/iab/i,
                  /(alipay)client\/([\w\.]+)/i,
                  /(twitter)(?:and| f.+e\/([\w\.]+))/i,
                  /(chromium|instagram|snapchat)[\/ ]([-\w\.]+)/i,
                ],
                [r, t],
                [/\bgsa\/([\w\.]+) .*safari\//i],
                [t, [r, "GSA"]],
                [/musical_ly(?:.+app_?version\/|_)([\w\.]+)/i],
                [t, [r, "TikTok"]],
                [/headlesschrome(?:\/([\w\.]+)| )/i],
                [t, [r, Y + " Headless"]],
                [/ wv\).+(chrome)\/([\w\.]+)/i],
                [[r, Y + " WebView"], t],
                [/droid.+ version\/([\w\.]+)\b.+(?:mobile safari|safari)/i],
                [t, [r, "Android " + G]],
                [/(chrome|omniweb|arora|[tizenoka]{5} ?browser)\/v?([\w\.]+)/i],
                [r, t],
                [/version\/([\w\.\,]+) .*mobile\/\w+ (safari)/i],
                [t, [r, "Mobile Safari"]],
                [/version\/([\w(\.|\,)]+) .*(mobile ?safari|safari)/i],
                [t, r],
                [/webkit.+?(mobile ?safari|safari)(\/[\w\.]+)/i],
                [r, [t, L, Ue]],
                [/(webkit|khtml)\/([\w\.]+)/i],
                [r, t],
                [/(navigator|netscape\d?)\/([-\w\.]+)/i],
                [[r, "Netscape"], t],
                [/(wolvic|librewolf)\/([\w\.]+)/i],
                [r, t],
                [/mobile vr; rv:([\w\.]+)\).+firefox/i],
                [t, [r, Z + " Reality"]],
                [
                  /ekiohf.+(flow)\/([\w\.]+)/i,
                  /(swiftfox)/i,
                  /(icedragon|iceweasel|camino|chimera|fennec|maemo browser|minimo|conkeror)[\/ ]?([\w\.\+]+)/i,
                  /(seamonkey|k-meleon|icecat|iceape|firebird|phoenix|palemoon|basilisk|waterfox)\/([-\w\.]+)$/i,
                  /(firefox)\/([\w\.]+)/i,
                  /(mozilla)\/([\w\.]+) .+rv\:.+gecko\/\d+/i,
                  /(amaya|dillo|doris|icab|ladybird|lynx|mosaic|netsurf|obigo|polaris|w3m|(?:go|ice|up)[\. ]?browser)[-\/ ]?v?([\w\.]+)/i,
                  /\b(links) \(([\w\.]+)/i,
                ],
                [r, [t, /_/g, "."]],
                [/(cobalt)\/([\w\.]+)/i],
                [r, [t, /master.|lts./, ""]],
              ],
              cpu: [
                [/\b((amd|x|x86[-_]?|wow|win)64)\b/i],
                [[N, "amd64"]],
                [/(ia32(?=;))/i, /\b((i[346]|x)86)(pc)?\b/i],
                [[N, "ia32"]],
                [/\b(aarch64|arm(v?[89]e?l?|_?64))\b/i],
                [[N, "arm64"]],
                [/\b(arm(v[67])?ht?n?[fl]p?)\b/i],
                [[N, "armhf"]],
                [/( (ce|mobile); ppc;|\/[\w\.]+arm\b)/i],
                [[N, "arm"]],
                [/((ppc|powerpc)(64)?)( mac|;|\))/i],
                [[N, /ower/, g, H]],
                [/ sun4\w[;\)]/i],
                [[N, "sparc"]],
                [
                  /\b(avr32|ia64(?=;)|68k(?=\))|\barm(?=v([1-7]|[5-7]1)l?|;|eabi)|(irix|mips|sparc)(64)?\b|pa-risc)/i,
                ],
                [[N, H]],
              ],
              device: [
                [
                  /\b(sch-i[89]0\d|shw-m380s|sm-[ptx]\w{2,4}|gt-[pn]\d{2,4}|sgh-t8[56]9|nexus 10)/i,
                ],
                [e, [o, q], [i, l]],
                [
                  /\b((?:s[cgp]h|gt|sm)-(?![lr])\w+|sc[g-]?[\d]+a?|galaxy nexus)/i,
                  /samsung[- ]((?!sm-[lr])[-\w]+)/i,
                  /sec-(sgh\w+)/i,
                ],
                [e, [o, q], [i, n]],
                [/(?:\/|\()(ip(?:hone|od)[\w, ]*)(?:\/|;)/i],
                [e, [o, B], [i, n]],
                [
                  /\((ipad);[-\w\),; ]+apple/i,
                  /applecoremedia\/[\w\.]+ \((ipad)/i,
                  /\b(ipad)\d\d?,\d\d?[;\]].+ios/i,
                ],
                [e, [o, B], [i, l]],
                [/(macintosh);/i],
                [e, [o, B]],
                [/\b(sh-?[altvz]?\d\d[a-ekm]?)/i],
                [e, [o, me], [i, n]],
                [
                  /\b((?:brt|eln|hey2?|gdi|jdn)-a?[lnw]09|(?:ag[rm]3?|jdn2|kob2)-a?[lw]0[09]hn)(?: bui|\)|;)/i,
                ],
                [e, [o, we], [i, l]],
                [/honor([-\w ]+)[;\)]/i],
                [e, [o, we], [i, n]],
                [
                  /\b((?:ag[rs][2356]?k?|bah[234]?|bg[2o]|bt[kv]|cmr|cpn|db[ry]2?|jdn2|got|kob2?k?|mon|pce|scm|sht?|[tw]gr|vrd)-[ad]?[lw][0125][09]b?|605hw|bg2-u03|(?:gem|fdr|m2|ple|t1)-[7a]0[1-4][lu]|t1-a2[13][lw]|mediapad[\w\. ]*(?= bui|\)))\b(?!.+d\/s)/i,
                ],
                [e, [o, de], [i, l]],
                [
                  /(?:huawei)([-\w ]+)[;\)]/i,
                  /\b(nexus 6p|\w{2,4}e?-[atu]?[ln][\dx][012359c][adn]?)\b(?!.+d\/s)/i,
                ],
                [e, [o, de], [i, n]],
                [
                  /oid[^\)]+; (2[\dbc]{4}(182|283|rp\w{2})[cgl]|m2105k81a?c)(?: bui|\))/i,
                  /\b((?:red)?mi[-_ ]?pad[\w- ]*)(?: bui|\))/i,
                ],
                [
                  [e, /_/g, " "],
                  [o, te],
                  [i, l],
                ],
                [
                  /\b(poco[\w ]+|m2\d{3}j\d\d[a-z]{2})(?: bui|\))/i,
                  /\b; (\w+) build\/hm\1/i,
                  /\b(hm[-_ ]?note?[_ ]?(?:\d\w)?) bui/i,
                  /\b(redmi[\-_ ]?(?:note|k)?[\w_ ]+)(?: bui|\))/i,
                  /oid[^\)]+; (m?[12][0-389][01]\w{3,6}[c-y])( bui|; wv|\))/i,
                  /\b(mi[-_ ]?(?:a\d|one|one[_ ]plus|note lte|max|cc)?[_ ]?(?:\d?\w?)[_ ]?(?:plus|se|lite|pro)?)(?: bui|\))/i,
                  / ([\w ]+) miui\/v?\d/i,
                ],
                [
                  [e, /_/g, " "],
                  [o, te],
                  [i, n],
                ],
                [
                  /; (\w+) bui.+ oppo/i,
                  /\b(cph[12]\d{3}|p(?:af|c[al]|d\w|e[ar])[mt]\d0|x9007|a101op)\b/i,
                ],
                [e, [o, re], [i, n]],
                [/\b(opd2(\d{3}a?))(?: bui|\))/i],
                [
                  e,
                  [o, L, { OnePlus: ["304", "403", "203"], "*": re }],
                  [i, l],
                ],
                [/vivo (\w+)(?: bui|\))/i, /\b(v[12]\d{3}\w?[at])(?: bui|;)/i],
                [e, [o, "Vivo"], [i, n]],
                [/\b(rmx[1-3]\d{3})(?: bui|;|\))/i],
                [e, [o, "Realme"], [i, n]],
                [
                  /\b(milestone|droid(?:[2-4x]| (?:bionic|x2|pro|razr))?:?( 4g)?)\b[\w ]+build\//i,
                  /\bmot(?:orola)?[- ](\w*)/i,
                  /((?:moto(?! 360)[\w\(\) ]+|xt\d{3,4}|nexus 6)(?= bui|\)))/i,
                ],
                [e, [o, ie], [i, n]],
                [/\b(mz60\d|xoom[2 ]{0,2}) build\//i],
                [e, [o, ie], [i, l]],
                [
                  /((?=lg)?[vl]k\-?\d{3}) bui| 3\.[-\w; ]{10}lg?-([06cv9]{3,4})/i,
                ],
                [e, [o, K], [i, l]],
                [
                  /(lm(?:-?f100[nv]?|-[\w\.]+)(?= bui|\))|nexus [45])/i,
                  /\blg[-e;\/ ]+((?!browser|netcast|android tv|watch)\w+)/i,
                  /\blg-?([\d\w]+) bui/i,
                ],
                [e, [o, K], [i, n]],
                [
                  /(ideatab[-\w ]+|602lv|d-42a|a101lv|a2109a|a3500-hv|s[56]000|pb-6505[my]|tb-?x?\d{3,4}(?:f[cu]|xu|[av])|yt\d?-[jx]?\d+[lfmx])( bui|;|\)|\/)/i,
                  /lenovo ?(b[68]0[08]0-?[hf]?|tab(?:[\w- ]+?)|tb[\w-]{6,7})( bui|;|\)|\/)/i,
                ],
                [e, [o, Ne], [i, l]],
                [/(nokia) (t[12][01])/i],
                [o, e, [i, l]],
                [
                  /(?:maemo|nokia).*(n900|lumia \d+|rm-\d+)/i,
                  /nokia[-_ ]?(([-\w\. ]*))/i,
                ],
                [
                  [e, /_/g, " "],
                  [i, n],
                  [o, "Nokia"],
                ],
                [/(pixel (c|tablet))\b/i],
                [e, [o, $], [i, l]],
                [/droid.+; (pixel[\daxl ]{0,6})(?: bui|\))/i],
                [e, [o, $], [i, n]],
                [
                  /droid.+; (a?\d[0-2]{2}so|[c-g]\d{4}|so[-gl]\w+|xq-a\w[4-7][12])(?= bui|\).+chrome\/(?![1-6]{0,1}\d\.))/i,
                ],
                [e, [o, z], [i, n]],
                [/sony tablet [ps]/i, /\b(?:sony)?sgp\w+(?: bui|\))/i],
                [
                  [e, "Xperia Tablet"],
                  [o, z],
                  [i, l],
                ],
                [
                  / (kb2005|in20[12]5|be20[12][59])\b/i,
                  /(?:one)?(?:plus)? (a\d0\d\d)(?: b|\))/i,
                ],
                [e, [o, ue], [i, n]],
                [
                  /(alexa)webm/i,
                  /(kf[a-z]{2}wi|aeo(?!bc)\w\w)( bui|\))/i,
                  /(kf[a-z]+)( bui|\)).+silk\//i,
                ],
                [e, [o, F], [i, l]],
                [/((?:sd|kf)[0349hijorstuw]+)( bui|\)).+silk\//i],
                [
                  [e, /(.+)/g, "Fire Phone $1"],
                  [o, F],
                  [i, n],
                ],
                [/(playbook);[-\w\),; ]+(rim)/i],
                [e, o, [i, l]],
                [/\b((?:bb[a-f]|st[hv])100-\d)/i, /\(bb10; (\w+)/i],
                [e, [o, ce], [i, n]],
                [
                  /(?:\b|asus_)(transfo[prime ]{4,10} \w+|eeepc|slider \w+|nexus 7|padfone|p00[cj])/i,
                ],
                [e, [o, be], [i, l]],
                [/ (z[bes]6[027][012][km][ls]|zenfone \d\w?)\b/i],
                [e, [o, be], [i, n]],
                [/(nexus 9)/i],
                [e, [o, "HTC"], [i, l]],
                [
                  /(htc)[-;_ ]{1,2}([\w ]+(?=\)| bui)|\w+)/i,
                  /(zte)[- ]([\w ]+?)(?: bui|\/|\))/i,
                  /(alcatel|geeksphone|nexian|panasonic(?!(?:;|\.))|sony(?!-bra))[-_ ]?([-\w]*)/i,
                ],
                [o, [e, /_/g, " "], [i, n]],
                [
                  /droid [\w\.]+; ((?:8[14]9[16]|9(?:0(?:48|60|8[01])|1(?:3[27]|66)|2(?:6[69]|9[56])|466))[gqswx])\w*(\)| bui)/i,
                ],
                [e, [o, "TCL"], [i, l]],
                [/(itel) ((\w+))/i],
                [
                  [o, H],
                  e,
                  [i, L, { tablet: ["p10001l", "w7001"], "*": "mobile" }],
                ],
                [/droid.+; ([ab][1-7]-?[0178a]\d\d?)/i],
                [e, [o, "Acer"], [i, l]],
                [/droid.+; (m[1-5] note) bui/i, /\bmz-([-\w]{2,})/i],
                [e, [o, "Meizu"], [i, n]],
                [/; ((?:power )?armor(?:[\w ]{0,8}))(?: bui|\))/i],
                [e, [o, "Ulefone"], [i, n]],
                [
                  /; (energy ?\w+)(?: bui|\))/i,
                  /; energizer ([\w ]+)(?: bui|\))/i,
                ],
                [e, [o, "Energizer"], [i, n]],
                [
                  /; cat (b35);/i,
                  /; (b15q?|s22 flip|s48c|s62 pro)(?: bui|\))/i,
                ],
                [e, [o, "Cat"], [i, n]],
                [/((?:new )?andromax[\w- ]+)(?: bui|\))/i],
                [e, [o, "Smartfren"], [i, n]],
                [/droid.+; (a(?:015|06[35]|142p?))/i],
                [e, [o, "Nothing"], [i, n]],
                [
                  /; (x67 5g|tikeasy \w+|ac[1789]\d\w+)( b|\))/i,
                  /archos ?(5|gamepad2?|([\w ]*[t1789]|hello) ?\d+[\w ]*)( b|\))/i,
                ],
                [e, [o, "Archos"], [i, l]],
                [/archos ([\w ]+)( b|\))/i, /; (ac[3-6]\d\w{2,8})( b|\))/i],
                [e, [o, "Archos"], [i, n]],
                [/(imo) (tab \w+)/i, /(infinix) (x1101b?)/i],
                [o, e, [i, l]],
                [
                  /(blackberry|benq|palm(?=\-)|sonyericsson|acer|asus(?! zenw)|dell|jolla|meizu|motorola|polytron|infinix|tecno|micromax|advan)[-_ ]?([-\w]*)/i,
                  /; (hmd|imo) ([\w ]+?)(?: bui|\))/i,
                  /(hp) ([\w ]+\w)/i,
                  /(microsoft); (lumia[\w ]+)/i,
                  /(lenovo)[-_ ]?([-\w ]+?)(?: bui|\)|\/)/i,
                  /(oppo) ?([\w ]+) bui/i,
                ],
                [o, e, [i, n]],
                [
                  /(kobo)\s(ereader|touch)/i,
                  /(hp).+(touchpad(?!.+tablet)|tablet)/i,
                  /(kindle)\/([\w\.]+)/i,
                  /(nook)[\w ]+build\/(\w+)/i,
                  /(dell) (strea[kpr\d ]*[\dko])/i,
                  /(le[- ]+pan)[- ]+(\w{1,9}) bui/i,
                  /(trinity)[- ]*(t\d{3}) bui/i,
                  /(gigaset)[- ]+(q\w{1,9}) bui/i,
                  /(vodafone) ([\w ]+)(?:\)| bui)/i,
                ],
                [o, e, [i, l]],
                [/(surface duo)/i],
                [e, [o, ee], [i, l]],
                [/droid [\d\.]+; (fp\du?)(?: b|\))/i],
                [e, [o, "Fairphone"], [i, n]],
                [/(u304aa)/i],
                [e, [o, "AT&T"], [i, n]],
                [/\bsie-(\w*)/i],
                [e, [o, "Siemens"], [i, n]],
                [/\b(rct\w+) b/i],
                [e, [o, "RCA"], [i, l]],
                [/\b(venue[\d ]{2,7}) b/i],
                [e, [o, "Dell"], [i, l]],
                [/\b(q(?:mv|ta)\w+) b/i],
                [e, [o, "Verizon"], [i, l]],
                [/\b(?:barnes[& ]+noble |bn[rt])([\w\+ ]*) b/i],
                [e, [o, "Barnes & Noble"], [i, l]],
                [/\b(tm\d{3}\w+) b/i],
                [e, [o, "NuVision"], [i, l]],
                [/\b(k88) b/i],
                [e, [o, "ZTE"], [i, l]],
                [/\b(nx\d{3}j) b/i],
                [e, [o, "ZTE"], [i, n]],
                [/\b(gen\d{3}) b.+49h/i],
                [e, [o, "Swiss"], [i, n]],
                [/\b(zur\d{3}) b/i],
                [e, [o, "Swiss"], [i, l]],
                [/\b((zeki)?tb.*\b) b/i],
                [e, [o, "Zeki"], [i, l]],
                [/\b([yr]\d{2}) b/i, /\b(dragon[- ]+touch |dt)(\w{5}) b/i],
                [[o, "Dragon Touch"], e, [i, l]],
                [/\b(ns-?\w{0,9}) b/i],
                [e, [o, "Insignia"], [i, l]],
                [/\b((nxa|next)-?\w{0,9}) b/i],
                [e, [o, "NextBook"], [i, l]],
                [/\b(xtreme\_)?(v(1[045]|2[015]|[3469]0|7[05])) b/i],
                [[o, "Voice"], e, [i, n]],
                [/\b(lvtel\-)?(v1[12]) b/i],
                [[o, "LvTel"], e, [i, n]],
                [/\b(ph-1) /i],
                [e, [o, "Essential"], [i, n]],
                [/\b(v(100md|700na|7011|917g).*\b) b/i],
                [e, [o, "Envizen"], [i, l]],
                [/\b(trio[-\w\. ]+) b/i],
                [e, [o, "MachSpeed"], [i, l]],
                [/\btu_(1491) b/i],
                [e, [o, "Rotor"], [i, l]],
                [/((?:tegranote|shield t(?!.+d tv))[\w- ]*?)(?: b|\))/i],
                [e, [o, oe], [i, l]],
                [/(sprint) (\w+)/i],
                [o, e, [i, n]],
                [/(kin\.[onetw]{3})/i],
                [
                  [e, /\./g, " "],
                  [o, ee],
                  [i, n],
                ],
                [/droid.+; (cc6666?|et5[16]|mc[239][23]x?|vc8[03]x?)\)/i],
                [e, [o, se], [i, l]],
                [/droid.+; (ec30|ps20|tc[2-8]\d[kx])\)/i],
                [e, [o, se], [i, n]],
                [/smart-tv.+(samsung)/i],
                [o, [i, y]],
                [/hbbtv.+maple;(\d+)/i],
                [
                  [e, /^/, "SmartTV"],
                  [o, q],
                  [i, y],
                ],
                [/(nux; netcast.+smarttv|lg (netcast\.tv-201\d|android tv))/i],
                [
                  [o, K],
                  [i, y],
                ],
                [/(apple) ?tv/i],
                [o, [e, B + " TV"], [i, y]],
                [/crkey/i],
                [
                  [e, Y + "cast"],
                  [o, $],
                  [i, y],
                ],
                [/droid.+aft(\w+)( bui|\))/i],
                [e, [o, F], [i, y]],
                [/(shield \w+ tv)/i],
                [e, [o, oe], [i, y]],
                [/\(dtv[\);].+(aquos)/i, /(aquos-tv[\w ]+)\)/i],
                [e, [o, me], [i, y]],
                [/(bravia[\w ]+)( bui|\))/i],
                [e, [o, z], [i, y]],
                [/(mi(tv|box)-?\w+) bui/i],
                [e, [o, te], [i, y]],
                [/Hbbtv.*(technisat) (.*);/i],
                [o, e, [i, y]],
                [
                  /\b(roku)[\dx]*[\)\/]((?:dvp-)?[\d\.]*)/i,
                  /hbbtv\/\d+\.\d+\.\d+ +\([\w\+ ]*; *([\w\d][^;]*);([^;]*)/i,
                ],
                [
                  [o, ae],
                  [e, ae],
                  [i, y],
                ],
                [/droid.+; ([\w- ]+) (?:android tv|smart[- ]?tv)/i],
                [e, [i, y]],
                [/\b(android tv|smart[- ]?tv|opera tv|tv; rv:)\b/i],
                [[i, y]],
                [/(ouya)/i, /(nintendo) ([wids3utch]+)/i],
                [o, e, [i, P]],
                [/droid.+; (shield)( bui|\))/i],
                [e, [o, oe], [i, P]],
                [/(playstation \w+)/i],
                [e, [o, z], [i, P]],
                [/\b(xbox(?: one)?(?!; xbox))[\); ]/i],
                [e, [o, ee], [i, P]],
                [/\b(sm-[lr]\d\d[0156][fnuw]?s?|gear live)\b/i],
                [e, [o, q], [i, T]],
                [
                  /((pebble))app/i,
                  /(asus|google|lg|oppo) ((pixel |zen)?watch[\w ]*)( bui|\))/i,
                ],
                [o, e, [i, T]],
                [/(ow(?:19|20)?we?[1-3]{1,3})/i],
                [e, [o, re], [i, T]],
                [/(watch)(?: ?os[,\/]|\d,\d\/)[\d\.]+/i],
                [e, [o, B], [i, T]],
                [/(opwwe\d{3})/i],
                [e, [o, ue], [i, T]],
                [/(moto 360)/i],
                [e, [o, ie], [i, T]],
                [/(smartwatch 3)/i],
                [e, [o, z], [i, T]],
                [/(g watch r)/i],
                [e, [o, K], [i, T]],
                [/droid.+; (wt63?0{2,3})\)/i],
                [e, [o, se], [i, T]],
                [/droid.+; (glass) \d/i],
                [e, [o, $], [i, T]],
                [/(pico) (4|neo3(?: link|pro)?)/i],
                [o, e, [i, T]],
                [/; (quest( \d| pro)?)/i],
                [e, [o, pe], [i, T]],
                [/(tesla)(?: qtcarbrowser|\/[-\w\.]+)/i],
                [o, [i, V]],
                [/(aeobc)\b/i],
                [e, [o, F], [i, V]],
                [/(homepod).+mac os/i],
                [e, [o, B], [i, V]],
                [/windows iot/i],
                [[i, V]],
                [
                  /droid .+?; ([^;]+?)(?: bui|; wv\)|\) applew).+? mobile safari/i,
                ],
                [e, [i, n]],
                [/droid .+?; ([^;]+?)(?: bui|\) applew).+?(?! mobile) safari/i],
                [e, [i, l]],
                [/\b((tablet|tab)[;\/]|focus\/\d(?!.+mobile))/i],
                [[i, l]],
                [
                  /(phone|mobile(?:[;\/]| [ \w\/\.]*safari)|pda(?=.+windows ce))/i,
                ],
                [[i, n]],
                [/droid .+?; ([\w\. -]+)( bui|\))/i],
                [e, [o, "Generic"]],
              ],
              engine: [
                [/windows.+ edge\/([\w\.]+)/i],
                [t, [r, Oe + "HTML"]],
                [/(arkweb)\/([\w\.]+)/i],
                [r, t],
                [/webkit\/537\.36.+chrome\/(?!27)([\w\.]+)/i],
                [t, [r, "Blink"]],
                [
                  /(presto)\/([\w\.]+)/i,
                  /(webkit|trident|netfront|netsurf|amaya|lynx|w3m|goanna|servo)\/([\w\.]+)/i,
                  /ekioh(flow)\/([\w\.]+)/i,
                  /(khtml|tasman|links)[\/ ]\(?([\w\.]+)/i,
                  /(icab)[\/ ]([23]\.[\d\.]+)/i,
                  /\b(libweb)/i,
                ],
                [r, t],
                [/ladybird\//i],
                [[r, "LibWeb"]],
                [/rv\:([\w\.]{1,9})\b.+(gecko)/i],
                [t, r],
              ],
              os: [
                [/microsoft (windows) (vista|xp)/i],
                [r, t],
                [/(windows (?:phone(?: os)?|mobile|iot))[\/ ]?([\d\.\w ]*)/i],
                [r, [t, L, xe]],
                [
                  /windows nt 6\.2; (arm)/i,
                  /windows[\/ ]([ntce\d\. ]+\w)(?!.+xbox)/i,
                  /(?:win(?=3|9|n)|win 9x )([nt\d\.]+)/i,
                ],
                [
                  [t, L, xe],
                  [r, "Windows"],
                ],
                [
                  /[adehimnop]{4,7}\b(?:.*os ([\w]+) like mac|; opera)/i,
                  /(?:ios;fbsv\/|iphone.+ios[\/ ])([\d\.]+)/i,
                  /cfnetwork\/.+darwin/i,
                ],
                [
                  [t, /_/g, "."],
                  [r, "iOS"],
                ],
                [
                  /(mac os x) ?([\w\. ]*)/i,
                  /(macintosh|mac_powerpc\b)(?!.+haiku)/i,
                ],
                [
                  [r, ge],
                  [t, /_/g, "."],
                ],
                [/droid ([\w\.]+)\b.+(android[- ]x86|harmonyos)/i],
                [t, r],
                [/(ubuntu) ([\w\.]+) like android/i],
                [[r, /(.+)/, "$1 Touch"], t],
                [
                  /(android|bada|blackberry|kaios|maemo|meego|openharmony|qnx|rim tablet os|sailfish|series40|symbian|tizen|webos)\w*[-\/; ]?([\d\.]*)/i,
                ],
                [r, t],
                [/\(bb(10);/i],
                [t, [r, ce]],
                [/(?:symbian ?os|symbos|s60(?=;)|series ?60)[-\/ ]?([\w\.]*)/i],
                [t, [r, "Symbian"]],
                [
                  /mozilla\/[\d\.]+ \((?:mobile|tablet|tv|mobile; [\w ]+); rv:.+ gecko\/([\w\.]+)/i,
                ],
                [t, [r, Z + " OS"]],
                [/web0s;.+rt(tv)/i, /\b(?:hp)?wos(?:browser)?\/([\w\.]+)/i],
                [t, [r, "webOS"]],
                [/watch(?: ?os[,\/]|\d,\d\/)([\d\.]+)/i],
                [t, [r, "watchOS"]],
                [/crkey\/([\d\.]+)/i],
                [t, [r, Y + "cast"]],
                [/(cros) [\w]+(?:\)| ([\w\.]+)\b)/i],
                [[r, he], t],
                [
                  /panasonic;(viera)/i,
                  /(netrange)mmh/i,
                  /(nettv)\/(\d+\.[\w\.]+)/i,
                  /(nintendo|playstation) ([wids345portablevuch]+)/i,
                  /(xbox); +xbox ([^\);]+)/i,
                  /\b(joli|palm)\b ?(?:os)?\/?([\w\.]*)/i,
                  /(mint)[\/\(\) ]?(\w*)/i,
                  /(mageia|vectorlinux)[; ]/i,
                  /([kxln]?ubuntu|debian|suse|opensuse|gentoo|arch(?= linux)|slackware|fedora|mandriva|centos|pclinuxos|red ?hat|zenwalk|linpus|raspbian|plan 9|minix|risc os|contiki|deepin|manjaro|elementary os|sabayon|linspire)(?: gnu\/linux)?(?: enterprise)?(?:[- ]linux)?(?:-gnu)?[-\/ ]?(?!chrom|package)([-\w\.]*)/i,
                  /(hurd|linux)(?: arm\w*| x86\w*| ?)([\w\.]*)/i,
                  /(gnu) ?([\w\.]*)/i,
                  /\b([-frentopcghs]{0,5}bsd|dragonfly)[\/ ]?(?!amd|[ix346]{1,2}86)([\w\.]*)/i,
                  /(haiku) (\w+)/i,
                ],
                [r, t],
                [/(sunos) ?([\w\.\d]*)/i],
                [[r, "Solaris"], t],
                [
                  /((?:open)?solaris)[-\/ ]?([\w\.]*)/i,
                  /(aix) ((\d)(?=\.|\)| )[\w\.])*/i,
                  /\b(beos|os\/2|amigaos|morphos|openvms|fuchsia|hp-ux|serenityos)/i,
                  /(unix) ?([\w\.]*)/i,
                ],
                [r, t],
              ],
            },
            O = function (d, u) {
              if ((typeof d === x && ((u = d), (d = a)), !(this instanceof O)))
                return new O(d, u).getResult();
              var b = typeof p !== f && p.navigator ? p.navigator : a,
                h = d || (b && b.userAgent ? b.userAgent : g),
                C = b && b.userAgentData ? b.userAgentData : a,
                S = u ? Se(ke, u) : ke,
                m = b && b.userAgent == h;
              return (
                (this.getBrowser = function () {
                  var s = {};
                  return (
                    (s[r] = a),
                    (s[t] = a),
                    I.call(s, h, S.browser),
                    (s[W] = _e(s[t])),
                    m &&
                      b &&
                      b.brave &&
                      typeof b.brave.isBrave == k &&
                      (s[r] = "Brave"),
                    s
                  );
                }),
                (this.getCPU = function () {
                  var s = {};
                  return ((s[N] = a), I.call(s, h, S.cpu), s);
                }),
                (this.getDevice = function () {
                  var s = {};
                  return (
                    (s[o] = a),
                    (s[e] = a),
                    (s[i] = a),
                    I.call(s, h, S.device),
                    m && !s[i] && C && C.mobile && (s[i] = n),
                    m &&
                      s[e] == "Macintosh" &&
                      b &&
                      typeof b.standalone !== f &&
                      b.maxTouchPoints &&
                      b.maxTouchPoints > 2 &&
                      ((s[e] = "iPad"), (s[i] = l)),
                    s
                  );
                }),
                (this.getEngine = function () {
                  var s = {};
                  return ((s[r] = a), (s[t] = a), I.call(s, h, S.engine), s);
                }),
                (this.getOS = function () {
                  var s = {};
                  return (
                    (s[r] = a),
                    (s[t] = a),
                    I.call(s, h, S.os),
                    m &&
                      !s[r] &&
                      C &&
                      C.platform &&
                      C.platform != "Unknown" &&
                      (s[r] = C.platform
                        .replace(/chrome os/i, he)
                        .replace(/macos/i, ge)),
                    s
                  );
                }),
                (this.getResult = function () {
                  return {
                    ua: this.getUA(),
                    browser: this.getBrowser(),
                    engine: this.getEngine(),
                    os: this.getOS(),
                    device: this.getDevice(),
                    cpu: this.getCPU(),
                  };
                }),
                (this.getUA = function () {
                  return h;
                }),
                (this.setUA = function (s) {
                  return (
                    (h = typeof s === U && s.length > Q ? ae(s, Q) : s),
                    this
                  );
                }),
                this.setUA(h),
                this
              );
            };
          ((O.VERSION = v),
            (O.BROWSER = X([r, t, W])),
            (O.CPU = X([N])),
            (O.DEVICE = X([e, o, i, P, n, y, l, T, V])),
            (O.ENGINE = O.OS = X([r, t])),
            w.exports && (c = w.exports = O),
            (c.UAParser = O));
          var M = typeof p !== f && (p.jQuery || p.Zepto);
          if (M && !M.ua) {
            var J = new O();
            ((M.ua = J.getResult()),
              (M.ua.get = function () {
                return J.getUA();
              }),
              (M.ua.set = function (d) {
                J.setUA(d);
                var u = J.getResult();
                for (var b in u) M.ua[b] = u[b];
              }));
          }
        })(typeof window == "object" ? window : qe);
      })(D, D.exports)),
    D.exports
  );
}
var He = ze();
const Ie = Ce(He),
  Le =
    /bot|crawler|spider|slurp|facebookexternalhit|curl\/|wget\/|python-requests|headlesschrome/i,
  De =
    /\b(Googlebot|Bingbot|bingbot|DuckDuckBot|Baiduspider|YandexBot|Slurp|facebookexternalhit|Twitterbot|LinkedInBot|AhrefsBot|SemrushBot|[A-Za-z]+bot|[A-Za-z]*crawler|[A-Za-z]*spider)\/([\d.]+)/i,
  We =
    /\b(curl|Wget|python-requests|HeadlessChrome|Go-http-client|okhttp)\/([\d.]+)/i,
  Fe = /Mozilla\/|Opera\/|Dalvik\/|AppleWebKit|Gecko\/|Trident\//i;
function Ge(w) {
  const c = new Ie(w).getResult(),
    p = Le.test(w),
    a = p ? (w.match(De) ?? w.match(We)) : null,
    v = c.device.type,
    g = !!(
      c.browser.name ||
      c.os.name ||
      c.engine.name ||
      v ||
      p ||
      Fe.test(w)
    ),
    E =
      v === "mobile"
        ? "Mobile"
        : v === "tablet"
          ? "Tablet"
          : v
            ? v.charAt(0).toUpperCase() + v.slice(1)
            : p
              ? "Bot / script"
              : g
                ? "Desktop"
                : "Unknown";
  return {
    browser: c.browser.name ?? (a ? a[1] : "Unknown"),
    browserVersion: c.browser.version ?? (a ? a[2] : "Unknown"),
    os: c.os.name ?? "Unknown",
    osVersion: c.os.version ?? "",
    deviceType: E,
    device: [c.device.vendor, c.device.model].filter(Boolean).join(" "),
    engine: c.engine.name ?? "Unknown",
    cpu: c.cpu.architecture ?? "",
    isBot: p,
    recognised: g,
  };
}
const Ye = /not.{0,2}a.{0,2}brand|^\W*not\W/i,
  Ze = [
    "Microsoft Edge",
    "Google Chrome",
    "Opera",
    "Brave",
    "Vivaldi",
    "Samsung Internet",
    "Chromium",
  ];
function $e(w) {
  const c = (w ?? []).filter((p) => p.brand && !Ye.test(p.brand));
  for (const p of Ze) {
    const a = c.find((v) => v.brand === p);
    if (a) return a;
  }
  return c[0] ?? null;
}
function Ke(w) {
  const c = parseInt((w ?? "").split(".")[0], 10);
  return Number.isFinite(c)
    ? c >= 13
      ? "Windows 11"
      : c >= 1
        ? "Windows 10"
        : "Windows 7 / 8"
    : "Windows";
}
function Te(w) {
  const c = $e(w.fullVersionList?.length ? w.fullVersionList : w.brands),
    p = (w.platform ?? "").replace(/^"|"$/g, ""),
    a = (w.platformVersion ?? "").replace(/^"|"$/g, ""),
    v = /^windows$/i.test(p),
    g = v ? Ke(a) : p || "Unknown",
    E = (w.model ?? "").replace(/^"|"$/g, ""),
    k = [w.architecture, w.bitness ? `${w.bitness}-bit` : ""]
      .filter(Boolean)
      .join(" ");
  return {
    browser: c?.brand ?? "Unknown",
    browserVersion: c?.version ?? w.uaFullVersion ?? "Unknown",
    os: g,
    osVersion: v ? "" : a,
    deviceType: w.mobile ? "Mobile" : "Desktop / tablet",
    model: E,
    cpu: k,
  };
}
function Ae(w) {
  const c = [],
    p = /"([^"]*)"\s*;\s*v\s*=\s*"([^"]*)"/g;
  let a;
  for (; (a = p.exec(w));) c.push({ brand: a[1], version: a[2] });
  return c;
}
function Xe(w) {
  return /^\s*sec-ch-ua[\w-]*\s*:/im.test(w);
}
function Je(w) {
  const c = (k) => {
      const f = new RegExp(`^\\s*${k}\\s*:\\s*(.*)$`, "im").exec(w);
      return f ? f[1].trim() : void 0;
    },
    p = c("sec-ch-ua"),
    a = c("sec-ch-ua-full-version-list"),
    v = c("sec-ch-ua-platform");
  if (p === void 0 && a === void 0 && v === void 0) return null;
  const g = (k) => (k === void 0 ? void 0 : k.replace(/^"|"$/g, "")),
    E = c("sec-ch-ua-mobile");
  return {
    brands: p ? Ae(p) : void 0,
    fullVersionList: a ? Ae(a) : void 0,
    platform: g(v),
    platformVersion: g(c("sec-ch-ua-platform-version")),
    model: g(c("sec-ch-ua-model")),
    architecture: g(c("sec-ch-ua-arch")),
    bitness: g(c("sec-ch-ua-bitness")),
    uaFullVersion: g(c("sec-ch-ua-full-version")),
    mobile: E === void 0 ? void 0 : E.includes("?1"),
  };
}
const Qe =
    "This doesn't look like a user-agent string. A real one starts like Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ... Copy it from a server log's user-agent field, a bug report or your browser's Network tab. Pasted Sec-CH-UA headers work too.",
  ei =
    "This browser doesn't offer Client Hints (Chrome, Edge and Opera do; Firefox and Safari don't), so only the user-agent string is used.",
  le = {
    what: `Reads a browser's "user-agent" string — the piece of text every browser automatically sends with each request, identifying itself — and breaks it down into plain, readable facts: which browser and version, which operating system, and whether it's a phone, tablet, or desktop. Every web server, analytics tool, and error-tracking system sees this string constantly; this tool turns the cryptic raw text into something a person can actually read at a glance.

Why this matters in practice: when a bug report says "broken on Safari" but doesn't say which version, or a server log shows a confusing string of characters and you need to know what device actually made that request, or you're checking whether your site's analytics correctly identified visitors as mobile vs. desktop — pasting the raw string here decodes it in one step instead of manually reading through cryptic browser-engine naming conventions.`,
    how: `A textarea below is pre-filled with your own browser's real user-agent string as a working example — clear it and paste any other user-agent string (copied from a server log, a bug report, or a browser testing tool) to decode that one instead. The parsed browser, version, OS, and device type update automatically as you type or paste. "Use My Browser" also asks your own browser for its Client Hints when it has them (Chrome, Edge, Opera), which can show Windows 11, the real device model and the full browser version that the user-agent string hides; those values are labelled "from Client Hints". You can also paste Sec-CH-UA request headers. Everything is read in your browser; nothing is sent anywhere.`,
    tip: "User-agent strings are self-reported by the browser and can be changed or spoofed by the user (browser dev tools, extensions, and some privacy-focused browsers all let someone override what gets sent) — treat parsed results as generally reliable for everyday debugging and analytics, but never as a security control something important depends on.",
  };
function Ui() {
  const [w, c] = R.useState(typeof navigator < "u" ? navigator.userAgent : ""),
    [p, a] = R.useState(null),
    [v, g] = R.useState(""),
    E = R.useMemo(() => (Xe(w) ? Je(w) : null), [w]),
    k = R.useMemo(() => (E ? Te(E) : null), [E]),
    f = R.useMemo(() => Ge(w), [w]),
    x = p ?? k,
    U = p ? "from Client Hints" : "from Sec-CH-UA headers",
    W = async () => {
      (c(navigator.userAgent), a(null), g(""));
      const e = navigator.userAgentData;
      if (!e?.getHighEntropyValues) {
        g(ei);
        return;
      }
      try {
        const r = await e.getHighEntropyValues([
          "platformVersion",
          "model",
          "architecture",
          "bitness",
          "fullVersionList",
          "uaFullVersion",
        ]);
        a(
          Te({
            brands: e.brands,
            mobile: e.mobile,
            platform: e.platform,
            ...r,
          }),
        );
      } catch {
        g(
          "Your browser has Client Hints but declined to share the detailed values, so only the user-agent string is used.",
        );
      }
    };
  return (
    je(f),
    A.jsxs(Be, {
      children: [
        A.jsx(Me, {
          value: w,
          onChange: (e) => {
            (c(e.target.value), a(null), g(""));
          },
          placeholder: "Paste a user-agent string (or Sec-CH-UA headers)...",
          "aria-label": "User-agent string",
          className: "min-h-[100px] font-mono text-sm mb-2",
        }),
        A.jsx(Re, {
          size: "sm",
          variant: "outline",
          onClick: () => {
            W();
          },
          children: "Use My Browser's User-Agent",
        }),
        v &&
          A.jsx("p", {
            className: "text-xs text-muted-foreground mt-2",
            role: "status",
            children: v,
          }),
        w.trim() !== "" &&
          !f.recognised &&
          !k &&
          A.jsx("p", {
            className:
              "text-sm mt-3 rounded-md border border-amber-300 bg-amber-50 text-amber-900 dark:bg-amber-950/30 dark:text-amber-200 dark:border-amber-700 px-3 py-2",
            role: "status",
            "data-testid": "ua-not-a-ua",
            children: Qe,
          }),
        A.jsxs(A.Fragment, {
          children: [
            A.jsx("div", {
              className: "grid grid-cols-2 md:grid-cols-4 gap-3 mt-6",
              children: [
                [
                  "Browser",
                  x && x.browser !== "Unknown" ? x.browser : f.browser,
                ],
                [
                  "Version",
                  x && x.browserVersion !== "Unknown"
                    ? `${x.browserVersion} (${U})`
                    : f.browserVersion,
                ],
                [
                  "OS",
                  x
                    ? `${`${x.os} ${x.osVersion}`.trim()} (${U})`
                    : `${f.os} ${f.osVersion}`.trim(),
                ],
                ["Device type", !p && k ? k.deviceType : f.deviceType],
                ["Device", x?.model ? `${x.model} (${U})` : f.device || "—"],
                ["Engine", f.engine],
                ["CPU", x?.cpu ? `${x.cpu} (${U})` : f.cpu || "—"],
                ["Bot / script", f.isBot ? "Yes" : "No"],
              ].map(([e, r]) =>
                A.jsxs(
                  Pe,
                  {
                    className: "p-4 text-center",
                    children: [
                      A.jsx("p", {
                        className: "text-lg font-bold text-primary break-words",
                        children: r,
                      }),
                      A.jsx("p", {
                        className: "text-xs text-muted-foreground mt-1",
                        children: e,
                      }),
                    ],
                  },
                  e,
                ),
              ),
            }),
            f.os === "Windows" &&
              !x &&
              A.jsx("p", {
                className: "text-xs text-muted-foreground mt-3",
                children:
                  "Windows 10 and Windows 11 send the same user-agent, so they can't be told apart from this string.",
              }),
          ],
        }),
        A.jsx(Ve, { whatIsIt: le.what, howToUse: le.how, tip: le.tip }),
      ],
    })
  );
}
export { Ui as default };
//# sourceMappingURL=UserAgentParser-BymHlzBs.js.map
