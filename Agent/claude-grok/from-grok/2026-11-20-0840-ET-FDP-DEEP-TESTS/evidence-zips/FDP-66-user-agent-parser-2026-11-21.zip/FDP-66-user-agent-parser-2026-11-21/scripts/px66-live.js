// FDP-66 User-Agent Parser (Professional), guest. Usage: node px66-live.js <zero|left|cases|hints> [engine]   env TRIES, SUF
// zero: a context at the cap: Copy result, Save as text, Print (window.print stubbed in the test page), Ctrl+C on selected card text -> gated?
// left: uses left: does load/typing log? Copy result, Save as text, new string + Copy, Ctrl+C, reload + Save.
// cases (no actions): parsing of known UA strings, Sec-CH-UA headers, garbage. hints: "Use My Browser's User-Agent" in Chromium (Client Hints).
// Never signs in, never types an email or card, never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/66-user-agent-parser/'; const OUT = BASE + 'live/'; const TOOL = 'https://www.freedailypro.com/tool/user-agent-parser';
const mode = process.argv[2] || 'zero'; const eng = process.argv[3] || 'chromium'; const sfx = (eng === 'chromium' ? '' : '-' + eng) + (process.env.SUF || '');
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
fs.mkdirSync(OUT + 'cases', { recursive: true }); fs.mkdirSync(OUT + 'downloads', { recursive: true });
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p, h, net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 1000 }, locale: 'en-US', acceptDownloads: true }); if (eng === 'chromium') await c.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://www.freedailypro.com' }); p = await c.newPage(); p.setDefaultTimeout(12000); net = [];
  await p.addInitScript(() => { window.__prints = 0; window.print = () => { window.__prints++; }; });
  p.on('request', r => { const u = r.url(); if (r.method() === 'POST' && /freedailypro\.com\/api/.test(u) && !/insight\.hit|funnel\.hit/.test(u)) net.push({ t: now(), u: u.slice(0, 70) }); });
  await p.goto(TOOL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const helper = async () => { if (!h) { h = await c.newPage(); await h.goto('https://www.freedailypro.com/robots.txt'); } };
 const clipSet = async s => { if (eng !== 'chromium') return; await helper(); await h.bringToFront(); await h.evaluate(s => navigator.clipboard.writeText(s), s).catch(() => { }); await p.bringToFront(); };
 const clipGet = async () => { if (eng !== 'chromium') return null; await helper(); await h.bringToFront(); const v = await h.evaluate(() => navigator.clipboard.readText()).catch(e => 'ERR ' + e.message.slice(0, 40)); await p.bringToFront(); return v; };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(250); } };
 const shot = n => p.screenshot({ path: OUT + 'cases/' + n + sfx + '.png' });
 const toasts = () => p.locator('[data-sonner-toast]').allInnerTexts().catch(() => []);
 const ta = () => p.locator('main textarea[aria-label="User-agent string"]');
 const setUA = async v => { await ta().fill(v); await p.waitForTimeout(500); };
 const cards = () => p.evaluate(() => { const o = {}; document.querySelectorAll('main .grid > div').forEach(d => { const ps = d.querySelectorAll('p'); if (ps.length >= 2) o[ps[1].innerText] = ps[0].innerText; }); const st = [...document.querySelectorAll('main [role=status]')].map(x => x.innerText).filter(Boolean); o._status = st; const n = [...document.querySelectorAll('main p')].find(x => /Windows 10 and Windows 11/.test(x.innerText)); o._winNote = !!n; return o; });
 const strip = () => p.evaluate(() => (document.querySelector('main').innerText.match(/Trial[^\n]*/) || [null])[0]);
 const act = async (label, kind) => { await clipSet('SENTINEL'); const np = net.length; const before = await used(); const pr0 = await p.evaluate(() => window.__prints); const dl = kind === 'dl' ? p.waitForEvent('download', { timeout: 8000 }).catch(() => null) : null; await p.locator('main button', { hasText: label }).first().click(); const d = dl ? await dl : null; await p.waitForTimeout(1500); let file = null; if (d) { const f = OUT + 'downloads/' + (process.env.SUF || '') + Date.now() % 100000 + '-' + d.suggestedFilename(); await d.saveAs(f); file = { name: d.suggestedFilename(), bytes: fs.statSync(f).size, head: fs.readFileSync(f, 'utf8').slice(0, 300) }; }
  const r = { before, after: await used(), posts: net.slice(np).length, dialog: await dialog(), toasts: await toasts(), clip: kind === 'copy' ? await clipGet() : undefined, prints: (await p.evaluate(() => window.__prints)) - pr0, file }; if (r.dialog) { await shot('act-' + label.replace(/\W+/g, '') + '-dialog'); await esc(); } return r; };
 const ctrlC = async () => { await clipSet('SENTINEL'); const np = net.length; const before = await used(); await p.evaluate(() => { const el = document.querySelector('main .grid'); const r = document.createRange(); r.selectNodeContents(el); const s = getSelection(); s.removeAllRanges(); s.addRange(r); }); await p.keyboard.press('Control+C'); await p.waitForTimeout(1500); const r = { before, after: await used(), posts: net.slice(np).length, dialog: await dialog(), clip: (await clipGet() || '').slice(0, 80) }; if (r.dialog) { await shot('ctrlc-dialog'); await esc(); } await p.evaluate(() => getSelection().removeAllRanges()); return r; };
 const C = async (id, fn) => { try { R.cases[id] = await fn(); } catch (e) { R.cases[id] = { err: e.message.split('\n')[0].slice(0, 200) }; await shot(id + '-err').catch(() => { }); } console.log(id, JSON.stringify(R.cases[id]).slice(0, 600)); };
 const find = async want => { const TRIES = +(process.env.TRIES || 10); for (let i = 0; i < TRIES; i++) { await open(); const u = await used(); R.tries.push(u); const [a, l] = u.split('/').map(Number); if (want === 'cap' ? a >= l : a < l) return true; h = null; await c.close(); } return false; };
 const IPH = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1';
 if (mode === 'zero' || mode === 'left') { R.found = await find(mode === 'zero' ? 'cap' : 'left'); if (!R.found) { console.log('none', R.tries.join(',')); fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); await b.close(); return; }
  R.start = { used: await used(), strip: await strip(), postsOnLoad: net.length }; await shot(mode === 'zero' ? 'Z00' : 'L00');
  await C('A01-type-wait', async () => { const np = net.length; await setUA(IPH); await p.waitForTimeout(5000); return { posts: net.slice(np).length, used: await used(), cards: await cards() }; });
  await C('A02-copy-result', () => act('Copy result', 'copy'));
  await C('A03-save-text', () => act('Save as text', 'dl'));
  await C('A04-print', () => act('Print', 'print'));
  await C('A05-ctrlC-cards', () => ctrlC());
  await C('A06-new-string-copy', async () => { await setUA('Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)'); return act('Copy result', 'copy'); });
  await C('A07-reload-save', async () => { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); return act('Save as text', 'dl'); });
  R.end = await used(); R.net = net;
 } else if (mode === 'cases') { await open(); R.start = { used: await used() };
  const UAS = { iphone: IPH,
   ipad13: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15',
   androidReduced: 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
   samsungTab: 'Mozilla/5.0 (Linux; Android 13; SM-X710) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Safari/537.36',
   pixel8Old: 'Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.144 Mobile Safari/537.36',
   edgeWin: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0',
   firefoxMac: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14.4; rv:126.0) Gecko/20100101 Firefox/126.0',
   win7ie: 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko',
   googlebotSmart: 'Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.204 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
   bingbot: 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)',
   gptbot: 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GPTBot/1.2; +https://openai.com/gptbot)',
   curl: 'curl/8.5.0', pyreq: 'python-requests/2.31.0', wget: 'Wget/1.21.4',
   headless: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.0.0 Safari/537.36',
   facebook: 'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)',
   smartTV: 'Mozilla/5.0 (SMART-TV; Linux; Tizen 6.0) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/4.0 Chrome/76.0.3809.146 TV Safari/537.36',
   logLine: '203.0.113.7 - - [21/Nov/2026:10:00:00 +0000] "GET / HTTP/1.1" 200 512 "-" "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"',
   secChUa: 'sec-ch-ua: "Chromium";v="131", "Google Chrome";v="131", "Not_A Brand";v="24"\nsec-ch-ua-mobile: ?1\nsec-ch-ua-platform: "Android"\nsec-ch-ua-platform-version: "14.0.0"\nsec-ch-ua-model: "Pixel 8 Pro"\nsec-ch-ua-full-version-list: "Chromium";v="131.0.6778.135", "Google Chrome";v="131.0.6778.135"',
   secChUaWin11: 'sec-ch-ua: "Microsoft Edge";v="131", "Chromium";v="131"\nsec-ch-ua-mobile: ?0\nsec-ch-ua-platform: "Windows"\nsec-ch-ua-platform-version: "15.0.0"',
   garbage: 'hello world this is not a UA', empty: '' };
  for (const [k, v] of Object.entries(UAS)) await C('C:' + k, async () => { await setUA(v); return cards(); });
  await setUA(UAS.garbage); await shot('C-garbage'); await setUA(UAS.secChUa); await shot('C-secchua'); await setUA(UAS.edgeWin); await shot('C-windows');
  R.end = await used(); R.net = net;
 } else if (mode === 'hints') { await open(); await setUA('x'); await p.locator('main button', { hasText: "Use My Browser's User-Agent" }).click(); await p.waitForTimeout(1500); R.cases.hints = await cards(); await shot('H-hints'); console.log(JSON.stringify(R.cases.hints)); }
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', JSON.stringify(R.tries), JSON.stringify(R.start || ''), R.end); await b.close(); })();
