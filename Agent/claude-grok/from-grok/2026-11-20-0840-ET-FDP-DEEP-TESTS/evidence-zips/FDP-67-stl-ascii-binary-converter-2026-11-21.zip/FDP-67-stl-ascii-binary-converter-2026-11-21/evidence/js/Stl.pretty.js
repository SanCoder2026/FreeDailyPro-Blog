import { r as x, j as e } from "./vendor-react-D01g8YgM.js";
import { u as j } from "./useRevealDownload-BkGzz0vy.js";
import { T as k, F as T, P as w, D as N } from "./ToolPage-DwLoDncN.js";
import { B as g, f as v } from "./index-B1CTyGtY.js";
import { C } from "./card-KXKUZKW8.js";
import { T as L } from "./ToolInfoSection-C0i6Zbwo.js";
import { J as I } from "./jszip.min-CT0ZA6V1.js";
import { v as B, w as $, a as A, m as z, b as D } from "./mesh3d-C14zW8wv.js";
import { u as F } from "./zipUtils-BHiIs4Un.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
async function E(a) {
  try {
    const n = await a.arrayBuffer();
    return { name: a.name, bytes: n, check: B(n) };
  } catch {
    return {
      name: a.name,
      bytes: new ArrayBuffer(0),
      check: { ok: !1, reason: "Not a valid STL: the file could not be read." },
    };
  }
}
const S = (a) => a.replace(/\.stl$/i, "");
function y(a, n) {
  const c = a.filter((i) => i.check.ok);
  return c.length > 0 && c.every((i) => i.check.ok && i.check.format === n);
}
async function P(a, n) {
  const c = a.filter((t) => t.check.ok),
    i = a.filter((t) => !t.check.ok).map((t) => t.name);
  if (c.length === 0) throw new Error("There is no valid STL file to convert.");
  const r = F(c.map((t) => `${S(t.name)}_${n}.stl`)),
    o = c.map((t, m) => {
      const p = t.check.format === n,
        s = t.check.mesh,
        d = p ? t.bytes : n === "binary" ? $(s) : A(s, S(t.name));
      return {
        name: r[m],
        bytes: d,
        same: p,
        stats: z(D(s)),
        triangles: t.check.triangleCount,
      };
    }),
    u = "application/sla",
    h = o.length === 1;
  let l, f;
  if (h) ((l = new Blob([o[0].bytes], { type: u })), (f = o[0].name));
  else {
    const t = new I();
    (o.forEach((m) => t.file(m.name, m.bytes)),
      (l = await t.generateAsync({ type: "blob", compression: "DEFLATE" })),
      (f = `stl_${n}_${o.length}_files.zip`));
  }
  return {
    blob: l,
    name: f,
    format: n,
    skipped: i,
    files: o.map((t) => ({
      name: t.name,
      size:
        t.bytes instanceof ArrayBuffer
          ? t.bytes.byteLength
          : new Blob([t.bytes]).size,
      same: t.same,
      triangles: t.triangles,
    })),
    stats: o[0].stats,
    single: h,
  };
}
const b = {
  what: "Converts an STL file between its ASCII (human-readable text) and binary (compact) representations, auto-detecting which format your file is currently in.",
  how: "Upload your STL file (or several at once), and convert it to either ASCII or binary format. A file that is not a real STL is flagged straight away and can't be converted. One file downloads as an .stl; several download as one ZIP.",
  tip: "This converts the geometry only: the 80-byte header text and any per-triangle colour bytes are not carried over, and the face normals are recalculated from the triangles. Binary STL files are significantly smaller than the equivalent ASCII version for the same geometry — if file size matters for storage or transfer, binary is almost always the better choice.",
};
function ge() {
  const [a, n] = x.useState([]),
    [c, i] = x.useState(!1),
    [r, o] = x.useState(null),
    u = j(!!r),
    h = a.filter((s) => s.check.ok).length,
    l = a.length === 1 ? a[0] : null,
    f = x.useCallback(async (s) => {
      if (s.length !== 0) {
        (o(null), i(!0));
        try {
          n(await Promise.all(s.map(E)));
        } finally {
          i(!1);
        }
      }
    }, []),
    t = async (s) => {
      if (h !== 0) {
        i(!0);
        try {
          const d = await P(a, s);
          (o(d),
            v.success(
              d.single
                ? `Converted to ${s} STL`
                : `Converted ${d.files.length} files to ${s} STL`,
            ));
        } catch {
          v.error("Couldn't convert this STL file");
        } finally {
          i(!1);
        }
      }
    },
    m = a.length > 0 && h === 0,
    p = (s) =>
      m
        ? "No valid STL file to convert"
        : y(a, s)
          ? `${a.length > 1 ? "These files are" : "This file is"} already ${s === "ascii" ? "ASCII" : "Binary"} STL`
          : void 0;
  return e.jsxs(k, {
    children: [
      a.length === 0
        ? e.jsx(T, {
            gateAtDownload: !0,
            accept: ".stl",
            multiple: !0,
            onFiles: f,
            label: "Drop an STL file",
            description:
              "Convert between ASCII and binary STL, auto-detects the current format. Drop several files to get one ZIP.",
          })
        : e.jsxs("div", {
            className: "space-y-4",
            children: [
              e.jsxs("div", {
                className: "p-4 rounded-lg border bg-card space-y-2",
                children: [
                  e.jsxs("div", {
                    className:
                      "flex flex-wrap items-center justify-between gap-2",
                    children: [
                      e.jsx("p", {
                        className: "text-sm font-medium",
                        children: l
                          ? e.jsx("span", {
                              className: "break-all",
                              children: l.name,
                            })
                          : `${a.length} files (${h} valid)`,
                      }),
                      e.jsxs(g, {
                        size: "sm",
                        variant: "ghost",
                        onClick: () => {
                          (n([]), o(null));
                        },
                        children: ["Change file", a.length > 1 ? "s" : ""],
                      }),
                    ],
                  }),
                  l
                    ? l.check.ok
                      ? e.jsxs("p", {
                          className: "text-xs text-muted-foreground",
                          children: [
                            "Detected as ",
                            l.check.format.toUpperCase(),
                            " STL, ",
                            l.check.triangleCount.toLocaleString(),
                            " triangles",
                          ],
                        })
                      : e.jsx("p", {
                          role: "alert",
                          className: "text-sm text-destructive",
                          children: l.check.reason,
                        })
                    : e.jsx("ul", {
                        className: "text-xs space-y-1",
                        children: a.map((s, d) =>
                          e.jsxs(
                            "li",
                            {
                              className: s.check.ok
                                ? "text-muted-foreground"
                                : "text-destructive",
                              children: [
                                e.jsx("span", {
                                  className: "break-all font-medium",
                                  children: s.name,
                                }),
                                ": ",
                                s.check.ok
                                  ? `${s.check.format.toUpperCase()} STL, ${s.check.triangleCount.toLocaleString()} triangles`
                                  : s.check.reason,
                              ],
                            },
                            d,
                          ),
                        ),
                      }),
                ],
              }),
              c
                ? e.jsx(w, {})
                : e.jsxs("div", {
                    className: "flex flex-wrap gap-3",
                    children: [
                      e.jsx(g, {
                        onClick: () => t("ascii"),
                        disabled: m || y(a, "ascii"),
                        title: p("ascii"),
                        children: "Convert to ASCII STL",
                      }),
                      e.jsx(g, {
                        variant: "outline",
                        onClick: () => t("binary"),
                        disabled: m || y(a, "binary"),
                        title: p("binary"),
                        children: "Convert to Binary STL",
                      }),
                    ],
                  }),
              m &&
                !c &&
                e.jsx("p", {
                  className: "text-xs text-muted-foreground",
                  children:
                    "Choose a different file: only real STL files can be converted.",
                }),
              r &&
                e.jsxs(C, {
                  className: "p-4 space-y-3",
                  children: [
                    e.jsxs("div", {
                      className: "grid grid-cols-3 gap-3 text-center",
                      children: [
                        e.jsxs("div", {
                          children: [
                            e.jsx("p", {
                              className: "text-lg font-bold text-primary",
                              children: (r.single
                                ? r.stats.vertexCount
                                : r.files.length
                              ).toLocaleString(),
                            }),
                            e.jsx("p", {
                              className: "text-xs text-muted-foreground",
                              children: r.single ? "Vertices" : "Files",
                            }),
                          ],
                        }),
                        e.jsxs("div", {
                          children: [
                            e.jsx("p", {
                              className: "text-lg font-bold text-primary",
                              children: (r.single
                                ? r.stats.triangleCount
                                : r.files.reduce((s, d) => s + d.triangles, 0)
                              ).toLocaleString(),
                            }),
                            e.jsx("p", {
                              className: "text-xs text-muted-foreground",
                              children: "Triangles",
                            }),
                          ],
                        }),
                        e.jsxs("div", {
                          children: [
                            e.jsxs("p", {
                              className: "text-lg font-bold text-primary",
                              children: [
                                (r.blob.size / 1024).toFixed(1),
                                " KB",
                              ],
                            }),
                            e.jsx("p", {
                              className: "text-xs text-muted-foreground",
                              children: r.single
                                ? `${r.format} size`
                                : "ZIP size",
                            }),
                          ],
                        }),
                      ],
                    }),
                    r.skipped.length > 0 &&
                      e.jsxs("p", {
                        className: "text-xs font-medium",
                        children: [
                          "Left out because they are not valid STL files: ",
                          r.skipped.join(", "),
                        ],
                      }),
                    r.files.some((s) => s.same) &&
                      !r.single &&
                      e.jsxs("p", {
                        className: "text-xs text-muted-foreground",
                        children: [
                          "Files already in ",
                          r.format,
                          " format were included unchanged.",
                        ],
                      }),
                    e.jsx("div", {
                      ref: u.ref,
                      className: u.className,
                      children: e.jsx(N, { blob: r.blob, fileName: r.name }),
                    }),
                  ],
                }),
            ],
          }),
      e.jsx(L, { whatIsIt: b.what, howToUse: b.how, tip: b.tip }),
    ],
  });
}
export { ge as default };
//# sourceMappingURL=StlAsciiBinaryConverter-qqsQjr6Z.js.map
