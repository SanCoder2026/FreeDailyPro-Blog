# Generates the FDP-67 test STLs into the current directory (numpy). Same code as used on Nov 21.
import numpy as np, struct, os
def cube():
    v=np.array([[0,0,0],[10,0,0],[10,10,0],[0,10,0],[0,0,10],[10,0,10],[10,10,10],[0,10,10]],float)
    f=[(0,2,1),(0,3,2),(4,5,6),(4,6,7),(0,1,5),(0,5,4),(1,2,6),(1,6,5),(2,3,7),(2,7,6),(3,0,4),(3,4,7)]
    return np.array([[v[a],v[b],v[c]] for a,b,c in f])
def sphere(n=60):
    P=lambda t,p:[25*np.sin(t)*np.cos(p),25*np.sin(t)*np.sin(p),25*np.cos(t)]; tris=[]
    for i in range(n):
        for j in range(2*n):
            t0,t1=np.pi*i/n,np.pi*(i+1)/n; p0,p1=2*np.pi*j/(2*n),2*np.pi*(j+1)/(2*n)
            a,b,c,d=P(t0,p0),P(t1,p0),P(t1,p1),P(t0,p1)
            if i>0: tris.append([a,b,c])
            if i<n-1: tris.append([a,c,d])
    return np.array(tris)
def nrm(t):
    n=np.cross(t[1]-t[0],t[2]-t[0]); l=np.linalg.norm(n); return n/l if l else n
def ascii(T,name,fn,crlf=False,fmt='%e'):
    nl='\r\n' if crlf else '\n'; s=[f'solid {name}']
    for t in T:
        s.append('  facet normal '+' '.join(fmt%x for x in nrm(t))); s.append('    outer loop')
        for p in t: s.append('      vertex '+' '.join(fmt%x for x in p))
        s+=['    endloop','  endfacet']
    s.append(f'endsolid {name}'); open(fn,'w',newline='').write(nl.join(s)+nl)
def binary(T,fn,header=b'binary cube from FDP test',attr=0,count=None):
    out=bytearray(header.ljust(80,b' ')[:80]+struct.pack('<I',len(T) if count is None else count))
    for t in T: out+=struct.pack('<12fH',*nrm(t),*t.flatten(),attr)
    open(fn,'wb').write(out)
C=cube(); S=sphere()
ascii(C,'cube','cube-ascii.stl'); binary(C,'cube-binary.stl'); binary(C,'cube-binary-color.stl',header=b'COLOR=\xff\x00\x00\xff test',attr=0x801f)
binary(C,'binary-solid-header.stl',header=b'solid cube exported by SolidWorks'); ascii(C,'crlf','cube-ascii-crlf.stl',crlf=True,fmt='%.6f')
ascii(S,'sphere','sphere-ascii.stl'); binary(S,'sphere-binary.stl'); binary(C,'truncated.stl',count=50)
open('notstl.stl','w').write('hello this is not an stl file\n'*20); open('empty.stl','w').write('')
s=open('cube-ascii.stl').read(); open('two-solids.stl','w').write(s+s.replace('solid cube','solid cube2')); open('cube-ascii-upper.STL','w').write(s)
