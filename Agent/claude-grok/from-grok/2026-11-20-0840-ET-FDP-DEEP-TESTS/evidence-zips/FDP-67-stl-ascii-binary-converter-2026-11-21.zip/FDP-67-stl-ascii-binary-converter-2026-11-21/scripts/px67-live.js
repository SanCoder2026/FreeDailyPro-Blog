// FDP-67 STL ASCII / Binary Converter (Professional), guest. Usage: node px67-live.js <zero|left|cases|batch|quickbuy> [engine]   env TRIES, ANY=1, SUF
// zero: at the cap: upload, convert (does it run? result card?), any blob link in DOM?, Download -> cap dialog?
// left: uses left: convert + Download, convert other way + Download, Change file + Download, reload + Download. Records usage POSTs and counter.
// cases: edge files (convert only; downloads only when uses are left, env DL=1). batch: 3 files -> ZIP.
// Never signs in, never types an email or card, never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/67-stl-ascii-binary-converter/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const TOOL = 'https://www.freedailypro.com/tool/stl-ascii-binary-converter';
const mode = process.argv[2] || 'zero'; const eng = process.argv[3] || 'chromium'; const sfx = (eng === 'chromium' ? '' : '-' + eng) + (process.env.SUF || '');
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').replace(/dev[:%][^&"]*/g, 'dev:REDACTED').slice(0, 160);
fs.mkdirSync(OUT + 'cases', { recursive: true }); fs.mkdirSync(OUT + 'downloads', { recursive: true });
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p, net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 1000 }, locale: 'en-US', acceptDownloads: true }); p = await c.newPage(); p.setDefaultTimeout(15000); net = [];
  await p.addInitScript(() => { window.__t = []; const seen = new WeakSet(); setInterval(() => { document.querySelectorAll('[data-sonner-toast]').forEach(n => { if (!seen.has(n)) { seen.add(n); window.__t.push((n.innerText || '').trim()); } }); }, 120); });
  p.on('request', r => { const u = r.url(); if (r.method() === 'POST' && /freedailypro\.com\/api/.test(u) && !/insight\.hit|funnel\.hit/.test(u)) net.push({ t: now(), u: red(u) }); });
  await p.goto(TOOL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 400) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(250); } };
 const toasts = n => p.evaluate(n => (window.__t || []).slice(n), n); const tc = () => p.evaluate(() => (window.__t || []).length);
 const shot = n => p.screenshot({ path: OUT + 'cases/' + n + sfx + '.png', fullPage: false });
 const mainText = () => p.evaluate(() => document.querySelector('main').innerText);
 const block = async () => { const t = await mainText(); const i = t.search(/Drop an STL|Change file/); return i < 0 ? t.slice(0, 300) : t.slice(Math.max(0, i - 120), i + 700); };
 const upload = async f => { const np = net.length; const before = await used(); await p.locator('main input[type=file]').first().setInputFiles(Array.isArray(f) ? f.map(x => TF + x) : TF + f); await p.waitForTimeout(2500); return { before, after: await used(), posts: net.slice(np).length, dialog: await dialog(), block: (await block()).slice(0, 600), alerts: await p.locator('main [role=alert]').allInnerTexts(), btns: await p.evaluate(() => [...document.querySelectorAll('main button')].filter(x => /Convert to/.test(x.innerText)).map(x => x.innerText + (x.disabled ? ' [disabled: ' + x.title + ']' : ''))) }; };
 const convert = async to => { const np = net.length; const before = await used(); const n = await tc(); const t0 = Date.now(); await p.locator('main button', { hasText: to === 'ascii' ? 'Convert to ASCII STL' : 'Convert to Binary STL' }).click(); await p.waitForTimeout(2500);
  const dom = await p.evaluate(() => ({ blobLinks: [...document.querySelectorAll('a[href^="blob:"]')].map(a => (a.download || '') + ' ' + a.href.slice(0, 20)), dlBtns: [...document.querySelectorAll('main button')].filter(x => /Download|Save/.test(x.innerText)).map(x => x.innerText.trim()) }));
  const t = await mainText(); const i = t.search(/Vertices|Files\n/); return { ms: Date.now() - t0, before, after: await used(), posts: net.slice(np).map(x => x.u.slice(0, 70)), dialog: await dialog(), toasts: await toasts(n), card: i < 0 ? null : t.slice(Math.max(0, i - 40), i + 260), dom }; };
 const download = async (pre = '') => { const np = net.length; const before = await used(); const n = await tc(); const dl = p.waitForEvent('download', { timeout: +(process.env.DLT || 20000) }).catch(() => null); await p.locator('main button', { hasText: /^Download/ }).first().click(); const d = await dl; await p.waitForTimeout(1500); let file = null; if (d) { const nm = pre + (process.env.SUF || '') + d.suggestedFilename(); const f = OUT + 'downloads/' + nm; await d.saveAs(f); file = { name: d.suggestedFilename(), saved: nm, bytes: fs.statSync(f).size, md5: cp.execSync(`md5sum "${f}"`).toString().slice(0, 12) }; } const r = { before, after: await used(), posts: net.slice(np).map(x => x.u.slice(0, 70)), dialog: await dialog(), toasts: await toasts(n), file }; if (r.dialog) { await shot('dl-dialog-' + pre + Date.now() % 100000); await esc(); } return r; };
 const C = async (id, fn) => { try { R.cases[id] = await fn(); } catch (e) { R.cases[id] = { err: e.message.split('\n')[0].slice(0, 200) }; await shot(id + '-err').catch(() => { }); } console.log(id, JSON.stringify(R.cases[id]).slice(0, 900)); };
 const findLeft = async () => { if (process.env.ANY) { await open(); R.tries.push(await used()); return true; } const TRIES = +(process.env.TRIES || 10); for (let i = 0; i < TRIES; i++) { await open(); const u = await used(); R.tries.push(u); const [a, l] = u.split('/').map(Number); if (a < l) return true; await c.close(); } return false; };
 const strip = () => p.evaluate(() => (document.querySelector('main').innerText.match(/Trial[^\n]*/) || [null])[0]);
 const btn = t => p.locator('main button', { hasText: t }).first();
 const fresh = async () => { await p.goto(TOOL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); };
 if (mode === 'zero') { for (let i = 0; i < +(process.env.TRIES || 10); i++) { await open(); const u = await used(); R.tries.push(u); const [a, l] = u.split('/').map(Number); if (a >= l) break; await c.close(); } R.start = { used: await used(), strip: await strip() }; await shot('Z00');
  await C('Z01-upload-ascii', () => upload('cube-ascii.stl')); await shot('Z01');
  await C('Z02-convert-binary', () => convert('binary')); await shot('Z02-converted');
  await C('Z03-download', () => download('zero-'));
  await C('Z04-change-file-sphere-ascii', async () => { await btn('Change file').click(); await p.waitForTimeout(600); const u = await upload('sphere-binary.stl'); return { u, conv: await convert('ascii') }; });
  await C('Z05-download', () => download('zero-'));
  await C('Z06-reload-download', async () => { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); await upload('cube-binary.stl'); await convert('ascii'); return download('zero-r-'); });
  R.end = await used(); R.net = net;
 } else if (mode === 'left') { const ok = await findLeft(); R.found = ok; if (!ok) { console.log('no context with uses left', R.tries.join(',')); fs.writeFileSync(OUT + 'left' + sfx + '.json', JSON.stringify(R, null, 1)); await b.close(); return; }
  R.start = { used: await used(), strip: await strip() }; await shot('L00');
  await C('L01-upload-ascii', () => upload('cube-ascii.stl'));
  await C('L02-convert-binary', () => convert('binary')); await shot('L02');
  await C('L03-download', () => download('L03-'));
  await C('L04-download-again', () => download('L04-'));
  await C('L05-convert-ascii-disabled?', async () => ({ btns: (await upload('cube-ascii.stl').catch(() => null)) }));
  await C('L06-change-binary-to-ascii', async () => { await fresh(); const u = await upload('cube-binary-color.stl'); return { u, conv: await convert('ascii') }; });
  await C('L07-download', () => download('L07-'));
  await C('L08-sphere-ascii-to-binary', async () => { await fresh(); const u = await upload('sphere-ascii.stl'); return { u, conv: await convert('binary') }; });
  await C('L09-download', () => download('L09-'));
  await C('L10-binary-solid-header-to-ascii', async () => { await fresh(); const u = await upload('binary-solid-header.stl'); await shot('L10'); return { u, conv: await convert('ascii').catch(e => e.message.slice(0, 80)) }; });
  await C('L11-download', () => download('L11-'));
  R.end = await used(); R.net = net;
 } else if (mode === 'batch') { const ok = await findLeft(); R.found = ok; if (!ok) { fs.writeFileSync(OUT + 'batch' + sfx + '.json', JSON.stringify(R, null, 1)); await b.close(); return; }
  R.start = { used: await used(), strip: await strip() };
  await C('B01-add-4', async () => { const r = await upload(['cube-ascii.stl', 'cube-binary.stl', 'two-solids.stl', 'notstl.stl']); await shot('B01'); return r; });
  await C('B02-convert-binary', async () => { const r = await convert('binary'); await shot('B02'); return r; });
  await C('B03-download-zip', async () => { const r = await download('B03-'); if (r.file) r.list = cp.execSync(`unzip -l "${OUT}downloads/${r.file.saved}" | tail -n +4`).toString().trim().split('\n').slice(0, 8); return r; });
  await C('B04-dup-names', async () => { await fresh(); const r = await upload(['cube-ascii.stl', 'cube-ascii-upper.STL']); const cv = await convert('binary'); const d = await download('B04-'); if (d.file) d.list = cp.execSync(`unzip -l "${OUT}downloads/${d.file.saved}" | tail -n +4`).toString().trim().split('\n').slice(0, 6); return { r, cv, d }; });
  await C('B05-sphere-binary-to-ascii', async () => { await fresh(); await upload('sphere-binary.stl'); const cv = await convert('ascii'); return { cv, d: await download('B05-') }; });
  R.end = await used(); R.net = net;
 } else if (mode === 'extra') { if (process.env.CAP) { for (let i = 0; i < 10; i++) { await open(); const u = await used(); R.tries.push(u); const [a, l] = u.split('/').map(Number); if (a >= l) break; await c.close(); } } else { const ok = await findLeft(); if (!ok) { fs.writeFileSync(OUT + 'extra' + sfx + '.json', JSON.stringify(R, null, 1)); await b.close(); return; } }
  R.start = { used: await used() };
  for (const lab of ['Save to Google Drive', 'Save to my cloud storage']) await C('X-' + lab, async () => { await fresh(); await upload('cube-ascii.stl'); await convert('binary'); const np = net.length; const before = await used(); const pop = c.waitForEvent('page', { timeout: 8000 }).catch(() => null); await btn(lab).click(); const pg = await pop; await p.waitForTimeout(2500); const r = { before, after: await used(), posts: net.slice(np).map(x => x.u.slice(0, 70)), dialog: await dialog(), popup: pg ? red(pg.url()) : null }; await shot('X-' + lab.replace(/ /g, '-')); if (pg) await pg.close(); await esc(); return r; });
  await C('X-open-from-drive', async () => { await fresh(); const pop = c.waitForEvent('page', { timeout: 8000 }).catch(() => null); await btn('Open from Google Drive').click(); const pg = await pop; await p.waitForTimeout(2000); const r = { dialog: await dialog(), popup: pg ? red(pg.url()) : null }; await shot('X-open-drive'); if (pg) await pg.close(); await esc(); return r; });
  R.end = await used(); R.net = net;
 } else if (mode === 'perload') { const ok = await findLeft(); R.found = ok; if (!ok) { fs.writeFileSync(OUT + 'perload' + sfx + '.json', JSON.stringify(R, null, 1)); await b.close(); return; }
  R.start = { used: await used() };
  await C('P01-cube-to-binary-dl', async () => { await upload('cube-ascii.stl'); await convert('binary'); return download('P01-'); });
  await C('P02-same-page-change-file-sphere-to-ascii-dl', async () => { await btn('Change file').click(); await p.waitForTimeout(600); await upload('sphere-binary.stl'); await convert('ascii'); return download('P02-'); });
  await C('P03-same-page-change-file-color-to-ascii-dl', async () => { await btn('Change file').click(); await p.waitForTimeout(600); await upload('cube-binary-color.stl'); await convert('ascii'); return download('P03-'); });
  await C('P04-drive-save-with-uses-left', async () => { const np = net.length; const before = await used(); const pop = c.waitForEvent('page', { timeout: 8000 }).catch(() => null); await btn('Save to Google Drive').click(); const pg = await pop; await p.waitForTimeout(2500); const r = { before, after: await used(), posts: net.slice(np).map(x => x.u.slice(0, 70)), dialog: await dialog(), popup: pg ? red(pg.url()) : null }; await shot('P04-drive'); if (pg) await pg.close(); await esc(); return r; });
  R.end = await used(); R.net = net;
 } else if (mode === 'cases') { await open(); R.start = { used: await used() };
  for (const [id, f] of [['C01-notstl', 'notstl.stl'], ['C02-empty', 'empty.stl'], ['C03-truncated', 'truncated.stl'], ['C04-crlf', 'cube-ascii-crlf.stl'], ['C05-two-solids', 'two-solids.stl'], ['C06-upper-ext', 'cube-ascii-upper.STL'], ['C07-binary-solid-header', 'binary-solid-header.stl'], ['C08-color', 'cube-binary-color.stl'], ['C09-sphere-binary', 'sphere-binary.stl']])
   await C(id, async () => { await fresh(); const r = await upload(f); await shot(id); return r; });
  R.end = await used(); R.net = net;
 } else if (mode === 'quickbuy') { await open(); for (const [i, lab] of [[0, 'day'], [1, 'monthly']]) await C('Q-' + lab, async () => { const pg = await c.newPage(); await pg.goto(TOOL, { waitUntil: 'domcontentloaded' }); await pg.waitForTimeout(4500); await pg.locator('main button', { hasText: 'Quick Buy' }).nth(i).click(); await pg.waitForTimeout(7000); await pg.screenshot({ path: OUT + 'quickbuy-' + lab + sfx + '.png' }); const d = await pg.locator('[role=dialog]').first().innerText().catch(() => null); return { url: red(pg.url()), dialog: d ? d.replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null }; }); }
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', JSON.stringify(R.tries), JSON.stringify(R.start || ''), R.end); await b.close(); })();
