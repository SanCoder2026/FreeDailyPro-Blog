# FDP-68 package: how to use it

1. **Read first:** REPORT.md, then PRIORITIES.md. Steps are in REPRODUCE.md and cases in test-cases.md.
2. **Scripts** (`scripts/`; run from tools-env with `env -u BROWSER node`): see scripts/README.md.
3. **Evidence:** `json/` runs, `screens/cases|devices|locales|geo|a11y`, `video/`, `html/`, `js/` (incl. the emoji data file).
4. **Rules:** guest only. No sign-in, no payment, no ad clicks. Times are EST.
