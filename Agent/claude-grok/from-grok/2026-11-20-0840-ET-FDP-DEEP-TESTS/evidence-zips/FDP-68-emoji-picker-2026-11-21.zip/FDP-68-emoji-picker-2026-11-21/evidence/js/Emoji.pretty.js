import { ap as N, I as C, b as T, f as v } from "./index-B1CTyGtY.js";
import { r as n, j as a } from "./vendor-react-D01g8YgM.js";
import { b as z, T as E } from "./ToolPage-DwLoDncN.js";
import { T as L } from "./ToolInfoSection-C0i6Zbwo.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
const w = (s) =>
  s
    .toLowerCase()
    .split(/[^a-z0-9\u00c0-\u024f]+/)
    .filter(Boolean);
function O(s, l) {
  const r = w(l);
  if (r.length === 0) return 0;
  const t = w(s.label),
    h = s.tags.flatMap(w);
  let c = 0;
  for (const i of r)
    if (t.includes(i)) c += 6;
    else if (t.some((y) => y.startsWith(i))) c += 4;
    else if (h.includes(i)) c += 3;
    else if (h.some((y) => y.startsWith(i))) c += 1;
    else return -1;
  return (s.label.toLowerCase() === r.join(" ") && (c += 20), c);
}
function _(s, l) {
  return w(l).length
    ? s
        .map((r, t) => ({ e: r, i: t, s: O(r, l) }))
        .filter((r) => r.s >= 0)
        .sort((r, t) => t.s - r.s || r.i - t.i)
        .map((r) => r.e)
    : s;
}
const x = [
    { char: "😀", keywords: "grin happy smile face" },
    { char: "😃", keywords: "happy smile grin joy face" },
    { char: "😄", keywords: "happy smile laugh joy face" },
    { char: "😁", keywords: "grin happy smile teeth face" },
    { char: "😆", keywords: "laugh happy squint face" },
    { char: "😂", keywords: "laugh cry funny lol" },
    { char: "🤣", keywords: "rofl laugh floor funny hilarious" },
    { char: "🙂", keywords: "smile slight happy face" },
    { char: "😊", keywords: "happy blush smile shy face" },
    { char: "😍", keywords: "love heart eyes crush" },
    { char: "🥰", keywords: "love hearts adore" },
    { char: "😘", keywords: "kiss love face blow" },
    { char: "😎", keywords: "cool sunglasses" },
    { char: "🤩", keywords: "star struck excited eyes wow" },
    { char: "🥳", keywords: "party celebrate birthday" },
    { char: "😜", keywords: "wink tongue silly playful" },
    { char: "🤪", keywords: "zany crazy wild silly" },
    { char: "😏", keywords: "smirk sly sneaky" },
    { char: "🤨", keywords: "skeptical raised eyebrow suspicious" },
    { char: "😐", keywords: "neutral blank straight face" },
    { char: "🙄", keywords: "eye roll annoyed unimpressed" },
    { char: "😴", keywords: "sleep tired zzz" },
    { char: "🥱", keywords: "yawn tired bored sleepy" },
    { char: "😢", keywords: "sad cry tear" },
    { char: "😭", keywords: "sob crying sad" },
    { char: "😡", keywords: "angry mad rage" },
    { char: "🤬", keywords: "furious cursing angry swearing" },
    { char: "😱", keywords: "scared shock surprised" },
    { char: "😨", keywords: "fear scared afraid nervous" },
    { char: "🤔", keywords: "thinking hmm" },
    { char: "🙃", keywords: "upside down silly" },
    { char: "😉", keywords: "wink flirt" },
    { char: "🤗", keywords: "hug welcome" },
    { char: "😇", keywords: "angel innocent halo" },
    { char: "🤒", keywords: "sick fever ill thermometer" },
    { char: "🤢", keywords: "nauseous sick gross disgust" },
    { char: "🥵", keywords: "hot sweating overheated" },
    { char: "🥶", keywords: "cold freezing frozen" },
    { char: "😵", keywords: "dizzy confused knocked out" },
    { char: "🤯", keywords: "mind blown shocked exploding head" },
    { char: "🥺", keywords: "pleading puppy eyes hopeful" },
    { char: "😬", keywords: "grimace awkward nervous cringe" },
    { char: "👍", keywords: "thumbs up like good yes" },
    { char: "👎", keywords: "thumbs down dislike no" },
    { char: "👏", keywords: "clap applause" },
    { char: "🙏", keywords: "pray thanks please" },
    { char: "🤝", keywords: "handshake deal agreement" },
    { char: "✌️", keywords: "peace victory" },
    { char: "👋", keywords: "wave hello bye" },
    { char: "💪", keywords: "strong muscle flex" },
    { char: "🤞", keywords: "fingers crossed luck" },
    { char: "👌", keywords: "ok okay perfect" },
    { char: "🤙", keywords: "call me shaka hang loose" },
    { char: "👆", keywords: "point up finger" },
    { char: "👇", keywords: "point down finger" },
    { char: "👈", keywords: "point left finger" },
    { char: "👉", keywords: "point right finger" },
    { char: "✊", keywords: "fist raised power solidarity" },
    { char: "👊", keywords: "fist bump punch" },
    { char: "🖐️", keywords: "hand stop high five" },
    { char: "🤟", keywords: "love you hand sign rock" },
    { char: "🫡", keywords: "salute respect yes sir" },
    { char: "❤️", keywords: "heart love red" },
    { char: "💔", keywords: "broken heart sad" },
    { char: "💕", keywords: "hearts love two" },
    { char: "💖", keywords: "sparkling heart love" },
    { char: "💗", keywords: "growing heart love pink" },
    { char: "💓", keywords: "beating heart love pulse" },
    { char: "🧡", keywords: "orange heart love" },
    { char: "💛", keywords: "yellow heart love" },
    { char: "💚", keywords: "green heart love" },
    { char: "💙", keywords: "blue heart love" },
    { char: "💜", keywords: "purple heart love" },
    { char: "🖤", keywords: "black heart love dark" },
    { char: "🤍", keywords: "white heart love pure" },
    { char: "💝", keywords: "heart gift ribbon love" },
    { char: "🐶", keywords: "dog puppy pet" },
    { char: "🐱", keywords: "cat kitten pet" },
    { char: "🦁", keywords: "lion king animal" },
    { char: "🐼", keywords: "panda bear" },
    { char: "🦄", keywords: "unicorn magic" },
    { char: "🐸", keywords: "frog animal" },
    { char: "🐢", keywords: "turtle slow animal" },
    { char: "🦋", keywords: "butterfly insect" },
    { char: "🐘", keywords: "elephant animal big" },
    { char: "🐵", keywords: "monkey animal" },
    { char: "🐰", keywords: "rabbit bunny animal" },
    { char: "🦊", keywords: "fox animal" },
    { char: "🐻", keywords: "bear animal" },
    { char: "🐨", keywords: "koala animal" },
    { char: "🐧", keywords: "penguin animal bird" },
    { char: "🦉", keywords: "owl bird animal wise" },
    { char: "🐴", keywords: "horse animal" },
    { char: "🐝", keywords: "bee insect honey" },
    { char: "🍕", keywords: "pizza food" },
    { char: "🍔", keywords: "burger food" },
    { char: "🍩", keywords: "donut sweet food" },
    { char: "☕", keywords: "coffee drink" },
    { char: "🍎", keywords: "apple fruit food" },
    { char: "🍰", keywords: "cake dessert birthday" },
    { char: "🍺", keywords: "beer drink" },
    { char: "🍷", keywords: "wine drink" },
    { char: "🍟", keywords: "fries food snack" },
    { char: "🌮", keywords: "taco food mexican" },
    { char: "🍣", keywords: "sushi food japanese" },
    { char: "🍦", keywords: "ice cream dessert sweet" },
    { char: "🍫", keywords: "chocolate sweet candy" },
    { char: "🍪", keywords: "cookie sweet dessert" },
    { char: "🍜", keywords: "noodles ramen food soup" },
    { char: "🥗", keywords: "salad food healthy" },
    { char: "🍿", keywords: "popcorn snack movie" },
    { char: "🍉", keywords: "watermelon fruit food" },
    { char: "✈️", keywords: "plane travel flight" },
    { char: "🚗", keywords: "car drive travel" },
    { char: "🏖️", keywords: "beach vacation travel" },
    { char: "🎉", keywords: "party celebrate confetti" },
    { char: "🎂", keywords: "birthday cake celebrate" },
    { char: "🎁", keywords: "gift present" },
    { char: "💡", keywords: "idea lightbulb bright" },
    { char: "🔥", keywords: "fire hot lit" },
    { char: "⭐", keywords: "star favorite" },
    { char: "✅", keywords: "check done complete yes" },
    { char: "❌", keywords: "cross wrong no cancel" },
    { char: "⚡", keywords: "lightning bolt fast" },
    { char: "🎯", keywords: "target goal bullseye" },
    { char: "🚀", keywords: "rocket launch fast" },
    { char: "💰", keywords: "money bag cash" },
    { char: "📅", keywords: "calendar date schedule" },
    { char: "⏰", keywords: "alarm clock time" },
    { char: "📱", keywords: "phone mobile device" },
    { char: "💻", keywords: "laptop computer work" },
    { char: "📧", keywords: "email mail message" },
    { char: "🚆", keywords: "train travel transport" },
    { char: "🚢", keywords: "ship boat travel" },
    { char: "🏔️", keywords: "mountain travel nature" },
    { char: "🗽", keywords: "statue liberty travel landmark" },
    { char: "🎒", keywords: "backpack travel bag" },
    { char: "🧳", keywords: "luggage suitcase travel packing" },
    { char: "☀️", keywords: "sun sunny weather bright" },
    { char: "🌧️", keywords: "rain weather cloud" },
    { char: "⛈️", keywords: "storm thunder lightning weather" },
    { char: "❄️", keywords: "snow snowflake cold winter" },
    { char: "🌈", keywords: "rainbow colorful weather" },
    { char: "🌙", keywords: "moon night crescent" },
    { char: "🌊", keywords: "wave ocean water sea" },
    { char: "🌸", keywords: "flower blossom spring pink" },
    { char: "🌻", keywords: "sunflower flower yellow" },
    { char: "🌵", keywords: "cactus desert plant" },
    { char: "🍁", keywords: "leaf autumn fall maple" },
    { char: "🌳", keywords: "tree nature plant green" },
    { char: "⚽", keywords: "soccer football sport ball" },
    { char: "🏀", keywords: "basketball sport ball" },
    { char: "🏈", keywords: "football american sport ball" },
    { char: "🎾", keywords: "tennis sport ball" },
    { char: "🏓", keywords: "ping pong table tennis sport" },
    { char: "🏋️", keywords: "gym workout weightlifting fitness" },
    { char: "🏃", keywords: "run running exercise fitness" },
    { char: "🧘", keywords: "yoga meditate relax mindfulness" },
    { char: "🎮", keywords: "game controller gaming video" },
    { char: "🎸", keywords: "guitar music instrument" },
    { char: "🎨", keywords: "art paint palette creative" },
    { char: "📚", keywords: "books read study education" },
    { char: "🎬", keywords: "movie film clapperboard cinema" },
    { char: "🎵", keywords: "music note song" },
    { char: "💯", keywords: "hundred perfect score complete" },
    { char: "❗", keywords: "exclamation important alert" },
    { char: "❓", keywords: "question mark confused" },
    { char: "♻️", keywords: "recycle green eco environment" },
    { char: "🔒", keywords: "lock secure private locked" },
    { char: "🔓", keywords: "unlock open unlocked" },
    { char: "⚠️", keywords: "warning caution alert" },
    { char: "🆕", keywords: "new label badge" },
    { char: "🔔", keywords: "bell notification alert ring" },
    { char: "📌", keywords: "pin pushpin location marker" },
    { char: "🔗", keywords: "link chain url connect" },
    { char: "🏆", keywords: "trophy win award champion" },
  ],
  m = {
    what: "A searchable emoji picker with the complete Unicode emoji set (about 1,900 emoji), organised by category, with skin-tone choices, so you can find and copy any emoji without scrolling through a phone keyboard.",
    how: 'Search by keyword (like "happy" or "travel") or pick a category, choose a skin tone if you want one, and click any emoji to copy it to your clipboard.',
    tip: "Try a few different keywords if your first search doesn't find what you're looking for — emoji are tagged by common descriptive words, and different people describe the same emoji slightly differently. How an emoji looks depends on the device you paste it into.",
  },
  I = [
    "Smileys & emotion",
    "People & body",
    "Components",
    "Animals & nature",
    "Food & drink",
    "Travel & places",
    "Activities",
    "Objects",
    "Symbols",
    "Flags",
  ],
  U = [
    ["Default", "🖐️"],
    ["Light", "🖐🏻"],
    ["Medium-light", "🖐🏼"],
    ["Medium", "🖐🏽"],
    ["Medium-dark", "🖐🏾"],
    ["Dark", "🖐🏿"],
  ];
function ie() {
  const [s, l] = n.useState(""),
    [r, t] = n.useState("all"),
    [h, c] = n.useState(0),
    [i, y] = n.useState(null);
  n.useEffect(() => {
    let e = !0;
    return (
      N(() => import("./compact-yUvgKgo9.js"), [])
        .then((o) => {
          if (!e) return;
          const k = o.default
            .filter((d) => d.group !== void 0)
            .map((d) => ({
              char: d.unicode,
              label: d.label,
              tags: d.tags ?? [],
              group: d.group,
              skins: d.skins?.filter((u) => u.unicode).map((u) => u.unicode),
            }));
          y(k);
        })
        .catch(() =>
          y(
            x.map((o) => ({
              char: o.char,
              label: o.keywords.split(" ")[0] ?? "",
              tags: o.keywords.split(" "),
              group: 0,
            })),
          ),
        ),
      () => {
        e = !1;
      }
    );
  }, []);
  const p = n.useMemo(() => {
      const e =
        i ??
        x.map((o) => ({
          char: o.char,
          label: "",
          tags: o.keywords.split(" "),
          group: 0,
        }));
      return (
        s.trim().toLowerCase(),
        _(
          e.filter((o) => r === "all" || o.group === r),
          s,
        )
      );
    }, [i, s, r]),
    { logUsageNow: j } = z(),
    g = (e) =>
      h > 0 && e.skins && e.skins.length >= 5 ? e.skins[h - 1] : e.char,
    [f, b] = n.useState(null),
    S = async (e) => {
      if (await j("copy"))
        try {
          (await navigator.clipboard.writeText(e),
            b(e),
            setTimeout(() => b((k) => (k === e ? null : k)), 2500),
            v.success(`Copied ${e}`));
        } catch {
          v.error(
            "Couldn't copy automatically. Select the emoji and copy it by hand.",
          );
        }
    };
  return a.jsxs(E, {
    children: [
      a.jsx(C, {
        placeholder: "Search emoji by keyword (e.g. happy, flag india, cat)...",
        value: s,
        onChange: (e) => l(e.target.value),
        className: "mb-3",
      }),
      a.jsxs("div", {
        className: "flex flex-wrap items-center gap-2 mb-4",
        children: [
          a.jsx("button", {
            type: "button",
            onClick: () => t("all"),
            className: `text-xs rounded-full border px-3 py-1 ${r === "all" ? "bg-primary text-primary-foreground" : ""}`,
            children: "All",
          }),
          I.map((e, o) =>
            o === 2
              ? null
              : a.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => t(o),
                    className: `text-xs rounded-full border px-3 py-1 ${r === o ? "bg-primary text-primary-foreground" : ""}`,
                    children: e,
                  },
                  e,
                ),
          ),
          a.jsx("select", {
            "aria-label": "Skin tone",
            value: h,
            onChange: (e) => c(Number(e.target.value)),
            className:
              "ml-auto h-8 rounded-md border bg-background px-2 text-xs",
            children: U.map(([e, o], k) =>
              a.jsxs(
                "option",
                { value: k, children: [o, " ", e, " skin tone"] },
                e,
              ),
            ),
          }),
        ],
      }),
      a.jsx("p", {
        className: "text-sm font-medium mb-1 min-h-5",
        role: "status",
        "aria-live": "polite",
        "data-testid": "ep-copied",
        children: f ? `Copied ${f} to your clipboard` : "",
      }),
      a.jsx("p", {
        className: "text-xs text-muted-foreground mb-2",
        children: i
          ? `${p.length.toLocaleString()} emoji`
          : "Loading the full emoji set…",
      }),
      a.jsx("div", {
        className: "grid grid-cols-6 sm:grid-cols-8 md:grid-cols-10 gap-2",
        children: p.map((e) =>
          a.jsx(
            "button",
            {
              type: "button",
              onClick: () => S(g(e)),
              className:
                "text-3xl p-2 rounded-lg hover:bg-muted transition-colors",
              title: e.label || e.tags.join(" "),
              "aria-label": `Copy ${e.label || e.tags[0] || "emoji"}`,
              children: g(e),
            },
            e.char,
          ),
        ),
      }),
      p.length === 0 &&
        a.jsxs("p", {
          className: "text-sm text-muted-foreground text-center py-8",
          children: ['No emoji found for "', s, '"'],
        }),
      a.jsxs("p", {
        className: "text-xs text-muted-foreground mt-4",
        "data-testid": "ep-crosslink",
        children: [
          "Need the code for an emoji (U+ code point, HTML entity, CSS or JavaScript escape)? Use the ",
          a.jsx(T, {
            href: "/tool/emoji-unicode-converter",
            className: "underline",
            children: "Emoji to Unicode Converter",
          }),
          ".",
        ],
      }),
      a.jsx(L, { whatIsIt: m.what, howToUse: m.how, tip: m.tip }),
    ],
  });
}
export { ie as default };
//# sourceMappingURL=EmojiPicker-DAHM4kZZ.js.map
