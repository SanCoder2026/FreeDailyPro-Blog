// FDP-68 Emoji Picker & Copy (Professional), guest. Usage: node px68-live.js <zero|left|cases|tones> [engine]   env TRIES, SUF
// zero: at the cap: click emoji (copies? cap dialog?), Ctrl+C selection, keyboard Enter. left: copies with uses left, count per copy, reload. cases: search terms. tones: skin tones.
// Clipboard set/read from a same-origin robots.txt helper tab. Never signs in, never pays, never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const OUT = '/workspace/deep/68-emoji-picker/live/'; const TOOL = 'https://www.freedailypro.com/tool/emoji-picker';
const mode = process.argv[2] || 'zero'; const eng = process.argv[3] || 'chromium'; const sfx = (eng === 'chromium' ? '' : '-' + eng) + (process.env.SUF || '');
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const red = u => u.replace(/(client_id|deviceId|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/dev[:%][^&"]*/g, 'dev:REDACTED').slice(0, 120);
fs.mkdirSync(OUT + 'cases', { recursive: true });
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p, h, net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 1000 }, locale: 'en-US' }); if (eng === 'chromium') await c.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://www.freedailypro.com' }); p = await c.newPage(); p.setDefaultTimeout(12000); net = []; h = null;
  await p.addInitScript(() => { window.__t = []; const seen = new WeakSet(); setInterval(() => { document.querySelectorAll('[data-sonner-toast]').forEach(n => { if (!seen.has(n)) { seen.add(n); window.__t.push((n.innerText || '').trim()); } }); }, 120); });
  p.on('request', r => { const u = r.url(); if (r.method() === 'POST' && /freedailypro\.com\/api/.test(u) && !/insight\.hit|funnel\.hit/.test(u)) net.push({ t: now(), u: red(u) }); });
  await p.goto(TOOL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForFunction(() => /\d emoji/.test(document.querySelector('main').innerText), null, { timeout: 20000 }).catch(() => { }); await p.waitForTimeout(1500); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 400) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(250); } };
 const toasts = () => p.evaluate(() => { const t = window.__t.slice(); window.__t.length = 0; return t; });
 const shot = n => p.screenshot({ path: OUT + 'cases/' + n + sfx + '.png' });
 const helper = async () => { if (!h) { h = await c.newPage(); await h.goto('https://www.freedailypro.com/robots.txt'); } };
 const clipSet = async s => { if (eng !== 'chromium') return; await helper(); await h.bringToFront(); await h.evaluate(s => navigator.clipboard.writeText(s), s).catch(() => { }); await p.bringToFront(); };
 const clipGet = async () => { if (eng !== 'chromium') return null; await helper(); await h.bringToFront(); const v = await h.evaluate(() => navigator.clipboard.readText()).catch(e => 'ERR ' + e.message.slice(0, 40)); await p.bringToFront(); return v; };
 const count = () => p.evaluate(() => (document.querySelector('main').innerText.match(/([\d,]+) emoji\b/) || [])[1]);
 const strip = () => p.evaluate(() => (document.querySelector('main').innerText.match(/Trial[^\n]*/) || [null])[0]);
 const search = async q => { await p.locator('main input').first().fill(q); await p.waitForTimeout(700); return { n: await count(), first: await p.evaluate(() => [...document.querySelectorAll('main .grid button')].slice(0, 12).map(b => b.innerText + '=' + b.title)), none: await p.evaluate(() => (document.querySelector('main').innerText.match(/No emoji found[^\n]*/) || [null])[0]) }; };
 const clickEmoji = async (i = 0, how = 'click') => { await clipSet('SENTINEL'); const np = net.length; const before = await used(); const btn = p.locator('main .grid button').nth(i); const ch = await btn.innerText(); if (how === 'enter') { await btn.focus(); await p.keyboard.press('Enter'); } else await btn.click(); await p.waitForTimeout(1400); const r = { emoji: ch, before, after: await used(), posts: net.slice(np).map(x => x.u.slice(0, 60)), dialog: await dialog(), toasts: await toasts(), status: await p.locator('[data-testid=ep-copied]').innerText().catch(() => null), clip: await clipGet() }; if (r.dialog) { await shot('dialog-' + Date.now() % 100000); await esc(); } return r; };
 const ctrlC = async () => { await clipSet('SENTINEL'); const np = net.length; const before = await used(); await p.evaluate(() => { const el = document.querySelector('main .grid button'); const r = document.createRange(); r.selectNodeContents(el); const s = getSelection(); s.removeAllRanges(); s.addRange(r); }); await p.keyboard.press('Control+C'); await p.waitForTimeout(1200); return { before, after: await used(), posts: net.slice(np).length, dialog: await dialog(), clip: await clipGet() }; };
 const C = async (id, fn) => { try { R.cases[id] = await fn(); } catch (e) { R.cases[id] = { err: e.message.split('\n')[0].slice(0, 200) }; await shot(id + '-err').catch(() => { }); } console.log(id, JSON.stringify(R.cases[id]).slice(0, 700)); };
 const find = async want => { for (let i = 0; i < +(process.env.TRIES || 10); i++) { await open(); const u = await used(); R.tries.push(u); const [a, l] = u.split('/').map(Number); if (want === 'cap' ? a >= l : a < l) return true; await c.close(); } return false; };
 if (mode === 'zero' || mode === 'left') { R.found = await find(mode === 'zero' ? 'cap' : 'left'); R.start = { used: await used(), strip: await strip(), count: await count() }; await shot(mode === 'zero' ? 'Z00' : 'L00');
  await C('A01-click-first', () => clickEmoji(0)); await shot(mode[0].toUpperCase() + '01-after-click');
  await C('A02-click-second', () => clickEmoji(1));
  await C('A03-click-same-again', () => clickEmoji(1));
  await C('A04-search-cat-click', async () => { const s = await search('cat'); return { s, r: await clickEmoji(0) }; });
  await C('A05-keyboard-enter', () => clickEmoji(2, 'enter'));
  await C('A06-ctrlC-selection', () => ctrlC());
  await C('A07-reload-click', async () => { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); return clickEmoji(5); });
  for (let k = 8; k <= (mode === 'left' ? 13 : 8); k++) await C('A' + String(k).padStart(2, '0') + '-more-click', () => clickEmoji(10 + k));
  R.end = await used(); R.net = net;
 } else if (mode === 'cases') { await open(); R.start = { used: await used(), count: await count() };
  for (const q of ['heart', 'flag india', 'india', 'sun', 'flower', 'sunflower', 'thumbs up', 'thumbsup', '+1', 'lol', 'smile', 'Smile', 'SMILE', 'cœur', 'corazón', 'xyzzy', ' ', 'u+1f600', 'party', 'rocket', 'tada', 'shrug', 'skin', 'hair', 'regional', 'flag', 'us', 'united states', 'uk'])
   await C('S:' + q, () => search(q));
  await C('S-shot-noresult', async () => { await search('xyzzy'); await shot('S-noresult'); return 1; });
  await search(''); for (const cat of ['Smileys & emotion', 'People & body', 'Animals & nature', 'Food & drink', 'Travel & places', 'Activities', 'Objects', 'Symbols', 'Flags']) await C('Cat:' + cat, async () => { await p.locator('main button', { hasText: cat }).first().click(); await p.waitForTimeout(500); return { n: await count(), first: await p.evaluate(() => [...document.querySelectorAll('main .grid button')].slice(0, 6).map(b => b.innerText)) }; });
  await C('Cat+search Flags "india"', async () => { await p.locator('main input').first().fill('india'); await p.waitForTimeout(600); return { n: await count() }; });
  await C('All-components?', async () => { await p.locator('main input').first().fill(''); await p.locator('main button', { hasText: /^All$/ }).click(); await p.waitForTimeout(500); return await p.evaluate(() => [...document.querySelectorAll('main .grid button')].filter(b => /skin tone|hair/i.test(b.title)).map(b => b.innerText + '=' + b.title).slice(0, 12)); });
  R.end = await used(); R.net = net;
 } else if (mode === 'tones') { await open(); R.start = { used: await used() };
  for (const k of [0, 1, 3, 5]) await C('T' + k, async () => { await p.selectOption('main select[aria-label="Skin tone"]', String(k)); await p.waitForTimeout(500); const out = {}; for (const q of ['thumbs up', 'wave', 'family', 'couple', 'handshake', 'person', 'santa', 'smile']) { await p.locator('main input').first().fill(q); await p.waitForTimeout(400); out[q] = await p.evaluate(() => [...document.querySelectorAll('main .grid button')].slice(0, 5).map(b => b.innerText + ' ' + [...b.innerText].map(c => c.codePointAt(0).toString(16)).join(','))); } if (k === 5) await shot('T5'); return out; });
  R.end = await used(); R.net = net; }
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', JSON.stringify(R.tries), JSON.stringify(R.start || ''), R.end); await b.close(); })();
