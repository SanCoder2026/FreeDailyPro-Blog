// FDP-68: which network requests does one emoji copy send? (guest; logs URL paths only, redacted)
const { chromium } = require('playwright');
(async () => { const b = await chromium.launch(); const c = await b.newContext(); await c.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://www.freedailypro.com' }); const p = await c.newPage(); const L = []; let on = false;
 p.on('request', r => { if (on) L.push(r.method() + ' ' + r.url().replace(/\?.*/, '').slice(0, 90) + ' ' + ((r.postData() || '').replace(/dev:[0-9a-f-]+/g, 'dev:REDACTED').slice(0, 160))); });
 await p.goto('https://www.freedailypro.com/tool/emoji-picker', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(7000); on = true;
 await p.locator('main .grid button').first().click(); await p.waitForTimeout(4000); on = false; console.log(JSON.stringify(L.filter(x => !/google|doubleclick|adtrafficquality|gstatic/.test(x)), null, 1)); await b.close(); })();
