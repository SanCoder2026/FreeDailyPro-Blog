import { r as l, j as a } from "./vendor-react-D01g8YgM.js";
import {
  b as ce,
  T as de,
  F as Y,
  D as q,
  d as O,
} from "./ToolPage-DwLoDncN.js";
import { B as I, e as j, I as M, f as P } from "./index-B1CTyGtY.js";
import { C as he } from "./card-KXKUZKW8.js";
import { C as ue } from "./checkbox-Ml1pfDb3.js";
import { J as ge } from "./jszip.min-CT0ZA6V1.js";
import { T as pe } from "./ToolInfoSection-C0i6Zbwo.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-DhOoIDuZ.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
const F = 64,
  W = 16,
  T = 16384,
  xe = 268435456,
  R = (t, r, o) =>
    Math.min(o, Math.max(r, Number.isFinite(t) ? Math.floor(t) : r));
function z(t, r, o) {
  return R(parseInt(t, 10), r, o);
}
function we(t, r) {
  const o = Math.max(1, Math.floor(r.cols) || 1),
    s = R(r.padding, 0, F),
    e = R(r.extrude, 0, W),
    m = Math.max(1, Math.ceil(t.length / o)),
    i = Math.max(1, ...t.map((c) => c.width)),
    w = Math.max(1, ...t.map((c) => c.height)),
    p = i + e * 2,
    x = w + e * 2,
    S = t.map((c, f) => {
      const D = f % o,
        k = Math.floor(f / o),
        A = D * (p + s),
        y = k * (x + s);
      return {
        name: c.name,
        w: c.width,
        h: c.height,
        cellX: A,
        cellY: y,
        x: A + e + Math.floor((i - c.width) / 2),
        y: y + e + Math.floor((w - c.height) / 2),
      };
    });
  return {
    width: o * p + (o - 1) * s,
    height: m * x + (m - 1) * s,
    cols: o,
    rows: m,
    cellW: p,
    cellH: x,
    padding: s,
    extrude: e,
    placements: S,
  };
}
function fe(t) {
  return t.width > T || t.height > T || t.width * t.height > xe
    ? `That sheet would be ${t.width} x ${t.height} px, more than a browser can draw (${T} px on a side). Use more columns, fewer frames or smaller frames.`
    : null;
}
function be(t, r, o) {
  t.imageSmoothingEnabled = !1;
  const s = r.extrude;
  r.placements.forEach((e, m) => {
    const i = o[m];
    (t.drawImage(i, e.x, e.y),
      s &&
        (t.drawImage(i, 0, 0, 1, e.h, e.x - s, e.y, s, e.h),
        t.drawImage(i, e.w - 1, 0, 1, e.h, e.x + e.w, e.y, s, e.h),
        t.drawImage(i, 0, 0, e.w, 1, e.x, e.y - s, e.w, s),
        t.drawImage(i, 0, e.h - 1, e.w, 1, e.x, e.y + e.h, e.w, s),
        t.drawImage(i, 0, 0, 1, 1, e.x - s, e.y - s, s, s),
        t.drawImage(i, e.w - 1, 0, 1, 1, e.x + e.w, e.y - s, s, s),
        t.drawImage(i, 0, e.h - 1, 1, 1, e.x - s, e.y + e.h, s, s),
        t.drawImage(i, e.w - 1, e.h - 1, 1, 1, e.x + e.w, e.y + e.h, s, s)));
  });
}
function Se(t) {
  const r = new Map();
  return t.map((o, s) => {
    const e = o.trim() || `frame_${String(s + 1).padStart(2, "0")}.png`,
      m = (r.get(e) ?? 0) + 1;
    return (
      r.set(e, m),
      m === 1 ? e : e.replace(/(\.[^.]*)?$/, (i) => `-${m}${i}`)
    );
  });
}
function je(t, r) {
  const o = {};
  for (const s of t.placements)
    o[s.name] = {
      frame: { x: s.x, y: s.y, w: s.w, h: s.h },
      rotated: !1,
      trimmed: !1,
      spriteSourceSize: { x: 0, y: 0, w: s.w, h: s.h },
      sourceSize: { w: s.w, h: s.h },
    };
  return {
    frames: o,
    meta: {
      app: "FreeDailyPro Sprite Sheet",
      image: r,
      format: "RGBA8888",
      size: { w: t.width, h: t.height },
      scale: "1",
      padding: t.padding,
      extrude: t.extrude,
    },
  };
}
function Ce(t, r, o, s, e = 0) {
  const m = Math.max(1, Math.floor(o) || 1),
    i = Math.max(1, Math.floor(s) || 1),
    w = R(e, 0, F),
    p = (t - w * (m - 1)) / m,
    x = (r - w * (i - 1)) / i,
    S = [];
  for (let c = 0; c < i; c++)
    for (let f = 0; f < m; f++)
      S.push({
        x: Math.round(f * (p + w)),
        y: Math.round(c * (x + w)),
        w: Math.max(1, Math.floor(p)),
        h: Math.max(1, Math.floor(x)),
      });
  return {
    cells: S,
    exact: Number.isInteger(p) && Number.isInteger(x) && p > 0 && x > 0,
  };
}
const _ = (t) => `${t} ${t === 1 ? "frame" : "frames"}`,
  J = {
    what: "Combines multiple individual images into a single sprite sheet grid, or splits an existing sprite sheet back into individual frame images — useful for game development and animation work.",
    how: "In combine mode, upload your frames in order and set the grid columns; in split mode, upload a sprite sheet and specify its rows and columns. Download the result.",
    tip: "Frames of the same pixel size make the cleanest grid. If sizes differ, each cell takes the size of the largest frame and smaller ones are centered, not scaled.",
  };
function tt() {
  const [t, r] = l.useState("combine"),
    [o, s] = l.useState([]),
    [e, m] = l.useState("4"),
    [i, w] = l.useState(null),
    [p, x] = l.useState(null),
    [S, c] = l.useState("0"),
    [f, D] = l.useState("0"),
    [k, A] = l.useState(!1),
    [y, X] = l.useState(null),
    [B, K] = l.useState(null),
    [G, Q] = l.useState("4"),
    [H, ee] = l.useState("2"),
    [Z, te] = l.useState("0"),
    [ae, se] = l.useState(!0),
    [E, V] = l.useState([]),
    { logUsageNow: oe } = ce(),
    ne = l.useCallback((n) => {
      (s(n), w(null), x(null), X(null));
    }, []),
    re = l.useCallback((n) => {
      const u = n[0];
      u && (K(u), V([]));
    }, []),
    ie = async () => {
      if (o.length === 0) return;
      const n = Math.max(1, parseInt(e, 10) || 1);
      let u;
      try {
        u = await Promise.all(
          o.map(
            (h) =>
              new Promise((N, L) => {
                const v = new Image();
                ((v.onload = () => N(v)),
                  (v.onerror = () => L(new Error(`Couldn't read ${h.name}`))),
                  (v.src = URL.createObjectURL(h)));
              }),
          ),
        );
      } catch (h) {
        P.error(
          h instanceof Error ? h.message : "One of the frames couldn't be read",
        );
        return;
      }
      const b = Se(o.map((h) => h.name)),
        g = we(
          u.map((h, N) => ({
            name: b[N],
            width: h.naturalWidth,
            height: h.naturalHeight,
          })),
          { cols: n, padding: z(S, 0, F), extrude: z(f, 0, W) },
        ),
        U = fe(g);
      if (U) {
        P.error(U);
        return;
      }
      if (!(await oe())) return;
      const d = document.createElement("canvas");
      ((d.width = g.width), (d.height = g.height));
      const C = d.getContext("2d");
      (be(C, g, u),
        d.toBlob((h) => {
          h && (x(h), w(URL.createObjectURL(h)));
        }, "image/png"),
        X(
          new Blob([JSON.stringify(je(g, "sprite-sheet.png"), null, 2)], {
            type: "application/json",
          }),
        ),
        P.success(
          `Combined ${_(o.length)} into a ${g.width} × ${g.height} px sprite sheet (${g.cols}×${g.rows})`,
        ));
    },
    le = async () => {
      if (!B) return;
      const n = Math.max(1, parseInt(G, 10) || 1),
        u = Math.max(1, parseInt(H, 10) || 1),
        b = new Image();
      ((b.src = URL.createObjectURL(B)),
        await new Promise((d) => (b.onload = d)));
      const { cells: g, exact: U } = Ce(
          b.naturalWidth,
          b.naturalHeight,
          n,
          u,
          z(Z, 0, F),
        ),
        $ = [];
      for (const d of g) {
        const C = document.createElement("canvas");
        ((C.width = d.w),
          (C.height = d.h),
          C.getContext("2d").drawImage(b, d.x, d.y, d.w, d.h, 0, 0, d.w, d.h));
        const N = await new Promise((L) => C.toBlob((v) => L(v), "image/png"));
        $.push({ url: URL.createObjectURL(N), blob: N });
      }
      (V($), se(U), P.success(`Split into ${_($.length)}`));
    },
    me = async () => {
      const n = new ge();
      E.forEach((b, g) =>
        n.file(`frame_${String(g + 1).padStart(2, "0")}.png`, b.blob),
      );
      const u = await n.generateAsync({ type: "blob" });
      O(u, "sprite-frames.zip");
    };
  return a.jsxs(de, {
    children: [
      a.jsxs("div", {
        className: "flex flex-wrap gap-3 mb-6",
        children: [
          a.jsx(I, {
            variant: t === "combine" ? "default" : "outline",
            onClick: () => r("combine"),
            children: "Combine Frames → Sheet",
          }),
          a.jsx(I, {
            variant: t === "split" ? "default" : "outline",
            onClick: () => r("split"),
            children: "Split Sheet → Frames",
          }),
        ],
      }),
      t === "combine"
        ? a.jsxs("div", {
            className: "space-y-4",
            children: [
              a.jsx(Y, {
                accept: "image/*",
                multiple: !0,
                onFiles: ne,
                label: "Drop multiple frame images",
                description:
                  "Upload frames in order — they'll be arranged left-to-right, top-to-bottom",
                deferUsageLog: !0,
              }),
              o.length > 0 &&
                a.jsxs(a.Fragment, {
                  children: [
                    a.jsxs("p", {
                      className: "text-sm text-muted-foreground",
                      children: [o.length, " frames loaded"],
                    }),
                    a.jsxs("div", {
                      className: "flex flex-wrap items-center gap-3",
                      children: [
                        a.jsx(j, { className: "text-sm", children: "Columns" }),
                        a.jsx(M, {
                          "aria-label": "Columns",
                          className: "w-20",
                          value: e,
                          onChange: (n) => m(n.target.value),
                        }),
                        a.jsx(j, {
                          className: "text-sm",
                          children: "Padding (px)",
                        }),
                        a.jsx(M, {
                          "aria-label": "Padding (px)",
                          inputMode: "numeric",
                          className: "w-20",
                          value: S,
                          onChange: (n) => c(n.target.value),
                        }),
                        a.jsx(j, {
                          className: "text-sm",
                          children: "Extrude (px)",
                        }),
                        a.jsx(M, {
                          "aria-label": "Extrude (px)",
                          inputMode: "numeric",
                          className: "w-20",
                          value: f,
                          onChange: (n) => D(n.target.value),
                        }),
                        a.jsx(I, {
                          onClick: ie,
                          children: "Generate Sprite Sheet",
                        }),
                      ],
                    }),
                    a.jsxs("p", {
                      className: "text-xs text-muted-foreground",
                      children: [
                        "Padding leaves a gap between frames (up to ",
                        F,
                        "); extrude repeats each frame's edge pixels outwards (up to ",
                        W,
                        ") so game engines do not bleed neighbours into a sprite. Both 0 gives the plain grid.",
                      ],
                    }),
                    a.jsxs("div", {
                      className: "flex items-center gap-2",
                      children: [
                        a.jsx(ue, {
                          id: "sprite-json",
                          checked: k,
                          onCheckedChange: (n) => A(n === !0),
                        }),
                        a.jsx(j, {
                          htmlFor: "sprite-json",
                          className: "font-normal cursor-pointer",
                          children:
                            "Also offer a JSON atlas (each frame's x, y, width, height)",
                        }),
                      ],
                    }),
                  ],
                }),
              i &&
                a.jsxs(he, {
                  className: "p-4",
                  children: [
                    a.jsx("img", {
                      src: i,
                      alt: "Sprite sheet",
                      className: "max-w-full border rounded mb-3",
                    }),
                    a.jsx(q, {
                      onClick: () => {
                        p && O(p, "sprite-sheet.png");
                      },
                      label: "Download PNG",
                    }),
                    k &&
                      y &&
                      a.jsx(q, {
                        onClick: () => O(y, "sprite-sheet.json"),
                        label: "Download JSON atlas",
                      }),
                  ],
                }),
            ],
          })
        : a.jsxs("div", {
            className: "space-y-4",
            children: [
              a.jsx(Y, {
                accept: "image/*",
                gateAtDownload: !0,
                onFiles: re,
                label: "Drop a sprite sheet image",
                description: "We'll slice it into a grid of individual frames",
              }),
              B &&
                a.jsxs("div", {
                  className: "flex flex-wrap items-center gap-3",
                  children: [
                    a.jsx(j, { className: "text-sm", children: "Columns" }),
                    a.jsx(M, {
                      "aria-label": "Columns",
                      className: "w-20",
                      value: G,
                      onChange: (n) => Q(n.target.value),
                    }),
                    a.jsx(j, { className: "text-sm", children: "Rows" }),
                    a.jsx(M, {
                      "aria-label": "Rows",
                      className: "w-20",
                      value: H,
                      onChange: (n) => ee(n.target.value),
                    }),
                    a.jsx(j, {
                      className: "text-sm",
                      children: "Padding (px)",
                    }),
                    a.jsx(M, {
                      "aria-label": "Padding between frames (px)",
                      inputMode: "numeric",
                      className: "w-20",
                      value: Z,
                      onChange: (n) => te(n.target.value),
                    }),
                    a.jsx(I, { onClick: le, children: "Split into Frames" }),
                  ],
                }),
              E.length > 0 &&
                a.jsxs(a.Fragment, {
                  children: [
                    a.jsx("p", {
                      role: "status",
                      className: "text-sm font-medium",
                      "data-testid": "split-count",
                      children: _(E.length),
                    }),
                    !ae &&
                      a.jsx("p", {
                        className: "text-xs text-muted-foreground",
                        children:
                          "The sheet size does not divide evenly by these columns, rows and padding, so frames were cut at rounded sizes. Check the numbers if the frames look off.",
                      }),
                    a.jsx("div", {
                      className: "grid grid-cols-4 md:grid-cols-6 gap-2",
                      children: E.map((n, u) =>
                        a.jsx(
                          "img",
                          {
                            src: n.url,
                            alt: `Frame ${u + 1}`,
                            className: "border rounded w-full",
                          },
                          u,
                        ),
                      ),
                    }),
                    a.jsx(I, {
                      variant: "outline",
                      onClick: me,
                      children: "Download All as ZIP",
                    }),
                  ],
                }),
            ],
          }),
      a.jsx(pe, { whatIsIt: J.what, howToUse: J.how, tip: J.tip }),
    ],
  });
}
export { tt as default };
//# sourceMappingURL=SpriteSheetTool-CUkSyUBC.js.map
