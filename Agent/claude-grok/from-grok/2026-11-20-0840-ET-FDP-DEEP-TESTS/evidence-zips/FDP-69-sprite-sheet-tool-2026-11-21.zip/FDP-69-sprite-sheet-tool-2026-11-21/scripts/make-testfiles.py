# Generates the FDP-69 test PNGs into the current directory (Pillow). Same code as used on Nov 21.
from PIL import Image, ImageDraw
import colorsys
for i in range(8):
    r,g,b=[int(x*255) for x in colorsys.hsv_to_rgb(i/8,0.8,0.9)]
    im=Image.new('RGBA',(32,32),(0,0,0,0)); d=ImageDraw.Draw(im); d.rectangle([2,2,29,29],fill=(r,g,b,255)); d.text((10,10),str(i+1),fill=(0,0,0,255))
    im.save(f'walk_{i+1:02d}.png')
Image.new('RGBA',(48,20),(255,0,0,255)).save('wide.png'); Image.new('RGBA',(16,40),(0,0,255,255)).save('tall.png')
sh=Image.new('RGBA',(128,64),(0,0,0,0))
for i in range(8): sh.paste(Image.open(f'walk_{i+1:02d}.png'),((i%4)*32,(i//4)*32))
sh.save('sheet-4x2.png')
sp=Image.new('RGBA',(134,66),(255,0,255,255))
for i in range(8): sp.paste(Image.open(f'walk_{i+1:02d}.png'),((i%4)*34,(i//4)*34))
sp.save('sheet-4x2-pad2.png')
Image.new('RGBA',(130,65),(10,200,10,255)).save('sheet-odd-130x65.png')
open('not-image.png','w').write('not an image')
Image.new('RGB',(4096,4096),(30,60,90)).save('big-4096.png')
