import { j as e, r as f } from "./vendor-react-D01g8YgM.js";
import { T as ge, F as fe, d as se } from "./ToolPage-DwLoDncN.js";
import { e as $, B as X, N as xe, f as J } from "./index-B1CTyGtY.js";
import { S as Q } from "./slider-nIHsxb_2.js";
import {
  S as oe,
  a as ie,
  b as ne,
  c as re,
  d as he,
} from "./select-ic5yaeGw.js";
import { T as we } from "./ToolInfoSection-C0i6Zbwo.js";
import { a as be, c as Z } from "./decode-DrS85i4S.js";
import { s as Me } from "./jpegDpi-c8DPdZxl.js";
import { l as je, n as ye } from "./imageCheck-BWF-RE4r.js";
import { r as ve } from "./backgroundRemoval-D1VF3bhv.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./chevron-up-BDUcPssj.js";
import "./CollapsibleText-BCSBEG9-.js";
function Se(t, n) {
  const o = [
    { sw: 101.6, sh: 152.4 },
    { sw: 152.4, sh: 101.6 },
  ].map(({ sw: c, sh: d }) => {
    const p = Math.max(1, Math.floor((c + 0.01) / t)),
      h = Math.max(1, Math.floor((d + 0.01) / n));
    return { sw: c, sh: d, cols: p, rows: h, count: p * h };
  });
  return o[1].count > o[0].count ? o[1] : o[0];
}
function ke(t, n, o) {
  const c = [],
    d = [];
  for (let m = 0; m < o; m++) {
    let l = -1,
      F = -1,
      W = 0;
    for (let P = 0; P < n; P++)
      t[(m * n + P) * 4 + 3] > 128 && (l < 0 && (l = P), (F = P), W++);
    (c.push(W), d.push(l < 0 ? -1 : (l + F) / 2));
  }
  const p = Math.max(3, n * 0.02),
    h = c.findIndex((m) => m >= p);
  if (h < 0) return null;
  const v = Math.min(o - 1, h + Math.round(o * 0.12)),
    C = Math.max(...c.slice(h, v + 1));
  let T = -1;
  for (let m = v; m < o; m++)
    if (c[m] > C * 1.7) {
      T = m;
      break;
    }
  const N = d.slice(h, v + 1).filter((m) => m >= 0),
    q = N.length ? N.reduce((m, l) => m + l, 0) / N.length : n / 2,
    D = T > 0 ? (T - h) * 0.82 : null;
  return { top: h, centerX: q, headH: D };
}
function Pe(t, n, o, c, d) {
  const p = o / c,
    h = t / n > p ? n : t / p,
    v = h * p,
    C = Math.max(0.25, d / 100);
  return { w: v / C, h: h / C };
}
const Ce = 0.75;
function Ne(t, n) {
  const o = n > 0 ? t / n : 1;
  return { low: o < Ce, share: o };
}
const A = 300,
  H = (t, n = A) => Math.round((t / 25.4) * n),
  K = [
    {
      id: "us",
      label: "US Passport / Visa (2 x 2 in)",
      widthMm: 50.8,
      heightMm: 50.8,
      headMin: 0.5,
      headMax: 0.69,
      source:
        "https://travel.state.gov/content/travel/en/passports/how-apply/photos.html",
    },
    {
      id: "uk",
      label: "UK Passport (35 x 45 mm)",
      widthMm: 35,
      heightMm: 45,
      headMin: 0.64,
      headMax: 0.76,
      source: "https://www.gov.uk/photos-for-passports",
    },
    {
      id: "schengen",
      label: "EU / Schengen Visa (35 x 45 mm)",
      widthMm: 35,
      heightMm: 45,
      headMin: 0.7,
      headMax: 0.8,
      source:
        "https://home-affairs.ec.europa.eu/policies/schengen-borders-and-visa/visa-policy_en",
    },
    {
      id: "australia",
      label: "Australia Passport (35 x 45 mm)",
      widthMm: 35,
      heightMm: 45,
      headMin: 0.7,
      headMax: 0.8,
      source: "https://www.passports.gov.au/",
    },
    {
      id: "japan",
      label: "Japan Passport (35 x 45 mm)",
      widthMm: 35,
      heightMm: 45,
      headMin: 0.7,
      headMax: 0.8,
      source: "https://www.mofa.go.jp/",
    },
    {
      id: "canada",
      label: "Canada Passport (50 x 70 mm)",
      widthMm: 50,
      heightMm: 70,
      headMin: 0.44,
      headMax: 0.51,
      source:
        "https://www.canada.ca/en/immigration-refugees-citizenship/services/canadian-passports/photos.html",
    },
    {
      id: "india",
      label: "India Passport (51 x 51 mm)",
      widthMm: 51,
      heightMm: 51,
      headMin: 0.5,
      headMax: 0.69,
      source: "https://www.passportindia.gov.in/",
    },
    {
      id: "china",
      label: "China Visa (33 x 48 mm)",
      widthMm: 33,
      heightMm: 48,
      headMin: 0.58,
      headMax: 0.69,
      source: "https://www.visaforchina.cn/",
    },
    {
      id: "newzealand",
      label: "New Zealand Passport (35 x 45 mm)",
      widthMm: 35,
      heightMm: 45,
      headMin: 0.71,
      headMax: 0.8,
      source: "https://www.passports.govt.nz/",
      unverified: !0,
    },
    {
      id: "ireland",
      label: "Ireland Passport (35 x 45 mm)",
      widthMm: 35,
      heightMm: 45,
      headMin: 0.64,
      headMax: 0.76,
      source: "https://www.ireland.ie/en/dfa/overseas-travel/passports/",
      unverified: !0,
    },
    {
      id: "singapore",
      label: "Singapore Passport (35 x 45 mm)",
      widthMm: 35,
      heightMm: 45,
      headMin: 0.56,
      headMax: 0.78,
      source: "https://www.ica.gov.sg/",
      unverified: !0,
    },
    {
      id: "korea",
      label: "South Korea Passport (35 x 45 mm)",
      widthMm: 35,
      heightMm: 45,
      headMin: 0.71,
      headMax: 0.8,
      source: "https://www.passport.go.kr/",
      unverified: !0,
    },
  ];
function Ie(t, n = A) {
  const o = (c) => Math.round(c * 10) / 10;
  return {
    widthPx: H(t.widthMm, n),
    heightPx: H(t.heightMm, n),
    dpi: n,
    widthMm: o(t.widthMm),
    heightMm: o(t.heightMm),
  };
}
function ze({ preset: t, limitLabel: n }) {
  const o = Ie(t);
  return e.jsxs("div", {
    className: "mt-1 space-y-1 text-xs text-muted-foreground",
    "data-testid": "passport-spec",
    children: [
      e.jsxs("p", {
        "data-testid": "passport-pixels",
        children: [
          "Output: ",
          e.jsxs("strong", {
            className: "text-foreground",
            children: [o.widthPx, " × ", o.heightPx, " px"],
          }),
          " at ",
          o.dpi,
          " dpi (",
          o.widthMm,
          " × ",
          o.heightMm,
          " mm)",
          n ? `, JPEG ${n.toLowerCase()}` : "",
          ".",
        ],
      }),
      e.jsxs("p", {
        children: [
          "Head should fill ",
          Math.round(t.headMin * 100),
          "-",
          Math.round(t.headMax * 100),
          "% of the photo height.",
        ],
      }),
      t.unverified &&
        e.jsx("p", {
          "data-testid": "passport-unverified",
          role: "note",
          children:
            "Newly added: these numbers come from published specifications and have not yet been compared with the official page. Check them there before you submit.",
        }),
      e.jsxs("p", {
        children: [
          "Rules can change and this tool cannot check them for you:",
          " ",
          e.jsx("a", {
            href: t.source,
            target: "_blank",
            rel: "noopener noreferrer",
            className: "underline",
            children: "official page for this document",
          }),
          ". A correctly sized photo is not a guarantee of acceptance.",
        ],
      }),
    ],
  });
}
const Y = [
  { id: "none", label: "No limit", bytes: 0 },
  { id: "50", label: "Under 50 KB", bytes: 50 * 1e3 },
  { id: "100", label: "Under 100 KB", bytes: 100 * 1e3 },
  { id: "240", label: "Under 240 KB", bytes: 240 * 1e3 },
  { id: "500", label: "Under 500 KB", bytes: 500 * 1e3 },
];
async function Re(t, n) {
  if (!n) return Z(t, "image/jpeg", 0.95);
  let o = 0.2,
    c = 0.95,
    d = null;
  for (let p = 0; p < 8; p++) {
    const h = (o + c) / 2,
      v = await Z(t, "image/jpeg", h);
    v.size <= n ? ((d = v), (o = h)) : (c = h);
  }
  return d ?? (await Z(t, "image/jpeg", 0.2));
}
async function le(t) {
  return new Blob([Me(new Uint8Array(await t.arrayBuffer()), A)], {
    type: "image/jpeg",
  });
}
const ee = {
  what: "Resizes and crops a regular photo to standard passport/visa photo dimension templates for several countries, and can lay out multiple copies on a single printable sheet.",
  how: "Upload a photo taken against a plain background, select a country's standard size template from the preset list, adjust the framing, and download either a single photo or a print-ready sheet.",
  tip: `Take the original photo in even, natural light with a plain white or light-colored background — this tool handles the size and crop correctly, but it can't fix harsh shadows or a distracting background behind you.

Honestly: these are standard dimension templates, not an official compliance check — actual government photo requirements can include rules this tool doesn't verify (specific background color, facial expression, glasses/head covering rules, recency of the photo, and more), and requirements do change. Always check your destination country's current official passport/visa photo requirements directly before submitting, rather than assuming a correctly-sized photo is automatically an accepted one.`,
};
function mt() {
  const [t, n] = f.useState(null),
    [o, c] = f.useState(K[0]),
    [d, p] = f.useState([100]),
    [h, v] = f.useState([50]),
    [C, T] = f.useState([30]),
    [N, q] = f.useState(Y[0]),
    [D, m] = f.useState(!0),
    [l, F] = f.useState(""),
    [W, P] = f.useState(""),
    [te, O] = f.useState(""),
    ae = f.useRef(null),
    V = f.useRef(null),
    ce = f.useCallback((a) => {
      const s = a[0];
      if (s) {
        if (!je(s)) {
          O(ye(s.name));
          return;
        }
        (O(""),
          be(s)
            .then(({ canvas: i }) => {
              ((V.current = s), n(i), P(""), p([100]), v([50]), T([30]));
            })
            .catch((i) =>
              O(i?.message || `"${s.name}" could not be opened as an image.`),
            ));
      }
    }, []),
    x = H(o.widthMm),
    S = H(o.heightMm),
    _ = f.useCallback(
      (a, s, i) => {
        if (!t) return;
        ((a.width = s), (a.height = i));
        const w = a.getContext("2d");
        if (!w) return;
        ((w.fillStyle = "#fff"), w.fillRect(0, 0, s, i));
        const r = s / i,
          g = t.width / t.height,
          y = d[0] / 100;
        let b, M;
        g > r ? ((M = t.height), (b = M * r)) : ((b = t.width), (M = b / r));
        const u = b / y,
          I = M / y,
          k = t.width - u,
          j = t.height - I,
          E = (h[0] / 100) * k,
          B = (C[0] / 100) * j,
          z = Math.max(0, E),
          R = Math.max(0, B),
          U = Math.min(t.width, E + u),
          L = Math.min(t.height, B + I);
        U <= z ||
          L <= R ||
          ((w.imageSmoothingQuality = "high"),
          w.drawImage(
            t,
            z,
            R,
            U - z,
            L - R,
            ((z - E) / u) * s,
            ((R - B) / I) * i,
            ((U - z) / u) * s,
            ((L - R) / I) * i,
          ));
      },
      [t, d, h, C],
    );
  f.useEffect(() => {
    const a = ae.current;
    if (!a || (_(a, 300, Math.round(300 * (S / x))), !D || !t)) return;
    const s = a.getContext("2d"),
      i = a.width,
      w = a.height;
    (s.save(), (s.lineWidth = 2));
    const r = w * 0.1;
    for (const [g, y, b] of [
      [o.headMax, "rgba(220,38,38,0.9)", [6, 4]],
      [o.headMin, "rgba(22,163,74,0.95)", []],
    ]) {
      const M = w * g;
      ((s.strokeStyle = y),
        s.setLineDash([...b]),
        s.beginPath(),
        s.ellipse(i / 2, r + M / 2, M * 0.36, M / 2, 0, 0, Math.PI * 2),
        s.stroke());
    }
    (s.setLineDash([3, 3]),
      (s.strokeStyle = "rgba(59,130,246,0.8)"),
      s.beginPath(),
      s.moveTo(i / 2, 0),
      s.lineTo(i / 2, w),
      s.stroke(),
      s.restore());
  }, [_, S, x, D, o, t]);
  const G = t ? Pe(t.width, t.height, x, S, d[0]) : null,
    de = G ? Ne(G.w, x) : null,
    me = async () => {
      if (!(!V.current || l)) {
        F("Making the background white and fitting the head...");
        try {
          const a = await ve(V.current),
            s = await new Promise((b, M) => {
              const u = new Image();
              ((u.onload = () => b(u)), (u.onerror = M), (u.src = a));
            }),
            i = document.createElement("canvas");
          ((i.width = s.naturalWidth),
            (i.height = s.naturalHeight),
            i.getContext("2d").drawImage(s, 0, 0));
          const w = i
              .getContext("2d")
              .getImageData(0, 0, i.width, i.height).data,
            r = document.createElement("canvas");
          ((r.width = i.width), (r.height = i.height));
          const g = r.getContext("2d");
          ((g.fillStyle = "#fff"),
            g.fillRect(0, 0, r.width, r.height),
            g.drawImage(i, 0, 0));
          const y = ke(w, i.width, i.height);
          if ((n(r), y)) {
            const b = x / S,
              u = r.width / r.height > b ? r.height : r.width / b,
              I = u * b,
              k = (o.headMin + o.headMax) / 2;
            let j = 1;
            y.headH && (j = Math.min(4, Math.max(1, u / (y.headH / k))));
            const E = u / j,
              B = I / j,
              z = r.width - B,
              R = r.height - E,
              U = y.centerX - B / 2,
              L = y.top - E * 0.1;
            (p([Math.round(j * 100)]),
              v([z > 0 ? Math.max(0, Math.min(100, (U / z) * 100)) : 50]),
              T([R > 0 ? Math.max(0, Math.min(100, (L / R) * 100)) : 0]),
              P(
                y.headH
                  ? "Background made white and the head sized to the middle of the allowed range. This is an estimate: check the face against the two guide ovals and adjust the sliders."
                  : "Background made white and the head centred under the top margin. Head size could not be estimated: use Zoom so the face fits between the two guide ovals.",
              ));
          } else
            P(
              "Background made white. No person was found to position automatically - use the sliders.",
            );
        } catch (a) {
          J.error(
            "Could not make the background white: " +
              (a?.message || "unknown error"),
          );
        } finally {
          F("");
        }
      }
    },
    ue = async () => {
      if (l) return;
      const a = document.createElement("canvas");
      _(a, x, S);
      const s = await le(await Re(a, N.bytes));
      (se(s, `passport-photo-${o.id}.jpg`),
        J.success(`${x} x ${S} px, ${A} DPI, ${(s.size / 1e3).toFixed(0)} KB`));
    },
    pe = async () => {
      if (l) return;
      const a = Se(o.widthMm, o.heightMm),
        s = H(a.sw),
        i = H(a.sh),
        w = document.createElement("canvas");
      _(w, x, S);
      const r = document.createElement("canvas");
      ((r.width = s), (r.height = i));
      const g = r.getContext("2d");
      if (!g) return;
      ((g.fillStyle = "#fff"), g.fillRect(0, 0, s, i));
      const y = a.cols * x,
        b = a.rows * S,
        M = (s - y) / 2,
        u = (i - b) / 2;
      for (let k = 0; k < a.rows; k++)
        for (let j = 0; j < a.cols; j++)
          g.drawImage(w, M + j * x, u + k * S, x, S);
      ((g.strokeStyle = "#bbb"), (g.lineWidth = 1));
      for (let k = 0; k < a.rows; k++)
        for (let j = 0; j < a.cols; j++)
          g.strokeRect(M + j * x, u + k * S, x, S);
      const I = await le(await Z(r, "image/jpeg", 0.95));
      (se(I, `passport-photo-sheet-${o.id}.jpg`),
        J.success(
          `Print sheet ready: ${a.count} photos on a 4x6 in sheet (${a.sw > a.sh ? "landscape" : "portrait"})`,
        ));
    };
  return e.jsxs(ge, {
    children: [
      t
        ? e.jsxs("div", {
            className: "space-y-5",
            children: [
              e.jsxs("div", {
                children: [
                  e.jsx($, { children: "Photo Size" }),
                  e.jsxs(oe, {
                    disabled: !!l,
                    value: o.id,
                    onValueChange: (a) => c(K.find((s) => s.id === a) ?? K[0]),
                    children: [
                      e.jsx(ie, {
                        "aria-label": "Photo Size",
                        children: e.jsx(ne, {}),
                      }),
                      e.jsx(re, {
                        children: K.map((a) =>
                          e.jsx(he, { value: a.id, children: a.label }, a.id),
                        ),
                      }),
                    ],
                  }),
                  e.jsx(ze, {
                    preset: o,
                    limitLabel: N.bytes ? N.label : void 0,
                  }),
                ],
              }),
              e.jsx("div", {
                className: "flex justify-center",
                children: e.jsx("canvas", {
                  ref: ae,
                  className: "border rounded-lg max-w-[300px] w-full",
                }),
              }),
              e.jsxs("label", {
                className: "flex items-center gap-2 text-sm justify-center",
                children: [
                  e.jsx("input", {
                    type: "checkbox",
                    checked: D,
                    onChange: (a) => m(a.target.checked),
                  }),
                  " Show head-size guide (green = smallest head, red dashed = largest; not in the download)",
                ],
              }),
              e.jsx("div", {
                className: "flex justify-center",
                children: e.jsx(X, {
                  variant: "outline",
                  onClick: me,
                  disabled: !!l,
                  children: l
                    ? "Working…"
                    : "Make background white + auto-fit head",
                }),
              }),
              e.jsx("p", {
                role: "status",
                "aria-live": "polite",
                className: "text-xs text-center text-muted-foreground",
                "data-testid": "passport-busy",
                children: l
                  ? `Working… ${l} Download is paused until it finishes.`
                  : "",
              }),
              de?.low &&
                e.jsxs(xe, {
                  role: "alert",
                  className: "text-xs text-center",
                  testId: "passport-lowres",
                  children: [
                    "Low resolution: the part of your photo that fills the frame is only about ",
                    Math.round(G.w),
                    " px wide, and this size needs ",
                    x,
                    " px for a sharp ",
                    A,
                    " dpi print. Passport offices reject blurry photos. Use a larger original photo.",
                  ],
                }),
              W &&
                e.jsx("p", {
                  className: "text-xs text-muted-foreground text-center",
                  children: W,
                }),
              e.jsxs("div", {
                children: [
                  e.jsxs($, { children: ["Zoom: ", d[0], "%"] }),
                  e.jsx(Q, {
                    "aria-label": "Zoom",
                    value: d,
                    onValueChange: p,
                    min: 25,
                    max: 400,
                    step: 1,
                  }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx($, { children: "Position (horizontal)" }),
                  e.jsx(Q, {
                    "aria-label": "Position (horizontal)",
                    value: h,
                    onValueChange: v,
                    min: 0,
                    max: 100,
                    step: 1,
                  }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx($, { children: "Position (vertical)" }),
                  e.jsx(Q, {
                    "aria-label": "Position (vertical)",
                    value: C,
                    onValueChange: T,
                    min: 0,
                    max: 100,
                    step: 1,
                  }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx($, {
                    children: "File size limit (for online applications)",
                  }),
                  e.jsxs(oe, {
                    value: N.id,
                    onValueChange: (a) => q(Y.find((s) => s.id === a) ?? Y[0]),
                    children: [
                      e.jsx(ie, {
                        className: "w-48",
                        "aria-label": "File size limit",
                        children: e.jsx(ne, {}),
                      }),
                      e.jsx(re, {
                        children: Y.map((a) =>
                          e.jsx(he, { value: a.id, children: a.label }, a.id),
                        ),
                      }),
                    ],
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "flex gap-3",
                children: [
                  e.jsx(X, {
                    onClick: ue,
                    variant: "outline",
                    className: "flex-1",
                    disabled: !!l,
                    children: "Download Single Photo",
                  }),
                  e.jsx(X, {
                    onClick: pe,
                    className: "flex-1",
                    disabled: !!l,
                    children: 'Download Print Sheet (4x6")',
                  }),
                ],
              }),
              e.jsx(X, {
                variant: "ghost",
                disabled: !!l,
                onClick: () => {
                  (n(null), (V.current = null), O(""));
                },
                className: "w-full",
                children: "Upload Different Photo",
              }),
            ],
          })
        : e.jsxs(e.Fragment, {
            children: [
              e.jsx(fe, {
                gateAtDownload: !0,
                accept: "image/*",
                onFiles: ce,
                label: "Drop a photo to create passport/visa photos",
                description:
                  "Face forward, plain background works best - processed entirely in your browser",
              }),
              te &&
                e.jsx("p", {
                  role: "alert",
                  className: "text-xs text-destructive mt-2",
                  "data-testid": "passport-file-error",
                  children: te,
                }),
            ],
          }),
      e.jsx(we, { whatIsIt: ee.what, howToUse: ee.how, tip: ee.tip }),
    ],
  });
}
export { mt as default };
//# sourceMappingURL=PassportPhoto-DjC3QAJh.js.map
