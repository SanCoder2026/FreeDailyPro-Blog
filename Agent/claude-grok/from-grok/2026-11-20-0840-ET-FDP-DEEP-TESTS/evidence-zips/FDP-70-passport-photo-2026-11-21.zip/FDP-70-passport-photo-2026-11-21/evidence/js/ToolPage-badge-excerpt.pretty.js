            ],
            Border: [0, 0, 0],
            Contents: d.of(at),
            A: { Type: "Action", S: "URI", URI: d.of(sn) },
          }),
          K = $.register(F),
          Y = m.node.lookup(i.of("Annots"));
        Y instanceof h ? Y.push(K) : m.node.set(i.of("Annots"), $.obj([K]));
      } catch {}
    }
  }
  const y = await f.save({ useObjectStreams: !0 });
  return new Blob([y], { type: "application/pdf" });
}
async function Qo(e, t, n = Ne()) {
  if (typeof document > "u" || typeof createImageBitmap > "u") return e;
  const a = await createImageBitmap(e),
    { width: i, height: d } = a;
  if (i * d > nn || i < 160 || d < 100) return (a.close?.(), e);
  const h = document.createElement("canvas");
  ((h.width = i), (h.height = d));
  const l = h.getContext("2d");
  if (!l) return (a.close?.(), e);
  (l.drawImage(a, 0, 0), a.close?.());
  const c = rn.test(n),
    u = c
      ? Math.max(16, Math.round(Math.min(i, d) * 0.04))
      : Math.max(22, Math.round(Math.min(i, d) * 0.055)),
    p =
      "system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
    g = Vt(u, (T, A) => ((l.font = `700 ${A}px ${p}`), l.measureText(T).width)),
    b = Math.round(u * 0.6),
    y = i - g.w - b,
    m = c ? [d - u - b] : [b, d - u - b],
    w = u / 2;
  for (const T of m) {
    const A = (N, C = 0) => T + u - N - C;
    ((l.globalAlpha = 0.94),
      (l.fillStyle = Ue),
      l.beginPath(),
      l.moveTo(y + w, T),
      l.arcTo(y + g.w, T, y + g.w, T + u, w),
      l.arcTo(y + g.w, T + u, y, T + u, w),
      l.arcTo(y, T + u, y, T, w),
      l.arcTo(y, T, y + g.w, T, w),
      l.closePath(),
      l.fill(),
      (l.globalAlpha = 1));
    for (const N of g.rects)
      ((l.fillStyle = N.color), l.fillRect(y + N.x, A(N.y, N.h), N.w, N.h));
    ((l.fillStyle = g.dot.color),
      l.beginPath(),
      l.arc(y + g.dot.cx, A(g.dot.cy), g.dot.r, 0, Math.PI * 2),
      l.fill(),
      (l.textBaseline = "alphabetic"));
    for (const N of g.texts)
      ((l.font = `700 ${N.size}px ${p}`),
        (l.fillStyle = N.color),
        l.fillText(N.text, y + N.x, A(N.y)));
  }
  const I =
    /\.png$/i.test(t) || e.type === "image/png"
      ? "image/png"
      : e.type === "image/webp"
        ? "image/webp"
        : "image/jpeg";
  return (await new Promise((T) => h.toBlob(T, I, 0.92))) ?? e;
}
function bl(e = Ne()) {
  return Bt() && !jt.test(e);
}
