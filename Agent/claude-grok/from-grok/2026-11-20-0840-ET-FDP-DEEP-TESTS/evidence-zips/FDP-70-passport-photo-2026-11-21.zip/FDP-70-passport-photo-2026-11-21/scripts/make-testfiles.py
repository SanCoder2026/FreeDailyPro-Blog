#!/usr/bin/env python3
"""FDP-70 Passport Photo Maker test files. Needs Pillow and curl.
Downloads two openly licensed portraits from Wikimedia Commons and derives the rest.
  fdr-pd.jpg      Franklin D. Roosevelt passport photograph (public domain, NARA via DPLA), 1872x2489
  pereira-ogl.jpg Alvaro Santos Pereira 2013 (passport ratio), UK Open Government Licence v1.0, 1073x1381
"""
import subprocess
from PIL import Image, ImageDraw
UA = 'FDP-QA/1.0'
subprocess.run(['curl', '-s', '-A', UA, '-o', 'fdr-pd.jpg', 'https://upload.wikimedia.org/wikipedia/commons/c/cf/Franklin_D._Roosevelt%27s_Passport_Photograph_-_DPLA_-_e053829d561ad42cefd53ee457a6b754.jpg'], check=True)
subprocess.run(['curl', '-s', '-A', UA, '-o', 'pereira-ogl.jpg', 'https://upload.wikimedia.org/wikipedia/commons/a/a9/%C3%81lvaro_Santos_Pereira_2013_%28passport_ratio%29.jpg'], check=True)
im = Image.open('fdr-pd.jpg').convert('RGB')
im.thumbnail((1400, 1400)); im.save('fdr-1400.jpg', quality=92)                      # 1052x1400 main test photo
bg = Image.new('RGB', (2000, 1500)); d = ImageDraw.Draw(bg)                            # busy striped landscape background
for i in range(0, 2000, 40): d.rectangle([i, 0, i + 20, 1500], fill=((i * 7) % 256, (i * 3) % 256, (255 - i) % 256))
p = im.resize((int(im.width * 1400 / im.height), 1400)); bg.paste(p, (600, 100)); bg.save('fdr-busy-landscape.jpg', quality=90)
Image.new('RGB', (4032, 3024), (200, 200, 200)).save('phone-4032x3024-plain.jpg', quality=90)  # no person (auto-fit "no person")
Image.new('RGB', (300, 200), (180, 180, 180)).save('tiny-300x200.jpg')                        # low-resolution warning
open('not-image.jpg', 'w').write('nope')                                                         # invalid file
