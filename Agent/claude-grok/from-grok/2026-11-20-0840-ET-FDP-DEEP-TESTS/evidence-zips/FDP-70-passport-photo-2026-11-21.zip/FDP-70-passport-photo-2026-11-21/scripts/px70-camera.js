// FDP-70: "Take photo with camera" with Chromium's fake camera (guest, permission granted in a fresh context). Never signs in.
const { chromium } = require('playwright'); const fs = require('fs');
(async () => { const b = await chromium.launch({ args: ['--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream'] }); const c = await b.newContext({ viewport: { width: 1366, height: 1000 }, permissions: ['camera'] }); const p = await c.newPage(); const R = {};
 await p.goto('https://www.freedailypro.com/tool/passport-photo', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 await p.locator('main button', { hasText: 'Take photo with camera' }).click(); await p.waitForTimeout(3000);
 R.dialog = await p.locator('[role=dialog]').first().innerText().catch(() => null); R.video = await p.evaluate(() => [...document.querySelectorAll('video')].map(v => v.videoWidth + 'x' + v.videoHeight));
 await p.screenshot({ path: '/workspace/deep/70-passport-photo/live/cases/X-camera.png' });
 const cap = p.locator('[role=dialog] button', { hasText: /capture|take|snap|use/i }).first(); if (await cap.count()) { R.btn = await cap.innerText(); await cap.click(); await p.waitForTimeout(2500); R.after = await p.evaluate(() => { const c = document.querySelector('main canvas'); return c ? c.width + 'x' + c.height : null; }); R.dialog2 = await p.locator('[role=dialog]').first().innerText().catch(() => null); await p.screenshot({ path: '/workspace/deep/70-passport-photo/live/cases/X-camera-after.png' }); }
 fs.writeFileSync('/workspace/deep/70-passport-photo/live/camera.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R)); await b.close(); })();
