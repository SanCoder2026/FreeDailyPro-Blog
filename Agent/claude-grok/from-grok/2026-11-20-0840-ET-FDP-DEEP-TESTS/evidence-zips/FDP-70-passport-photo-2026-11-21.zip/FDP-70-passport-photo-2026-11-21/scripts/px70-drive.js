// FDP-70: "Open from Google Drive" (guest): record the popup URL (redacted) and close it. Never signs in.
const { chromium } = require('playwright'); const fs = require('fs');
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 1000 } }); const p = await c.newPage(); await p.goto('https://www.freedailypro.com/tool/passport-photo', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 const pop = c.waitForEvent('page', { timeout: 8000 }).catch(() => null); await p.locator('main button', { hasText: 'Open from Google Drive' }).click(); const pg = await pop; await p.waitForTimeout(2000);
 const u = pg ? pg.url().replace(/(client_id|opparams|dsh)=[^&]*/g, '$1=REDACTED').slice(0, 160) : null; await p.screenshot({ path: '/workspace/deep/70-passport-photo/live/cases/X-open-drive.png' }); if (pg) await pg.close();
 fs.writeFileSync('/workspace/deep/70-passport-photo/live/drive.json', JSON.stringify({ popup: u }, null, 1)); console.log(u); await b.close(); })();
