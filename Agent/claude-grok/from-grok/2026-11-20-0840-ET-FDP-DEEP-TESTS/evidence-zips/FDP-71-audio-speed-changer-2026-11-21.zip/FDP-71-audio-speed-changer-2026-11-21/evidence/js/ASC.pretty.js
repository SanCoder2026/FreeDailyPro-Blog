import { r as o, j as e } from "./vendor-react-D01g8YgM.js";
import { T as Y, F as Z, R as G, D as H } from "./ToolPage-DwLoDncN.js";
import { e as P, B as h, f as J } from "./index-B1CTyGtY.js";
import { S as L } from "./slider-nIHsxb_2.js";
import { T as K } from "./ToolInfoSection-C0i6Zbwo.js";
import { u as Q } from "./UsageAndUpgradeStrip-B1CY210m.js";
import {
  checkFileSize as W,
  resetFFmpegEngine as T,
  loadFFmpeg as X,
  fetchFile as ee,
  ffmpegOutputToBlob as te,
} from "./ffmpegEngine-DH91Xnxx.js";
import { n as A, C as se, b as oe } from "./operations-DLxdtd8A.js";
import { f as ae } from "./containers-CEblVBL8.js";
import { F as ie, A as re, s as ne } from "./uiHelpers-DY6mT0h-.js";
import { T as le } from "./ToolSteps-DWea1Jiy.js";
import { u as ce } from "./useDownloadedResult-C1FfMpBH.js";
import { a as ue } from "./timeFormat-Va_Xba1f.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./sniffRate-BQP3kobv.js";
import "./progress-Y72GQ7li.js";
import "./square-DmBnvOHU.js";
const w = {
    what: 'Speeds up or slows down an audio file without changing its pitch — unlike simply playing a file faster (which raises pitch, the "chipmunk" effect), this keeps voices and music sounding natural at a different speed. Runs entirely in your browser — the audio never leaves your device.',
    how: "Upload your audio file, choose a speed (0.5x to 4x) and click Change Speed. You can listen to the result right on the page, with its exact length, before downloading; the trial use is only taken when you download. Pitch stays the same unless you also move the Pitch slider (up to an octave either way), which is separate from speed.",
    tip: "This works well up to about 2x or down to about 0.5x — pushed further than that, audio can start to sound artifacted or robotic since the underlying technique has to stretch or compress the waveform more aggressively while trying to preserve pitch.",
  },
  j = ue,
  de = (t) =>
    t === 0
      ? "unchanged"
      : `${t > 0 ? "+" : ""}${t} semitone${Math.abs(t) === 1 ? "" : "s"}`,
  me = [0.5, 0.75, 1, 1.25, 1.5, 2, 2.5, 3, 4];
function We() {
  const [t, f] = o.useState(null),
    [n, b] = o.useState([1]),
    [x, S] = o.useState(0),
    [i, v] = o.useState([0]),
    [y, R] = o.useState(null),
    [l, k] = o.useState(!1),
    [D, F] = o.useState(0),
    [E, p] = o.useState(""),
    [c, u] = o.useState(null),
    { isPro: N, isLoading: O, isAdmin: U } = Q(),
    m = o.useRef(null),
    $ = o.useRef(null),
    _ = o.useCallback((s) => {
      const r = s[0];
      if (!r) return;
      (f(r), u(null), S(0), R(null), v([0]));
      const d = URL.createObjectURL(r),
        a = new Audio();
      ((a.preload = "metadata"),
        (a.onloadedmetadata = () => {
          (Number.isFinite(a.duration) && S(a.duration),
            URL.revokeObjectURL(d));
        }),
        (a.onerror = () => URL.revokeObjectURL(d)),
        (a.src = d));
    }, []),
    z = ce(c),
    g = t ? W([t], N || O, U) : null,
    I = () => {
      ($.current?.abort(), m.current && T(m.current));
    },
    B = async () => {
      if (!t) return;
      (k(!0), F(0));
      const s = new AbortController();
      $.current = s;
      try {
        p("Loading audio engine...");
        const r = await X((q) => p(q));
        ((m.current = r), p("Reading audio file..."));
        const d = t.name.match(/\.([^.]+)$/)?.[1] || "mp3";
        await r.writeFile(`input.${d}`, await ee(t));
        const a = A(t.name);
        p(`Adjusting speed to ${n[0]}x...`);
        const M = i[0]
            ? { semitones: i[0], sampleRate: (await ae(t)) ?? 48e3 }
            : void 0,
          V = await se(
            r,
            `input.${d}`,
            `output.${a.value}`,
            n[0],
            F,
            s.signal,
            a.codec,
            M,
          ),
          C = te(V, a.mime);
        (u(C), oe(C).then(R), J.success("Speed adjusted!"));
      } catch (r) {
        ne(r);
      } finally {
        (m.current && T(m.current), k(!1));
      }
    };
  return e.jsxs(Y, {
    children: [
      e.jsx(le, {
        toolId: "audio-speed-changer",
        state: {
          hasFile: !!t,
          speedSet: n[0] !== 1 || i[0] !== 0,
          processing: l,
          resultReady: !!c && !l,
          downloaded: z,
        },
      }),
      t
        ? e.jsxs("div", {
            className: "space-y-4",
            children: [
              e.jsx("div", {
                className: "p-4 rounded-lg border bg-card",
                children: e.jsx("p", {
                  className: "text-sm font-medium",
                  children: t.name,
                }),
              }),
              g && e.jsx(ie, { check: g, isPro: N }),
              e.jsxs("div", {
                className: "space-y-2 max-w-sm",
                children: [
                  e.jsxs(P, {
                    children: [
                      "Speed: ",
                      Math.round(n[0] * 100) / 100,
                      "x",
                      x ? ` (${j(x)} → ${j(x / n[0])})` : "",
                    ],
                  }),
                  e.jsx(L, {
                    "aria-label": "Playback speed",
                    value: n,
                    onValueChange: (s) => {
                      (b(s), u(null));
                    },
                    min: 0.5,
                    max: 4,
                    step: 0.05,
                  }),
                  e.jsx("div", {
                    className: "flex flex-wrap gap-1.5",
                    children: me.map((s) =>
                      e.jsxs(
                        h,
                        {
                          size: "sm",
                          variant: "ghost",
                          className: "h-7 text-xs",
                          onClick: () => {
                            (b([s]), u(null));
                          },
                          children: [s, "x"],
                        },
                        s,
                      ),
                    ),
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "space-y-2 max-w-sm",
                children: [
                  e.jsxs(P, { children: ["Pitch: ", de(i[0])] }),
                  e.jsx(L, {
                    value: i,
                    onValueChange: (s) => {
                      (v(s), u(null));
                    },
                    min: -12,
                    max: 12,
                    step: 1,
                    "aria-label": "Pitch in semitones",
                  }),
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground",
                    children:
                      "Leave this in the middle to keep the voice or notes as they are; it is separate from speed.",
                  }),
                ],
              }),
              l && e.jsx(re, { progress: D, statusMessage: E, onStop: I }),
              c &&
                e.jsxs("div", {
                  className: "space-y-1",
                  "data-testid": "speed-result",
                  children: [
                    e.jsxs("p", {
                      className: "text-sm font-medium",
                      children: [
                        "Listen to the result",
                        y ? ` (${j(y)} long)` : "",
                      ],
                    }),
                    e.jsx("p", {
                      className: "text-xs text-muted-foreground",
                      children:
                        "Playing it here costs nothing; a trial use is only taken when you download.",
                    }),
                    e.jsx(G, { blob: c }),
                  ],
                }),
              e.jsx("div", {
                className: "flex gap-3",
                children: c
                  ? e.jsxs(e.Fragment, {
                      children: [
                        e.jsx(H, {
                          blob: c,
                          fileName: `speed_${n[0]}x${i[0] ? `_pitch${i[0] > 0 ? "+" : ""}${i[0]}` : ""}_${t.name.replace(/\.[^.]+$/, `.${A(t.name).value}`)}`,
                        }),
                        e.jsx(h, {
                          variant: "outline",
                          onClick: () => {
                            (f(null), u(null));
                          },
                          children: "New",
                        }),
                      ],
                    })
                  : e.jsxs(e.Fragment, {
                      children: [
                        e.jsx(h, {
                          onClick: B,
                          disabled:
                            l ||
                            g?.severity !== "ok" ||
                            (n[0] === 1 && i[0] === 0),
                          children: l ? "Processing..." : "Change Speed",
                        }),
                        e.jsx(h, {
                          variant: "outline",
                          onClick: () => f(null),
                          disabled: l,
                          children: "Reset",
                        }),
                      ],
                    }),
              }),
            ],
          })
        : e.jsx(Z, {
            gateAtDownload: !0,
            accept: "audio/*",
            maxSize: 500,
            onFiles: _,
            label: "Drop an audio file",
            description: "Change playback speed without altering pitch",
          }),
      e.jsx(K, { whatIsIt: w.what, howToUse: w.how, tip: w.tip }),
    ],
  });
}
export { We as default };
//# sourceMappingURL=AudioSpeedChanger-Dgf8DX20.js.map
