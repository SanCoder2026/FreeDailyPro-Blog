        j(!1);
      }
    };
  return a.startsWith("image/")
    ? o.jsx("div", {
        className: "rounded-lg border bg-muted/30 p-2",
        children: o.jsx("img", {
          src: d || void 0,
          alt: "Result preview",
          className: "max-w-full max-h-96 mx-auto rounded object-contain",
        }),
      })
    : a.startsWith("audio/")
      ? l
        ? o.jsx("audio", {
            src: d || void 0,
            controls: !0,
            preload: "metadata",
            className: "w-full",
          })
        : o.jsxs(G, {
            type: "button",
            variant: "outline",
            size: "sm",
            className: "gap-2",
            onClick: () => c(!0),
