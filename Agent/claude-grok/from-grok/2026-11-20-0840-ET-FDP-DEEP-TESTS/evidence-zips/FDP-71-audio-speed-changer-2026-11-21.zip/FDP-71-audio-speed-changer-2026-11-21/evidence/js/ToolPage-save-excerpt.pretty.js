  const n = URL.createObjectURL(e),
    a = document.createElement("a");
  ((a.href = n),
    (a.download = t),
    document.body.appendChild(a),
    a.click(),
    document.body.removeChild(a),
    setTimeout(() => URL.revokeObjectURL(n), 6e4),
    window.dispatchEvent(
      new CustomEvent("freedailypro:download-complete", {
        detail: { filename: t },
      }),
    ));
}
function vt(e, t, n) {
  (n?.free ? (a) => a() : Sa)(() => {
    if (!n?.marked && (Re(e.type, t) || st(e, t))) {
      nt(e, t).then(
        (a) => Nt(a, t),
        () => {
          M.error("Couldn't prepare the file for download. Please try again.");
        },
      );
      return;
    }
    Nt(e, t);
  });
}
function Al({ blob: e, mimeType: t, sizeWarnMB: n = 25 }) {
