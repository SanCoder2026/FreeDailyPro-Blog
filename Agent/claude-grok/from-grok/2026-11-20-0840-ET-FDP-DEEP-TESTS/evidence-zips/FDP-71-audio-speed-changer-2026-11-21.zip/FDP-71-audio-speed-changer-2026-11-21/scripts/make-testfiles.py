#!/usr/bin/env python3
"""FDP-71 Audio Speed Changer test files (needs numpy and ffmpeg). Run inside testfiles/.
tone-10s-44k.wav : 10.000 s, 44.1 kHz mono 16-bit: 440 Hz sine with a 1 kHz 50 ms click every 1.000 s (tempo marker).
Derived: .mp3 (192k), .flac, .ogg (vorbis), .m4a (aac), 48k stereo wav, a 5 s mp4 with picture + audio, a non-audio file.
"""
import numpy as np, wave, subprocess
sr = 44100; t = np.arange(int(sr * 10)) / sr
x = 0.4 * np.sin(2 * np.pi * 440 * t)
for k in range(10):
    i = int(k * sr); n = int(0.05 * sr); x[i:i + n] += 0.4 * np.sin(2 * np.pi * 1000 * t[:n])
pcm = (np.clip(x, -1, 1) * 32767).astype('<i2')
with wave.open('tone-10s-44k.wav', 'wb') as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr); w.writeframes(pcm.tobytes())
ff = lambda *a: subprocess.run(['ffmpeg', '-loglevel', 'error', '-y', '-i', 'tone-10s-44k.wav', *a], check=True)
ff('-b:a', '192k', 'tone-10s.mp3'); ff('tone-10s.flac'); ff('-c:a', 'libvorbis', 'tone-10s.ogg'); ff('-c:a', 'aac', '-b:a', '160k', 'tone-10s.m4a')
ff('-ar', '48000', '-ac', '2', 'tone-10s-48k-stereo.wav')
subprocess.run(['ffmpeg', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'testsrc=size=320x240:rate=25', '-i', 'tone-10s-44k.wav', '-t', '5', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-shortest', 'video-5s.mp4'], check=True)
open('not-audio.mp3', 'w').write('this is not audio\n')
