# FDP-71: analyse audio outputs: container/codec/sample rate/channels/duration (ffprobe), dominant frequency, click spacing (tempo marker).
import sys, json, subprocess, numpy as np
def an(f):
    pr = json.loads(subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=format_name,duration:stream=codec_type,codec_name,sample_rate,channels', '-of', 'json', f], capture_output=True, text=True).stdout or '{}')
    raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', f, '-ac', '1', '-ar', '44100', '-f', 'f32le', '-'], capture_output=True).stdout
    x = np.frombuffer(raw, '<f4'); sr = 44100
    r = {'file': f.split('/')[-1], 'probe': pr, 'decoded_s': round(len(x) / sr, 3)}
    if len(x) > sr:
        m = x[len(x) // 4: len(x) // 4 + sr]; sp = np.abs(np.fft.rfft(m * np.hanning(len(m)))); r['dominant_hz'] = round(float(np.argmax(sp[20:]) + 20) * sr / len(m), 1)
        # click marker: band energy around the shifted click; use high-pass by differencing, 10 ms frames
        d = np.diff(x); fr = int(0.01 * sr); e = np.array([np.sum(d[i:i + fr] ** 2) for i in range(0, len(d) - fr, fr)])
        thr = e.mean() + 2 * e.std(); on = [i for i in range(1, len(e)) if e[i] > thr and e[i - 1] <= thr]
        t = [round(i * 0.01, 2) for i in on]; r['clicks'] = t[:12]
        if len(t) > 2: r['click_spacing_s'] = round(float(np.median(np.diff(t))), 3)
    return r
print(json.dumps([an(f) for f in sys.argv[1:]], indent=1))
