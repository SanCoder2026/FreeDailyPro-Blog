// FDP-71 Audio Speed Changer (Professional), guest. Usage: node px71-live.js <zero|left|cases|quickbuy> [engine]   env TRIES, SUF
// zero: at the cap: upload, Change Speed (result player), read the <audio> attributes, fetch the player's blob in the page (stands in for the player's own
//       Download menu / "Save audio as"; test only), press Download -> dialog?
// left: with uses left: downloads across formats, presets, pitch, New file, reload; records usage POSTs and counter; player blob vs download md5.
// Never signs in, never types an email or card, never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/71-audio-speed-changer/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const TOOL = 'https://www.freedailypro.com/tool/audio-speed-changer';
const mode = process.argv[2] || 'zero'; const eng = process.argv[3] || 'chromium'; const sfx = (eng === 'chromium' ? '' : '-' + eng) + (process.env.SUF || '');
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').replace(/dev[:%][^&"]*/g, 'dev:REDACTED').slice(0, 160);
fs.mkdirSync(OUT + 'cases', { recursive: true }); fs.mkdirSync(OUT + 'downloads', { recursive: true });
const md5 = f => cp.execSync(`md5sum "${f}"`).toString().slice(0, 12);
const AN = f => { try { const r = JSON.parse(cp.execSync(`/workspace/deep/venv-pdf/bin/python /workspace/deep/tools-env/px71-analyze.py "${f}"`).toString())[0]; const s = (r.probe.streams || []).map(x => x.codec_name + '/' + (x.sample_rate || '') + '/' + (x.channels || '')).join(','); return { fmt: (r.probe.format || {}).format_name, streams: s, dur: r.decoded_s, hz: r.dominant_hz, click: r.click_spacing_s }; } catch (e) { return 'ERR'; } };
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p, net = [], eng25 = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 1000 }, locale: 'en-US', acceptDownloads: true }); p = await c.newPage(); p.setDefaultTimeout(15000); net = []; eng25 = [];
  await p.addInitScript(() => { window.__t = []; const seen = new WeakSet(); setInterval(() => { document.querySelectorAll('[data-sonner-toast]').forEach(n => { if (!seen.has(n)) { seen.add(n); window.__t.push((n.innerText || '').trim()); } }); }, 120); });
  p.on('request', r => { const u = r.url(); if (r.method() === 'POST' && /freedailypro\.com\/api/.test(u) && !/insight\.hit|funnel\.hit/.test(u)) net.push({ t: now(), u: red(u) }); });
  p.on('response', r => { const u = r.url(); if (/ffmpeg|\.wasm/.test(u)) eng25.push({ u: u.slice(0, 120), s: r.status(), len: r.headers()['content-length'] || null }); });
  await p.goto(TOOL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 400) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(250); } };
 const toasts = () => p.evaluate(() => { const t = window.__t.slice(); window.__t.length = 0; return t; });
 const shot = n => p.screenshot({ path: OUT + 'cases/' + n + sfx + '.png' });
 const btn = t => p.locator('main button', { hasText: t }).first();
 const strip = () => p.evaluate(() => (document.querySelector('main').innerText.match(/Trial[^\n]*/) || [null])[0]);
 const label = () => p.evaluate(() => (document.querySelector('main').innerText.match(/Speed: [^\n]*/) || [null])[0]);
 const upload = async f => { const np = net.length; const before = await used(); await p.locator('main input[type=file]').first().setInputFiles(TF + f); await p.waitForTimeout(2500); const d = await dialog(); if (d) { await shot('upload-dialog-' + Date.now() % 100000); await esc(); } return { before, after: await used(), posts: net.slice(np).length, dialog: d, label: await label(), notice: await p.evaluate(() => [...document.querySelectorAll('main [role=alert], main .text-destructive')].map(n => n.innerText.trim()).filter(Boolean).slice(0, 3)) }; };
 const preset = async s => { await p.locator('main button', { hasText: new RegExp('^' + s.replace('.', '\\.') + 'x$') }).first().click(); await p.waitForTimeout(300); };
 const pitch = async n => { const s = p.locator('main [role=slider][aria-label="Pitch in semitones"]'); await s.focus(); await p.keyboard.press('Home'); for (let i = 0; i < 12 + n; i++) await p.keyboard.press('ArrowRight'); await p.waitForTimeout(300); return s.getAttribute('aria-valuenow'); };
 const change = async (wait = 240000) => { const np = net.length; const before = await used(); await toasts(); const t0 = Date.now(); const dis = await btn('Change Speed').isDisabled(); if (dis) return { disabled: true, label: await label() }; await btn('Change Speed').click(); await p.locator('[data-testid=speed-result]').waitFor({ timeout: wait }).catch(() => null); await p.waitForTimeout(1500); const d = await dialog(); if (d) { await shot('change-dialog-' + Date.now() % 100000); await esc(); } const res = await p.locator('[data-testid=speed-result]').innerText().catch(() => null); return { before, after: await used(), posts: net.slice(np).map(x => x.u.slice(0, 60)), ms: Date.now() - t0, dialog: d, toasts: await toasts(), result: res ? res.replace(/\s*\n\s*/g, ' | ') : null, label: await label() }; };
 const audioAttrs = () => p.evaluate(() => { const a = document.querySelector('[data-testid=speed-result] audio'); if (!a) return null; const ev = new MouseEvent('contextmenu', { bubbles: true, cancelable: true }); const ok = a.dispatchEvent(ev); return { controls: a.controls, controlsList: a.getAttribute('controlsList'), srcBlob: a.src.startsWith('blob:'), contextMenuAllowed: ok, duration: a.duration }; });
 const grab = async pre => { const r = await p.evaluate(async () => { const a = document.querySelector('[data-testid=speed-result] audio'); if (!a) return null; const res = await fetch(a.src); const buf = new Uint8Array(await res.arrayBuffer()); let s = ''; for (let k = 0; k < buf.length; k += 0x8000) s += String.fromCharCode.apply(null, buf.subarray(k, k + 0x8000)); return [res.headers.get('content-type'), btoa(s)]; }); if (!r) return null; const ext = (r[0] || '').includes('wav') ? 'wav' : (r[0] || '').includes('flac') ? 'flac' : (r[0] || '').includes('ogg') ? 'ogg' : (r[0] || '').includes('mp4') || (r[0] || '').includes('m4a') ? 'm4a' : 'mp3'; const f = OUT + 'downloads/' + pre + (process.env.SUF || '') + 'player-blob.' + ext; fs.writeFileSync(f, Buffer.from(r[1], 'base64')); return { type: r[0], file: f.split('/').pop(), bytes: fs.statSync(f).size, md5: md5(f), an: AN(f) }; };
 const download = async pre => { const np = net.length; const before = await used(); await toasts(); const dl = p.waitForEvent('download', { timeout: 20000 }).catch(() => null); await p.locator('main button', { hasText: /^\s*Download/ }).first().click(); const d = await dl; await p.waitForTimeout(1500); let file = null; if (d) { const nm = pre + (process.env.SUF || '') + d.suggestedFilename(); const f = OUT + 'downloads/' + nm; await d.saveAs(f); file = { name: d.suggestedFilename(), saved: nm, bytes: fs.statSync(f).size, md5: md5(f), an: AN(f) }; } const dg = await dialog(); const r = { before, after: await used(), posts: net.slice(np).map(x => x.u.slice(0, 60)), dialog: dg, toasts: await toasts(), file }; if (dg) { await shot('dl-dialog-' + pre + Date.now() % 100000); await esc(); } return r; };
 const C = async (id, fn) => { try { R.cases[id] = await fn(); } catch (e) { R.cases[id] = { err: e.message.split('\n')[0].slice(0, 200) }; await shot(id + '-err').catch(() => { }); } console.log(id, JSON.stringify(R.cases[id]).slice(0, 900)); };
 const find = async want => { for (let i = 0; i < +(process.env.TRIES || 10); i++) { await open(); const u = await used(); R.tries.push(u); const [a, l] = u.split('/').map(Number); if (want === 'cap' ? a >= l : a < l) return true; await c.close(); } return false; };
 const fresh = async () => { await btn('New').click().catch(() => { }); await p.waitForTimeout(800); };
 if (mode === 'zero') { R.found = await find('cap'); R.start = { used: await used(), strip: await strip() }; await shot('Z00');
  await C('Z01-upload-wav', () => upload('tone-10s-44k.wav')); await shot('Z01');
  await C('Z02-1x-disabled', async () => ({ disabled: await btn('Change Speed').isDisabled(), label: await label() }));
  await C('Z03-2x-change', async () => { await preset('2'); const r = await change(); r.engine = eng25.slice(0, 6); await shot('Z03-result'); return r; });
  await C('Z04-audio-attrs', audioAttrs);
  await C('Z05-player-blob', () => grab('zero-2x-'));
  await C('Z06-download', () => download('zero-'));
  await C('Z07-new-mp3-1.5x', async () => { await fresh(); await upload('tone-10s.mp3'); await preset('1.5'); const r = await change(); r.blob = await grab('zero-mp3-1.5x-'); return r; });
  await C('Z08-download', () => download('zero-mp3-'));
  R.end = await used(); R.net = net;
 } else if (mode === 'cases') { R.found = await find('cap'); R.start = { used: await used() };
  const run = async (id, f, sp, pt) => C(id, async () => { await p.goto(TOOL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); const u = await upload(f); if (sp) await preset(sp); let pv = null; if (pt) pv = await pitch(pt); const r = await change(); r.pitch = pv; r.u = u; r.blob = r.result ? await grab(id + '-') : null; return r; });
  await run('C01-flac-2x', 'tone-10s.flac', '2'); await run('C02-ogg-3x', 'tone-10s.ogg', '3'); await run('C03-m4a-0.5x', 'tone-10s.m4a', '0.5');
  await run('C04-wav-4x', 'tone-10s-44k.wav', '4'); await run('C05-48k-stereo-1.25x-pitch-12', 'tone-10s-48k-stereo.wav', '1.25', -12);
  await run('C06-wav-1x-pitch+12', 'tone-10s-44k.wav', null, 12); await run('C07-video-mp4-2x', 'video-5s.mp4', '2');
  await C('C08-not-audio', async () => { await p.goto(TOOL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); const u = await upload('not-audio.mp3'); await preset('2'); const r = await change(60000); await shot('C08'); return { u, r }; });
  await C('C09-slider-keys', async () => { await p.goto(TOOL, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); await upload('tone-10s-44k.wav'); const s = p.locator('main [role=slider][aria-label="Playback speed"]'); await s.focus(); await p.keyboard.press('End'); const a = await label(); await p.keyboard.press('Home'); const b2 = await label(); await preset('1'); await p.keyboard.press('ArrowRight'); return { end: a, home: b2, plus1: await label() }; });
  R.end = await used(); R.net = net;
 } else if (mode === 'left') { R.found = await find('left'); if (!R.found) { fs.writeFileSync(OUT + 'left' + sfx + '.json', JSON.stringify(R, null, 1)); await b.close(); return; } R.start = { used: await used(), strip: await strip() }; await shot('L00');
  await C('L01-upload-wav', () => upload('tone-10s-44k.wav'));
  await C('L02-1.5x-change', async () => { await preset('1.5'); const r = await change(); r.blob = await grab('L02-'); return r; });
  await C('L03-download', () => download('L03-'));
  await C('L04-download-again', () => download('L04-'));
  await C('L05-2x-new-result-download', async () => { await preset('2'); const r = await change(); return { r, d: await download('L05-') }; }).catch(() => { });
  await C('L06-new-mp3-0.5x', async () => { await fresh(); await upload('tone-10s.mp3'); await preset('0.5'); const r = await change(); return { r, d: await download('L06-') }; });
  await C('L07-new-m4a-1.25x-pitch+12', async () => { await fresh(); await upload('tone-10s.m4a'); await preset('1.25'); const pv = await pitch(12); const r = await change(); return { pv, r, d: await download('L07-') }; });
  await C('L08-reload-flac-2x', async () => { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); await upload('tone-10s.flac'); await preset('2'); const r = await change(); return { r, d: await download('L08-') }; });
  await C('L09-download-again', () => download('L09-'));
  R.end = await used(); R.net = net;
 } else if (mode === 'quickbuy') { await open(); for (const [i, lab] of [[0, 'day'], [1, 'monthly']]) await C('Q-' + lab, async () => { const pg = await c.newPage(); await pg.goto(TOOL, { waitUntil: 'domcontentloaded' }); await pg.waitForTimeout(4500); await pg.locator('main button', { hasText: 'Quick Buy' }).nth(i).click(); await pg.waitForTimeout(7000); await pg.screenshot({ path: OUT + 'quickbuy-' + lab + sfx + '.png' }); const d = await pg.locator('[role=dialog]').first().innerText().catch(() => null); return { url: red(pg.url()), dialog: d ? d.replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null }; }); }
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', JSON.stringify(R.tries), JSON.stringify(R.start || ''), R.end); await b.close(); })();
