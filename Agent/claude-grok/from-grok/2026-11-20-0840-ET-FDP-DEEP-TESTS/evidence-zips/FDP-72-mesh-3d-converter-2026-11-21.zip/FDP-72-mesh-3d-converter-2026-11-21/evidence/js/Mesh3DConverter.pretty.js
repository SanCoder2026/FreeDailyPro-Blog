import { r as z, j as o } from "./vendor-react-D01g8YgM.js";
import { u as ue } from "./useRevealDownload-BkGzz0vy.js";
import { T as he, F as pe, P as ge, D as xe } from "./ToolPage-DwLoDncN.js";
import { f as ce, B as Z, e as Q, I as be } from "./index-B1CTyGtY.js";
import { C as ye } from "./card-KXKUZKW8.js";
import { S as W, a as X, b as q, c as ee, d as V } from "./select-ic5yaeGw.js";
import { T as we } from "./ToolInfoSection-C0i6Zbwo.js";
import {
  b as de,
  m as ve,
  c as je,
  s as te,
  w as Se,
  a as ke,
  d as Fe,
  e as Le,
  f as Ce,
  g as Ne,
} from "./mesh3d-C14zW8wv.js";
import {
  d as Te,
  l as Me,
  m as $e,
  g as Ae,
  M as Be,
  U as H,
  a as ze,
} from "./MeshReport-Dqk1IzcF.js";
import { write3MF as Ie } from "./threemf-Cq05XjYJ.js";
import { p as Ee } from "./numberInput-5hjoxJ5z.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./chevron-up-BDUcPssj.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
const K = (c, a) => {
    const n = new Float64Array(10);
    for (let r = 0; r < 10; r++) n[r] = c[r] + a[r];
    return n;
  },
  fe = (c, a, n, r, d) =>
    Float64Array.of(
      c * c * d,
      c * a * d,
      c * n * d,
      c * r * d,
      a * a * d,
      a * n * d,
      a * r * d,
      n * n * d,
      n * r * d,
      r * r * d,
    ),
  De = (c, a, n, r) =>
    c[0] * a * a +
    2 * c[1] * a * n +
    2 * c[2] * a * r +
    2 * c[3] * a +
    c[4] * n * n +
    2 * c[5] * n * r +
    2 * c[6] * n +
    c[7] * r * r +
    2 * c[8] * r +
    c[9];
function Pe(c) {
  const a = c[0],
    n = c[1],
    r = c[2],
    d = c[4],
    l = c[5],
    i = c[7],
    y = a * (d * i - l * l) - n * (n * i - l * r) + r * (n * l - d * r);
  if (Math.abs(y) < 1e-12) return null;
  const x = -c[3],
    w = -c[6],
    A = -c[8],
    I = (x * (d * i - l * l) - n * (w * i - l * A) + r * (w * l - d * A)) / y,
    T = (a * (w * i - l * A) - x * (n * i - l * r) + r * (n * A - w * r)) / y,
    u = (a * (d * A - w * l) - n * (n * A - w * r) + x * (n * l - d * r)) / y;
  return Number.isFinite(I + T + u) ? [I, T, u] : null;
}
class Oe {
  constructor() {
    this.h = [];
  }
  get size() {
    return this.h.length;
  }
  push(a) {
    const n = this.h;
    n.push(a);
    let r = n.length - 1;
    for (; r > 0;) {
      const d = (r - 1) >> 1;
      if (n[d].cost <= n[r].cost) break;
      (([n[d], n[r]] = [n[r], n[d]]), (r = d));
    }
  }
  pop() {
    const a = this.h;
    if (!a.length) return;
    const n = a[0],
      r = a.pop();
    if (a.length) {
      a[0] = r;
      let d = 0;
      for (;;) {
        const l = 2 * d + 1,
          i = l + 1;
        let y = d;
        if (
          (l < a.length && a[l].cost < a[y].cost && (y = l),
          i < a.length && a[i].cost < a[y].cost && (y = i),
          y === d)
        )
          break;
        (([a[y], a[d]] = [a[d], a[y]]), (d = y));
      }
    }
    return n;
  }
}
function Ge(c, a) {
  const n = c.triangles.length,
    r = Math.max(4, Math.floor(a));
  if (n <= r) return c;
  const d = c.vertices.length / 3,
    l = Float64Array.from(c.vertices),
    i = new Int32Array(n * 3);
  c.triangles.forEach((t, e) => {
    ((i[e * 3] = t[0]), (i[e * 3 + 1] = t[1]), (i[e * 3 + 2] = t[2]));
  });
  const y = new Uint8Array(n).fill(1),
    x = Array.from({ length: d }, () => new Set());
  for (let t = 0; t < n; t++)
    for (let e = 0; e < 3; e++) x[i[t * 3 + e]].add(t);
  const w = Array.from({ length: d }, () => new Float64Array(10)),
    A = new Map(),
    I = (t, e) => (t < e ? t * d + e : e * d + t),
    T = (t, e = l) => {
      const f = i[t * 3] * 3,
        p = i[t * 3 + 1] * 3,
        m = i[t * 3 + 2] * 3,
        v = e[p] - e[f],
        j = e[p + 1] - e[f + 1],
        C = e[p + 2] - e[f + 2],
        s = e[m] - e[f],
        b = e[m + 1] - e[f + 1],
        g = e[m + 2] - e[f + 2],
        k = j * g - C * b,
        $ = C * s - v * g,
        N = v * b - j * s;
      return [k, $, N, Math.hypot(k, $, N)];
    };
  for (let t = 0; t < n; t++) {
    const [e, f, p, m] = T(t);
    if (m > 0) {
      const v = i[t * 3] * 3,
        j = -((e / m) * l[v] + (f / m) * l[v + 1] + (p / m) * l[v + 2]),
        C = fe(e / m, f / m, p / m, j, m / 2);
      for (let s = 0; s < 3; s++) w[i[t * 3 + s]] = K(w[i[t * 3 + s]], C);
    }
    for (let v = 0; v < 3; v++) {
      const j = I(i[t * 3 + v], i[t * 3 + ((v + 1) % 3)]);
      A.set(j, (A.get(j) ?? 0) + 1);
    }
  }
  for (let t = 0; t < n; t++) {
    const [e, f, p, m] = T(t);
    if (m)
      for (let v = 0; v < 3; v++) {
        const j = i[t * 3 + v],
          C = i[t * 3 + ((v + 1) % 3)];
        if (A.get(I(j, C)) !== 1) continue;
        const s = l[C * 3] - l[j * 3],
          b = l[C * 3 + 1] - l[j * 3 + 1],
          g = l[C * 3 + 2] - l[j * 3 + 2];
        let k = b * p - g * f,
          $ = g * e - s * p,
          N = s * f - b * e;
        const J = Math.hypot(k, $, N);
        if (!J) continue;
        ((k /= J), ($ /= J), (N /= J));
        const _ = fe(
          k,
          $,
          N,
          -(k * l[j * 3] + $ * l[j * 3 + 1] + N * l[j * 3 + 2]),
          (100 * Math.hypot(s, b, g) ** 2) / 2 / 1,
        );
        ((w[j] = K(w[j], _)), (w[C] = K(w[C], _)));
      }
  }
  const u = new Int32Array(d),
    F = new Uint8Array(d),
    M = (t) => {
      const e = new Set();
      for (const f of Array.from(x[t]))
        for (let p = 0; p < 3; p++) {
          const m = i[f * 3 + p];
          m !== t && e.add(m);
        }
      return e;
    },
    h = (t, e) => {
      const f = K(w[t], w[e]),
        p = Pe(f),
        m = [
          [l[t * 3], l[t * 3 + 1], l[t * 3 + 2]],
          [l[e * 3], l[e * 3 + 1], l[e * 3 + 2]],
        ];
      (m.push([
        (m[0][0] + m[1][0]) / 2,
        (m[0][1] + m[1][1]) / 2,
        (m[0][2] + m[1][2]) / 2,
      ]),
        p && m.push(p));
      let v = m[0],
        j = 1 / 0;
      for (const C of m) {
        const s = De(f, C[0], C[1], C[2]);
        s < j && ((j = s), (v = C));
      }
      return { cost: Math.max(0, j), a: t, b: e, va: u[t], vb: u[e], p: v };
    },
    L = new Oe(),
    O = new Set();
  for (let t = 0; t < n; t++)
    for (let e = 0; e < 3; e++) {
      const f = i[t * 3 + e],
        p = i[t * 3 + ((e + 1) % 3)],
        m = I(f, p);
      O.has(m) || (O.add(m), L.push(h(f, p)));
    }
  let Y = n;
  const S = new Float64Array(9);
  for (; Y > r && L.size;) {
    const t = L.pop(),
      { a: e, b: f } = t;
    if (F[e] || F[f] || u[e] !== t.va || u[f] !== t.vb) continue;
    const p = M(e),
      m = M(f);
    let v = 0;
    p.forEach((s) => {
      m.has(s) && v++;
    });
    const j = Array.from(x[e]).filter((s) => x[f].has(s)).length;
    if (v !== j) continue;
    let C = !0;
    for (const [s, b] of [
      [e, f],
      [f, e],
    ]) {
      for (const g of Array.from(x[s])) {
        if (x[b].has(g)) continue;
        const [k, $, N, J] = T(g);
        for (let E = 0; E < 9; E++)
          S[E] = l[i[g * 3 + ((E / 3) | 0)] * 3 + (E % 3)];
        for (let E = 0; E < 3; E++)
          i[g * 3 + E] === s &&
            ((S[E * 3] = t.p[0]),
            (S[E * 3 + 1] = t.p[1]),
            (S[E * 3 + 2] = t.p[2]));
        const _ = S[3] - S[0],
          D = S[4] - S[1],
          P = S[5] - S[2],
          U = S[6] - S[0],
          ne = S[7] - S[1],
          oe = S[8] - S[2],
          le = D * oe - P * ne,
          re = P * U - _ * oe,
          ie = _ * ne - D * U,
          ae = Math.hypot(le, re, ie);
        if (
          J > 0 &&
          (ae === 0 || (k * le + $ * re + N * ie) / (J * ae) < 0.2)
        ) {
          C = !1;
          break;
        }
      }
      if (!C) break;
    }
    if (C) {
      ((l[e * 3] = t.p[0]),
        (l[e * 3 + 1] = t.p[1]),
        (l[e * 3 + 2] = t.p[2]),
        (w[e] = K(w[e], w[f])));
      for (const s of Array.from(x[f])) {
        if (x[e].has(s)) {
          ((y[s] = 0), Y--);
          for (let b = 0; b < 3; b++) x[i[s * 3 + b]].delete(s);
          continue;
        }
        for (let b = 0; b < 3; b++) i[s * 3 + b] === f && (i[s * 3 + b] = e);
        (x[f].delete(s), x[e].add(s));
      }
      ((F[f] = 1), u[e]++, M(e).forEach((s) => L.push(h(e, s))));
    }
  }
  const G = new Int32Array(d).fill(-1),
    B = [],
    R = [];
  for (let t = 0; t < n; t++) {
    if (!y[t]) continue;
    const e = [i[t * 3], i[t * 3 + 1], i[t * 3 + 2]];
    if (!(e[0] === e[1] || e[1] === e[2] || e[0] === e[2])) {
      for (let f = 0; f < 3; f++)
        (G[e[f]] < 0 &&
          ((G[e[f]] = B.length / 3),
          B.push(l[e[f] * 3], l[e[f] * 3 + 1], l[e[f] * 3 + 2])),
          (e[f] = G[e[f]]));
      R.push(e);
    }
  }
  return { vertices: B, triangles: R };
}
function Ue(c, a = 100) {
  const n = new Map(),
    r = (u, F) => (u < F ? `${u}_${F}` : `${F}_${u}`);
  for (const [u, F, M] of c.triangles)
    for (const [h, L] of [
      [u, F],
      [F, M],
      [M, u],
    ])
      n.set(r(h, L), (n.get(r(h, L)) ?? 0) + 1);
  const d = new Map();
  let l = 0;
  for (const [u, F, M] of c.triangles)
    for (const [h, L] of [
      [u, F],
      [F, M],
      [M, u],
    ])
      n.get(r(h, L)) === 1 && (l++, d.set(h, [...(d.get(h) ?? []), L]));
  if (l === 0) return { mesh: c, filled: 0, skipped: 0, addedTriangles: 0 };
  const i = (u, F) => (n.get(r(u, F)) ?? 0) > 2,
    y = c.vertices.slice(),
    x = c.triangles.map((u) => u.slice()),
    w = new Set();
  let A = 0,
    I = 0,
    T = 0;
  for (const [u, F] of Array.from(d.entries()))
    for (const M of F) {
      if (w.has(`${u}>${M}`)) continue;
      const h = [u];
      let L = u,
        O = M,
        Y = !1,
        S = F.length === 1;
      for (; O !== void 0;) {
        if ((w.add(`${L}>${O}`), i(L, O) && (S = !1), (L = O), L === u)) {
          Y = !0;
          break;
        }
        h.push(L);
        const e = d.get(L) ?? [];
        (e.length !== 1 && (S = !1), (O = e.find((f) => !w.has(`${L}>${f}`))));
      }
      if (!Y || !S || h.length < 3 || h.length > a) {
        I++;
        continue;
      }
      if (h.length === 3) {
        (x.push([h[0], h[2], h[1]]), T++, A++);
        continue;
      }
      let G = 0,
        B = 0,
        R = 0;
      for (const e of h)
        ((G += y[e * 3]), (B += y[e * 3 + 1]), (R += y[e * 3 + 2]));
      const t = y.length / 3;
      y.push(G / h.length, B / h.length, R / h.length);
      for (let e = 0; e < h.length; e++)
        (x.push([h[(e + 1) % h.length], h[e], t]), T++);
      A++;
    }
  return {
    mesh: { vertices: y, triangles: x },
    filled: A,
    skipped: I,
    addedTriangles: T,
  };
}
function Ye(c) {
  const a = c.vertices;
  if (a.length < 3) return 0;
  const n = [1 / 0, 1 / 0, 1 / 0],
    r = [-1 / 0, -1 / 0, -1 / 0];
  for (let d = 0; d + 2 < a.length; d += 3)
    for (let l = 0; l < 3; l++) {
      const i = a[d + l];
      (i < n[l] && (n[l] = i), i > r[l] && (r[l] = i));
    }
  return Math.max(r[0] - n[0], r[1] - n[1], r[2] - n[2]);
}
function Re(c, a, n) {
  if (c === "none") return 1;
  if (a === null || !Number.isFinite(a) || a <= 0) return null;
  if (c === "factor") return a <= 1e6 ? a : null;
  const r = Ye(n);
  if (!(r > 0)) return null;
  const d = a / r;
  return d <= 1e6 ? d : null;
}
const me = [
    { id: "stl-bin", label: "STL (binary, smaller)", ext: "stl" },
    { id: "stl-ascii", label: "STL (ASCII text)", ext: "stl" },
    { id: "obj", label: "OBJ", ext: "obj" },
    { id: "ply-bin", label: "PLY (binary, smaller)", ext: "ply" },
    { id: "ply-ascii", label: "PLY (ASCII text)", ext: "ply" },
    { id: "glb", label: "GLB (glTF binary)", ext: "glb" },
    { id: "3mf", label: "3MF (3D printing, millimetres)", ext: "3mf" },
  ],
  se = {
    what: 'Converts 3D mesh files between STL, OBJ, PLY (ASCII and binary), GLB (glTF) and 3MF, entirely in your browser. It merges duplicate vertices (so OBJ/PLY/GLB files are much smaller), writes face normals for STL output (OBJ, PLY and GLB are written without them), and checks the model (size, watertight, volume) before you download. You can tick "Fill small holes" to close open loops in a model that is not watertight, and scale the exported model by a factor or to a target size. A slider can also reduce the triangle count (mesh simplification) for big scans.',
    how: "Upload a 3D file (the format is detected from its extension), choose what to convert to, and download. For GLB and 3MF, tell it the model's units, because glTF is always in metres and 3MF in millimetres.",
    tip: "This converts geometry only: positions and triangles, with no colours, textures or materials. STL has no units; glTF/GLB uses metres, so pick the unit your model was made in (3D-printing models are usually millimetres). STEP and IGES are CAD formats that need specialised software.",
  };
function Nt() {
  const [c, a] = z.useState(null),
    [n, r] = z.useState(100),
    [d, l] = z.useState("stl"),
    [i, y] = z.useState("obj"),
    [x, w] = z.useState("mm"),
    [A, I] = z.useState(!1),
    [T, u] = z.useState(null),
    [F, M] = z.useState(null),
    [h, L] = z.useState(null),
    [O, Y] = z.useState(!1),
    [S, G] = z.useState(!1),
    [B, R] = z.useState("none"),
    [t, e] = z.useState(""),
    f = ue(!!T),
    p = z.useMemo(() => {
      if (!h) return null;
      const s = de(h);
      return { welded: s, checks: je(s), size: ve(s).size };
    }, [h]),
    m = p ? Re(B, Ee(t), p.welded) : 1,
    v = B !== "none" && m === null,
    j = z.useCallback(async (s) => {
      const b = s[0];
      if (!b) return;
      const g = Te(b.name);
      if (!g) {
        ce.error("Unsupported file type. Use STL, OBJ, PLY, GLB or 3MF.");
        return;
      }
      (a(b),
        u(null),
        G(!1),
        R("none"),
        e(""),
        l(g),
        M(null),
        L(null),
        Y(!1),
        w(g === "glb" ? "m" : "mm"),
        g === "obj" ? y("stl-bin") : g === "stl" && y("obj"),
        I(!0));
      try {
        const k = await Me(b, g),
          $ = $e(k);
        if ($) {
          M($);
          return;
        }
        (L(k), (g === "obj" || g === "ply") && (w(Ae(k)), Y(!0)));
      } catch (k) {
        M(
          k instanceof Error && k.message
            ? `Couldn't read this file: ${k.message}`
            : "Couldn't read this file. Check it is a valid 3D file.",
        );
      } finally {
        I(!1);
      }
    }, []),
    C = async () => {
      if (!(!c || !h)) {
        I(!0);
        try {
          const b = de(h),
            g = S ? Ue(b) : null,
            k = g ? { ...g.mesh, removedDegenerate: b.removedDegenerate } : b,
            $ =
              n < 100
                ? {
                    ...Ge(k, (k.triangles.length * n) / 100),
                    removedDegenerate: k.removedDegenerate,
                  }
                : k;
          if (m === null) throw new Error("Enter a scale above zero");
          const N =
              m === 1
                ? $
                : { ...te($, m), removedDegenerate: $.removedDegenerate },
            J = me.find((U) => U.id === i),
            _ = c.name.replace(/\.[^.]+$/, "");
          let D,
            P = "";
          if (i === "stl-bin")
            D = new Blob([Se(N)], { type: "application/sla" });
          else if (i === "stl-ascii")
            D = new Blob([ke(N, _)], { type: "application/sla" });
          else if (i === "obj") D = new Blob([Fe(N)], { type: "text/plain" });
          else if (i === "ply-bin")
            D = new Blob([Le(N)], { type: "application/octet-stream" });
          else if (i === "ply-ascii")
            D = new Blob([Ce(N)], { type: "text/plain" });
          else if (i === "3mf") {
            const U = H[x].f / 0.001;
            ((D = await Ie(te(N, U), _)),
              U !== 1 &&
                (P = `Scaled from ${H[x].label.toLowerCase()} to millimetres for 3MF.`));
          } else {
            const U = H[x].f;
            ((D = new Blob([Ne(te(N, U))], { type: "model/gltf-binary" })),
              U !== 1 &&
                (P = `Scaled from ${H[x].label.toLowerCase()} to metres for glTF.`));
          }
          (g &&
            (P +=
              g.filled > 0
                ? ` Filled ${g.filled} hole${g.filled === 1 ? "" : "s"} (${g.addedTriangles.toLocaleString()} triangles added).`
                : ""),
            g &&
              g.skipped > 0 &&
              (P += ` ${g.skipped} open loop${g.skipped === 1 ? " was" : "s were"} left as is (too large, or touching another hole).`),
            m !== 1 &&
              (P += ` Scaled by ${Number(m.toPrecision(6)).toLocaleString(void 0, { maximumFractionDigits: 6 })}x.`),
            n < 100 &&
              (P += ` Reduced from ${k.triangles.length.toLocaleString()} to ${$.triangles.length.toLocaleString()} triangles.`),
            N.removedDegenerate > 0 &&
              (P += ` ${N.removedDegenerate.toLocaleString()} zero-area triangle(s) were dropped.`),
            u({ blob: D, name: `${_}.${J.ext}`, mesh: N, note: P.trim() }),
            ce.success(
              `Converted ${N.triangles.length.toLocaleString()} triangles`,
            ));
        } catch (s) {
          M(
            s instanceof Error && s.message
              ? `Couldn't convert: ${s.message}`
              : "Couldn't convert this file. Check it is a valid 3D file.",
          );
        } finally {
          I(!1);
        }
      }
    };
  return o.jsxs(he, {
    children: [
      c
        ? o.jsxs("div", {
            className: "space-y-4",
            children: [
              o.jsxs("div", {
                className:
                  "p-4 rounded-lg border bg-card flex items-center justify-between gap-2",
                children: [
                  o.jsxs("p", {
                    className: "text-sm font-medium truncate",
                    children: [
                      c.name,
                      " ",
                      o.jsxs("span", {
                        className: "text-xs text-muted-foreground",
                        children: ["(", d.toUpperCase(), ")"],
                      }),
                    ],
                  }),
                  o.jsx(Z, {
                    size: "sm",
                    variant: "ghost",
                    onClick: () => {
                      (a(null),
                        u(null),
                        M(null),
                        L(null),
                        G(!1),
                        R("none"),
                        e(""));
                    },
                    children: "Change file",
                  }),
                ],
              }),
              o.jsxs("div", {
                className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                children: [
                  o.jsxs("div", {
                    children: [
                      o.jsx(Q, {
                        className: "mb-2 block",
                        children: "Convert to",
                      }),
                      o.jsxs(W, {
                        value: i,
                        onValueChange: (s) => {
                          (y(s), u(null));
                        },
                        children: [
                          o.jsx(X, {
                            "aria-label": "Convert to",
                            children: o.jsx(q, {}),
                          }),
                          o.jsx(ee, {
                            children: me.map((s) =>
                              o.jsx(
                                V,
                                { value: s.id, children: s.label },
                                s.id,
                              ),
                            ),
                          }),
                        ],
                      }),
                    ],
                  }),
                  o.jsxs("div", {
                    children: [
                      o.jsx(Q, {
                        className: "mb-2 block",
                        children: "Model units",
                      }),
                      o.jsxs(W, {
                        value: x,
                        onValueChange: (s) => {
                          (w(s), Y(!1), u(null));
                        },
                        children: [
                          o.jsx(X, {
                            "aria-label": "Model units",
                            children: o.jsx(q, {}),
                          }),
                          o.jsx(ee, {
                            children: Object.entries(H).map(([s, b]) =>
                              o.jsx(V, { value: s, children: b.label }, s),
                            ),
                          }),
                        ],
                      }),
                      o.jsxs("p", {
                        className: "text-xs text-muted-foreground mt-1",
                        children: [
                          O
                            ? "Guessed from the model's size (OBJ and PLY files don't store units). Change it if the size below looks wrong. "
                            : "",
                          i === "glb"
                            ? "glTF is always in metres, so the model is scaled."
                            : i === "3mf"
                              ? "3MF is always in millimetres, so the model is scaled if needed."
                              : "Used for the size and fits-on-bed checks.",
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              o.jsxs("div", {
                children: [
                  o.jsxs(Q, {
                    htmlFor: "keep-pct",
                    className: "mb-2 block",
                    children: [
                      "Reduce triangles: keep ",
                      n,
                      "%",
                      n < 100
                        ? " (smaller file, less detail)"
                        : " (no reduction)",
                    ],
                  }),
                  o.jsx("input", {
                    id: "keep-pct",
                    type: "range",
                    min: 5,
                    max: 100,
                    step: 5,
                    value: n,
                    onChange: (s) => {
                      (r(Number(s.target.value)), u(null));
                    },
                    className: "w-full max-w-sm",
                  }),
                  o.jsx("p", {
                    className: "text-xs text-muted-foreground mt-1",
                    children:
                      "Merges the least important edges first, keeping the shape, the outline and closed surfaces. Try 50% for a big scan; large models can take several seconds.",
                  }),
                ],
              }),
              p &&
                o.jsxs("div", {
                  className: "space-y-3 rounded-lg border p-3",
                  "data-testid": "mesh-options",
                  children: [
                    o.jsxs("div", {
                      children: [
                        o.jsx("p", {
                          className: "text-sm font-medium mb-1",
                          children: "Repair",
                        }),
                        p.checks.watertight
                          ? o.jsx("p", {
                              className: "text-xs text-muted-foreground",
                              children:
                                "This model is already watertight, so there is nothing to fill.",
                            })
                          : o.jsxs(o.Fragment, {
                              children: [
                                o.jsxs("p", {
                                  className: "text-xs font-medium mb-2",
                                  children: [
                                    "⚠ Not watertight: ",
                                    p.checks.openEdges.toLocaleString(),
                                    " open edge",
                                    p.checks.openEdges === 1 ? "" : "s",
                                    p.checks.nonManifoldEdges
                                      ? ` and ${p.checks.nonManifoldEdges.toLocaleString()} edge(s) shared by 3+ faces`
                                      : "",
                                    ".",
                                  ],
                                }),
                                o.jsxs("label", {
                                  className: "flex items-start gap-2 text-sm",
                                  children: [
                                    o.jsx("input", {
                                      type: "checkbox",
                                      className: "mt-1",
                                      checked: S,
                                      onChange: (s) => {
                                        (G(s.target.checked), u(null));
                                      },
                                    }),
                                    o.jsx("span", {
                                      children:
                                        "Fill small holes (open loops of up to 100 edges) when converting. Your file is only changed if this is ticked, and the result is re-checked below.",
                                    }),
                                  ],
                                }),
                                p.checks.nonManifoldEdges > 0 &&
                                  o.jsx("p", {
                                    className:
                                      "text-xs text-muted-foreground mt-1",
                                    children:
                                      "Edges shared by 3+ faces can't be fixed by filling holes.",
                                  }),
                              ],
                            }),
                      ],
                    }),
                    o.jsxs("div", {
                      children: [
                        o.jsx(Q, {
                          className: "mb-1 block text-sm font-medium",
                          children: "Scale",
                        }),
                        o.jsxs("div", {
                          className: "flex flex-wrap items-center gap-2",
                          children: [
                            o.jsxs(W, {
                              value: B,
                              onValueChange: (s) => {
                                (R(s), u(null));
                              },
                              children: [
                                o.jsx(X, {
                                  "aria-label": "Scale mode",
                                  className: "w-56",
                                  children: o.jsx(q, {}),
                                }),
                                o.jsxs(ee, {
                                  children: [
                                    o.jsx(V, {
                                      value: "none",
                                      children: "Keep the size",
                                    }),
                                    o.jsx(V, {
                                      value: "factor",
                                      children: "Multiply by a factor",
                                    }),
                                    o.jsx(V, {
                                      value: "largest",
                                      children: "Set the largest side to",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            B !== "none" &&
                              o.jsx(be, {
                                "aria-label":
                                  B === "factor"
                                    ? "Scale factor"
                                    : `Largest side (${x})`,
                                className: "h-9 w-28",
                                inputMode: "decimal",
                                placeholder: B === "factor" ? "10" : "50",
                                value: t,
                                onChange: (s) => {
                                  (e(s.target.value), u(null));
                                },
                              }),
                            B === "largest" &&
                              o.jsx("span", {
                                className: "text-xs text-muted-foreground",
                                children: x,
                              }),
                            B === "factor" &&
                              [0.1, 10, 25.4].map((s) =>
                                o.jsxs(
                                  Z,
                                  {
                                    type: "button",
                                    size: "sm",
                                    variant: "outline",
                                    onClick: () => {
                                      (e(String(s)), u(null));
                                    },
                                    children: ["×", s],
                                  },
                                  s,
                                ),
                              ),
                          ],
                        }),
                        o.jsx("p", {
                          className: `text-xs mt-1 ${v ? "text-destructive" : "text-muted-foreground"}`,
                          children:
                            B === "none"
                              ? "Applies to the exported model, in the units chosen above."
                              : v
                                ? "Enter a number above zero."
                                : `Exported size: ${p.size.map((s) => Number((s * (m ?? 1)).toPrecision(6)).toLocaleString(void 0, { maximumFractionDigits: 4 })).join(" × ")} ${x}`,
                        }),
                      ],
                    }),
                  ],
                }),
              F &&
                o.jsx("p", {
                  role: "alert",
                  className: "text-sm text-destructive",
                  children: F,
                }),
              A
                ? o.jsx(ge, {})
                : o.jsx(Z, {
                    onClick: C,
                    disabled: !h || !!F || v,
                    children: "Convert",
                  }),
              T &&
                o.jsxs(ye, {
                  className: "p-4 space-y-3",
                  children: [
                    o.jsx(ze, { mesh: T.mesh, unitLabel: x }),
                    T.note &&
                      o.jsx("p", {
                        className: "text-xs text-muted-foreground",
                        children: T.note,
                      }),
                    o.jsxs("p", {
                      className: "text-xs text-muted-foreground",
                      children: [
                        "Output size: ",
                        (T.blob.size / 1024).toLocaleString(void 0, {
                          maximumFractionDigits: 1,
                        }),
                        " KB",
                      ],
                    }),
                    o.jsx("div", {
                      ref: f.ref,
                      className: f.className,
                      children: o.jsx(xe, { blob: T.blob, fileName: T.name }),
                    }),
                  ],
                }),
            ],
          })
        : o.jsx(pe, {
            gateAtDownload: !0,
            accept: Be,
            onFiles: j,
            label: "Drop an STL, OBJ, PLY, GLB or 3MF file",
            description:
              "Convert between 3D mesh formats — runs entirely in your browser",
          }),
      o.jsx(we, { whatIsIt: se.what, howToUse: se.how, tip: se.tip }),
    ],
  });
}
export { Nt as default };
//# sourceMappingURL=Mesh3DConverter-CXAH8d0k.js.map
