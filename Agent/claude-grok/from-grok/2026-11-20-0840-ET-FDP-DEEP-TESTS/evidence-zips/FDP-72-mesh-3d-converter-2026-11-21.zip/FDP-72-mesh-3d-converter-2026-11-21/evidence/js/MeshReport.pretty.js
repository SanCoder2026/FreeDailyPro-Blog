const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/threemf-Cq05XjYJ.js",
      "assets/jszip.min-CT0ZA6V1.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/jszip.min-C-FLQHAz.js",
      "assets/_commonjs-dynamic-modules-TDtrdbi3.js",
      "assets/GLTFLoader-DPzr8bkz.js",
      "assets/three.module-DDguy-kI.js",
    ]),
) => i.map((i) => d[i]);
import { r as j, j as n } from "./vendor-react-D01g8YgM.js";
import { ap as v, e as _, I as M } from "./index-B1CTyGtY.js";
import {
  p as $,
  h as L,
  i as S,
  b as I,
  c as T,
  m as z,
} from "./mesh3d-C14zW8wv.js";
import { p as y } from "./numberInput-5hjoxJ5z.js";
const D = ".stl,.obj,.ply,.glb,.3mf";
function O(t) {
  const e = t.split(".").pop()?.toLowerCase();
  return e === "stl" || e === "obj" || e === "ply" || e === "glb" || e === "3mf"
    ? e
    : null;
}
async function U(t, e) {
  const s = await t.arrayBuffer();
  if (e === "stl") return $(s);
  if (e === "obj") return L(new TextDecoder().decode(s));
  if (e === "ply") return S(s);
  if (e === "3mf")
    return (
      await v(
        async () => {
          const { parse3MF: m } = await import("./threemf-Cq05XjYJ.js");
          return { parse3MF: m };
        },
        __vite__mapDeps([0, 1, 2, 3, 4]),
      )
    ).parse3MF(s);
  const [{ GLTFLoader: c }, l] = await Promise.all([
      v(() => import("./GLTFLoader-DPzr8bkz.js"), __vite__mapDeps([5, 6])),
      v(() => import("./three.module-DDguy-kI.js"), []),
    ]),
    o = await new Promise((m, r) => new c().parse(s, "", m, r));
  o.scene.updateMatrixWorld(!0);
  const i = [],
    g = [],
    f = new l.Vector3();
  if (
    (o.scene.traverse((m) => {
      const r = m;
      if (!r.isMesh || !r.geometry) return;
      const d = r.geometry.getAttribute("position");
      if (!d) return;
      const u = i.length / 3;
      for (let a = 0; a < d.count; a++)
        (f.fromBufferAttribute(d, a).applyMatrix4(r.matrixWorld),
          i.push(f.x, f.y, f.z));
      const x = r.geometry.getIndex(),
        E = x ? x.count : d.count;
      for (let a = 0; a + 2 < E; a += 3)
        g.push(
          x
            ? [u + x.getX(a), u + x.getX(a + 1), u + x.getX(a + 2)]
            : [u + a, u + a + 1, u + a + 2],
        );
    }),
    !i.length)
  )
    throw new Error("No triangle geometry found in this GLB");
  return { vertices: i, triangles: g };
}
const b = {
  mm: { label: "Millimetres", f: 0.001 },
  cm: { label: "Centimetres", f: 0.01 },
  m: { label: "Metres", f: 1 },
  in: { label: "Inches", f: 0.0254 },
};
function C(t) {
  const e = t.vertices;
  if (e.length < 3) return 0;
  let s = [1 / 0, 1 / 0, 1 / 0],
    c = [-1 / 0, -1 / 0, -1 / 0];
  for (let l = 0; l + 2 < e.length; l += 3)
    for (let o = 0; o < 3; o++) {
      const i = e[l + o];
      (i < s[o] && (s[o] = i), i > c[o] && (c[o] = i));
    }
  return Math.max(c[0] - s[0], c[1] - s[1], c[2] - s[2]);
}
function X(t) {
  const e = C(t);
  return e > 0 && e < 1e3 ? "mm" : "m";
}
function W(t) {
  return t.vertices.length === 0 || t.triangles.length === 0
    ? "No triangles found in this file. It may be empty, corrupt, or not the format its extension says."
    : t.vertices.some((e) => !Number.isFinite(e))
      ? "This file contains invalid coordinates (NaN), so it can't be converted."
      : null;
}
const F = (t) => t in b;
function w(t, e, s) {
  return (t * b[e].f) / b[s].f;
}
const h = (t) =>
    t !== 0 && Math.abs(t) < 0.01
      ? t.toExponential(2)
      : t.toLocaleString("en-US", { maximumFractionDigits: t >= 100 ? 1 : 3 }),
  N = (t) => (t === "in" ? "mm" : "in");
function G(t, e) {
  const s = N(e);
  return `${h(t)} ${e} (${h(w(t, e, s))} ${s})`;
}
function P(t, e) {
  const s = N(e);
  return `${t.map(h).join(" × ")} ${e} (${t.map((c) => h(w(c, e, s))).join(" × ")} ${s})`;
}
const p = (t, e = 2) =>
  t !== 0 && Math.abs(t) < 0.01
    ? t.toExponential(2)
    : t.toLocaleString(void 0, { maximumFractionDigits: e });
function H({ mesh: t, unitLabel: e = "units" }) {
  const [s, c] = j.useState({ x: "220", y: "220", z: "250" }),
    l = j.useMemo(() => {
      const r = I(t);
      return {
        stats: z(r),
        checks: T(r),
        removed: r.removedDegenerate,
        rawVerts: t.vertices.length / 3,
      };
    }, [t]),
    { stats: o, checks: i } = l,
    g = e === "mm",
    f = [y(s.x), y(s.y), y(s.z)],
    m =
      g && f.every((r) => r !== null && r > 0)
        ? o.size.every((r, d) => r <= f[d])
        : null;
  return n.jsxs("div", {
    className: "space-y-3",
    "data-testid": "mesh-report",
    children: [
      n.jsxs("div", {
        className: "grid grid-cols-2 md:grid-cols-4 gap-3 text-center",
        children: [
          n.jsxs("div", {
            children: [
              n.jsx("p", {
                className: "text-lg font-bold text-primary",
                children: o.vertexCount.toLocaleString(),
              }),
              n.jsxs("p", {
                className: "text-xs text-muted-foreground",
                children: [
                  "Vertices",
                  l.rawVerts !== o.vertexCount
                    ? ` (${l.rawVerts.toLocaleString()} before merging)`
                    : "",
                ],
              }),
            ],
          }),
          n.jsxs("div", {
            children: [
              n.jsx("p", {
                className: "text-lg font-bold text-primary",
                children: o.triangleCount.toLocaleString(),
              }),
              n.jsx("p", {
                className: "text-xs text-muted-foreground",
                children: "Triangles",
              }),
            ],
          }),
          n.jsxs("div", {
            className: "col-span-2",
            children: [
              n.jsx("p", {
                className: "text-sm font-medium",
                "data-testid": "mesh-bbox",
                children: F(e)
                  ? P(o.size, e)
                  : `${p(o.size[0])} × ${p(o.size[1])} × ${p(o.size[2])} ${e}`,
              }),
              n.jsx("p", {
                className: "text-xs text-muted-foreground",
                children: "Bounding box (X × Y × Z)",
              }),
            ],
          }),
        ],
      }),
      n.jsxs("ul", {
        className: "text-sm space-y-1",
        children: [
          n.jsx("li", {
            className: i.watertight ? "text-green-600" : "text-amber-600",
            children: i.watertight
              ? "✓ Watertight: every edge joins exactly two faces, so a slicer can treat it as a solid."
              : `⚠ Not watertight: ${i.openEdges.toLocaleString()} open edge${i.openEdges === 1 ? "" : "s"}${i.nonManifoldEdges ? ` and ${i.nonManifoldEdges.toLocaleString()} edge(s) shared by 3+ faces` : ""}. Slicers may report holes.`,
          }),
          i.watertight &&
            n.jsxs("li", {
              children: [
                "Volume ",
                p(i.volume),
                " ",
                e,
                "³ · surface area ",
                p(i.area),
                " ",
                e,
                "²",
                i.flipped ? " · faces point inward (normals flipped)" : "",
              ],
            }),
          l.removed > 0 &&
            n.jsxs("li", {
              className: "text-muted-foreground",
              children: [
                l.removed.toLocaleString(),
                " zero-area triangle(s) were ignored in these checks.",
              ],
            }),
        ],
      }),
      g &&
        n.jsxs("div", {
          className: "flex flex-wrap items-end gap-2 text-sm",
          children: [
            n.jsx("span", {
              className: "text-xs text-muted-foreground",
              children: "Print bed (mm):",
            }),
            ["x", "y", "z"].map((r) =>
              n.jsxs(
                "div",
                {
                  children: [
                    n.jsx(_, {
                      className: "text-[10px] uppercase text-muted-foreground",
                      children: r,
                    }),
                    n.jsx(M, {
                      "aria-label": `Bed ${r} (mm)`,
                      className: "h-8 w-20",
                      inputMode: "decimal",
                      value: s[r],
                      onChange: (d) => c({ ...s, [r]: d.target.value }),
                    }),
                  ],
                },
                r,
              ),
            ),
            m !== null &&
              n.jsx("span", {
                className: m ? "text-green-600" : "text-amber-600",
                children: m ? "✓ Fits on the bed" : "⚠ Larger than the bed",
              }),
          ],
        }),
    ],
  });
}
export {
  D as M,
  b as U,
  H as a,
  O as d,
  G as f,
  X as g,
  F as i,
  U as l,
  W as m,
};
//# sourceMappingURL=MeshReport-Dqk1IzcF.js.map
