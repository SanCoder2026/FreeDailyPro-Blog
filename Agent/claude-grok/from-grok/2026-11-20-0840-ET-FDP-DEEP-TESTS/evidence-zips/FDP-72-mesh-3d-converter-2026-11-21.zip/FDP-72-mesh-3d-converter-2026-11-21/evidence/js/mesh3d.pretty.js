function N(t) {
  const o = t.vertices.length / 3,
    r = t.triangles.length;
  let n = [1 / 0, 1 / 0, 1 / 0],
    e = [-1 / 0, -1 / 0, -1 / 0];
  for (let c = 0; c < t.vertices.length; c += 3)
    for (let a = 0; a < 3; a++) {
      const f = t.vertices[c + a];
      (f < n[a] && (n[a] = f), f > e[a] && (e[a] = f));
    }
  const i =
    n[0] === 1 / 0 ? [0, 0, 0] : [e[0] - n[0], e[1] - n[1], e[2] - n[2]];
  return { vertexCount: o, triangleCount: r, min: n, max: e, size: i };
}
function L(t) {
  if (!Number.isFinite(t)) return "0";
  const o = Math.fround(t);
  for (let r = 1; r <= 9; r++) {
    const n = Number(o.toPrecision(r));
    if (Math.fround(n) === o) return String(n === 0 ? 0 : n);
  }
  return String(o);
}
function z(t, o, r, n) {
  const e = t.vertices,
    i = e[r * 3] - e[o * 3],
    c = e[r * 3 + 1] - e[o * 3 + 1],
    a = e[r * 3 + 2] - e[o * 3 + 2],
    f = e[n * 3] - e[o * 3],
    g = e[n * 3 + 1] - e[o * 3 + 1],
    l = e[n * 3 + 2] - e[o * 3 + 2],
    s = c * l - a * g,
    u = a * f - i * l,
    y = i * g - c * f,
    d = Math.hypot(s, u, y);
  return d > 0 ? [s / d, u / d, y / d] : [0, 0, 0];
}
function Y(t) {
  const o = N(t),
    n = (Math.hypot(o.size[0], o.size[1], o.size[2]) || 1) * 1e-7,
    e = new Map(),
    i = new Array(t.vertices.length / 3),
    c = [];
  for (let g = 0; g < i.length; g++) {
    const l = t.vertices[g * 3],
      s = t.vertices[g * 3 + 1],
      u = t.vertices[g * 3 + 2],
      y = `${Math.round(l / n)},${Math.round(s / n)},${Math.round(u / n)}`;
    let d = e.get(y);
    (d === void 0 && ((d = c.length / 3), e.set(y, d), c.push(l, s, u)),
      (i[g] = d));
  }
  const a = [];
  let f = 0;
  for (const [g, l, s] of t.triangles) {
    const u = i[g],
      y = i[l],
      d = i[s];
    if (u === y || y === d || u === d) {
      f++;
      continue;
    }
    a.push([u, y, d]);
  }
  return { vertices: c, triangles: a, removedDegenerate: f };
}
function V(t, o) {
  return o === 1
    ? t
    : { vertices: t.vertices.map((r) => r * o), triangles: t.triangles };
}
function j(t) {
  const o = new Map(),
    r = (f, g) => {
      const l = f < g ? `${f}_${g}` : `${g}_${f}`;
      o.set(l, (o.get(l) ?? 0) + 1);
    };
  let n = 0,
    e = 0;
  const i = t.vertices;
  for (const [f, g, l] of t.triangles) {
    (r(f, g), r(g, l), r(l, f));
    const s = i[f * 3],
      u = i[f * 3 + 1],
      y = i[f * 3 + 2],
      d = i[g * 3],
      v = i[g * 3 + 1],
      p = i[g * 3 + 2],
      w = i[l * 3],
      x = i[l * 3 + 1],
      b = i[l * 3 + 2];
    ((n +=
      (s * (v * b - p * x) - u * (d * b - p * w) + y * (d * x - v * w)) / 6),
      (e +=
        0.5 *
        Math.hypot(
          (v - u) * (b - y) - (p - y) * (x - u),
          (p - y) * (w - s) - (d - s) * (b - y),
          (d - s) * (x - u) - (v - u) * (w - s),
        )));
  }
  let c = 0,
    a = 0;
  return (
    o.forEach((f) => {
      f === 1 ? c++ : f > 2 && a++;
    }),
    {
      watertight: t.triangles.length > 0 && c === 0 && a === 0,
      openEdges: c,
      nonManifoldEdges: a,
      volume: Math.abs(n),
      flipped: n < 0,
      area: e,
    }
  );
}
function E(t) {
  const o =
      t.byteLength >= 84 &&
      t.byteLength === 84 + new DataView(t).getUint32(80, !0) * 50,
    r = new TextDecoder().decode(t.slice(0, Math.min(t.byteLength, 1024))),
    n =
      /^\s*solid/i.test(r) &&
      /facet\s+normal\s+\S+\s+\S+\s+\S+\s+outer\s+loop\s+vertex/i.test(r);
  return o && !n ? "binary" : "ascii";
}
function J(t) {
  if (t.byteLength === 0)
    return { ok: !1, reason: "Not a valid STL: the file is empty." };
  const o = E(t);
  if (o === "ascii" && t.byteLength >= 84) {
    const n = new DataView(t).getUint32(80, !0),
      e = new TextDecoder().decode(t.slice(0, 1024));
    if (n > 0 && !/facet|vertex/i.test(e)) {
      const i = Math.floor((t.byteLength - 84) / 50);
      if (t.byteLength < 84 + n * 50 && n < 1e8)
        return {
          ok: !1,
          reason: `Not a valid STL: it looks like a binary STL that is cut off (the header lists ${n.toLocaleString()} triangles, the file holds ${i.toLocaleString()}).`,
        };
    }
  }
  let r;
  try {
    r = P(t);
  } catch {
    return { ok: !1, reason: "Not a valid STL: the file could not be read." };
  }
  return r.triangles.length === 0
    ? {
        ok: !1,
        reason:
          o === "ascii"
            ? 'Not a valid STL: no facets found. An ASCII STL needs lines like "facet normal" and "vertex x y z".'
            : "Not a valid STL: the file lists no triangles.",
      }
    : r.vertices.every(Number.isFinite)
      ? { ok: !0, format: o, mesh: r, triangleCount: r.triangles.length }
      : {
          ok: !1,
          reason:
            "Not a valid STL: it contains coordinates that are not numbers.",
        };
}
function P(t) {
  return E(t) === "binary" ? B(t) : C(new TextDecoder().decode(t));
}
function B(t) {
  const o = new DataView(t),
    r = o.getUint32(80, !0),
    n = [],
    e = [];
  let i = 84;
  for (let c = 0; c < r; c++) {
    i += 12;
    const a = n.length / 3;
    for (let f = 0; f < 3; f++)
      (n.push(
        o.getFloat32(i, !0),
        o.getFloat32(i + 4, !0),
        o.getFloat32(i + 8, !0),
      ),
        (i += 12));
    (e.push([a, a + 1, a + 2]), (i += 2));
  }
  return { vertices: n, triangles: e };
}
function C(t) {
  const o = [],
    r = [],
    n = /vertex\s+([-\d.eE+]+)\s+([-\d.eE+]+)\s+([-\d.eE+]+)/g;
  let e,
    i = [];
  for (; (e = n.exec(t)) !== null;)
    if (
      (i.push(parseFloat(e[1]), parseFloat(e[2]), parseFloat(e[3])),
      i.length === 9)
    ) {
      const c = o.length / 3;
      (o.push(...i), r.push([c, c + 1, c + 2]), (i = []));
    }
  return { vertices: o, triangles: r };
}
function W(t, o = "mesh") {
  let r = `solid ${o}
`;
  for (const [n, e, i] of t.triangles) {
    const c = z(t, n, e, i);
    r += `  facet normal ${c.map(L).join(" ")}
    outer loop
`;
    for (const a of [n, e, i])
      r += `      vertex ${L(t.vertices[a * 3])} ${L(t.vertices[a * 3 + 1])} ${L(t.vertices[a * 3 + 2])}
`;
    r += `    endloop
  endfacet
`;
  }
  return (
    (r += `endsolid ${o}
`),
    r
  );
}
function Z(t) {
  const o = t.triangles.length,
    r = new ArrayBuffer(84 + o * 50),
    n = new DataView(r);
  (new Uint8Array(r, 0, 40).set(
    new TextEncoder().encode("Binary STL by FreeDailyPro"),
  ),
    n.setUint32(80, o, !0));
  let e = 84;
  for (const [i, c, a] of t.triangles) {
    const f = z(t, i, c, a);
    (n.setFloat32(e, f[0], !0),
      n.setFloat32(e + 4, f[1], !0),
      n.setFloat32(e + 8, f[2], !0),
      (e += 12));
    for (const g of [i, c, a])
      (n.setFloat32(e, t.vertices[g * 3], !0),
        n.setFloat32(e + 4, t.vertices[g * 3 + 1], !0),
        n.setFloat32(e + 8, t.vertices[g * 3 + 2], !0),
        (e += 12));
    (n.setUint16(e, 0, !0), (e += 2));
  }
  return r;
}
function R(t) {
  const o = [],
    r = [];
  for (const n of t.split(/\r?\n/)) {
    const e = n.trim();
    if (e.startsWith("v ")) {
      const i = e.split(/\s+/),
        c = parseFloat(i[1]),
        a = parseFloat(i[2]),
        f = parseFloat(i[3]);
      if (![c, a, f].every(Number.isFinite))
        throw new Error(
          "OBJ has a vertex with a missing or invalid coordinate",
        );
      o.push(c, a, f);
    } else if (e.startsWith("f ")) {
      const i = o.length / 3,
        c = e
          .split(/\s+/)
          .slice(1)
          .map((a) => {
            const f = parseInt(a.split("/")[0], 10);
            return f < 0 ? i + f : f - 1;
          });
      if (c.some((a) => !Number.isInteger(a) || a < 0 || a >= i))
        throw new Error("OBJ face points at a vertex that doesn't exist");
      for (let a = 1; a < c.length - 1; a++) r.push([c[0], c[a], c[a + 1]]);
    }
  }
  return { vertices: o, triangles: r };
}
function X(t) {
  let o = `# exported by FreeDailyPro 3D Mesh Converter
`;
  for (let r = 0; r < t.vertices.length; r += 3)
    o += `v ${L(t.vertices[r])} ${L(t.vertices[r + 1])} ${L(t.vertices[r + 2])}
`;
  for (const [r, n, e] of t.triangles)
    o += `f ${r + 1} ${n + 1} ${e + 1}
`;
  return o;
}
const O = {
  char: 1,
  int8: 1,
  uchar: 1,
  uint8: 1,
  short: 2,
  int16: 2,
  ushort: 2,
  uint16: 2,
  int: 4,
  int32: 4,
  uint: 4,
  uint32: 4,
  float: 4,
  float32: 4,
  double: 8,
  float64: 8,
};
function q(t) {
  const o = new Uint8Array(t),
    r = (() => {
      const l = "end_header",
        s = new TextDecoder("latin1").decode(
          o.subarray(0, Math.min(o.length, 65536)),
        ),
        u = s.indexOf(l);
      if (u < 0) throw new Error("Not a PLY file: no end_header");
      let y = u + l.length;
      return (
        s[y] === "\r" && y++,
        s[y] ===
          `
` && y++,
        { header: s.slice(0, u), body: y }
      );
    })(),
    n = r.header.split(/\r?\n/).map((l) => l.trim());
  if (n[0] !== "ply") throw new Error("Not a PLY file");
  const e = (n.find((l) => l.startsWith("format ")) ?? "").split(/\s+/)[1];
  if (!["ascii", "binary_little_endian", "binary_big_endian"].includes(e))
    throw new Error("Unknown PLY format");
  const i = [];
  for (const l of n) {
    const s = l.split(/\s+/);
    if (s[0] === "element")
      i.push({ name: s[1], count: parseInt(s[2], 10), props: [] });
    else if (s[0] === "property" && i.length) {
      const u = i[i.length - 1];
      s[1] === "list"
        ? u.props.push({
            name: s[4],
            type: s[3],
            list: { count: s[2], item: s[3] },
          })
        : u.props.push({ name: s[2], type: s[1] });
    }
  }
  const c = [],
    a = [],
    f = (l) => {
      for (let s = 1; s < l.length - 1; s++) a.push([l[0], l[s], l[s + 1]]);
    };
  if (e === "ascii") {
    const l = new TextDecoder().decode(o.subarray(r.body)).split(/\r?\n/);
    let s = 0;
    for (const u of i)
      for (let y = 0; y < u.count; y++, s++) {
        const d = (l[s] ?? "").trim().split(/\s+/);
        if (u.name === "vertex") {
          const v = u.props.findIndex((x) => x.name === "x"),
            p = u.props.findIndex((x) => x.name === "y"),
            w = u.props.findIndex((x) => x.name === "z");
          c.push(parseFloat(d[v]), parseFloat(d[p]), parseFloat(d[w]));
        } else if (u.name === "face") {
          let v = 0;
          for (const p of u.props)
            if (p.list) {
              const w = Number(d[v++]),
                x = d.slice(v, v + w).map(Number);
              ((v += w),
                (p.name === "vertex_indices" || p.name === "vertex_index") &&
                  f(x));
            } else v++;
        }
      }
  } else {
    const l = e === "binary_little_endian",
      s = new DataView(t, r.body);
    let u = 0;
    const y = (d) => {
      const v = O[d];
      if (!v) throw new Error(`Unsupported PLY property type ${d}`);
      if (u + v > s.byteLength) throw new Error("PLY file is truncated");
      let p;
      switch (d) {
        case "char":
        case "int8":
          p = s.getInt8(u);
          break;
        case "uchar":
        case "uint8":
          p = s.getUint8(u);
          break;
        case "short":
        case "int16":
          p = s.getInt16(u, l);
          break;
        case "ushort":
        case "uint16":
          p = s.getUint16(u, l);
          break;
        case "int":
        case "int32":
          p = s.getInt32(u, l);
          break;
        case "uint":
        case "uint32":
          p = s.getUint32(u, l);
          break;
        case "float":
        case "float32":
          p = s.getFloat32(u, l);
          break;
        default:
          p = s.getFloat64(u, l);
      }
      return ((u += v), p);
    };
    for (const d of i)
      for (let v = 0; v < d.count; v++) {
        const p = {};
        for (const w of d.props)
          if (w.list) {
            const x = y(w.list.count),
              b = [];
            for (let $ = 0; $ < x; $++) b.push(y(w.list.item));
            d.name === "face" &&
              (w.name === "vertex_indices" || w.name === "vertex_index") &&
              f(b);
          } else p[w.name] = y(w.type);
        d.name === "vertex" && c.push(p.x, p.y, p.z);
      }
  }
  const g = c.length / 3;
  if (c.some((l) => !Number.isFinite(l)))
    throw new Error("PLY vertex data is invalid");
  if (a.some((l) => l.some((s) => !Number.isInteger(s) || s < 0 || s >= g)))
    throw new Error("PLY face points at a vertex that doesn't exist");
  return { vertices: c, triangles: a };
}
function G(t) {
  const o = t.vertices.length / 3,
    r = new TextEncoder().encode(`ply
format binary_little_endian 1.0
comment exported by FreeDailyPro 3D Mesh Converter
element vertex ${o}
property float x
property float y
property float z
element face ${t.triangles.length}
property list uchar int vertex_indices
end_header
`),
    n = new ArrayBuffer(r.length + o * 12 + t.triangles.length * 13);
  new Uint8Array(n).set(r);
  const e = new DataView(n);
  let i = r.length;
  for (const c of t.vertices) (e.setFloat32(i, c, !0), (i += 4));
  for (const [c, a, f] of t.triangles)
    (e.setUint8(i++, 3),
      e.setInt32(i, c, !0),
      e.setInt32(i + 4, a, !0),
      e.setInt32(i + 8, f, !0),
      (i += 12));
  return n;
}
function H(t) {
  const o = t.vertices.length / 3;
  let r = `ply
format ascii 1.0
comment exported by FreeDailyPro 3D Mesh Converter
`;
  ((r += `element vertex ${o}
property float x
property float y
property float z
`),
    (r += `element face ${t.triangles.length}
property list uchar int vertex_indices
end_header
`));
  for (let n = 0; n < t.vertices.length; n += 3)
    r += `${L(t.vertices[n])} ${L(t.vertices[n + 1])} ${L(t.vertices[n + 2])}
`;
  for (const [n, e, i] of t.triangles)
    r += `3 ${n} ${e} ${i}
`;
  return r;
}
function K(t) {
  const o = t.vertices.length / 3,
    r = t.triangles.length * 3,
    n = o <= 65535,
    e = n ? new Uint16Array(r) : new Uint32Array(r);
  let i = 0;
  for (const [m, S, I] of t.triangles)
    ((e[i++] = m), (e[i++] = S), (e[i++] = I));
  const c = new Float32Array(t.vertices);
  let a = 1 / 0,
    f = 1 / 0,
    g = 1 / 0,
    l = -1 / 0,
    s = -1 / 0,
    u = -1 / 0;
  for (let m = 0; m < t.vertices.length; m += 3) {
    const S = t.vertices[m],
      I = t.vertices[m + 1],
      T = t.vertices[m + 2];
    (S < a && (a = S),
      S > l && (l = S),
      I < f && (f = I),
      I > s && (s = I),
      T < g && (g = T),
      T > u && (u = T));
  }
  const y = c.byteLength,
    d = e.byteLength,
    v = Math.ceil(y / 4) * 4,
    p = v + d,
    x = JSON.stringify({
      asset: { version: "2.0", generator: "FreeDailyPro 3D Mesh Converter" },
      scene: 0,
      scenes: [{ nodes: [0] }],
      nodes: [{ mesh: 0 }],
      meshes: [
        { primitives: [{ attributes: { POSITION: 0 }, indices: 1, mode: 4 }] },
      ],
      accessors: [
        {
          bufferView: 0,
          componentType: 5126,
          count: o,
          type: "VEC3",
          min: [a, f, g],
          max: [l, s, u],
        },
        {
          bufferView: 1,
          componentType: n ? 5123 : 5125,
          count: r,
          type: "SCALAR",
        },
      ],
      bufferViews: [
        { buffer: 0, byteOffset: 0, byteLength: y, target: 34962 },
        { buffer: 0, byteOffset: v, byteLength: d, target: 34963 },
      ],
      buffers: [{ byteLength: p }],
    }),
    b = new TextEncoder().encode(x),
    $ = (4 - (b.length % 4)) % 4,
    A = b.length + $,
    k = (4 - (p % 4)) % 4,
    D = p + k,
    M = 20 + A + 8 + D,
    U = new ArrayBuffer(M),
    F = new DataView(U);
  let h = 0;
  (F.setUint32(h, 1179937895, !0),
    (h += 4),
    F.setUint32(h, 2, !0),
    (h += 4),
    F.setUint32(h, M, !0),
    (h += 4),
    F.setUint32(h, A, !0),
    (h += 4),
    F.setUint32(h, 1313821514, !0),
    (h += 4),
    new Uint8Array(U, h, b.length).set(b),
    (h += b.length));
  for (let m = 0; m < $; m++) (F.setUint8(h, 32), h++);
  (F.setUint32(h, D, !0), (h += 4), F.setUint32(h, 5130562, !0), (h += 4));
  const _ = h;
  (new Uint8Array(U, h, c.byteLength).set(
    new Uint8Array(c.buffer, c.byteOffset, c.byteLength),
  ),
    new Uint8Array(U, h + v, e.byteLength).set(
      new Uint8Array(e.buffer, e.byteOffset, e.byteLength),
    ),
    (h = _ + p));
  for (let m = 0; m < k; m++) (F.setUint8(h, 0), h++);
  return U;
}
export {
  W as a,
  Y as b,
  j as c,
  X as d,
  G as e,
  H as f,
  K as g,
  R as h,
  q as i,
  N as m,
  P as p,
  V as s,
  J as v,
  Z as w,
};
//# sourceMappingURL=mesh3d-C14zW8wv.js.map
