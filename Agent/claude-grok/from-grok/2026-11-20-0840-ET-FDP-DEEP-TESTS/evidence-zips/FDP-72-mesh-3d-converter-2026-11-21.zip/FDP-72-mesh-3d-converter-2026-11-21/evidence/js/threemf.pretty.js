import { J as k } from "./jszip.min-CT0ZA6V1.js";
import "./vendor-react-D01g8YgM.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
const C = {
    micron: 0.001,
    millimeter: 1,
    centimeter: 10,
    inch: 25.4,
    foot: 304.8,
    meter: 1e3,
  },
  D = [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],
  A = (t) => {
    if (!t) return D;
    const o = t.trim().split(/\s+/).map(Number);
    return o.length === 12 && o.every(Number.isFinite) ? o : D;
  },
  _ = (t, o) => {
    const n = (m, a) =>
      m < 3
        ? t[m * 3] * o[a] + t[m * 3 + 1] * o[3 + a] + t[m * 3 + 2] * o[6 + a]
        : t[9] * o[a] + t[10] * o[3 + a] + t[11] * o[6 + a] + o[9 + a];
    return [
      n(0, 0),
      n(0, 1),
      n(0, 2),
      n(1, 0),
      n(1, 1),
      n(1, 2),
      n(2, 0),
      n(2, 1),
      n(2, 2),
      n(3, 0),
      n(3, 1),
      n(3, 2),
    ];
  },
  l = (t, o) =>
    t.getAttribute(o) ??
    t.getAttributeNS("*", o) ??
    Array.from(t.attributes).find((n) => n.localName === o)?.value ??
    null,
  w = (t, o) => Array.from(t.getElementsByTagNameNS("*", o));
function $(t) {
  const o = new DOMParser().parseFromString(t, "application/xml");
  if (o.getElementsByTagName("parsererror").length)
    throw new Error("This 3MF file's model XML is damaged");
  const n = o.documentElement,
    m = C[(l(n, "unit") || "millimeter").toLowerCase()] ?? 1,
    a = new Map();
  for (const s of w(n, "object")) {
    const r = l(s, "id");
    if (r === null) continue;
    const f = { type: (l(s, "type") || "model").toLowerCase() },
      v = w(s, "mesh")[0];
    if (v) {
      ((f.verts = []), (f.tris = []));
      for (const d of w(v, "vertex"))
        f.verts.push(Number(l(d, "x")), Number(l(d, "y")), Number(l(d, "z")));
      for (const d of w(v, "triangle"))
        f.tris.push(Number(l(d, "v1")), Number(l(d, "v2")), Number(l(d, "v3")));
    }
    const b = w(s, "component");
    (b.length &&
      (f.comps = b.map((d) => ({
        id: l(d, "objectid") || "",
        path: l(d, "path"),
        m: A(l(d, "transform")),
      }))),
      a.set(r, f));
  }
  const T = w(n, "item").map((s) => ({
    id: l(s, "objectid") || "",
    path: l(s, "path"),
    m: A(l(s, "transform")),
  }));
  return { objects: a, build: T, unit: m };
}
async function I(t) {
  const o = await k.loadAsync(t),
    n = async (c) => {
      const x = o.file(c) ?? o.file(c.replace(/^\//, ""));
      return x ? x.async("text") : null;
    };
  let m = "3D/3dmodel.model";
  const a = await n("_rels/.rels");
  if (a) {
    const c =
        /Type="[^"]*3dmodel"[^>]*Target="([^"]+)"|Target="([^"]+)"[^>]*Type="[^"]*3dmodel"/.exec(
          a,
        ),
      x = c?.[1] ?? c?.[2];
    x && (m = x.replace(/^\//, ""));
  }
  const T = await n(m);
  if (!T)
    throw new Error("This doesn't look like a 3MF file (no 3D model inside)");
  const s = $(T),
    r = new Map([[m, s]]),
    f = [],
    v = [],
    b = s.unit,
    d = 8,
    E = async (c, x, e, F) => {
      if (F > d) throw new Error("This 3MF nests its parts too deeply to read");
      let N = r.get(c);
      if (!N) {
        const p = await n(c);
        if (!p) return;
        ((N = $(p)), r.set(c, N));
      }
      const i = N.objects.get(x);
      if (!(
        !i ||
        i.type === "support" ||
        i.type === "solidsupport" ||
        i.type === "surface"
      )) {
        if (i.verts && i.tris && i.type !== "other") {
          const p = f.length / 3;
          for (let u = 0; u < i.verts.length; u += 3) {
            const g = i.verts[u],
              h = i.verts[u + 1],
              y = i.verts[u + 2];
            f.push(
              (g * e[0] + h * e[3] + y * e[6] + e[9]) * b,
              (g * e[1] + h * e[4] + y * e[7] + e[10]) * b,
              (g * e[2] + h * e[5] + y * e[8] + e[11]) * b,
            );
          }
          const M = i.verts.length / 3,
            j =
              e[0] * (e[4] * e[8] - e[5] * e[7]) -
              e[1] * (e[3] * e[8] - e[5] * e[6]) +
              e[2] * (e[3] * e[7] - e[4] * e[6]);
          for (let u = 0; u < i.tris.length; u += 3) {
            const g = i.tris[u],
              h = i.tris[u + 1],
              y = i.tris[u + 2];
            g < M &&
              h < M &&
              y < M &&
              g >= 0 &&
              h >= 0 &&
              y >= 0 &&
              v.push(j < 0 ? [p + g, p + y, p + h] : [p + g, p + h, p + y]);
          }
        }
        for (const p of i.comps ?? [])
          await E(
            p.path ? p.path.replace(/^\//, "") : c,
            p.id,
            _(p.m, e),
            F + 1,
          );
      }
    };
  for (const c of s.build)
    await E(c.path ? c.path.replace(/^\//, "") : m, c.id, c.m, 0);
  if (!v.length)
    throw new Error("No printable geometry found in this 3MF file");
  return { vertices: f, triangles: v };
}
async function O(t, o = "model") {
  const n = (r) => r.replace(/[<>&"]/g, ""),
    m = [];
  for (let r = 0; r < t.vertices.length; r += 3)
    m.push(
      `<vertex x="${t.vertices[r]}" y="${t.vertices[r + 1]}" z="${t.vertices[r + 2]}"/>`,
    );
  const a = t.triangles.map(
      (r) => `<triangle v1="${r[0]}" v2="${r[1]}" v3="${r[2]}"/>`,
    ),
    T = `<?xml version="1.0" encoding="UTF-8"?>
<model unit="millimeter" xml:lang="en-US" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02"><metadata name="Title">${n(o)}</metadata><metadata name="Application">FreeDailyPro 3D Mesh Converter</metadata><resources><object id="1" type="model"><mesh><vertices>${m.join("")}</vertices><triangles>${a.join("")}</triangles></mesh></object></resources><build><item objectid="1"/></build></model>`,
    s = new k();
  return (
    s.file(
      "[Content_Types].xml",
      `<?xml version="1.0" encoding="UTF-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>`,
    ),
    s.file(
      "_rels/.rels",
      `<?xml version="1.0" encoding="UTF-8"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>`,
    ),
    s.file("3D/3dmodel.model", T),
    s.generateAsync({
      type: "blob",
      mimeType: "application/vnd.ms-package.3dmanufacturing-3dmodel+xml",
      compression: "DEFLATE",
    })
  );
}
export { I as parse3MF, O as write3MF };
//# sourceMappingURL=threemf-Cq05XjYJ.js.map
