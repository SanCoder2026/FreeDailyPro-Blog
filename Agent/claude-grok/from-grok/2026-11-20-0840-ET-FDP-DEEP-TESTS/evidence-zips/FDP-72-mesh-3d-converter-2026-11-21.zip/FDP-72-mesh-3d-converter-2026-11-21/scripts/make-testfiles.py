#!/usr/bin/env python3
"""FDP-72 3D Mesh Converter test files (needs trimesh, numpy, lxml). Run inside testfiles/.
cube20: 20 mm cube (12 tris, watertight, volume 8000 mm3, area 2400 mm2)
sphere: icosphere subdiv 3, r=10 (1280 tris); scan: icosphere subdiv 6, r=50 (81920 tris, for Reduce triangles)
openbox: cube20 without its top (10 tris, 1 hole of 4 edges); fin: cube20 + one extra triangle on an edge (non-manifold edge)
Formats: STL bin/ascii, OBJ, PLY bin (little + big endian)/ascii, GLB, 3MF; plus a .gltf (should be refused) and a non-mesh file.
"""
import trimesh, numpy as np
cube = trimesh.creation.box(extents=(20, 20, 20)); cube.apply_translation((10, 10, 10))
sphere = trimesh.creation.icosphere(subdivisions=3, radius=10)
scan = trimesh.creation.icosphere(subdivisions=6, radius=50)
top = [i for i, n in enumerate(cube.face_normals) if n[2] > 0.9]
openbox = trimesh.Trimesh(cube.vertices, np.delete(cube.faces, top, axis=0), process=False)
v = np.vstack([cube.vertices, [[10, 30, 40]]]); e = cube.edges_unique[0]
fin = trimesh.Trimesh(v, np.vstack([cube.faces, [[e[0], e[1], len(v) - 1]]]), process=False)
for name, m in [('cube20', cube), ('sphere', sphere), ('openbox', openbox), ('fin', fin)]:
    m.export(f'{name}-bin.stl'); open(f'{name}-ascii.stl', 'wb').write(trimesh.exchange.stl.export_stl_ascii(m).encode())
for name, m in [('cube20', cube), ('sphere', sphere), ('openbox', openbox)]:
    m.export(f'{name}.obj'); m.export(f'{name}-bin.ply', encoding='binary'); m.export(f'{name}-ascii.ply', encoding='ascii'); m.export(f'{name}.glb'); m.export(f'{name}.3mf')
scan.export('scan-81920.stl')
# big-endian binary PLY of the cube
vv = cube.vertices.astype('>f4'); ff = cube.faces
hdr = f"ply\nformat binary_big_endian 1.0\nelement vertex {len(vv)}\nproperty float x\nproperty float y\nproperty float z\nelement face {len(ff)}\nproperty list uchar int vertex_indices\nend_header\n".encode()
body = vv.tobytes() + b''.join(np.uint8(3).tobytes() + f.astype('>i4').tobytes() for f in ff)
open('cube20-bin-be.ply', 'wb').write(hdr + body)
open('cube20.gltf', 'w').write(trimesh.exchange.gltf.export_gltf(cube)['model.gltf'].decode())
open('not-mesh.stl', 'w').write('hello, not a mesh\n')
