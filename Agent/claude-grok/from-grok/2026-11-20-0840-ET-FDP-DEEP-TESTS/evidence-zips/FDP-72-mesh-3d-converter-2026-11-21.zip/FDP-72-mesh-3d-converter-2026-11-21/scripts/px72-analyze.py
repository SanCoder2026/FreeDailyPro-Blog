# FDP-72: analyse a mesh output with trimesh (+ raw header checks): format, triangles, vertices, watertight, volume, extents, STL normals, GLB/3MF unit scale.
import sys, json, struct, zipfile, trimesh, numpy as np
def an(f):
    r = {'file': f.split('/')[-1]}; b = open(f, 'rb').read(); ext = f.rsplit('.', 1)[-1].lower()
    if ext == 'stl':
        r['stl'] = 'ascii' if b[:5].lower() == b'solid' and b'facet' in b[:400] else 'binary'
        if r['stl'] == 'binary':
            n = struct.unpack('<I', b[80:84])[0]; r['stl_count'] = n; r['size_ok'] = len(b) == 84 + 50 * n
            nm = np.frombuffer(b[84:84 + 50 * n], dtype=np.dtype([('n', '<f4', 3), ('v', '<f4', 9), ('a', '<u2')]))['n']; r['normals_nonzero'] = bool(np.all(np.linalg.norm(nm, axis=1) > 0.5))
    if ext == 'ply': r['ply_header'] = b[:b.find(b'end_header')].decode(errors='replace').split('\n')[1]
    if ext == '3mf':
        z = zipfile.ZipFile(f); r['3mf_entries'] = z.namelist(); mdl = [n for n in z.namelist() if n.endswith('.model')]
        if mdl: x = z.read(mdl[0]).decode(errors='replace'); i = x.find('unit='); r['3mf_unit'] = x[i:i + 20] if i >= 0 else None
    if ext == 'obj': t = b.decode(errors='replace').split('\n'); r['obj_lines'] = {k: sum(1 for l in t if l.startswith(k + ' ')) for k in ('v', 'vn', 'vt', 'f')}
    try:
        m = trimesh.load(f, force='mesh', process=False); m2 = m.copy(); m2.merge_vertices()
        r.update({'tris': int(len(m.faces)), 'verts': int(len(m.vertices)), 'watertight': bool(m2.is_watertight), 'volume': round(float(m2.volume), 4) if m2.is_watertight else None, 'area': round(float(m2.area), 4), 'extents': [round(float(e), 5) for e in m.extents]})
    except Exception as e: r['load_err'] = str(e)[:120]
    return r
print(json.dumps([an(f) for f in sys.argv[1:]]))
