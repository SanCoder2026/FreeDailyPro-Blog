Sent: 2026-11-21 20:04 ET

# FDP-73 catalog-maker: rerun after the 7:00 PM ET reset (Nov 21 2026)

Run 19:57-19:59 ET `TRIES=40 px73-live.js left firefox`, fresh Firefox; found one context with uses left at try 1 ("tries 2/2,0/2").
- L01 first catalog build + Download `Spring_2026_Product_Catalog.pdf` (5 pages): display **0/2 -> 2/2** with one usage.log (the jump to the cap repeats, 100% of the time so far, 2 of 2 runs).
- L02 same download again: free. L03/L05 edited builds (price $13.00 and $35.00) built fine; L06 combine (sheet-letter-2p.pdf + pricelist.docx -> 5 pages, "Supplier Catalog 2026") built.
- L07 combine re-download at 2/2: **cap dialog** ("To keep using Premium Applications, pick Monthly for $9.99, or a Day Pass for $3"). So one download uses both Premium uses on the display (answering the question: no second edited catalog download was attempted after L01 in this script beyond the combine; the edited builds L03/L05 were built but their downloads were not run).
- Whether the server `...:premium` count is 2 after one download is not verifiable from the client (display only).
Evidence: rr/73.log.

(Rows run in order: 4,5,7,8,11,14,20 then 28-33,40,56,57,69,73. No sign-in, no payment, no ads clicked, no admin, no API/MCP. Counters are display-only evidence.)
