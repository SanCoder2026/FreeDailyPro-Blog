import { r as i, j as e } from "./vendor-react-D01g8YgM.js";
import { P as Ue } from "./ProfileBar-BPOawnEt.js";
import {
  e as m,
  B,
  I as x,
  T as ve,
  f as v,
  aG as Pe,
  aH as Me,
  dq as De,
  dr as ze,
  c9 as He,
  aU as Ve,
} from "./index-B1CTyGtY.js";
import { p as Ae } from "./utils-s8ucLyj8.js";
import {
  h as _e,
  f as Ge,
  P as qe,
  D as Le,
  R as $e,
  T as We,
  F as Te,
} from "./ToolPage-DwLoDncN.js";
import { C as $ } from "./checkbox-Ml1pfDb3.js";
import { S as H, a as V, b as _, c as G, d as N } from "./select-ic5yaeGw.js";
import { C as ae } from "./card-KXKUZKW8.js";
import { R as Ke } from "./ReorderableFileList-BhqJ-ECL.js";
import { normalizeImageFile as ke } from "./imagePdf-Dtz8PQyf.js";
import { B as Be, a as Je } from "./bookAssembly-DmpTM49o.js";
import { C as Qe } from "./money-Dkxewa8a.js";
import { d as Ye, p as Ze, a as Xe } from "./csvParse-eP1CzDn2.js";
import {
  v as et,
  p as we,
  c as tt,
  a as Ee,
  s as Re,
  b as at,
  d as st,
  e as rt,
  f as ot,
  n as lt,
  g as it,
  M as nt,
  h as ct,
} from "./productCatalog-CL4Qj03q.js";
import { b as Fe, s as dt, d as mt } from "./localFiles-BJNBw6au.js";
import { T as ut } from "./trash-2-CmoDM6Qu.js";
import { I as pt } from "./image-plus-XffUX0hB.js";
import { B as xt } from "./codeGeneration-D1g4LVfX.js";
import { f as gt } from "./reorderMath-CVj9Q6Gj.js";
import "./EmbedContext-CCnUNY-R.js";
import "./logoFile-BxMwsj0a.js";
import "./eraser-DVBgSK_0.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-DhOoIDuZ.js";
import "./index-BdQq_4o_.js";
import "./chevron-up-BDUcPssj.js";
import "./formatFileSize-B-JRDfN5.js";
import "./grip-vertical-Dzkp2Q5V.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./pdfMetadata-CcxIhQF2.js";
import "./fontkit.es-DA-3qwB1.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./pageView-BQIwVYOi.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./formAppearance-CdNbuISd.js";
import "./drawTextAnywhere-DcuP6lHH.js";
import "./pdfText-bjh9eBB-.js";
import "./numberInput-5hjoxJ5z.js";
import "./JsBarcode-QeG8kXh7.js";
import "./browser-CMr8NRjw.js";
import "./qrHelpers-av3Dz-dA.js";
const ht = [
    {
      id: "line-sheet",
      name: "Wholesale line sheet",
      blurb: "3 per row, price list and minimum orders at the end.",
      columns: 3,
      page: "letter",
      accent: "#0f766e",
      cover: !0,
      contents: !0,
      priceList: !0,
      categoryHints: ["Best sellers", "New arrivals"],
    },
    {
      id: "lookbook",
      name: "Maker's lookbook",
      blurb: "2 larger cards per row, no price list: lead with the photos.",
      columns: 2,
      page: "a4",
      accent: "#be123c",
      cover: !0,
      contents: !1,
      priceList: !1,
      categoryHints: ["Spring collection", "Gift sets"],
    },
    {
      id: "price-list",
      name: "Compact price catalog",
      blurb: "3 per row, no cover: a quick reference sheet with prices.",
      columns: 3,
      page: "letter",
      accent: "#1d4ed8",
      cover: !1,
      contents: !0,
      priceList: !0,
      categoryHints: ["Hardware", "Accessories"],
    },
  ],
  Se = "freedailypro-catalog",
  y = (l, c = 5e3) => (typeof l == "string" ? l.slice(0, c) : ""),
  Ie = (l) =>
    typeof l == "string" &&
    /^data:image\/(png|jpeg|jpg);base64,[A-Za-z0-9+/=]+$/.test(l)
      ? l
      : "",
  ft = (l, c) => (typeof l == "string" && /^#[0-9a-f]{6}$/i.test(l) ? l : c);
function vt(l, c = new Date()) {
  const n = { app: Se, version: 1, savedAt: c.toISOString(), ...l };
  return JSON.stringify(n, null, 2);
}
function jt(l) {
  let c;
  try {
    c = JSON.parse(l);
  } catch {
    return {
      ok: !1,
      error: "That file is not a saved catalog (it could not be read as JSON).",
    };
  }
  const n = c;
  if (!n || typeof n != "object" || n.app !== Se)
    return { ok: !1, error: "That file is not a saved FreeDailyPro catalog." };
  if (n.version !== 1)
    return {
      ok: !1,
      error:
        "That catalog file is from a newer version and cannot be opened here.",
    };
  if (!Array.isArray(n.products))
    return { ok: !1, error: "That catalog file has no product list." };
  if (n.products.length > 2e3)
    return { ok: !1, error: "That catalog has more than 2,000 products." };
  const b = n.tax && typeof n.tax == "object" ? n.tax : {},
    C = b.mode === "excl" || b.mode === "incl" ? b.mode : "none",
    w = n.products.map((f) => {
      const g = f && typeof f == "object" ? f : {};
      return {
        name: y(g.name, 300),
        sku: y(g.sku, 100),
        price: y(g.price, 40),
        category: y(g.category, 200),
        description: y(g.description, 2e3),
        moq: y(g.moq, 20),
        url: y(g.url, 500),
        taxRate: y(g.taxRate, 10),
        image: Ie(g.image),
      };
    });
  return {
    ok: !0,
    project: {
      app: Se,
      version: 1,
      savedAt: y(n.savedAt, 40),
      title: y(n.title, 300),
      company: y(n.company, 300),
      currency: y(n.currency, 3) || "USD",
      columns: n.columns === 3 ? 3 : 2,
      page: n.page === "a4" ? "a4" : "letter",
      accent: ft(n.accent, "#4f46e5"),
      cover: n.cover !== !1,
      contents: n.contents !== !1,
      priceList: n.priceList !== !1,
      tax: { mode: C, rate: y(b.rate, 10) },
      logo: Ie(n.logo),
      products: w,
    },
  };
}
let bt = 1;
const te = (l = "") => ({
    id: bt++,
    name: "",
    sku: "",
    price: "",
    category: l,
    description: "",
    moq: "",
    url: "",
    taxRate: "",
  }),
  Ct = {
    name: "name",
    product: "name",
    title: "name",
    "product name": "name",
    item: "name",
    sku: "sku",
    code: "sku",
    "item code": "sku",
    "product code": "sku",
    id: "sku",
    price: "price",
    cost: "price",
    amount: "price",
    category: "category",
    group: "category",
    type: "category",
    section: "category",
    description: "description",
    details: "description",
    desc: "description",
    notes: "description",
    moq: "moq",
    "min order": "moq",
    "minimum order": "moq",
    "minimum order quantity": "moq",
    "min qty": "moq",
    url: "url",
    link: "url",
    "product url": "url",
    "product link": "url",
    "order link": "url",
    "buy link": "url",
    website: "url",
  };
function yt(l) {
  return ct(Ze(l.replace(/^\uFEFF/, ""), Xe(l)), Ct);
}
async function Nt(l) {
  try {
    const c = await createImageBitmap(l),
      { width: n, height: b } = it(c.width, c.height, nt);
    if (n === c.width && b === c.height) return (c.close?.(), l);
    const C = document.createElement("canvas");
    ((C.width = n), (C.height = b));
    const w = l.type === "image/png",
      f = C.getContext("2d");
    (w || ((f.fillStyle = "#fff"), f.fillRect(0, 0, n, b)),
      f.drawImage(c, 0, 0, n, b),
      c.close?.());
    const g = await new Promise((O) =>
      C.toBlob(O, w ? "image/png" : "image/jpeg", 0.88),
    );
    return g
      ? new File([g], l.name, { type: w ? "image/png" : "image/jpeg" })
      : l;
  } catch {
    return l;
  }
}
function wt() {
  const [l, c] = i.useState(() => [te(), te()]),
    [n, b] = i.useState(""),
    [C, w] = i.useState(""),
    [f, g] = i.useState("USD"),
    [O, R] = i.useState("2"),
    [se, W] = i.useState("letter"),
    [re, U] = i.useState("#4f46e5"),
    [K, J] = i.useState(!0),
    [oe, M] = i.useState(!0),
    [le, Q] = i.useState(""),
    [je, Y] = i.useState(!1),
    [ie, D] = i.useState(!0),
    [S, I] = i.useState("none"),
    [E, ne] = i.useState(""),
    [ce, A] = i.useState(""),
    [pe, q] = i.useState(""),
    [P, d] = i.useState(null),
    [Z, be] = i.useState(!1),
    [X, xe] = i.useState(null),
    { toolId: ge } = _e(),
    z = i.useRef(new Set()),
    r = et(l, n, K),
    de = Z && r.noProducts,
    ee = Z && r.title,
    he = (t) => {
      (R(String(t.columns)),
        W(t.page),
        U(t.accent),
        J(t.cover),
        M(t.contents),
        D(t.priceList),
        c((a) =>
          a.map((o, u) =>
            t.categoryHints[u] ? { ...o, categoryHint: t.categoryHints[u] } : o,
          ),
        ),
        d(null),
        v.success(
          `${t.name} layout applied. Add your products, then Build Catalog.`,
        ));
    },
    k = (t, a) => {
      (c((o) => o.map((u) => (u.id === t ? { ...u, ...a } : u))), d(null));
    },
    Ce = l.length ? l[l.length - 1].category : "",
    ye = async (t, a) => {
      if (a)
        try {
          const o = await Nt(await ke(a)),
            u = new Uint8Array(await o.arrayBuffer());
          k(t, {
            image: {
              bytes: u,
              isPng: o.type === "image/png",
              url: URL.createObjectURL(o),
            },
          });
        } catch {
          v.error("That image couldn't be read. Try a JPG or PNG.");
        }
    },
    fe = (t) => {
      const a = yt(t);
      if (!a.rows.length) {
        (v.error(
          "No products found. Use columns: name, SKU, price, category, description.",
        ),
          xe({
            text: a.skippedNoName.length
              ? Re(a)
              : "No products found in that data.",
            warn: !0,
          }));
        return;
      }
      const o = a.rows.map((me) => ({ ...te(), ...me.product }));
      (c((me) => [
        ...me.filter(
          (ue) => ue.name || ue.sku || ue.price || ue.moq || ue.description,
        ),
        ...o,
      ]),
        Q(""),
        d(null));
      const u = Re(a),
        F = a.rows.some((me) => me.priceError) || a.skippedNoName.length > 0;
      (xe({
        text: F
          ? `${u}. Rows with a bad price are added and marked in red: fix them below.`
          : u,
        warn: F,
      }),
        F ? v.warning(u) : v.success(u));
    },
    Ne = async (t) => {
      if (!t) return;
      const a = Me(await t.text());
      if (!a.ok) {
        (q(a.error), v.error(a.error));
        return;
      }
      s(a.profile);
    },
    s = (t) => {
      const a = De(t);
      (a && U(a),
        t.logo && A(t.logo),
        t.name && !C.trim() && w(t.name),
        d(null),
        q(`Brand loaded${t.name ? `: ${t.name}` : ""}.`));
    },
    h = () => {
      const t = l
        .filter((a) => a.name.trim() || a.sku.trim() || a.price.trim())
        .map((a) => ({
          name: a.name,
          sku: a.sku,
          price: a.price,
          category: a.category,
          description: a.description,
          moq: a.moq,
          url: a.url,
          taxRate: a.taxRate,
          image: a.image ? Fe(a.image.bytes, a.image.isPng) : "",
        }));
      (dt(
        `${(n || "catalog").replace(/[^\w-]+/g, "_")}.catalog.json`,
        vt({
          title: n,
          company: C,
          currency: f,
          columns: Number(O),
          page: se,
          accent: re,
          cover: K,
          contents: oe,
          priceList: ie,
          tax: { mode: S, rate: E },
          logo: ce,
          products: t,
        }),
      ),
        q("Saved to your device. Open it again with Open saved catalog."));
    },
    j = async (t) => {
      if (!t) return;
      const a = jt(await t.text());
      if (!a.ok) {
        (q(a.error), v.error(a.error));
        return;
      }
      const o = a.project;
      (b(o.title),
        w(o.company),
        g(o.currency),
        R(String(o.columns)),
        W(o.page),
        U(o.accent),
        J(o.cover),
        M(o.contents),
        D(o.priceList),
        I(o.tax.mode),
        ne(o.tax.rate),
        A(o.logo),
        c(
          o.products.length
            ? o.products.map((u) => {
                const F = mt(u.image);
                return {
                  ...te(),
                  ...u,
                  image: F ? { ...F, url: u.image } : void 0,
                };
              })
            : [te()],
        ),
        d(null),
        q(
          `Opened ${o.products.length} product${o.products.length === 1 ? "" : "s"}.`,
        ));
    },
    p = we(E) ?? 0,
    T =
      S !== "none"
        ? tt(
            l
              .filter((t) => t.name.trim())
              .map((t) => ({ price: Ee(t.price), taxRate: t.taxRate })),
            p,
            S,
            f,
          )
        : null,
    L = async () => {
      if (
        (be(!0),
        r.noProducts ||
          r.title ||
          r.priceErrorCount > 0 ||
          r.moqErrorCount > 0 ||
          r.urlErrorCount > 0 ||
          Object.values(r.rows).some((a) => a.name))
      )
        return;
      const t = l
        .filter((a) => a.name.trim())
        .map((a) => ({
          name: a.name.trim(),
          sku: a.sku.trim(),
          price: Ee(a.price),
          category: a.category.trim(),
          description: a.description.trim(),
          moq: st(a.moq),
          url: at(a.url),
          image: a.image
            ? { bytes: a.image.bytes, isPng: a.image.isPng }
            : void 0,
          taxRate: a.taxRate.trim(),
        }));
      Y(!0);
      try {
        const a = {
            title: n.trim(),
            company: C.trim(),
            currency: f,
            columns: Number(O),
            page: se,
            cover: K,
            contents: oe,
            accent: re,
            priceList: ie,
            tax: S !== "none" ? { mode: S, rate: p } : void 0,
            logo: ze(ce) ?? void 0,
          },
          { bytes: o, pageCount: u, note: F } = await rt(t, a);
        (d({ blob: Ae(o), pages: u, hash: ot(t, a) }),
          v.success("Catalog ready!"),
          F && v.warning(F));
      } catch (a) {
        (console.error(a),
          v.error(
            a instanceof Error ? a.message : "Could not build the catalog",
          ));
      } finally {
        Y(!1);
      }
    },
    Oe = () => {
      P && lt(z.current, P.hash) && (z.current.add(P.hash), He(ge));
    };
  return e.jsxs("div", {
    className: "space-y-6",
    "data-testid": "product-catalog-builder",
    children: [
      e.jsxs("div", {
        className: "grid sm:grid-cols-2 gap-4",
        children: [
          e.jsxs("div", {
            className: "sm:col-span-2",
            children: [
              e.jsx(m, {
                className: "mb-2 block",
                children: "Start from a template (optional)",
              }),
              e.jsx("div", {
                className: "grid sm:grid-cols-3 gap-2",
                role: "group",
                "aria-label": "Starter templates",
                children: ht.map((t) =>
                  e.jsxs(
                    B,
                    {
                      type: "button",
                      variant: "outline",
                      className:
                        "h-auto py-2 flex-col items-start text-left whitespace-normal",
                      onClick: () => he(t),
                      children: [
                        e.jsx("span", {
                          className: "text-sm font-medium",
                          children: t.name,
                        }),
                        e.jsx("span", {
                          className:
                            "text-xs font-normal text-muted-foreground",
                          children: t.blurb,
                        }),
                      ],
                    },
                    t.id,
                  ),
                ),
              }),
            ],
          }),
          e.jsxs("div", {
            children: [
              e.jsx(m, { htmlFor: "pcb-title", children: "Catalog Title" }),
              e.jsx(x, {
                id: "pcb-title",
                "aria-invalid": ee || void 0,
                className: ee ? "border-destructive" : void 0,
                value: n,
                onChange: (t) => {
                  (b(t.target.value), d(null));
                },
                placeholder: "e.g. Spring 2026 Product Catalog",
              }),
              ee &&
                e.jsx("p", {
                  role: "alert",
                  className: "text-xs text-destructive mt-1",
                  children:
                    "Enter a catalog title, or turn off the cover page.",
                }),
            ],
          }),
          e.jsxs("div", {
            children: [
              e.jsx(m, { children: "Company Name" }),
              e.jsx(x, {
                "aria-label": "Company Name",
                value: C,
                onChange: (t) => {
                  (w(t.target.value), d(null));
                },
                placeholder: "Your company name",
              }),
            ],
          }),
        ],
      }),
      e.jsxs("div", {
        children: [
          e.jsx(m, { className: "mb-2 block", children: "Products" }),
          e.jsx("div", {
            className: "space-y-3",
            children: l.map((t, a) =>
              e.jsxs(
                ae,
                {
                  className: "p-3 space-y-2",
                  children: [
                    e.jsxs("div", {
                      className: "flex items-center gap-2",
                      children: [
                        e.jsxs("span", {
                          className:
                            "text-xs text-muted-foreground w-6 shrink-0",
                          children: [a + 1, "."],
                        }),
                        e.jsxs("div", {
                          className: "flex-1",
                          children: [
                            e.jsx(x, {
                              "aria-label": `Product ${a + 1} name`,
                              "aria-invalid":
                                !!r.rows[t.id]?.name ||
                                (de && a === 0) ||
                                void 0,
                              className:
                                r.rows[t.id]?.name || (de && a === 0)
                                  ? "border-destructive"
                                  : void 0,
                              value: t.name,
                              onChange: (o) =>
                                k(t.id, { name: o.target.value }),
                              placeholder: "Product name",
                            }),
                            Z &&
                              r.rows[t.id]?.name &&
                              e.jsx("p", {
                                role: "alert",
                                className: "text-xs text-destructive mt-1",
                                children: r.rows[t.id]?.name,
                              }),
                            de &&
                              a === 0 &&
                              e.jsx("p", {
                                role: "alert",
                                className: "text-xs text-destructive mt-1",
                                children:
                                  "Add a name for at least one product.",
                              }),
                          ],
                        }),
                        e.jsx(B, {
                          type: "button",
                          size: "icon",
                          variant: "ghost",
                          "aria-label": `Remove product ${a + 1}`,
                          onClick: () => {
                            (c((o) => o.filter((u) => u.id !== t.id)), d(null));
                          },
                          children: e.jsx(ut, { className: "h-4 w-4" }),
                        }),
                      ],
                    }),
                    e.jsxs("div", {
                      className:
                        "grid grid-cols-2 sm:grid-cols-4 gap-2 items-start",
                      children: [
                        e.jsx(x, {
                          "aria-label": `Product ${a + 1} SKU`,
                          value: t.sku,
                          onChange: (o) => k(t.id, { sku: o.target.value }),
                          placeholder: "SKU",
                        }),
                        e.jsxs("div", {
                          children: [
                            e.jsx(x, {
                              "aria-label": `Product ${a + 1} price`,
                              "aria-invalid": !!r.rows[t.id]?.price || void 0,
                              className: r.rows[t.id]?.price
                                ? "border-destructive"
                                : void 0,
                              value: t.price,
                              onChange: (o) =>
                                k(t.id, { price: o.target.value }),
                              placeholder: "Price",
                              inputMode: "decimal",
                            }),
                            r.rows[t.id]?.price &&
                              e.jsx("p", {
                                role: "alert",
                                className: "text-xs text-destructive mt-1",
                                children: r.rows[t.id]?.price,
                              }),
                          ],
                        }),
                        e.jsxs("div", {
                          children: [
                            e.jsx(x, {
                              "aria-label": `Product ${a + 1} minimum order quantity`,
                              "aria-invalid": !!r.rows[t.id]?.moq || void 0,
                              className: r.rows[t.id]?.moq
                                ? "border-destructive"
                                : void 0,
                              value: t.moq,
                              onChange: (o) => k(t.id, { moq: o.target.value }),
                              placeholder: "MOQ (optional)",
                              inputMode: "numeric",
                            }),
                            r.rows[t.id]?.moq &&
                              e.jsx("p", {
                                role: "alert",
                                className: "text-xs text-destructive mt-1",
                                children: r.rows[t.id]?.moq,
                              }),
                          ],
                        }),
                        e.jsx(x, {
                          "aria-label": `Product ${a + 1} category`,
                          value: t.category,
                          onChange: (o) =>
                            k(t.id, { category: o.target.value }),
                          placeholder: t.categoryHint
                            ? `Category, e.g. ${t.categoryHint}`
                            : "Category",
                        }),
                      ],
                    }),
                    e.jsxs("div", {
                      children: [
                        e.jsx(x, {
                          "aria-label": `Product ${a + 1} link`,
                          "aria-invalid": !!r.rows[t.id]?.url || void 0,
                          className: r.rows[t.id]?.url
                            ? "border-destructive"
                            : void 0,
                          value: t.url,
                          onChange: (o) => k(t.id, { url: o.target.value }),
                          placeholder:
                            "Order link (optional): printed as a link and a small QR code",
                          inputMode: "url",
                        }),
                        r.rows[t.id]?.url &&
                          e.jsx("p", {
                            role: "alert",
                            className: "text-xs text-destructive mt-1",
                            children: r.rows[t.id]?.url,
                          }),
                      ],
                    }),
                    S !== "none" &&
                      e.jsx(x, {
                        "aria-label": `Product ${a + 1} tax rate`,
                        value: t.taxRate,
                        onChange: (o) => k(t.id, { taxRate: o.target.value }),
                        placeholder: `Tax rate % (blank uses ${E || "0"}%)`,
                        inputMode: "decimal",
                        className: "max-w-xs",
                      }),
                    e.jsx(ve, {
                      "aria-label": `Product ${a + 1} description`,
                      value: t.description,
                      onChange: (o) => k(t.id, { description: o.target.value }),
                      placeholder: "Short description",
                      rows: 2,
                    }),
                    e.jsxs("div", {
                      className: "flex items-center gap-3",
                      children: [
                        e.jsxs("label", {
                          className:
                            "inline-flex items-center gap-2 text-xs cursor-pointer text-muted-foreground hover:text-foreground",
                          children: [
                            e.jsx(pt, { className: "h-4 w-4" }),
                            " ",
                            t.image ? "Change photo" : "Add photo",
                            e.jsx("input", {
                              type: "file",
                              accept: "image/*",
                              className: "hidden",
                              onChange: (o) => {
                                (ye(t.id, o.target.files?.[0]),
                                  (o.target.value = ""));
                              },
                            }),
                          ],
                        }),
                        t.image &&
                          e.jsxs(e.Fragment, {
                            children: [
                              e.jsx("img", {
                                src: t.image.url,
                                alt: "",
                                className:
                                  "h-10 w-10 object-cover rounded border",
                              }),
                              e.jsx("button", {
                                type: "button",
                                className: "text-xs underline",
                                onClick: () => k(t.id, { image: void 0 }),
                                children: "Remove",
                              }),
                            ],
                          }),
                      ],
                    }),
                  ],
                },
                t.id,
              ),
            ),
          }),
          e.jsxs(B, {
            type: "button",
            variant: "outline",
            className: "mt-3 gap-1",
            onClick: () => {
              (c((t) => [...t, te(Ce)]), d(null));
            },
            children: [e.jsx(Ge, { className: "h-4 w-4" }), " Add product"],
          }),
        ],
      }),
      e.jsxs(ae, {
        className: "p-4 space-y-2",
        children: [
          e.jsx("p", {
            className: "text-sm font-medium",
            children: "Import many products at once",
          }),
          e.jsx("p", {
            className: "text-xs text-muted-foreground",
            children:
              "Paste rows from a spreadsheet or CSV: name, SKU, price, category, description, minimum order, order link (the last two optional). A header row is recognised automatically. Photos are added per product above.",
          }),
          e.jsx(ve, {
            "aria-label": "Paste CSV",
            value: le,
            onChange: (t) => Q(t.target.value),
            rows: 4,
            placeholder: `name,sku,price,category,description
Blue Mug,MUG-1,12.50,Kitchen,Ceramic 350 ml`,
          }),
          e.jsxs("div", {
            className: "flex gap-2 flex-wrap",
            children: [
              X &&
                e.jsx("p", {
                  role: "status",
                  className: `w-full text-xs ${X.warn ? "text-destructive" : "text-muted-foreground"}`,
                  "data-testid": "csv-import-summary",
                  children: X.text,
                }),
              e.jsx(B, {
                type: "button",
                size: "sm",
                disabled: !le.trim(),
                onClick: () => fe(le),
                children: "Add pasted rows",
              }),
              e.jsxs("label", {
                className: "inline-flex",
                children: [
                  e.jsx("span", {
                    className:
                      "inline-flex items-center rounded-md border px-3 h-9 text-sm cursor-pointer hover:bg-accent",
                    children: "Import CSV file",
                  }),
                  e.jsx("input", {
                    type: "file",
                    accept: ".csv,.tsv,.txt,text/csv",
                    className: "hidden",
                    onChange: async (t) => {
                      const a = t.target.files?.[0];
                      ((t.target.value = ""),
                        a && fe(Ye(await a.arrayBuffer()).text));
                    },
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
      e.jsxs(ae, {
        className: "p-4 space-y-4",
        children: [
          e.jsx("p", { className: "text-sm font-medium", children: "Layout" }),
          e.jsxs("div", {
            className: "grid sm:grid-cols-4 gap-3",
            children: [
              e.jsxs("div", {
                children: [
                  e.jsx(m, { className: "text-xs", children: "Currency" }),
                  e.jsxs(H, {
                    value: f,
                    onValueChange: (t) => {
                      (g(t), d(null));
                    },
                    children: [
                      e.jsx(V, {
                        "aria-label": "Currency",
                        children: e.jsx(_, {}),
                      }),
                      e.jsx(G, {
                        children: Qe.map((t) =>
                          e.jsx(
                            N,
                            { value: t.code, children: t.label },
                            t.code,
                          ),
                        ),
                      }),
                    ],
                  }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx(m, { className: "text-xs", children: "Columns" }),
                  e.jsxs(H, {
                    value: O,
                    onValueChange: (t) => {
                      (R(t), d(null));
                    },
                    children: [
                      e.jsx(V, {
                        "aria-label": "Columns",
                        children: e.jsx(_, {}),
                      }),
                      e.jsxs(G, {
                        children: [
                          e.jsx(N, { value: "2", children: "2 per row" }),
                          e.jsx(N, { value: "3", children: "3 per row" }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx(m, { className: "text-xs", children: "Page size" }),
                  e.jsxs(H, {
                    value: se,
                    onValueChange: (t) => {
                      (W(t), d(null));
                    },
                    children: [
                      e.jsx(V, {
                        "aria-label": "Page size",
                        children: e.jsx(_, {}),
                      }),
                      e.jsxs(G, {
                        children: [
                          e.jsx(N, { value: "letter", children: "US Letter" }),
                          e.jsx(N, { value: "a4", children: "A4" }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              e.jsxs("div", {
                children: [
                  e.jsx(m, { className: "text-xs", children: "Accent colour" }),
                  e.jsx(x, {
                    "aria-label": "Accent colour",
                    type: "color",
                    value: re,
                    onChange: (t) => {
                      (U(t.target.value), d(null));
                    },
                    className: "h-9 p-1",
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("div", {
            className: "flex items-center gap-2",
            children: [
              e.jsx($, {
                id: "pcb-cover",
                checked: K,
                onCheckedChange: () => {
                  (J((t) => !t), d(null));
                },
              }),
              e.jsx(m, {
                htmlFor: "pcb-cover",
                className: "font-normal cursor-pointer",
                children: "Cover page",
              }),
            ],
          }),
          e.jsxs("div", {
            className: "flex items-center gap-2",
            children: [
              e.jsx($, {
                id: "pcb-prices",
                checked: ie,
                onCheckedChange: () => {
                  (D((t) => !t), d(null));
                },
              }),
              e.jsx(m, {
                htmlFor: "pcb-prices",
                className: "font-normal cursor-pointer",
                children:
                  "Price list page at the end (SKU, product, minimum order, price)",
              }),
            ],
          }),
          e.jsxs("div", {
            className: "flex items-center gap-2",
            children: [
              e.jsx($, {
                id: "pcb-toc",
                checked: oe,
                onCheckedChange: () => {
                  (M((t) => !t), d(null));
                },
              }),
              e.jsx(m, {
                htmlFor: "pcb-toc",
                className: "font-normal cursor-pointer",
                children: "Contents page (categories with page numbers)",
              }),
            ],
          }),
        ],
      }),
      e.jsxs(ae, {
        className: "p-4 space-y-3",
        "data-testid": "catalog-tax-card",
        children: [
          e.jsx("p", {
            className: "text-sm font-medium",
            children: "Tax, brand and saved catalogs",
          }),
          e.jsxs("div", {
            className: "grid sm:grid-cols-3 gap-3",
            children: [
              e.jsxs("div", {
                children: [
                  e.jsx(m, { className: "text-xs", children: "Prices are" }),
                  e.jsxs(H, {
                    value: S,
                    onValueChange: (t) => {
                      (I(t), d(null));
                    },
                    children: [
                      e.jsx(V, {
                        "aria-label": "Tax on prices",
                        children: e.jsx(_, {}),
                      }),
                      e.jsxs(G, {
                        children: [
                          e.jsx(N, {
                            value: "none",
                            children: "Shown as typed (no tax column)",
                          }),
                          e.jsx(N, {
                            value: "excl",
                            children:
                              "Before tax (tax added in the price list)",
                          }),
                          e.jsx(N, {
                            value: "incl",
                            children:
                              "Tax included (tax split out in the price list)",
                          }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              S !== "none" &&
                e.jsxs("div", {
                  children: [
                    e.jsx(m, {
                      className: "text-xs",
                      htmlFor: "pcb-tax",
                      children: "Default tax rate (%)",
                    }),
                    e.jsx(x, {
                      id: "pcb-tax",
                      inputMode: "decimal",
                      value: E,
                      onChange: (t) => {
                        (ne(t.target.value), d(null));
                      },
                      placeholder: "e.g. 20",
                      "aria-invalid":
                        (E.trim() !== "" && we(E) === null) || void 0,
                    }),
                  ],
                }),
              e.jsxs("div", {
                children: [
                  e.jsx(m, {
                    className: "text-xs",
                    htmlFor: "pcb-logo",
                    children: "Logo (optional)",
                  }),
                  e.jsx(x, {
                    id: "pcb-logo",
                    type: "file",
                    accept: "image/png,image/jpeg",
                    onChange: async (t) => {
                      const a = t.target.files?.[0];
                      if (((t.target.value = ""), !!a))
                        try {
                          const o = await ke(a);
                          (A(
                            Fe(
                              new Uint8Array(await o.arrayBuffer()),
                              o.type === "image/png",
                            ),
                          ),
                            d(null));
                        } catch {
                          v.error(
                            "That logo couldn't be read. Try a PNG or JPG.",
                          );
                        }
                    },
                  }),
                  ce &&
                    e.jsx("button", {
                      type: "button",
                      className: "text-xs underline mt-1",
                      onClick: () => {
                        (A(""), d(null));
                      },
                      children: "Remove logo",
                    }),
                ],
              }),
            ],
          }),
          S !== "none" &&
            E.trim() !== "" &&
            we(E) === null &&
            e.jsx("p", {
              role: "alert",
              className: "text-xs text-destructive",
              children: "Enter a tax rate from 0 to 100.",
            }),
          T &&
            T.priced > 0 &&
            e.jsxs("p", {
              className: "text-xs text-muted-foreground",
              role: "status",
              "data-testid": "catalog-totals",
              children: [
                "One of each priced product: ",
                T.net.toFixed(2),
                " before tax, ",
                T.tax.toFixed(2),
                " tax, ",
                T.gross.toFixed(2),
                " total (",
                f,
                ").",
              ],
            }),
          e.jsxs("div", {
            className: "flex gap-2 flex-wrap items-center",
            children: [
              Pe() &&
                e.jsx("button", {
                  type: "button",
                  className:
                    "inline-flex items-center rounded-md border px-3 h-9 text-sm hover:bg-accent",
                  "data-testid": "use-open-profile",
                  onClick: () => s(Pe()),
                  children: "Use my open business profile",
                }),
              e.jsxs("label", {
                className: "inline-flex",
                children: [
                  e.jsx("span", {
                    className:
                      "inline-flex items-center rounded-md border px-3 h-9 text-sm cursor-pointer hover:bg-accent",
                    children: "Load brand profile",
                  }),
                  e.jsx("input", {
                    type: "file",
                    accept: ".json,application/json",
                    className: "hidden",
                    "aria-label": "Load brand profile file",
                    onChange: (t) => {
                      const a = t.target.files?.[0];
                      ((t.target.value = ""), Ne(a));
                    },
                  }),
                ],
              }),
              e.jsx(B, {
                type: "button",
                variant: "outline",
                size: "sm",
                onClick: h,
                children: "Save catalog to this device",
              }),
              e.jsxs("label", {
                className: "inline-flex",
                children: [
                  e.jsx("span", {
                    className:
                      "inline-flex items-center rounded-md border px-3 h-9 text-sm cursor-pointer hover:bg-accent",
                    children: "Open saved catalog",
                  }),
                  e.jsx("input", {
                    type: "file",
                    accept: ".json,application/json",
                    className: "hidden",
                    "aria-label": "Open saved catalog file",
                    onChange: (t) => {
                      const a = t.target.files?.[0];
                      ((t.target.value = ""), j(a));
                    },
                  }),
                ],
              }),
            ],
          }),
          pe &&
            e.jsx("p", {
              role: "status",
              className: "text-xs text-muted-foreground",
              children: pe,
            }),
          e.jsx("p", {
            className: "text-xs text-muted-foreground",
            children:
              "Saved files stay on your device; nothing is stored on our servers.",
          }),
        ],
      }),
      e.jsxs("div", {
        className: "flex gap-3 flex-wrap items-start",
        children: [
          je
            ? e.jsx(qe, { message: "Building catalog..." })
            : P
              ? e.jsx("div", {
                  onClickCapture: Oe,
                  children: e.jsx(Le, {
                    blob: P.blob,
                    fileName: `${(n || "catalog").replace(/[^\w-]+/g, "_")}.pdf`,
                    label: `Download Catalog (${P.pages} pages)`,
                  }),
                })
              : e.jsxs("div", {
                  children: [
                    e.jsx(B, {
                      onClick: L,
                      disabled:
                        r.priceErrorCount > 0 ||
                        r.moqErrorCount > 0 ||
                        r.urlErrorCount > 0,
                      children: "Build Catalog",
                    }),
                    r.priceErrorCount > 0 &&
                      e.jsxs("p", {
                        role: "alert",
                        className: "text-xs text-destructive mt-1",
                        children: [
                          "Fix ",
                          r.priceErrorCount,
                          " price",
                          r.priceErrorCount > 1 ? "s" : "",
                          " above to build.",
                        ],
                      }),
                    r.moqErrorCount > 0 &&
                      e.jsxs("p", {
                        role: "alert",
                        className: "text-xs text-destructive mt-1",
                        children: [
                          "Fix ",
                          r.moqErrorCount,
                          " minimum order",
                          r.moqErrorCount > 1 ? "s" : "",
                          " above to build.",
                        ],
                      }),
                    r.urlErrorCount > 0 &&
                      e.jsxs("p", {
                        role: "alert",
                        className: "text-xs text-destructive mt-1",
                        children: [
                          "Fix ",
                          r.urlErrorCount,
                          " link",
                          r.urlErrorCount > 1 ? "s" : "",
                          " above to build.",
                        ],
                      }),
                    Z &&
                      r.noProducts &&
                      e.jsxs("p", {
                        role: "alert",
                        className: "text-xs text-destructive mt-1",
                        "data-testid": "build-empty-message",
                        children: [
                          "Nothing to build yet: add a name to at least one product",
                          r.title ? " and a catalog title" : "",
                          ".",
                        ],
                      }),
                  ],
                }),
          P &&
            e.jsx(B, {
              variant: "outline",
              onClick: () => d(null),
              children: "Edit",
            }),
        ],
      }),
      P && e.jsx($e, { blob: P.blob, mimeType: "application/pdf" }),
    ],
  });
}
function kt() {
  const [l, c] = i.useState([]),
    [n, b] = i.useState(""),
    [C, w] = i.useState(""),
    [f] = Ve();
  i.useEffect(() => {
    f.name && w((s) => s || f.name);
  }, [f.name]);
  const [g, O] = i.useState("letter"),
    [R, se] = i.useState(!0),
    [W, re] = i.useState(null),
    [U, K] = i.useState(!0),
    [J, oe] = i.useState(!0),
    [M, le] = i.useState({ productIndex: !1 }),
    [Q, je] = i.useState(""),
    [Y, ie] = i.useState(!1),
    [D, S] = i.useState(""),
    [I, E] = i.useState("none"),
    [ne, ce] = i.useState(""),
    [A, pe] = i.useState(""),
    [q, P] = i.useState("EAN13"),
    [d, Z] = i.useState(""),
    [be, X] = i.useState(!1),
    [xe, ge] = i.useState(""),
    [z, r] = i.useState(null),
    [de, ee] = i.useState(0),
    he = i.useCallback((s) => {
      const h = s.filter((j) => {
        const p = j.name.toLowerCase();
        return (
          p.endsWith(".pdf") ||
          p.endsWith(".docx") ||
          p.endsWith(".txt") ||
          /^image\/(png|jpe?g|webp|heic|heif)$/.test(j.type) ||
          /\.(heic|heif|webp)$/.test(p)
        );
      });
      (h.length < s.length &&
        v.warning(
          "Some files were skipped — Catalog Maker accepts PDF, Word (.docx/.txt), and PNG, JPEG, WebP or HEIC images",
        ),
        c((j) => {
          const p = gt(
            j.map((L) => L.file),
            h,
          );
          p.length > 0 &&
            v.warning(
              `${p.length === 1 ? "One file is" : `${p.length} files are`} already in your list — added anyway.`,
            );
          const T = (L) =>
            L.name
              .replace(/\.[^.]+$/, "")
              .replace(/\s*\(\d+\)$/, "")
              .replace(/_/g, " ")
              .trim();
          return [...j, ...h.map((L) => ({ file: L, title: T(L) }))];
        }),
        r(null));
    }, []),
    k = (s) => {
      (c((h) => s.map((j) => h.find((p) => p.file === j))), r(null));
    },
    Ce = (s) => {
      (c((h) => h.filter((j, p) => p !== s)), r(null));
    },
    ye = (s, h) => {
      (c((j) => j.map((p, T) => (T === s ? { ...p, title: h } : p))), r(null));
    },
    fe = async () => {
      if (l.length === 0) {
        v.error("Add at least one product or section file first");
        return;
      }
      if (R && !n.trim()) {
        v.error("Enter a catalog title, or turn off the cover page");
        return;
      }
      (X(!0), r(null));
      try {
        const s = W ? await ke(W) : void 0,
          h = s
            ? {
                bytes: new Uint8Array(await s.arrayBuffer()),
                isPng: s.type === "image/png",
              }
            : void 0,
          j =
            M.productIndex && Q.trim()
              ? { kind: "custom", heading: "Product Index", body: Q }
              : void 0,
          { bytes: p, totalPages: T } = await Je({
            bookTitle: n,
            author: C,
            bookSize: g,
            sections: l,
            frontCover: R ? { image: h } : void 0,
            backCover: {
              blurb: Y && D.trim() ? D : void 0,
              qrUrl: (I === "qr" && ne.trim()) || void 0,
              barcode:
                I === "barcode" && A.trim()
                  ? { value: A.trim(), format: q, caption: d.trim() || void 0 }
                  : void 0,
            },
            frontMatter: {
              title: R ? { kind: "title", heading: n, body: "" } : void 0,
              contributors: j,
            },
            backMatter: {},
            includeToc: U,
            includeListOfImages: J,
            onProgress: ge,
          });
        (r(Ae(p)), ee(T), v.success("Catalog assembled!"));
      } catch (s) {
        (console.error("Catalog assembly failed:", s),
          v.error(
            s instanceof Error
              ? s.message
              : "Something went wrong assembling this catalog",
          ));
      } finally {
        (X(!1), ge(""));
      }
    },
    Ne = () => {
      (c([]), r(null), ee(0));
    };
  return e.jsxs("div", {
    className: "space-y-6",
    children: [
      e.jsx(Ue, { compact: !0 }),
      e.jsxs("div", {
        children: [
          e.jsx(m, { children: "Catalog Title" }),
          e.jsx(x, {
            "aria-label": "Catalog Title",
            value: n,
            onChange: (s) => {
              (b(s.target.value), r(null));
            },
            placeholder: "e.g. Spring 2026 Product Catalog",
          }),
        ],
      }),
      e.jsxs("div", {
        children: [
          e.jsx(m, { children: "Company Name" }),
          e.jsx(x, {
            "aria-label": "Company Name",
            value: C,
            onChange: (s) => {
              (w(s.target.value), r(null));
            },
            placeholder: "Your company name",
          }),
        ],
      }),
      e.jsxs("div", {
        children: [
          e.jsx(m, { children: "Page Size" }),
          e.jsxs(H, {
            value: g,
            onValueChange: (s) => {
              (O(s), r(null));
            },
            children: [
              e.jsx(V, { "aria-label": "Page size", children: e.jsx(_, {}) }),
              e.jsx(G, {
                children: Object.keys(Be).map((s) =>
                  e.jsx(N, { value: s, children: Be[s].label }, s),
                ),
              }),
            ],
          }),
        ],
      }),
      e.jsxs("div", {
        children: [
          e.jsx(m, {
            className: "mb-2 block",
            children: "Products & Sections",
          }),
          l.length === 0
            ? e.jsx(Te, {
                gateAtDownload: !0,
                accept:
                  ".pdf,.docx,.txt,image/png,image/jpeg,image/jpg,image/webp,.heic,.heif",
                multiple: !0,
                onFiles: he,
                label: "Drop your product/section files",
                description:
                  "PDF, Word (.docx/.txt), or images — add as many as you need",
              })
            : e.jsxs("div", {
                className: "space-y-4",
                children: [
                  e.jsx(Ke, {
                    files: l.map((s) => s.file),
                    onReorder: k,
                    onRemove: Ce,
                  }),
                  e.jsx("div", {
                    className: "space-y-2",
                    children: l.map((s, h) =>
                      e.jsxs(
                        "div",
                        {
                          className: "flex items-center gap-2",
                          children: [
                            e.jsxs("span", {
                              className:
                                "text-xs text-muted-foreground w-6 shrink-0",
                              children: [h + 1, "."],
                            }),
                            e.jsx(x, {
                              "aria-label": `Section name, file ${h + 1}`,
                              value: s.title,
                              onChange: (j) => ye(h, j.target.value),
                              placeholder:
                                "Product/section name (appears in Table of Contents)",
                              className: "text-sm",
                            }),
                          ],
                        },
                        `${s.file.name}-${s.file.size}-${h}`,
                      ),
                    ),
                  }),
                  e.jsx(Te, {
                    gateAtDownload: !0,
                    accept:
                      ".pdf,.docx,.txt,image/png,image/jpeg,image/jpg,image/webp,.heic,.heif",
                    multiple: !0,
                    onFiles: he,
                    label: "Add another file",
                    description: "",
                  }),
                ],
              }),
        ],
      }),
      e.jsxs(ae, {
        className: "p-4 space-y-4",
        children: [
          e.jsx("p", {
            className: "text-sm font-medium",
            children: "Cover & Price List",
          }),
          e.jsxs("div", {
            className: "flex items-center gap-2",
            children: [
              e.jsx($, {
                checked: R,
                onCheckedChange: () => {
                  (se((s) => !s), r(null));
                },
                id: "cover",
              }),
              e.jsx(m, {
                htmlFor: "cover",
                className: "font-normal cursor-pointer",
                children:
                  "Cover Page (uses the catalog title and company above)",
              }),
            ],
          }),
          R &&
            e.jsxs("div", {
              className: "pl-6 space-y-1",
              children: [
                e.jsx(m, {
                  className: "text-xs text-muted-foreground",
                  children: "Cover image (optional)",
                }),
                e.jsx(x, {
                  "aria-label": "Cover image (optional)",
                  type: "file",
                  accept: "image/png,image/jpeg",
                  onChange: (s) => {
                    (re(s.target.files?.[0] ?? null), r(null));
                  },
                }),
              ],
            }),
          e.jsxs("div", {
            className: "space-y-2 pt-2 border-t",
            children: [
              e.jsxs("div", {
                className: "flex items-center gap-2",
                children: [
                  e.jsx($, {
                    checked: Y,
                    onCheckedChange: () => {
                      (ie((s) => !s), r(null));
                    },
                    id: "price-list",
                  }),
                  e.jsx(m, {
                    htmlFor: "price-list",
                    className: "font-normal cursor-pointer",
                    children: "Price List / Order Info (back page)",
                  }),
                ],
              }),
              Y &&
                e.jsx(ve, {
                  "aria-label": "Price list / order info (back page)",
                  value: D,
                  onChange: (s) => {
                    (S(s.target.value), r(null));
                  },
                  placeholder: "List prices, SKUs, or ordering instructions...",
                  rows: 4,
                }),
            ],
          }),
          e.jsxs("div", {
            children: [
              e.jsx(m, {
                className: "text-xs text-muted-foreground",
                children: "Back page code (optional)",
              }),
              e.jsxs(H, {
                value: I,
                onValueChange: (s) => {
                  (E(s), r(null));
                },
                children: [
                  e.jsx(V, {
                    "aria-label": "Back page code type",
                    children: e.jsx(_, {}),
                  }),
                  e.jsxs(G, {
                    children: [
                      e.jsx(N, { value: "none", children: "None" }),
                      e.jsx(N, {
                        value: "qr",
                        children:
                          "QR Code (a link — your store, order form, anything)",
                      }),
                      e.jsx(N, {
                        value: "barcode",
                        children: "Real Barcode (Code 128, EAN-13, UPC, etc.)",
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          I === "qr" &&
            e.jsx("div", {
              className: "pl-6",
              children: e.jsx(x, {
                "aria-label": "QR code link",
                value: ne,
                onChange: (s) => {
                  (ce(s.target.value), r(null));
                },
                placeholder: "https://your-store.com",
              }),
            }),
          I === "barcode" &&
            e.jsxs("div", {
              className: "pl-6 space-y-2",
              children: [
                e.jsxs(H, {
                  value: q,
                  onValueChange: (s) => {
                    (P(s), r(null));
                  },
                  children: [
                    e.jsx(V, {
                      "aria-label": "Barcode format",
                      children: e.jsx(_, {}),
                    }),
                    e.jsx(G, {
                      children: xt.map((s) =>
                        e.jsx(
                          N,
                          { value: s.value, children: s.label },
                          s.value,
                        ),
                      ),
                    }),
                  ],
                }),
                e.jsx(x, {
                  "aria-label": "Barcode value",
                  value: A,
                  onChange: (s) => {
                    (pe(s.target.value), r(null));
                  },
                  placeholder: "Value to encode",
                }),
                e.jsx(x, {
                  "aria-label": "Barcode caption (optional)",
                  value: d,
                  onChange: (s) => {
                    (Z(s.target.value), r(null));
                  },
                  placeholder: "What is this for? (optional)",
                }),
              ],
            }),
        ],
      }),
      e.jsxs(ae, {
        className: "p-4 space-y-4",
        children: [
          e.jsx("p", {
            className: "text-sm font-medium",
            children: "Front Matter",
          }),
          e.jsxs("div", {
            className: "space-y-2",
            children: [
              e.jsxs("div", {
                className: "flex items-center gap-2",
                children: [
                  e.jsx($, {
                    checked: M.productIndex,
                    onCheckedChange: () => {
                      (le((s) => ({ ...s, productIndex: !s.productIndex })),
                        r(null));
                    },
                    id: "product-index",
                  }),
                  e.jsx(m, {
                    htmlFor: "product-index",
                    className: "font-normal cursor-pointer",
                    children: "Product Index",
                  }),
                ],
              }),
              M.productIndex &&
                e.jsx(ve, {
                  "aria-label": "Product index",
                  value: Q,
                  onChange: (s) => {
                    (je(s.target.value), r(null));
                  },
                  placeholder:
                    "List key products/categories for quick reference...",
                  rows: 3,
                }),
            ],
          }),
          e.jsxs("div", {
            className: "flex items-center gap-2 pt-2 border-t",
            children: [
              e.jsx($, {
                checked: U,
                onCheckedChange: () => {
                  (K((s) => !s), r(null));
                },
                id: "toc",
              }),
              e.jsx(m, {
                htmlFor: "toc",
                className: "font-normal cursor-pointer",
                children: "Table of Contents (auto-generated)",
              }),
            ],
          }),
          e.jsxs("div", {
            className: "flex items-center gap-2",
            children: [
              e.jsx($, {
                checked: J,
                onCheckedChange: () => {
                  (oe((s) => !s), r(null));
                },
                id: "loi",
              }),
              e.jsx(m, {
                htmlFor: "loi",
                className: "font-normal cursor-pointer",
                children: "List of Images (embedded product photos)",
              }),
            ],
          }),
        ],
      }),
      e.jsx("div", {
        className: "flex gap-3",
        children: be
          ? e.jsx(qe, { message: xe || "Assembling..." })
          : z
            ? e.jsxs(e.Fragment, {
                children: [
                  e.jsx(Le, {
                    blob: z,
                    fileName: `${(n || "catalog").replace(/[^\w-]+/g, "_")}.pdf`,
                    label: `Download Catalog (${de} pages)`,
                  }),
                  e.jsx(B, {
                    variant: "outline",
                    onClick: Ne,
                    children: "New Catalog",
                  }),
                ],
              })
            : e.jsx(B, {
                onClick: fe,
                disabled: l.length === 0,
                children: "Assemble Catalog",
              }),
      }),
      z && e.jsx($e, { blob: z, mimeType: "application/pdf" }),
    ],
  });
}
function Aa() {
  const [l, c] = i.useState("products");
  return e.jsxs(We, {
    children: [
      e.jsxs("div", {
        className: "flex gap-2 mb-6",
        role: "tablist",
        children: [
          e.jsx(B, {
            role: "tab",
            "aria-selected": l === "products",
            variant: l === "products" ? "default" : "outline",
            onClick: () => c("products"),
            children: "Product list",
          }),
          e.jsx(B, {
            role: "tab",
            "aria-selected": l === "files",
            variant: l === "files" ? "default" : "outline",
            onClick: () => c("files"),
            children: "Combine files",
          }),
        ],
      }),
      l === "products" ? e.jsx(wt, {}) : e.jsx(kt, {}),
    ],
  });
}
export { Aa as default };
//# sourceMappingURL=CatalogMaker-BlrB82Gj.js.map
