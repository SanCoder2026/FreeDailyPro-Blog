import { k as ht, u as g, e as mt } from "./index-BRvxULIc.js";
import { T as dt } from "./pdfText-bjh9eBB-.js";
import { p as gt } from "./numberInput-5hjoxJ5z.js";
import { b as ft } from "./codeGeneration-D1g4LVfX.js";
const Q = "Uncategorised";
function Z(e) {
  if (!e.trim()) return { ok: !0, value: null };
  const t = gt(e);
  return t === null || !Number.isFinite(t)
    ? { ok: !1, error: "Enter a number, like 12.50" }
    : t < 0
      ? { ok: !1, error: "Price can't be negative" }
      : { ok: !0, value: t };
}
function Ot(e) {
  const t = Z(e);
  return t.ok && t.value !== null ? String(t.value) : "";
}
function tt(e) {
  const t = e.trim().replace(/,/g, "");
  if (!t) return { ok: !0, value: null };
  if (!/^\d+$/.test(t))
    return { ok: !1, error: "Enter a whole number, like 12" };
  const o = Number(t);
  return !Number.isSafeInteger(o) || o < 1
    ? { ok: !1, error: "Minimum order must be 1 or more" }
    : { ok: !0, value: o };
}
function Tt(e) {
  const t = tt(e);
  return t.ok && t.value !== null ? String(t.value) : "";
}
function rt(e) {
  const t = e.trim();
  if (!t) return { ok: !0, url: "" };
  if (/\s/.test(t)) return { ok: !1, error: "A link can't contain spaces" };
  if (t.length > 500)
    return { ok: !1, error: "That link is too long (500 characters at most)" };
  const o =
    /^[a-z][a-z0-9+.-]*:/i.test(t) && !/^[^/]+\.[^/]+:\d+/.test(t)
      ? t
      : `https://${t}`;
  let n;
  try {
    n = new URL(o);
  } catch {
    return {
      ok: !1,
      error: "Enter a web address, like https://shop.example.com/mug",
    };
  }
  return n.protocol !== "http:" && n.protocol !== "https:"
    ? { ok: !1, error: "Only http:// or https:// links can be used" }
    : !n.hostname.includes(".") || n.hostname.endsWith(".")
      ? {
          ok: !1,
          error: "Enter a web address, like https://shop.example.com/mug",
        }
      : { ok: !0, url: n.toString() };
}
function vt(e) {
  const t = rt(e);
  return t.ok ? t.url : "";
}
function Y(e) {
  try {
    const t = new URL(e);
    return (t.host + t.pathname + t.search).replace(/\/$/, "");
  } catch {
    return e;
  }
}
function Lt(e, t, o) {
  const n = Math.max(e, t);
  if (!(n > o) || e <= 0 || t <= 0) return { width: e, height: t };
  const r = o / n;
  return {
    width: Math.max(1, Math.round(e * r)),
    height: Math.max(1, Math.round(t * r)),
  };
}
const Ut = 1200,
  pt = ["name", "sku", "price", "category", "description", "moq", "url"];
function Dt(e, t) {
  const o = e.filter((d) => d.some((y) => y.trim()));
  if (!o.length) return { rows: [], skippedNoName: [] };
  const n = o[0].map((d) => t[d.trim().toLowerCase()]),
    r = n.filter(Boolean).length >= 2,
    c = r ? n : [...pt],
    a = [],
    m = [];
  return (
    o.forEach((d, y) => {
      if (r && y === 0) return;
      const f = {
        name: "",
        sku: "",
        price: "",
        category: "",
        description: "",
        moq: "",
        url: "",
      };
      d.forEach((M, X) => {
        const R = c[X];
        R && (f[R] = M.trim());
      });
      const $ = y + 1;
      if (!f.name) {
        m.push($);
        return;
      }
      const x = Z(f.price),
        C = tt(f.moq),
        w = rt(f.url);
      a.push({
        rowNumber: $,
        product: f,
        priceError: x.ok ? void 0 : x.error,
        moqError: C.ok ? void 0 : C.error,
        urlError: w.ok ? void 0 : w.error,
      });
    }),
    { rows: a, skippedNoName: m }
  );
}
function At(e) {
  const t = e.rows.filter((a) => a.priceError).map((a) => a.rowNumber),
    o = e.rows.filter((a) => a.moqError).map((a) => a.rowNumber),
    n = e.rows.filter((a) => a.urlError).map((a) => a.rowNumber),
    c = [`${e.rows.length - t.length} imported`];
  return (
    t.length &&
      c.push(
        `${t.length} bad price${t.length > 1 ? "s" : ""} on row${t.length > 1 ? "s" : ""} ${t.join(", ")}`,
      ),
    o.length &&
      c.push(
        `${o.length} bad minimum order on row${o.length > 1 ? "s" : ""} ${o.join(", ")}`,
      ),
    n.length &&
      c.push(
        `${n.length} bad link${n.length > 1 ? "s" : ""} on row${n.length > 1 ? "s" : ""} ${n.join(", ")}`,
      ),
    e.skippedNoName.length &&
      c.push(
        `${e.skippedNoName.length} skipped (no name) on row${e.skippedNoName.length > 1 ? "s" : ""} ${e.skippedNoName.join(", ")}`,
      ),
    c.join(", ")
  );
}
function at(e) {
  return e.trim() || Q;
}
function wt(e) {
  const t = [];
  for (const o of e) {
    const n = at(o);
    t.includes(n) || t.push(n);
  }
  return t.includes(Q) ? [...t.filter((o) => o !== Q), Q] : t;
}
function Ft(e, t, o) {
  const n = {
    title: o && !t.trim(),
    noProducts: !e.some((r) => r.name.trim()),
    rows: {},
    priceErrorCount: 0,
    moqErrorCount: 0,
    urlErrorCount: 0,
  };
  for (const r of e) {
    const c = {},
      a = Z(r.price);
    a.ok || ((c.price = a.error), n.priceErrorCount++);
    const m = tt(r.moq ?? "");
    m.ok || ((c.moq = m.error), n.moqErrorCount++);
    const d = rt(r.url ?? "");
    d.ok || ((c.url = d.error), n.urlErrorCount++);
    const y = !!(
      (r.moq ?? "").trim() ||
      (r.url ?? "").trim() ||
      r.sku.trim() ||
      r.price.trim() ||
      r.category.trim() ||
      r.description.trim()
    );
    (!r.name.trim() && y && (c.name = "Add a product name or remove this row"),
      (c.name || c.price || c.moq || c.url) && (n.rows[r.id] = c));
  }
  return n;
}
function xt(e) {
  let t = 3735928559,
    o = 1103547991;
  const n = (r) => {
    ((t = Math.imul(t ^ r, 2654435761)), (o = Math.imul(o ^ r, 1597334677)));
  };
  for (const r of e) {
    if (typeof r == "string")
      for (let c = 0; c < r.length; c++) n(r.charCodeAt(c));
    else for (let c = 0; c < r.length; c++) n(r[c]);
    n(31);
  }
  return (
    (t =
      Math.imul(t ^ (t >>> 16), 2246822507) ^
      Math.imul(o ^ (o >>> 13), 3266489909)),
    (o =
      Math.imul(o ^ (o >>> 16), 2246822507) ^
      Math.imul(t ^ (t >>> 13), 3266489909)),
    (4294967296 * (2097151 & o) + (t >>> 0)).toString(36)
  );
}
function Xt(e, t) {
  const o = [JSON.stringify(t, Object.keys(t).sort())];
  for (const n of e)
    (o.push(
      JSON.stringify(
        n.url
          ? [
              n.name,
              n.sku,
              n.price,
              n.category,
              n.description,
              n.moq ?? "",
              n.url,
            ]
          : [n.name, n.sku, n.price, n.category, n.description, n.moq ?? ""],
      ),
    ),
      n.image && o.push(n.image.bytes));
  return xt(o);
}
function Ht(e, t) {
  return !e.has(t);
}
const yt = { JPY: 0, KRW: 0, VND: 0, KWD: 3, BHD: 3, OMR: 3 },
  kt = (e) => yt[e.toUpperCase()] ?? 2;
function S(e, t = "USD") {
  const o = 10 ** kt(t);
  return Math.round((e + Number.EPSILON * Math.sign(e)) * o) / o;
}
function bt(e) {
  const t = (e ?? "").trim().replace(/%$/, "").trim();
  if (!t || !/^\d+(\.\d+)?$/.test(t)) return null;
  const o = Number(t);
  return o >= 0 && o <= 100 ? o : null;
}
function Pt(e, t, o, n = "USD") {
  if (o === "none" || !(t > 0)) return { net: S(e, n), tax: 0, gross: S(e, n) };
  const r = t / 100;
  if (o === "excl") {
    const m = S(e, n),
      d = S(e * (1 + r), n);
    return { net: m, tax: S(d - m, n), gross: d };
  }
  const c = S(e, n),
    a = S(e / (1 + r), n);
  return { net: a, tax: S(c - a, n), gross: c };
}
function lt(e, t, o, n = "USD") {
  const r = e.price.trim().replace(/,/g, "");
  if (!r || !Number.isFinite(Number(r))) return null;
  const c = bt(e.taxRate);
  return Pt(Number(r), c ?? t, o, n);
}
function Wt(e, t, o, n = "USD") {
  let r = 0,
    c = 0,
    a = 0,
    m = 0,
    d = 0;
  for (const y of e) {
    const f = lt(y, t, o, n);
    if (!f) {
      d++;
      continue;
    }
    (m++, (r += f.net), (c += f.tax), (a += f.gross));
  }
  return { net: S(r, n), tax: S(c, n), gross: S(a, n), priced: m, unpriced: d };
}
const V = 20,
  Mt = 70;
function Rt(e) {
  const t = et[e][1];
  return Math.max(1, Math.floor((t - l - ot - Mt - (l + ut)) / V));
}
const et = { letter: [612, 792], a4: [595.28, 841.89] },
  l = 40,
  G = 16,
  ot = 34,
  ut = 34,
  it = 30,
  Et = 50,
  F = 40;
function st(e, t, o, n) {
  const r = e.context.register(
    e.context.obj({
      Type: "Annot",
      Subtype: "Link",
      Rect: [o.x, o.y, o.x + o.width, o.y + o.height],
      Border: [0, 0, 0],
      A: { Type: "Action", S: "URI", URI: mt.of(n) },
    }),
  );
  t.node.addAnnot(r);
}
function ct(e, t, o) {
  const n = t * 0.75,
    r = Math.min(2, Math.max(1, o(e.name, t - 8, 11))) * 14,
    c = e.description.trim()
      ? Math.min(4, o(e.description, t - 8, 9)) * 11.5 + 4
      : 0;
  return (
    8 +
    n +
    8 +
    r +
    14 +
    (e.price.trim() || e.moq?.trim() ? 16 : 0) +
    c +
    (e.url?.trim() ? Et : 0) +
    8
  );
}
function zt(e, t, o) {
  const [n, r] = et[t.page],
    c = (n - l * 2 - G * (t.columns - 1)) / t.columns,
    a = r - l - ot,
    m = l + ut,
    d = wt(e.map((w) => w.category)),
    y = new Map();
  for (const w of e) {
    const M = at(w.category);
    (y.has(M) || y.set(M, []), y.get(M).push(w));
  }
  const f = [{ items: [] }],
    $ = [];
  let x = a;
  const C = () => {
    (f.push({ items: [] }), (x = a));
  };
  for (const w of d) {
    const M = y.get(w),
      X = ct(M[0], c, o);
    (x - it - X < m && x !== a && C(),
      $.push({ name: w, pageIndex: f.length - 1 }),
      f[f.length - 1].items.push({ kind: "category", name: w, y: x }),
      (x -= it));
    for (let R = 0; R < M.length; R += t.columns) {
      const W = M.slice(R, R + t.columns),
        O = Math.max(...W.map((z) => ct(z, c, o)));
      (x - O < m && x !== a && C(),
        W.forEach((z, B) =>
          f[f.length - 1].items.push({
            kind: "card",
            product: z,
            col: B,
            y: x,
            h: O,
          }),
        ),
        (x -= O + G));
    }
  }
  return { pages: f, categories: $ };
}
const Nt = (e) => {
  const t = /^#?([0-9a-f]{6})$/i.exec(e.trim()),
    o = t ? parseInt(t[1], 16) : 5195493;
  return g(((o >> 16) & 255) / 255, ((o >> 8) & 255) / 255, (o & 255) / 255);
};
function j(e, t) {
  const o = e.trim();
  if (!o) return "";
  const n = Number(o.replace(/,/g, ""));
  if (!isFinite(n)) return o;
  try {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: t,
    }).format(n);
  } catch {
    return o;
  }
}
async function _t(e, t) {
  const o = await ht.create(),
    n =
      [
        t.title,
        t.company,
        ...e.flatMap((i) => [
          i.name,
          i.sku,
          j(i.price, t.currency),
          i.category,
          i.description,
          i.moq ? `MOQ ${i.moq}` : "",
          i.url ? Y(i.url) : "",
        ]),
        "Tax Total Excl. tax Price (incl. tax) 0123456789.,-",
      ].join(`
`) + "•",
    r = await dt.create(o, n),
    c = Nt(t.accent),
    [a, m] = et[t.page],
    d = (a - l * 2 - G * (t.columns - 1)) / t.columns,
    y = (i, u, h) => r.wrap(i, h, u).length,
    { pages: f, categories: $ } = zt(e, t, y),
    x = t.priceList
      ? f
          .flatMap((i) => i.items)
          .filter((i) => i.kind === "card")
          .map((i) => i.product)
      : [],
    C = Rt(t.page),
    w = x.length ? Math.ceil(x.length / C) : 0,
    M = $.map((i) => ({ name: i.name, page: 0 })),
    X =
      t.contents && ($.length > 0 || w > 0)
        ? Math.ceil(($.length + (w ? 1 : 0)) / 36)
        : 0,
    R = (t.cover ? 1 : 0) + X;
  ($.forEach((i, u) => {
    M[u].page = i.pageIndex + R + 1;
  }),
    w && M.push({ name: "Price list", page: f.length + R + 1 }));
  const W = new Map();
  for (const i of e)
    if (i.image)
      try {
        W.set(
          i,
          i.image.isPng
            ? await o.embedPng(i.image.bytes)
            : await o.embedJpg(i.image.bytes),
        );
      } catch {}
  const O = new Map();
  for (const i of e) {
    const u = i.url?.trim();
    if (!(!u || O.has(u)))
      try {
        O.set(u, await o.embedPng(await ft(u, { size: 240 })));
      } catch {}
  }
  let z = null;
  if (t.logo)
    try {
      z = t.logo.isPng
        ? await o.embedPng(t.logo.bytes)
        : await o.embedJpg(t.logo.bytes);
    } catch {}
  const B = (i, u, h, N, s) => {
    if (!z) return;
    const p = Math.min(N / z.width, s / z.height, 1);
    i.drawImage(z, { x: u, y: h, width: z.width * p, height: z.height * p });
  };
  if (t.cover) {
    const i = o.addPage([a, m]);
    (B(i, l, m - l - 70, 160, 70),
      i.drawRectangle({
        x: 0,
        y: m * 0.45,
        width: a,
        height: m * 0.2,
        color: c,
      }),
      r
        .wrap(t.title || "Product Catalog", 34, a - 100, !0)
        .slice(0, 3)
        .forEach((N, s) =>
          r.draw(i, N, {
            x: (a - r.width(N, 34, !0)) / 2,
            y: m * 0.55 - s * 40,
            size: 34,
            bold: !0,
            color: g(1, 1, 1),
          }),
        ),
      t.company.trim() &&
        r.draw(i, t.company, {
          x: (a - r.width(t.company, 16)) / 2,
          y: m * 0.45 - 40,
          size: 16,
          color: g(0.25, 0.25, 0.3),
        }));
    const h = `${e.length} product${e.length === 1 ? "" : "s"}`;
    r.draw(i, h, {
      x: (a - r.width(h, 11)) / 2,
      y: l + 10,
      size: 11,
      color: g(0.45, 0.45, 0.5),
    });
  }
  for (let i = 0; i < X; i++) {
    const u = o.addPage([a, m]);
    (r.draw(u, "Contents", {
      x: l,
      y: m - l - 20,
      size: 22,
      bold: !0,
      color: c,
    }),
      M.slice(i * 36, i * 36 + 36).forEach((h, N) => {
        const s = m - l - 62 - N * 18,
          p = String(h.page);
        (r.draw(u, h.name, { x: l, y: s, size: 11 }),
          r.drawRight(u, p, { rightX: a - l, y: s, size: 11 }),
          u.drawLine({
            start: { x: l + r.width(h.name, 11) + 6, y: s + 3 },
            end: { x: a - l - r.width(p, 11) - 6, y: s + 3 },
            thickness: 0.4,
            color: g(0.8, 0.8, 0.82),
          }));
      }));
  }
  f.forEach((i, u) => {
    const h = o.addPage([a, m]),
      N = u + R + 1;
    (t.company.trim() &&
      r.draw(h, t.company, {
        x: l,
        y: m - l + 6,
        size: 9,
        color: g(0.5, 0.5, 0.55),
      }),
      B(h, a - l - 40, m - l + 3, 40, 18),
      h.drawLine({
        start: { x: l, y: m - l },
        end: { x: a - l, y: m - l },
        thickness: 0.6,
        color: c,
      }),
      r.draw(h, String(N), {
        x: (a - r.width(String(N), 9)) / 2,
        y: l - 6,
        size: 9,
        color: g(0.45, 0.45, 0.5),
      }));
    for (const s of i.items) {
      if (s.kind === "category") {
        (r.draw(h, s.name, { x: l, y: s.y - 18, size: 15, bold: !0, color: c }),
          h.drawLine({
            start: { x: l, y: s.y - 24 },
            end: { x: a - l, y: s.y - 24 },
            thickness: 0.5,
            color: g(0.8, 0.8, 0.84),
          }));
        continue;
      }
      const p = l + s.col * (d + G),
        T = s.y;
      h.drawRectangle({
        x: p,
        y: T - s.h,
        width: d,
        height: s.h,
        borderColor: g(0.85, 0.85, 0.88),
        borderWidth: 0.6,
        color: g(1, 1, 1),
      });
      const q = d * 0.75,
        v = d - 16,
        L = T - 8 - q,
        I = W.get(s.product);
      if (I) {
        const P = Math.min(v / I.width, q / I.height);
        h.drawImage(I, {
          x: p + 8 + (v - I.width * P) / 2,
          y: L + (q - I.height * P) / 2,
          width: I.width * P,
          height: I.height * P,
        });
      } else
        h.drawRectangle({
          x: p + 8,
          y: L,
          width: v,
          height: q,
          color: g(0.95, 0.95, 0.97),
        });
      let k = L - 16;
      for (const P of r.wrap(s.product.name, 11, d - 16, !0).slice(0, 2))
        (r.draw(h, P, { x: p + 8, y: k, size: 11, bold: !0 }), (k -= 14));
      (s.product.sku.trim() &&
        r.draw(h, `SKU ${s.product.sku.trim()}`, {
          x: p + 8,
          y: k + 1,
          size: 8,
          color: g(0.5, 0.5, 0.55),
        }),
        (k -= 13));
      const U = j(s.product.price, t.currency),
        D = s.product.moq?.trim() ? `MOQ ${s.product.moq.trim()}` : "";
      if (
        (U && r.draw(h, U, { x: p + 8, y: k, size: 12, bold: !0, color: c }),
        D &&
          (U
            ? r.drawRight(h, D, {
                rightX: p + d - 8,
                y: k,
                size: 9,
                color: g(0.3, 0.3, 0.35),
              })
            : r.draw(h, D, {
                x: p + 8,
                y: k,
                size: 9,
                color: g(0.3, 0.3, 0.35),
              })),
        (U || D) && (k -= 16),
        s.product.description.trim())
      )
        for (const P of r.wrap(s.product.description, 9, d - 16).slice(0, 4))
          (r.draw(h, P, { x: p + 8, y: k, size: 9, color: g(0.3, 0.3, 0.35) }),
            (k -= 11.5));
      const b = s.product.url?.trim();
      if (b) {
        const P = O.get(b),
          _ = T - s.h + 6,
          K = d - 16 - (P ? F + 8 : 0),
          E = r.wrap(Y(b), 8, K)[0] ?? "",
          J = E.length < Y(b).length ? E.replace(/\s+$/, "") + "..." : E,
          A = _ + F / 2 + 3;
        (r.draw(h, "Order online", {
          x: p + 8,
          y: A + 12,
          size: 8,
          bold: !0,
          color: g(0.3, 0.3, 0.35),
        }),
          r.draw(h, J, { x: p + 8, y: A, size: 8, color: c }));
        const H = r.width(J, 8);
        if (
          (h.drawLine({
            start: { x: p + 8, y: A - 2 },
            end: { x: p + 8 + H, y: A - 2 },
            thickness: 0.5,
            color: c,
          }),
          st(
            o,
            h,
            { x: p + 8, y: A - 4, width: Math.max(H, 40), height: 22 },
            b,
          ),
          P)
        ) {
          const nt = p + d - 8 - F;
          (h.drawImage(P, { x: nt, y: _, width: F, height: F }),
            st(o, h, { x: nt, y: _, width: F, height: F }, b));
        }
      }
    }
  });
  for (let i = 0; i < w; i++) {
    const u = o.addPage([a, m]),
      h = f.length + R + i + 1;
    (t.company.trim() &&
      r.draw(u, t.company, {
        x: l,
        y: m - l + 6,
        size: 9,
        color: g(0.5, 0.5, 0.55),
      }),
      u.drawLine({
        start: { x: l, y: m - l },
        end: { x: a - l, y: m - l },
        thickness: 0.6,
        color: c,
      }),
      r.draw(u, String(h), {
        x: (a - r.width(String(h), 9)) / 2,
        y: l - 6,
        size: 9,
        color: g(0.45, 0.45, 0.5),
      }));
    const N = w > 1 ? `Price list (${i + 1} of ${w})` : "Price list";
    let s = m - l - ot - 22;
    (r.draw(u, N, { x: l, y: s, size: 18, bold: !0, color: c }), (s -= 30));
    const p = l,
      T = l + 110,
      q = a - l,
      v = x.some((b) => b.moq?.trim()),
      L = !!t.tax && t.tax.mode !== "none",
      k = q - (L ? 150 : 0),
      U = k - 90,
      D = q - 80;
    (r.draw(u, "SKU", {
      x: p,
      y: s,
      size: 9,
      bold: !0,
      color: g(0.4, 0.4, 0.45),
    }),
      r.draw(u, "Product", {
        x: T,
        y: s,
        size: 9,
        bold: !0,
        color: g(0.4, 0.4, 0.45),
      }),
      v &&
        r.drawRight(u, "MOQ", {
          rightX: U,
          y: s,
          size: 9,
          bold: !0,
          color: g(0.4, 0.4, 0.45),
        }),
      r.drawRight(u, t.tax?.mode === "incl" ? "Price (incl. tax)" : "Price", {
        rightX: k,
        y: s,
        size: 9,
        bold: !0,
        color: g(0.4, 0.4, 0.45),
      }),
      L &&
        (r.drawRight(u, "Tax", {
          rightX: D,
          y: s,
          size: 9,
          bold: !0,
          color: g(0.4, 0.4, 0.45),
        }),
        r.drawRight(u, t.tax?.mode === "incl" ? "Excl. tax" : "Total", {
          rightX: q,
          y: s,
          size: 9,
          bold: !0,
          color: g(0.4, 0.4, 0.45),
        })),
      u.drawLine({
        start: { x: l, y: s - 6 },
        end: { x: q, y: s - 6 },
        thickness: 0.6,
        color: c,
      }),
      (s -= V));
    for (const b of x.slice(i * C, (i + 1) * C)) {
      const P = j(b.price, t.currency) || "-",
        _ = r.width(P, 10, !0),
        K = (E, J, A) => {
          const H = r.wrap(E, J, A)[0] ?? "";
          return H.length < E.length ? H.replace(/\s+$/, "") + "..." : H;
        };
      if (
        (r.draw(u, K(b.sku.trim() || "-", 9, 100), {
          x: p,
          y: s,
          size: 9,
          color: g(0.4, 0.4, 0.45),
        }),
        r.draw(u, K(b.name, 10, k - T - _ - 16 - (v ? 90 : 0)), {
          x: T,
          y: s,
          size: 10,
        }),
        v &&
          r.drawRight(u, b.moq?.trim() || "-", { rightX: U, y: s, size: 10 }),
        r.drawRight(u, P, { rightX: k, y: s, size: 10, bold: !0 }),
        L && t.tax)
      ) {
        const E = lt(
          { price: b.price, taxRate: b.taxRate },
          t.tax.rate,
          t.tax.mode,
          t.currency,
        );
        (r.drawRight(u, E ? j(String(E.tax), t.currency) : "-", {
          rightX: D,
          y: s,
          size: 10,
        }),
          r.drawRight(
            u,
            E
              ? j(String(t.tax.mode === "incl" ? E.net : E.gross), t.currency)
              : "-",
            { rightX: q, y: s, size: 10, bold: !0 },
          ));
      }
      (u.drawLine({
        start: { x: l, y: s - 6 },
        end: { x: q, y: s - 6 },
        thickness: 0.3,
        color: g(0.88, 0.88, 0.9),
      }),
        (s -= V));
    }
  }
  return (
    await r.finish(),
    o.setTitle(t.title || "Product Catalog"),
    o.setProducer("FreeDailyPro"),
    { bytes: await o.save(), pageCount: o.getPageCount(), note: r.note() }
  );
}
export {
  Ut as M,
  et as P,
  Ot as a,
  vt as b,
  Wt as c,
  Tt as d,
  _t as e,
  Xt as f,
  Lt as g,
  Dt as h,
  Ht as n,
  bt as p,
  At as s,
  Ft as v,
};
//# sourceMappingURL=productCatalog-CL4Qj03q.js.map
