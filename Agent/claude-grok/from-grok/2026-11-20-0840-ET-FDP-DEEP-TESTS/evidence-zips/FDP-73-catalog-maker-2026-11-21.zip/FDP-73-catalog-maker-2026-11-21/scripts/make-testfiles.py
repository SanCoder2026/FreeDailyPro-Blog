#!/usr/bin/env python3
"""FDP-73 Catalog Maker test files (needs Pillow, reportlab, pypdf, python-docx). Run inside testfiles/.
Photos: 4:3 PNG, portrait JPEG, tiny PNG, 4000x3000 JPEG, WebP, a text file renamed .jpg.
CSV: 24-SKU line sheet with header; no-header rows; bad price/MOQ/link rows; quoted commas + line breaks; BOM + semicolons;
     TSV; Unicode (accents, Japanese, Arabic, emoji) and a 'Call for price' text price; long names/descriptions; 300 rows.
Combine files: Letter PDF (2 p), A4 landscape PDF (1 p), DOCX, TXT, PNG, encrypted PDF, damaged PDF, .doc, .xlsx.
Brand profile JSON (colour + name)."""
import csv, io, random, zipfile
from PIL import Image, ImageDraw
from reportlab.pdfgen import canvas; from reportlab.lib.pagesizes import letter, A4, landscape
from pypdf import PdfReader, PdfWriter; import docx
def photo(name, w, h, col, fmt=None):
    im = Image.new('RGB', (w, h), col); d = ImageDraw.Draw(im); d.rectangle([w*0.2, h*0.2, w*0.8, h*0.8], outline='white', width=max(2, w//60)); d.text((w*0.25, h*0.45), name, fill='white'); im.save(name, fmt)
photo('mug-4x3.png', 800, 600, (30, 90, 200)); photo('vase-portrait.jpg', 600, 900, (180, 60, 40)); photo('tiny.png', 10, 10, (0, 150, 0))
photo('big-4000.jpg', 4000, 3000, (90, 30, 120)); photo('lamp.webp', 800, 600, (200, 150, 0), 'WEBP')
open('fake-photo.jpg', 'w').write('not an image\n')
cats = ['Kitchen', 'Lighting', 'Textiles', 'Decor']; random.seed(73)
rows = [[f'Item {i+1:02d} {random.choice(["Mug","Bowl","Lamp","Throw","Vase","Tray"])}', f'SKU-{i+1:03d}', f'{random.randint(5,120)}.{random.choice(["00","50","99"])}', cats[i % 4], 'Handmade, sold in boxes of 6.', str(random.choice([6, 12, 24])), f'https://example.com/p/{i+1}'] for i in range(24)]
with open('linesheet-24.csv', 'w', newline='') as f: w = csv.writer(f); w.writerow(['Product', 'Code', 'Cost', 'Group', 'Description', 'MOQ', 'Link']); w.writerows(rows)
with open('noheader-3.csv', 'w', newline='') as f: csv.writer(f).writerows(rows[:3])
with open('bad-rows.csv', 'w', newline='') as f: w = csv.writer(f); w.writerow(['name', 'sku', 'price', 'category', 'description', 'moq', 'link']); w.writerows([['Good', 'G1', '10', 'A', 'ok', '', ''], ['Neg price', 'N1', '-5', 'A', '', '', ''], ['Comma price', 'C1', '1,299.00', 'A', '', '', ''], ['Bad MOQ', 'M1', '9', 'A', '', 'many', ''], ['JS link', 'J1', '9', 'A', '', '', 'javascript:alert(1)'], ['', 'NONAME', '9', 'A', 'no name row', '', ''], ['Euro comma', 'E1', '12,50', 'A', '', '', '']])
with open('quoted.csv', 'w', newline='') as f: w = csv.writer(f); w.writerow(['name', 'sku', 'price', 'category', 'description']); w.writerow(['Mug, large', 'Q1', '12.5', 'Kitchen', 'Line one\nLine two "quoted"'])
open('bom-semicolon.csv', 'w', encoding='utf-8-sig').write('name;sku;price;category;description\nSemi Mug;S1;7.25;Kitchen;semicolon separated\n')
open('rows.tsv', 'w').write('name\tsku\tprice\tcategory\tdescription\nTab Mug\tT1\t8\tKitchen\ttab separated\n')
with open('unicode.csv', 'w', newline='', encoding='utf-8') as f: w = csv.writer(f); w.writerow(['name', 'sku', 'price', 'category', 'description']); w.writerows([['Crème brûlée dish', 'U1', '14', 'Cuisine', 'Façade, naïve, Zürich'], ['湯呑み 茶碗', 'U2', '2200', '和食器', '手作りの陶器'], ['مصباح نحاسي', 'U3', '45', 'إضاءة', 'مصباح يدوي'], ['Star mug ⭐🎉', 'U4', 'Call for price', 'Gifts', 'emoji 😀 test'], ['Rupee tray ₹', 'U5', '999', 'Gifts', 'Ελληνικά, Русский']])
with open('long.csv', 'w', newline='') as f: w = csv.writer(f); w.writerow(['name', 'sku', 'price', 'category', 'description']); w.writerow(['Extraordinarily long product name that keeps going well past any sensible card width to test the two line cut off ' * 2, 'L1', '19', 'Long', ('Very long description sentence number one. ' * 20)])
with open('rows-300.csv', 'w', newline='') as f: w = csv.writer(f); w.writerow(['name', 'sku', 'price', 'category', 'description']); w.writerows([[f'Bulk {i}', f'B{i}', f'{i%90+1}.00', cats[i % 4], 'bulk row'] for i in range(300)])
def pdf(name, size, pages, label):
    c = canvas.Canvas(name, pagesize=size)
    for i in range(pages): c.setFont('Helvetica', 28); c.drawString(60, size[1]-100, f'{label} page {i+1}'); c.rect(40, 40, size[0]-80, size[1]-80); c.showPage()
    c.save()
pdf('sheet-letter-2p.pdf', letter, 2, 'Supplier sheet A'); pdf('sheet-a4-landscape.pdf', landscape(A4), 1, 'Supplier sheet B')
r = PdfReader('sheet-letter-2p.pdf'); w = PdfWriter(); [w.add_page(p) for p in r.pages]; w.encrypt('secret'); w.write('locked.pdf')
open('damaged.pdf', 'wb').write(open('sheet-letter-2p.pdf', 'rb').read()[:600])
d = docx.Document(); d.add_heading('Price list (Word)', 1); d.add_paragraph('Blue Mug — $12.50\nGreen Bowl — $18.00'); d.save('pricelist.docx')
open('notes.txt', 'w').write('Plain text section\nCare: hand wash only.\n')
photo('photo-section.png', 1200, 900, (20, 120, 120))
open('old.doc', 'wb').write(b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1' + b'\0' * 512)
z = zipfile.ZipFile('sheet.xlsx', 'w'); z.writestr('[Content_Types].xml', '<Types/>'); z.close()
open('brand.json', 'w').write('{"name":"Test Brand","primary":"#e11d48","accent":"#e11d48"}')
open('bad-saved.json', 'w').write('{"hello": "not a catalog"}')
