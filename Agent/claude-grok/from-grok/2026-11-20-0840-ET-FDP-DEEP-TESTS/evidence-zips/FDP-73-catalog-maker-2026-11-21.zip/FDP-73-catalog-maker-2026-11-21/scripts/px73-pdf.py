# FDP-73: PDF facts: pages, page sizes (pt), text per page (first 160 chars), fonts, images, links (URIs), outline titles, metadata title.
import sys, json; from pypdf import PdfReader
r = PdfReader(sys.argv[1]); o = {'pages': len(r.pages), 'sizes': sorted({(round(float(p.mediabox.width)), round(float(p.mediabox.height))) for p in r.pages}), 'title': (r.metadata or {}).get('/Title')}
o['text'] = [(p.extract_text() or '').replace('\n', ' | ')[:200] for p in r.pages[:4]] + ([(r.pages[-1].extract_text() or '').replace('\n', ' | ')[:300]] if len(r.pages) > 4 else [])
uris, imgs = [], 0
for p in r.pages:
    for a in p.get('/Annots') or []:
        a = a.get_object(); u = (a.get('/A') or {}).get('/URI')
        if u: uris.append(str(u))
    try: imgs += len(p.images)
    except Exception: pass
o['uris'] = uris[:6]; o['images'] = imgs
try: o['outline'] = [x.title for x in r.outline if hasattr(x, 'title')][:8]
except Exception: o['outline'] = None
print(json.dumps(o, ensure_ascii=False))
