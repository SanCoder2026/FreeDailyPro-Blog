// FDP-73: at the cap, build a catalog and press "Preview first page": what is shown (size, mark?). Guest; no sign-in.
const pw = require('playwright'); const fs = require('fs');
(async () => { const b = await pw.chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage(); const O = '/workspace/deep/73-catalog-maker/live/';
 await p.goto('https://www.freedailypro.com/tool/catalog-maker', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
 const used = await p.evaluate(() => localStorage.getItem('fdp-usage-v1'));
 await p.locator('#pcb-title').fill('Spring 2026 Product Catalog'); await p.getByLabel('Product 1 name', { exact: true }).fill('Blue Mug'); await p.getByLabel('Product 1 price', { exact: true }).fill('12.50');
 await p.locator('main input[type=file][accept="image/*"]').first().setInputFiles('/workspace/deep/73-catalog-maker/testfiles/mug-4x3.png'); await p.waitForTimeout(800);
 await p.locator('main button', { hasText: /^Build Catalog$/ }).click(); await p.waitForTimeout(3000);
 await p.locator('main button', { hasText: /Preview first page/ }).click(); await p.waitForTimeout(3000);
 const info = await p.evaluate(() => { const m = document.querySelector('main'); return [...m.querySelectorAll('img,canvas,iframe,embed,object')].filter(e => e.getBoundingClientRect().width > 100 && !e.closest('[data-ad-placement]')).map(e => e.tagName + ' ' + Math.round(e.getBoundingClientRect().width) + 'x' + Math.round(e.getBoundingClientRect().height) + ' nat ' + (e.naturalWidth || e.width) + 'x' + (e.naturalHeight || e.height) + ' ' + (e.src || '').slice(0, 20)); });
 await p.evaluate(() => { const i = [...document.querySelectorAll('main img[src^="blob:"]')].filter(e => e.getBoundingClientRect().width > 100).pop(); if (i) i.scrollIntoView({ block: 'center' }); }); await p.waitForTimeout(500); await p.screenshot({ path: O + 'cases/X20-preview-first-page.png' });
 fs.writeFileSync(O + 'preview.json', JSON.stringify({ used, info, text: (await p.locator('main').innerText()).match(/Download Catalog[^\n]*\n[^\n]*\n[^\n]*\n[^\n]*\n[^\n]*/)?.[0] }, null, 1)); console.log(used, info); await b.close(); })();
