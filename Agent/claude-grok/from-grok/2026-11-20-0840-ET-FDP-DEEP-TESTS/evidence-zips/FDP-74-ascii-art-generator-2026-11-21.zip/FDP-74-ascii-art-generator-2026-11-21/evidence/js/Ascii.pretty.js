import { r as B, j as p } from "./vendor-react-D01g8YgM.js";
import { ap as _, e as Y, T as Se, B as re } from "./index-B1CTyGtY.js";
import { T as we } from "./ToolPage-DwLoDncN.js";
import { T as ye } from "./ToolInfoSection-C0i6Zbwo.js";
import { u as Le } from "./useLogToolUsage-BdvvKW0n.js";
import { c as xe } from "./copyText-DPnES92p.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
var Ce = { FULL_WIDTH: 0, FITTING: 1, SMUSHING: 2, CONTROLLED_SMUSHING: 3 },
  be = class {
    constructor() {
      ((this.comment = ""), (this.numChars = 0), (this.options = {}));
    }
  },
  Z = [
    "1Row",
    "3-D",
    "3D Diagonal",
    "3D-ASCII",
    "3x5",
    "4Max",
    "5 Line Oblique",
    "AMC 3 Line",
    "AMC 3 Liv1",
    "AMC AAA01",
    "AMC Neko",
    "AMC Razor",
    "AMC Razor2",
    "AMC Slash",
    "AMC Slider",
    "AMC Thin",
    "AMC Tubes",
    "AMC Untitled",
    "ANSI Compact",
    "ANSI Regular",
    "ANSI Shadow",
    "ASCII 12",
    "ASCII 9",
    "ASCII New Roman",
    "Acrobatic",
    "Alligator",
    "Alligator2",
    "Alpha",
    "Alphabet",
    "Arrows",
    "Avatar",
    "B1FF",
    "Babyface Lame",
    "Babyface Leet",
    "Banner",
    "Banner3-D",
    "Banner3",
    "Banner4",
    "Barbwire",
    "Basic",
    "Bear",
    "Bell",
    "Benjamin",
    "Big ASCII 12",
    "Big ASCII 9",
    "Big Chief",
    "Big Money-ne",
    "Big Money-nw",
    "Big Money-se",
    "Big Money-sw",
    "Big Mono 12",
    "Big Mono 9",
    "Big",
    "Bigfig",
    "Binary",
    "Block",
    "Blocks",
    "Bloody",
    "BlurVision ASCII",
    "Bolger",
    "Braced",
    "Bright",
    "Broadway KB",
    "Broadway",
    "Bubble",
    "Bulbhead",
    "Caligraphy",
    "Caligraphy2",
    "Calvin S",
    "Cards",
    "Catwalk",
    "Chiseled",
    "Chunky",
    "Circle",
    "Classy",
    "Coder Mini",
    "Coinstak",
    "Cola",
    "Colossal",
    "Computer",
    "Contessa",
    "Contrast",
    "Cosmike",
    "Cosmike2",
    "Crawford",
    "Crawford2",
    "Crazy",
    "Cricket",
    "Cursive",
    "Cyberlarge",
    "Cybermedium",
    "Cybersmall",
    "Cygnet",
    "DANC4",
    "DOS Rebel",
    "DWhistled",
    "Dancing Font",
    "Decimal",
    "Def Leppard",
    "Delta Corps Priest 1",
    "DiamFont",
    "Diamond",
    "Diet Cola",
    "Digital",
    "Doh",
    "Doom",
    "Dot Matrix",
    "Double Shorts",
    "Double",
    "Dr Pepper",
    "Efti Chess",
    "Efti Font",
    "Efti Italic",
    "Efti Piti",
    "Efti Robot",
    "Efti Wall",
    "Efti Water",
    "Electronic",
    "Elite",
    "Emboss 2",
    "Emboss",
    "Epic",
    "Fender",
    "Filter",
    "Fire Font-k",
    "Fire Font-s",
    "Flipped",
    "Flower Power",
    "Font Font",
    "Four Tops",
    "Fraktur",
    "Fun Face",
    "Fun Faces",
    "Future Smooth",
    "Future Thin",
    "Future",
    "Fuzzy",
    "Georgi16",
    "Georgia11",
    "Ghost",
    "Ghoulish",
    "Glenyn",
    "Goofy",
    "Gothic",
    "Graceful",
    "Gradient",
    "Graffiti",
    "Greek",
    "Heart Left",
    "Heart Right",
    "Henry 3D",
    "Hex",
    "Hieroglyphs",
    "Hollywood",
    "Horizontal Left",
    "Horizontal Right",
    "ICL-1900",
    "Impossible",
    "Invita",
    "Isometric1",
    "Isometric2",
    "Isometric3",
    "Isometric4",
    "Italic",
    "Ivrit",
    "JS Block Letters",
    "JS Bracket Letters",
    "JS Capital Curves",
    "JS Cursive",
    "JS Stick Letters",
    "Jacky",
    "Jazmine",
    "Jerusalem",
    "Katakana",
    "Kban",
    "Keyboard",
    "Knob",
    "Konto Slant",
    "Konto",
    "LCD",
    "Larry 3D 2",
    "Larry 3D",
    "Lean",
    "Letter",
    "Letters",
    "Lil Devil",
    "Line Blocks",
    "Linguaholic Mini Block",
    "Linguaholic Neon",
    "Linguaholic Rounded",
    "Linguaholic Shadow 3D",
    "Linux",
    "Lockergnome",
    "Madrid",
    "Marquee",
    "Maxfour",
    "Merlin1",
    "Merlin2",
    "Mike",
    "Mini",
    "Mirror",
    "Mnemonic",
    "Modular",
    "Mono 12",
    "Mono 9",
    "Morse",
    "Morse2",
    "Moscow",
    "Mshebrew210",
    "Muzzle",
    "NScript",
    "NT Greek",
    "NV Script",
    "Nancyj-Fancy",
    "Nancyj-Improved",
    "Nancyj-Underlined",
    "Nancyj",
    "Nipples",
    "O8",
    "OS2",
    "Octal",
    "Ogre",
    "Old Banner",
    "Pagga",
    "Patorjk's Cheese",
    "Patorjk-HeX",
    "Pawp",
    "Peaks Slant",
    "Peaks",
    "Pebbles",
    "Pepper",
    "Poison",
    "Puffy",
    "Puzzle",
    "Pyramid",
    "Rammstein",
    "Rebel",
    "Rectangles",
    "Red Phoenix",
    "Relief",
    "Relief2",
    "Reverse",
    "Roman",
    "Rot13",
    "Rotated",
    "Rounded",
    "Rowan Cap",
    "Rozzo",
    "RubiFont",
    "Runic",
    "Runyc",
    "S Blood",
    "SL Script",
    "Santa Clara",
    "Script",
    "Serifcap",
    "Shaded Blocky",
    "Shadow",
    "Shimrod",
    "Short",
    "Slant Relief",
    "Slant",
    "Slide",
    "Small ASCII 12",
    "Small ASCII 9",
    "Small Block",
    "Small Braille",
    "Small Caps",
    "Small Isometric1",
    "Small Keyboard",
    "Small Mono 12",
    "Small Mono 9",
    "Small Poison",
    "Small Script",
    "Small Shadow",
    "Small Slant",
    "Small Tengwar",
    "Small",
    "Soft",
    "Speed",
    "Spliff",
    "Stacey",
    "Stampate",
    "Stampatello",
    "Standard",
    "Star Strips",
    "Star Wars",
    "Stellar",
    "Stforek",
    "Stick Letters",
    "Stop",
    "Straight",
    "Stronger Than All",
    "Sub-Zero",
    "Swamp Land",
    "Swan",
    "Sweet",
    "THIS",
    "Tanja",
    "Tengwar",
    "Term",
    "Terrace",
    "Test1",
    "The Edge",
    "Thick",
    "Thin",
    "Thorned",
    "Three Point",
    "Ticks Slant",
    "Ticks",
    "Tiles",
    "Tinker-Toy",
    "Tmplr",
    "Tombstone",
    "Train",
    "Trek",
    "Tsalagi",
    "Tubular",
    "Twisted",
    "Two Point",
    "USA Flag",
    "Univers",
    "Upside Down Text",
    "Varsity",
    "Wavescape",
    "Wavy",
    "Weird",
    "Wet Letter",
    "Whimsy",
    "WideTerm",
    "Wow",
    "miniwi",
  ],
  ie = { "ANSI-Compact": "ANSI Compact" },
  W = (m) => (ie[m] ? ie[m] : m);
function _e(m) {
  return /[.*+?^${}()|[\]\\]/.test(m) ? "\\" + m : m;
}
var le = (() => {
  const {
      FULL_WIDTH: m = 0,
      FITTING: R,
      SMUSHING: w,
      CONTROLLED_SMUSHING: I,
    } = Ce,
    S = {},
    y = { font: "Standard", fontPath: "./fonts", fetchFontIfMissing: !0 };
  function L(n, r, e) {
    const t = _e(n.trim().slice(-1)) || "@",
      i = r === e - 1 ? new RegExp(t + t + "?\\s*$") : new RegExp(t + "\\s*$");
    return n.replace(i, "");
  }
  function M(n = -1, r = null) {
    let e = {},
      t,
      i = [
        [16384, "vLayout", w],
        [8192, "vLayout", R],
        [4096, "vRule5", !0],
        [2048, "vRule4", !0],
        [1024, "vRule3", !0],
        [512, "vRule2", !0],
        [256, "vRule1", !0],
        [128, "hLayout", w],
        [64, "hLayout", R],
        [32, "hRule6", !0],
        [16, "hRule5", !0],
        [8, "hRule4", !0],
        [4, "hRule3", !0],
        [2, "hRule2", !0],
        [1, "hRule1", !0],
      ];
    t = r !== null ? r : n;
    for (const [l, o, a] of i)
      t >= l
        ? ((t -= l), e[o] === void 0 && (e[o] = a))
        : o !== "vLayout" && o !== "hLayout" && (e[o] = !1);
    return (
      typeof e.hLayout > "u"
        ? n === 0
          ? (e.hLayout = R)
          : n === -1
            ? (e.hLayout = m)
            : e.hRule1 ||
                e.hRule2 ||
                e.hRule3 ||
                e.hRule4 ||
                e.hRule5 ||
                e.hRule6
              ? (e.hLayout = I)
              : (e.hLayout = w)
        : e.hLayout === w &&
          (e.hRule1 ||
            e.hRule2 ||
            e.hRule3 ||
            e.hRule4 ||
            e.hRule5 ||
            e.hRule6) &&
          (e.hLayout = I),
      typeof e.vLayout > "u"
        ? e.vRule1 || e.vRule2 || e.vRule3 || e.vRule4 || e.vRule5
          ? (e.vLayout = I)
          : (e.vLayout = m)
        : e.vLayout === w &&
          (e.vRule1 || e.vRule2 || e.vRule3 || e.vRule4 || e.vRule5) &&
          (e.vLayout = I),
      e
    );
  }
  function F(n, r, e = "") {
    return n === r && n !== e ? n : !1;
  }
  function k(n, r) {
    let e = "|/\\[]{}()<>";
    if (n === "_") {
      if (e.indexOf(r) !== -1) return r;
    } else if (r === "_" && e.indexOf(n) !== -1) return n;
    return !1;
  }
  function j(n, r) {
    let e = "| /\\ [] {} () <>",
      t = e.indexOf(n),
      i = e.indexOf(r);
    if (t !== -1 && i !== -1 && t !== i && Math.abs(t - i) !== 1) {
      const l = Math.max(t, i),
        o = l + 1;
      return e.substring(l, o);
    }
    return !1;
  }
  function U(n, r) {
    let e = "[] {} ()",
      t = e.indexOf(n),
      i = e.indexOf(r);
    return t !== -1 && i !== -1 && Math.abs(t - i) <= 1 ? "|" : !1;
  }
  function z(n, r) {
    return { "/\\": "|", "\\/": "Y", "><": "X" }[n + r] || !1;
  }
  function A(n, r, e = "") {
    return n === e && r === e ? e : !1;
  }
  function J(n, r) {
    return n === r ? n : !1;
  }
  function K(n, r) {
    return k(n, r);
  }
  function H(n, r) {
    return j(n, r);
  }
  function d(n, r) {
    return (n === "-" && r === "_") || (n === "_" && r === "-") ? "=" : !1;
  }
  function X(n, r) {
    return n === "|" && r === "|" ? "|" : !1;
  }
  function P(n, r, e) {
    return r === " " || r === "" || (r === e && n !== " ") ? n : r;
  }
  function ue(n, r, e) {
    if (e.fittingRules && e.fittingRules.vLayout === m) return "invalid";
    let t,
      i = Math.min(n.length, r.length),
      l,
      o,
      a = !1,
      s;
    if (i === 0) return "invalid";
    for (t = 0; t < i; t++)
      if (
        ((l = n.substring(t, t + 1)),
        (o = r.substring(t, t + 1)),
        l !== " " && o !== " ")
      ) {
        if (e.fittingRules && e.fittingRules.vLayout === R) return "invalid";
        if (e.fittingRules && e.fittingRules.vLayout === w) return "end";
        if (X(l, o)) {
          a = a || !1;
          continue;
        }
        if (
          ((s = !1),
          (s = e.fittingRules && e.fittingRules.vRule1 ? J(l, o) : s),
          (s = !s && e.fittingRules && e.fittingRules.vRule2 ? K(l, o) : s),
          (s = !s && e.fittingRules && e.fittingRules.vRule3 ? H(l, o) : s),
          (s = !s && e.fittingRules && e.fittingRules.vRule4 ? d(l, o) : s),
          (a = !0),
          !s)
        )
          return "invalid";
      }
    return a ? "end" : "valid";
  }
  function fe(n, r, e) {
    let t = n.length,
      i = n.length,
      l,
      o,
      a,
      s = 1,
      u,
      h,
      f;
    for (; s <= t;) {
      for (
        l = n.slice(Math.max(0, i - s), i),
          o = r.slice(0, Math.min(t, s)),
          a = o.length,
          f = "",
          u = 0;
        u < a;
        u++
      )
        if (((h = ue(l[u], o[u], e)), h === "end")) f = h;
        else if (h === "invalid") {
          f = h;
          break;
        } else f === "" && (f = "valid");
      if (f === "invalid") {
        s--;
        break;
      }
      if (f === "end") break;
      f === "valid" && s++;
    }
    return Math.min(t, s);
  }
  function he(n, r, e) {
    let t,
      i = Math.min(n.length, r.length),
      l,
      o,
      a = "",
      s;
    const u = e.fittingRules || {};
    for (t = 0; t < i; t++)
      ((l = n.substring(t, t + 1)),
        (o = r.substring(t, t + 1)),
        l !== " " && o !== " "
          ? u.vLayout === R || u.vLayout === w
            ? (a += P(l, o))
            : ((s = !1),
              (s = u.vRule5 ? X(l, o) : s),
              (s = !s && u.vRule1 ? J(l, o) : s),
              (s = !s && u.vRule2 ? K(l, o) : s),
              (s = !s && u.vRule3 ? H(l, o) : s),
              (s = !s && u.vRule4 ? d(l, o) : s),
              (a += s))
          : (a += P(l, o)));
    return a;
  }
  function ce(n, r, e, t) {
    let i = n.length,
      l = r.length,
      o = n.slice(0, Math.max(0, i - e)),
      a = n.slice(Math.max(0, i - e), i),
      s = r.slice(0, Math.min(e, l)),
      u,
      h,
      f,
      c = [],
      g;
    for (h = a.length, u = 0; u < h; u++)
      (u >= l ? (f = a[u]) : (f = he(a[u], s[u], t)), c.push(f));
    return ((g = r.slice(Math.min(e, l), l)), [...o, ...c, ...g]);
  }
  function ee(n, r) {
    const e = " ".repeat(r);
    return n.map((t) => t + e);
  }
  function me(n, r, e) {
    let t = n[0].length,
      i = r[0].length,
      l;
    return (
      t > i ? (r = ee(r, t - i)) : i > t && (n = ee(n, i - t)),
      (l = fe(n, r, e)),
      ce(n, r, l, e)
    );
  }
  function de(n, r, e) {
    const t = e.fittingRules || {};
    if (t.hLayout === m) return 0;
    let i,
      l = n.length,
      o = r.length,
      a = l,
      s = 1,
      u = !1,
      h,
      f,
      c,
      g;
    if (l === 0) return 0;
    e: for (; s <= a;) {
      const E = l - s;
      for (
        h = n.substring(E, E + s), f = r.substring(0, Math.min(s, o)), i = 0;
        i < Math.min(s, o);
        i++
      )
        if (
          ((c = h.substring(i, i + 1)),
          (g = f.substring(i, i + 1)),
          c !== " " && g !== " ")
        ) {
          if (t.hLayout === R) {
            s = s - 1;
            break e;
          } else if (t.hLayout === w) {
            (c === e.hardBlank || g === e.hardBlank) && (s = s - 1);
            break e;
          } else if (
            ((u = !0),
            !(
              (t.hRule1 && F(c, g, e.hardBlank)) ||
              (t.hRule2 && k(c, g)) ||
              (t.hRule3 && j(c, g)) ||
              (t.hRule4 && U(c, g)) ||
              (t.hRule5 && z(c, g)) ||
              (t.hRule6 && A(c, g, e.hardBlank))
            ))
          ) {
            s = s - 1;
            break e;
          }
        }
      if (u) break;
      s++;
    }
    return Math.min(a, s);
  }
  function q(n, r, e, t) {
    let i,
      l,
      o = [],
      a,
      s,
      u,
      h,
      f,
      c,
      g,
      E;
    const C = t.fittingRules || {};
    if (typeof t.height != "number") throw new Error("height is not defined.");
    for (i = 0; i < t.height; i++) {
      ((g = n[i]),
        (E = r[i]),
        (f = g.length),
        (c = E.length),
        (a = f - e),
        (s = g.slice(0, Math.max(0, a))),
        (u = ""));
      const $ = Math.max(0, f - e);
      let T = g.substring($, $ + e),
        N = E.substring(0, Math.min(e, c));
      for (l = 0; l < e; l++) {
        let b = l < f ? T.substring(l, l + 1) : " ",
          x = l < c ? N.substring(l, l + 1) : " ";
        if (b !== " " && x !== " ")
          if (C.hLayout === R || C.hLayout === w) u += P(b, x, t.hardBlank);
          else {
            const V =
              (C.hRule1 && F(b, x, t.hardBlank)) ||
              (C.hRule2 && k(b, x)) ||
              (C.hRule3 && j(b, x)) ||
              (C.hRule4 && U(b, x)) ||
              (C.hRule5 && z(b, x)) ||
              (C.hRule6 && A(b, x, t.hardBlank)) ||
              P(b, x, t.hardBlank);
            u += V;
          }
        else u += P(b, x, t.hardBlank);
      }
      (e >= c ? (h = "") : (h = E.substring(e, e + Math.max(0, c - e))),
        (o[i] = s + u + h));
    }
    return o;
  }
  function O(n) {
    return new Array(n).fill("");
  }
  const G = function (n) {
    return Math.max(...n.map((r) => r.length));
  };
  function D(n, r, e) {
    return n.reduce(function (t, i) {
      return q(t, i.fig, i.overlap || 0, e);
    }, O(r));
  }
  function ge(n, r, e) {
    for (let t = n.length - 1; t > 0; t--) {
      const i = D(n.slice(0, t), r, e);
      if (G(i) <= e.width) return { outputFigText: i, chars: n.slice(t) };
    }
    return n.length > 0
      ? { outputFigText: D([n[0]], r, e), chars: n.slice(1) }
      : { outputFigText: O(r), chars: n };
  }
  function Re(n, r, e) {
    let t,
      i,
      l = 0,
      o,
      a,
      s,
      u = e.height,
      h = [],
      f,
      c = { chars: [], overlap: l },
      g = [],
      E,
      C,
      $,
      T,
      N;
    if (typeof u != "number") throw new Error("height is not defined.");
    a = O(u);
    const b = e.fittingRules || {},
      x = [...n];
    for (e.printDirection === 1 && x.reverse(), s = x.length, t = 0; t < s; t++)
      if (
        ((E = x[t]),
        (C = E.match(/\s/)),
        (i = r[E.codePointAt(0)] ?? r[0]),
        (T = null),
        i)
      ) {
        if (b.hLayout !== m) {
          for (l = 1e4, o = 0; o < u; o++) l = Math.min(l, de(a[o], i[o], e));
          l = l === 1e4 ? 0 : l;
        }
        if (
          (e.width > 0 &&
            (e.whitespaceBreak
              ? (($ = D(c.chars.concat([{ fig: i, overlap: l }]), u, e)),
                (T = D(g.concat([{ fig: $, overlap: c.overlap }]), u, e)),
                (f = G(T)))
              : ((T = q(a, i, l, e)), (f = G(T))),
            f >= e.width &&
              t > 0 &&
              (e.whitespaceBreak
                ? ((a = D(g.slice(0, -1), u, e)),
                  g.length > 1 && (h.push(a), (a = O(u))),
                  (g = []))
                : (h.push(a), (a = O(u))))),
          e.width > 0 &&
            e.whitespaceBreak &&
            ((!C || t === s - 1) && c.chars.push({ fig: i, overlap: l }),
            C || t === s - 1))
        ) {
          for (N = null; (T = D(c.chars, u, e)), (f = G(T)), f >= e.width;)
            ((N = ge(c.chars, u, e)),
              (c = { chars: N.chars }),
              h.push(N.outputFigText));
          (f > 0 &&
            (N
              ? g.push({ fig: T, overlap: 1 })
              : g.push({ fig: T, overlap: c.overlap })),
            C && (g.push({ fig: i, overlap: l }), (a = O(u))),
            t === s - 1 && (a = D(g, u, e)),
            (c = { chars: [], overlap: l }));
          continue;
        }
        a = q(a, i, l, e);
      }
    return (
      G(a) > 0 && h.push(a),
      e.showHardBlanks ||
        h.forEach(function (V) {
          for (s = V.length, o = 0; o < s; o++)
            V[o] = V[o].replace(new RegExp("\\" + e.hardBlank, "g"), " ");
        }),
      n === "" && h.length === 0 && h.push(new Array(u).fill("")),
      h
    );
  }
  const pe = function (n, r) {
      let e;
      const t = r.fittingRules || {};
      if (n === "default")
        e = {
          hLayout: t.hLayout,
          hRule1: t.hRule1,
          hRule2: t.hRule2,
          hRule3: t.hRule3,
          hRule4: t.hRule4,
          hRule5: t.hRule5,
          hRule6: t.hRule6,
        };
      else if (n === "full")
        e = {
          hLayout: m,
          hRule1: !1,
          hRule2: !1,
          hRule3: !1,
          hRule4: !1,
          hRule5: !1,
          hRule6: !1,
        };
      else if (n === "fitted")
        e = {
          hLayout: R,
          hRule1: !1,
          hRule2: !1,
          hRule3: !1,
          hRule4: !1,
          hRule5: !1,
          hRule6: !1,
        };
      else if (n === "controlled smushing")
        e = {
          hLayout: I,
          hRule1: !0,
          hRule2: !0,
          hRule3: !0,
          hRule4: !0,
          hRule5: !0,
          hRule6: !0,
        };
      else if (n === "universal smushing")
        e = {
          hLayout: w,
          hRule1: !1,
          hRule2: !1,
          hRule3: !1,
          hRule4: !1,
          hRule5: !1,
          hRule6: !1,
        };
      else return;
      return e;
    },
    ve = function (n, r) {
      let e = {};
      const t = r.fittingRules || {};
      if (n === "default")
        e = {
          vLayout: t.vLayout,
          vRule1: t.vRule1,
          vRule2: t.vRule2,
          vRule3: t.vRule3,
          vRule4: t.vRule4,
          vRule5: t.vRule5,
        };
      else if (n === "full")
        e = {
          vLayout: m,
          vRule1: !1,
          vRule2: !1,
          vRule3: !1,
          vRule4: !1,
          vRule5: !1,
        };
      else if (n === "fitted")
        e = {
          vLayout: R,
          vRule1: !1,
          vRule2: !1,
          vRule3: !1,
          vRule4: !1,
          vRule5: !1,
        };
      else if (n === "controlled smushing")
        e = {
          vLayout: I,
          vRule1: !0,
          vRule2: !0,
          vRule3: !0,
          vRule4: !0,
          vRule5: !0,
        };
      else if (n === "universal smushing")
        e = {
          vLayout: w,
          vRule1: !1,
          vRule2: !1,
          vRule3: !1,
          vRule4: !1,
          vRule5: !1,
        };
      else return;
      return e;
    },
    te = function (n, r, e) {
      e = e
        .replace(
          /\r\n/g,
          `
`,
        )
        .replace(
          /\r/g,
          `
`,
        );
      const t = W(n);
      let i = e.split(`
`),
        l = [],
        o,
        a,
        s;
      for (a = i.length, o = 0; o < a; o++) l = l.concat(Re(i[o], S[t], r));
      for (a = l.length, s = l[0], o = 1; o < a; o++) s = me(s, l[o], r);
      return s
        ? s.join(`
`)
        : "";
    };
  function ne(n, r) {
    let e;
    if (
      (typeof structuredClone < "u"
        ? (e = structuredClone(n))
        : (e = JSON.parse(JSON.stringify(n))),
      (e.showHardBlanks = r.showHardBlanks || !1),
      (e.width = r.width || -1),
      (e.whitespaceBreak = r.whitespaceBreak || !1),
      r.horizontalLayout)
    ) {
      const t = pe(r.horizontalLayout, n);
      t && Object.assign(e.fittingRules, t);
    }
    if (r.verticalLayout) {
      const t = ve(r.verticalLayout, n);
      t && Object.assign(e.fittingRules, t);
    }
    return (
      (e.printDirection =
        r.printDirection !== null && r.printDirection !== void 0
          ? r.printDirection
          : n.printDirection),
      e
    );
  }
  const v = async function (n, r, e) {
    return v.text(n, r, e);
  };
  return (
    (v.text = async function (n, r, e) {
      n = n + "";
      let t, i;
      typeof r == "function"
        ? ((i = r), (t = { font: y.font }))
        : typeof r == "string"
          ? ((t = { font: r }), (i = e))
          : r
            ? ((t = r), (i = e))
            : ((t = { font: y.font }), (i = e));
      const l = t.font || y.font;
      try {
        const o = await v.loadFont(l),
          a = o ? te(l, ne(o, t), n) : "";
        return (i && i(null, a), a);
      } catch (o) {
        const a = o instanceof Error ? o : new Error(String(o));
        if (i) return (i(a), "");
        throw a;
      }
    }),
    (v.textSync = function (n, r) {
      ((n = n + ""), typeof r == "string" ? (r = { font: r }) : (r = r || {}));
      const e = r.font || y.font;
      let t = ne(v.loadFontSync(e), r);
      return te(e, t, n);
    }),
    (v.metadata = async function (n, r) {
      n = n + "";
      try {
        const e = await v.loadFont(n);
        if (!e) throw new Error("Error loading font.");
        const t = W(n),
          i = S[t] || {},
          l = [e, i.comment || ""];
        return (r && r(null, e, i.comment), l);
      } catch (e) {
        const t = e instanceof Error ? e : new Error(String(e));
        if (r) return (r(t), null);
        throw t;
      }
    }),
    (v.defaults = function (n) {
      return (
        n && typeof n == "object" && Object.assign(y, n),
        typeof structuredClone < "u"
          ? structuredClone(y)
          : JSON.parse(JSON.stringify(y))
      );
    }),
    (v.parseFont = function (n, r, e = !0) {
      if (S[n] && !e) return S[n].options;
      r = r
        .replace(
          /\r\n/g,
          `
`,
        )
        .replace(
          /\r/g,
          `
`,
        );
      const t = new be(),
        i = r.split(`
`),
        l = i.shift();
      if (!l) throw new Error("Invalid font file: missing header");
      const o = l.split(" "),
        a = {
          hardBlank: o[0].substring(5, 6),
          height: parseInt(o[1], 10),
          baseline: parseInt(o[2], 10),
          maxLength: parseInt(o[3], 10),
          oldLayout: parseInt(o[4], 10),
          numCommentLines: parseInt(o[5], 10),
          printDirection: o[6] ? parseInt(o[6], 10) : 0,
          fullLayout: o[7] ? parseInt(o[7], 10) : null,
          codeTagCount: o[8] ? parseInt(o[8], 10) : null,
        };
      if (
        (a.hardBlank || "").length !== 1 ||
        [
          a.height,
          a.baseline,
          a.maxLength,
          a.oldLayout,
          a.numCommentLines,
        ].some((u) => u == null || isNaN(u))
      )
        throw new Error("FIGlet header contains invalid values.");
      if (a.height == null || a.numCommentLines == null)
        throw new Error("FIGlet header contains invalid values.");
      if (
        a.height < 1 ||
        a.baseline < 0 ||
        a.maxLength < 0 ||
        a.numCommentLines < 0
      )
        throw new Error("FIGlet header contains invalid values.");
      ((a.fittingRules = M(a.oldLayout, a.fullLayout)), (t.options = a));
      const s = [];
      for (let u = 32; u <= 126; u++) s.push(u);
      if (
        (s.push(196, 214, 220, 228, 246, 252, 223),
        i.length < a.numCommentLines + a.height * s.length)
      )
        throw new Error(
          `FIGlet file is missing data. Line length: ${i.length}. Comment lines: ${a.numCommentLines}. Height: ${a.height}. Num chars: ${s.length}.`,
        );
      for (
        t.comment = i.splice(0, a.numCommentLines).join(`
`),
          t.numChars = 0;
        i.length > 0 && t.numChars < s.length;
      ) {
        const u = s[t.numChars];
        t[u] = i.splice(0, a.height);
        for (let h = 0; h < a.height; h++)
          typeof t[u][h] > "u"
            ? (t[u][h] = "")
            : (t[u][h] = L(t[u][h], h, a.height));
        t.numChars++;
      }
      for (; i.length > 0;) {
        const u = i.shift();
        if (!u || u.trim() === "") break;
        let h = u.split(" ")[0],
          f;
        if (/^-?0[xX][0-9a-fA-F]+$/.test(h)) f = parseInt(h, 16);
        else if (/^-?0[0-7]+$/.test(h)) f = parseInt(h, 8);
        else if (/^-?[0-9]+$/.test(h)) f = parseInt(h, 10);
        else throw new Error(`Error parsing data. Invalid data: ${h}`);
        if (f === -1 || f < -2147483648 || f > 2147483647)
          throw new Error(
            `Error parsing data. ${f === -1 ? "The char code -1 is not permitted." : `The char code cannot be ${f < -2147483648 ? "less than -2147483648" : "greater than 2147483647"}.`}`,
          );
        t[f] = i.splice(0, a.height);
        for (let c = 0; c < a.height; c++)
          typeof t[f][c] > "u"
            ? (t[f][c] = "")
            : (t[f][c] = L(t[f][c], c, a.height));
        t.numChars++;
      }
      return ((S[n] = t), a);
    }),
    (v.loadedFonts = () => Object.keys(S)),
    (v.clearLoadedFonts = () => {
      Object.keys(S).forEach((n) => {
        delete S[n];
      });
    }),
    (v.loadFont = async function (n, r) {
      const e = W(n);
      if (S[e]) {
        const t = S[e].options;
        return (r && r(null, t), Promise.resolve(t));
      }
      try {
        if (!y.fetchFontIfMissing) throw new Error(`Font is not loaded: ${e}`);
        const t = await fetch(`${y.fontPath}/${e}.flf`);
        if (!t.ok) throw new Error(`Network response was not ok: ${t.status}`);
        const i = await t.text(),
          l = v.parseFont(e, i);
        return (r && r(null, l), l);
      } catch (t) {
        const i = t instanceof Error ? t : new Error(String(t));
        if (r) return (r(i), null);
        throw i;
      }
    }),
    (v.loadFontSync = function (n) {
      const r = W(n);
      if (S[r]) return S[r].options;
      throw new Error(
        "Synchronous font loading is not implemented for the browser, it will only work for fonts already loaded.",
      );
    }),
    (v.preloadFonts = async function (n, r) {
      try {
        for (const e of n) {
          const t = W(e),
            i = await fetch(`${y.fontPath}/${t}.flf`);
          if (!i.ok)
            throw new Error(
              `Failed to preload fonts. Error fetching font: ${t}, status code: ${i.statusText}`,
            );
          const l = await i.text();
          v.parseFont(t, l);
        }
        r && r();
      } catch (e) {
        const t = e instanceof Error ? e : new Error(String(e));
        if (r) {
          r(t);
          return;
        }
        throw e;
      }
    }),
    (v.fonts = function (n) {
      return new Promise(function (r, e) {
        (r(Z), n && n(null, Z));
      });
    }),
    (v.fontsSync = function () {
      return Z;
    }),
    (v.figFonts = S),
    v
  );
})();
const se = {
    Standard: () => _(() => import("./Standard-CtX3eT6v.js"), []),
    Big: () => _(() => import("./Big-5ynOV6De.js"), []),
    Slant: () => _(() => import("./Slant-BIsbx0hW.js"), []),
    Small: () => _(() => import("./Small-B8dNERiI.js"), []),
    Mini: () => _(() => import("./Mini-iROdYdWk.js"), []),
    Banner3: () => _(() => import("./Banner3-BWpN-5I1.js"), []),
    Block: () => _(() => import("./Block-92kD1YsY.js"), []),
    "ANSI Shadow": () => _(() => import("./ANSI Shadow-BjrKADDm.js"), []),
    Doom: () => _(() => import("./Doom-C79xZok0.js"), []),
    Graffiti: () => _(() => import("./Graffiti-BfIn4fuz.js"), []),
    Ghost: () => _(() => import("./Ghost-BMm0TSUS.js"), []),
    Bubble: () => _(() => import("./Bubble-DDBIYRhU.js"), []),
  },
  ae = new Set(),
  oe = (m) => /^[\x00-\x7f]*$/.test(m),
  Ie = {
    ß: "ss",
    æ: "ae",
    Æ: "AE",
    œ: "oe",
    Œ: "OE",
    ø: "o",
    Ø: "O",
    đ: "d",
    Đ: "D",
    ł: "l",
    Ł: "L",
    ð: "d",
    Ð: "D",
    þ: "th",
    Þ: "TH",
    ı: "i",
    "‘": "'",
    "’": "'",
    "“": '"',
    "”": '"',
    "–": "-",
    "—": "-",
    "…": "...",
  };
function Ee(m) {
  return m
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^\x00-\x7f]/g, (R) => Ie[R] ?? R)
    .normalize("NFC");
}
async function Te(m, R, w = "left") {
  const I = se[R];
  if (!I) throw new Error(`Unknown font ${R}`);
  if (!ae.has(R)) {
    const L = await I();
    (le.parseFont(R, L.default), ae.add(R));
  }
  let y = m
    .split(
      `
`,
    )
    .map((L) =>
      L.trim() ? le.textSync(L, { font: R }).replace(/\s+$/gm, "") : "",
    )
    .join(
      `

`,
    )
    .replace(/^\n+|\n+$/g, "");
  if (w === "center") {
    const L = y.split(`
`),
      M = Math.max(...L.map((F) => F.length));
    y = L.map((F) => " ".repeat(Math.floor((M - F.length) / 2)) + F).join(`
`);
  }
  return y;
}
const Fe = (m) =>
    Math.max(
      0,
      ...m
        .split(
          `
`,
        )
        .map((R) => R.length),
    ),
  Q = {
    what: "Converts text into ASCII art — an image made entirely of text characters — for a retro-style banner or decorative text in a plain-text context like a code comment, terminal output, or README file, where an actual image file isn't an option.",
    how: "Type your text (several lines make several banners), pick a font and alignment, and copy the result. The preview can be zoomed; a note tells you if the art is wider than 80 columns.",
    tip: "ASCII art displays correctly only in a monospaced font — if you paste it somewhere with a proportional font, the alignment will look broken even though the text itself is correct. Code editors, terminals, and plain-text files almost always use a monospaced font by default, which is why this works well for those specific contexts but not for a regular word processor or webpage without adjusting the font first.",
  };
function lt() {
  const [m, R] = B.useState("Hello"),
    [w, I] = B.useState("Standard"),
    [S, y] = B.useState("left"),
    [L, M] = B.useState(""),
    [F, k] = B.useState(""),
    [j, U] = B.useState(12),
    z = B.useRef(null);
  B.useEffect(() => {
    const d = z.current?.value;
    d !== void 0 && d !== m && R(d.slice(0, 60));
  }, []);
  const A = Ee(m),
    J = A !== m;
  B.useEffect(() => {
    let d = !0;
    if (!A.trim()) {
      (M(""), k(""));
      return;
    }
    if (!oe(A)) {
      (M(""),
        k(
          "Banner fonts only contain plain English letters, digits and punctuation. Hindi, emoji and other scripts can't be drawn — remove them to continue. (Accented Latin letters are converted automatically.)",
        ));
      return;
    }
    return (
      Te(A, w, S)
        .then((X) => {
          d && (M(X), k(""));
        })
        .catch(() => {
          d && k("Couldn't load that font. Try another one.");
        }),
      () => {
        d = !1;
      }
    );
  }, [A, w, S]);
  const K = () => {
    xe(L, "Copied to clipboard");
  };
  Le(L, void 0, { ownActions: !0 });
  const H = Fe(L);
  return p.jsxs(we, {
    children: [
      p.jsxs("div", {
        className: "grid grid-cols-1 md:grid-cols-3 gap-4",
        children: [
          p.jsxs("div", {
            className: "md:col-span-2",
            children: [
              p.jsx(Y, {
                className: "mb-2 block",
                children: "Text (one banner per line)",
              }),
              p.jsx(Se, {
                "aria-label": "Text (one banner per line)",
                ref: z,
                value: m,
                onChange: (d) => R(d.target.value.slice(0, 60)),
                placeholder: "Hello",
                rows: 2,
              }),
            ],
          }),
          p.jsxs("div", {
            className: "space-y-3",
            children: [
              p.jsxs("div", {
                children: [
                  p.jsx(Y, { className: "mb-2 block", children: "Font" }),
                  p.jsx("select", {
                    className:
                      "border rounded px-2 py-1.5 w-full bg-background text-sm",
                    value: w,
                    onChange: (d) => I(d.target.value),
                    "aria-label": "Banner font",
                    children: Object.keys(se).map((d) =>
                      p.jsx("option", { value: d, children: d }, d),
                    ),
                  }),
                ],
              }),
              p.jsx("div", {
                className: "flex gap-2",
                role: "group",
                "aria-label": "Alignment",
                children: ["left", "center"].map((d) =>
                  p.jsx(
                    re,
                    {
                      type: "button",
                      size: "sm",
                      variant: S === d ? "default" : "outline",
                      "aria-pressed": S === d,
                      onClick: () => y(d),
                      children: d === "left" ? "Left" : "Centre",
                    },
                    d,
                  ),
                ),
              }),
            ],
          }),
        ],
      }),
      p.jsxs("div", {
        className: "flex items-center gap-3 mt-4",
        children: [
          p.jsx(Y, { className: "text-sm shrink-0", children: "Preview zoom" }),
          p.jsx("input", {
            type: "range",
            min: 8,
            max: 22,
            value: j,
            onChange: (d) => U(Number(d.target.value)),
            className: "w-full",
            "aria-label": "Preview zoom",
          }),
        ],
      }),
      J &&
        oe(A) &&
        p.jsxs("p", {
          className: "mt-4 text-xs text-muted-foreground",
          role: "status",
          "data-testid": "ascii-translit",
          children: [
            'Accented letters were drawn without their accents (for example "',
            A.split(
              `
`,
            )[0].slice(0, 30),
            '"), because banner fonts only have plain letters.',
          ],
        }),
      F &&
        p.jsx("p", {
          className: "mt-4 text-sm text-destructive",
          role: "alert",
          children: F,
        }),
      L &&
        !0 &&
        p.jsxs("div", {
          className: "mt-4",
          children: [
            p.jsx("pre", {
              "data-testid": "ascii-art",
              className:
                "rounded-lg border border-border bg-muted/30 p-4 overflow-x-auto font-mono whitespace-pre",
              style: { fontSize: j, lineHeight: 1.1 },
              children: L,
            }),
            p.jsxs("p", {
              className: "text-xs text-muted-foreground mt-1",
              children: [
                H,
                " characters wide",
                H > 80
                  ? " — wider than 80 columns, so it may wrap in a terminal or README. Try a smaller font or shorter text."
                  : "",
              ],
            }),
            p.jsx(re, {
              className: "mt-3",
              onClick: K,
              children: "Copy ASCII Art",
            }),
          ],
        }),
      p.jsx(ye, { whatIsIt: Q.what, howToUse: Q.how, tip: Q.tip }),
    ],
  });
}
export { lt as default };
//# sourceMappingURL=AsciiArtGenerator-ZgJPcy0H.js.map
