// FDP-74 ASCII Art Generator (Professional), guest. Usage: node px74-live.js <zero|left|cases> [engine]   env TRIES, SUF
// zero: context at the cap: Copy ASCII Art, Ctrl+C on the art, right-click-free select+copy -> gated? Typing/new art -> logs?
// left: uses left: does load/typing log? Copy, new text + Copy, font change + Copy, Ctrl+C, reload + Copy (per-copy or per-page-load?).
// cases (no copy actions): 12 fonts, alignment, multi-line, 60-char cut, accents, emoji/Hindi, empty/space, width note, zoom. Art read from the <pre>.
// Never signs in, never types an email or card, never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/74-ascii-art-generator/'; const OUT = BASE + 'live/'; const TOOL = 'https://www.freedailypro.com/tool/ascii-art-generator';
const mode = process.argv[2] || 'zero'; const eng = process.argv[3] || 'chromium'; const sfx = (eng === 'chromium' ? '' : '-' + eng) + (process.env.SUF || '');
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
fs.mkdirSync(OUT + 'cases', { recursive: true }); fs.mkdirSync(OUT + 'art', { recursive: true });
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p, h, net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 1000 }, locale: 'en-US' }); if (eng === 'chromium') await c.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://www.freedailypro.com' }); p = await c.newPage(); p.setDefaultTimeout(12000); net = []; h = null;
  p.on('request', r => { const u = r.url(); if (r.method() === 'POST' && /freedailypro\.com\/api/.test(u) && !/insight\.hit|funnel\.hit/.test(u)) net.push({ t: now(), u: u.slice(0, 70) }); else if (r.method() === 'GET' && /assets\/.*(Standard|Big|Slant|Small|Mini|Banner3|Block|ANSI|Doom|Graffiti|Ghost|Bubble)-/.test(u)) net.push({ t: now(), font: decodeURIComponent(u.split('/').pop()) }); });
  await p.goto(TOOL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const helper = async () => { if (!h) { h = await c.newPage(); await h.goto('https://www.freedailypro.com/robots.txt'); } };
 const clipSet = async s => { if (eng !== 'chromium') return; await helper(); await h.bringToFront(); await h.evaluate(s => navigator.clipboard.writeText(s), s).catch(() => { }); await p.bringToFront(); };
 const clipGet = async () => { if (eng !== 'chromium') return null; await helper(); await h.bringToFront(); const v = await h.evaluate(() => navigator.clipboard.readText()).catch(e => 'ERR ' + e.message.slice(0, 40)); await p.bringToFront(); return v; };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(250); } };
 const shot = n => p.screenshot({ path: OUT + 'cases/' + n + sfx + '.png' });
 const toasts = () => p.locator('[data-sonner-toast]').allInnerTexts().catch(() => []);
 const ta = () => p.locator('main textarea[aria-label="Text (one banner per line)"]');
 const setText = async v => { await ta().fill(v); await p.waitForTimeout(900); };
 const font = async f => { await p.locator('main select[aria-label="Banner font"]').selectOption(f); await p.waitForTimeout(1200); };
 const art = () => p.evaluate(() => { const pre = document.querySelector('main [data-testid=ascii-art]'); const m = document.querySelector('main'); const w = [...m.querySelectorAll('p')].map(x => x.innerText).find(t => /characters wide/.test(t)); return { art: pre ? pre.textContent : null, width: w || null, alerts: [...m.querySelectorAll('[role=alert],[role=status]')].map(x => x.innerText).filter(Boolean), value: m.querySelector('textarea').value, copyBtn: !![...m.querySelectorAll('button')].find(x => /Copy ASCII Art/.test(x.innerText)) }; });
 const strip = () => p.evaluate(() => (document.querySelector('main').innerText.match(/(Trial|Professional)[^\n]*/) || [null])[0]);
 const copyBtn = async () => { await clipSet('SENTINEL'); const np = net.length; const before = await used(); await p.locator('main button', { hasText: 'Copy ASCII Art' }).click(); await p.waitForTimeout(1500); const r = { before, after: await used(), posts: net.slice(np).filter(x => x.u).length, dialog: await dialog(), toasts: await toasts(), clip: ((await clipGet()) || '').slice(0, 60) }; if (r.dialog) { await shot('copy-dialog-' + Date.now() % 100000); await esc(); } return r; };
 const ctrlC = async () => { await clipSet('SENTINEL'); const np = net.length; const before = await used(); await p.evaluate(() => { const el = document.querySelector('main [data-testid=ascii-art]'); const r = document.createRange(); r.selectNodeContents(el); const s = getSelection(); s.removeAllRanges(); s.addRange(r); }); await p.keyboard.press('Control+C'); await p.waitForTimeout(1500); const r = { before, after: await used(), posts: net.slice(np).filter(x => x.u).length, dialog: await dialog(), clip: ((await clipGet()) || '').slice(0, 60) }; if (r.dialog) { await shot('ctrlc-dialog-' + Date.now() % 100000); await esc(); } await p.evaluate(() => getSelection().removeAllRanges()); return r; };
 const C = async (id, fn) => { try { R.cases[id] = await fn(); } catch (e) { R.cases[id] = { err: e.message.split('\n')[0].slice(0, 200) }; await shot(id + '-err').catch(() => { }); } console.log(id, JSON.stringify(R.cases[id]).slice(0, 700)); };
 const find = async want => { const TRIES = +(process.env.TRIES || 10); for (let i = 0; i < TRIES; i++) { await open(); const u = await used(); R.tries.push(u); const [a, l] = u.split('/').map(Number); if (want === 'cap' ? a >= l : a < l) return true; await c.close(); } return false; };
 if (mode === 'zero' || mode === 'left') { R.found = await find(mode === 'zero' ? 'cap' : 'left'); if (!R.found) { console.log('none', R.tries.join(',')); fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); await b.close(); return; }
  R.start = { used: await used(), strip: await strip(), postsOnLoad: net.filter(x => x.u).length }; await shot(mode === 'zero' ? 'Z00' : 'L00');
  await C('A01-type-wait', async () => { const np = net.length; await setText('Deploy'); await font('Slant'); await p.waitForTimeout(4000); return { posts: net.slice(np).filter(x => x.u).length, used: await used(), art: (await art()).art?.slice(0, 80) }; });
  await C('A02-copy', () => copyBtn());
  await C('A03-ctrlC', () => ctrlC());
  await C('A04-new-text-copy', async () => { await setText('Build OK'); return copyBtn(); });
  await C('A05-font-copy', async () => { await font('Doom'); return copyBtn(); });
  await C('A06-ctrlC-new', async () => { await setText('Release 2'); return ctrlC(); });
  for (let i = 7; i <= (mode === 'left' ? 16 : 8); i++) await C('A' + String(i).padStart(2, '0') + '-more-copy', async () => { await setText('Item ' + i); return copyBtn(); });
  await C('A20-reload-copy', async () => { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); await setText('After reload'); return copyBtn(); });
  await C('A21-reload-ctrlC', () => ctrlC());
  R.end = await used(); R.net = net;
 } else if (mode === 'cases') { await open(); R.start = { used: await used(), strip: await strip() };
  R.fontOpts = await p.locator('main select[aria-label="Banner font"] option').allInnerTexts();
  for (const f of R.fontOpts) await C('F:' + f, async () => { await setText('Hello World'); await font(f); const a = await art(); fs.writeFileSync(OUT + 'art/' + f.replace(/ /g, '_') + '.txt', a.art || ''); return { width: a.width, lines: (a.art || '').split('\n').length, nonAscii: [...new Set([...(a.art || '')].filter(ch => ch.charCodeAt(0) > 126))].join('') }; });
  await font('Standard');
  const T = { multi: 'Hi\nThere friend', sixty: 'x'.repeat(75), accents: 'Café Zürich', emoji: 'Hi 😀', hindi: 'नमस्ते', mixedLine: 'OK\nनमस्ते', empty: '', spaces: '   ', punct: '~`!@#$%^&*()_+{}|:"<>?[]\\;\',./', script: '<script>alert(1)</script>', tabs: 'a\tb', blanklines: 'A\n\n\nB', trailing: 'End   ', wide: 'ABCDEFGHIJKLMNOP', curly: '“Smart” – quotes…', german: 'Straße Œuvre æ' };
  for (const [k, v] of Object.entries(T)) await C('T:' + k, async () => { await setText(v); const a = await art(); if (a.art) fs.writeFileSync(OUT + 'art/T-' + k + '.txt', a.art); return { ...a, art: a.art ? a.art.split('\n').slice(0, 2).join('⏎').slice(0, 120) : null, artLen: a.art ? a.art.length : 0, valLen: a.value.length }; });
  await setText('Hi\nThere friend'); await p.locator('main button', { hasText: /^Centre$/ }).click(); await p.waitForTimeout(800); { const a = await art(); fs.writeFileSync(OUT + 'art/T-multi-centre.txt', a.art || ''); R.cases['T:multi-centre'] = { width: a.width }; await shot('T-multi-centre'); }
  await setText('Hello World'); await font('ANSI Shadow'); await shot('T-ansi'); await setText('x'.repeat(75)); await shot('T-sixty-wide');
  await p.locator('main input[aria-label="Preview zoom"]').fill('22'); await p.waitForTimeout(400); R.zoom22 = await p.evaluate(() => getComputedStyle(document.querySelector('main [data-testid=ascii-art]')).fontSize); await shot('T-zoom22');
  await setText('Café 😀'); await shot('T-emoji-error');
  R.end = await used(); R.net = net;
 }
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', JSON.stringify(R.tries), JSON.stringify(R.start || ''), R.end); await b.close(); })();
