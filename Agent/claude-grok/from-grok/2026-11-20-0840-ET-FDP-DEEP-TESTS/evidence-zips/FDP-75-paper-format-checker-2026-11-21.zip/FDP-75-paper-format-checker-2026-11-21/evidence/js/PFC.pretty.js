import { r as F, j as i } from "./vendor-react-D01g8YgM.js";
import { b as ve, T as Se, F as $e } from "./ToolPage-DwLoDncN.js";
import { C as je } from "./card-KXKUZKW8.js";
import {
  S as Fe,
  a as Ce,
  b as ke,
  c as Te,
  d as ne,
} from "./select-ic5yaeGw.js";
import { e as ze, ax as Le, aq as Pe, X as Ee } from "./index-B1CTyGtY.js";
import { J as Me } from "./jszip.min-CT0ZA6V1.js";
import { T as Re } from "./ToolInfoSection-C0i6Zbwo.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./chevron-up-BDUcPssj.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./CollapsibleText-BCSBEG9-.js";
const C = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
function r(s, t) {
  return s ? (s.getAttributeNS(C, t) ?? s.getAttribute("w:" + t)) : null;
}
function p(s, t) {
  if (s) return Array.from(s.children).find((o) => o.localName === t);
}
function b(s) {
  if (s === null || s === "") return;
  const t = Number(s);
  return Number.isFinite(t) ? t : void 0;
}
function oe(s) {
  const t = {};
  if (!s) return t;
  const o = p(s, "spacing");
  if (o) {
    const f = b(r(o, "line"));
    f !== void 0 && ((t.line = f), (t.lineRule = r(o, "lineRule") || "auto"));
    const d = b(r(o, "before"));
    d !== void 0 && (t.before = d);
    const N = b(r(o, "after"));
    (N !== void 0 && (t.after = N),
      (r(o, "beforeAutospacing") === "1" ||
        r(o, "beforeAutospacing") === "true") &&
        (t.before = 280),
      (r(o, "afterAutospacing") === "1" ||
        r(o, "afterAutospacing") === "true") &&
        (t.after = 280));
  }
  const u = p(s, "ind");
  if (u) {
    const f = b(r(u, "firstLine"));
    f !== void 0 && ((t.firstLine = f), (t.hanging = 0));
    const d = b(r(u, "hanging"));
    d !== void 0 && ((t.hanging = d), (t.firstLine = 0));
    const N = b(r(u, "firstLineChars"));
    N !== void 0 && f === void 0 && (t.firstLine = N * 2.4);
  }
  return t;
}
function ie(s) {
  const t = {};
  if (!s) return t;
  const o = p(s, "rFonts");
  if (o) {
    const f = r(o, "asciiTheme"),
      d = r(o, "ascii") || r(o, "hAnsi");
    f
      ? ((t.fontTheme = f), (t.font = void 0))
      : d && ((t.font = d), (t.fontTheme = void 0));
  }
  const u = b(r(p(s, "sz"), "val"));
  return (u !== void 0 && (t.size = u / 2), t);
}
const O = (s, t) => {
    const o = { ...s };
    for (const [f, d] of Object.entries(t)) d !== void 0 && (o[f] = d);
    const u = t;
    return (
      u.font !== void 0 && (o.fontTheme = void 0),
      u.fontTheme !== void 0 && (o.font = void 0),
      o
    );
  },
  xe = /^(references?|reference list|works cited|bibliography|sources)$/i,
  re = (s) => `${Math.round(s * 100)}%`,
  B = (s) => s / 1440;
function De(s, t) {
  const o =
      s.parse || ((e) => new DOMParser().parseFromString(e, "application/xml")),
    u = o(s.document),
    f = new Map();
  let d = {},
    N = {};
  if (s.styles) {
    const e = o(s.styles),
      a = e.getElementsByTagNameNS(C, "docDefaults")[0];
    a &&
      ((N = ie(p(p(a, "rPrDefault"), "rPr"))),
      (d = oe(p(p(a, "pPrDefault"), "pPr"))));
    for (const n of Array.from(e.getElementsByTagNameNS(C, "style"))) {
      const l = r(n, "styleId") || "";
      f.set(l, {
        id: l,
        type: r(n, "type") || "paragraph",
        basedOn: r(p(n, "basedOn"), "val") || void 0,
        name: (r(p(n, "name"), "val") || l).toLowerCase(),
        isDefault: r(n, "default") === "1" || r(n, "default") === "true",
        p: oe(p(n, "pPr")),
        r: ie(p(n, "rPr")),
      });
    }
  }
  const W = Array.from(f.values()).find(
    (e) => e.type === "paragraph" && e.isDefault,
  );
  let M = "Calibri",
    k = "Calibri Light";
  if (s.theme) {
    const e = o(s.theme),
      a = e
        .getElementsByTagNameNS("*", "minorFont")[0]
        ?.getElementsByTagNameNS("*", "latin")[0]
        ?.getAttribute("typeface"),
      n = e
        .getElementsByTagNameNS("*", "majorFont")[0]
        ?.getElementsByTagNameNS("*", "latin")[0]
        ?.getAttribute("typeface");
    (a && (M = a), n && (k = n));
  }
  const I = (e) => (e.toLowerCase().startsWith("major") ? k : M),
    G = (e) => {
      const a = [],
        n = new Set();
      let l = e ? f.get(e) : void 0;
      for (; l && !n.has(l.id);)
        (n.add(l.id),
          a.unshift(l),
          (l = l.basedOn ? f.get(l.basedOn) : void 0));
      return a;
    },
    T = new Map(),
    x = new Map();
  let w = 0,
    H = 0,
    U = 0;
  const K = new Map();
  let z = 0,
    Q = 0,
    _ = 0,
    q = 0,
    J = !1,
    ce = !1,
    R = 0,
    V = 0;
  for (const e of Array.from(u.getElementsByTagNameNS(C, "p"))) {
    let a = !1;
    for (let h = e.parentElement; h; h = h.parentElement)
      if (h.localName === "tbl" || h.localName === "txbxContent") {
        a = !0;
        break;
      }
    if (a) continue;
    const n = p(e, "pPr"),
      l = r(p(n, "pStyle"), "val") || W?.id,
      g = G(l);
    let c = d,
      A = N;
    for (const h of g) ((c = O(c, h.p)), (A = O(A, h.r)));
    c = O(c, oe(n));
    const ee = g.length ? g[g.length - 1].name : "",
      Ae = /^(heading|title|subtitle|toc|caption)/.test(ee);
    let P = 0,
      fe = 0,
      he = 0;
    for (const h of Array.from(e.getElementsByTagNameNS(C, "r"))) {
      let v = 0;
      for (const D of Array.from(h.children))
        D.localName === "t"
          ? (v += (D.textContent || "").length)
          : D.localName === "tab" && (v += 1);
      if (!v) continue;
      let j = A;
      const pe = p(h, "rPr"),
        ge = r(p(pe, "rStyle"), "val");
      if (ge) for (const D of G(ge)) j = O(j, D.r);
      j = O(j, ie(pe));
      const be = j.fontTheme
          ? I(j.fontTheme)
          : j.font || (s.styles ? "Times New Roman" : "unknown"),
        ae = j.size ?? 10;
      (T.set(be, (T.get(be) || 0) + v),
        x.set(String(ae), (x.get(String(ae)) || 0) + v),
        (w += v),
        (P += v),
        v > he && ((he = v), (fe = ae)));
    }
    if (!P) continue;
    const E = Array.from(e.getElementsByTagNameNS(C, "t"))
      .map((h) => h.textContent || "")
      .join("")
      .trim();
    E.length <= 40 && xe.test(E)
      ? ((J = !0), (ce = !0))
      : J && E.length <= 40 && /^appendix\b/i.test(E) && (J = !1);
    const ue = J && !xe.test(E) && E.length >= 20;
    ue && (R++, (c.hanging || 0) >= 576 && (c.hanging || 0) <= 864 && V++);
    const te = fe || 10;
    let se, Z;
    const me = c.line ?? 240;
    if ((c.lineRule || "auto") === "auto") {
      const h = me / 240;
      ((Z = `${Math.round(h * 100) / 100}×`),
        (se =
          h >= 1.9 && h <= 2.1 ? "double" : h <= 1.25 ? "single" : "other"));
    } else {
      const h = me / 20;
      ((Z = `exactly ${h} pt`),
        (se =
          h >= te * 1.9 && h <= te * 2.3
            ? "double"
            : h <= te * 1.25
              ? "single"
              : "other"));
    }
    (se === "double" && (H += P),
      (U += P),
      K.set(Z, (K.get(Z) || 0) + P),
      P >= 60 &&
        !Ae &&
        !ue &&
        (z++,
        (c.hanging || 0) > 0
          ? q++
          : (c.firstLine || 0) >= 600 && (c.firstLine || 0) <= 840 && Q++,
        ((c.before || 0) > 0 || (c.after || 0) > 0) && _++));
  }
  const de = (e) =>
      Array.from(e.entries())
        .map(([a, n]) => ({ name: a, share: w ? n / w : 0 }))
        .sort((a, n) => n.share - a.share),
    y = de(T),
    S = de(x),
    L = (e, a = "") =>
      e
        .slice(0, 3)
        .map((n) => `${n.name}${a} (${re(n.share)})`)
        .join(", "),
    Ne = Array.from(u.getElementsByTagNameNS(C, "sectPr")),
    $ = [],
    X = new Set();
  for (const e of Ne) {
    const a = p(e, "pgMar");
    a &&
      $.push({
        t: b(r(a, "top")) ?? NaN,
        b: b(r(a, "bottom")) ?? NaN,
        l: b(r(a, "left")) ?? NaN,
        r: b(r(a, "right")) ?? NaN,
      });
    const n = p(e, "pgSz");
    if (n) {
      const l = b(r(n, "w")) ?? 0,
        g = b(r(n, "h")) ?? 0,
        [c, A] = r(n, "orient") === "landscape" ? [g, l] : [l, g];
      X.add(`${(c / 1440).toFixed(2)}×${(A / 1440).toFixed(2)}`);
    }
  }
  const m = [];
  if ($.length) {
    const e = $.filter((l) =>
        [l.t, l.b, l.l, l.r].some((g) => !(Math.abs(B(g) - 1) < 0.05)),
      ),
      a = $[0],
      n = `top ${B(a.t).toFixed(2)}", bottom ${B(a.b).toFixed(2)}", left ${B(a.l).toFixed(2)}", right ${B(a.r).toFixed(2)}"`;
    m.push({
      id: "margins",
      label: 'Margins (1" on all sides)',
      pass: e.length === 0,
      detail:
        e.length === 0
          ? `Found: ${n}${$.length > 1 ? ` (all ${$.length} sections)` : ""}`
          : `Found: ${n}${$.length > 1 ? `; ${e.length} of ${$.length} sections differ` : ""}`,
    });
  } else
    m.push({
      id: "margins",
      label: 'Margins (1" on all sides)',
      pass: null,
      detail: "Couldn't detect margins in this document",
    });
  if (X.size) {
    const e = Array.from(X).every((a) => a === "8.50×11.00");
    m.push({
      id: "page",
      label: 'Page size (8.5" × 11" Letter)',
      pass: e,
      detail: `Found: ${Array.from(X).join(", ")}${e ? "" : " — A4 and other sizes aren't what US style guides assume"}`,
    });
  }
  if (w) {
    const e = y[0]?.name || "",
      a = Number(S[0]?.name),
      n = (g) => y.filter((c) => g(c.name)).reduce((c, A) => c + A.share, 0),
      l = (g) => /times new roman/i.test(g);
    if (t === "APA") {
      const g = {
          "times new roman": 12,
          calibri: 11,
          arial: 11,
          georgia: 11,
          "lucida sans unicode": 10,
          "computer modern": 10,
        },
        c = Object.keys(g).find((ee) => e.toLowerCase().includes(ee)),
        A = !!c;
      (m.push({
        id: "font",
        label:
          "Font (APA 7: Times New Roman 12, Calibri 11, Arial 11, Georgia 11, Lucida Sans Unicode 10)",
        pass: A && y[0].share >= 0.9,
        detail: `Found: ${L(y)}${A && y[0].share < 0.9 ? " — body text mixes fonts" : ""}`,
      }),
        m.push({
          id: "size",
          label: c ? `Font size (${g[c]} pt for ${e})` : "Font size",
          pass: c ? Math.abs(a - g[c]) < 0.5 && S[0].share >= 0.9 : !1,
          detail: `Found: ${L(S, " pt")}`,
        }));
    } else
      t === "MLA"
        ? (m.push({
            id: "font",
            label:
              "Font (MLA: any easily readable face; Times New Roman is the usual choice)",
            pass: y[0].share >= 0.9,
            detail: `Found: ${L(y)}${y[0].share < 0.9 ? " — body text mixes fonts" : ""}`,
            info: !0,
          }),
          m.push({
            id: "size",
            label: "Font size (MLA: 12 pt)",
            pass: Math.abs(a - 12) < 0.5 && S[0].share >= 0.9,
            detail: `Found: ${L(S, " pt")}`,
          }))
        : (m.push({
            id: "font",
            label:
              "Font (Chicago: Times New Roman recommended; other readable faces accepted)",
            pass: n(l) >= 0.9 ? !0 : y[0].share >= 0.9 ? null : !1,
            detail: `Found: ${L(y)}${n(l) < 0.9 && y[0].share >= 0.9 ? " — acceptable if your instructor allows another readable face" : ""}`,
          }),
          m.push({
            id: "size",
            label: "Font size (Chicago: 12 pt; 11 pt is acceptable)",
            pass: a >= 11 && a <= 12 && S[0].share >= 0.9,
            detail: `Found: ${L(S, " pt")}`,
          }));
  } else
    (m.push({
      id: "font",
      label: "Font",
      pass: null,
      detail: "No body text found in this document",
    }),
      m.push({
        id: "size",
        label: "Font size",
        pass: null,
        detail: "No body text found in this document",
      }));
  if (U) {
    const e = H / U,
      a = Array.from(K.entries())
        .sort((n, l) => l[1] - n[1])
        .slice(0, 3)
        .map(([n, l]) => `${n} (${re(l / U)})`)
        .join(", ");
    m.push({
      id: "spacing",
      label: "Line spacing (double-spaced throughout)",
      pass: e >= 0.9,
      detail:
        e >= 0.9 ? `Double-spaced for ${re(e)} of the text` : `Found: ${a}`,
    });
  } else
    m.push({
      id: "spacing",
      label: "Line spacing (double-spaced throughout)",
      pass: null,
      detail: "No body text found in this document",
    });
  if (z) {
    m.push({
      id: "gap",
      label: "No extra space between paragraphs",
      pass: _ / z < 0.1,
      detail: _
        ? `${_} of ${z} paragraphs have space before/after set — Word's default 8 pt after is the usual culprit`
        : "No extra space before or after body paragraphs",
    });
    const e = z - q;
    e > 0 &&
      m.push({
        id: "indent",
        label: 'First line of each paragraph indented 0.5"',
        pass: Q / e >= 0.8,
        detail: `${Q} of ${e} body paragraphs have a 0.5" first-line indent${q ? ` (${q} hanging-indent entries such as references were skipped)` : ""}`,
      });
  }
  const Y = 'Reference list: hanging indent of 0.5" on each entry';
  if (
    (R
      ? m.push({
          id: "refindent",
          label: Y,
          pass: V / R >= 0.8,
          detail: `${V} of ${R} reference entries have a 0.5" hanging indent${V < R ? ' — select the list, open Paragraph, and set Special to Hanging, 0.5"' : ""}`,
        })
      : ce
        ? m.push({
            id: "refindent",
            label: Y,
            pass: null,
            detail:
              "A reference-list heading was found but no entries followed it",
          })
        : m.push({
            id: "refindent",
            label: Y,
            pass: null,
            detail:
              "No References, Works Cited or Bibliography heading found, so the hanging indent wasn't checked",
          }),
    s.headers)
  ) {
    const e = s.headers.some((a) =>
      /<w:instrText[^>]*>[^<]*\bPAGE\b|<w:fldSimple[^>]*\bPAGE\b/.test(a),
    );
    m.push({
      id: "pageno",
      label: "Page numbers in the header (top right)",
      pass: e,
      detail: e
        ? "A page-number field was found in a header or footer"
        : "No page-number field found in any header or footer",
    });
  }
  return { checks: m, bodyChars: w, bodyParagraphs: z, fonts: y, sizes: S };
}
const ye =
  "This isn't a valid .docx file, so nothing could be checked. Open it in Word, Google Docs or LibreOffice and use Save As .docx (a renamed .doc or .pdf won't work), then drop it again.";
class we extends Error {
  constructor() {
    (super("not a Word document"), (this.name = "NotDocxError"));
  }
}
async function Oe(s) {
  let t;
  try {
    t = await Me.loadAsync(s);
  } catch {
    throw new we();
  }
  const o = async (d) => (await t.file(d)?.async("text")) || void 0,
    u = await o("word/document.xml");
  if (!u) throw new we();
  const f = [];
  for (const d of Object.keys(t.files))
    /^word\/(header|footer)\d*\.xml$/.test(d) && f.push((await o(d)) || "");
  return {
    document: u,
    styles: await o("word/styles.xml"),
    theme: await o("word/theme/theme1.xml"),
    headers: f,
  };
}
function Be({ label: s, pass: t, detail: o }) {
  return i.jsxs("div", {
    className: "flex items-start gap-3 py-2",
    children: [
      t === null
        ? i.jsx(Le, { className: "h-4 w-4 text-amber-500 shrink-0 mt-0.5" })
        : t
          ? i.jsx(Pe, { className: "h-4 w-4 text-green-600 shrink-0 mt-0.5" })
          : i.jsx(Ee, { className: "h-4 w-4 text-red-500 shrink-0 mt-0.5" }),
      i.jsxs("div", {
        children: [
          i.jsx("p", { className: "text-sm font-medium", children: s }),
          i.jsx("p", {
            className: "text-xs text-muted-foreground",
            children: o,
          }),
        ],
      }),
    ],
  });
}
const le = {
  what: "Reads a real .docx file's margins, fonts, sizes, line spacing, paragraph spacing, indents and page numbers as Word applies them, and checks them against APA, MLA, or Chicago formatting requirements — an actual read of the document's formatting, not a guess based on word count.",
  how: "Choose which style to check against, upload your .docx paper, and each formatting requirement is checked against what's actually set in the document, with a clear pass, fail, or undetected result for each.",
  tip: "Each result is weighted by how much of your body text it covers, so a mixed-font paper is reported with the percentages — fix the largest share first, and still give it a final visual check.",
};
function wt() {
  const [s, t] = F.useState("APA"),
    [o, u] = F.useState(null),
    [f, d] = F.useState(null),
    [N, W] = F.useState(!1),
    [M, k] = F.useState(""),
    { logUsageNow: I } = ve(),
    G = F.useCallback(
      async (x) => {
        const w = x[0];
        if (w) {
          if ((k(""), !w.name.toLowerCase().endsWith(".docx"))) {
            k(
              `"${w.name}" isn't a .docx file. This tool reads Word .docx files: save your paper as .docx first if it's in another format.`,
            );
            return;
          }
          (u(w), W(!0));
          try {
            const H = await Oe(w);
            if (!(await I())) {
              u(null);
              return;
            }
            d(H);
          } catch {
            (u(null), d(null), k(ye));
          } finally {
            W(!1);
          }
        }
      },
      [I],
    ),
    T = F.useMemo(() => {
      if (!f) return null;
      try {
        return De(f, s);
      } catch {
        return null;
      }
    }, [f, s]);
  return i.jsxs(Se, {
    children: [
      i.jsx(ze, {
        htmlFor: "paper-style",
        className: "mb-2 block text-sm",
        children: "Check against",
      }),
      i.jsxs(Fe, {
        value: s,
        onValueChange: (x) => t(x),
        children: [
          i.jsx(Ce, {
            id: "paper-style",
            className: "max-w-xs mb-6",
            children: i.jsx(ke, {}),
          }),
          i.jsxs(Te, {
            children: [
              i.jsx(ne, { value: "APA", children: "APA (7th edition)" }),
              i.jsx(ne, { value: "MLA", children: "MLA (9th edition)" }),
              i.jsx(ne, {
                value: "Chicago",
                children: "Chicago (17th edition)",
              }),
            ],
          }),
        ],
      }),
      M &&
        i.jsx("p", {
          role: "alert",
          "data-testid": "paper-problem",
          className: "mb-3 text-sm text-destructive",
          children: M,
        }),
      o
        ? N
          ? i.jsx("p", {
              className: "text-sm text-muted-foreground",
              children: "Reading document formatting...",
            })
          : T
            ? i.jsxs("div", {
                className: "space-y-4",
                children: [
                  i.jsxs("div", {
                    className:
                      "p-3 rounded-lg border bg-card flex items-center justify-between gap-3",
                    children: [
                      i.jsx("p", {
                        className: "text-sm font-medium",
                        children: o.name,
                      }),
                      i.jsx("button", {
                        className: "text-xs underline text-muted-foreground",
                        onClick: () => {
                          (u(null), d(null));
                        },
                        children: "Check another file",
                      }),
                    ],
                  }),
                  i.jsx(je, {
                    className: "p-4",
                    children: T.checks.map((x) =>
                      i.jsx(
                        Be,
                        { label: x.label, pass: x.pass, detail: x.detail },
                        x.id,
                      ),
                    ),
                  }),
                  i.jsx("p", {
                    className: "text-xs text-muted-foreground",
                    children:
                      "Reads the formatting Word actually applies — the style chain, document defaults, theme fonts, direct paragraph and run formatting, every section's margins and the page-number fields — weighted by how much body text each setting covers, so a single heading in another font doesn't fail the paper. Text in tables and text boxes, footnotes, citations, title-page structure and running heads aren't checked, and your instructor's requirements always come first.",
                  }),
                ],
              })
            : i.jsxs("div", {
                className: "space-y-2",
                children: [
                  i.jsx("p", {
                    role: "alert",
                    "data-testid": "paper-problem",
                    className: "text-sm text-destructive",
                    children: ye,
                  }),
                  i.jsx("button", {
                    className: "text-xs underline text-muted-foreground",
                    onClick: () => {
                      (u(null), d(null));
                    },
                    children: "Check another file",
                  }),
                ],
              })
        : i.jsx($e, {
            gateAtDownload: !0,
            accept: ".docx",
            onFiles: G,
            label: "Drop your .docx paper",
            description:
              "Checks your document's actual margins, font, and line spacing against the style guide — reads real formatting, not just word count",
          }),
      i.jsx(Re, { whatIsIt: le.what, howToUse: le.how, tip: le.tip }),
    ],
  });
}
export { wt as default };
//# sourceMappingURL=PaperFormatChecker-RAfBEqf7.js.map
