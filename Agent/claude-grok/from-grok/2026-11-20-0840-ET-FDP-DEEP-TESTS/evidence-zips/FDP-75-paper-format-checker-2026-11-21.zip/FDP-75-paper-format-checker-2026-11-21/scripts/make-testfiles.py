#!/usr/bin/env python3
"""FDP-75 Paper Format Checker test papers (python-docx). Run inside testfiles/.
apa-good: Times New Roman 12, double, 1" margins, Letter, 0.5" first-line indent, no paragraph spacing, References with 0.5" hanging indent, PAGE field in header.
word-default: python-docx default template text (Normal style as shipped). a4-narrow: A4, 0.75" margins.
direct-format: Normal style = APA-perfect, but every body paragraph directly formatted Arial 10, single (tests the FAQ 'direct formatting is not caught').
mixed-fonts: half TNR, half Arial. exact-24pt: line rule exactly 24 pt. two-sections: 2nd section has 1.5" left margin.
refs-no-hanging: References entries without hanging indent. georgia-11: Georgia 11 (APA OK, MLA size fail, Chicago size OK).
empty: no text. long-60p: ~60 pages APA. not-docx.docx (a PDF renamed), old.doc, minimal.docx (document.xml only; no styles/theme/header).
"""
import docx, zipfile, io
from docx.shared import Pt, Inches
from docx.enum.text import WD_LINE_SPACING
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
LOREM = ('Students in this study reported that structured feedback improved their revision habits across the semester, '
         'and instructors noted fewer formatting errors in final submissions compared with the previous year. ') * 2
def page_field(section):
    p = section.header.paragraphs[0]; p.alignment = 2; r = p.add_run()
    for t, v in (('begin', None), (None, 'PAGE'), ('end', None)):
        if t: e = OxmlElement('w:fldChar'); e.set(qn('w:fldCharType'), t)
        else: e = OxmlElement('w:instrText'); e.text = v
        r._r.append(e)
def base(font='Times New Roman', size=12, line=2.0, margins=1.0, a4=False, indent=True, after=0, header=True):
    d = docx.Document(); st = d.styles['Normal']; st.font.name = font; st.font.size = Pt(size)
    st.element.rPr.rFonts.set(qn('w:ascii'), font); st.element.rPr.rFonts.set(qn('w:hAnsi'), font)
    pf = st.paragraph_format; pf.line_spacing = line; pf.space_after = Pt(after); pf.space_before = Pt(0)
    if indent: pf.first_line_indent = Inches(0.5)
    s = d.sections[0]
    for side in ('top_margin', 'bottom_margin', 'left_margin', 'right_margin'): setattr(s, side, Inches(margins))
    if a4: s.page_width, s.page_height = Inches(8.27), Inches(11.69)
    else: s.page_width, s.page_height = Inches(8.5), Inches(11)
    if header: page_field(s)
    return d
def body(d, n=8):
    for i in range(n): d.add_paragraph(f'{i+1}. ' + LOREM)
def refs(d, hanging=True):
    h = d.add_paragraph('References'); h.paragraph_format.first_line_indent = Inches(0); h.alignment = 1
    for a in ['Adams, J. (2020). Feedback and revision in first-year writing. Journal of Writing Studies, 12(3), 45-67.',
              'Brown, K., & Lee, M. (2021). Formatting errors in student papers: A survey. College Teaching, 69(2), 101-110.',
              'Chen, L. (2019). Style guides in practice. Academic Press.']:
        p = d.add_paragraph(a)
        if hanging: p.paragraph_format.first_line_indent = Inches(-0.5); p.paragraph_format.left_indent = Inches(0.5)
d = base(); body(d); refs(d); d.save('apa-good.docx')
d = docx.Document(); body(d); d.save('word-default.docx')
d = base(margins=0.75, a4=True); body(d); d.save('a4-narrow.docx')
d = base(); body(d)
for p in d.paragraphs:
    p.paragraph_format.line_spacing = 1.0
    for r in p.runs: r.font.name = 'Arial'; r.font.size = Pt(10)
d.save('direct-format.docx')
d = base(); body(d, 4)
for i in range(4):
    p = d.add_paragraph(LOREM); [setattr(r.font, 'name', 'Arial') for r in p.runs]
d.save('mixed-fonts.docx')
d = base(); st = d.styles['Normal'].paragraph_format; st.line_spacing_rule = WD_LINE_SPACING.EXACTLY; st.line_spacing = Pt(24); body(d); d.save('exact-24pt.docx')
d = base(); body(d, 4); s2 = d.add_section(); s2.left_margin = Inches(1.5); body(d, 4); d.save('two-sections.docx')
d = base(); body(d); refs(d, hanging=False); d.save('refs-no-hanging.docx')
d = base(font='Georgia', size=11); body(d); refs(d); d.save('georgia-11.docx')
d = base(); d.save('empty.docx')
d = base(); body(d, 220); refs(d); d.save('long-60p.docx')
d = base(header=False); body(d); refs(d); d.save('no-page-number.docx')
open('not-docx.docx', 'wb').write(b'%PDF-1.4\n%fake\n')
open('old.doc', 'wb').write(b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1' + b'\0' * 512)
z = zipfile.ZipFile('minimal.docx', 'w')
z.writestr('[Content_Types].xml', '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>')
z.writestr('word/document.xml', '<?xml version="1.0"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>' + LOREM + '</w:t></w:r></w:p><w:sectPr><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/></w:sectPr></w:body></w:document>')
z.close()

# Added later (offline harness only): footer-pageno: apa-good, but the PAGE field sits centred in the FOOTER, not the header.
def make_footer_pageno():
    d = base(header=False); s = d.sections[0]; p = s.footer.paragraphs[0]; p.alignment = 1; r = p.add_run()
    for t, v in (('begin', None), (None, 'PAGE'), ('end', None)):
        if t: e = OxmlElement('w:fldChar'); e.set(qn('w:fldCharType'), t)
        else: e = OxmlElement('w:instrText'); e.text = v
        r._r.append(e)
    body(d); refs(d); d.save('footer-pageno.docx')
if __name__ == '__main__': make_footer_pageno()
