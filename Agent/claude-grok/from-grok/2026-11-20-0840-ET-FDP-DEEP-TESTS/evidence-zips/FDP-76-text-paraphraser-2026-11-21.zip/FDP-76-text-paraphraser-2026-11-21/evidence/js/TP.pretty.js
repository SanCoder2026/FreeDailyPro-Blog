import { r as $, j as r } from "./vendor-react-D01g8YgM.js";
import { u as P } from "./useShareGate-BYBawloP.js";
import { b as U, T as q } from "./ToolPage-DwLoDncN.js";
import { T as z, B as T, k as B, f as j } from "./index-B1CTyGtY.js";
import { T as _ } from "./ToolInfoSection-C0i6Zbwo.js";
import "./useExportGate-BU4jIFHF.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
const E = "",
  I = "",
  e = (s, t) => [new RegExp(`\\b${s}\\b`, "gi"), t],
  D = [
    e("in order to", ["to"]),
    e("due to the fact that", ["because"]),
    e("in spite of", ["despite"]),
    e("as well as", ["along with"]),
    e("a number of", ["several"]),
    e("a lot of", ["plenty of"]),
    e("a few", ["a handful of"]),
    e("at this point in time", ["now"]),
    e("at the present time", ["currently"]),
    e("in the event that", ["if"]),
    e("prior to", ["before"]),
    e("subsequent to", ["after"]),
    e("is able to", ["can"]),
    e("are able to", ["can"]),
    e("right away", ["immediately"]),
    e("right now", ["at the moment"]),
    e("for example", ["for instance"]),
    e("because of", ["due to"]),
    e("i think", ["I believe"]),
    e("i want to", ["I would like to"]),
    e("let me know", ["please tell me", "feel free to tell me"]),
    e("thank you very much for", ["thank you so much for", "many thanks for"]),
    e("thanks a lot for", ["many thanks for"]),
    e("don't forget to", ["remember to"]),
    e("don't forget", ["remember"]),
    e("get started", ["begin"]),
    e("quick update", ["brief update"]),
    e("quick question", ["short question"]),
    e("quick look", ["brief look"]),
    e("as soon as possible", ["at your earliest convenience"]),
  ],
  F = [
    e("big", ["large"]),
    e("huge", ["enormous"]),
    e("important", ["significant"]),
    e("main", ["primary"]),
    e("easy", ["straightforward"]),
    e("buy", ["purchase"]),
    e("buys", ["purchases"]),
    e("bought", ["purchased"]),
    e("buying", ["purchasing"]),
    e("goals", ["aims", "objectives"]),
    e("goal", ["aim", "objective"]),
    e("companies", ["businesses"]),
    e("company", ["business"]),
    e("problems", ["issues"]),
    e("problem", ["issue"]),
    e("ideas", ["concepts"]),
    e("idea", ["concept"]),
    e("methods", ["approaches"]),
    e("method", ["approach"]),
    e("(will|to|would|should|can|must|may) start", ["$1 begin"]),
    e("(will|to|would|should|can|must|may) help", ["$1 assist"]),
    e("(needs|need) to", ["$1 to"]),
    e("however", ["that said"]),
    e("also", ["as well"]),
  ],
  Z = F.filter(([, s]) => s.some((t) => t !== "$1 to")),
  H = [
    [/\bcan't\b/gi, "cannot"],
    [/\bwon't\b/gi, "will not"],
    [/\bdon't\b/gi, "do not"],
    [/\bdoesn't\b/gi, "does not"],
    [/\bdidn't\b/gi, "did not"],
    [/\bisn't\b/gi, "is not"],
    [/\baren't\b/gi, "are not"],
    [/\bwasn't\b/gi, "was not"],
    [/\bcouldn't\b/gi, "could not"],
    [/\bshouldn't\b/gi, "should not"],
    [/\bwouldn't\b/gi, "would not"],
    [/\bhaven't\b/gi, "have not"],
    [/\bhasn't\b/gi, "has not"],
    [/\bI'm\b/g, "I am"],
    [/\b(you|we|they)'re\b/gi, "$1 are"],
    [/\b(I|you|we|they)'ll\b/gi, "$1 will"],
    [/\b(I|you|we|they)'ve\b/gi, "$1 have"],
  ],
  W = [
    [/\bdo not\b/gi, "don't"],
    [/\bdoes not\b/gi, "doesn't"],
    [/\bdid not\b/gi, "didn't"],
    [/\bis not\b/gi, "isn't"],
    [/\bare not\b/gi, "aren't"],
    [/\bcannot\b/gi, "can't"],
    [/\bwill not\b/gi, "won't"],
    [/\bI am\b/g, "I'm"],
    [/\b(you|we|they) are\b/gi, "$1're"],
    [/\b(I|you|we|they) will\b/gi, "$1'll"],
  ],
  Y = [
    [/^But\b/, ["However,", "Even so,"]],
    [/^Also,/, ["In addition,"]],
    [/^So\b,?/, ["As a result,"]],
  ];
function G(s, t) {
  return s.length > 1 && s === s.toUpperCase() && /[A-Z]/.test(s)
    ? t.toUpperCase()
    : /^[A-Z]/.test(s)
      ? t.charAt(0).toUpperCase() + t.slice(1)
      : t;
}
function A(s, t, c) {
  let n = s;
  for (const [i, o] of t)
    n = n.replace(new RegExp(i.source, i.flags), (...m) => {
      const h = m[0];
      if (h.includes(E) || h.includes(I)) return h;
      const w = m.slice(1, -2);
      let l = o[c(o.length)].replace(
        /\$(\d)/g,
        (p, d) => w[Number(d) - 1] ?? "",
      );
      return l === h ? h : ((l = G(h, l)), `${E}${l}${I}${h}`);
    });
  return n;
}
function X(s) {
  const t = /^([^,;:]+?) because ([^,;:]+?)([.!?])$/.exec(s.trim());
  if (!t) return null;
  const [, c, n, i] = t;
  return c.split(/\s+/).length < 2 || /^(and|but|or)\b/i.test(c)
    ? null
    : `Because ${n}, ${((m) => (/^[A-Z][a-z]/.test(m) ? m[0].toLowerCase() + m.slice(1) : m))(c)}${i}`;
}
function J(s) {
  return s.match(/[^.!?]+[.!?]+["')\]]*\s*|[^.!?]+$/g) ?? [s];
}
function L(s, t = "medium", c = 0) {
  let n = c;
  const i = (d) => (d <= 1 ? 0 : Math.abs(n++) % d),
    o = /\b\w+n't\b|\bI'm\b/.test(s),
    h = s
      .split(
        `
`,
      )
      .map((d) =>
        /[A-Za-z]/.test(d)
          ? J(d)
              .map((S) => {
                const v = /\s*$/.exec(S)[0];
                let u = S.slice(0, S.length - v.length);
                if (t === "strong") {
                  const b = X(u);
                  if (b && i(2) === 0 && !/[-]/.test(u))
                    return `${E}${b}${I}${u}${v}`;
                  for (const [x, N] of Y)
                    u = u.replace(x, (C) => `${E}${N[i(N.length)]}${I}${C}`);
                }
                return (
                  (u = A(u, D, i)),
                  t !== "light" && (u = A(u, Z, i)),
                  t === "strong" &&
                    (u = A(
                      u,
                      (o ? H : W).map(([b, x]) => [b, [x]]),
                      i,
                    )),
                  u + v
                );
              })
              .join("")
          : d,
      ).join(`
`),
    w = [],
    y = /([^]*)([^]*)/g;
  let l = 0,
    p;
  for (; (p = y.exec(h));)
    (p.index > l && w.push({ text: h.slice(l, p.index) }),
      w.push({ text: p[1], original: p[2] }),
      (l = p.index + p[0].length));
  return (l < h.length && w.push({ text: h.slice(l) }), w);
}
const K = new Set(
  "the a an and or but of to in on at for with is are was were be been it this that these those as by from not have has had will would can could i you he she we they my your his her our their".split(
    " ",
  ),
);
function Q(s) {
  const t = Array.from(s).filter(
    (o) => o.toLowerCase() !== o.toUpperCase() || o.charCodeAt(0) > 591,
  );
  if (t.length < 12) return !1;
  if (t.filter((o) => /[^\u0000-ɏ]/.test(o)).length / t.length > 0.3) return !0;
  const n = s.toLowerCase().match(/[a-z\u00c0-\u024f']+/g) ?? [];
  return n.length < 6 ? !1 : n.filter((o) => K.has(o)).length / n.length < 0.08;
}
const k = {
  light: {
    label: "Light",
    hint: 'Light: swaps whole phrases only, such as "in order to" to "to". The smallest, safest edits.',
  },
  medium: {
    label: "Medium",
    hint: "Medium: phrase swaps plus a short list of safe single words, such as big to large and buy to purchase.",
  },
  strong: {
    label: "Strong",
    hint: 'Strong: everything in Medium, plus connectors, contractions, and moving a "because" clause to the front of the sentence.',
  },
};
function V(s, t, c) {
  return !!s && (s.strength !== t || s.input !== c);
}
function ee(s, t, c) {
  const n = [];
  return (
    s.strength !== t &&
      n.push(
        `This result is from ${k[s.strength].label}, but ${k[t].label} is selected`,
      ),
    s.input !== c &&
      n.push(
        n.length
          ? "your text has changed too"
          : "Your text has changed since this result",
      ),
    `${n.join(" and ")}. Press Paraphrase to update it.`
  );
}
function te(s) {
  const t =
    s === "light"
      ? "Light only swaps whole phrases, so many sentences stay as they are. Try Medium or Strong."
      : s === "medium"
        ? "Try Strong, which also changes connectors and moves clauses."
        : "Try a longer passage, or edit the wording by hand.";
  return `No safe changes found for this text at ${k[s].label}, so no trial use was counted. ${t}`;
}
const R = {
  what: 'Rewrites English text with safe, hand-checked phrase and word swaps — and, on the Strong setting, simple sentence changes such as moving a "because" clause to the front — so the grammar stays intact. It is a light rewriter, not an AI one: expect careful edits, not a full rewrite.',
  how: 'Paste your text, pick a strength (Light, Medium or Strong) and press Paraphrase. Changed words are highlighted — click one to put the original back. Press "Rewrite again" for a different version.',
  tip: "Treat the output as a starting draft to edit, not a finished result — the best writing still benefits from a human pass to make sure it actually sounds like you and fits the context it's going into, rather than reading like a generic rewrite.",
};
function Ie() {
  const { gateShare: s } = P(),
    [t, c] = $.useState(""),
    [n, i] = $.useState([]),
    [o, m] = $.useState("medium"),
    [h, w] = $.useState(0),
    [y, l] = $.useState(null),
    [p, d] = $.useState(""),
    { logUsageNow: S } = U(),
    v = (a) => {
      w(a);
      const f = L(t, o, a);
      return (
        i(f),
        l({ strength: o, input: t }),
        f.some((g) => g.original !== void 0)
      );
    },
    u = async () => {
      if (!t.trim()) return;
      if ((d(""), Q(t))) {
        (i([]), l(null));
        const g =
          "This looks like it is not English. The paraphraser is English only, so no changes were made and no trial use was counted.";
        (d(g), j.info(g));
        return;
      }
      const a = L(t, o, 0);
      if (!a.some((g) => g.original !== void 0)) {
        (i(a), l({ strength: o, input: t }));
        const g = te(o);
        (d(g), j.info(g));
        return;
      }
      if (!(await S("generate"))) {
        (i([]),
          l(null),
          d(
            "Nothing was paraphrased because today's trial uses are used up. Your text is still here.",
          ));
        return;
      }
      v(0);
    },
    b = V(y, o, t),
    x = n.map((a) => a.text).join(""),
    N = n.filter((a) => a.original !== void 0).length,
    C = (a) => (a.trim() ? a.trim().split(/\s+/).length : 0),
    O = (a) => i((f) => f.map((g, M) => (M === a ? { text: g.original } : g)));
  return r.jsxs(q, {
    children: [
      r.jsxs("div", {
        className: "space-y-4",
        children: [
          r.jsx(z, {
            "aria-label": "Text to paraphrase (English)",
            value: t,
            onChange: (a) => c(a.target.value),
            placeholder: "Enter English text to paraphrase...",
            className: "min-h-[150px]",
          }),
          r.jsxs("p", {
            className: "text-xs text-muted-foreground",
            children: [C(t), " words · ", t.length, " characters"],
          }),
          r.jsxs("div", {
            className: "flex flex-wrap items-center gap-2",
            role: "group",
            "aria-label": "Strength",
            children: [
              r.jsx("span", { className: "text-sm", children: "Strength:" }),
              ["light", "medium", "strong"].map((a) =>
                r.jsx(
                  T,
                  {
                    size: "sm",
                    variant: o === a ? "default" : "outline",
                    onClick: () => m(a),
                    "aria-pressed": o === a,
                    "aria-label": `Strength: ${k[a].label}`,
                    "aria-describedby": "para-mode-hint",
                    children: k[a].label,
                  },
                  a,
                ),
              ),
            ],
          }),
          r.jsx("p", {
            id: "para-mode-hint",
            className: "text-xs text-muted-foreground",
            children: k[o].hint,
          }),
          r.jsxs("div", {
            className: "flex gap-2",
            children: [
              r.jsxs(T, {
                onClick: u,
                disabled: !t.trim(),
                className: "gap-2",
                children: [r.jsx(B, { className: "h-4 w-4" }), "Paraphrase"],
              }),
              n.length > 0 &&
                !b &&
                r.jsx(T, {
                  variant: "outline",
                  onClick: () => {
                    v(h + 1) || j.info("No safe changes found this time.");
                  },
                  disabled: !t.trim(),
                  children: "Rewrite again",
                }),
            ],
          }),
          p &&
            !b &&
            r.jsx("p", {
              role: "status",
              "data-testid": "para-note",
              className: "text-sm text-muted-foreground",
              children: p,
            }),
          n.length > 0 &&
            r.jsxs("div", {
              children: [
                b &&
                  y &&
                  r.jsx("p", {
                    role: "status",
                    "data-testid": "para-stale",
                    className:
                      "mb-2 text-sm text-amber-700 dark:text-amber-400",
                    children: ee(y, o, t),
                  }),
                r.jsx("div", {
                  className: `p-3 rounded-lg border bg-card text-sm whitespace-pre-wrap min-h-[150px]${b ? " opacity-50" : ""}`,
                  "data-testid": "para-output",
                  "aria-live": "polite",
                  children: n.map((a, f) =>
                    a.original !== void 0
                      ? r.jsx(
                          "mark",
                          {
                            title: `Original: ${a.original} — click to restore`,
                            onClick: () => O(f),
                            className:
                              "cursor-pointer rounded bg-primary/15 px-0.5 text-foreground",
                            children: a.text,
                          },
                          f,
                        )
                      : r.jsx("span", { children: a.text }, f),
                  ),
                }),
                r.jsxs("p", {
                  className: "text-xs text-muted-foreground mt-1",
                  children: [
                    N,
                    " change",
                    N === 1 ? "" : "s",
                    " highlighted · ",
                    C(x),
                    " words · ",
                    x.length,
                    " characters",
                  ],
                }),
                r.jsx(T, {
                  size: "sm",
                  className: "mt-2",
                  onClick: () => {
                    s(async () => {
                      try {
                        return (
                          await navigator.clipboard.writeText(x),
                          j.success("Copied!"),
                          !0
                        );
                      } catch {
                        return (
                          j.error(
                            "Couldn't copy. Select the text and copy it by hand.",
                          ),
                          !1
                        );
                      }
                    });
                  },
                  children: "Copy",
                }),
              ],
            }),
          r.jsx("p", {
            className: "text-xs text-muted-foreground",
            children:
              "English only. Makes safe, hand-checked word, phrase and sentence changes — it is not an AI rewriter, so review the result. Runs in your browser: your text is never sent anywhere, though a plain usage tick (tool name and an anonymous device id) is recorded.",
          }),
        ],
      }),
      r.jsx(_, { whatIsIt: R.what, howToUse: R.how, tip: R.tip }),
    ],
  });
}
export { Ie as default };
//# sourceMappingURL=TextParaphraser-BDp9aeKR.js.map
