# Devices, locales, geo, a11y (FDP-76)

- Devices: 10/10 return 200; no strip on any. Only iPhone SE overflows (329/320, header button).
- Locales: 10 hreflang pages 200; navigation translated, tool controls and copy English (English-only tool). /ar → 404 (not in hreflang). ja desktop overflows a few px.
- Geo: no prices in any of 6 contexts; consent banner text in de-DE and fr-FR.
- axe: desktop label-content-name-mismatch (serious) + region (moderate); Pixel 7 color-contrast (serious, `.text-muted-foreground/50`).
