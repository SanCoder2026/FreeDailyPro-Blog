// FDP-76 offline harness: the tool's own rule engine (lines 29-221 of TextParaphraser-BDp9aeKR.js, pretty-printed, copied verbatim) + the same output parse/join the page uses. Usage: node px76-harness.js [cases.json]
const E = "",
  I = "",
  e = (s, t) => [new RegExp(`\\b${s}\\b`, "gi"), t],
  D = [
    e("in order to", ["to"]),
    e("due to the fact that", ["because"]),
    e("in spite of", ["despite"]),
    e("as well as", ["along with"]),
    e("a number of", ["several"]),
    e("a lot of", ["plenty of"]),
    e("a few", ["a handful of"]),
    e("at this point in time", ["now"]),
    e("at the present time", ["currently"]),
    e("in the event that", ["if"]),
    e("prior to", ["before"]),
    e("subsequent to", ["after"]),
    e("is able to", ["can"]),
    e("are able to", ["can"]),
    e("right away", ["immediately"]),
    e("right now", ["at the moment"]),
    e("for example", ["for instance"]),
    e("because of", ["due to"]),
    e("i think", ["I believe"]),
    e("i want to", ["I would like to"]),
    e("let me know", ["please tell me", "feel free to tell me"]),
    e("thank you very much for", ["thank you so much for", "many thanks for"]),
    e("thanks a lot for", ["many thanks for"]),
    e("don't forget to", ["remember to"]),
    e("don't forget", ["remember"]),
    e("get started", ["begin"]),
    e("quick update", ["brief update"]),
    e("quick question", ["short question"]),
    e("quick look", ["brief look"]),
    e("as soon as possible", ["at your earliest convenience"]),
  ],
  F = [
    e("big", ["large"]),
    e("huge", ["enormous"]),
    e("important", ["significant"]),
    e("main", ["primary"]),
    e("easy", ["straightforward"]),
    e("buy", ["purchase"]),
    e("buys", ["purchases"]),
    e("bought", ["purchased"]),
    e("buying", ["purchasing"]),
    e("goals", ["aims", "objectives"]),
    e("goal", ["aim", "objective"]),
    e("companies", ["businesses"]),
    e("company", ["business"]),
    e("problems", ["issues"]),
    e("problem", ["issue"]),
    e("ideas", ["concepts"]),
    e("idea", ["concept"]),
    e("methods", ["approaches"]),
    e("method", ["approach"]),
    e("(will|to|would|should|can|must|may) start", ["$1 begin"]),
    e("(will|to|would|should|can|must|may) help", ["$1 assist"]),
    e("(needs|need) to", ["$1 to"]),
    e("however", ["that said"]),
    e("also", ["as well"]),
  ],
  Z = F.filter(([, s]) => s.some((t) => t !== "$1 to")),
  H = [
    [/\bcan't\b/gi, "cannot"],
    [/\bwon't\b/gi, "will not"],
    [/\bdon't\b/gi, "do not"],
    [/\bdoesn't\b/gi, "does not"],
    [/\bdidn't\b/gi, "did not"],
    [/\bisn't\b/gi, "is not"],
    [/\baren't\b/gi, "are not"],
    [/\bwasn't\b/gi, "was not"],
    [/\bcouldn't\b/gi, "could not"],
    [/\bshouldn't\b/gi, "should not"],
    [/\bwouldn't\b/gi, "would not"],
    [/\bhaven't\b/gi, "have not"],
    [/\bhasn't\b/gi, "has not"],
    [/\bI'm\b/g, "I am"],
    [/\b(you|we|they)'re\b/gi, "$1 are"],
    [/\b(I|you|we|they)'ll\b/gi, "$1 will"],
    [/\b(I|you|we|they)'ve\b/gi, "$1 have"],
  ],
  W = [
    [/\bdo not\b/gi, "don't"],
    [/\bdoes not\b/gi, "doesn't"],
    [/\bdid not\b/gi, "didn't"],
    [/\bis not\b/gi, "isn't"],
    [/\bare not\b/gi, "aren't"],
    [/\bcannot\b/gi, "can't"],
    [/\bwill not\b/gi, "won't"],
    [/\bI am\b/g, "I'm"],
    [/\b(you|we|they) are\b/gi, "$1're"],
    [/\b(I|you|we|they) will\b/gi, "$1'll"],
  ],
  Y = [
    [/^But\b/, ["However,", "Even so,"]],
    [/^Also,/, ["In addition,"]],
    [/^So\b,?/, ["As a result,"]],
  ];
function G(s, t) {
  return s.length > 1 && s === s.toUpperCase() && /[A-Z]/.test(s)
    ? t.toUpperCase()
    : /^[A-Z]/.test(s)
      ? t.charAt(0).toUpperCase() + t.slice(1)
      : t;
}
function A(s, t, c) {
  let n = s;
  for (const [i, o] of t)
    n = n.replace(new RegExp(i.source, i.flags), (...m) => {
      const h = m[0];
      if (h.includes(E) || h.includes(I)) return h;
      const w = m.slice(1, -2);
      let l = o[c(o.length)].replace(
        /\$(\d)/g,
        (p, d) => w[Number(d) - 1] ?? "",
      );
      return l === h ? h : ((l = G(h, l)), `${E}${l}${I}${h}`);
    });
  return n;
}
function X(s) {
  const t = /^([^,;:]+?) because ([^,;:]+?)([.!?])$/.exec(s.trim());
  if (!t) return null;
  const [, c, n, i] = t;
  return c.split(/\s+/).length < 2 || /^(and|but|or)\b/i.test(c)
    ? null
    : `Because ${n}, ${((m) => (/^[A-Z][a-z]/.test(m) ? m[0].toLowerCase() + m.slice(1) : m))(c)}${i}`;
}
function J(s) {
  return s.match(/[^.!?]+[.!?]+["')\]]*\s*|[^.!?]+$/g) ?? [s];
}
function L(s, t = "medium", c = 0) {
  let n = c;
  const i = (d) => (d <= 1 ? 0 : Math.abs(n++) % d),
    o = /\b\w+n't\b|\bI'm\b/.test(s),
    h = s
      .split(
        `
`,
      )
      .map((d) =>
        /[A-Za-z]/.test(d)
          ? J(d)
              .map((S) => {
                const v = /\s*$/.exec(S)[0];
                let u = S.slice(0, S.length - v.length);
                if (t === "strong") {
                  const b = X(u);
                  if (b && i(2) === 0 && !/[-]/.test(u))
                    return `${E}${b}${I}${u}${v}`;
                  for (const [x, N] of Y)
                    u = u.replace(x, (C) => `${E}${N[i(N.length)]}${I}${C}`);
                }
                return (
                  (u = A(u, D, i)),
                  t !== "light" && (u = A(u, Z, i)),
                  t === "strong" &&
                    (u = A(
                      u,
                      (o ? H : W).map(([b, x]) => [b, [x]]),
                      i,
                    )),
                  u + v
                );
              })
              .join("")
          : d,
      ).join(`
`),
    w = [],
    y = /([^]*)([^]*)/g;
  let l = 0,
    p;
  for (; (p = y.exec(h));)
    (p.index > l && w.push({ text: h.slice(l, p.index) }),
      w.push({ text: p[1], original: p[2] }),
      (l = p.index + p[0].length));
  return (l < h.length && w.push({ text: h.slice(l) }), w);
}
const K = new Set(
  "the a an and or but of to in on at for with is are was were be been it this that these those as by from not have has had will would can could i you he she we they my your his her our their".split(
    " ",
  ),
);
function Q(s) {
  const t = Array.from(s).filter(
    (o) => o.toLowerCase() !== o.toUpperCase() || o.charCodeAt(0) > 591,
  );
  if (t.length < 12) return !1;
  if (t.filter((o) => /[^\u0000-ɏ]/.test(o)).length / t.length > 0.3) return !0;
  const n = s.toLowerCase().match(/[a-z\u00c0-\u024f']+/g) ?? [];
  return n.length < 6 ? !1 : n.filter((o) => K.has(o)).length / n.length < 0.08;
}
const out = (s, st, seed = 0) => { if (Q(s)) return { notEnglish: true }; const segs = L(s, st, seed); return { text: segs.map(a => a.text).join(''), changes: segs.filter(a => a.original !== undefined).map(a => a.original + ' -> ' + a.text), pua: /[\uE000-\uE003]/.test(segs.map(a => a.text).join('')) }; };
const cases = require(process.argv[2] || './px76-cases.json'); const R = {};
for (const [id, s, st, seed] of cases) { R[id] = { in: s, st: st || 'medium', ...out(s, st || 'medium', seed || 0) }; console.log(id, '|', (st||'medium').padEnd(6), '|', R[id].notEnglish ? 'NOT-ENGLISH' : JSON.stringify(R[id].text) + (R[id].pua ? '  [PUA LEFT]' : '')); }
require('fs').writeFileSync('/workspace/deep/76-text-paraphraser/harness.json', JSON.stringify(R, null, 1));
