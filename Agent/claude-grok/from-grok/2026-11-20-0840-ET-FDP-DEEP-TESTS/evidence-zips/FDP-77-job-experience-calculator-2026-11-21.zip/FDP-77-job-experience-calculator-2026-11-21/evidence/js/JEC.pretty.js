import { r as E, j as a } from "./vendor-react-D01g8YgM.js";
import { T as F, f as B } from "./ToolPage-DwLoDncN.js";
import { I as w, B as C, X as G, e as k } from "./index-B1CTyGtY.js";
import { C as I } from "./checkbox-Ml1pfDb3.js";
import { T as M } from "./ToolInfoSection-C0i6Zbwo.js";
import { u as R } from "./useLogToolUsage-BdvvKW0n.js";
import {
  c as h,
  a as J,
  b as T,
  f as z,
  p as y,
  t as A,
} from "./dates-DoPZ1fRV.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-DhOoIDuZ.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./copyText-DPnES92p.js";
const S = (t, m) => (m ? z(t, 1) : t);
function U(t, m) {
  if (h(t.end, t.start) < 0) return null;
  const f = S(t.end, m);
  return { ...T(t.start, f), totalDays: J(t.start, f) };
}
function Y(t, m) {
  const f = t
    .filter((o) => h(o.end, o.start) >= 0)
    .map((o) => ({ start: o.start, end: S(o.end, m) }))
    .filter((o) => h(o.end, o.start) >= 0)
    .sort((o, l) => h(o.start, l.start));
  if (!f.length) return null;
  const n = [];
  for (const o of f) {
    const l = n[n.length - 1];
    l && h(o.start, l.end) <= 0
      ? h(o.end, l.end) > 0 && (l.end = o.end)
      : n.push({ ...o });
  }
  let u = 0,
    r = 0,
    d = 0;
  for (const o of n) {
    const l = T(o.start, o.end);
    ((u += l.years * 12 + l.months), (r += l.days), (d += J(o.start, o.end)));
  }
  return (
    (u += Math.floor(r / 30)),
    (r %= 30),
    {
      years: Math.floor(u / 12),
      months: u % 12,
      days: r,
      totalDays: d,
      periods: n.length,
    }
  );
}
const b = (t) => Math.round((t / 365.25) * 10) / 10;
function _(t, m) {
  const f = t
      .filter((r) => h(r.end, r.start) >= 0)
      .map((r) => ({ start: r.start, end: r.end, bound: S(r.end, m) }))
      .sort((r, d) => h(r.start, d.start)),
    n = [];
  for (const r of f) {
    const d = n[n.length - 1];
    d && h(r.start, d.bound) <= 0
      ? h(r.bound, d.bound) > 0 && ((d.bound = r.bound), (d.end = r.end))
      : n.push({ ...r });
  }
  const u = [];
  for (let r = 1; r < n.length; r++) {
    const d = n[r - 1].bound,
      o = n[r].start;
    u.push({ after: n[r - 1].end, before: o, ...T(d, o), totalDays: J(d, o) });
  }
  return u;
}
const L = (t) =>
    [
      t.years && `${t.years} yr`,
      t.months && `${t.months} mo`,
      (t.days || (!t.years && !t.months)) && `${t.days} d`,
    ]
      .filter(Boolean)
      .join(" "),
  D = {
    what: "Calculates work experience duration in years, months, and days between a start and end date — add multiple jobs to also see your total combined professional experience across all of them, useful for resumes, LinkedIn, or job applications that ask for total years of experience.",
    how: `Enter a start date and end date for each job (or check "Currently working here" to use today's date), and add as many jobs as you need. Each one shows its own duration, and the total combines them all. With two or more jobs, any gap between them is listed too (for example "Gap: 2 mo"), which is the follow-up many application forms and recruiters ask about.`,
    tip: `Overlapping jobs (for example a freelance job alongside a full-time role) are merged first, so the overlapping period is counted once. Month convention: months are calendar months counted from the start date (31 Jan to 28 Feb is 1 month, because the 31st is clamped to the end of February); each period's months and days are then added up, and a 30-day month is used only when carrying leftover days between periods. Tick or untick "Count the end date as a full day": HR and visa forms usually expect 1 January to 31 December to be one year.`,
  };
let H = 1;
const j = (t) => String(t).padStart(2, "0"),
  g = (t) => `${t.y}-${j(t.m)}-${j(t.d)}`,
  P = () => {
    const t = A();
    return `${t.y}-${j(t.m)}-${j(t.d)}`;
  };
function we() {
  const t = P(),
    [m, f] = E.useState(!0),
    [n, u] = E.useState([
      { id: 0, company: "", start: "", end: t, current: !0 },
    ]),
    r = () => {
      u((e) => [
        ...e,
        { id: H++, company: "", start: "", end: t, current: !0 },
      ]);
    },
    d = (e) => {
      u((s) => s.filter((i) => i.id !== e));
    },
    o = (e, s, i) => {
      u((p) => p.map((N) => (N.id === e ? { ...N, [s]: i } : N)));
    },
    l = (e) => {
      const s = y(e.start),
        i = y(e.current ? t : e.end);
      return s && i ? { start: s, end: i } : null;
    },
    v = n.map((e) => {
      const s = l(e);
      return { job: e, duration: s ? U(s, m) : null };
    }),
    x = v.filter((e) => e.duration !== null),
    c =
      x.length > 0
        ? Y(
            n.map(l).filter((e) => !!e),
            m,
          )
        : null,
    $ = _(
      n.map(l).filter((e) => !!e),
      m,
    ),
    O = () => {
      if (!c) return;
      const e = v
        .filter((s) => s.duration)
        .map(
          (s) =>
            `${s.job.company || "Job"}: ${s.job.start} to ${s.job.current ? "present" : s.job.end} = ${s.duration.years} y ${s.duration.months} m ${s.duration.days} d`,
        );
      for (const s of $)
        e.push(`Gap: ${L(s)} between ${g(s.after)} and ${g(s.before)}`);
      (e.push(
        `Total (overlaps counted once): ${c.years} years ${c.months} months ${c.days} days (about ${b(c.totalDays)} ${b(c.totalDays) === 1 ? "year" : "years"})`,
      ),
        navigator.clipboard
          ?.writeText(
            e.join(`
`),
          )
          .catch(() => {}));
    };
  return (
    R(!0, 3e3, { ownActions: !0 }),
    a.jsxs(F, {
      children: [
        a.jsxs("div", {
          className: "max-w-2xl mx-auto space-y-4",
          children: [
            n.map((e, s) => {
              const i = v.find((p) => p.job.id === e.id)?.duration;
              return a.jsxs(
                "div",
                {
                  className: "p-4 rounded-lg border bg-card space-y-3",
                  children: [
                    a.jsxs("div", {
                      className: "flex items-center justify-between",
                      children: [
                        a.jsx(w, {
                          "aria-label": `Job name, Job ${s + 1}`,
                          value: e.company,
                          onChange: (p) => o(e.id, "company", p.target.value),
                          placeholder: `Job ${s + 1} (e.g. company or role name, optional)`,
                          className:
                            "border-none px-0 h-auto text-sm font-medium focus-visible:ring-0",
                        }),
                        n.length > 1 &&
                          a.jsx(C, {
                            variant: "ghost",
                            size: "icon",
                            className: "h-6 w-6 shrink-0",
                            "aria-label": `Remove Job ${s + 1}`,
                            onClick: () => d(e.id),
                            children: a.jsx(G, { className: "h-3.5 w-3.5" }),
                          }),
                      ],
                    }),
                    a.jsxs("div", {
                      className: "grid grid-cols-2 gap-3",
                      children: [
                        a.jsxs("div", {
                          children: [
                            a.jsx(k, {
                              htmlFor: `je-start-${e.id}`,
                              className: "text-xs",
                              children: "Start Date",
                            }),
                            a.jsx(w, {
                              id: `je-start-${e.id}`,
                              "aria-label": `Start date, Job ${s + 1}`,
                              type: "date",
                              value: e.start,
                              onChange: (p) => o(e.id, "start", p.target.value),
                            }),
                          ],
                        }),
                        a.jsxs("div", {
                          children: [
                            a.jsx(k, {
                              htmlFor: `je-end-${e.id}`,
                              className: "text-xs",
                              children: "End Date",
                            }),
                            a.jsx(w, {
                              id: `je-end-${e.id}`,
                              "aria-label": `End date, Job ${s + 1}`,
                              type: "date",
                              value: e.end,
                              onChange: (p) => o(e.id, "end", p.target.value),
                              disabled: e.current,
                            }),
                          ],
                        }),
                      ],
                    }),
                    a.jsxs("div", {
                      className: "flex items-center gap-2",
                      children: [
                        a.jsx(I, {
                          id: `current-${e.id}`,
                          checked: e.current,
                          onCheckedChange: (p) => o(e.id, "current", !!p),
                        }),
                        a.jsx(k, {
                          htmlFor: `current-${e.id}`,
                          className: "text-xs font-normal cursor-pointer",
                          children: "Currently working here",
                        }),
                      ],
                    }),
                    i &&
                      !0 &&
                      a.jsxs("p", {
                        className: "text-sm font-medium text-primary pt-1",
                        children: [
                          i.years,
                          " year",
                          i.years !== 1 ? "s" : "",
                          ", ",
                          i.months,
                          " month",
                          i.months !== 1 ? "s" : "",
                          ", ",
                          i.days,
                          " day",
                          i.days !== 1 ? "s" : "",
                          a.jsxs("span", {
                            className: "text-muted-foreground font-normal",
                            children: [
                              " (",
                              i.totalDays.toLocaleString(),
                              " total days)",
                            ],
                          }),
                        ],
                      }),
                    !e.current &&
                      !!y(e.start) &&
                      !!y(e.end) &&
                      h(y(e.end), y(e.start)) < 0 &&
                      a.jsx("p", {
                        role: "alert",
                        "data-testid": "je-reversed",
                        className: "text-xs text-destructive",
                        children:
                          "End date is before the start date, so this job isn't counted. Swap the dates or correct one of them.",
                      }),
                  ],
                },
                e.id,
              );
            }),
            a.jsxs(C, {
              variant: "outline",
              size: "sm",
              onClick: r,
              className: "gap-1.5",
              children: [
                a.jsx(B, { className: "h-3.5 w-3.5" }),
                " Add Another Job",
              ],
            }),
            a.jsxs("label", {
              className: "flex items-center gap-2 text-sm",
              children: [
                a.jsx(I, {
                  "aria-label": "Count the end date as a full day",
                  checked: m,
                  onCheckedChange: (e) => f(!!e),
                }),
                " Count the end date as a full day (1 Jan to 31 Dec = 1 year)",
              ],
            }),
            c &&
              !0 &&
              a.jsxs("div", {
                className: "p-6 rounded-xl border bg-primary/5 text-center",
                "data-testid": "je-total",
                children: [
                  a.jsxs("p", {
                    className: "text-xs text-muted-foreground mb-1",
                    children: [
                      "Total experience (",
                      x.length,
                      " job",
                      x.length === 1 ? "" : "s",
                      ", overlapping periods counted once)",
                    ],
                  }),
                  a.jsxs("p", {
                    className: "text-3xl font-bold text-primary",
                    children: [c.years, " yr ", c.months, " mo ", c.days, " d"],
                  }),
                  a.jsxs("p", {
                    className: "text-sm text-muted-foreground mt-1",
                    children: [
                      "about ",
                      b(c.totalDays),
                      " ",
                      b(c.totalDays) === 1 ? "year" : "years",
                    ],
                  }),
                  a.jsx(C, {
                    variant: "outline",
                    size: "sm",
                    className: "mt-3",
                    onClick: O,
                    children: "Copy summary",
                  }),
                ],
              }),
            c &&
              !0 &&
              x.length >= 2 &&
              a.jsxs("div", {
                className: "p-4 rounded-lg border bg-card",
                "data-testid": "je-gaps",
                children: [
                  a.jsx("p", {
                    className: "text-sm font-medium mb-1",
                    children: "Gaps between jobs",
                  }),
                  $.length === 0
                    ? a.jsx("p", {
                        className: "text-sm text-muted-foreground",
                        children:
                          "No gaps: the jobs you entered run back to back or overlap.",
                      })
                    : a.jsx("ul", {
                        className: "text-sm space-y-1",
                        children: $.map((e, s) =>
                          a.jsxs(
                            "li",
                            {
                              children: [
                                "Gap: ",
                                a.jsx("strong", { children: L(e) }),
                                " ",
                                a.jsxs("span", {
                                  className: "text-muted-foreground",
                                  children: [
                                    "(",
                                    e.totalDays.toLocaleString(),
                                    " days, between ",
                                    g(e.after),
                                    " and ",
                                    g(e.before),
                                    ")",
                                  ],
                                }),
                              ],
                            },
                            s,
                          ),
                        ),
                      }),
                ],
              }),
          ],
        }),
        a.jsx(M, { whatIsIt: D.what, howToUse: D.how, tip: D.tip }),
      ],
    })
  );
}
export { we as default };
//# sourceMappingURL=JobExperienceCalculator-fu8pMVn_.js.map
