// text-paraphraser: dump both blog posts' text and links. Read-only.
const { chromium } = require('playwright'); const fs = require('fs');
const D = '/workspace/deep/77-job-experience-calculator/';
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage();
 for (const s of ['job-experience-calculator']) {
  await p.goto('https://www.freedailypro.com/blog/' + s, { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(5000);
  const t = await p.evaluate(() => (document.querySelector('article') || document.querySelector('main')).innerText);
  const links = await p.evaluate(() => [...(document.querySelector('article') || document.querySelector('main')).querySelectorAll('a')].map(a => a.innerText.trim().slice(0, 50) + ' -> ' + a.href));
  fs.writeFileSync(D + 'blog/' + s + '.txt', t + '\n\n--- links\n' + links.join('\n') + '\n\n--- title: ' + await p.title());
  await p.screenshot({ path: D + 'live/blog-' + s.slice(0, 20) + '.png' }); }
 await b.close(); })();
