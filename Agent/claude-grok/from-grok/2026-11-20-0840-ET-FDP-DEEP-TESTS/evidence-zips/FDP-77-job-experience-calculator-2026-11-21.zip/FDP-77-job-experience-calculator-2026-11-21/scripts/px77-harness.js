// FDP-77 offline harness: dates-DoPZ1fRV.js (D,c,i,l,m,u,h,T) and JobExperienceCalculator-fu8pMVn_.js (S,U,Y,_,L,b) copied verbatim (pretty-printed), renamed only where the two modules' minified names collide. Usage: node px77-harness.js
function D(t) {
  const e = /^(\d{4})-(\d{2})-(\d{2})$/.exec(t);
  if (!e) return null;
  const [n, a, s] = [Number(e[1]), Number(e[2]), Number(e[3])],
    r = new Date(Date.UTC(n, a - 1, s));
  return r.getUTCFullYear() !== n ||
    r.getUTCMonth() !== a - 1 ||
    r.getUTCDate() !== s
    ? null
    : { y: n, m: a, d: s };
}
function todayLocal(t = new Date()) {
  return { y: t.getFullYear(), m: t.getMonth() + 1, d: t.getDate() };
}
const c = (t) => Math.round(Date.UTC(t.y, t.m - 1, t.d) / 864e5),
  i = (t, e) => c(e) - c(t),
  l = (t, e) => new Date(Date.UTC(t, e, 0)).getUTCDate(),
  y = (t) => l(t, 2) === 29,
  m = (t, e) => c(t) - c(e);
function u(t, e) {
  const n = t.y * 12 + (t.m - 1) + e,
    a = Math.floor(n / 12),
    s = (n % 12) + 1;
  return { y: a, m: s, d: Math.min(t.d, l(a, s)) };
}
function diffYMD(t, e) {
  let n = (e.y - t.y) * 12 + (e.m - t.m);
  m(u(t, n), e) > 0 && n--;
  const a = i(u(t, n), e);
  return { years: Math.floor(n / 12), months: n % 12, days: a };
}
function addDays(t, e) {
  const n = new Date(Date.UTC(t.y, t.m - 1, t.d + e));
  return { y: n.getUTCFullYear(), m: n.getUTCMonth() + 1, d: n.getUTCDate() };
}
const p = D, J = i, z = addDays, T = diffYMD, h = m;
const S = (t, m) => (m ? z(t, 1) : t);
function U(t, m) {
  if (h(t.end, t.start) < 0) return null;
  const f = S(t.end, m);
  return { ...T(t.start, f), totalDays: J(t.start, f) };
}
function Y(t, m) {
  const f = t
    .filter((o) => h(o.end, o.start) >= 0)
    .map((o) => ({ start: o.start, end: S(o.end, m) }))
    .filter((o) => h(o.end, o.start) >= 0)
    .sort((o, l) => h(o.start, l.start));
  if (!f.length) return null;
  const n = [];
  for (const o of f) {
    const l = n[n.length - 1];
    l && h(o.start, l.end) <= 0
      ? h(o.end, l.end) > 0 && (l.end = o.end)
      : n.push({ ...o });
  }
  let u = 0,
    r = 0,
    d = 0;
  for (const o of n) {
    const l = T(o.start, o.end);
    ((u += l.years * 12 + l.months), (r += l.days), (d += J(o.start, o.end)));
  }
  return (
    (u += Math.floor(r / 30)),
    (r %= 30),
    {
      years: Math.floor(u / 12),
      months: u % 12,
      days: r,
      totalDays: d,
      periods: n.length,
    }
  );
}
const b = (t) => Math.round((t / 365.25) * 10) / 10;
function _(t, m) {
  const f = t
      .filter((r) => h(r.end, r.start) >= 0)
      .map((r) => ({ start: r.start, end: r.end, bound: S(r.end, m) }))
      .sort((r, d) => h(r.start, d.start)),
    n = [];
  for (const r of f) {
    const d = n[n.length - 1];
    d && h(r.start, d.bound) <= 0
      ? h(r.bound, d.bound) > 0 && ((d.bound = r.bound), (d.end = r.end))
      : n.push({ ...r });
  }
  const u = [];
  for (let r = 1; r < n.length; r++) {
    const d = n[r - 1].bound,
      o = n[r].start;
    u.push({ after: n[r - 1].end, before: o, ...T(d, o), totalDays: J(d, o) });
  }
  return u;
}
const L = (t) =>
    [
      t.years && `${t.years} yr`,
      t.months && `${t.months} mo`,
      (t.days || (!t.years && !t.months)) && `${t.days} d`,
    ]
      .filter(Boolean)
      .join(" ");

const P = s => p(s);
const run = (jobs, inc = true) => { const J2 = jobs.map(([a, e]) => ({ start: P(a), end: P(e) })); return { perJob: J2.map(j => { const d = U(j, inc); return d ? `${d.years}y ${d.months}m ${d.days}d (${d.totalDays}d)` : null; }), total: (() => { const t = Y(J2, inc); return t ? `${t.years} yr ${t.months} mo ${t.days} d, about ${b(t.totalDays)} years, ${t.totalDays} days, ${t.periods} periods` : null; })(), gaps: _(J2, inc).map(g => `Gap: ${L(g)} (${g.totalDays} days, between ${g.after.y}-${g.after.m}-${g.after.d} and ${g.before.y}-${g.before.m}-${g.before.d})`) }; };
const cases = require(process.argv[2] || './px77-cases.json'); const R = {};
for (const [id, jobs, inc] of cases) { R[id] = { jobs, inclusive: inc !== false, ...run(jobs, inc !== false) }; console.log(id, JSON.stringify(R[id].perJob), '|', R[id].total, '|', R[id].gaps.join('; ')); }
require('fs').writeFileSync('/workspace/deep/77-job-experience-calculator/harness.json', JSON.stringify(R, null, 1));
