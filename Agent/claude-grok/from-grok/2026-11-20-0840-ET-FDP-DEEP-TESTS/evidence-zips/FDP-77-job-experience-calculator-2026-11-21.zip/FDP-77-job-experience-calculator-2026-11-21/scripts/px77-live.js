// FDP-77 Job Experience Calculator (Professional 10/day), guest. Usage: node px77-live.js <zero|left|cases> [engine]   env TRIES, SUF
// zero: context at the cap: enter jobs, read results, Copy summary (clipboard read back in Chromium), Ctrl+C on the total; POSTs.
// left: context with uses left: several different calculations + copies in ONE load; POSTs per action; reload.
// cases: the harness cases entered live (results compared with px77-harness.js).
// Never signs in, never types an email or card, never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/77-job-experience-calculator/'; const OUT = BASE + 'live/'; const TOOL = 'https://www.freedailypro.com/tool/job-experience-calculator';
const mode = process.argv[2] || 'zero'; const eng = process.argv[3] || 'chromium'; const sfx = (eng === 'chromium' ? '' : '-' + eng) + (process.env.SUF || '');
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
fs.mkdirSync(OUT + 'cases', { recursive: true });
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p, h, net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 1000 }, locale: 'en-US', timezoneId: 'America/New_York' }); if (eng === 'chromium') await c.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://www.freedailypro.com' }); p = await c.newPage(); p.setDefaultTimeout(12000); net = []; h = null;
  p.on('request', r => { const u = r.url(); if (r.method() === 'POST' && /freedailypro\.com\/api/.test(u) && !/insight\.hit|funnel\.hit/.test(u)) net.push({ t: now(), u: u.slice(0, 70), len: (r.postData() || '').length }); });
  await p.goto(TOOL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const helper = async () => { if (!h) { h = await c.newPage(); await h.goto('https://www.freedailypro.com/robots.txt'); } };
 const clipGet = async () => { if (eng !== 'chromium') return null; await helper(); await h.bringToFront(); const v = await h.evaluate(() => navigator.clipboard.readText()).catch(e => 'ERR ' + e.message.slice(0, 40)); await p.bringToFront(); return v; };
 const clipSet = async s => { if (eng !== 'chromium') return; await helper(); await h.bringToFront(); await h.evaluate(s => navigator.clipboard.writeText(s), s).catch(() => { }); await p.bringToFront(); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(250); } };
 const shot = (n, full) => p.screenshot({ path: OUT + 'cases/' + n + sfx + '.png', fullPage: !!full });
 const strip = () => p.evaluate(() => (document.querySelector('main').innerText.match(/Trial[^\n]*/) || [null])[0]);
 const read = () => p.evaluate(() => { const m = document.querySelector('main'); const jobs = [...m.querySelectorAll('.p-4.rounded-lg.border.bg-card.space-y-3')].map(d => ({ dur: d.querySelector('p.text-primary')?.innerText || null, alert: d.querySelector('[data-testid=je-reversed]')?.innerText || null })); const t = m.querySelector('[data-testid=je-total]'); const g = m.querySelector('[data-testid=je-gaps]'); return { jobs, total: t ? t.innerText.replace(/\n+/g, ' | ').replace(/ \| Copy summary/, '') : null, gaps: g ? g.innerText.replace(/\n+/g, ' | ') : null }; });
 const reset = async () => { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); };
 const setInc = async on => { const cb = p.getByRole('checkbox', { name: 'Count the end date as a full day' }); const st = (await cb.getAttribute('aria-checked')) === 'true'; if (st !== on) await cb.click(); };
 const enter = async (jobs, inc = true) => { for (let k = 0; k < jobs.length; k++) { if (k > 0) await p.locator('main button', { hasText: 'Add Another Job' }).click(); const [s, e, cur] = jobs[k]; const cards = p.locator('main .p-4.rounded-lg.border.bg-card.space-y-3'); const card = cards.nth(k); if (!cur) { const cb = card.getByRole('checkbox'); if ((await cb.getAttribute('aria-checked')) === 'true') await cb.click(); } await card.locator('input[type=date]').nth(0).fill(s); if (!cur) await card.locator('input[type=date]').nth(1).fill(e); } await setInc(inc); await p.waitForTimeout(800); };
 const act = async (label, fn) => { const np = net.length; const before = await used(); const x = await fn(); await p.waitForTimeout(3800); const dg = await dialog(); const r = { before, after: await used(), posts: net.slice(np).length, dialog: dg, ...(await read()), ...(x || {}) }; if (dg) { await shot('dlg-' + label); await esc(); } return r; };
 const copySum = async () => { await clipSet('EMPTY'); await p.locator('main button', { hasText: 'Copy summary' }).click(); await p.waitForTimeout(800); return { clip: await clipGet() }; };
 const ctrlC = async () => { await clipSet('EMPTY'); await p.locator('[data-testid=je-total] p.text-3xl').selectText(); await p.keyboard.press('Control+C'); await p.waitForTimeout(800); return { clipCtrlC: await clipGet() }; };
 const C = async (id, fn) => { try { R.cases[id] = await fn(); } catch (e) { R.cases[id] = { err: e.message.split('\n')[0].slice(0, 200) }; await shot(id + '-err').catch(() => { }); } console.log(id, JSON.stringify(R.cases[id]).slice(0, 700)); };
 const find = async want => { const TRIES = +(process.env.TRIES || 10); for (let i = 0; i < TRIES; i++) { await open(); const u = await used(); R.tries.push(u); const [a, l] = u.split('/').map(Number); if (want === 'cap' ? a >= l : a < l) return true; await c.close(); } return false; };
 const A = [['2016-03-01', '2019-05-31'], ['2018-11-01', '2021-02-28'], ['2021-06-14', '', true]];
 if (mode === 'zero' || mode === 'left') { R.found = await find(mode === 'zero' ? 'cap' : 'left'); if (!R.found) { fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('none', R.tries.join(',')); await b.close(); return; } R.start = { used: await used(), strip: await strip() }; await shot('X00-' + mode);
  await C('X01-three-jobs', async () => { const r = await act('X01', () => enter(A)); await shot('X01-' + mode, true); return r; });
  await C('X02-copy-summary', () => act('X02', copySum));
  await C('X03-ctrl-c-total', () => act('X03', ctrlC));
  await C('X04-edit-date', () => act('X04', async () => { await p.locator('main .p-4.rounded-lg.border.bg-card.space-y-3').nth(0).locator('input[type=date]').nth(0).fill('2015-01-05'); }));
  await C('X05-copy-again', () => act('X05', copySum));
  await C('X06-toggle-inclusive', () => act('X06', () => setInc(false)));
  await C('X07-reload-new-calc', async () => { await reset(); return act('X07', () => enter([['2010-01-01', '2012-12-31']])); });
  await C('X08-copy-after-reload', () => act('X08', copySum));
  R.end = await used(); R.net = net;
 } else if (mode === 'cases') { await open(); R.start = { used: await used() };
  const cases = require('./px77-cases.json');
  for (const [id, jobs, inc] of cases) { await C(id, async () => { await reset(); await enter(jobs.map(([s, e]) => [s, e, false]), inc !== false); const r = await read(); if (/E02|E12|E21|E10/.test(id)) await shot(id, true); return r; }); }
  await C('F01-future-start-current', async () => { await reset(); await enter([['2027-03-01', '', true]]); const r = await read(); await shot('F01-future-start', true); return r; });
  await C('F02-start-only', async () => { await reset(); await enter([['2024-01-15', '', true]]); return read(); });
  await C('F03-remove-job', async () => { await reset(); await enter([['2019-01-01', '2019-12-31'], ['2021-01-01', '2021-12-31']].map(x => [...x, false])); await p.getByRole('button', { name: 'Remove Job 2' }).click(); await p.waitForTimeout(400); return read(); });
  R.end = await used(); R.net = net;
 }
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', JSON.stringify(R.tries), JSON.stringify(R.start || ''), R.end); await b.close(); })();
