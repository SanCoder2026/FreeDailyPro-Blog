const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/jszip.min-CT0ZA6V1.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/jszip.min-C-FLQHAz.js",
      "assets/_commonjs-dynamic-modules-TDtrdbi3.js",
    ]),
) => i.map((i) => d[i]);
import { r as f, j as s } from "./vendor-react-D01g8YgM.js";
import { b as Z, T as _, d as z } from "./ToolPage-DwLoDncN.js";
import {
  ap as U,
  e as C,
  I as q,
  B as y,
  N as A,
  D as B,
  f as j,
} from "./index-B1CTyGtY.js";
import { T as F } from "./ToolInfoSection-C0i6Zbwo.js";
import { F as O } from "./file-archive-DModNmKj.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
function R(o) {
  const i = (o ?? "").trim();
  if (!i) return null;
  if (/^[\w-]{11}$/.test(i)) return i;
  let t;
  try {
    t = new URL(/^[a-z]+:\/\//i.test(i) ? i : "https://" + i);
  } catch {
    return null;
  }
  const d = t.hostname.toLowerCase().replace(/^(www|m|music)\./, ""),
    c = (l) => (l && /^[\w-]{11}$/.test(l) ? l : null);
  if (d === "youtu.be") return c(t.pathname.split("/")[1]);
  if (d === "youtube.com" || d === "youtube-nocookie.com") {
    const l = t.searchParams.get("v");
    if (l) return c(l);
    const n = t.pathname.match(/^\/(?:shorts|embed|live|v|e)\/([\w-]{11})/);
    if (n) return n[1];
  }
  return null;
}
const p = [
    { file: "maxresdefault", label: "Max resolution", w: 1280, h: 720 },
    { file: "sddefault", label: "Standard", w: 640, h: 480 },
    { file: "hqdefault", label: "High quality", w: 480, h: 360 },
    { file: "mqdefault", label: "Medium", w: 320, h: 180 },
    { file: "default", label: "Small", w: 120, h: 90 },
  ],
  b = (o, i) => `https://img.youtube.com/vi/${o}/${i}.jpg`,
  H = (o, i) => o <= 120 && i > 120,
  I = (o) => !!o.hqdefault && !!o.mqdefault,
  D = (o) => p.filter((i) => !o[i.file]),
  P = (o, i) => `youtube-${o}-${i}.jpg`,
  M = (o) => `youtube-${o}-thumbnails.zip`;
function V(o, i) {
  for (const t of p) if (!o[t.file]) return i[t.file] ? t : "loading";
  return null;
}
const W = (o, i) => p.every((t) => o[t.file] || i[t.file]);
async function G(o, i, t = (d) => fetch(d)) {
  const { default: d } = await U(
      async () => {
        const { default: a } = await import("./jszip.min-CT0ZA6V1.js").then(
          (u) => u.j,
        );
        return { default: a };
      },
      __vite__mapDeps([0, 1, 2, 3]),
    ),
    c = new d(),
    l = [],
    n = [];
  if (
    (await Promise.all(
      i.map(async (a) => {
        try {
          const u = await t(b(o, a.file));
          if (!u.ok) throw new Error(String(u.status));
          (c.file(P(o, a.file), await u.arrayBuffer()), l.push(a.file));
        } catch {
          n.push(a.file);
        }
      }),
    ),
    l.length === 0)
  )
    throw new Error("no thumbnail could be fetched");
  return {
    blob: await c.generateAsync({ type: "blob" }),
    included: p.filter((a) => l.includes(a.file)).map((a) => a.file),
    failed: p.filter((a) => n.includes(a.file)).map((a) => a.file),
  };
}
const N = {
  what: "Downloads the thumbnail image of a YouTube video in every size YouTube has, given the video's address. Works with watch, youtu.be, Shorts, embed, live and mobile links.",
  how: `Paste the YouTube link (or just the 11-character video ID) and press Get Thumbnails. A large preview shows the biggest size that exists, sizes YouTube doesn't have for that video are left out, and a video ID that does not exist shows "Video not found or has no thumbnail". Press Download on one size, or Download all sizes (ZIP) for every size that exists in one file.`,
  tip: 'The largest size (1280×720) only exists for videos uploaded in HD, and the "Standard" size has black bars above and below on widescreen videos. For most uses the max resolution is the one to take; if it is unavailable, use High quality.',
};
function Ne() {
  const [o, i] = f.useState(""),
    [t, d] = f.useState(null),
    [c, l] = f.useState(""),
    [n, a] = f.useState({}),
    [u, S] = f.useState({}),
    [w, T] = f.useState(!1),
    { logUsageNow: $ } = Z(),
    Y = () => {
      const e = R(o);
      if ((a({}), S({}), !e)) {
        (d(null),
          l(
            "That doesn't look like a YouTube video link. Paste the address of a video (watch, youtu.be, Shorts or embed link).",
          ));
        return;
      }
      (l(""), d(e));
    },
    E = async (e) => {
      if (!t || !(await $())) return;
      const m = b(t, e);
      try {
        const r = await fetch(m);
        if (!r.ok) throw new Error(String(r.status));
        z(await r.blob(), P(t, e));
      } catch {
        (window.open(m, "_blank", "noopener,noreferrer"),
          j.info(
            "Your browser blocked the direct download, so the image opened in a new tab. Right-click it and choose Save image.",
          ));
      }
    },
    L = async () => {
      if (!(!t || w)) {
        T(!0);
        try {
          const { blob: e, included: m, failed: r } = await G(t, D(n));
          (z(e, M(t)),
            r.length > 0 &&
              j.info(
                `${r.length} size${r.length === 1 ? "" : "s"} couldn't be fetched and ${r.length === 1 ? "is" : "are"} not in the ZIP. ${m.length} included.`,
              ));
        } catch {
          j.error(
            "Your browser blocked bundling the images, so no ZIP was made. Use the Download button on each size instead.",
          );
        } finally {
          T(!1);
        }
      }
    },
    h = t ? V(n, u) : null,
    g = D(n),
    x = p.filter((e) => n[e.file]),
    k = W(n, u);
  return s.jsxs(_, {
    children: [
      s.jsxs("div", {
        className: "space-y-4",
        children: [
          s.jsxs("form", {
            className: "flex gap-3",
            onSubmit: (e) => {
              (e.preventDefault(), Y());
            },
            children: [
              s.jsxs("div", {
                className: "flex-1",
                children: [
                  s.jsx(C, { children: "YouTube URL" }),
                  s.jsx(q, {
                    "aria-label": "YouTube URL",
                    value: o,
                    onChange: (e) => i(e.target.value),
                    placeholder:
                      "https://youtube.com/watch?v=… or a Shorts / youtu.be link",
                  }),
                ],
              }),
              s.jsx(y, {
                className: "mt-6",
                type: "submit",
                children: "Get Thumbnails",
              }),
            ],
          }),
          c &&
            s.jsx("p", { className: "text-sm text-destructive", children: c }),
          t &&
            I(n) &&
            s.jsx(A, {
              className: "text-sm",
              testId: "yt-not-found",
              children:
                "Video not found or has no thumbnail. Check the link or video ID and try again.",
            }),
          t &&
            !I(n) &&
            s.jsxs("div", {
              className: "space-y-4",
              children: [
                h &&
                  h !== "loading" &&
                  s.jsxs("div", {
                    className: "space-y-1",
                    "data-testid": "yt-preview",
                    children: [
                      s.jsx("img", {
                        src: b(t, h.file),
                        alt: `${h.label} preview`,
                        className: "w-full max-w-2xl rounded-lg border",
                      }),
                      s.jsxs("p", {
                        className: "text-xs text-muted-foreground",
                        children: [
                          "Preview: ",
                          h.label,
                          ", ",
                          u[h.file].w,
                          "×",
                          u[h.file].h,
                        ],
                      }),
                    ],
                  }),
                h === "loading" &&
                  s.jsx("p", {
                    className: "text-sm text-muted-foreground",
                    role: "status",
                    children: "Loading preview…",
                  }),
                s.jsxs("div", {
                  className: "flex flex-wrap items-center gap-3",
                  children: [
                    s.jsxs(y, {
                      onClick: L,
                      disabled: !k || w || g.length === 0,
                      className: "gap-1.5",
                      children: [
                        s.jsx(O, { className: "h-4 w-4" }),
                        " ",
                        w
                          ? "Making ZIP…"
                          : k
                            ? `Download all sizes (ZIP, ${g.length} files)`
                            : "Checking sizes…",
                      ],
                    }),
                    x.length > 0 &&
                      s.jsxs("p", {
                        className: "text-xs text-muted-foreground",
                        "data-testid": "yt-hidden",
                        children: [
                          "YouTube doesn't have ",
                          x.map((e) => e.label).join(", "),
                          " for this video, so ",
                          x.length === 1 ? "it is" : "they are",
                          " left out.",
                        ],
                      }),
                  ],
                }),
                s.jsx("div", {
                  className:
                    "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4",
                  children: g.map((e) =>
                    s.jsxs(
                      "div",
                      {
                        className: "border rounded-lg overflow-hidden",
                        children: [
                          s.jsx("img", {
                            src: b(t, e.file),
                            alt: `${e.label} thumbnail`,
                            className: "w-full",
                            onLoad: (m) => {
                              const r = m.target;
                              H(r.naturalWidth, e.w)
                                ? a((v) => ({ ...v, [e.file]: !0 }))
                                : S((v) => ({
                                    ...v,
                                    [e.file]: {
                                      w: r.naturalWidth,
                                      h: r.naturalHeight,
                                    },
                                  }));
                            },
                            onError: () => a((m) => ({ ...m, [e.file]: !0 })),
                          }),
                          s.jsxs("div", {
                            className:
                              "p-2 flex items-center justify-between gap-2",
                            children: [
                              s.jsxs("span", {
                                className: "text-xs text-muted-foreground",
                                children: [e.label, " · ", e.w, "×", e.h],
                              }),
                              s.jsxs(y, {
                                size: "sm",
                                variant: "outline",
                                className: "gap-1.5",
                                onClick: () => E(e.file),
                                children: [
                                  s.jsx(B, { className: "h-3.5 w-3.5" }),
                                  " Download",
                                ],
                              }),
                            ],
                          }),
                        ],
                      },
                      e.file,
                    ),
                  ),
                }),
              ],
            }),
        ],
      }),
      s.jsx(F, { whatIsIt: N.what, howToUse: N.how, tip: N.tip }),
    ],
  });
}
export { Ne as default };
//# sourceMappingURL=YtThumbnail-BluoGDJ4.js.map
