// FDP-78 YouTube Thumbnail Downloader (Professional 10/day), guest. Usage: node px78-live.js <zero|left|parse> [engine]   env TRIES, SUF
// zero: context at the cap: Get Thumbnails, per-size Download, Download all sizes (ZIP); downloads saved to live/dl/.
// left: context with uses left: several Downloads + ZIP + another video in ONE load, POSTs per action; reload.
// parse: many link forms -> ID / message / sizes shown (Get Thumbnails is not gated).
// Never signs in, never types an email or card, never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/78-yt-thumbnail/'; const OUT = BASE + 'live/'; const TOOL = 'https://www.freedailypro.com/tool/yt-thumbnail';
const mode = process.argv[2] || 'zero'; const eng = process.argv[3] || 'chromium'; const sfx = (eng === 'chromium' ? '' : '-' + eng) + (process.env.SUF || '');
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
fs.mkdirSync(OUT + 'cases', { recursive: true }); fs.mkdirSync(OUT + 'dl', { recursive: true });
const HD = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', OLD = 'https://youtu.be/jNQXAC9IVRw', OWN = 'https://www.youtube.com/watch?v=lDBgQDbgHmY';
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p, net = [], dls = [], pops = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 1000 }, locale: 'en-US', acceptDownloads: true }); p = await c.newPage(); p.setDefaultTimeout(15000); net = []; dls = []; pops = [];
  p.on('request', r => { const u = r.url(); if (r.method() === 'POST' && /freedailypro\.com\/api/.test(u) && !/insight\.hit|funnel\.hit/.test(u)) net.push({ t: now(), u: u.slice(0, 70), len: (r.postData() || '').length }); });
  p.on('download', async d => { const n = d.suggestedFilename(); const f = OUT + 'dl/' + mode + sfx + '-' + n; await d.saveAs(f).catch(() => { }); let sz = 0; try { sz = fs.statSync(f).size; } catch (e) { } dls.push({ name: n, bytes: sz }); });
  c.on('page', pg => pops.push(pg.url()));
  await p.goto(TOOL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(250); } };
 const shot = (n, full) => p.screenshot({ path: OUT + 'cases/' + n + sfx + '.png', fullPage: !!full });
 const strip = () => p.evaluate(() => (document.querySelector('main').innerText.match(/Trial[^\n]*/) || [null])[0]);
 const read = () => p.evaluate(() => { const m = document.querySelector('main'); const err = m.querySelector('p.text-destructive')?.innerText || null; const nf = m.querySelector('[data-testid=yt-not-found]')?.innerText || null; const pv = m.querySelector('[data-testid=yt-preview] p')?.innerText || null; const hid = m.querySelector('[data-testid=yt-hidden]')?.innerText || null; const tiles = [...m.querySelectorAll('.border.rounded-lg.overflow-hidden span')].map(s => s.innerText); const zip = [...m.querySelectorAll('button')].map(x => x.innerText).find(t => /ZIP|Checking/.test(t)) || null; const toast = [...document.querySelectorAll('[data-sonner-toast]')].map(x => x.innerText).join(' / ').slice(0, 200); return { err, nf, pv, hid, tiles, zip, toast }; });
 const get = async url => { await p.getByLabel('YouTube URL').fill(url); await p.locator('main button', { hasText: 'Get Thumbnails' }).click(); await p.waitForTimeout(3500); };
 const act = async (label, fn) => { const np = net.length, nd = dls.length, npop = pops.length; const before = await used(); await fn(); await p.waitForTimeout(3500); const dg = await dialog(); const r = { before, after: await used(), posts: net.slice(np).length, downloads: dls.slice(nd), popups: pops.slice(npop), dialog: dg, ...(await read()) }; if (dg) { await shot('dlg-' + label); await esc(); } return r; };
 const dl = n => async () => { await p.locator('main .border.rounded-lg.overflow-hidden button', { hasText: 'Download' }).nth(n).click(); };
 const zip = async () => { await p.locator('main button', { hasText: /Download all sizes/ }).click(); await p.waitForTimeout(3000); };
 const C = async (id, fn) => { try { R.cases[id] = await fn(); } catch (e) { R.cases[id] = { err: e.message.split('\n')[0].slice(0, 200) }; await shot(id + '-err').catch(() => { }); } console.log(id, JSON.stringify(R.cases[id]).slice(0, 700)); };
 const find = async want => { const TRIES = +(process.env.TRIES || 10); for (let i = 0; i < TRIES; i++) { await open(); const u = await used(); R.tries.push(u); const [a, l] = u.split('/').map(Number); if (want === 'cap' ? a >= l : a < l) return true; await c.close(); } return false; };
 if (mode === 'zero' || mode === 'left') { R.found = await find(mode === 'zero' ? 'cap' : 'left'); if (!R.found) { fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('none', R.tries.join(',')); await b.close(); return; } R.start = { used: await used(), strip: await strip() }; await shot('X00-' + mode);
  await C('X01-get-hd', async () => { const r = await act('X01', () => get(HD)); await shot('X01-' + mode, true); return r; });
  await C('X02-download-max', () => act('X02', dl(0)));
  await C('X03-download-standard', () => act('X03', dl(1)));
  await C('X04-download-small', () => act('X04', dl(4)));
  await C('X05-zip', () => act('X05', zip));
  await C('X06-zip-again', () => act('X06', zip));
  await C('X07-get-old', async () => { const r = await act('X07', () => get(OLD)); await shot('X07-' + mode, true); return r; });
  await C('X08-download-old-hq', () => act('X08', dl(0)));
  await C('X09-zip-old', () => act('X09', zip));
  await C('X10-reload-get-download', async () => { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); await get(OWN); return act('X10', dl(2)); });
  await C('X11-zip-after-reload', () => act('X11', zip));
  R.end = await used(); R.net = net; R.allDownloads = dls; R.popups = pops;
 } else if (mode === 'resubmit') { await open(); R.start = { used: await used() };
  await C('S01-first-get', async () => { await get(HD); await p.waitForTimeout(4000); return read(); });
  await C('S02-same-link-again-10s', async () => { await get(HD); await p.waitForTimeout(10000); const r = await read(); r.zipDisabled = await p.locator('main button', { hasText: /ZIP|Checking/ }).isDisabled(); await shot('S02-same-again', true); return r; });
  await C('S03-other-form-same-id', async () => { await get('https://youtu.be/dQw4w9WgXcQ'); await p.waitForTimeout(8000); const r = await read(); r.zipDisabled = await p.locator('main button', { hasText: /ZIP|Checking/ }).isDisabled(); return r; });
  await C('S04-other-video-then-back', async () => { await get(OLD); await p.waitForTimeout(5000); await get(HD); await p.waitForTimeout(8000); const r = await read(); r.zipDisabled = await p.locator('main button', { hasText: /ZIP|Checking/ }).isDisabled(); return r; });
  R.end = await used(); R.net = net;
 } else if (mode === 'parse') { await open(); R.start = { used: await used() };
  const L = [['P01-watch', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'], ['P02-watch-t', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=42s&list=PL123'], ['P03-youtu.be-si', 'https://youtu.be/dQw4w9WgXcQ?si=abc123'], ['P04-shorts', 'https://www.youtube.com/shorts/dQw4w9WgXcQ?feature=share'], ['P05-embed', 'https://www.youtube.com/embed/dQw4w9WgXcQ'], ['P06-live', 'https://www.youtube.com/live/dQw4w9WgXcQ'], ['P07-mobile', 'https://m.youtube.com/watch?v=dQw4w9WgXcQ'], ['P08-music', 'https://music.youtube.com/watch?v=dQw4w9WgXcQ'], ['P09-nocookie', 'https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ'], ['P10-bare-id', 'dQw4w9WgXcQ'], ['P11-no-scheme', 'youtube.com/watch?v=dQw4w9WgXcQ'], ['P12-app-desktop', 'https://www.youtube.com/watch?app=desktop&v=dQw4w9WgXcQ'], ['P13-channel', 'https://www.youtube.com/@freedailypro'], ['P14-playlist', 'https://www.youtube.com/playlist?list=PLxyz'], ['P15-attribution', 'https://www.youtube.com/attribution_link?u=%2Fwatch%3Fv%3DdQw4w9WgXcQ'], ['P16-other-site', 'https://vimeo.com/123456789?v=dQw4w9WgXcQ'], ['P17-fake-id', 'aaaaaaaaaaa'], ['P18-old-video', 'https://youtu.be/jNQXAC9IVRw'], ['P19-uk-domain', 'https://www.youtube.co.uk/watch?v=dQw4w9WgXcQ'], ['P20-spaces', '   https://youtu.be/dQw4w9WgXcQ   '], ['P21-word', 'hello-world'], ['P22-v-short', 'https://www.youtube.com/watch?v=abc'], ['P23-gaming', 'https://gaming.youtube.com/watch?v=dQw4w9WgXcQ'], ['P24-yt-v-path', 'https://www.youtube.com/v/dQw4w9WgXcQ'], ['P25-html', '<script>alert(1)</script>']];
  for (const [id, u] of L) await C(id, async () => { const r = await act(id, () => get(u)); if (/P13|P17|P18|P21/.test(id)) await shot(id); return r; });
  R.end = await used(); R.net = net;
 }
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', JSON.stringify(R.tries), JSON.stringify(R.start || ''), R.end); await b.close(); })();
