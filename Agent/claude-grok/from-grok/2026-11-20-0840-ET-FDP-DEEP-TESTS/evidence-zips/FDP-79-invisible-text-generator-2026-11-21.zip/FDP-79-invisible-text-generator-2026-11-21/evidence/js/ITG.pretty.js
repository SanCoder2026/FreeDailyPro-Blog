import { r as n, j as t } from "./vendor-react-D01g8YgM.js";
import { e as y, I as C, B as u, T as S } from "./index-B1CTyGtY.js";
import { b as U, T as I } from "./ToolPage-DwLoDncN.js";
import { S as B } from "./slider-nIHsxb_2.js";
import { T as z } from "./ToolInfoSection-C0i6Zbwo.js";
import { c as A } from "./copyText-DPnES92p.js";
import { C as $ } from "./copy-DcUvE8ta.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
const r = 500;
function O(o, i) {
  const l = o.replace(/\D/g, "");
  if (!l) return { text: "", count: i, note: "empty" };
  const a = parseInt(l, 10);
  return a < 1
    ? { text: "1", count: 1, note: "min" }
    : a > r
      ? { text: String(r), count: r, note: "max" }
      : { text: String(a), count: a, note: "" };
}
function P(o, i) {
  return o === "min"
    ? "The minimum is 1, so 1 will be used."
    : o === "max"
      ? `The most you can generate is ${r}, so ${r} will be used.`
      : o === "empty"
        ? `Type a number from 1 to ${r}. Until then ${i} will be used.`
        : "";
}
const x = [
    {
      id: "braille",
      label: "Braille Blank",
      char: "⠀",
      code: "U+2800",
      note: "Recommended. Has real width, so most apps accept it as non-empty.",
    },
    {
      id: "hangul",
      label: "Hangul Filler",
      char: "ㅤ",
      code: "U+3164",
      note: "Wide blank; often accepted for usernames and game names.",
    },
    {
      id: "zwsp",
      label: "Zero-Width Space",
      char: "​",
      code: "U+200B",
      note: "Truly invisible, but many apps strip it.",
    },
    {
      id: "zwnj",
      label: "Zero-Width Non-Joiner",
      char: "‌",
      code: "U+200C",
      note: "Invisible; sometimes survives where U+200B is stripped.",
    },
    {
      id: "zwj",
      label: "Zero-Width Joiner",
      char: "‍",
      code: "U+200D",
      note: "Invisible; can affect emoji next to it.",
    },
    {
      id: "wordjoiner",
      label: "Word Joiner",
      char: "⁠",
      code: "U+2060",
      note: "Zero-width and no-break. Some apps accept it as text; others treat it like the other zero-width characters and strip it.",
    },
    {
      id: "invsep",
      label: "Invisible Separator",
      char: "⁣",
      code: "U+2063",
      note: "Zero-width punctuation used between items. It is rarely on a platform's strip list, but it is not accepted everywhere.",
    },
    {
      id: "emspace",
      label: "Em Space",
      char: " ",
      code: "U+2003",
      note: "A wide blank that is ordinary whitespace, so forms that trim spaces will remove it.",
    },
    {
      id: "linebreak",
      label: "Invisible Line Break",
      char: `⠀
`,
      code: "U+2800 + newline",
      note: "A blank-looking line (use in bios and multi-line fields).",
    },
  ],
  E = [1, 5, 10, 50],
  b = {
    what: `Generates invisible or blank-looking Unicode characters, commonly used to create a blank-looking username, bio, or message where normal empty text isn't allowed — a platform's "field can't be empty" validation is usually checking for zero characters, not checking whether those characters are visible, so a character that exists but renders as nothing satisfies the requirement.`,
    how: "Pick a character, set how many you want (type a number from 1 to 500, drag the slider, or press 1, 5, 10 or 50), copy it into the field that requires non-empty text, and check it in the Test box.",
    tip: "Platforms change which of these they accept, so there is no list that stays true: paste the result into the Test box here to confirm what you copied, then try it in the real field. Not every platform accepts every invisible character the same way — if one doesn't work, try a different variant, since some platforms filter specific Unicode ranges that are commonly used for exactly this purpose.",
  };
function he() {
  const [o, i] = n.useState([1]),
    [l, a] = n.useState("1"),
    [c, d] = n.useState(""),
    f = (e) => {
      (i([e]), a(String(e)), d(""));
    },
    w = (e) => {
      const h = O(e, o[0]);
      (a(h.text), i([h.count]), d(h.note));
    },
    [p, v] = n.useState("braille"),
    [g, j] = n.useState(""),
    m = x.find((e) => e.id === p) ?? x[0],
    k = m.char.repeat(o[0]),
    { logUsageNow: N } = U(),
    T = async () => {
      (await N("copy")) &&
        A(k, "Copied! Paste it anywhere you'd use normal text.");
    },
    s = Array.from(g).map(
      (e) =>
        "U+" + e.codePointAt(0).toString(16).toUpperCase().padStart(4, "0"),
    );
  return t.jsxs(I, {
    children: [
      t.jsxs("div", {
        className: "max-w-md mx-auto space-y-6",
        children: [
          t.jsx("div", {
            className:
              "p-6 rounded-xl border bg-card min-h-[80px] flex items-center justify-center",
            children: t.jsxs("span", {
              className: "text-xs text-muted-foreground",
              "data-testid": "inv-status",
              children: [o[0], " × ", m.label, " (", m.code, ") ready to copy"],
            }),
          }),
          t.jsxs("div", {
            children: [
              t.jsxs(y, {
                htmlFor: "inv-count",
                children: ["Number of characters (1 to ", r, ")"],
              }),
              t.jsx(C, {
                id: "inv-count",
                type: "text",
                inputMode: "numeric",
                value: l,
                onChange: (e) => w(e.target.value),
                onBlur: () => {
                  (a(String(o[0])), c === "empty" && d(""));
                },
                "aria-invalid": c !== "",
                className: "mb-3 mt-1",
              }),
              c &&
                t.jsx("p", {
                  role: "alert",
                  "data-testid": "inv-count-note",
                  className: "text-xs text-destructive mb-2",
                  children: P(c, o[0]),
                }),
              t.jsx("div", {
                className: "flex gap-2 mb-3",
                role: "group",
                "aria-label": "Quick lengths",
                children: E.map((e) =>
                  t.jsx(
                    u,
                    {
                      size: "sm",
                      variant: o[0] === e ? "default" : "outline",
                      "aria-pressed": o[0] === e,
                      onClick: () => f(e),
                      children: e,
                    },
                    e,
                  ),
                ),
              }),
              t.jsx(B, {
                "aria-label": "Number of characters slider",
                value: [Math.min(o[0], 20)],
                onValueChange: (e) => f(e[0]),
                min: 1,
                max: 20,
                step: 1,
              }),
            ],
          }),
          t.jsx("div", {
            className: "grid grid-cols-2 gap-2",
            role: "group",
            "aria-label": "Character type",
            children: x.map((e) =>
              t.jsx(
                u,
                {
                  size: "sm",
                  variant: p === e.id ? "default" : "outline",
                  onClick: () => v(e.id),
                  "aria-pressed": p === e.id,
                  children: e.label,
                },
                e.id,
              ),
            ),
          }),
          t.jsx("p", {
            className: "text-xs text-muted-foreground",
            children: m.note,
          }),
          t.jsxs(u, {
            onClick: T,
            className: "w-full gap-2",
            children: [
              t.jsx($, { className: "h-4 w-4" }),
              " Copy Invisible Text",
            ],
          }),
          t.jsxs("div", {
            children: [
              t.jsx(y, {
                className: "mb-1 block",
                children: "Test box: paste it here to check it works",
              }),
              t.jsx(S, {
                "aria-label": "Test box: paste it here to check it works",
                value: g,
                onChange: (e) => j(e.target.value),
                placeholder: "Paste here…",
                className: "min-h-[60px]",
              }),
              t.jsx("p", {
                className:
                  "text-xs text-muted-foreground mt-1 font-mono break-all",
                "data-testid": "inv-codes",
                children: s.length
                  ? `${s.length} character${s.length === 1 ? "" : "s"}: ${s.slice(0, 40).join(" ")}${s.length > 40 ? " …" : ""}`
                  : "Nothing pasted yet",
              }),
            ],
          }),
          t.jsx("p", {
            className: "text-xs text-muted-foreground text-center",
            children:
              "Please use blank text responsibly. Don't use it to impersonate others, evade moderation or mislead people. Some platforms remove these characters.",
          }),
        ],
      }),
      t.jsx(z, { whatIsIt: b.what, howToUse: b.how, tip: b.tip }),
    ],
  });
}
export { he as default };
//# sourceMappingURL=InvisibleTextGenerator-Cl_rBsOe.js.map
