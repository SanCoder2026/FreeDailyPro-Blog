// FDP-79 Invisible Text Generator, guest. Usage: node px79-live.js <zero|left|cases> [engine]   env TRIES, SUF
// zero: context at the cap: pick variants, counts, Copy Invisible Text (clipboard read back in Chromium); POSTs + dialogs.
// left: context with uses left: several copies in ONE load; POSTs per action; reload.
// cases: every variant x copy (code points checked), count-box edge inputs, slider, Test box.
// Never signs in, never types an email or card, never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/79-invisible-text-generator/'; const OUT = BASE + 'live/'; const TOOL = 'https://www.freedailypro.com/tool/invisible-text-generator';
const mode = process.argv[2] || 'zero'; const eng = process.argv[3] || 'chromium'; const sfx = (eng === 'chromium' ? '' : '-' + eng) + (process.env.SUF || '');
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const cps = s => s == null ? null : Array.from(s).map(e => 'U+' + e.codePointAt(0).toString(16).toUpperCase().padStart(4, '0'));
const sum = s => { if (s == null) return null; const a = cps(s); const u = [...new Set(a)]; return { len: a.length, uniq: u.join(','), head: a.slice(0, 4).join(' ') }; };
fs.mkdirSync(OUT + 'cases', { recursive: true });
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p, h, net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 1000 }, locale: 'en-US', timezoneId: 'America/New_York' }); if (eng === 'chromium') await c.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://www.freedailypro.com' }); p = await c.newPage(); p.setDefaultTimeout(12000); net = []; h = null;
  p.on('request', r => { const u = r.url(); if (r.method() === 'POST' && /freedailypro\.com\/api/.test(u) && !/insight\.hit|funnel\.hit/.test(u)) net.push({ t: now(), u: u.slice(0, 70), len: (r.postData() || '').length }); });
  await p.goto(TOOL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const helper = async () => { if (!h) { h = await c.newPage(); await h.goto('https://www.freedailypro.com/robots.txt'); } };
 const clipGet = async () => { if (eng !== 'chromium') return null; await helper(); await h.bringToFront(); const v = await h.evaluate(() => navigator.clipboard.readText()).catch(e => 'ERR ' + e.message.slice(0, 40)); await p.bringToFront(); return v; };
 const clipSet = async s => { if (eng !== 'chromium') return; await helper(); await h.bringToFront(); await h.evaluate(s => navigator.clipboard.writeText(s), s).catch(() => { }); await p.bringToFront(); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(250); } };
 const shot = (n, full) => p.screenshot({ path: OUT + 'cases/' + n + sfx + '.png', fullPage: !!full });
 const strip = () => p.evaluate(() => (document.querySelector('main').innerText.match(/Trial[^\n]*/) || [null])[0]);
 const read = () => p.evaluate(() => { const q = s => document.querySelector(s)?.innerText ?? null; const sl = document.querySelector('[role=slider]'); return { status: q('[data-testid=inv-status]'), note: q('[data-testid=inv-count-note]'), box: document.querySelector('#inv-count')?.value ?? null, slider: sl ? sl.getAttribute('aria-valuenow') : null, codes: q('[data-testid=inv-codes]'), toast: [...document.querySelectorAll('[data-sonner-toast],[role=status]')].map(e => e.innerText).join(' / ').slice(0, 160) }; });
 const reset = async () => { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(3500); };
 const pick = async lbl => { await p.locator('main [aria-label="Character type"] button', { hasText: lbl }).first().click(); };
 const quick = async n => { await p.locator('main [aria-label="Quick lengths"] button', { hasText: new RegExp('^' + n + '$') }).click(); };
 const count = async s => { const i = p.locator('#inv-count'); await i.click(); await i.press('Control+A'); await i.press('Backspace'); if (s) await i.pressSequentially(s, { delay: 30 }); await p.waitForTimeout(300); };
 const copy = async () => { await clipSet('EMPTY'); await p.locator('main button', { hasText: 'Copy Invisible Text' }).click(); await p.waitForTimeout(900); const v = await clipGet(); return { clip: sum(v), clipRaw: v === 'EMPTY' ? 'EMPTY (not copied)' : undefined }; };
 const act = async (label, fn) => { const np = net.length; const before = await used(); const x = await fn(); await p.waitForTimeout(3500); const dg = await dialog(); const r = { before, after: await used(), posts: net.slice(np).length, dialog: dg, ...(await read()), ...(x || {}) }; if (dg) { await shot('dlg-' + label); await esc(); } return r; };
 const C = async (id, fn) => { try { R.cases[id] = await fn(); } catch (e) { R.cases[id] = { err: e.message.split('\n')[0].slice(0, 200) }; await shot(id + '-err').catch(() => { }); } console.log(id, JSON.stringify(R.cases[id]).slice(0, 500)); };
 const find = async want => { const TRIES = +(process.env.TRIES || 10); for (let i = 0; i < TRIES; i++) { await open(); const u = await used(); R.tries.push(u); const [a, l] = u.split('/').map(Number); if (want === 'cap' ? a >= l : a < l) return true; await c.close(); } return false; };
 if (mode === 'zero' || mode === 'left') { R.found = await find(mode === 'zero' ? 'cap' : 'left'); if (!R.found) { fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('none', R.tries.join(',')); await b.close(); return; } R.start = { used: await used(), strip: await strip() }; await shot('X00-' + mode, true);
  await C('X01-copy-default', () => act('X01', copy));
  await C('X02-copy-again', () => act('X02', copy));
  await C('X03-hangul-10', () => act('X03', async () => { await pick('Hangul Filler'); await quick(10); return copy(); }));
  await C('X04-zwsp-50', () => act('X04', async () => { await pick('Zero-Width Space'); await quick(50); return copy(); }));
  await C('X05-linebreak-500', () => act('X05', async () => { await pick('Invisible Line Break'); await count('500'); return copy(); }));
  await C('X06-reload-copy', async () => { await reset(); return act('X06', copy); });
  await C('X07-copy-after-reload', () => act('X07', copy));
  await shot('X07-' + mode, true); R.end = await used(); R.net = net;
 } else if (mode === 'cases') { await open(); R.start = { used: await used(), strip: await strip() };
  const V = [['V01', 'Braille Blank'], ['V02', 'Hangul Filler'], ['V03', 'Zero-Width Space'], ['V04', 'Zero-Width Non-Joiner'], ['V05', 'Zero-Width Joiner'], ['V06', 'Word Joiner'], ['V07', 'Invisible Separator'], ['V08', 'Em Space'], ['V09', 'Invisible Line Break']];
  for (const [id, l] of V) await C(id + '-' + l, async () => { await pick(l); await quick(5); const x = await copy(); return { ...(await read()), ...x }; });
  const N = [['N01-zero', '0'], ['N02-501', '501'], ['N03-empty', ''], ['N04-decimal', '2.5'], ['N05-negative', '-3'], ['N06-letters', 'abc'], ['N07-exp', '1e2'], ['N08-999999', '999999'], ['N09-leading0', '007'], ['N10-space', ' 4 '], ['N11-fullwidth', '１２'], ['N12-500', '500']];
  for (const [id, s] of N) await C(id, async () => { await reset(); await pick('Braille Blank'); await count(s); const r1 = await read(); const x = await copy(); await p.locator('main').click({ position: { x: 5, y: 5 } }).catch(() => { }); await p.locator('#inv-count').blur(); await p.waitForTimeout(200); return { typed: s, during: r1, ...x, afterBlur: await read() }; });
  await C('S01-slider-after-50', async () => { await reset(); await quick(50); const a = await read(); await p.locator('[role=slider]').focus(); await p.keyboard.press('ArrowLeft'); await p.waitForTimeout(300); return { at50: a, afterLeft: await read() }; });
  await C('S02-slider-end', async () => { await reset(); await p.locator('[role=slider]').focus(); await p.keyboard.press('End'); await p.waitForTimeout(300); return read(); });
  await C('T01-testbox-paste-copied', async () => { await reset(); await pick('Hangul Filler'); await quick(5); const x = await copy(); const v = await clipGet(); await p.getByRole('textbox', { name: /Test box/ }).focus(); await p.keyboard.press('Control+V'); await p.waitForTimeout(400); const r = await read(); await shot('T01-testbox', true); return { ...x, ...r, pastedOk: v && r.codes }; });
  await C('T02-testbox-mixed', async () => { await reset(); await p.getByRole('textbox', { name: /Test box/ }).fill('a\u200Bb 😀\u2800'); await p.waitForTimeout(300); return read(); });
  await C('T03-testbox-60', async () => { await reset(); await p.getByRole('textbox', { name: /Test box/ }).fill('\u2800'.repeat(60)); await p.waitForTimeout(300); return read(); });
  await C('K01-keyboard-tab-copy', async () => { await reset(); await p.locator('main button', { hasText: 'Copy Invisible Text' }).focus(); await clipSet('EMPTY'); await p.keyboard.press('Enter'); await p.waitForTimeout(900); return { clip: sum(await clipGet()), ...(await read()) }; });
  await shot('cases-final', true); R.end = await used(); R.net = net;
 }
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', JSON.stringify(R.tries), JSON.stringify(R.start || ''), R.end); await b.close(); })();
