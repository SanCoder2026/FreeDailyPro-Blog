// FDP-79: Copy when the browser refuses clipboard access (Chromium context without clipboard permission). Guest, read-only.
const pw = require('playwright');
(async () => { const b = await pw.chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage();
 await p.goto('https://www.freedailypro.com/tool/invisible-text-generator', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500);
 const btn = p.locator('main button', { hasText: 'Copy Invisible Text' }); await btn.scrollIntoViewIfNeeded(); await btn.click(); await p.waitForTimeout(700);
 const t = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText).join(' / '));
 const sel = await p.evaluate(() => { const m = document.querySelector('main'); const w = document.createTreeWalker(m, NodeFilter.SHOW_TEXT); let n, f = 0; while (n = w.nextNode()) if (/[\u2800\u3164\u200B-\u200D\u2060\u2063\u2003]/.test(n.data)) f++; return f; });
 await p.screenshot({ path: '/workspace/deep/79-invisible-text-generator/live/cases/noclip-toast.png' }); console.log(JSON.stringify({ toast: t, textNodesWithTheCharacter: sel })); await b.close(); })();
