// FDP-79: the Copy button moves when the count box (empty, with the "Type a number" note) loses focus; measure and check the copy. Guest, read-only.
const pw = require('playwright'); const fs = require('fs');
const O = '/workspace/deep/79-invisible-text-generator/live/'; const TOOL = 'https://www.freedailypro.com/tool/invisible-text-generator';
(async () => { const out = {};
 for (const [name, eng, dev] of [['chromium-desktop', 'chromium', null], ['firefox-desktop', 'firefox', null], ['pixel7-tap', 'chromium', 'Pixel 7'], ['iphone14-tap', 'webkit', 'iPhone 14 Pro Max']]) {
  const b = await pw[eng].launch(); const opt = dev ? { ...pw.devices[dev] } : { viewport: { width: 1366, height: 1000 } }; const c = await b.newContext(opt); const p = await c.newPage();
  await p.goto(TOOL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500);
  const btn = p.locator('main button', { hasText: 'Copy Invisible Text' }); const i = p.locator('#inv-count');
  const r = {};
  if (dev) await i.tap(); else await i.click(); await i.press('Control+A').catch(() => { }); await i.press('Backspace'); await i.press('Backspace'); await p.waitForTimeout(300);
  r.note = await p.locator('[data-testid=inv-count-note]').innerText().catch(() => null); r.boxBefore = await btn.boundingBox();
  await p.screenshot({ path: O + 'cases/shift-' + name + '-before.png' });
  if (dev) await btn.tap(); else await btn.click(); await p.waitForTimeout(1200);
  r.boxAfter = await btn.boundingBox(); r.toast = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast],[role=status]')].map(e => e.innerText).join(' / ')); r.noteAfter = await p.locator('[data-testid=inv-count-note]').count();
  await p.screenshot({ path: O + 'cases/shift-' + name + '-after.png' });
  r.secondTap = null; if (dev) await btn.tap(); else await btn.click(); await p.waitForTimeout(1000); r.toastSecond = await p.evaluate(() => [...document.querySelectorAll('[data-sonner-toast],[role=status]')].map(e => e.innerText).join(' / '));
  out[name] = r; console.log(name, JSON.stringify(r)); await b.close(); }
 fs.writeFileSync(O + 'shift.json', JSON.stringify(out, null, 1)); })();
