import { r as o, j as e } from "./vendor-react-D01g8YgM.js";
import { T as ue, F as me, R as pe, D as he } from "./ToolPage-DwLoDncN.js";
import { B as u, e as fe, f as D } from "./index-B1CTyGtY.js";
import { S as xe } from "./slider-nIHsxb_2.js";
import { T as ge } from "./ToolInfoSection-C0i6Zbwo.js";
import { u as ve } from "./UsageAndUpgradeStrip-B1CY210m.js";
import {
  checkFileSize as je,
  resetFFmpegEngine as G,
  loadFFmpeg as be,
  fetchFile as we,
  ffmpegOutputToBlob as Ne,
} from "./ffmpegEngine-DH91Xnxx.js";
import {
  f as Se,
  N as Re,
  U as ke,
  p as H,
  s as Y,
  r as ye,
  t as Fe,
} from "./operations-DLxdtd8A.js";
import { T as Ce } from "./TimeRangeFields-kSkKSW90.js";
import { v as Ae } from "./containers-CEblVBL8.js";
import { u as Te, F as $e, A as Ee, s as Oe } from "./uiHelpers-DY6mT0h-.js";
import { f as L, a as j } from "./timeFormat-Va_Xba1f.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./sniffRate-BQP3kobv.js";
import "./progress-Y72GQ7li.js";
import "./square-DmBnvOHU.js";
const M = {
  what: "Cuts an audio clip down to a specific start and end point (Keep selection), or deletes a section from the middle and joins the two ends (Remove selection), such as a cough or an ad read. A video file works too: its sound is trimmed and saved as audio. Runs in your browser: the audio never leaves your device, but the first use downloads a processing engine from a public CDN.",
  how: "Upload your audio file (or a video), listen to the preview to find your spot, then drag either end of the range slider to set the start and end points (shown in minutes:seconds, or typed exactly). Choose Keep selection to cut away everything outside the range, or Remove selection to delete the range and keep the rest. You can also add fades, use the 30-second Ringtone button, and watch the waveform. The output keeps the format of the file you uploaded. Listen to the result, then download it.",
  tip: "This re-encodes the audio to trim precisely at the exact time you specify, unlike a fast video-style copy trim — which means it takes a little real processing time, but the cut point is exact rather than snapped to the nearest keyframe.",
};
function vt() {
  const { intermediate: P } = Te(),
    [c, h] = o.useState(null),
    [Z, q] = o.useState(""),
    [r, b] = o.useState(0),
    [a, f] = o.useState([0, 10]),
    [n, J] = o.useState("keep"),
    [Q, z] = o.useState(!0),
    [w, k] = o.useState(!1),
    [N, U] = o.useState(!1),
    [X, y] = o.useState(0),
    [ee, S] = o.useState(""),
    [R, d] = o.useState(null),
    { isPro: I, isLoading: te, isAdmin: se } = ve(),
    x = o.useRef(null),
    _ = o.useRef(null),
    g = o.useRef(null),
    [F, oe] = o.useState(0),
    [C, ae] = o.useState(0),
    [p, B] = o.useState(null),
    [re, A] = o.useState(!1),
    K = o.useRef(null),
    ie = o.useCallback((t) => {
      const s = t[0];
      if (!s) return;
      (A(!1),
        k(!1),
        z(!0),
        h(s),
        q(URL.createObjectURL(s)),
        d(null),
        b(0),
        f([0, 10]),
        B(null));
      const l =
        s.type.startsWith("video/") ||
        /\.(mp4|m4v|mov|webm|mkv)$/i.test(s.name);
      (l &&
        Ae(s).then((i) => {
          i === !1 && k(!0);
        }),
        (!l || s.size < 60 * 1024 * 1024) && Se(s).then(B));
    }, []);
  o.useEffect(() => {
    const t = K.current;
    if (!t || !p || !r) return;
    const s = t.getContext("2d"),
      l = t.width,
      i = t.height;
    s.clearRect(0, 0, l, i);
    const v = (a[0] / r) * l,
      m = (a[1] / r) * l;
    p.forEach(($, E) => {
      const O = (E / p.length) * l,
        V = O >= v && O <= m;
      s.fillStyle =
        n === "keep"
          ? V
            ? "#6366f1"
            : "rgba(128,128,128,0.45)"
          : V
            ? "rgba(220,60,60,0.7)"
            : "#6366f1";
      const W = Math.max(1, $ * i);
      s.fillRect(O, (i - W) / 2, Math.max(1, l / p.length - 0.5), W);
    });
  }, [p, a, r, n]);
  const ne = () => {
      const t = g.current?.duration;
      t && Number.isFinite(t) && (b(t), f([0, t]));
    },
    le = () => {
      g.current && ((g.current.currentTime = a[0]), g.current.play());
    },
    T = c ? je([c], I || te, se) : null,
    ce = () => {
      (_.current?.abort(), x.current && G(x.current));
    },
    de = async () => {
      if (!c) return;
      const [t, s] = a;
      if (s <= t) {
        D.error("End time must be after start time");
        return;
      }
      if (n === "remove") {
        const i = H(r, t, s);
        if (i.error) {
          D.error(i.error);
          return;
        }
      }
      (U(!0), y(0));
      const l = new AbortController();
      _.current = l;
      try {
        S("Loading audio engine...");
        const i = await be((E) => S(E));
        ((x.current = i), S("Reading audio file..."));
        const v = c.name.match(/\.([^.]+)$/)?.[1] || "mp3";
        await i.writeFile(`input.${v}`, await we(c));
        const m = Y(c, P);
        S(n === "remove" ? "Removing the section..." : "Trimming...");
        const $ =
          n === "remove"
            ? (
                await ye(
                  i,
                  `input.${v}`,
                  `output.${m.value}`,
                  r,
                  t,
                  s,
                  y,
                  l.signal,
                  { codec: m.codec, fadeIn: F, fadeOut: C },
                )
              ).data
            : await Fe(
                i,
                `input.${v}`,
                `output.${m.value}`,
                t,
                s,
                y,
                l.signal,
                { codec: m.codec, fadeIn: F, fadeOut: C },
              );
        (d(Ne($, m.mime)),
          D.success(n === "remove" ? "Section removed!" : "Audio trimmed!"));
      } catch (i) {
        Oe(i);
      } finally {
        (x.current && G(x.current), U(!1));
      }
    };
  return e.jsxs(ue, {
    children: [
      c
        ? e.jsxs("div", {
            className: "space-y-4",
            children: [
              e.jsx("div", {
                className: "p-4 rounded-lg border bg-card",
                children: e.jsx("p", {
                  className: "text-sm font-medium",
                  children: c.name,
                }),
              }),
              T && e.jsx($e, { check: T, isPro: I }),
              e.jsx("audio", {
                ref: g,
                src: Z,
                controls: !0,
                onLoadedMetadata: ne,
                onError: () => {
                  A(!0);
                },
                className: "w-full",
              }),
              w &&
                e.jsxs("div", {
                  role: "alert",
                  "data-testid": "no-audio-track",
                  className:
                    "p-3 rounded-lg border border-destructive/50 text-sm text-destructive flex items-center justify-between gap-3",
                  children: [
                    e.jsxs("span", {
                      children: [
                        Re,
                        " There is nothing to trim. Nothing was used from your trial.",
                      ],
                    }),
                    e.jsx(u, {
                      size: "sm",
                      variant: "outline",
                      onClick: () => {
                        (h(null), k(!1), b(0));
                      },
                      children: "Choose another",
                    }),
                  ],
                }),
              re &&
                !w &&
                e.jsxs("div", {
                  role: "alert",
                  className:
                    "p-3 rounded-lg border border-destructive/50 text-sm text-destructive flex items-center justify-between gap-3",
                  children: [
                    e.jsx("span", { children: ke }),
                    e.jsx(u, {
                      size: "sm",
                      variant: "outline",
                      onClick: () => {
                        (h(null), A(!1), b(0));
                      },
                      children: "Choose another",
                    }),
                  ],
                }),
              r > 0 &&
                !w &&
                e.jsxs("div", {
                  className: "space-y-2",
                  children: [
                    e.jsxs("div", {
                      className:
                        "flex flex-wrap items-center justify-between gap-2",
                      children: [
                        e.jsxs("div", {
                          className: "flex items-center gap-3",
                          role: "radiogroup",
                          "aria-label": "What to do with the selection",
                          children: [
                            e.jsx(fe, {
                              className: "text-xs",
                              children: "Selection",
                            }),
                            [
                              ["keep", "Keep selection"],
                              ["remove", "Remove selection"],
                            ].map(([t, s]) =>
                              e.jsx(
                                u,
                                {
                                  size: "sm",
                                  variant: n === t ? "default" : "outline",
                                  className: "h-7 text-xs",
                                  role: "radio",
                                  "aria-checked": n === t,
                                  onClick: () => {
                                    (J(t), d(null));
                                  },
                                  children: s,
                                },
                                t,
                              ),
                            ),
                          ],
                        }),
                        e.jsxs("div", {
                          className: "flex gap-1",
                          children: [
                            n === "keep" &&
                              e.jsx(u, {
                                variant: "ghost",
                                size: "sm",
                                className: "h-6 text-xs",
                                onClick: () => {
                                  const t = Math.min(r, a[0] + 30);
                                  (f([a[0], t]), d(null));
                                },
                                children: "Ringtone (30 s)",
                              }),
                            e.jsx(u, {
                              variant: "ghost",
                              size: "sm",
                              className: "h-6 text-xs",
                              onClick: le,
                              children: "Preview from start",
                            }),
                          ],
                        }),
                      ],
                    }),
                    p &&
                      e.jsx("canvas", {
                        ref: K,
                        width: 600,
                        height: 64,
                        className: "w-full h-16 rounded border bg-card",
                        "aria-label":
                          "Waveform of the file; the selected part is highlighted",
                        "data-testid": "waveform",
                      }),
                    e.jsx(xe, {
                      "aria-label": "Trim range",
                      value: a,
                      onValueChange: (t) => {
                        const s = [t[0], t[1]];
                        (f(s), d(null));
                      },
                      min: 0,
                      max: r,
                      step: 0.1,
                      minStepsBetweenThumbs: 1,
                    }),
                    e.jsx(Ce, {
                      range: a,
                      duration: r,
                      onChange: (t) => {
                        (f(t), d(null));
                      },
                      onValidChange: z,
                    }),
                    e.jsxs("div", {
                      className:
                        "flex justify-between text-xs text-muted-foreground font-mono",
                      children: [
                        e.jsx("span", { children: L(a[0]) }),
                        e.jsxs("span", { children: ["Total: ", L(r)] }),
                        e.jsx("span", { children: L(a[1]) }),
                      ],
                    }),
                    e.jsxs("div", {
                      className: "flex flex-wrap items-center gap-4 text-xs",
                      children: [
                        e.jsxs("label", {
                          className: "flex items-center gap-1.5",
                          children: [
                            "Fade in ",
                            e.jsx("select", {
                              className:
                                "border rounded px-1 py-0.5 bg-background",
                              value: F,
                              onChange: (t) => {
                                (oe(Number(t.target.value)), d(null));
                              },
                              children: [0, 0.5, 1, 2, 3, 5].map((t) =>
                                e.jsx(
                                  "option",
                                  { value: t, children: t ? `${t} s` : "none" },
                                  t,
                                ),
                              ),
                            }),
                          ],
                        }),
                        e.jsxs("label", {
                          className: "flex items-center gap-1.5",
                          children: [
                            "Fade out ",
                            e.jsx("select", {
                              className:
                                "border rounded px-1 py-0.5 bg-background",
                              value: C,
                              onChange: (t) => {
                                (ae(Number(t.target.value)), d(null));
                              },
                              children: [0, 0.5, 1, 2, 3, 5].map((t) =>
                                e.jsx(
                                  "option",
                                  { value: t, children: t ? `${t} s` : "none" },
                                  t,
                                ),
                              ),
                            }),
                          ],
                        }),
                      ],
                    }),
                    e.jsx("p", {
                      className: "text-xs text-muted-foreground text-center",
                      "data-testid": "trim-summary",
                      children:
                        n === "keep"
                          ? `Keeping ${j(a[1] - a[0])} of ${j(r)}`
                          : (() => {
                              const t = H(r, a[0], a[1]);
                              return t.error
                                ? t.error
                                : `Removing ${j(Math.min(r, a[1]) - a[0])} of ${j(r)}, leaving ${j(t.outSeconds)}`;
                            })(),
                    }),
                  ],
                }),
              N && e.jsx(Ee, { progress: X, statusMessage: ee, onStop: ce }),
              R &&
                e.jsxs("div", {
                  className: "space-y-1",
                  children: [
                    e.jsx("p", {
                      className: "text-sm font-medium",
                      children: "Listen to the result",
                    }),
                    e.jsx(pe, { blob: R }),
                  ],
                }),
              e.jsx("div", {
                className: "flex gap-3",
                children: R
                  ? e.jsxs(e.Fragment, {
                      children: [
                        e.jsx(he, {
                          blob: R,
                          fileName: `${n === "remove" ? "cut" : "trimmed"}_${c.name.replace(/\.[^.]+$/, `.${Y(c, P).value}`)}`,
                        }),
                        e.jsx(u, {
                          variant: "outline",
                          onClick: () => {
                            (h(null), d(null));
                          },
                          children: "New",
                        }),
                      ],
                    })
                  : e.jsxs(e.Fragment, {
                      children: [
                        e.jsx(u, {
                          onClick: de,
                          disabled:
                            N || T?.severity !== "ok" || r === 0 || !Q || w,
                          children: N
                            ? n === "remove"
                              ? "Removing..."
                              : "Trimming..."
                            : n === "remove"
                              ? "Remove Section"
                              : "Trim Audio",
                        }),
                        e.jsx(u, {
                          variant: "outline",
                          onClick: () => h(null),
                          disabled: N,
                          children: "Reset",
                        }),
                      ],
                    }),
              }),
            ],
          })
        : e.jsx(me, {
            gateAtDownload: !0,
            accept: "audio/*,video/*",
            maxSize: 500,
            onFiles: ie,
            label: "Drop an audio file to trim",
            description:
              "Keep a range or cut a section out. A video works too: its sound is trimmed.",
          }),
      e.jsx(ge, { whatIsIt: M.what, howToUse: M.how, tip: M.tip }),
    ],
  });
}
export { vt as default };
//# sourceMappingURL=AudioTrimmer-DBXW8itP.js.map
