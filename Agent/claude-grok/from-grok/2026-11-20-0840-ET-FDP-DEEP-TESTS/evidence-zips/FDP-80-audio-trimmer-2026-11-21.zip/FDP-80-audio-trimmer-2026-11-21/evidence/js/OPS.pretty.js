import {
  execWithProgress as p,
  probeMedia as ie,
} from "./ffmpegEngine-DH91Xnxx.js";
import { a as ce, b as le, f as ue } from "./timeFormat-Va_Xba1f.js";
const Ue =
    "Couldn't read this audio file. It may be damaged or not audio. Nothing was used from your trial.",
  me = "This video has no audio track.";
function de(e, t) {
  const a = e[0]?.length ?? 0;
  if (!a || t < 1) return [];
  const n = new Array(t).fill(0),
    o = a / t;
  for (const s of e)
    for (let r = 0; r < t; r++) {
      const i = Math.floor(r * o),
        l = Math.min(a, Math.floor((r + 1) * o));
      let c = 0;
      for (let u = i; u < l; u += Math.max(1, Math.floor((l - i) / 64))) {
        const m = Math.abs(s[u]);
        m > c && (c = m);
      }
      c > n[r] && (n[r] = c);
    }
  return n;
}
async function De(e, t = 600) {
  try {
    const a = new AudioContext();
    try {
      const n = await a.decodeAudioData(await e.arrayBuffer()),
        o = Array.from({ length: n.numberOfChannels }, (s, r) =>
          n.getChannelData(r),
        );
      return de(o, t);
    } finally {
      a.close();
    }
  } catch {
    return null;
  }
}
function j(e, t, a) {
  const n = Math.min(Math.max(0, e), a / 2),
    o = Math.min(Math.max(0, t), a / 2),
    s = [];
  return (
    n > 0 && s.push(`afade=t=in:st=0:d=${n}`),
    o > 0 && s.push(`afade=t=out:st=${Math.max(0, a - o).toFixed(3)}:d=${o}`),
    s.join(",")
  );
}
const v = [
    {
      value: "mp3",
      label: "MP3",
      codec: ["-c:a", "libmp3lame", "-q:a", "2"],
      mime: "audio/mpeg",
    },
    {
      value: "wav",
      label: "WAV",
      codec: ["-c:a", "pcm_s16le"],
      mime: "audio/wav",
    },
    {
      value: "ogg",
      label: "OGG",
      codec: ["-c:a", "libvorbis", "-q:a", "5"],
      mime: "audio/ogg",
    },
    {
      value: "m4a",
      label: "M4A",
      codec: ["-c:a", "aac", "-b:a", "192k"],
      mime: "audio/mp4",
    },
    {
      value: "flac",
      label: "FLAC",
      codec: ["-c:a", "flac"],
      mime: "audio/flac",
    },
  ],
  U = {
    high: "High (largest file)",
    standard: "Standard",
    small: "Small (smaller file)",
  };
function E(e, t) {
  const a = v.find((n) => n.value === e).codec;
  return e === "mp3"
    ? [
        "-c:a",
        "libmp3lame",
        "-q:a",
        { high: "2", standard: "4", small: "6" }[t],
      ]
    : e === "ogg"
      ? [
          "-c:a",
          "libvorbis",
          "-q:a",
          { high: "5", standard: "3", small: "1" }[t],
        ]
      : e === "m4a"
        ? [
            "-c:a",
            "aac",
            "-b:a",
            { high: "192k", standard: "128k", small: "96k" }[t],
          ]
        : a;
}
function pe(e) {
  return new Promise((t) => {
    const a = document.createElement("audio"),
      n = URL.createObjectURL(e),
      o = (s) => {
        (URL.revokeObjectURL(n), t(s));
      };
    ((a.preload = "metadata"),
      (a.onloadedmetadata = () =>
        o(Number.isFinite(a.duration) && a.duration > 0 ? a.duration : null)),
      (a.onerror = () => o(null)),
      setTimeout(() => o(null), 8e3),
      (a.src = n));
  });
}
const D = /\.(mp4|m4v|mov|webm|mkv|avi|wmv|flv|3gp|mpg|mpeg|ogv|ts|mts|m2ts)$/i,
  g = (e) => D.test(e),
  R = [32, 48, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320];
function z(e) {
  let t = R[0];
  for (const a of R) a <= e + 1 && (t = a);
  return t;
}
function M(e, t) {
  return /\.(wav|wave|flac|aiff?)$/i.test(e.name) || g(e.name) || !t
    ? 192
    : z((e.size * 8) / t / 1e3);
}
function fe(e, t) {
  const a = /\.(wav|wave|flac|aiff?)$/i.test(e.name),
    n = M(e, t);
  return g(e.name)
    ? `Same as original (video sound, ${n} kbps)`
    : a
      ? `Same as original (lossless source, ${n} kbps)`
      : t
        ? `Same as original (${n} kbps)`
        : `Same as original (${n} kbps, length unknown)`;
}
function T(e, t) {
  const a = `${t}k`;
  return e === "mp3"
    ? ["-c:a", "libmp3lame", "-b:a", a]
    : e === "ogg"
      ? ["-c:a", "libvorbis", "-b:a", a]
      : e === "m4a"
        ? ["-c:a", "aac", "-b:a", a]
        : v.find((n) => n.value === e).codec;
}
function G(e) {
  const t = (e.match(/\.([^.]+)$/)?.[1] ?? "").toLowerCase(),
    a =
      t === "wav" || t === "wave"
        ? "wav"
        : t === "flac"
          ? "flac"
          : ["m4a", "aac", "mp4"].includes(t)
            ? "m4a"
            : ["ogg", "oga", "opus"].includes(t)
              ? "ogg"
              : "mp3";
  return v.find((n) => n.value === a);
}
const V = 25 * 1024 * 1024;
function Y(e, t) {
  const a = G(e.name);
  return !t || a.value === "wav" || a.value === "flac"
    ? a
    : v.find((n) => n.value === (e.size > V ? "flac" : "wav"));
}
function he(e, t, a, n) {
  if (!t && a === "audiobook")
    return {
      format: v.find((r) => r.value === "mp3"),
      codec: [
        "-ar",
        "44100",
        "-c:a",
        "libmp3lame",
        "-b:a",
        "192k",
        "-write_xing",
        "0",
      ],
      note: "Saved as a 192 kbps constant-bit-rate MP3 at 44.1 kHz, the format ACX accepts.",
    };
  const o = Y(e, t);
  if (!t && ["mp3", "m4a", "ogg"].includes(o.value)) {
    const s = M(e, n);
    return {
      format: o,
      codec: T(o.value, s),
      note: n ? `Saved at ${s} kbps, matched to the original.` : "",
    };
  }
  return { format: o, codec: o.codec, note: "" };
}
const q = ["mp3", "ogg", "m4a"];
function X(e, t, a, n) {
  const o = q.includes(t);
  if (a === "match")
    return { codec: T(t, M(e, n)), kbps: o ? M(e, n) : null, lossy: o };
  const s = E(t, a),
    r = Number((s.find((i) => /k$/.test(i)) ?? "0k").replace("k", "")) || null;
  return { codec: s, kbps: o ? r : null, lossy: o };
}
function be(e, t, a, n, o, s) {
  const r = v.find((c) => c.value === a),
    l = q.includes(a)
      ? ` (${n === "match" ? `${M(e, o)} kbps${g(e.name) ? " (the video's sound track was re-encoded at 192 kbps)" : /\.(wav|wave|flac|aiff?)$/i.test(e.name) ? " (the source is lossless, so 192 kbps was used)" : ", matched to the original"}` : `${U[n].split(" ")[0].toLowerCase()} quality`})`
      : "";
  return `${e.name.replace(/^.*\./, "").toUpperCase()} ${s(e.size)} → ${r.label} ${s(t)}${l}.`;
}
function ve(e, t) {
  return new RegExp(`\\.${t}$`, "i").test(e)
    ? e.replace(/\.[^.]+$/, `-converted.${t}`)
    : e.replace(/\.[^.]+$/, `.${t}`);
}
const y = ["-map", "0:a:0", "-vn", "-map_metadata", "0"];
async function H(e, t, a, n, o, s, r) {
  const i = ["-map", "0:a:0", "-vn", "-map_metadata", "0"];
  if (/\.(mp3|m4a|flac)$/i.test(a) && !g(t))
    try {
      return (
        await p(
          e,
          [
            "-i",
            t,
            "-map",
            "0:a:0",
            "-map",
            "0:v:0?",
            "-c:v",
            "copy",
            "-disposition:v",
            "attached_pic",
            "-map_metadata",
            "0",
            ...n,
            a,
          ],
          o,
          s,
          r,
        ),
        e.readFile(a)
      );
    } catch (c) {
      if (s?.aborted) throw c;
    }
  return (await p(e, ["-i", t, ...i, ...n, a], o, s, r), e.readFile(a));
}
async function $e(e, t, a, n, o, s, r, i) {
  const l = t.name.match(/\.([^.]+)$/)?.[1] || "mp3";
  return (
    await e.writeFile(`input.${l}`, a),
    H(e, `input.${l}`, `output.${n}`, X(t, n, o, s).codec, r, i, s ?? void 0)
  );
}
function we(e) {
  const t = e.trim();
  if (!t) return null;
  if (t.includes(":")) {
    const [n, o] = t.split(":"),
      s = parseFloat(n),
      r = parseFloat(o);
    return Number.isNaN(s) || Number.isNaN(r) ? null : s * 60 + r;
  }
  const a = parseFloat(t);
  return Number.isNaN(a) ? null : a;
}
async function ke(e, t, a, n, o, s, r, i = {}) {
  const { codec: l = [], fadeIn: c = 0, fadeOut: u = 0, preFilter: m = "" } = i,
    d = [m, j(c, u, o - n)].filter(Boolean).join(","),
    h = ["-ss", String(n)],
    $ = ["-t", String(Math.round((o - n) * 1e3) / 1e3)];
  if (/\.(mp3|m4a|flac)$/i.test(a))
    try {
      return (
        await p(
          e,
          [
            ...h,
            "-i",
            t,
            ...$,
            "-map",
            "0:a:0",
            "-map",
            "0:v:0?",
            "-c:v",
            "copy",
            "-disposition:v",
            "attached_pic",
            "-map_metadata",
            "0",
            ...(d ? ["-af", d] : []),
            ...l,
            a,
          ],
          s,
          r,
        ),
        e.readFile(a)
      );
    } catch (A) {
      if (r?.aborted) throw A;
    }
  return (
    await p(
      e,
      [
        ...h,
        "-i",
        t,
        ...$,
        "-map",
        "0:a:0",
        "-vn",
        "-map_metadata",
        "0",
        ...(d ? ["-af", d] : []),
        ...l,
        a,
      ],
      s,
      r,
    ),
    e.readFile(a)
  );
}
const K = 0.008;
function W(e, t, a) {
  const n = Math.max(0, t),
    o = Math.min(e, a);
  if (!(e > 0))
    return {
      keep: [],
      outSeconds: 0,
      error: "The length of this audio is not known yet.",
    };
  if (o <= n)
    return {
      keep: [],
      outSeconds: 0,
      error: "The end of the section must be after its start.",
    };
  const s = [];
  (n > 0.005 && s.push([0, n]), o < e - 0.005 && s.push([o, e]));
  const r = s.reduce((i, [l, c]) => i + (c - l), 0);
  return r < 0.05
    ? {
        keep: [],
        outSeconds: 0,
        error:
          "That would remove everything, so nothing would be left. Choose a smaller section.",
      }
    : { keep: s, outSeconds: r };
}
function J(e, t, a = "") {
  const n = e.map(([s, r], i) => {
      const l = r - s,
        c = Math.min(K, l / 2),
        u = [
          i > 0 ? `afade=t=in:st=0:d=${c}` : "",
          i < e.length - 1
            ? `afade=t=out:st=${Math.max(0, l - c).toFixed(4)}:d=${c}`
            : "",
        ].filter(Boolean);
      return `[0:a:0]${[r >= t - 0.005 ? `atrim=start=${s}` : `atrim=start=${s}:end=${r}`, "asetpts=PTS-STARTPTS", ...u].join(",")}[k${i}]`;
    }),
    o =
      e.length > 1
        ? `${e.map((s, r) => `[k${r}]`).join("")}concat=n=${e.length}:v=0:a=1${a ? "," + a : ""}[out]`
        : `[k0]${a || "anull"}[out]`;
  return `${n.join(";")};${o}`;
}
async function Ae(e, t, a, n, o, s, r, i, l = {}) {
  const { codec: c = [], fadeIn: u = 0, fadeOut: m = 0 } = l,
    d = W(n, o, s);
  if (d.error) throw new Error(d.error);
  const h = J(d.keep, n, j(u, m, d.outSeconds));
  if (/\.(mp3|m4a|flac)$/i.test(a))
    try {
      return (
        await p(
          e,
          [
            "-i",
            t,
            "-filter_complex",
            h,
            "-map",
            "[out]",
            "-map",
            "0:v:0?",
            "-c:v",
            "copy",
            "-disposition:v",
            "attached_pic",
            "-map_metadata",
            "0",
            ...c,
            a,
          ],
          r,
          i,
        ),
        { data: await e.readFile(a), outSeconds: d.outSeconds }
      );
    } catch ($) {
      if (i?.aborted) throw $;
    }
  return (
    await p(
      e,
      [
        "-i",
        t,
        "-filter_complex",
        h,
        "-map",
        "[out]",
        "-map_metadata",
        "0",
        ...c,
        a,
      ],
      r,
      i,
    ),
    { data: await e.readFile(a), outSeconds: d.outSeconds }
  );
}
const Me = [
  { value: "mp3", label: "MP3 (variable quality, smaller for speech)" },
  { value: "mp3-128", label: "MP3 128 kbps" },
  { value: "mp3-192", label: "MP3 192 kbps" },
  { value: "wav", label: "WAV (uncompressed)" },
  { value: "m4a", label: "M4A (AAC)" },
  { value: "ogg", label: "OGG" },
  { value: "flac", label: "FLAC" },
  { value: "original", label: "Original audio (no re-encode, instant)" },
];
class Q extends Error {
  constructor() {
    (super(me), (this.name = "NoAudioTrackError"));
  }
}
const Z = {
  mp3: "audio/mpeg",
  wav: "audio/wav",
  m4a: "audio/mp4",
  ogg: "audio/ogg",
  opus: "audio/ogg",
  flac: "audio/flac",
};
function P(e, t) {
  const a = /^mp3-(\d+)$/.exec(e);
  if (e === "original") {
    const o = {
      aac: "m4a",
      mp3: "mp3",
      opus: "opus",
      vorbis: "ogg",
      flac: "flac",
    }[t];
    return o
      ? { ext: o, codec: ["-c:a", "copy"], fellBack: !1 }
      : { ext: "mp3", codec: v[0].codec, fellBack: !0 };
  }
  return a
    ? {
        ext: "mp3",
        codec: ["-c:a", "libmp3lame", "-b:a", `${a[1]}k`],
        fellBack: !1,
      }
    : { ext: e, codec: E(e, "high"), fellBack: !1 };
}
async function _e(e, t, a, n, o, s) {
  await e.writeFile("input", t);
  const r = await ie(e, "input");
  if (!r.hasAudio) throw new Q();
  const { ext: i, codec: l, fellBack: c } = P(a, r.acodec),
    u = n ? ["-ss", String(n[0])] : [],
    m = n ? ["-t", String(Math.round((n[1] - n[0]) * 1e3) / 1e3)] : [];
  return (
    await p(
      e,
      [...u, "-i", "input", ...m, "-vn", "-map", "0:a:0", ...l, `output.${i}`],
      o,
      s,
    ),
    {
      data: await e.readFile(`output.${i}`),
      ext: i,
      mime: Z[i] || "audio/mpeg",
      fellBack: c,
    }
  );
}
const ge = 5;
function L(e, t) {
  const a = [];
  for (let n = 0; n + 1 < e.length; n++) {
    const o = Math.min(
      ...[e[n], e[n + 1]].map((s) => (s && s > 0 ? s / 2 : 1 / 0)),
    );
    a.push(Math.max(0, Math.round(Math.min(t, o) * 1e3) / 1e3));
  }
  return a;
}
function ye(e, t, a) {
  if (e.length === 0 || e.some((o) => !o)) return null;
  const n = e.reduce((o, s) => o + s, 0);
  return a > 0
    ? n - L(e, a).reduce((o, s) => o + s, 0)
    : n + t * (e.length - 1);
}
function ee(e, t = {}) {
  const { gapSeconds: a = 0, crossfades: n = [], sampleRate: o = null } = t,
    s = Array.from(
      { length: e },
      (c, u) => `[${u}:a]${o ? `aresample=${o}` : "anull"}[s${u}]`,
    );
  if (n.some((c) => c > 0)) {
    const c = [];
    let u = "[s0]";
    for (let m = 1; m < e; m++) {
      const d = m === e - 1 ? "[outa]" : `[x${m}]`;
      (c.push(`${u}[s${m}]acrossfade=d=${n[m - 1] ?? 0}:c1=qsin:c2=qsin${d}`),
        (u = d));
    }
    return [...s, ...c].join(";");
  }
  const i = Array.from({ length: e }, (c, u) =>
      a > 0 && u < e - 1 ? `[s${u}]apad=pad_dur=${a}[p${u}]` : null,
    ),
    l = Array.from({ length: e }, (c, u) =>
      i[u] ? `[p${u}]` : `[s${u}]`,
    ).join("");
  return [...s, ...i.filter(Boolean), `${l}concat=n=${e}:v=0:a=1[outa]`].join(
    ";",
  );
}
function ae(e) {
  const t = e % 100;
  return `${e}${t >= 11 && t <= 13 ? "th" : (["th", "st", "nd", "rd"][e % 10] ?? "th")}`;
}
const I = (e) => `${+(e / 1e3).toFixed(2)}`;
function Fe(e) {
  return e.find((t) => !!t) ?? null;
}
function Se(e, t) {
  return t
    ? e
        .flatMap((n, o) =>
          n && n !== t
            ? [`${ae(o + 1)} clip resampled ${I(n)} → ${I(t)} kHz`]
            : [],
        )
        .join("; ")
    : "";
}
function xe(e, t) {
  return `merged-${e}-${e === 1 ? "clip" : "clips"}.${t}`;
}
async function Ne(
  e,
  t,
  a,
  n,
  o,
  s = 0,
  r = { ext: "mp3", codec: ["-c:a", "libmp3lame", "-q:a", "2"] },
  i = {},
) {
  const l = [];
  for (let m = 0; m < t.length; m++) {
    const d = (
      t[m].name.match(/\.([A-Za-z0-9]+)$/)?.[1] ?? "mp3"
    ).toLowerCase();
    (await e.writeFile(`in${m}.${d}`, await a(t[m])),
      l.push("-i", `in${m}.${d}`));
  }
  const c =
      (i.crossfadeSeconds ?? 0) > 0
        ? L(i.durations ?? t.map(() => null), i.crossfadeSeconds)
        : [],
    u = ee(t.length, {
      gapSeconds: s,
      crossfades: c,
      sampleRate: i.sampleRate,
    });
  return (
    await p(
      e,
      [
        ...l,
        "-filter_complex",
        u,
        "-map",
        "[outa]",
        ...r.codec,
        `output.${r.ext}`,
      ],
      n,
      o,
      r.durationSec,
    ),
    e.readFile(`output.${r.ext}`)
  );
}
const te = 32;
function Ee(e, t, a) {
  const o = (e * t * 8) / a / 1e3;
  return Math.max(te, Math.round(o));
}
async function Te(e, t, a, n, o, s, r = !1) {
  return (
    await p(
      e,
      [
        "-i",
        t,
        "-map",
        "0:a:0",
        "-vn",
        "-map_metadata",
        "0",
        ...(r ? ["-ac", "1"] : []),
        "-c:a",
        "libmp3lame",
        "-b:a",
        `${n}k`,
        a,
      ],
      o,
      s,
    ),
    e.readFile(a)
  );
}
const Le = [
  {
    id: "podcast",
    label: "Podcast (-16 LUFS)",
    hint: "-16 LUFS, a common podcast level",
    lufs: -16,
    peak: -1.5,
  },
  {
    id: "spotify",
    label: "Spotify / streaming (-14 LUFS)",
    hint: "-14 LUFS, the level Spotify normalises to",
    lufs: -14,
    peak: -1,
  },
  {
    id: "youtube",
    label: "YouTube (common streaming reference)",
    hint: "-14 LUFS, a common streaming reference (YouTube publishes no official target)",
    lufs: -14,
    peak: -1,
  },
  {
    id: "broadcast",
    label: "Broadcast (EBU R128)",
    hint: "-23 LUFS",
    lufs: -23,
    peak: -1,
  },
  {
    id: "audiobook",
    label: "Audiobook (ACX)",
    hint: "about -20 dB RMS (LUFS used as a proxy), peak -3 dB. Saved as a 192 kbps CBR MP3",
    lufs: -20,
    peak: -3,
  },
  {
    id: "peak",
    label: "Peak to -1 dB",
    hint: "just louder, no compression",
    lufs: null,
    peak: -1,
  },
];
async function x(e, t, a) {
  const n = [],
    o = ({ message: s }) => {
      n.push(s);
    };
  e.on("log", o);
  try {
    const s = await e.exec(t, void 0, a ? { signal: a } : void 0);
    if (a?.aborted) throw new Error("Processing stopped");
    if (s !== 0) throw new Error(`Processing failed (exit code ${s}).`);
  } finally {
    e.off("log", o);
  }
  return n;
}
function ne(e) {
  const a = e
    .join(
      `
`,
    )
    .match(/\{[^{}]*"input_i"[^{}]*\}/);
  if (!a) return null;
  try {
    const n = JSON.parse(a[0]),
      o = (s) => Number.isFinite(Number(s)) && Math.abs(Number(s)) < 1e3;
    return o(n.input_i) &&
      o(n.input_tp) &&
      o(n.input_lra) &&
      o(n.input_thresh) &&
      o(n.target_offset)
      ? n
      : null;
  } catch {
    return null;
  }
}
function N(e) {
  const t = e
    .join(
      `
`,
    )
    .match(/max_volume:\s*(-?[\d.]+) dB/);
  return t ? Number(t[1]) : null;
}
function oe(e, t, a) {
  const n = `volume=${e.toFixed(3)}dB`;
  if (!a) return n;
  const o = Math.min(1, Math.max(0.0625, Math.pow(10, t / 20)));
  return `${n},alimiter=limit=${o.toFixed(4)}:attack=5:release=50:level=0`;
}
async function Oe(e, t, a, n, o, s, r = [], i = !1) {
  const c = r.some((f) => /mp3lame|aac|vorbis/.test(f)) ? 0.3 : 0.05,
    u = async (f) => {
      await p(
        e,
        [
          "-i",
          t,
          ...y,
          "-af",
          oe(f, n.peak - c, i && n.lufs !== null),
          ...r,
          a,
        ],
        o,
        s,
      );
    };
  if (n.lufs === null) {
    const f = await x(
        e,
        ["-i", t, "-af", "volumedetect", "-f", "null", "-"],
        s,
      ),
      S = N(f);
    if (S === null)
      throw new Error(
        "Processing failed: could not measure the level of this file.",
      );
    const C = n.peak - c - S;
    await u(C);
    const re = N(
      await x(e, ["-i", a, "-af", "volumedetect", "-f", "null", "-"], s),
    );
    return {
      data: await e.readFile(a),
      inputLufs: null,
      outputLufs: null,
      gainDb: C,
      limited: !1,
      inputPeak: S,
      outputPeak: re,
    };
  }
  const m = async (f) =>
      ne(
        await x(
          e,
          [
            "-i",
            f,
            "-af",
            "loudnorm=I=-23:TP=-1:LRA=11:print_format=json",
            "-f",
            "null",
            "-",
          ],
          s,
        ),
      ),
    d = await m(t);
  if (!d)
    throw new Error(
      "Processing failed: could not measure the loudness of this file.",
    );
  const h = Number(d.input_i),
    $ = Number(d.input_tp),
    A = n.peak - c - $;
  let w = n.lufs - h;
  const F = i;
  let _ = !F && w > A;
  (_ && (w = A), await u(w));
  let k = await m(a),
    b = k ? Number(k.input_i) : null;
  if (b !== null && !_ && Math.abs(b - n.lufs) > 0.25) {
    let f = w + (n.lufs - b);
    (!F && f > A && ((f = A), (_ = !0)),
      (w = f),
      await u(w),
      (k = await m(a)),
      (b = k ? Number(k.input_i) : b));
  }
  return (
    F && b !== null && b < n.lufs - 0.5 && (_ = !0),
    {
      data: await e.readFile(a),
      inputLufs: h,
      outputLufs: b,
      gainDb: w,
      limited: _,
      inputPeak: $,
      outputPeak: k ? Number(k.input_tp) : null,
    }
  );
}
function O(e) {
  const t = [];
  let a = e;
  for (; a > 2;) (t.push(2), (a /= 2));
  for (; a < 0.5;) (t.push(0.5), (a /= 0.5));
  return (
    t.push(Math.round(a * 1e4) / 1e4),
    t.map((n) => `atempo=${n}`).join(",")
  );
}
function se(e, t, a) {
  const n = Math.abs(e - 1) > 1e-6 ? O(e) : "";
  return t ? [B(t, a), n].filter(Boolean).join(",") : n || "anull";
}
async function Be(e, t, a, n, o, s, r = [], i) {
  const l = i && i.semitones ? se(n, i.semitones, i.sampleRate) : O(n);
  return (
    await p(e, ["-i", t, ...y, "-filter:a", l, ...r, a], o, s),
    e.readFile(a)
  );
}
function B(e, t) {
  const a = Math.pow(2, e / 12),
    n = Math.round(t * a),
    o = 1 / a;
  return `aresample=${t},asetrate=${n},atempo=${o},aresample=${t}`;
}
async function Ce(e, t, a, n, o, s, r = [], i = 0) {
  return (
    await p(
      e,
      [
        "-i",
        t,
        ...y,
        "-af",
        B(n, 44100),
        ...(i > 0 ? ["-t", String(i)] : []),
        ...r,
        a,
      ],
      o,
      s,
    ),
    e.readFile(a)
  );
}
async function Re(e, t, a, n, o, s, r, i = [], l) {
  let c = `afftdn=nr=${n}:nf=${o}`;
  return (
    l &&
      (await e.writeFile("voice.rnnn", l),
      (c = "aresample=48000,arnndn=m=voice.rnnn:mix=1")),
    await p(e, ["-i", t, ...y, "-af", c, ...i, a], s, r),
    e.readFile(a)
  );
}
const ze = Object.freeze(
  Object.defineProperty(
    {
      __proto__: null,
      AUDIO_FORMAT_OPTIONS: v,
      AUDIO_QUALITY_LABELS: U,
      EXTRACT_FORMATS: Me,
      EXTRACT_MIME: Z,
      INTERMEDIATE_WAV_MAX_BYTES: V,
      JOIN_FADE_SECONDS: K,
      MAX_JOIN_SECONDS: ge,
      MIN_BITRATE_KBPS: te,
      NORMALIZE_TARGETS: Le,
      NoAudioTrackError: Q,
      VIDEO_NAME: D,
      atempoFilter: O,
      buildMergeFilter: ee,
      calculateTargetBitrateKbps: Ee,
      changeAudioSpeed: Be,
      codecForQuality: E,
      compressAudioToBitrate: Te,
      convertAudioFormat: H,
      convertAudioWithPlan: $e,
      convertPlan: X,
      convertedName: ve,
      crossfadeDurations: L,
      describeConversion: be,
      expectedMergeSeconds: ye,
      extractAudioFromVideo: _e,
      extractCodec: P,
      formatDuration: ce,
      formatMinSec: le,
      formatMinSecTenth: ue,
      isVideoName: g,
      keepRangesFilter: J,
      matchBitrate: M,
      matchCodec: T,
      matchQualityLabel: fe,
      mergeAudioFiles: Ne,
      mergeSampleRate: Fe,
      mergedFileName: xe,
      normalizeAudioLoudness: Oe,
      normalizeFilter: oe,
      normalizeOutput: he,
      ordinal: ae,
      parseLoudnorm: ne,
      parseMaxVolume: N,
      parseMinSec: we,
      pitchShiftFilters: B,
      planRemoval: W,
      probeDuration: pe,
      removeAudioNoise: Re,
      removeAudioSegment: Ae,
      resampleNote: Se,
      sameFormat: G,
      shiftAudioPitch: Ce,
      speedPitchFilter: se,
      stepAtOrBelow: z,
      stepOutputFormat: Y,
      trimAudioSegment: ke,
    },
    Symbol.toStringTag,
    { value: "Module" },
  ),
);
export {
  v as A,
  H as B,
  Be as C,
  Le as D,
  Me as E,
  he as F,
  Oe as G,
  Re as H,
  Ce as I,
  we as J,
  ze as K,
  te as M,
  me as N,
  Ue as U,
  Q as a,
  pe as b,
  X as c,
  U as d,
  _e as e,
  De as f,
  ve as g,
  $e as h,
  g as i,
  be as j,
  Fe as k,
  Se as l,
  fe as m,
  G as n,
  ye as o,
  W as p,
  L as q,
  Ae as r,
  Y as s,
  ke as t,
  xe as u,
  T as v,
  M as w,
  Ne as x,
  Ee as y,
  Te as z,
};
//# sourceMappingURL=operations-DLxdtd8A.js.map
