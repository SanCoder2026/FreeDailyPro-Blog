#!/usr/bin/env python3
"""FDP-80: decode each output with ffmpeg to 44.1 kHz mono and report duration (ffprobe), beep onsets and their pitch
(1 kHz = whole-second beep, 2 kHz = the 10.0 s marker), plus codec/container and tags. Usage: analyze.py file..."""
import sys, subprocess, json, numpy as np
SR = 44100
def info(f):
    j = json.loads(subprocess.run(['ffprobe', '-v', 'error', '-show_format', '-show_streams', '-of', 'json', f], capture_output=True, text=True).stdout or '{}')
    st = [(s.get('codec_type'), s.get('codec_name')) for s in j.get('streams', [])]
    fm = j.get('format', {}); return {'container': fm.get('format_name'), 'dur': round(float(fm.get('duration', 0) or 0), 3), 'streams': st, 'tags': {k: v for k, v in (fm.get('tags') or {}).items() if k.lower() in ('title', 'artist')}}
def beeps(f):
    raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', f, '-map', '0:a:0', '-ac', '1', '-ar', str(SR), '-f', 'f32le', '-'], capture_output=True).stdout
    x = np.frombuffer(raw, dtype='<f4'); on = []; i = 0; thr = 0.15
    while i < len(x):
        if abs(x[i]) > thr:
            seg = x[i:i + int(0.015 * SR)]; zc = np.sum(np.diff(np.signbit(seg).astype(int)) != 0); hz = zc / 2 / (len(seg) / SR)
            on.append((round(i / SR, 3), 2000 if hz > 1500 else 1000, round(float(np.max(np.abs(seg))), 2))); i += int(0.3 * SR)
        else: i += 1
    return {'samples_dur': round(len(x) / SR, 3), 'onsets': on}
out = {}
for f in sys.argv[1:]:
    try: out[f.split('/')[-1]] = {**info(f), **beeps(f)}
    except Exception as e: out[f.split('/')[-1]] = {'err': str(e)}
print(json.dumps(out, indent=1))
