#!/usr/bin/env python3
"""FDP-80 test files. A 20.0 s mono 44.1 kHz WAV: silence with a 20 ms 1 kHz beep at every whole second
(0,1,...,19) and a 2 kHz marker beep at 10.0 s, so a trimmed file shows exactly where it was cut.
From it: MP3, FLAC, M4A, OGG, Opus; an MP4 video with this audio; an MP4 with no audio; a 0.5 s WAV; a corrupt .mp3;
a 'song.mp3' with an ID3 title and cover; a 6 min WAV and a 12 min (63 MB) WAV. Needs numpy + ffmpeg."""
import numpy as np, wave, subprocess, os, sys
D = sys.argv[1] if len(sys.argv) > 1 else 'testfiles'; os.makedirs(D, exist_ok=True); SR = 44100
def beeps(sec):
    t = np.arange(int(sec * SR)) / SR; x = np.zeros_like(t)
    for s in range(int(sec)):
        f = 2000 if s == 10 else 1000; m = (t >= s) & (t < s + 0.02); x[m] = 0.6 * np.sin(2 * np.pi * f * (t[m] - s))
    return x
def wav(path, x):
    with wave.open(path, 'wb') as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((x * 32767).astype('<i2').tobytes())
ff = lambda *a: subprocess.run(['ffmpeg', '-loglevel', 'error', '-y', *a], check=True)
wav(f'{D}/beeps20.wav', beeps(20)); wav(f'{D}/short0.5.wav', beeps(0.5) + 0.0); wav(f'{D}/long6min.wav', beeps(360)); wav(f'{D}/big12min.wav', beeps(720))
src = f'{D}/beeps20.wav'
ff('-i', src, '-c:a', 'libmp3lame', '-q:a', '2', f'{D}/beeps20.mp3')
ff('-i', src, '-c:a', 'flac', f'{D}/beeps20.flac')
ff('-i', src, '-c:a', 'aac', '-b:a', '192k', f'{D}/beeps20.m4a')
ff('-i', src, '-c:a', 'libvorbis', '-q:a', '5', f'{D}/beeps20.ogg')
ff('-i', src, '-c:a', 'libopus', f'{D}/beeps20.opus')
ff('-f', 'lavfi', '-i', 'testsrc=size=320x240:rate=25', '-i', src, '-t', '20', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-shortest', f'{D}/video20.mp4')
ff('-f', 'lavfi', '-i', 'testsrc=size=320x240:rate=25', '-t', '5', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-an', f'{D}/video-noaudio.mp4')
ff('-f', 'lavfi', '-i', 'testsrc=size=300x300:rate=1', '-frames:v', '1', f'{D}/cover.png')
ff('-i', src, '-i', f'{D}/cover.png', '-map', '0', '-map', '1', '-c:a', 'libmp3lame', '-q:a', '2', '-c:v', 'png', '-disposition:v', 'attached_pic', '-metadata', 'title=FDP Beeps', '-metadata', 'artist=QA', f'{D}/song-tags.mp3')
open(f'{D}/corrupt.mp3', 'wb').write(b'ID3' + os.urandom(20000))
print(sorted(os.listdir(D)))
