import { a as D } from "./timeFormat-Va_Xba1f.js";
const $ = 0.02,
  A = 0.15,
  C = 0.015,
  v = 0.008;
function k(t, o, s, M, m = 0) {
  const i = t[0]?.length ?? 0,
    n = Math.max(1, Math.round(o * $)),
    h = Math.ceil(i / n),
    d = new Array(h),
    f = Math.pow(10, s / 20);
  for (let e = 0; e < h; e++) {
    const r = e * n,
      a = Math.min(i, r + n);
    let w = 0;
    for (const p of t) {
      let E = 0;
      for (let c = r; c < a; c++) E += p[c] * p[c];
      const g = Math.sqrt(E / Math.max(1, a - r));
      g > w && (w = g);
    }
    d[e] = w < f;
  }
  const l = Math.max(1, Math.round(M / $)),
    u = Math.round(o * (m > 0 ? A : C)),
    U = [];
  let S = 0;
  for (; S < h;) {
    if (!d[S]) {
      S++;
      continue;
    }
    let e = S;
    for (; e < h && d[e];) e++;
    if (e - S >= l) {
      const r = S * n,
        a = Math.min(i, e * n),
        w = r === 0 ? 0 : r + u,
        p = a >= i ? i : a - u,
        E = Math.max(0, Math.round(o * m) - 2 * u),
        g = r === 0 ? w : w + Math.floor(E / 2),
        c = a >= i ? p : p - Math.ceil(E / 2);
      U.push({
        start: r,
        end: a,
        startSeconds: r / o,
        endSeconds: a / o,
        durationSeconds: (a - r) / o,
        cut: c - g > 0 ? [g, c] : null,
      });
    }
    S = e;
  }
  return U;
}
function y(t, o, s, M, m = 0, i = new Set()) {
  const n = t[0]?.length ?? 0,
    h = k(t, o, s, M, m).flatMap((e) =>
      e.cut && !i.has(e.start) ? [e.cut] : [],
    ),
    d = [];
  let f = 0;
  for (const [e, r] of h) (e > f && d.push([f, e]), (f = r));
  f < n && d.push([f, n]);
  const l = d.reduce((e, [r, a]) => e + (a - r), 0),
    u = Math.round(o * v),
    U = t.map(() => new Float32Array(l));
  let S = 0;
  return (
    d.forEach(([e, r], a) => {
      const w = r - e;
      (t.forEach((p, E) => {
        U[E].set(p.subarray(e, r), S);
        const g = Math.min(u, Math.floor(w / 2));
        if (a > 0) for (let c = 0; c < g; c++) U[E][S + c] *= c / g;
        if (a < d.length - 1)
          for (let c = 0; c < g; c++) U[E][S + w - 1 - c] *= c / g;
      }),
        (S += w));
    }),
    {
      channels: U,
      keptSeconds: l / o,
      removedSeconds: (n - l) / o,
      pausesRemoved: h.length,
    }
  );
}
function O(t) {
  const o = (M) => (M === 1 ? "pause" : "pauses"),
    s =
      t.keepPauseSeconds > 0
        ? `${t.cut} ${o(t.cut)} shortened to ${t.keepPauseSeconds} s`
        : `${t.cut} ${o(t.cut)} removed`;
  return `${D(t.beforeSeconds)} → ${D(t.afterSeconds)}, ${s}${t.kept > 0 ? `, ${t.kept} kept` : ""}`;
}
function W(t, o, s) {
  return s && s !== o ? [...t, "-ar", String(s)] : t;
}
function N(t, o, s, M) {
  const m = t.reduce(
    (i, n) => i + (n.cut && !o.has(n.start) ? n.cut[1] - n.cut[0] : 0),
    0,
  );
  return (s - m) / M;
}
function P(t, o) {
  const s = t.length,
    M = t[0]?.length ?? 0,
    m = M * s * 2,
    i = new ArrayBuffer(44 + m),
    n = new DataView(i),
    h = (f, l) => {
      for (let u = 0; u < l.length; u++) n.setUint8(f + u, l.charCodeAt(u));
    };
  (h(0, "RIFF"),
    n.setUint32(4, 36 + m, !0),
    h(8, "WAVE"),
    h(12, "fmt "),
    n.setUint32(16, 16, !0),
    n.setUint16(20, 1, !0),
    n.setUint16(22, s, !0),
    n.setUint32(24, o, !0),
    n.setUint32(28, o * s * 2, !0),
    n.setUint16(32, s * 2, !0),
    n.setUint16(34, 16, !0),
    h(36, "data"),
    n.setUint32(40, m, !0));
  let d = 44;
  for (let f = 0; f < M; f++)
    for (let l = 0; l < s; l++) {
      const u = Math.max(-1, Math.min(1, t[l][f]));
      (n.setInt16(d, u < 0 ? u * 32768 : u * 32767, !0), (d += 2));
    }
  return new Uint8Array(i);
}
export { W as a, O as b, k as d, P as e, N as p, y as r };
//# sourceMappingURL=silence-CD6mHmXq.js.map
