import { r as n, j as e } from "./vendor-react-D01g8YgM.js";
import { T as fe, F as ge, R as q, D as ve } from "./ToolPage-DwLoDncN.js";
import { B as d, e as F, f as C } from "./index-B1CTyGtY.js";
import { S as V } from "./slider-nIHsxb_2.js";
import { T as je } from "./ToolInfoSection-C0i6Zbwo.js";
import { u as be } from "./UsageAndUpgradeStrip-B1CY210m.js";
import {
  checkFileSize as we,
  resetFFmpegEngine as W,
  loadFFmpeg as Se,
  ffmpegOutputToBlob as ke,
} from "./ffmpegEngine-DH91Xnxx.js";
import { m as Ne } from "./noise-DlTLMK2Q.js";
import { U as ye, s as G, B as Re } from "./operations-DLxdtd8A.js";
import {
  d as Fe,
  p as Ce,
  r as H,
  e as Z,
  a as Pe,
  b as Te,
} from "./silence-CD6mHmXq.js";
import { d as Ae } from "./audioFile-CL1ltBQd.js";
import { u as Be, F as De, A as ze, s as Me } from "./uiHelpers-DY6mT0h-.js";
import { f as J, a as Q } from "./timeFormat-Va_Xba1f.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
import "./containers-CEblVBL8.js";
import "./sniffRate-BQP3kobv.js";
import "./progress-Y72GQ7li.js";
import "./square-DmBnvOHU.js";
const P = {
  what: "Automatically detects and trims quiet or silent sections from an audio file — useful for cleaning up a voice recording with long dead air, or tightening up a podcast with awkward pauses. Runs entirely in your browser — the audio never leaves your device.",
  how: "Upload your audio file and adjust the silence threshold and minimum duration if needed. Every pause that would be cut is listed with its time range: un-tick any you want to keep (a dramatic pause, a beat before a punchline). Preview the result right on the page, then Remove Silence and download.",
  tip: `This trims silence throughout the file, not just at the start and end — it looks for any stretch quieter than the threshold and at least as long as the minimum duration, and removes it. If it's cutting out parts that shouldn't be silent, try lowering the threshold (a more negative dB value is stricter about what counts as "silent").`,
};
function St() {
  const { inPipeline: X, intermediate: T } = Be(),
    [i, A] = n.useState(null),
    [j, b] = n.useState([-35]),
    [w, B] = n.useState([0.5]),
    [D, Y] = n.useState(X ? 0.5 : 0),
    [g, z] = n.useState(!1),
    [ee, M] = n.useState(0),
    [te, v] = n.useState(""),
    [u, c] = n.useState(null),
    [s, S] = n.useState(null),
    [se, k] = n.useState(!1),
    [h, p] = n.useState(new Set()),
    [$, m] = n.useState(null),
    { isPro: E, isLoading: ae, isAdmin: ne } = be(),
    x = n.useRef(null),
    O = n.useRef(null),
    oe = n.useCallback((t) => {
      const a = t[0];
      a && (A(a), c(null), S(null), k(!1), p(new Set()), m(null));
    }, []);
  n.useEffect(() => {
    if (!i) return;
    let t = !0;
    return (
      Ae(i, { maxChannels: 2, matchFileRate: !0 }).then(
        (a) => {
          t && S(a);
        },
        () => {
          t && k(!0);
        },
      ),
      () => {
        t = !1;
      }
    );
  }, [i]);
  const o = n.useDeferredValue({ t: j[0], m: w[0], k: D }),
    r = n.useMemo(
      () => (s ? Fe(s.channels, s.sampleRate, o.t, o.m, o.k) : []),
      [s, o.t, o.m, o.k],
    );
  n.useEffect(() => {
    (p(new Set()), m(null));
  }, [o.t, o.m, o.k]);
  const L = s?.channels[0]?.length ?? 0,
    f = r.filter((t) => t.cut),
    I = f.filter((t) => !h.has(t.start)),
    ie = s ? Ce(r, h, L, s.sampleRate) : 0,
    le = (t) => {
      (p((a) => {
        const l = new Set(a);
        return (l.has(t) ? l.delete(t) : l.add(t), l);
      }),
        c(null),
        m(null));
    },
    U = (t) => {
      (p(t ? new Set() : new Set(f.map((a) => a.start))), c(null), m(null));
    },
    _ = s ? L * s.channels.length * 2 > 150 * 1024 * 1024 : !1,
    N = i ? we([i], E || ae, ne) : null,
    re = () => {
      (O.current?.abort(), x.current && W(x.current));
    },
    ce = () => {
      if (!s) return;
      const t = Ne(s.channels.slice(0, 2), s.sampleRate),
        a = Math.max(-60, Math.min(-15, Math.round((t + 10) / 5) * 5));
      (b([a]),
        c(null),
        C.success(
          `Background noise is about ${Math.round(t)} dB, so the threshold is set to ${a} dB.`,
        ));
    },
    ue = () => {
      if (!s) return;
      const t = H(s.channels, s.sampleRate, o.t, o.m, o.k, h);
      m(new Blob([Z(t.channels, s.sampleRate)], { type: "audio/wav" }));
    },
    de = async () => {
      if (!i || !s) return;
      (z(!0), M(0));
      const t = new AbortController();
      O.current = t;
      try {
        v("Loading audio engine...");
        const a = await Se((xe) => v(xe));
        ((x.current = a), v("Removing silence..."));
        const l = H(s.channels, s.sampleRate, o.t, o.m, o.k, h);
        if (l.keptSeconds < 0.1) {
          C.info(
            "The whole file is quieter than the threshold. Try a lower (more negative) threshold.",
          );
          return;
        }
        (v("Saving..."),
          await a.writeFile("cut.wav", Z(l.channels, s.sampleRate)));
        const R = G(i, T),
          me = s.fileRate ?? s.sampleRate,
          he = await Re(
            a,
            "cut.wav",
            `output.${R.value}`,
            Pe(R.codec, s.sampleRate, s.fileRate),
            M,
            t.signal,
          ),
          pe = `${Te({ beforeSeconds: s.duration, afterSeconds: l.keptSeconds, cut: l.pausesRemoved, kept: f.length - l.pausesRemoved, keepPauseSeconds: o.k })}. Saved at ${+(me / 1e3).toFixed(2)} kHz${s.fileRate ? ", the same as your file" : ""}.`,
          K = ke(he, R.mime);
        (c({ blob: K, size: K.size, summary: pe }),
          C.success("Silence removed!"));
      } catch (a) {
        Me(a);
      } finally {
        (x.current && W(x.current), z(!1));
      }
    },
    y = () => {
      (A(null),
        c(null),
        S(null),
        k(!1),
        b([-35]),
        B([0.5]),
        p(new Set()),
        m(null));
    };
  return e.jsxs(fe, {
    children: [
      i
        ? e.jsxs("div", {
            className: "space-y-4",
            children: [
              e.jsxs("div", {
                className: "p-4 rounded-lg border bg-card flex justify-between",
                children: [
                  e.jsxs("div", {
                    children: [
                      e.jsx("p", {
                        className: "text-sm font-medium",
                        children: i.name,
                      }),
                      e.jsxs("p", {
                        className: "text-xs text-muted-foreground",
                        children: [
                          "Original: ",
                          (i.size / 1024 / 1024).toFixed(1),
                          " MB",
                        ],
                      }),
                    ],
                  }),
                  u &&
                    e.jsxs("p", {
                      className: "text-sm font-medium text-green-600",
                      children: [(u.size / 1024 / 1024).toFixed(1), " MB"],
                    }),
                ],
              }),
              N && e.jsx(De, { check: N, isPro: E }),
              se &&
                e.jsxs("div", {
                  role: "alert",
                  className:
                    "p-3 rounded-lg border border-destructive/50 text-sm text-destructive flex items-center justify-between gap-3",
                  children: [
                    e.jsx("span", { children: ye }),
                    e.jsx(d, {
                      size: "sm",
                      variant: "outline",
                      onClick: y,
                      children: "Choose another",
                    }),
                  ],
                }),
              e.jsxs("div", {
                className: "space-y-3 max-w-sm",
                children: [
                  e.jsxs("div", {
                    children: [
                      e.jsxs(F, {
                        children: ["Silence Threshold: ", j[0], " dB"],
                      }),
                      e.jsx(V, {
                        "aria-label": "Silence threshold (dB)",
                        value: j,
                        onValueChange: (t) => {
                          (b(t), c(null));
                        },
                        min: -60,
                        max: -15,
                        step: 5,
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className: "flex flex-wrap gap-2 items-center text-xs",
                    children: [
                      e.jsx(d, {
                        size: "sm",
                        variant: "outline",
                        className: "h-7",
                        onClick: ce,
                        disabled: !s,
                        children: "Auto threshold",
                      }),
                      e.jsx("span", {
                        className: "text-muted-foreground",
                        children:
                          "sets the threshold from this file's own background noise",
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsx(F, { children: "Pauses" }),
                      e.jsxs("select", {
                        className:
                          "block border rounded px-2 py-1 w-full bg-background text-sm",
                        value: D,
                        onChange: (t) => {
                          (Y(Number(t.target.value)), c(null));
                        },
                        "aria-label": "What to do with pauses",
                        children: [
                          e.jsx("option", {
                            value: 0,
                            children: "Remove them completely",
                          }),
                          e.jsx("option", {
                            value: 0.3,
                            children: "Shorten to about 0.3 s",
                          }),
                          e.jsx("option", {
                            value: 0.5,
                            children: "Shorten to about 0.5 s",
                          }),
                          e.jsx("option", {
                            value: 1,
                            children: "Shorten to about 1 s",
                          }),
                        ],
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    children: [
                      e.jsxs(F, {
                        children: ["Minimum Duration: ", w[0], "s"],
                      }),
                      e.jsx(V, {
                        "aria-label": "Minimum silence duration (seconds)",
                        value: w,
                        onValueChange: (t) => {
                          (B(t), c(null));
                        },
                        min: 0.2,
                        max: 2,
                        step: 0.1,
                      }),
                    ],
                  }),
                ],
              }),
              s &&
                e.jsxs("div", {
                  className: "space-y-2",
                  "data-testid": "pause-list",
                  children: [
                    e.jsxs("div", {
                      className:
                        "flex flex-wrap items-center justify-between gap-2",
                      children: [
                        e.jsx("p", {
                          className: "text-sm font-medium",
                          children:
                            r.length === 0
                              ? "No pauses found at these settings"
                              : `${r.length} ${r.length === 1 ? "pause" : "pauses"} found`,
                        }),
                        f.length > 1 &&
                          e.jsxs("div", {
                            className: "flex gap-1",
                            children: [
                              e.jsx(d, {
                                size: "sm",
                                variant: "ghost",
                                className: "h-7 text-xs",
                                onClick: () => U(!0),
                                children: "Cut all",
                              }),
                              e.jsx(d, {
                                size: "sm",
                                variant: "ghost",
                                className: "h-7 text-xs",
                                onClick: () => U(!1),
                                children: "Keep all",
                              }),
                            ],
                          }),
                      ],
                    }),
                    r.length > 0 &&
                      e.jsx("ul", {
                        className:
                          "max-h-60 overflow-auto rounded-lg border divide-y text-sm",
                        children: r.slice(0, 1e3).map((t) => {
                          const a = `pause-${t.start}`,
                            l = !!t.cut && !h.has(t.start);
                          return e.jsxs(
                            "li",
                            {
                              className: "flex items-center gap-3 px-3 py-1.5",
                              children: [
                                e.jsx("input", {
                                  id: a,
                                  type: "checkbox",
                                  className: "h-4 w-4",
                                  checked: l,
                                  disabled: !t.cut,
                                  onChange: () => le(t.start),
                                }),
                                e.jsxs("label", {
                                  htmlFor: a,
                                  className:
                                    "flex-1 cursor-pointer font-mono text-xs",
                                  children: [
                                    J(t.startSeconds),
                                    "–",
                                    J(t.endSeconds),
                                    " ",
                                    e.jsxs("span", {
                                      className:
                                        "text-muted-foreground font-sans",
                                      children: [
                                        "(",
                                        t.durationSeconds.toFixed(1),
                                        " s",
                                        t.cut
                                          ? ""
                                          : ", already short enough, left as it is",
                                        ")",
                                      ],
                                    }),
                                  ],
                                }),
                              ],
                            },
                            t.start,
                          );
                        }),
                      }),
                    r.length > 1e3 &&
                      e.jsx("p", {
                        className: "text-xs text-muted-foreground",
                        children:
                          "Showing the first 1000 pauses; Cut all and Keep all cover every pause.",
                      }),
                    r.length > 0 &&
                      e.jsxs("p", {
                        className: "text-xs text-muted-foreground",
                        "data-testid": "pause-prediction",
                        children: [
                          "Ticked pauses are cut: ",
                          Q(s.duration),
                          " → ",
                          Q(ie),
                          " (",
                          I.length,
                          " of ",
                          f.length,
                          " cut). Un-tick a pause to keep it.",
                        ],
                      }),
                    e.jsxs("div", {
                      className: "flex flex-wrap items-center gap-2",
                      children: [
                        e.jsx(d, {
                          size: "sm",
                          variant: "outline",
                          onClick: ue,
                          disabled: _ || r.length === 0,
                          children: "Preview the result",
                        }),
                        e.jsx("span", {
                          className: "text-xs text-muted-foreground",
                          children: _
                            ? "Too long to preview here; Remove Silence makes the file and you can listen to it before downloading."
                            : "Plays here, costs nothing.",
                        }),
                      ],
                    }),
                    $ && e.jsx(q, { blob: $ }),
                  ],
                }),
              g && e.jsx(ze, { progress: ee, statusMessage: te, onStop: re }),
              u &&
                e.jsx("p", {
                  className: "text-sm text-muted-foreground",
                  "data-testid": "silence-summary",
                  children: u.summary,
                }),
              u && e.jsx(q, { blob: u.blob }),
              e.jsx("div", {
                className: "flex gap-3",
                children: u
                  ? e.jsxs(e.Fragment, {
                      children: [
                        e.jsx(ve, {
                          blob: u.blob,
                          fileName: `desilenced_${i.name.replace(/\.[^.]+$/, `.${G(i, T).value}`)}`,
                        }),
                        e.jsx(d, {
                          variant: "outline",
                          onClick: y,
                          children: "New",
                        }),
                      ],
                    })
                  : e.jsxs(e.Fragment, {
                      children: [
                        e.jsx(d, {
                          onClick: de,
                          disabled:
                            g || N?.severity !== "ok" || !s || I.length === 0,
                          children: g ? "Removing..." : "Remove Silence",
                        }),
                        e.jsx(d, {
                          variant: "outline",
                          onClick: y,
                          disabled: g,
                          children: "Reset",
                        }),
                      ],
                    }),
              }),
            ],
          })
        : e.jsx(ge, {
            gateAtDownload: !0,
            accept: "audio/*",
            maxSize: 500,
            onFiles: oe,
            label: "Drop an audio file",
            description: "Automatically trim silent sections",
          }),
      e.jsx(je, { whatIsIt: P.what, howToUse: P.how, tip: P.tip }),
    ],
  });
}
export { St as default };
//# sourceMappingURL=SilenceRemover-DrPlWmTi.js.map
