function ql({
  onClick: e,
  label: t = "Download",
  disabled: n,
  blob: a,
  fileName: i,
  markHint: d,
  shareText: h,
  shareTitle: l,
  enableShare: c = !0,
  toolId: u,
  category: p,
  freeDownload: f = !1,
  gate: g,
  subtitle: b,
  stacked: y = !1,
  pinned: m,
  hideMarkNoticeOnPhone: w = !1,
}) {
  const { isAuthenticated: I } = Pe(),
    { logUsageNow: v } = la(),
    T = ee.usage.log.useMutation(),
    A = ee.useUtils(),
    N = pe(),
    C = Yo(),
    [, E] = No();
  Wt();
  const x = u ?? N.id ?? "unknown",
    _ = p ?? J(x)?.category ?? "unknown",
    j = !!C && C.currentStepIndex >= C.steps.length - 1,
    q = i && C && j ? C.finalName(i) : i,
    [D, W] = s.useState(!1),
    P = s.useMemo(
      () =>
        !a || !q
          ? null
          : new File([a], q, { type: a.type || "application/octet-stream" }),
      [a, q],
    ),
    $ = C?.recordOutput,
    F = C?.currentStepIndex ?? 0;
  s.useEffect(() => {
    $ && a && i && $(F, i, a.size, a);
  }, [$, F, a, i]);
  const K = c && P ? na(P) : !1,
    Y = c && !K && !!h && ra(),
    Z = () => {
      if (!(x === "unknown" || _ === "unknown") && !Ge(x)) {
        Eo(x);
        try {
          const L = I ? void 0 : ke();
          T.mutate(
            { toolId: x, category: _, deviceId: L },
            { onSuccess: () => A.usage.check.invalidate() },
          );
        } catch {}
      }
    },
    se = async () => (f ? !0 : g ? At(g) : u ? (Z(), !0) : v("download")),
    k = async () => {
      if (await se()) {
        if (a && q) {
          vt(a, q, { free: !0 });
          return;
        }
        e?.();
      }
    },
    V = async () => {
      if (await se())
        try {
          if (a && q) {
            (await Zn(a, q, { title: l || q })) || vt(a, q, { free: !0 });
            return;
          }
          h && (await Qn(h, { title: l }));
        } catch (L) {
          if (L instanceof DOMException && L.name === "AbortError") return;
          (console.error(L),
            a &&
              q &&
              (vt(a, q, { free: !0 }),
              M.info(
                "Sharing isn't available here — downloaded the file instead.",
              )));
        }
    };
  return o.jsxs("div", {
    className: `flex flex-wrap items-center gap-2 ${y ? "w-full" : ""}`,
    children: [
      (() => {
        const L = a && i ? i : d;
        return !L || !Re(a && i ? a.type : "", L, x)
          ? null
          : o.jsxs("p", {
              className: `w-full order-last text-xs text-muted-foreground${w ? " max-sm:hidden" : ""}`,
              "data-testid": "trial-mark-notice",
              children: [
                lt(a && i ? a.type : "", L) === "pdf"
                  ? "This download will carry a small “Created with FreeDailyPro.com” badge in the bottom right corner of each page."
function Al({ blob: e, mimeType: t, sizeWarnMB: n = 25 }) {
  const a = t || e.type || "",
    i = e.size / (1024 * 1024),
    [d, h] = s.useState("");
  s.useEffect(() => {
    const F = URL.createObjectURL(e);
    return (h(F), () => URL.revokeObjectURL(F));
  }, [e]);
  const [l, c] = s.useState(i <= n),
    [u, p] = s.useState(null),
    [f, g] = s.useState(!1),
    [b, y] = s.useState(!1),
    [m, w] = s.useState(null),
    [I, v] = s.useState(!1),
    [T, A] = s.useState(!1),
    [N, C] = s.useState(null),
    [E, x] = s.useState(null),
