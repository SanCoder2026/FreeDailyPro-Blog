#!/usr/bin/env python3
"""FDP-81: decode each output (ffmpeg, all channels) and list the 'speech' bursts and the gaps between them, using 20 ms RMS
windows above -20 dBFS on the loudest channel. Also rate, channels, codec, duration. Usage: analyze.py file..."""
import sys, subprocess, json, numpy as np
def probe(f):
    j = json.loads(subprocess.run(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', f], capture_output=True, text=True).stdout or '{}')
    a = [s for s in j.get('streams', []) if s.get('codec_type') == 'audio'][0]; return int(a['sample_rate']), int(a['channels']), a['codec_name'], float(j['format'].get('duration', 0))
out = {}
for f in sys.argv[1:]:
    try:
        sr, ch, codec, dur = probe(f)
        x = np.frombuffer(subprocess.run(['ffmpeg', '-v', 'error', '-i', f, '-f', 'f32le', '-'], capture_output=True).stdout, '<f4').reshape(-1, ch)
        n = int(sr * 0.02); w = len(x) // n; r = np.sqrt((x[:w * n].reshape(w, n, ch) ** 2).mean(1)).max(1); on = r > 10 ** (-20 / 20)
        segs = []; i = 0
        while i < w:
            if on[i]:
                j = i
                while j < w and on[j]: j += 1
                segs.append((round(i * .02, 2), round(j * .02, 2))); i = j
            else: i += 1
        gaps = [round(segs[k + 1][0] - segs[k][1], 2) for k in range(len(segs) - 1)]
        out[f.split('/')[-1]] = {'rate': sr, 'ch': ch, 'codec': codec, 'dur': round(dur, 3), 'bursts': len(segs), 'lead': segs[0][0] if segs else None, 'trail': round(len(x) / sr - segs[-1][1], 2) if segs else None, 'gaps': gaps[:12], 'gapsTotal': len(gaps)}
    except Exception as e: out[f.split('/')[-1]] = {'err': str(e)[:120]}
print(json.dumps(out, indent=1))
