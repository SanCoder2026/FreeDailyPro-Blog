#!/usr/bin/env python3
"""FDP-81 test files ("speech" = 1 s 440 Hz tone bursts at -6 dBFS; floor = white noise).
speech.wav (44.1 kHz mono, 14.5 s): lead 1.0 s, 6 bursts, gaps 0.1 / 0.3 / 0.6 / 1.5 / 3.0 s, trail 2.0 s, floor -50 dBFS.
noisy.wav: same at a -30 dBFS floor.  soft.wav: bursts at -40 dBFS (softer than the -35 default).  allquiet.wav: 5 s floor only.
speech48k.wav / speech22k.wav: other rates. stereo.wav: L = speech, R = speech with the 1.5 s gap filled by a burst.
speech.mp3/.m4a/.flac/.ogg from speech.wav. many.wav (8 kHz): 1100 x (0.25 s burst + 0.5 s gap) = 825 s.
Needs numpy + ffmpeg."""
import numpy as np, wave, subprocess, os, sys
D = sys.argv[1] if len(sys.argv) > 1 else 'testfiles'; os.makedirs(D, exist_ok=True); rng = np.random.default_rng(81)
def build(sr, floor_db=-50, amp_db=-6, gaps=(0.1, 0.3, 0.6, 1.5, 3.0), lead=1.0, trail=2.0, fill=None):
    a = 10 ** (amp_db / 20); parts = []; tone = lambda s: a * np.sin(2 * np.pi * 440 * np.arange(int(s * sr)) / sr)
    parts.append(np.zeros(int(lead * sr)))
    for i, g in enumerate(gaps): parts += [tone(1.0), tone(g) if fill == i else np.zeros(int(g * sr))]
    parts += [tone(1.0), np.zeros(int(trail * sr))]; x = np.concatenate(parts)
    return x + rng.normal(0, 10 ** (floor_db / 20), len(x))
def wav(path, chans, sr):
    x = np.stack(chans, 1) if isinstance(chans, list) else chans[:, None]
    with wave.open(path, 'wb') as w: w.setnchannels(x.shape[1]); w.setsampwidth(2); w.setframerate(sr); w.writeframes((np.clip(x, -1, 1) * 32767).astype('<i2').tobytes())
wav(f'{D}/speech.wav', build(44100), 44100); wav(f'{D}/noisy.wav', build(44100, -30), 44100); wav(f'{D}/soft.wav', build(44100, -60, -40), 44100)
wav(f'{D}/allquiet.wav', rng.normal(0, 10 ** (-50 / 20), 5 * 44100), 44100)
wav(f'{D}/speech48k.wav', build(48000), 48000); wav(f'{D}/speech22k.wav', build(22050), 22050)
wav(f'{D}/stereo.wav', [build(44100), build(44100, fill=3)], 44100)
sr = 8000; one = np.concatenate([0.5 * np.sin(2 * np.pi * 440 * np.arange(int(.25 * sr)) / sr), np.zeros(int(.5 * sr))]); wav(f'{D}/many.wav', np.tile(one, 1100) + rng.normal(0, 0.003, 1100 * len(one)), sr)
ff = lambda *a: subprocess.run(['ffmpeg', '-loglevel', 'error', '-y', *a], check=True)
for ext, c in [('mp3', ['-c:a', 'libmp3lame', '-q:a', '2']), ('m4a', ['-c:a', 'aac', '-b:a', '192k']), ('flac', ['-c:a', 'flac']), ('ogg', ['-c:a', 'libvorbis', '-q:a', '5'])]: ff('-i', f'{D}/speech.wav', *c, f'{D}/speech.{ext}')
print(sorted(os.listdir(D)))
