import { r, j as t } from "./vendor-react-D01g8YgM.js";
import { T as ee, F as te, R as se, D as ae } from "./ToolPage-DwLoDncN.js";
import { f as F, N as oe, B as C } from "./index-B1CTyGtY.js";
import {
  S as re,
  a as ie,
  b as le,
  c as ne,
  d as L,
} from "./select-ic5yaeGw.js";
import { T as ce } from "./ToolInfoSection-C0i6Zbwo.js";
import { R as de } from "./ReorderableFileList-BhqJ-ECL.js";
import { u as me } from "./UsageAndUpgradeStrip-B1CY210m.js";
import {
  checkFileSize as ue,
  resetFFmpegEngine as $,
  loadFFmpeg as pe,
  fetchFile as he,
  ffmpegOutputToBlob as fe,
} from "./ffmpegEngine-DH91Xnxx.js";
import {
  b as ge,
  k as xe,
  l as be,
  n as je,
  A as B,
  o as ve,
  q as we,
  u as Ne,
  v as Se,
  w as ye,
  x as Fe,
} from "./operations-DLxdtd8A.js";
import { f as Ce } from "./containers-CEblVBL8.js";
import { F as ke, A as Re, s as Ae } from "./uiHelpers-DY6mT0h-.js";
import { a as _ } from "./timeFormat-Va_Xba1f.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-BdQq_4o_.js";
import "./index-DhOoIDuZ.js";
import "./chevron-up-BDUcPssj.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./formatFileSize-B-JRDfN5.js";
import "./reorderMath-CVj9Q6Gj.js";
import "./grip-vertical-Dzkp2Q5V.js";
import "./sniffRate-BQP3kobv.js";
import "./progress-Y72GQ7li.js";
import "./square-DmBnvOHU.js";
const k = {
    what: "Combines two or more audio clips into a single file, played back to back in the order you set. You can leave a gap of silence between clips or crossfade them, up to 5 seconds. Runs entirely in your browser — your audio never leaves your device.",
    how: "Upload your audio clips, then drag them (or use the arrows) into the order you want them to play. Each clip shows its length and sample rate. Choose a gap of silence or a crossfade between clips (they are alternatives), then merge and listen to the result before you download. Merging and listening cost nothing; a trial use is taken only when you download.",
    tip: "Clips are re-encoded during merging (the output format defaults to the first clip's, at its bitrate), so mixing different source formats (like an MP3 and a WAV) won't break the merge. Clips recorded at different sample rates are all brought to the first clip's rate, and a note says which ones were. A crossfade is shortened where a clip is too short for it. The size limit applies to all clips added together, not each one separately.",
  },
  U = [0, 0.25, 0.5, 1, 2, 3, 5],
  G = (a) => (a === 0 ? "none" : `${a} s`);
function xt() {
  const [a, p] = r.useState([]),
    [c, R] = r.useState(!1),
    [V, A] = r.useState(0),
    [H, v] = r.useState(""),
    [d, l] = r.useState(null),
    [w, T] = r.useState(0),
    [m, M] = r.useState(0),
    [N, q] = r.useState("same"),
    [g, O] = r.useState({}),
    x = (e) => `${e.name}|${e.size}|${e.lastModified}`;
  r.useEffect(() => {
    a.forEach((e) => {
      const s = x(e);
      s in g ||
        (O((o) => ({ ...o, [s]: { duration: null, rate: null } })),
        Promise.all([ge(e), Ce(e)]).then(([o, i]) =>
          O((n) => ({ ...n, [s]: { duration: o, rate: i } })),
        ));
    });
  }, [a]);
  const b = a.map((e) => g[x(e)]?.duration ?? null),
    I = a.map((e) => g[x(e)]?.rate ?? null),
    D = xe(I),
    S = be(I, D),
    u = N === "same" ? je(a[0]?.name ?? "x.mp3") : B.find((e) => e.value === N),
    j = ve(b, w, m),
    J = m > 0 && we(b, m).some((e) => e < m - 1e-9),
    { isPro: E, isLoading: W, isAdmin: Y } = me(),
    h = r.useRef(null),
    z = r.useRef(null),
    Z = r.useCallback((e) => {
      (p((s) => {
        const o = [...s];
        let i = 0;
        for (const n of e)
          o.some(
            (f) =>
              f.name === n.name &&
              f.size === n.size &&
              f.lastModified === n.lastModified,
          )
            ? i++
            : o.push(n);
        return (
          i > 0 &&
            F.error(
              i === 1
                ? "That file is already in the list — skipped the duplicate."
                : `${i} of those files are already in the list — skipped the duplicates.`,
            ),
          o
        );
      }),
        l(null));
    }, []),
    K = (e) => {
      (p((s) => s.filter((o, i) => i !== e)), l(null));
    },
    y = a.length > 0 ? ue(a, E || W, Y) : null,
    Q = () => {
      (z.current?.abort(), h.current && $(h.current));
    },
    X = async () => {
      if (a.length < 2) {
        F.error("Add at least 2 audio files to merge");
        return;
      }
      (R(!0), A(0));
      const e = new AbortController();
      z.current = e;
      try {
        v("Loading audio engine...");
        const s = await pe((f) => v(f));
        ((h.current = s), v("Merging clips..."));
        const o = a[0],
          i = ["mp3", "ogg", "m4a"].includes(u.value)
            ? Se(u.value, ye(o, b[0]))
            : u.codec,
          n = await Fe(
            s,
            a,
            he,
            A,
            e.signal,
            w,
            { ext: u.value, codec: i, durationSec: j ?? void 0 },
            { crossfadeSeconds: m, sampleRate: D, durations: b },
          ),
          P = fe(n, u.mime);
        (l({ blob: P, note: S, seconds: j }), F.success("Audio merged!"));
      } catch (s) {
        Ae(s);
      } finally {
        (h.current && $(h.current), R(!1));
      }
    };
  return t.jsxs(ee, {
    children: [
      t.jsx(te, {
        accept: "audio/*",
        multiple: !0,
        maxSize: 500,
        onFiles: Z,
        label: "Drop audio files to merge",
        description: "Combine multiple audio clips",
        deferUsageLog: !0,
      }),
      a.length > 0 &&
        t.jsxs("div", {
          className: "mt-4 space-y-3",
          children: [
            t.jsx(de, {
              files: a,
              onReorder: (e) => {
                (p(e), l(null));
              },
              onRemove: K,
              renderItemExtra: (e) => {
                const { duration: s, rate: o } = g[x(a[e])] ?? {
                  duration: null,
                  rate: null,
                };
                return t.jsxs("span", {
                  className: "text-xs text-muted-foreground",
                  "data-testid": "clip-info",
                  children: [
                    e + 1,
                    ".",
                    s ? ` ${_(s)}` : "",
                    o ? ` · ${+(o / 1e3).toFixed(2)} kHz` : "",
                  ],
                });
              },
            }),
            t.jsxs("div", {
              className:
                "flex flex-wrap items-center gap-x-6 gap-y-2 pt-1 text-sm",
              children: [
                t.jsxs("label", {
                  className: "flex items-center gap-2",
                  children: [
                    "Gap between clips",
                    t.jsx("select", {
                      className: "border rounded px-2 py-1 bg-background",
                      "aria-label": "Gap between clips",
                      value: w,
                      disabled: c,
                      onChange: (e) => {
                        const s = Number(e.target.value);
                        (T(s), s > 0 && M(0), l(null));
                      },
                      children: U.map((e) =>
                        t.jsx("option", { value: e, children: G(e) }, e),
                      ),
                    }),
                  ],
                }),
                t.jsxs("label", {
                  className: "flex items-center gap-2",
                  children: [
                    "Crossfade",
                    t.jsx("select", {
                      className: "border rounded px-2 py-1 bg-background",
                      "aria-label": "Crossfade between clips",
                      value: m,
                      disabled: c,
                      onChange: (e) => {
                        const s = Number(e.target.value);
                        (M(s), s > 0 && T(0), l(null));
                      },
                      children: U.map((e) =>
                        t.jsx("option", { value: e, children: G(e) }, e),
                      ),
                    }),
                  ],
                }),
                t.jsx("span", {
                  className: "text-xs text-muted-foreground",
                  children:
                    "A gap and a crossfade are alternatives: choosing one clears the other.",
                }),
              ],
            }),
            J &&
              t.jsx("p", {
                className: "text-xs text-muted-foreground",
                "data-testid": "crossfade-shortened",
                children:
                  "The crossfade is shortened where a clip is too short for it (at most half of either clip).",
              }),
            t.jsxs("div", {
              className: "flex flex-wrap items-center gap-2 pt-1",
              children: [
                t.jsx("span", {
                  className: "text-sm",
                  children: "Output format:",
                }),
                t.jsxs(re, {
                  value: N,
                  onValueChange: (e) => {
                    (q(e), l(null));
                  },
                  children: [
                    t.jsx(ie, {
                      className: "w-44",
                      "aria-label": "Output format",
                      children: t.jsx(le, {}),
                    }),
                    t.jsxs(ne, {
                      children: [
                        t.jsx(L, {
                          value: "same",
                          children: "Same as first file",
                        }),
                        B.map((e) =>
                          t.jsx(
                            L,
                            { value: e.value, children: e.label },
                            e.value,
                          ),
                        ),
                      ],
                    }),
                  ],
                }),
                j !== null &&
                  t.jsxs("span", {
                    className: "text-xs text-muted-foreground",
                    "data-testid": "merge-total",
                    children: ["Total length ", _(j)],
                  }),
              ],
            }),
            S &&
              t.jsxs(oe, {
                testId: "merge-resample-note",
                className: "text-sm",
                children: [
                  S,
                  ". Mixed sample rates are brought to the first clip's rate.",
                ],
              }),
            y && t.jsx(ke, { check: y, isPro: E }),
            c &&
              t.jsx("div", {
                className: "pt-2",
                children: t.jsx(Re, {
                  progress: V,
                  statusMessage: H,
                  onStop: Q,
                }),
              }),
            d &&
              t.jsxs("div", {
                className: "space-y-1",
                children: [
                  t.jsx("p", {
                    className: "text-sm font-medium",
                    children: "Listen to the result",
                  }),
                  t.jsx("p", {
                    className: "text-xs text-muted-foreground",
                    "data-testid": "merge-charge-note",
                    children:
                      "Merging and listening cost nothing; a trial use is only taken when you download.",
                  }),
                  d.note &&
                    t.jsxs("p", {
                      className: "text-xs text-muted-foreground",
                      "data-testid": "merge-result-note",
                      children: [d.note, "."],
                    }),
                  t.jsx(se, { blob: d.blob }),
                ],
              }),
            t.jsx("div", {
              className: "flex gap-3 pt-4",
              children: d
                ? t.jsxs(t.Fragment, {
                    children: [
                      t.jsx(ae, {
                        blob: d.blob,
                        fileName: Ne(a.length, u.value),
                      }),
                      t.jsx(C, {
                        variant: "outline",
                        onClick: () => {
                          (p([]), l(null));
                        },
                        children: "New",
                      }),
                    ],
                  })
                : t.jsxs(t.Fragment, {
                    children: [
                      t.jsx(C, {
                        onClick: X,
                        disabled: c || a.length < 2 || y?.severity !== "ok",
                        children: c ? "Merging..." : "Merge Audio",
                      }),
                      t.jsx(C, {
                        variant: "outline",
                        onClick: () => p([]),
                        disabled: c,
                        children: "Clear",
                      }),
                    ],
                  }),
            }),
          ],
        }),
      t.jsx(ce, { whatIsIt: k.what, howToUse: k.how, tip: k.tip }),
    ],
  });
}
export { xt as default };
//# sourceMappingURL=AudioMerger-yWIf0YyA.js.map
