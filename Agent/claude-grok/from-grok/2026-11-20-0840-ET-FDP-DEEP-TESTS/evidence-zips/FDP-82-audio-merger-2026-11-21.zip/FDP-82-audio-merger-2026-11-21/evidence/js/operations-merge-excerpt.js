// Excerpt of operations-DLxdtd8A.js (prettified): crossfade cap L, total length ye, filter graph ee, resample note Se, file name xe, merge Ne, bitrate M/T/G.
function M(e, t) {
  return /\.(wav|wave|flac|aiff?)$/i.test(e.name) || g(e.name) || !t
    ? 192
    : z((e.size * 8) / t / 1e3);
}
function fe(e, t) {
  const a = /\.(wav|wave|flac|aiff?)$/i.test(e.name),
    n = M(e, t);
  return g(e.name)
    ? `Same as original (video sound, ${n} kbps)`
    : a
      ? `Same as original (lossless source, ${n} kbps)`
      : t
        ? `Same as original (${n} kbps)`
        : `Same as original (${n} kbps, length unknown)`;
}
function T(e, t) {
  const a = `${t}k`;
  return e === "mp3"
    ? ["-c:a", "libmp3lame", "-b:a", a]
    : e === "ogg"
      ? ["-c:a", "libvorbis", "-b:a", a]
      : e === "m4a"
        ? ["-c:a", "aac", "-b:a", a]
        : v.find((n) => n.value === e).codec;
}
function G(e) {
  const t = (e.match(/\.([^.]+)$/)?.[1] ?? "").toLowerCase(),
    a =
      t === "wav" || t === "wave"
        ? "wav"
        : t === "flac"
          ? "flac"
          : ["m4a", "aac", "mp4"].includes(t)
            ? "m4a"
            : ["ogg", "oga", "opus"].includes(t)
              ? "ogg"
              : "mp3";
function L(e, t) {
  const a = [];
  for (let n = 0; n + 1 < e.length; n++) {
    const o = Math.min(
      ...[e[n], e[n + 1]].map((s) => (s && s > 0 ? s / 2 : 1 / 0)),
    );
    a.push(Math.max(0, Math.round(Math.min(t, o) * 1e3) / 1e3));
  }
  return a;
}
function ye(e, t, a) {
  if (e.length === 0 || e.some((o) => !o)) return null;
  const n = e.reduce((o, s) => o + s, 0);
  return a > 0
    ? n - L(e, a).reduce((o, s) => o + s, 0)
    : n + t * (e.length - 1);
}
function ee(e, t = {}) {
  const { gapSeconds: a = 0, crossfades: n = [], sampleRate: o = null } = t,
    s = Array.from(
      { length: e },
      (c, u) => `[${u}:a]${o ? `aresample=${o}` : "anull"}[s${u}]`,
    );
  if (n.some((c) => c > 0)) {
    const c = [];
    let u = "[s0]";
    for (let m = 1; m < e; m++) {
      const d = m === e - 1 ? "[outa]" : `[x${m}]`;
      (c.push(`${u}[s${m}]acrossfade=d=${n[m - 1] ?? 0}:c1=qsin:c2=qsin${d}`),
        (u = d));
    }
    return [...s, ...c].join(";");
  }
  const i = Array.from({ length: e }, (c, u) =>
      a > 0 && u < e - 1 ? `[s${u}]apad=pad_dur=${a}[p${u}]` : null,
    ),
    l = Array.from({ length: e }, (c, u) =>
      i[u] ? `[p${u}]` : `[s${u}]`,
    ).join("");
  return [...s, ...i.filter(Boolean), `${l}concat=n=${e}:v=0:a=1[outa]`].join(
    ";",
  );
}
function ae(e) {
  const t = e % 100;
  return `${e}${t >= 11 && t <= 13 ? "th" : (["th", "st", "nd", "rd"][e % 10] ?? "th")}`;
}
const I = (e) => `${+(e / 1e3).toFixed(2)}`;
function Fe(e) {
  return e.find((t) => !!t) ?? null;
}
function Se(e, t) {
  return t
    ? e
        .flatMap((n, o) =>
          n && n !== t
            ? [`${ae(o + 1)} clip resampled ${I(n)} → ${I(t)} kHz`]
            : [],
        )
        .join("; ")
    : "";
}
function xe(e, t) {
  return `merged-${e}-${e === 1 ? "clip" : "clips"}.${t}`;
}
async function Ne(
  e,
  t,
  a,
  n,
  o,
  s = 0,
  r = { ext: "mp3", codec: ["-c:a", "libmp3lame", "-q:a", "2"] },
  i = {},
) {
  const l = [];
  for (let m = 0; m < t.length; m++) {
    const d = (
      t[m].name.match(/\.([A-Za-z0-9]+)$/)?.[1] ?? "mp3"
    ).toLowerCase();
    (await e.writeFile(`in${m}.${d}`, await a(t[m])),
      l.push("-i", `in${m}.${d}`));
  }
  const c =
      (i.crossfadeSeconds ?? 0) > 0
        ? L(i.durations ?? t.map(() => null), i.crossfadeSeconds)
        : [],
    u = ee(t.length, {
      gapSeconds: s,
      crossfades: c,
      sampleRate: i.sampleRate,
    });
  return (
    await p(
      e,
      [
        ...l,
        "-filter_complex",
        u,
        "-map",
        "[outa]",
        ...r.codec,
        `output.${r.ext}`,
