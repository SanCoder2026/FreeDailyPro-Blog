#!/usr/bin/env python3
"""FDP-82: duration, rate, channels, codec, bitrate, and every beep onset with its pitch (1/2/3 kHz = clip a/b/c) per channel. Usage: analyze.py file..."""
import sys, subprocess, json, numpy as np
out = {}
for f in sys.argv[1:]:
    try:
        j = json.loads(subprocess.run(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', f], capture_output=True, text=True).stdout)
        a = [s for s in j['streams'] if s['codec_type'] == 'audio'][0]; sr = int(a['sample_rate']); ch = int(a['channels'])
        x = np.frombuffer(subprocess.run(['ffmpeg', '-v', 'error', '-i', f, '-map', '0:a:0', '-f', 'f32le', '-'], capture_output=True).stdout, '<f4').reshape(-1, ch)
        res = []
        for c in range(ch):
            y = x[:, c]; i = 0; on = []
            while i < len(y):
                if abs(y[i]) > 0.1:
                    seg = y[i:i + int(0.015 * sr)]; zc = np.sum(np.diff(np.signbit(seg).astype(int)) != 0); hz = zc / 2 / (len(seg) / sr)
                    on.append((round(i / sr, 2), int(round(hz / 1000)))); i += int(0.3 * sr)
                else: i += 1
            res.append(on)
        out[f.split('/')[-1]] = {'rate': sr, 'ch': ch, 'codec': a['codec_name'], 'kbps': round(int(j['format'].get('bit_rate', 0)) / 1000), 'dur': round(float(j['format']['duration']), 3), 'streams': [s['codec_type'] + ':' + s['codec_name'] for s in j['streams']], 'beeps_kHz': res}
    except Exception as e: out[f.split('/')[-1]] = {'err': str(e)[:120]}
print(json.dumps(out))
