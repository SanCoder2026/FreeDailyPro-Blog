#!/usr/bin/env python3
"""FDP-82 test clips. Each clip has 20 ms beeps at its whole seconds, pitched so the merged file shows which clip is where:
a.wav 3.0 s 44.1 kHz mono, 1 kHz | b.mp3 2.0 s, 2 kHz | c48.wav 2.0 s 48 kHz, 3 kHz | st.wav 2.0 s stereo 44.1 kHz, 1 kHz on L only
short.wav 0.4 s, 2 kHz | cover.mp3 = b with a ~1.5 MB cover picture | corrupt.mp3 random bytes | video.mp4 (audio = a) | b.ogg, b.m4a, b.flac.
Needs numpy + ffmpeg."""
import numpy as np, wave, subprocess, os, sys
D = sys.argv[1] if len(sys.argv) > 1 else 'testfiles'; os.makedirs(D, exist_ok=True); rng = np.random.default_rng(82)
def beeps(sec, sr, hz):
    t = np.arange(int(sec * sr)) / sr; x = np.zeros_like(t)
    for s in range(int(np.ceil(sec))):
        m = (t >= s) & (t < s + 0.02); x[m] = 0.6 * np.sin(2 * np.pi * hz * (t[m] - s))
    return x
def wav(path, x, sr):
    x = x if x.ndim == 2 else x[:, None]
    with wave.open(path, 'wb') as w: w.setnchannels(x.shape[1]); w.setsampwidth(2); w.setframerate(sr); w.writeframes((x * 32767).astype('<i2').tobytes())
ff = lambda *a: subprocess.run(['ffmpeg', '-loglevel', 'error', '-y', *a], check=True)
wav(f'{D}/a.wav', beeps(3, 44100, 1000), 44100); wav(f'{D}/b-src.wav', beeps(2, 44100, 2000), 44100); wav(f'{D}/c48.wav', beeps(2, 48000, 3000), 48000)
l = beeps(2, 44100, 1000); wav(f'{D}/st.wav', np.stack([l, np.zeros_like(l)], 1), 44100); wav(f'{D}/short.wav', beeps(0.4, 44100, 2000), 44100)
ff('-i', f'{D}/b-src.wav', '-c:a', 'libmp3lame', '-b:a', '128k', f'{D}/b.mp3')
for e, c in [('ogg', ['-c:a', 'libvorbis', '-q:a', '5']), ('m4a', ['-c:a', 'aac', '-b:a', '128k']), ('flac', ['-c:a', 'flac'])]: ff('-i', f'{D}/b-src.wav', *c, f'{D}/b.{e}')
from PIL import Image
Image.fromarray(rng.integers(0, 255, (700, 700, 3), dtype=np.uint8)).save(f'{D}/noise.png')
ff('-i', f'{D}/b.mp3', '-i', f'{D}/noise.png', '-map', '0', '-map', '1', '-c:a', 'copy', '-c:v', 'png', '-disposition:v', 'attached_pic', f'{D}/cover.mp3')
ff('-f', 'lavfi', '-i', 'testsrc=size=320x240:rate=25', '-i', f'{D}/a.wav', '-t', '3', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-shortest', f'{D}/video.mp4')
open(f'{D}/corrupt.mp3', 'wb').write(b'ID3' + rng.bytes(20000)); os.remove(f'{D}/b-src.wav'); os.remove(f'{D}/noise.png')
print({f: os.path.getsize(f'{D}/{f}') for f in sorted(os.listdir(D))})
