// FDP-82: two 30 MB WAVs (60 MB combined) as a guest: size notice and Merge Audio state. No Download press.
const pw = require('playwright'); const D = '/workspace/deep/82-audio-merger/';
(async () => { const b = await pw.chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 1000 } })).newPage();
 await p.goto('https://www.freedailypro.com/tool/audio-merger', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 await p.locator('input[type=file]').first().setInputFiles([D + 'bigfiles/big1.wav']); await p.waitForTimeout(2500);
 const st = () => p.evaluate(() => { const m = document.querySelector('main'); const btn = [...m.querySelectorAll('button')].find(x => /^Merge Audio$/.test(x.innerText.trim())); return { btn: btn ? (btn.disabled ? 'disabled' : 'enabled') : null, notices: (m.innerText.match(/[^\n]*(MB|limit|too large|combined)[^\n]*/gi) || []).slice(0, 6), toasts: [...document.querySelectorAll('[data-sonner-toast]')].map(e => e.innerText.replace(/\s+/g, ' ')).join(' / ') }; });
 const one = await st(); await p.locator('input[type=file]').first().setInputFiles([D + 'bigfiles/big2.wav']); await p.waitForTimeout(3000); const two = await st();
 await p.screenshot({ path: D + 'live/cases/B01-60MB-guest.png', fullPage: true }); console.log(JSON.stringify({ one, two })); require('fs').writeFileSync(D + 'live/big.json', JSON.stringify({ one, two }, null, 1)); await b.close(); })();
