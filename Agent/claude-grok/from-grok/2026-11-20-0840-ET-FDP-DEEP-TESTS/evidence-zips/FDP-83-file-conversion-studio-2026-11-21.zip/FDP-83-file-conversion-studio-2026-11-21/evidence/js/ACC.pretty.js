import { g as o } from "./index-B1CTyGtY.js";
import { u as s } from "./useAdminAccess-CRDzdxJU.js";
function r() {
  const i = o(),
    e = s();
  return i
    ? { open: !0, preview: !1, loading: !1 }
    : { open: e.allowed, preview: e.allowed, loading: e.loading };
}
export { r as u };
//# sourceMappingURL=access-BB4298M0.js.map
