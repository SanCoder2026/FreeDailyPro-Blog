const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/jszip.min-CT0ZA6V1.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/jszip.min-C-FLQHAz.js",
      "assets/_commonjs-dynamic-modules-TDtrdbi3.js",
      "assets/convertBrowser-CYvv7SBJ.js",
      "assets/decode-DrS85i4S.js",
      "assets/index-B1CTyGtY.js",
      "assets/index-BJxTAPRn.css",
      "assets/convertCore-pdjQ6UTb.js",
      "assets/jpegDpi-c8DPdZxl.js",
      "assets/operations-YdcesJcx.js",
      "assets/utils-1EQcVBdK.js",
      "assets/operations-B4LtHhm8.js",
      "assets/pdfFonts-Ckcqm3Ic.js",
      "assets/index-BRvxULIc.js",
      "assets/index-CnXdQaNG.js",
      "assets/index-DMQTJy3b.js",
      "assets/fontkit.es-DA-3qwB1.js",
      "assets/pdfBookmarks-BjfxtCfb.js",
      "assets/pdfMetadata-CcxIhQF2.js",
      "assets/pageView-BQIwVYOi.js",
      "assets/formAppearance-CdNbuISd.js",
      "assets/drawTextAnywhere-DcuP6lHH.js",
      "assets/ocrText-C_9cxcFa.js",
      "assets/ocrImage-CmXFNUud.js",
      "assets/utils-s8ucLyj8.js",
      "assets/imageRecompress-eXQFDUm-.js",
      "assets/formatFileSize-B-JRDfN5.js",
      "assets/plural-FIChqbp4.js",
      "assets/textDiff-DxE9AzvO.js",
      "assets/formFill-Dg9Myfyq.js",
      "assets/redactSearch-DQpyyh_t.js",
      "assets/nameDetect-DvHCRM0m.js",
      "assets/universalCore-DlMOBYC5.js",
      "assets/legacyDeck-Dmz2TtSU.js",
      "assets/trpcVanilla-BSVQBMYf.js",
      "assets/textToPdf-BuGdG5vq.js",
      "assets/ToolPage-DwLoDncN.js",
      "assets/useUploadApi-cn-OKK9Q.js",
      "assets/cloudStorage-BzUdFuQl.js",
      "assets/camera-8PGplCT5.js",
      "assets/share-2-B4TSO3Yd.js",
      "assets/copy-DcUvE8ta.js",
      "assets/workflowCta-WWwB7oO9.js",
      "assets/UsageAndUpgradeStrip-B1CY210m.js",
      "assets/access-BB4298M0.js",
      "assets/useAdminAccess-CRDzdxJU.js",
      "assets/tool-name-translations-d1j9ms8v.js",
      "assets/InstallToolButton-CQjOKKQY.js",
      "assets/map-pin-Dp16LrFV.js",
      "assets/FaqSection-C8274byc.js",
      "assets/ToolVideoEmbed-CCFWLqkW.js",
      "assets/GuideLinks-CJoJwps-.js",
      "assets/blog-8brHQns7.js",
      "assets/info-B8t_e6MS.js",
      "assets/productCards-BBBZlV20.js",
      "assets/layers-Dw7RJFNV.js",
      "assets/usePwaManifest-D8HDEEPW.js",
      "assets/mdConvert-ChWDCiEy.js",
      "assets/index-CHifq31M.js",
      "assets/operations-DLxdtd8A.js",
      "assets/ffmpegEngine-DH91Xnxx.js",
      "assets/timeFormat-Va_Xba1f.js",
      "assets/operations-P8Ty5WBe.js",
      "assets/scriptFonts-B9baRZsf.js",
      "assets/utils-qgqMjnRG.js",
    ]),
) => i.map((i) => d[i]);
import { r as b, j as s } from "./vendor-react-D01g8YgM.js";
import { J as It } from "./jszip.min-CT0ZA6V1.js";
import {
  B as N,
  f as D,
  N as ce,
  ap as z,
  a_ as Ue,
  D as Ve,
  aJ as Ze,
} from "./index-B1CTyGtY.js";
import {
  aa as At,
  ab as Ce,
  ac as ae,
  ad as st,
  ae as at,
  d as se,
  f as Rt,
  af as nt,
  ag as Dt,
  ah as Ot,
  ai as Bt,
  aj as Ft,
  ak as Lt,
  al as Mt,
  T as zt,
  U as Je,
} from "./ToolPage-DwLoDncN.js";
import { T as qt } from "./ToolInfoSection-C0i6Zbwo.js";
import { W as Ut } from "./WorkflowProductGate-DbtxVtBO.js";
import { T as Pe } from "./trash-2-CmoDM6Qu.js";
import { s as Vt } from "./csvParse-eP1CzDn2.js";
import { F as Zt } from "./folder-open-CaGDudCA.js";
import { P as Jt } from "./pause-D6USnVqY.js";
import { S as We } from "./square-DmBnvOHU.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./useUploadApi-cn-OKK9Q.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-8PGplCT5.js";
import "./share-2-B4TSO3Yd.js";
import "./copy-DcUvE8ta.js";
import "./workflowCta-WWwB7oO9.js";
import "./UsageAndUpgradeStrip-B1CY210m.js";
import "./access-BB4298M0.js";
import "./useAdminAccess-CRDzdxJU.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CQjOKKQY.js";
import "./map-pin-Dp16LrFV.js";
import "./FaqSection-C8274byc.js";
import "./ToolVideoEmbed-CCFWLqkW.js";
import "./GuideLinks-CJoJwps-.js";
import "./blog-8brHQns7.js";
import "./info-B8t_e6MS.js";
import "./productCards-BBBZlV20.js";
import "./layers-Dw7RJFNV.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-BCSBEG9-.js";
import "./chevron-up-BDUcPssj.js";
const rt = [
    "image",
    "heic",
    "pdf",
    "text",
    "excel",
    "csv",
    "powerpoint",
    "docx",
    "html",
    "markdown",
    "audio",
    "video",
  ],
  X = {
    image: "Image",
    heic: "HEIC photo",
    pdf: "PDF",
    text: "Text file",
    excel: "Spreadsheet",
    csv: "CSV",
    powerpoint: "PowerPoint presentation",
    docx: "Word document",
    html: "HTML file",
    markdown: "Markdown file",
    audio: "Audio",
    video: "Video",
  },
  Wt = (e) => (e.toLowerCase().match(/\.([^./]+)$/) ?? [])[1] ?? "",
  ot = [
    "jpg",
    "jpeg",
    "png",
    "webp",
    "gif",
    "avif",
    "bmp",
    "tif",
    "tiff",
    "svg",
  ],
  it = ["mp3", "wav", "flac", "m4a", "ogg", "aac", "wma", "opus"],
  lt = [
    "mp4",
    "m4v",
    "mov",
    "webm",
    "mkv",
    "avi",
    "wmv",
    "flv",
    "3gp",
    "mpg",
    "mpeg",
    "ogv",
  ];
function Ht(e) {
  const t = Wt(e.name);
  if (t === "heic" || t === "heif") return "heic";
  if (ot.includes(t)) return "image";
  if (t === "pdf") return "pdf";
  if (t === "md") return "markdown";
  if (t === "html" || t === "htm") return "html";
  if (t === "txt") return "text";
  if (t === "csv") return "csv";
  if (t === "xls" || t === "xlsx") return "excel";
  if (["ppt", "pptx", "pps", "odp", "key"].includes(t)) return "powerpoint";
  if (t === "doc" || t === "docx") return "docx";
  if (it.includes(t)) return "audio";
  if (lt.includes(t)) return "video";
  const n = e.type ?? "";
  return n.startsWith("audio/")
    ? "audio"
    : n.startsWith("video/")
      ? "video"
      : null;
}
const Gt = /(^|\/)(\.|__MACOSX|node_modules)/,
  we = (e) => Gt.test(e) || /(^|\/)(thumbs\.db|desktop\.ini)$/i.test(e);
function Kt(e) {
  const t = { accepted: [], unsupported: [], junk: 0 };
  for (const n of e) {
    if (we(n.path ?? n.name)) {
      t.junk++;
      continue;
    }
    const c = Ht(n);
    c ? t.accepted.push({ item: n, kind: c }) : t.unsupported.push(n);
  }
  return t;
}
const Xt = [
    ...ot,
    "heic",
    "heif",
    "pdf",
    "md",
    "html",
    "htm",
    "txt",
    "csv",
    "xls",
    "xlsx",
    "ppt",
    "pptx",
    "pps",
    "odp",
    "key",
    "doc",
    "docx",
    ...it,
    ...lt,
  ]
    .map((e) => `.${e}`)
    .join(","),
  He = (e) => e === "audio" || e === "video",
  ge = 300,
  Yt = {
    image: 4e7,
    heic: 4e7,
    pdf: 8e7,
    text: 2e7,
    excel: 3e7,
    csv: 5e7,
    powerpoint: 8e7,
    docx: 4e7,
    html: 2e7,
    markdown: 1e7,
    audio: 15e7,
    video: 2e8,
  },
  Qt = {
    image: 15e7,
    heic: 15e7,
    pdf: 3e8,
    text: 1e8,
    excel: 1e8,
    csv: 2e8,
    powerpoint: 25e7,
    docx: 15e7,
    html: 1e8,
    markdown: 5e7,
    audio: 200 * 1024 * 1024,
    video: 200 * 1024 * 1024,
  },
  Ge = 1e9,
  es = 15e8;
function ts(e, t) {
  return t > Qt[e] ? "refuse" : t > Yt[e] ? "warn" : "ok";
}
function L(e) {
  return !Number.isFinite(e) || e < 0
    ? ""
    : e < 1024
      ? `${e} B`
      : e < 1024 * 1024
        ? `${Math.max(1, Math.round(e / 1024))} KB`
        : e < 1024 ** 3
          ? `${(e / 1024 / 1024).toFixed(1)} MB`
          : `${(e / 1024 ** 3).toFixed(2)} GB`;
}
const Ie = "{name}",
  ss = /[\u0000-\u001f\u007f]/g,
  as = /[\\/:*?"<>|]/g;
function ns(e, t = "file") {
  const n = e
    .replace(ss, "")
    .replace(as, "-")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/^\.+/, "")
    .replace(/[. ]+$/, "");
  return (n.length > 150 ? n.slice(0, 150).trim() : n) || t;
}
const rs = (e) =>
  `${e.getFullYear()}-${String(e.getMonth() + 1).padStart(2, "0")}-${String(e.getDate()).padStart(2, "0")}`;
function ct(e, t) {
  const c = (e.trim() === "" ? Ie : e).replace(
    /\{(name|date|n)(?::(\d{1,2}))?\}/g,
    (r, i, u) =>
      i === "name"
        ? t.name
        : i === "date"
          ? rs(t.date)
          : String(t.n).padStart(u ? Math.min(8, Number(u)) : 0, "0"),
  );
  return `${ns(c, t.name || "file")}.${t.ext.replace(/^\./, "")}`;
}
const os = {
    jpg: "images",
    jpeg: "images",
    png: "images",
    webp: "images",
    avif: "images",
    gif: "images",
    bmp: "images",
    tiff: "images",
    ico: "images",
    pdf: "pdf",
    mp3: "audio",
    m4a: "audio",
    ogg: "audio",
    wav: "audio",
    flac: "audio",
    mp4: "video",
    webm: "video",
    mov: "video",
    mkv: "video",
    avi: "video",
    docx: "documents",
    pptx: "documents",
    odp: "documents",
    html: "documents",
    md: "documents",
    xlsx: "data",
    csv: "data",
    json: "data",
    txt: "text",
  },
  is = (e) => os[e.toLowerCase().replace(/^\./, "")] ?? "other";
function ls(e, t) {
  const n = (f) => f.toLowerCase();
  if (!t.has(n(e))) return (t.add(n(e)), e);
  const c = e.lastIndexOf("/"),
    o = c >= 0 ? e.slice(0, c + 1) : "",
    r = c >= 0 ? e.slice(c + 1) : e,
    i = r.lastIndexOf("."),
    u = i > 0 ? r.slice(0, i) : r,
    x = i > 0 ? r.slice(i) : "";
  for (let f = 2; ; f++) {
    const y = `${o}${u} (${f})${x}`;
    if (!t.has(n(y))) return (t.add(n(y)), y);
  }
}
function cs(e, t, n) {
  const c = new Set();
  return e.map((o) => {
    const r = (o.match(/\.([^./]+)$/) ?? [])[1] ?? "",
      i = t === "by-type" ? `${is(r)}/${o}` : o;
    return c.has(i.toLowerCase())
      ? n === "skip"
        ? { path: null, renamed: !1 }
        : { path: ls(i, c), renamed: !0 }
      : (c.add(i.toLowerCase()), { path: i, renamed: !1 });
  });
}
const ye = 1,
  ds = ".fdp-recipe.json",
  dt = 1e6,
  fe = 40,
  ut = 200,
  pt = ["convert", "edit", "rename", "zip"],
  Y = (e) => typeof e == "object" && e !== null && !Array.isArray(e);
function K(e = "My recipe") {
  return {
    name: e,
    steps: [...pt],
    rules: [],
    naming: { pattern: Ie, layout: "flat", collision: "number" },
  };
}
function _(e, t, n = {}) {
  const c = Ce(e, t);
  return {
    match: { kind: e, ...(n.exts && n.exts.length ? { exts: n.exts } : {}) },
    target: t,
    quality: { ...c.quality, ...n.quality },
    edit: { ...c.edit, ...n.edit },
  };
}
function me(e, t, n) {
  const c = n.toLowerCase().replace(/^\./, "");
  return (
    e.rules.find(
      (o) =>
        o.match.kind === t &&
        (!o.match.exts ||
          o.match.exts.length === 0 ||
          o.match.exts.includes(c)),
    ) ?? null
  );
}
const ie = (e, t, n = "flat") => ({
    ...e,
    naming: { ...e.naming, pattern: t, layout: n },
  }),
  us = [
    {
      id: "email-photos",
      blurb:
        "Phone and camera photos made small enough to attach: JPG, longest side 1600 px, quality 78.",
      recipe: ie(
        {
          ...K("Email-ready photos"),
          rules: [
            _("image", "jpg", {
              quality: { quality: 78, dpi: 72 },
              edit: { maxEdge: 1600 },
            }),
            _("heic", "jpg", {
              quality: { quality: 78, dpi: 72 },
              edit: { maxEdge: 1600 },
            }),
          ],
        },
        "{name}-email",
      ),
    },
    {
      id: "web-images",
      blurb:
        "Pictures for a website: WebP, longest side 2048 px, quality 80, no leftover camera data.",
      recipe: ie(
        {
          ...K("Web images"),
          rules: [
            _("image", "webp", {
              quality: { quality: 80 },
              edit: { maxEdge: 2048 },
            }),
            _("heic", "webp", {
              quality: { quality: 80 },
              edit: { maxEdge: 2048 },
            }),
          ],
        },
        "{name}",
        "flat",
      ),
    },
    {
      id: "office-pdf-packet",
      blurb:
        "Word, Excel, PowerPoint, text and HTML files to PDF, and pictures to PDF pages, in one ZIP.",
      recipe: ie(
        {
          ...K("Office to PDF packet"),
          rules: [
            _("docx", "pdf"),
            _("excel", "pdf"),
            _("powerpoint", "pdf"),
            _("csv", "pdf"),
            _("text", "pdf"),
            _("html", "pdf"),
            _("markdown", "pdf"),
            _("image", "pdf"),
            _("heic", "pdf"),
          ],
        },
        "{n:2}-{name}",
      ),
    },
    {
      id: "voice-memo-mp3",
      blurb:
        "Voice memos and recordings to MP3 at 128 kbps, loudness evened out.",
      recipe: ie(
        {
          ...K("Voice memo to MP3"),
          rules: [
            _("audio", "mp3", {
              quality: { bitrate: 128 },
              edit: { normalise: !0 },
            }),
            _("video", "x-mp3", {
              quality: { bitrate: 128 },
              edit: { normalise: !0 },
            }),
          ],
        },
        "{name}",
      ),
    },
    {
      id: "video-phone-mp4",
      blurb:
        "Videos to MP4 that play on any phone: 720 px tall, balanced quality.",
      recipe: ie(
        {
          ...K("Video to phone MP4"),
          rules: [_("video", "mp4", { quality: { resolution: 720, crf: 26 } })],
        },
        "{name}-phone",
      ),
    },
  ];
function ps(e) {
  const t = At(e);
  if (!t) return null;
  const n = _(t.kind, t.target, { exts: t.exts });
  return {
    ...K(`${e.from.toUpperCase()} to ${e.to.toUpperCase()}`),
    rules: [n],
  };
}
function mt(e, t = new Date()) {
  const n = {
    app: "freedailypro",
    kind: "conversion-recipe",
    version: ye,
    saved: t.toISOString(),
    recipe: e,
  };
  return JSON.stringify(n, null, 2);
}
const ms = (e) =>
    `${
      (e.name || "recipe")
        .replace(/[^a-z0-9._ -]+/gi, "-")
        .trim()
        .replace(/\s+/g, "-")
        .slice(0, 60) || "recipe"
    }${ds}`,
  _e = (e, t, n) =>
    typeof e == "string" && e.trim() ? e.trim().slice(0, t) : n;
function fs(e, t, n) {
  if (!Y(e) || !Y(e.match))
    return (t.push(`Rule ${n + 1} was skipped: it has no "match".`), null);
  const c = e.match.kind;
  if (typeof c != "string" || !rt.includes(c))
    return (
      t.push(
        `Rule ${n + 1} was skipped: "${String(c).slice(0, 30)}" is not a file kind the Studio knows.`,
      ),
      null
    );
  const o = c,
    r = typeof e.target == "string" ? e.target : "",
    i = ae(o, r);
  if (!i)
    return (
      t.push(
        `Rule ${n + 1} was skipped: ${o} files cannot become "${r.slice(0, 30)}" in the Studio.`,
      ),
      null
    );
  const u = Array.isArray(e.match.exts)
      ? e.match.exts
          .filter((f) => typeof f == "string" && /^[a-z0-9]{1,8}$/i.test(f))
          .map((f) => f.toLowerCase())
          .slice(0, 12)
      : [],
    x = Ce(o, i.id);
  return {
    match: { kind: o, ...(u.length ? { exts: u } : {}) },
    target: i.id,
    quality: { ...x.quality, ...at(e.quality, i) },
    edit: st(e.edit, i),
  };
}
function ft(e, t) {
  if (!Y(e)) return null;
  const n = Array.isArray(e.rules) ? e.rules.slice(0, fe) : [];
  Array.isArray(e.rules) &&
    e.rules.length > fe &&
    t.push(`Only the first ${fe} rules were loaded.`);
  const c = n.map((r, i) => fs(r, t, i)).filter((r) => r !== null),
    o = Y(e.naming) ? e.naming : {};
  return {
    name: _e(e.name, 80, "Imported recipe"),
    steps: [...pt],
    rules: c,
    naming: {
      pattern: _e(o.pattern, 120, Ie),
      layout: o.layout === "by-type" ? "by-type" : "flat",
      collision: o.collision === "skip" ? "skip" : "number",
    },
  };
}
function ht(e) {
  if (e.length > dt)
    return { ok: !1, error: "That file is too large to be a recipe." };
  let t;
  try {
    t = JSON.parse(e);
  } catch {
    return {
      ok: !1,
      error: "That file is not valid JSON, so it cannot be a recipe.",
    };
  }
  if (!Y(t) || t.app !== "freedailypro")
    return { ok: !1, error: "That is not a FreeDailyPro file." };
  if (t.kind !== "conversion-recipe")
    return {
      ok: !1,
      error:
        t.kind === "conversion-recipe-pack"
          ? "That is a recipe pack. Use Open pack to choose one recipe from it."
          : "That is a FreeDailyPro file, but not a conversion recipe.",
    };
  if (typeof t.version != "number" || t.version > ye)
    return {
      ok: !1,
      error:
        "That recipe was saved by a newer version of the Studio. Reload the page and try again.",
    };
  const n = [],
    c = ft(t.recipe, n);
  return c
    ? c.rules.length === 0
      ? { ok: !1, error: n[0] ?? "That recipe has no usable rules." }
      : { ok: !0, recipe: c, warnings: n }
    : { ok: !1, error: "That recipe file has no recipe inside." };
}
function hs(e, t = new Date()) {
  const n = {
    app: "freedailypro",
    kind: "conversion-recipe-pack",
    version: ye,
    saved: t.toISOString(),
    recipes: e.slice(0, ut),
  };
  return JSON.stringify(n, null, 2);
}
function gs(e) {
  if (e.length > dt * 5)
    return { ok: !1, error: "That file is too large to be a recipe pack." };
  let t;
  try {
    t = JSON.parse(e);
  } catch {
    return { ok: !1, error: "That file is not valid JSON." };
  }
  if (!Y(t) || t.app !== "freedailypro" || t.kind !== "conversion-recipe-pack")
    return { ok: !1, error: "That is not a conversion recipe pack." };
  if (typeof t.version != "number" || t.version > ye)
    return {
      ok: !1,
      error: "That pack was saved by a newer version of the Studio.",
    };
  if (!Array.isArray(t.recipes))
    return { ok: !1, error: "That pack has no recipes." };
  const n = [],
    c = [];
  for (const o of t.recipes.slice(0, ut)) {
    if (!Y(o)) continue;
    const r = ft(o.recipe, n);
    !r ||
      r.rules.length === 0 ||
      c.push({
        name: _e(o.name, 80, r.name),
        ranAt: typeof o.ranAt == "string" ? o.ranAt.slice(0, 40) : "",
        files:
          typeof o.files == "number" && Number.isFinite(o.files)
            ? Math.max(0, Math.round(o.files))
            : 0,
        recipe: r,
      });
  }
  return c.length === 0
    ? { ok: !1, error: "That pack has no usable recipes." }
    : { ok: !0, entries: c, warnings: n };
}
const M = "h-9 rounded-md border bg-background px-2 text-sm";
function xs({ rule: e, sample: t, onChange: n, onRemove: c }) {
  const o = e.match.kind,
    r = ae(o, e.target),
    i = (d) => r.options.includes(d),
    u = e.quality,
    x = e.edit,
    f = (d) => n({ ...e, quality: at({ ...u, ...d }, r) }),
    y = (d) => n({ ...e, edit: st({ ...x, ...d }, r) }),
    T = t
      ? Dt({
          kind: o,
          target: e.target,
          quality: u,
          edit: x,
          inBytes: t.size,
          inExt: (t.name.match(/\.([^.]+)$/) ?? [])[1] ?? "",
        })
      : null;
  return s.jsxs("li", {
    className: "rounded-xl border bg-card p-4 space-y-3",
    "data-testid": `rule-${o}`,
    children: [
      s.jsxs("div", {
        className: "flex flex-wrap items-end gap-3",
        children: [
          s.jsxs("div", {
            children: [
              s.jsx("p", {
                className: "text-xs font-medium text-muted-foreground mb-1",
                children: "When the file is",
              }),
              s.jsxs("p", {
                className: "h-9 flex items-center text-sm font-semibold",
                children: [
                  X[o],
                  e.match.exts?.length
                    ? s.jsxs("span", {
                        className: "ml-1 font-normal text-muted-foreground",
                        children: ["(.", e.match.exts.join(", ."), " only)"],
                      })
                    : null,
                ],
              }),
            ],
          }),
          s.jsxs("label", {
            className: "text-sm",
            children: [
              s.jsx("span", {
                className:
                  "block text-xs font-medium text-muted-foreground mb-1",
                children: "Convert to",
              }),
              s.jsx("select", {
                className: M,
                "aria-label": `Convert ${X[o]} files to`,
                value: e.target,
                onChange: (d) => {
                  const $ = Ce(o, d.target.value);
                  n({
                    ...e,
                    target: d.target.value,
                    quality: $.quality,
                    edit: $.edit,
                  });
                },
                children: nt(o).map((d) =>
                  s.jsx("option", { value: d.id, children: d.label }, d.id),
                ),
              }),
            ],
          }),
          s.jsxs(N, {
            variant: "ghost",
            size: "sm",
            onClick: c,
            "aria-label": `Remove the rule for ${X[o]} files`,
            className: "ml-auto",
            children: [s.jsx(Pe, { className: "h-4 w-4 mr-1" }), "Remove"],
          }),
        ],
      }),
      r.options.length > 0 &&
        s.jsxs("div", {
          className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3 border-t pt-3",
          children: [
            i("quality") &&
              s.jsxs("label", {
                className: "text-sm",
                children: [
                  s.jsxs("span", {
                    className:
                      "block text-xs font-medium text-muted-foreground mb-1",
                    children: ["Picture quality: ", u.quality ?? 85],
                  }),
                  s.jsx("input", {
                    type: "range",
                    min: 30,
                    max: 100,
                    value: u.quality ?? 85,
                    onChange: (d) => f({ quality: Number(d.target.value) }),
                    "aria-label": "Picture quality",
                    className: "w-full",
                  }),
                ],
              }),
            i("maxEdge") &&
              s.jsxs("label", {
                className: "text-sm",
                children: [
                  s.jsx("span", {
                    className:
                      "block text-xs font-medium text-muted-foreground mb-1",
                    children: "Edit: longest side",
                  }),
                  s.jsx("select", {
                    className: M,
                    "aria-label": "Longest side in pixels",
                    value: x.maxEdge ?? 0,
                    onChange: (d) => y({ maxEdge: Number(d.target.value) }),
                    children: Ot.map((d) =>
                      s.jsx(
                        "option",
                        {
                          value: d,
                          children:
                            d === 0
                              ? "Keep the size"
                              : `${d} px (never enlarged)`,
                        },
                        d,
                      ),
                    ),
                  }),
                ],
              }),
            i("dpi") &&
              s.jsxs("label", {
                className: "text-sm",
                children: [
                  s.jsx("span", {
                    className:
                      "block text-xs font-medium text-muted-foreground mb-1",
                    children: "Print resolution",
                  }),
                  s.jsxs("select", {
                    className: M,
                    "aria-label": "Print resolution in dots per inch",
                    value: u.dpi ?? 0,
                    onChange: (d) =>
                      f({ dpi: Number(d.target.value) || void 0 }),
                    children: [
                      s.jsx("option", { value: 0, children: "Leave as is" }),
                      [72, 96, 150, 300, 600].map((d) =>
                        s.jsxs(
                          "option",
                          { value: d, children: [d, " dpi"] },
                          d,
                        ),
                      ),
                    ],
                  }),
                ],
              }),
            i("grayscale") &&
              s.jsxs("label", {
                className: "flex items-center gap-2 text-sm self-end h-9",
                children: [
                  s.jsx("input", {
                    type: "checkbox",
                    checked: !!x.grayscale,
                    onChange: (d) => y({ grayscale: d.target.checked }),
                  }),
                  "Edit: black and white",
                ],
              }),
            i("pageSize") &&
              s.jsxs("label", {
                className: "text-sm",
                children: [
                  s.jsx("span", {
                    className:
                      "block text-xs font-medium text-muted-foreground mb-1",
                    children: "PDF page size",
                  }),
                  s.jsxs("select", {
                    className: M,
                    "aria-label": "PDF page size",
                    value: u.pageSize ?? "a4",
                    onChange: (d) => f({ pageSize: d.target.value }),
                    children: [
                      s.jsx("option", { value: "a4", children: "A4" }),
                      s.jsx("option", {
                        value: "letter",
                        children: "US Letter",
                      }),
                    ],
                  }),
                ],
              }),
            i("pdfLevel") &&
              s.jsxs("label", {
                className: "text-sm sm:col-span-2",
                children: [
                  s.jsx("span", {
                    className:
                      "block text-xs font-medium text-muted-foreground mb-1",
                    children: "How small",
                  }),
                  s.jsx("select", {
                    className: `${M} w-full`,
                    "aria-label": "PDF shrink level",
                    value: u.pdfLevel ?? "balanced",
                    onChange: (d) => f({ pdfLevel: d.target.value }),
                    children: Bt.map((d) =>
                      s.jsx("option", { value: d.id, children: d.label }, d.id),
                    ),
                  }),
                ],
              }),
            i("bitrate") &&
              s.jsxs("label", {
                className: "text-sm",
                children: [
                  s.jsx("span", {
                    className:
                      "block text-xs font-medium text-muted-foreground mb-1",
                    children: "Bitrate",
                  }),
                  s.jsxs("select", {
                    className: M,
                    "aria-label": "Audio bitrate",
                    value: u.bitrate ?? 0,
                    onChange: (d) => f({ bitrate: Number(d.target.value) }),
                    children: [
                      s.jsx("option", {
                        value: 0,
                        children: "Standard for the format",
                      }),
                      Ft.map((d) =>
                        s.jsxs(
                          "option",
                          { value: d, children: [d, " kbps"] },
                          d,
                        ),
                      ),
                    ],
                  }),
                ],
              }),
            i("normalise") &&
              s.jsxs("label", {
                className: "flex items-center gap-2 text-sm self-end h-9",
                children: [
                  s.jsx("input", {
                    type: "checkbox",
                    checked: !!x.normalise,
                    onChange: (d) => y({ normalise: d.target.checked }),
                  }),
                  "Edit: even out loudness",
                ],
              }),
            i("resolution") &&
              s.jsxs("label", {
                className: "text-sm",
                children: [
                  s.jsx("span", {
                    className:
                      "block text-xs font-medium text-muted-foreground mb-1",
                    children: "Tallest picture",
                  }),
                  s.jsx("select", {
                    className: M,
                    "aria-label": "Video height in pixels",
                    value: u.resolution ?? 0,
                    onChange: (d) => f({ resolution: Number(d.target.value) }),
                    children: Lt.map((d) =>
                      s.jsx(
                        "option",
                        {
                          value: d,
                          children:
                            d === 0
                              ? "Keep the size"
                              : `${d} px (never enlarged)`,
                        },
                        d,
                      ),
                    ),
                  }),
                ],
              }),
            i("crf") &&
              s.jsxs("label", {
                className: "text-sm",
                children: [
                  s.jsxs("span", {
                    className:
                      "block text-xs font-medium text-muted-foreground mb-1",
                    children: [
                      "Video quality: ",
                      u.crf ?? 23,
                      " (lower is better and larger)",
                    ],
                  }),
                  s.jsx("input", {
                    type: "range",
                    min: 18,
                    max: 32,
                    value: u.crf ?? 23,
                    onChange: (d) => f({ crf: Number(d.target.value) }),
                    "aria-label": "Video quality, lower is better",
                    className: "w-full",
                  }),
                ],
              }),
          ],
        }),
      t &&
        T &&
        s.jsxs("p", {
          className: "text-xs text-muted-foreground",
          "data-testid": `estimate-${o}`,
          children: [
            "About ",
            L(T.bytes),
            " for a file like ",
            t.name,
            " (",
            L(t.size),
            "). ",
            T.note,
          ],
        }),
    ],
  });
}
function bs({
  recipe: e,
  setRecipe: t,
  samples: n,
  kindsPresent: c,
  history: o,
  setHistory: r,
  disabled: i,
  firstName: u,
}) {
  const x = b.useRef(null),
    f = b.useRef(null),
    y = c.filter((l) => !e.rules.some((p) => p.match.kind === l)),
    T = rt.filter((l) => !e.rules.some((p) => p.match.kind === l)),
    d = (l, p) => t({ ...e, rules: e.rules.map((g, I) => (I === l ? p : g)) }),
    $ = (l) => {
      e.rules.length >= fe ||
        t({ ...e, rules: [...e.rules, _(l, nt(l)[0].id)] });
    },
    S = ct(e.naming.pattern, {
      name: (u ?? "IMG_0042").replace(/\.[^.]+$/, ""),
      n: 1,
      date: new Date(),
      ext: "jpg",
    }),
    P = async (l, p) =>
      l
        ? l.size > p
          ? (D.error("That file is too large to be a recipe."), null)
          : l.text()
        : null;
  return s.jsxs("section", {
    className: "rounded-2xl border bg-card p-5 space-y-5",
    "aria-label": "Recipe",
    "data-testid": "studio-recipe",
    children: [
      s.jsxs("div", {
        className: "flex flex-wrap items-end gap-3",
        children: [
          s.jsxs("label", {
            className: "text-sm grow min-w-[12rem]",
            children: [
              s.jsx("span", {
                className:
                  "block text-xs font-medium text-muted-foreground mb-1",
                children: "Recipe name",
              }),
              s.jsx("input", {
                className: `${M} w-full`,
                "aria-label": "Recipe name",
                maxLength: 80,
                value: e.name,
                disabled: i,
                onChange: (l) => t({ ...e, name: l.target.value }),
              }),
            ],
          }),
          s.jsx(N, {
            variant: "outline",
            size: "sm",
            disabled: e.rules.length === 0,
            onClick: () =>
              se(new Blob([mt(e)], { type: "application/json" }), ms(e), {
                free: !0,
              }),
            children: "Save recipe",
          }),
          s.jsx(N, {
            variant: "outline",
            size: "sm",
            disabled: i,
            onClick: () => x.current?.click(),
            children: "Open recipe",
          }),
          s.jsx("input", {
            ref: x,
            type: "file",
            accept: ".json,application/json",
            className: "sr-only",
            "aria-label": "Open a recipe file",
            tabIndex: -1,
            onChange: async (l) => {
              const p = await P(l.target.files?.[0], 1e6);
              if (((l.target.value = ""), p === null)) return;
              const g = ht(p);
              if (!g.ok) {
                D.error(g.error);
                return;
              }
              (t(g.recipe),
                D.success(
                  g.warnings.length
                    ? `Recipe opened. ${g.warnings[0]}`
                    : "Recipe opened.",
                ));
            },
          }),
        ],
      }),
      s.jsxs("div", {
        children: [
          s.jsx("p", {
            className: "text-xs font-medium text-muted-foreground mb-2",
            children: "Starter recipes",
          }),
          s.jsx("div", {
            className: "flex flex-wrap gap-2",
            children: us.map((l) =>
              s.jsx(
                N,
                {
                  variant: "outline",
                  size: "sm",
                  disabled: i,
                  title: l.blurb,
                  onClick: () => t(l.recipe),
                  "data-testid": `starter-${l.id}`,
                  children: l.recipe.name,
                },
                l.id,
              ),
            ),
          }),
        ],
      }),
      y.length > 0 &&
        s.jsxs(ce, {
          testId: "studio-missing-rules",
          children: [
            s.jsxs("p", {
              className: "text-sm",
              children: [
                "No rule yet for: ",
                y.map((l) => X[l]).join(", "),
                ". Those files are skipped until you add one.",
              ],
            }),
            s.jsx("div", {
              className: "mt-2 flex flex-wrap gap-2",
              children: y.map((l) =>
                s.jsxs(
                  N,
                  {
                    size: "sm",
                    variant: "outline",
                    disabled: i,
                    onClick: () => $(l),
                    children: [
                      s.jsx(Rt, { className: "h-3.5 w-3.5 mr-1" }),
                      "Add rule for ",
                      X[l],
                    ],
                  },
                  l,
                ),
              ),
            }),
          ],
        }),
      s.jsx("ul", {
        className: "space-y-3",
        children: e.rules.map((l, p) =>
          s.jsx(
            xs,
            {
              rule: l,
              sample: n[l.match.kind],
              onChange: (g) => d(p, g),
              onRemove: () =>
                t({ ...e, rules: e.rules.filter((g, I) => I !== p) }),
            },
            `${l.match.kind}-${p}`,
          ),
        ),
      }),
      e.rules.length === 0 &&
        s.jsx("p", {
          className: "text-sm text-muted-foreground",
          children:
            "Pick a starter recipe, open a saved one, or add a rule for a kind of file.",
        }),
      T.length > 0 &&
        s.jsxs("label", {
          className: "text-sm inline-flex items-center gap-2",
          children: [
            "Add a rule for",
            s.jsxs("select", {
              className: M,
              "aria-label": "Add a rule for a kind of file",
              value: "",
              disabled: i,
              onChange: (l) => {
                l.target.value && $(l.target.value);
              },
              children: [
                s.jsx("option", {
                  value: "",
                  children: "Choose a kind of file",
                }),
                T.map((l) => s.jsx("option", { value: l, children: X[l] }, l)),
              ],
            }),
          ],
        }),
      s.jsxs("div", {
        className: "grid gap-3 sm:grid-cols-3 border-t pt-4",
        children: [
          s.jsxs("label", {
            className: "text-sm sm:col-span-3",
            children: [
              s.jsxs("span", {
                className:
                  "block text-xs font-medium text-muted-foreground mb-1",
                children: [
                  "Rename: pattern (use ",
                  "{name}",
                  ", ",
                  "{date}",
                  ", ",
                  "{n}",
                  " or ",
                  "{n:3}",
                  ")",
                ],
              }),
              s.jsx("input", {
                className: `${M} w-full font-mono`,
                "aria-label": "File name pattern",
                maxLength: 120,
                value: e.naming.pattern,
                disabled: i,
                onChange: (l) =>
                  t({ ...e, naming: { ...e.naming, pattern: l.target.value } }),
              }),
              s.jsxs("span", {
                className: "block mt-1 text-xs text-muted-foreground",
                children: ["Example: ", S],
              }),
            ],
          }),
          s.jsxs("label", {
            className: "text-sm",
            children: [
              s.jsx("span", {
                className:
                  "block text-xs font-medium text-muted-foreground mb-1",
                children: "ZIP layout",
              }),
              s.jsxs("select", {
                className: `${M} w-full`,
                "aria-label": "ZIP layout",
                value: e.naming.layout,
                disabled: i,
                onChange: (l) =>
                  t({ ...e, naming: { ...e.naming, layout: l.target.value } }),
                children: [
                  s.jsx("option", {
                    value: "flat",
                    children: "All files in one folder",
                  }),
                  s.jsx("option", {
                    value: "by-type",
                    children: "Folders by type (images, pdf, audio ...)",
                  }),
                ],
              }),
            ],
          }),
          s.jsxs("label", {
            className: "text-sm",
            children: [
              s.jsx("span", {
                className:
                  "block text-xs font-medium text-muted-foreground mb-1",
                children: "If two files get the same name",
              }),
              s.jsxs("select", {
                className: `${M} w-full`,
                "aria-label": "Same-name handling",
                value: e.naming.collision,
                disabled: i,
                onChange: (l) =>
                  t({
                    ...e,
                    naming: { ...e.naming, collision: l.target.value },
                  }),
                children: [
                  s.jsx("option", {
                    value: "number",
                    children: "Number the later one: name (2)",
                  }),
                  s.jsx("option", {
                    value: "skip",
                    children: "Leave the later one out",
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
      s.jsxs("div", {
        className: "border-t pt-4",
        "data-testid": "studio-history",
        children: [
          s.jsxs("div", {
            className: "flex flex-wrap items-center gap-2",
            children: [
              s.jsxs("p", {
                className: "text-xs font-medium text-muted-foreground mr-auto",
                children: [
                  "This visit's recipes (",
                  o.length,
                  "). Kept in this tab only; save the pack to keep them.",
                ],
              }),
              s.jsx(N, {
                variant: "outline",
                size: "sm",
                disabled: o.length === 0,
                onClick: () =>
                  se(
                    new Blob([hs(o)], { type: "application/json" }),
                    "studio-session.fdp-recipe-pack.json",
                    { free: !0 },
                  ),
                children: "Download recipe pack",
              }),
              s.jsx(N, {
                variant: "outline",
                size: "sm",
                disabled: i,
                onClick: () => f.current?.click(),
                children: "Open pack",
              }),
              s.jsx("input", {
                ref: f,
                type: "file",
                accept: ".json,application/json",
                className: "sr-only",
                "aria-label": "Open a recipe pack file",
                tabIndex: -1,
                onChange: async (l) => {
                  const p = await P(l.target.files?.[0], 5e6);
                  if (((l.target.value = ""), p === null)) return;
                  const g = gs(p);
                  if (!g.ok) {
                    D.error(g.error);
                    return;
                  }
                  (r([...g.entries, ...o].slice(0, 200)),
                    D.success(
                      `${g.entries.length} recipe${g.entries.length === 1 ? "" : "s"} added below.`,
                    ));
                },
              }),
            ],
          }),
          o.length > 0 &&
            s.jsx("ul", {
              className: "mt-2 space-y-1 text-sm",
              children: o
                .slice(0, 8)
                .map((l, p) =>
                  s.jsxs(
                    "li",
                    {
                      className: "flex items-center gap-2",
                      children: [
                        s.jsxs("span", {
                          className: "truncate",
                          children: [
                            l.name,
                            l.files
                              ? `, ${l.files} file${l.files === 1 ? "" : "s"}`
                              : "",
                            l.ranAt
                              ? `, ${new Date(l.ranAt).toLocaleString()}`
                              : "",
                          ],
                        }),
                        s.jsx(N, {
                          variant: "ghost",
                          size: "sm",
                          className: "ml-auto",
                          disabled: i,
                          onClick: () => t(l.recipe),
                          "aria-label": `Use the recipe ${l.name}`,
                          children: "Use",
                        }),
                      ],
                    },
                    `${l.ranAt}-${p}`,
                  ),
                ),
            }),
        ],
      }),
    ],
  });
}
const gt = 10,
  xt = 5e3,
  ws = () => typeof window < "u" && "showDirectoryPicker" in window;
async function bt(e, t, n, c, o) {
  if (n.seen++ > xt || t.length >= ge) {
    n.capped = !0;
    return;
  }
  const r = o + e.name;
  if (!we(r)) {
    if (e.isFile && e.file) {
      const i = await new Promise((u, x) => e.file(u, x));
      t.push({ file: i, path: r });
    } else if (e.isDirectory && e.createReader && c < gt) {
      const i = e.createReader();
      for (;;) {
        const u = await new Promise((x, f) => i.readEntries(x, f));
        if (u.length === 0) break;
        for (const x of u) await bt(x, t, n, c + 1, `${r}/`);
        if (n.capped) break;
      }
    }
  }
}
async function ys(e) {
  const t = [],
    n = { seen: 0, capped: !1 },
    c = Array.from(e.items ?? []),
    o = c.map((r) =>
      typeof r.webkitGetAsEntry == "function" ? r.webkitGetAsEntry() : null,
    );
  if (c.length > 0 && o.every((r) => r))
    for (const r of o) await bt(r, t, n, 0, "");
  else for (const r of Array.from(e.files)) t.push({ file: r, path: r.name });
  return { files: t, capped: n.capped };
}
function Ke(e) {
  return Array.from(e ?? [])
    .map((t) => ({ file: t, path: t.webkitRelativePath || t.name }))
    .filter((t) => !we(t.path));
}
async function wt(e, t, n, c, o) {
  for await (const r of e.values()) {
    if (n.seen++ > xt || t.length >= ge) {
      n.capped = !0;
      return;
    }
    const i = o + r.name;
    we(i) ||
      (r.kind === "file"
        ? t.push({ file: await r.getFile(), path: i })
        : c < gt && (await wt(r, t, n, c + 1, `${i}/`)));
  }
}
async function vs() {
  try {
    const e = await window.showDirectoryPicker({ mode: "read" }),
      t = [],
      n = { seen: 0, capped: !1 };
    return (await wt(e, t, n, 0, `${e.name}/`), { files: t, capped: n.capped });
  } catch (e) {
    if (e instanceof DOMException && e.name === "AbortError") return null;
    throw e;
  }
}
function js(e, t) {
  const n = [...e],
    c = new Map(),
    o = new AbortController();
  let r = !1,
    i = !1,
    u = 0,
    x = 0,
    f = 0,
    y;
  const T = new Promise((l) => {
      y = l;
    }),
    d = Math.max(1, Math.floor(t.concurrency)),
    $ = () => {
      n.length === 0 && u + x === 0 && y(c);
    },
    S = () => {
      if (i) {
        for (; n.length;) {
          const l = n.shift();
          (c.set(l.id, "stopped"), t.onEnd?.(l, "stopped"));
        }
        $();
        return;
      }
      if (!r)
        for (let l = 0; l < n.length;) {
          const p = n[l],
            g = p.lane === "media" ? x < 1 : u < d,
            I = u + x,
            J = I === 0 || f + p.bytes <= t.maxInFlightBytes;
          if (!g || !J) {
            l++;
            continue;
          }
          if (t.canStart && !t.canStart(p)) {
            if (I === 0) {
              (n.splice(l, 1), c.set(p.id, "held"), t.onEnd?.(p, "held"));
              continue;
            }
            l++;
            continue;
          }
          (n.splice(l, 1),
            p.lane === "media" ? x++ : u++,
            (f += p.bytes),
            t.onStart?.(p),
            t.run(p, o.signal).then(
              () => P(p, "done"),
              (Q) => P(p, o.signal.aborted ? "stopped" : "error", Q),
            ));
        }
      $();
    },
    P = (l, p, g) => {
      (l.lane === "media" ? x-- : u--,
        (f -= l.bytes),
        c.set(l.id, p),
        t.onEnd?.(l, p, g),
        S());
    };
  return (
    Promise.resolve().then(S),
    {
      done: T,
      pause() {
        r = !0;
      },
      resume() {
        ((r = !1), Promise.resolve().then(S));
      },
      stop() {
        ((i = !0), o.abort(), Promise.resolve().then(S));
      },
      get paused() {
        return r;
      },
      get running() {
        return u + x;
      },
    }
  );
}
const ks = [
  "File",
  "From",
  "To",
  "Size in (bytes)",
  "Size out (bytes)",
  "Change",
  "Status",
  "Warnings",
  "Seconds",
  "Output files",
];
function he(e, t) {
  if (!(e > 0) || !(t > 0)) return "";
  const n = Math.round((t / e - 1) * 100);
  return n === 0 ? "0%" : `${n > 0 ? "+" : ""}${n}%`;
}
function Ns(e) {
  const t = e.map((n) => [
    n.file,
    n.from,
    n.to,
    n.inBytes,
    n.outBytes || "",
    he(n.inBytes, n.outBytes),
    n.status,
    n.warnings.join("; "),
    Math.round(n.seconds * 10) / 10,
    n.outputs.join("; "),
  ]);
  return Vt([ks, ...t]);
}
function Ss(e, t, n = new Date()) {
  const c = (o) => t.filter((r) => r.status === o).length;
  return {
    app: "freedailypro",
    kind: "conversion-log",
    version: 1,
    saved: n.toISOString(),
    recipe: e,
    totals: {
      files: t.length,
      done: c("done"),
      warnings: c("warning"),
      skipped: c("skipped"),
      failed: c("error"),
      stopped: c("stopped") + c("held") + c("waiting"),
      inBytes: t.reduce((o, r) => o + r.inBytes, 0),
      outBytes: t.reduce((o, r) => o + r.outBytes, 0),
    },
    rows: t,
  };
}
const Es = "loudnorm=I=-16:TP=-1.5:LRA=11";
function Ts(e, t, n) {
  const c = t && t > 0 ? `${Math.round(t)}k` : "";
  let o;
  switch (e) {
    case "mp3":
      o = c
        ? ["-c:a", "libmp3lame", "-b:a", c]
        : ["-c:a", "libmp3lame", "-q:a", "2"];
      break;
    case "m4a":
      o = ["-c:a", "aac", "-b:a", c || "192k"];
      break;
    case "ogg":
      o = c
        ? ["-c:a", "libvorbis", "-b:a", c]
        : ["-c:a", "libvorbis", "-q:a", "5"];
      break;
    case "wav":
      o = ["-c:a", "pcm_s16le"];
      break;
    case "flac":
      o = ["-c:a", "flac"];
      break;
    default:
      throw new Error(`Unknown audio format: ${e}`);
  }
  return n ? ["-af", Es, ...o] : o;
}
const $s = (e, t) => !(e && e > 0) && (t === void 0 || t === 23);
function Ps(e, t, n, c) {
  const o = n && n > 0 ? Math.round(n) : 0,
    r = o ? `scale=-2:'min(${o},ih)'` : "scale=trunc(iw/2)*2:trunc(ih/2)*2",
    i = Math.min(36, Math.max(14, Math.round(c ?? 23)));
  return [
    "-i",
    e,
    "-vf",
    r,
    "-c:v",
    "libx264",
    "-preset",
    "veryfast",
    "-crf",
    String(i),
    "-pix_fmt",
    "yuv420p",
    "-c:a",
    "aac",
    "-b:a",
    "128k",
    "-movflags",
    "+faststart",
    t,
  ];
}
class xe extends Error {
  constructor(t) {
    (super(t), (this.name = "SkippedError"));
  }
}
const ve = (e) => e.replace(/\.[^.]+$/, ""),
  je = (e) => (e.match(/\.([^./]+)$/) ?? [])[1]?.toLowerCase() ?? "",
  V = (e) => ve(e.name),
  Xe = {
    mp3: "audio/mpeg",
    m4a: "audio/mp4",
    ogg: "audio/ogg",
    wav: "audio/wav",
    flac: "audio/flac",
    mp4: "video/mp4",
    webm: "video/webm",
    mov: "video/quicktime",
    mkv: "video/x-matroska",
    avi: "video/x-msvideo",
  },
  Ye = {
    jpg: "jpeg",
    png: "png",
    webp: "webp",
    avif: "avif",
    gif: "gif",
    bmp: "bmp",
    tiff: "tiff",
    ico: "ico",
  };
async function _s(e) {
  const { default: t } = await z(
      async () => {
        const { default: r } = await import("./jszip.min-CT0ZA6V1.js").then(
          (i) => i.j,
        );
        return { default: r };
      },
      __vite__mapDeps([0, 1, 2, 3]),
    ),
    n = await t.loadAsync(e),
    c = Object.values(n.files)
      .filter((r) => !r.dir)
      .sort((r, i) => r.name.localeCompare(i.name, void 0, { numeric: !0 })),
    o = [];
  for (const r of c) {
    const i = r.name.split("/").pop() ?? r.name,
      u = je(i) || "jpg";
    o.push({
      blob: new Blob([await r.async("arraybuffer")], {
        type: u === "png" ? "image/png" : "image/jpeg",
      }),
      stem: ve(i),
      ext: u,
    });
  }
  return o;
}
async function Cs(e, t, n, c) {
  const o = n.target,
    r = n.edit,
    i = n.quality,
    u = [],
    x =
      r.maxEdge && r.maxEdge > 0 ? { width: r.maxEdge, height: r.maxEdge } : {};
  if (Ye[o]) {
    const { parseConvertOptions: d } = await z(async () => {
        const { parseConvertOptions: l } =
          await import("./convertCore-pdjQ6UTb.js");
        return { parseConvertOptions: l };
      }, []),
      { convertImageInBrowser: $ } = await z(
        async () => {
          const { convertImageInBrowser: l } =
            await import("./convertBrowser-CYvv7SBJ.js");
          return { convertImageInBrowser: l };
        },
        __vite__mapDeps([4, 5, 6, 1, 7, 8, 9, 10, 11]),
      ),
      S = d({
        format: Ye[o],
        fit: "inside",
        withoutEnlargement: !0,
        autoOrient: !0,
        stripMetadata: !0,
        grayscale: !!r.grayscale,
        ...(i.quality ? { quality: i.quality } : {}),
        ...(i.dpi ? { dpi: i.dpi } : {}),
        ...x,
      });
    if (!S.ok) throw new Error(S.error);
    if (c.aborted) throw new Error("stopped");
    const P = await $(e, S.options);
    return (
      o === "gif" &&
        /\.gif$/i.test(e.name) &&
        u.push("Only the first frame of an animated GIF is kept."),
      {
        outputs: [{ blob: P, stem: V(e), ext: o === "jpg" ? "jpg" : o }],
        warnings: u,
      }
    );
  }
  if (o === "pdf") {
    const { convertImagesToPdf: d } = await z(
      async () => {
        const { convertImagesToPdf: P } =
          await import("./operations-B4LtHhm8.js").then((l) => l.Z);
        return { convertImagesToPdf: P };
      },
      __vite__mapDeps([
        12, 6, 1, 7, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 0, 2, 3,
        25, 26, 27, 28, 29, 11, 5, 30, 31, 32,
      ]),
    );
    let $ = e;
    if (
      t === "heic" ||
      r.maxEdge ||
      r.grayscale ||
      /\.(avif|tiff?|bmp|svg)$/i.test(e.name)
    ) {
      const { parseConvertOptions: P } = await z(async () => {
          const { parseConvertOptions: g } =
            await import("./convertCore-pdjQ6UTb.js");
          return { parseConvertOptions: g };
        }, []),
        { convertImageInBrowser: l } = await z(
          async () => {
            const { convertImageInBrowser: g } =
              await import("./convertBrowser-CYvv7SBJ.js");
            return { convertImageInBrowser: g };
          },
          __vite__mapDeps([4, 5, 6, 1, 7, 8, 9, 10, 11]),
        ),
        p = P({
          format: "jpeg",
          quality: 92,
          fit: "inside",
          withoutEnlargement: !0,
          grayscale: !!r.grayscale,
          ...x,
        });
      if (!p.ok) throw new Error(p.error);
      $ = new File([await l(e, p.options)], `${V(e)}.jpg`, {
        type: "image/jpeg",
      });
    }
    return {
      outputs: [
        { blob: await d([$], i.pageSize ?? "a4"), stem: V(e), ext: "pdf" },
      ],
      warnings: u,
    };
  }
  const { TARGETS_BY_KIND: f } = await z(
      async () => {
        const { TARGETS_BY_KIND: d } =
          await import("./universalCore-DlMOBYC5.js");
        return { TARGETS_BY_KIND: d };
      },
      __vite__mapDeps([
        33, 6, 1, 7, 34, 35, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24,
        0, 2, 3, 25, 26, 27, 28, 29, 11, 5, 30, 31, 32, 36, 10, 37, 38, 39, 40,
        41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58,
        59,
      ]),
    ),
    y = f[t === "heic" ? "heic" : "image"].find((d) => d.id === o);
  if (!y) throw new Error(`The Studio cannot make "${o}" from a picture.`);
  const T = await y.run(e);
  if ("skipped" in T) throw new xe(T.reason);
  return {
    outputs: [{ blob: T.blob, stem: ve(T.fileName), ext: je(T.fileName) }],
    warnings: u,
  };
}
async function Is(e, t, n) {
  const { compressPdf: c } = await z(
      async () => {
        const { compressPdf: u } =
          await import("./operations-B4LtHhm8.js").then((x) => x.Z);
        return { compressPdf: u };
      },
      __vite__mapDeps([
        12, 6, 1, 7, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 0, 2, 3,
        25, 26, 27, 28, 29, 11, 5, 30, 31, 32,
      ]),
    ),
    o = t.quality.pdfLevel ?? "balanced",
    r = await c(e, o, { shouldStop: () => n.aborted });
  if (n.aborted) throw new Error("stopped");
  if (r.status === "unchanged")
    return {
      outputs: [{ blob: e, stem: V(e), ext: "pdf" }],
      warnings: ["Could not be made smaller; the original is kept."],
    };
  if (r.size >= e.size)
    return {
      outputs: [{ blob: e, stem: V(e), ext: "pdf" }],
      warnings: ["The result was not smaller; the original is kept."],
    };
  const i = [];
  return (
    r.method === "pictures" &&
      i.push("Some pages were turned into pictures to reach this size."),
    {
      outputs: [
        {
          blob: new Blob([new Uint8Array(r.bytes)], {
            type: "application/pdf",
          }),
          stem: V(e),
          ext: "pdf",
        },
      ],
      warnings: i,
    }
  );
}
async function As(e, t, n) {
  const { TARGETS_BY_KIND: c } = await z(
      async () => {
        const { TARGETS_BY_KIND: u } =
          await import("./universalCore-DlMOBYC5.js");
        return { TARGETS_BY_KIND: u };
      },
      __vite__mapDeps([
        33, 6, 1, 7, 34, 35, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24,
        0, 2, 3, 25, 26, 27, 28, 29, 11, 5, 30, 31, 32, 36, 10, 37, 38, 39, 40,
        41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58,
        59,
      ]),
    ),
    o = c[t]?.find((u) => u.id === n.target);
  if (!o)
    throw new Error(
      `The Studio cannot make "${n.target}" from this kind of file.`,
    );
  const r = await o.run(e);
  if ("skipped" in r) throw new xe(r.reason);
  const i = je(r.fileName);
  if (i === "zip") {
    const u = await _s(r.blob);
    if (u.length > 0)
      return {
        outputs: u,
        warnings: u.length > 1 ? [`${u.length} pictures were made.`] : [],
      };
  }
  return {
    outputs: [
      {
        blob: r.blob,
        stem: ve(r.fileName),
        ext: i || (ae(t, n.target)?.ext ?? "bin"),
      },
    ],
    warnings: [],
  };
}
async function Rs(e, t, n, c, o) {
  const r = await z(() => import("./ffmpegEngine-DH91Xnxx.js"), []),
    i = await r.loadFFmpeg(),
    u = [],
    f = `input.${je(e.name) || (t === "audio" ? "mp3" : "mp4")}`;
  try {
    await i.writeFile(f, await r.fetchFile(e));
    const y = await r.probeMedia(i, f).catch(() => null),
      T = y && y.duration > 0 ? y.duration : void 0,
      d = n.target,
      $ = t === "video" && d.startsWith("x-");
    if (t === "audio" || $) {
      const g = $ ? d.slice(2) : d;
      if (y && !y.hasAudio)
        throw new Error(
          t === "video"
            ? "This video has no sound track, so there is nothing to extract."
            : "Could not read any sound in this file.",
        );
      const { convertAudioFormat: I } = await z(
          async () => {
            const { convertAudioFormat: Q } =
              await import("./operations-DLxdtd8A.js").then((W) => W.K);
            return { convertAudioFormat: Q };
          },
          __vite__mapDeps([60, 61, 62]),
        ),
        J = await I(
          i,
          f,
          `output.${g}`,
          Ts(g, n.quality.bitrate, !!n.edit.normalise),
          o,
          c,
          T,
        );
      return {
        outputs: [
          {
            blob: r.ffmpegOutputToBlob(J, Xe[g] ?? "audio/mpeg"),
            stem: V(e),
            ext: g,
          },
        ],
        warnings: u,
      };
    }
    if (d === "mp4" && !$s(n.quality.resolution, n.quality.crf)) {
      await r.execWithProgress(
        i,
        Ps(f, "output.mp4", n.quality.resolution, n.quality.crf),
        o,
        c,
        T,
      );
      const g = await i.readFile("output.mp4");
      return {
        outputs: [
          {
            blob: r.ffmpegOutputToBlob(g, "video/mp4"),
            stem: V(e),
            ext: "mp4",
          },
        ],
        warnings: u,
      };
    }
    const { convertVideoFormat: S } = await z(
        async () => {
          const { convertVideoFormat: g } =
            await import("./operations-P8Ty5WBe.js").then((I) => I.o);
          return { convertVideoFormat: g };
        },
        __vite__mapDeps([63, 64, 65, 61]),
      ),
      { data: P, rewrapped: l } = await S(i, f, `output.${d}`, d, o, c);
    l && u.push("Repackaged without re-encoding, so quality is unchanged.");
    const p = ae("video", d)?.ext ?? d;
    return {
      outputs: [
        {
          blob: r.ffmpegOutputToBlob(P, Xe[p] ?? "video/mp4"),
          stem: V(e),
          ext: p,
        },
      ],
      warnings: u,
    };
  } finally {
    r.resetFFmpegEngine(i);
  }
}
async function Qe(e, t, n, c, o = () => {}) {
  if (c.aborted) throw new Error("stopped");
  return t === "audio" || t === "video"
    ? Rs(e, t, n, c, o)
    : t === "image" || t === "heic"
      ? Cs(e, t, n, c)
      : t === "pdf" && n.target === "compress"
        ? Is(e, n, c)
        : As(e, t, n);
}
const $e = {
    what: "A workspace for converting many files, or many kinds of files, in one go. Drop a folder of pictures, PDFs, Word, Excel, PowerPoint, HTML, text, audio and video. The Studio recognises each file, and a recipe says what each kind becomes, how good it should be, what to call it and how to pack it. You get a ZIP, a results CSV and a run log. Nothing is uploaded; every file is converted in this tab.",
    how: "Drop files or a folder (or use Add files or Add folder). Choose a starter recipe or add a rule for each kind of file, set the quality panel, and check the file-name pattern. Press Test on one file to see the real before and after size, then Start. Pause or Stop whenever you like and Retry any file that failed. Download the ZIP, the results CSV and the run log, and Save recipe to reuse the same settings.",
    tip: "Test a rule on one file before running a hundred. Audio and video go one at a time because they share one converter, so put big videos in their own run.",
  },
  be = "fdp-studio-",
  et = () =>
    typeof crypto < "u" && "randomUUID" in crypto
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.random()}`,
  le = (e) => (e.match(/\.([^./]+)$/) ?? [])[1]?.toLowerCase() ?? "",
  te = (e) => e.toUpperCase(),
  Ds = {
    waiting: "Waiting",
    running: "Working",
    done: "Done",
    warning: "Done, with a note",
    skipped: "Skipped",
    error: "Failed",
    stopped: "Stopped",
    held: "Held (memory)",
  };
function Os() {
  try {
    const e = sessionStorage.getItem(be + "recipe");
    if (e) {
      const t = ht(e);
      if (t.ok) return t.recipe;
    }
  } catch {}
  return K();
}
function tt() {
  try {
    const e = sessionStorage.getItem(be + "history");
    if (e) {
      const t = JSON.parse(e);
      if (Array.isArray(t)) return t.slice(0, 200);
    }
  } catch {}
  return [];
}
function wa() {
  return s.jsx(Ut, {
    product: "file-conversion-studio",
    children: s.jsx(Bs, {}),
  });
}
function Bs() {
  const [e, t] = b.useState([]),
    [n, c] = b.useState(Os),
    [o, r] = b.useState(tt),
    [i, u] = b.useState("idle"),
    [x, f] = b.useState(null),
    [y, T] = b.useState(() =>
      typeof navigator < "u" && (navigator.hardwareConcurrency ?? 4) >= 8
        ? 3
        : 2,
    ),
    [d, $] = b.useState(null),
    [S, P] = b.useState(null),
    [l, p] = b.useState(!1),
    [g, I] = b.useState(!1),
    [J, Q] = b.useState(!1),
    W = b.useRef(null),
    ne = b.useRef(0),
    R = b.useRef([]),
    re = b.useRef(n),
    de = b.useRef(null),
    Ae = b.useRef(null),
    Re = b.useRef(null),
    ke = b.useRef(0);
  ((R.current = e), (re.current = n));
  const Ne = b.useCallback((a) => {
      (c(a), P(null));
      try {
        sessionStorage.setItem(be + "recipe", mt(a));
      } catch {}
    }, []),
    De = b.useCallback((a) => {
      r(a);
      try {
        sessionStorage.setItem(be + "history", JSON.stringify(a));
      } catch {}
    }, []);
  b.useEffect(() => {
    try {
      const a = Mt(new URLSearchParams(window.location.search).get("preset"));
      if (!a) return;
      const m = ps(a);
      ($({ p: a, ok: !!m }), m && Ne(m));
    } catch {}
  }, [Ne]);
  const U = b.useCallback(
      (a, m) => t((v) => v.map((h) => (h.id === a ? { ...h, ...m } : h))),
      [],
    ),
    H = i !== "idle",
    ue = b.useCallback((a, m = !1) => {
      const {
          accepted: v,
          unsupported: h,
          junk: O,
        } = Kt(
          a.map((k) => ({
            name: k.file.name,
            type: k.file.type,
            path: k.path,
            file: k.file,
          })),
        ),
        C = Math.max(0, ge - R.current.length),
        w = v.slice(0, C),
        E = new Set(
          R.current.map(
            (k) => `${k.path}|${k.file.size}|${k.file.lastModified}`,
          ),
        ),
        j = [];
      let Z = 0;
      for (const k of w) {
        const F = k.item.file,
          oe = k.item.path ?? F.name,
          A = `${oe}|${F.size}|${F.lastModified}`;
        if (E.has(A)) {
          Z++;
          continue;
        }
        E.add(A);
        const ee = ts(k.kind, F.size),
          Ct =
            ee === "warn"
              ? [
                  `Large file (${L(F.size)}): it may be slow or run out of memory.`,
                ]
              : [];
        j.push({
          id: et(),
          file: F,
          path: oe,
          kind: k.kind,
          status: ee === "refuse" ? "skipped" : "waiting",
          progress: 0,
          warnings: Ct,
          message:
            ee === "refuse"
              ? `Too large for the browser (${L(F.size)}).`
              : void 0,
          seconds: 0,
          outputs: [],
          released: 0,
          outBytes: 0,
        });
      }
      t((k) => [...k, ...j]);
      const q = [];
      (h.length &&
        q.push(
          `${h.length} file${h.length === 1 ? "" : "s"} the Studio cannot convert ${h.length === 1 ? "was" : "were"} left out (${h
            .slice(0, 3)
            .map((k) => k.name)
            .join(", ")}${h.length > 3 ? ", ..." : ""}).`,
        ),
        v.length > C &&
          q.push(
            `Only ${ge} files fit in one run; ${v.length - C} were not added.`,
          ),
        m &&
          q.push(
            "The folder was very large, so only the first files were read.",
          ),
        Z && q.push(`${Z} repeated file${Z === 1 ? "" : "s"} skipped.`),
        O && q.push(`${O} hidden or system file${O === 1 ? "" : "s"} ignored.`),
        f(q.length ? q.join(" ") : null));
      const B = [...R.current, ...j].reduce((k, F) => k + F.file.size, 0);
      B > es &&
        f(
          (k) =>
            `${k ? `${k} ` : ""}Together these files are ${L(B)}. Run them in several smaller batches if the tab slows down.`,
        );
    }, []),
    yt = async (a) => {
      if ((a.preventDefault(), I(!1), !H))
        try {
          const m = await ys(a.dataTransfer);
          ue(m.files, m.capped);
        } catch {
          D.error(
            "Could not read what was dropped. Try Add files or Add folder.",
          );
        }
    },
    vt = async () => {
      if (ws())
        try {
          const a = await vs();
          a && ue(a.files, a.capped);
        } catch {
          D.error("Could not open that folder. Try dropping it instead.");
        }
      else Re.current?.click();
    },
    Se = (a) => me(re.current, a.kind, le(a.file.name)),
    pe = b.useMemo(
      () =>
        e.filter(
          (a) =>
            (a.status === "waiting" ||
              a.status === "held" ||
              a.status === "stopped") &&
            me(n, a.kind, le(a.file.name)),
        ),
      [e, n],
    ),
    Oe = (a) => {
      const m = R.current.filter((w) =>
          a
            ? a.includes(w.id)
            : ["waiting", "held", "stopped"].includes(w.status),
        ),
        v = [],
        h = [];
      for (const w of m) {
        if (!Se(w)) {
          h.push(w.id);
          continue;
        }
        v.push({
          id: w.id,
          lane: He(w.kind) ? "media" : "main",
          bytes: w.file.size,
        });
      }
      if (
        (h.forEach((w) =>
          U(w, {
            status: "skipped",
            message: "No rule for this kind of file in the recipe.",
          }),
        ),
        v.length === 0)
      ) {
        f("Nothing to convert yet: add files and a rule for their kind.");
        return;
      }
      f(null);
      const O = re.current;
      (t((w) =>
        w.map((E) =>
          v.some((j) => j.id === E.id)
            ? {
                ...E,
                status: "waiting",
                message: void 0,
                progress: 0,
                warnings: E.warnings.filter((j) => j.startsWith("Large file")),
              }
            : E,
        ),
      ),
        u("running"));
      const C = js(v, {
        concurrency: y,
        maxInFlightBytes: 6e8,
        canStart: () => ne.current < Ge,
        onStart: (w) => U(w.id, { status: "running", progress: 0 }),
        onEnd: (w, E, j) => {
          E === "stopped"
            ? U(w.id, { status: "stopped", message: "Stopped." })
            : E === "held"
              ? U(w.id, {
                  status: "held",
                  message:
                    "Held back so the tab does not run out of memory. Download the ZIP part, then press Start.",
                })
              : E === "error" &&
                U(w.id, {
                  status: "error",
                  message:
                    j instanceof Error
                      ? j.message
                      : "This file could not be converted.",
                });
        },
        run: async (w, E) => {
          const j = R.current.find((B) => B.id === w.id),
            Z = me(O, j.kind, le(j.file.name)),
            q = performance.now();
          try {
            const B = await Qe(j.file, j.kind, Z, E, (A) =>
                U(j.id, { progress: A }),
              ),
              k = R.current.findIndex((A) => A.id === j.id) + 1,
              F = B.outputs.map((A, ee) => ({
                id: et(),
                blob: A.blob,
                name: ct(O.naming.pattern, {
                  name: A.stem,
                  n: k,
                  total: R.current.length,
                  date: new Date(),
                  ext: A.ext,
                }),
              })),
              oe = F.reduce((A, ee) => A + ee.blob.size, 0);
            ((ne.current += oe),
              U(j.id, {
                outputs: F,
                outBytes: oe,
                status: B.warnings.length ? "warning" : "done",
                warnings: [
                  ...j.warnings.filter((A) => A.startsWith("Large file")),
                  ...B.warnings,
                ],
                seconds: (performance.now() - q) / 1e3,
                progress: 1,
                ruleTarget: Z.target,
                message: void 0,
              }));
          } catch (B) {
            if (B instanceof xe) {
              U(j.id, {
                status: "skipped",
                message: B.message,
                seconds: (performance.now() - q) / 1e3,
              });
              return;
            }
            throw (
              U(j.id, {
                seconds: (performance.now() - q) / 1e3,
                ruleTarget: Z.target,
              }),
              E.aborted ? new Error("stopped") : B
            );
          }
        },
      });
      ((W.current = C),
        C.done.then(() => {
          ((W.current = null), u("idle"));
          const w = R.current,
            E = w.filter(
              (j) => j.status === "done" || j.status === "warning",
            ).length;
          (De(
            [
              {
                name: O.name,
                ranAt: new Date().toISOString(),
                files: v.length,
                recipe: O,
              },
              ...tt().filter(
                (j) => JSON.stringify(j.recipe) !== JSON.stringify(O),
              ),
            ].slice(0, 200),
          ),
            D.success(
              `Finished: ${E} of ${w.length} file${w.length === 1 ? "" : "s"} converted.`,
            ));
        }));
    },
    jt = () => {
      const a = W.current;
      a && (a.paused ? (a.resume(), u("running")) : (a.pause(), u("paused")));
    },
    Be = () => {
      (W.current?.stop(), de.current?.abort());
    };
  b.useEffect(
    () => () => {
      (W.current?.stop(), de.current?.abort());
    },
    [],
  );
  const kt = (a) => {
      U(a, { status: "waiting", message: void 0, progress: 0 });
    },
    Nt = () => {
      const a = R.current.filter((m) => m.status === "error").map((m) => m.id);
      a.length && Oe(a);
    },
    St = (a) =>
      t((m) => {
        const v = m.find((h) => h.id === a);
        return (v && (ne.current -= v.outBytes), m.filter((h) => h.id !== a));
      }),
    Et = () => {
      ((ne.current = 0), (ke.current = 0), t([]), P(null), f(null));
    },
    Tt = async () => {
      const a = R.current.find(
        (h) =>
          (h.status === "waiting" ||
            h.status === "held" ||
            h.status === "stopped") &&
          Se(h),
      );
      if (!a) {
        D.error("Add a file that has a rule first.");
        return;
      }
      const m = Se(a);
      (p(!0), P(null));
      const v = new AbortController();
      de.current = v;
      try {
        const h = await Qe(a.file, a.kind, m, v.signal);
        P({
          name: a.file.name,
          inBytes: a.file.size,
          outBytes: h.outputs.reduce((O, C) => O + C.blob.size, 0),
        });
      } catch (h) {
        v.signal.aborted ||
          D.error(
            h instanceof xe || h instanceof Error
              ? h.message
              : "The test failed.",
          );
      } finally {
        (p(!1), (de.current = null));
      }
    },
    Ee = e.filter((a) => a.outputs.length > 0),
    $t = async () => {
      const a = R.current.flatMap((C) => C.outputs);
      if (a.length === 0) return null;
      const m = cs(
          a.map((C) => C.name),
          re.current.naming.layout,
          re.current.naming.collision,
        ),
        v = new It(),
        h = [];
      return (
        a.forEach((C, w) => {
          const E = m[w];
          if (!E.path) {
            h.push(`${C.name} was left out (same name as an earlier file).`);
            return;
          }
          v.file(E.path, C.blob, { binary: !0 });
        }),
        {
          blob: await v.generateAsync({ type: "blob", compression: "STORE" }),
          count: a.length - h.length,
          notes: h,
        }
      );
    },
    Fe = async (a) => {
      Q(!0);
      try {
        const m = await $t();
        if (!m) {
          D.error("There are no converted files yet.");
          return;
        }
        ((ke.current += a ? 1 : 0),
          se(
            m.blob,
            a ? `converted-files-part${ke.current}.zip` : "converted-files.zip",
          ),
          m.notes.length && f(m.notes.slice(0, 3).join(" ")),
          a &&
            (t((v) =>
              v.map((h) =>
                h.outputs.length
                  ? {
                      ...h,
                      released: h.released + h.outputs.length,
                      outputs: [],
                      outBytes: 0,
                    }
                  : h,
              ),
            ),
            (ne.current = 0),
            D.success(
              "Saved, and memory freed. Press Start to carry on with the rest.",
            )));
      } catch {
        D.error(
          "The ZIP could not be built. Try Download ZIP part and free memory.",
        );
      } finally {
        Q(!1);
      }
    },
    Le = () =>
      R.current.map((a) => ({
        file: a.path,
        from: te(le(a.file.name)),
        to: a.ruleTarget
          ? te(ae(a.kind, a.ruleTarget)?.ext ?? a.ruleTarget)
          : "",
        inBytes: a.file.size,
        outBytes: a.outBytes,
        status: a.status,
        warnings: [
          ...a.warnings,
          ...(a.message && (a.status === "error" || a.status === "skipped")
            ? [a.message]
            : []),
          ...(a.released ? ["Saved in an earlier ZIP part"] : []),
        ],
        seconds: a.seconds,
        outputs: a.outputs.map((m) => m.name),
      })),
    Pt = b.useMemo(() => Array.from(new Set(e.map((a) => a.kind))), [e]),
    _t = b.useMemo(() => {
      const a = {};
      for (const m of e)
        a[m.kind] ||
          (a[m.kind] = { name: m.file.name, size: m.file.size, kind: m.kind });
      return a;
    }, [e]),
    G = b.useMemo(
      () => ({
        inB: e.reduce((a, m) => a + m.file.size, 0),
        outB: e.reduce((a, m) => a + m.outBytes, 0),
        n: e.length,
      }),
      [e],
    ),
    Me = e.filter((a) => a.status === "error").length,
    ze = e.length
      ? Math.round(
          (e.filter((a) =>
            ["done", "warning", "skipped", "error", "stopped", "held"].includes(
              a.status,
            ),
          ).length /
            e.length) *
            100,
        )
      : 0,
    qe = e.filter((a) => He(a.kind)).length,
    Te = e.filter((a) => a.status === "held").length;
  return s.jsxs(zt, {
    children: [
      s.jsxs("div", {
        className: "space-y-5",
        children: [
          d &&
            s.jsx(ce, {
              testId: "studio-preset",
              children: d.ok
                ? s.jsxs("p", {
                    className: "text-sm",
                    children: [
                      "Opened from a converter page: ",
                      te(d.p.from),
                      " to ",
                      te(d.p.to),
                      ". The recipe below is set up for it. Drop your files, or change the recipe to handle mixed files.",
                    ],
                  })
                : s.jsxs("p", {
                    className: "text-sm",
                    children: [
                      "The converter page asked for ",
                      te(d.p.from),
                      " to ",
                      te(d.p.to),
                      ", which the Studio cannot do. Choose a recipe below, or use that page's own converter.",
                    ],
                  }),
            }),
          s.jsxs("div", {
            onDragOver: (a) => {
              (a.preventDefault(), H || I(!0));
            },
            onDragLeave: () => I(!1),
            onDrop: yt,
            className: `rounded-2xl border-2 border-dashed p-6 text-center transition-colors ${g ? "border-primary bg-primary/10" : "border-border"}`,
            "data-testid": "studio-drop",
            children: [
              s.jsx(Je, {
                className: "mx-auto h-8 w-8 text-muted-foreground mb-2",
                "aria-hidden": !0,
              }),
              s.jsx("p", {
                className: "font-medium",
                children: "Drop files or a whole folder here",
              }),
              s.jsx("p", {
                className: "text-sm text-muted-foreground mb-3",
                children:
                  "Pictures, PDF, Word, Excel, PowerPoint, HTML, text, audio and video. Nothing is uploaded.",
              }),
              s.jsxs("div", {
                className: "flex flex-wrap justify-center gap-2",
                children: [
                  s.jsxs(N, {
                    variant: "outline",
                    disabled: H,
                    onClick: () => Ae.current?.click(),
                    children: [
                      s.jsx(Je, { className: "h-4 w-4 mr-1.5" }),
                      "Add files",
                    ],
                  }),
                  s.jsxs(N, {
                    variant: "outline",
                    disabled: H,
                    onClick: vt,
                    children: [
                      s.jsx(Zt, { className: "h-4 w-4 mr-1.5" }),
                      "Add folder",
                    ],
                  }),
                ],
              }),
              s.jsx("input", {
                ref: Ae,
                type: "file",
                multiple: !0,
                accept: Xt,
                className: "sr-only",
                tabIndex: -1,
                "aria-label": "Choose files to convert",
                onChange: (a) => {
                  (ue(Ke(a.target.files)), (a.target.value = ""));
                },
              }),
              s.jsx("input", {
                ref: Re,
                type: "file",
                multiple: !0,
                className: "sr-only",
                tabIndex: -1,
                "aria-label": "Choose a folder to convert",
                webkitdirectory: "",
                onChange: (a) => {
                  (ue(Ke(a.target.files)), (a.target.value = ""));
                },
              }),
            ],
          }),
          x &&
            s.jsx(ce, {
              role: "status",
              testId: "studio-notice",
              children: s.jsx("p", { className: "text-sm", children: x }),
            }),
          s.jsx(bs, {
            recipe: n,
            setRecipe: Ne,
            samples: _t,
            kindsPresent: Pt,
            history: o,
            setHistory: De,
            disabled: H,
            firstName: e[0]?.file.name,
          }),
          e.length > 0 &&
            s.jsxs("section", {
              className: "rounded-2xl border bg-card p-5 space-y-4",
              "aria-label": "Queue",
              "data-testid": "studio-queue",
              children: [
                s.jsxs("div", {
                  className: "flex flex-wrap items-center gap-2",
                  children: [
                    s.jsxs("p", {
                      className: "mr-auto text-sm",
                      children: [
                        s.jsx("strong", { children: G.n }),
                        " file",
                        G.n === 1 ? "" : "s",
                        ", ",
                        L(G.inB),
                        G.outB > 0
                          ? ` in, ${L(G.outB)} out (${he(G.inB, G.outB)})`
                          : "",
                      ],
                    }),
                    i === "idle"
                      ? s.jsxs(s.Fragment, {
                          children: [
                            s.jsxs("label", {
                              className:
                                "text-sm inline-flex items-center gap-1.5",
                              children: [
                                "Files at once",
                                s.jsx("select", {
                                  className:
                                    "h-9 rounded-md border bg-background px-2 text-sm",
                                  "aria-label": "Files converted at once",
                                  value: y,
                                  onChange: (a) => T(Number(a.target.value)),
                                  children: [1, 2, 3, 4].map((a) =>
                                    s.jsx(
                                      "option",
                                      { value: a, children: a },
                                      a,
                                    ),
                                  ),
                                }),
                              ],
                            }),
                            s.jsx(N, {
                              variant: "outline",
                              onClick: Tt,
                              disabled: l || pe.length === 0,
                              children: l ? "Testing..." : "Test on one file",
                            }),
                            s.jsxs(N, {
                              onClick: () => Oe(),
                              disabled: pe.length === 0,
                              "data-testid": "studio-start",
                              children: [
                                s.jsx(Ue, { className: "h-4 w-4 mr-1.5" }),
                                "Start",
                                pe.length ? ` (${pe.length})` : "",
                              ],
                            }),
                          ],
                        })
                      : s.jsxs(s.Fragment, {
                          children: [
                            s.jsx(N, {
                              variant: "outline",
                              onClick: jt,
                              children:
                                i === "paused"
                                  ? s.jsxs(s.Fragment, {
                                      children: [
                                        s.jsx(Ue, {
                                          className: "h-4 w-4 mr-1.5",
                                        }),
                                        "Resume",
                                      ],
                                    })
                                  : s.jsxs(s.Fragment, {
                                      children: [
                                        s.jsx(Jt, {
                                          className: "h-4 w-4 mr-1.5",
                                        }),
                                        "Pause",
                                      ],
                                    }),
                            }),
                            s.jsxs(N, {
                              variant: "destructive",
                              onClick: Be,
                              "data-testid": "studio-stop",
                              children: [
                                s.jsx(We, { className: "h-4 w-4 mr-1.5" }),
                                "Stop",
                              ],
                            }),
                          ],
                        }),
                    l &&
                      s.jsxs(N, {
                        variant: "destructive",
                        onClick: Be,
                        children: [
                          s.jsx(We, { className: "h-4 w-4 mr-1.5" }),
                          "Stop test",
                        ],
                      }),
                    s.jsxs(N, {
                      variant: "ghost",
                      onClick: Et,
                      disabled: H,
                      children: [
                        s.jsx(Pe, { className: "h-4 w-4 mr-1.5" }),
                        "Clear all",
                      ],
                    }),
                  ],
                }),
                i !== "idle" &&
                  s.jsx("div", {
                    role: "progressbar",
                    "aria-label": "Overall progress",
                    "aria-valuemin": 0,
                    "aria-valuemax": 100,
                    "aria-valuenow": ze,
                    className: "h-2 rounded-full bg-muted overflow-hidden",
                    children: s.jsx("div", {
                      className: "h-full bg-primary transition-all",
                      style: { width: `${ze}%` },
                    }),
                  }),
                i === "paused" &&
                  s.jsx("p", {
                    className: "text-xs text-muted-foreground",
                    children:
                      "Paused: files already started will finish; nothing new starts until you press Resume.",
                  }),
                qe > 0 &&
                  i === "idle" &&
                  s.jsxs("p", {
                    className: "text-xs text-muted-foreground",
                    children: [
                      "Audio and video (",
                      qe,
                      ") run one at a time and can take a while.",
                    ],
                  }),
                S &&
                  s.jsx(ce, {
                    role: "status",
                    testId: "studio-test",
                    children: s.jsxs("p", {
                      className: "text-sm",
                      children: [
                        "Test on ",
                        S.name,
                        ": ",
                        L(S.inBytes),
                        " became ",
                        L(S.outBytes),
                        " (",
                        he(S.inBytes, S.outBytes) || "same size",
                        "). The test file is not added to the ZIP.",
                      ],
                    }),
                  }),
                Te > 0 &&
                  i === "idle" &&
                  s.jsx(ce, {
                    role: "alert",
                    testId: "studio-held",
                    children: s.jsxs("p", {
                      className: "text-sm",
                      children: [
                        "The converted files in memory reached ",
                        L(Ge),
                        ", so ",
                        Te,
                        " file",
                        Te === 1 ? " was" : "s were",
                        " held back. Use Download ZIP part and free memory, then press Start.",
                      ],
                    }),
                  }),
                s.jsx("ul", {
                  className: "divide-y",
                  "data-testid": "studio-rows",
                  children: e.map((a) => {
                    const m = me(n, a.kind, le(a.file.name)),
                      v = m ? ae(a.kind, m.target) : null;
                    return s.jsxs(
                      "li",
                      {
                        className:
                          "py-2.5 flex flex-wrap items-center gap-x-3 gap-y-1",
                        "data-testid": "studio-row",
                        children: [
                          s.jsxs("div", {
                            className: "min-w-0 grow basis-56",
                            children: [
                              s.jsx("p", {
                                className: "truncate text-sm font-medium",
                                title: a.path,
                                children: a.path,
                              }),
                              s.jsxs("p", {
                                className: "text-xs text-muted-foreground",
                                children: [
                                  X[a.kind],
                                  ", ",
                                  L(a.file.size),
                                  v
                                    ? ` → ${v.label.replace(/ \(.*\)$/, "")}`
                                    : " → no rule",
                                  a.outBytes
                                    ? `, now ${L(a.outBytes)} (${he(a.file.size, a.outBytes)})`
                                    : "",
                                ],
                              }),
                              (a.message || a.warnings.length > 0) &&
                                s.jsx("p", {
                                  className: `text-xs ${a.status === "error" ? "text-destructive" : "text-muted-foreground"}`,
                                  children: [a.message, ...a.warnings]
                                    .filter(Boolean)
                                    .join(" "),
                                }),
                            ],
                          }),
                          a.status === "running" &&
                            s.jsx("div", {
                              role: "progressbar",
                              "aria-label": `Progress for ${a.file.name}`,
                              "aria-valuemin": 0,
                              "aria-valuemax": 100,
                              "aria-valuenow": Math.round(a.progress * 100),
                              className:
                                "h-1.5 w-24 rounded-full bg-muted overflow-hidden",
                              children: s.jsx("div", {
                                className: "h-full bg-primary",
                                style: {
                                  width: `${Math.max(4, Math.round(a.progress * 100))}%`,
                                },
                              }),
                            }),
                          s.jsxs("span", {
                            className: `text-xs font-medium rounded-full px-2 py-0.5 ${a.status === "error" ? "bg-destructive/10 text-destructive" : "bg-muted text-foreground"}`,
                            children: [
                              Ds[a.status],
                              a.released ? ", saved" : "",
                            ],
                          }),
                          a.outputs.length === 1 &&
                            s.jsx(N, {
                              variant: "ghost",
                              size: "sm",
                              "aria-label": `Download ${a.outputs[0].name}`,
                              onClick: () =>
                                se(a.outputs[0].blob, a.outputs[0].name),
                              children: s.jsx(Ve, { className: "h-4 w-4" }),
                            }),
                          (a.status === "error" ||
                            a.status === "stopped" ||
                            a.status === "held" ||
                            a.status === "skipped") &&
                            !H &&
                            m &&
                            s.jsxs(N, {
                              variant: "ghost",
                              size: "sm",
                              onClick: () => kt(a.id),
                              "aria-label": `Retry ${a.file.name}`,
                              children: [
                                s.jsx(Ze, { className: "h-4 w-4 mr-1" }),
                                "Retry",
                              ],
                            }),
                          s.jsx(N, {
                            variant: "ghost",
                            size: "sm",
                            disabled: a.status === "running",
                            onClick: () => St(a.id),
                            "aria-label": `Remove ${a.file.name}`,
                            children: s.jsx(Pe, { className: "h-4 w-4" }),
                          }),
                        ],
                      },
                      a.id,
                    );
                  }),
                }),
                (Ee.length > 0 || e.some((a) => a.released)) &&
                  i === "idle" &&
                  s.jsxs("div", {
                    className:
                      "flex flex-wrap items-center gap-2 border-t pt-4",
                    "data-testid": "studio-downloads",
                    children: [
                      s.jsxs(N, {
                        onClick: () => Fe(!1),
                        disabled: J || Ee.length === 0,
                        children: [
                          s.jsx(Ve, { className: "h-4 w-4 mr-1.5" }),
                          J ? "Building ZIP..." : "Download ZIP",
                        ],
                      }),
                      s.jsx(N, {
                        variant: "outline",
                        onClick: () => Fe(!0),
                        disabled: J || Ee.length === 0,
                        children: "Download ZIP part and free memory",
                      }),
                      s.jsx(N, {
                        variant: "outline",
                        onClick: () =>
                          se(
                            new Blob([Ns(Le())], {
                              type: "text/csv;charset=utf-8",
                            }),
                            "conversion-results.csv",
                            { free: !0 },
                          ),
                        children: "Results CSV",
                      }),
                      s.jsx(N, {
                        variant: "outline",
                        onClick: () =>
                          se(
                            new Blob([JSON.stringify(Ss(n, Le()), null, 2)], {
                              type: "application/json",
                            }),
                            "conversion-run-log.json",
                            { free: !0 },
                          ),
                        children: "Run log (JSON)",
                      }),
                      Me > 0 &&
                        s.jsxs(N, {
                          variant: "outline",
                          onClick: Nt,
                          children: [
                            s.jsx(Ze, { className: "h-4 w-4 mr-1.5" }),
                            "Retry ",
                            Me,
                            " failed",
                          ],
                        }),
                    ],
                  }),
              ],
            }),
        ],
      }),
      s.jsx(qt, { whatIsIt: $e.what, howToUse: $e.how, tip: $e.tip }),
    ],
  });
}
export { wa as default };
//# sourceMappingURL=FileConversionStudio-DzZvPuK7.js.map
