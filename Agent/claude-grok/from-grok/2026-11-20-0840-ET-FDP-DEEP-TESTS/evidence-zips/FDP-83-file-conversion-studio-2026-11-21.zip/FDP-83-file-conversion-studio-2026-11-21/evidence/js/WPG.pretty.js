import { r as i, j as e } from "./vendor-react-D01g8YgM.js";
import {
  a as I,
  z as A,
  aN as W,
  t as u,
  L as w,
  aO as E,
  N as p,
  aP as B,
  a1 as y,
  aq as R,
  B as O,
  aQ as T,
  b as U,
  f as g,
  aR as $,
} from "./index-B1CTyGtY.js";
import { T as j, l as D, W as F } from "./ToolPage-DwLoDncN.js";
import { w as K, a as M } from "./workflowCta-WWwB7oO9.js";
const m = (s) =>
  s
    ? new Date(s).toLocaleDateString(void 0, {
        year: "numeric",
        month: "long",
        day: "numeric",
      })
    : "";
function q({ product: s, children: k }) {
  const r = E[s],
    { isAuthenticated: l } = I(),
    { localizedHref: N } = A(),
    b = l ? void 0 : W(),
    [o] = i.useState(
      () =>
        typeof window < "u" &&
        new URLSearchParams(window.location.search).get("checkout") ===
          "success",
    ),
    [c, f] = i.useState(o ? 20 : 0),
    n = u.workflowProduct.status.useQuery(
      { product: s, deviceId: b },
      { refetchInterval: o && c > 0 ? 3e3 : !1 },
    );
  i.useEffect(() => {
    if (!(!o || c <= 0)) {
      if (n.data?.entitled) {
        f(0);
        return;
      }
      n.dataUpdatedAt && f((t) => t - 1);
    }
  }, [n.dataUpdatedAt]);
  const P = u.workflowProduct.checkout.useMutation(),
    v = u.workflowProduct.portal.useMutation(),
    [x, h] = i.useState(!1),
    L = async () => {
      if (!l) {
        window.location.href = $(s);
        return;
      }
      h(!0);
      try {
        const t = await P.mutateAsync({ product: s });
        window.location.href = t.url;
      } catch (t) {
        (h(!1),
          g.error(
            t instanceof Error
              ? t.message
              : "Could not start checkout. Please try again.",
          ));
      }
    },
    C = async () => {
      try {
        const t = await v.mutateAsync({ product: s });
        window.location.href = t.url;
      } catch (t) {
        g.error(
          t instanceof Error
            ? t.message
            : "Could not open billing. Please try again.",
        );
      }
    };
  if (n.isLoading)
    return e.jsx(j, {
      children: e.jsxs("div", {
        className:
          "flex items-center justify-center gap-2 py-16 text-sm text-muted-foreground",
        role: "status",
        children: [
          e.jsx(w, { className: "h-4 w-4 animate-spin" }),
          "Checking your access",
        ],
      }),
    });
  const a = n.data;
  if (a?.entitled)
    return e.jsxs(D.Provider, {
      value: { entitled: !0, plan: null, premium: !1 },
      children: [
        k,
        a.hasSubscription &&
          e.jsxs("div", {
            className:
              "mx-auto max-w-3xl px-4 pb-6 text-center text-xs text-muted-foreground space-y-1",
            "data-testid": "workflow-account",
            children: [
              e.jsxs("p", {
                children: [
                  r.name,
                  a.trialing
                    ? `, trial until ${m(a.until)}`
                    : `, renews ${m(a.until)}`,
                  ".",
                  " ",
                  e.jsx("button", {
                    type: "button",
                    className: "underline",
                    onClick: () => {
                      C();
                    },
                    "data-testid": "workflow-manage",
                    children: "Manage or cancel",
                  }),
                ],
              }),
              a.endsAtPeriodEnd &&
                e.jsxs(p, {
                  role: "status",
                  testId: "workflow-ends",
                  children: ["Cancelled. Your plan ends on ", m(a.until), "."],
                }),
            ],
          }),
      ],
    });
  const d = a?.trialEligible ?? !0,
    S = o && c > 0;
  return e.jsx(j, {
    children: e.jsxs("section", {
      className: "mx-auto max-w-xl",
      "data-testid": "workflow-paywall",
      children: [
        S &&
          e.jsx(p, {
            role: "status",
            testId: "workflow-confirming",
            children:
              "Thank you. We are confirming your payment with Stripe; this page opens by itself in a few seconds.",
          }),
        e.jsxs("div", {
          className: "text-center",
          children: [
            e.jsx(B, {
              className: "mx-auto h-6 w-6 text-primary",
              "aria-hidden": !0,
            }),
            e.jsx("h2", {
              className: "mt-2 text-xl font-semibold",
              children: r.name,
            }),
            e.jsxs("p", {
              className: "mt-1 text-sm text-muted-foreground",
              children: [r.tagline, d ? ` Try it for ${y} days first.` : ""],
            }),
          ],
        }),
        e.jsxs("div", {
          className:
            "mt-5 rounded-xl border border-primary bg-card p-5 flex flex-col",
          children: [
            e.jsxs("p", {
              className: "text-3xl font-bold",
              children: [
                "$",
                r.monthlyUsd,
                e.jsx("span", {
                  className: "text-base font-normal text-muted-foreground",
                  children: " / month",
                }),
              ],
            }),
            e.jsx("p", {
              className: "text-xs text-muted-foreground",
              children: "Billed monthly, cancel any time",
            }),
            e.jsx("ul", {
              className: "mt-3 space-y-2 text-sm",
              children: r.features.map((t) =>
                e.jsxs(
                  "li",
                  {
                    className: "flex gap-2",
                    children: [
                      e.jsx(R, {
                        className: "mt-0.5 h-4 w-4 shrink-0 text-primary",
                        "aria-hidden": !0,
                      }),
                      e.jsx("span", { children: t }),
                    ],
                  },
                  t,
                ),
              ),
            }),
            e.jsxs(O, {
              className: "mt-4 w-full gap-2",
              onClick: () => {
                L();
              },
              disabled: x,
              "data-testid": "workflow-subscribe",
              children: [
                x && e.jsx(w, { className: "h-4 w-4 animate-spin" }),
                K(
                  M({ signedIn: l, entitled: !1, trialEligible: d }),
                  r.monthlyUsd,
                ),
              ],
            }),
          ],
        }),
        e.jsx(F, { ...T[s], testId: `wf-preview-${s}` }),
        e.jsxs("p", {
          className: "mt-4 text-xs text-muted-foreground text-center",
          "data-testid": "workflow-terms",
          children: [
            d
              ? `After the ${y}-day trial you are charged monthly unless you cancel first. `
              : "",
            "Billed monthly. If you cancel, your plan continues to the end of the paid month. No trial uses and no day pass. Your work stays in your browser and is not stored on our servers.",
          ],
        }),
        e.jsxs("p", {
          className: "mt-2 text-xs text-muted-foreground text-center",
          children: [
            "Looking for single tools? See ",
            e.jsx(U, {
              href: N("/pricing"),
              className: "underline",
              children: "Professional Tools and Premium Applications",
            }),
            ".",
          ],
        }),
      ],
    }),
  });
}
export { q as W };
//# sourceMappingURL=WorkflowProductGate-DbtxVtBO.js.map
