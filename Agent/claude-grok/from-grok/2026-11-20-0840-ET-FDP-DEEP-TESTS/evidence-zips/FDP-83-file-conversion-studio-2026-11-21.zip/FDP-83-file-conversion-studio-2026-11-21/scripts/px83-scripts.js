// List JS chunks and UI on file-conversion-studio (guest, no actions)
const { chromium } = require('playwright'); const fs=require('fs');
(async()=>{const b=await chromium.launch(); const c=await b.newContext({viewport:{width:1366,height:900}}); const p=await c.newPage(); const s=[];
p.on('response',r=>{const u=r.url(); if(/\/assets\/.*\.js$/.test(u)) s.push(u)});
await p.goto('https://www.freedailypro.com/tool/file-conversion-studio',{waitUntil:'domcontentloaded',timeout:45000}); await p.waitForTimeout(6000);
const t=await p.evaluate(()=>document.querySelector('main').innerText);
fs.writeFileSync('/workspace/deep/83-file-conversion-studio/tool-expanded.txt',t); fs.writeFileSync('/workspace/deep/83-file-conversion-studio/js/chunks.txt',s.join('\n'));
await p.screenshot({path:'/workspace/deep/83-file-conversion-studio/live/initial.png'}); console.log(s.length, JSON.stringify(await p.evaluate(()=>localStorage.getItem('fdp-usage-v1')))); await b.close();})();
