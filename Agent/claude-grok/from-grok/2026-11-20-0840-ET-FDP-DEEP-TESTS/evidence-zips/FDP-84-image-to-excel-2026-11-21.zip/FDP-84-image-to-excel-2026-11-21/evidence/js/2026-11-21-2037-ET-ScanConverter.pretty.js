const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/operations-BatXiFlG.js",
      "assets/index-xgcQ0Xo8.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/index-BJxTAPRn.css",
      "assets/pdfFonts-Ckcqm3Ic.js",
      "assets/index-BRvxULIc.js",
      "assets/index-CnXdQaNG.js",
      "assets/index-DMQTJy3b.js",
      "assets/fontkit.es-DA-3qwB1.js",
      "assets/pdfBookmarks-BjfxtCfb.js",
      "assets/pdfMetadata-CcxIhQF2.js",
      "assets/pageView-BQIwVYOi.js",
      "assets/formAppearance-CdNbuISd.js",
      "assets/drawTextAnywhere-DcuP6lHH.js",
      "assets/ocrText-C_9cxcFa.js",
      "assets/ocrImage-CmXFNUud.js",
      "assets/jszip.min-CT0ZA6V1.js",
      "assets/jszip.min-C-FLQHAz.js",
      "assets/_commonjs-dynamic-modules-TDtrdbi3.js",
      "assets/utils-s8ucLyj8.js",
      "assets/imageRecompress-eXQFDUm-.js",
      "assets/formatFileSize-B-JRDfN5.js",
      "assets/plural-FIChqbp4.js",
      "assets/textDiff-DxE9AzvO.js",
      "assets/utils-BB7NgdRI.js",
      "assets/decode-FlLGQ42m.js",
      "assets/formFill-Dg9Myfyq.js",
      "assets/redactSearch-DQpyyh_t.js",
      "assets/nameDetect-DvHCRM0m.js",
      "assets/imagePdf-Dtz8PQyf.js",
      "assets/scanRun-BhP99oKM.js",
      "assets/scanCore-B6hkUd9X.js",
      "assets/index-CHifq31M.js",
      "assets/ocrBlocks-CqBbJ5zn.js",
      "assets/tablesToExcel-C1ZZUvmI.js",
      "assets/pdfLayout-BswErtWz.js",
      "assets/xlsx-CNerDvZX.js",
    ]),
) => i.map((i) => d[i]);
import {
  ap as V,
  B as N,
  N as y,
  ax as Xe,
  b as G,
  ay as Ye,
  f as ne,
} from "./index-xgcQ0Xo8.js";
import { r, j as e } from "./vendor-react-D01g8YgM.js";
import { t as Ze } from "./fileHandoff-RQJcoDih.js";
import { F as qe, f as ke, P as Ke, D as le } from "./ToolPage-DrleSM7T.js";
import { R as et } from "./ReorderableFileList-DbcwU2LD.js";
import { C as oe } from "./card-C4-tkNoN.js";
import { u as tt } from "./useRunToken-sJpsnYiZ.js";
import { u as st } from "./useShareGate-D9Hi-u97.js";
import { f as at } from "./formatFileSize-B-JRDfN5.js";
import { p as j } from "./plural-FIChqbp4.js";
import { OCR_LANGUAGES as rt } from "./ocrText-C_9cxcFa.js";
import { D as nt } from "./tablesToExcel-C1ZZUvmI.js";
import {
  checkScanInput as lt,
  findScanTables as ot,
  buildScanExcel as ct,
  textToParagraphs as it,
  buildScanWord as dt,
  stemOfImageName as Ce,
  documentText as mt,
  averageConfidence as ut,
  tableQualityNotes as xt,
  textQualityNotes as ht,
  SCAN_LIMITS as ce,
  paragraphsToText as pt,
  readingParagraphs as gt,
  linesAsTable as ft,
} from "./scanCore-B6hkUd9X.js";
import { S as bt } from "./scan-text-CzZL-zgD.js";
import { I as H } from "./info-x67VbErc.js";
import { C as jt } from "./copy-B6PRNyNa.js";
import { T as wt } from "./trash-2-DBtfaxvp.js";
const Nt = [
    { id: "word", label: "Word (.docx)", ext: "docx" },
    { id: "excel", label: "Excel (.xlsx)", ext: "xlsx" },
    { id: "text", label: "Plain text (.txt)", ext: "txt" },
  ],
  yt = [
    { id: "auto", label: "Work it out from the file" },
    { id: "dmy", label: "Day first (31/12/2026)" },
    { id: "mdy", label: "Month first (12/31/2026)" },
  ],
  ie = 300;
let vt = 1;
const kt = (S) => (S.type === "image/png" ? "png" : "jpg");
function Ut({ toolId: S, initialOutput: R, lockOutput: de = !1 }) {
  const { gateShare: Se } = st(),
    [p, _] = r.useState([]),
    [F, me] = r.useState(!1),
    [D, ue] = r.useState([]),
    [m, Te] = r.useState(R),
    [xe, Ee] = r.useState("eng"),
    [he, Re] = r.useState(!1),
    [pe, _e] = r.useState(!1),
    [J, Fe] = r.useState("letter"),
    [I, De] = r.useState(!1),
    [g, O] = r.useState({ ...nt, sheetMode: "table" }),
    [ge, Q] = r.useState(!1),
    [Ie, T] = r.useState(""),
    [fe, $] = r.useState(0),
    [be, je] = r.useState(""),
    [c, we] = r.useState(null),
    [A, Ne] = r.useState([]),
    [L, X] = r.useState([]),
    [v, k] = r.useState([]),
    [Oe, Y] = r.useState(!1),
    [E, M] = r.useState(null),
    [Z, ye] = r.useState(""),
    u = tt(),
    q = r.useRef(null),
    ve = r.useRef(null),
    W = r.useCallback(() => {
      const t = q.current;
      ((q.current = null), t && t.terminate().catch(() => {}));
    }, []);
  r.useEffect(
    () => () => {
      (u.cancel(), W());
    },
    [u, W],
  );
  const C = r.useMemo(() => p.map((t) => t.file), [p]),
    B = r.useMemo(() => C.map((t) => URL.createObjectURL(t)), [C]);
  r.useEffect(() => () => B.forEach((t) => URL.revokeObjectURL(t)), [B]);
  const f = r.useCallback(() => {
      (u.cancel(),
        W(),
        Q(!1),
        we(null),
        Ne([]),
        X([]),
        k([]),
        Y(!1),
        M(null),
        je(""));
    }, [u, W]),
    U = r.useCallback(
      async (t) => {
        if (!t.length) return;
        f();
        const s = lt(t, {
            count: p.length,
            bytes: p.reduce((l, o) => l + o.file.size, 0),
          }),
          a = s.rejected.map(
            (l) => `${l.name}: ${l.reason}. It was not added.`,
          ),
          n = [];
        if (s.accepted.length) {
          me(!0);
          try {
            const [{ convertHeicToJpegFile: l }, { normalizeImageFile: o }] =
              await Promise.all([
                V(
                  () => import("./operations-BatXiFlG.js").then((d) => d.Z),
                  __vite__mapDeps([
                    0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
                    17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28,
                  ]),
                ),
                V(
                  () => import("./imagePdf-Dtz8PQyf.js"),
                  __vite__mapDeps([29, 5, 6, 2, 7, 10]),
                ),
              ]);
            for (const d of s.accepted) {
              const b = t[d];
              try {
                const i = await o(await l(b));
                n.push({
                  id: vt++,
                  file:
                    i.name === b.name
                      ? i
                      : new File([i], b.name, { type: i.type }),
                });
              } catch (i) {
                a.push(
                  `${b.name}: ${i instanceof Error && i.message ? i.message : "could not be read"}. It was not added.`,
                );
              }
            }
          } finally {
            me(!1);
          }
        }
        (n.length && _((l) => [...l, ...n]), ue(a));
      },
      [p, f],
    ),
    K = r.useRef(U);
  ((K.current = U),
    r.useEffect(() => {
      const t = Ze("scan-convert");
      t.length && K.current(t);
    }, []),
    r.useEffect(() => {
      const t = (s) => {
        const a = Array.from(s.clipboardData?.files ?? []).filter((n) =>
          n.type.startsWith("image/"),
        );
        a.length && (s.preventDefault(), K.current(a));
      };
      return (
        window.addEventListener("paste", t),
        () => window.removeEventListener("paste", t)
      );
    }, []));
  const $e = () => {
      (f(), _([]), ue([]), $(0), T(""));
    },
    Ae = async () => {
      if (!C.length) return;
      f();
      const t = u.start(),
        s = [...C];
      (Q(!0), $(0), T("Starting…"));
      try {
        const { readScanImages: a } = await V(
            async () => {
              const { readScanImages: l } =
                await import("./scanRun-BhP99oKM.js");
              return { readScanImages: l };
            },
            __vite__mapDeps([
              30, 1, 2, 3, 31, 32, 33, 14, 34, 35, 36, 29, 5, 6, 7, 10,
            ]),
          ),
          n = await a(
            s,
            { language: xe, deskew: he, enhance: pe },
            {
              isCurrent: () => u.isCurrent(t),
              status: (l) => u.isCurrent(t) && T(l),
              progress: (l) => u.isCurrent(t) && $(l),
              registerEngine: (l) => {
                u.isCurrent(t) && (q.current = l);
              },
            },
          );
        if (!u.isCurrent(t)) return;
        (Ne(s),
          we(n),
          X(n.map((l) => pt(gt(l.reading.data)))),
          Ye(S, "pdf-tools"),
          ne.success(
            n.some((l) => l.reading.data.text?.trim())
              ? "Reading finished. Check the text before you download."
              : "Reading finished, but no text was found.",
          ));
      } catch (a) {
        if (
          !u.isCurrent(t) ||
          (a instanceof Error && a.message === "cancelled")
        )
          return;
        (console.error("Scan reading failed", a),
          je(
            a instanceof Error && a.name === "OcrStartError"
              ? a.message
              : `The pictures could not be read: ${a instanceof Error ? a.message : "unknown problem"}. Try a clearer picture.`,
          ));
      } finally {
        u.isCurrent(t) && (Q(!1), T(""));
      }
    },
    Le = () => {
      (f(), $(0), T(""));
    },
    w = r.useMemo(() => (c ? c.map((t) => t.reading) : []), [c]),
    x = r.useMemo(() => (w.length ? ot(w, g) : null), [w, g.joinContinued]);
  r.useEffect(() => {
    (Y(!1),
      k(
        x
          ? x.tables.map((t) => ({ ...t, rows: t.rows.map((s) => [...s]) }))
          : [],
      ));
  }, [x]);
  const h = r.useMemo(
      () =>
        m !== "excel" || !x || !v.length
          ? null
          : ct(
              v,
              {
                pages: w.length,
                unreadPages: x.unreadPages,
                joined: x.joined,
                anyText: x.anyText,
              },
              g,
            ),
      [m, x, v, w.length, g],
    ),
    Me = (t, s, a, n) =>
      k((l) =>
        l.map((o, d) =>
          d !== t
            ? o
            : {
                ...o,
                rows: o.rows.map((b, i) =>
                  i !== s ? b : b.map((z, re) => (re === a ? n : z)),
                ),
              },
        ),
      ),
    We = (t, s) =>
      k((a) =>
        a.map((n, l) =>
          l !== t
            ? n
            : {
                ...n,
                rows: n.rows.filter((o, d) => d !== s),
                boldRow: n.boldRow.filter((o, d) => d !== s),
                headerRows:
                  s < n.headerRows
                    ? Math.max(0, n.headerRows - 1)
                    : n.headerRows,
              },
        ),
      ),
    Be = (t) =>
      k((s) =>
        s.map((a, n) =>
          n !== t
            ? a
            : {
                ...a,
                rows: [...a.rows, a.rows[0]?.map(() => "") ?? [""]],
                boldRow: [...a.boldRow, !1],
              },
        ),
      ),
    Ue = (t, s) =>
      k((a) =>
        a.map((n, l) => (l !== t ? n : { ...n, headerRows: s ? 1 : 0 })),
      ),
    ze = () => {
      const t = ft(w);
      t && (k([t]), Y(!0));
    },
    P = r.useMemo(() => L.map(it), [L]);
  r.useEffect(() => {
    if (m !== "word" || !c) {
      M(null);
      return;
    }
    let t = !1;
    (M(null), ye(""));
    const s = setTimeout(async () => {
      try {
        const a = [];
        for (let l = 0; l < c.length; l++) {
          const o = c[l].reading,
            d = I || !P[l]?.length;
          let b;
          if (d && A[l]) {
            let i = A[l],
              z = kt(A[l]);
            if (o.rotation) {
              const { rotateImageBlob: re } = await V(async () => {
                const { rotateImageBlob: Qe } =
                  await import("./ocrImage-CmXFNUud.js");
                return { rotateImageBlob: Qe };
              }, []);
              ((i = await re(i, o.rotation)), (z = "jpg"));
            }
            b = {
              bytes: new Uint8Array(await i.arrayBuffer()),
              type: z,
              widthPx: o.widthPx,
              heightPx: o.heightPx,
            };
          }
          a.push({
            paragraphs: P[l] ?? [],
            picture: b,
            landscape: o.widthPx > o.heightPx,
          });
        }
        const n = await dt(a, {
          title: Ce(c[0].reading.name),
          pageSize: J,
          includePicture: I,
        });
        t || M({ blob: n.blob, pictureOnly: n.pictureOnlyPages });
      } catch (a) {
        (console.error("Word file failed", a),
          t ||
            ye(
              "The Word file could not be built. Try again, or download the text instead.",
            ));
      }
    }, 350);
    return () => {
      ((t = !0), clearTimeout(s));
    };
  }, [m, c, A, P, J, I]);
  const ee = r.useMemo(() => mt(P), [P]),
    Ve = r.useMemo(
      () => new Blob([ee], { type: "text/plain;charset=utf-8" }),
      [ee],
    ),
    Ge = () =>
      Se(async () => {
        try {
          return (
            await navigator.clipboard.writeText(ee),
            ne.success("Copied!"),
            !0
          );
        } catch {
          return (
            ne.error("Couldn't copy. Select the text and copy it by hand."),
            !1
          );
        }
      }),
    te = Ce(c?.[0]?.reading.name ?? C[0]?.name ?? "scan"),
    se = ut(w),
    He = p.reduce((t, s) => t + s.file.size, 0),
    ae = m === "excel" && x ? xt(v, se) : null,
    Je = c && m !== "excel" ? ht(w, P) : [];
  return !p.length && !F
    ? e.jsxs("div", {
        className: "space-y-3",
        children: [
          e.jsx(qe, {
            gateAtDownload: !0,
            multiple: !0,
            accept: "image/*,.heic,.heif",
            acceptLabel: "pictures (JPG, PNG, WebP, HEIC)",
            onFiles: (t) => {
              U(t);
            },
            label: "Drop photos, scans or screenshots",
            description:
              "JPG, PNG, WebP or iPhone HEIC, one or many, in order. You can also paste a screenshot with Ctrl/Cmd+V. Read in your browser; nothing is uploaded.",
          }),
          D.length > 0 && e.jsx(Pe, { problems: D }),
        ],
      })
    : e.jsxs("div", {
        className: "space-y-4",
        children: [
          D.length > 0 && e.jsx(Pe, { problems: D }),
          e.jsxs("div", {
            children: [
              e.jsxs("div", {
                className:
                  "mb-2 flex flex-wrap items-center justify-between gap-2",
                children: [
                  e.jsxs("p", {
                    className: "text-sm font-medium text-muted-foreground",
                    children: [
                      j(p.length, "picture"),
                      " (",
                      at(He),
                      "): in this order they become ",
                      p.length === 1 ? "the page" : "the pages",
                      ". Drag to reorder.",
                    ],
                  }),
                  !ge &&
                    e.jsxs(e.Fragment, {
                      children: [
                        e.jsx("input", {
                          ref: ve,
                          type: "file",
                          multiple: !0,
                          accept: "image/*,.heic,.heif",
                          className: "hidden",
                          "aria-label": "Add more pictures",
                          onChange: (t) => {
                            const s = Array.from(t.target.files ?? []);
                            ((t.target.value = ""), U(s));
                          },
                        }),
                        e.jsxs(N, {
                          type: "button",
                          size: "sm",
                          variant: "outline",
                          className: "gap-1.5",
                          disabled: p.length >= ce.maxImages || F,
                          onClick: () => ve.current?.click(),
                          children: [
                            e.jsx(ke, { className: "h-3.5 w-3.5" }),
                            " Add more",
                          ],
                        }),
                      ],
                    }),
                ],
              }),
              F &&
                e.jsx("p", {
                  className: "text-xs text-muted-foreground mb-2",
                  role: "status",
                  children:
                    "Preparing pictures (iPhone photos are converted and turned upright)…",
                }),
              e.jsx(et, {
                files: C,
                thumbnailUrls: B,
                thumbnailFit: "large",
                onReorder: (t) => {
                  (f(), _((s) => t.map((a) => s.find((n) => n.file === a))));
                },
                onRemove: (t) => {
                  (f(), _((s) => s.filter((a, n) => n !== t)));
                },
              }),
            ],
          }),
          ge
            ? e.jsx(Ke, {
                message: Ie || "Working…",
                progress: fe > 0 ? fe * 100 : void 0,
                onStop: Le,
              })
            : e.jsxs(e.Fragment, {
                children: [
                  e.jsxs("fieldset", {
                    className: "space-y-3 rounded-lg border p-3 min-w-0",
                    children: [
                      e.jsx("legend", {
                        className: "px-1 text-sm font-medium",
                        children: "Options",
                      }),
                      !de &&
                        e.jsxs("div", {
                          children: [
                            e.jsx("p", {
                              className: "mb-1 text-sm",
                              children: "Make a",
                            }),
                            e.jsx("div", {
                              className: "flex flex-wrap gap-2",
                              role: "group",
                              "aria-label": "Output format",
                              children: Nt.map((t) =>
                                e.jsx(
                                  N,
                                  {
                                    type: "button",
                                    size: "sm",
                                    variant: m === t.id ? "default" : "outline",
                                    "aria-pressed": m === t.id,
                                    onClick: () => Te(t.id),
                                    children: t.label,
                                  },
                                  t.id,
                                ),
                              ),
                            }),
                            c &&
                              e.jsx("p", {
                                className: "mt-1 text-xs text-muted-foreground",
                                children:
                                  "You can switch the output now without reading the pictures again.",
                              }),
                          ],
                        }),
                      e.jsxs("div", {
                        className: "flex flex-wrap items-center gap-2 text-sm",
                        children: [
                          e.jsx("label", {
                            htmlFor: "scan-lang",
                            className: "text-muted-foreground",
                            children: "Language of the text",
                          }),
                          e.jsx("select", {
                            id: "scan-lang",
                            value: xe,
                            onChange: (t) => {
                              (Ee(t.target.value), f());
                            },
                            className:
                              "h-9 rounded-md border bg-background px-2 text-sm",
                            children: rt.map((t) =>
                              e.jsx(
                                "option",
                                { value: t.id, children: t.label },
                                t.id,
                              ),
                            ),
                          }),
                          e.jsx("p", {
                            className:
                              "basis-full text-xs text-muted-foreground",
                            children:
                              "The wrong language gives wrong characters, and accents are lost unless the language is chosen. The first reading downloads the language data.",
                          }),
                        ],
                      }),
                      e.jsxs("label", {
                        className: "flex items-start gap-2 text-sm",
                        children: [
                          e.jsx("input", {
                            type: "checkbox",
                            className: "mt-1",
                            checked: he,
                            onChange: (t) => {
                              (Re(t.target.checked), f());
                            },
                          }),
                          e.jsxs("span", {
                            children: [
                              "Straighten tilted photos ",
                              e.jsx("span", {
                                className: "text-muted-foreground",
                                children:
                                  "(for a page photographed at a slight angle; leave off for screenshots)",
                              }),
                            ],
                          }),
                        ],
                      }),
                      e.jsxs("label", {
                        className: "flex items-start gap-2 text-sm",
                        children: [
                          e.jsx("input", {
                            type: "checkbox",
                            className: "mt-1",
                            checked: pe,
                            onChange: (t) => {
                              (_e(t.target.checked), f());
                            },
                          }),
                          e.jsxs("span", {
                            children: [
                              "Boost contrast ",
                              e.jsx("span", {
                                className: "text-muted-foreground",
                                children:
                                  "(for faded or shadowed paper; it can hurt photographs, so try without it first)",
                              }),
                            ],
                          }),
                        ],
                      }),
                      m === "word" &&
                        e.jsxs(e.Fragment, {
                          children: [
                            e.jsxs("div", {
                              className:
                                "flex flex-wrap items-center gap-2 text-sm",
                              children: [
                                e.jsx("label", {
                                  htmlFor: "scan-page",
                                  className: "text-muted-foreground",
                                  children: "Page size",
                                }),
                                e.jsxs("select", {
                                  id: "scan-page",
                                  value: J,
                                  onChange: (t) => Fe(t.target.value),
                                  className:
                                    "h-9 rounded-md border bg-background px-2 text-sm",
                                  children: [
                                    e.jsx("option", {
                                      value: "letter",
                                      children: "US Letter",
                                    }),
                                    e.jsx("option", {
                                      value: "a4",
                                      children: "A4",
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            e.jsxs("label", {
                              className: "flex items-center gap-2 text-sm",
                              children: [
                                e.jsx("input", {
                                  type: "checkbox",
                                  checked: I,
                                  onChange: (t) => De(t.target.checked),
                                }),
                                "Also put the original picture above its text",
                              ],
                            }),
                          ],
                        }),
                      m === "excel" &&
                        e.jsxs(e.Fragment, {
                          children: [
                            e.jsxs("label", {
                              className: "flex items-center gap-2 text-sm",
                              children: [
                                e.jsx("input", {
                                  type: "checkbox",
                                  checked: g.joinContinued,
                                  onChange: (t) =>
                                    O((s) => ({
                                      ...s,
                                      joinContinued: t.target.checked,
                                    })),
                                }),
                                "Join a table that continues on the next picture ",
                                c &&
                                  e.jsx("span", {
                                    className: "text-muted-foreground",
                                    children: "(resets your edits)",
                                  }),
                              ],
                            }),
                            e.jsxs("label", {
                              className: "flex items-center gap-2 text-sm",
                              children: [
                                e.jsx("input", {
                                  type: "checkbox",
                                  checked: g.sheetMode === "single",
                                  onChange: (t) =>
                                    O((s) => ({
                                      ...s,
                                      sheetMode: t.target.checked
                                        ? "single"
                                        : "table",
                                    })),
                                }),
                                "Put every table on one sheet (otherwise one sheet per table)",
                              ],
                            }),
                            e.jsxs("label", {
                              className: "flex items-center gap-2 text-sm",
                              children: [
                                e.jsx("input", {
                                  type: "checkbox",
                                  checked: g.convertValues,
                                  onChange: (t) =>
                                    O((s) => ({
                                      ...s,
                                      convertValues: t.target.checked,
                                    })),
                                }),
                                "Write numbers and dates as real values (so they can be summed and sorted)",
                              ],
                            }),
                            g.convertValues &&
                              e.jsxs("div", {
                                className:
                                  "flex flex-wrap items-center gap-2 text-sm pl-6",
                                children: [
                                  e.jsx("label", {
                                    htmlFor: "scan-date",
                                    className: "text-muted-foreground",
                                    children: "Dates like 09/02/2026 are:",
                                  }),
                                  e.jsx("select", {
                                    id: "scan-date",
                                    value: g.dateOrder,
                                    onChange: (t) =>
                                      O((s) => ({
                                        ...s,
                                        dateOrder: t.target.value,
                                      })),
                                    className:
                                      "h-9 rounded-md border bg-background px-2 text-sm",
                                    children: yt.map((t) =>
                                      e.jsx(
                                        "option",
                                        { value: t.id, children: t.label },
                                        t.id,
                                      ),
                                    ),
                                  }),
                                ],
                              }),
                          ],
                        }),
                    ],
                  }),
                  be &&
                    e.jsxs(y, {
                      role: "alert",
                      className: "flex gap-2 text-sm",
                      children: [
                        e.jsx(Xe, { className: "h-4 w-4 shrink-0 mt-0.5" }),
                        e.jsx("p", { children: be }),
                      ],
                    }),
                  e.jsxs("div", {
                    className: "flex flex-wrap gap-3",
                    children: [
                      e.jsxs(N, {
                        onClick: Ae,
                        disabled: F,
                        className: "gap-2",
                        children: [
                          e.jsx(bt, { className: "h-4 w-4" }),
                          " ",
                          c ? "Read again" : "Read the pictures",
                        ],
                      }),
                      e.jsx(N, {
                        variant: "outline",
                        onClick: $e,
                        children: "Start over",
                      }),
                    ],
                  }),
                  c &&
                    e.jsxs("div", {
                      className: "space-y-4",
                      "aria-live": "polite",
                      children: [
                        e.jsxs(oe, {
                          className: "p-4 space-y-2",
                          children: [
                            e.jsxs("p", {
                              className: "text-sm font-medium",
                              children: [
                                "Read ",
                                j(c.length, "picture"),
                                se !== null ? ` · about ${se}% confidence` : "",
                                ". Correct anything wrong below, then download.",
                              ],
                            }),
                            c.flatMap((t, s) =>
                              t.notes.map((a) =>
                                e.jsxs(
                                  "p",
                                  {
                                    className: "text-xs text-muted-foreground",
                                    children: ["Picture ", s + 1, ": ", a],
                                  },
                                  `${s}-${a}`,
                                ),
                              ),
                            ),
                            Je.map((t) =>
                              e.jsxs(
                                y,
                                {
                                  className: "text-xs flex gap-1.5",
                                  children: [
                                    e.jsx(H, {
                                      className: "h-3.5 w-3.5 shrink-0 mt-0.5",
                                    }),
                                    t,
                                  ],
                                },
                                t,
                              ),
                            ),
                          ],
                        }),
                        m !== "excel"
                          ? e.jsxs("div", {
                              className: "space-y-3",
                              children: [
                                e.jsxs("p", {
                                  className: "text-sm font-medium",
                                  children: [
                                    "Edit the text ",
                                    e.jsx("span", {
                                      className:
                                        "font-normal text-muted-foreground",
                                      children:
                                        "(a blank line starts a new paragraph)",
                                    }),
                                  ],
                                }),
                                c.map((t, s) =>
                                  e.jsxs(
                                    "div",
                                    {
                                      className:
                                        "grid gap-2 sm:grid-cols-[8rem_1fr] rounded-lg border p-3",
                                      children: [
                                        e.jsx("img", {
                                          src: B[s],
                                          alt: `Picture ${s + 1}: ${t.reading.name}`,
                                          className:
                                            "max-h-32 w-auto rounded border object-contain",
                                        }),
                                        e.jsxs("div", {
                                          children: [
                                            e.jsxs("label", {
                                              htmlFor: `scan-text-${s}`,
                                              className:
                                                "text-xs text-muted-foreground",
                                              children: [
                                                c.length > 1
                                                  ? `Page ${s + 1}`
                                                  : "Text",
                                                " · ",
                                                t.reading.name,
                                              ],
                                            }),
                                            e.jsx("textarea", {
                                              id: `scan-text-${s}`,
                                              value: L[s] ?? "",
                                              onChange: (a) =>
                                                X((n) =>
                                                  n.map((l, o) =>
                                                    o === s
                                                      ? a.target.value
                                                      : l,
                                                  ),
                                                ),
                                              rows: Math.min(
                                                14,
                                                Math.max(
                                                  4,
                                                  (L[s] ?? "").split(`
`).length + 1,
                                                ),
                                              ),
                                              className:
                                                "mt-1 w-full rounded-md border bg-background p-2 text-sm",
                                              placeholder:
                                                "No text was found in this picture.",
                                            }),
                                          ],
                                        }),
                                      ],
                                    },
                                    `${s}-${t.reading.name}`,
                                  ),
                                ),
                                m === "word"
                                  ? e.jsxs("div", {
                                      className: "space-y-2",
                                      children: [
                                        Z &&
                                          e.jsx(y, {
                                            role: "alert",
                                            className: "text-xs",
                                            children: Z,
                                          }),
                                        E &&
                                          E.pictureOnly > 0 &&
                                          e.jsxs(y, {
                                            className: "text-xs flex gap-1.5",
                                            children: [
                                              e.jsx(H, {
                                                className:
                                                  "h-3.5 w-3.5 shrink-0 mt-0.5",
                                              }),
                                              j(E.pictureOnly, "page"),
                                              " with no text will be a picture in the Word file.",
                                            ],
                                          }),
                                        e.jsx("div", {
                                          className: "flex flex-wrap gap-3",
                                          children: E
                                            ? e.jsx(le, {
                                                blob: E.blob,
                                                fileName: `${te}.docx`,
                                                label: "Download Word File",
                                              })
                                            : e.jsx(N, {
                                                disabled: !0,
                                                children: Z
                                                  ? "Word file unavailable"
                                                  : "Preparing the Word file…",
                                              }),
                                        }),
                                        e.jsx("p", {
                                          className:
                                            "text-xs text-muted-foreground",
                                          children:
                                            "The Word file holds the text as plain paragraphs. Columns, fonts, bold and tables in the original are not recreated; for a table use Excel.",
                                        }),
                                      ],
                                    })
                                  : e.jsxs("div", {
                                      className: "flex flex-wrap gap-3",
                                      children: [
                                        e.jsx(le, {
                                          blob: Ve,
                                          fileName: `${te}.txt`,
                                          label: "Download .txt",
                                        }),
                                        e.jsxs(N, {
                                          variant: "outline",
                                          onClick: Ge,
                                          className: "gap-1.5",
                                          children: [
                                            e.jsx(jt, { className: "h-4 w-4" }),
                                            " Copy",
                                          ],
                                        }),
                                      ],
                                    }),
                              ],
                            })
                          : e.jsxs("div", {
                              className: "space-y-3",
                              children: [
                                v.length === 0
                                  ? e.jsxs(oe, {
                                      className: "p-4 space-y-2",
                                      role: "status",
                                      children: [
                                        e.jsx("p", {
                                          className: "text-sm font-medium",
                                          children: x?.anyText
                                            ? "No table was found in these pictures."
                                            : "No readable text was found in these pictures.",
                                        }),
                                        e.jsx("p", {
                                          className:
                                            "text-sm text-muted-foreground",
                                          children: x?.anyText
                                            ? "A table needs at least three rows whose columns line up with visible gaps between them. Ordinary paragraphs and two-column text are not treated as tables. A straighter, larger picture helps. If you only need the words, you can put each line of text in its own row, or make a Word file instead."
                                            : "A clearer or larger picture may help, and the language must match the text.",
                                        }),
                                        x?.anyText &&
                                          e.jsx(N, {
                                            size: "sm",
                                            variant: "outline",
                                            onClick: ze,
                                            children:
                                              "Put each line of text in its own row",
                                          }),
                                      ],
                                    })
                                  : e.jsxs(e.Fragment, {
                                      children: [
                                        e.jsxs("p", {
                                          className: "text-sm font-medium",
                                          children: [
                                            "Check the table",
                                            v.length > 1 ? "s" : "",
                                            " ",
                                            e.jsx("span", {
                                              className:
                                                "font-normal text-muted-foreground",
                                              children:
                                                "(edit any cell; this is exactly what goes into the spreadsheet)",
                                            }),
                                          ],
                                        }),
                                        Oe &&
                                          e.jsx(y, {
                                            className: "text-xs",
                                            children:
                                              "These are not detected tables: each line of text was put in its own row.",
                                          }),
                                        v.map((t, s) =>
                                          e.jsxs(
                                            "div",
                                            {
                                              className:
                                                "rounded-lg border p-3 space-y-2",
                                              children: [
                                                e.jsxs("div", {
                                                  className:
                                                    "flex flex-wrap items-center justify-between gap-2",
                                                  children: [
                                                    e.jsxs("p", {
                                                      className:
                                                        "text-xs font-medium",
                                                      children: [
                                                        "Table ",
                                                        s + 1,
                                                        " · ",
                                                        j(t.rows.length, "row"),
                                                        " · picture",
                                                        t.pages.length > 1
                                                          ? "s"
                                                          : "",
                                                        " ",
                                                        t.pages.join(", "),
                                                      ],
                                                    }),
                                                    e.jsxs("label", {
                                                      className:
                                                        "flex items-center gap-1.5 text-xs",
                                                      children: [
                                                        e.jsx("input", {
                                                          type: "checkbox",
                                                          checked:
                                                            t.headerRows > 0,
                                                          onChange: (a) =>
                                                            Ue(
                                                              s,
                                                              a.target.checked,
                                                            ),
                                                        }),
                                                        " First row is a heading",
                                                      ],
                                                    }),
                                                  ],
                                                }),
                                                e.jsx("div", {
                                                  className:
                                                    "max-h-[26rem] overflow-auto",
                                                  children: e.jsx("table", {
                                                    className:
                                                      "text-xs border-collapse",
                                                    children: e.jsx("tbody", {
                                                      children: t.rows
                                                        .slice(0, ie)
                                                        .map((a, n) =>
                                                          e.jsxs(
                                                            "tr",
                                                            {
                                                              className:
                                                                n < t.headerRows
                                                                  ? "bg-muted/50 font-medium"
                                                                  : "",
                                                              children: [
                                                                a.map((l, o) =>
                                                                  e.jsx(
                                                                    "td",
                                                                    {
                                                                      className:
                                                                        "border p-0",
                                                                      children:
                                                                        e.jsx(
                                                                          "input",
                                                                          {
                                                                            value:
                                                                              l,
                                                                            onChange:
                                                                              (
                                                                                d,
                                                                              ) =>
                                                                                Me(
                                                                                  s,
                                                                                  n,
                                                                                  o,
                                                                                  d
                                                                                    .target
                                                                                    .value,
                                                                                ),
                                                                            "aria-label": `Table ${s + 1} row ${n + 1} column ${o + 1}`,
                                                                            className:
                                                                              "w-full min-w-[5rem] bg-transparent px-1.5 py-1",
                                                                            size: Math.max(
                                                                              6,
                                                                              Math.min(
                                                                                30,
                                                                                l.length +
                                                                                  1,
                                                                              ),
                                                                            ),
                                                                          },
                                                                        ),
                                                                    },
                                                                    o,
                                                                  ),
                                                                ),
                                                                e.jsx("td", {
                                                                  className:
                                                                    "p-0 pl-1",
                                                                  children:
                                                                    e.jsx(
                                                                      "button",
                                                                      {
                                                                        type: "button",
                                                                        onClick:
                                                                          () =>
                                                                            We(
                                                                              s,
                                                                              n,
                                                                            ),
                                                                        className:
                                                                          "p-1 text-muted-foreground hover:text-foreground",
                                                                        "aria-label": `Delete row ${n + 1} of table ${s + 1}`,
                                                                        children:
                                                                          e.jsx(
                                                                            wt,
                                                                            {
                                                                              className:
                                                                                "h-3 w-3",
                                                                            },
                                                                          ),
                                                                      },
                                                                    ),
                                                                }),
                                                              ],
                                                            },
                                                            n,
                                                          ),
                                                        ),
                                                    }),
                                                  }),
                                                }),
                                                t.rows.length > ie &&
                                                  e.jsxs("p", {
                                                    className:
                                                      "text-xs text-muted-foreground",
                                                    children: [
                                                      "Showing the first ",
                                                      ie,
                                                      " rows for editing; the rest are exported as read.",
                                                    ],
                                                  }),
                                                e.jsxs(N, {
                                                  type: "button",
                                                  size: "sm",
                                                  variant: "ghost",
                                                  onClick: () => Be(s),
                                                  className: "gap-1",
                                                  children: [
                                                    e.jsx(ke, {
                                                      className: "h-3 w-3",
                                                    }),
                                                    " Add a row",
                                                  ],
                                                }),
                                              ],
                                            },
                                            s,
                                          ),
                                        ),
                                      ],
                                    }),
                                h?.kind === "ok" &&
                                  e.jsxs(oe, {
                                    className: "p-4 space-y-2",
                                    children: [
                                      e.jsxs("p", {
                                        className: "text-sm font-medium",
                                        children: [
                                          j(h.summary.tables, "table"),
                                          " · ",
                                          j(h.summary.rows, "row"),
                                          " in ",
                                          j(h.summary.sheets, "sheet"),
                                        ],
                                      }),
                                      e.jsx("p", {
                                        className:
                                          "text-xs text-muted-foreground",
                                        children:
                                          h.summary.numericCells > 0 ||
                                          h.summary.dateCells > 0
                                            ? `${j(h.summary.numericCells, "number")}${h.summary.dateCells ? ` and ${j(h.summary.dateCells, "date")}` : ""} written as real values.`
                                            : g.convertValues
                                              ? "No numeric or date columns were recognised, so everything is text."
                                              : "Everything is written as text, as chosen.",
                                      }),
                                      h.summary.notes.map((t) =>
                                        e.jsxs(
                                          y,
                                          {
                                            className: "text-xs flex gap-1.5",
                                            children: [
                                              e.jsx(H, {
                                                className:
                                                  "h-3.5 w-3.5 shrink-0 mt-0.5",
                                              }),
                                              t,
                                            ],
                                          },
                                          t,
                                        ),
                                      ),
                                      e.jsx(le, {
                                        blob: h.blob,
                                        fileName: `${te}.xlsx`,
                                        label: "Download Excel File",
                                      }),
                                    ],
                                  }),
                                ae &&
                                  e.jsxs("div", {
                                    className: "space-y-2",
                                    children: [
                                      ae.observations.map((t) =>
                                        e.jsxs(
                                          y,
                                          {
                                            className: "text-xs flex gap-1.5",
                                            children: [
                                              e.jsx(H, {
                                                className:
                                                  "h-3.5 w-3.5 shrink-0 mt-0.5",
                                              }),
                                              t,
                                            ],
                                          },
                                          t,
                                        ),
                                      ),
                                      e.jsxs("details", {
                                        className: "rounded-lg border p-3",
                                        children: [
                                          e.jsx("summary", {
                                            className:
                                              "cursor-pointer text-sm font-medium",
                                            children: "What this cannot do",
                                          }),
                                          e.jsx("ul", {
                                            className:
                                              "mt-2 list-disc pl-5 space-y-1 text-xs text-muted-foreground",
                                            children: ae.limitations.map((t) =>
                                              e.jsx("li", { children: t }, t),
                                            ),
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                              ],
                            }),
                      ],
                    }),
                ],
              }),
          e.jsxs("p", {
            className: "text-xs text-muted-foreground",
            children: [
              de
                ? e.jsxs(e.Fragment, {
                    children: [
                      "Need something else? ",
                      e.jsx(G, {
                        href: "/tool/scan-to-document",
                        className: "underline text-primary",
                        children: "Scan or Photo to Word, Excel or Text",
                      }),
                      " makes all three. ",
                    ],
                  })
                : null,
              "Scanned PDF instead? Use ",
              e.jsx(G, {
                href: "/tool/pdf-to-word",
                className: "underline text-primary",
                children: "PDF to Word",
              }),
              ", ",
              e.jsx(G, {
                href: "/tool/pdf-to-excel",
                className: "underline text-primary",
                children: "PDF to Excel",
              }),
              " or ",
              e.jsx(G, {
                href: "/tool/ocr-pdf",
                className: "underline text-primary",
                children: "OCR PDF",
              }),
              ". Up to ",
              ce.maxImages,
              " pictures, ",
              Math.round(ce.maxFileBytes / 1024 / 1024),
              " MB each. Nothing is uploaded or stored.",
            ],
          }),
        ],
      });
}
function Pe({ problems: S }) {
  return e.jsx(y, {
    role: "status",
    className: "text-xs space-y-1",
    children: S.map((R) => e.jsx("p", { children: R }, R)),
  });
}
export { Ut as S };
//# sourceMappingURL=ScanConverter-Di_4PqSS.js.map
