// ToolPage-DrleSM7T.js (prettified) excerpts: DownloadButton ql (lines 3131-3260) and la() hook (4620-4665)
function ql({
  onClick: e,
  label: t = "Download",
  disabled: n,
  blob: a,
  fileName: i,
  markHint: d,
  shareText: h,
  shareTitle: l,
  enableShare: c = !0,
  toolId: u,
  category: p,
  freeDownload: f = !1,
  gate: g,
  subtitle: b,
  stacked: y = !1,
  pinned: m,
  hideMarkNoticeOnPhone: w = !1,
}) {
  const { isAuthenticated: I } = Pe(),
    { logUsageNow: v } = la(),
    T = ee.usage.log.useMutation(),
    A = ee.useUtils(),
    N = pe(),
    C = Yo(),
    [, E] = No();
  Wt();
  const x = u ?? N.id ?? "unknown",
    _ = p ?? J(x)?.category ?? "unknown",
    j = !!C && C.currentStepIndex >= C.steps.length - 1,
    q = i && C && j ? C.finalName(i) : i,
    [D, W] = s.useState(!1),
    P = s.useMemo(
      () =>
        !a || !q
          ? null
          : new File([a], q, { type: a.type || "application/octet-stream" }),
      [a, q],
    ),
    $ = C?.recordOutput,
    F = C?.currentStepIndex ?? 0;
  s.useEffect(() => {
    $ && a && i && $(F, i, a.size, a);
  }, [$, F, a, i]);
  const K = c && P ? na(P) : !1,
    Y = c && !K && !!h && ra(),
    Z = () => {
      if (!(x === "unknown" || _ === "unknown") && !Ge(x)) {
        Eo(x);
        try {
          const L = I ? void 0 : ke();
          T.mutate(
            { toolId: x, category: _, deviceId: L },
            { onSuccess: () => A.usage.check.invalidate() },
          );
        } catch {}
      }
    },
    se = async () => (f ? !0 : g ? At(g) : u ? (Z(), !0) : v("download")),
    k = async () => {
      if (await se()) {
        if (a && q) {
          vt(a, q, { free: !0 });
          return;
        }
        e?.();
      }
    },
    V = async () => {
      if (await se())
        try {
          if (a && q) {
            (await Zn(a, q, { title: l || q })) || vt(a, q, { free: !0 });
            return;
          }
          h && (await Qn(h, { title: l }));
        } catch (L) {
          if (L instanceof DOMException && L.name === "AbortError") return;
          (console.error(L),
            a &&
              q &&
              (vt(a, q, { free: !0 }),
              M.info(
                "Sharing isn't available here — downloaded the file instead.",
              )));
        }
    };
  return o.jsxs("div", {
    className: `flex flex-wrap items-center gap-2 ${y ? "w-full" : ""}`,
    children: [
      (() => {
        const L = a && i ? i : d;
        return !L || !Re(a && i ? a.type : "", L, x)
          ? null
          : o.jsxs("p", {
              className: `w-full order-last text-xs text-muted-foreground${w ? " max-sm:hidden" : ""}`,
              "data-testid": "trial-mark-notice",
              children: [
                lt(a && i ? a.type : "", L) === "pdf"
                  ? "This download will carry a small “Created with FreeDailyPro.com” badge in the bottom right corner of each page."
                  : "This download will carry small “Created with FreeDailyPro.com” badges in the top and bottom right corners.",
                " ",
                o.jsx("button", {
                  type: "button",
                  className:
                    "underline underline-offset-2 hover:text-foreground",
                  onClick: () => E("/pricing"),
                  children: "Go paid to avoid the mark",
                }),
                ".",
              ],
            });
      })(),
      y
        ? o.jsxs(G, {
            onClick: () => {
              k();
            },
            disabled: n,
            className:
              "gap-3 h-auto min-h-14 w-full sm:w-auto whitespace-normal text-left py-2",
            "data-testid": "download-stacked",
            children: [
              o.jsx(ze, { className: "h-4 w-4 shrink-0" }),
              o.jsxs("span", {
                className: "flex min-w-0 flex-col items-start",
                children: [
                  o.jsx("span", { className: "break-words", children: t }),
                  (b || !f) &&
                    o.jsxs("span", {
// ...
      async (y) => {
        if (c) return "allowed";
        if (u) return pt(t, h, p, f);
        const m = Do(t, y);
        if (m === "free") return "allowed";
        await et(h, p);
        const w = m === "first" ? await pt(t, h, p, f) : await za(h, p, f);
        return (w === "allowed" && (Ra(t, y), m !== "first" && Ua(t)), w);
      },
      [c, u, t, h, p, f],
    );
  return {
    known: l,
    scope: h,
    fetcher: p,
    tryUse: g,
    tryUseExport: b,
    paid: c,
    toolId: t,
  };
}
function la() {
  const { known: e, tryUse: t, tryUseExport: n, toolId: a } = nr(),
    i = s.useCallback(
      async (h) =>
        e
          ? At(async () => ((await t()) === "blocked" ? (tt(a, h), !1) : !0), {
              explainFalse: !0,
            })
          : !0,
      [e, t, a],
    ),
    d = s.useCallback(
      async (h) =>
        e
          ? At(
              async () =>
                (await n(h)) === "blocked" ? (tt(a, "download"), !1) : !0,
              { explainFalse: !0 },
            )
          : !0,
      [e, n, a],
    );
  return { logUsageNow: i, logExportNow: d };
}
function rr() {
// index-xgcQ0Xo8.js usage store (minified):
function dI(e,t){const o=ua.get(e);return o?.has(t)?"free":o&&o.size>0?"again":"first"}function uI(e,t){let o=ua.get(e);o||ua.set(e,o=new Set),o.add(t)}function CA(e){ua.delete(e)}const Ps={"merge-pdf":["gated","
function wI(e){CA(e),Kt.delete(e),Xr.delete(e),As.delete(e)}function xI(e,t,o,r){if(qi(e))return af(e),Promise.resolve("allowed");if(Kt.has(e))return Promise.resolve("allowed");const a=Xr.get(e);if(a)return a;const s=MA(t,o,r).then(i=>(i==="allowed"&&(Kt.has(e)||Va(e),Kt.add(e)),Xr.delete(e),i));return Xr.set(e,s),s}function kI(e){Va(e)}fun
