const e = {};
function f(t, n) {
  e[t] = n.slice(0, 50);
}
function o(t) {
  const n = e[t] ?? [];
  return (delete e[t], n);
}
export { f as s, o as t };
//# sourceMappingURL=fileHandoff-RQJcoDih.js.map
