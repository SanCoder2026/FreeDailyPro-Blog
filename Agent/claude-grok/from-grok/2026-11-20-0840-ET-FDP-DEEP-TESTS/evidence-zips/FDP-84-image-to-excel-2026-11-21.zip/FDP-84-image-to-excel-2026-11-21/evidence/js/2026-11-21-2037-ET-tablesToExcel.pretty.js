import { l as W } from "./pdfLayout-BswErtWz.js";
import { utils as A, write as Y } from "./xlsx-CNerDvZX.js";
const V = /^[^gjpqyQ,;()[\]{}|/\\$]+$/,
  P = (t) => {
    const e = [...t].sort((n, o) => n - o);
    return e[Math.floor(e.length / 2)] ?? 0;
  };
function Z(t, e, n) {
  return t.length < 3 || !e || n <= 0 || e.x1 - e.x0 > 0.15 * n
    ? !1
    : !t.some(
        (o) =>
          (o.text.match(/[A-Za-z\u00C0-\u024F\u0370-\u04FF]/g) ?? []).length >=
          3,
      );
}
function he(t, e, n) {
  const o = [];
  let s = 0;
  for (const r of t.blocks ?? [])
    for (const u of r.paragraphs ?? [])
      for (const a of u.lines ?? []) s = Math.max(s, a.bbox?.x1 ?? 0);
  for (const r of t.blocks ?? [])
    for (const u of r.paragraphs ?? [])
      for (const a of u.lines ?? []) {
        const l = (a.words ?? []).filter(
          (d) => d.text && d.text.trim() && d.bbox,
        );
        if (!l.length || Z(l, a.bbox, s)) continue;
        const i = l.map((d) => d.bbox.y1 - d.bbox.y0),
          c = P(i),
          x = l.filter((d) => V.test(d.text)),
          h = x.length
            ? P(x.map((d) => d.bbox.y1))
            : P(l.map((d) => d.bbox.y1)) - 0.2 * c,
          g = x.map((d) => d.bbox.y1 - d.bbox.y0).sort((d, k) => d - k),
          C = g.length ? g[Math.floor(g.length * 0.75)] : 0,
          y = Math.max(6, C ? (C * n) / 0.72 : (c * n) / 0.95);
        for (const d of l) {
          const k = d.bbox;
          o.push({
            str: d.text.trim(),
            x: k.x0 * e,
            baseline: h * n,
            width: Math.max(1, (k.x1 - k.x0) * e),
            size: y,
            bold: !1,
            italic: !1,
          });
        }
      }
  return o;
}
const S = "$€£¥₹",
  I = /[    ]/g,
  q = /[−–‒]/g;
function H(t) {
  let e = t.replace(I, " ").replace(q, "-").trim();
  if (!e || e.length > 30) return null;
  let n = !1;
  const o = /^\((.*)\)$/.exec(e);
  (o && ((n = !0), (e = o[1].trim())),
    /-$/.test(e) && !/^-/.test(e) && ((n = !n), (e = e.slice(0, -1).trim())));
  let s = "";
  const r = /^([+-])\s*/.exec(e);
  r && ((s = r[1]), (e = e.slice(r[0].length)));
  let u,
    a = !1;
  if (e.length && S.includes(e[0])) {
    ((u = e[0]), (e = e.slice(1).trim()));
    const y = /^([+-])\s*/.exec(e);
    y && !s && ((s = y[1]), (e = e.slice(y[0].length)));
  } else
    e.length &&
      S.includes(e[e.length - 1]) &&
      ((u = e[e.length - 1]), (a = !0), (e = e.slice(0, -1).trim()));
  let l = !1;
  if (
    (e.endsWith("%") && ((l = !0), (e = e.slice(0, -1).trim())),
    s === "-" && (n = !n),
    !e || !/^\d[\d.,]*$|^[.,]\d+$/.test(e))
  )
    return null;
  let i,
    c = "",
    x = !1,
    h;
  if ((h = /^(\d{1,3}(?:,\d{3})+)(?:\.(\d+))?$/.exec(e)))
    ((i = h[1].replace(/,/g, "")), (c = h[2] ?? ""), (x = !0));
  else if ((h = /^(\d{1,3}(?:\.\d{3})+),(\d+)$/.exec(e)))
    ((i = h[1].replace(/\./g, "")), (c = h[2]), (x = !0));
  else if ((h = /^(\d+)\.(\d+)$/.exec(e))) ((i = h[1]), (c = h[2]));
  else if ((h = /^(\d+),(\d{1,2})$/.exec(e))) ((i = h[1]), (c = h[2]));
  else if ((h = /^(\d+)$/.exec(e))) i = h[1];
  else if ((h = /^\.(\d+)$/.exec(e))) ((i = "0"), (c = h[1]));
  else return null;
  if ((i.length > 1 && i.startsWith("0")) || i.length + c.length > 15)
    return null;
  let g = +`${i}.${c || "0"}`;
  if (!Number.isFinite(g)) return null;
  const C = c.length;
  return (
    l && (g = Number((g / 100).toFixed(C + 2))),
    n && (g = -g),
    {
      value: g,
      kind: l ? "percent" : u ? "currency" : "plain",
      symbol: u,
      symbolAfter: a,
      decimals: C,
      thousands: x,
    }
  );
}
function G(t, e, n, o, s = !1) {
  const r = n > 0 ? "." + "0".repeat(n) : "";
  if (t === "percent") return `0${r}%`;
  const u = `${o || t === "currency" ? "#,##0" : "0"}${r}`;
  return t === "currency" && e ? (s ? `${u}" ${e}"` : `"${e}"${u}`) : u;
}
const K = [
    "jan",
    "feb",
    "mar",
    "apr",
    "may",
    "jun",
    "jul",
    "aug",
    "sep",
    "oct",
    "nov",
    "dec",
  ],
  j = (t) => K.indexOf(t.slice(0, 3).toLowerCase());
function T(t, e, n) {
  if (e < 1 || e > 12 || n < 1) return null;
  const o = new Date(Date.UTC(t, e - 1, n));
  return o.getUTCFullYear() !== t ||
    o.getUTCMonth() !== e - 1 ||
    o.getUTCDate() !== n
    ? null
    : Math.round(o.getTime() / 864e5) + 25569;
}
const L = (t) => {
  if (t.length === 4) return Number(t);
  const e = Number(t);
  return e <= 49 ? 2e3 + e : 1900 + e;
};
function U(t) {
  const e = t.replace(I, " ").trim();
  if (!e || e.length > 30) return null;
  let n;
  if ((n = /^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/.exec(e))) {
    const o = T(Number(n[1]), Number(n[2]), Number(n[3]));
    return o === null
      ? null
      : { options: [{ serial: o, order: "fixed" }], format: "yyyy-mm-dd" };
  }
  if ((n = /^(\d{1,2})([/.-])(\d{1,2})\2(\d{4}|\d{2})$/.exec(e))) {
    const o = Number(n[1]),
      s = Number(n[3]),
      r = L(n[4]),
      u = n[2],
      a = [],
      l = T(r, s, o),
      i = T(r, o, s);
    return (
      l !== null && l === i
        ? a.push({ serial: l, order: "fixed" })
        : (l !== null && a.push({ serial: l, order: "dmy" }),
          i !== null && a.push({ serial: i, order: "mdy" })),
      a.length
        ? {
            options: a,
            format: "",
            numeric: { sep: u, twoDigitYear: n[4].length === 2 },
          }
        : null
    );
  }
  if ((n = /^(\d{1,2})[ -]([A-Za-z]{3,9})\.?,?[ -](\d{4}|\d{2})$/.exec(e))) {
    const o = j(n[2]);
    if (o < 0) return null;
    const s = T(L(n[3]), o + 1, Number(n[1]));
    return s === null
      ? null
      : { options: [{ serial: s, order: "fixed" }], format: "d mmm yyyy" };
  }
  if ((n = /^([A-Za-z]{3,9})\.? (\d{1,2}),? (\d{4})$/.exec(e))) {
    const o = j(n[1]);
    if (o < 0) return null;
    const s = T(Number(n[3]), o + 1, Number(n[2]));
    return s === null
      ? null
      : { options: [{ serial: s, order: "fixed" }], format: "d mmm yyyy" };
  }
  return null;
}
function Q(t, e, n) {
  const o = n ? "yy" : "yyyy";
  return e === "dmy" ? `dd${t}mm${t}${o}` : `mm${t}dd${t}${o}`;
}
const X =
    /\b(id|ids|no\.?|num|number|code|zip|zipcode|postcode|postal|phone|tel|mobile|account|acct|ref|reference|sku|isbn|iban|ssn|pin|invoice|order|serial|barcode)\b|#/i,
  O = 0.8;
function J(t, e, n = "auto") {
  const o = Math.max(0, ...t.map((l) => l.length)),
    s = t.map((l) =>
      Array.from({ length: o }, (i, c) => ({ t: "s", v: l[c] ?? "" })),
    ),
    r = [];
  let u = 0,
    a = 0;
  for (let l = 0; l < o; l++) {
    const i = t
        .slice(0, e)
        .map((f) => f[l] ?? "")
        .join(" "),
      c = X.test(i),
      x = [];
    for (let f = e; f < t.length; f++) {
      const p = (t[f][l] ?? "").trim();
      p && x.push({ row: f, text: p });
    }
    if (x.length === 0) continue;
    const h = x.map((f) => ({ ...f, parsed: U(f.text) })),
      g = h.filter((f) => f.parsed).length;
    if (g / x.length >= O && g >= 1) {
      let f = null;
      const p = new Set();
      for (const m of h) {
        if (!m.parsed) continue;
        const w = m.parsed.options
          .map((b) => b.order)
          .filter((b) => b !== "fixed");
        w.length === 1 && p.add(w[0]);
      }
      if (p.size === 1) {
        if (((f = Array.from(p)[0]), n !== "auto" && n !== f)) {
          const m = h.find(
            (w) =>
              w.parsed &&
              w.parsed.options.filter((b) => b.order !== "fixed").length ===
                1 &&
              w.parsed.options.length === 1 &&
              w.parsed.numeric,
          )?.text;
          r.push(
            `These dates can only be ${f === "mdy" ? "month-first" : "day-first"}${m ? ` (for example ${m})` : ""}, so that order was used.`,
          );
        }
      } else p.size === 0 && n !== "auto" && (f = n);
      const $ = h.some(
        (m) =>
          m.parsed &&
          m.parsed.options.length > 1 &&
          m.parsed.options.every((w) => w.order !== "fixed"),
      );
      if (p.size === 2) {
        r.push(
          `Column ${l + 1} mixes day-first and month-first dates, so its dates were left as text.`,
        );
        continue;
      }
      if ($ && !f) {
        r.push(
          `Dates like ${h.find((m) => m.parsed && m.parsed.options.length > 1).text} could be day-first or month-first, so they were left as text. Choose the date order above and convert again to get real dates.`,
        );
        continue;
      }
      let N = 0;
      const M = [];
      for (const m of h) {
        if (!m.parsed) continue;
        const w =
          m.parsed.options.find((R) => R.order === "fixed") ??
          (f ? m.parsed.options.find((R) => R.order === f) : void 0);
        if (!w) continue;
        let b = m.parsed.format;
        if (m.parsed.numeric) {
          const R =
            w.order !== "fixed" ? w.order : (f ?? (n !== "auto" ? n : "mdy"));
          b = Q(m.parsed.numeric.sep, R, m.parsed.numeric.twoDigitYear);
        }
        (M.push({ row: m.row, serial: w.serial, fmt: b }), N++);
      }
      if (N === g) {
        for (const m of M) s[m.row][l] = { t: "d", v: m.serial, z: m.fmt };
        a += N;
        continue;
      }
    }
    if (c) continue;
    const C = x.map((f) => ({ ...f, parsed: H(f.text) })),
      y = C.filter((f) => f.parsed);
    if (y.length === 0) continue;
    const d = C.filter((f) => !f.parsed).every((f) =>
        /[A-Za-z\u00C0-\u024F\u0370-\u03FF\u0400-\u04FF]{3,}/.test(f.text),
      ),
      k = y.length / x.length;
    if (k < O && !(d && k >= 0.5 && y.length >= 2)) continue;
    const E = new Map();
    for (const f of y)
      (
        E.get(f.parsed.kind) ?? E.set(f.parsed.kind, []).get(f.parsed.kind)
      ).push(f.parsed);
    const v = new Map();
    for (const [f, p] of Array.from(E)) {
      const $ = Math.max(...p.map((b) => b.decimals)),
        N = p.some((b) => b.thousands),
        M = p.map((b) => b.symbol).filter(Boolean),
        m =
          M.length >= p.length / 2
            ? M.sort(
                (b, R) =>
                  M.filter((F) => F === R).length -
                  M.filter((F) => F === b).length,
              )[0]
            : void 0,
        w =
          p.filter((b) => b.symbol === m && b.symbolAfter).length >
          p.filter((b) => b.symbol === m).length / 2;
      v.set(f, G(f, m, $, N, w));
    }
    for (const f of y)
      ((s[f.row][l] = { t: "n", v: f.parsed.value, z: v.get(f.parsed.kind) }),
        u++);
  }
  return { cells: s, notes: r, numericCells: u, dateCells: a };
}
function ee(t) {
  return t
    ? /%$/.test(t)
      ? "%"
      : (/^"[^"]*"/.exec(t)?.[0] ?? /"[^"]*"$/.exec(t)?.[0] ?? "")
    : "";
}
function te(t) {
  const e = Array.from(new Set(t));
  if (e.length <= 1) return e[0] ?? "General";
  const n = e.some((i) => i.includes("#,##0")),
    o = Math.max(
      ...e.map(
        (i) => /\.(0+)/.exec(i.replace(/"[^"]*"/g, ""))?.[1].length ?? 0,
      ),
    ),
    s = e.some((i) => /%$/.test(i)),
    r = `${n ? "#,##0" : "0"}${o ? "." + "0".repeat(o) : ""}`;
  if (s) return `${r}%`;
  const u = e.find((i) => i.includes('"'));
  if (!u) return r;
  const a = /^"[^"]*"/.exec(u)?.[0];
  if (a) return `${a}${r}`;
  const l = /"[^"]*"$/.exec(u)?.[0];
  return l ? `${r}${l}` : r;
}
const pe = {
    sheetMode: "table",
    joinContinued: !0,
    convertValues: !0,
    dateOrder: "auto",
  },
  _ = (t) =>
    t.runs
      .map((e) => e.text)
      .join("")
      .replace(/[\t\r\n]+/g, " ")
      .replace(/\s{2,}/g, " ")
      .trim();
function ne(t, e, n) {
  const o = t.rows.map((a) => a.map(_)),
    s = t.rows.map((a) => {
      const l = a.filter((i) => _(i));
      return (
        l.length > 0 &&
        l.every((i) => i.runs.filter((c) => c.text.trim()).every((c) => c.bold))
      );
    }),
    r =
      t.colExtents ??
      t.colWidthsPt.map((a, l) => ({
        left: t.leftPt + l,
        right: t.leftPt + l,
      })),
    u = {
      pages: [e],
      rows: o,
      boldRow: s,
      colExtents: r,
      headerRows: 0,
      fromOcr: n,
    };
  return ((u.headerRows = se(u)), u);
}
function oe(t, e = new Set()) {
  const n = [];
  return (
    t.pages.forEach((o, s) => {
      for (const r of o.blocks) {
        if (r.kind !== "table") continue;
        const u = ne(r, s + 1, e.has(s + 1));
        u.rows.length >= 2 &&
          u.rows.some((a) => a.filter(Boolean).length >= 2) &&
          n.push(u);
      }
    }),
    n
  );
}
const B = (t) => !!(t && (H(t) || U(t)));
function se(t) {
  if (t.rows.length < 2) return 0;
  const e = t.rows[0],
    n = e.filter(Boolean);
  if (n.length === 0 || n.some(B)) return 0;
  const o = t.rows.slice(1),
    s = Math.max(...t.rows.map((a) => a.length));
  let r = 0;
  for (let a = 0; a < s; a++) {
    const l = o.map((i) => i[a] ?? "").filter(Boolean);
    l.length && l.filter(B).length / l.length >= 0.6 && e[a] && r++;
  }
  if (r > 0) return 1;
  const u = t.boldRow[1];
  return t.boldRow[0] && !u ? 1 : 0;
}
const D = (t) =>
  t.map((e) => e.toLowerCase().replace(/\s+/g, " ").trim()).join("|");
function re(t, e) {
  const n = t.pages[t.pages.length - 1];
  return e.pages[0] !== n + 1 || t.colExtents.length !== e.colExtents.length
    ? !1
    : t.colExtents.every((o, s) => {
        const r = e.colExtents[s];
        return Math.min(o.right, r.right) - Math.max(o.left, r.left) > -2;
      });
}
function le(t) {
  const e = [];
  for (const n of t) {
    const o = e[e.length - 1];
    if (o && re(o, n)) {
      let s = n.rows,
        r = n.boldRow;
      const u = o.headerRows > 0 ? D(o.rows[0]) : null;
      (((u !== null && s.length && D(s[0]) === u) ||
        (u === null &&
          n.headerRows === 0 &&
          o.rows.length &&
          s.length &&
          D(s[0]) === D(o.rows[0]))) &&
        ((s = s.slice(1)), (r = r.slice(1))),
        (o.rows = [...o.rows, ...s]),
        (o.boldRow = [...o.boldRow, ...r]),
        (o.pages = [...o.pages, ...n.pages]),
        (o.fromOcr = o.fromOcr || n.fromOcr));
      continue;
    }
    e.push({
      ...n,
      rows: [...n.rows],
      boldRow: [...n.boldRow],
      pages: [...n.pages],
    });
  }
  return e;
}
const ae = (t) => (t.length === 1 ? `p${t[0]}` : `p${t[0]}-${t[t.length - 1]}`);
function ie(t, e) {
  if (e === "single") return t.length ? [{ name: "Tables", tables: t }] : [];
  if (e === "page") {
    const n = new Map();
    for (const o of t)
      for (const s of o.pages) (n.get(s) ?? n.set(s, []).get(s)).push(o);
    return Array.from(n.entries())
      .sort((o, s) => o[0] - s[0])
      .map(([o, s]) => ({ name: `Page ${o}`, tables: s }));
  }
  return t.map((n, o) => ({
    name: `Table ${o + 1} (${ae(n.pages)})`,
    tables: [n],
  }));
}
const ce = 8;
function z(t) {
  let e = "";
  for (t++; t > 0; t = Math.floor((t - 1) / 26))
    e = String.fromCharCode(65 + ((t - 1) % 26)) + e;
  return e;
}
function fe(t, e) {
  const n = A.book_new(),
    o = [],
    s = [];
  let r = 0,
    u = 0,
    a = 0;
  const l = [];
  for (const i of t) {
    const c = {},
      x = [],
      h = [];
    let g = 0,
      C = 0,
      y = 0;
    (i.tables.forEach((d, k) => {
      (k > 0 && g++, k === 0 && (y = d.headerRows));
      const E = e.convertValues
        ? J(d.rows, d.headerRows, e.dateOrder)
        : {
            cells: d.rows.map((v) => v.map((f) => ({ t: "s", v: f }))),
            notes: [],
            numericCells: 0,
            dateCells: 0,
          };
      for (const v of E.notes) {
        const f = i.tables.length > 1 || t.length > 1 ? `${i.name}: ${v}` : v;
        s.includes(f) || s.push(f);
      }
      ((r += E.numericCells),
        (u += E.dateCells),
        E.cells.forEach((v, f) => {
          (v.forEach((p, $) => {
            C = Math.max(C, $ + 1);
            const N = d.rows[f][$] ?? "";
            if (
              ((x[$] = Math.max(x[$] ?? 8, Math.min(60, N.length + 2))),
              p.t === "s")
            )
              p.v !== "" && (c[z($) + (g + 1)] = { t: "s", v: p.v });
            else {
              const M = { t: "n", v: p.v, z: p.z };
              ((c[z($) + (g + 1)] = M),
                l.push({
                  cell: M,
                  key: `${$}|${d.rows
                    .slice(0, d.headerRows)
                    .map((m) => m[$] ?? "")
                    .join(" ")
                    .trim()
                    .toLowerCase()}|${p.t}|${ee(p.z)}`,
                  isDate: p.t === "d",
                }));
            }
          }),
            h.length < ce &&
              h.push(
                v.map((p, $) => ({
                  text: d.rows[f][$] ?? "",
                  numeric: p.t !== "s",
                })),
              ),
            g++,
            a++);
        }));
    }),
      g !== 0 &&
        ((c["!ref"] = `A1:${z(Math.max(0, C - 1))}${g}`),
        (c["!cols"] = x.map((d) => ({ wch: d }))),
        i.tables.length === 1 &&
          y > 0 &&
          g > 2 &&
          (c["!autofilter"] = { ref: c["!ref"] }),
        A.book_append_sheet(n, c, i.name.slice(0, 31)),
        o.push({
          name: i.name,
          tableCount: i.tables.length,
          rowCount: g,
          columnCount: C,
          rows: h,
          headerRows: y,
        })));
  }
  if (t.length > 1) {
    const i = new Map();
    for (const c of l)
      !c.isDate &&
        c.cell.z &&
        (i.get(c.key) ?? i.set(c.key, []).get(c.key)).push(c.cell.z);
    for (const c of l) !c.isDate && c.cell.z && (c.cell.z = te(i.get(c.key)));
  }
  return {
    workbook: n,
    preview: o,
    notes: s,
    numericCells: r,
    dateCells: u,
    rowCount: a,
  };
}
function ue(t) {
  const e = Y(t, { type: "array", bookType: "xlsx", cellDates: !1 });
  return new Blob([e], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
}
function ge(t, e, n) {
  const o = W(t);
  let s = oe(o, e);
  const r = [];
  if (n.joinContinued && n.sheetMode !== "page") {
    const u = s.length;
    if (((s = le(s)), s.length < u))
      for (const a of s)
        a.pages.length > 1 && r.push([a.pages[0], a.pages[a.pages.length - 1]]);
  }
  return { tables: s, joined: r };
}
function be(t, e, n) {
  const { tables: o, joined: s } = t,
    r = {
      pages: e.pages,
      tables: o.length,
      sheets: 0,
      rows: 0,
      numericCells: 0,
      dateCells: 0,
      ocrPages: e.ocrPages,
      unreadPages: e.unreadPages,
      joined: s,
      notes: [],
    };
  if (o.length === 0)
    return {
      kind: "none",
      reason: e.anyText ? "no-tables" : "no-text",
      summary: r,
    };
  const u = ie(o, n.sheetMode),
    a = fe(u, n),
    l = [...a.notes],
    { ocrPages: i, unreadPages: c } = e;
  return (
    i > 0 &&
      l.push(
        `${i === 1 ? "1 page was a scan and was" : `${i} pages were scans and were`} read with OCR, so check numbers against the original.`,
      ),
    c > 0 &&
      e.ocrEnabled &&
      l.push(
        `${c} ${c === 1 ? "page" : "pages"} had no readable text and ${c === 1 ? "was" : "were"} skipped.`,
      ),
    c > 0 &&
      !e.ocrEnabled &&
      l.push(
        `${c} ${c === 1 ? "page has" : "pages have"} no text layer (a scan) and ${c === 1 ? "was" : "were"} skipped; turn on scanned-page reading to include ${c === 1 ? "it" : "them"}.`,
      ),
    {
      kind: "ok",
      blob: ue(a.workbook),
      preview: a.preview,
      summary: {
        ...r,
        sheets: a.preview.length,
        rows: a.rowCount,
        numericCells: a.numericCells,
        dateCells: a.dateCells,
        notes: l,
      },
    }
  );
}
export { pe as D, be as b, ge as d, he as o };
//# sourceMappingURL=tablesToExcel-C1ZZUvmI.js.map
