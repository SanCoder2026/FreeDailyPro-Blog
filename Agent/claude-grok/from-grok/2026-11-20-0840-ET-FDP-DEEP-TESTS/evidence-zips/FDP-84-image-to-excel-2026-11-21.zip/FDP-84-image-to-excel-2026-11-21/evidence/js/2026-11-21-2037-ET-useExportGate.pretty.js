import { r as c } from "./vendor-react-D01g8YgM.js";
import { aK as i } from "./index-xgcQ0Xo8.js";
import { h as n, i as d, j as p } from "./ToolPage-DrleSM7T.js";
function w() {
  const { known: o, paid: a, toolId: t, scope: e, fetcher: r } = n();
  return {
    checkExport: c.useCallback(
      async (s) =>
        !o || a
          ? !0
          : (s ? await d(t, e, s, r) : await p(t, e, r)) === "blocked"
            ? (i(t, "download"), !1)
            : !0,
      [o, a, t, e, r],
    ),
  };
}
export { w as u };
//# sourceMappingURL=useExportGate-VrUOBDKB.js.map
