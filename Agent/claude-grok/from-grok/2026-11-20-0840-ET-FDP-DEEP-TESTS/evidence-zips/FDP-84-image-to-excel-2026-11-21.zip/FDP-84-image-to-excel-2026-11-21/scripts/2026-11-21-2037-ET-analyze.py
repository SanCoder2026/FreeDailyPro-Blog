#!/usr/bin/env python3
"""FDP-84: read every .xlsx (openpyxl) and compare with testfiles/truth.json: sheets, cell values and Excel types (number/date/text), number formats. Usage: analyze.py truth.json file.xlsx..."""
import sys, json, openpyxl, datetime
truth = json.load(open(sys.argv[1])); out = {}
for f in sys.argv[2:]:
    wb = openpyxl.load_workbook(f); r = {'sheets': wb.sheetnames}
    for ws in wb.worksheets:
        rows = []
        for row in ws.iter_rows():
            rows.append([(c.value.isoformat()[:10] if isinstance(c.value, (datetime.date, datetime.datetime)) else c.value, type(c.value).__name__, c.number_format) for c in row if c.value is not None])
        r[ws.title] = rows
    out[f.split('/')[-1]] = r
print(json.dumps(out, default=str))
