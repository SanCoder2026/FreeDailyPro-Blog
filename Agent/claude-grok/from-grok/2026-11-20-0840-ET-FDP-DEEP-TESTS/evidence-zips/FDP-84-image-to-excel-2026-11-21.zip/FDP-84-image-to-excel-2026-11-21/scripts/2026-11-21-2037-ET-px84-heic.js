// FDP-84 HEIC: page says "iPhone HEIC" is accepted. Drop clean.heic and Read (no download). Chromium + Firefox + WebKit.
const pw = require('playwright'); const fs = require('fs'); const O = '/workspace/deep/84-image-to-excel/live/'; const TF = '/workspace/deep/84-image-to-excel/testfiles/';
(async () => { const R = {};
 for (const eng of ['chromium', 'firefox', 'webkit']) { const b = await pw[eng].launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 1000 } })).newPage(); p.setDefaultTimeout(15000);
  try { await p.goto('https://www.freedailypro.com/tool/image-to-excel', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500);
   await p.locator('main input[type=file]').first().setInputFiles(TF + 'clean.heic'); await p.waitForTimeout(2000);
   const t0 = Date.now(); await p.locator('main button', { hasText: 'Read the pictures' }).click();
   await p.locator('main').getByText(/Read \d+ picture|could not be read|No table/).first().waitFor({ timeout: 150000 }).catch(() => { });
   R[eng] = { sec: Math.round((Date.now() - t0) / 1000), text: (await p.locator('main').innerText()).split('\n').filter(l => /Read \d|could not|No table|not a picture|HEIC|table ·/.test(l)).slice(0, 5) };
   await p.screenshot({ path: O + `cases/C25-heic-${eng}.png` }); } catch (e) { R[eng] = e.message.slice(0, 150); }
  await b.close(); }
 fs.writeFileSync(O + 'heic.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R)); })();
