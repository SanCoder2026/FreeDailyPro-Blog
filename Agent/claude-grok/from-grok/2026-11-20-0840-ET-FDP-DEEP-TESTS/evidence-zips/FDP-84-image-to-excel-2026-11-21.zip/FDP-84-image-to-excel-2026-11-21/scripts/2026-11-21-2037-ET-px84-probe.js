// FDP-84 probe: drop clean.png, Read the pictures, dump UI text/controls and screenshots. Guest; no Download press.
const pw = require('playwright'); const fs = require('fs'); const W = '/workspace/deep/84-image-to-excel/';
(async () => { const b = await pw.chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 1000 } })).newPage(); p.setDefaultTimeout(15000);
 await p.goto('https://www.freedailypro.com/tool/image-to-excel', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 await p.locator('input[type=file]').first().setInputFiles(W + 'testfiles/clean.png'); await p.waitForTimeout(2500);
 const dump = () => p.evaluate(() => { const m = document.querySelector('main'); return { text: m.innerText.slice(0, 3000), controls: [...m.querySelectorAll('button,input,select,label')].map(e => e.tagName + ':' + (e.getAttribute('aria-label') || e.innerText || e.type || '').trim().slice(0, 60) + (e.type === 'checkbox' ? (e.checked ? '[x]' : '[ ]') : '')).slice(0, 80) }; });
 const a = await dump(); await p.screenshot({ path: W + 'live/cases/P01-dropped.png', fullPage: true });
 await p.locator('main button', { hasText: 'Read the pictures' }).click(); for (let i = 0; i < 90; i++) { await p.waitForTimeout(1000); if (await p.locator('main button', { hasText: 'Download Excel File' }).count()) break; }
 await p.waitForTimeout(1500); const c = await dump(); await p.screenshot({ path: W + 'live/cases/P02-read.png', fullPage: true });
 fs.writeFileSync(W + 'live/probe.json', JSON.stringify({ a, c, usage: await p.evaluate(() => localStorage.getItem('fdp-usage-v1')).then(s => s.replace(/dev:[0-9a-f-]+/, 'dev:REDACTED')) }, null, 1)); console.log('ok'); await b.close(); })();
