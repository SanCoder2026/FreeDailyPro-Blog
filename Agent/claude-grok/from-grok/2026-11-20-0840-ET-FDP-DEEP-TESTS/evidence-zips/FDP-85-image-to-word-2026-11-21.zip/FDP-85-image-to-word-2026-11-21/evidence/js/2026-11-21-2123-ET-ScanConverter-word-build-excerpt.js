      t && (k([t]), Y(!0));
    },
    P = r.useMemo(() => L.map(it), [L]);
  r.useEffect(() => {
    if (m !== "word" || !c) {
      M(null);
      return;
    }
    let t = !1;
    (M(null), ye(""));
    const s = setTimeout(async () => {
      try {
        const a = [];
        for (let l = 0; l < c.length; l++) {
          const o = c[l].reading,
            d = I || !P[l]?.length;
          let b;
          if (d && A[l]) {
            let i = A[l],
              z = kt(A[l]);
            if (o.rotation) {
              const { rotateImageBlob: re } = await V(async () => {
                const { rotateImageBlob: Qe } =
                  await import("./ocrImage-CmXFNUud.js");
                return { rotateImageBlob: Qe };
              }, []);
              ((i = await re(i, o.rotation)), (z = "jpg"));
            }
            b = {
              bytes: new Uint8Array(await i.arrayBuffer()),
              type: z,
              widthPx: o.widthPx,
              heightPx: o.heightPx,
            };
          }
          a.push({
            paragraphs: P[l] ?? [],
            picture: b,
            landscape: o.widthPx > o.heightPx,
          });
        }
        const n = await dt(a, {
          title: Ce(c[0].reading.name),
          pageSize: J,
          includePicture: I,
        });
        t || M({ blob: n.blob, pictureOnly: n.pictureOnlyPages });
      } catch (a) {
        (console.error("Word file failed", a),
          t ||
            ye(
              "The Word file could not be built. Try again, or download the text instead.",
            ));
      }
