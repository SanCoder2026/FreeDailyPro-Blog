#!/usr/bin/env python3
"""FDP-85: read .docx files (python-docx + raw XML): page size, margins, paragraphs, page breaks, images, headers/footers (watermark text), core title. Usage: analyze85.py file.docx..."""
import sys, json, zipfile, re, docx
out = {}
for f in sys.argv[1:]:
    d = docx.Document(f); z = zipfile.ZipFile(f); x = z.read('word/document.xml').decode()
    s = d.sections[0]
    hf = ' | '.join(p.text for sec in d.sections for part in (sec.header, sec.footer) for p in part.paragraphs if p.text.strip())
    out[f.split('/')[-1]] = {'pageIn': [round(s.page_width.inches, 2), round(s.page_height.inches, 2)], 'orient': str(s.orientation), 'sections': len(d.sections),
        'paragraphs': [p.text for p in d.paragraphs if p.text.strip()], 'pageBreaks': x.count('w:type="page"') + x.count('<w:pageBreakBefore'), 'sectBreaks': x.count('<w:sectPr') - 1,
        'images': len([n for n in z.namelist() if n.startswith('word/media/') and not n.endswith('/')]), 'headerFooter': hf, 'title': d.core_properties.title, 'creator': d.core_properties.author,
        'fdpMark': bool(re.search(r'FreeDailyPro', x + hf)), 'size': __import__('os').path.getsize(f)}
print(json.dumps(out, indent=1, ensure_ascii=False))
