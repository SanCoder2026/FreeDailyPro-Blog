#!/usr/bin/env python3
"""FDP-84 test pictures of tables with known contents (ground truth in truth.json). Needs Pillow (+ DejaVu fonts).
clean.png 6 cols x 8 rows (Item, Code, ZIP, Qty, Price, Share, Date) | tilt.jpg = clean rotated 6 deg on paper, dark corners | tilt-light3/6.jpg = same with light corners | exif6.jpg = clean stored sideways with EXIF Orientation 6
part1.png / part2.png = one table split over two pictures, header repeated | tworows.png = header + 1 row (should not be detected)
dmy.png = dates 09/02/2026 style + 31/12/2026 | de.png = German table (1.234,50 €, 12,5 %) | small.png = clean at 35% size | lowcon.png = grey on grey
prose.png = paragraphs, no table | tight.png = columns 6 px apart | corrupt.jpg random bytes | big.jpg ~ 6000x4000"""
import json, os, sys, random
from PIL import Image, ImageDraw, ImageFont
D = sys.argv[1] if len(sys.argv) > 1 else 'testfiles'; os.makedirs(D, exist_ok=True); random.seed(84)
F = lambda s: ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', s)
HDR = ['Item', 'Code', 'ZIP', 'Qty', 'Price', 'Share', 'Date']
ROWS = [['Paper A4', '00412', '02134', '12', '$4.50', '12.5%', '2026-03-01'], ['Stapler', '00977', '10001', '3', '$18.99', '7%', '2026-03-04'],
        ['Toner black', '01250', '60601', '2', '$64.00', '30%', '2026-03-09'], ['Pens blue', '00033', '94105', '48', '$0.85', '4.2%', '2026-03-12'],
        ['Folders', '00508', '30301', '25', '$1.20', '3%', '2026-03-15'], ['Desk lamp', '02001', '73301', '1', '$39.90', '18%', '2026-03-20'],
        ['Labels', '00090', '98101', '6', '$7.25', '5.3%', '2026-03-28']]
def table(rows, hdr=HDR, size=26, gap=60, fg=(0, 0, 0), bg=(255, 255, 255), w=None):
    f = F(size); cols = list(zip(*([hdr] + rows))); cw = [max(f.getlength(c) for c in col) + gap for col in cols]
    W = int(sum(cw) + 80); H = int((len(rows) + 1) * size * 1.9 + 80); im = Image.new('RGB', (W, H), bg); d = ImageDraw.Draw(im); y = 40
    for r in [hdr] + rows:
        x = 40
        for i, c in enumerate(r): d.text((x, y), c, fill=fg, font=f); x += cw[i]
        y += int(size * 1.9)
    return im
T = {}
im = table(ROWS); im.save(f'{D}/clean.png'); T['clean'] = [HDR] + ROWS
pg = Image.new('RGB', (im.width + 300, im.height + 300), (235, 232, 225)); pg.paste(im, (150, 150)); pg.rotate(6, expand=True, fillcolor=(90, 90, 90)).save(f'{D}/tilt.jpg', quality=90)
for a in (3, 6): pg.rotate(a, expand=True, fillcolor=(225, 222, 215)).save(f'{D}/tilt-light{a}.jpg', quality=90)
ex = im.rotate(90, expand=True); exif = Image.Exif(); exif[0x0112] = 6; ex.save(f'{D}/exif6.jpg', quality=92, exif=exif)
table(ROWS[:4]).save(f'{D}/part1.png'); table(ROWS[4:]).save(f'{D}/part2.png'); T['joined'] = [HDR] + ROWS
table(ROWS[:1]).save(f'{D}/tworows.png')
DM = [['Invoice', 'Date', 'Amount'], ['INV-1', '09/02/2026', '120.00'], ['INV-2', '31/12/2026', '75.50'], ['INV-3', '05/06/2026', '9.99'], ['INV-4', '12/01/2026', '300.00']]
table(DM[1:], DM[0]).save(f'{D}/dmy.png'); T['dmy'] = DM
DE = [['Artikel', 'Menge', 'Preis', 'Rabatt'], ['Schraube', '1.200', '1.234,50 €', '12,5 %'], ['Mutter', '350', '89,90 €', '5 %'], ['Dübel', '40', '7,25 €', '0 %'], ['Größe XL', '2', '1.099,00 €', '15,0 %']]
table(DE[1:], DE[0]).save(f'{D}/de.png'); T['de'] = DE
im.resize((int(im.width * .35), int(im.height * .35))).save(f'{D}/small.png')
table(ROWS, fg=(140, 140, 140), bg=(170, 170, 170)).save(f'{D}/lowcon.png')
p = Image.new('RGB', (1400, 600), 'white'); d = ImageDraw.Draw(p); txt = ['Quarterly notes for the office team.', 'We ordered paper, toner and a new desk lamp this month.', 'Please return borrowed staplers to the front desk by Friday.', 'The next order goes out on the first Monday of April.']
for i, t in enumerate(txt): d.text((40, 40 + i * 60), t, fill='black', font=F(30))
p.save(f'{D}/prose.png'); T['prose'] = txt
table(ROWS, gap=6).save(f'{D}/tight.png')
big = im.resize((6000, int(im.height * 6000 / im.width))); big.save(f'{D}/big.jpg', quality=92)
open(f'{D}/corrupt.jpg', 'wb').write(b'\xff\xd8\xff' + random.randbytes(30000))
json.dump(T, open(f'{D}/truth.json', 'w'), indent=1)
print({f: os.path.getsize(f'{D}/{f}') for f in sorted(os.listdir(D))})
