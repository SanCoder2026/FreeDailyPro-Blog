#!/usr/bin/env python3
"""FDP-85 test pictures of documents with known text (truth85.json). Pillow + DejaVu/Noto fonts. Seed 85.
letter.png 4 paragraphs (numbers, codes, punctuation) | page1/2/3.png "Page one/two/three" for order | fr.png French accents | de-doc.png German umlauts/ß
hi.png Hindi (Devanagari, needs raqm) | rot180.png letter upside down (no EXIF) | rot90.png letter sideways (no EXIF) | exif6-letter.jpg sideways + EXIF 6
tilt-dark.jpg letter 5 deg dark corners | tilt-light.jpg 5 deg light corners | twocol.png two text columns | photo.jpg no text (gradient + shapes)
small-letter.png 40% | lowcon-letter.png grey on grey | lines.png lines with single line breaks (paragraph rule)"""
import json, os, sys, random
from PIL import Image, ImageDraw, ImageFont, features
D = sys.argv[1] if len(sys.argv) > 1 else 'testfiles'; os.makedirs(D, exist_ok=True); random.seed(85)
F = lambda s, f='/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf': ImageFont.truetype(f, s)
def page(paras, size=30, w=1500, fg=(0, 0, 0), bg=(255, 255, 255), font=None, gap=1.0):
    f = font or F(size); lines = []
    for p in paras:
        words = p.split(' '); cur = ''
        for wd in words:
            t = (cur + ' ' + wd).strip()
            if f.getlength(t) > w - 160: lines.append(cur); cur = wd
            else: cur = t
        lines.append(cur); lines.append('')
    H = int(len(lines) * size * 1.6 + 160); im = Image.new('RGB', (w, H), bg); d = ImageDraw.Draw(im); y = 80
    for l in lines: d.text((80, y), l, fill=fg, font=f); y += int(size * 1.6)
    return im
T = {}
L = ['Dear Ms. Alvarez,', 'Thank you for your order 0047-OL dated 12 March 2026. The total of $1,284.50 was received on 14 March, and the goods will ship from our Boston office within 10 working days.',
     'Please note that invoice INV-2026-0311 replaces the earlier draft. If anything is wrong, call 617-555-0142 or reply to this letter before 31 March.', 'Kind regards, Jonathan Reed, Accounts']
im = page(L); im.save(f'{D}/letter.png'); T['letter'] = L
for i, n in enumerate(['one', 'two', 'three']):
    P = [f'Page {n} of the meeting notes.', f'This is section {i+1}. The budget line for item {i+1} is {100*(i+1)} dollars.']; page(P).save(f'{D}/page{i+1}.png'); T[f'page{i+1}'] = P
FR = ['Réunion du comité à Genève', 'Les élèves ont reçu leurs bulletins. Le château, la forêt et l’hôpital sont fermés jusqu’à la fin de l’été. Où est le garçon ?']
page(FR).save(f'{D}/fr.png'); T['fr'] = FR
DE = ['Sehr geehrte Damen und Herren,', 'die Größe der Lieferung für die Straße in München übersteigt die Maße. Grüße aus Köln.']
page(DE).save(f'{D}/de-doc.png'); T['de'] = DE
HI = ['नमस्ते, यह एक परीक्षण पत्र है।', 'कृपया बैठक में समय पर आएं।']
page(HI, font=F(34, '/usr/share/fonts/truetype/sand-box/google/Noto Sans Devanagari/NotoSansDevanagari-VariableFont_wdth,wght.ttf')).save(f'{D}/hi.png'); T['hi'] = HI
im.rotate(180, expand=True).save(f'{D}/rot180.png'); im.rotate(90, expand=True).save(f'{D}/rot90.png')
ex = im.rotate(90, expand=True).convert('RGB'); e = Image.Exif(); e[0x0112] = 6; ex.save(f'{D}/exif6-letter.jpg', quality=92, exif=e)
pg = Image.new('RGB', (im.width + 300, im.height + 300), (235, 232, 225)); pg.paste(im, (150, 150))
pg.rotate(5, expand=True, fillcolor=(70, 70, 70)).convert('RGB').save(f'{D}/tilt-dark.jpg', quality=90); pg.rotate(5, expand=True, fillcolor=(225, 222, 215)).convert('RGB').save(f'{D}/tilt-light.jpg', quality=90)
A = ['Left column: the first story is about the new office.', 'It opened in May with forty desks.']; B = ['Right column: the second story covers the budget.', 'Spending fell by nine percent.']
a = page(A, w=750); b = page(B, w=750); tc = Image.new('RGB', (1500, max(a.height, b.height)), 'white'); tc.paste(a, (0, 0)); tc.paste(b, (750, 0)); tc.save(f'{D}/twocol.png'); T['twocol'] = A + B
ph = Image.new('RGB', (1600, 1200)); d = ImageDraw.Draw(ph)
for y in range(1200): d.line([(0, y), (1600, y)], fill=(int(40 + y / 8), 90, int(200 - y / 10)))
for i in range(40): x, y, r = random.randint(0, 1600), random.randint(0, 1200), random.randint(20, 120); d.ellipse([x - r, y - r, x + r, y + r], fill=tuple(random.randint(0, 255) for _ in range(3)))
ph.save(f'{D}/photo.jpg', quality=88)
im.resize((int(im.width * .4), int(im.height * .4))).save(f'{D}/small-letter.png')
page(L, fg=(140, 140, 140), bg=(175, 175, 175)).save(f'{D}/lowcon-letter.png')
LN = ['Line one of a poem', 'line two continues it', '', 'A new stanza starts here']
im2 = Image.new('RGB', (1200, 420), 'white'); d = ImageDraw.Draw(im2)
for i, t in enumerate(LN): d.text((80, 60 + i * 70), t, fill='black', font=F(32))
im2.save(f'{D}/lines.png'); T['lines'] = LN
json.dump(T, open(f'{D}/truth85.json', 'w'), indent=1, ensure_ascii=False); print(sorted(os.listdir(D)), features.check('raqm'))
