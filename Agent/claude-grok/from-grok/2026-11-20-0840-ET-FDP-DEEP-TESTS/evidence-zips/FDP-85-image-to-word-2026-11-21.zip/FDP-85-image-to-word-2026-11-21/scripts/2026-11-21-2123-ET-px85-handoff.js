// FDP-85 inbound handoff: document-scanner "Edit as Word" -> where does it land? Guest, no downloads.
const { chromium } = require('playwright'); const fs = require('fs'); const O = '/workspace/deep/85-image-to-word/live/'; const TF = '/workspace/deep/85-image-to-word/testfiles/';
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 1000 } }); const p = await c.newPage(); p.setDefaultTimeout(15000); const R = {}; let posts = 0;
 p.on('request', r => { if (r.method() === 'POST' && /usage\.log/.test(r.postData() || '')) posts++; });
 await p.goto('https://www.freedailypro.com/tool/document-scanner', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500);
 await p.locator('main input[type=file][accept="image/*"]').first().setInputFiles(TF + 'clean.png'); await p.waitForTimeout(2500);
 await p.locator('main button', { hasText: /^Continue$/ }).click(); await p.waitForTimeout(2500);
 await p.locator('main button', { hasText: /^Straighten$/ }).click(); await p.waitForTimeout(3000);
 await p.locator('main button', { hasText: 'Edit as Word' }).click(); await p.waitForTimeout(6000);
 R.url = p.url(); R.h1 = await p.locator('h1').first().innerText().catch(() => null); R.title = await p.title(); R.usagePosts = posts;
 await p.screenshot({ path: O + 'cases/X10-scanner-handoff.png' });
 fs.writeFileSync(O + 'handoff.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R)); await b.close(); })();
