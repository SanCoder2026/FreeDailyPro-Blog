// FDP-78 YouTube Thumbnail Downloader (quickbuy mode only used) (Professional 10/day), guest. Usage: node px75-live.js <zero|left|quickbuy> [engine]   env TRIES, SUF, FILES (comma list for left)
// zero: context at the cap: drop apa-good.docx -> report or cap dialog? style switch; wrong files; Open from Google Drive.
// left: context with uses left: drop each test paper in ONE page (Check another file between), read the checklist for APA/MLA/Chicago, record usage POSTs per file; reload + drop.
// Never signs in, never types an email or card, never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/86-scan-to-document/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const TOOL = 'https://www.freedailypro.com/tool/scan-to-document';
const mode = process.argv[2] || 'zero'; const eng = process.argv[3] || 'chromium'; const sfx = (eng === 'chromium' ? '' : '-' + eng) + (process.env.SUF || '');
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').slice(0, 160);
fs.mkdirSync(OUT + 'cases', { recursive: true });
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p, net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 1000 }, locale: 'en-US' }); p = await c.newPage(); p.setDefaultTimeout(12000); net = [];
  p.on('request', r => { const u = r.url(); if (r.method() === 'POST' && /freedailypro\.com\/api/.test(u) && !/insight\.hit|funnel\.hit/.test(u)) net.push({ t: now(), u: u.slice(0, 70), len: (r.postData() || '').length, doc: /Students in this study|References/.test(r.postData() || '') }); });
  await p.goto(TOOL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(250); } };
 const shot = n => p.screenshot({ path: OUT + 'cases/' + n + sfx + '.png', fullPage: true });
 const strip = () => p.evaluate(() => (document.querySelector('main').innerText.match(/Trial[^\n]*/) || [null])[0]);
 const checks = () => p.evaluate(() => { const m = document.querySelector('main'); const out = []; m.querySelectorAll('.flex.items-start.gap-3').forEach(row => { const ps = row.querySelectorAll('p'); const svg = row.querySelector('svg'); const cls = svg ? svg.getAttribute('class') || '' : ''; out.push({ s: /green/.test(cls) ? 'PASS' : /red/.test(cls) ? 'FAIL' : /amber/.test(cls) ? 'WARN' : '?', l: ps[0]?.innerText, d: ps[1]?.innerText }); }); const al = [...m.querySelectorAll('[role=alert]')].map(x => x.innerText).filter(Boolean); return { rows: out, alerts: al }; });
 const style = async s => { await p.locator('#paper-style').click(); await p.waitForTimeout(300); await p.getByRole('option', { name: new RegExp('^' + s) }).click(); await p.waitForTimeout(600); };
 const another = async () => { const a = p.locator('main button', { hasText: 'Check another file' }); if (await a.count()) { await a.first().click(); await p.waitForTimeout(500); } };
 const drop = async (f, styles = ['APA']) => { await another(); const np = net.length; const before = await used(); await p.locator('main input[type=file][accept=".docx"]').setInputFiles(TF + f); await p.waitForTimeout(2500); const dg = await dialog(); if (dg) { await shot('dlg-' + f.replace('.docx', '')); await esc(); }
  const r = { f, before, after: await used(), posts: net.slice(np).length, docInPost: net.slice(np).some(x => x.doc), dialog: dg }; for (const s of styles) { await style(s); r[s] = await checks(); } return r; };
 const C = async (id, fn) => { try { R.cases[id] = await fn(); } catch (e) { R.cases[id] = { err: e.message.split('\n')[0].slice(0, 200) }; await shot(id + '-err').catch(() => { }); } console.log(id, JSON.stringify(R.cases[id]).slice(0, 900)); };
 const find = async want => { const TRIES = +(process.env.TRIES || 10); for (let i = 0; i < TRIES; i++) { await open(); const u = await used(); R.tries.push(u); const [a, l] = u.split('/').map(Number); if (want === 'cap' ? a >= l : a < l) return true; await c.close(); } return false; };
 const FILES = (process.env.FILES || 'apa-good.docx,word-default.docx,a4-narrow.docx,direct-format.docx,mixed-fonts.docx,exact-24pt.docx,two-sections.docx,refs-no-hanging.docx,georgia-11.docx,no-page-number.docx,empty.docx,long-60p.docx,minimal.docx,not-docx.docx').split(',');
 if (mode === 'zero') { R.found = await find('cap'); R.start = { used: await used(), strip: await strip() }; await shot('Z00');
  await C('Z01-apa-good', async () => { const r = await drop('apa-good.docx'); await shot('Z01'); return r; });
  await C('Z02-wrong-ext', async () => { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4000); const np = net.length; await p.locator('main input[type=file][accept=".docx"]').setInputFiles(TF + 'old.doc'); await p.waitForTimeout(1500); return { posts: net.slice(np).length, dialog: await dialog(), ...(await checks()) }; });
  await C('Z03-open-drive', async () => { await esc(); const pop = c.waitForEvent('page', { timeout: 6000 }).catch(() => null); await p.locator('main button', { hasText: 'Open from Google Drive' }).click(); const pg = await pop; await p.waitForTimeout(2000); const r = { dialog: await dialog(), popup: pg ? red(pg.url()) : null }; if (pg) await pg.close(); return r; });
  R.end = await used(); R.net = net;
 } else if (mode === 'left') { R.found = await find('left'); if (!R.found) { fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('none', R.tries.join(',')); await b.close(); return; } R.start = { used: await used(), strip: await strip() }; await shot('L00');
  let k = 1; for (const f of FILES) { const id = 'L' + String(k++).padStart(2, '0') + '-' + f.replace('.docx', ''); await C(id, async () => { const r = await drop(f, f === 'apa-good.docx' || f === 'georgia-11.docx' || f === 'word-default.docx' ? ['APA', 'MLA', 'Chicago'] : ['APA']); if (k <= 3 || /direct|minimal|not-docx/.test(f)) await shot(id); return r; }); }
  await C('L90-reload-drop', async () => { await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); return drop('apa-good.docx'); });
  await C('L91-same-file-again', () => drop('apa-good.docx'));
  R.end = await used(); R.net = net;
 } else if (mode === 'quickbuy') { await open(); const u0 = p.url(); await p.locator('main button', { hasText: 'Quick Buy' }).first().click(); await p.waitForTimeout(5000); R.qbDay = { url: red(p.url()), dialog: await dialog() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await esc(); await p.goto(TOOL); await p.waitForTimeout(4000); await p.locator('main button', { hasText: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); R.qbMonth = { url: red(p.url()), title: await p.title() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' }); }
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', JSON.stringify(R.tries), JSON.stringify(R.start || ''), R.end); await b.close(); })();
