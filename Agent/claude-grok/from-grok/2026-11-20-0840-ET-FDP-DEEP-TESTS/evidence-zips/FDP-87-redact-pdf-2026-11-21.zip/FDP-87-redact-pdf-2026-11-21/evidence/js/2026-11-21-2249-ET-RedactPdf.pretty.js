const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/redactApply-BSsjW140.js",
      "assets/index-BRvxULIc.js",
      "assets/index-CnXdQaNG.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/index-DMQTJy3b.js",
      "assets/utils-s8ucLyj8.js",
      "assets/pdfBookmarks-BjfxtCfb.js",
      "assets/redactSearch-DQpyyh_t.js",
      "assets/nameDetect-DvHCRM0m.js",
      "assets/imageRecompress-eXQFDUm-.js",
    ]),
) => i.map((i) => d[i]);
import {
  f as j,
  B as y,
  X as Ie,
  T as de,
  S as ze,
  N as We,
  ap as Xe,
} from "./index-xgcQ0Xo8.js";
import { r as i, j as e } from "./vendor-react-D01g8YgM.js";
import { T as Ue } from "./ToolWithSidebar-CO7i-D3n.js";
import {
  F as He,
  P as me,
  D as Ye,
  K as he,
  d as Ge,
  R as Ke,
  M as Qe,
} from "./ToolPage-DrleSM7T.js";
import { l as qe, r as Je } from "./utils-s8ucLyj8.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./index-BRvxULIc.js";
import "./fontkit.es-DA-3qwB1.js";
import "./jszip.min-CT0ZA6V1.js";
import "./imageRecompress-eXQFDUm-.js";
import {
  c as Ve,
  p as Ze,
  M as et,
  a as tt,
  b as at,
  A as ue,
  t as st,
  f as rt,
  P as nt,
} from "./redactSearch-DQpyyh_t.js";
import { u as pe } from "./useSessionState-BLsNNse9.js";
import { C as O } from "./checkbox-CRLgbqRK.js";
import { C as ot } from "./chevron-left-DFs0oPKQ.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./CollapsibleText-DFD2kyG0.js";
import "./chevron-up-RK9L2OPY.js";
import "./useUploadApi-yCV1cZhw.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-Cl69OhvT.js";
import "./share-2-tv4Mz_hR.js";
import "./copy-B6PRNyNa.js";
import "./workflowCta-BFTpZlex.js";
import "./UsageAndUpgradeStrip-DMhPNgnJ.js";
import "./access-DqVqJd33.js";
import "./useAdminAccess-mVM_2mWb.js";
import "./InstallToolButton-DxfN0Pem.js";
import "./map-pin-CwlIzHDK.js";
import "./FaqSection-BNxk42M5.js";
import "./ToolVideoEmbed-DNaMY2Pn.js";
import "./GuideLinks-D5fn3NI1.js";
import "./blog-CxdB1WyW.js";
import "./info-x67VbErc.js";
import "./productCards-DhpNcELZ.js";
import "./layers-B44Zba7-.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./nameDetect-DvHCRM0m.js";
import "./index-DhOoIDuZ.js";
const it = [
    "ssn",
    "ein",
    "card",
    "email",
    "phone",
    "name",
    "custom",
    "text",
    "field",
    "manual",
  ],
  lt = {
    ssn: "SSN",
    ein: "EIN",
    card: "card",
    email: "email",
    phone: "phone",
    name: "name",
    custom: "custom pattern",
    text: "typed text",
    field: "form field",
    manual: "drawn by hand",
  };
function ct(r) {
  const u = new Map();
  for (const [a, m] of Object.entries(r)) {
    const h = Number(a) + 1;
    m.forEach((c, d) => {
      const k = c.kind ?? "manual",
        f = c.kind && c.group !== void 0 ? `${h}:${c.group}` : `${h}:box${d}`;
      let w = u.get(k);
      (w || ((w = { keys: new Set(), pages: new Set() }), u.set(k, w)),
        w.keys.add(f),
        w.pages.add(h));
    });
  }
  return it
    .filter((a) => u.has(a))
    .map((a) => ({
      kind: a,
      label: lt[a],
      count: u.get(a).keys.size,
      pages: Array.from(u.get(a).pages).sort((m, h) => m - h),
    }));
}
function dt(r) {
  const u = ct(r.boxesByPage);
  return {
    fileName: r.fileName,
    marked: u,
    headline: u
      .map(
        (a) =>
          `${a.label} ${a.count} (${a.pages.map((m) => `p${m}`).join(", ")})`,
      )
      .join(", "),
    pages: r.report.pages.map((a) => ({
      page: a.page,
      areas: r.boxesByPage[a.page - 1]?.length ?? 0,
      how: a.how,
      reason: a.reason,
      removed: a.removed,
    })),
    hiddenOption: r.removeHidden,
    hidden: r.report.removed,
    metadataCleared: r.scrubMetadata,
    rasterizedPages: r.report.rasterizedPages,
    inspection: r.report.inspection,
  };
}
const p = (r, u, a = u + "s") => `${r} ${r === 1 ? u : a}`;
function xe(r, u = new Date()) {
  const a = [];
  (a.push(
    "REDACTION SUMMARY",
    `File: ${r.fileName}`,
    `Made: ${u.toISOString().slice(0, 10)} with FreeDailyPro Redact PDF, on your device (the file was not uploaded)`,
    "",
  ),
    a.push(
      "What was marked and removed (counted by what found it; pages in brackets)",
    ),
    r.marked.length === 0 && a.push("  Nothing was marked."));
  for (const c of r.marked)
    a.push(
      `  ${c.label}: ${c.count} (page${c.pages.length === 1 ? "" : "s"} ${c.pages.join(", ")})`,
    );
  (a.push("  The text that was removed is not written in this summary.", ""),
    a.push("What happened on each page"));
  for (const c of r.pages)
    if (c.how === "picture")
      a.push(
        `  Page ${c.page}: ${p(c.areas, "area")} marked. The page was turned into a picture with the areas painted black${c.reason ? ` (${c.reason})` : ""}. Its text can no longer be selected or searched.`,
      );
    else {
      const d = c.removed;
      a.push(
        `  Page ${c.page}: ${p(c.areas, "area")} marked. Removed from the page itself: ${p(d.glyphs, "character")}, ${p(d.images, "picture")}, ${p(d.paths, "drawing")}, ${p(d.annotations, "annotation")}. A black bar was drawn in each area.${d.glyphs + d.images + d.paths + d.annotations === 0 ? " Nothing was found under the marked areas, so check their position." : ""}`,
      );
    }
  (a.push("  Pages with no marks were not changed.", ""),
    a.push("Options"),
    r.hiddenOption
      ? a.push(
          `  Comments, links, form values and bookmarks: removed ${p(r.hidden.comments, "comment")} (all comments, on every page), ${p(r.hidden.links, "link")}, ${p(r.hidden.fields, "form field")} and ${p(r.hidden.bookmarks, "bookmark")} that matched the searched text, the ticked detectors or the custom patterns.`,
        )
      : a.push(
          "  Comments, links, form values and bookmarks: not touched (the option was off).",
        ),
    a.push(
      `  Document properties (title, author, subject, keywords, creator, custom fields) and the XMP metadata stream: ${r.metadataCleared ? "cleared (the Producer field says FreeDailyPro)" : "NOT cleared (the option was off)"}.`,
      "",
    ));
  const m = r.inspection,
    h = [];
  return (
    m.properties > 0 &&
      h.push(p(m.properties, "document property", "document properties")),
    m.xmp && h.push("an XMP metadata stream"),
    m.bookmarks > 0 && h.push(p(m.bookmarks, "bookmark")),
    m.attachments > 0 && h.push(p(m.attachments, "attached file")),
    m.comments > 0 && h.push(p(m.comments, "comment or other annotation")),
    m.filledFormFields > 0 &&
      h.push(p(m.filledFormFields, "form field") + " with a value"),
    a.push(
      "Still in the finished file (counted, not inspected for sensitive content)",
    ),
    a.push(
      h.length
        ? `  ${h.join("; ")}.`
        : "  None of: document properties, XMP metadata, bookmarks, attached files, comments, filled form fields.",
      "",
    ),
    a.push("What this tool does NOT do"),
    a.push(
      "  - It removes only the areas that were marked. Sensitive text anywhere else, including text the search or detectors did not find, is still there.",
    ),
    a.push(
      "  - Scanned pages have no text to search; areas on them are removed only where they were drawn by hand.",
    ),
    a.push(
      "  - Attached files, and the content inside them, are not inspected or removed.",
    ),
    a.push(
      "  - Bookmarks, links, form values and comments are checked only when the matching option is on, and then only against the searched text, ticked detectors and custom patterns.",
    ),
    a.push("  - Document properties are cleared only when that option is on."),
    a.push("  Open the finished file and check it before you send it."),
    a.join(`
`) +
      `
`
  );
}
const ge = {
    what: `Permanently removes sensitive information from a PDF. The text, picture pixels, drawings and form fields under each box you mark are taken out of the file itself, not just covered, and a black bar is drawn in their place. Everything else on the page stays as it was: the rest of the text is still real, selectable and searchable, in its own fonts. A simple black box drawn on top of text in most "redaction" tools deletes nothing, because the real text is still in the file for anyone who copies it or opens the PDF's raw content. This tool removes what is underneath.`,
    tip: `A page is turned into a picture only when it cannot be edited exactly: a curved drawing partly under a box, a shading, an unusual font encoding, or a picture format the tool cannot read. When that happens the page's text can no longer be selected, searched or read by a screen reader, and a notice under the result names the page and the reason; run OCR PDF on the result if you need searchable text on it again. Every other page keeps its real text, links and bookmarks. Search reads the page text, including a name split across text pieces, and boxes only the matched words. It can't read scanned pages (they're pictures) — draw boxes by hand or run OCR PDF first. With the option on, link addresses, form values and bookmarks that contain the searched text are removed, and every comment-style annotation on unmarked pages is removed whether or not it mentions the text. It's still worth looking over the result before you send it.

What is and is not cleaned: only the areas you mark (or that a search, detector or custom pattern marked and you kept) are removed from the page. Document properties and the XMP metadata are cleared only when "clear document metadata" is on. Comments are all removed when "remove comments..." is on, but links, form values and bookmarks only when they contain the searched text, a ticked detector's match or a custom pattern's match. Attached files (and what is inside them) are never inspected or removed, and the summary counts any that remain. Custom patterns are checked before they run: at most ${et} patterns, ${tt} characters for a simple pattern and ${at} for a regular expression; lookahead, back-references and ^ $ are not supported, and a pattern that would be too slow is stopped with a message instead of freezing the page.`,
  },
  fe = () =>
    Xe(
      () => import("./redactApply-BSsjW140.js"),
      __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]),
    );
function Zt() {
  const [r, u] = i.useState(null),
    [a, m] = i.useState(0),
    [h, c] = i.useState([]),
    [d, k] = i.useState({}),
    [f, w] = i.useState(null),
    [be, ee] = i.useState(!1),
    [ye, W] = i.useState(!1),
    [ke, X] = i.useState(0),
    [P, v] = i.useState(null),
    [S, we] = i.useState(""),
    [te, ae] = i.useState(!1),
    [U, ve] = i.useState(!0),
    [H, je] = i.useState(!0),
    [E, Ne] = i.useState(!1),
    [Y, Pe] = i.useState(!1),
    [$, se] = i.useState([]),
    [re, G] = i.useState([]),
    [ne, K] = i.useState([]),
    [$e, Ce] = i.useState("text-removed"),
    [L, Se] = i.useState([]),
    [x, Q] = i.useState(null),
    [q, Te] = pe("rd-custom-text", ""),
    [N, oe] = pe("rd-custom-mode", "wildcard"),
    R = i.useRef([]),
    T = Ve(q, N, { ignoreCase: !E }),
    B = Ze(q, N);
  i.useEffect(() => {
    fe().catch(() => {});
  }, []);
  const D = i.useRef([]),
    _ = i.useRef(!1),
    ie = i.useRef(null),
    [g, I] = i.useState(null),
    [b, M] = i.useState(null),
    Me = i.useCallback(async (t) => {
      const s = t[0];
      if (s) {
        (u(s), v(null), k({}), ee(!0));
        try {
          const n = await qe(s);
          m(n.numPages);
          const o = [];
          for (let l = 1; l <= n.numPages; l++) {
            const C = await n.getPage(l),
              Z = await Je(C, 0.6, 0.75);
            o.push(URL.createObjectURL(Z));
          }
          c(o);
        } catch (n) {
          (console.error("Couldn't load PDF pages:", n),
            j.error(
              "Couldn't read this PDF — it may be corrupted or password-protected",
            ),
            u(null));
        } finally {
          ee(!1);
        }
      }
    }, []),
    J = (t, s) => {
      const n = ie.current.getBoundingClientRect();
      return {
        x: Math.min(1, Math.max(0, (t - n.left) / n.width)),
        y: Math.min(1, Math.max(0, (s - n.top) / n.height)),
      };
    },
    V = (t) => J(t.clientX, t.clientY),
    Re = (t) => {
      (I(V(t)), M(V(t)));
    },
    De = (t) => {
      g && M(V(t));
    },
    Ae = (t) => {
      if (t.touches.length === 0) return;
      const s = t.touches[0],
        n = J(s.clientX, s.clientY);
      (I(n), M(n));
    },
    Fe = (t) => {
      if (!g || t.touches.length === 0) return;
      t.preventDefault();
      const s = t.touches[0];
      M(J(s.clientX, s.clientY));
    },
    z = () => {
      if (!g || !b || f === null) {
        (I(null), M(null));
        return;
      }
      const t = Math.abs(b.x - g.x),
        s = Math.abs(b.y - g.y);
      if (t > 0.01 && s > 0.01) {
        const n = { x: Math.min(g.x, b.x), y: Math.min(g.y, b.y), w: t, h: s };
        (k((o) => ({ ...o, [f]: [...(o[f] || []), n] })), v(null));
      }
      (I(null), M(null));
    },
    Oe = (t, s) => {
      (k((n) => ({ ...n, [t]: n[t].filter((o, l) => l !== s) })), v(null));
    },
    Ee = async () => {
      if (!(!r || (!S.trim() && $.length === 0 && B.length === 0))) {
        if (T) {
          j.error(T, { id: "redact-search" });
          return;
        }
        ae(!0);
        try {
          const t = await rt(r, S, {
            matchCase: E,
            wholeWord: Y,
            patterns: $,
            custom: B,
          });
          for (const o of B)
            R.current.some((l) => l.mode === o.mode && l.source === o.source) ||
              R.current.push(o);
          const s = t.boxes;
          for (const o of S.split(/\r?\n/)
            .map((l) => l.trim())
            .filter(Boolean))
            D.current.includes(o) || D.current.push(o);
          G((o) => [
            ...o,
            ...t.hidden.filter(
              (l) =>
                !o.some(
                  (C) =>
                    C.kind === l.kind && C.page === l.page && C.text === l.text,
                ),
            ),
          ]);
          const n = Object.values(s).reduce((o, l) => o + l.length, 0);
          if (n === 0) {
            t.pagesWithoutText.length === a
              ? j.error(
                  "This PDF is a scanned image, so search can't read it. Draw boxes by hand, or run OCR PDF first.",
                  { id: "redact-search" },
                )
              : j.error(
                  `No matches found for "${S.trim().split(/\r?\n/)[0]}"`,
                  { id: "redact-search" },
                );
            return;
          }
          (k((o) => {
            const l = { ...o };
            for (const [C, Z] of Object.entries(s)) {
              const ce = Number(C);
              l[ce] = [...(l[ce] || []), ...Z];
            }
            return l;
          }),
            v(null),
            j.success(
              `Marked ${n} match${n === 1 ? "" : "es"} — review before applying`,
              { id: "redact-search" },
            ));
        } catch (t) {
          (console.error("Text search failed:", t),
            j.error(t instanceof nt ? t.message : "Search failed — try again", {
              id: "redact-search",
            }));
        } finally {
          ae(!1);
        }
      }
    },
    A =
      g && b
        ? {
            x: Math.min(g.x, b.x),
            y: Math.min(g.y, b.y),
            w: Math.abs(b.x - g.x),
            h: Math.abs(b.y - g.y),
          }
        : null,
    F = Object.values(d).reduce((t, s) => t + s.length, 0),
    Le = () => {
      ((_.current = !0), W(!1), X(0));
    },
    Be = async () => {
      if (r) {
        if (F === 0) {
          j.error("Mark at least one area to redact first");
          return;
        }
        ((_.current = !1), W(!0), X(0));
        try {
          const { redactPdfPages: t } = await fe(),
            s = await t(r, a, d, (o, l) => X((o / l) * 100), {
              scrubMetadata: U,
              removeHidden: H,
              query: D.current.join(`
`),
              searchOptions: {
                matchCase: E,
                wholeWord: Y,
                patterns: $,
                custom: R.current,
              },
            });
          if (_.current) return;
          let n = s.blob;
          if (he())
            try {
              n = await Qe(s.blob);
            } catch {}
          (v(n),
            K(s.warnings),
            Ce(s.mode),
            Se(s.rasterizedPages),
            Q(
              dt({
                fileName: r.name,
                boxesByPage: d,
                report: s,
                scrubMetadata: U,
                removeHidden: H,
              }),
            ),
            j.success(
              `Redacted ${Object.keys(d).filter((o) => d[+o]?.length).length} page(s)`,
            ));
        } catch (t) {
          if (_.current) return;
          (console.error("Redaction failed:", t),
            j.error("Something went wrong applying redactions — try again"));
        } finally {
          W(!1);
        }
      }
    },
    le = () => {
      (h.forEach((t) => URL.revokeObjectURL(t)),
        u(null),
        c([]),
        k({}),
        w(null),
        v(null),
        G([]),
        K([]),
        (D.current = []),
        (R.current = []),
        Q(null));
    },
    _e = () => {
      (k({}),
        G([]),
        K([]),
        (D.current = []),
        (R.current = []),
        v(null),
        Q(null));
    };
  return e.jsx(Ue, {
    toolId: "redact-pdf",
    categoryId: "pdf-tools",
    whatItDoes: ge.what,
    proTip: ge.tip,
    children: r
      ? be
        ? e.jsx(me, { message: "Loading pages..." })
        : f !== null
          ? e.jsxs("div", {
              className: "space-y-3",
              children: [
                e.jsxs("div", {
                  className: "flex items-center justify-between",
                  children: [
                    e.jsxs(y, {
                      size: "sm",
                      variant: "ghost",
                      onClick: () => w(null),
                      className: "gap-1",
                      children: [
                        e.jsx(ot, { className: "h-4 w-4" }),
                        " Back to pages",
                      ],
                    }),
                    e.jsxs("p", {
                      className: "text-sm text-muted-foreground",
                      children: [
                        "Page ",
                        f + 1,
                        " of ",
                        a,
                        " -- drag to mark an area",
                      ],
                    }),
                  ],
                }),
                e.jsxs("div", {
                  ref: ie,
                  onMouseDown: Re,
                  onMouseMove: De,
                  onMouseUp: z,
                  onMouseLeave: z,
                  onTouchStart: Ae,
                  onTouchMove: Fe,
                  onTouchEnd: z,
                  onTouchCancel: z,
                  className:
                    "relative border rounded-lg overflow-hidden bg-white mx-auto",
                  style: {
                    maxWidth: "600px",
                    cursor: "crosshair",
                    touchAction: "none",
                  },
                  children: [
                    e.jsx("img", {
                      src: h[f],
                      alt: `Page ${f + 1}`,
                      className:
                        "w-full h-auto block pointer-events-none select-none",
                    }),
                    (d[f] || []).map((t, s) =>
                      e.jsx(
                        "div",
                        {
                          className: "absolute bg-black group",
                          style: {
                            left: `${t.x * 100}%`,
                            top: `${t.y * 100}%`,
                            width: `${t.w * 100}%`,
                            height: `${t.h * 100}%`,
                          },
                          children: e.jsx("button", {
                            onClick: () => Oe(f, s),
                            className:
                              "absolute -top-2 -right-2 h-5 w-5 rounded-full bg-background border flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity",
                            "aria-label": "Remove this redaction",
                            children: e.jsx(Ie, { className: "h-3 w-3" }),
                          }),
                        },
                        s,
                      ),
                    ),
                    A &&
                      e.jsx("div", {
                        className:
                          "absolute bg-black/70 border-2 border-primary pointer-events-none",
                        style: {
                          left: `${A.x * 100}%`,
                          top: `${A.y * 100}%`,
                          width: `${A.w * 100}%`,
                          height: `${A.h * 100}%`,
                        },
                      }),
                  ],
                }),
                e.jsx("p", {
                  className: "text-xs text-muted-foreground text-center",
                  children: "Hover a black box and click the X to remove it",
                }),
              ],
            })
          : e.jsxs("div", {
              className: "space-y-4",
              children: [
                e.jsxs("div", {
                  className:
                    "p-3 rounded-lg border bg-muted/50 text-xs text-muted-foreground flex flex-wrap gap-x-4 gap-y-1",
                  children: [
                    e.jsx("span", {
                      children:
                        "🔒 Runs entirely in your browser — never uploaded",
                    }),
                    e.jsx("span", {
                      children:
                        "✂️ Genuinely removes content — not a cosmetic overlay",
                    }),
                    e.jsx("span", {
                      children:
                        "📄 Only what is under your boxes is removed; the rest of the page keeps its real text. A page is turned into a picture only if it cannot be edited exactly, and you are told which.",
                    }),
                  ],
                }),
                e.jsx("div", {
                  className: "flex items-center justify-between",
                  children: e.jsxs("p", {
                    className: "text-sm font-medium",
                    children: [
                      r.name,
                      " -- ",
                      a,
                      " page",
                      a === 1 ? "" : "s",
                      F > 0 ? `, ${F} area(s) marked` : "",
                    ],
                  }),
                }),
                e.jsxs("div", {
                  className: "space-y-2 max-w-xl",
                  children: [
                    e.jsx(de, {
                      value: S,
                      onChange: (t) => we(t.target.value),
                      rows: 2,
                      "aria-label": "Text to find and mark",
                      placeholder:
                        "Text to find and mark — one name or number per line",
                    }),
                    e.jsxs("div", {
                      className:
                        "flex flex-wrap items-center gap-x-4 gap-y-2 text-sm",
                      children: [
                        e.jsxs("label", {
                          className: "flex items-center gap-1.5 cursor-pointer",
                          children: [
                            e.jsx(O, {
                              checked: E,
                              onCheckedChange: (t) => Ne(t === !0),
                            }),
                            " Match case",
                          ],
                        }),
                        e.jsxs("label", {
                          className: "flex items-center gap-1.5 cursor-pointer",
                          children: [
                            e.jsx(O, {
                              checked: Y,
                              onCheckedChange: (t) => Pe(t === !0),
                            }),
                            " Whole words only",
                          ],
                        }),
                        e.jsx(y, {
                          type: "button",
                          size: "sm",
                          variant: "outline",
                          className: "h-7 px-2 text-xs",
                          onClick: () => se(st($)),
                          children: ue.every((t) => $.includes(t))
                            ? "Clear all detectors"
                            : "Select all detectors",
                        }),
                        ue.map((t) =>
                          e.jsxs(
                            "label",
                            {
                              className:
                                "flex items-center gap-1.5 cursor-pointer",
                              children: [
                                e.jsx(O, {
                                  checked: $.includes(t),
                                  onCheckedChange: (s) =>
                                    se((n) =>
                                      s === !0
                                        ? [...n, t]
                                        : n.filter((o) => o !== t),
                                    ),
                                }),
                                {
                                  email: "Email addresses",
                                  phone: "Phone numbers",
                                  card: "Card numbers",
                                  ssn: "SSN-style numbers",
                                  ein: "EIN-style numbers",
                                  name: "Likely names (review)",
                                }[t],
                              ],
                            },
                            t,
                          ),
                        ),
                      ],
                    }),
                    e.jsxs("div", {
                      className: "space-y-1.5 pt-1",
                      children: [
                        e.jsxs("div", {
                          className: "flex flex-wrap items-center gap-2",
                          children: [
                            e.jsx("label", {
                              htmlFor: "rd-custom",
                              className: "text-sm font-medium",
                              children: "Custom pattern (optional)",
                            }),
                            e.jsxs("div", {
                              className: "flex gap-1",
                              role: "group",
                              "aria-label": "Pattern style",
                              children: [
                                e.jsx(y, {
                                  type: "button",
                                  size: "sm",
                                  className: "h-7 px-2 text-xs",
                                  variant:
                                    N === "wildcard" ? "default" : "outline",
                                  "aria-pressed": N === "wildcard",
                                  onClick: () => oe("wildcard"),
                                  children: "Simple (ACCT-####)",
                                }),
                                e.jsx(y, {
                                  type: "button",
                                  size: "sm",
                                  className: "h-7 px-2 text-xs",
                                  variant:
                                    N === "regex" ? "default" : "outline",
                                  "aria-pressed": N === "regex",
                                  onClick: () => oe("regex"),
                                  children: "Regular expression",
                                }),
                              ],
                            }),
                          ],
                        }),
                        e.jsx(de, {
                          id: "rd-custom",
                          value: q,
                          onChange: (t) => Te(t.target.value),
                          rows: 2,
                          "aria-invalid": !!T,
                          "aria-describedby": "rd-custom-msg",
                          placeholder:
                            N === "wildcard"
                              ? "One pattern per line, e.g. ACCT-####  (# digit, @ letter, ? any character, * a run)"
                              : "One pattern per line, e.g. ACCT-\\d{4}",
                        }),
                        e.jsx("div", {
                          id: "rd-custom-msg",
                          "aria-live": "polite",
                          children: T
                            ? e.jsx("p", {
                                role: "alert",
                                className: "text-xs text-destructive",
                                children: T,
                              })
                            : e.jsxs("p", {
                                className: "text-xs text-muted-foreground",
                                children: [
                                  "Checked on your device. Remembered in this tab only. ",
                                  N === "wildcard"
                                    ? "A space matches any run of spaces."
                                    : "Lookahead, back-references and ^ $ are not supported.",
                                ],
                              }),
                        }),
                      ],
                    }),
                    e.jsxs(y, {
                      onClick: Ee,
                      disabled:
                        te ||
                        !!T ||
                        (!S.trim() && $.length === 0 && B.length === 0),
                      variant: "outline",
                      className: "gap-1.5",
                      children: [
                        e.jsx(ze, { className: "h-4 w-4" }),
                        " ",
                        te ? "Searching..." : "Find & Mark",
                      ],
                    }),
                  ],
                }),
                re.length > 0 &&
                  e.jsxs(We, {
                    className: "text-sm space-y-1 max-w-xl",
                    children: [
                      e.jsx("p", {
                        className: "font-medium",
                        children:
                          "The text was also found outside the page text:",
                      }),
                      e.jsx("ul", {
                        className:
                          "list-disc pl-5 text-xs text-muted-foreground",
                        children: re.map((t, s) =>
                          e.jsxs(
                            "li",
                            {
                              children: [
                                {
                                  comment: "Comment",
                                  link: "Link address",
                                  form: "Form field",
                                  bookmark: "Bookmark",
                                }[t.kind],
                                t.page >= 0 ? ` on page ${t.page + 1}` : "",
                                ": “",
                                t.text.slice(0, 60),
                                "”",
                              ],
                            },
                            s,
                          ),
                        ),
                      }),
                      e.jsx("p", {
                        className: "text-xs",
                        children:
                          "Tick “Remove comments, and links, form values and bookmarks containing this text” below so they don't survive. Form fields on a marked page are blacked out with the page.",
                      }),
                    ],
                  }),
                e.jsxs("label", {
                  className: "flex items-center gap-2 text-sm cursor-pointer",
                  children: [
                    e.jsx(O, {
                      checked: H,
                      onCheckedChange: (t) => {
                        (je(t === !0), v(null));
                      },
                    }),
                    "Remove comments, and links, form values and bookmarks containing the searched text",
                  ],
                }),
                e.jsxs("label", {
                  className: "flex items-center gap-2 text-sm cursor-pointer",
                  children: [
                    e.jsx(O, {
                      checked: U,
                      onCheckedChange: (t) => {
                        (ve(t === !0), v(null));
                      },
                    }),
                    "Also clear document metadata (title, author, subject, keywords)",
                  ],
                }),
                e.jsx("div", {
                  className: "grid grid-cols-3 sm:grid-cols-4 gap-4",
                  children: h.map((t, s) => {
                    const n = (d[s] || []).length > 0;
                    return e.jsxs(
                      "button",
                      {
                        onClick: () => w(s),
                        className:
                          "relative rounded-lg border-2 overflow-hidden text-left hover:border-primary transition-colors",
                        style: { borderColor: n ? "rgb(220 38 38)" : void 0 },
                        children: [
                          e.jsxs("div", {
                            className: "relative",
                            children: [
                              e.jsx("img", {
                                src: t,
                                alt: `Page ${s + 1}`,
                                className: "w-full h-auto block",
                              }),
                              (d[s] || []).map((o, l) =>
                                e.jsx(
                                  "div",
                                  {
                                    className: "absolute bg-black/80",
                                    style: {
                                      left: `${o.x * 100}%`,
                                      top: `${o.y * 100}%`,
                                      width: `${o.w * 100}%`,
                                      height: `${o.h * 100}%`,
                                    },
                                  },
                                  l,
                                ),
                              ),
                            ],
                          }),
                          e.jsx("span", {
                            className:
                              "absolute bottom-1 left-1 text-xs px-1.5 py-0.5 rounded bg-background/90 border",
                            children: s + 1,
                          }),
                          n &&
                            e.jsx("span", {
                              className:
                                "absolute top-1 right-1 text-xs px-1.5 py-0.5 rounded bg-red-600 text-white",
                              children: d[s].length,
                            }),
                        ],
                      },
                      s,
                    );
                  }),
                }),
                e.jsx("div", {
                  className: "flex gap-3",
                  children: ye
                    ? e.jsx(me, {
                        message: "Applying redactions...",
                        progress: ke,
                        onStop: Le,
                      })
                    : P
                      ? e.jsxs(e.Fragment, {
                          children: [
                            e.jsx(Ye, {
                              blob: P,
                              fileName: `redacted_${r.name}`,
                            }),
                            e.jsx(y, {
                              variant: "outline",
                              onClick: le,
                              children: "New",
                            }),
                          ],
                        })
                      : e.jsxs(e.Fragment, {
                          children: [
                            e.jsx(y, {
                              onClick: Be,
                              disabled: F === 0,
                              children: "Apply Redactions",
                            }),
                            e.jsx(y, {
                              variant: "ghost",
                              onClick: _e,
                              disabled: F === 0,
                              children: "Clear marks",
                            }),
                            e.jsx(y, {
                              variant: "ghost",
                              onClick: le,
                              children: "Start over",
                            }),
                          ],
                        }),
                }),
                P &&
                  e.jsxs("p", {
                    className: "text-xs text-muted-foreground max-w-xl",
                    children: [
                      $e === "rasterized-pages"
                        ? `Everything under your boxes is gone. ${L.length === 1 ? "One page" : `${L.length} pages`} (${L.join(", ")}) had to be turned into a picture, so the text on ${L.length === 1 ? "that page" : "those pages"} can no longer be selected or searched; the notice below says why. All other text is still real text. `
                        : "Everything under your boxes is gone, and the rest of the text is still real, selectable text. ",
                      he()
                        ? "A small “Created with FreeDailyPro.com” mark is added at the bottom of each page on trial uses. "
                        : "",
                      "Check the result before you send it.",
                    ],
                  }),
                P &&
                  ne.length > 0 &&
                  e.jsx("div", {
                    className:
                      "p-3 rounded-lg border border-red-500/50 bg-red-500/10 text-sm",
                    children: ne.map((t, s) =>
                      e.jsxs("p", { children: ["⚠️ ", t] }, s),
                    ),
                  }),
                P &&
                  x &&
                  e.jsxs("div", {
                    className:
                      "p-3 rounded-lg border bg-card max-w-2xl space-y-2",
                    "data-testid": "redaction-summary",
                    children: [
                      e.jsx("p", {
                        className: "text-sm font-medium",
                        children: "Redaction summary",
                      }),
                      e.jsx("p", {
                        className: "text-sm",
                        "data-testid": "summary-headline",
                        children:
                          x.headline ||
                          "Only areas drawn by hand were removed.",
                      }),
                      e.jsxs("p", {
                        className: "text-xs text-muted-foreground",
                        children: [
                          "Metadata ",
                          x.metadataCleared ? "cleared" : "not cleared",
                          ".",
                          x.rasterizedPages.length > 0
                            ? ` ${x.rasterizedPages.length === 1 ? "Page" : "Pages"} ${x.rasterizedPages.join(", ")} became ${x.rasterizedPages.length === 1 ? "a picture" : "pictures"}.`
                            : "",
                          x.inspection.attachments > 0
                            ? ` ${x.inspection.attachments} attached file${x.inspection.attachments === 1 ? "" : "s"} still in the file (not inspected or removed).`
                            : "",
                          " ",
                          "The removed text is not in the summary.",
                        ],
                      }),
                      e.jsxs("details", {
                        className: "text-xs",
                        children: [
                          e.jsx("summary", {
                            className: "cursor-pointer text-muted-foreground",
                            children: "Show the full summary",
                          }),
                          e.jsx("pre", {
                            className:
                              "mt-2 whitespace-pre-wrap font-sans text-xs",
                            children: xe(x),
                          }),
                        ],
                      }),
                      e.jsx(y, {
                        size: "sm",
                        variant: "outline",
                        onClick: () =>
                          Ge(
                            new Blob([xe(x)], {
                              type: "text/plain;charset=utf-8",
                            }),
                            `redaction-summary_${r.name.replace(/\.pdf$/i, "")}.txt`,
                            { free: !0 },
                          ),
                        children: "Download summary (.txt)",
                      }),
                    ],
                  }),
                P && e.jsx(Ke, { blob: P, mimeType: "application/pdf" }),
              ],
            })
      : e.jsx(He, {
          gateAtDownload: !0,
          accept: ".pdf",
          onFiles: Me,
          label: "Drop a PDF file",
          description: "Mark and permanently remove sensitive content",
        }),
  });
}
export { Zt as default };
//# sourceMappingURL=RedactPdf-DPaVI6zY.js.map
