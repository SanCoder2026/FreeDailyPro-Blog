import {
  c as L,
  b as S,
  f as F,
  y as J,
  P as u,
  z as K,
  g as Pt,
  a as U,
  F as vt,
  E as Dt,
  k as Ct,
  e as Ot,
  d as St,
} from "./index-BRvxULIc.js";
import { p as Ft, l as At } from "./utils-s8ucLyj8.js";
import { r as ut, a as Bt, w as Tt } from "./pdfBookmarks-BjfxtCfb.js";
import { d as $t, e as ht } from "./redactSearch-DQpyyh_t.js";
import {
  d as V,
  f as dt,
  c as pt,
  r as Rt,
  u as It,
} from "./imageRecompress-eXQFDUm-.js";
import "./index-CnXdQaNG.js";
import "./vendor-react-D01g8YgM.js";
import "./index-DMQTJy3b.js";
import "./nameDetect-DvHCRM0m.js";
let Z = null;
function jt(n) {
  Z = n;
}
const mt = () => {
    if (!Z) throw new Error("redaction picture codec is not set");
    return Z;
  },
  gt = (n) => {
    const t = new Uint8Array(n.length);
    for (let e = 0; e < n.length; e++) t[e] = n.charCodeAt(e) & 255;
    return t;
  };
class B extends Error {
  constructor(t) {
    (super(t), (this.reason = t), (this.name = "NeedRasterError"));
  }
}
const G = [1, 0, 0, 1, 0, 0],
  I = (n, t) => [
    n[0] * t[0] + n[1] * t[2],
    n[0] * t[1] + n[1] * t[3],
    n[2] * t[0] + n[3] * t[2],
    n[2] * t[1] + n[3] * t[3],
    n[4] * t[0] + n[5] * t[2] + t[4],
    n[4] * t[1] + n[5] * t[3] + t[5],
  ],
  $ = (n, t, e) => [n[0] * t + n[2] * e + n[4], n[1] * t + n[3] * e + n[5]];
function yt(n) {
  const t = n[0] * n[3] - n[1] * n[2];
  if (Math.abs(t) < 1e-12) return null;
  const e = n[3] / t,
    o = -n[1] / t,
    s = -n[2] / t,
    i = n[0] / t;
  return [e, o, s, i, -(n[4] * e + n[5] * s), -(n[4] * o + n[5] * i)];
}
const ot = (n) => Math.sqrt(Math.abs(n[0] * n[3] - n[1] * n[2])),
  st = (n) =>
    (Math.abs(n[1]) < 1e-9 && Math.abs(n[2]) < 1e-9) ||
    (Math.abs(n[0]) < 1e-9 && Math.abs(n[3]) < 1e-9),
  E = 0.05,
  H = (n, t) =>
    n.x0 < t.x1 - E && n.x1 > t.x0 + E && n.y0 < t.y1 - E && n.y1 > t.y0 + E,
  zt = (n, t) =>
    n.x0 >= t.x0 - E &&
    n.x1 <= t.x1 + E &&
    n.y0 >= t.y0 - E &&
    n.y1 <= t.y1 + E,
  j = (n) => ({
    x0: Math.min(...n.map((t) => t[0])),
    x1: Math.max(...n.map((t) => t[0])),
    y0: Math.min(...n.map((t) => t[1])),
    y1: Math.max(...n.map((t) => t[1])),
  }),
  kt = new Set([0, 9, 10, 12, 13, 32]),
  Et = new Set([40, 41, 60, 62, 91, 93, 123, 125, 47, 37]),
  it = (n) => !kt.has(n) && !Et.has(n);
function Wt(n) {
  let t = 0;
  const e = n.length,
    o = [];
  let s = [],
    i = -1;
  function c() {
    for (;;) {
      for (; t < e && kt.has(n.charCodeAt(t));) t++;
      if (n[t] === "%")
        for (
          ;
          t < e &&
          n[t] !==
            `
` &&
          n[t] !== "\r";
        )
          t++;
      else break;
    }
  }
  function r() {
    const p = t;
    t++;
    let h = 1;
    const d = [];
    for (; t < e && h > 0;) {
      const a = n[t];
      if (a === "\\") {
        const f = n[t + 1];
        if (f === void 0) {
          t++;
          break;
        }
        if (/[0-7]/.test(f)) {
          let y = f,
            M = 2;
          for (; M < 4 && t + M < e && /[0-7]/.test(n[t + M]) && y.length < 3;)
            ((y += n[t + M]), M++);
          (d.push(parseInt(y, 8) & 255), (t += 1 + y.length));
          continue;
        }
        const g = {
          n: 10,
          r: 13,
          t: 9,
          b: 8,
          f: 12,
          "(": 40,
          ")": 41,
          "\\": 92,
        };
        if (f === "\r") {
          t +=
            n[t + 2] ===
            `
`
              ? 3
              : 2;
          continue;
        }
        if (
          f ===
          `
`
        ) {
          t += 2;
          continue;
        }
        (d.push(g[f] ?? f.charCodeAt(0)), (t += 2));
        continue;
      }
      if (a === "(") h++;
      else if (a === ")" && (h--, h === 0)) {
        t++;
        break;
      }
      (d.push(n.charCodeAt(t) & 255), t++);
    }
    return { t: "str", bytes: Uint8Array.from(d), raw: n.slice(p, t) };
  }
  function m() {
    const p = t;
    t++;
    let h = "";
    for (; t < e && n[t] !== ">";)
      (/[0-9a-fA-F]/.test(n[t]) && (h += n[t]), t++);
    (t++, h.length % 2 && (h += "0"));
    const d = new Uint8Array(h.length / 2);
    for (let a = 0; a < d.length; a++)
      d[a] = parseInt(h.slice(a * 2, a * 2 + 2), 16);
    return { t: "str", bytes: d, raw: n.slice(p, t) };
  }
  function l() {
    const p = t,
      h = n[t];
    if (h === "(") return r();
    if (h === "<") {
      if (n[t + 1] === "<") {
        t += 2;
        const a = [];
        for (; c(), !(t >= e);) {
          if (n[t] === ">" && n[t + 1] === ">") {
            t += 2;
            break;
          }
          const f = l();
          "close" in f || "op" in f || a.push(f);
        }
        return { t: "dict", items: a, raw: n.slice(p, t) };
      }
      return m();
    }
    if (h === ">") return ((t += n[t + 1] === ">" ? 2 : 1), { close: ">>" });
    if (h === "[") {
      t++;
      const a = [];
      for (; c(), !(t >= e);) {
        if (n[t] === "]") {
          t++;
          break;
        }
        const f = l();
        "close" in f || "op" in f || a.push(f);
      }
      return { t: "arr", items: a, raw: n.slice(p, t) };
    }
    if (h === "]") return (t++, { close: "]" });
    if (h === "/") {
      for (t++; t < e && it(n.charCodeAt(t));) t++;
      const a = n.slice(p, t);
      return {
        t: "name",
        v: a
          .slice(1)
          .replace(/#([0-9a-fA-F]{2})/g, (g, y) =>
            String.fromCharCode(parseInt(y, 16)),
          ),
        raw: a,
      };
    }
    if (h === "{" || h === "}" || h === ")")
      return (t++, { t: "other", raw: h });
    for (; t < e && it(n.charCodeAt(t));) t++;
    if (t === p) return (t++, { t: "other", raw: n[p] });
    const d = n.slice(p, t);
    return /^[+-]?(\d+\.?\d*|\.\d+)$/.test(d)
      ? { t: "num", v: parseFloat(d), raw: d }
      : d === "true" || d === "false" || d === "null"
        ? { t: "other", raw: d }
        : { op: d };
  }
  for (; c(), !(t >= e);) {
    i < 0 && (i = t);
    const p = l();
    if (!("close" in p))
      if ("op" in p) {
        const h = { op: p.op, args: s, start: i, end: t };
        if (p.op === "BI") {
          const d = /(^|[\s])ID[\s]/.exec(n.slice(t));
          if (d) {
            const a = t + d.index + d[0].length,
              f = /[\s]EI(?=[\s]|$)/.exec(n.slice(a)),
              g = f ? a + f.index + f[0].length : e;
            ((h.inlineData = n.slice(t, g)), (t = g), (h.end = t));
          }
        }
        (o.push(h), (s = []), (i = -1));
      } else s.push(p);
  }
  return o;
}
const Nt = (n) =>
    "<" + Array.from(n, (t) => t.toString(16).padStart(2, "0")).join("") + ">",
  T = (n) => {
    const t = Math.round(n * 1e3) / 1e3;
    return Object.is(t, -0) ? "0" : String(t);
  };
function A(n, t = 0) {
  return n instanceof U ? n.asNumber() : t;
}
const W = (n) => (n instanceof u ? n.decodeText() : null);
function qt(n) {
  const t = n
      .replace(/^[A-Z]{6}\+/, "")
      .replace(/[\s,_-]+/g, "")
      .toLowerCase(),
    e = /bold|black|heavy|demi/.test(t),
    o = /italic|oblique|ital\b/.test(t) || /(it|obl)$/.test(t);
  return /^(courier|couriernew)/.test(t)
    ? e
      ? o
        ? "Courier-BoldOblique"
        : "Courier-Bold"
      : o
        ? "Courier-Oblique"
        : "Courier"
    : /^(helvetica|arial)/.test(t)
      ? e
        ? o
          ? "Helvetica-BoldOblique"
          : "Helvetica-Bold"
        : o
          ? "Helvetica-Oblique"
          : "Helvetica"
      : /^(times|timesnewroman)/.test(t)
        ? e
          ? o
            ? "Times-BoldItalic"
            : "Times-Bold"
          : o
            ? "Times-Italic"
            : "Times-Roman"
        : t.startsWith("symbol")
          ? "Symbol"
          : t.startsWith("zapfdingbats")
            ? "ZapfDingbats"
            : null;
}
let _ = null;
function Ut(n) {
  if (n === "WinAnsi" && _) return _;
  const t = new Map(),
    e = Dt[n];
  for (const o of e.supportedCodePoints) {
    const { code: s, name: i } = e.encodeUnicodeCodePoint(o);
    t.has(s) || t.set(s, i);
  }
  return (n === "WinAnsi" && (_ = t), t);
}
function Gt(n) {
  const t = W(n.lookup(u.of("Subtype"))),
    e = W(n.lookup(u.of("BaseFont"))) ?? "";
  if (t === "Type0") {
    const a = n.lookup(u.of("Encoding")),
      f = W(a);
    if (f !== "Identity-H")
      throw new B(
        `font encoding ${f ?? "custom CMap"} is not supported for text removal`,
      );
    const g = n.lookup(u.of("DescendantFonts")),
      y = g instanceof F ? g.lookupMaybe(0, S) : void 0;
    if (!y) throw new B("composite font without a descendant");
    const M = A(y.lookup(u.of("DW")), 1e3),
      k = new Map(),
      b = y.lookup(u.of("W"));
    if (b instanceof F) {
      let x = 0;
      for (; x < b.size();) {
        const P = b.lookup(x),
          C = b.lookup(x + 1);
        if (P instanceof U && C instanceof F) {
          for (let v = 0; v < C.size(); v++)
            k.set(P.asNumber() + v, A(C.lookup(v)));
          x += 2;
        } else if (P instanceof U && C instanceof U) {
          const v = A(b.lookup(x + 2)),
            R = P.asNumber(),
            N = C.asNumber();
          if (N - R > 7e4) throw new B("font width table too large");
          for (let z = R; z <= N; z++) k.set(z, v);
          x += 3;
        } else x++;
      }
    }
    const w = y.lookupMaybe(u.of("FontDescriptor"), S),
      { ascent: O, descent: D } = at(w, null);
    return { wide: !0, width: (x) => k.get(x) ?? M, ascent: O, descent: D };
  }
  const o = n.lookupMaybe(u.of("FontDescriptor"), S),
    s = A(n.lookup(u.of("FirstChar")), 0),
    i = n.lookup(u.of("Widths")),
    c = A(o?.lookup(u.of("MissingWidth")), 0),
    r = qt(e);
  if (t === "Type3") {
    const a = n.lookup(u.of("FontMatrix")),
      f = a instanceof F ? A(a.lookup(0), 0.001) : 0.001,
      g = n.lookup(u.of("FontBBox"));
    let y = 0.9,
      M = -0.2;
    if (g instanceof F && g.size() === 4) {
      const k = a instanceof F ? A(a.lookup(3), 0.001) : 0.001,
        b = A(g.lookup(1)) * k,
        w = A(g.lookup(3)) * k;
      w > b && ((y = Math.max(w, 0.1)), (M = Math.min(b, 0)));
    }
    return {
      wide: !1,
      ascent: y,
      descent: M,
      width: (k) =>
        i instanceof F && k - s >= 0 && k - s < i.size()
          ? A(i.lookup(k - s)) * f * 1e3
          : 0,
    };
  }
  let m = null,
    l = null;
  if (
    !(i instanceof F) ||
    (!!r &&
      !o?.get(u.of("FontFile")) &&
      !o?.get(u.of("FontFile2")) &&
      !o?.get(u.of("FontFile3")) &&
      !(i instanceof F))
  ) {
    const a = r ?? "Helvetica";
    l = vt.load(a);
    const f =
      a === "Symbol"
        ? "Symbol"
        : a === "ZapfDingbats"
          ? "ZapfDingbats"
          : "WinAnsi";
    m = new Map(Ut(f));
    const g = n.lookup(u.of("Encoding"));
    if (g instanceof S) {
      const y = g.lookup(u.of("Differences"));
      if (y instanceof F) {
        let M = 0;
        for (let k = 0; k < y.size(); k++) {
          const b = y.lookup(k);
          b instanceof U
            ? (M = b.asNumber())
            : b instanceof u && m.set(M++, b.decodeText());
        }
      }
    }
  }
  const { ascent: h, descent: d } = at(o, l);
  return {
    wide: !1,
    ascent: h,
    descent: d,
    width: (a) => {
      if (i instanceof F) {
        const y = a - s;
        return y >= 0 && y < i.size() ? A(i.lookup(y), c) : c;
      }
      const f = m?.get(a),
        g = f && l ? l.getWidthOfGlyph(f) : void 0;
      return typeof g == "number" ? g : c || 500;
    },
  };
}
function at(n, t) {
  let e = A(n?.lookup(u.of("Ascent")), 0),
    o = A(n?.lookup(u.of("Descent")), 0);
  return (
    !e && t && typeof t.Ascender == "number" && (e = t.Ascender),
    !o && t && typeof t.Descender == "number" && (o = t.Descender),
    e || (e = 800),
    o || (o = -200),
    o > 0 && (o = -o),
    {
      ascent: Math.min(Math.max(e, 500), 1100) / 1e3,
      descent: Math.max(Math.min(o, 0), -400) / 1e3,
    }
  );
}
function rt(n, t, e, o) {
  const s = new Uint8Array(t * e);
  let i = !1;
  const c = (a, f) =>
      j([
        $(n, a / t, 1 - f / e),
        $(n, (a + 1) / t, 1 - f / e),
        $(n, a / t, 1 - (f + 1) / e),
        $(n, (a + 1) / t, 1 - (f + 1) / e),
      ]),
    r = o.filter((a) =>
      H(j([$(n, 0, 0), $(n, 1, 0), $(n, 0, 1), $(n, 1, 1)]), a),
    );
  if (!r.length) return null;
  const m = yt(n);
  let l = 0,
    p = t - 1,
    h = 0,
    d = e - 1;
  if (m) {
    const a = [];
    for (const k of r)
      for (const [b, w] of [
        [k.x0, k.y0],
        [k.x1, k.y0],
        [k.x0, k.y1],
        [k.x1, k.y1],
      ])
        a.push($(m, b, w));
    const f = Math.min(...a.map((k) => k[0])),
      g = Math.max(...a.map((k) => k[0])),
      y = Math.min(...a.map((k) => k[1])),
      M = Math.max(...a.map((k) => k[1]));
    ((l = Math.max(0, Math.floor(f * t) - 1)),
      (p = Math.min(t - 1, Math.ceil(g * t) + 1)),
      (h = Math.max(0, Math.floor((1 - M) * e) - 1)),
      (d = Math.min(e - 1, Math.ceil((1 - y) * e) + 1)));
  }
  for (let a = h; a <= d; a++)
    for (let f = l; f <= p; f++) {
      const g = c(f, a);
      r.some((y) => H(g, y)) && ((s[a * t + f] = 1), (i = !0));
    }
  return i ? s : null;
}
function Q(n, t) {
  const e = (s) =>
      s === "DeviceGray" || s === "G" || s === "CalGray"
        ? { comps: 1, black: [0], name: "DeviceGray" }
        : s === "DeviceRGB" || s === "RGB" || s === "CalRGB"
          ? { comps: 3, black: [0, 0, 0], name: "DeviceRGB" }
          : s === "DeviceCMYK" || s === "CMYK"
            ? { comps: 4, black: [0, 0, 0, 255], name: "DeviceCMYK" }
            : null,
    o = t instanceof L ? n.lookup(t) : t;
  if (o instanceof u) return e(o.decodeText());
  if (o instanceof F) {
    const s = W(o.lookup(0));
    if (s === "ICCBased") {
      const i = o.lookup(1),
        c = i instanceof J ? A(i.dict.lookup(u.of("N")), 0) : 0;
      return c === 1
        ? { comps: 1, black: [0], name: "" }
        : c === 3
          ? { comps: 3, black: [0, 0, 0], name: "" }
          : c === 4
            ? { comps: 4, black: [0, 0, 0, 255], name: "" }
            : null;
    }
    if (s === "CalGray" || s === "CalRGB") return e(s);
    if (s === "Indexed" || s === "I") {
      const c = Rt(o, (r) => {
        const m = Q(n, r);
        return m && (m.comps === 1 || m.comps === 3) ? m.comps : null;
      });
      return c
        ? {
            comps: 3,
            black: [0, 0, 0],
            name: "DeviceRGB",
            indexed: { palette: c.palette },
          }
        : null;
    }
  }
  return null;
}
async function ct(n, t, e, o, s, i) {
  const c = dt(t.dict),
    r = pt(c);
  if (r === "jpeg") {
    const d = V(t, c);
    if (e.comps === 4) return null;
    const a = await mt().decodeJpeg(d, o, s, e.comps);
    return !a || a.length !== o * s * e.comps
      ? null
      : { w: o, h: s, comps: e.comps, data: a };
  }
  if (r !== "raw") return null;
  let m;
  try {
    m = V(t, c);
  } catch {
    return null;
  }
  const l = e.indexed ? 1 : e.comps,
    p = Math.ceil((o * l * i) / 8) * s;
  if (m.length < p) return null;
  let h = It(m, o, s, l, i);
  if (e.indexed) {
    const d = new Uint8Array(o * s * 3),
      a = e.indexed.palette,
      f = a.length / 3 - 1;
    for (let g = 0; g < o * s; g++) {
      const y = Math.min(h[g], f);
      ((d[g * 3] = a[y * 3]),
        (d[g * 3 + 1] = a[y * 3 + 1]),
        (d[g * 3 + 2] = a[y * 3 + 2]));
    }
    return { w: o, h: s, comps: 3, data: d };
  }
  if (i !== 8) {
    const d = (1 << i) - 1,
      a = new Uint8Array(h.length);
    for (let f = 0; f < h.length; f++) a[f] = Math.round((h[f] * 255) / d);
    h = a;
  }
  return { w: o, h: s, comps: e.comps, data: new Uint8Array(h) };
}
const Xt = (n, t) => {
  if (!(n instanceof F)) return !0;
  for (let e = 0; e < n.size(); e++)
    if (A(n.lookup(e), e % 2) !== e % 2) return !1;
  return n.size() === 0 || n.size() === t * 2;
};
function X(n, t, e, o = !0) {
  return o ? n.register(n.flateStream(e, t)) : n.register(K.of(n.obj(t), e));
}
class xt {
  constructor(t, e, o) {
    ((this.dict = t),
      (this.ctx = e),
      (this.attach = o),
      (this.cloned = !1),
      (this.replaced = new Set()),
      (this.shared = !1));
  }
  lookupXObject(t) {
    return this.dict.lookupMaybe(u.of("XObject"), S)?.lookup(u.of(t));
  }
  fonts() {
    return this.dict.lookupMaybe(u.of("Font"), S);
  }
  prune(t) {
    if (!this.cloned || this.shared) return;
    const e = this.dict.lookupMaybe(u.of("XObject"), S);
    if (e)
      for (const o of Array.from(this.replaced)) {
        const s = o.replace(
          /[^A-Za-z0-9_.-]/g,
          (c) => "#" + c.charCodeAt(0).toString(16).padStart(2, "0"),
        );
        t.includes(`/${o} Do`) || t.includes(`/${s} Do`) || e.delete(u.of(o));
      }
  }
  addXObject(t, e, o) {
    if ((o && this.replaced.add(o), !this.cloned)) {
      const r = S.fromMapWithContext(new Map(this.dict.entries()), this.ctx),
        m = this.dict.lookupMaybe(u.of("XObject"), S);
      (r.set(
        u.of("XObject"),
        m
          ? S.fromMapWithContext(new Map(m.entries()), this.ctx)
          : this.ctx.obj({}),
      ),
        (this.dict = r),
        (this.cloned = !0),
        this.attach(r));
    }
    const s = this.dict.lookup(u.of("XObject"));
    let i = 0,
      c = `${t}${i}`;
    for (; s.has(u.of(c));) c = `${t}${++i}`;
    return (s.set(u.of(c), e), c);
  }
}
class nt {
  constructor(t, e, o, s, i, c, r) {
    ((this.ctx = t),
      (this.boxes = e),
      (this.res = o),
      (this.stats = i),
      (this.depth = c),
      (this.seen = r),
      (this.stack = []),
      (this.tm = G),
      (this.tlm = G),
      (this.out = []),
      (this.changed = !1),
      (this.path = { ops: [], segs: [] }),
      (this.clipPending = null),
      (this.fontCache = new Map()),
      (this.gs = {
        ctm: s,
        font: null,
        fs: 0,
        tc: 0,
        tw: 0,
        th: 1,
        tl: 0,
        rise: 0,
        lw: 1,
        clip: null,
      }));
  }
  hits(t) {
    return this.boxes.filter((e) => H(t, e));
  }
  emit(t) {
    this.out.push(t);
  }
  emitOp(t, e) {
    this.emit(t.slice(e.start, e.end));
  }
  async run(t) {
    const e = Wt(t);
    for (const s of e) await this.step(t, s);
    if ((this.flushPath(t), !this.changed)) return null;
    const o =
      this.out.join(`
`) +
      `
`;
    return (this.res.prune(o), o);
  }
  flushPath(t) {
    for (const e of this.path.ops) this.emitOp(t, e);
    this.path = { ops: [], segs: [] };
  }
  pt(t, e) {
    return $(this.gs.ctm, t, e);
  }
  async step(t, e) {
    const o = e.args,
      s = (c) => (o[c] && o[c].t === "num" ? o[c].v : 0),
      i = this.gs;
    switch (e.op) {
      case "q":
        return (this.stack.push({ ...i, ctm: [...i.ctm] }), this.emitOp(t, e));
      case "Q": {
        const c = this.stack.pop();
        return (c && (this.gs = c), this.emitOp(t, e));
      }
      case "cm":
        return (
          (i.ctm = I([s(0), s(1), s(2), s(3), s(4), s(5)], i.ctm)),
          this.emitOp(t, e)
        );
      case "w":
        return ((i.lw = s(0)), this.emitOp(t, e));
      case "BT":
        return ((this.tm = G), (this.tlm = G), this.emitOp(t, e));
      case "ET":
        return this.emitOp(t, e);
      case "Tc":
        return ((i.tc = s(0)), this.emitOp(t, e));
      case "Tw":
        return ((i.tw = s(0)), this.emitOp(t, e));
      case "Tz":
        return ((i.th = s(0) / 100), this.emitOp(t, e));
      case "TL":
        return ((i.tl = s(0)), this.emitOp(t, e));
      case "Ts":
        return ((i.rise = s(0)), this.emitOp(t, e));
      case "Tf": {
        const c = o[0] && o[0].t === "name" ? o[0].v : "";
        return ((i.fs = s(1)), (i.font = this.loadFont(c)), this.emitOp(t, e));
      }
      case "Td":
        return (
          (this.tlm = I([1, 0, 0, 1, s(0), s(1)], this.tlm)),
          (this.tm = this.tlm),
          this.emitOp(t, e)
        );
      case "TD":
        return (
          (i.tl = -s(1)),
          (this.tlm = I([1, 0, 0, 1, s(0), s(1)], this.tlm)),
          (this.tm = this.tlm),
          this.emitOp(t, e)
        );
      case "Tm":
        return (
          (this.tlm = [s(0), s(1), s(2), s(3), s(4), s(5)]),
          (this.tm = this.tlm),
          this.emitOp(t, e)
        );
      case "T*":
        return (
          (this.tlm = I([1, 0, 0, 1, 0, -i.tl], this.tlm)),
          (this.tm = this.tlm),
          this.emitOp(t, e)
        );
      case "Tj":
      case "TJ":
      case "'":
      case '"':
        return this.showText(t, e);
      case "m":
      case "l": {
        (this.path.ops.push(e),
          this.path.segs.push({ kind: e.op, pts: [this.pt(s(0), s(1))] }));
        return;
      }
      case "c":
        (this.path.ops.push(e),
          this.path.segs.push({
            kind: "c",
            pts: [
              this.pt(s(0), s(1)),
              this.pt(s(2), s(3)),
              this.pt(s(4), s(5)),
            ],
          }));
        return;
      case "v":
      case "y":
        (this.path.ops.push(e),
          this.path.segs.push({
            kind: "c",
            pts: [this.pt(s(0), s(1)), this.pt(s(2), s(3))],
          }));
        return;
      case "re": {
        this.path.ops.push(e);
        const [c, r, m, l] = [s(0), s(1), s(2), s(3)];
        this.path.segs.push({
          kind: "re",
          pts: [
            this.pt(c, r),
            this.pt(c + m, r),
            this.pt(c + m, r + l),
            this.pt(c, r + l),
          ],
        });
        return;
      }
      case "h":
        (this.path.ops.push(e), this.path.segs.push({ kind: "h", pts: [] }));
        return;
      case "W":
      case "W*":
        ((this.clipPending = e.op), this.path.ops.push(e));
        return;
      case "S":
      case "s":
      case "f":
      case "F":
      case "f*":
      case "B":
      case "B*":
      case "b":
      case "b*":
      case "n":
        return this.paintPath(t, e);
      case "sh": {
        const c = i.clip;
        if (!c || this.hits(c).length)
          throw new B("a shading (gradient) fill may lie under a box");
        return this.emitOp(t, e);
      }
      case "BI": {
        const c = j([
          this.pt(0, 0),
          this.pt(1, 0),
          this.pt(0, 1),
          this.pt(1, 1),
        ]);
        if (this.hits(c).length)
          throw new B("an inline picture lies under a box");
        return this.emitOp(t, e);
      }
      case "Do":
        return this.doXObject(t, e);
      case "BDC":
      case "DP":
        return this.markedContent(t, e);
      default:
        return this.emitOp(t, e);
    }
  }
  markedContent(t, e) {
    const o = e.args[1];
    if (o && o.t === "dict" && /\/(ActualText|Alt|E)\b/.test(o.raw)) {
      const s = [];
      for (let i = 0; i + 1 < o.items.length; i += 2) {
        const c = o.items[i];
        (c.t === "name" && ["ActualText", "Alt", "E"].includes(c.v)) ||
          s.push(c.raw, o.items[i + 1].raw);
      }
      return (
        (this.changed = !0),
        this.emit(`${e.args[0].raw} <<${s.join(" ")}>> ${e.op}`)
      );
    }
    return this.emitOp(t, e);
  }
  loadFont(t) {
    const e = this.res.fonts()?.lookupMaybe(u.of(t), S);
    if (!e) return null;
    let o = this.fontCache.get(e);
    return (o || ((o = Gt(e)), this.fontCache.set(e, o)), o);
  }
  showText(t, e) {
    const o = this.gs;
    if (!o.font) throw new B("text drawn without a readable font");
    const s = o.font;
    let i = "";
    (e.op === "'" || e.op === '"') &&
      (e.op === '"' &&
        ((o.tw = e.args[0]?.v ?? o.tw), (o.tc = e.args[1]?.v ?? o.tc)),
      (this.tlm = I([1, 0, 0, 1, 0, -o.tl], this.tlm)),
      (this.tm = this.tlm),
      (i = e.op === '"' ? `${T(o.tw)} Tw ${T(o.tc)} Tc T*` : "T*"));
    const c =
        e.op === "TJ" ? (e.args[0]?.items ?? []) : [e.args[e.args.length - 1]],
      r = [];
    let m = !1;
    const l = I([o.fs * o.th, 0, 0, o.fs, 0, o.rise], I(this.tm, o.ctm));
    let p = 0;
    for (const d of c) {
      if (d.t === "num") {
        const y = (-d.v / 1e3) * o.fs * o.th;
        ((p += y), r.push({ n: d.v }));
        continue;
      }
      if (d.t !== "str") continue;
      const a = d.bytes,
        f = s.wide ? 2 : 1;
      let g = [];
      for (let y = 0; y + f <= a.length; y += f) {
        const M = s.wide ? (a[y] << 8) | a[y + 1] : a[y],
          k = s.width(M) / 1e3,
          b = (k * o.fs + o.tc + (!s.wide && M === 32 ? o.tw : 0)) * o.th,
          w = I([1, 0, 0, 1, p / (o.fs * o.th || 1), 0], l),
          O = j([
            $(w, 0, s.descent),
            $(w, k, s.descent),
            $(w, 0, s.ascent),
            $(w, k, s.ascent),
          ]);
        if (this.hits(O).length)
          ((m = !0),
            this.stats.glyphs++,
            g.length && (r.push({ s: g }), (g = [])),
            r.push({
              n: -(
                k * 1e3 +
                ((o.tc + (!s.wide && M === 32 ? o.tw : 0)) * 1e3) / (o.fs || 1)
              ),
            }));
        else for (let D = 0; D < f; D++) g.push(a[y + D]);
        p += b;
      }
      g.length && r.push({ s: g });
    }
    if (((this.tm = I([1, 0, 0, 1, p, 0], this.tm)), !m))
      return this.emitOp(t, e);
    this.changed = !0;
    const h = r.map((d) => (d.s ? Nt(Uint8Array.from(d.s)) : T(d.n)));
    this.emit(`${i ? i + " " : ""}[${h.join(" ")}] TJ`);
  }
  paintPath(t, e) {
    const { ops: o, segs: s } = this.path,
      i = this.gs,
      c = this.clipPending;
    ((this.clipPending = null), o.filter((x) => x.op !== "W" && x.op !== "W*"));
    const r = (x, P) => {
      if (((this.path = { ops: [], segs: [] }), P))
        for (const C of P) this.emit(C);
      else if (x) {
        for (const C of o) this.emitOp(t, C);
        this.emitOp(t, e);
      }
    };
    (() => {
      if (!c) return;
      const x = s.filter((P) => P.kind === "re");
      if (x.length === 1 && s.length === 1 && st(i.ctm)) {
        const P = j(x[0].pts);
        i.clip = i.clip
          ? {
              x0: Math.max(i.clip.x0, P.x0),
              y0: Math.max(i.clip.y0, P.y0),
              x1: Math.min(i.clip.x1, P.x1),
              y1: Math.min(i.clip.y1, P.y1),
            }
          : P;
      }
    })();
    const l =
      e.op === "n"
        ? "none"
        : /^(S|s)$/.test(e.op)
          ? "stroke"
          : /^(B|B\*|b|b\*)$/.test(e.op)
            ? "both"
            : "fill";
    if (l === "none" || !s.length) return r(!0);
    const p = s.flatMap((x) => x.pts),
      h = l === "fill" ? 0 : ((i.lw * ot(i.ctm)) / 2) * 1.5 + 0.5,
      d = j(p),
      a = { x0: d.x0 - h, y0: d.y0 - h, x1: d.x1 + h, y1: d.y1 + h },
      f = this.hits(a);
    if (!f.length) return r(!0);
    if (f.some((x) => zt(a, x)))
      return (
        this.stats.paths++,
        (this.changed = !0),
        r(!1, c ? [...o.map((x) => t.slice(x.start, x.end)), "n"] : [])
      );
    if (c) throw new B("a clipped drawing is partly under a box");
    const g = yt(i.ctm);
    if (!g)
      throw new B(
        "a drawing with a degenerate transform is partly under a box",
      );
    const y = Vt(s),
      M = y.map(Ht),
      k = M.every((x) => x !== null),
      b = y.every((x) => !x.curve),
      w = (x, P) => $(g, x, P),
      O = () => {
        let x = M;
        for (const C of f) x = x.flatMap((v) => Lt(v, C));
        const P = [];
        for (const C of x) {
          const v = [
            w(C.x0, C.y0),
            w(C.x1, C.y0),
            w(C.x1, C.y1),
            w(C.x0, C.y1),
          ];
          P.push(
            `${T(v[0][0])} ${T(v[0][1])} m ${T(v[1][0])} ${T(v[1][1])} l ${T(v[2][0])} ${T(v[2][1])} l ${T(v[3][0])} ${T(v[3][1])} l h`,
          );
        }
        return (P.length && P.push(/\*/.test(e.op) ? "f*" : "f"), P);
      },
      D = () => {
        const x = [];
        for (const v of y) {
          for (let R = 0; R + 1 < v.pts.length; R++)
            x.push([v.pts[R], v.pts[R + 1]]);
          (v.closed || /^(s|b|b\*)$/.test(e.op)) &&
            v.pts.length > 2 &&
            x.push([v.pts[v.pts.length - 1], v.pts[0]]);
        }
        let P = x;
        for (const v of f) {
          const R = (i.lw * ot(i.ctm)) / 2 + 0.02,
            N = { x0: v.x0 - R, y0: v.y0 - R, x1: v.x1 + R, y1: v.y1 + R };
          P = P.flatMap((z) => Kt(z, N));
        }
        const C = [];
        for (const [v, R] of P) {
          const N = w(v[0], v[1]),
            z = w(R[0], R[1]);
          C.push(`${T(N[0])} ${T(N[1])} m ${T(z[0])} ${T(z[1])} l`);
        }
        return (C.length && C.push("S"), C);
      };
    if (
      l !== "stroke" &&
      k &&
      st(i.ctm) &&
      (!/\*/.test(e.op) || y.length === 1)
    )
      return (
        this.stats.paths++,
        (this.changed = !0),
        r(!1, [...O(), ...(l === "both" ? D() : [])])
      );
    if (l === "stroke" && b)
      return (this.stats.paths++, (this.changed = !0), r(!1, D()));
    throw new B("a curved or filled-and-stroked drawing is partly under a box");
  }
  async doXObject(t, e) {
    const o = e.args[0] && e.args[0].t === "name" ? e.args[0].v : "",
      s = this.res.lookupXObject(o);
    if (!(s instanceof J)) return this.emitOp(t, e);
    const i = W(s.dict.lookup(u.of("Subtype"))),
      c = this.gs;
    if (i === "Image") {
      const r = j([this.pt(0, 0), this.pt(1, 0), this.pt(0, 1), this.pt(1, 1)]);
      if (!this.hits(r).length) return this.emitOp(t, e);
      const m = await this.blankImage(s, c.ctm),
        l = this.res.addXObject("FdpImg", m, o);
      return ((this.changed = !0), this.stats.images++, this.emit(`/${l} Do`));
    }
    if (i === "Form") {
      if (this.depth >= 8 || this.seen.has(s))
        throw new B("forms nested too deeply");
      const r = s.dict.lookup(u.of("Matrix")),
        m =
          r instanceof F && r.size() === 6
            ? [0, 1, 2, 3, 4, 5].map((D) => A(r.lookup(D)))
            : G,
        l = I(m, c.ctm),
        p = s.dict.lookup(u.of("BBox"));
      if (p instanceof F && p.size() === 4) {
        const D = [0, 1, 2, 3].map((P) => A(p.lookup(P))),
          x = j([
            $(l, D[0], D[1]),
            $(l, D[2], D[1]),
            $(l, D[0], D[3]),
            $(l, D[2], D[3]),
          ]);
        if (!this.hits(x).length) return this.emitOp(t, e);
      }
      const h = new TextDecoder("latin1").decode(V(s)),
        d = s.dict.lookupMaybe(u.of("Resources"), S);
      let a = null;
      const f = new xt(d ?? this.res.dict, this.ctx, (D) => {
        a = D;
      });
      d || (this.res.shared = !0);
      const g = new Set(this.seen);
      g.add(s);
      const M = await new nt(
        this.ctx,
        this.boxes,
        f,
        l,
        this.stats,
        this.depth + 1,
        g,
      ).run(h);
      if (M === null) return this.emitOp(t, e);
      const k = {};
      for (const [D, x] of s.dict.entries()) {
        const P = D.decodeText();
        [
          "Length",
          "Filter",
          "DecodeParms",
          "F",
          "FFilter",
          "FDecodeParms",
        ].includes(P) || (k[P] = x);
      }
      const b = a ?? (d ? void 0 : this.res.dict);
      b && (k.Resources = b);
      const w = X(this.ctx, k, gt(M)),
        O = this.res.addXObject("FdpForm", w, o);
      return ((this.changed = !0), this.emit(`/${O} Do`));
    }
    return this.emitOp(t, e);
  }
  async blankImage(t, e) {
    const o = t.dict,
      s = A(o.lookup(u.of("Width"))),
      i = A(o.lookup(u.of("Height")));
    if (!s || !i || s * i > 12e7) throw new B("picture too large to edit");
    const c =
        o.lookup(u.of("ImageMask")) instanceof Pt &&
        o.lookup(u.of("ImageMask")).asBoolean(),
      r = A(o.lookup(u.of("BitsPerComponent")), c ? 1 : 8),
      m = (k) => {
        const b = {};
        for (const [w, O] of o.entries()) {
          const D = w.decodeText();
          k.includes(D) || (b[D] = O);
        }
        return b;
      },
      l = rt(e, s, i, this.boxes);
    if (!l) throw new B("picture overlap could not be mapped");
    if (c) {
      let k;
      try {
        k = V(t);
      } catch {
        throw new B("stencil mask cannot be decoded");
      }
      const b = Math.ceil(s / 8),
        w = o.lookup(u.of("Decode")),
        D = w instanceof F && A(w.lookup(0)) === 1 ? 0 : 1,
        x = Uint8Array.from(k.subarray(0, b * i));
      for (let P = 0; P < i; P++)
        for (let C = 0; C < s; C++) {
          if (!l[P * s + C]) continue;
          const v = P * b + (C >> 3),
            R = 7 - (C & 7);
          x[v] = D ? x[v] | (1 << R) : x[v] & ~(1 << R);
        }
      return X(this.ctx, m(["Length", "Filter", "DecodeParms", "DP", "F"]), x);
    }
    const p = Q(this.ctx, o.get(u.of("ColorSpace")));
    if (!p) throw new B("picture colour space is not supported for editing");
    if (!Xt(o.lookup(u.of("Decode")), p.indexed ? 1 : p.comps) && !p.indexed)
      throw new B("picture uses a custom decode array");
    const h = await ct(this.ctx, t, p, s, i, r);
    if (!h) throw new B("picture format cannot be edited exactly");
    for (let k = 0; k < s * i; k++)
      if (l[k])
        for (let b = 0; b < h.comps; b++) h.data[k * h.comps + b] = p.black[b];
    const d = dt(o),
      a = pt(d) === "jpeg",
      f = [
        "Length",
        "Filter",
        "DecodeParms",
        "DP",
        "F",
        "BitsPerComponent",
        "SMask",
        "Mask",
        "Metadata",
      ];
    p.indexed && f.push("ColorSpace");
    const g = m(f);
    (p.indexed && (g.ColorSpace = u.of("DeviceRGB")),
      (g.BitsPerComponent = U.of(8)));
    const y = o.lookup(u.of("SMask"));
    if (y instanceof K) {
      const k = await this.blankSoftMask(y, e);
      g.SMask = k;
    }
    const M = o.lookup(u.of("Mask"));
    if (M instanceof K) throw new B("picture with an explicit stencil mask");
    if ((M instanceof F && (g.Mask = M), a)) {
      const k = await mt().encodeJpeg(h.data, s, i, h.comps, 90);
      if (k) return X(this.ctx, { ...g, Filter: u.of("DCTDecode") }, k, !1);
    }
    return X(this.ctx, g, h.data);
  }
  async blankSoftMask(t, e) {
    const o = t.dict,
      s = A(o.lookup(u.of("Width"))),
      i = A(o.lookup(u.of("Height"))),
      c = A(o.lookup(u.of("BitsPerComponent")), 8),
      r = Q(this.ctx, o.get(u.of("ColorSpace")));
    if (!r || r.comps !== 1 || r.indexed)
      throw new B("soft mask is not a plain grey image");
    const m = await ct(this.ctx, t, r, s, i, c);
    if (!m) throw new B("soft mask cannot be decoded");
    const l = rt(e, s, i, this.boxes);
    if (l) for (let h = 0; h < s * i; h++) l[h] && (m.data[h] = 255);
    const p = {};
    for (const [h, d] of o.entries()) {
      const a = h.decodeText();
      [
        "Length",
        "Filter",
        "DecodeParms",
        "DP",
        "F",
        "BitsPerComponent",
        "SMask",
        "Matte",
      ].includes(a) || (p[a] = d);
    }
    return (
      (p.BitsPerComponent = U.of(8)),
      (p.ColorSpace = u.of("DeviceGray")),
      X(this.ctx, p, m.data)
    );
  }
}
function Vt(n) {
  const t = [];
  let e = null;
  for (const o of n)
    o.kind === "re"
      ? (t.push({ pts: o.pts, closed: !0, curve: !1, isRe: !0 }), (e = null))
      : o.kind === "m"
        ? ((e = { pts: [o.pts[0]], closed: !1, curve: !1, isRe: !1 }),
          t.push(e))
        : o.kind === "l"
          ? (e ||
              ((e = { pts: [], closed: !1, curve: !1, isRe: !1 }), t.push(e)),
            e.pts.push(o.pts[0]))
          : o.kind === "c"
            ? (e ||
                ((e = { pts: [], closed: !1, curve: !0, isRe: !1 }), t.push(e)),
              (e.curve = !0),
              e.pts.push(...o.pts))
            : o.kind === "h" && e && (e.closed = !0);
  return t;
}
function Ht(n) {
  if (n.curve) return null;
  let t = n.pts;
  if (n.isRe) return j(t);
  if (
    (t.length === 5 &&
      Math.abs(t[4][0] - t[0][0]) < 1e-6 &&
      Math.abs(t[4][1] - t[0][1]) < 1e-6 &&
      (t = t.slice(0, 4)),
    t.length !== 4)
  )
    return null;
  for (let e = 0; e < 4; e++) {
    const o = t[e],
      s = t[(e + 1) % 4];
    if (Math.abs(o[0] - s[0]) > 1e-6 && Math.abs(o[1] - s[1]) > 1e-6)
      return null;
  }
  return j(t);
}
function Lt(n, t) {
  if (!H(n, t)) return [n];
  const e = [],
    o = Math.max(n.x0, t.x0),
    s = Math.min(n.x1, t.x1);
  (n.y0 < t.y0 && e.push({ x0: n.x0, x1: n.x1, y0: n.y0, y1: t.y0 }),
    n.y1 > t.y1 && e.push({ x0: n.x0, x1: n.x1, y0: t.y1, y1: n.y1 }));
  const i = Math.max(n.y0, t.y0),
    c = Math.min(n.y1, t.y1);
  return (
    n.x0 < o && e.push({ x0: n.x0, x1: o, y0: i, y1: c }),
    n.x1 > s && e.push({ x0: s, x1: n.x1, y0: i, y1: c }),
    e.filter((r) => r.x1 - r.x0 > 1e-6 && r.y1 - r.y0 > 1e-6)
  );
}
function Kt(n, t) {
  const [e, o] = n,
    s = o[0] - e[0],
    i = o[1] - e[1];
  let c = 0,
    r = 1;
  const m = [-s, s, -i, i],
    l = [e[0] - t.x0, t.x1 - e[0], e[1] - t.y0, t.y1 - e[1]];
  for (let d = 0; d < 4; d++) {
    if (m[d] === 0) {
      if (l[d] <= 0) return [n];
      continue;
    }
    const a = l[d] / m[d];
    if (m[d] < 0) {
      if (a > r) return [n];
      a > c && (c = a);
    } else {
      if (a < c) return [n];
      a < r && (r = a);
    }
  }
  if (c >= r) return [n];
  const p = (d) => [e[0] + s * d, e[1] + i * d],
    h = [];
  return (c > 1e-9 && h.push([e, p(c)]), r < 1 - 1e-9 && h.push([p(r), o]), h);
}
function Jt(n) {
  n.doc.context;
  const t = n.node.lookup(u.of("Contents")),
    e =
      t instanceof F
        ? Array.from({ length: t.size() }, (i, c) => t.lookup(c))
        : [t],
    o = new TextDecoder("latin1"),
    s = [];
  for (const i of e)
    i instanceof K
      ? s.push(o.decode(V(i)))
      : i instanceof J && s.push(o.decode(i.getContents()));
  return s.join(`
`);
}
function _t(n) {
  let t = n.node;
  for (let e = 0; e < 32 && t; e++) {
    const o = t.lookupMaybe(u.of("Resources"), S);
    if (o) return o;
    t = t.lookupMaybe(u.of("Parent"), S);
  }
}
async function Zt(n, t, e, o) {
  const s = n.context;
  if (!t.node.has(u.of("Contents"))) {
    ft(n, t, null, e);
    return;
  }
  const i = Jt(t),
    c = _t(t) ?? s.obj({}),
    r = new xt(c, s, (h) => t.node.set(u.of("Resources"), h)),
    l = await new nt(s, e, r, G, o, 0, new Set()).run(i);
  ft(n, t, l, e, i);
  const p = t.node.lookupMaybe(u.of("Annots"), F);
  if (p) {
    const h = [],
      d = new Set();
    for (let f = 0; f < p.size(); f++) {
      const g = p.get(f),
        y = s.lookupMaybe(g, S);
      if (!y) {
        h.push(g);
        continue;
      }
      const M = y.lookup(u.of("Rect"));
      let k = !1;
      if (M instanceof F && M.size() === 4) {
        const w = [0, 1, 2, 3].map((D) => A(M.lookup(D))),
          O = {
            x0: Math.min(w[0], w[2]),
            x1: Math.max(w[0], w[2]),
            y0: Math.min(w[1], w[3]),
            y1: Math.max(w[1], w[3]),
          };
        k = e.some((D) => H(O, D));
      }
      const b = y.get(u.of("Parent"));
      if (
        (!k &&
          W(y.lookup(u.of("Subtype"))) === "Popup" &&
          b &&
          d.has(b) &&
          (k = !0),
        k)
      ) {
        (o.annotations++,
          d.add(g),
          W(y.lookup(u.of("Subtype"))) === "Widget" && Qt(n, g, y));
        const w = y.get(u.of("Popup"));
        w && d.add(w);
      } else h.push(g);
    }
    const a = h.filter((f) => {
      const g = s.lookupMaybe(f, S);
      return !(
        g &&
        W(g.lookup(u.of("Subtype"))) === "Popup" &&
        g.get(u.of("Parent")) &&
        d.has(g.get(u.of("Parent")))
      );
    });
    a.length !== p.size() && t.node.set(u.of("Annots"), s.obj(a));
  }
  for (const h of ["Thumb", "PieceInfo", "Metadata"]) t.node.delete(u.of(h));
}
function Qt(n, t, e) {
  const o = n.context,
    s = n.catalog.lookupMaybe(u.of("AcroForm"), S);
  for (const m of ["V", "DV", "AP", "RV", "Contents"]) e.delete(u.of(m));
  let i = t,
    c = e;
  for (let m = 0; m < 16 && c; m++) {
    const l = c.get(u.of("Parent")),
      h = (l ? o.lookupMaybe(l, S) : void 0) ?? null,
      d = h?.lookupMaybe(u.of("Kids"), F);
    if (h && d) {
      for (const f of ["V", "DV", "RV"]) h.delete(u.of(f));
      const a = [];
      for (let f = 0; f < d.size(); f++) d.get(f) !== i && a.push(d.get(f));
      if ((h.set(u.of("Kids"), o.obj(a)), a.length)) return;
      ((i = l), (c = h));
      continue;
    }
    break;
  }
  const r = s?.lookupMaybe(u.of("Fields"), F);
  if (r) {
    const m = [];
    for (let l = 0; l < r.size(); l++) r.get(l) !== i && m.push(r.get(l));
    s.set(u.of("Fields"), o.obj(m));
  }
}
function ft(n, t, e, o, s) {
  const i = n.context,
    c = o.map(
      (l) => `${T(l.x0)} ${T(l.y0)} ${T(l.x1 - l.x0)} ${T(l.y1 - l.y0)} re`,
    ).join(`
`),
    r = `q
${e ?? s ?? ""}
Q
q
0 0 0 rg
${c}
f
Q
`,
    m = X(i, {}, gt(r));
  t.node.set(u.of("Contents"), m);
}
function Y(n) {
  const t = n.context,
    e = new Set(),
    o = [],
    s = (r) => {
      r && o.push(r);
    },
    i = t.trailerInfo;
  for (s(i.Root), s(i.Info), s(i.Encrypt); o.length;) {
    const r = o.pop();
    if (r instanceof L) {
      const m = r.toString();
      if (e.has(m)) continue;
      (e.add(m), s(t.lookup(r)));
    } else if (r instanceof S) for (const [, m] of r.entries()) s(m);
    else if (r instanceof F) for (let m = 0; m < r.size(); m++) s(r.get(m));
    else r instanceof J && s(r.dict);
  }
  let c = 0;
  for (const [r] of t.enumerateIndirectObjects())
    e.has(r.toString()) || (t.delete(r), c++);
  return c;
}
function Yt(n, t) {
  const e = n.context,
    o = n.catalog.lookupMaybe(u.of("StructTreeRoot"), S);
  if (!o) return;
  const s = new Set(),
    i = (c, r, m) => {
      if (!c || m > 200) return;
      const l = c instanceof L ? e.lookup(c) : c;
      if (l instanceof F) {
        for (let f = 0; f < l.size(); f++) i(l.get(f), r, m + 1);
        return;
      }
      if (!(l instanceof S) || s.has(l)) return;
      s.add(l);
      const p = l.get(u.of("Pg")),
        d = (p instanceof L ? t.has(p.toString()) : !1) || (r && !p);
      if (d) for (const f of ["ActualText", "Alt", "E", "T"]) l.delete(u.of(f));
      const a = l.get(u.of("K"));
      i(a, d, m + 1);
    };
  i(o.get(u.of("K")), !1, 0);
}
async function te(n, t, e, o, s) {
  const i = await n.embedJpg(e),
    c = t.node;
  for (const l of [
    "CropBox",
    "TrimBox",
    "BleedBox",
    "ArtBox",
    "Rotate",
    "Annots",
    "Thumb",
    "PieceInfo",
    "Metadata",
    "Group",
    "B",
    "Dur",
    "Trans",
    "AA",
  ])
    c.delete(u.of(l));
  c.set(u.of("MediaBox"), n.context.obj([0, 0, o, s]));
  const r = "FdpPage";
  c.set(u.of("Resources"), n.context.obj({ XObject: { [r]: i.ref } }));
  const m = n.context.flateStream(`q ${o} 0 0 ${s} 0 0 cm /${r} Do Q`);
  c.set(u.of("Contents"), n.context.register(m));
}
async function ee(n, t, e, o) {
  const s = { glyphs: 0, images: 0, paths: 0, annotations: 0 },
    i = [],
    c = [],
    r = [],
    m = {},
    l = n.getPages(),
    p = new Set(),
    h = Object.keys(e)
      .map(Number)
      .filter((a) => a >= 0 && a < l.length && e[a]?.length)
      .sort((a, f) => a - f);
  let d = 0;
  for (const a of h) {
    const f = e[a],
      g = l[a],
      y = await t.getPage(a + 1),
      M = y.getViewport({ scale: 1 }),
      k = f.map((O) => {
        const [D, x] = M.convertToPdfPoint(O.x * M.width, O.y * M.height),
          [P, C] = M.convertToPdfPoint(
            (O.x + O.w) * M.width,
            (O.y + O.h) * M.height,
          );
        return {
          x0: Math.min(D, P),
          x1: Math.max(D, P),
          y0: Math.min(x, C),
          y1: Math.max(x, C),
        };
      });
    p.add(g.ref.toString());
    let b = o.forceRaster ? "a picture of the page was requested" : "";
    const w = { glyphs: 0, images: 0, paths: 0, annotations: 0 };
    if (!o.forceRaster)
      try {
        await Zt(n, g, k, w);
      } catch (O) {
        if (!(O instanceof B)) throw O;
        b = O.reason;
      }
    if (b) {
      const O = await o.rasterize(y, f);
      (await te(n, g, O.jpeg, O.width, O.height),
        O.emptyBoxes && (m[a + 1] = O.emptyBoxes),
        i.push(a + 1),
        c.push(`Page ${a + 1}: ${b}.`),
        r.push({
          page: a + 1,
          how: "picture",
          reason: b,
          removed: { glyphs: 0, images: 0, paths: 0, annotations: 0 },
        }));
    } else {
      for (const O of Object.keys(w)) s[O] += w[O];
      r.push({ page: a + 1, how: "edited", removed: w });
    }
    o.onProgress?.(++d, h.length);
  }
  return (
    Yt(n, p),
    Y(n),
    { pages: r, rasterizedPages: i, reasons: c, removed: s, emptyBoxes: m }
  );
}
function tt(n, t) {
  const e = document.createElement("canvas");
  return ((e.width = n), (e.height = t), e);
}
let q = null;
function lt() {
  if (q !== null) return q;
  try {
    const n = tt(4, 4).getContext("2d", { willReadFrequently: !0 });
    if (!n) return (q = !1);
    ((n.fillStyle = "rgb(13,77,201)"), n.fillRect(0, 0, 4, 4));
    const t = n.getImageData(0, 0, 4, 4).data;
    q = !0;
    for (let e = 0; e < t.length; e += 4)
      (t[e] !== 13 ||
        t[e + 1] !== 77 ||
        t[e + 2] !== 201 ||
        t[e + 3] !== 255) &&
        (q = !1);
  } catch {
    q = !1;
  }
  return q;
}
const ne = {
  async decodeJpeg(n, t, e, o) {
    if ((o !== 1 && o !== 3) || !lt()) return null;
    let s = null;
    try {
      if (
        ((s = await createImageBitmap(
          new Blob([new Uint8Array(n)], { type: "image/jpeg" }),
          { colorSpaceConversion: "none", imageOrientation: "none" },
        )),
        s.width !== t || s.height !== e)
      )
        return null;
      const i = tt(t, e).getContext("2d", { willReadFrequently: !0 });
      if (!i) return null;
      i.drawImage(s, 0, 0);
      const c = i.getImageData(0, 0, t, e).data,
        r = new Uint8Array(t * e * o);
      for (let m = 0, l = 0; m < c.length; m += 4)
        ((r[l++] = c[m]),
          o === 3 && ((r[l++] = c[m + 1]), (r[l++] = c[m + 2])));
      return r;
    } catch {
      return null;
    } finally {
      s?.close();
    }
  },
  async encodeJpeg(n, t, e, o, s) {
    if (o !== 3 || !lt()) return null;
    try {
      const i = tt(t, e),
        c = i.getContext("2d");
      if (!c) return null;
      const r = c.createImageData(t, e);
      for (let l = 0, p = 0; l < n.length; l += 3, p += 4)
        ((r.data[p] = n[l]),
          (r.data[p + 1] = n[l + 1]),
          (r.data[p + 2] = n[l + 2]),
          (r.data[p + 3] = 255));
      c.putImageData(r, 0, 0);
      const m = await new Promise((l) => i.toBlob(l, "image/jpeg", s / 100));
      return m ? new Uint8Array(await m.arrayBuffer()) : null;
    } catch {
      return null;
    }
  },
};
jt(ne);
function wt(n, t = 0) {
  if (!n || t > 20) return 0;
  let e = 0;
  const o = n.lookupMaybe(u.of("Names"), F);
  o && (e += Math.floor(o.size() / 2));
  const s = n.lookupMaybe(u.of("Kids"), F);
  if (s) for (let i = 0; i < s.size(); i++) e += wt(s.lookupMaybe(i, S), t + 1);
  return e;
}
function oe(n) {
  const t = n.context.lookupMaybe(n.context.trailerInfo.Info, S),
    e = t ? t.keys().filter((p) => p.decodeText() !== "Producer").length : 0,
    o = !!n.catalog.get(u.of("Metadata")),
    s = (p) => p.reduce((h, d) => h + 1 + s(d.children), 0),
    i = s(ut(n)),
    c = n.catalog.lookupMaybe(u.of("Names"), S);
  let r = wt(c?.lookupMaybe(u.of("EmbeddedFiles"), S)),
    m = 0,
    l = 0;
  for (const p of n.getPages()) {
    const h = p.node.lookupMaybe(u.of("Annots"), F);
    if (h)
      for (let d = 0; d < h.size(); d++) {
        const a = h.lookupMaybe(d, S);
        if (!a) continue;
        const f = a.get(u.of("Subtype"))?.toString();
        f === "/Widget"
          ? bt(a) && l++
          : f !== "/Link" && (m++, f === "/FileAttachment" && r++);
      }
  }
  return {
    properties: e,
    xmp: o,
    bookmarks: i,
    attachments: r,
    comments: m,
    filledFormFields: l,
  };
}
const se = 4200;
async function ie(n, t) {
  const e = n.getViewport({ scale: 1 }),
    o = Math.max(0.5, Math.min(3, se / Math.max(e.width, e.height))),
    s = n.getViewport({ scale: o }),
    i = document.createElement("canvas");
  ((i.width = Math.round(s.width)), (i.height = Math.round(s.height)));
  const c = i.getContext("2d");
  ((c.fillStyle = "#fff"),
    c.fillRect(0, 0, i.width, i.height),
    await n.render({
      canvasContext: c,
      viewport: s,
      canvas: i,
      intent: "print",
    }).promise,
    (c.fillStyle = "#000000"));
  let r = 0;
  for (const l of t) {
    const p = Math.floor(l.x * i.width),
      h = Math.floor(l.y * i.height),
      d = Math.max(1, Math.ceil(l.w * i.width)),
      a = Math.max(1, Math.ceil(l.h * i.height));
    try {
      const f = c.getImageData(
        Math.max(0, p),
        Math.max(0, h),
        Math.max(1, Math.min(d, i.width - p)),
        Math.max(1, Math.min(a, i.height - h)),
      ).data;
      let g = !1;
      for (let y = 0; y < f.length; y += 16)
        if (f[y] < 245 || f[y + 1] < 245 || f[y + 2] < 245) {
          g = !0;
          break;
        }
      g || r++;
    } catch {}
    c.fillRect(p, h, d, a);
  }
  const m = await new Promise((l, p) =>
    i.toBlob(
      (h) => (h ? l(h) : p(new Error("Couldn't render this page"))),
      "image/jpeg",
      0.92,
    ),
  );
  return {
    jpeg: new Uint8Array(await m.arrayBuffer()),
    width: e.width,
    height: e.height,
    emptyBoxes: r,
  };
}
const et = (n) => (n instanceof Ot || n instanceof St ? n.decodeText() : "");
function bt(n) {
  let t = n;
  for (let e = 0; e < 16 && t; e++) {
    const o = t.lookup(u.of("V"));
    if (o) return et(o) || (o instanceof u ? o.decodeText() : "");
    t = t.lookupMaybe(u.of("Parent"), S);
  }
  return "";
}
function ae(n, t, e) {
  const o = { comments: 0, links: 0, fields: 0 },
    s = (i) => !!i && e.length > 0 && ht(i, e).length > 0;
  for (const i of t) {
    const c = i.node.lookupMaybe(u.of("Annots"), F);
    if (!c) continue;
    const r = [];
    for (let m = 0; m < c.size(); m++) {
      const l = c.get(m),
        p = n.context.lookupMaybe(l, S);
      if (!p) {
        r.push(l);
        continue;
      }
      const h = p.get(u.of("Subtype"))?.toString();
      if (h === "/Widget") {
        if (s(bt(p))) {
          let d = p;
          for (let a = 0; a < 16 && d; a++) {
            for (const f of ["V", "DV", "AP", "RV"]) d.delete(u.of(f));
            d = d.lookupMaybe(u.of("Parent"), S);
          }
          o.fields++;
          continue;
        }
      } else if (h === "/Link") {
        const d = p.lookupMaybe(u.of("A"), S),
          a = d ? et(d.lookup(u.of("URI"))) : "";
        if (s(a) || s(et(p.lookup(u.of("Contents"))))) {
          o.links++;
          continue;
        }
      } else {
        o.comments++;
        continue;
      }
      r.push(l);
    }
    r.length !== c.size() && i.node.set(u.of("Annots"), n.context.obj(r));
  }
  return o;
}
function Mt(n, t, e) {
  const o = [];
  for (const s of n) {
    if (t.length && ht(s.title, t).length > 0) {
      e.n++;
      continue;
    }
    o.push({ ...s, children: Mt(s.children, t, e) });
  }
  return o;
}
async function re(n, t, e, o, s = {}) {
  const i = s.removeHidden ?? !0,
    c = s.query ? $t(s.query, s.searchOptions) : [],
    r = await Ct.load(n),
    m = await e.openPdfjs(n),
    l = await ee(r, m, t, { rasterize: e.rasterize, onProgress: o }),
    p = [];
  for (const a of l.pages)
    if (a.how === "edited") {
      const f = a.removed;
      f.glyphs + f.images + f.paths + f.annotations === 0 &&
        p.push(
          `Page ${a.page}: nothing was found under the marked area${(t[a.page - 1]?.length ?? 0) === 1 ? "" : "s"} — check ${(t[a.page - 1]?.length ?? 0) === 1 ? "its" : "their"} position. A black bar was still drawn.`,
        );
    } else {
      p.push(
        `Page ${a.page} became a picture: ${a.reason}. Its text can no longer be selected or searched.`,
      );
      const f = l.emptyBoxes[a.page];
      f &&
        p.push(
          `Page ${a.page}: ${f} marked area${f === 1 ? " is" : "s are"} empty — check ${f === 1 ? "its" : "their"} position.`,
        );
    }
  const h = { comments: 0, links: 0, fields: 0, bookmarks: 0 };
  if (i) {
    Object.assign(h, ae(r, r.getPages(), c));
    const a = ut(r),
      f = { n: 0 },
      g = Mt(Bt(a, r.getPages()), c, f);
    ((h.bookmarks = f.n),
      f.n > 0 && (r.catalog.delete(u.of("Outlines")), Tt(r, g)),
      Y(r));
  }
  if (s.scrubMetadata) {
    const a = r.context.lookupMaybe(r.context.trailerInfo.Info, S);
    if (a) for (const f of a.keys()) a.delete(f);
    (r.catalog.delete(u.of("Metadata")), Y(r));
  }
  r.setProducer("FreeDailyPro");
  const d = oe(r);
  return {
    blob: Ft(await r.save()),
    warnings: p,
    removed: h,
    content: l.removed,
    pages: l.pages,
    inspection: d,
    mode: l.rasterizedPages.length ? "rasterized-pages" : "text-removed",
    rasterizedPages: l.rasterizedPages,
    reasons: l.reasons,
  };
}
async function ye(n, t, e, o, s = {}) {
  const i = typeof s == "boolean" ? { scrubMetadata: s } : s,
    c = new Uint8Array(await n.arrayBuffer());
  return re(c, e, { openPdfjs: () => At(n), rasterize: ie }, o, i);
}
export {
  oe as inspectOutput,
  ie as rasterizeInBrowser,
  re as redactPdfBytes,
  ye as redactPdfPages,
  ae as stripHiddenAnnotations,
};
//# sourceMappingURL=redactApply-BSsjW140.js.map
