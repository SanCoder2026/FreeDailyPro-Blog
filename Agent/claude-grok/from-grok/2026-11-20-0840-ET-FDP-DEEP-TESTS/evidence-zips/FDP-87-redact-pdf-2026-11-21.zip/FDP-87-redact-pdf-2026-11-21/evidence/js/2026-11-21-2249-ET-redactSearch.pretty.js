import { l as K, U as Z } from "./utils-s8ucLyj8.js";
import { N as Y } from "./nameDetect-DvHCRM0m.js";
const I = 100,
  U = 60,
  $ = 5,
  J = 200,
  R = 100,
  Q = 3e3,
  j = 3e7;
class f extends Error {
  constructor(s) {
    (super(s), (this.name = "PatternError"));
  }
}
class O extends f {
  constructor() {
    (super(
      "This pattern is too complex to run on this page. Make it more specific (fewer wildcards and repeats) and try again.",
    ),
      (this.name = "PatternBudgetError"));
  }
}
const _ = (e) => e >= 48 && e <= 57,
  L = (e) => _(e) || (e >= 65 && e <= 90) || (e >= 97 && e <= 122) || e === 95,
  D = (e) =>
    e === 32 ||
    (e >= 9 && e <= 13) ||
    e === 160 ||
    e === 65279 ||
    (e >= 8192 && e <= 8202) ||
    e === 8232 ||
    e === 8233 ||
    e === 8239 ||
    e === 8287 ||
    e === 12288 ||
    e === 5760,
  N = (e) => (s) => !e(s),
  tt = /[pPkuxcB0-9]/;
class et {
  constructor(s) {
    ((this.p = 0), (this.cs = Array.from(s)));
  }
  parse() {
    const s = this.alt();
    if (this.p < this.cs.length)
      throw new f(
        "There is a closing bracket ) with no opening bracket before it.",
      );
    return s;
  }
  alt() {
    const s = [this.cat()];
    for (; this.cs[this.p] === "|";) (this.p++, s.push(this.cat()));
    return s.length === 1 ? s[0] : { t: "alt", items: s };
  }
  cat() {
    const s = [];
    for (
      ;
      this.p < this.cs.length &&
      this.cs[this.p] !== "|" &&
      this.cs[this.p] !== ")";
    )
      s.push(this.quantified());
    return { t: "cat", items: s };
  }
  quantified() {
    const s = this.atom(),
      t = this.cs[this.p];
    let n = -1,
      r = -1;
    if (t === "*") ((n = 0), (r = 1 / 0), this.p++);
    else if (t === "+") ((n = 1), (r = 1 / 0), this.p++);
    else if (t === "?") ((n = 0), (r = 1), this.p++);
    else if (t === "{") {
      const i = /^\{(\d+)(?:(,)(\d*))?\}/.exec(
        this.cs.slice(this.p, this.p + 16).join(""),
      );
      if (i) {
        if (
          ((n = Number(i[1])),
          (r = i[2] ? (i[3] === "" ? 1 / 0 : Number(i[3])) : n),
          n > R || (r !== 1 / 0 && r > R))
        )
          throw new f(`A repeat count can be at most ${R}.`);
        if (r < n)
          throw new f(
            "In a repeat like {2,5} the first number must not be larger than the second.",
          );
        this.p += i[0].length;
      }
    }
    if (n < 0) return s;
    if (s.t === "assert") throw new f("A word edge (\\b) can't be repeated.");
    const o = this.cs[this.p];
    if (o === "?" || o === "+")
      throw new f(
        "Lazy and possessive repeats aren't supported. The longest match is always used, so remove the extra ? or +.",
      );
    return { t: "rep", node: s, min: n, max: r };
  }
  atom() {
    const s = this.cs[this.p++];
    switch (s) {
      case "(": {
        if (this.cs[this.p] === "?")
          if (this.cs[this.p + 1] === ":") this.p += 2;
          else
            throw new f(
              "Lookahead, lookbehind and named groups aren't supported. Use a plain group ( ) or (?: ).",
            );
        const t = this.alt();
        if (this.cs[this.p] !== ")")
          throw new f("A bracket ( is never closed.");
        return (this.p++, t);
      }
      case "[":
        return this.charClass();
      case ".":
        return {
          t: "set",
          test: (t) => t !== 10 && t !== 13 && t !== 8232 && t !== 8233,
        };
      case "^":
      case "$":
        throw new f(
          "^ and $ aren't supported: the pattern is looked for anywhere in the page text. Use \\b for a word edge.",
        );
      case "*":
      case "+":
      case "?":
        throw new f(`"${s}" has nothing before it to repeat.`);
      case "\\":
        return this.escape(!1);
      default:
        return B(s);
    }
  }
  escape(s) {
    const t = this.cs[this.p++];
    if (t === void 0) throw new f("The pattern ends with a lone backslash.");
    const n = (r) => (s ? r : { t: "set", test: r });
    switch (t) {
      case "d":
        return n(_);
      case "D":
        return n(N(_));
      case "w":
        return n(L);
      case "W":
        return n(N(L));
      case "s":
        return n(D);
      case "S":
        return n(N(D));
      case "n":
        return n((r) => r === 10);
      case "t":
        return n((r) => r === 9);
      case "b":
      case "B":
        if (s) throw new f("\\b isn't allowed inside [ ].");
        return { t: "assert", word: t === "b" };
    }
    if (/[0-9]/.test(t))
      throw new f("Back-references like \\1 aren't supported.");
    if (tt.test(t))
      throw new f(
        `\\${t} isn't supported. Use \\d, \\w, \\s, a [class] or the plain character.`,
      );
    return s ? (r) => r === t.codePointAt(0) : B(t);
  }
  charClass() {
    let s = !1;
    this.cs[this.p] === "^" && ((s = !0), this.p++);
    const t = [];
    let n = !0;
    for (;;) {
      const o = this.cs[this.p++];
      if (o === void 0) throw new f("A [ is never closed with ].");
      if (o === "]" && !n) break;
      n = !1;
      let i = null;
      if (o === "\\") {
        const c = this.escape(!0),
          a = this.cs[this.p - 1];
        if (/[dDwWsSnt]/.test(a) && this.cs[this.p - 2] === "\\") {
          t.push(c);
          continue;
        }
        i = a.codePointAt(0);
      } else i = o.codePointAt(0);
      if (
        this.cs[this.p] === "-" &&
        this.cs[this.p + 1] !== void 0 &&
        this.cs[this.p + 1] !== "]"
      ) {
        this.p++;
        let c = this.cs[this.p++];
        if (
          c === "\\" &&
          (this.escape(!0), (c = this.cs[this.p - 1]), /[dDwWsS]/.test(c))
        )
          throw new f("A range like a-\\d isn't valid.");
        const a = c.codePointAt(0);
        if (a < i)
          throw new f("A range in [ ] runs backwards (for example z-a).");
        const u = i;
        t.push((h) => h >= u && h <= a);
      } else {
        const c = i;
        t.push((a) => a === c);
      }
    }
    const r = (o) => t.some((i) => i(o));
    return { t: "set", test: s ? N(r) : r };
  }
}
function B(e) {
  const s = e.codePointAt(0);
  return { t: "set", test: (t) => t === s };
}
function st(e, s) {
  const t = [],
    n = (i) => {
      if (t.length >= Q)
        throw new f("This pattern is too large. Use fewer or smaller repeats.");
      return (t.push(i), t.length - 1);
    },
    r = (i) =>
      s
        ? (c) => {
            if (i(c)) return !0;
            if (c < 65536) {
              const a = String.fromCharCode(c),
                u = a.toLowerCase().charCodeAt(0),
                h = a.toUpperCase().charCodeAt(0);
              return i(u) || i(h);
            }
            return !1;
          }
        : i,
    o = (i) => {
      switch (i.t) {
        case "set":
          n({ op: "char", test: r(i.test) });
          return;
        case "cat":
          for (const c of i.items) o(c);
          return;
        case "assert":
          n({ op: "assert", word: i.word });
          return;
        case "alt": {
          const c = [];
          i.items.forEach((a, u) => {
            if (u < i.items.length - 1) {
              const h = n({ op: "split", a: 0, b: 0 });
              ((t[h].a = t.length),
                o(a),
                c.push(n({ op: "jmp", to: 0 })),
                (t[h].b = t.length));
            } else o(a);
          });
          for (const a of c) t[a].to = t.length;
          return;
        }
        case "rep": {
          for (let c = 0; c < i.min; c++) o(i.node);
          if (i.max === 1 / 0) {
            const c = n({ op: "split", a: 0, b: 0 });
            ((t[c].a = t.length),
              o(i.node),
              n({ op: "jmp", to: c }),
              (t[c].b = t.length));
          } else {
            const c = [];
            for (let a = i.min; a < i.max; a++) {
              const u = n({ op: "split", a: 0, b: 0 });
              ((t[u].a = t.length), c.push(u), o(i.node));
            }
            for (const a of c) t[a].b = t.length;
          }
          return;
        }
      }
    };
  return (o(e), n({ op: "match" }), t);
}
function nt(e, s) {
  const t = s.length,
    n = [],
    r = new Int32Array(e.length).fill(-1);
  let o = 0,
    i = 0;
  const c = (h) => h >= 0 && h < t && L(s.charCodeAt(h)),
    a = (h, x, A) => {
      const d = [x];
      for (; d.length;) {
        const b = d.pop();
        if (r[b] === o) continue;
        ((r[b] = o), i++);
        const m = e[b];
        m.op === "jmp"
          ? d.push(m.to)
          : m.op === "split"
            ? (d.push(m.b), d.push(m.a))
            : m.op === "assert"
              ? (c(A - 1) !== c(A)) === m.word && d.push(b + 1)
              : h.push(b);
      }
    };
  let u = 0;
  for (; u < t;) {
    let h = [];
    (o++, a(h, 0, u));
    let x = -1;
    const A = Math.min(t, u + J);
    for (
      let d = u;
      h.some((g) => e[g].op === "match") && (x = d),
        !(d >= A || h.length === 0);
      d++
    ) {
      const b = s.charCodeAt(d),
        m = [];
      o++;
      for (const g of h) {
        i++;
        const k = e[g];
        k.op === "char" && k.test(b) && a(m, g + 1, d + 1);
      }
      if (i > j) throw new O();
      h = m;
    }
    if (i > j) throw new O();
    x > u ? (n.push([u, x]), (u = x)) : u++;
  }
  return n;
}
function H(e, s = {}) {
  const t = e.trim();
  if (!t) throw new f("Type a pattern first.");
  if (Array.from(t).length > I)
    throw new f(`A pattern can be at most ${I} characters long.`);
  const n = st(new et(t).parse(), !!s.ignoreCase);
  return { safe: !0, findAll: (r) => nt(n, r) };
}
function V(e) {
  const s = [];
  let t = !1;
  for (const n of Array.from(e.trim())) {
    if (/\s/.test(n)) {
      (t || s.push("\\s+"), (t = !0));
      continue;
    }
    ((t = !1),
      n === "#"
        ? s.push("\\d")
        : n === "@"
          ? s.push("[A-Za-z]")
          : n === "?"
            ? s.push("\\S")
            : n === "*"
              ? s.push("\\S*")
              : s.push(/[A-Za-z0-9]/.test(n) ? n : "\\" + n));
  }
  return s.join("");
}
function ot(e, s = {}) {
  const t = e.source.trim();
  if (!t) return null;
  if (e.mode === "wildcard" && Array.from(t).length > U)
    return `A simple pattern can be at most ${U} characters long.`;
  try {
    return (H(e.mode === "wildcard" ? V(t) : t, s), null);
  } catch (n) {
    return n instanceof f ? n.message : "This pattern can't be used.";
  }
}
function rt(e, s) {
  return e
    .split(/\r?\n/)
    .map((t) => t.trim())
    .filter(Boolean)
    .map((t) => ({ mode: s, source: t }));
}
function xt(e, s, t = {}) {
  const n = rt(e, s);
  if (n.length > $) return `Use at most ${$} patterns (one per line).`;
  for (let r = 0; r < n.length; r++) {
    const o = ot(n[r], t);
    if (o) return n.length > 1 ? `Pattern ${r + 1}: ${o}` : o;
  }
  return null;
}
function it(e, s = {}) {
  return e.map((t) => H(t.mode === "wildcard" ? V(t.source) : t.source, s));
}
const at = (e) => e.safe === !0,
  W = ["email", "phone", "card", "ssn", "ein", "name"];
function At(e) {
  return W.every((s) => e.includes(s)) ? [] : [...W];
}
const ct = {
    email: "[\\w.+-]+@[\\w-]+(?:\\.[\\w-]+)+",
    phone:
      "(?<![\\d])(?:\\+?\\d{1,3}[\\s.-]?)?(?:\\(\\d{3}\\)|\\d{3})[\\s.-]?\\d{3}[\\s.-]?\\d{4}(?![\\d])",
    card: "(?<![\\d])(?:\\d[ -]?){12,18}\\d(?![\\d])",
    ssn: "(?<![\\d])\\d{3}-\\d{2}-\\d{4}(?![\\d])",
    ein: "(?<![\\d-])\\d{2}-\\d{7}(?![\\d-])",
    name: Y,
  },
  ht = (e) => e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
function q(e, s = {}) {
  const t = "gu" + (s.matchCase ? "" : "i"),
    n = [];
  for (const r of e.split(/\r?\n/)) {
    const o = r.trim();
    if (!o) continue;
    let i = o.split(/\s+/).map(ht).join("\\s+");
    (s.wholeWord && (i = `(?<![\\p{L}\\p{N}_])${i}(?![\\p{L}\\p{N}_])`),
      n.push({ kind: "text", matcher: new RegExp(i, t) }));
  }
  for (const r of s.patterns ?? [])
    n.push({ kind: r, matcher: new RegExp(ct[r], "gu") });
  if (s.custom?.length)
    for (const r of it(s.custom, { ignoreCase: !s.matchCase }))
      n.push({ kind: "custom", matcher: r });
  return n;
}
function bt(e, s = {}) {
  return q(e, s).map((t) => t.matcher);
}
function lt(e, s) {
  if (at(s)) return s.findAll(e);
  const t = [];
  s.lastIndex = 0;
  let n;
  for (; (n = s.exec(e));) {
    if (n[0].length === 0) {
      s.lastIndex++;
      continue;
    }
    t.push([n.index, n.index + n[0].length]);
  }
  return t;
}
const X = [
    "custom",
    "ssn",
    "ein",
    "card",
    "email",
    "phone",
    "name",
    "text",
    "field",
  ],
  ut = (e, s) => (X.indexOf(e) <= X.indexOf(s) ? e : s);
function F(e, s) {
  const t = [];
  for (const r of s)
    for (const [o, i] of lt(e, r.matcher))
      t.push({ start: o, end: i, kind: r.kind });
  t.sort((r, o) => r.start - o.start);
  const n = [];
  for (const r of t) {
    const o = n[n.length - 1];
    o && r.start <= o.end
      ? ((o.end = Math.max(o.end, r.end)), (o.kind = ut(o.kind, r.kind)))
      : n.push({ ...r });
  }
  return n;
}
function z(e, s) {
  return F(
    e,
    s.map((t) => ({ kind: "text", matcher: t })),
  ).map((t) => [t.start, t.end]);
}
function ft(e) {
  let s = "";
  const t = [];
  return (
    e.forEach((n, r) => {
      for (let o = 0; o < n.str.length; o++)
        ((s += n.str[o]), t.push({ run: r, idx: o }));
      n.hasEOL && ((s += " "), t.push({ run: -1, idx: 0 }));
    }),
    { text: s, owner: t }
  );
}
function pt(e, s, t) {
  const n = [];
  for (let r = s; r < t; r++) {
    const o = e[r];
    if (!o || o.run < 0) continue;
    const i = n[n.length - 1];
    i && i.run === o.run && i.to === o.idx
      ? (i.to = o.idx + 1)
      : n.push({ run: o.run, from: o.idx, to: o.idx + 1 });
  }
  return n;
}
function dt(e, s, t) {
  const [n, r, o, i, c, a] = e.matrix,
    u = Math.hypot(n, r) || 1,
    h = Math.hypot(o, i) || 10,
    x = n / u,
    A = r / u,
    d = o / h,
    b = i / h,
    m = Math.max(1, e.str.length),
    g = e.width;
  let k = (g * s) / m,
    C = (g * t) / m;
  const M = e.measure ? e.measure(e.str) : 0;
  e.measure &&
    M > 0 &&
    ((k = (g * e.measure(e.str.slice(0, s))) / M),
    (C = (g * e.measure(e.str.slice(0, t))) / M));
  const l = Math.max(2, h * 0.1),
    p = -0.25 * h,
    S = 1.1 * h,
    T = [];
  for (const P of [k - l, C + l])
    for (const w of [p, S]) T.push([c + x * P + d * w, a + A * P + b * w]);
  const E = T.map((P) => P[0]),
    y = T.map((P) => P[1]);
  return {
    x0: Math.min(...E),
    y0: Math.min(...y),
    x1: Math.max(...E),
    y1: Math.max(...y),
  };
}
function G(e, s, t) {
  const n = Math.max(0, e.x0),
    r = Math.max(0, e.y0),
    o = Math.min(s, e.x1),
    i = Math.min(t, e.y1);
  return {
    x: n / s,
    y: r / t,
    w: Math.max(0, o - n) / s,
    h: Math.max(0, i - r) / t,
  };
}
async function yt(e, s, t = {}) {
  return mt(await K(e), s, t);
}
async function mt(e, s, t = {}) {
  const n = q(s, t),
    r = n.map((a) => a.matcher),
    o = { boxes: {}, hidden: [], pagesWithoutText: [] };
  if (r.length === 0) return o;
  for (let a = 0; a < e.numPages; a++) {
    const u = await e.getPage(a + 1),
      h = u.getViewport({ scale: 1 }),
      x = await u.getTextContent(),
      A = [],
      d =
        typeof document < "u"
          ? document.createElement("canvas").getContext("2d")
          : null;
    for (const l of x.items) {
      if (!("str" in l) || !("transform" in l)) continue;
      const p = l,
        S = (p.fontName && x.styles[p.fontName]?.fontFamily) || "sans-serif",
        T = d
          ? (E) => ((d.font = `100px ${S}`), d.measureText(E).width)
          : void 0;
      A.push({
        measure: T,
        str: p.str,
        hasEOL: p.hasEOL,
        width: p.width * (Math.hypot(h.transform[0], h.transform[1]) || 1),
        matrix: Z.transform(h.transform, p.transform),
      });
    }
    A.some((l) => l.str.trim()) || o.pagesWithoutText.push(a);
    const { text: b, owner: m } = ft(A),
      g = [];
    let k = 0;
    for (const l of F(b, n)) {
      k++;
      for (const p of pt(m, l.start, l.end))
        g.push({
          ...G(dt(A[p.run], p.from, p.to), h.width, h.height),
          kind: l.kind,
          group: k,
        });
    }
    const C = await u.getAnnotations(),
      M = (l) => typeof l == "string" && l && z(l, r).length > 0;
    for (const l of C) {
      const p = h.transform,
        S = (w, v) => [p[0] * w + p[2] * v + p[4], p[1] * w + p[3] * v + p[5]],
        T = S(l.rect[0], l.rect[1]),
        E = S(l.rect[2], l.rect[3]),
        y = [T[0], T[1], E[0], E[1]],
        P = G(
          {
            x0: Math.min(y[0], y[2]),
            y0: Math.min(y[1], y[3]),
            x1: Math.max(y[0], y[2]),
            y1: Math.max(y[1], y[3]),
          },
          h.width,
          h.height,
        );
      if (l.subtype === "Widget") {
        const w = Array.isArray(l.fieldValue)
          ? l.fieldValue.join(" ")
          : l.fieldValue;
        M(w) &&
          (g.push({ ...P, kind: "field", group: ++k }),
          o.hidden.push({ page: a, kind: "form", text: String(w), box: P }));
      } else if (l.subtype === "Link") {
        const w = l.url ?? l.unsafeUrl;
        M(w) && o.hidden.push({ page: a, kind: "link", text: String(w) });
      } else if (l.subtype !== "Popup") {
        const w = l.contentsObj?.str ?? l.contents;
        M(w) && o.hidden.push({ page: a, kind: "comment", text: String(w) });
      }
    }
    g.length > 0 && (o.boxes[a] = g);
  }
  const i = await e.getOutline().catch(() => null),
    c = (a) => {
      for (const u of a ?? [])
        (u.title &&
          z(String(u.title), r).length > 0 &&
          o.hidden.push({ page: -1, kind: "bookmark", text: String(u.title) }),
          c(u.items));
    };
  return (c(i), o);
}
export {
  W as A,
  $ as M,
  f as P,
  U as a,
  I as b,
  xt as c,
  bt as d,
  z as e,
  yt as f,
  rt as p,
  At as t,
};
//# sourceMappingURL=redactSearch-DQpyyh_t.js.map
