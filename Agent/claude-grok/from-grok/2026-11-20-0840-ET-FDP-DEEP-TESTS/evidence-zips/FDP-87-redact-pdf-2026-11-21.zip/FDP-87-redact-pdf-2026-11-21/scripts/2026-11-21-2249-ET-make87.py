#!/usr/bin/env python3
"""FDP-87 redaction test PDFs with known secrets. reportlab + pikepdf + Pillow. Secret marker: the name "Jonathan Reed" (and variants), SSN 123-45-6789,
email jreed@example.com, phone (617) 555-0142, card 4111 1111 1111 1111, EIN 12-3456789.
secrets.pdf (4 pages):
 p1: visible name/SSN/email/phone/card/EIN lines; name split over two text runs ("Jona"+"than Reed"); invisible text (render mode 3) "Jonathan Reed" at bottom;
     white-on-white "Jonathan Reed"; JPEG picture with the name in pixels; vector rectangle under the SSN; Form XObject text "XOBJ Jonathan Reed"; page thumbnail (/Thumb) showing the name
 p2: TTF (DejaVu) text "Signed by Jonathan Reed"; link annotation mailto:jreed@example.com; sticky note "Call Jonathan Reed"; text form field value "Jonathan Reed"; hidden optional-content layer (OCG OFF) "LAYER Jonathan Reed"
 p3: no secrets except one "Jonathan Reed" line at the end (tests search across pages)
 p4: page /Rotate 90 with "Rotated Jonathan Reed"
 doc: Info Title/Author/Subject/Keywords/Creator + custom /Client all with the name; XMP dc:creator; outline "Jonathan Reed intake"; attachment notes.txt with the name;
      StructTreeRoot with Figure /Alt "Photo of Jonathan Reed"; incremental update whose OLD revision of p3 had "OLDREV Jonathan Reed"
scan.pdf: one page that is only a picture of text (no text layer). enc.pdf: secrets.pdf with an open password "test123". corrupt.pdf: random bytes."""
import io, os, random, pikepdf
from PIL import Image, ImageDraw, ImageFont
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
D = 'testfiles'; os.makedirs(D, exist_ok=True); random.seed(87)
pdfmetrics.registerFont(TTFont('DejaVu', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
F = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 40)
def img(text, w=700, h=90):
    im = Image.new('RGB', (w, h), 'white'); ImageDraw.Draw(im).text((10, 20), text, fill='black', font=F); return im
img('Jonathan Reed (photo ID)').save(f'{D}/_name.jpg', quality=90)
img('THUMB Jonathan Reed', 400, 90).save(f'{D}/_thumb.png')
c = canvas.Canvas(f'{D}/_base.pdf', pagesize=letter)
c.setTitle('Case file Jonathan Reed'); c.setAuthor('Jonathan Reed'); c.setSubject('Client Jonathan Reed'); c.setKeywords('Jonathan Reed, SSN'); c.setCreator('Jonathan Reed laptop')
# p1
c.setFont('Helvetica', 14); y = 720
for t in ['Client: Jonathan Reed', 'SSN: 123-45-6789', 'Email: jreed@example.com', 'Phone: (617) 555-0142', 'Card: 4111 1111 1111 1111', 'EIN: 12-3456789', 'Account: ACCT-7781', 'Keep this line: public summary text stays.']:
    c.drawString(72, y, t); y -= 26
c.drawString(72, y, 'Split name: Jona'); w = c.stringWidth('Split name: Jona', 'Helvetica', 14); c.drawString(72 + w, y, 'than Reed'); y -= 26
c.setStrokeColorRGB(0.2, 0.4, 0.8); c.setLineWidth(2); c.rect(66, 688, 220, 24, stroke=1, fill=0)  # vector box around SSN line
c.drawImage(f'{D}/_name.jpg', 72, 380, width=350, height=45)
c.setFillColorRGB(1, 1, 1); c.drawString(72, 340, 'Jonathan Reed'); c.setFillColorRGB(0, 0, 0)  # white text
t = c.beginText(72, 80); t.setTextRenderMode(3); t.textLine('Jonathan Reed'); c.drawText(t)  # invisible
c.beginForm('xo'); c.setFont('Helvetica', 14); c.drawString(72, 300, 'XOBJ Jonathan Reed'); c.endForm(); c.doForm('xo')
c.bookmarkPage('p1'); c.addOutlineEntry('Jonathan Reed intake', 'p1', 0)
c.showPage()
# p2
c.setFont('DejaVu', 14); c.drawString(72, 720, 'Signed by Jonathan Reed on 12 March 2026.'); c.drawString(72, 690, 'Contact: jreed@example.com')
c.linkURL('mailto:jreed@example.com', (72, 685, 300, 705), relative=0)
c.acroForm.textfield(name='client', value='Jonathan Reed', x=72, y=600, width=250, height=24)
c.showPage()
# p3
c.setFont('Helvetica', 14); c.drawString(72, 720, 'Page three is mostly public text.'); c.drawString(72, 690, 'PLACEHOLDER-P3'); c.drawString(72, 660, 'Final line: Jonathan Reed'); c.showPage()
# p4
c.setFont('Helvetica', 14); c.drawString(72, 720, 'Rotated Jonathan Reed'); c.drawString(72, 690, 'Rotated page public text.'); c.showPage(); c.save()
pdf = pikepdf.open(f'{D}/_base.pdf')
pdf.pages[3].obj.Rotate = 90
# sticky note on p2
p2 = pdf.pages[1]
note = pdf.make_indirect(pikepdf.Dictionary(Type=pikepdf.Name.Annot, Subtype=pikepdf.Name.Text, Rect=[400, 700, 420, 720], Contents=pikepdf.String('Call Jonathan Reed'), T=pikepdf.String('Jonathan Reed')))
p2.obj.Annots = pdf.make_indirect(pikepdf.Array(list(p2.obj.get('/Annots', [])) + [note]))
# OCG hidden layer on p2
ocg = pdf.make_indirect(pikepdf.Dictionary(Type=pikepdf.Name.OCG, Name=pikepdf.String('Hidden layer')))
pdf.Root.OCProperties = pikepdf.Dictionary(OCGs=[ocg], D=pikepdf.Dictionary(OFF=[ocg], ON=[]))
res = p2.obj.Resources; res.Properties = pikepdf.Dictionary(oc1=ocg)
fnt = pdf.make_indirect(pikepdf.Dictionary(Type=pikepdf.Name.Font, Subtype=pikepdf.Name.Type1, BaseFont=pikepdf.Name.Helvetica)); res.Font.HL = fnt
p2.contents_add(pdf.make_stream(b'/OC /oc1 BDC BT /HL 14 Tf 72 500 Td (LAYER Jonathan Reed) Tj ET EMC'), prepend=False)
# thumbnail on p1
th = Image.open(f'{D}/_thumb.png').convert('RGB')
pdf.pages[0].obj.Thumb = pdf.make_stream(th.tobytes(), Width=th.width, Height=th.height, ColorSpace=pikepdf.Name.DeviceRGB, BitsPerComponent=8)
# custom info + XMP
with pdf.open_metadata(set_pikepdf_as_editor=False, update_docinfo=False) as m: m['dc:creator'] = ['Jonathan Reed']; m['dc:description'] = 'XMP Jonathan Reed'
for k, v in dict(Title='Case file Jonathan Reed', Author='Jonathan Reed', Subject='Client Jonathan Reed', Keywords='Jonathan Reed, SSN', Creator='Jonathan Reed laptop', Producer='FDP-87 test generator', Client='Jonathan Reed').items(): pdf.docinfo['/' + k] = pikepdf.String(v)
# attachment
pdf.attachments['notes.txt'] = pikepdf.AttachedFileSpec(pdf, b'Private notes about Jonathan Reed, SSN 123-45-6789\n', mime_type='text/plain')
# struct tree alt text
fig = pikepdf.Dictionary(Type=pikepdf.Name.StructElem, S=pikepdf.Name.Figure, Alt=pikepdf.String('Photo of Jonathan Reed'), Pg=pdf.pages[0].obj)
pdf.Root.StructTreeRoot = pdf.make_indirect(pikepdf.Dictionary(Type=pikepdf.Name.StructTreeRoot, K=[pdf.make_indirect(fig)]))
pdf.Root.MarkInfo = pikepdf.Dictionary(Marked=True)
# p3 old revision text, then incremental update replacing it
p3 = pdf.pages[2]; cs = p3.obj.Contents.read_bytes() if isinstance(p3.obj.Contents, pikepdf.Stream) else b''
p3.obj.Contents = pdf.make_stream(cs.replace(b'PLACEHOLDER-P3', b'OLDREV Jonathan Reed'))
pdf.save(f'{D}/_rev1.pdf', compress_streams=False)
# manual incremental update (classic xref) so the OLD revision of page 3 stays in the file bytes
q = pikepdf.open(f'{D}/_rev1.pdf'); pg3 = q.pages[2].obj; pnum = pg3.objgen[0]; size = int(q.trailer.Size)
newc = q.pages[2].obj.Contents.read_bytes().replace(b'OLDREV Jonathan Reed', b'NEWREV public text')
pd = pikepdf.unparse(pg3) if hasattr(pikepdf, 'unparse') else None
items = {k: v for k, v in pg3.items() if k != '/Contents'}
q.close(); raw = open(f'{D}/_rev1.pdf', 'rb').read(); prev = int(raw.rsplit(b'startxref', 1)[1].split()[0])
import re
m = re.search(rb'\n%d 0 obj\s*(<<.*?>>)\s*endobj' % pnum, raw, re.S); pdict = m.group(1)
pdict2 = re.sub(rb'/Contents \d+ 0 R', b'/Contents %d 0 R' % size, pdict)
out = bytearray(raw); offs = {}
offs[size] = len(out); out += b'%d 0 obj\n<< /Length %d >>\nstream\n' % (size, len(newc)) + newc + b'\nendstream\nendobj\n'
offs[pnum] = len(out); out += b'%d 0 obj\n' % pnum + pdict2 + b'\nendobj\n'
xref = len(out); out += b'xref\n'
for n in sorted(offs): out += b'%d 1\n%010d 00000 n \n' % (n, offs[n])
idm = re.search(rb'/ID\s*\[[^\]]*\]', raw).group(0)
out += b'trailer\n<< /Size %d /Root 1 0 R /Info 2 0 R /Prev %d %s >>\nstartxref\n%d\n%%%%EOF\n' % (size + 1, prev, idm, xref)
open(f'{D}/secrets.pdf', 'wb').write(out)
# scan.pdf: picture-only page
im = Image.new('RGB', (1700, 2200), 'white'); d = ImageDraw.Draw(im)
for i, t in enumerate(['Scanned letter for Jonathan Reed', 'SSN 123-45-6789', 'This page has no text layer.']): d.text((150, 200 + i * 90), t, fill='black', font=F)
im.save(f'{D}/_scan.jpg', quality=85); c = canvas.Canvas(f'{D}/scan.pdf', pagesize=letter); c.drawImage(f'{D}/_scan.jpg', 0, 0, width=612, height=792); c.showPage(); c.save()
p = pikepdf.open(f'{D}/secrets.pdf'); p.save(f'{D}/enc.pdf', encryption=pikepdf.Encryption(user='test123', owner='owner987'))
open(f'{D}/corrupt.pdf', 'wb').write(b'%PDF-1.7\n' + random.randbytes(40000))
print('final', pikepdf.open(f'{D}/secrets.pdf').trailer.keys())
for f in os.listdir(D):
    if f.startswith('_'): os.remove(f'{D}/{f}')
print(sorted(os.listdir(D)))
# curve.pdf (added later): text + stroked circle partly under a box, to trigger the rasterize notice
