const pw=require('playwright');const fs=require('fs');(async()=>{const b=await pw.chromium.launch();const out={};
for(const s of ['ai-pdf-redactor','blind-cv-redactor','redact-powerpoint']){const c=await b.newContext({viewport:{width:1366,height:900}});const p=await c.newPage();
await p.goto('https://www.freedailypro.com/tool/'+s,{waitUntil:'domcontentloaded',timeout:45000});await p.waitForTimeout(5000);
out[s]=await p.evaluate(()=>{const m=document.querySelector('main');return{h1:(document.querySelector('h1')||{}).innerText,top:m.innerText.slice(0,1400),accept:[...m.querySelectorAll('input[type=file]')].map(i=>i.accept),links:[...m.querySelectorAll('a[href*="redact"]')].map(a=>a.getAttribute('href')+' | '+a.innerText.trim().slice(0,60)),faq:(m.innerText.match(/[^\n]*(redact pdf|Redact PDF|true removal|permanent|black box)[^\n]*/gi)||[]).slice(0,8)}});
await p.screenshot({path:'/workspace/deep/87-redact-pdf/live/cases/dup-'+s+'.png'});await c.close();}
fs.writeFileSync('/workspace/deep/87-redact-pdf/live/dups.json',JSON.stringify(out,null,1));await b.close();})();
