// FDP-87 probe: drop secrets.pdf, dump UI controls; no Apply. Guest.
const pw = require('playwright'); const fs = require('fs'); const W = '/workspace/deep/87-redact-pdf/';
(async () => { const b = await pw.chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 1000 } })).newPage(); p.setDefaultTimeout(15000);
 await p.goto('https://www.freedailypro.com/tool/redact-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 await p.locator('input[type=file]').first().setInputFiles(W + 'testfiles/secrets.pdf'); await p.waitForTimeout(6000);
 const dump = () => p.evaluate(() => { const m = document.querySelector('main'); return { text: m.innerText.slice(0, 4000), controls: [...m.querySelectorAll('button,input,select,textarea,label,canvas,img')].map(e => e.tagName + ':' + (e.getAttribute('aria-label') || e.innerText || e.type || e.alt || '').trim().slice(0, 70) + (e.type === 'checkbox' ? (e.checked ? '[x]' : '[ ]') : '') + (e.tagName === 'CANVAS' || e.tagName === 'IMG' ? ` ${e.width}x${e.height}` : '')).slice(0, 120) }; });
 const a = await dump(); await p.screenshot({ path: W + 'live/cases/P01-loaded.png', fullPage: true });
 fs.writeFileSync(W + 'live/probe.json', JSON.stringify({ a, usage: await p.evaluate(() => localStorage.getItem('fdp-usage-v1')).then(s => (s || '').replace(/dev:[0-9a-f-]+/, 'dev:REDACTED')) }, null, 1)); console.log('ok'); await b.close(); })();
