// FDP-87 Quick Buy: day + monthly redirect host only (Stripe IDs redacted); stops at Stripe, never types email or card.
// Never signs in, never types an email or card, never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const BASE = '/workspace/deep/87-redact-pdf/'; const OUT = BASE + 'live/'; const TF = BASE + 'testfiles/'; const TOOL = 'https://www.freedailypro.com/tool/redact-pdf';
const mode = process.argv[2] || 'zero'; const eng = process.argv[3] || 'chromium'; const sfx = (eng === 'chromium' ? '' : '-' + eng) + (process.env.SUF || '');
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
const red = u => u.replace(/(client_id|state|redirect_uri|deviceId|code_challenge|nonce|opparams|dsh)=[^&]*/g, '$1=REDACTED').replace(/cs_live_[A-Za-z0-9]+/g, 'cs_live_REDACTED').replace(/#.*$/, '#REDACTED').slice(0, 160);
fs.mkdirSync(OUT + 'cases', { recursive: true });
(async () => { const b = await pw[eng].launch(); const R = { t: now(), mode, engine: eng, tries: [], cases: {} }; let c, p, net = [];
 const open = async () => { c = await b.newContext({ viewport: { width: 1366, height: 1000 }, locale: 'en-US' }); p = await c.newPage(); p.setDefaultTimeout(12000); net = [];
  p.on('request', r => { const u = r.url(); if (r.method() === 'POST' && /freedailypro\.com\/api/.test(u) && !/insight\.hit|funnel\.hit/.test(u)) net.push({ t: now(), u: u.slice(0, 70), len: (r.postData() || '').length, doc: /Students in this study|References/.test(r.postData() || '') }); });
  await p.goto(TOOL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(250); } };
 const shot = n => p.screenshot({ path: OUT + 'cases/' + n + sfx + '.png', fullPage: true });
 if (false) {
 } else if (mode === 'quickbuy') { await open(); const u0 = p.url(); await p.locator('main button', { hasText: 'Quick Buy' }).first().click(); await p.waitForTimeout(5000); R.qbDay = { url: red(p.url()), dialog: await dialog() }; await p.screenshot({ path: OUT + 'quickbuy-day.png' }); await esc(); await p.goto(TOOL); await p.waitForTimeout(4000); await p.locator('main button', { hasText: 'Quick Buy' }).nth(1).click(); await p.waitForTimeout(6000); R.qbMonth = { url: red(p.url()), title: await p.title() }; await p.screenshot({ path: OUT + 'quickbuy-monthly.png' }); }
 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', JSON.stringify(R.tries), JSON.stringify(R.start || ''), R.end); await b.close(); })();
