#!/usr/bin/env python3
"""FDP-87 true-redaction verifier. Usage: verify87.py <redacted.pdf> [original.pdf] -> prints JSON with every place a secret could survive."""
import sys, json, re, subprocess, hashlib, zlib
import pikepdf, fitz
SECRETS = ['Jonathan Reed', 'Jonathan', 'Reed', 'Jona', '123-45-6789', 'jreed@example.com', 'jreed', '555-0142', '4111', '12-3456789', 'ACCT-7781', 'OLDREV', 'LAYER', 'XOBJ', 'THUMB']
KEEP = ['Keep this line: public summary text stays', 'Page three is mostly public text', 'NEWREV public text', 'Final line:', 'Client:', 'Signed by', 'Rotated']
def cnt(t): return {s: t.count(s) for s in SECRETS if t.count(s)}
def run(*a): return subprocess.run(a, capture_output=True, text=True).stdout
def main(path, orig=None):
    R = {'file': path}
    raw = open(path, 'rb').read(); R['bytes'] = len(raw); R['eof_markers'] = raw.count(b'%%EOF'); R['raw_bytes_hits'] = {s: raw.count(s.encode()) for s in SECRETS if raw.count(s.encode())}
    R['pdftotext'] = cnt(run('pdftotext', '-layout', path, '-'))
    R['pdftotext_raw'] = cnt(run('pdftotext', '-raw', path, '-'))
    d = fitz.open(path); R['pages'] = d.page_count; R['rotation'] = [pg.rotation for pg in d]
    R['fitz_text_per_page'] = [cnt(pg.get_text()) for pg in d]
    R['fitz_search_Jonathan_Reed'] = [len(pg.search_for('Jonathan Reed')) for pg in d]
    R['fitz_search_ssn_email'] = [len(pg.search_for('123-45-6789')) + len(pg.search_for('jreed@example.com')) for pg in d]
    R['keep_present'] = {k: (k in ''.join(pg.get_text() for pg in d)) for k in KEEP}
    # copy-paste simulation: text inside every black filled rectangle (redaction boxes)
    clips = []
    for i, pg in enumerate(d):
        for dr in pg.get_drawings():
            f = dr.get('fill')
            if f and max(f) < 0.15 and dr['rect'].width > 3 and dr['rect'].height > 3:
                r = dr['rect']; t = pg.get_text('text', clip=r).strip()
                clips.append({'page': i + 1, 'rect': [round(x) for x in r], 'text_under_box': t[:120]})
    R['black_boxes'] = clips
    R['annots'] = [[{'type': a.type[1], 'info': {k: v for k, v in a.info.items() if v}} for a in pg.annots()] for pg in d]
    R['links'] = [[l.get('uri') for l in pg.get_links() if l.get('uri')] for pg in d]
    R['widgets'] = [[(w.field_name, w.field_value) for w in pg.widgets()] for pg in d]
    R['toc'] = d.get_toc(); R['metadata'] = {k: v for k, v in d.metadata.items() if v}
    R['xmp'] = cnt(d.get_xml_metadata() or ''); R['xmp_len'] = len(d.get_xml_metadata() or '')
    R['embedded_files'] = d.embfile_names()
    R['images'] = run('pdfimages', '-list', path).strip().splitlines()[2:]
    R['fonts'] = run('pdffonts', path).strip().splitlines()[2:]
    p = pikepdf.open(path)
    R['ocproperties'] = '/OCProperties' in p.Root; R['acroform'] = '/AcroForm' in p.Root; R['names'] = list(p.Root.Names.keys()) if '/Names' in p.Root else []
    R['struct_alt'] = []; R['thumbs'] = [i + 1 for i, pg in enumerate(p.pages) if '/Thumb' in pg.obj]
    dec = {}; nobj = 0
    for o in p.objects:
        nobj += 1
        try:
            if isinstance(o, pikepdf.Stream):
                try: b = o.read_bytes()
                except Exception: b = o.read_raw_bytes()
            else: b = repr(o).encode('latin1', 'replace')
        except Exception: continue
        for s in SECRETS:
            n = b.count(s.encode())
            if n: dec[s] = dec.get(s, 0) + n
        if b'/Alt' in b or (isinstance(o, pikepdf.Dictionary) and '/Alt' in o): R['struct_alt'].append(str(o.get('/Alt')) if isinstance(o, pikepdf.Dictionary) else 'stream')
    R['decoded_objects_hits'] = dec; R['objects'] = nobj
    if orig:
        o = fitz.open(orig); oh = set(); nh = set()
        for pg in o:
            for im in pg.get_images(full=True): oh.add(hashlib.md5(o.xref_stream_raw(im[0])).hexdigest())
        for pg in d:
            for im in pg.get_images(full=True): nh.add(hashlib.md5(d.xref_stream_raw(im[0])).hexdigest())
        R['original_image_streams_still_present'] = len(oh & nh)
        # unmarked pages untouched? compare text & content hash per page
        R['page_text_same_as_original'] = [o[i].get_text() == d[i].get_text() for i in range(min(o.page_count, d.page_count))]
    print(json.dumps(R, indent=1, default=str))
if __name__ == '__main__': main(*sys.argv[1:])
