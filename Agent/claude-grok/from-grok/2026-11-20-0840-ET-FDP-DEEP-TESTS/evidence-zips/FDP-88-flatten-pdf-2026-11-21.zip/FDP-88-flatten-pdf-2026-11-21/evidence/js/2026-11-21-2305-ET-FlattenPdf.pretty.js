import { r as o, j as e } from "./vendor-react-D01g8YgM.js";
import { T as $ } from "./ToolWithSidebar-CO7i-D3n.js";
import {
  n as z,
  k as Z,
  F as H,
  P as D,
  D as C,
  R as J,
} from "./ToolPage-DrleSM7T.js";
import { f as w, N as S, B as T } from "./index-xgcQ0Xo8.js";
import { i as K, f as M } from "./operations-BatXiFlG.js";
import { p as W, U as q } from "./protectedPdfNotice-Dl0m_ReY.js";
import { l as G, r as Q } from "./utils-s8ucLyj8.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./CollapsibleText-DFD2kyG0.js";
import "./chevron-up-RK9L2OPY.js";
import "./useUploadApi-yCV1cZhw.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-Cl69OhvT.js";
import "./share-2-tv4Mz_hR.js";
import "./copy-B6PRNyNa.js";
import "./workflowCta-BFTpZlex.js";
import "./UsageAndUpgradeStrip-DMhPNgnJ.js";
import "./access-DqVqJd33.js";
import "./useAdminAccess-mVM_2mWb.js";
import "./InstallToolButton-DxfN0Pem.js";
import "./map-pin-CwlIzHDK.js";
import "./FaqSection-BNxk42M5.js";
import "./ToolVideoEmbed-DNaMY2Pn.js";
import "./GuideLinks-D5fn3NI1.js";
import "./blog-CxdB1WyW.js";
import "./info-x67VbErc.js";
import "./productCards-DhpNcELZ.js";
import "./layers-B44Zba7-.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./pdfMetadata-CcxIhQF2.js";
import "./pageView-BQIwVYOi.js";
import "./formAppearance-CdNbuISd.js";
import "./drawTextAnywhere-DcuP6lHH.js";
import "./ocrText-C_9cxcFa.js";
import "./ocrImage-CmXFNUud.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./imageRecompress-eXQFDUm-.js";
import "./formatFileSize-B-JRDfN5.js";
import "./plural-FIChqbp4.js";
import "./textDiff-DxE9AzvO.js";
import "./utils-BB7NgdRI.js";
import "./decode-FlLGQ42m.js";
import "./formFill-Dg9Myfyq.js";
import "./redactSearch-DQpyyh_t.js";
import "./nameDetect-DvHCRM0m.js";
const I = {
  what: `Permanently locks in a PDF's fillable form field values, so they become regular page content instead of still-editable fields. Useful any time a PDF has been filled in — by you, by someone else, in this site's own Sign PDF or Fillable Forms tools, in Acrobat, or in a browser's built-in PDF viewer — and you want to make sure whoever receives the final copy can't change what was entered.

Honestly: this is forms-only. It locks AcroForm field values (text fields, checkboxes, signatures placed as fields), but doesn't flatten other annotation types like highlights, sticky notes, or comments — those stay as separate, still-editable annotations in the output. If a document only has non-form annotations and no fillable fields, there's nothing here for this tool to flatten.`,
  tip: `This is the natural second step after using Sign PDF to send someone a document with fields for them to fill in — once they've entered their signature, name, or date, running the result through this tool locks their entries in place before it gets sent back or filed away. Flattening is one-way: the field values can't be edited as fields again in the downloaded copy. The date is recorded in the file's properties; if you want a small "flattened on" note printed on each page, tick the option before flattening and choose local time or UTC (off by default, because flattened forms are usually official documents).`,
};
function Qe() {
  const d = z(),
    L = d !== null,
    [i, u] = o.useState(null),
    [c, f] = o.useState([]),
    [j, F] = o.useState(!1),
    [P, N] = o.useState(!1),
    [n, m] = o.useState(null),
    [h, g] = o.useState(null),
    [x, U] = o.useState(!1),
    [k, R] = o.useState("local"),
    [v, b] = o.useState(null),
    [a, p] = o.useState(null),
    O = o.useCallback(async (s) => {
      const t = s[0];
      if (t) {
        if ((b(null), Z(t))) {
          b(t.name);
          return;
        }
        (u(t),
          m(null),
          g(null),
          f([]),
          F(!0),
          p(null),
          K(t)
            .then(p)
            .catch(() => p(null)));
        try {
          const l = await G(t),
            r = [];
          for (let y = 1; y <= l.numPages; y++) {
            const A = await l.getPage(y),
              _ = await Q(A, 0.6, 0.75);
            r.push(URL.createObjectURL(_));
          }
          f(r);
        } catch (l) {
          console.error("Couldn't render preview:", l);
          const r = l;
          (r?.name === "PasswordException" ||
          /password|encrypted/i.test(r?.message ?? "")
            ? b(t.name)
            : w.error(
                "Couldn't read this PDF — it may be corrupted or damaged",
              ),
            u(null));
        } finally {
          F(!1);
        }
      }
    }, []),
    B = async () => {
      if (i) {
        (N(!0), m(null));
        try {
          const { blob: s, fieldCount: t } = await M(i, {
            stamp: x,
            stampZone: k,
          });
          (m(s),
            g(t),
            w.success(
              `Flattened ${t} field${t === 1 ? "" : "s"} — your entries are now permanent`,
            ));
        } catch (s) {
          (console.error("PDF flatten failed:", s),
            w.error(
              s instanceof Error
                ? s.message
                : "Something went wrong flattening this PDF — try again",
            ));
        } finally {
          N(!1);
        }
      }
    },
    E = () => {
      (u(null), m(null), g(null), f([]), p(null));
    };
  return e.jsxs($, {
    toolId: "flatten-pdf",
    categoryId: "pdf-tools",
    whatItDoes: I.what,
    proTip: I.tip,
    children: [
      e.jsxs("div", {
        className:
          "mb-4 p-3 rounded-lg border bg-muted/50 text-xs text-muted-foreground flex flex-wrap gap-x-4 gap-y-1",
        children: [
          e.jsx("span", {
            children: "🔒 Runs entirely in your browser — never uploaded",
          }),
          e.jsx("span", {
            children:
              "🧾 Nothing is printed on your pages unless you choose to",
          }),
        ],
      }),
      i
        ? e.jsxs("div", {
            className: "space-y-4",
            children: [
              e.jsx("p", { className: "text-sm", children: i.name }),
              j && e.jsx(D, { message: "Loading pages..." }),
              c.length > 0 &&
                e.jsxs("div", {
                  children: [
                    e.jsxs("p", {
                      className: "text-xs text-muted-foreground mb-2",
                      children: [
                        c.length,
                        " page",
                        c.length === 1 ? "" : "s",
                        " -- check this is the right file before flattening",
                      ],
                    }),
                    e.jsx("div", {
                      className: "flex flex-wrap gap-3",
                      children: c.map((s, t) =>
                        e.jsxs(
                          "div",
                          {
                            className:
                              "border rounded-lg overflow-hidden bg-muted/30",
                            children: [
                              e.jsx("img", {
                                src: s,
                                alt: `Page ${t + 1}`,
                                className: "h-48 w-auto block",
                              }),
                              e.jsxs("p", {
                                className:
                                  "text-center text-xs py-1 text-muted-foreground",
                                children: ["Page ", t + 1],
                              }),
                            ],
                          },
                          t,
                        ),
                      ),
                    }),
                  ],
                }),
              a &&
                a.fieldCount === 0 &&
                e.jsx(S, {
                  className: "text-sm",
                  role: "alert",
                  children:
                    "This PDF has no fillable form fields — it may already be flattened, so there is nothing to lock in.",
                }),
              L &&
                a &&
                a.fieldCount === 0 &&
                !n &&
                e.jsxs("div", {
                  className: "space-y-2",
                  "data-testid": "pass-through",
                  children: [
                    e.jsx("p", {
                      className: "text-sm",
                      children:
                        "Nothing to flatten, your file is ready as it is.",
                    }),
                    e.jsx(C, {
                      blob: i,
                      fileName: i.name,
                      label:
                        d && d.currentStepIndex >= d.steps.length - 1
                          ? "Download final file"
                          : "Download file",
                    }),
                  ],
                }),
              a &&
                a.signatureCount > 0 &&
                e.jsxs(S, {
                  className: "text-sm",
                  role: "alert",
                  children: [
                    "This PDF has ",
                    a.signatureCount,
                    " signature field",
                    a.signatureCount === 1 ? "" : "s",
                    ". Flattening a digitally signed PDF breaks the signature — keep the original signed copy.",
                  ],
                }),
              !n &&
                e.jsxs("div", {
                  className: "space-y-1",
                  children: [
                    e.jsxs("label", {
                      className: "flex items-center gap-2 text-sm",
                      children: [
                        e.jsx("input", {
                          type: "checkbox",
                          checked: x,
                          onChange: (s) => U(s.target.checked),
                        }),
                        'Print a small "Flattened on <date>" note at the bottom of each page',
                      ],
                    }),
                    x &&
                      e.jsxs("div", {
                        className: "ml-6 flex items-center gap-2 text-sm",
                        children: [
                          e.jsx("label", {
                            htmlFor: "flatten-zone",
                            children: "Time shown",
                          }),
                          e.jsxs("select", {
                            id: "flatten-zone",
                            value: k,
                            onChange: (s) => R(s.target.value),
                            className:
                              "rounded-md border bg-background px-2 py-1 text-sm",
                            children: [
                              e.jsx("option", {
                                value: "local",
                                children: "My local time, with zone name",
                              }),
                              e.jsx("option", {
                                value: "utc",
                                children: "UTC",
                              }),
                            ],
                          }),
                        ],
                      }),
                  ],
                }),
              P && e.jsx(D, { message: "Flattening form fields..." }),
              n &&
                h !== null &&
                e.jsxs("p", {
                  className: "text-sm text-green-600",
                  children: [
                    "Flattened ",
                    h,
                    " field",
                    h === 1 ? "" : "s",
                    " -- these values are now permanent and can't be edited as fields anymore.",
                  ],
                }),
              e.jsxs("div", {
                className: "flex gap-3",
                children: [
                  n
                    ? e.jsx(C, { blob: n, fileName: `flattened-${i.name}` })
                    : e.jsx(T, {
                        onClick: B,
                        disabled: P || j || a?.fieldCount === 0,
                        children: "Flatten PDF",
                      }),
                  e.jsx(T, {
                    variant: "outline",
                    onClick: E,
                    children: n ? "New" : "Reset",
                  }),
                ],
              }),
              n && e.jsx(J, { blob: n, mimeType: "application/pdf" }),
            ],
          })
        : e.jsxs("div", {
            className: "space-y-3",
            children: [
              e.jsx(H, {
                gateAtDownload: !0,
                keepSkippedProtectedFiles: !0,
                accept: "application/pdf",
                onFiles: O,
                label: "Drop a filled-in PDF to flatten",
                description:
                  "Locks in form field values so they can no longer be edited",
              }),
              v &&
                e.jsxs("p", {
                  role: "alert",
                  className: "text-sm text-destructive",
                  children: [
                    W(v, "flattened"),
                    " ",
                    e.jsx("a", {
                      href: q,
                      className: "underline font-medium",
                      children: "Unlock it with Unlock PDF",
                    }),
                    ", then drop the unlocked copy here.",
                  ],
                }),
            ],
          }),
    ],
  });
}
export { Qe as default };
//# sourceMappingURL=FlattenPdf-CCNgzGJR.js.map
