import {
  d as P,
  S as w,
  P as f,
  g as h,
  h as u,
  i as g,
  j as F,
  b as x,
  f as D,
  c as y,
} from "./index-BRvxULIc.js";
import {
  measureTextAnywhere as M,
  drawTextAnywhere as T,
  needsPicture as b,
} from "./drawTextAnywhere-DcuP6lHH.js";
async function v(e, t, n) {
  t.acroField.setValue(P.fromText(n));
  const o = t.isMultiline();
  for (const c of t.acroField.getWidgets()) {
    const a = c.getRectangle(),
      s = Math.max(10, a.width),
      r = Math.max(8, a.height),
      m = o ? n.split(/\r?\n/) : [n.replace(/[\r\n]+/g, " ")];
    let i = o ? 11 : Math.min(14, Math.max(6, r * 0.62));
    if (!o) {
      const l = await M(e, m[0], i);
      l > s - 4 && (i = Math.max(5, (i * (s - 4)) / l));
    }
    const p = e.addPage([s, r]);
    try {
      let l = o ? r - i - 2 : (r - i) / 2 + i * 0.22;
      for (const d of m)
        (d && (await T(e, p, d, { x: 2, y: l, size: i })), (l -= i * 1.2));
      const A = await e.embedPage(p);
      c.setNormalAppearance(A.ref);
    } finally {
      e.removePage(e.getPageCount() - 1);
    }
  }
  await e.flush();
}
async function S(e) {
  const t = e.getForm(),
    n = await e.embedFont(w.Helvetica),
    o = [],
    c = t.acroForm.dict.lookup(f.of("NeedAppearances")) === h.True;
  for (const a of t.getFields())
    try {
      const s = a instanceof u || a instanceof g || a instanceof F;
      if (!(c && s) && !a.needsAppearancesUpdate?.()) continue;
      if (a instanceof u) {
        const r = a.getText() ?? "";
        b(r) ? await v(e, a, r) : a.defaultUpdateAppearances(n);
      } else
        a instanceof g || a instanceof F
          ? a.defaultUpdateAppearances(n)
          : a.defaultUpdateAppearances();
    } catch (s) {
      o.push({
        name: a.getName(),
        reason: String(s?.message ?? s).slice(0, 120),
      });
    }
  return o;
}
function U(e) {
  const t = e.catalog.lookupMaybe(f.of("AcroForm"), x);
  t && t.set(f.of("NeedAppearances"), h.False);
}
function z(e) {
  for (const t of e.getPages()) {
    const n = t.node.lookupMaybe(f.of("Annots"), D);
    if (n) {
      for (let o = n.size() - 1; o >= 0; o--) {
        const c = n.get(o);
        c instanceof y && !e.context.lookup(c) && n.remove(o);
      }
      n.size() === 0 && t.node.delete(f.of("Annots"));
    }
  }
}
export { U as a, z as d, S as r, v as s };
//# sourceMappingURL=formAppearance-CdNbuISd.js.map
