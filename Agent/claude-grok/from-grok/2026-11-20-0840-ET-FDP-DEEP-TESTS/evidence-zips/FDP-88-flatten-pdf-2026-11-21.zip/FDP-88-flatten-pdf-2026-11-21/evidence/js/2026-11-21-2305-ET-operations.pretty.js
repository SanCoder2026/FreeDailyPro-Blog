const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/drawTextAnywhere-DcuP6lHH.js",
      "assets/pdfFonts-Ckcqm3Ic.js",
      "assets/index-BRvxULIc.js",
      "assets/index-CnXdQaNG.js",
      "assets/vendor-react-D01g8YgM.js",
      "assets/index-DMQTJy3b.js",
      "assets/fontkit.es-DA-3qwB1.js",
      "assets/imagePdf-Dtz8PQyf.js",
      "assets/pdfMetadata-CcxIhQF2.js",
      "assets/index-CmBFpp8Z.js",
      "assets/index-xgcQ0Xo8.js",
      "assets/index-BJxTAPRn.css",
      "assets/pdfRecover-PVH02fpy.js",
      "assets/repairDiagnose-Csq-PeZE.js",
      "assets/heic2any-Cwwvdsxn.js",
      "assets/docxRead-O6CRn7oc.js",
      "assets/jszip.min-CT0ZA6V1.js",
      "assets/jszip.min-C-FLQHAz.js",
      "assets/_commonjs-dynamic-modules-TDtrdbi3.js",
      "assets/xmlLite-D0-GZ86u.js",
      "assets/docxToPdf-K5O8yYaD.js",
      "assets/docxModel-CrYTKRGY.js",
      "assets/textToPdf-BuGdG5vq.js",
      "assets/excelPdf-DQL9QKOc.js",
      "assets/backgroundSafe-DObGz9DE.js",
      "assets/pptxRasterize-ByR_iBgN.js",
      "assets/domCapture-YfuNE2xZ.js",
      "assets/utils-s8ucLyj8.js",
      "assets/domTextLines-YXN485C_.js",
      "assets/pdfToExcel-38p0cUiA.js",
      "assets/index-DQo6ttmA.js",
      "assets/pdfPageContent-BLgAwNtO.js",
      "assets/ocrImage-CmXFNUud.js",
      "assets/tablesToExcel-C1ZZUvmI.js",
      "assets/pdfLayout-BswErtWz.js",
      "assets/xlsx-CNerDvZX.js",
      "assets/ocrEngine-C8AaB6dN.js",
      "assets/ocrText-C_9cxcFa.js",
    ]),
) => i.map((i) => d[i]);
import { ap as q } from "./index-xgcQ0Xo8.js";
import { c as Te, i as Ee, s as Me } from "./pdfFonts-Ckcqm3Ic.js";
import {
  P as G,
  f as rt,
  c as ct,
  b as tt,
  e as Dt,
  d as Ft,
  g as Se,
  y as bt,
  z as ie,
  k as U,
  u as ce,
  p as Ae,
  D as Ie,
  G as De,
  s as Fe,
  t as et,
  S as le,
  n as $e,
} from "./index-BRvxULIc.js";
import { w as xt, m as Nt, r as _t, a as Le } from "./pdfBookmarks-BjfxtCfb.js";
import { a as st, s as Q } from "./pdfMetadata-CcxIhQF2.js";
import { p as nt, s as Oe } from "./pageView-BQIwVYOi.js";
import { r as Ce, a as Re, d as Be } from "./formAppearance-CdNbuISd.js";
import { f as Ne } from "./fontkit.es-DA-3qwB1.js";
import { allowsDevanagari as ze } from "./ocrText-C_9cxcFa.js";
import { rotateImageBlob as je } from "./ocrImage-CmXFNUud.js";
import { J as Ue } from "./jszip.min-CT0ZA6V1.js";
import {
  c as We,
  l as kt,
  p as K,
  d as Vt,
  f as Ve,
  b as Ge,
  r as He,
  o as Xe,
} from "./utils-s8ucLyj8.js";
import {
  C as $t,
  b as qe,
  a as Je,
  e as Gt,
  g as Ke,
  h as Ye,
  B as Ht,
  S as Ze,
  i as Qe,
} from "./imageRecompress-eXQFDUm-.js";
import { f as gt } from "./formatFileSize-B-JRDfN5.js";
import { p as ta } from "./plural-FIChqbp4.js";
import { M as Lt, d as ea } from "./textDiff-DxE9AzvO.js";
import { l as fe } from "./utils-BB7NgdRI.js";
import { f as aa, p as na } from "./formFill-Dg9Myfyq.js";
import { f as oa } from "./redactSearch-DQpyyh_t.js";
function ra(e, t = "local", o) {
  const a = t === "utc" ? "UTC" : o;
  let n = {};
  try {
    const i = new Intl.DateTimeFormat("en-CA", {
      timeZone: a,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hourCycle: "h23",
      timeZoneName: "short",
    });
    for (const f of i.formatToParts(e)) n[f.type] = f.value;
  } catch {
    n = {};
  }
  if (!n.year)
    return `Flattened on ${e.toISOString().replace("T", " ").slice(0, 16)} UTC`;
  const r =
    (n.timeZoneName ?? "UTC").replace(/[^\x20-\x7e]/g, "").trim() || "UTC";
  return `Flattened on ${n.year}-${n.month}-${n.day} ${n.hour}:${n.minute} ${r}`;
}
const ht = (e) => `${e.objectNumber}:${e.generationNumber}`;
function ue(e, t) {
  const o = t.context,
    a = new Set(),
    n = [],
    r = new Set();
  for (const u of t.getPages()) {
    const d = u.node.lookupMaybe(G.of("Annots"), rt);
    if (d)
      for (let g = 0; g < d.size(); g++) {
        const h = d.get(g);
        if (!(h instanceof ct)) continue;
        const m = o.lookupMaybe(h, tt);
        if (!m || m.get(G.of("Subtype"))?.toString() !== "/Widget") continue;
        a.add(ht(h));
        let b = h,
          O = m;
        for (let D = 0; D < 32; D++) {
          const P = O.get(G.of("Parent")),
            p = P ? o.lookupMaybe(P, tt) : void 0;
          if (!p || !(P instanceof ct)) break;
          ((b = P), (O = p));
        }
        r.has(ht(b)) || (r.add(ht(b)), n.push(b));
      }
  }
  if (n.length === 0) return 0;
  const i = (u) => {
      const d = o.lookupMaybe(u, tt);
      if (!d) return !1;
      const g = d.lookupMaybe(G.of("Kids"), rt);
      if (!g) return a.has(ht(u));
      const h = [];
      for (let m = 0; m < g.size(); m++) {
        const b = g.get(m);
        b instanceof ct && i(b) && h.push(b);
      }
      return (d.set(G.of("Kids"), o.obj(h)), h.length > 0);
    },
    f = n.filter((u) => i(u));
  if (f.length === 0) return 0;
  const c = e.catalog.lookupMaybe(G.of("AcroForm"), tt),
    s = o.obj({});
  s.set(G.of("Fields"), o.obj(f));
  const l = c?.lookupMaybe(G.of("DA"), Dt, Ft);
  return (
    l && s.set(G.of("DA"), Dt.of(l.decodeText())),
    s.set(G.of("NeedAppearances"), Se.True),
    t.catalog.set(G.of("AcroForm"), o.register(s)),
    f.length
  );
}
function sa(e, t, o) {
  const a = e.context,
    n = t.node.lookupMaybe(G.of("Annots"), rt);
  if (!n) return;
  const r = new Set();
  for (let i = 0; i < n.size(); i++) {
    const f = n.get(i),
      c = f instanceof ct ? a.lookupMaybe(f, tt) : void 0;
    if (!c || c.get(G.of("Subtype"))?.toString() !== "/Widget") continue;
    let s = c;
    for (let u = 0; u < 32; u++) {
      const d = s.get(G.of("Parent")),
        g = d ? a.lookupMaybe(d, tt) : void 0;
      if (!g) break;
      s = g;
    }
    if (r.has(s)) continue;
    r.add(s);
    const l = s.lookupMaybe(G.of("T"), Dt, Ft);
    l && s.set(G.of("T"), Ft.fromText(`${l.decodeText()}_${o}`));
  }
}
function dt(e) {
  return (((Math.round(e / 90) * 90) % 360) + 360) % 360;
}
function ia(e) {
  return e
    ? (e.removed?.length ?? 0) > 0 ||
        Object.values(e.rotations ?? {}).some((t) => dt(t) !== 0)
    : !1;
}
function ca(e, t, o) {
  let a = Array.from({ length: e }, (f, c) => c);
  const n = t?.trim();
  if (n) {
    const f = Tt(n, e);
    if ("error" in f) return { error: f.error };
    a = f.pages;
  }
  const r = new Set((o?.removed ?? []).map((f) => f - 1)),
    i = a
      .filter((f) => !r.has(f))
      .map((f) => ({ index: f, rotate: dt(o?.rotations?.[f + 1] ?? 0) }));
  return i.length === 0
    ? { error: "No pages left from this file" }
    : { pages: i };
}
function lo(e, t) {
  const o = new Set(e ?? []);
  return (
    o.has(t) ? o.delete(t) : o.add(t),
    Array.from(o).sort((a, n) => a - n)
  );
}
function fo(e, t, o) {
  const a = { ...(e ?? {}) },
    n = dt((a[t] ?? 0) + o);
  return (n === 0 ? delete a[t] : (a[t] = n), a);
}
function uo(e) {
  const t = [];
  return (
    e.forEach((o, a) => {
      if (!("error" in o))
        for (const n of o.pages)
          t.push({ fileIndex: a, index: n.index, rotate: n.rotate });
    }),
    t
  );
}
function go(e, t, o) {
  if (t === o || t < 0 || t >= e.length || o < 0 || o >= e.length)
    return [...e];
  const a = [...e],
    [n] = a.splice(t, 1);
  return (a.splice(o, 0, n), a);
}
function ho(e, t, o) {
  return e.map((a, n) => (n === t ? { ...a, rotate: dt(a.rotate + o) } : a));
}
function po(e, t) {
  return e.filter((o, a) => a !== t);
}
const de = new RegExp("[\\p{L}\\p{N}]", "u"),
  la = new RegExp("[^\\p{L}]", "gu");
function Xt(e) {
  const t = e.split(/\s+/).filter((a) => de.test(a));
  if (t.length === 0) return 0;
  let o = 0;
  for (const a of t) {
    const n = a.replace(la, ""),
      r = /[{}|\\^~<>_[\]]/.test(
        a.replace(/^[[({"'“]+|[\])}"'”.,;:!?]+$/g, ""),
      ),
      i =
        n.length >= 4 &&
        !/[aeiouyàâäéèêëîïôöùûüáíóúñ]/i.test(n) &&
        /^[a-z]+$/i.test(n);
    (r || i) && o++;
  }
  return o / t.length;
}
function fa(e) {
  const t = e.text.split(/\s+/).filter((o) => de.test(o));
  return typeof e.confidence == "number" && e.confidence < 50
    ? !0
    : t.length < 3
      ? !1
      : Xt(e.text) > 0.4 ||
        (typeof e.confidence == "number" &&
          e.confidence < 62 &&
          Xt(e.text) > 0.2);
}
function ua(e) {
  const t = new Map(),
    o = new Set();
  return e.map((a) => {
    const n = a.toLowerCase();
    let r = (t.get(n) ?? 0) + 1,
      i = r === 1 ? a : `${a} (${r})`;
    for (; o.has(i.toLowerCase());) (r++, (i = `${a} (${r})`));
    return (t.set(n, r), o.add(i.toLowerCase()), i);
  });
}
function Mt(e) {
  return (
    e
      .replace(/\.pdf$/i, "")
      .replace(/[\\/:*?"<>|]/g, "_")
      .trim() || "document"
  );
}
function da(e, t, o, a) {
  if (o <= 1) return `${e}.${a}`;
  const n = Math.max(2, String(o).length);
  return `${e}-page-${String(t).padStart(n, "0")}.${a}`;
}
function ga(e) {
  return Array.from(new Set(e));
}
function mo(e) {
  return Math.round(e * 72);
}
function wo(e) {
  return `${e} page${e === 1 ? "" : "s"}`;
}
const ha = "/assets/jbig2-BHianOOZ.wasm";
function pa(e) {
  const t = () => new DataView(e().buffer),
    o = {
      fd_write: (n, r, i, f) => {
        const c = t();
        let s = 0;
        for (let l = 0; l < i; l++) s += c.getUint32(r + l * 8 + 4, !0);
        return (c.setUint32(f, s, !0), 0);
      },
      clock_time_get: (n, r, i) => {
        const f = t();
        return (f.setUint32(i, 0, !0), f.setUint32(i + 4, 0, !0), 0);
      },
      environ_sizes_get: (n, r) => {
        const i = t();
        return (i.setUint32(n, 0, !0), i.setUint32(r, 0, !0), 0);
      },
      environ_get: () => 0,
      args_sizes_get: (n, r) => {
        const i = t();
        return (i.setUint32(n, 0, !0), i.setUint32(r, 0, !0), 0);
      },
      args_get: () => 0,
      random_get: (n, r) => (new Uint8Array(e().buffer, n, r).fill(0), 0),
      proc_exit: () => {
        throw new Error("The JBIG2 encoder stopped unexpectedly.");
      },
      fd_close: () => 0,
      fd_prestat_get: () => 8,
      fd_prestat_dir_name: () => 8,
      fd_seek: () => 70,
      fd_fdstat_get: () => 8,
    };
  return {
    wasi_snapshot_preview1: new Proxy(o, { get: (n, r) => n[r] ?? (() => 52) }),
  };
}
async function ma(e) {
  let t;
  const o = pa(() => t),
    n = (await WebAssembly.instantiate(e, o)).instance.exports;
  ((t = n.memory), n._initialize?.());
  const r = () => new Uint8Array(n.memory.buffer),
    i = (s) => {
      const l = n.wasm_alloc(s.length);
      return (r().set(s, l), l);
    },
    f = () => r().slice(n.out_ptr(), n.out_ptr() + n.out_len());
  return {
    generic(s, l, u, d) {
      const g = i(s);
      try {
        n.enc_generic(g, l, u, d, d);
      } finally {
        n.wasm_free(g);
      }
      return f();
    },
    symbolBegin(s, l) {
      if (!n.sym_begin(s, l, l))
        throw new Error("JBIG2 symbol mode could not start");
    },
    symbolAdd(s, l, u) {
      const d = i(s);
      try {
        n.sym_add(d, l, u);
      } finally {
        n.wasm_free(d);
      }
    },
    symbolFinish() {
      return (
        n.sym_globals(),
        { globals: f(), page: (l) => (n.sym_page(l), f()) }
      );
    },
    symbolEnd() {
      n.sym_end();
    },
  };
}
function wa(e, t, o, a = 150) {
  const n = (t + 7) >> 3,
    r = new Uint8Array(n * o);
  for (let i = 0; i < o; i++) {
    const f = i * n,
      c = i * t * 4;
    for (let s = 0; s < t; s++) {
      const l = c + s * 4;
      e[l + 1] < a && (r[f + (s >> 3)] |= 128 >> (s & 7));
    }
  }
  return r;
}
let pt = null;
function ya(e) {
  if (pt) return pt;
  const t = (async () => {
    const o = await fetch(ha);
    if (!o.ok) throw new Error("Couldn't load the JBIG2 encoder");
    return ma(await o.arrayBuffer());
  })();
  return (
    (pt = t),
    t.catch(() => {
      pt = null;
    }),
    t
  );
}
const ba = [
    "00110101",
    "000111",
    "0111",
    "1000",
    "1011",
    "1100",
    "1110",
    "1111",
    "10011",
    "10100",
    "00111",
    "01000",
    "001000",
    "000011",
    "110100",
    "110101",
    "101010",
    "101011",
    "0100111",
    "0001100",
    "0001000",
    "0010111",
    "0000011",
    "0000100",
    "0101000",
    "0101011",
    "0010011",
    "0100100",
    "0011000",
    "00000010",
    "00000011",
    "00011010",
    "00011011",
    "00010010",
    "00010011",
    "00010100",
    "00010101",
    "00010110",
    "00010111",
    "00101000",
    "00101001",
    "00101010",
    "00101011",
    "00101100",
    "00101101",
    "00000100",
    "00000101",
    "00001010",
    "00001011",
    "01010010",
    "01010011",
    "01010100",
    "01010101",
    "00100100",
    "00100101",
    "01011000",
    "01011001",
    "01011010",
    "01011011",
    "01001010",
    "01001011",
    "00110010",
    "00110011",
    "00110100",
  ],
  Pa = [
    "0000110111",
    "010",
    "11",
    "10",
    "011",
    "0011",
    "0010",
    "00011",
    "000101",
    "000100",
    "0000100",
    "0000101",
    "0000111",
    "00000100",
    "00000111",
    "000011000",
    "0000010111",
    "0000011000",
    "0000001000",
    "00001100111",
    "00001101000",
    "00001101100",
    "00000110111",
    "00000101000",
    "00000010111",
    "00000011000",
    "000011001010",
    "000011001011",
    "000011001100",
    "000011001101",
    "000001101000",
    "000001101001",
    "000001101010",
    "000001101011",
    "000011010010",
    "000011010011",
    "000011010100",
    "000011010101",
    "000011010110",
    "000011010111",
    "000001101100",
    "000001101101",
    "000011011010",
    "000011011011",
    "000001010100",
    "000001010101",
    "000001010110",
    "000001010111",
    "000001100100",
    "000001100101",
    "000001010010",
    "000001010011",
    "000000100100",
    "000000110111",
    "000000111000",
    "000000100111",
    "000000101000",
    "000001011000",
    "000001011001",
    "000000101011",
    "000000101100",
    "000001011010",
    "000001100110",
    "000001100111",
  ],
  xa = [
    "11011",
    "10010",
    "010111",
    "0110111",
    "00110110",
    "00110111",
    "01100100",
    "01100101",
    "01101000",
    "01100111",
    "011001100",
    "011001101",
    "011010010",
    "011010011",
    "011010100",
    "011010101",
    "011010110",
    "011010111",
    "011011000",
    "011011001",
    "011011010",
    "011011011",
    "010011000",
    "010011001",
    "010011010",
    "011000",
    "010011011",
    "00000001000",
    "00000001100",
    "00000001101",
    "000000010010",
    "000000010011",
    "000000010100",
    "000000010101",
    "000000010110",
    "000000010111",
    "000000011100",
    "000000011101",
    "000000011110",
    "000000011111",
  ],
  _a = [
    "0000001111",
    "000011001000",
    "000011001001",
    "000001011011",
    "000000110011",
    "000000110100",
    "000000110101",
    "0000001101100",
    "0000001101101",
    "0000001001010",
    "0000001001011",
    "0000001001100",
    "0000001001101",
    "0000001110010",
    "0000001110011",
    "0000001110100",
    "0000001110101",
    "0000001110110",
    "0000001110111",
    "0000001010010",
    "0000001010011",
    "0000001010100",
    "0000001010101",
    "0000001011010",
    "0000001011011",
    "0000001100100",
    "0000001100101",
    "00000001000",
    "00000001100",
    "00000001101",
    "000000010010",
    "000000010011",
    "000000010100",
    "000000010101",
    "000000010110",
    "000000010111",
    "000000011100",
    "000000011101",
    "000000011110",
    "000000011111",
  ];
class ka {
  constructor() {
    ((this.out = []), (this.cur = 0), (this.n = 0));
  }
  put(t) {
    for (let o = 0; o < t.length; o++)
      ((this.cur = (this.cur << 1) | (t.charCodeAt(o) - 48)),
        ++this.n === 8 &&
          (this.out.push(this.cur), (this.cur = 0), (this.n = 0)));
  }
  finish() {
    return (
      this.n && this.out.push(this.cur << (8 - this.n)),
      Uint8Array.from(this.out)
    );
  }
}
function qt(e, t, o) {
  const a = o ? _a : xa,
    n = o ? Pa : ba;
  for (; t >= 2560;) (e.put(a[39]), (t -= 2560));
  if (t >= 64) {
    const r = Math.floor(t / 64);
    (e.put(r <= 27 ? a[r - 1] : a[27 + (r - 28)]), (t -= r * 64));
  }
  e.put(n[t]);
}
function va(e, t, o) {
  const a = new ka();
  let n = new Uint8Array(t);
  for (let r = 0; r < o; r++) {
    const i = e.subarray(r * t, (r + 1) * t),
      f = (l, u) => (u < 0 ? 0 : l[u] ? 1 : 0);
    let c = -1,
      s = 0;
    for (; c < t;) {
      let l = c + 1;
      for (; l < t && f(i, l) === s;) l++;
      let u = c + 1;
      for (; u < t && !(f(n, u) !== s && f(n, u - 1) === s);) u++;
      let d = u + 1;
      for (; d < t && f(n, d) !== s;) d++;
      if (((u >= t || d > t) && (d = t), d < l)) {
        (a.put("0001"), (c = d));
        continue;
      }
      const g = l - u;
      if (g >= -3 && g <= 3) {
        (a.put(
          ["0000010", "000010", "010", "1", "011", "000011", "0000011"][g + 3],
        ),
          (c = l),
          (s ^= 1));
        continue;
      }
      let h = l + 1;
      for (; h < t && f(i, h) !== s;) h++;
      ((l >= t || h > t) && (h = t),
        a.put("001"),
        qt(a, l - Math.max(c, 0), s === 1),
        qt(a, h - l, s === 0),
        (c = h));
    }
    n = i;
  }
  return (a.put("000000000001000000000001"), a.finish());
}
function Ta(e) {
  const t = e.context,
    o = e.getPages(),
    a = [],
    n = new Map(),
    r = new Map(),
    i = new Set(["Parent", "P", "Prev", "Next", "First", "Last", "Dest", "D"]);
  for (const f of o) {
    const c = new Set(),
      s = [f.node];
    for (; s.length;) {
      const l = s.pop();
      let u = l;
      if (l instanceof ct) {
        const d = l.toString();
        if (c.has(d)) continue;
        (c.add(d),
          (u = t.lookup(l)),
          u instanceof bt &&
            !n.has(d) &&
            n.set(
              d,
              u instanceof ie ? u.contents.length : u.getContentsSize(),
            ));
      }
      if (u) {
        if (u instanceof tt)
          for (const [d, g] of u.entries()) i.has(d.decodeText()) || s.push(g);
        else if (u instanceof bt)
          for (const [d, g] of u.dict.entries())
            i.has(d.decodeText()) || s.push(g);
        else if (u instanceof rt)
          for (let d = 0; d < u.size(); d++) s.push(u.get(d));
      }
    }
    (a.push(c), c.forEach((l) => r.set(l, (r.get(l) ?? 0) + 1)));
  }
  return a.map((f) => {
    let c = 400;
    return (
      f.forEach((s) => {
        const l = n.get(s);
        l && (c += l / (r.get(s) ?? 1));
      }),
      Math.round(c)
    );
  });
}
const Ot = 250,
  lt = 0.1;
function Ea(e, t, o) {
  const a = {
    Type: "XObject",
    Subtype: "Image",
    Width: t.w,
    Height: t.h,
    ColorSpace: "DeviceGray",
    BitsPerComponent: 1,
    Filter: "JBIG2Decode",
  };
  if (t.globals) {
    let n = o.get(t.globals);
    (n ||
      ((n = e.context.register(e.context.stream(t.globals, {}))),
      o.set(t.globals, n)),
      (a.DecodeParms = { JBIG2Globals: n }));
  }
  return e.context.register(e.context.stream(t.data, a));
}
const Ma = 10,
  Sa = 20,
  Jt = 24,
  Aa = 238,
  Ia = 24;
function ot(e, t) {
  return (e[t] * 299 + e[t + 1] * 587 + e[t + 2] * 114) / 1e3;
}
function vt(e, t) {
  if (ot(e, t) < Aa) return !0;
  const o = Math.max(e[t], e[t + 1], e[t + 2]),
    a = Math.min(e[t], e[t + 1], e[t + 2]);
  return o - a > Ia;
}
function Da(e, t, o, a, n, r) {
  const i = new Array(32).fill(0);
  let f = 0,
    c = 0,
    s = 0,
    l = 0,
    u = 0,
    d = 0,
    g = 0,
    h = 0;
  for (let x = a; x < r; x++)
    for (let R = o; R < n; R++) {
      const _ = (x * t + R) * 4,
        L = ot(e, _);
      (i[Math.min(31, L >> 3)]++,
        f++,
        (h += L),
        (g += L * L),
        (l += e[_]),
        (u += e[_ + 1]),
        (d += e[_ + 2]),
        vt(e, _) && c++,
        ((R + 1 < n && Math.abs(L - ot(e, _ + 4)) > 40) ||
          (x + 1 < r && Math.abs(L - ot(e, _ + t * 4)) > 40)) &&
          s++);
    }
  if (!f) return { kind: "blank" };
  if (c / f < 0.004) return { kind: "blank" };
  let m = 0,
    b = 0,
    O = 31;
  for (let x = 0; x < 32; x++)
    if (((m += i[x]), m >= f * 0.02)) {
      b = x;
      break;
    }
  m = 0;
  for (let x = 31; x >= 0; x--)
    if (((m += i[x]), m >= f * 0.02)) {
      O = x;
      break;
    }
  if (
    Math.sqrt(Math.max(0, g / f - (h / f) * (h / f))) <= 3.5 &&
    O - b <= 2 &&
    s / f < 0.002
  )
    return {
      kind: "background",
      color: [Math.round(l / f), Math.round(u / f), Math.round(d / f)],
    };
  const P = ge(i, f, s, c);
  if (P === "text") return { kind: "text" };
  const p = (o + n) >> 1,
    M = (a + r) >> 1,
    j = [];
  for (const [x, R, _, L] of [
    [o, a, p, M],
    [p, a, n, M],
    [o, M, p, r],
    [p, M, n, r],
  ])
    j.push(Fa(e, t, x, R, _, L));
  const I = j.includes("text"),
    A = j.includes("photo");
  return I && A
    ? { kind: "mixed" }
    : P === "photo"
      ? { kind: "image" }
      : { kind: "mixed" };
}
function ge(e, t, o, a) {
  let n = 0;
  for (let i = 0; i < 32; i++) e[i] >= t * 0.01 && n++;
  const r = o / t;
  return n <= 7 && (r >= 0.01 || a / t < 0.05)
    ? "text"
    : r < 0.03
      ? "photo"
      : n <= 7
        ? "text"
        : "other";
}
function Fa(e, t, o, a, n, r) {
  const i = new Array(32).fill(0);
  let f = 0,
    c = 0,
    s = 0;
  for (let l = a; l < r; l++)
    for (let u = o; u < n; u++) {
      const d = (l * t + u) * 4,
        g = ot(e, d);
      (i[Math.min(31, g >> 3)]++,
        f++,
        vt(e, d) && c++,
        ((u + 1 < n && Math.abs(g - ot(e, d + 4)) > 40) ||
          (l + 1 < r && Math.abs(g - ot(e, d + t * 4)) > 40)) &&
          s++);
    }
  return !f || c / f < 0.004 ? "empty" : ge(i, f, s, c);
}
function $a(e, t, o, a, n, r) {
  const i = (s) =>
      e[s] === "background"
        ? `background:${(t[s] ?? [255, 255, 255]).map((l) => l >> 4).join(",")}`
        : e[s],
    f = new Map(),
    c = [];
  for (let s = 0; s < a; s++) {
    const l = new Map();
    let u = 0;
    for (; u < o;) {
      const d = s * o + u;
      if (e[d] === "blank") {
        u++;
        continue;
      }
      const g = i(d);
      let h = u + 1;
      for (; h < o && e[s * o + h] !== "blank" && i(s * o + h) === g;) h++;
      const m = `${g}|${u}|${h}`,
        b = f.get(m);
      (b
        ? ((b.r1 = s + 1), l.set(m, b), f.delete(m))
        : l.set(m, {
            c0: u,
            c1: h,
            r0: s,
            r1: s + 1,
            key: g,
            kind: e[d],
            color: t[d],
          }),
        (u = h));
    }
    (f.forEach((d) => c.push(d)), f.clear(), l.forEach((d, g) => f.set(g, d)));
  }
  return (
    f.forEach((s) => c.push(s)),
    Ca(
      c.map((s) => ({
        x0: n[s.c0],
        x1: n[s.c1],
        y0: r[s.r0],
        y1: r[s.r1],
        kind: s.kind,
        color: s.color,
      })),
    )
  );
}
const La = 2.5,
  Oa = (e, t) => e.x0 < t.x1 && t.x0 < e.x1 && e.y0 < t.y1 && t.y0 < e.y1,
  St = (e) => (e.x1 - e.x0) * (e.y1 - e.y0);
function Ca(e) {
  const t = e.slice();
  for (;;) {
    let o = null;
    for (let a = 0; a < t.length; a++)
      if (t[a].kind !== "background")
        for (let n = a + 1; n < t.length; n++) {
          if (t[n].kind !== t[a].kind) continue;
          const r = {
              kind: t[a].kind,
              x0: Math.min(t[a].x0, t[n].x0),
              y0: Math.min(t[a].y0, t[n].y0),
              x1: Math.max(t[a].x1, t[n].x1),
              y1: Math.max(t[a].y1, t[n].y1),
            },
            i = St(r) / (St(t[a]) + St(t[n]));
          i > La ||
            (o && i >= o.growth) ||
            t.some((f, c) => c !== a && c !== n && Oa(r, f)) ||
            (o = { i: a, j: n, growth: i, u: r });
        }
    if (!o) return t;
    (t.splice(o.j, 1), (t[o.i] = o.u));
  }
}
function Ra(e, t, o) {
  const a = new Uint32Array(o),
    n = new Uint32Array(t);
  for (let p = 0; p < o; p++)
    for (let M = 0; M < t; M++) vt(e, (p * t + M) * 4) && (a[p]++, n[M]++);
  const r = (p) => p.findIndex((M) => M >= 3),
    i = (p) => {
      for (let M = p.length - 1; M >= 0; M--) if (p[M] >= 3) return M;
      return -1;
    },
    f = r(n),
    c = i(n) + 1,
    s = r(a),
    l = i(a) + 1;
  if (f < 0 || s < 0 || c <= f || l <= s)
    return {
      width: t,
      height: o,
      content: null,
      cols: 0,
      rows: 0,
      kinds: [],
      rects: [],
    };
  const u = c - f,
    d = l - s,
    g = Math.max(1, Math.min(Ma, Math.floor(u / Jt))),
    h = Math.max(1, Math.min(Sa, Math.floor(d / Jt))),
    m = Array.from({ length: g + 1 }, (p, M) => Math.round(f + (M * u) / g)),
    b = Array.from({ length: h + 1 }, (p, M) => Math.round(s + (M * d) / h)),
    O = [],
    D = [];
  for (let p = 0; p < h; p++)
    for (let M = 0; M < g; M++) {
      const j = Da(e, t, m[M], b[p], m[M + 1], b[p + 1]);
      (O.push(j.kind), D.push(j.color));
    }
  Va(O, D, g, h);
  const P = $a(O, D, g, h, m, b).map((p) =>
    p.kind === "text" && Ua(e, t, p) ? { ...p, kind: "fine" } : p,
  );
  return {
    width: t,
    height: o,
    content: { x0: f, y0: s, x1: c, y1: l },
    cols: g,
    rows: h,
    kinds: O,
    rects: P,
  };
}
function Ba(e, t, o, a, n, r) {
  const i = (n - o) * (r - a);
  if (i <= 0) return !0;
  const f = Math.max(1, Math.floor(i * 0.004));
  let c = 0;
  for (let s = a; s < r; s++)
    for (let l = o; l < n; l++)
      if (vt(e, (s * t + l) * 4) && ++c > f) return !1;
  return !0;
}
function At(e, t, o, a, n) {
  const r = [];
  for (let i = 0; i < n; i++)
    for (let f = 0; f < a; f++) {
      const c = Math.round((f * t) / a),
        s = Math.round(((f + 1) * t) / a),
        l = Math.round((i * o) / n),
        u = Math.round(((i + 1) * o) / n);
      Ba(e, t, c, l, s, u) || r.push({ x0: c, y0: l, x1: s, y1: u });
    }
  return r;
}
function Na(e) {
  for (let t = 0; t < e.length; t += 4) {
    const o = Math.max(e[t], e[t + 1], e[t + 2]),
      a = Math.min(e[t], e[t + 1], e[t + 2]);
    a >= 215 && o - a <= 28 && (e[t] = e[t + 1] = e[t + 2] = 255);
  }
}
const he = 200,
  za = 31;
function ja(e, t, o) {
  const a = o.y1 - o.y0,
    n = new Float64Array(a);
  for (let c = 0; c < a; c++) {
    let s = 0;
    for (let l = o.x0; l < o.x1; l++)
      ot(e, ((o.y0 + c) * t + l) * 4) < 160 && s++;
    n[c] = s;
  }
  let r = 0;
  for (let c = 0; c < a; c++) r += n[c];
  r /= a || 1;
  let i = 0;
  for (let c = 0; c < a; c++) ((n[c] -= r), (i += n[c] * n[c]));
  if (i <= 0) return { pitch: 0, strength: 0 };
  let f = { pitch: 0, strength: 0 };
  for (let c = 10; c <= Math.min(120, Math.floor(a / 2)); c++) {
    let s = 0;
    for (let u = 0; u + c < a; u++) s += n[u] * n[u + c];
    const l = s / i;
    l > f.strength && (f = { pitch: c, strength: l });
  }
  return f;
}
function Ua(e, t, o) {
  const a = o.y1 - o.y0;
  if (a < 60) return !1;
  const { pitch: n, strength: r } = ja(e, t, o);
  return r >= 0.3 ? n < za : a >= 200;
}
const pe = (e) => e / he,
  Y = (e, t) => ({ ratio: pe(e), quality: t }),
  mt = {
    image: Y(140, 0.8),
    mixed: Y(140, 0.8),
    text: Y(140, 0.8),
    fine: Y(140, 0.85),
  },
  Kt = [
    {
      name: "Remaining areas at 140 dpi",
      detail: "Every area that still holds something is stored at 140 dpi.",
      stage: { flat: pe(140), ...mt },
    },
    {
      name: "Flat-colour areas as plain fills",
      detail:
        "Areas of one even colour are not stored as pictures any more; they are drawn as a filled rectangle.",
      stage: { flat: "fill", ...mt },
    },
    {
      name: "Photo and shaded areas at 70 dpi",
      detail: "Areas where colour varies (photos, shading) drop to 70 dpi.",
      stage: { flat: "fill", ...mt, image: Y(70, 0.65) },
    },
    {
      name: "Text-with-picture areas at 100 dpi",
      detail: "Areas that mix text and colour drop to 100 dpi.",
      stage: { flat: "fill", ...mt, image: Y(70, 0.65), mixed: Y(100, 0.8) },
    },
    {
      name: "Text areas at 100 dpi (small print and math at 120 dpi)",
      detail:
        "Plain text drops to 100 dpi. Small print and math areas drop to 120 dpi so they stay readable.",
      stage: {
        flat: "fill",
        image: Y(70, 0.65),
        mixed: Y(100, 0.8),
        text: Y(100, 0.8),
        fine: Y(120, 0.85),
      },
    },
    {
      name: "Text areas at 85 dpi (final level)",
      detail:
        "Plain text drops to 85 dpi, the lowest that is still readable. Small print and math stay at 120 dpi.",
      stage: {
        flat: "fill",
        image: Y(70, 0.65),
        mixed: Y(100, 0.8),
        text: Y(85, 0.8),
        fine: Y(120, 0.85),
      },
    },
  ];
function Yt(e, t) {
  return t === "background"
    ? e.flat === "fill"
      ? "fill"
      : { ratio: e.flat, quality: 0.7 }
    : t === "image"
      ? e.image
      : t === "mixed"
        ? e.mixed
        : t === "text"
          ? e.text
          : t === "fine"
            ? e.fine
            : null;
}
const Wa = 6;
function Va(e, t, o, a) {
  const n = (i) => (t[i] ?? [255, 255, 255]).map((f) => f >> 4).join(","),
    r = new Uint8Array(e.length);
  for (let i = 0; i < e.length; i++) {
    if (r[i] || e[i] !== "background") continue;
    const f = n(i),
      c = [],
      s = [i];
    for (r[i] = 1; s.length;) {
      const l = s.pop();
      c.push(l);
      const u = Math.floor(l / o),
        d = l % o;
      for (const [g, h] of [
        [u - 1, d],
        [u + 1, d],
        [u, d - 1],
        [u, d + 1],
      ]) {
        if (g < 0 || g >= a || h < 0 || h >= o) continue;
        const m = g * o + h;
        !r[m] && e[m] === "background" && n(m) === f && ((r[m] = 1), s.push(m));
      }
    }
    if (c.length < Wa) for (const l of c) ((e[l] = "image"), (t[l] = void 0));
  }
}
async function It(e, t, o, a, n) {
  const r = o.x1 - o.x0,
    i = o.y1 - o.y0,
    f = e.makeCanvas(
      Math.max(1, Math.round(r * a)),
      Math.max(1, Math.round(i * a)),
    ),
    c = f.getContext("2d");
  if (!c) throw new Error("Canvas not supported in this browser");
  ((c.fillStyle = "#fff"),
    c.fillRect(0, 0, f.width, f.height),
    c.drawImage(t, o.x0, o.y0, r, i, 0, 0, f.width, f.height));
  const s = await e.jpeg(f, n);
  return ((f.width = f.height = 0), s);
}
const Ga = 120,
  Ha = 30,
  Zt = (e, t, o) => `${e}:${t}:${o}`;
function ft(e) {
  if (!e.seen || !e.pieces) return 1 / 0;
  let t = Ot;
  for (const o of e.pieces)
    t += o.g4
      ? o.g4.data.length + 200
      : o.jb2
        ? o.jb2.data.length + 200
        : o.jpg
          ? o.jpg.length + Ga
          : Ha;
  return t;
}
const Xa = {
    name: "Pages as pictures, empty quarters dropped",
    detail:
      "Each remaining page is turned into a 200 dpi picture and cut into 4 quarters. Quarters with nothing in them are not stored at all. Text can no longer be selected on these pages.",
  },
  qa = {
    name: "Pages split finer, empty areas dropped",
    detail:
      "The quarters that still hold something are cut again into 4, and the empty pieces are dropped.",
  },
  ut = [
    {
      dpi: 150,
      name: "Black-and-white pages at 150 dpi",
      detail:
        "Pages are stored as pure black and white (a format about ten times smaller than a picture for text). Shades of grey and colour are lost, so check that the pages still look right.",
    },
    {
      dpi: 120,
      name: "Black-and-white pages at 120 dpi",
      detail:
        "The same black-and-white pages at 120 dpi. Small print gets rough; stop at the level before if it is hard to read.",
    },
  ],
  Ja = {
    name: "Paper speckle cleaned",
    detail:
      "Scanner dust, shadows and faint paper tint are set to plain white so empty areas can be dropped completely.",
  },
  Qt = {
    name: "Greyscale pages at 70 dpi",
    detail:
      "Every page becomes a grey picture at 70 dpi: colour is lost and small print gets soft, but shading stays. Text can no longer be selected.",
  },
  te = {
    name: "Black and white, lossless (JBIG2)",
    detail:
      "Pages are stored as pure black and white at 150 dpi, exactly as read, with no guessing. Colour, shading and photos are lost, so check that the pages still look right.",
  },
  ee = {
    name: "Black and white, smallest (JBIG2)",
    detail:
      "Letters that look alike are stored once and reused, which makes the file much smaller. Very rarely a letter can be swapped for a look-alike one, so read important numbers in the original. Colour, shading and photos are lost.",
  };
async function Ka(e, t) {
  const o = () => {
      if (t.shouldStop?.()) throw new $t();
    },
    a = await e.open(),
    n = a.numPages,
    r = await U.load(t.base, {
      ignoreEncryption: !0,
      updateMetadata: !1,
      throwOnInvalidObject: !1,
    }),
    i = Ta(r),
    f = [];
  for (let _ = 1; _ <= n; _++) {
    const L = (await a.getPage(_)).getViewport({ scale: 1 });
    f.push({ width: L.width, height: L.height });
  }
  const c = he / 72,
    s = Array.from({ length: n }, () => ({
      w: 1,
      h: 1,
      seen: !1,
      grid: null,
      pieces: null,
      enc: new Map(),
    }));
  let l = t.firstLevel,
    u = null;
  const d = () => (u ? u.size : Math.min(t.base.length, t.mustBeat)),
    g = () => !!u && u.size <= t.goal,
    h = (_) => ft(s[_]) < i[_] * (1 - lt),
    m = async () => {
      const _ = s.map((N, w) => h(w)),
        L = _.filter(Boolean).length;
      if (!L) return null;
      const S = [];
      _.forEach((N, w) => {
        N || S.push(w);
      });
      const F = await U.create(),
        B = S.length ? await F.copyPages(r, S) : [],
        z = new Map();
      let V = 0;
      for (let N = 0; N < n; N++) {
        if (!_[N]) {
          F.addPage(B[V++]);
          continue;
        }
        const w = s[N],
          v = f[N],
          E = F.addPage([v.width, v.height]),
          T = v.width / w.w,
          y = v.height / w.h,
          $ = (k) => ({
            x: k.x0 * T,
            y: v.height - k.y1 * y - 0.3,
            width: (k.x1 - k.x0) * T + 0.3,
            height: (k.y1 - k.y0) * y + 0.3,
          }),
          C = (k, W) => {
            const H = E.node.newXObject("Bw", k),
              Z = $(W);
            E.pushOperators(
              Ae(),
              Ie(Z.width, 0, 0, Z.height, Z.x, Z.y),
              De(H),
              Fe(),
            );
          };
        for (const k of w.pieces)
          k.fill &&
            E.drawRectangle({
              ...$(k.r),
              color: ce(k.fill[0] / 255, k.fill[1] / 255, k.fill[2] / 255),
              borderWidth: 0,
            });
        for (const k of w.pieces)
          k.jpg && E.drawImage(await F.embedJpg(k.jpg), $(k.r));
        for (const k of w.pieces)
          k.g4 &&
            C(
              F.context.register(
                F.context.stream(k.g4.data, {
                  Type: "XObject",
                  Subtype: "Image",
                  Width: k.g4.w,
                  Height: k.g4.h,
                  ColorSpace: "DeviceGray",
                  BitsPerComponent: 1,
                  Filter: "CCITTFaxDecode",
                  DecodeParms: { K: -1, Columns: k.g4.w, Rows: k.g4.h },
                }),
              ),
              k.r,
            );
        for (const k of w.pieces) k.jb2 && C(Ea(F, k.jb2, z), k.r);
      }
      return (
        t.stamp?.(F),
        {
          bytes: new Uint8Array(await F.save({ useObjectStreams: !0 })),
          converted: L,
        }
      );
    },
    b = async (_) => {
      (o(), t.onProgress?.(`Building level ${l}: ${_.name}...`));
      const L = await m();
      if (!L) return !1;
      const { bytes: S, converted: F } = L;
      return S.length >= d() * 0.995
        ? !1
        : ((u = {
            bytes: S,
            size: S.length,
            pagesConverted: F,
            pagesKept: n - F,
          }),
          t.onLevel?.({
            level: l,
            name: _.name,
            detail: _.detail,
            bytes: S,
            size: S.length,
            turnsPagesToPictures: !0,
            pagesConverted: F,
            pagesKept: n - F,
          }),
          l++,
          !0);
    },
    O = (_) => _.getContext("2d").getImageData(0, 0, _.width, _.height).data,
    D = (_) => {
      _.width = _.height = 0;
    },
    P = async (_, L) => {
      const S = [];
      for (const F of L) S.push({ r: F, jpg: await It(e, _, F, 1, 0.85) });
      return S;
    },
    p = i.map((_, L) => L).sort((_, L) => i[L] - i[_]),
    M = async () => {
      let L = 0,
        S = 0;
      for (const v of p) {
        if ((o(), L >= 12)) break;
        if (i[v] < 1500) continue;
        (S++,
          t.onProgress?.(
            `Turning pages into pictures: ${S} done (heaviest pages first)...`,
          ));
        const E = await a.renderCanvas(v + 1, c),
          T = O(E),
          y = At(T, E.width, E.height, 2, 2),
          $ = await P(E, y);
        ((s[v] = {
          w: E.width,
          h: E.height,
          seen: !0,
          grid: null,
          pieces: $,
          enc: new Map(),
        }),
          D(E),
          (L = ft(s[v]) * 0.25 > i[v] * (1 - lt) ? L + 1 : 0));
      }
      const F = () =>
        s
          .map((v, E) => (v.seen && ft(v) * 0.25 < i[E] * (1 - lt) ? E : -1))
          .filter((v) => v >= 0);
      if ((await b(Xa), g())) return;
      const B = F();
      if (!B.length) return;
      const z = async (v, E, T) => {
        for (const y of B) {
          (o(), t.onProgress?.(`${v}: page ${y + 1} of ${n}...`));
          const $ = await a.renderCanvas(y + 1, c),
            C = O($);
          (E && Na(C), await T(y, $, C), D($));
        }
      };
      let V = 0,
        N = 0;
      if (
        (await z("Splitting pages finer", !1, async (v, E, T) => {
          const y = At(T, E.width, E.height, 4, 4);
          ((V += y.length), (N += 16), (s[v].pieces = await P(E, y)));
        }),
        await b(qa),
        g())
      )
        return;
      let w = !1;
      if (N && V / N >= 0.8) {
        const v = B.reduce((T, y) => T + ft(s[y]), 0);
        if (
          (await z("Cleaning scanned paper", !0, async (T, y, $) => {
            const C = At($, y.width, y.height, 4, 4);
            s[T].pieces = await P(y, C);
          }),
          B.reduce((T, y) => T + ft(s[y]), 0) < v * 0.95 &&
            ((w = !0), await b(Ja), g()))
        )
          return;
      }
      await z("Studying page areas", w, async (v, E, T) => {
        const y = Ra(T, E.width, E.height),
          $ = s[v];
        $.grid = y;
        for (const C of Kt)
          for (let k = 0; k < y.rects.length; k++) {
            const W = Yt(C.stage, y.rects[k].kind);
            if (!W || W === "fill") continue;
            const H = Zt(k, W.ratio, W.quality);
            $.enc.has(H) ||
              $.enc.set(H, await It(e, E, y.rects[k], W.ratio, W.quality));
          }
      });
      for (const v of Kt) {
        for (const E of B) {
          const T = s[E],
            y = [];
          (T.grid.rects.forEach(($, C) => {
            const k = Yt(v.stage, $.kind);
            k &&
              (k === "fill"
                ? y.push({ r: $, fill: $.color ?? [255, 255, 255] })
                : y.push({ r: $, jpg: T.enc.get(Zt(C, k.ratio, k.quality)) }));
          }),
            (T.pieces = y));
        }
        if ((await b(v), g())) return;
      }
    },
    j = async () => {
      let L = 0,
        S = 0;
      const F = new Map();
      for (const B of p) {
        if ((o(), L >= 12)) break;
        if (i[B] < 3e3) continue;
        (S++,
          t.onProgress?.(
            `Trying black-and-white pages: ${S} done (heaviest pages first)...`,
          ));
        const z = await a.renderCanvas(B + 1, ut[0].dpi / 72),
          V = [];
        for (const w of ut) {
          const v = w.dpi / ut[0].dpi,
            E = e.makeCanvas(
              Math.max(1, Math.round(z.width * v)),
              Math.max(1, Math.round(z.height * v)),
            ),
            T = E.getContext("2d");
          ((T.imageSmoothingQuality = "high"),
            (T.fillStyle = "#fff"),
            T.fillRect(0, 0, E.width, E.height),
            T.drawImage(z, 0, 0, E.width, E.height));
          const y = T.getImageData(0, 0, E.width, E.height).data,
            $ = new Uint8Array(E.width * E.height);
          for (let C = 0; C < $.length; C++) $[C] = y[C * 4 + 1] < 150 ? 1 : 0;
          (V.push({
            dpi: w.dpi,
            g4: { data: va($, E.width, E.height), w: E.width, h: E.height },
          }),
            D(E));
        }
        (D(z),
          F.set(B, V),
          (L =
            V[V.length - 1].g4.data.length + Ot + 200 >= i[B] * (1 - lt)
              ? L + 1
              : 0));
      }
      for (let B = 0; B < ut.length; B++) {
        for (let z = 0; z < n; z++) {
          const V = s[z],
            N = F.get(z)?.[B];
          if (!N) {
            ((V.seen = !1), (V.pieces = null));
            continue;
          }
          ((V.seen = !0),
            (V.w = N.g4.w),
            (V.h = N.g4.h),
            (V.pieces = [
              { r: { x0: 0, y0: 0, x1: N.g4.w, y1: N.g4.h }, g4: N.g4 },
            ]));
        }
        if ((await b(ut[B]), g())) return;
      }
    },
    I = 150,
    A = 70,
    x = (_, L, S, F) =>
      S.length >= t.mustBeat * 0.995
        ? !1
        : ((!u || S.length < u.size) &&
            (u = {
              bytes: S,
              size: S.length,
              pagesConverted: F,
              pagesKept: n - F,
            }),
          t.onLevel?.({
            level: l,
            name: _,
            detail: L,
            bytes: S,
            size: S.length,
            turnsPagesToPictures: !0,
            pagesConverted: F,
            pagesKept: n - F,
          }),
          l++,
          !0),
    R = async () => {
      let _;
      try {
        _ = await e.loadJbig2();
      } catch {
        return !1;
      }
      const L = 12;
      let S = 0,
        F = 0;
      const B = new Map(),
        z = new Map(),
        V = new Map();
      for (const T of p) {
        if ((o(), S >= L)) break;
        if (i[T] < 3e3) continue;
        (F++,
          t.onProgress?.(
            `Extreme steps: ${F} pages done (heaviest pages first)...`,
          ));
        const y = await a.renderCanvas(T + 1, I / 72),
          $ = y.width,
          C = y.height,
          k = wa(O(y), $, C, 150),
          W = _.generic(k, $, C, I);
        (B.set(T, { bits: k, w: $, h: C }), z.set(T, W));
        const H = y.getContext("2d"),
          Z = H.getImageData(0, 0, $, C),
          J = Z.data;
        for (let X = 0; X < J.length; X += 4) {
          const it = (J[X] * 77 + J[X + 1] * 151 + J[X + 2] * 28) >> 8;
          J[X] = J[X + 1] = J[X + 2] = it;
        }
        (H.putImageData(Z, 0, 0),
          V.set(T, {
            jpg: await It(e, y, { x0: 0, y0: 0, x1: $, y1: C }, A / I, 0.5),
            w: Math.round(($ * A) / I),
            h: Math.round((C * A) / I),
          }),
          D(y),
          (S = W.length + Ot + 200 >= i[T] * (1 - lt) ? S + 1 : 0));
      }
      if (!B.size) return !1;
      const N = (T) => {
          for (let y = 0; y < n; y++) {
            const $ = B.get(y),
              C = $ ? T(y) : null,
              k = s[y];
            if (!$ || !C) {
              ((k.seen = !1), (k.pieces = null));
              continue;
            }
            ((k.seen = !0), (k.w = C.r.x1), (k.h = C.r.y1), (k.pieces = [C]));
          }
        },
        w = [],
        v = async (T, y) => {
          o();
          const $ = await m();
          $ &&
            w.push({
              name: T,
              detail: y,
              bytes: $.bytes,
              converted: $.converted,
            });
        };
      (t.onProgress?.("Building the greyscale file..."),
        N((T) => {
          const y = V.get(T);
          return { r: { x0: 0, y0: 0, x1: y.w, y1: y.h }, jpg: y.jpg };
        }),
        await v(Qt.name, Qt.detail),
        t.onProgress?.("Building the lossless black-and-white file..."),
        N((T) => {
          const y = B.get(T);
          return {
            r: { x0: 0, y0: 0, x1: y.w, y1: y.h },
            jb2: { data: z.get(T), w: y.w, h: y.h },
          };
        }),
        await v(te.name, te.detail),
        t.onProgress?.(
          "Building the smallest black-and-white file (shared letter shapes)...",
        ));
      try {
        const T = Array.from(B.keys())
          .filter((y) => s[y].seen && h(y))
          .sort((y, $) => y - $);
        if (T.length) {
          _.symbolBegin(0.85, I);
          for (const W of T) {
            const H = B.get(W);
            (o(), _.symbolAdd(H.bits, H.w, H.h));
          }
          const { globals: y, page: $ } = _.symbolFinish(),
            C = T.map((W, H) => $(H));
          _.symbolEnd();
          const k = new Map(T.map((W, H) => [W, H]));
          (N((W) => {
            const H = k.get(W);
            if (H === void 0) return null;
            const Z = B.get(W);
            return {
              r: { x0: 0, y0: 0, x1: Z.w, y1: Z.h },
              jb2: { data: C[H], w: Z.w, h: Z.h, globals: y },
            };
          }),
            await v(ee.name, ee.detail));
        }
      } catch (T) {
        if (T instanceof $t) throw T;
      }
      w.sort((T, y) => y.bytes.length - T.bytes.length);
      let E = !1;
      for (const T of w) x(T.name, T.detail, T.bytes, T.converted) && (E = !0);
      return E;
    };
  return (await M(), t.extreme && !g() && !(await R()) && (await j()), u);
}
function Ya(e) {
  const t = e.context,
    o = new Set(),
    a = [],
    n = t.trailerInfo.Root,
    r = t.trailerInfo.Info;
  for (n && a.push(n), r && a.push(r); a.length;) {
    const i = a.pop();
    let f = i;
    if (i instanceof ct) {
      const c = i.toString();
      if (o.has(c)) continue;
      (o.add(c), (f = t.lookup(i)));
    }
    if (f) {
      if (f instanceof tt) for (const c of f.values()) a.push(c);
      else if (f instanceof bt) for (const c of f.dict.values()) a.push(c);
      else if (f instanceof rt)
        for (let c = 0; c < f.size(); c++) a.push(f.get(c));
    }
  }
  for (const [i] of t.enumerateIndirectObjects())
    o.has(i.toString()) || t.delete(i);
}
async function Za(e, t, o) {
  const a = await U.load(e, {
      ignoreEncryption: !0,
      updateMetadata: !1,
      throwOnInvalidObject: !1,
    }),
    n = a.getPages();
  for (const r of t) {
    const i = n[r].node;
    (i.set(G.of("Contents"), a.context.register(a.context.stream(""))),
      i.set(G.of("Resources"), a.context.obj({})));
  }
  return (Ya(a), new Uint8Array(await a.save({ useObjectStreams: !0 })));
}
async function Qa(e, t) {
  return new Promise((o, a) => {
    e.toBlob(
      (n) => (n ? o(n) : a(new Error("Canvas encoding failed"))),
      "image/jpeg",
      t,
    );
  });
}
async function tn(e, t, o) {
  const a = await e.getPage(t),
    n = a.getViewport({ scale: o }),
    r = document.createElement("canvas");
  ((r.width = Math.max(1, Math.round(n.width))),
    (r.height = Math.max(1, Math.round(n.height))));
  const i = r.getContext("2d");
  if (!i) throw new Error("Canvas not supported in this browser");
  return (
    (i.fillStyle = "#fff"),
    i.fillRect(0, 0, r.width, r.height),
    await a.render({
      canvasContext: i,
      viewport: n,
      canvas: r,
      intent: "print",
    }).promise,
    r
  );
}
function en(e) {
  return {
    async open() {
      const t = await kt(e);
      return {
        numPages: t.numPages,
        getPage: (o) => t.getPage(o),
        renderCanvas: (o, a) => tn(t, o, a),
      };
    },
    makeCanvas(t, o) {
      const a = document.createElement("canvas");
      return ((a.width = t), (a.height = o), a);
    },
    async jpeg(t, o) {
      return new Uint8Array(await (await Qa(t, o)).arrayBuffer());
    },
    loadJbig2: () => ya(),
  };
}
function an(e, t = qe) {
  return { ...en(e), codec: t, ops: We };
}
function yo(e) {
  const t =
    e.limit === "extreme"
      ? "turn pages into pictures, then grey, then black and white"
      : "turn pages into pictures";
  return e.kind === "already-small"
    ? `Stopped at level ${e.level}: the file is already ${e.savedPercent}% smaller, and the next levels would ${t}, so text and colour would be lost.`
    : `${e.limit === "extreme" ? "The heavier levels (pages as pictures, grey, black and white)" : "The heavier levels (pages as pictures)"} were tried and none came out smaller than level ${e.level}, so level ${e.level} is the smallest this mode can make from this file.`;
}
const ae = 0.01,
  nn = 0.985,
  wt = {
    name: "Tidy the file",
    detail:
      "Repacks the file's internal structure. Nothing you can see changes.",
  },
  ne = {
    name: "Blank pages emptied",
    detail:
      "Pages with nothing on them are stored as empty pages. Nothing you can see changes.",
  },
  oe = {
    name: "Pictures inside made smaller (quick)",
    detail:
      "Photos and scans stored inside the PDF are re-saved once at a balanced quality. Text stays text.",
  },
  re = {
    name: "Pictures inside fitted to the size",
    detail:
      "Each picture is measured and shrunk only as far as it can go without visibly suffering. Text stays text.",
  };
async function on(e, t) {
  const o = await U.load(e, {
      ignoreEncryption: !0,
      updateMetadata: !1,
      throwOnInvalidObject: !1,
    }),
    a = new Set();
  if (
    (o.getPages().forEach((c, s) => {
      const l = c.node;
      if (l.lookup(G.of("Annots"))) return;
      const u = l.lookup(G.of("Resources"));
      if (u instanceof tt) {
        const m = u.lookup(G.of("XObject"));
        if (m instanceof tt && m.keys().length) return;
      }
      const d = l.lookup(G.of("Contents")),
        g =
          d instanceof rt
            ? Array.from({ length: d.size() }, (m, b) => d.lookup(b))
            : [d];
      let h = 0;
      for (const m of g)
        m instanceof bt &&
          (h += m instanceof ie ? m.contents.length : m.getContentsSize());
      h <= 6e3 && a.add(s);
    }),
    !a.size)
  )
    return [];
  const n = await t.open(),
    r = t.ops,
    i = new Set(
      [
        r.showText,
        r.showSpacedText,
        r.nextLineShowText,
        r.nextLineSetSpacingShowText,
        r.paintImageXObject,
        r.paintImageXObjectRepeat,
        r.paintInlineImageXObject,
        r.paintImageMaskXObject,
        r.paintImageMaskXObjectGroup,
        r.paintImageMaskXObjectRepeat,
        r.paintFormXObjectBegin,
        r.shadingFill,
        r.fill,
        r.eoFill,
        r.fillStroke,
        r.eoFillStroke,
        r.closeFillStroke,
        r.closeEOFillStroke,
        r.stroke,
        r.closeStroke,
        r.paintSolidColorImageMask,
      ].filter((c) => typeof c == "number"),
    ),
    f = [];
  for (let c = 1; c <= n.numPages; c++) {
    if (!a.has(c - 1)) continue;
    const s = await n.getPage(c);
    if ((await s.getAnnotations()).length) continue;
    const l = await s.getOperatorList();
    Array.from(l.fnArray).some((u) => i.has(u)) || f.push(c - 1);
  }
  return f;
}
function bo(e, t, o, a, n = "site") {
  const r = `Every step was tried and the smallest file is ${gt(e)}, above your ${gt(t)} target.`;
  if (o === "balanced")
    return `${r} Only the Balanced steps were allowed (text stays selectable). ${n === "api" ? "Send limit=aggressive or limit=extreme" : 'Choose "Go as far as" Aggressive or Extreme'} to let pages become pictures.`;
  if (o === "aggressive")
    return `${r} The Aggressive steps are finished. Going further means Extreme, which makes pages grey and then black and white. ${n === "api" ? "Send limit=extreme" : 'Choose "Go as far as" Extreme'} to try it.`;
  const i =
    a > 0
      ? ` With ${ta(a, "page")}, the target leaves about ${gt(Math.floor(t / a))} for each page, but the smallest this tool can store a page of this file at without making it unreadable is about ${gt(Math.floor(e / a))}.`
      : "";
  return `${r} This included the Extreme steps (grey, then black and white), so there is nothing smaller to try.${i} Splitting the document into parts is the other way to fit a limit.`;
}
async function rn(e, t, o, a = {}) {
  const n = o.codec,
    r = e.length,
    i = { shouldStop: a.shouldStop },
    f = await U.load(e, { updateMetadata: !1 }),
    { images: c, totalStoredBytes: s } = Je(f),
    l = c.length,
    d =
      l === 0 && s >= Math.max(50 * 1024, r * 0.2)
        ? "unsupported-pictures"
        : "no-images",
    g = {
      title: f.getTitle(),
      author: f.getAuthor(),
      fallbackTitle: st(a.fileName ?? "document.pdf"),
    },
    h = async (w) => {
      const v = await U.load(w, { updateMetadata: !1 });
      return (Q(v, g), v.save({ useObjectStreams: !0 }));
    },
    m = async () => {
      const w = await U.load(e, { updateMetadata: !1 });
      return (Q(w, g), w.save({ useObjectStreams: !0 }));
    },
    b = (w) => w <= r * (1 - ae);
  let O = 1,
    D = 1 / 0;
  const P = (w, v, E) =>
    !b(E.length) || E.length >= D * 0.995
      ? !1
      : ((D = E.length),
        a.onLevel?.({
          level: O++,
          name: w,
          detail: v,
          bytes: E,
          size: E.length,
          turnsPagesToPictures: !1,
        }),
        !0);
  let p = t,
    M = a.targetBytes,
    j,
    I = "extreme",
    A = !1;
  if (
    ((t === "balanced" ||
      t === "aggressive" ||
      t === "extreme" ||
      t === "size") &&
      ((I = t === "size" ? (a.limit ?? "extreme") : t),
      t !== "size" && ((A = !0), (M = Math.max(1, Math.floor(r * 0.02)))),
      (p = "target")),
    t === "auto")
  ) {
    a.onProgress?.("Tidying the file...");
    const w = await m();
    if (((j = w), P(wt.name, wt.detail, w), w.length <= r * 0.5))
      return {
        status: "ok",
        bytes: w,
        size: w.length,
        method: "structure",
        imagesShrunk: 0,
        imageCount: l,
      };
    ((p = "target"), (M = Math.floor(r * 0.5)));
  }
  if (p === "medium" || p === "strong") {
    if (l === 0) {
      a.onProgress?.("No pictures to shrink; tidying the file...");
      const E = await m();
      return b(E.length)
        ? {
            status: "ok",
            bytes: E,
            size: E.length,
            method: "structure",
            imagesShrunk: 0,
            imageCount: l,
          }
        : {
            status: "unchanged",
            reason: d,
            imageCount: l,
            pictureFallbackWouldHelp: !a.allowPictures,
          };
    }
    const w = await Gt(e, p === "medium" ? Ht : Ze, n, {
        ...i,
        onProgress: (E, T) =>
          a.onProgress?.(`Shrinking picture ${Math.min(E + 1, T)} of ${T}...`),
      }),
      v = await h(w.bytes);
    return b(v.length)
      ? {
          status: "ok",
          bytes: v,
          size: v.length,
          method: "images",
          imagesShrunk: w.replaced,
          imageCount: l,
        }
      : {
          status: "unchanged",
          reason: "no-gain",
          imageCount: l,
          pictureFallbackWouldHelp: !a.allowPictures,
        };
  }
  const x = M;
  if (!x || x <= 0)
    throw new Error(
      "A valid target size is required for this compression mode",
    );
  if (!A && r <= x)
    return { status: "unchanged", reason: "under-target", imageCount: l };
  const R = (w) => (A ? { ...w, metTarget: void 0, targetBytes: void 0 } : w),
    _ = Math.floor(x * nn),
    L = j ?? (await m());
  j === void 0 && P(wt.name, wt.detail, L);
  let S = { bytes: L, method: "structure", replaced: 0 };
  if (L.length <= x)
    return R({
      status: "ok",
      bytes: L,
      size: L.length,
      method: "structure",
      metTarget: !0,
      targetBytes: x,
      imagesShrunk: 0,
      imageCount: l,
    });
  let F = e;
  try {
    a.onProgress?.("Looking for blank pages...");
    const w = await on(e, o);
    if (w.length) {
      const v = await h(await Za(e, w, void 0));
      if (
        P(ne.name, ne.detail, v) &&
        ((F = v),
        (S = { bytes: v, method: "structure", replaced: 0 }),
        v.length <= x)
      )
        return R({
          status: "ok",
          bytes: v,
          size: v.length,
          method: "structure",
          metTarget: !0,
          targetBytes: x,
          imagesShrunk: 0,
          imageCount: l,
        });
    }
  } catch (w) {
    if (w instanceof $t) throw w;
  }
  const z =
      t === "balanced" || t === "aggressive" || t === "extreme" || t === "size"
        ? I !== "balanced"
        : !!a.allowPictures,
    V = (w) =>
      A && I !== "balanced" && O > 1
        ? {
            kind: w,
            level: O - 1,
            savedPercent: Math.floor((1 - S.bytes.length / r) * 100),
            limit: I,
          }
        : void 0,
    N = (w) =>
      b(S.bytes.length)
        ? R({
            status: "ok",
            bytes: S.bytes,
            size: S.bytes.length,
            method: S.method,
            metTarget: S.bytes.length <= x,
            targetBytes: x,
            imagesShrunk: S.replaced,
            imageCount: l,
            pictureFallbackWouldHelp: !z,
            pictureFallbackTried: z,
            stopNote: w ? V(w) : void 0,
          })
        : {
            status: "unchanged",
            reason: l === 0 ? d : "no-gain",
            imageCount: l,
            pictureFallbackWouldHelp: !z,
            pictureFallbackTried: z,
          };
  if (l > 0) {
    a.onProgress?.("Shrinking the pictures inside...");
    const w = await Gt(F, A && I === "balanced" ? Qe : Ht, n, {
        ...i,
        onProgress: (C, k) =>
          a.onProgress?.(`Shrinking picture ${Math.min(C + 1, k)} of ${k}...`),
      }),
      v = await h(w.bytes),
      E = v.length < _ * 0.88;
    if (
      (!E &&
        P(oe.name, oe.detail, v) &&
        v.length < S.bytes.length &&
        (S = { bytes: v, method: "images", replaced: w.replaced }),
      !A && !E && S.bytes.length <= x)
    )
      return R({
        status: "ok",
        bytes: S.bytes,
        size: S.bytes.length,
        method: "images",
        metTarget: !0,
        targetBytes: x,
        imagesShrunk: S.replaced,
        imageCount: l,
      });
    const y =
        (await Ke(F, _, n, {
          ...i,
          onPass: (C) =>
            a.onProgress?.(
              C === 1
                ? "Measuring each picture..."
                : "Choosing the best setting for each picture...",
            ),
          onProgress: (C, k) =>
            a.onProgress?.(`Picture ${Math.min(C + 1, k)} of ${k}...`),
        })) ??
        (await Ye(F, _, n, {
          ...i,
          onPass: (C, k) =>
            a.onProgress?.(
              `Finding the sharpest result that fits: pass ${C} of ${k}...`,
            ),
          onProgress: (C, k) =>
            a.onProgress?.(
              `Shrinking picture ${Math.min(C + 1, k)} of ${k}...`,
            ),
        })),
      $ = await h(y.bytes);
    P(re.name, re.detail, $) &&
      $.length < S.bytes.length &&
      (S = { bytes: $, method: "images", replaced: y.replaced });
  }
  if (A && I === "balanced") return N();
  if (S.bytes.length <= x) {
    if (A && !a.runAllLevels) return N("already-small");
    if (!A)
      return R({
        status: "ok",
        bytes: S.bytes,
        size: S.bytes.length,
        method: S.method,
        metTarget: !0,
        targetBytes: x,
        imagesShrunk: S.replaced,
        imageCount: l,
      });
  }
  if (z) {
    const w = await Ka(o, {
      base: S.bytes,
      goal: _,
      mustBeat: r * (1 - ae),
      firstLevel: O,
      extreme: I === "extreme",
      stamp: (v) => Q(v, g),
      onLevel: (v) => {
        ((O = v.level + 1), (D = v.size), a.onLevel?.(v));
      },
      onProgress: a.onProgress,
      shouldStop: a.shouldStop,
    });
    if (w && w.size < S.bytes.length)
      return R({
        status: "ok",
        bytes: w.bytes,
        size: w.size,
        method: "pictures",
        metTarget: w.size <= x,
        targetBytes: x,
        imagesShrunk: 0,
        imageCount: l,
        pagesConverted: w.pagesConverted,
        pagesKept: w.pagesKept,
      });
  }
  return N("no-smaller");
}
async function sn(e) {
  return (await U.load(await e.arrayBuffer())).getPageCount();
}
async function cn(e) {
  let t;
  try {
    t = await e.arrayBuffer();
  } catch {
    return { status: "invalid" };
  }
  try {
    const o = await U.load(t, { ignoreEncryption: !0, updateMetadata: !1 });
    if (o.isEncrypted) return { status: "encrypted" };
    let a = !1;
    try {
      a = o.getForm().getFields().length > 0;
    } catch {}
    return {
      status: "ok",
      doc: o,
      pageCount: o.getPageCount(),
      hasFormFields: a,
    };
  } catch {
    return { status: "invalid" };
  }
}
async function ln(e, t, o = {}) {
  if (e.length < 2) throw new Error("Merging requires at least 2 PDF files");
  if (o.arrangement) return fn(e, o.arrangement, t);
  const a = await U.create();
  let n, r;
  const i = [];
  let f = !1;
  for (let c = 0; c < e.length; c++) {
    const s = await e[c].arrayBuffer();
    let l;
    try {
      l = await U.load(s);
    } catch (P) {
      const p =
        P instanceof Error && /encrypt/i.test(P.message)
          ? "is password-protected"
          : "couldn't be read (it may be damaged)";
      throw new Error(`"${e[c].name}" ${p}`);
    }
    c === 0 && ((n = l.getTitle() || void 0), (r = l.getAuthor() || void 0));
    let u = l.getPageIndices(),
      d = [];
    const g = o.ranges?.[c]?.trim(),
      h = o.pageEdits?.[c],
      m = ia(h);
    if (g || m) {
      const P = ca(l.getPageCount(), g, h);
      if ("error" in P) throw new Error(`"${e[c].name}": ${P.error}`);
      ((u = P.pages.map((p) => p.index)), (d = P.pages.map((p) => p.rotate)));
    }
    const b = await a.copyPages(l, u);
    if (
      (b.forEach((P, p) => {
        (d[p] && P.setRotation(et((P.getRotation().angle + d[p]) % 360)),
          a.addPage(P));
      }),
      o.padOdd && c < e.length - 1 && b.length % 2 === 1)
    ) {
      const P = b[b.length - 1].getSize();
      a.addPage([P.width, P.height]);
    }
    const O = _t(l);
    O.length > 0 && (f = !0);
    const D = g || m ? Nt(O, new Map(u.map((P, p) => [P, b[p]]))) : Le(O, b);
    (i.push({
      title: e[c].name.replace(/\.pdf$/i, ""),
      page: b[0] ?? null,
      children: D,
    }),
      t?.(c + 1, e.length));
  }
  return (
    f && xt(a, i),
    Q(a, { title: n, author: r, fallbackTitle: `${st(e[0].name)}-merged` }),
    a.save()
  );
}
async function fn(e, t, o) {
  if (t.length === 0) throw new Error("No pages left to merge");
  const a = await U.create(),
    n = [];
  for (let i = 0; i < e.length; i++)
    try {
      n.push(await U.load(await e[i].arrayBuffer()));
    } catch (f) {
      const c =
        f instanceof Error && /encrypt/i.test(f.message)
          ? "is password-protected"
          : "couldn't be read (it may be damaged)";
      throw new Error(`"${e[i].name}" ${c}`);
    }
  const r = new Map();
  for (let i = 0; i < t.length; i++) {
    const f = t[i],
      c = n[f.fileIndex];
    if (!c || f.index < 0 || f.index >= c.getPageCount())
      throw new Error(
        "The page arrangement no longer matches the files. Open the arranger again.",
      );
    const [s] = await a.copyPages(c, [f.index]),
      l = dt(f.rotate);
    (l && s.setRotation(et((s.getRotation().angle + l) % 360)),
      a.addPage(s),
      r.has(f.fileIndex) || r.set(f.fileIndex, s),
      o?.(i + 1, t.length));
  }
  if (n.some((i) => _t(i).length > 0)) {
    const i = [];
    (e.forEach((f, c) => {
      const s = r.get(c);
      s &&
        i.push({ title: f.name.replace(/\.pdf$/i, ""), page: s, children: [] });
    }),
      xt(a, i));
  }
  return (
    Q(a, {
      title: n[0].getTitle() || void 0,
      author: n[0].getAuthor() || void 0,
      fallbackTitle: `${st(e[0].name)}-merged`,
    }),
    a.save()
  );
}
function me(e, t) {
  const o = e.replace(/\s+/g, "").replace(/[\u2010-\u2015\u2212]/g, "-");
  if (!o) return { error: "Empty range" };
  const a = `${t} ${t === 1 ? "page" : "pages"}`;
  if (o.includes("-")) {
    const r = o.split("-");
    if (r.length !== 2) return { error: `"${e}" isn't a valid range` };
    r[1] === "" && r[0] !== "" && (r[1] = String(t));
    const [i, f] = r.map(Number);
    return r.some((c) => c === "") ||
      !Number.isInteger(i) ||
      !Number.isInteger(f)
      ? { error: `"${e}" isn't a valid range` }
      : i < 1 || f > t
        ? { error: `"${e}" is outside this PDF's ${a}` }
        : i > f
          ? { error: `"${e}" starts after it ends` }
          : { pages: Array.from({ length: f - i + 1 }, (c, s) => i + s - 1) };
  }
  const n = Number(o);
  return Number.isInteger(n)
    ? n < 1 || n > t
      ? { error: `Page ${n} is outside this PDF's ${a}` }
      : { pages: [n - 1] }
    : { error: `"${e}" isn't a valid page number` };
}
async function Pt(e, t, o) {
  const a = await t.copyPages(e, o);
  a.forEach((c) => t.addPage(c));
  const n = new Map();
  o.forEach((c, s) => {
    n.has(c) || n.set(c, a[s]);
  });
  const r = Nt(_t(e), n);
  xt(t, r);
  const i = ue(e, t),
    f = (c) => c.reduce((s, l) => s + 1 + f(l.children), 0);
  return { formFields: i, bookmarks: f(r) };
}
function Ct(e) {
  const t = e.map((n) => n + 1),
    o = [];
  let a = 0;
  for (; a < t.length;) {
    let n = a;
    for (; n + 1 < t.length && t[n + 1] === t[n] + 1;) n++;
    (o.push(n > a ? `${t[a]}-${t[n]}` : `${t[a]}`), (a = n + 1));
  }
  return o.join("_");
}
async function un(e, t, o, a) {
  const n = await U.load(await e.arrayBuffer()),
    r = st(e.name);
  if (o) {
    const c = t.flat(),
      s = await U.create(),
      l = await Pt(n, s, c);
    return (
      Q(s, {
        title: n.getTitle(),
        author: n.getAuthor(),
        fallbackTitle: `${r}-combined`,
      }),
      [
        {
          blob: await s.save(),
          name: `${r}-combined.pdf`,
          rangeLabel: `pages ${t.map(Ct).join(", ")}`,
          pageCount: c.length,
          ...l,
        },
      ]
    );
  }
  const i = [],
    f = new Set();
  for (let c = 0; c < t.length; c++) {
    const s = t[c],
      l = await U.create(),
      u = await Pt(n, l, s),
      d = Ct(s);
    Q(l, {
      title: n.getTitle(),
      author: n.getAuthor(),
      fallbackTitle: `${r} (part ${c + 1})`,
    });
    const g = await l.save();
    let h = `${r}-${s.length === 1 ? "page" : "pages"}-${d}.pdf`;
    for (let m = 2; f.has(h); m++)
      h = `${r}-${s.length === 1 ? "page" : "pages"}-${d} (${m}).pdf`;
    (f.add(h),
      i.push({
        blob: g,
        name: h,
        rangeLabel: `${s.length === 1 ? "page" : "pages"} ${d.replace(/_/g, ", ")}`,
        pageCount: s.length,
        ...u,
      }),
      a?.(c + 1, t.length));
  }
  return i;
}
async function dn(e, t, o = {}) {
  const a = new Uint8Array(await e.arrayBuffer()),
    { codec: n, ...r } = o;
  return rn(a, t, an(e, n), { ...r, fileName: e.name });
}
function we(e, t, o) {
  const a = (-o * Math.PI) / 180,
    n = Math.cos(a),
    r = Math.sin(a),
    i = [0, e, e, 0].map((d, g) => d * n - [0, 0, t, t][g] * r),
    f = [0, e, e, 0].map((d, g) => d * r + [0, 0, t, t][g] * n),
    c = Math.min(...i),
    s = Math.max(...i),
    l = Math.min(...f),
    u = Math.max(...f);
  return { width: s - c, height: u - l, offsetX: -c, offsetY: -l };
}
async function gn(e, t, o, a) {
  const n = await U.load(await e.arrayBuffer(), { updateMetadata: !1 }),
    r = n.getPageCount();
  for (let i = 0; i < r; i++) {
    if (a?.()) throw new Error("Rotation stopped");
    const f = i + 1,
      c = t[f] || 0;
    if (c === 0) continue;
    const s = n.getPage(i),
      l = s.getRotation().angle,
      u = Math.round(c / 90) * 90,
      d = c - u;
    if (Math.abs(d) < 1e-9) {
      (o?.(`Page ${f} of ${r}...`),
        s.setRotation(et((((l + u) % 360) + 360) % 360)));
      continue;
    }
    o?.(`Turning page ${f} of ${r} by ${Math.round(c * 100) / 100}°...`);
    const { width: g, height: h } = s.getSize(),
      m = l + c,
      b = we(g, h, m),
      O = await n.embedPage(s);
    (n
      .insertPage(i, [b.width, b.height])
      .drawPage(O, { x: b.offsetX, y: b.offsetY, rotate: et(-m) }),
      n.removePage(i + 1));
  }
  return (
    Q(n, {
      title: n.getTitle(),
      author: n.getAuthor(),
      fallbackTitle: st(e.name),
    }),
    n.save({ useObjectStreams: !0 })
  );
}
function yt(e, t = "arabic") {
  if (t === "arabic" || e < 1) return String(e);
  if (t === "roman" || t === "ROMAN") {
    const n = [
      [1e3, "m"],
      [900, "cm"],
      [500, "d"],
      [400, "cd"],
      [100, "c"],
      [90, "xc"],
      [50, "l"],
      [40, "xl"],
      [10, "x"],
      [9, "ix"],
      [5, "v"],
      [4, "iv"],
      [1, "i"],
    ];
    let r = e,
      i = "";
    for (const [f, c] of n) for (; r >= f;) ((i += c), (r -= f));
    return t === "ROMAN" ? i.toUpperCase() : i;
  }
  let o = "",
    a = e;
  for (; a > 0;)
    (a--,
      (o = String.fromCharCode(97 + (a % 26)) + o),
      (a = Math.floor(a / 26)));
  return t === "ALPHA" ? o.toUpperCase() : o;
}
class ye extends Error {
  constructor(t) {
    (super(t), (this.name = "PageRangeError"));
  }
}
async function hn(e, t, o, a = {}) {
  const {
      format: n = "plain",
      prefix: r = "",
      skipFirstPage: i = !1,
      fontSize: f = 10,
      style: c = "arabic",
      margin: s = 28,
      color: l = { r: 0.35, g: 0.35, b: 0.35 },
    } = a,
    u = new Uint8Array(await e.arrayBuffer()),
    d = await U.load(u),
    { drawTextAnywhere: g, measureTextAnywhere: h } = await q(
      async () => {
        const { drawTextAnywhere: M, measureTextAnywhere: j } =
          await import("./drawTextAnywhere-DcuP6lHH.js");
        return { drawTextAnywhere: M, measureTextAnywhere: j };
      },
      __vite__mapDeps([0, 1, 2, 3, 4, 5, 6]),
    ),
    m = d.getPages(),
    b = s;
  let O;
  if (a.pageRange) {
    const M = Tt(a.pageRange, m.length);
    if ("error" in M) throw new ye(M.error);
    O = new Set(M.pages);
  } else O = new Set(m.map((M, j) => j).filter((M) => !(i && M === 0)));
  let D = o;
  const P = O.size;
  for (let M = 0; M < m.length; M++) {
    const j = m[M];
    if (!O.has(M)) continue;
    const I = yt(D, c),
      A =
        n === "page-of-total"
          ? `Page ${I} of ${a.totalOverride !== void 0 ? yt(a.totalOverride, c) : yt(o + P - 1, c)}`
          : n === "prefixed"
            ? `${r}${I}`
            : I;
    D++;
    const x = nt(j),
      { width: R, height: _ } = x,
      L = await h(d, A, f),
      F = t.startsWith("top") ? _ - b : b;
    let B;
    t.endsWith("center")
      ? (B = R / 2 - L / 2)
      : t.endsWith("right")
        ? (B = R - b - L)
        : (B = b);
    const { x: z, y: V } = x.toStored(B, F);
    await g(d, j, A, {
      x: z,
      y: V,
      size: f,
      color: l,
      rotateDegrees: x.rotation,
    });
  }
  const p = await d.save();
  return K(p);
}
function pn(e, t = 0.01) {
  const { data: o, width: a, height: n } = e,
    r = 250,
    i = (D) => {
      for (let P = 0; P < a; P++) {
        const p = (D * a + P) * 4;
        if (o[p] < r || o[p + 1] < r || o[p + 2] < r) return !1;
      }
      return !0;
    },
    f = (D) => {
      for (let P = 0; P < n; P++) {
        const p = (P * a + D) * 4;
        if (o[p] < r || o[p + 1] < r || o[p + 2] < r) return !1;
      }
      return !0;
    };
  let c = 0;
  for (; c < n && i(c);) c++;
  let s = n - 1;
  for (; s > c && i(s);) s--;
  let l = 0;
  for (; l < a && f(l);) l++;
  let u = a - 1;
  for (; u > l && f(u);) u--;
  if (c >= s || l >= u) return { x: 0, y: 0, w: 1, h: 1 };
  const d = a * t,
    g = n * t,
    h = Math.max(0, (l - d) / a),
    m = Math.max(0, (c - g) / n),
    b = Math.min(1 - h, (u - l + d * 2) / a),
    O = Math.min(1 - m, (s - c + g * 2) / n);
  return { x: h, y: m, w: b, h: O };
}
async function mn(e, t, o) {
  const a = new Uint8Array(await e.arrayBuffer()),
    n = await U.load(a),
    r = n.getPages(),
    i = o ?? r.map((s, l) => l),
    f = new Set(i);
  r.forEach((s, l) => {
    if (!f.has(l)) return;
    const u = nt(s),
      d = t.w * u.width,
      g = t.h * u.height,
      h = Oe(u, t.x * u.width, u.height - t.y * u.height - g, d, g);
    s.setCropBox(h.x, h.y, h.width, h.height);
  });
  const c = await n.save();
  return K(c);
}
async function wn(e, t, o) {
  const a = new Uint8Array(await e.arrayBuffer()),
    n = await U.load(a),
    r = await U.create(),
    i = n.getPageCount();
  for (let c = 0; c < i; c++) {
    const s = n.getPage(c),
      l = await r.embedPage(s),
      u = Math.min(t / l.width, o / l.height),
      d = l.width * u,
      g = l.height * u;
    r.addPage([t, o]).drawPage(l, {
      x: (t - d) / 2,
      y: (o - g) / 2,
      width: d,
      height: g,
    });
  }
  const f = await r.save();
  return K(f);
}
const yn = {
    a4: { width: 595.28, height: 841.89, label: "A4" },
    letter: { width: 612, height: 792, label: "US Letter" },
    legal: { width: 612, height: 1008, label: "US Legal" },
    a5: { width: 419.53, height: 595.28, label: "A5" },
  },
  be = { r: 0.5, g: 0.5, b: 0.5 },
  Pe = 0.4;
function zt(e) {
  const t = e.contentStreamRef;
  if (!t) return;
  const o = e.node.Contents();
  if (o instanceof rt) {
    for (let a = 0; a < o.size(); a++)
      if (String(o.get(a)) === String(t)) {
        (o.remove(a), o.insert(0, t));
        return;
      }
  }
}
function xe(e, t, o, a, n, r = 0) {
  const f = (r * Math.PI) / 180,
    c = Math.cos(f),
    s = Math.sin(f),
    l = Math.abs(a * c) + Math.abs(n * s),
    u = Math.abs(a * s) + Math.abs(n * c),
    d = e.endsWith("left")
      ? 40 + l / 2
      : e.endsWith("right")
        ? t - 40 - l / 2
        : t / 2,
    g = e.startsWith("top")
      ? o - 40 - u / 2
      : e.startsWith("bottom")
        ? 40 + u / 2
        : o / 2;
  return { x: d - (a / 2) * c + (n / 2) * s, y: g - (a / 2) * s - (n / 2) * c };
}
async function bn(e, t, o = {}) {
  const a = t.replace(/[\r\n\t]+/g, " ").trim(),
    {
      opacity: n = Pe,
      position: r = "center",
      fontSize: i = 50,
      color: f = be,
      rotationDegrees: c = 45,
    } = o,
    s = await U.load(await e.arrayBuffer()),
    { drawTextAnywhere: l, measureTextAnywhere: u } = await q(
      async () => {
        const { drawTextAnywhere: D, measureTextAnywhere: P } =
          await import("./drawTextAnywhere-DcuP6lHH.js");
        return { drawTextAnywhere: D, measureTextAnywhere: P };
      },
      __vite__mapDeps([0, 1, 2, 3, 4, 5, 6]),
    );
  if (!a) throw new Error("Enter the watermark text");
  let d = i;
  const g = o.pages ? new Set(o.pages) : null,
    h = s.getPages().filter((D, P) => !g || g.has(P));
  if (h.length === 0) throw new Error("No pages to watermark");
  if (r !== "tiled") {
    const D = (c * Math.PI) / 180;
    let P = await u(s, a, d, !0);
    const p = Math.min(...h.map((x) => nt(x).width)) - 80,
      M = Math.min(...h.map((x) => nt(x).height)) - 80,
      j = Math.abs(P * Math.cos(D)) + Math.abs(d * 0.75 * Math.sin(D)),
      I = Math.abs(P * Math.sin(D)) + Math.abs(d * 0.75 * Math.cos(D)),
      A = Math.min(1, p / j, M / I);
    A < 1 && (d = Math.max(6, d * A));
  }
  const m = await u(s, a, d, !0),
    b = d * 0.75;
  for (const D of h) {
    const P = nt(D),
      { width: p, height: M } = P,
      j = (I, A) => {
        const { x, y: R } = P.toStored(I, A);
        return l(s, D, a, {
          x,
          y: R,
          size: d,
          bold: !0,
          color: f,
          opacity: n,
          rotateDegrees: c + P.rotation,
        });
      };
    if (r === "tiled") {
      const I = m + 80,
        A = b + 60;
      for (let x = -A; x < M + A; x += A)
        for (let R = -I; R < p + I; R += I) await j(R, x);
    } else {
      const { x: I, y: A } = xe(r, p, M, m, b, c);
      await j(I, A);
    }
    o.layer === "behind" && zt(D);
  }
  const O = await s.save();
  return K(O);
}
async function Pn(e, t, o = {}) {
  const {
      opacity: a = 0.4,
      position: n = "center",
      rotationDegrees: r = 0,
    } = o,
    i = o.widthFraction ?? (n === "tiled" ? 0.18 : 0.3),
    f = await U.load(await e.arrayBuffer()),
    { normalizeImageFile: c } = await q(
      async () => {
        const { normalizeImageFile: h } =
          await import("./imagePdf-Dtz8PQyf.js");
        return { normalizeImageFile: h };
      },
      __vite__mapDeps([7, 2, 3, 4, 5, 8]),
    );
  t = await c(t);
  const s = await t.arrayBuffer(),
    u = t.type === "image/png" ? await f.embedPng(s) : await f.embedJpg(s),
    d = o.pages ? new Set(o.pages) : null;
  for (const [h, m] of Array.from(f.getPages().entries())) {
    if (d && !d.has(h)) continue;
    const b = nt(m),
      { width: O, height: D } = b;
    let P = O * i,
      p = (P * u.height) / u.width;
    const M = (n === "tiled" ? 0.3 : 0.6) * D;
    p > M && ((p = M), (P = (p * u.width) / u.height));
    const j = (I, A) => {
      const { x, y: R } = b.toStored(I, A);
      m.drawImage(u, {
        x,
        y: R,
        width: P,
        height: p,
        opacity: a,
        rotate: et(r + b.rotation),
      });
    };
    if (n === "tiled") {
      const I = P + 70,
        A = p + 70;
      let x = 0;
      for (let R = 20; R < D; R += A, x++)
        for (let _ = 20 + (x % 2) * (I / 2); _ < O; _ += I) j(_, R);
    } else {
      const I = xe(n, O, D, P, p, r);
      j(I.x, I.y);
    }
    o.layer === "behind" && zt(m);
  }
  const g = await f.save();
  return K(g);
}
function Tt(e, t) {
  const o = e
    .split(/[,;]/)
    .map((n) => n.trim())
    .filter(Boolean);
  if (o.length === 0) return { error: "Enter at least one page or range" };
  const a = [];
  for (const n of o) {
    const r = me(n, t);
    if ("error" in r) return r;
    a.push(...r.pages);
  }
  return { pages: a };
}
async function _e(e, t) {
  const o = await U.load(await e.arrayBuffer()),
    a = await U.create();
  (await Pt(o, a, t),
    Q(a, {
      title: o.getTitle(),
      author: o.getAuthor(),
      fallbackTitle: st(e.name),
    }));
  const n = await a.save();
  return K(n);
}
async function xn(e, t) {
  return _e(e, t);
}
async function _n(e, t) {
  const o = await U.load(await e.arrayBuffer()),
    a = await U.create(),
    n = (c) => {
      for (let s = c - 1; s >= 0; s--) {
        const l = t[s];
        if (l.type === "source") return o.getPage(l.index).getSize();
      }
      for (let s = c + 1; s < t.length; s++) {
        const l = t[s];
        if (l.type === "source") return o.getPage(l.index).getSize();
      }
      return { width: 595.28, height: 841.89 };
    },
    r = new Map(),
    i = new Map();
  for (let c = 0; c < t.length; c++) {
    const s = t[c];
    if (s.type === "blank") {
      const { width: g, height: h } = n(c);
      a.addPage([g, h]);
      continue;
    }
    const [l] = await a.copyPages(o, [s.index]);
    if (s.rotation) {
      const g = o.getPage(s.index);
      l.setRotation(et(g.getRotation().angle + s.rotation));
    }
    const u = (i.get(s.index) ?? 0) + 1;
    (i.set(s.index, u), u > 1 && sa(a, l, u));
    const d = a.addPage(l);
    r.has(s.index) || r.set(s.index, d);
  }
  (xt(a, Nt(_t(o), r)),
    ue(o, a),
    Q(a, {
      title: o.getTitle(),
      author: o.getAuthor(),
      fallbackTitle: st(e.name),
    }));
  const f = await a.save();
  return K(f);
}
async function kn(e, t, o = {}) {
  const { PDFDocument: a } = await q(
      async () => {
        const { PDFDocument: s } = await import("./index-CmBFpp8Z.js");
        return { PDFDocument: s };
      },
      __vite__mapDeps([9, 10, 4, 11]),
    ),
    n = await a.load(new Uint8Array(await e.arrayBuffer()), {
      updateMetadata: !1,
    }),
    r = o.restrict ?? {},
    i = !!(r.printing || r.copying || r.modifying);
  let f = t;
  if (i) {
    const s = crypto.getRandomValues(new Uint8Array(24));
    f = Array.from(s, (l) => l.toString(16).padStart(2, "0")).join("");
  }
  (n.setProducer("FreeDailyPro"),
    n.encrypt({
      userPassword: t,
      ownerPassword: f,
      algorithm: "AES-256",
      permissions: i
        ? {
            printing: r.printing ? !1 : "highResolution",
            copying: !r.copying,
            modifying: !r.modifying,
            annotating: !r.modifying,
            fillingForms: !r.modifying,
            contentAccessibility: !0,
            documentAssembly: !r.modifying,
          }
        : void 0,
    }));
  const c = await n.save();
  return new Blob([new Uint8Array(c)], { type: "application/pdf" });
}
async function vn(e, t, o) {
  try {
    const a = new Uint8Array(await t.arrayBuffer()),
      { PDFDocument: n } = await q(
        async () => {
          const { PDFDocument: s } = await import("./index-CmBFpp8Z.js");
          return { PDFDocument: s };
        },
        __vite__mapDeps([9, 10, 4, 11]),
      );
    if (
      !(await n.load(a, { ignoreEncryption: !0, updateMetadata: !1 }))
        .isEncrypted
    )
      return {
        ok: !1,
        pages: 0,
        reason: "The file did not come out protected.",
      };
    const i = async (s, l) => {
        const u = await Xe(s, l),
          d = (await u.getMetadata().catch(() => null))?.info,
          g = Object.keys((await u.getFieldObjects().catch(() => null)) ?? {})
            .sort()
            .join("|");
        return { pages: u.numPages, title: d?.Title ?? "", fields: g };
      },
      f = await i(new Uint8Array(await e.arrayBuffer())),
      c = await i(a, o);
    return c.pages !== f.pages
      ? { ok: !1, pages: c.pages, reason: "The page count changed." }
      : c.title !== f.title
        ? { ok: !1, pages: c.pages, reason: "The title changed." }
        : c.fields !== f.fields
          ? { ok: !1, pages: c.pages, reason: "Some form fields were lost." }
          : { ok: !0, pages: c.pages };
  } catch (a) {
    return (
      console.error("Protected PDF check failed:", a),
      {
        ok: !1,
        pages: 0,
        reason: "The protected file could not be opened with that password.",
      }
    );
  }
}
class Rt extends Error {
  constructor(t, o) {
    (super(t), (this.kind = o));
  }
}
async function Tn(e) {
  const t = new Uint8Array(await e.arrayBuffer()),
    { sniffNotPdf: o, recoverPagesByScan: a } = await q(
      async () => {
        const { sniffNotPdf: l, recoverPagesByScan: u } =
          await import("./pdfRecover-PVH02fpy.js");
        return { sniffNotPdf: l, recoverPagesByScan: u };
      },
      __vite__mapDeps([12, 2, 3, 4, 5, 13]),
    ),
    {
      notPdfMessage: n,
      diagnoseStructure: r,
      repairSummary: i,
    } = await q(async () => {
      const {
        notPdfMessage: l,
        diagnoseStructure: u,
        repairSummary: d,
      } = await import("./repairDiagnose-Csq-PeZE.js");
      return { notPdfMessage: l, diagnoseStructure: u, repairSummary: d };
    }, []),
    f = o(t.subarray(0, 1024));
  if (f) throw new Rt(n(f), "not-pdf");
  const c = r(t);
  let s = !1;
  try {
    s = !new TextDecoder("latin1")
      .decode(t.subarray(Math.max(0, t.length - 2048)))
      .includes("%%EOF");
  } catch {}
  try {
    const l = await U.load(t, {
        throwOnInvalidObject: !1,
        ignoreEncryption: !0,
        updateMetadata: !1,
      }),
      u = l.getPageCount();
    if (u > 0) {
      const d = await l.save();
      return {
        blob: K(d),
        pageCount: u,
        totalPages: null,
        partial: !1,
        summary: i({
          diagnosis: c,
          method: "lenient",
          recovered: u,
          total: null,
        }),
      };
    }
  } catch (l) {
    console.warn("Lenient load failed, trying a scan:", l);
  }
  try {
    const l = await a(t),
      u = s || (l.total !== null && l.total > l.recovered);
    return {
      blob: K(l.bytes),
      pageCount: l.recovered,
      totalPages: l.total,
      partial: u,
      summary: i({
        diagnosis: c,
        method: "scan",
        recovered: l.recovered,
        total: l.total,
      }),
    };
  } catch (l) {
    throw (
      console.warn("Scan recovery failed:", l),
      new Rt(
        "This file couldn't be recovered — no complete page could be found in it.",
        "unrecoverable",
      )
    );
  }
}
async function En(e, t) {
  const [o, a] = await Promise.all([Vt(e), Vt(t)]),
    n = o.flat(),
    r = a.flat();
  return n.length > Lt || r.length > Lt
    ? { kind: "too-large" }
    : n.length === 0 && r.length === 0
      ? { kind: "no-text" }
      : { kind: "diff", diff: ea(n, r) };
}
const Mn = {
  a4: { width: 595.28, height: 841.89, label: "A4" },
  letter: { width: 612, height: 792, label: "US Letter" },
  original: { width: 0, height: 0, label: "Original image size (no fitting)" },
};
async function Sn(e, t, o) {
  const { buildImagePdf: a, DEFAULT_IMAGE_PDF_OPTIONS: n } = await q(
      async () => {
        const { buildImagePdf: i, DEFAULT_IMAGE_PDF_OPTIONS: f } =
          await import("./imagePdf-Dtz8PQyf.js");
        return { buildImagePdf: i, DEFAULT_IMAGE_PDF_OPTIONS: f };
      },
      __vite__mapDeps([7, 2, 3, 4, 5, 8]),
    ),
    r = await a(e, { ...n, pageSize: t, originalDpi: 72 }, { progress: o });
  if (r.skipped.length)
    throw new Error(`${r.skipped[0].name} ${r.skipped[0].reason}`);
  return K(r.bytes);
}
async function An(e, t, o) {
  const { buildImagePdf: a, DEFAULT_IMAGE_PDF_OPTIONS: n } = await q(
      async () => {
        const { buildImagePdf: i, DEFAULT_IMAGE_PDF_OPTIONS: f } =
          await import("./imagePdf-Dtz8PQyf.js");
        return { buildImagePdf: i, DEFAULT_IMAGE_PDF_OPTIONS: f };
      },
      __vite__mapDeps([7, 2, 3, 4, 5, 8]),
    ),
    r = await a(e, { ...n, pageSize: t, originalDpi: 72, pair: o });
  if (r.skipped.length)
    throw new Error(`${r.skipped[0].name} ${r.skipped[0].reason}`);
  return K(r.bytes);
}
async function In(e, t) {
  if (t === 0) return e;
  const o = await fe(e),
    a = t === 90 || t === 270,
    n = document.createElement("canvas");
  ((n.width = a ? o.naturalHeight : o.naturalWidth),
    (n.height = a ? o.naturalWidth : o.naturalHeight));
  const r = n.getContext("2d");
  (r.translate(n.width / 2, n.height / 2),
    r.rotate((t * Math.PI) / 180),
    r.drawImage(o, -o.naturalWidth / 2, -o.naturalHeight / 2));
  const i = e.type === "image/png" ? "image/png" : "image/jpeg",
    f = await new Promise((c, s) => {
      n.toBlob((l) => (l ? c(l) : s(new Error("Rotation failed"))), i, 0.95);
    });
  return new File([f], e.name, { type: i });
}
async function Dn(e) {
  if (!(
    e.type === "image/heic" ||
    e.type === "image/heif" ||
    /\.(heic|heif)$/i.test(e.name)
  ))
    return e;
  const o = (
      await q(
        async () => {
          const { default: r } = await import("./heic2any-Cwwvdsxn.js").then(
            (i) => i.h,
          );
          return { default: r };
        },
        __vite__mapDeps([14, 4]),
      )
    ).default,
    a = await o({ blob: e, toType: "image/jpeg", quality: 0.92 }),
    n = Array.isArray(a) ? a[0] : a;
  return new File([n], e.name.replace(/\.(heic|heif)$/i, ".jpg"), {
    type: "image/jpeg",
  });
}
async function Fn(e) {
  if (!(e.type === "image/webp" || /\.webp$/i.test(e.name))) return e;
  const o = await fe(e),
    a = document.createElement("canvas");
  ((a.width = o.naturalWidth),
    (a.height = o.naturalHeight),
    a.getContext("2d").drawImage(o, 0, 0));
  const n = await new Promise((r, i) => {
    a.toBlob(
      (f) => (f ? r(f) : i(new Error("WEBP conversion failed"))),
      "image/png",
    );
  });
  return new File([n], e.name.replace(/\.webp$/i, ".png"), {
    type: "image/png",
  });
}
async function $n(e) {
  const { readDocx: t } = await q(
      async () => {
        const { readDocx: n } = await import("./docxRead-O6CRn7oc.js");
        return { readDocx: n };
      },
      __vite__mapDeps([15, 16, 4, 17, 18, 19]),
    ),
    { blocksText: o } = await q(async () => {
      const { blocksText: n } = await import("./docxModel-CrYTKRGY.js");
      return { blocksText: n };
    }, []);
  return (await t(e)).sections.map((n) => o(n.blocks)).join(`
`);
}
async function Ln(e) {
  const [{ readDocx: t }, { convertDocxDocumentToPdf: o }] = await Promise.all([
      q(
        () => import("./docxRead-O6CRn7oc.js"),
        __vite__mapDeps([15, 16, 4, 17, 18, 19]),
      ),
      q(
        () => import("./docxToPdf-K5O8yYaD.js"),
        __vite__mapDeps([20, 2, 3, 4, 5, 21, 1, 6, 8]),
      ),
    ]),
    a = await t(e),
    n = await o(a, { fallbackTitle: e.name.replace(/\.[^.]+$/, "") });
  return K(n.bytes);
}
async function On(e, t) {
  const { convertTextToPdfDocument: o } = await q(
      async () => {
        const { convertTextToPdfDocument: n } =
          await import("./textToPdf-BuGdG5vq.js");
        return { convertTextToPdfDocument: n };
      },
      __vite__mapDeps([22, 2, 3, 4, 5, 1, 6, 8]),
    ),
    a = await o(e, { title: t });
  return K(a.bytes);
}
async function Cn(e) {
  const o = (
    await U.load(new Uint8Array(await e.arrayBuffer()), {
      ignoreEncryption: !0,
    })
  )
    .getForm()
    .getFields();
  return {
    fieldCount: o.length,
    signatureCount: o.filter((a) => a instanceof $e).length,
  };
}
async function Rn(e, t = {}) {
  const o = new Uint8Array(await e.arrayBuffer()),
    a = await U.load(o),
    n = a.getForm(),
    r = n.getFields().length;
  if (r === 0)
    throw new Error(
      "This PDF doesn't have any fillable form fields to flatten — it may already be flattened, or it never had real fillable fields to begin with.",
    );
  const i = await Ce(a);
  if (i.length > 0)
    throw new Error(
      `Couldn't draw the answer in ${i
        .slice(0, 3)
        .map((c) => `"${c.name}"`)
        .join(", ")} — nothing was flattened, so no entry is lost.`,
    );
  if ((Re(a), n.flatten({ updateFieldAppearances: !1 }), Be(a), t.stamp)) {
    const c = await a.embedFont(le.Helvetica),
      s = ra(new Date(), t.stampZone ?? "local");
    for (const l of a.getPages()) {
      const u = nt(l),
        d = u.toStored(20, 8);
      l.drawText(s, {
        x: d.x,
        y: d.y,
        size: 6.5,
        font: c,
        color: ce(0.6, 0.6, 0.6),
        maxWidth: u.width - 40,
        rotate: et(u.rotation),
      });
    }
  }
  (a.setProducer("FreeDailyPro"), a.setModificationDate(new Date()));
  const f = await a.save({ updateFieldAppearances: !1 });
  return { blob: K(f), fieldCount: r };
}
class Bt extends Error {
  constructor() {
    (super("Conversion stopped"), (this.name = "PdfToJpgCancelled"));
  }
}
const se = 16e6,
  Bn = 12;
async function Nn(e, t, o = {}) {
  const {
      scale: a = 2,
      format: n = "image/jpeg",
      quality: r = 0.92,
      pageRange: i,
      isCancelled: f,
    } = o,
    c = n === "image/png" ? "png" : "jpg",
    s = () => {
      if (f?.()) throw new Bt();
    },
    l = [],
    u = [];
  for (const I of e) {
    s();
    let A;
    try {
      A = await kt(I);
    } catch (R) {
      const _ = R instanceof Error ? R.message : "";
      u.push({
        name: I.name,
        reason: /password/i.test(_)
          ? "password-protected"
          : "damaged or not a real PDF",
      });
      continue;
    }
    let x = Array.from({ length: A.numPages }, (R, _) => _);
    if (i && e.length === 1) {
      const R = Tt(i, A.numPages);
      if ("error" in R) throw new Error(R.error);
      x = ga(R.pages);
    }
    l.push({ file: I, pdf: A, pages: x });
  }
  if (l.length === 0)
    throw new Error(
      e.length === 1
        ? "This PDF could not be read. It may be damaged or password-protected."
        : "None of these PDFs could be read. They may be damaged or password-protected.",
    );
  const d = l.reduce((I, A) => I + A.pages.length, 0),
    g = ua(l.map((I) => Mt(I.file.name))),
    h = l.length > 1,
    m = new Ue(),
    b = [];
  let O = 0,
    D = 0;
  for (let I = 0; I < l.length; I++) {
    const { file: A, pdf: x, pages: R } = l[I],
      _ = [],
      L = O;
    let S = 0;
    try {
      for (const F of R) {
        (s(), t?.(O, d));
        const B = await x.getPage(F + 1),
          z = B.getViewport({ scale: 1 }),
          N =
            z.width * z.height * a * a > se
              ? Math.sqrt(se / (z.width * z.height))
              : a;
        N !== a && S++;
        const w = await Ve(B, N, n, r);
        s();
        const v = da(Mt(A.name), F + 1, x.numPages, c);
        (_.push({
          name: v,
          sourceName: A.name,
          pageNum: F + 1,
          width: Math.floor(B.getViewport({ scale: N }).width),
          height: Math.floor(B.getViewport({ scale: N }).height),
          blob: w,
        }),
          O++);
      }
    } catch (F) {
      if (F instanceof Bt) throw F;
      (u.push({ name: A.name, reason: "its pages could not be drawn" }),
        (O = L + R.length));
      continue;
    }
    D += S;
    for (const F of _) m.file(h ? `${g[I]}/${F.name}` : F.name, F.blob);
    b.push(..._);
  }
  if (b.length === 0)
    throw new Error(
      e.length === 1
        ? "This PDF could not be converted. It may be damaged."
        : "None of these PDFs could be converted. They may be damaged.",
    );
  t?.(d, d);
  const P = b.slice(0, Bn),
    p = {
      imageCount: b.length,
      fileCount: l.length,
      skipped: u,
      previews: P,
      reducedPages: D,
    };
  if (b.length === 1) return { blob: b[0].blob, filename: b[0].name, ...p };
  const M = await m.generateAsync({ type: "blob" }),
    j = h
      ? `converted-images-${l.length}-files.zip`
      : `${Mt(l[0].file.name)}-images.zip`;
  return { blob: M, filename: j, ...p };
}
async function zn(e) {
  const {
      loadWorkbook: t,
      convertWorkbookToPdf: o,
      DEFAULT_EXCEL_PDF_OPTIONS: a,
    } = await q(
      async () => {
        const {
          loadWorkbook: i,
          convertWorkbookToPdf: f,
          DEFAULT_EXCEL_PDF_OPTIONS: c,
        } = await import("./excelPdf-DQL9QKOc.js");
        return {
          loadWorkbook: i,
          convertWorkbookToPdf: f,
          DEFAULT_EXCEL_PDF_OPTIONS: c,
        };
      },
      __vite__mapDeps([
        23, 10, 4, 11, 2, 3, 5, 16, 17, 18, 24, 1, 6, 8, 22, 19,
      ]),
    ),
    n = await t(e),
    r = await o(n, a, e.name.replace(/\.[^.]+$/, ""));
  return K(r.bytes);
}
async function jn(e) {
  const { convertPowerPointToPdfRaster: t } = await q(
    async () => {
      const { convertPowerPointToPdfRaster: o } =
        await import("./pptxRasterize-ByR_iBgN.js");
      return { convertPowerPointToPdfRaster: o };
    },
    __vite__mapDeps([
      25, 10, 4, 11, 2, 3, 5, 26, 24, 27, 1, 6, 28, 8, 16, 17, 18,
    ]),
  );
  return t(e, { quality: "default", includeHidden: !1 });
}
async function Un(e) {
  const { convertPdfToExcelDocument: t, DEFAULT_RUN_OPTIONS: o } = await q(
      async () => {
        const { convertPdfToExcelDocument: r, DEFAULT_RUN_OPTIONS: i } =
          await import("./pdfToExcel-38p0cUiA.js");
        return { convertPdfToExcelDocument: r, DEFAULT_RUN_OPTIONS: i };
      },
      __vite__mapDeps([29, 30, 18, 31, 27, 32, 33, 34, 35]),
    ),
    a = await kt(e),
    n = await t(
      a,
      { ...o, ocr: !1 },
      {
        isCurrent: () => !0,
        status: () => {},
        progress: () => {},
        registerWorker: () => {},
      },
    );
  return n.kind === "ok"
    ? { blob: n.blob, hasData: !0 }
    : { blob: new Blob(), hasData: !1 };
}
async function Wn(e, t, o = {}) {
  const a = o.language ?? "eng",
    n = () => {
      if (o.isCurrent && !o.isCurrent()) throw new Error("cancelled");
    },
    r = new Uint8Array(await e.arrayBuffer()),
    i = await U.load(r, { updateMetadata: !1 }),
    f = await U.create(),
    c = await f.embedFont(le.Helvetica);
  let s = null;
  const l = ze(a),
    u = await kt(e),
    d = await Ge(e),
    g = u.numPages;
  let h = 0,
    m = 0;
  const b = [],
    O = [],
    D = o.rotate ?? 0,
    P = {},
    { startOcrEngine: p } = await q(
      async () => {
        const { startOcrEngine: A } = await import("./ocrEngine-C8AaB6dN.js");
        return { startOcrEngine: A };
      },
      __vite__mapDeps([36, 30, 18, 32, 37]),
    );
  let M = null;
  const j = 3;
  try {
    for (let A = 0; A < g; A++) {
      n();
      const x = A + 1,
        _ =
          (d[A] ?? [])
            .map((W) => W.text)
            .join(" ")
            .trim().length >= 3,
        [L] = await f.copyPages(i, [A]),
        S = f.addPage(L);
      if (_) continue;
      (M ||
        t?.(
          "Starting OCR (first use downloads the language data)...",
          (A / g) * 100,
        ),
        t?.(`Reading page ${x} of ${g} with OCR...`, (A / g) * 100));
      const F = await u.getPage(x),
        B = await He(F, j, 0.92);
      (n(),
        M ||
          ((M = await p(a, (W) =>
            t?.(
              `Reading page ${x} of ${g} with OCR... ${Math.round(W * 100)}%`,
              ((A + W) / g) * 100,
            ),
          )),
          n()),
        m++);
      const z = D === "auto" || D === 0 ? 0 : D,
        V = z ? await je(B, z) : B;
      n();
      const N = await M.read(V, {
        isCurrent: o.isCurrent,
        autoRotate: D === "auto",
        status: (W) => t?.(`Page ${x}: ${W}`, (A / g) * 100),
      });
      n();
      const w = z || N.rotation || 0;
      if (fa({ text: N.text ?? "", confidence: N.confidence })) {
        b.push(x);
        continue;
      }
      w &&
        (S.setRotation(et((((S.getRotation().angle + w) % 360) + 360) % 360)),
        O.push({ page: x, degrees: w }));
      const v = nt(S),
        { width: E, height: T } = v,
        y = F.getViewport({ scale: j }),
        $ = E / (w % 180 === 90 ? y.height : y.width),
        C = T / (w % 180 === 90 ? y.width : y.height);
      let k = 0;
      for (const W of N.blocks ?? [])
        for (const H of W.paragraphs ?? [])
          for (const Z of H.lines ?? []) {
            const J = Z;
            let X = (J.text ?? (J.words ?? []).map((at) => at.text).join(" "))
              .replace(/\s+/g, " ")
              .trim();
            if (!X || !J.bbox) continue;
            let it = c;
            if (l && /[\u0900-\u097f]/.test(X)) {
              if (!s) {
                f.registerFontkit(Ne);
                const at = await fetch("/fonts/FreeSans-devanagari-subset.ttf");
                at.ok &&
                  (s = await f.embedFont(
                    new Uint8Array(await at.arrayBuffer()),
                    { subset: !1 },
                  ));
              }
              if (s) {
                it = s;
                const at = new Set(s.getCharacterSet());
                X = Array.from(X)
                  .filter((ve) => at.has(ve.codePointAt(0)))
                  .join("");
              }
            }
            if (
              (it === c &&
                (X = Array.from(X)
                  .filter((at) => Te(at.codePointAt(0)))
                  .join("")),
              !X.trim())
            )
              continue;
            const jt = (J.bbox.x1 - J.bbox.x0) * $,
              Et = (J.bbox.y1 - J.bbox.y0) * C,
              Ut = it.widthOfTextAtSize(X, 1);
            if (Ut <= 0 || jt <= 0) continue;
            const ke = Math.min(Math.max(jt / Ut, Et * 0.5), Et * 1.4),
              Wt = v.toStored(J.bbox.x0 * $, T - J.bbox.y1 * C + Et * 0.2);
            (S.drawText(X, {
              x: Wt.x,
              y: Wt.y,
              size: ke,
              font: it,
              opacity: 0,
              rotate: et(v.rotation),
            }),
              (k += X.split(" ").length));
          }
      k > 0 && (h++, (P[A] = k));
    }
  } finally {
    M && (await M.terminate());
  }
  Q(f, {
    title: i.getTitle(),
    author: i.getAuthor(),
    fallbackTitle: e.name.replace(/\.pdf$/i, ""),
  });
  const I = await f.save();
  return {
    blob: K(I),
    pagesOcrd: h,
    wordsByPage: P,
    pagesAttempted: m,
    unreadablePages: b,
    rotatedPages: O,
  };
}
const Po = Object.freeze(
  Object.defineProperty(
    {
      __proto__: null,
      DEFAULT_WATERMARK_COLOR: be,
      DEFAULT_WATERMARK_OPACITY: Pe,
      IMAGE_PDF_PAGE_SIZES: Mn,
      MAX_DIFF_LINES: Lt,
      PDF_PAGE_SIZES_PT: yn,
      PageRangeError: ye,
      PdfToJpgCancelled: Bt,
      RepairError: Rt,
      addImageWatermark: Pn,
      addPageNumbers: hn,
      addTextWatermark: bn,
      buildOrganizedPdf: _n,
      comparePdfText: En,
      compressPdf: dn,
      convertDocxToPdfBlob: Ln,
      convertExcelToPdf: zn,
      convertHeicToJpegFile: Dn,
      convertImagesToPdf: Sn,
      convertPdfToExcel: Un,
      convertPdfsToJpgs: Nn,
      convertPowerPointToPdf: jn,
      convertTextToPdf: On,
      convertWebpToPngFile: Fn,
      copyPagesWithStructure: Pt,
      cropPdf: mn,
      detectContentBounds: pn,
      extractDocxText: $n,
      extractPdfPages: _e,
      fillPdfForm: aa,
      findTextInPdf: oa,
      flattenPdf: Rn,
      formatPageNumber: yt,
      getPdfPageCount: sn,
      inspectFormFields: Cn,
      loadPdfSafely: cn,
      mergePdfs: ln,
      ocrPdf: Wn,
      pageGroupLabel: Ct,
      pairImagesOntoPages: An,
      parseMultiRange: Tt,
      parsePdfFormFields: na,
      parseSplitRange: me,
      protectPdfWithPassword: kn,
      reorderPdfPages: xn,
      repairPdf: Tn,
      resizePdfPages: wn,
      rotateImageToFile: In,
      rotatePdf: gn,
      rotatedBounds: we,
      sanitizeForWinAnsi: Ee,
      sanitizeForWinAnsiSingleLine: Me,
      sendDrawnContentBehind: zt,
      splitPdf: un,
      verifyProtectedPdf: vn,
    },
    Symbol.toStringTag,
    { value: "Module" },
  ),
);
export {
  gn as A,
  _e as B,
  _n as C,
  $n as D,
  Ln as E,
  jn as F,
  zn as G,
  On as H,
  Un as I,
  po as J,
  ho as K,
  go as L,
  fo as M,
  lo as N,
  dt as O,
  Bt as P,
  ia as Q,
  Rt as R,
  uo as S,
  ca as T,
  ln as U,
  bn as V,
  Pn as W,
  yn as X,
  wn as Y,
  Po as Z,
  kn as a,
  Tn as b,
  Dn as c,
  yo as d,
  dn as e,
  Rn as f,
  sn as g,
  mo as h,
  Cn as i,
  wo as j,
  Nn as k,
  cn as l,
  yt as m,
  hn as n,
  ye as o,
  me as p,
  Tt as q,
  In as r,
  un as s,
  xn as t,
  Wn as u,
  vn as v,
  bo as w,
  Sn as x,
  pn as y,
  mn as z,
};
//# sourceMappingURL=operations-BatXiFlG.js.map
