#!/usr/bin/env python3
"""FDP-88 test PDFs for Flatten PDF. Writes testfiles/: form.pdf (every field type + annots + layer + rotated page),
nofields.pdf, signed.pdf (signature field with a /V signature dictionary), stale.pdf (values whose appearance is stale/missing),
hindi.pdf, enc.pdf (pw test123), corrupt.pdf."""
import pikepdf, os
from reportlab.pdfgen import canvas
from reportlab.lib.colors import black
T = 'testfiles/'
def base_form(path, rotate_p3=True):
    c = canvas.Canvas(path, pagesize=(612, 792)); f = c.acroForm
    c.setFont('Helvetica', 12); c.drawString(72, 740, 'FDP-88 form page 1: public body text stays selectable.')
    c.drawString(72, 700, 'Name:'); f.textfield(name='name', value='Jonathan Reed', x=160, y=692, width=250, height=20, borderWidth=1, fontSize=11)
    c.drawString(72, 660, 'Notes:'); f.textfield(name='notes', value='Line one of notes\nLine two of notes', x=160, y=610, width=300, height=60, borderWidth=1, fieldFlags='multiline', fontSize=10)
    c.drawString(72, 580, 'Agree:'); f.checkbox(name='agree', checked=True, x=160, y=574, size=16, buttonStyle='check')
    c.drawString(200, 580, 'Not ticked:'); f.checkbox(name='spam', checked=False, x=280, y=574, size=16)
    c.drawString(72, 540, 'Plan:')
    f.radio(name='plan', value='A', selected=False, x=160, y=534, size=14); c.drawString(180, 538, 'A')
    f.radio(name='plan', value='B', selected=True, x=210, y=534, size=14); c.drawString(230, 538, 'B')
    c.drawString(72, 500, 'Country:'); f.choice(name='country', value='Canada', options=['USA', 'Canada', 'India'], x=160, y=494, width=150, height=20, fontSize=11)
    c.drawString(72, 450, 'Colors:'); f.listbox(name='colors', value='Green', options=['Red', 'Green', 'Blue'], x=160, y=400, width=120, height=60, fontSize=10)
    c.drawString(72, 360, 'Read-only:'); f.textfield(name='ro', value='READONLY VALUE', x=160, y=352, width=200, height=20, fieldFlags='readOnly', fontSize=11)
    f.textfield(name='hiddenf', value='HIDDEN FIELD VALUE', x=320, y=352, width=200, height=20, annotationFlags='hidden', fontSize=11)
    c.drawString(72, 320, 'Empty field:'); f.textfield(name='empty', value='', x=160, y=312, width=200, height=20, fontSize=11)
    c.showPage()
    c.setFont('Helvetica', 12); c.drawString(72, 740, 'Page 2: highlight, sticky note, ink, free text and a hidden layer.')
    c.drawString(72, 700, 'Highlighted sentence here.')
    c.drawString(72, 650, 'Page 2 field:'); f.textfield(name='p2field', value='PAGE2 VALUE', x=180, y=642, width=200, height=20, fontSize=11)
    c.showPage()
    c.setFont('Helvetica', 12); c.drawString(72, 740, 'Page 3 rotated with a field.'); f.textfield(name='rotfield', value='ROTATED VALUE', x=72, y=680, width=200, height=20, fontSize=11)
    c.showPage(); c.save()
    pdf = pikepdf.open(path, allow_overwriting_input=True)
    p2 = pdf.pages[1].obj
    annots = [
      pikepdf.Dictionary(Type=pikepdf.Name.Annot, Subtype=pikepdf.Name.Highlight, Rect=[70, 695, 230, 715], QuadPoints=[70, 715, 230, 715, 70, 695, 230, 695], C=[1, 1, 0], Contents=pikepdf.String('HL note')),
      pikepdf.Dictionary(Type=pikepdf.Name.Annot, Subtype=pikepdf.Name.Text, Rect=[400, 700, 420, 720], Contents=pikepdf.String('STICKY NOTE'), T=pikepdf.String('Reviewer')),
      pikepdf.Dictionary(Type=pikepdf.Name.Annot, Subtype=pikepdf.Name.Ink, Rect=[72, 560, 300, 620], InkList=[[80, 570, 150, 610, 220, 570, 290, 610]], C=[0, 0, 1], BS=pikepdf.Dictionary(W=2)),
      pikepdf.Dictionary(Type=pikepdf.Name.Annot, Subtype=pikepdf.Name.FreeText, Rect=[72, 500, 350, 530], Contents=pikepdf.String('FREETEXT COMMENT'), DA=pikepdf.String('/Helv 12 Tf 0 0 1 rg')),
    ]
    p2.Annots = pdf.make_indirect(pikepdf.Array(list(p2.Annots) + [pdf.make_indirect(a) for a in annots]))
    ocg = pdf.make_indirect(pikepdf.Dictionary(Type=pikepdf.Name.OCG, Name=pikepdf.String('Optional layer')))
    pdf.Root.OCProperties = pikepdf.Dictionary(OCGs=[ocg], D=pikepdf.Dictionary(ON=[ocg], OFF=[]))
    res = p2.Resources; res.Properties = pikepdf.Dictionary(OC1=ocg)
    if '/Font' not in res: res.Font = pikepdf.Dictionary()
    res.Font.FL = pikepdf.Dictionary(Type=pikepdf.Name.Font, Subtype=pikepdf.Name.Type1, BaseFont=pikepdf.Name.Helvetica)
    s = pikepdf.Stream(pdf, b'/OC /OC1 BDC BT /FL 12 Tf 72 450 Td (LAYER TEXT visible layer) Tj ET EMC')
    p2.Contents = pdf.make_indirect(pikepdf.Array([p2.Contents, s] if not isinstance(p2.Contents, pikepdf.Array) else list(p2.Contents) + [s]))
    if rotate_p3: pdf.pages[2].obj.Rotate = 90
    pdf.save(path + '.tmp'); os.replace(path + '.tmp', path)
os.makedirs(T, exist_ok=True)
base_form(T + 'form.pdf')
# signed.pdf: form + a signature field with a /V signature dictionary (fake bytes, not a valid signature)
pdf = pikepdf.open(T + 'form.pdf'); pg = pdf.pages[0].obj
ap = pikepdf.Stream(pdf, b'q 0 0 1 rg BT /Helv 14 Tf 4 8 Td (SIGNED J. Reed) Tj ET Q'); ap.Type = pikepdf.Name.XObject; ap.Subtype = pikepdf.Name.Form; ap.BBox = [0, 0, 200, 30]
ap.Resources = pikepdf.Dictionary(Font=pikepdf.Dictionary(Helv=pikepdf.Dictionary(Type=pikepdf.Name.Font, Subtype=pikepdf.Name.Type1, BaseFont=pikepdf.Name.Helvetica)))
sigv = pdf.make_indirect(pikepdf.Dictionary(Type=pikepdf.Name.Sig, Filter=pikepdf.Name('/Adobe.PPKLite'), SubFilter=pikepdf.Name('/adbe.pkcs7.detached'), Name=pikepdf.String('Jonathan Reed'), M=pikepdf.String('D:20261121000000Z'), ByteRange=[0, 0, 0, 0], Contents=pikepdf.String(b'\x00' * 64)))
sig = pdf.make_indirect(pikepdf.Dictionary(Type=pikepdf.Name.Annot, Subtype=pikepdf.Name.Widget, FT=pikepdf.Name.Sig, T=pikepdf.String('signature1'), Rect=[360, 160, 560, 190], F=4, P=pg, V=sigv, AP=pikepdf.Dictionary(N=pdf.make_indirect(ap))))
pg.Annots.append(sig); pdf.Root.AcroForm.Fields.append(sig); pdf.Root.AcroForm.SigFlags = 3
pdf.save(T + 'signed.pdf')
# stale.pdf: name value changed but appearance left old; one field with appearance removed; NeedAppearances true
pdf = pikepdf.open(T + 'form.pdf')
for fld in pdf.Root.AcroForm.Fields:
    t = str(fld.get('/T', ''))
    if t == 'name': fld.V = pikepdf.String('NEW VALUE Maria Lopez')   # AP still shows Jonathan Reed
    if t == 'p2field': del fld['/AP']; fld.V = pikepdf.String('NO AP VALUE')
pdf.Root.AcroForm.NeedAppearances = True
pdf.save(T + 'stale.pdf')
# stale2.pdf: value changed, appearance stale, NeedAppearances NOT set (what most viewers show = old appearance)
pdf = pikepdf.open(T + 'form.pdf')
for fld in pdf.Root.AcroForm.Fields:
    if str(fld.get('/T', '')) == 'name': fld.V = pikepdf.String('NEW VALUE Maria Lopez')
if '/NeedAppearances' in pdf.Root.AcroForm: del pdf.Root.AcroForm['/NeedAppearances']
pdf.save(T + 'stale2.pdf')
# hindi.pdf
pdf = pikepdf.open(T + 'form.pdf')
for fld in pdf.Root.AcroForm.Fields:
    if str(fld.get('/T', '')) == 'name': fld.V = pikepdf.String('नमस्ते राम')
pdf.Root.AcroForm.NeedAppearances = True
pdf.save(T + 'hindi.pdf')
# nofields.pdf: text + annotations only
c = canvas.Canvas(T + 'nofields.pdf'); c.drawString(72, 740, 'No form fields here, just text.'); c.showPage(); c.save()
pdf = pikepdf.open(T + 'nofields.pdf', allow_overwriting_input=True); pg = pdf.pages[0].obj
pg.Annots = pdf.make_indirect(pikepdf.Array([pdf.make_indirect(pikepdf.Dictionary(Type=pikepdf.Name.Annot, Subtype=pikepdf.Name.Text, Rect=[400, 700, 420, 720], Contents=pikepdf.String('only a note')))]))
pdf.save(T + 'nofields2.pdf'); os.replace(T + 'nofields2.pdf', T + 'nofields.pdf')
pikepdf.open(T + 'form.pdf').save(T + 'enc.pdf', encryption=pikepdf.Encryption(user='test123', owner='owner987', R=6))
open(T + 'corrupt.pdf', 'wb').write(b'%PDF-1.7\n' + os.urandom(3000))
print('ok')
