const pw=require('playwright');const fs=require('fs');(async()=>{const b=await pw.chromium.launch();const c=await b.newContext({viewport:{width:1366,height:900}});const p=await c.newPage();
for(const s of ['flatten-filled-pdf-forms-before-sending','fillable-forms']){await p.goto('https://www.freedailypro.com/blog/'+s,{waitUntil:'domcontentloaded',timeout:45000});await p.waitForTimeout(5000);
const t=await p.evaluate(()=>(document.querySelector('article')||document.querySelector('main')).innerText);fs.writeFileSync('/workspace/deep/88-flatten-pdf/blog/'+s+'.txt',t);await p.screenshot({path:'/workspace/deep/88-flatten-pdf/blog/'+s+'-fold.png'});console.log(s,t.length);}
await b.close();})();
