const pw=require('playwright');const fs=require('fs');(async()=>{const b=await pw.chromium.launch();const out={};
for(const s of ['pdf-editor','sign-pdf','fillable-forms','create-fillable-pdf']){const c=await b.newContext({viewport:{width:1366,height:900}});const p=await c.newPage();
await p.goto('https://www.freedailypro.com/tool/'+s,{waitUntil:'domcontentloaded',timeout:45000});await p.waitForTimeout(5000);
for(const t of ['About','Common questions','Details']){const bt=p.locator('main button',{hasText:t});if(await bt.count()){await bt.first().click().catch(()=>{});await p.waitForTimeout(400);}}
out[s]=await p.evaluate(()=>{const m=document.querySelector('main');const t=m.innerText;return{h1:(document.querySelector('h1')||{}).innerText,top:t.slice(0,900),accept:[...m.querySelectorAll('input[type=file]')].map(i=>i.accept),links:[...m.querySelectorAll('a[href*="flatten"]')].map(a=>a.getAttribute('href')+' | '+a.innerText.trim().slice(0,60)),flat:(t.match(/[^\n]*(flatten|Flatten|annotation|AcroForm|form field)[^\n]*/g)||[]).slice(0,14)}});
await p.screenshot({path:'/workspace/deep/88-flatten-pdf/live/cases/dup-'+s+'.png'});await c.close();}
fs.writeFileSync('/workspace/deep/88-flatten-pdf/live/dups.json',JSON.stringify(out,null,1));await b.close();})();
