#!/usr/bin/env python3
"""FDP-88 flatten verifier. Usage: verify88.py <flattened.pdf> <original.pdf> [diffdir] -> JSON: AcroForm/widgets left, other annots kept,
values now page content (selectable via PyMuPDF/pdftotext with no widgets left), hidden field leak, appearance kept (render diff vs original),
signature, OCG, metadata, stamp, rotation."""
import sys, json, subprocess, os
import pikepdf, fitz
VALUES = ['Jonathan Reed', 'Line one of notes', 'Line two of notes', 'Canada', 'Green', 'READONLY VALUE', 'PAGE2 VALUE', 'ROTATED VALUE', 'SIGNED J. Reed', 'NEW VALUE Maria Lopez', 'NO AP VALUE', 'नमस्ते']
LEAK = ['HIDDEN FIELD VALUE']
BODY = ['public body text stays selectable', 'Highlighted sentence here', 'LAYER TEXT visible layer', 'Page 3 rotated with a field']
def run(*a): return subprocess.run(a, capture_output=True, text=True).stdout
def main(out, orig, diffdir=None):
    R = {'file': out, 'bytes': os.path.getsize(out)}
    p = pikepdf.open(out)
    af = p.Root.get('/AcroForm')
    R['acroform'] = None if af is None else {'fields': len(af.get('/Fields', [])), 'NeedAppearances': str(af.get('/NeedAppearances')), 'SigFlags': str(af.get('/SigFlags')), 'XFA': '/XFA' in af}
    R['annots_by_page'] = []
    for pg in p.pages:
        a = pg.obj.get('/Annots', [])
        R['annots_by_page'].append([str(x.get('/Subtype')) + (':' + str(x.get('/FT')) if '/FT' in x else '') for x in a])
    R['widgets_left'] = sum(1 for pg in R['annots_by_page'] for s in pg if s.startswith('/Widget'))
    R['ocproperties'] = '/OCProperties' in p.Root
    R['docinfo'] = {str(k): str(v) for k, v in p.docinfo.items()}
    R['sig_objects'] = sum(1 for o in p.objects if isinstance(o, pikepdf.Dictionary) and o.get('/Type') == pikepdf.Name.Sig)
    d = fitz.open(out); o = fitz.open(orig)
    R['pages'] = d.page_count; R['rotation'] = [pg.rotation for pg in d]; R['orig_rotation'] = [pg.rotation for pg in o]
    txt = [pg.get_text() for pg in d]
    R['fitz_widgets'] = sum(len(list(pg.widgets())) for pg in d)
    R['values_in_text'] = {v: sum(t.count(v) for t in txt) for v in VALUES if sum(t.count(v) for t in txt)}
    R['hidden_leak'] = {v: sum(t.count(v) for t in txt) for v in LEAK}
    R['body_kept'] = {b: any(b in t for t in txt) for b in BODY}
    pt = run('pdftotext', '-layout', out, '-')
    R['pdftotext_values'] = {v: pt.count(v) for v in VALUES + LEAK if pt.count(v)}
    R['stamp'] = [l.strip() for l in pt.splitlines() if 'Flattened on' in l][:4]
    R['fonts'] = run('pdffonts', out).strip().splitlines()[2:]
    # appearance kept: render both with annotations, compare per page
    diffs = []
    for i in range(min(d.page_count, o.page_count)):
        a = o[i].get_pixmap(dpi=72, annots=True); b = d[i].get_pixmap(dpi=72, annots=True)
        if (a.width, a.height) != (b.width, b.height): diffs.append({'page': i + 1, 'size': [(a.width, a.height), (b.width, b.height)]}); continue
        sa, sb = a.samples, b.samples; n = len(sa); step = a.n
        changed = sum(1 for k in range(0, n, step) if abs(sa[k] - sb[k]) > 40 or abs(sa[k+1] - sb[k+1]) > 40 or abs(sa[k+2] - sb[k+2]) > 40)
        bbox = None
        if changed:
            xs, ys = [], []
            for k in range(0, n, step):
                if abs(sa[k] - sb[k]) > 40 or abs(sa[k+1] - sb[k+1]) > 40 or abs(sa[k+2] - sb[k+2]) > 40:
                    px = (k // step); xs.append(px % a.width); ys.append(px // a.width)
            bbox = [min(xs), min(ys), max(xs), max(ys)]
        diffs.append({'page': i + 1, 'changed_px': changed, 'bbox_pt': bbox})
        if diffdir:
            os.makedirs(diffdir, exist_ok=True); b.save(f'{diffdir}/out-p{i+1}.png'); a.save(f'{diffdir}/orig-p{i+1}.png')
    R['render_diff_vs_original'] = diffs
    print(json.dumps(R, indent=1, ensure_ascii=False))
if __name__ == '__main__': main(*sys.argv[1:])
