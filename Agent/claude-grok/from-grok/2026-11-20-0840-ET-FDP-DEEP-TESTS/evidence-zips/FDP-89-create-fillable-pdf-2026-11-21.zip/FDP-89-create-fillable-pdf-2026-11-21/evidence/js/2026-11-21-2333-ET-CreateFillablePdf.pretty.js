import { r as m, j as t } from "./vendor-react-D01g8YgM.js";
import { v as re, aw as ge, f as q, D as xe } from "./index-xgcQ0Xo8.js";
import { T as we, F as be, E as ye, s as ke } from "./ToolPage-DrleSM7T.js";
import { T as ve } from "./ToolInfoSection-DUdo3Ez7.js";
import { u as je } from "./useExportGate-VrUOBDKB.js";
import { s as Ce } from "./fileHandoff-RQJcoDih.js";
import { l as Fe } from "./utils-s8ucLyj8.js";
import {
  S as Y,
  a as Pe,
  F as z,
  B as $,
  A as Se,
  C as Z,
  N as Ne,
  s as De,
  P as ne,
  f as $e,
} from "./ui-DYoQIWB7.js";
import { k as se, S as Te, u as E } from "./index-BRvxULIc.js";
import { T as Le } from "./pdfText-bjh9eBB-.js";
import { P as le } from "./docKit-Ci3qhNGW.js";
import { T as Me } from "./trash-2-DBtfaxvp.js";
import "./useUploadApi-yCV1cZhw.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-Cl69OhvT.js";
import "./share-2-tv4Mz_hR.js";
import "./copy-B6PRNyNa.js";
import "./workflowCta-BFTpZlex.js";
import "./UsageAndUpgradeStrip-DMhPNgnJ.js";
import "./access-DqVqJd33.js";
import "./useAdminAccess-mVM_2mWb.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-DxfN0Pem.js";
import "./map-pin-CwlIzHDK.js";
import "./FaqSection-BNxk42M5.js";
import "./ToolVideoEmbed-DNaMY2Pn.js";
import "./GuideLinks-D5fn3NI1.js";
import "./blog-CxdB1WyW.js";
import "./info-x67VbErc.js";
import "./productCards-DhpNcELZ.js";
import "./layers-B44Zba7-.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-DFD2kyG0.js";
import "./chevron-up-RK9L2OPY.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./fontkit.es-DA-3qwB1.js";
import "./index-CHifq31M.js";
const Ie = re("FilePenLine", [
  [
    "path",
    {
      d: "m18 5-2.414-2.414A2 2 0 0 0 14.172 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2",
      key: "142zxg",
    },
  ],
  [
    "path",
    {
      d: "M21.378 12.626a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",
      key: "2t3380",
    },
  ],
  ["path", { d: "M8 18h1", key: "13wk12" }],
]);
const Ae = re("RectangleEllipsis", [
    [
      "rect",
      { width: "20", height: "12", x: "2", y: "6", rx: "2", key: "9lu3g6" },
    ],
    ["path", { d: "M12 12h.01", key: "1mp3jc" }],
    ["path", { d: "M17 12h.01", key: "1m0b6t" }],
    ["path", { d: "M7 12h.01", key: "eqddd0" }],
  ]),
  H = {
    text: "Text box",
    multiline: "Multi-line text",
    checkbox: "Checkbox",
    dropdown: "Dropdown",
    radio: "Radio choice",
    signature: "Signature area",
  },
  Re = {
    text: [180, 22],
    multiline: [260, 80],
    checkbox: [16, 16],
    dropdown: [160, 22],
    radio: [16, 16],
    signature: [200, 44],
  },
  F = (o, d, p) => Math.min(p, Math.max(d, o));
function Ee(o, d, p, n, l, g, B) {
  const [P, f] = Re[o],
    k = P / p,
    x = f / n,
    a =
      o === "checkbox"
        ? "Check"
        : o === "dropdown"
          ? "Choice"
          : o === "radio"
            ? "Group"
            : o === "signature"
              ? "Signature"
              : o === "multiline"
                ? "Notes"
                : "Field";
  return {
    id: `f${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
    kind: o,
    name: ee(
      a,
      B.map((r) => r.name),
    ),
    label: "",
    page: d,
    fx: F(l - k / 2, 0, 1 - k),
    fy: F(g - x / 2, 0, 1 - x),
    fw: k,
    fh: x,
    options:
      o === "dropdown" || o === "radio"
        ? `Option 1
Option 2`
        : "",
    value: "",
    required: !1,
  };
}
function Q(o) {
  return o
    .replace(/[.\s]+/g, "_")
    .replace(/[^\w\-]/g, "")
    .slice(0, 60);
}
function ee(o, d) {
  const p = Q(o) || "Field",
    n = new Set(d.map((l) => l.toLowerCase()));
  if (!n.has(p.toLowerCase())) return p;
  for (let l = 2; l < 1e3; l++)
    if (!n.has(`${p}_${l}`.toLowerCase())) return `${p}_${l}`;
  return `${p}_${Date.now()}`;
}
const te = (o) =>
  Array.from(
    new Set(
      o
        .split(/\r?\n/)
        .map((d) => d.trim())
        .filter(Boolean),
    ),
  ).slice(0, 60);
function Be(o) {
  const d = [],
    p = new Map();
  for (const n of o) {
    const l = n.name.toLowerCase();
    n.name.trim() || d.push("A field has no name.");
    const g = p.get(l);
    (g &&
      !(g === "radio" && n.kind === "radio") &&
      d.push(
        `The name "${n.name}" is used twice. Field names must be unique (only radio choices may share a name).`,
      ),
      p.set(l, n.kind),
      n.kind === "dropdown" &&
        te(n.options).length < 1 &&
        d.push(`"${n.name}" is a dropdown with no options.`),
      (n.fx < 0 || n.fy < 0 || n.fx + n.fw > 1.0001 || n.fy + n.fh > 1.0001) &&
        d.push(`"${n.name}" runs off the page.`));
  }
  return Array.from(new Set(d));
}
async function qe(o) {
  const d = o.source
    ? await se.load(o.source, { ignoreEncryption: !1, updateMetadata: !1 })
    : await se.create();
  if (!o.source) {
    const [a, r] = le[o.blank?.paper ?? "letter"];
    for (let v = 0; v < F(o.blank?.pages ?? 1, 1, 20); v++) d.addPage([a, r]);
  }
  const p = d.getPages(),
    n = d.getForm(),
    l = await d.embedFont(Te.Helvetica),
    g = o.showLabels
      ? await Le.create(
          d,
          o.fields.map((a) => a.label).join(`
`) + " 0123456789",
        )
      : null,
    B = o.boxBorder ? E(0.25, 0.3, 0.45) : void 0,
    P = new Map();
  let f = 0;
  const k = new Set(n.getFields().map((a) => a.getName().toLowerCase()));
  for (const a of o.fields) {
    const r = p[F(a.page, 0, p.length - 1)],
      { width: v, height: w } = r.getSize(),
      T = a.fw * v,
      S = a.fh * w,
      b = a.fx * v,
      j = w - (a.fy + a.fh) * w;
    let y = a.kind === "radio" ? Q(a.name) : ee(a.name, Array.from(k));
    if ((a.kind !== "radio" && k.add(y.toLowerCase()), g && a.label.trim())) {
      const C = g.wrap(a.label.trim(), 9, Math.max(T, 160));
      a.kind === "checkbox" || a.kind === "radio"
        ? g.draw(r, C[0], {
            x: b + T + 5,
            y: j + (S - 9) / 2 + 1,
            size: 9,
            color: E(0.1, 0.1, 0.1),
          })
        : g.draw(r, C[0], {
            x: b,
            y: Math.min(w - 10, j + S + 3),
            size: 9,
            color: E(0.25, 0.25, 0.25),
          });
    }
    const L = {
      x: b,
      y: j,
      width: T,
      height: S,
      borderColor: B,
      borderWidth: B ? 0.8 : 0,
      backgroundColor: void 0,
    };
    if (a.kind === "text" || a.kind === "multiline") {
      const c = n.createTextField(y);
      (c.addToPage(r, { ...L, font: l }),
        a.kind === "multiline" && c.enableMultiline(),
        a.value && c.setText(a.value.slice(0, 500)),
        a.required && c.enableRequired());
    } else if (a.kind === "checkbox") {
      const c = n.createCheckBox(y);
      (c.addToPage(r, L),
        a.value === "yes" && c.check(),
        a.required && c.enableRequired());
    } else if (a.kind === "dropdown") {
      const c = n.createDropdown(y),
        C = te(a.options);
      (c.addOptions(C),
        c.addToPage(r, { ...L, font: l }),
        a.value && C.includes(a.value) && c.select(a.value),
        a.required && c.enableRequired());
    } else if (a.kind === "radio") {
      let c = P.get(y.toLowerCase());
      c ||
        ((y = ee(y, Array.from(k))),
        k.add(y.toLowerCase()),
        (c = n.createRadioGroup(y)),
        P.set(
          a.name.toLowerCase() === y.toLowerCase()
            ? y.toLowerCase()
            : Q(a.name).toLowerCase(),
          c,
        ),
        a.required && c.enableRequired());
      const C = te(a.options)[0] ?? `Choice${f + 1}`;
      c.addOptionToPage(C, r, L);
    } else
      (r.drawRectangle({
        x: b,
        y: j,
        width: T,
        height: S,
        borderColor: E(0.25, 0.3, 0.45),
        borderWidth: 0.8,
        color: E(0.97, 0.98, 1),
      }),
        r.drawLine({
          start: { x: b + 6, y: j + 12 },
          end: { x: b + T - 6, y: j + 12 },
          thickness: 0.6,
          color: E(0.4, 0.4, 0.4),
        }),
        r.drawText("Sign here", {
          x: b + 6,
          y: j + 3,
          size: 7,
          font: l,
          color: E(0.45, 0.45, 0.45),
        }));
    f++;
  }
  return (
    g && (await g.finish()),
    {
      bytes: await d.save(),
      fieldCount: f,
      note: g?.note() ?? null,
      pageSizes: p.map((a) => [a.getWidth(), a.getHeight()]),
    }
  );
}
const J = {
    what: "Adds real fillable fields to any PDF, or to a blank page: text boxes, multi-line boxes, checkboxes, dropdowns, radio choices and signature areas. The result is a standard PDF form that opens and fills in any PDF reader.",
    how: "Open a PDF or start a blank form. Pick a field type, then tap the page where it should go. Tap a field to rename it, resize it, set its choices or make it required, and drag it to move it. Download the form, or send it straight to Fillable Forms to fill it in, or to Sign PDF to sign it.",
    tip: "Give each field a clear name: the name is what shows up in the data when the form is filled. A signature area is a marked box for a signature; place the actual signature with Sign PDF.",
  },
  ze = ["text", "multiline", "checkbox", "dropdown", "radio", "signature"];
function Pt() {
  const [, o] = ge(),
    { checkExport: d } = je(),
    [p, n] = m.useState(null),
    [l, g] = m.useState({ paper: "letter", pages: 1 }),
    [B, P] = m.useState(!1),
    [f, k] = m.useState([]),
    [x, a] = m.useState(0),
    [r, v] = m.useState([]),
    [w, T] = m.useState("text"),
    [S, b] = m.useState(null),
    [j, y] = m.useState(!0),
    [L, c] = m.useState(!0),
    [C, ae] = m.useState(!1),
    [M, O] = m.useState(null),
    I = m.useRef(null),
    G = m.useRef(null),
    de = m.useCallback(async (e) => {
      const i = e[0];
      if (i)
        try {
          const h = new Uint8Array(await i.arrayBuffer()),
            u = await Fe(new File([h], i.name, { type: "application/pdf" })),
            D = [],
            R = Math.min(u.numPages, 30);
          for (let K = 1; K <= R; K++) {
            const W = await u.getPage(K),
              X = W.getViewport({ scale: 1 }),
              V = W.getViewport({ scale: 900 / X.width }),
              _ = document.createElement("canvas");
            ((_.width = Math.floor(V.width)),
              (_.height = Math.floor(V.height)),
              await W.render({
                canvasContext: _.getContext("2d"),
                viewport: V,
                canvas: _,
              }).promise,
              D.push({
                w: X.width,
                h: X.height,
                img: _.toDataURL("image/jpeg", 0.8),
              }),
              W.cleanup());
          }
          (u.loadingTask.destroy(),
            u.numPages > 30 &&
              q.info(
                "Only the first 30 pages are shown for placing fields; the rest are kept as they are.",
              ),
            n({ bytes: h, name: i.name.replace(/\.pdf$/i, "") }),
            k(D),
            a(0),
            v([]),
            O(null),
            P(!0));
        } catch {
          q.error(
            "That file couldn't be opened as a PDF. If it has a password, remove it first.",
          );
        }
    }, []),
    ce = () => {
      const [e, i] = le[l.paper];
      (n(null),
        k(Array.from({ length: l.pages }, () => ({ w: e, h: i, img: null }))),
        a(0),
        v([]),
        O(null),
        P(!0));
    },
    N = f[x],
    pe = m.useMemo(() => r.filter((e) => e.page === x), [r, x]),
    s = r.find((e) => e.id === S) ?? null,
    U = m.useMemo(() => Be(r), [r]),
    A = (e, i) => v((h) => h.map((u) => (u.id === e ? { ...u, ...i } : u))),
    he = (e) => {
      if (!w || !I.current || !N) return;
      const i = I.current.getBoundingClientRect(),
        h = Ee(
          w,
          x,
          N.w,
          N.h,
          (e.clientX - i.left) / i.width,
          (e.clientY - i.top) / i.height,
          r,
        );
      (v((u) => [...u, h]), b(h.id), O(null));
    },
    ue = (e, i) => {
      if ((e.stopPropagation(), b(i.id), !I.current)) return;
      const h = I.current.getBoundingClientRect();
      ((G.current = {
        id: i.id,
        dx: (e.clientX - h.left) / h.width - i.fx,
        dy: (e.clientY - h.top) / h.height - i.fy,
      }),
        e.currentTarget.setPointerCapture(e.pointerId));
    },
    me = (e) => {
      const i = G.current;
      if (!i || !I.current) return;
      const h = I.current.getBoundingClientRect(),
        u = r.find((D) => D.id === i.id);
      u &&
        A(i.id, {
          fx: F((e.clientX - h.left) / h.width - i.dx, 0, 1 - u.fw),
          fy: F((e.clientY - h.top) / h.height - i.dy, 0, 1 - u.fh),
        });
    };
  m.useEffect(() => {
    const e = () => {
      G.current = null;
    };
    return (
      window.addEventListener("pointerup", e),
      () => window.removeEventListener("pointerup", e)
    );
  }, []);
  const ie = (e, i, h) => {
      const u = parseFloat(i),
        D = parseFloat(h),
        R = f[e.page];
      R &&
        A(e.id, {
          fw:
            Number.isFinite(u) && u > 4 ? F(u / R.w, 4 / R.w, 1 - e.fx) : e.fw,
          fh:
            Number.isFinite(D) && D > 4 ? F(D / R.h, 4 / R.h, 1 - e.fy) : e.fh,
        });
    },
    fe = async () => {
      if (!r.length) {
        q.error("Add at least one field first.");
        return;
      }
      if (U.length) {
        q.error(U[0]);
        return;
      }
      if (await d()) {
        ae(!0);
        try {
          const e = await qe({
              source: p?.bytes ?? null,
              blank: l,
              fields: r,
              showLabels: j,
              boxBorder: L,
            }),
            i = `${p?.name || "fillable-form"}-fillable.pdf`;
          (O({ bytes: e.bytes, name: i, count: e.fieldCount }),
            De(e.bytes, i, ne),
            e.note
              ? q.warning(e.note)
              : q.success(
                  `Fillable PDF with ${e.fieldCount} field${e.fieldCount === 1 ? "" : "s"} downloaded`,
                ));
        } catch (e) {
          $e("fillable PDF", e);
        } finally {
          ae(!1);
        }
      }
    },
    oe = (e) => {
      if (!M) return;
      const i = new File([M.bytes], M.name, { type: ne });
      (e === "sign-pdf"
        ? Ce("sign-pdf", [i])
        : ke({
            blob: i,
            fileName: M.name,
            fromToolId: "create-fillable-pdf",
            toToolId: "fillable-forms",
          }),
        o(`/tool/${e}`));
    };
  return t.jsx(we, {
    children: t.jsxs("div", {
      className: "max-w-3xl mx-auto space-y-6",
      children: [
        B
          ? t.jsxs(t.Fragment, {
              children: [
                t.jsxs(Y, {
                  title: "2. Place fields",
                  hint: w
                    ? `Tap the page to add a ${H[w].toLowerCase()}. Tap a field to edit it; drag to move it.`
                    : "Pick a field type, then tap the page. Tap a field to edit it.",
                  children: [
                    t.jsx("div", {
                      className: "flex flex-wrap gap-2",
                      role: "group",
                      "aria-label": "Field type",
                      children: ze.map((e) =>
                        t.jsx(
                          "button",
                          {
                            type: "button",
                            "aria-pressed": w === e,
                            onClick: () => T(w === e ? null : e),
                            "data-testid": `fp-kind-${e}`,
                            className: `px-3 min-h-10 rounded-md border text-sm ${w === e ? "bg-primary text-primary-foreground" : "bg-background"}`,
                            children: H[e],
                          },
                          e,
                        ),
                      ),
                    }),
                    f.length > 1 &&
                      t.jsxs("div", {
                        className: "flex items-center gap-2 text-sm",
                        children: [
                          t.jsx($, {
                            variant: "outline",
                            onClick: () => a(Math.max(0, x - 1)),
                            disabled: x === 0,
                            children: "Previous",
                          }),
                          t.jsxs("span", {
                            children: ["Page ", x + 1, " of ", f.length],
                          }),
                          t.jsx($, {
                            variant: "outline",
                            onClick: () => a(Math.min(f.length - 1, x + 1)),
                            disabled: x >= f.length - 1,
                            children: "Next",
                          }),
                        ],
                      }),
                    N &&
                      t.jsxs("div", {
                        ref: I,
                        onPointerDown: he,
                        onPointerMove: me,
                        "data-testid": "fp-page",
                        className:
                          "relative w-full border rounded bg-white select-none touch-none overflow-hidden",
                        style: {
                          aspectRatio: `${N.w} / ${N.h}`,
                          cursor: w ? "crosshair" : "default",
                        },
                        children: [
                          N.img &&
                            t.jsx("img", {
                              src: N.img,
                              alt: `Page ${x + 1} of the PDF`,
                              className:
                                "absolute inset-0 w-full h-full pointer-events-none",
                              draggable: !1,
                            }),
                          pe.map((e) =>
                            t.jsx(
                              "div",
                              {
                                onPointerDown: (i) => ue(i, e),
                                role: "button",
                                tabIndex: 0,
                                "aria-label": `${H[e.kind]} ${e.name}`,
                                onKeyDown: (i) => {
                                  i.key === "Enter" && b(e.id);
                                },
                                "data-testid": `fp-field-${e.id}`,
                                className: `absolute border-2 text-[10px] leading-none overflow-hidden px-0.5 flex items-center ${S === e.id ? "border-primary bg-primary/20" : "border-primary/70 bg-primary/10"} text-black`,
                                style: {
                                  left: `${e.fx * 100}%`,
                                  top: `${e.fy * 100}%`,
                                  width: `${e.fw * 100}%`,
                                  height: `${e.fh * 100}%`,
                                  cursor: "move",
                                },
                                children:
                                  e.kind === "signature" ? "Sign here" : e.name,
                              },
                              e.id,
                            ),
                          ),
                        ],
                      }),
                  ],
                }),
                s &&
                  t.jsxs(Y, {
                    title: `Field: ${H[s.kind]}`,
                    children: [
                      t.jsxs("div", {
                        className:
                          "grid sm:grid-cols-2 gap-3 p-3 rounded-lg border",
                        children: [
                          t.jsx(z, {
                            label: "Field name",
                            value: s.name,
                            onChange: (e) =>
                              A(s.id, { name: e.replace(/\./g, "_") }),
                            testId: "fp-name",
                            hint: "Shown in the form data. Letters, numbers, underscore.",
                          }),
                          t.jsx(z, {
                            label: "Label printed next to it (optional)",
                            value: s.label,
                            onChange: (e) => A(s.id, { label: e }),
                            testId: "fp-label",
                          }),
                          (s.kind === "dropdown" || s.kind === "radio") &&
                            t.jsx(Se, {
                              className: "sm:col-span-2",
                              label:
                                s.kind === "dropdown"
                                  ? "Choices, one per line"
                                  : "This radio button's choice (name shared buttons the same)",
                              rows: 3,
                              value: s.options,
                              onChange: (e) => A(s.id, { options: e }),
                              testId: "fp-options",
                            }),
                          s.kind !== "signature" &&
                            s.kind !== "radio" &&
                            t.jsx(z, {
                              label:
                                s.kind === "checkbox"
                                  ? 'Start ticked? type "yes"'
                                  : "Starting value (optional)",
                              value: s.value,
                              onChange: (e) => A(s.id, { value: e }),
                            }),
                          t.jsx(z, {
                            label: "Width (points)",
                            inputMode: "numeric",
                            value: String(
                              Math.round(s.fw * (f[s.page]?.w ?? 612)),
                            ),
                            onChange: (e) =>
                              ie(s, e, String(s.fh * (f[s.page]?.h ?? 792))),
                          }),
                          t.jsx(z, {
                            label: "Height (points)",
                            inputMode: "numeric",
                            value: String(
                              Math.round(s.fh * (f[s.page]?.h ?? 792)),
                            ),
                            onChange: (e) =>
                              ie(s, String(s.fw * (f[s.page]?.w ?? 612)), e),
                          }),
                          s.kind !== "signature" &&
                            t.jsx(Z, {
                              label: "Required",
                              checked: s.required,
                              onChange: (e) => A(s.id, { required: e }),
                            }),
                        ],
                      }),
                      t.jsxs($, {
                        variant: "outline",
                        onClick: () => {
                          (v((e) => e.filter((i) => i.id !== s.id)), b(null));
                        },
                        children: [
                          t.jsx(Me, { className: "h-4 w-4 mr-1" }),
                          "Delete this field",
                        ],
                      }),
                    ],
                  }),
                t.jsxs(Y, {
                  title: `3. Fields (${r.length})`,
                  children: [
                    r.length === 0
                      ? t.jsx("p", {
                          className: "text-sm text-muted-foreground",
                          children: "No fields yet.",
                        })
                      : t.jsx("ul", {
                          className: "text-sm divide-y border rounded-lg",
                          children: r.map((e) =>
                            t.jsx(
                              "li",
                              {
                                children: t.jsxs("button", {
                                  type: "button",
                                  onClick: () => {
                                    (a(e.page), b(e.id));
                                  },
                                  className: `w-full text-left px-3 py-2 min-h-10 flex justify-between ${S === e.id ? "bg-primary/10" : ""}`,
                                  children: [
                                    t.jsx("span", { children: e.name }),
                                    t.jsxs("span", {
                                      className: "text-muted-foreground",
                                      children: [
                                        H[e.kind],
                                        ", page ",
                                        e.page + 1,
                                      ],
                                    }),
                                  ],
                                }),
                              },
                              e.id,
                            ),
                          ),
                        }),
                    U.length > 0 &&
                      t.jsx(Ne, {
                        testId: "fp-issues",
                        children: U.map((e) => t.jsx("p", { children: e }, e)),
                      }),
                    t.jsxs("div", {
                      className: "grid sm:grid-cols-2 gap-1",
                      children: [
                        t.jsx(Z, {
                          label: "Print each label on the page",
                          checked: j,
                          onChange: y,
                        }),
                        t.jsx(Z, {
                          label: "Draw a border round each field",
                          checked: L,
                          onChange: c,
                        }),
                      ],
                    }),
                    t.jsxs("div", {
                      className: "flex flex-wrap gap-2 items-center",
                      children: [
                        t.jsxs($, {
                          onClick: fe,
                          disabled: C,
                          testId: "fp-download",
                          children: [
                            t.jsx(xe, { className: "h-4 w-4 mr-1" }),
                            C ? "Building..." : "Download fillable PDF",
                          ],
                        }),
                        t.jsx($, {
                          variant: "outline",
                          onClick: () => {
                            (P(!1), v([]), O(null), n(null), k([]));
                          },
                          children: "Start over",
                        }),
                      ],
                    }),
                    t.jsx(ye, {}),
                    M &&
                      t.jsxs("div", {
                        className: "p-3 rounded-lg border space-y-2",
                        "data-testid": "fp-next",
                        children: [
                          t.jsxs("p", {
                            className: "text-sm",
                            children: [
                              "Your form has ",
                              M.count,
                              " field",
                              M.count === 1 ? "" : "s",
                              ". Next:",
                            ],
                          }),
                          t.jsxs("div", {
                            className: "flex flex-wrap gap-2",
                            children: [
                              t.jsxs($, {
                                variant: "outline",
                                onClick: () => oe("fillable-forms"),
                                testId: "fp-to-fill",
                                children: [
                                  t.jsx(Ae, { className: "h-4 w-4 mr-1" }),
                                  "Fill it in (Fillable Forms)",
                                ],
                              }),
                              t.jsxs($, {
                                variant: "outline",
                                onClick: () => oe("sign-pdf"),
                                testId: "fp-to-sign",
                                children: [
                                  t.jsx(Ie, { className: "h-4 w-4 mr-1" }),
                                  "Sign it (Sign PDF)",
                                ],
                              }),
                            ],
                          }),
                        ],
                      }),
                  ],
                }),
              ],
            })
          : t.jsxs(Y, {
              title: "1. Start",
              hint: "Open a PDF to add fields to, or start with blank pages. Your file stays on this device.",
              children: [
                t.jsx(be, {
                  gateAtDownload: !0,
                  accept: ".pdf",
                  onFiles: de,
                  label: "Drop a PDF",
                  description: "Any PDF: a printed form, a contract, a flyer",
                }),
                t.jsxs("div", {
                  className: "p-3 rounded-lg border space-y-3",
                  children: [
                    t.jsx("p", {
                      className: "text-sm font-medium",
                      children: "Or start a blank form",
                    }),
                    t.jsxs("div", {
                      className: "grid grid-cols-2 gap-3",
                      children: [
                        t.jsx(Pe, {
                          label: "Paper",
                          value: l.paper,
                          onChange: (e) => g({ ...l, paper: e }),
                          options: [
                            { value: "letter", label: "US Letter" },
                            { value: "a4", label: "A4" },
                          ],
                          testId: "fp-paper",
                        }),
                        t.jsx(z, {
                          label: "Pages (1 to 20)",
                          inputMode: "numeric",
                          value: String(l.pages),
                          onChange: (e) =>
                            g({ ...l, pages: F(parseInt(e) || 1, 1, 20) }),
                          testId: "fp-pages",
                        }),
                      ],
                    }),
                    t.jsx($, {
                      onClick: ce,
                      testId: "fp-start-blank",
                      children: "Start blank form",
                    }),
                  ],
                }),
              ],
            }),
        t.jsx(ve, { whatIsIt: J.what, howToUse: J.how, tip: J.tip }),
      ],
    }),
  });
}
export { Pt as default };
//# sourceMappingURL=CreateFillablePdf-DH-3Fv8p.js.map
