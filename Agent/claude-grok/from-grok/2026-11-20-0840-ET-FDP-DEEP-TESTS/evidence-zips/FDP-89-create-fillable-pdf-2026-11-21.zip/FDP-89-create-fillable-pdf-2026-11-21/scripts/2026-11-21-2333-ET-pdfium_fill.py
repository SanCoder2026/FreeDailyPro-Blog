# Type into created fields with PDFium's own form-fill engine (the engine inside Chrome's PDF viewer), then render.
import sys, ctypes, pypdfium2 as pdfium, pypdfium2.raw as R, fitz
src, out, tag = sys.argv[1], sys.argv[2], sys.argv[3]
VALS = ['Jonathan Reed', 'राम कुमार', 'Москва', '東京都', 'José Müller']
pdf = pdfium.PdfDocument(src); env = pdf.init_forms(); page = pdf[0]; hp = page.raw; fh = pdf.formenv.raw
R.FORM_OnAfterLoadPage(hp, fh)
i = 0; log = []
n = R.FPDFPage_GetAnnotCount(hp)
for k in range(n):
    a = R.FPDFPage_GetAnnot(hp, k)
    if R.FPDFAnnot_GetSubtype(a) != R.FPDF_ANNOT_WIDGET or R.FPDFAnnot_GetFormFieldType(fh, a) != R.FPDF_FORMFIELD_TEXTFIELD: R.FPDFPage_CloseAnnot(a); continue
    nb = R.FPDFAnnot_GetFormFieldName(fh, a, None, 0); nbuf = ctypes.create_string_buffer(nb); R.FPDFAnnot_GetFormFieldName(fh, a, ctypes.cast(nbuf, ctypes.POINTER(R.FPDF_WCHAR)), nb); name = nbuf.raw.decode('utf-16-le').rstrip('\0')
    ok = R.FORM_SetFocusedAnnot(fh, a)
    v = VALS[i % len(VALS)]; i += 1
    ws = (v + '\0').encode('utf-16-le'); buf = ctypes.create_string_buffer(ws, len(ws))
    R.FORM_SelectAllText(fh, hp); R.FORM_ReplaceSelection(fh, hp, ctypes.cast(buf, R.FPDF_WIDESTRING))
    R.FORM_ForceToKillFocus(fh); log.append(f'{name}={v} focus={ok}'); R.FPDFPage_CloseAnnot(a)
R.FORM_ForceToKillFocus(fh)
img = page.render(scale=1.5, may_draw_forms=True).to_pil(); img.save(out + '/' + tag + '.png')
pdf.save(out + '/' + tag + '.pdf')
print(log)
