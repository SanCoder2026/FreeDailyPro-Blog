// FDP-89 charge check: fresh context at 0/2, one download; logs usage API responses and toasts as they appear.
const pw=require('playwright');const fs=require('fs');const cp=require('child_process');const W='/workspace/deep/89-create-fillable-pdf/';const now=()=>cp.execSync('date "+%F %T %Z"').toString().trim();
(async()=>{const b=await pw.chromium.launch();const R={t:now(),tries:[],log:[]};let c,p;
for(let i=0;i<10;i++){c=await b.newContext({acceptDownloads:true});p=await c.newPage();
 p.on('response',async r=>{const u=r.url();if(/\/api\/.*usage/.test(u)){let t='';try{t=(await r.text()).slice(0,400)}catch{};R.log.push({t:now(),m:r.request().method(),u:u.split('/api/')[1].slice(0,60),body:t.replace(/"deviceId":"[^"]+"/g,'"deviceId":"<redacted>"').replace(/dev:[a-z0-9-]+/gi,'dev:<redacted>')});}});
 await p.goto('https://www.freedailypro.com/tool/create-fillable-pdf',{waitUntil:'domcontentloaded'});await p.waitForTimeout(5000);
 const u=await p.evaluate(()=>{const u=JSON.parse(localStorage.getItem('fdp-usage-v1')||'{}');return u.usageToday+'/'+u.limit});R.tries.push(u);if(u==='0/2')break;await c.close();R.log=[];}
const used=()=>p.evaluate(()=>{const u=JSON.parse(localStorage.getItem('fdp-usage-v1')||'{}');return u.usageToday+'/'+u.limit});
R.before=await used();R.log.push('--- download');
await p.getByTestId('fp-start-blank').click();await p.waitForTimeout(1000);if((await p.getByTestId('fp-kind-text').getAttribute('aria-pressed'))!=='true')await p.getByTestId('fp-kind-text').click();const pg=p.getByTestId('fp-page');await pg.click({position:{x:200,y:200}});
const seen=new Set();await p.getByTestId('fp-download').click();for(let i=0;i<20;i++){for(const t of await p.locator('[data-sonner-toast]').allInnerTexts())seen.add(t.replace(/\s+/g,' '));await p.waitForTimeout(300);}
R.toasts=[...seen];R.after=await used();await p.waitForTimeout(5000);R.after10s=await used();
R.log.push('--- reload');await p.reload();await p.waitForTimeout(6000);R.afterReload=await used();
fs.writeFileSync(W+'live/charge'+(process.env.SUF||'')+'.json',JSON.stringify(R,null,1));console.log(JSON.stringify(R,null,1).slice(0,5000));await b.close();})();
