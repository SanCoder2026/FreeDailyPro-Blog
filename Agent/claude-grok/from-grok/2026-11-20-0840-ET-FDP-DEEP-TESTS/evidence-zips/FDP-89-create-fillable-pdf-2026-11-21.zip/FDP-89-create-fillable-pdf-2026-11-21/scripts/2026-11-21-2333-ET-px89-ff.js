// FDP-89 cross-check: fill a Create-Fillable-PDF output in Fillable Forms (guest, fresh context with uses left). Hindi + long notes.
const pw=require('playwright');const fs=require('fs');const W='/workspace/deep/89-create-fillable-pdf/';
(async()=>{const b=await pw.chromium.launch();let c,p,u;const R={tries:[]};
for(let i=0;i<10;i++){c=await b.newContext({acceptDownloads:true,viewport:{width:1366,height:1000}});p=await c.newPage();await p.goto('https://www.freedailypro.com/tool/fillable-forms',{waitUntil:'domcontentloaded'});await p.waitForTimeout(4500);u=await p.evaluate(()=>{const u=JSON.parse(localStorage.getItem('fdp-usage-v1')||'{}');return u.usageToday+'/'+u.limit});R.tries.push(u);if(u.startsWith('0/'))break;await c.close();}
await p.locator('input[type=file]').first().setInputFiles(W+'live/dl/left-2-fillable-form-fillable.pdf');await p.waitForTimeout(6000);
R.controls=await p.$$eval('main input:not([type=file]), main textarea, main select',els=>els.map(e=>({tag:e.tagName,type:e.type,label:e.getAttribute('aria-label')||e.id||e.name,req:e.required||e.getAttribute('aria-required'),val:e.value})));
R.text=(await p.locator('main').innerText()).slice(0,2500);
const tb=p.locator('main input[type=text], main input:not([type])');const ta=p.locator('main textarea');
if(await tb.count()){await tb.nth(0).fill('राम कुमार शर्मा');} if(await tb.count()>1){await tb.nth(1).fill('Москва 101000');}
if(await ta.count()){await ta.first().fill('Line one notes\nLine two notes\nLine three notes');}
const ch=p.locator('main button',{hasText:'Choose...'});if(await ch.count()){await ch.first().click();await p.waitForTimeout(800);R.radioOptions=await p.locator('[role=option]').allInnerTexts();if(R.radioOptions.length)await p.locator('[role=option]').last().click();await p.waitForTimeout(500);}
const tsA=new Set();
await p.screenshot({path:W+'live/cases/FF01-fillable-forms-filled.png',fullPage:true});
const dl=p.waitForEvent('download',{timeout:20000}).catch(()=>null);const btn=p.locator('main button',{hasText:/^\s*Fill form\s*$/}).filter({hasNotText:/Google|Drive/});R.btns=await btn.allInnerTexts();
if(await btn.count()){await btn.first().click();for(let k=0;k<12;k++){for(const t of await p.locator('[data-sonner-toast]').allInnerTexts())tsA.add(t);await p.waitForTimeout(250);}R.fillToasts=[...tsA];await p.waitForTimeout(5000);const d2=p.locator('main button',{hasText:/Download/});R.btns2=await d2.allInnerTexts();R.after=(await p.locator('main').innerText()).slice(300,1800);R.allBtns=await p.locator('main button').allInnerTexts();await p.screenshot({path:W+'live/cases/FF02-after-fill.png',fullPage:true});if(await d2.count())await d2.first().click();} const d=await dl; if(d){const path=W+'live/dl/ff-filled-'+d.suggestedFilename();await d.saveAs(path);R.saved=path;}
await p.waitForTimeout(2000);R.toasts=await p.locator('[data-sonner-toast]').allInnerTexts();R.dialog=await p.locator('[role=dialog]').allInnerTexts();
fs.writeFileSync(W+'live/ff-crosscheck.json',JSON.stringify(R,null,1));console.log(JSON.stringify(R,null,1).slice(0,4000));await b.close();})();
