// FDP-89 cross-check: flatten the Fillable-Forms-filled Create-Fillable-PDF output in Flatten PDF (guest, fresh context).
const pw=require('playwright');const fs=require('fs');const W='/workspace/deep/89-create-fillable-pdf/';
(async()=>{const b=await pw.chromium.launch();const R={};const c=await b.newContext({acceptDownloads:true,viewport:{width:1366,height:1000}});const p=await c.newPage();
await p.goto('https://www.freedailypro.com/tool/flatten-pdf',{waitUntil:'domcontentloaded'});await p.waitForTimeout(4500);R.usage=await p.evaluate(()=>localStorage.getItem('fdp-usage-v1').match(/"usageToday":\d+,"limit":\d+/)[0]);
await p.locator('input[type=file]').first().setInputFiles(W+'live/dl/ff-filled-filled_left-2-fillable-form-fillable.pdf');await p.waitForTimeout(5000);
R.pre=(await p.locator('main').innerText()).slice(400,1200);
await p.locator('main button',{hasText:/^\s*Flatten PDF\s*$/}).first().click();await p.waitForTimeout(6000);
const dl=p.waitForEvent('download',{timeout:15000}).catch(()=>null);await p.locator('main button',{hasText:/^\s*Download/}).first().click();const d=await dl;if(d){R.saved=W+'live/dl/flattened-ff-filled.pdf';await d.saveAs(R.saved);}
R.dialog=await p.locator('[role=dialog]').allInnerTexts();fs.writeFileSync(W+'live/flatten-crosscheck.json',JSON.stringify(R,null,1));console.log(JSON.stringify(R).slice(0,1500));await b.close();})();
