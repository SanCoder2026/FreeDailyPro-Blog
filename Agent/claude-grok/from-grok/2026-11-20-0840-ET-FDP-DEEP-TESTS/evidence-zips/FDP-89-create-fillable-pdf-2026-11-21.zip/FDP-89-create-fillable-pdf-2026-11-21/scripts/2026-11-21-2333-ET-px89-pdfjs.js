// FDP-89: open created PDFs in pdf.js 4.10 (AnnotationMode.ENABLE_FORMS), list controls, Tab order, fill like a user, save via pdf.js saveDocument.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const W = '/workspace/deep/89-create-fillable-pdf/'; const D = W + 'pdfjs/'; const files = process.argv.slice(2);
const srv = cp.spawn('python3', ['-m', 'http.server', '8789', '--bind', '127.0.0.1'], { cwd: D, stdio: 'ignore' });
const VAL = ['Jonathan Reed', 'राम कुमार', 'Москва', 'José Müller'];
(async () => { await new Promise(r => setTimeout(r, 1200)); const b = await pw.chromium.launch(); const R = {};
 for (const f of files) { const base = f.split('/').pop(); fs.copyFileSync(f, D + base); const p = await (await b.newContext({ viewport: { width: 1000, height: 1300 } })).newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') errs.push(m.text().slice(0, 200)); });
  await p.goto('http://127.0.0.1:8789/viewer.html?f=' + encodeURIComponent(base)); await p.waitForFunction(() => window.__ready, null, { timeout: 20000 }).catch(() => { }); await p.waitForTimeout(1500);
  const controls = await p.$$eval('.annotationLayer input, .annotationLayer textarea, .annotationLayer select', els => els.map(e => ({ tag: e.tagName, type: e.type, name: e.name, required: e.required, ariaReq: e.getAttribute('aria-required'), value: e.type === 'checkbox' || e.type === 'radio' ? e.checked : e.value, fontSize: getComputedStyle(e).fontSize, fontFamily: getComputedStyle(e).fontFamily.slice(0, 40), h: Math.round(e.getBoundingClientRect().height), tabIndex: e.tabIndex, ariaLabel: e.getAttribute('aria-label'), title: e.title })));
  // Tab order
  const tab = []; await p.locator('.annotationLayer input, .annotationLayer textarea, .annotationLayer select').first().focus().catch(() => { });
  for (let i = 0; i < controls.length + 1; i++) { tab.push(await p.evaluate(() => { const a = document.activeElement; return a ? (a.name || a.tagName) + (a.type === 'radio' ? '(' + (a.closest('section')?.dataset.annotationId) + ')' : '') : null; })); await p.keyboard.press('Tab'); }
  // fill like a user
  let ti = 0; const filled = [];
  for (const h of await p.$$('.annotationLayer input, .annotationLayer textarea, .annotationLayer select')) { const t = await h.evaluate(e => e.tagName + ':' + e.type + ':' + e.name);
   try { if (/INPUT:text|TEXTAREA/.test(t)) { const v = VAL[ti++ % VAL.length] + (/TEXTAREA/.test(t) ? '\nSecond line of notes\nThird line' : ''); await h.click(); await h.fill(''); await p.keyboard.type(v); await p.keyboard.press('Tab'); filled.push(t + '=' + v.replace(/\n/g, '/')); }
    else if (/checkbox/.test(t)) { await h.click(); filled.push(t + '=click'); }
    else if (/SELECT/.test(t)) { const o = await h.evaluate(e => [...e.options].map(o => o.value)); await h.selectOption(o[0]); filled.push(t + '=' + o[0]); } } catch (e) { filled.push(t + ' ERR ' + e.message.slice(0, 80)); } }
  const radios = await p.$$('.annotationLayer input[type=radio]'); const radioStates = [];
  for (const r of radios) { await r.click(); radioStates.push(await p.$$eval('.annotationLayer input[type=radio]', els => els.map(e => e.name + ':' + e.checked).join(','))); }
  await p.waitForTimeout(500); await p.screenshot({ path: W + 'verify/pdfjs-' + base.replace('.pdf', '') + '.png' });
  const bytes = await p.evaluate(() => window.__save()).catch(e => null); const out = W + 'verify/pdfjs-saved-' + base; if (bytes) fs.writeFileSync(out, Buffer.from(bytes));
  R[base] = { controls, tab, filled, radioStates, saved: bytes ? out.replace(W, '') : null, errs: errs.slice(0, 10) }; console.log(base, JSON.stringify(R[base]).slice(0, 2500)); await p.context().close(); }
 fs.writeFileSync(W + 'verify/pdfjs.json', JSON.stringify(R, null, 1)); await b.close(); srv.kill(); })();
