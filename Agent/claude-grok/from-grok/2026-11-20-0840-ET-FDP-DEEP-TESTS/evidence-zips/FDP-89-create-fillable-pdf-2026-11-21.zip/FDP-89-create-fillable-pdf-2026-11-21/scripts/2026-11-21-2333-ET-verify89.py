# FDP-89 verify: AcroForm inspection (pikepdf), reader view (PyMuPDF + pypdf), fill-by-script, render.
import sys, json, os, pikepdf, fitz, pypdf, io, warnings
warnings.filterwarnings('ignore')
FF = {1: 'ReadOnly', 2: 'Required', 3: 'NoExport', 13: 'Multiline', 14: 'Password', 15: 'NoToggleToOff', 16: 'Radio', 17: 'Pushbutton', 18: 'Combo', 19: 'Edit', 20: 'Sort', 21: 'FileSelect', 23: 'DoNotSpellCheck', 24: 'DoNotScroll', 25: 'Comb', 26: 'RichText/RadiosInUnison', 27: 'CommitOnSelChange'}
def flags(v): return [n for b, n in FF.items() if v & (1 << (b - 1))]
def S(x): return str(x) if x is not None else None
def inspect(path):
    pdf = pikepdf.open(path); af = pdf.Root.get('/AcroForm'); out = {'file': os.path.basename(path), 'pages': len(pdf.pages), 'acroform': af is not None}
    if af is None: return out
    out['NeedAppearances'] = bool(af.get('/NeedAppearances', False)); out['DA'] = S(af.get('/DA')); out['DR_fonts'] = [str(k) for k in af.get('/DR', {}).get('/Font', {}).keys()] if '/DR' in af else []
    out['has_JS_or_AA'] = any('/AA' in f for f in af.Fields)
    fields = []
    for f in af.Fields:
        kids = f.get('/Kids', [f]); ft = S(f.get('/FT')); ff = int(f.get('/Ff', 0))
        d = {'name': S(f.get('/T')), 'FT': ft, 'flags': flags(ff), 'V': S(f.get('/V')), 'DV': S(f.get('/DV')), 'DA': S(f.get('/DA')), 'MaxLen': S(f.get('/MaxLen')), 'TU': S(f.get('/TU')), 'AA': '/AA' in f, 'Q': S(f.get('/Q'))}
        if '/Opt' in f: d['Opt'] = [S(o) for o in f.Opt]
        w = []
        for k in kids:
            pg = next((i + 1 for i, p in enumerate(pdf.pages) if any(a.objgen == k.objgen for a in p.get('/Annots', []))), None)
            ap = k.get('/AP'); states = sorted(str(s) for s in ap.N.keys()) if ap is not None and isinstance(ap.get('/N'), pikepdf.Dictionary) else ('stream' if ap is not None else None)
            mk = k.get('/MK', {})
            w.append({'page': pg, 'rect': [round(float(x), 1) for x in k.Rect], 'AP_N': states, 'AS': S(k.get('/AS')), 'F': int(k.get('/F', 0)), 'MK_bc': S(mk.get('/BC')) if mk else None, 'MK_ca': S(mk.get('/CA')) if mk else None})
        d['widgets'] = w; fields.append(d)
    out['fields'] = fields
    tabs = []
    for i, p in enumerate(pdf.pages):
        names = []
        for a in p.get('/Annots', []):
            if a.get('/Subtype') == '/Widget':
                par = a.get('/Parent'); names.append(S(a.get('/T')) or (S(par.get('/T')) if par is not None else '?'))
        tabs.append({'page': i + 1, 'Tabs': S(p.get('/Tabs')), 'Rotate': int(p.get('/Rotate', 0)), 'MediaBox': [float(x) for x in p.MediaBox], 'CropBox': [float(x) for x in p.get('/CropBox', p.MediaBox)], 'widget_order': names})
    out['page_info'] = tabs
    out['struct_tree'] = '/StructTreeRoot' in pdf.Root
    return out
def readers(path):
    r = {}
    d = fitz.open(path); r['pymupdf'] = [{'page': p.number + 1, 'name': w.field_name, 'type': w.field_type_string, 'value': w.field_value, 'flags': w.field_flags, 'choices': w.choice_values, 'on_state': (w.on_state() if w.field_type in (2, 5) else None), 'rect': [round(x, 1) for x in w.rect]} for p in d for w in p.widgets()]
    pr = pypdf.PdfReader(path); f = pr.get_fields() or {}
    r['pypdf'] = {k: {'FT': S(v.get('/FT')), 'V': S(v.get('/V')), 'states': [str(s) for s in v.get('/_States_', [])]} for k, v in f.items()}
    r['pypdf_text_fields'] = pr.get_form_text_fields()
    return r
NONLATIN = {'hi': 'राम कुमार', 'ru': 'Москва', 'ja': '東京都', 'ar': 'محمد', 'latin1': 'José Müller-Øster'}
def fill(path, outdir, tag):
    """Fill every field by script with PyMuPDF (regenerates appearances) and with pypdf (auto_regenerate), re-read, render."""
    res = {}
    d = fitz.open(path); txt_i = 0; log = []
    for p in d:
        for w in p.widgets():
            t = w.field_type
            try:
                if t == fitz.PDF_WIDGET_TYPE_TEXT:
                    val = list(NONLATIN.values())[txt_i % len(NONLATIN)]; txt_i += 1; w.field_value = val
                elif t == fitz.PDF_WIDGET_TYPE_CHECKBOX: w.field_value = w.on_state() or True
                elif t == fitz.PDF_WIDGET_TYPE_COMBOBOX:
                    cv = (w.choice_values or [''])[-1]; w.field_value = cv[1] if isinstance(cv, (list, tuple)) else cv
                elif t == fitz.PDF_WIDGET_TYPE_RADIOBUTTON:
                    radios = [x for x in p.widgets() if x.field_name == w.field_name]
                    if w.xref == radios[-1].xref: w.field_value = w.on_state() or True
                    else: continue
                w.update(); log.append(f'{w.field_name}:{w.field_type_string}:{w.field_value}')
            except Exception as e: log.append(f'{w.field_name}: ERROR {e}')
    o1 = os.path.join(outdir, tag + '-filled-pymupdf.pdf'); d.save(o1)
    d2 = fitz.open(o1); res['pymupdf_fill_log'] = log
    res['pymupdf_reread'] = [(w.field_name, w.field_type_string, w.field_value) for p in d2 for w in p.widgets()]
    res['pymupdf_rendered_text'] = d2[0].get_text()[:600]
    pix = d2[0].get_pixmap(dpi=72, annots=True); pix.save(os.path.join(outdir, tag + '-filled-pymupdf-p1.png'))
    # pypdf fill
    try:
        pr = pypdf.PdfReader(path); pw_ = pypdf.PdfWriter(); pw_.append(pr)
        vals = {}
        for k, v in (pr.get_fields() or {}).items():
            ft = S(v.get('/FT'))
            if ft == '/Tx': vals[k] = 'pypdf ' + NONLATIN['latin1']
            elif ft == '/Btn': st = [s for s in v.get('/_States_', []) if s != '/Off']; vals[k] = st[0] if st else '/Yes'
            elif ft == '/Ch':
                o = v.get('/Opt')[-1] if v.get('/Opt') else ''
                vals[k] = S(o[0]) if isinstance(o, (list, pypdf.generic.ArrayObject)) else S(o)
        for page in pw_.pages: pw_.update_page_form_field_values(page, vals, auto_regenerate=True)
        o2 = os.path.join(outdir, tag + '-filled-pypdf.pdf'); pw_.write(o2)
        res['pypdf_values_set'] = vals; res['pypdf_reread'] = {k: S(v.get('/V')) for k, v in (pypdf.PdfReader(o2).get_fields() or {}).items()}
    except Exception as e: res['pypdf_error'] = repr(e)[:300]
    return res
if __name__ == '__main__':
    path = sys.argv[1]; outdir = sys.argv[2]; tag = sys.argv[3]; os.makedirs(outdir, exist_ok=True)
    R = {'inspect': inspect(path), 'readers': readers(path)}
    if len(sys.argv) < 5: R['fill'] = fill(path, outdir, tag)
    d = fitz.open(path); d[0].get_pixmap(dpi=72, annots=True).save(os.path.join(outdir, tag + '-p1.png'))
    json.dump(R, open(os.path.join(outdir, tag + '.json'), 'w'), indent=1, ensure_ascii=False, default=str)
    print(json.dumps(R, ensure_ascii=False, default=str)[:4000])
