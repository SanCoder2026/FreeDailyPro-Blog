import { r as i, j as s } from "./vendor-react-D01g8YgM.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./index-BRvxULIc.js";
import "./fontkit.es-DA-3qwB1.js";
import "./jszip.min-CT0ZA6V1.js";
import "./utils-s8ucLyj8.js";
import "./imageRecompress-eXQFDUm-.js";
import { p as Y, f as ee } from "./formFill-Dg9Myfyq.js";
import "./nameDetect-DvHCRM0m.js";
import { u as se } from "./useRevealDownload-BkGzz0vy.js";
import {
  T as ae,
  F as te,
  P as _,
  D as ie,
  R as le,
} from "./ToolPage-DrleSM7T.js";
import {
  f as n,
  N as ne,
  e as P,
  B as D,
  T as oe,
  I as re,
} from "./index-xgcQ0Xo8.js";
import { C as N } from "./checkbox-CRLgbqRK.js";
import {
  S as de,
  a as me,
  b as ce,
  c as fe,
  d as he,
} from "./select-BuPT3-Y0.js";
import { T as ue } from "./ToolInfoSection-DUdo3Ez7.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./drawTextAnywhere-DcuP6lHH.js";
import "./formAppearance-CdNbuISd.js";
import "./useUploadApi-yCV1cZhw.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-Cl69OhvT.js";
import "./share-2-tv4Mz_hR.js";
import "./copy-B6PRNyNa.js";
import "./workflowCta-BFTpZlex.js";
import "./UsageAndUpgradeStrip-DMhPNgnJ.js";
import "./access-DqVqJd33.js";
import "./useAdminAccess-mVM_2mWb.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-DxfN0Pem.js";
import "./map-pin-CwlIzHDK.js";
import "./FaqSection-BNxk42M5.js";
import "./ToolVideoEmbed-DNaMY2Pn.js";
import "./GuideLinks-D5fn3NI1.js";
import "./blog-CxdB1WyW.js";
import "./info-x67VbErc.js";
import "./productCards-DhpNcELZ.js";
import "./layers-B44Zba7-.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-DhOoIDuZ.js";
import "./index-BdQq_4o_.js";
import "./chevron-up-RK9L2OPY.js";
import "./CollapsibleText-DFD2kyG0.js";
const C = {
  what: "Fills in a PDF's existing fillable form fields — text boxes (any language), checkboxes, dropdowns, list boxes, and radio button groups — directly in your browser, then gives you back a completed PDF. This works with PDFs that already have real form fields built in (an application form, a government form, anything with fillable boxes when you open it in a PDF reader) — it doesn't add form fields to a plain document that doesn't have any.",
  how: `Upload a fillable PDF. Every field it contains shows up as a normal input, checkbox, or dropdown, grouped by page and labelled with the form's own field description when it has one. Fill them in and download. Read-only ("office use") fields are shown but never changed. Optionally flatten the form before downloading, which makes your answers a permanent part of the page instead of still-editable fields.`,
  tip: `If a PDF has no real fillable fields (most scanned forms and many "print and fill by hand" PDFs don't), this tool won't have anything to show — Redact PDF and Organize PDF are for editing a PDF's content directly, not filling structured form fields into an unstructured page. Flattening is one-way: once you download a flattened PDF, the field values can't be edited as fields again in that copy.`,
};
function ns() {
  const [h, u] = i.useState(null),
    [S, T] = i.useState(null),
    [m, y] = i.useState([]),
    [d, p] = i.useState({}),
    [g, x] = i.useState({}),
    [b, w] = i.useState({}),
    [O, F] = i.useState(!1),
    [M, L] = i.useState(!1),
    [U, $] = i.useState(!1),
    [z, A] = i.useState(!1),
    [c, o] = i.useState(null),
    E = se(!!c),
    [I, j] = i.useState([]),
    [R, v] = i.useState(!1),
    H = i.useCallback(async (e) => {
      const t = e[0];
      if (t) {
        (u(t), o(null), j([]), F(!1), v(!1), $(!0));
        try {
          const a = await Y(t);
          (T(a.pdfDoc),
            y(a.fields),
            p(a.initialValues),
            x(a.initialChecked),
            w(a.initialLists),
            L(a.hasXfa),
            a.hasXfa
              ? n.warning(
                  "This is an XFA form (Adobe LiveCycle). Its fields can't be filled here — open it in Adobe Acrobat, or use PDF Editor to type on the page.",
                )
              : a.fields.length === 0
                ? n.warning(
                    "This PDF doesn't have any fillable form fields — use PDF Editor to type on the page, or Sign PDF to add a signature",
                  )
                : a.fields.every(
                    (r) => r.kind === "unsupported" || r.kind === "signature",
                  ) &&
                  n.warning(
                    "This PDF's only fields are signatures or buttons — use Sign PDF to sign it",
                  ));
        } catch (a) {
          (console.error("Couldn't read this PDF's form:", a),
            n.error(
              "Couldn't read this PDF — it may be corrupted or password-protected",
            ),
            u(null));
        } finally {
          $(!1);
        }
      }
    }, []),
    l = m.filter((e) => e.kind !== "unsupported" && e.kind !== "signature"),
    Z = (e) =>
      e.kind === "text"
        ? !(d[e.name] ?? "").trim()
        : e.kind === "checkbox"
          ? !g[e.name]
          : e.kind === "list"
            ? !(b[e.name] ?? []).length
            : !d[e.name],
    f = l.filter((e) => e.required && !e.readOnly && Z(e)),
    G = async () => {
      if (!(!S || !h)) {
        if (f.length > 0 && !R) {
          (v(!0),
            n.warning(
              `${f.length} required field${f.length === 1 ? " is" : "s are"} empty — fill ${f.length === 1 ? "it" : "them"}, or press Fill form again to continue anyway`,
            ));
          return;
        }
        A(!0);
        try {
          let e;
          const t = await Promise.race([
            ee(S, m, d, g, O, b),
            new Promise((a, r) => {
              e = setTimeout(() => r(new Error("fill-timeout")), 6e4);
            }),
          ]).finally(() => {
            e && clearTimeout(e);
          });
          (o(t.blob),
            j(t.failed),
            t.failed.length > 0
              ? n.error(
                  `Couldn't fill: ${t.failed.map((a) => a.name).join(", ")}. The other answers were saved.`,
                )
              : n.success("Form filled!"));
        } catch (e) {
          (console.error("Couldn't fill this form:", e),
            n.error(
              e instanceof Error && e.message === "fill-timeout"
                ? "This form is taking too long on this device. Try again, or use a smaller PDF."
                : "Something went wrong filling this form — try again",
            ));
        } finally {
          A(!1);
        }
      }
    },
    X = () => {
      (u(null),
        T(null),
        y([]),
        p({}),
        x({}),
        w({}),
        o(null),
        j([]),
        L(!1),
        F(!1),
        v(!1));
    },
    k = (e, t) => {
      (p((a) => ({ ...a, [e]: t })), o(null));
    },
    q = Array.from(new Set(l.map((e) => e.page))).sort(
      (e, t) => (e ?? 1e9) - (t ?? 1e9),
    ),
    J = q.length > 1,
    K = (e) => {
      const t = R && f.includes(e);
      return s.jsxs(
        "div",
        {
          className: t ? "rounded border border-red-500/60 p-2" : void 0,
          children: [
            s.jsxs(P, {
              className: "text-xs text-muted-foreground",
              htmlFor: `f-${e.name}`,
              children: [
                e.label,
                e.required &&
                  s.jsx("span", {
                    className: "text-red-500",
                    "aria-label": "required",
                    children: " *",
                  }),
                e.readOnly && " (read only)",
              ],
            }),
            e.kind === "text" &&
              (e.multiline
                ? s.jsx(oe, {
                    id: `f-${e.name}`,
                    rows: 4,
                    disabled: e.readOnly,
                    maxLength: e.maxLength,
                    value: d[e.name] ?? "",
                    onChange: (a) => k(e.name, a.target.value),
                  })
                : s.jsx(re, {
                    id: `f-${e.name}`,
                    disabled: e.readOnly,
                    maxLength: e.maxLength,
                    value: d[e.name] ?? "",
                    onChange: (a) => k(e.name, a.target.value),
                  })),
            e.kind === "text" && e.maxLength
              ? s.jsxs("p", {
                  className: "text-[11px] text-muted-foreground mt-0.5",
                  children: [e.maxLength, " characters at most"],
                })
              : null,
            e.kind === "checkbox" &&
              s.jsxs("div", {
                className: "flex items-center gap-2 mt-1",
                children: [
                  s.jsx(N, {
                    checked: !!g[e.name],
                    disabled: e.readOnly,
                    onCheckedChange: () => {
                      (x((a) => ({ ...a, [e.name]: !a[e.name] })), o(null));
                    },
                    id: `f-${e.name}`,
                  }),
                  s.jsx(P, {
                    htmlFor: `f-${e.name}`,
                    className: "font-normal cursor-pointer",
                    children: "Checked",
                  }),
                ],
              }),
            (e.kind === "dropdown" || e.kind === "radio") &&
              s.jsxs(de, {
                value: d[e.name] ?? "",
                disabled: e.readOnly,
                onValueChange: (a) => k(e.name, a),
                children: [
                  s.jsx(me, {
                    id: `f-${e.name}`,
                    children: s.jsx(ce, { placeholder: "Choose..." }),
                  }),
                  s.jsx(fe, {
                    children: (e.options ?? []).map((a) =>
                      s.jsx(he, { value: a, children: a }, a),
                    ),
                  }),
                ],
              }),
            e.kind === "list" &&
              s.jsx("div", {
                className:
                  "mt-1 space-y-1 border rounded p-2 max-h-40 overflow-y-auto",
                children: (e.options ?? []).map((a) => {
                  const r = (b[e.name] ?? []).includes(a);
                  return s.jsxs(
                    "label",
                    {
                      className:
                        "flex items-center gap-2 text-sm cursor-pointer",
                      children: [
                        s.jsx(N, {
                          checked: r,
                          disabled: e.readOnly,
                          onCheckedChange: () => {
                            (w((B) => {
                              const V = B[e.name] ?? [],
                                Q = r
                                  ? V.filter((W) => W !== a)
                                  : e.multiSelect
                                    ? [...V, a]
                                    : [a];
                              return { ...B, [e.name]: Q };
                            }),
                              o(null));
                          },
                        }),
                        a,
                      ],
                    },
                    a,
                  );
                }),
              }),
          ],
        },
        e.name,
      );
    };
  return s.jsxs(ae, {
    children: [
      h
        ? U
          ? s.jsx(_, { message: "Reading form fields..." })
          : s.jsxs("div", {
              className: "space-y-4",
              children: [
                s.jsx("div", {
                  className: "flex items-center justify-between",
                  children: s.jsxs("p", {
                    className: "text-sm font-medium",
                    children: [
                      h.name,
                      " -- ",
                      l.length,
                      " fillable field",
                      l.length === 1 ? "" : "s",
                    ],
                  }),
                }),
                M &&
                  s.jsx(ne, {
                    className: "text-sm",
                    children:
                      "This is an XFA form (Adobe LiveCycle), which can't be filled in a browser tool. Open it in Adobe Acrobat, or use PDF Editor to type on the page.",
                  }),
                m.some((e) => e.kind === "signature") &&
                  s.jsxs("p", {
                    className: "text-xs text-muted-foreground",
                    children: [
                      "Signature field",
                      m.filter((e) => e.kind === "signature").length === 1
                        ? ""
                        : "s",
                      ": ",
                      m
                        .filter((e) => e.kind === "signature")
                        .map((e) => e.label)
                        .join(", "),
                      " — use Sign PDF to sign.",
                    ],
                  }),
                l.length > 0 &&
                  s.jsx("div", {
                    className: "space-y-4 max-h-[500px] overflow-y-auto pr-2",
                    children: q.map((e) =>
                      s.jsxs(
                        "div",
                        {
                          className: "space-y-3",
                          children: [
                            J &&
                              s.jsx("h3", {
                                className: "text-sm font-semibold pt-1",
                                children:
                                  e === null ? "Other fields" : `Page ${e + 1}`,
                              }),
                            l.filter((t) => t.page === e).map(K),
                          ],
                        },
                        String(e),
                      ),
                    ),
                  }),
                l.length > 0 &&
                  s.jsxs("div", {
                    className: "flex items-center gap-2 pt-2 border-t",
                    children: [
                      s.jsx(N, {
                        checked: O,
                        onCheckedChange: () => {
                          (F((e) => !e), o(null));
                        },
                        id: "flatten",
                      }),
                      s.jsx(P, {
                        htmlFor: "flatten",
                        className: "font-normal cursor-pointer",
                        children:
                          "Flatten (make answers permanent, no longer editable as fields)",
                      }),
                    ],
                  }),
                I.length > 0 &&
                  s.jsxs("div", {
                    className:
                      "p-3 rounded-lg border border-red-500/50 bg-red-500/10 text-sm space-y-0.5",
                    children: [
                      s.jsx("p", {
                        className: "font-medium",
                        children:
                          "Couldn't fill these fields (everything else was saved):",
                      }),
                      I.map((e) =>
                        s.jsxs(
                          "p",
                          {
                            className: "text-xs",
                            children: ["• ", e.name, ": ", e.reason],
                          },
                          e.name,
                        ),
                      ),
                    ],
                  }),
                s.jsx("div", {
                  className: "flex gap-3",
                  children: z
                    ? s.jsx(_, {})
                    : c
                      ? s.jsxs(s.Fragment, {
                          children: [
                            s.jsx("div", {
                              ref: E.ref,
                              className: E.className,
                              children: s.jsx(ie, {
                                blob: c,
                                fileName: `filled_${h.name}`,
                              }),
                            }),
                            s.jsx(D, {
                              variant: "outline",
                              onClick: X,
                              children: "New",
                            }),
                          ],
                        })
                      : s.jsxs(s.Fragment, {
                          children: [
                            l.length > 0 &&
                              s.jsx(D, { onClick: G, children: "Fill form" }),
                            s.jsx(D, {
                              variant: "ghost",
                              onClick: X,
                              children:
                                l.length > 0 ? "Reset" : "Choose another file",
                            }),
                          ],
                        }),
                }),
                c && s.jsx(le, { blob: c, mimeType: "application/pdf" }),
              ],
            })
        : s.jsx(te, {
            gateAtDownload: !0,
            accept: ".pdf",
            onFiles: H,
            label: "Drop a fillable PDF",
            description:
              "Forms with real fillable fields — applications, government forms, and similar",
          }),
      s.jsx(ue, { whatIsIt: C.what, howToUse: C.how, tip: C.tip }),
    ],
  });
}
export { ns as default };
//# sourceMappingURL=FillableForms-CxYEAwQ6.js.map
