import {
  k as h,
  P as d,
  b as F,
  h as k,
  l as x,
  i as P,
  m as y,
  j as b,
  n as A,
  f as D,
  c as L,
  e as w,
  d as O,
} from "./index-BRvxULIc.js";
import { p as T } from "./utils-s8ucLyj8.js";
import { needsPicture as M } from "./drawTextAnywhere-DcuP6lHH.js";
import { s as S, r as v, a as N, d as R } from "./formAppearance-CdNbuISd.js";
const p = 100,
  j = (s) => (s === p ? void 0 : s),
  B = (s) => {
    const a = s.split(".");
    return (
      (a[a.length - 1] || s)
        .replace(/\[\d+\]$/g, "")
        .replace(/[_]+/g, " ")
        .trim() || s
    );
  };
function E(s, a) {
  try {
    const r = a.acroField.getWidgets();
    if (r.length === 0) return null;
    const g = s.context.getObjectRef(r[0].dict);
    if (!g) return null;
    const m = s.getPages();
    for (let o = 0; o < m.length; o++) {
      const l = m[o].node.lookupMaybe(d.of("Annots"), D);
      if (l)
        for (let i = 0; i < l.size(); i++) {
          const u = l.get(i);
          if (u instanceof L && u.objectNumber === g.objectNumber) return o;
        }
    }
  } catch {}
  return null;
}
function C(s) {
  const a = s.acroField.dict.get(d.of("TU"));
  return ((a instanceof w || a instanceof O) && a.decodeText().trim()) || null;
}
async function G(s) {
  const a = await h.load(new Uint8Array(await s.arrayBuffer())),
    g = !!a.catalog.lookupMaybe(d.of("AcroForm"), F)?.get(d.of("XFA")),
    m = a.getForm(),
    o = {},
    l = {},
    i = {},
    u = m.getFields().map((e) => {
      const c = e.getName(),
        t = {
          name: c,
          field: e,
          label: C(e) ?? B(c),
          page: E(a, e),
          readOnly: e.isReadOnly(),
          required: e.isRequired(),
        };
      if (e instanceof k)
        return (
          (o[c] = e.getText() ?? ""),
          {
            ...t,
            kind: "text",
            multiline: e.isMultiline(),
            maxLength: j(e.getMaxLength()),
          }
        );
      if (e instanceof x)
        return ((l[c] = e.isChecked()), { ...t, kind: "checkbox" });
      if (e instanceof P) {
        const n = e.getSelected();
        return (
          n.length && (o[c] = n[0]),
          { ...t, kind: "dropdown", options: e.getOptions() }
        );
      }
      if (e instanceof y) {
        const n = e.getSelected();
        return (
          n && (o[c] = n),
          { ...t, kind: "radio", options: e.getOptions() }
        );
      }
      return e instanceof b
        ? ((i[c] = e.getSelected()),
          {
            ...t,
            kind: "list",
            options: e.getOptions(),
            multiSelect: e.isMultiselect(),
          })
        : e instanceof A
          ? { ...t, kind: "signature" }
          : { ...t, kind: "unsupported" };
    });
  return {
    pdfDoc: a,
    fields: u,
    initialValues: o,
    initialChecked: l,
    initialLists: i,
    hasXfa: g,
  };
}
async function W(s, a, r, g, m, o = {}) {
  const l = s.getForm(),
    i = [],
    u = [],
    e = (t, n) => i.push({ name: t, reason: n });
  for (const t of a)
    if (!t.readOnly)
      try {
        if (t.kind === "text") {
          const n = t.field,
            f = r[t.name] ?? "";
          if (
            (!t.maxLength &&
              n.getMaxLength() === p &&
              Array.from(f).length > p &&
              n.setMaxLength(void 0),
            t.maxLength && Array.from(f).length > t.maxLength)
          ) {
            e(t.name, `too long (${t.maxLength} characters at most)`);
            continue;
          }
          M(f) ? (await S(s, n, f), u.push(t.name)) : n.setText(f);
        } else if (t.kind === "checkbox") {
          const n = t.field;
          g[t.name] ? n.check() : n.uncheck();
        } else if (t.kind === "dropdown") {
          const n = r[t.name];
          n && t.field.select(n);
        } else if (t.kind === "radio") {
          const n = r[t.name];
          n && t.field.select(n);
        } else if (t.kind === "list") {
          const n = t.field,
            f = o[t.name] ?? [];
          (n.clear(), f.length && n.select(f));
        }
      } catch (n) {
        e(t.name, String(n?.message ?? n).slice(0, 120));
      }
  if ((i.push(...(await v(s))), N(s), m))
    try {
      (l.flatten({ updateFieldAppearances: !1 }), R(s));
    } catch (t) {
      e("(flatten)", String(t?.message ?? t).slice(0, 120));
    }
  s.setProducer("FreeDailyPro");
  const c = await s.save({ updateFieldAppearances: !1 });
  return { blob: T(c), failed: i, pictureFields: u };
}
export { W as f, G as p };
//# sourceMappingURL=formFill-Dg9Myfyq.js.map
