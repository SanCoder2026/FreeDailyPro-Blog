import { r } from "./vendor-react-D01g8YgM.js";
const c = "ring-2 ring-primary ring-offset-2 rounded-md animate-pulse",
  i = 2500;
function u(t) {
  if (!t || typeof t.scrollIntoView != "function") return !1;
  try {
    t.scrollIntoView({ behavior: "smooth", block: "center" });
  } catch {
    t.scrollIntoView();
  }
  return !0;
}
function a(t) {
  const o = r.useRef(null),
    [n, e] = r.useState(!1);
  return (
    r.useEffect(() => {
      if (!t) {
        e(!1);
        return;
      }
      (u(o.current), e(!0));
      const s = setTimeout(() => e(!1), i);
      return () => clearTimeout(s);
    }, [t]),
    { ref: o, className: n ? c : "" }
  );
}
export { a as u };
//# sourceMappingURL=useRevealDownload-BkGzz0vy.js.map
