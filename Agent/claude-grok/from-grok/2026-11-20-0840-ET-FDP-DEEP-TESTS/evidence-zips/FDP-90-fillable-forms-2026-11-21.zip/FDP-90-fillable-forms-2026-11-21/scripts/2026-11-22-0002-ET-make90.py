# FDP-90 test forms: calc/format JS, export values, MaxLen/comb/auto-size, pure XFA, owner-password-only, multi-page partial.
import pikepdf
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
T = 'testfiles/'
def base(fn, title, build):
    c = canvas.Canvas(T + fn, pagesize=letter); c.setFont('Helvetica-Bold', 14); c.drawString(72, 740, title); c.setFont('Helvetica', 10); f = c.acroForm; build(c, f); c.save()
# 1 calc.pdf
def b1(c, f):
    for i, (n, y) in enumerate([('qty', 680), ('price', 640), ('total', 600), ('dob', 560)]):
        c.drawString(72, y + 5, n); f.textfield(name=n, x=160, y=y, width=150, height=20, fontSize=10, borderWidth=1)
base('calc.pdf', 'Order form with calculated total', b1)
p = pikepdf.open(T + 'calc.pdf', allow_overwriting_input=True); af = p.Root.AcroForm
F = {str(x.T): x for x in af.Fields}
js = lambda s: p.make_indirect(pikepdf.Dictionary(S=pikepdf.Name.JavaScript, JS=pikepdf.String(s)))
for n in ('qty', 'price'):
    F[n].AA = pikepdf.Dictionary(F=js('AFNumber_Format(2, 0, 0, 0, "", true);'), K=js('AFNumber_Keystroke(2, 0, 0, 0, "", true);'))
F['total'].AA = pikepdf.Dictionary(C=js('AFSimple_Calculate("PRD", new Array ("qty", "price"));'), F=js('AFNumber_Format(2, 0, 0, 0, "$", true);'))
F['total'].V = pikepdf.String('0.00'); F['total'].Ff = 1  # read-only computed
F['dob'].AA = pikepdf.Dictionary(F=js('AFDate_FormatEx("mm/dd/yyyy");'), K=js('AFDate_KeystrokeEx("mm/dd/yyyy");'))
af.CO = pikepdf.Array([F['total']])
p.save(T + 'calc.pdf')
# 2 exports.pdf
def b2(c, f):
    c.drawString(72, 685, 'Agree (on-state /Agreed)'); f.checkbox(name='agree', x=250, y=680, size=16, buttonStyle='check')
    c.drawString(72, 645, 'Size radio (S/M/L)')
    for i, v in enumerate(['S', 'M', 'L']): f.radio(name='size', value=v, x=250 + i * 40, y=640, size=16); c.drawString(270 + i * 40, 645, v)
    c.drawString(72, 605, 'Pet checkbox kids (Dog/Cat)'); f.checkbox(name='petdog', x=250, y=600, size=16); f.checkbox(name='petcat', x=300, y=600, size=16)
    c.drawString(72, 565, 'Plan radio with /Opt'); 
    for i, v in enumerate(['0', '1']): f.radio(name='plan', value=v, x=250 + i * 60, y=560, size=16)
    c.drawString(270, 565, 'Basic'); c.drawString(330, 565, 'Premium plus')
base('exports.pdf', 'Checkbox and radio export values', b2)
p = pikepdf.open(T + 'exports.pdf', allow_overwriting_input=True); af = p.Root.AcroForm
def ren(w, old, new):
    for k in ('/N', '/D'):
        d = w.AP.get(k)
        if d is not None and old in d: d[new] = d[old]; del d[old]
    if w.get('/AS') == old: w.AS = pikepdf.Name(new)
fields = list(af.Fields); keep = []
for fl in fields:
    n = str(fl.T)
    if n == 'agree': ren(fl, '/Yes', '/Agreed')
    elif n in ('petdog', 'petcat'):
        ren(fl, '/Yes', '/Dog' if n == 'petdog' else '/Cat')
    else: keep.append(fl)
# merge petdog/petcat into one checkbox field 'pets' with two kids
dog = [x for x in fields if str(x.get('/T')) == 'petdog'][0]; cat = [x for x in fields if str(x.get('/T')) == 'petcat'][0]
pets = p.make_indirect(pikepdf.Dictionary(FT=pikepdf.Name.Btn, T=pikepdf.String('pets'), Kids=pikepdf.Array([dog, cat]), V=pikepdf.Name.Off))
for k in (dog, cat):
    del k['/T']; del k['/FT']; k.Parent = pets
    if '/V' in k: del k['/V']
for fl in keep:
    if str(fl.T) == 'plan': fl.Opt = pikepdf.Array([pikepdf.String('Basic'), pikepdf.String('Premium plus')])
af.Fields = pikepdf.Array([x for x in fields if x.objgen not in (dog.objgen, cat.objgen)] + [pets])
p.save(T + 'exports.pdf')
# 3 limits.pdf
def b3(c, f):
    rows = [('max100', 680, 400, 20), ('max5', 640, 120, 20), ('ssn_comb', 600, 180, 20), ('auto0', 560, 300, 20), ('notes_auto', 440, 400, 100), ('notes_12', 320, 400, 100)]
    for n, y, w, h in rows: c.drawString(72, y + h + 3, n); f.textfield(name=n, x=72, y=y, width=w, height=h, fontSize=10, borderWidth=1, fieldFlags='multiline' if n.startswith('notes') else '')
base('limits.pdf', 'MaxLen, comb and auto-size fields', b3)
p = pikepdf.open(T + 'limits.pdf', allow_overwriting_input=True)
for fl in p.Root.AcroForm.Fields:
    n = str(fl.T)
    if n == 'max100': fl.MaxLen = 100
    if n == 'max5': fl.MaxLen = 5
    if n in ('auto0', 'notes_auto', 'notes_12'): del fl['/MaxLen']
    if n == 'ssn_comb': fl.MaxLen = 9; fl.Ff = int(fl.get('/Ff', 0)) | (1 << 24)
    if n in ('auto0', 'notes_auto'): fl.DA = pikepdf.String('/Helv 0 Tf 0 g')
p.save(T + 'limits.pdf')
# 4 xfa-dynamic.pdf: pure XFA shell (no AcroForm fields), as Adobe LiveCycle dynamic forms
c = canvas.Canvas(T + 'xfa-dynamic.pdf', pagesize=letter); c.drawString(72, 700, 'Please wait... If this message is not eventually replaced by the proper contents of the document, your PDF viewer may not be able to display this type of document.'); c.save()
p = pikepdf.open(T + 'xfa-dynamic.pdf', allow_overwriting_input=True)
xdp = b'<?xml version="1.0"?><xdp:xdp xmlns:xdp="http://ns.adobe.com/xdp/"><template xmlns="http://www.xfa.org/schema/xfa-template/3.3/"><subform name="form1"><field name="Name"/></subform></template></xdp:xdp>'
p.Root.AcroForm = p.make_indirect(pikepdf.Dictionary(Fields=pikepdf.Array([]), XFA=p.make_stream(xdp)))
p.Root.NeedsRendering = True
p.save(T + 'xfa-dynamic.pdf')
# 5 owner-only.pdf: form.pdf restricted with owner password only (opens without a password, like many government forms)
p = pikepdf.open(T + 'form.pdf'); p.save(T + 'owner-only.pdf', encryption=pikepdf.Encryption(owner='ownerpw', user='', allow=pikepdf.Permissions(modify_form=True, modify_other=False, extract=False)))
print('ok')
