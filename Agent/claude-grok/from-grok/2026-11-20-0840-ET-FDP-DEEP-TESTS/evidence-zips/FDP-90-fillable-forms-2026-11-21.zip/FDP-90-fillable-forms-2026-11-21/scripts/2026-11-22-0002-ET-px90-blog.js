const pw=require('playwright');const fs=require('fs');(async()=>{const b=await pw.chromium.launch();const c=await b.newContext({viewport:{width:1366,height:900}});const p=await c.newPage();
for(const s of ['fillable-forms','turn-a-flat-pdf-into-a-fillable-form-with-checkboxes-and-dropdowns']){await p.goto('https://www.freedailypro.com/blog/'+s,{waitUntil:'domcontentloaded',timeout:45000});await p.waitForTimeout(5000);
const t=await p.evaluate(()=>(document.querySelector('article')||document.querySelector('main')).innerText);fs.writeFileSync('/workspace/deep/90-fillable-forms/blog/'+s+'.txt',t);await p.screenshot({path:'/workspace/deep/90-fillable-forms/blog/'+s+'-fold.png'});console.log(s,t.length);}
await b.close();})();
