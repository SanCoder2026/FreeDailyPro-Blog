# FDP-90 verify a filled output: values (pikepdf/pypdf/PyMuPDF), XFA, NeedAppearances, appearance fonts/sizes/images, widgets left, text layer, hidden leak, renders (MuPDF + PDFium).
import sys, json, os, re, pikepdf, fitz, pypdf, warnings
warnings.filterwarnings('ignore')
def S(x): return None if x is None else str(x)
def ap_info(w):
    ap = w.get('/AP'); 
    if ap is None: return None
    n = ap.get('/N')
    if isinstance(n, pikepdf.Dictionary) and not isinstance(n, pikepdf.Stream): return {'states': sorted(str(k) for k in n.keys())}
    try: data = n.read_bytes().decode('latin1')
    except Exception: data = ''
    res = n.get('/Resources', {}); xo = res.get('/XObject', {}) if res else {}
    sizes = re.findall(r'/(\S+)\s+([\d.]+)\s+Tf', data)
    imgs = 0; nested_fonts = []
    for k, v in (xo.items() if xo else []):
        if v.get('/Subtype') == '/Image': imgs += 1
        elif v.get('/Subtype') == '/Form':
            r2 = v.get('/Resources', {}); 
            for k2, v2 in (r2.get('/XObject', {}).items() if r2 and '/XObject' in r2 else []):
                if v2.get('/Subtype') == '/Image': imgs += 1
            if r2 and '/Font' in r2: nested_fonts += [str(f.get('/BaseFont')) for f in r2.Font.values()]
            try: sizes += re.findall(r'/(\S+)\s+([\d.]+)\s+Tf', v.read_bytes().decode('latin1'))
            except Exception: pass
    fonts = [str(f.get('/BaseFont')) for f in res.Font.values()] if res and '/Font' in res else []
    return {'Tf': sizes[:4], 'fonts': fonts + nested_fonts, 'images': imgs, 'bbox': [round(float(x)) for x in n.get('/BBox', [])]}
def run(path, outdir, tag, orig=None):
    os.makedirs(outdir, exist_ok=True); pdf = pikepdf.open(path); af = pdf.Root.get('/AcroForm'); R = {'file': os.path.basename(path), 'size': os.path.getsize(path), 'pages': len(pdf.pages)}
    R['xfa'] = bool(af is not None and '/XFA' in af); R['NeedAppearances'] = bool(af.get('/NeedAppearances', False)) if af is not None else None
    R['CO'] = af is not None and '/CO' in af
    R['producer'] = S(pdf.docinfo.get('/Producer')) if pdf.docinfo else None
    fields = []
    def walk(f, pre=''):
        n = (pre + '.' if pre else '') + str(f.get('/T', ''))
        kids = f.get('/Kids')
        if kids is not None and len(kids) and '/T' in kids[0]:
            for k in kids: walk(k, n); return
        ws = list(kids) if kids is not None else [f]
        fields.append({'name': n[-45:], 'FT': S(f.get('/FT') or (f.get('/Parent') or {}).get('/FT')), 'V': S(f.get('/V'))[:120] if f.get('/V') is not None else None, 'DA': S(f.get('/DA')), 'MaxLen': S(f.get('/MaxLen')), 'Ff': int(f.get('/Ff', 0)), 'AA': '/AA' in f, 'widgets': [{'AS': S(w.get('/AS')), 'F': int(w.get('/F', 0)), 'ap': ap_info(w)} for w in ws]})
    if af is not None:
        for f in af.Fields: walk(f)
    R['fields'] = fields
    d = fitz.open(path); R['widgets_left'] = sum(1 for p in d for _ in p.widgets()); R['text_p1'] = d[0].get_text()[:900]
    R['hidden_leak'] = sum(p.get_text().count('HIDDEN FIELD VALUE') for p in d)
    R['images_on_pages'] = [len(p.get_images()) for p in d][:5]
    d[0].get_pixmap(dpi=72, annots=True).save(os.path.join(outdir, tag + '-mupdf-p1.png'))
    try:
        import pypdfium2 as pdfium
        pd = pdfium.PdfDocument(path); pd.init_forms(); pd[0].render(scale=1, may_draw_forms=True).to_pil().save(os.path.join(outdir, tag + '-pdfium-p1.png'))
    except Exception as e: R['pdfium_err'] = repr(e)[:200]
    try:
        r = pypdf.PdfReader(path); R['pypdf'] = {k[-45:]: S(v.get('/V'))[:80] if v.get('/V') is not None else None for k, v in (r.get_fields() or {}).items()}
    except Exception as e: R['pypdf_err'] = repr(e)[:200]
    json.dump(R, open(os.path.join(outdir, tag + '.json'), 'w'), indent=1, ensure_ascii=False)
    return R
if __name__ == '__main__':
    R = run(sys.argv[1], sys.argv[2], sys.argv[3]); print(json.dumps(R, ensure_ascii=False)[:3500])
