import { r as x, j as t } from "./vendor-react-D01g8YgM.js";
import { T as Pt } from "./ToolWithSidebar-CO7i-D3n.js";
import { F as Dt, P as $t, D as St } from "./ToolPage-DrleSM7T.js";
import {
  v as et,
  N as ke,
  B as j,
  cv as Mt,
  X as Fe,
  f as q,
} from "./index-xgcQ0Xo8.js";
import { l as Tt, r as Et, p as zt } from "./utils-s8ucLyj8.js";
import { u as Rt } from "./useRevealDownload-BkGzz0vy.js";
import { p as tt, f as Lt } from "./formFill-Dg9Myfyq.js";
import { i as Wt, n as _e, N as At } from "./pdfLoadError-Bi-AAFkg.js";
import {
  k as It,
  t as Bt,
  u as je,
  f as Ut,
  C as Ht,
  y as Ot,
} from "./index-BRvxULIc.js";
import { p as Xt } from "./pageView-BQIwVYOi.js";
import { drawTextAnywhere as _t } from "./drawTextAnywhere-DcuP6lHH.js";
import { M as Yt } from "./mouse-pointer-2-B8tUhONe.js";
import { S as Ye } from "./square-BzMZ38nB.js";
import { P as Gt } from "./pencil-DXn808aj.js";
import { E as Kt } from "./eraser-C38Ls0AY.js";
import { I as Vt } from "./image-plus-BWlqbbtR.js";
import { U as qt } from "./undo-2-B7THajEr.js";
import { R as Jt } from "./redo-2-pYa4teg3.js";
import { C as Zt } from "./chevron-left-DFs0oPKQ.js";
import { C as Qt } from "./chevron-right-DfvQFVRV.js";
import { G as es } from "./grip-vertical-D-ubK7Rw.js";
import { T as ts } from "./trash-2-DBtfaxvp.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./CollapsibleText-DFD2kyG0.js";
import "./chevron-up-RK9L2OPY.js";
import "./useUploadApi-yCV1cZhw.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-Cl69OhvT.js";
import "./share-2-tv4Mz_hR.js";
import "./copy-B6PRNyNa.js";
import "./workflowCta-BFTpZlex.js";
import "./UsageAndUpgradeStrip-DMhPNgnJ.js";
import "./access-DqVqJd33.js";
import "./useAdminAccess-mVM_2mWb.js";
import "./InstallToolButton-DxfN0Pem.js";
import "./map-pin-CwlIzHDK.js";
import "./FaqSection-BNxk42M5.js";
import "./ToolVideoEmbed-DNaMY2Pn.js";
import "./GuideLinks-D5fn3NI1.js";
import "./blog-CxdB1WyW.js";
import "./info-x67VbErc.js";
import "./productCards-DhpNcELZ.js";
import "./layers-B44Zba7-.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./formAppearance-CdNbuISd.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./fontkit.es-DA-3qwB1.js";
const ss = et("Circle", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
]);
const os = et("TextCursorInput", [
    ["path", { d: "M5 4h1a3 3 0 0 1 3 3 3 3 0 0 1 3-3h1", key: "18xjzo" }],
    ["path", { d: "M13 20h-1a3 3 0 0 1-3-3 3 3 0 0 1-3 3H5", key: "fj48gi" }],
    ["path", { d: "M5 16H4a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h1", key: "1n9rhb" }],
    ["path", { d: "M13 8h7a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-7", key: "13ksps" }],
    ["path", { d: "M9 7v10", key: "1vc8ob" }],
  ]),
  rs = (a, c) => [
    a[0] * c[0] + a[2] * c[1],
    a[1] * c[0] + a[3] * c[1],
    a[0] * c[2] + a[2] * c[3],
    a[1] * c[2] + a[3] * c[3],
    a[0] * c[4] + a[2] * c[5] + a[4],
    a[1] * c[4] + a[3] * c[5] + a[5],
  ];
function as(a, c) {
  const u = [];
  for (const l of a) {
    if (!l.str || (!l.str.trim() && l.str.length === 0)) continue;
    const r = rs(c.transform, l.transform),
      g = Math.hypot(r[2], r[3]);
    if (g < 3 || Math.abs(r[1]) > 0.02 * Math.abs(r[0]) || r[0] <= 0) continue;
    const P = l.width * Math.hypot(c.transform[0], c.transform[1]);
    u.push({ str: l.str, x: r[4], right: r[4] + P, base: r[5], size: g });
  }
  u.sort((l, r) =>
    Math.abs(l.base - r.base) < Math.min(l.size, r.size) * 0.3
      ? l.x - r.x
      : l.base - r.base,
  );
  const k = [];
  for (const l of u) {
    const r = k[k.length - 1],
      g = r?.[r.length - 1];
    g &&
    Math.abs(g.base - l.base) < Math.min(g.size, l.size) * 0.3 &&
    l.x - g.right < Math.max(g.size, l.size) * 1 &&
    l.x >= g.x
      ? r.push(l)
      : k.push([l]);
  }
  const p = [];
  for (const l of k) {
    let r = "";
    for (let b = 0; b < l.length; b++) {
      const N = b > 0 ? l[b].x - l[b - 1].right : 0;
      (b > 0 &&
        N > l[b].size * 0.15 &&
        !r.endsWith(" ") &&
        !l[b].str.startsWith(" ") &&
        (r += " "),
        (r += l[b].str));
    }
    if (((r = r.replace(/\s+$/, "")), !r.trim())) continue;
    const g = Math.max(...l.map((b) => b.size)),
      P = l[0].base,
      w = l[0].x,
      n = l[l.length - 1].right,
      S = P - g * 0.95,
      D = g * 1.25;
    p.push({
      text: r,
      x: w / c.width,
      y: S / c.height,
      w: (n - w) / c.width,
      h: D / c.height,
      baseline: P / c.height,
      size: g,
    });
  }
  return p;
}
const ns = [
    { name: "Black", hex: "#000000" },
    { name: "Red", hex: "#E63333" },
    { name: "Orange", hex: "#F59E0B" },
    { name: "Yellow", hex: "#FFEB00" },
    { name: "Green", hex: "#16A34A" },
    { name: "Blue", hex: "#1A66E6" },
    { name: "Purple", hex: "#7C3AED" },
    { name: "White", hex: "#FFFFFF" },
  ],
  is = {
    text: "#000000",
    box: "#FFEB00",
    rectangle: "#E63333",
    ellipse: "#E63333",
    freehand: "#1A66E6",
  },
  Ne = [8, 10, 12, 14, 18, 24, 36, 48],
  Ce = [1, 2, 3, 5, 8];
function ls(a) {
  const c = /^#?([0-9a-f]{6})$/i.exec(a.trim());
  if (!c) return { r: 0, g: 0, b: 0 };
  const u = parseInt(c[1], 16);
  return {
    r: ((u >> 16) & 255) / 255,
    g: ((u >> 8) & 255) / 255,
    b: (u & 255) / 255,
  };
}
function Ge(a, c, u, k, p, l) {
  return {
    x: Math.min(Math.max(0, a + p), Math.max(0, 1 - u)),
    y: Math.min(Math.max(0, c + l), Math.max(0, 1 - k)),
  };
}
const Pe = (a) => ({ present: a, past: [], future: [] });
function Ke(a, c, u = 100) {
  return { present: c, past: [...a.past, a.present].slice(-u), future: [] };
}
function Ve(a, c) {
  return { ...a, present: c };
}
function cs(a) {
  return a.past.length
    ? {
        present: a.past[a.past.length - 1],
        past: a.past.slice(0, -1),
        future: [a.present, ...a.future],
      }
    : a;
}
function ds(a) {
  return a.future.length
    ? {
        present: a.future[0],
        past: [...a.past, a.present],
        future: a.future.slice(1),
      }
    : a;
}
function st(a) {
  return a.type === "text" && !a.cover && !a.text?.trim();
}
function hs(a) {
  const c = /^data:image\/(png|jpeg|jpg);base64,([A-Za-z0-9+/=]+)$/i.exec(
    (a || "").trim(),
  );
  if (!c) return null;
  const u = atob(c[2]),
    k = new Uint8Array(u.length);
  for (let p = 0; p < u.length; p++) k[p] = u.charCodeAt(p);
  return { bytes: k, kind: c[1].toLowerCase() === "png" ? "png" : "jpg" };
}
function us(a) {
  return Number.isFinite(a.strokeW) && a.strokeW > 0 ? a.strokeW : 2;
}
function qe(a, c) {
  const u = c.node.Contents();
  return (
    u instanceof Ut ? u.asArray().map((p) => a.context.lookup(p)) : u ? [u] : []
  ).reduce(
    (p, l) =>
      p +
      (l instanceof Ht
        ? l.operators.length
        : l instanceof Ot
          ? l.getContentsSize()
          : 0),
    0,
  );
}
async function ps(a, c) {
  const u = await It.load(a),
    k = u.getPages();
  u.setProducer("FreeDailyPro");
  const p = [];
  let l = 0;
  for (const r of c) {
    if (st(r)) continue;
    const g = k[r.page - 1];
    if (!g) {
      p.push({
        id: r.id,
        type: r.type,
        page: r.page,
        reason: "its page is missing",
      });
      continue;
    }
    const P = Xt(g),
      { width: w, height: n } = P,
      S = Bt(P.rotation),
      D = (m, d) => P.toStored(m, d),
      b = ls(r.color),
      N = je(b.r, b.g, b.b),
      L = us(r),
      M = qe(u, g);
    try {
      if (r.type === "text") {
        if (r.cover) {
          const m = r.cover,
            d = D(m.x * w, n - (m.y + m.h) * n);
          g.drawRectangle({
            x: d.x,
            y: d.y,
            width: m.w * w,
            height: m.h * n,
            color: je(1, 1, 1),
            borderWidth: 0,
            rotate: S,
          });
        }
        if (r.text?.trim()) {
          const m = r.xFrac * w,
            d = n - r.yFrac * n,
            f = D(m, d - r.size * 0.86);
          await _t(u, g, r.text.replace(/[\r\n\t]+/g, " ").trim(), {
            x: f.x,
            y: f.y,
            size: r.size,
            bold: r.bold,
            color: b,
            rotateDegrees: P.rotation,
          });
        }
      } else if (r.type === "box" || r.type === "rectangle") {
        const m = (r.widthFrac || 0.15) * w,
          d = (r.heightFrac || 0.05) * n,
          f = D(r.xFrac * w, n - r.yFrac * n - d);
        r.type === "box"
          ? g.drawRectangle({
              x: f.x,
              y: f.y,
              width: m,
              height: d,
              color: N,
              opacity: 0.4,
              rotate: S,
            })
          : g.drawRectangle({
              x: f.x,
              y: f.y,
              width: m,
              height: d,
              borderColor: N,
              borderWidth: L,
              borderOpacity: 1,
              ...(r.fill ? { color: N, opacity: 0.2 } : {}),
              rotate: S,
            });
      } else if (r.type === "whiteout") {
        const m = (r.widthFrac || 0.15) * w,
          d = (r.heightFrac || 0.05) * n,
          f = D(r.xFrac * w, n - r.yFrac * n - d);
        g.drawRectangle({
          x: f.x,
          y: f.y,
          width: m,
          height: d,
          color: je(1, 1, 1),
          opacity: 1,
          borderWidth: 0,
          rotate: S,
        });
      } else if (r.type === "image") {
        const m = hs(r.imageData);
        if (!m) throw new Error("the picture is not a PNG or JPEG");
        const d = (r.widthFrac || 0.2) * w,
          f = (r.heightFrac || 0.2) * n,
          W = D(r.xFrac * w, n - r.yFrac * n - f),
          I =
            m.kind === "png"
              ? await u.embedPng(m.bytes)
              : await u.embedJpg(m.bytes);
        g.drawImage(I, { x: W.x, y: W.y, width: d, height: f, rotate: S });
      } else if (r.type === "ellipse") {
        const m = (r.widthFrac || 0.15) * w,
          d = (r.heightFrac || 0.05) * n,
          f = D(r.xFrac * w + m / 2, n - (r.yFrac * n + d / 2));
        g.drawEllipse({
          x: f.x,
          y: f.y,
          xScale: m / 2,
          yScale: d / 2,
          borderColor: N,
          borderWidth: L,
          borderOpacity: 1,
          ...(r.fill ? { color: N, opacity: 0.2 } : {}),
          rotate: S,
        });
      } else if (r.type === "freehand") {
        if (!r.points || r.points.length < 2)
          throw new Error("the stroke has fewer than two points");
        const m = r.points.map(
            (W) => `${(W.x * w).toFixed(1)},${(W.y * n).toFixed(1)}`,
          ),
          d = `M ${m[0]} L ${m.slice(1).join(" L ")}`,
          f = D(0, n);
        g.drawSvgPath(d, {
          x: f.x,
          y: f.y,
          borderColor: N,
          borderWidth: L,
          rotate: S,
        });
      }
      if (qe(u, g) <= M) throw new Error("nothing was drawn on the page");
      l++;
    } catch (m) {
      (console.warn("Could not write one item:", { annotation: r, error: m }),
        p.push({
          id: r.id,
          type: r.type,
          page: r.page,
          reason: m instanceof Error ? m.message : "unknown error",
        }));
    }
  }
  return { bytes: await u.save(), written: l, skipped: p };
}
async function ms(a, c, u) {
  let k = new Uint8Array(await a.arrayBuffer()),
    p = [];
  if (u) {
    const r = await tt(a);
    if (r.fields.length > 0 && !r.hasXfa) {
      const g = await Lt(
        r.pdfDoc,
        r.fields,
        u.values,
        u.checked,
        !1,
        r.initialLists,
      );
      ((p = g.failed), (k = new Uint8Array(await g.blob.arrayBuffer())));
    }
  }
  return { ...(await ps(k, c)), formFailed: p };
}
const Je = {
    what: `Adds text, freehand drawing, shapes (rectangle and ellipse outlines), and highlight boxes, white patches and pictures directly onto a PDF's pages, without needing desktop software like Acrobat — for filling in a blank, labeling something, sketching an arrow or circle to point something out, or drawing attention to a section.

Honestly: this is annotation, not true document editing — it adds new content on top of the page. Edit text mode can replace a single line by covering it with a white patch, but it can't reflow paragraphs or change the PDF's own text layer; for full rewrites, PDF to Word converts to an editable document instead.`,
    tip: "Whiteout covers, it does not delete: the words underneath can still be found by searching the file, so use Redact PDF for anything sensitive. For filling out a form with defined fields, check whether the PDF already has real fillable form fields first — those give cleaner, better-aligned results than manually placing text boxes.",
  },
  Ze = (a) =>
    !a.readOnly &&
    (a.kind === "text" ||
      a.kind === "checkbox" ||
      a.kind === "dropdown" ||
      a.kind === "radio");
let le = 0;
const De = 0.15,
  $e = 0.05,
  Qe = 0.015;
function ho() {
  const [a, c] = x.useState(null),
    [u, k] = x.useState(0),
    [p, l] = x.useState(1),
    [r, g] = x.useState(null),
    [P, w] = x.useState(null),
    [n, S] = x.useState("text"),
    [D, b] = x.useState(Pe([])),
    N = D.present,
    L = (e) => b((s) => Ke(s, e(s.present))),
    M = L,
    [m, d] = x.useState(null),
    [f, W] = x.useState({ ...is }),
    [I, ot] = x.useState(2),
    [Se, rt] = x.useState(14),
    [Me, at] = x.useState(!1),
    [ce, nt] = x.useState(!1),
    [A, it] = x.useState(600),
    O = x.useRef(null),
    X = x.useRef(null),
    [lt, Te] = x.useState(!1),
    [J, v] = x.useState(null),
    [Ee, Z] = x.useState(null),
    [de, ze] = x.useState(null),
    [Q, _] = x.useState({}),
    [Re, he] = x.useState({}),
    [ct, Y] = x.useState(!1),
    [E, Le] = x.useState([]),
    We = Rt(!!J),
    [$, ee] = x.useState(null),
    [T, G] = x.useState(null),
    [te, se] = x.useState([]),
    Ae = x.useRef(null),
    ue = x.useRef(1.414);
  (x.useEffect(() => {
    if (!a) return;
    let e = !1,
      s = null;
    return (
      (async () => {
        let i;
        try {
          i = await Tt(a);
        } catch (C) {
          if (e) return;
          (console.error("Couldn't load PDF:", C),
            Z(
              Wt(C)
                ? `“${a.name}” is password-protected. Unlock it with Unlock PDF first, then drop the unlocked copy here.`
                : _e(a.name),
            ),
            c(null));
          return;
        }
        if (e) return;
        k(i.numPages);
        const o = await i.getPage(p);
        if (e) return;
        const h = await Et(o, 1.5, 0.9);
        ((s = URL.createObjectURL(h)), g(s));
        try {
          const C = await o.getTextContent();
          e || w(as(C.items, o.getViewport({ scale: 1 })));
        } catch {
          e || w([]);
        }
      })(),
      () => {
        ((e = !0), s && URL.revokeObjectURL(s));
      }
    );
  }, [a, p]),
    x.useEffect(() => {
      if ((ze(null), _({}), he({}), Y(!1), !a)) return;
      let e = !1;
      return (
        tt(a)
          .then((s) => {
            e ||
              s.hasXfa ||
              !s.fields.some(Ze) ||
              (ze(s), _(s.initialValues), he(s.initialChecked));
          })
          .catch(() => {}),
        () => {
          e = !0;
        }
      );
    }, [a]));
  const dt = x.useCallback((e) => {
      (Z(null), w(null), c(e[0] || null), l(1), b(Pe([])), d(null), v(null));
    }, []),
    F = N.find((e) => e.id === m) || null,
    Ie = F ? F.color : f[n === "select" || n === "edit" ? "text" : n],
    pe = F ? F.strokeW : I,
    me = F ? F.size : Se,
    xe = F ? !!F.bold : Me,
    ht = F ? !!F.fill : ce,
    B = (e) => ({
      color: e === "whiteout" || e === "image" ? "#FFFFFF" : f[e],
      strokeW: I,
      size: Se,
      bold: Me,
      fill: e === "rectangle" || e === "ellipse" ? ce : !1,
    }),
    K = (e) => {
      if (
        (F &&
          (L((s) => s.map((i) => (i.id === F.id ? { ...i, ...e } : i))),
          v(null)),
        e.color)
      ) {
        const s = e.color,
          i = F ? F.type : n === "select" ? null : n === "edit" ? "text" : n;
        i && W((o) => ({ ...o, [i]: s }));
      }
      (e.strokeW !== void 0 && ot(e.strokeW),
        e.size !== void 0 && rt(e.size),
        e.bold !== void 0 && at(e.bold),
        e.fill !== void 0 && nt(e.fill));
    },
    R = (e) => {
      (S(e), e !== "select" && d(null));
    },
    Be = () => {
      (b(cs), d(null), v(null));
    },
    ge = () => {
      (b(ds), d(null), v(null));
    };
  x.useEffect(() => {
    const e = (s) => {
      const i = s.target;
      if (
        i &&
        (i.tagName === "INPUT" ||
          i.tagName === "TEXTAREA" ||
          i.isContentEditable)
      )
        return;
      const o = s.key.toLowerCase();
      (s.ctrlKey || s.metaKey) && o === "z"
        ? (s.preventDefault(), s.shiftKey ? ge() : Be())
        : (s.ctrlKey || s.metaKey) && o === "y"
          ? (s.preventDefault(), ge())
          : (s.key === "Delete" || s.key === "Backspace") &&
            m !== null &&
            (s.preventDefault(), oe(m));
    };
    return (
      window.addEventListener("keydown", e),
      () => window.removeEventListener("keydown", e)
    );
  });
  const U = (e, s) => {
      (d(e), (X.current = null), (O.current = { id: e, last: s, pushed: !1 }));
    },
    ut = (e) => {
      const s = O.current;
      if (!s) return;
      const i = e.x - s.last.x,
        o = e.y - s.last.y;
      if (Math.abs(i) < 1e-4 && Math.abs(o) < 1e-4) return;
      s.last = e;
      const h = s.pushed ? Ve : (C, y) => Ke(C, y);
      ((s.pushed = !0),
        b((C) =>
          h(
            C,
            C.present.map((y) => {
              if (y.id !== s.id) return y;
              if (y.type === "freehand" && y.points) {
                const He = y.points.map((H) => H.x),
                  Oe = y.points.map((H) => H.y),
                  we = Math.min(...He),
                  Ft = Math.max(...He),
                  ve = Math.min(...Oe),
                  jt = Math.max(...Oe),
                  Xe = Ge(we, ve, Ft - we, jt - ve, i, o),
                  Nt = Xe.x - we,
                  Ct = Xe.y - ve;
                return {
                  ...y,
                  points: y.points.map((H) => ({ x: H.x + Nt, y: H.y + Ct })),
                };
              }
              const be = y.type === "text" ? 0.05 : y.widthFrac || De,
                ne = y.type === "text" ? 0.02 : y.heightFrac || $e,
                ie = Ge(y.xFrac, y.yFrac, be, ne, i, o);
              return { ...y, xFrac: ie.x, yFrac: ie.y };
            }),
          ),
        ),
        v(null));
    },
    z = (e, s) => {
      const i = Ae.current.getBoundingClientRect();
      return {
        x: Math.min(1, Math.max(0, (e - i.left) / i.width)),
        y: Math.min(1, Math.max(0, (s - i.top) / i.height)),
      };
    },
    pt = (e) => z(e.clientX, e.clientY),
    mt = (e, s) => {
      const i = `${p}:${s}`,
        o = N.find((y) => y.lineKey === i);
      if (o) {
        d(o.id);
        return;
      }
      const h = le++;
      X.current = null;
      const C = 0.004;
      (M((y) => [
        ...y,
        {
          id: h,
          page: p,
          type: "text",
          text: e.text,
          lineKey: i,
          xFrac: e.x,
          yFrac: e.baseline - (e.size * 0.86) / (A * (ue.current || 1.414)),
          cover: { x: Math.max(0, e.x - C), y: e.y, w: e.w + C * 2, h: e.h },
          ...B("text"),
          size: Math.round(e.size * 10) / 10,
          color: "#000000",
        },
      ]),
        d(h),
        v(null));
    },
    Ue = x.useRef(null),
    xt = async (e) => {
      try {
        const s = await createImageBitmap(e),
          o = Math.min(1, 1600 / Math.max(s.width, s.height)),
          h = document.createElement("canvas");
        ((h.width = Math.max(1, Math.round(s.width * o))),
          (h.height = Math.max(1, Math.round(s.height * o))),
          h.getContext("2d").drawImage(s, 0, 0, h.width, h.height));
        const C = h.toDataURL("image/png"),
          y = 0.3,
          be = Math.min(
            0.9,
            (y * (s.height / s.width)) / (ue.current || 1.414),
          ),
          ne = le++;
        (M((ie) => [
          ...ie,
          {
            id: ne,
            page: p,
            type: "image",
            imageData: C,
            xFrac: 0.35,
            yFrac: 0.3,
            widthFrac: y,
            heightFrac: be,
            ...B("image"),
          },
        ]),
          d(ne),
          v(null),
          S("select"));
      } catch {
        q.error("That picture could not be read. Try a PNG or JPEG.");
      }
    },
    gt = (e) => {
      if (n === "select") {
        d(null);
        return;
      }
      if (n !== "text") return;
      const { x: s, y: i } = pt(e),
        o = le++;
      ((X.current = null),
        M((h) => [
          ...h,
          {
            id: o,
            page: p,
            xFrac: s,
            yFrac: i,
            type: "text",
            text: "",
            ...B("text"),
          },
        ]),
        d(o),
        v(null));
    },
    fe = ["box", "rectangle", "ellipse", "freehand", "whiteout"],
    ft = (e) => {
      fe.includes(n) && (ee(e), G(e), n === "freehand" && se([e]));
    },
    yt = (e) => {
      !fe.includes(n) || !$ || (G(e), n === "freehand" && se((s) => [...s, e]));
    },
    bt = (e) => ft(z(e.clientX, e.clientY)),
    wt = (e) => {
      const s = z(e.clientX, e.clientY);
      if (O.current) return ut(s);
      yt(s);
    },
    ye = () => {
      if (O.current) {
        O.current = null;
        return;
      }
      if (!fe.includes(n) || !$ || !T) {
        (ee(null), G(null), se([]));
        return;
      }
      const e = le++;
      if (n === "freehand") {
        (te.length >= 2 &&
          (M((h) => [
            ...h,
            {
              id: e,
              page: p,
              xFrac: 0,
              yFrac: 0,
              type: "freehand",
              points: te,
              ...B("freehand"),
            },
          ]),
          d(e),
          v(null)),
          ee(null),
          G(null),
          se([]));
        return;
      }
      const s = Math.abs(T.x - $.x),
        i = Math.abs(T.y - $.y),
        o = n;
      if (s < Qe && i < Qe)
        (M((h) => [
          ...h,
          {
            id: e,
            page: p,
            xFrac: $.x,
            yFrac: $.y,
            type: o,
            widthFrac: De,
            heightFrac: $e,
            ...B(o),
          },
        ]),
          d(e));
      else {
        const h = Math.min($.x, T.x),
          C = Math.min($.y, T.y);
        (M((y) => [
          ...y,
          {
            id: e,
            page: p,
            xFrac: h,
            yFrac: C,
            type: o,
            widthFrac: s,
            heightFrac: i,
            ...B(o),
          },
        ]),
          d(e));
      }
      (v(null), ee(null), G(null));
    },
    vt = (e, s) => {
      const i = (o) => o.map((h) => (h.id === e ? { ...h, text: s } : h));
      (X.current === e
        ? b((o) => Ve(o, i(o.present)))
        : ((X.current = e), L(i)),
        v(null));
    },
    oe = (e) => {
      (M((s) => s.filter((i) => i.id !== e)),
        d((s) => (s === e ? null : s)),
        v(null));
    },
    kt = async () => {
      if (a) {
        (Te(!0), Le([]));
        try {
          const e = await ms(a, N, de ? { values: Q, checked: Re } : void 0);
          (e.formFailed.length > 0 &&
            q.warning(
              `${e.formFailed.length} form field${e.formFailed.length === 1 ? "" : "s"} could not be filled`,
              {
                description: e.formFailed
                  .slice(0, 3)
                  .map((s) => `${s.name}: ${s.reason}`)
                  .join("; "),
                duration: 1e4,
              },
            ),
            Le(e.skipped),
            v(zt(e.bytes)),
            e.skipped.length > 0
              ? q.warning(
                  `${e.skipped.length} of your items could not be added to the PDF`,
                  {
                    description: "See the notice above the download button.",
                    duration: 1e4,
                  },
                )
              : q.success(
                  `Changes applied (${e.written} item${e.written === 1 ? "" : "s"} written). Press Download to save the file.`,
                ));
        } catch (e) {
          (console.error("PDF edit failed:", e),
            q.error("Failed to apply changes to this PDF"));
        } finally {
          Te(!1);
        }
      }
    },
    re = N.filter(st).length,
    ae = N.length - re,
    V = N.filter((e) => e.page === p);
  return t.jsxs(Pt, {
    toolId: "pdf-editor",
    categoryId: "pdf-tools",
    whatItDoes: Je.what,
    proTip: Je.tip,
    children: [
      t.jsxs("div", {
        className:
          "mb-4 p-3 rounded-lg border bg-muted/50 text-xs text-muted-foreground flex flex-wrap gap-x-4 gap-y-1",
        children: [
          t.jsx("span", {
            children: "🔒 Runs entirely in your browser — never uploaded",
          }),
          t.jsx("span", {
            children:
              "✏️ Adds new content on top of the page — use Edit text to change a line that is already on the page",
          }),
        ],
      }),
      a
        ? t.jsxs("div", {
            className: "space-y-4",
            children: [
              t.jsxs("div", {
                className:
                  "flex flex-wrap items-center gap-3 p-3 rounded-lg border bg-card",
                children: [
                  t.jsxs(j, {
                    size: "sm",
                    variant: n === "select" ? "default" : "outline",
                    onClick: () => R("select"),
                    className: "gap-1.5",
                    title: "Click an item to select it, drag to move it",
                    children: [
                      t.jsx(Yt, { className: "h-3.5 w-3.5" }),
                      " Select",
                    ],
                  }),
                  t.jsxs(j, {
                    size: "sm",
                    variant: n === "edit" ? "default" : "outline",
                    onClick: () => R("edit"),
                    className: "gap-1.5",
                    title:
                      "Click a line of the page's own text to change or delete it",
                    children: [
                      t.jsx(os, { className: "h-3.5 w-3.5" }),
                      " Edit text",
                    ],
                  }),
                  t.jsxs(j, {
                    size: "sm",
                    variant: n === "text" ? "default" : "outline",
                    onClick: () => R("text"),
                    className: "gap-1.5",
                    children: [
                      t.jsx(Mt, { className: "h-3.5 w-3.5" }),
                      " Text",
                    ],
                  }),
                  t.jsxs(j, {
                    size: "sm",
                    variant: n === "box" ? "default" : "outline",
                    onClick: () => R("box"),
                    className: "gap-1.5",
                    children: [
                      t.jsx(Ye, { className: "h-3.5 w-3.5" }),
                      " Highlight",
                    ],
                  }),
                  t.jsxs(j, {
                    size: "sm",
                    variant: n === "rectangle" ? "default" : "outline",
                    onClick: () => R("rectangle"),
                    className: "gap-1.5",
                    children: [
                      t.jsx(Ye, { className: "h-3.5 w-3.5" }),
                      " Rectangle",
                    ],
                  }),
                  t.jsxs(j, {
                    size: "sm",
                    variant: n === "ellipse" ? "default" : "outline",
                    onClick: () => R("ellipse"),
                    className: "gap-1.5",
                    children: [
                      t.jsx(ss, { className: "h-3.5 w-3.5" }),
                      " Ellipse",
                    ],
                  }),
                  t.jsxs(j, {
                    size: "sm",
                    variant: n === "freehand" ? "default" : "outline",
                    onClick: () => R("freehand"),
                    className: "gap-1.5",
                    children: [
                      t.jsx(Gt, { className: "h-3.5 w-3.5" }),
                      " Freehand",
                    ],
                  }),
                  t.jsxs(j, {
                    size: "sm",
                    variant: n === "whiteout" ? "default" : "outline",
                    onClick: () => R("whiteout"),
                    className: "gap-1.5",
                    title: "Drag over something to cover it with a white patch",
                    children: [
                      t.jsx(Kt, { className: "h-3.5 w-3.5" }),
                      " Whiteout",
                    ],
                  }),
                  t.jsxs(j, {
                    size: "sm",
                    variant: "outline",
                    onClick: () => Ue.current?.click(),
                    className: "gap-1.5",
                    title:
                      "Add a picture from this device, such as a logo or signature",
                    children: [
                      t.jsx(Vt, { className: "h-3.5 w-3.5" }),
                      " Insert picture",
                    ],
                  }),
                  t.jsx("input", {
                    ref: Ue,
                    type: "file",
                    accept: "image/png,image/jpeg,image/webp,image/gif",
                    className: "sr-only",
                    "aria-label": "Choose a picture to insert",
                    onChange: (e) => {
                      const s = e.target.files?.[0];
                      ((e.target.value = ""), s && xt(s));
                    },
                  }),
                  t.jsxs("div", {
                    className: "flex items-center gap-1 ml-auto",
                    children: [
                      t.jsx(j, {
                        size: "icon",
                        variant: "ghost",
                        className: "h-7 w-7",
                        disabled: !D.past.length,
                        onClick: Be,
                        "aria-label": "Undo",
                        title: "Undo (Ctrl+Z)",
                        children: t.jsx(qt, { className: "h-4 w-4" }),
                      }),
                      t.jsx(j, {
                        size: "icon",
                        variant: "ghost",
                        className: "h-7 w-7",
                        disabled: !D.future.length,
                        onClick: ge,
                        "aria-label": "Redo",
                        title: "Redo (Ctrl+Y)",
                        children: t.jsx(Jt, { className: "h-4 w-4" }),
                      }),
                      t.jsx(j, {
                        size: "icon",
                        variant: "ghost",
                        className: "h-7 w-7",
                        disabled: p <= 1,
                        onClick: () => l((e) => e - 1),
                        children: t.jsx(Zt, { className: "h-4 w-4" }),
                      }),
                      t.jsxs("span", {
                        className: "text-xs text-muted-foreground",
                        children: ["Page ", p, " of ", u],
                      }),
                      t.jsx(j, {
                        size: "icon",
                        variant: "ghost",
                        className: "h-7 w-7",
                        disabled: p >= u,
                        onClick: () => l((e) => e + 1),
                        children: t.jsx(Qt, { className: "h-4 w-4" }),
                      }),
                    ],
                  }),
                ],
              }),
              (() => {
                const e = F
                  ? F.type
                  : n === "select"
                    ? null
                    : n === "edit"
                      ? "text"
                      : n;
                if (!e)
                  return t.jsx("p", {
                    className:
                      "text-xs text-muted-foreground px-3 flex items-center",
                    style: { minHeight: 54 },
                    children:
                      "Click an item on the page to select it — then drag to move it, change its look here, or press Delete.",
                  });
                if (e === "whiteout" || e === "image")
                  return t.jsx("p", {
                    className:
                      "text-xs text-muted-foreground px-3 flex items-center",
                    style: { minHeight: 54 },
                    children:
                      e === "whiteout"
                        ? "Drag over the part of the page to cover. The patch is solid white. The words under it are covered, not deleted - use Redact PDF to remove sensitive text for good."
                        : "Select the picture to drag it, or press Delete to remove it. It is drawn into your copy on this device only.",
                  });
                const s = e === "text",
                  i = e === "rectangle" || e === "ellipse";
                return t.jsxs("div", {
                  className:
                    "flex flex-wrap items-center gap-x-4 gap-y-2 p-3 rounded-lg border bg-card",
                  style: { minHeight: 54 },
                  "data-testid": "style-bar",
                  children: [
                    t.jsx("span", {
                      className: "text-xs text-muted-foreground",
                      children: F ? "Selected item" : "New items",
                    }),
                    t.jsx("div", {
                      className: "flex items-center gap-1",
                      role: "group",
                      "aria-label": "Colour",
                      children: ns.map((o) =>
                        t.jsx(
                          "button",
                          {
                            type: "button",
                            title: o.name,
                            "aria-label": o.name,
                            "aria-pressed":
                              Ie.toLowerCase() === o.hex.toLowerCase(),
                            onClick: () => K({ color: o.hex }),
                            className: `h-6 w-6 rounded-full border ${Ie.toLowerCase() === o.hex.toLowerCase() ? "ring-2 ring-primary ring-offset-1" : ""}`,
                            style: { background: o.hex },
                          },
                          o.hex,
                        ),
                      ),
                    }),
                    s &&
                      t.jsxs(t.Fragment, {
                        children: [
                          t.jsxs("label", {
                            className: "flex items-center gap-1.5 text-xs",
                            children: [
                              "Size",
                              t.jsx("select", {
                                "aria-label": "Text size",
                                value: me,
                                onChange: (o) =>
                                  K({ size: Number(o.target.value) }),
                                className:
                                  "border rounded px-1.5 py-1 text-xs bg-background",
                                children: (Ne.includes(me)
                                  ? Ne
                                  : [...Ne, me].sort((o, h) => o - h)
                                ).map((o) =>
                                  t.jsxs(
                                    "option",
                                    { value: o, children: [o, " pt"] },
                                    o,
                                  ),
                                ),
                              }),
                            ],
                          }),
                          t.jsx(j, {
                            size: "sm",
                            variant: xe ? "default" : "outline",
                            "aria-pressed": xe,
                            onClick: () => K({ bold: !xe }),
                            className: "h-7 px-2 font-bold",
                            children: "B",
                          }),
                        ],
                      }),
                    (i || e === "freehand") &&
                      t.jsxs("label", {
                        className: "flex items-center gap-1.5 text-xs",
                        children: [
                          "Line",
                          t.jsx("select", {
                            "aria-label": "Line width",
                            value: pe,
                            onChange: (o) =>
                              K({ strokeW: Number(o.target.value) }),
                            className:
                              "border rounded px-1.5 py-1 text-xs bg-background",
                            children: (Ce.includes(pe)
                              ? Ce
                              : [...Ce, pe].sort((o, h) => o - h)
                            ).map((o) =>
                              t.jsxs(
                                "option",
                                { value: o, children: [o, " pt"] },
                                o,
                              ),
                            ),
                          }),
                        ],
                      }),
                    i &&
                      t.jsxs("label", {
                        className: "flex items-center gap-1.5 text-xs",
                        children: [
                          t.jsx("input", {
                            type: "checkbox",
                            checked: ht,
                            onChange: (o) => K({ fill: o.target.checked }),
                          }),
                          " Tint inside",
                        ],
                      }),
                  ],
                });
              })(),
              n === "edit" &&
                t.jsx("p", {
                  className: "text-xs text-muted-foreground",
                  children:
                    "Click a line of text on the page, then change or clear it. The new text is drawn on a white patch over the old line, in a standard font. The old words are covered, not deleted — they can still be found by searching the file. To remove sensitive text for good, use Redact PDF.",
                }),
              r &&
                t.jsxs("div", {
                  ref: Ae,
                  onClick: gt,
                  onPointerDown: bt,
                  onPointerMove: wt,
                  onPointerUp: ye,
                  onPointerCancel: ye,
                  onPointerLeave: ye,
                  className:
                    "relative border rounded-lg overflow-hidden bg-white mx-auto",
                  style: {
                    maxWidth: "600px",
                    containerType: "inline-size",
                    cursor:
                      n === "select" || n === "edit"
                        ? "default"
                        : n === "text"
                          ? "text"
                          : "crosshair",
                    touchAction: "none",
                  },
                  children: [
                    t.jsx("img", {
                      src: r,
                      alt: `Page ${p}`,
                      onLoad: (e) => {
                        (it(e.currentTarget.naturalWidth / 1.5),
                          (ue.current =
                            e.currentTarget.naturalHeight /
                            e.currentTarget.naturalWidth));
                      },
                      className:
                        "w-full h-auto block pointer-events-none select-none",
                    }),
                    V.filter((e) => e.cover).map((e) =>
                      t.jsx(
                        "div",
                        {
                          className: "absolute bg-white pointer-events-none",
                          style: {
                            left: `${e.cover.x * 100}%`,
                            top: `${e.cover.y * 100}%`,
                            width: `${e.cover.w * 100}%`,
                            height: `${e.cover.h * 100}%`,
                          },
                        },
                        `cover-${e.id}`,
                      ),
                    ),
                    n === "edit" &&
                      P?.map((e, s) =>
                        t.jsx(
                          "button",
                          {
                            type: "button",
                            "aria-label": `Edit: ${e.text}`,
                            title: "Click to edit this line",
                            onClick: (i) => {
                              (i.stopPropagation(), mt(e, s));
                            },
                            className:
                              "absolute rounded-sm border border-transparent hover:border-primary hover:bg-primary/10 cursor-text",
                            style: {
                              left: `${e.x * 100}%`,
                              top: `${e.y * 100}%`,
                              width: `${e.w * 100}%`,
                              height: `${e.h * 100}%`,
                            },
                          },
                          `line-${s}`,
                        ),
                      ),
                    n === "edit" &&
                      P &&
                      P.length === 0 &&
                      t.jsx(ke, {
                        className:
                          "absolute inset-x-0 top-2 mx-auto w-fit bg-background px-3 py-1 text-xs pointer-events-none",
                        children:
                          "No editable text on this page (scanned pages are pictures). Use Text to add new text.",
                      }),
                    n === "freehand" &&
                      te.length >= 2 &&
                      t.jsx("svg", {
                        className:
                          "absolute inset-0 w-full h-full pointer-events-none",
                        viewBox: "0 0 100 100",
                        preserveAspectRatio: "none",
                        children: t.jsx("polyline", {
                          points: te
                            .map((e) => `${e.x * 100},${e.y * 100}`)
                            .join(" "),
                          fill: "none",
                          stroke: f.freehand,
                          strokeWidth: I * (600 / A),
                          vectorEffect: "non-scaling-stroke",
                        }),
                      }),
                    $ &&
                      T &&
                      n !== "freehand" &&
                      t.jsx("div", {
                        className: `absolute pointer-events-none ${n === "ellipse" ? "rounded-full" : "rounded-sm"}`,
                        style: {
                          left: `${Math.min($.x, T.x) * 100}%`,
                          top: `${Math.min($.y, T.y) * 100}%`,
                          width: `${Math.abs(T.x - $.x) * 100}%`,
                          height: `${Math.abs(T.y - $.y) * 100}%`,
                          ...(n === "whiteout"
                            ? {
                                background: "#fff",
                                border: "1px dashed #94a3b8",
                              }
                            : n === "box"
                              ? { background: f.box, opacity: 0.45 }
                              : {
                                  border: `${Math.max(1, I * (600 / A))}px solid ${f[n]}`,
                                  background: ce ? `${f[n]}33` : void 0,
                                }),
                        },
                      }),
                    V.filter((e) => e.type === "freehand" && e.points).length >
                      0 &&
                      t.jsx("svg", {
                        className:
                          "absolute inset-0 w-full h-full pointer-events-none",
                        viewBox: "0 0 100 100",
                        preserveAspectRatio: "none",
                        children: V.filter(
                          (e) => e.type === "freehand" && e.points,
                        ).map((e) => {
                          const s = e.points
                              .map((o) => `${o.x * 100},${o.y * 100}`)
                              .join(" "),
                            i = e.strokeW * (600 / A);
                          return t.jsxs(
                            "g",
                            {
                              children: [
                                e.id === m &&
                                  t.jsx("polyline", {
                                    points: s,
                                    fill: "none",
                                    stroke: "#3b82f6",
                                    strokeOpacity: 0.35,
                                    strokeWidth: i + 6,
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    vectorEffect: "non-scaling-stroke",
                                  }),
                                t.jsx("polyline", {
                                  points: s,
                                  fill: "none",
                                  stroke: e.color,
                                  strokeWidth: i,
                                  strokeLinecap: "round",
                                  strokeLinejoin: "round",
                                  vectorEffect: "non-scaling-stroke",
                                }),
                                n === "select" &&
                                  t.jsx("polyline", {
                                    "data-testid": `freehand-hit-${e.id}`,
                                    points: s,
                                    fill: "none",
                                    stroke: "transparent",
                                    strokeWidth: Math.max(i, 14),
                                    vectorEffect: "non-scaling-stroke",
                                    style: {
                                      pointerEvents: "stroke",
                                      cursor: "move",
                                    },
                                    onClick: (o) => o.stopPropagation(),
                                    onMouseDown: (o) => {
                                      (o.stopPropagation(),
                                        U(e.id, z(o.clientX, o.clientY)));
                                    },
                                    onTouchStart: (o) => {
                                      o.stopPropagation();
                                      const h = o.touches[0];
                                      U(e.id, z(h.clientX, h.clientY));
                                    },
                                  }),
                              ],
                            },
                            e.id,
                          );
                        }),
                      }),
                    V.filter(
                      (e) =>
                        e.type === "freehand" &&
                        e.points &&
                        e.points.length > 0,
                    ).map((e) =>
                      t.jsx(
                        "button",
                        {
                          onClick: (s) => {
                            (s.stopPropagation(), oe(e.id));
                          },
                          className:
                            "absolute h-5 w-5 rounded-full bg-white border shadow-sm flex items-center justify-center hover:text-destructive",
                          style: {
                            left: `${e.points[0].x * 100}%`,
                            top: `${e.points[0].y * 100}%`,
                            transform: "translate(-50%, -50%)",
                          },
                          "aria-label": "Remove this freehand stroke",
                          children: t.jsx(Fe, { className: "h-3 w-3" }),
                        },
                        `remove-${e.id}`,
                      ),
                    ),
                    V.filter((e) => e.type !== "freehand").map((e) => {
                      const s = e.id === m,
                        i = e.strokeW * (600 / A);
                      return t.jsx(
                        "div",
                        {
                          "data-testid": `ann-${e.type}-${e.id}`,
                          onClick: (o) => o.stopPropagation(),
                          onMouseDown: (o) => {
                            if (e.type === "text") {
                              d(e.id);
                              return;
                            }
                            n === "select" &&
                              (o.stopPropagation(),
                              U(e.id, z(o.clientX, o.clientY)));
                          },
                          onTouchStart: (o) => {
                            if (e.type === "text" || n !== "select") return;
                            o.stopPropagation();
                            const h = o.touches[0];
                            U(e.id, z(h.clientX, h.clientY));
                          },
                          className: "absolute",
                          style:
                            e.type === "text"
                              ? {
                                  left: `${e.xFrac * 100}%`,
                                  top: e.cover
                                    ? `calc(${e.yFrac * 100}% + ${((e.size * 0.56) / A) * 100}cqw)`
                                    : `${e.yFrac * 100}%`,
                                }
                              : {
                                  left: `${e.xFrac * 100}%`,
                                  top: `${e.yFrac * 100}%`,
                                  width: `${(e.widthFrac || De) * 100}%`,
                                  height: `${(e.heightFrac || $e) * 100}%`,
                                  cursor: n === "select" ? "move" : void 0,
                                },
                          children:
                            e.type === "text"
                              ? t.jsxs("div", {
                                  className:
                                    "flex items-center gap-1 -translate-y-1/2",
                                  children: [
                                    t.jsx("button", {
                                      type: "button",
                                      "aria-label": "Move this text",
                                      title: "Drag to move",
                                      onMouseDown: (o) => {
                                        (o.stopPropagation(),
                                          o.preventDefault(),
                                          U(e.id, z(o.clientX, o.clientY)));
                                      },
                                      onTouchStart: (o) => {
                                        o.stopPropagation();
                                        const h = o.touches[0];
                                        U(e.id, z(h.clientX, h.clientY));
                                      },
                                      className:
                                        "text-muted-foreground cursor-move",
                                      children: t.jsx(es, {
                                        className: "h-4 w-4",
                                      }),
                                    }),
                                    t.jsx("input", {
                                      autoFocus: !0,
                                      value: e.text || "",
                                      onFocus: () => d(e.id),
                                      onChange: (o) => vt(e.id, o.target.value),
                                      placeholder: "Type here...",
                                      className: `px-1.5 py-0.5 border rounded bg-white/95 shadow-sm ${s ? "border-primary" : "border-border"}`,
                                      style: {
                                        color:
                                          e.color === "#FFFFFF"
                                            ? "#999"
                                            : e.color,
                                        fontWeight: e.bold ? 700 : 400,
                                        fontSize: `${(e.size / A) * 100}cqw`,
                                        width: `${Math.max(8, (e.text?.length || 8) + 2)}ch`,
                                        maxWidth: "70cqw",
                                      },
                                    }),
                                    t.jsx("button", {
                                      onClick: () => oe(e.id),
                                      className:
                                        "text-muted-foreground hover:text-destructive",
                                      "aria-label": "Remove this text",
                                      children: t.jsx(Fe, {
                                        className: "h-3.5 w-3.5",
                                      }),
                                    }),
                                  ],
                                })
                              : t.jsxs("div", {
                                  className: "relative group w-full h-full",
                                  children: [
                                    t.jsx("div", {
                                      className: `w-full h-full ${e.type === "ellipse" ? "rounded-full" : "rounded-sm"} ${s ? "outline outline-2 outline-offset-2 outline-blue-500/60" : ""}`,
                                      style:
                                        e.type === "whiteout"
                                          ? {
                                              background: "#fff",
                                              border: "1px dashed #94a3b8",
                                            }
                                          : e.type === "image"
                                            ? {
                                                backgroundImage: `url(${e.imageData})`,
                                                backgroundSize: "100% 100%",
                                              }
                                            : e.type === "box"
                                              ? {
                                                  background: e.color,
                                                  opacity: 0.45,
                                                }
                                              : {
                                                  border: `${Math.max(1, i)}px solid ${e.color}`,
                                                  background: e.fill
                                                    ? `${e.color}33`
                                                    : void 0,
                                                },
                                    }),
                                    t.jsx("button", {
                                      onClick: () => oe(e.id),
                                      "aria-label": "Remove this shape",
                                      className: `absolute -top-2 -right-2 bg-white rounded-full border shadow-sm transition-opacity ${s ? "opacity-100" : "opacity-0 group-hover:opacity-100"}`,
                                      children: t.jsx(Fe, {
                                        className: "h-3 w-3",
                                      }),
                                    }),
                                  ],
                                }),
                        },
                        e.id,
                      );
                    }),
                  ],
                }),
              de &&
                t.jsxs("div", {
                  className: "rounded-lg border p-3 space-y-2",
                  "data-testid": "form-fields",
                  children: [
                    t.jsx("p", {
                      className: "text-sm font-medium",
                      children:
                        "This PDF has fill-in fields — type into them here",
                    }),
                    t.jsx("div", {
                      className: "grid gap-2 max-h-72 overflow-y-auto pr-1",
                      children: de.fields.filter(Ze).map((e) =>
                        t.jsxs(
                          "label",
                          {
                            className: "text-xs flex flex-col gap-1",
                            children: [
                              t.jsxs("span", {
                                className: "text-muted-foreground",
                                children: [
                                  e.label,
                                  e.page !== null
                                    ? ` (page ${e.page + 1})`
                                    : "",
                                ],
                              }),
                              e.kind === "checkbox"
                                ? t.jsx("input", {
                                    type: "checkbox",
                                    checked: !!Re[e.name],
                                    onChange: (s) => {
                                      (he((i) => ({
                                        ...i,
                                        [e.name]: s.target.checked,
                                      })),
                                        Y(!0),
                                        v(null));
                                    },
                                    className: "h-4 w-4 self-start",
                                  })
                                : e.kind === "dropdown" || e.kind === "radio"
                                  ? t.jsxs("select", {
                                      value: Q[e.name] ?? "",
                                      onChange: (s) => {
                                        (_((i) => ({
                                          ...i,
                                          [e.name]: s.target.value,
                                        })),
                                          Y(!0),
                                          v(null));
                                      },
                                      className:
                                        "border rounded px-2 py-1 text-sm bg-background",
                                      children: [
                                        t.jsx("option", {
                                          value: "",
                                          children: "—",
                                        }),
                                        (e.options ?? []).map((s) =>
                                          t.jsx(
                                            "option",
                                            { value: s, children: s },
                                            s,
                                          ),
                                        ),
                                      ],
                                    })
                                  : e.multiline
                                    ? t.jsx("textarea", {
                                        value: Q[e.name] ?? "",
                                        maxLength: e.maxLength,
                                        onChange: (s) => {
                                          (_((i) => ({
                                            ...i,
                                            [e.name]: s.target.value,
                                          })),
                                            Y(!0),
                                            v(null));
                                        },
                                        className:
                                          "border rounded px-2 py-1 text-sm bg-background",
                                        rows: 2,
                                      })
                                    : t.jsx("input", {
                                        type: "text",
                                        value: Q[e.name] ?? "",
                                        maxLength: e.maxLength,
                                        onChange: (s) => {
                                          (_((i) => ({
                                            ...i,
                                            [e.name]: s.target.value,
                                          })),
                                            Y(!0),
                                            v(null));
                                        },
                                        className:
                                          "border rounded px-2 py-1 text-sm bg-background",
                                      }),
                            ],
                          },
                          e.name,
                        ),
                      ),
                    }),
                  ],
                }),
              t.jsxs("p", {
                className: "text-xs text-muted-foreground",
                children: [
                  "Need to sign this document? Use ",
                  t.jsx("a", {
                    href: "/tool/sign-pdf",
                    className: "underline",
                    children: "Sign PDF",
                  }),
                  " — it places your signature or initials, and runs in your browser too.",
                ],
              }),
              t.jsxs("p", {
                className: "text-xs text-muted-foreground",
                children: [
                  ae,
                  " item",
                  ae === 1 ? "" : "s",
                  " added across all pages. Click the page above to add more.",
                  re > 0 &&
                    ` ${re} empty text box${re === 1 ? "" : "es"} will be left out.`,
                ],
              }),
              J &&
                E.length > 0 &&
                t.jsxs(ke, {
                  role: "alert",
                  className: "text-sm space-y-1",
                  children: [
                    t.jsxs("p", {
                      className: "font-medium",
                      children: [
                        E.length,
                        " of your ",
                        ae,
                        " items could not be written to the PDF, so the download will not include ",
                        E.length === 1 ? "it" : "them",
                        ":",
                      ],
                    }),
                    t.jsx("ul", {
                      className: "list-disc pl-5",
                      children: E.map((e) =>
                        t.jsxs(
                          "li",
                          {
                            children: [
                              e.type === "box" ? "highlight" : e.type,
                              " on page ",
                              e.page,
                              ": ",
                              e.reason,
                            ],
                          },
                          e.id,
                        ),
                      ),
                    }),
                    t.jsxs("p", {
                      children: [
                        "Remove or redo ",
                        E.length === 1 ? "that item" : "those items",
                        " and apply again, or download the file knowing ",
                        E.length === 1 ? "it is" : "they are",
                        " missing.",
                      ],
                    }),
                  ],
                }),
              t.jsx("div", {
                className: "flex gap-3",
                children: lt
                  ? t.jsx($t, { message: "Applying changes..." })
                  : J
                    ? t.jsxs(t.Fragment, {
                        children: [
                          t.jsx("div", {
                            ref: We.ref,
                            className: We.className,
                            children: t.jsx(St, {
                              blob: J,
                              fileName: `edited_${a.name}`,
                              label:
                                E.length > 0
                                  ? `Download without ${E.length === 1 ? "the missing item" : `the ${E.length} missing items`}`
                                  : "Download",
                            }),
                          }),
                          t.jsx(j, {
                            variant: "outline",
                            onClick: () => {
                              (c(null), b(Pe([])), d(null), v(null));
                            },
                            children: "New",
                          }),
                        ],
                      })
                    : t.jsxs(t.Fragment, {
                        children: [
                          t.jsx(j, {
                            onClick: kt,
                            disabled: ae === 0 && !ct,
                            children: "Apply changes",
                          }),
                          N.length > 0 &&
                            t.jsxs(j, {
                              variant: "ghost",
                              onClick: () => {
                                (M(() => []), d(null));
                              },
                              className: "gap-1.5",
                              children: [
                                t.jsx(ts, { className: "h-3.5 w-3.5" }),
                                " Clear all",
                              ],
                            }),
                        ],
                      }),
              }),
            ],
          })
        : t.jsxs("div", {
            className: "space-y-3",
            children: [
              t.jsx(Dt, {
                gateAtDownload: !0,
                accept: ".pdf",
                onFiles: dt,
                onAttempt: () => Z(null),
                onUnreadablePdf: (e) => Z(_e(e.name)),
                label: "Drop a PDF to edit",
                description:
                  "Add text, freehand drawing, shapes, and highlights directly on the page",
              }),
              Ee &&
                t.jsxs(ke, {
                  role: "alert",
                  className: "text-sm",
                  children: [
                    t.jsx("p", { className: "font-medium", children: At }),
                    t.jsxs("p", {
                      children: [
                        Ee,
                        " ",
                        t.jsx("a", {
                          href: "/tool/repair-pdf",
                          className: "underline",
                          children: "Repair PDF",
                        }),
                      ],
                    }),
                  ],
                }),
            ],
          }),
    ],
  });
}
export { ho as default };
//# sourceMappingURL=PdfEditor-CgQn_Z2A.js.map
