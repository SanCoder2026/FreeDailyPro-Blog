function u(h) {
  const i = h.getCropBox(),
    c = (((Math.round(h.getRotation().angle / 90) * 90) % 360) + 360) % 360,
    { x: r, y: n, width: t, height: e } = i,
    s = c === 90 || c === 270;
  return {
    width: s ? e : t,
    height: s ? t : e,
    rotation: c,
    toStored(o, a) {
      switch (c) {
        case 90:
          return { x: r + (t - a), y: n + o };
        case 180:
          return { x: r + (t - o), y: n + (e - a) };
        case 270:
          return { x: r + a, y: n + (e - o) };
        default:
          return { x: r + o, y: n + a };
      }
    },
    toViewed(o, a) {
      switch (c) {
        case 90:
          return { x: a - n, y: t - (o - r) };
        case 180:
          return { x: t - (o - r), y: e - (a - n) };
        case 270:
          return { x: e - (a - n), y: o - r };
        default:
          return { x: o - r, y: a - n };
      }
    },
  };
}
function d(h, i, c, r, n) {
  const t = h.toStored(i, c),
    e = h.toStored(i + r, c + n);
  return {
    x: Math.min(t.x, e.x),
    y: Math.min(t.y, e.y),
    width: Math.abs(t.x - e.x),
    height: Math.abs(t.y - e.y),
  };
}
export { u as p, d as s };
//# sourceMappingURL=pageView-BQIwVYOi.js.map
