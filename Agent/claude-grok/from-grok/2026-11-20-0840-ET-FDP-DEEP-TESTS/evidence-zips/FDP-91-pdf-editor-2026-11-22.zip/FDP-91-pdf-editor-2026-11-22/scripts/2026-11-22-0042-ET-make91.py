# FDP-91 test inputs (made-up data)
import fitz, io, os, random
from PIL import Image, ImageDraw
T='testfiles/'
# 1. contract.pdf: 3 pages, Times + embedded DejaVu Serif + Helvetica, text to edit, Hindi & Japanese lines (real text)
d=fitz.open()
for pn in range(3):
    p=d.new_page(width=612,height=792)
    p.insert_font(fontname='dvs',fontfile='/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf')
    p.insert_text((72,72),f'SERVICE AGREEMENT - page {pn+1}',fontname='hebo',fontsize=18)
    p.insert_text((72,110),'Client name: Acme Widgets LLC',fontname='tiro',fontsize=12)
    p.insert_text((72,130),'Total fee: $4,500.00 due on 2026-12-01',fontname='tiro',fontsize=12)
    p.insert_text((72,150),'Governing law: State of New York',fontname='dvs',fontsize=12)
    p.insert_text((72,170),'Contact: jane.doe@example.com  Phone: 555-0100',fontname='helv',fontsize=10)
    y=200
    for i in range(18):
        p.insert_text((72,y),f'{i+1}. The parties agree to clause {i+1} which is a long line of body text for reflow testing.',fontname='tiro',fontsize=10); y+=16
    if pn==0:
        p.insert_font(fontname='deva',fontfile='/usr/share/fonts/truetype/sand-box/google/Noto Sans Devanagari/NotoSansDevanagari-VariableFont_wdth,wght.ttf')
        p.insert_text((72,520),'नाम: राम कुमार',fontname='deva',fontsize=12)
d.save(T+'contract.pdf')
# 2. scanned.pdf: image-only page
img=Image.new('RGB',(1275,1650),'white'); dr=ImageDraw.Draw(img)
for i in range(30): dr.text((100,100+i*45),f'Scanned line {i+1}: this text is only pixels',fill='black')
b=io.BytesIO(); img.save(b,'JPEG',quality=70)
d=fitz.open(); p=d.new_page(width=612,height=792); p.insert_image(p.rect,stream=b.getvalue()); d.save(T+'scanned.pdf')
# 3. large: 300 text pages (~?) and heavy: 40 pages of noisy images (~45 MB)
d=fitz.open()
for i in range(300):
    p=d.new_page(); p.insert_text((72,72),f'Large file page {i+1}',fontsize=20)
    for j in range(40): p.insert_text((72,100+j*16),f'Line {j} on page {i+1} lorem ipsum dolor sit amet consectetur.',fontsize=10)
d.save(T+'large-300p.pdf')
d=fitz.open(); random.seed(1)
for i in range(30):
    im=Image.frombytes('RGB',(1400,1800),os.urandom(1400*1800*3)); bb=io.BytesIO(); im.save(bb,'JPEG',quality=92)
    p=d.new_page(); p.insert_image(p.rect,stream=bb.getvalue()); p.insert_text((72,72),f'Heavy page {i+1}',fontsize=24,color=(1,1,1))
d.save(T+'heavy.pdf')
# images to insert
Image.new('RGBA',(400,200),(30,120,220,160)).save(T+'logo.png')
im=Image.new('RGB',(300,300),'red'); ImageDraw.Draw(im).ellipse((50,50,250,250),fill='yellow'); im.save(T+'stamp.jpg')
im.save(T+'stamp.webp')
print({f:os.path.getsize(T+f) for f in os.listdir(T)})
