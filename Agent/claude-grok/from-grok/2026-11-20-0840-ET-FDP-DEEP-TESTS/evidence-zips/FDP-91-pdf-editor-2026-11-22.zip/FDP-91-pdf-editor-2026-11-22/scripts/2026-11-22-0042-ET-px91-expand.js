// FDP-91: expand the info accordions (About, Common questions, Details, Guides) on flatten-pdf (guest) and save text, JSON-LD and links
const { chromium } = require('playwright'); const fs = require('fs'); const O = '/workspace/deep/91-pdf-editor/';
(async () => { const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1366, height: 900 } })).newPage(); p.setDefaultTimeout(5000);
 await p.goto('https://www.freedailypro.com/tool/pdf-editor', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(5000);
 for (const n of [/^About /, 'Common questions', 'Details: when to use it, limits, privacy', 'Guides and next steps']) { await p.locator('main button', { hasText: n }).first().click().catch(e => console.log('miss', n)); await p.waitForTimeout(700); }
 const t = await p.evaluate(() => document.querySelector('main').innerText); fs.writeFileSync(O + 'tool-expanded.txt', t);
 const ld = await p.evaluate(() => [...document.querySelectorAll('script[type="application/ld+json"]')].map(s => { try { return JSON.parse(s.textContent) } catch (e) { return s.textContent } }));
 fs.writeFileSync(O + 'tool-expanded.txt.jsonld.json', JSON.stringify(ld, null, 1));
 const links = await p.evaluate(() => [...document.querySelectorAll('main a')].map(a => a.getAttribute('href') + ' | ' + a.innerText.trim().slice(0, 80)));
 fs.writeFileSync(O + 'tool-links.txt', links.join('\n')); console.log(t.length, ld.length); await b.close(); })();
