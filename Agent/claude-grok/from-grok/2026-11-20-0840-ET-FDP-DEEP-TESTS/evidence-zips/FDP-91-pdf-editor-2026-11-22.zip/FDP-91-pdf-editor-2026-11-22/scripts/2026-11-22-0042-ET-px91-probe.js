// FDP-91 UI probe: load contract.pdf as guest, list toolbar controls, screenshot. No downloads.
const pw = require('playwright'); const fs = require('fs'); const O = '/workspace/deep/91-pdf-editor/';
(async () => { const b = await pw.chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 1000 } }); const p = await c.newPage();
 await p.goto('https://www.freedailypro.com/tool/pdf-editor', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500);
 await p.locator('input[type=file]').first().setInputFiles(O + 'testfiles/contract.pdf'); await p.waitForTimeout(6000);
 const ctr = await p.locator('main button, main input, main select, main [role=slider], main img, main canvas').evaluateAll(es => es.map(e => [e.tagName, e.getAttribute('aria-label'), e.getAttribute('title'), (e.innerText || '').trim().slice(0, 40), e.getAttribute('type'), e.getAttribute('aria-pressed'), e.getAttribute('data-testid'), Math.round(e.getBoundingClientRect().width) + 'x' + Math.round(e.getBoundingClientRect().height)].join('|')));
 fs.mkdirSync(O + 'live/cases', { recursive: true }); fs.writeFileSync(O + 'live/probe-controls.txt', ctr.join('\n'));
 fs.writeFileSync(O + 'live/probe-text.txt', await p.evaluate(() => document.querySelector('main').innerText));
 await p.screenshot({ path: O + 'live/cases/P01-loaded.png', fullPage: true });
 console.log(ctr.length, JSON.stringify(await p.evaluate(() => localStorage.getItem('fdp-usage-v1')))); await b.close(); })();
