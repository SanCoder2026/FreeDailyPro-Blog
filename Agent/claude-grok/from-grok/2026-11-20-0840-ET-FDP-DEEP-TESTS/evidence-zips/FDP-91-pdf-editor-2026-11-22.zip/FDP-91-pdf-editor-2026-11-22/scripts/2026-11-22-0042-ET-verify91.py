# FDP-91: inspect an edited PDF. python3 verify91.py <pdf> <outdir> <tag> [needle ...]
import sys, json, os, fitz, pikepdf, pypdfium2 as pdfium
pdf, out, tag = sys.argv[1:4]; needles = sys.argv[4:]
os.makedirs(out, exist_ok=True)
d = fitz.open(pdf); R = {'file': pdf, 'size': os.path.getsize(pdf), 'pages': d.page_count, 'producer': d.metadata.get('producer'), 'pagesInfo': []}
for i, p in enumerate(d):
    if i >= 4: break
    t = p.get_text()
    R['pagesInfo'].append({'page': i + 1, 'rotation': p.rotation, 'mediabox': list(p.mediabox), 'cropbox': list(p.cropbox),
        'fonts': sorted({f[3] for f in p.get_fonts()}), 'images': len(p.get_images()), 'annots': [a.type[1] for a in p.annots()],
        'widgets': len(list(p.widgets())), 'text': t[:1500], 'needles': {n: (n in t) for n in needles}})
with pikepdf.open(pdf) as q:
    af = q.Root.get('/AcroForm'); R['acroform_fields'] = len(af.Fields) if af is not None and '/Fields' in af else 0
    R['fontfile_bytes'] = sum(len(o.read_raw_bytes()) for o in q.objects if isinstance(o, pikepdf.Stream) and any(k in o for k in ('/Length1',)) )
for i in range(min(2, d.page_count)):
    d[i].get_pixmap(dpi=100).save(f'{out}/{tag}-mupdf-p{i+1}.png')
    pg = pdfium.PdfDocument(pdf)[i]; pg.render(scale=100/72, may_draw_forms=True).to_pil().save(f'{out}/{tag}-pdfium-p{i+1}.png')
json.dump(R, open(f'{out}/{tag}.json', 'w'), indent=1, ensure_ascii=False)
for pi in R['pagesInfo']: print(tag, 'p', pi['page'], 'fonts', pi['fonts'], 'imgs', pi['images'], 'annots', pi['annots'], 'widgets', pi['widgets'], pi['needles'])
print(tag, 'size', R['size'], 'fields', R['acroform_fields'], 'fontfile_bytes', R['fontfile_bytes'])
