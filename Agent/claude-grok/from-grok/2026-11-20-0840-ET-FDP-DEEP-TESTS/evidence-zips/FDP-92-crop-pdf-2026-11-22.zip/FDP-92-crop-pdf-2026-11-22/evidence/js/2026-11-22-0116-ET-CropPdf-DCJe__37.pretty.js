import { r as c, j as r } from "./vendor-react-D01g8YgM.js";
import { T as $e } from "./ToolWithSidebar-CO7i-D3n.js";
import {
  k as Ie,
  F as Le,
  P as he,
  D as Ue,
  R as Be,
} from "./ToolPage-DrleSM7T.js";
import { f as M, N as de, B as b, I as fe, e as Ee } from "./index-xgcQ0Xo8.js";
import { y as Oe, q as ge, z as _e } from "./operations-BatXiFlG.js";
import { l as Xe, r as xe } from "./utils-s8ucLyj8.js";
import { i as Ye, n as we, N as ye } from "./pdfLoadError-Bi-AAFkg.js";
import { M as Ge } from "./move-B8aj4hm4.js";
import { W as Ve } from "./wand-sparkles-CkEQjAaN.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./CollapsibleText-DFD2kyG0.js";
import "./chevron-up-RK9L2OPY.js";
import "./useUploadApi-yCV1cZhw.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-Cl69OhvT.js";
import "./share-2-tv4Mz_hR.js";
import "./copy-B6PRNyNa.js";
import "./workflowCta-BFTpZlex.js";
import "./UsageAndUpgradeStrip-DMhPNgnJ.js";
import "./access-DqVqJd33.js";
import "./useAdminAccess-mVM_2mWb.js";
import "./InstallToolButton-DxfN0Pem.js";
import "./map-pin-CwlIzHDK.js";
import "./FaqSection-BNxk42M5.js";
import "./ToolVideoEmbed-DNaMY2Pn.js";
import "./GuideLinks-D5fn3NI1.js";
import "./blog-CxdB1WyW.js";
import "./info-x67VbErc.js";
import "./productCards-DhpNcELZ.js";
import "./layers-B44Zba7-.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./pdfMetadata-CcxIhQF2.js";
import "./pageView-BQIwVYOi.js";
import "./formAppearance-CdNbuISd.js";
import "./drawTextAnywhere-DcuP6lHH.js";
import "./ocrText-C_9cxcFa.js";
import "./ocrImage-CmXFNUud.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./imageRecompress-eXQFDUm-.js";
import "./formatFileSize-B-JRDfN5.js";
import "./plural-FIChqbp4.js";
import "./textDiff-DxE9AzvO.js";
import "./utils-BB7NgdRI.js";
import "./decode-FlLGQ42m.js";
import "./formFill-Dg9Myfyq.js";
import "./redactSearch-DQpyyh_t.js";
import "./nameDetect-DvHCRM0m.js";
function be(t) {
  if (t.length === 0) return null;
  let s = 1,
    o = 1,
    u = 0,
    i = 0;
  for (const h of t)
    ((s = Math.min(s, h.x)),
      (o = Math.min(o, h.y)),
      (u = Math.max(u, h.x + h.w)),
      (i = Math.max(i, h.y + h.h)));
  return { x: s, y: o, w: u - s, h: i - o };
}
function qe(t, s, o = 0.006) {
  return (
    t.x < s.x - o ||
    t.y < s.y - o ||
    t.x + t.w > s.x + s.w + o ||
    t.y + t.h > s.y + s.h + o
  );
}
function We(t, s, o) {
  return s
    .filter((u) => {
      const i = t[u];
      return i != null && qe(i, o);
    })
    .map((u) => u + 1);
}
function Je(t, s = 250) {
  for (let o = 0; o < t.length; o += 4)
    if (t[o + 3] > 0 && (t[o] < s || t[o + 1] < s || t[o + 2] < s)) return !1;
  return !0;
}
const Ze = [
    { value: 0, label: "None" },
    { value: 0.02, label: "Small (2%)" },
    { value: 0.05, label: "Medium (5%)" },
    { value: 0.1, label: "Large (10%)" },
  ],
  Ke = 0.05;
function Qe(t, s) {
  const o = Number.isFinite(s) && s > 0 ? Math.min(s, 0.4) : 0;
  if (o === 0) return { ...t };
  const u = Math.max(0, t.x - o),
    i = Math.max(0, t.y - o),
    h = Math.min(1, t.x + t.w + o),
    l = Math.min(1, t.y + t.h + o);
  return { x: u, y: i, w: h - u, h: l - i };
}
const K = { in: 72, mm: 72 / 25.4 },
  D = (t, s) => {
    const o = 10 ** s;
    return Math.round(t * o) / o;
  };
function He(t, s, o, u) {
  const i = K[u];
  if (
    ![t.top, t.right, t.bottom, t.left].every(
      (I) => Number.isFinite(I) && I >= 0,
    ) ||
    !(s > 0) ||
    !(o > 0)
  )
    return null;
  const l = (t.left * i) / s,
    d = (t.top * i) / o,
    $ = 1 - l - (t.right * i) / s,
    R = 1 - d - (t.bottom * i) / o;
  return $ < 0.01 || R < 0.01 ? null : { x: l, y: d, w: $, h: R };
}
function et(t, s, o, u) {
  const i = K[u],
    h = u === "in" ? 2 : 1;
  return {
    left: D((t.x * s) / i, h),
    top: D((t.y * o) / i, h),
    right: D(((1 - t.x - t.w) * s) / i, h),
    bottom: D(((1 - t.y - t.h) * o) / i, h),
  };
}
function ve(t, s, o) {
  const u = K[o],
    i = o === "in" ? 2 : 0;
  return `${D(t / u, i)}×${D(s / u, i)} ${o}`;
}
function je(t, s, o, u) {
  return `${ve(s, o, u)} → ${ve(t.w * s, t.h * o, u)}`;
}
const k = 0.02,
  Pe = (t) => Math.min(1, Math.max(0, t));
function tt(t, s, o) {
  return {
    ...t,
    x: Math.min(1 - t.w, Math.max(0, t.x + s)),
    y: Math.min(1 - t.h, Math.max(0, t.y + o)),
  };
}
function rt(t, s, o, u) {
  const i = s === "nw" || s === "sw" ? t.x + t.w : t.x,
    h = s === "nw" || s === "ne" ? t.y + t.h : t.y;
  let l = Pe(o),
    d = Pe(u);
  return (
    Math.abs(l - i) < k &&
      (l = l < i ? Math.max(0, i - k) : Math.min(1, i + k)),
    Math.abs(d - h) < k &&
      (d = d < h ? Math.max(0, h - k) : Math.min(1, h + k)),
    {
      x: Math.min(l, i),
      y: Math.min(d, h),
      w: Math.abs(l - i),
      h: Math.abs(d - h),
    }
  );
}
const Me = {
  what: "Crops a PDF to a region you select — useful for trimming excess margins before printing, removing a header/footer strip that repeats on every page, or cutting a PDF down to just the content that matters when it was scanned or exported with extra whitespace around the edges. Choose whether the crop applies to every page, just the current one, or a specific page range.",
  tip: `When cropping several pages, the same region (as a share of the page) is applied to each one. Auto-trim measures every page you are cropping and keeps the area that holds all of their content, and before applying you are warned about any page whose content would be cut off. If your pages have inconsistent sizing or content position — common in scanned documents where each page was photographed slightly differently — check a few pages in the result before relying on it, since a crop that's perfect for page one can clip real content on a page that's shifted even slightly. Auto-trim works well for a page with a clean white background and margins; it's less reliable on a page with a colored or textured background, since it can't distinguish "background" from "content" as clearly.`,
};
function ar() {
  const [t, s] = c.useState(null),
    [o, u] = c.useState(null),
    [i, h] = c.useState(0),
    [l, d] = c.useState(null),
    [$, R] = c.useState(!1),
    [I, Q] = c.useState(!1),
    [T, g] = c.useState(null),
    [v, Y] = c.useState("all"),
    [z, Ne] = c.useState(""),
    [H, ee] = c.useState(!1),
    [x, L] = c.useState(0),
    [C, P] = c.useState(null),
    [te, G] = c.useState(null),
    [re, Ce] = c.useState(Ke),
    [ne, U] = c.useState(null),
    [S, Se] = c.useState("in"),
    [w, ae] = c.useState(null),
    [oe, V] = c.useState({ top: "", right: "", bottom: "", left: "" }),
    q = c.useRef(!1),
    F = c.useRef(null),
    B = c.useRef(new Map()),
    se = c.useRef(null),
    ke = c.useRef(null),
    [y, W] = c.useState(null),
    [j, E] = c.useState(null),
    De = c.useCallback(async (e) => {
      const n = e[0];
      if (n) {
        if ((G(null), U(null), Ie(n))) {
          G(n.name);
          return;
        }
        (s(n), g(null), d(null), R(!0));
        try {
          const a = await Xe(n);
          ((F.current = a),
            (B.current = new Map()),
            L(0),
            P(null),
            h(a.numPages));
          const p = await a.getPage(1);
          {
            const f = p.getViewport({ scale: 1 });
            ae({ w: f.width, h: f.height });
          }
          const m = await xe(p, 1.2, 0.85);
          u(URL.createObjectURL(m));
        } catch (a) {
          (console.error("Couldn't load PDF:", a),
            Ye(a) ? G(n.name) : (U(we(n.name)), M.error(ye)),
            s(null));
        } finally {
          R(!1);
        }
      }
    }, []);
  (c.useEffect(() => {
    const e = F.current;
    if (!e || !t) return;
    let n = !1;
    return (
      (async () => {
        try {
          const a = await e.getPage(x + 1);
          if (!n) {
            const m = a.getViewport({ scale: 1 });
            ae({ w: m.width, h: m.height });
          }
          const p = await xe(a, 1.2, 0.85);
          if (n) return;
          u((m) => (m && URL.revokeObjectURL(m), URL.createObjectURL(p)));
        } catch (a) {
          console.error("Preview failed:", a);
        }
      })(),
      () => {
        n = !0;
      }
    );
  }, [x, t]),
    c.useEffect(() => {
      if (q.current) {
        q.current = !1;
        return;
      }
      if (!l || !w) {
        V({ top: "", right: "", bottom: "", left: "" });
        return;
      }
      const e = et(l, w.w, w.h, S);
      V({
        top: String(e.top),
        right: String(e.right),
        bottom: String(e.bottom),
        left: String(e.left),
      });
    }, [l, w, S]));
  const Re = (e, n) => {
      const a = { ...oe, [e]: n };
      if ((V(a), !w)) return;
      const p = (f) => (f.trim() === "" ? 0 : Number(f)),
        m = He(
          {
            top: p(a.top),
            right: p(a.right),
            bottom: p(a.bottom),
            left: p(a.left),
          },
          w.w,
          w.h,
          S,
        );
      m && ((q.current = !0), d(m), g(null), P(null));
    },
    J = c.useCallback(async (e) => {
      if (B.current.has(e)) return B.current.get(e);
      const a = await F.current.getPage(e + 1),
        p = a.getViewport({ scale: 0.7 }),
        m = document.createElement("canvas");
      ((m.width = Math.max(1, Math.floor(p.width))),
        (m.height = Math.max(1, Math.floor(p.height))));
      const f = m.getContext("2d");
      ((f.fillStyle = "#fff"),
        f.fillRect(0, 0, m.width, m.height),
        await a.render({ canvasContext: f, viewport: p, canvas: m }).promise);
      const N = f.getImageData(0, 0, m.width, m.height),
        X = Je(N.data) ? null : Oe(N, 0.01);
      return (B.current.set(e, X), X);
    }, []),
    ie = () => {
      if (v === "current") return [x];
      if (v === "range") {
        if (!z.trim()) return null;
        const e = ge(z, i);
        return "error" in e ? null : e.pages;
      }
      return Array.from({ length: i }, (e, n) => n);
    },
    O = (e, n) => {
      const a = se.current.getBoundingClientRect();
      return {
        x: Math.min(1, Math.max(0, (e - a.left) / a.width)),
        y: Math.min(1, Math.max(0, (n - a.top) / a.height)),
      };
    },
    Te = (e) => {
      if (e.pointerType === "mouse" && e.button !== 0) return;
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {}
      const n = O(e.clientX, e.clientY);
      (W(n), E(n));
    },
    ze = (e) => {
      y && E(O(e.clientX, e.clientY));
    },
    Z = c.useRef(null),
    le = (e) => (n) => {
      if (!(!l || (n.pointerType === "mouse" && n.button !== 0))) {
        n.stopPropagation();
        try {
          n.currentTarget.setPointerCapture(n.pointerId);
        } catch {}
        Z.current = { mode: e, from: O(n.clientX, n.clientY), box: l };
      }
    },
    ce = (e) => {
      const n = Z.current;
      if (!n) return;
      e.stopPropagation();
      const a = O(e.clientX, e.clientY);
      (d(
        n.mode === "move"
          ? tt(n.box, a.x - n.from.x, a.y - n.from.y)
          : rt(n.box, n.mode, a.x, a.y),
      ),
        g(null),
        P(null));
    },
    _ = (e) => {
      (e.stopPropagation(), (Z.current = null));
    },
    ue = () => {
      if (!y || !j) {
        (W(null), E(null));
        return;
      }
      const e = Math.abs(j.x - y.x),
        n = Math.abs(j.y - y.y);
      (e > 0.02 &&
        n > 0.02 &&
        (d({ x: Math.min(y.x, j.x), y: Math.min(y.y, j.y), w: e, h: n }),
        g(null)),
        W(null),
        E(null));
    },
    A =
      y && j
        ? {
            x: Math.min(y.x, j.x),
            y: Math.min(y.y, j.y),
            w: Math.abs(j.x - y.x),
            h: Math.abs(j.y - y.y),
          }
        : l,
    Fe = async () => {
      if (!F.current) return;
      const e = ie() ?? [x];
      ee(!0);
      try {
        const n = [];
        for (const m of e) {
          const f = await J(m);
          f && n.push(f);
        }
        const a = be(n),
          p = a ? Qe(a, re) : null;
        if (!p) {
          M.error("These pages look blank, so there is nothing to trim to");
          return;
        }
        (d(p),
          g(null),
          P(null),
          e.length > 1 &&
            M.success(
              `Selected the area that holds the content of all ${e.length} pages`,
            ));
      } catch (n) {
        (console.error("Auto-trim failed:", n),
          M.error(
            "Couldn't auto-detect the content area — try selecting it manually",
          ));
      } finally {
        ee(!1);
      }
    },
    me = async (e = !1) => {
      if (!t || !l) {
        M.error("Draw the area to keep first, or use Auto-trim");
        return;
      }
      if (v === "range" && !z.trim()) {
        M.error("Enter a page range first");
        return;
      }
      let n;
      if (v === "current") n = [x];
      else if (v === "range") {
        const a = ge(z, i);
        if ("error" in a) {
          M.error(a.error);
          return;
        }
        n = a.pages;
      }
      Q(!0);
      try {
        if (!e) {
          const p = n ?? Array.from({ length: i }, (N, X) => X),
            m = [];
          for (let N = 0; N < i; N++) m.push(p.includes(N) ? await J(N) : null);
          const f = We(m, p, l);
          if (f.length > 0) {
            P(f);
            return;
          }
        }
        P(null);
        const a = await _e(t, l, n);
        (g(a), M.success("PDF cropped"));
      } catch (a) {
        (console.error("Crop failed:", a),
          M.error("Something went wrong cropping this PDF — try again"));
      } finally {
        Q(!1);
      }
    },
    Ae = async () => {
      const e = ie() ?? [x],
        n = l ? [l] : [];
      for (const p of e) {
        const m = await J(p);
        m && n.push(m);
      }
      const a = be(n);
      (a && d(a), P(null), g(null));
    },
    pe = () => {
      (o && URL.revokeObjectURL(o),
        (F.current = null),
        s(null),
        u(null),
        d(null),
        g(null),
        P(null),
        L(0));
    };
  return r.jsx($e, {
    toolId: "crop-pdf",
    categoryId: "pdf-tools",
    whatItDoes: Me.what,
    proTip: Me.tip,
    children: t
      ? $
        ? r.jsx(he, { message: "Loading preview..." })
        : r.jsxs("div", {
            className: "space-y-4",
            children: [
              r.jsxs("p", {
                className: "text-sm font-medium",
                children: [t.name, " -- ", i, " page", i === 1 ? "" : "s"],
              }),
              o &&
                r.jsxs("div", {
                  ref: se,
                  onPointerDown: Te,
                  onPointerMove: ze,
                  onPointerUp: ue,
                  onPointerCancel: ue,
                  className:
                    "relative border rounded-lg bg-white mx-auto select-none",
                  style: {
                    maxWidth: "500px",
                    cursor: "crosshair",
                    touchAction: "none",
                  },
                  children: [
                    r.jsx("img", {
                      ref: ke,
                      src: o,
                      alt: `Page ${x + 1} preview`,
                      className:
                        "w-full h-auto block pointer-events-none select-none rounded-lg",
                      draggable: !1,
                    }),
                    A &&
                      r.jsx("div", {
                        className:
                          "absolute border-2 border-primary bg-primary/20 pointer-events-none",
                        style: {
                          left: `${A.x * 100}%`,
                          top: `${A.y * 100}%`,
                          width: `${A.w * 100}%`,
                          height: `${A.h * 100}%`,
                        },
                      }),
                    l &&
                      !y &&
                      (() => {
                        const e = (a, p) => ({
                            left: `clamp(22px, ${a * 100}%, calc(100% - 22px))`,
                            top: `clamp(22px, ${p * 100}%, calc(100% - 22px))`,
                          }),
                          n = [
                            {
                              c: "nw",
                              x: l.x,
                              y: l.y,
                              cursor: "nwse-resize",
                              label: "top left",
                            },
                            {
                              c: "ne",
                              x: l.x + l.w,
                              y: l.y,
                              cursor: "nesw-resize",
                              label: "top right",
                            },
                            {
                              c: "sw",
                              x: l.x,
                              y: l.y + l.h,
                              cursor: "nesw-resize",
                              label: "bottom left",
                            },
                            {
                              c: "se",
                              x: l.x + l.w,
                              y: l.y + l.h,
                              cursor: "nwse-resize",
                              label: "bottom right",
                            },
                          ];
                        return r.jsxs(r.Fragment, {
                          children: [
                            r.jsx("div", {
                              role: "button",
                              "aria-label": "Move the crop box (drag)",
                              title: "Drag to move the crop box",
                              "data-testid": "crop-move-handle",
                              className:
                                "absolute z-10 flex h-11 w-11 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border-2 border-primary bg-background/90 text-primary shadow",
                              style: {
                                ...e(l.x + l.w / 2, l.y + l.h / 2),
                                touchAction: "none",
                                cursor: "move",
                              },
                              onPointerDown: le("move"),
                              onPointerMove: ce,
                              onPointerUp: _,
                              onPointerCancel: _,
                              children: r.jsx(Ge, {
                                className: "h-5 w-5",
                                "aria-hidden": "true",
                              }),
                            }),
                            n.map((a) =>
                              r.jsx(
                                "div",
                                {
                                  role: "button",
                                  "aria-label": `Resize the crop box from the ${a.label} corner (drag)`,
                                  "data-testid": `crop-handle-${a.c}`,
                                  className:
                                    "absolute z-10 flex h-11 w-11 -translate-x-1/2 -translate-y-1/2 items-center justify-center",
                                  style: {
                                    ...e(a.x, a.y),
                                    touchAction: "none",
                                    cursor: a.cursor,
                                  },
                                  onPointerDown: le(a.c),
                                  onPointerMove: ce,
                                  onPointerUp: _,
                                  onPointerCancel: _,
                                  children: r.jsx("span", {
                                    className:
                                      "block h-4 w-4 rounded-sm border-2 border-primary bg-background shadow",
                                  }),
                                },
                                a.c,
                              ),
                            ),
                          ],
                        });
                      })(),
                  ],
                }),
              i > 1 &&
                r.jsxs("div", {
                  className: "flex items-center justify-center gap-3 text-sm",
                  children: [
                    r.jsx(b, {
                      size: "sm",
                      variant: "outline",
                      disabled: x === 0,
                      onClick: () => L((e) => Math.max(0, e - 1)),
                      children: "Previous",
                    }),
                    r.jsxs("span", { children: ["Page ", x + 1, " of ", i] }),
                    r.jsx(b, {
                      size: "sm",
                      variant: "outline",
                      disabled: x >= i - 1,
                      onClick: () => L((e) => Math.min(i - 1, e + 1)),
                      children: "Next",
                    }),
                  ],
                }),
              r.jsx("p", {
                className: "text-xs text-muted-foreground text-center",
                children:
                  "Drag on the page above to select the area to keep, then use the round handle to move it or a corner square to resize it. The box is applied to each page as a share of its size.",
              }),
              r.jsxs("div", {
                className: "space-y-2",
                "data-testid": "crop-margins",
                children: [
                  r.jsxs("div", {
                    className:
                      "flex justify-center items-center gap-2 flex-wrap text-sm",
                    children: [
                      r.jsx("span", {
                        className: "font-medium",
                        children: "Margins to remove",
                      }),
                      r.jsxs("select", {
                        "aria-label": "Margin unit",
                        value: S,
                        onChange: (e) => Se(e.target.value),
                        className:
                          "h-8 rounded-md border bg-background px-2 text-sm",
                        children: [
                          r.jsx("option", { value: "in", children: "inches" }),
                          r.jsx("option", {
                            value: "mm",
                            children: "millimetres",
                          }),
                        ],
                      }),
                    ],
                  }),
                  r.jsx("div", {
                    className:
                      "grid grid-cols-2 sm:grid-cols-4 gap-2 max-w-md mx-auto",
                    children: ["top", "right", "bottom", "left"].map((e) =>
                      r.jsxs(
                        "label",
                        {
                          className: "text-xs flex flex-col gap-1 capitalize",
                          children: [
                            e,
                            r.jsx(fe, {
                              inputMode: "decimal",
                              "aria-label": `${e} margin`,
                              value: oe[e],
                              placeholder: "0",
                              onChange: (n) => Re(e, n.target.value),
                            }),
                          ],
                        },
                        e,
                      ),
                    ),
                  }),
                  w &&
                    r.jsxs("p", {
                      className: "text-xs text-muted-foreground text-center",
                      "data-testid": "crop-size-readout",
                      children: [
                        l
                          ? `Page ${x + 1}: ${je(l, w.w, w.h, S)}`
                          : `Page ${x + 1} is ${je({ w: 1, h: 1 }, w.w, w.h, S).split(" → ")[0]}`,
                        l && i > 1 && v !== "current"
                          ? ". Other pages keep the same share of their own size."
                          : "",
                      ],
                    }),
                ],
              }),
              r.jsxs("div", {
                className: "flex justify-center items-center gap-3 flex-wrap",
                children: [
                  r.jsxs(b, {
                    size: "sm",
                    variant: "outline",
                    onClick: Fe,
                    disabled: H,
                    className: "gap-1.5",
                    children: [
                      r.jsx(Ve, { className: "h-3.5 w-3.5" }),
                      " ",
                      H ? "Detecting..." : "Auto-trim",
                    ],
                  }),
                  r.jsxs("label", {
                    className: "flex items-center gap-1.5 text-sm",
                    htmlFor: "crop-trim-pad",
                    children: [
                      "Padding",
                      r.jsx("select", {
                        id: "crop-trim-pad",
                        value: re,
                        onChange: (e) => Ce(Number(e.target.value)),
                        className:
                          "h-8 rounded-md border bg-background px-2 text-sm",
                        children: Ze.map((e) =>
                          r.jsx(
                            "option",
                            { value: e.value, children: e.label },
                            e.value,
                          ),
                        ),
                      }),
                    ],
                  }),
                ],
              }),
              r.jsxs("div", {
                className: "space-y-2",
                children: [
                  r.jsx(Ee, {
                    className: "block text-center text-sm",
                    children: "Apply crop to",
                  }),
                  r.jsxs("div", {
                    className: "flex gap-2 justify-center flex-wrap",
                    children: [
                      r.jsx(b, {
                        size: "sm",
                        variant: v === "all" ? "default" : "outline",
                        onClick: () => {
                          (Y("all"), g(null));
                        },
                        children: "All pages",
                      }),
                      r.jsx(b, {
                        size: "sm",
                        variant: v === "current" ? "default" : "outline",
                        onClick: () => {
                          (Y("current"), g(null));
                        },
                        children: "This page",
                      }),
                      r.jsx(b, {
                        size: "sm",
                        variant: v === "range" ? "default" : "outline",
                        onClick: () => {
                          (Y("range"), g(null));
                        },
                        children: "Page range",
                      }),
                    ],
                  }),
                  v === "range" &&
                    r.jsx("div", {
                      className: "max-w-xs mx-auto",
                      children: r.jsx(fe, {
                        value: z,
                        onChange: (e) => {
                          (Ne(e.target.value), g(null));
                        },
                        placeholder: `e.g. 1-${i}`,
                      }),
                    }),
                ],
              }),
              r.jsx("div", {
                className: "flex gap-3 justify-center",
                children: I
                  ? r.jsx(he, { message: "Cropping..." })
                  : T
                    ? r.jsxs(r.Fragment, {
                        children: [
                          r.jsx(Ue, { blob: T, fileName: `cropped_${t.name}` }),
                          r.jsx(b, {
                            variant: "outline",
                            onClick: pe,
                            children: "New",
                          }),
                        ],
                      })
                    : r.jsxs(r.Fragment, {
                        children: [
                          r.jsx(b, {
                            onClick: () => me(),
                            disabled: !l,
                            children: "Apply Crop",
                          }),
                          r.jsx(b, {
                            variant: "ghost",
                            onClick: pe,
                            children: "Reset",
                          }),
                        ],
                      }),
              }),
              C &&
                r.jsxs(de, {
                  role: "alert",
                  className: "text-sm space-y-2 max-w-xl mx-auto",
                  children: [
                    r.jsxs("p", {
                      children: [
                        C.length === 1
                          ? `Page ${C[0]} has`
                          : `Pages ${C.length > 8 ? C.slice(0, 8).join(", ") + ` and ${C.length - 8} more` : C.join(", ")} have`,
                        " content outside this area — it would be cut off.",
                      ],
                    }),
                    r.jsxs("div", {
                      className: "flex gap-2 flex-wrap",
                      children: [
                        r.jsx(b, {
                          size: "sm",
                          onClick: Ae,
                          children: "Widen the box to fit",
                        }),
                        r.jsx(b, {
                          size: "sm",
                          variant: "outline",
                          onClick: () => me(!0),
                          children: "Crop anyway",
                        }),
                        r.jsx(b, {
                          size: "sm",
                          variant: "ghost",
                          onClick: () => P(null),
                          children: "Cancel",
                        }),
                      ],
                    }),
                  ],
                }),
              T &&
                r.jsxs("p", {
                  className:
                    "text-xs text-muted-foreground text-center max-w-xl mx-auto",
                  children: [
                    "Cropping only hides what is outside the box; that content is still inside the file. To remove sensitive content for good, use ",
                    r.jsx("a", {
                      href: "/tool/redact-pdf",
                      className: "underline",
                      children: "Redact PDF",
                    }),
                    ".",
                  ],
                }),
              T && r.jsx(Be, { blob: T, mimeType: "application/pdf" }),
            ],
          })
      : r.jsxs("div", {
          className: "space-y-3",
          children: [
            r.jsx(Le, {
              gateAtDownload: !0,
              keepSkippedProtectedFiles: !0,
              accept: ".pdf",
              onFiles: De,
              onAttempt: () => U(null),
              onUnreadablePdf: (e) => U(we(e.name)),
              label: "Drop a PDF file",
              description: "Crop every page to a region you select",
            }),
            ne &&
              r.jsxs(de, {
                role: "alert",
                className: "text-sm",
                children: [
                  r.jsx("p", { className: "font-medium", children: ye }),
                  r.jsxs("p", {
                    children: [
                      ne,
                      " ",
                      r.jsx("a", {
                        href: "/tool/repair-pdf",
                        className: "underline",
                        children: "Repair PDF",
                      }),
                    ],
                  }),
                ],
              }),
            te &&
              r.jsxs("p", {
                role: "alert",
                className: "text-sm text-destructive",
                children: [
                  "“",
                  te,
                  "” is password-protected, so it can't be cropped yet. ",
                  r.jsx("a", {
                    href: "/tool/unlock-pdf",
                    className: "underline font-medium",
                    children: "Unlock it with Unlock PDF",
                  }),
                  ", then drop the unlocked copy here.",
                ],
              }),
          ],
        }),
  });
}
export { ar as default };
//# sourceMappingURL=CropPdf-DCJe__37.js.map
