}
const sn = "https://freedailypro.com",
  at = "Created with FreeDailyPro.com",
  $o = 60 * 1024 * 1024,
  nn = 4e7,
  Ko =
    /compress|password|protect|unlock|decrypt|repair|redact|sign|linearize|pdf-a\b|bookmark|bates|exhibit/,
  jt =
    /qr|barcode|favicon|icon|exif|compress|convert|heic|svg|ocr|scan|sprite|resize|crop|rotate|flip/,
  rn = /^avatar/;
function lt(e, t) {
  const n = (e || "").toLowerCase(),
    a = t.toLowerCase();
  return n === "application/pdf" || a.endsWith(".pdf")
    ? "pdf"
    : n === "image/png" ||
        n === "image/jpeg" ||
        n === "image/webp" ||
        /\.(png|jpe?g|webp)$/.test(a)
      ? "image"
      : null;
}
function Ne() {
  if (typeof window > "u") return "";
  const e = window.location.pathname.match(/^\/tool\/([^/?#]+)/);
  return e ? e[1] : "";
}
function Bt() {
  const e = Aa();
  return !(!e || e.isPro || e.isAdmin);
}
function Re(e, t, n = Ne()) {
  if (!Bt()) return !1;
  const a = lt(e, t);
  return !(!a || (a === "pdf" && Ko.test(n)) || (a === "image" && jt.test(n)));
}
const ln =
  /^(zip-unzip|file-archive|archive|extract-from-powerpoint|extract-charts-powerpoint|split-powerpoint)/;
function dn(e, t) {
  return /\.zip$/i.test(e) || (t || "").toLowerCase() === "application/zip";
}
function st(e, t, n = Ne()) {
  return Bt() && dn(t, e.type) && !ln.test(n) && e.size <= $o;
}
async function hn(e, t = Ne()) {
  try {
    const { default: n } = await r(
        async () => {
          const { default: d } = await import("./jszip.min-CT0ZA6V1.js").then(
            (h) => h.j,
          );
          return { default: d };
        },
        __vite__mapDeps([0, 1, 2, 3]),
      ),
      a = await n.loadAsync(await e.arrayBuffer());
    let i = !1;
    for (const d of Object.values(a.files)) {
      if (d.dir) continue;
      const h = lt("", d.name);
      if (!h || (h === "pdf" && Ko.test(t)) || (h === "image" && jt.test(t)))
        continue;
      const l = await d.async("uint8array"),
        c =
          h === "pdf"
            ? "application/pdf"
            : /\.png$/i.test(d.name)
              ? "image/png"
              : /\.webp$/i.test(d.name)
                ? "image/webp"
                : "image/jpeg",
        u = new Blob([l], { type: c }),
        p = h === "pdf" ? await Zo(u) : await Qo(u, d.name, t);
      p !== u &&
        (a.file(d.name, new Uint8Array(await p.arrayBuffer())), (i = !0));
    }
    return i
      ? new Blob(
          [
            await a.generateAsync({
              type: "uint8array",
              compression: "DEFLATE",
            }),
          ],
          { type: "application/zip" },
        )
      : e;
  } catch {
    return e;
  }
}
async function nt(e, t, n = Ne()) {
  try {
    if (st(e, t, n)) return await hn(e, n);
    if (e.size > $o || !Re(e.type, t, n)) return e;
    const a = lt(e.type, t);
    if (a === "pdf") return await Zo(e);
    if (a === "image") return await Qo(e, t);
  } catch {}
  return e;
}
const Ue = "#111a2b",
  He = "#4fd8c4",
  cn = "#ffffff";
function Vt(e, t) {
  const n = 0.36 * e,
    a = 0.5 * e,
    i = a / 32.5,
    d = n,
    h = (e - a) / 2,
    l = (I) => h + (52 - I) * i,
    c = (I) => d + (I - 22) * i,
    u = [
      { x: c(22), y: l(52), w: 7 * i, h: 32 * i, color: He },
      { x: c(22), y: l(27), w: 21 * i, h: 7 * i, color: He },
      { x: c(22), y: l(40), w: 16 * i, h: 7 * i, color: He },
    ],
    p = { cx: c(50), cy: l(48), r: 4.5 * i, color: He },
    f = 0.4 * e,
    g = 0.24 * e;
  let b = d + a + g;
  const y = e / 2 - f * 0.33,
    m = [];
  return (
    m.push({ text: at, x: b, y, size: f, color: cn }),
    (b += t(at, f)),
    { w: b + 0.42 * e, h: e, rects: u, dot: p, texts: m }
  );
}
const un = (e) => [
  parseInt(e.slice(1, 3), 16) / 255,
  parseInt(e.slice(3, 5), 16) / 255,
  parseInt(e.slice(5, 7), 16) / 255,
];
function pn(e, t) {
  try {
    const n = e.getPages()[0]?.node.Annots();
    if (!n) return !1;
    for (let a = 0; a < n.size(); a++)
      if (n.lookup(a)?.get?.(t.of("Contents"))?.decodeText?.() === at)
        return !0;
  } catch {}
  return !1;
}
async function Zo(e) {
  const {
      PDFDocument: t,
      StandardFonts: n,
      rgb: a,
      PDFName: i,
      PDFString: d,
      PDFArray: h,
      pushGraphicsState: l,
      popGraphicsState: c,
      concatTransformationMatrix: u,
    } = await r(
      async () => {
        const {
          PDFDocument: m,
          StandardFonts: w,
          rgb: I,
          PDFName: v,
          PDFString: T,
          PDFArray: A,
          pushGraphicsState: N,
          popGraphicsState: C,
          concatTransformationMatrix: E,
        } = await import("./index-BRvxULIc.js").then((x) => x.H);
        return {
          PDFDocument: m,
          StandardFonts: w,
          rgb: I,
          PDFName: v,
          PDFString: T,
          PDFArray: A,
          pushGraphicsState: N,
          popGraphicsState: C,
          concatTransformationMatrix: E,
        };
      },
      __vite__mapDeps([4, 5, 1, 6]),
    ),
    p = new Uint8Array(await e.arrayBuffer()),
    f = await t.load(p, { updateMetadata: !1 });
  if (pn(f, i)) return e;
  const g = await f.embedFont(n.HelveticaBold),
    b = (m) => {
      const [w, I, v] = un(m);
      return a(w, I, v);
    };
  for (const m of f.getPages()) {
    if (!m.node.has(i.of("Contents"))) continue;
    const w = m.getCropBox(),
      I = ((m.getRotation().angle % 360) + 360) % 360,
      v = I === 90 || I === 270 ? w.height : w.width,
      T = I === 90 || I === 270 ? w.width : w.height,
      A =
        I === 90
          ? [0, 1, -1, 0, w.width, 0]
          : I === 180
            ? [-1, 0, 0, -1, w.width, w.height]
            : I === 270
              ? [0, -1, 1, 0, 0, w.height]
              : [1, 0, 0, 1, 0, 0],
      N = (q, D) => [
        A[0] * q + A[2] * D + A[4] + w.x,
        A[1] * q + A[3] * D + A[5] + w.y,
      ],
      C = Math.min(20, Math.max(12, Math.min(v, T) * 0.034)),
      E = Vt(C, (q, D) => g.widthOfTextAtSize(q, D)),
      x = Math.max(8, C * 0.7),
      _ = v - E.w - x,
      j = [x];
    for (const q of j) {
      m.pushOperators(l(), u(A[0], A[1], A[2], A[3], A[4] + w.x, A[5] + w.y));
      const D = C / 2;
      (m.drawRectangle({
        x: _ + D,
        y: q,
        width: E.w - C,
        height: C,
