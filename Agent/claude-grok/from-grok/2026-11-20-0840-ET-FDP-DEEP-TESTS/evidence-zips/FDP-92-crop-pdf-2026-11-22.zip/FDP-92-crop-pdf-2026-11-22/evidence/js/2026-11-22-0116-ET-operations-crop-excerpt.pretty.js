      x: z,
      y: V,
      size: f,
      color: l,
      rotateDegrees: x.rotation,
    });
  }
  const p = await d.save();
  return K(p);
}
function pn(e, t = 0.01) {
  const { data: o, width: a, height: n } = e,
    r = 250,
    i = (D) => {
      for (let P = 0; P < a; P++) {
        const p = (D * a + P) * 4;
        if (o[p] < r || o[p + 1] < r || o[p + 2] < r) return !1;
      }
      return !0;
    },
    f = (D) => {
      for (let P = 0; P < n; P++) {
        const p = (P * a + D) * 4;
        if (o[p] < r || o[p + 1] < r || o[p + 2] < r) return !1;
      }
      return !0;
    };
  let c = 0;
  for (; c < n && i(c);) c++;
  let s = n - 1;
  for (; s > c && i(s);) s--;
  let l = 0;
  for (; l < a && f(l);) l++;
  let u = a - 1;
  for (; u > l && f(u);) u--;
  if (c >= s || l >= u) return { x: 0, y: 0, w: 1, h: 1 };
  const d = a * t,
    g = n * t,
    h = Math.max(0, (l - d) / a),
    m = Math.max(0, (c - g) / n),
    b = Math.min(1 - h, (u - l + d * 2) / a),
    O = Math.min(1 - m, (s - c + g * 2) / n);
  return { x: h, y: m, w: b, h: O };
}
async function mn(e, t, o) {
  const a = new Uint8Array(await e.arrayBuffer()),
    n = await U.load(a),
    r = n.getPages(),
    i = o ?? r.map((s, l) => l),
    f = new Set(i);
  r.forEach((s, l) => {
    if (!f.has(l)) return;
    const u = nt(s),
      d = t.w * u.width,
      g = t.h * u.height,
      h = Oe(u, t.x * u.width, u.height - t.y * u.height - g, d, g);
    s.setCropBox(h.x, h.y, h.width, h.height);
  });
  const c = await n.save();
  return K(c);
}
async function wn(e, t, o) {
  const a = new Uint8Array(await e.arrayBuffer()),
    n = await U.load(a),
    r = await U.create(),
    i = n.getPageCount();
  for (let c = 0; c < i; c++) {
    const s = n.getPage(c),
      l = await r.embedPage(s),
      u = Math.min(t / l.width, o / l.height),
      d = l.width * u,
