# FDP-92 crop-pdf test inputs (made-up data). python3 make92.py
import fitz, io, os, random, pikepdf, shutil
from PIL import Image, ImageDraw, ImageFilter
T='testfiles/'; os.makedirs(T,exist_ok=True)
def body(p,tag,x0=108,y0=108,x1=504,y1=684):
    # content block exactly inside [x0,y0]-[x1,y1] (top-left coords), plus a margin note we expect to be HIDDEN
    p.draw_rect(fitz.Rect(x0,y0,x1,y1),color=(0,0,0.6),width=1.5)
    p.insert_text((x0+12,y0+30),f'{tag} KEEP-HEADING',fontname='hebo',fontsize=16)
    y=y0+60
    for i in range(20):
        p.insert_text((x0+12,y),f'Line {i+1}: searchable body text {tag} alpha beta gamma.',fontname='tiro',fontsize=10); y+=18
    p.draw_rect(fitz.Rect(x0+12,y1-120,x0+150,y1-20),color=(0.8,0,0),fill=(1,0.85,0.85))
# 1. doc.pdf: 3 Letter pages, content box 1.5in margins, hidden margin text "OUTSIDE-SECRET-<n>" in light grey 0.4in from edge
d=fitz.open()
for n in range(3):
    p=d.new_page(width=612,height=792); body(p,f'P{n+1}')
    p.insert_text((30,40),f'OUTSIDE-SECRET-{n+1} header strip',fontname='helv',fontsize=9,color=(0.3,0.3,0.3))
    p.insert_text((30,770),f'Footer page {n+1} OUTSIDE-FOOTER',fontname='helv',fontsize=9,color=(0.3,0.3,0.3))
d.save(T+'doc.pdf')
# 2. clean.pdf: same as doc but nothing in margins (for auto-trim exactness): content box [108,108,504,684]
d=fitz.open()
for n in range(3):
    p=d.new_page(width=612,height=792); body(p,f'C{n+1}')
d.save(T+'clean.pdf')
# 3. rotated.pdf: 4 pages, stored 612x792, quadrant labels in stored coords, /Rotate 0,90,180,270
d=fitz.open()
for n,r in enumerate([0,90,180,270]):
    p=d.new_page(width=612,height=792)
    cols=[(1,.8,.8),(.8,1,.8),(.8,.8,1),(1,1,.7)]
    for qi,(x,y) in enumerate([(0,0),(306,0),(0,396),(306,396)]):
        p.draw_rect(fitz.Rect(x+6,y+6,x+300,y+390),color=(0,0,0),fill=cols[qi],width=1)
        p.insert_text((x+40,y+200),f'Q{qi+1} rot{r}',fontname='hebo',fontsize=28)
    p.set_rotation(r)
d.save(T+'rotated.pdf')
# 4. offset.pdf: p1 existing CropBox offset [100,150,500,700]; p2 MediaBox origin (50,50); p3 rotate 90 + offset crop; p4 crop box bigger than media
d=fitz.open()
for n in range(4):
    p=d.new_page(width=612,height=792)
    for gx in range(0,612,51):
        for gy in range(0,792,66):
            p.draw_rect(fitz.Rect(gx,gy,gx+51,gy+66),color=(.6,.6,.6),width=.5)
            p.insert_text((gx+4,gy+20),f'{gx//51},{gy//66}',fontsize=8)
d.save('/tmp/off.pdf')
q=pikepdf.open('/tmp/off.pdf')
P=q.pages
P[0].obj.CropBox=pikepdf.Array([100,150,500,700])
P[1].obj.MediaBox=pikepdf.Array([50,50,662,842])
P[2].obj.CropBox=pikepdf.Array([100,150,500,700]); P[2].obj.Rotate=90
P[3].obj.CropBox=pikepdf.Array([-20,-20,632,812])
q.save(T+'offset.pdf')
# 5. mixed.pdf: Letter portrait, A4 landscape, A5 portrait, each with a 1in-inset frame
d=fitz.open()
for (w,h) in [(612,792),(842,595),(420,595)]:
    p=d.new_page(width=w,height=h); p.draw_rect(fitz.Rect(72,72,w-72,h-72),color=(0,0,0),width=1)
    p.insert_text((90,110),f'{w}x{h} frame at 1 inch',fontsize=12)
d.save(T+'mixed.pdf')
# 6. stray.pdf: clean content on 3 pages, page 3 has a stray dot near the right edge
d=fitz.open(T+'clean.pdf'); d[2].draw_circle((598,400),3,color=(0,0,0),fill=(0,0,0)); d.save(T+'stray.pdf')
# 7. tinted.pdf: light grey (0.94) full-page background, content in middle
d=fitz.open()
for n in range(2):
    p=d.new_page(width=612,height=792); p.draw_rect(p.rect,fill=(.94,.94,.94),color=None); body(p,f'T{n+1}')
d.save(T+'tinted.pdf')
# 8. scan.pdf: image-only, off-white paper (246), scanner shadow at left edge, text pixels in the middle
img=Image.new('RGB',(1275,1650),(246,246,244)); dr=ImageDraw.Draw(img)
dr.rectangle((0,0,40,1650),fill=(90,90,90))
for i in range(25): dr.text((300,350+i*36),f'Scanned line {i+1}: pixels only, no text layer',fill=(20,20,20))
img=img.filter(ImageFilter.GaussianBlur(0.6)); b=io.BytesIO(); img.save(b,'JPEG',quality=80)
d=fitz.open(); p=d.new_page(width=612,height=792); p.insert_image(p.rect,stream=b.getvalue()); d.save(T+'scan.pdf')
# 9. blank.pdf: 2 blank pages
d=fitz.open(); d.new_page(); d.new_page(); d.save(T+'blank.pdf')
# 10. boxes.pdf: TrimBox/BleedBox/ArtBox + a link annot in the margin + bookmarks
d=fitz.open(T+'clean.pdf'); d[0].insert_link({'kind':fitz.LINK_URI,'from':fitz.Rect(20,20,90,40),'uri':'https://example.com/margin-link'})
d.set_toc([[1,'Page one',1],[1,'Page two',2]]); d.save('/tmp/bx.pdf')
q=pikepdf.open('/tmp/bx.pdf')
for pg in q.pages:
    pg.obj.TrimBox=pikepdf.Array([9,9,603,783]); pg.obj.BleedBox=pikepdf.Array([0,0,612,792]); pg.obj.ArtBox=pikepdf.Array([36,36,576,756])
q.save(T+'boxes.pdf')
for f in ['enc.pdf','corrupt.pdf','large-300p.pdf','heavy.pdf']: shutil.copy('../91-pdf-editor/testfiles/'+f,T+f)
print({f:os.path.getsize(T+f) for f in sorted(os.listdir(T))})
# 11. scan-offwhite.pdf (paper 246, no shadow) and scan-white.pdf (paper 255) image-only, JPEG q80
for name,bg in [('scan-offwhite.pdf',(246,246,244)),('scan-white.pdf',(255,255,255)),('scan-249.pdf',(249,249,249))]:
    img=Image.new('RGB',(1275,1650),bg); dr=ImageDraw.Draw(img)
    for i in range(25): dr.text((300,350+i*36),f'Scanned line {i+1}: pixels only, no text layer',fill=(20,20,20))
    b=io.BytesIO(); img.save(b,'JPEG',quality=80)
    d=fitz.open(); p=d.new_page(width=612,height=792); p.insert_image(p.rect,stream=b.getvalue()); d.save(T+name)
