// FDP-92: what "Open from Google Drive" does for a guest (popup URL host only, OAuth params redacted); closes it. Never signs in.
const pw = require('playwright');
(async () => { const b = await pw.chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 900 } }); const p = await c.newPage();
 await p.goto('https://www.freedailypro.com/tool/crop-pdf', { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500);
 const pop = p.waitForEvent('popup', { timeout: 10000 }).catch(() => null); await p.locator('main button', { hasText: 'Open from Google Drive' }).click(); const w = await pop; await p.waitForTimeout(2500);
 const d = p.locator('[role=dialog]'); const dlg = (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 250) : null;
 let u = null; if (w) { await w.waitForLoadState('domcontentloaded').catch(() => { }); u = w.url().replace(/\?.*$/, '?REDACTED'); await w.close(); }
 await p.screenshot({ path: '/workspace/deep/92-crop-pdf/live/cases/drive-click.png' }); console.log(JSON.stringify({ popup: u, dialog: dlg })); await b.close(); })();
