# FDP-92: inspect a cropped PDF against its original.
# python3 verify92.py <orig> <out> <outdir> <tag> [frac=x,y,w,h | margins_in=T,R,B,L] [needle ...]
import sys, json, os, subprocess, fitz, pikepdf, pypdfium2 as pdfium, numpy as np
from pypdf import PdfReader
from PIL import Image
orig, out, od, tag = sys.argv[1:5]; rest = sys.argv[5:]
spec = rest[0] if rest and ('=' in rest[0]) else None; needles = rest[1:] if spec else rest
os.makedirs(od, exist_ok=True)
R = {'tag': tag, 'orig': os.path.basename(orig), 'out': os.path.basename(out), 'size_orig': os.path.getsize(orig), 'size_out': os.path.getsize(out), 'spec': spec, 'pages': []}
qo, qn = pikepdf.open(orig), pikepdf.open(out)
ro = PdfReader(orig); rn = PdfReader(out)
po = pdfium.PdfDocument(orig); pn = pdfium.PdfDocument(out)
fo, fn = fitz.open(orig), fitz.open(out)
def box(pg, k):
    v = pg.obj.get(k); return [round(float(x), 2) for x in v] if v is not None else None
def ptxt(doc, i): tp = doc[i].get_textpage(); return tp.get_text_range()
def pdftotext(f, i):
    return subprocess.run(['pdftotext', '-f', str(i+1), '-l', str(i+1), '-layout', '-cropbox', f, '-'], capture_output=True, text=True).stdout
for i in range(min(len(qn.pages), 6)):
    a, b = qo.pages[i], qn.pages[i]
    I = {'page': i+1, 'rotate': int(b.obj.get('/Rotate', 0)), 'media_o': box(a, '/MediaBox'), 'crop_o': box(a, '/CropBox'), 'media_n': box(b, '/MediaBox'), 'crop_n': box(b, '/CropBox'),
         'trim_n': box(b, '/TrimBox'), 'bleed_n': box(b, '/BleedBox'), 'art_n': box(b, '/ArtBox'), 'annots_n': len(b.obj.get('/Annots', [])),
         'viewed_o_pt': [round(fo[i].rect.width, 1), round(fo[i].rect.height, 1)], 'viewed_n_pt': [round(fn[i].rect.width, 1), round(fn[i].rect.height, 1)]}
    allt = rn.pages[i].extract_text() or ''; vis = fn[i].get_text(clip=fn[i].rect); pdfi = ptxt(pn, i)
    I['needles'] = {n: {'in_file(pypdf)': n in allt, 'visible_in_cropbox(mupdf clip)': n in vis, 'pdfium_textpage(Chrome)': n in pdfi} for n in needles}
    I['words_orig'] = len((ro.pages[i].extract_text() or '').split()); I['words_out'] = len(allt.split())
    # render
    dpi = 72
    imo = Image.fromarray(np.array(po[i].render(scale=dpi/72).to_pil().convert('L')))
    imn = pn[i].render(scale=dpi/72).to_pil().convert('L'); imn.save(f'{od}/{tag}-p{i+1}.png')
    if spec:
        k, v = spec.split('='); v = [float(x) for x in v.split(',')]
        W, H = fo[i].rect.width, fo[i].rect.height
        if k == 'frac': x, y, w, h = v
        else: t, r_, bt, l = v; x, y, w, h = l*72/W, t*72/H, 1-(l+r_)*72/W, 1-(t+bt)*72/H
        X0, Y0 = round(x*imo.width), round(y*imo.height); X1, Y1 = round((x+w)*imo.width), round((y+h)*imo.height)
        exp = imo.crop((X0, Y0, X1, Y1)); I['expected_px'] = list(exp.size); I['got_px'] = list(imn.size)
        if abs(exp.width-imn.width) <= 3 and abs(exp.height-imn.height) <= 3:
            e = np.asarray(exp.resize(imn.size), dtype=float); g = np.asarray(imn, dtype=float)
            hh = g.shape[0]; m = np.ones_like(g, bool); m[int(hh*0.88):, int(g.shape[1]*0.45):] = False  # skip trial mark corner
            I['mean_abs_diff'] = round(float(np.abs(e-g)[m].mean()), 2); I['region_match'] = I['mean_abs_diff'] < 6
        else: I['region_match'] = False; I['mean_abs_diff'] = None
        Image.fromarray(np.hstack([np.asarray(exp.resize(imn.size)), np.asarray(imn)])).save(f'{od}/{tag}-p{i+1}-exp-vs-got.png')
    R['pages'].append(I)
R['trial_mark_bytes'] = sum(1 for o in qn.objects if isinstance(o, pikepdf.Stream) and b'fdp' in o.read_bytes()[:0]+b'')  # placeholder
R['outline_n'] = len(fn.get_toc()); R['outline_o'] = len(fo.get_toc())
json.dump(R, open(f'{od}/{tag}.json', 'w'), indent=1)
for I in R['pages']:
    print(tag, 'p', I['page'], 'rot', I['rotate'], 'media', I['media_n'], 'crop', I['crop_o'], '->', I['crop_n'], 'view', I['viewed_n_pt'], 'match', I.get('region_match'), I.get('mean_abs_diff'), 'words', I['words_orig'], I['words_out'], json.dumps(I['needles']))
print(tag, 'size', R['size_orig'], '->', R['size_out'], 'toc', R['outline_o'], '->', R['outline_n'])
