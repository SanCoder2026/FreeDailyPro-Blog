import { r as h, j as e } from "./vendor-react-D01g8YgM.js";
import {
  k as W,
  T as ee,
  F as te,
  P as se,
  D as oe,
  R as ae,
  x as re,
} from "./ToolPage-DrleSM7T.js";
import { B as F, e as B, I as ne, f as ie } from "./index-xgcQ0Xo8.js";
import { T as le } from "./ToolInfoSection-DUdo3Ez7.js";
import { a as ce } from "./pdfMetadata-CcxIhQF2.js";
import { p as me, U as de } from "./protectedPdfNotice-Dl0m_ReY.js";
import { g as pe, B as ue } from "./operations-BatXiFlG.js";
import { u as he, P as ge, a as fe } from "./PdfPageThumbnails-Ce-P-PMM.js";
import { l as xe } from "./utils-s8ucLyj8.js";
import "./useUploadApi-yCV1cZhw.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-Cl69OhvT.js";
import "./share-2-tv4Mz_hR.js";
import "./copy-B6PRNyNa.js";
import "./workflowCta-BFTpZlex.js";
import "./UsageAndUpgradeStrip-DMhPNgnJ.js";
import "./access-DqVqJd33.js";
import "./useAdminAccess-mVM_2mWb.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-DxfN0Pem.js";
import "./map-pin-CwlIzHDK.js";
import "./FaqSection-BNxk42M5.js";
import "./ToolVideoEmbed-DNaMY2Pn.js";
import "./GuideLinks-D5fn3NI1.js";
import "./blog-CxdB1WyW.js";
import "./info-x67VbErc.js";
import "./productCards-DhpNcELZ.js";
import "./layers-B44Zba7-.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-DFD2kyG0.js";
import "./chevron-up-RK9L2OPY.js";
import "./pdfFonts-Ckcqm3Ic.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./pageView-BQIwVYOi.js";
import "./formAppearance-CdNbuISd.js";
import "./drawTextAnywhere-DcuP6lHH.js";
import "./ocrText-C_9cxcFa.js";
import "./ocrImage-CmXFNUud.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./imageRecompress-eXQFDUm-.js";
import "./formatFileSize-B-JRDfN5.js";
import "./plural-FIChqbp4.js";
import "./textDiff-DxE9AzvO.js";
import "./utils-BB7NgdRI.js";
import "./decode-FlLGQ42m.js";
import "./formFill-Dg9Myfyq.js";
import "./redactSearch-DQpyyh_t.js";
import "./nameDetect-DvHCRM0m.js";
function K(t, o) {
  const a = (i) => ({ pages: [], error: i, note: null });
  if (!t.trim()) return a(null);
  const p = `${o} ${o === 1 ? "page" : "pages"}`,
    d = new Set();
  let u = !1;
  const r = [];
  for (const i of t
    .split(/[,;]/)
    .map((k) => k.trim())
    .filter(Boolean)) {
    const k = i.replace(/\s+/g, "").replace(/[‐-―−]/g, "-"),
      f = k.match(/^(\d+)-(\d*)$/);
    if (f) {
      let n = Number(f[1]),
        l = f[2] === "" ? o : Number(f[2]);
      if ((n > l && ([n, l] = [l, n]), n < 1 || n > o)) {
        r.push({ raw: i, msg: `"${i}" is outside this PDF's ${p}.` });
        continue;
      }
      l > o && ((l = o), (u = !0));
      for (let b = n; b <= l; b++) d.add(b);
      continue;
    }
    if (/^\d+$/.test(k)) {
      const n = Number(k);
      if (n < 1 || n > o) {
        r.push({ raw: i, msg: `Page ${n} is outside this PDF's ${p}.` });
        continue;
      }
      d.add(n);
      continue;
    }
    r.push({
      raw: i,
      msg: `"${i}" is not a page number or a range. Use a list such as 2, 5-7.`,
    });
  }
  return r.length === 1
    ? a(r[0].msg)
    : r.length > 1
      ? a(
          `These entries cannot be used: ${r.map((i) => `"${i.raw}"`).join(", ")}. Use page numbers from 1 to ${o} or ranges, such as 2, 5-7.`,
        )
      : {
          pages: Array.from(d).sort((i, k) => i - k),
          error: null,
          note: u
            ? `Only ${p} in this file, so the range stops at page ${o}.`
            : null,
        };
}
function ke(t, o) {
  const a = new Set(o);
  return Array.from({ length: t }, (p, d) => d).filter((p) => !a.has(p + 1));
}
const G = 0.005,
  be = 0.5,
  V = 0.025,
  ye = 60;
function ve({ data: t, width: o, height: a }) {
  const p = Math.floor(o * V),
    d = o - p,
    u = Math.floor(a * V),
    r = a - u;
  if (d - p < 3 || r - u < 3) return 0;
  const i = new Uint8Array(o * a),
    k = new Uint32Array(256);
  let f = 0;
  for (let c = u; c < r; c++)
    for (let x = p; x < d; x++) {
      const j = (c * o + x) * 4,
        g = t[j + 3] / 255,
        w = Math.round(
          (0.299 * t[j] + 0.587 * t[j + 1] + 0.114 * t[j + 2]) * g +
            255 * (1 - g),
        );
      ((i[c * o + x] = w), k[w]++, f++);
    }
  let n = 0,
    l = 255;
  for (let c = 0; c < 256; c++)
    if (((n += k[c]), n >= f * 0.85)) {
      l = c;
      break;
    }
  if (l < 120) return 100;
  const b = l - ye,
    y = (c, x) => c >= p && c < d && x >= u && x < r && i[x * o + c] < b;
  let D = 0;
  for (let c = u; c < r; c++)
    for (let x = p; x < d; x++) {
      if (!y(x, c)) continue;
      let j = 0;
      for (let g = -1; g <= 1; g++)
        for (let w = -1; w <= 1; w++) (w || g) && y(x + w, c + g) && j++;
      j >= 2 && D++;
    }
  return (D / f) * 100;
}
function we(t, o) {
  return Object.keys(t)
    .map(Number)
    .filter((a) => t[a] <= o)
    .sort((a, p) => a - p);
}
function Pe(t, o) {
  const a =
    t < 0.005
      ? "no ink"
      : `${t < 0.1 ? t.toFixed(2) : t < 10 ? t.toFixed(1) : Math.round(t)}% ink`;
  return t <= o ? `Blank (${a})` : a;
}
async function je(t, o, a = () => !0, p) {
  const d = {};
  for (let u = 1; u <= t.numPages; u++) {
    if (!a()) return d;
    const r = await t.getPage(u),
      i = r.getViewport({ scale: 1 }),
      k = Math.min(2, 900 / Math.max(i.width, i.height)),
      f = r.getViewport({ scale: k }),
      n = o(Math.max(1, Math.ceil(f.width)), Math.max(1, Math.ceil(f.height))),
      l = n.getContext("2d");
    ((l.fillStyle = "#ffffff"),
      l.fillRect(0, 0, n.width, n.height),
      await r.render({
        canvasContext: l,
        viewport: f,
        canvas: n,
        intent: "print",
      }).promise);
    const b = l.getImageData(0, 0, n.width, n.height);
    ((d[u] = ve({ data: b.data, width: b.width, height: b.height })),
      r.cleanup?.(),
      p?.(u, t.numPages));
  }
  return d;
}
const O = {
  what: "Deletes the pages you choose from a PDF and gives you the rest as a new file, in the original order. Bookmarks that point at the pages you keep and form fields on them are kept. Everything happens in your browser.",
  how: "Drop a PDF. Click the pages you want removed (they get a red cross), or type them as a list such as 2, 5-7. Odd, even and clear buttons help with big files. Or press Select blank pages to tick the empty backs of double-sided scans, and adjust how much ink still counts as blank. Click Remove pages, check the preview and download.",
  tip: 'Your original is never changed, so you can try again. If you would rather list the pages to keep, use Extract Pages & Text instead. You cannot remove every page: at least one must stay. "Select blank pages" only ticks the pages that look empty (pages with just a footer or page number are not counted as blank at the default setting); you still decide, and nothing is removed until you press Remove pages. Check scans with faint show-through before you apply.',
};
function Nt() {
  const [t, o] = h.useState(null),
    [a, p] = h.useState(0),
    [d, u] = h.useState(""),
    [r, i] = h.useState(new Set()),
    [k, f] = h.useState(!1),
    [n, l] = h.useState(null),
    [b, y] = h.useState(""),
    [D, c] = h.useState(null),
    { thumbnails: x, loading: j } = he(t),
    [g, w] = h.useState(null),
    [$, A] = h.useState(G),
    [S, M] = h.useState([]),
    [T, R] = h.useState(null),
    [U, E] = h.useState(""),
    Y = h.useCallback(async (s) => {
      const m = s[0];
      if (m) {
        if ((c(null), W(m))) {
          c(m.name);
          return;
        }
        (o(m),
          l(null),
          y(""),
          u(""),
          i(new Set()),
          w(null),
          M([]),
          E(""),
          A(G));
        try {
          p(await pe(m));
        } catch {
          (y(
            "This PDF could not be read. It may be damaged or password-protected (try Unlock PDF or Repair PDF).",
          ),
            o(null));
        }
      }
    }, []),
    C = (s) => {
      (i(new Set(s)), u(s.join(",")), l(null), y(""));
    },
    P = h.useMemo(() => K(d, a), [d, a]),
    H = (s) => {
      const m = new Set(r);
      (m.has(s) ? m.delete(s) : m.add(s),
        C(Array.from(m).sort((v, N) => v - N)));
    },
    z = h.useMemo(() => Array.from({ length: a }, (s, m) => m + 1), [a]),
    _ = (s, m, v) => {
      const N = we(s, m),
        I = Array.from(r).filter((L) => !v.includes(L));
      return (
        M(N),
        C(Array.from(new Set([...I, ...N])).sort((L, Q) => L - Q)),
        N.length
      );
    },
    X = async () => {
      if (!(!t || T)) {
        (E(""), R({ done: 0, total: a }));
        try {
          const s = await xe(t),
            m =
              g ??
              (await je(
                s,
                (v, N) => {
                  const I = document.createElement("canvas");
                  return ((I.width = v), (I.height = N), I);
                },
                () => !0,
                (v, N) => R({ done: v, total: N }),
              ));
          (w(m), _(m, $, S));
        } catch (s) {
          (console.error(s),
            E(
              "The pages could not be checked for blank ones. Pick them by hand in the previews instead.",
            ));
        } finally {
          R(null);
        }
      }
    },
    Z = (s) => {
      (A(s), g && _(g, s, S));
    },
    q = h.useMemo(() => {
      if (g)
        return Object.fromEntries(
          Object.keys(g).map((s) => [Number(s), Pe(g[Number(s)], $)]),
        );
    }, [g, $]),
    J = async () => {
      if (!t) return;
      if (!d.trim()) {
        y("Choose at least one page to remove.");
        return;
      }
      if (P.error) {
        y(P.error);
        return;
      }
      const s = new Set(P.pages),
        m = ke(a, P.pages);
      if (m.length === 0) {
        y("That would remove every page. Leave at least one page in the file.");
        return;
      }
      (f(!0), y(""));
      try {
        const v = await ue(t, m);
        (l({ blob: v, kept: m.length, removed: s.size }),
          ie.success(`${s.size} page${s.size === 1 ? "" : "s"} removed`));
      } catch (v) {
        (console.error(v),
          y(
            re(t)
              ? "The pages could not be removed from this password-protected file. Unlock PDF can make an unprotected copy; use that file here, or try Repair PDF."
              : "The pages could not be removed. The file may be damaged; try Repair PDF first.",
          ));
      } finally {
        f(!1);
      }
    };
  return e.jsxs(ee, {
    children: [
      t
        ? e.jsxs("div", {
            className: "space-y-4",
            children: [
              e.jsx("div", {
                className: "p-4 rounded-lg border bg-card",
                children: e.jsxs("p", {
                  className: "text-sm font-medium",
                  children: [t.name, " — ", a, " page", a === 1 ? "" : "s"],
                }),
              }),
              j
                ? e.jsx(ge, {})
                : e.jsxs(e.Fragment, {
                    children: [
                      e.jsxs("div", {
                        className: "flex flex-wrap gap-1",
                        children: [
                          e.jsx(F, {
                            size: "sm",
                            variant: "ghost",
                            onClick: () => C(z.filter((s) => s % 2 === 1)),
                            children: "Odd pages",
                          }),
                          e.jsx(F, {
                            size: "sm",
                            variant: "ghost",
                            onClick: () => C(z.filter((s) => s % 2 === 0)),
                            children: "Even pages",
                          }),
                          e.jsx(F, {
                            size: "sm",
                            variant: "ghost",
                            onClick: () => {
                              (C([]), M([]));
                            },
                            children: "Clear",
                          }),
                          e.jsx(F, {
                            size: "sm",
                            variant: "outline",
                            onClick: () => {
                              X();
                            },
                            disabled: !!T,
                            "data-testid": "select-blank",
                            children: T
                              ? `Checking page ${Math.min(T.done + 1, T.total)} of ${T.total}...`
                              : "Select blank pages",
                          }),
                        ],
                      }),
                      g &&
                        e.jsxs("div", {
                          className: "space-y-1",
                          "data-testid": "blank-summary",
                          children: [
                            e.jsxs(B, {
                              htmlFor: "rm-ink",
                              children: [
                                "Ink that still counts as blank: ",
                                $.toFixed(3),
                                "% of the page",
                              ],
                            }),
                            e.jsx("input", {
                              id: "rm-ink",
                              type: "range",
                              min: 0,
                              max: be,
                              step: 0.005,
                              value: $,
                              onChange: (s) => Z(Number(s.target.value)),
                              className: "w-full",
                            }),
                            e.jsx("p", {
                              className: "text-xs text-muted-foreground",
                              "aria-live": "polite",
                              children:
                                S.length === 0
                                  ? "No page looks blank at this setting. Raise it to also count pages with a little ink, such as a stamp or page number."
                                  : `${S.length} page${S.length === 1 ? "" : "s"} look blank (${S.join(", ")}) and ${S.length === 1 ? "is" : "are"} ticked below. Nothing is removed until you press Remove pages. Pages with only a footer or page number are not counted as blank at the default.`,
                            }),
                          ],
                        }),
                      U &&
                        e.jsx("p", {
                          role: "alert",
                          className: "text-sm text-destructive",
                          children: U,
                        }),
                      e.jsx(fe, {
                        thumbnails: x,
                        selected: r,
                        onToggle: H,
                        mode: "remove",
                        captions: q,
                      }),
                    ],
                  }),
              e.jsxs("div", {
                children: [
                  e.jsx(B, {
                    htmlFor: "rm-pages",
                    children: 'Pages to remove (e.g. "2, 5-7")',
                  }),
                  e.jsx(ne, {
                    id: "rm-pages",
                    value: d,
                    onChange: (s) => {
                      (u(s.target.value),
                        l(null),
                        y(""),
                        i(new Set(K(s.target.value, a).pages)));
                    },
                    "aria-invalid": !!P.error,
                    "aria-describedby": "rm-pages-msg",
                  }),
                  e.jsxs("div", {
                    id: "rm-pages-msg",
                    "aria-live": "polite",
                    children: [
                      P.error &&
                        e.jsx("p", {
                          className: "text-sm text-destructive mt-1",
                          children: P.error,
                        }),
                      !P.error &&
                        P.note &&
                        e.jsx("p", {
                          className: "text-xs text-muted-foreground mt-1",
                          children: P.note,
                        }),
                    ],
                  }),
                ],
              }),
              r.size > 0 &&
                e.jsxs("p", {
                  className: "text-xs text-muted-foreground",
                  "aria-live": "polite",
                  children: [
                    r.size,
                    " page",
                    r.size === 1 ? "" : "s",
                    " will be removed; ",
                    Math.max(0, a - r.size),
                    " stay.",
                  ],
                }),
              b &&
                e.jsx("p", {
                  role: "alert",
                  className: "text-sm text-destructive",
                  children: b,
                }),
              e.jsx("div", {
                className: "flex gap-3",
                children: k
                  ? e.jsx(se, {})
                  : n
                    ? e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(oe, {
                            blob: n.blob,
                            fileName: `${ce(t.name)}-removed-pages.pdf`,
                            label: "Download PDF",
                          }),
                          e.jsx(F, {
                            variant: "outline",
                            onClick: () => {
                              (o(null), l(null));
                            },
                            children: "New",
                          }),
                        ],
                      })
                    : e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(F, {
                            onClick: J,
                            disabled: r.size === 0,
                            children: "Remove pages",
                          }),
                          e.jsx(F, {
                            variant: "ghost",
                            onClick: () => o(null),
                            children: "Reset",
                          }),
                        ],
                      }),
              }),
              n && e.jsx(ae, { blob: n.blob, mimeType: "application/pdf" }),
            ],
          })
        : e.jsxs("div", {
            className: "space-y-3",
            children: [
              e.jsx(te, {
                gateAtDownload: !0,
                keepSkippedProtectedFiles: !0,
                accept: ".pdf",
                onFiles: Y,
                label: "Drop a PDF file",
                description: "Delete the pages you do not need",
              }),
              D &&
                e.jsxs("p", {
                  role: "alert",
                  className: "text-sm text-destructive",
                  children: [
                    me(D, "edited"),
                    " ",
                    e.jsx("a", {
                      href: de,
                      className: "underline font-medium",
                      children: "Unlock it with Unlock PDF",
                    }),
                    ", then drop the unlocked copy here.",
                  ],
                }),
            ],
          }),
      e.jsx(le, { whatIsIt: O.what, howToUse: O.how, tip: O.tip }),
    ],
  });
}
export { Nt as default };
//# sourceMappingURL=RemovePdfPages-DQGNibzq.js.map
