import {
  P as t,
  a as F,
  b as h,
  c as x,
  d as P,
  e as N,
  f as O,
} from "./index-BRvxULIc.js";
function T(r) {
  const l = r.context,
    e = r.catalog.lookupMaybe(t.of("Outlines"), h);
  if (!e) return [];
  const a = r.getPages().map((f) => f.ref),
    u = (f) => {
      const n = a.findIndex(
        (s) =>
          s.objectNumber === f.objectNumber &&
          s.generationNumber === f.generationNumber,
      );
      return n >= 0 ? n : null;
    },
    g = (f) => {
      let n = f.get(t.of("Dest"));
      if (!n) {
        const o = f.lookupMaybe(t.of("A"), h);
        o?.get(t.of("S"))?.toString() === "/GoTo" && (n = o.get(t.of("D")));
      }
      if (!n) return null;
      let s;
      try {
        s = l.lookupMaybe(n, O);
      } catch {
        return null;
      }
      const i = s?.get(0);
      return i instanceof x ? u(i) : null;
    },
    c = (f) => {
      const n = [],
        s = new Set();
      let i = f;
      for (; i && !s.has(i.tag);) {
        s.add(i.tag);
        const o = l.lookupMaybe(i, h);
        if (!o) break;
        const d = o.lookup(t.of("Title")),
          k = d instanceof N || d instanceof P ? d.decodeText() : "",
          m = o.get(t.of("First"));
        n.push({
          title: k,
          pageIndex: g(o),
          children: m instanceof x ? c(m) : [],
        });
        const D = o.get(t.of("Next"));
        i = D instanceof x ? D : void 0;
      }
      return n;
    },
    p = e.get(t.of("First"));
  return p instanceof x ? c(p) : [];
}
const b = (r) => r.reduce((l, e) => l + 1 + b(e.children), 0);
function S(r, l) {
  if (l.length === 0) return;
  const e = r.context,
    a = e.nextRef(),
    u = (p, f) => {
      const n = p.map(() => e.nextRef());
      return (
        p.forEach((s, i) => {
          const o = e.obj({});
          if (
            (o.set(t.of("Title"), P.fromText(s.title || "Untitled")),
            o.set(t.of("Parent"), f),
            i > 0 && o.set(t.of("Prev"), n[i - 1]),
            i < p.length - 1 && o.set(t.of("Next"), n[i + 1]),
            s.page && o.set(t.of("Dest"), e.obj([s.page.ref, t.of("Fit")])),
            s.children.length > 0)
          ) {
            const d = u(s.children, n[i]);
            (o.set(t.of("First"), d.first),
              o.set(t.of("Last"), d.last),
              o.set(t.of("Count"), F.of(b(s.children))));
          }
          e.assign(n[i], o);
        }),
        { first: n[0], last: n[n.length - 1] }
      );
    },
    g = u(l, a),
    c = e.obj({});
  (c.set(t.of("Type"), t.of("Outlines")),
    c.set(t.of("First"), g.first),
    c.set(t.of("Last"), g.last),
    c.set(t.of("Count"), F.of(b(l))),
    e.assign(a, c),
    r.catalog.set(t.of("Outlines"), a));
}
function w(r, l) {
  return r.map((e) => ({
    title: e.title,
    page: e.pageIndex !== null ? (l[e.pageIndex] ?? null) : null,
    children: w(e.children, l),
  }));
}
function y(r, l) {
  const e = [];
  for (const a of r) {
    const u = y(a.children, l),
      g = a.pageIndex !== null ? (l.get(a.pageIndex) ?? null) : null;
    (!g && u.length === 0) ||
      e.push({
        title: a.title,
        page: g ?? u.find((c) => c.page)?.page ?? null,
        children: u,
      });
  }
  return e;
}
export { w as a, y as m, T as r, S as w };
//# sourceMappingURL=pdfBookmarks-BjfxtCfb.js.map
