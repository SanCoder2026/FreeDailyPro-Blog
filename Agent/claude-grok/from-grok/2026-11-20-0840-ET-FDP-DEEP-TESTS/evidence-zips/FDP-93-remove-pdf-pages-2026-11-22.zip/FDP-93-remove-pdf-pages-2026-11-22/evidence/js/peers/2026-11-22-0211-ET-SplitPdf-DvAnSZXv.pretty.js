import { r as m, j as t } from "./vendor-react-D01g8YgM.js";
import { J as ne } from "./jszip.min-CT0ZA6V1.js";
import { g as re, p as K, s as ie } from "./operations-BlL6iX51.js";
import { p as le } from "./utils-s8ucLyj8.js";
import {
  w as me,
  F as pe,
  P as de,
  S as q,
  a as J,
  D as ce,
  d as ue,
} from "./ToolPage-B4roIUf_.js";
import {
  f as x,
  e as T,
  B as w,
  I as U,
  a3 as ge,
  b as fe,
} from "./index-DagluEtV.js";
import { T as he } from "./ToolWithSidebar-DStt-BwB.js";
import { u as xe, P as be } from "./PdfPageThumbnails-NaEsN3Wa.js";
import { u as we } from "./useRunToken-sJpsnYiZ.js";
import { f as Y } from "./formatFileSize-B-JRDfN5.js";
import { p as c } from "./plural-FIChqbp4.js";
import { T as ye } from "./ToolSteps-DiGCpXJU.js";
import { u as ve } from "./useDownloadedResult-C1FfMpBH.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./pdfFonts-CIqHAJiw.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./pdfMetadata-CcxIhQF2.js";
import "./pageView-BQIwVYOi.js";
import "./formAppearance-TraefmEd.js";
import "./drawTextAnywhere-Dl7l_xfJ.js";
import "./ocrText-C_9cxcFa.js";
import "./ocrImage-DAAOwTV-.js";
import "./imageRecompress-eXQFDUm-.js";
import "./textDiff-DxE9AzvO.js";
import "./utils-BvcV7ep8.js";
import "./decode-CE2kW_I3.js";
import "./formFill-xgtRnF-K.js";
import "./redactSearch-DQpyyh_t.js";
import "./nameDetect-DvHCRM0m.js";
import "./useUploadApi-Cwp1vwlT.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-CL8JsD0s.js";
import "./share-2-B34wyobX.js";
import "./copy-CQptMDp5.js";
import "./workflowCta-oWYKzOWD.js";
import "./UsageAndUpgradeStrip-BiAdGTIF.js";
import "./access-BSSUf40u.js";
import "./useAdminAccess-CYp3AlSq.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CgocG3qD.js";
import "./map-pin-DvVDRebE.js";
import "./FaqSection-DsOLPaJ0.js";
import "./ToolVideoEmbed-CZwBIyFf.js";
import "./GuideLinks-BVE0aHrc.js";
import "./blog-BPnsEI_q.js";
import "./info-56I4OKVq.js";
import "./productCards-CUOqxId0.js";
import "./layers-BVDCe9zx.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-DmEVOuX4.js";
import "./chevron-up-B0wsCoBg.js";
const G = {
  what: `Breaks a single PDF into separate files by page range — extract just the pages you need, or list several ranges at once to get multiple files in one pass (packaged as one ZIP download when there's more than one file). Can also combine the selected ranges into a single reordered PDF instead, if that's what you actually need. Useful when you've received a large combined document but only need to share or file away a portion of it.

Upload your PDF, check the page previews to confirm which pages are which, then type the page range or ranges you want (comma-separated, e.g. "1-3, 4-6, 7") — or click "Every page" for a one-click split into every individual page, no typing required. Choose whether you want each range as its own separate file, or all of them combined into one PDF in the order you listed them, then download.

If you only need one specific page pulled out, or you need the actual text content rather than a page-range PDF, Extract Pages & Text is the more direct tool for that — Split is built around ranges and multi-file output, not single-page or text extraction.`,
  tip: "Combining into one PDF is also a quick way to reorder or drop a few pages from a document — list the ranges in the order you want them to end up in.",
};
function je(p) {
  const j = new Set(),
    r = new Set();
  for (const o of p)
    for (const s of Array.from(new Set(o))) (j.has(s) ? r : j).add(s);
  if (r.size === 0) return null;
  const u = Array.from(r)
      .sort((o, s) => o - s)
      .map((o) => o + 1),
    g = [];
  for (let o = 0; o < u.length;) {
    let s = o;
    for (; s + 1 < u.length && u[s + 1] === u[s] + 1;) s++;
    (g.push(s > o ? `${u[o]}-${u[s]}` : `${u[o]}`), (o = s + 1));
  }
  return `${r.size === 1 ? "Page" : "Pages"} ${g.join(", ")} ${r.size === 1 ? "appears" : "appear"} in more than one file.`;
}
function kt() {
  const [p, j] = m.useState(null),
    [r, u] = m.useState(0),
    [g, o] = m.useState(""),
    [s, F] = m.useState(!1),
    [P, N] = m.useState(!1),
    [V, k] = m.useState(0),
    [l, $] = m.useState([]),
    [z, D] = m.useState(null),
    [S, B] = m.useState(!1),
    { thumbnails: A, loading: W } = xe(p),
    h = we(),
    [L, I] = m.useState(""),
    y = () => {
      (h.cancel(), N(!1), k(0), $([]), D(null));
    },
    H = () => {
      (y(), j(null), u(0), o(""), F(!1), I(""));
    },
    Q = () => {
      (y(), o(Array.from({ length: r }, (e, a) => a + 1).join(",")));
    },
    O = () => {
      const e = L.trim(),
        a = Number(e);
      if (!e || !Number.isInteger(a) || a < 1) {
        x.error("Enter a whole number of 1 or more");
        return;
      }
      y();
      const n = [];
      for (let d = 1; d <= r; d += a) {
        const i = Math.min(d + a - 1, r);
        n.push(d === i ? `${d}` : `${d}-${i}`);
      }
      o(n.join(","));
    },
    X = m.useCallback(
      async (e) => {
        const a = e[0];
        if (a) {
          (h.cancel(), N(!1), k(0), $([]), D(null), F(!1), I(""));
          try {
            const n = await re(a);
            (j(a), u(n), o(n === 1 ? "1" : `1-${n}`));
          } catch {
            x.error(`"${a.name}" couldn't be read as a PDF`);
          }
        }
      },
      [h],
    ),
    ee = () => {
      (h.cancel(), N(!1), k(0), x.info("Stopped."));
    },
    E = async () => {
      if (!p) return;
      y();
      const e = g
        .split(/[,;]/)
        .map((i) => i.trim())
        .filter(Boolean);
      if (e.length === 0) {
        x.error("Enter at least one page range");
        return;
      }
      const a = e.map((i) => K(i, r)),
        n = a.find((i) => "error" in i);
      if (n) {
        x.error(n.error);
        return;
      }
      const d = h.start();
      N(!0);
      try {
        const i = a.map((f) => f.pages),
          _ = await ie(p, i, s, (f, R) => {
            h.isCurrent(d) && k((f / R) * 100);
          });
        if (!h.isCurrent(d)) return;
        ($(
          _.map((f, R) => ({
            blob: le(f.blob),
            name: f.name,
            rangeLabel: f.rangeLabel,
            pageCount: f.pageCount,
            firstPage: (s ? i[0] : i[R])[0] ?? 0,
            formFields: f.formFields,
            bookmarks: f.bookmarks,
          })),
        ),
          D(s ? null : je(i)),
          s
            ? x.success(`Combined ${c(i.flat().length, "page")} into one PDF`)
            : x.success(`Split into ${c(_.length, "file")}`));
      } catch (i) {
        if (!h.isCurrent(d)) return;
        (console.error("Split failed:", i), x.error("Failed to split PDF"));
      } finally {
        h.isCurrent(d) && N(!1);
      }
    },
    Z = async () => {
      B(!0);
      try {
        const e = new ne();
        for (const n of l) e.file(n.name, n.blob);
        const a = await e.generateAsync({ type: "blob" });
        ue(a, `${(p?.name ?? "split").replace(/\.pdf$/i, "")}-split.zip`);
      } catch (e) {
        (console.error("ZIP packaging failed:", e),
          x.error(
            "Couldn't package the files into a ZIP — download them individually below instead.",
          ));
      } finally {
        B(!1);
      }
    },
    b = r === 1,
    te = ve(l.length > 0 ? l : null),
    se = !!p && (g.trim() !== (b ? "1" : `1-${r}`) || s),
    v = m.useMemo(() => {
      if (!p) return null;
      const e = g
        .split(/[,;]/)
        .map((a) => a.trim())
        .filter(Boolean);
      if (e.length === 0) return "Enter at least one page range";
      for (const a of e) {
        const n = K(a, r);
        if ("error" in n) return n.error;
      }
      return null;
    }, [p, g, r]),
    C = m.useMemo(
      () =>
        g
          .split(/[,;]/)
          .map((e) => e.trim())
          .filter(Boolean),
      [g],
    ),
    M = s ? 1 : C.length,
    ae = `${c(r, "page")} · ${c(M, "file")}${C.length > 0 && C.length <= 4 ? ` from ${C.join(", ")}` : ""}`,
    oe =
      l.length > 0 &&
      l.some((e) => me(e.blob.type || "application/pdf", e.name, "split-pdf"));
  return t.jsxs(he, {
    toolId: "split-pdf",
    categoryId: "pdf-tools",
    whatItDoes: G.what,
    proTip: G.tip,
    children: [
      t.jsx(ye, {
        toolId: "split-pdf",
        state: {
          hasFile: !!p,
          rangesChosen: se,
          processing: P,
          resultReady: l.length > 0 && !P,
          downloaded: te,
        },
      }),
      p
        ? t.jsxs("div", {
            className: "space-y-4",
            children: [
              t.jsxs("div", {
                className: "p-4 rounded-lg border border-border bg-card",
                children: [
                  t.jsxs("p", {
                    className: "text-sm font-medium",
                    children: [p.name, " — ", c(r, "page")],
                  }),
                  b &&
                    t.jsx("p", {
                      className: "text-xs text-muted-foreground mt-1",
                      children:
                        "This PDF has only one page, so there is nothing to split.",
                    }),
                ],
              }),
              W
                ? t.jsx(be, {})
                : t.jsx("div", {
                    className:
                      "flex snap-x gap-2 overflow-x-auto rounded-lg sm:grid sm:grid-cols-4 sm:gap-3 sm:overflow-x-visible sm:overflow-y-auto sm:max-h-72 md:grid-cols-6",
                    tabIndex: 0,
                    "aria-label": "Page previews",
                    children: A.map((e) =>
                      t.jsxs(
                        "div",
                        {
                          className:
                            "flex w-[60px] shrink-0 snap-start flex-col items-center gap-1 sm:w-auto sm:shrink",
                          children: [
                            t.jsx("div", {
                              className:
                                "border rounded-lg overflow-hidden bg-white w-full",
                              style: { aspectRatio: "0.75" },
                              children: t.jsx("img", {
                                src: e.url,
                                alt: `Page ${e.pageNumber}`,
                                className: "w-full h-full object-contain",
                              }),
                            }),
                            t.jsx("span", {
                              className: "text-xs text-muted-foreground",
                              children: e.pageNumber,
                            }),
                          ],
                        },
                        e.pageNumber,
                      ),
                    ),
                  }),
              t.jsxs("div", {
                className: "space-y-2",
                children: [
                  t.jsxs("div", {
                    className: "flex items-center justify-between",
                    children: [
                      t.jsx(T, {
                        htmlFor: "split-ranges",
                        children:
                          'Page ranges (comma-separated, e.g. "1-3, 4-6, 7")',
                      }),
                      t.jsx(w, {
                        type: "button",
                        size: "sm",
                        variant: "outline",
                        className: "max-sm:min-h-11",
                        onClick: Q,
                        disabled: b,
                        children: "Every page",
                      }),
                    ],
                  }),
                  t.jsx(U, {
                    id: "split-ranges",
                    value: g,
                    onChange: (e) => {
                      (y(), o(e.target.value));
                    },
                    onKeyDown: (e) => {
                      e.key === "Enter" &&
                        !P &&
                        !b &&
                        (e.preventDefault(), E());
                    },
                    placeholder: "1-3, 4-6",
                    "aria-invalid": v ? !0 : void 0,
                    "aria-describedby": v ? "split-ranges-error" : void 0,
                    className: "max-sm:h-11",
                  }),
                  v &&
                    t.jsx("p", {
                      id: "split-ranges-error",
                      role: "alert",
                      className: "text-sm text-destructive",
                      children: v,
                    }),
                  t.jsxs("div", {
                    className: "flex items-center gap-2",
                    children: [
                      t.jsx(T, {
                        htmlFor: "split-every-n",
                        className: "text-xs font-normal text-muted-foreground",
                        children: "Or split every",
                      }),
                      t.jsx(U, {
                        id: "split-every-n",
                        value: L,
                        onChange: (e) => I(e.target.value),
                        onKeyDown: (e) => {
                          e.key === "Enter" && (e.preventDefault(), O());
                        },
                        placeholder: "e.g. 3",
                        "aria-label": "Split every this many pages",
                        className: "w-20 h-11 text-base sm:h-8 sm:text-sm",
                        inputMode: "numeric",
                        disabled: b,
                      }),
                      t.jsx("span", {
                        className: "text-xs text-muted-foreground",
                        children: "pages",
                      }),
                      t.jsx(w, {
                        type: "button",
                        size: "sm",
                        variant: "outline",
                        className: "max-sm:min-h-11",
                        onClick: O,
                        disabled: b,
                        children: "Apply",
                      }),
                    ],
                  }),
                ],
              }),
              t.jsxs("div", {
                className: "flex items-center gap-2 max-sm:min-h-11",
                children: [
                  t.jsx("input", {
                    type: "checkbox",
                    id: "combine-into-one",
                    checked: s,
                    onChange: (e) => {
                      (y(), F(e.target.checked));
                    },
                    className: "h-4 w-4",
                  }),
                  t.jsx(T, {
                    htmlFor: "combine-into-one",
                    className: "cursor-pointer font-normal",
                    children:
                      "Combine all ranges into one PDF file, instead of separate files",
                  }),
                ],
              }),
              t.jsx("div", {
                className: "flex gap-3",
                children: P
                  ? t.jsx(de, {
                      message: s ? "Combining..." : "Splitting...",
                      progress: s ? void 0 : V,
                      onStop: ee,
                    })
                  : t.jsxs(t.Fragment, {
                      children: [
                        t.jsx(w, {
                          onClick: E,
                          disabled: b || !!v,
                          className: "btn-glow max-sm:hidden",
                          children: "Split PDF",
                        }),
                        t.jsx(w, {
                          variant: "outline",
                          className: "max-sm:min-h-11",
                          onClick: H,
                          children: "Reset",
                        }),
                        l.length === 0 &&
                          t.jsxs(q, {
                            children: [
                              t.jsx("div", {
                                className:
                                  "min-w-0 flex-1 text-[13px] leading-tight text-muted-foreground",
                                "data-testid": "split-bar-summary",
                                children: ae,
                              }),
                              t.jsx(w, {
                                onClick: E,
                                disabled: b || !!v,
                                className: `${J} btn-glow`,
                                "data-testid": "split-bar-button",
                                children: s
                                  ? "Combine into 1 file"
                                  : `Split into ${c(M, "file")}`,
                              }),
                            ],
                          }),
                        l.length > 1 &&
                          t.jsxs(q, {
                            children: [
                              t.jsxs("div", {
                                className:
                                  "min-w-0 flex-1 text-[13px] leading-tight text-muted-foreground",
                                children: [c(l.length, "file"), " ready"],
                              }),
                              t.jsx(w, {
                                onClick: Z,
                                disabled: S,
                                className: J,
                                "data-testid": "split-bar-zip",
                                children: S
                                  ? "Packaging..."
                                  : "Download all (ZIP)",
                              }),
                            ],
                          }),
                      ],
                    }),
              }),
              l.length > 0 &&
                t.jsxs("div", {
                  className: "space-y-2 pt-4 border-t",
                  children: [
                    z &&
                      t.jsx("p", {
                        className: "text-xs text-muted-foreground",
                        children: z,
                      }),
                    oe &&
                      t.jsxs("p", {
                        className: "text-xs text-muted-foreground sm:hidden",
                        "data-testid": "split-mark-note-once",
                        children: [
                          "Trial downloads carry a small badge. Remove it with the ",
                          ge.dayPass,
                          " day pass.",
                          " ",
                          t.jsx(fe, {
                            href: "/pricing",
                            className:
                              "inline-flex min-h-11 items-center underline",
                            children: "See passes",
                          }),
                        ],
                      }),
                    l.length > 1 &&
                      t.jsx(w, {
                        onClick: Z,
                        disabled: S,
                        className: "w-full btn-glow max-sm:hidden",
                        children: S
                          ? "Packaging ZIP..."
                          : `Download all ${l.length} files as ZIP`,
                      }),
                    l.map((e, a) => {
                      const n = A[e.firstPage];
                      return t.jsxs(
                        "div",
                        {
                          className:
                            "split-result flex items-center justify-between gap-3 p-3 rounded-lg border",
                          children: [
                            t.jsxs("div", {
                              className: "flex items-center gap-3 min-w-0",
                              children: [
                                n &&
                                  t.jsx("div", {
                                    className:
                                      "w-10 shrink-0 border rounded overflow-hidden bg-white",
                                    style: { aspectRatio: "0.75" },
                                    children: t.jsx("img", {
                                      src: n.url,
                                      alt: `First page of ${e.name}`,
                                      className: "w-full h-full object-contain",
                                    }),
                                  }),
                                t.jsxs("div", {
                                  className: "min-w-0",
                                  children: [
                                    t.jsx("p", {
                                      className:
                                        "text-sm truncate max-sm:overflow-visible max-sm:whitespace-normal max-sm:[overflow-wrap:anywhere]",
                                      title: e.name,
                                      children: e.name,
                                    }),
                                    t.jsxs("p", {
                                      className:
                                        "text-xs text-muted-foreground",
                                      children: [
                                        e.rangeLabel,
                                        " · ",
                                        c(e.pageCount, "page"),
                                        " · ",
                                        Y(e.blob.size),
                                        e.formFields > 0 &&
                                          ` · ${c(e.formFields, "form field")} kept`,
                                        e.bookmarks > 0 &&
                                          ` · ${c(e.bookmarks, "bookmark")} kept`,
                                      ],
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            t.jsx(ce, {
                              blob: e.blob,
                              fileName: e.name,
                              label: "Download",
                              hideMarkNoticeOnPhone: !0,
                              pinned:
                                l.length === 1
                                  ? {
                                      summary: `${e.rangeLabel} · ${c(e.pageCount, "page")} · ${Y(e.blob.size)}`,
                                    }
                                  : void 0,
                            }),
                          ],
                        },
                        `${e.name}-${a}`,
                      );
                    }),
                  ],
                }),
            ],
          })
        : t.jsx(pe, {
            gateAtDownload: !0,
            accept: ".pdf",
            onFiles: X,
            label: "Drop a PDF here, or click to browse",
            description: "Split into multiple files by page ranges",
          }),
    ],
  });
}
export { kt as default };
//# sourceMappingURL=SplitPdf-DvAnSZXv.js.map
