// FDP-93 Remove PDF Pages (Professional 10/day), guest. node px93-live.js <core|rot|blank|form|err|enc|capload|mobile>
// Never signs in, never types an email or card, never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const W = '/workspace/deep/93-remove-pdf-pages/'; const OUT = W + 'live/'; const TF = W + 'testfiles/'; const TOOL = 'https://www.freedailypro.com/tool/remove-pdf-pages';
const mode = process.argv[2] || 'core'; const sfx = process.env.SUF || '';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
fs.mkdirSync(OUT + 'dl', { recursive: true }); fs.mkdirSync(OUT + 'cases', { recursive: true });
(async () => { const b = await (process.env.WK ? pw.webkit : pw.chromium).launch(); const R = { t: now(), mode, tries: [], cases: {} }; let c, p, net = [], dls = [], cons = [];
 const open = async (opts = {}) => { c = await b.newContext({ viewport: { width: 1366, height: 1800 }, locale: 'en-US', timezoneId: 'America/New_York', acceptDownloads: true, ...opts }); p = await c.newPage(); p.setDefaultTimeout(20000); net = []; dls = [];
  p.on('request', r => { const u = r.url(); if (r.method() === 'POST' && /freedailypro\.com\/api/.test(u) && !/insight\.hit|funnel\.hit/.test(u)) net.push({ t: now(), u: u.slice(0, 70) }); });
  p.on('download', async d => { const n = d.suggestedFilename(); const path = OUT + 'dl/' + mode + sfx + '-' + dls.length + '-' + n; dls.push({ name: n, path }); await d.saveAs(path).catch(() => { }); });
  p.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') cons.push(m.text().slice(0, 200)); });
  await p.goto(TOOL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(200); } };
 const shot = (n, full = true) => p.screenshot({ path: OUT + 'cases/' + n + sfx + '.png', fullPage: full });
 const toasts = async () => (await p.locator('[data-sonner-toast]').allInnerTexts()).map(s => s.replace(/\s*\n\s*/g, ' '));
 const poll = async (ms = 3000) => { const s = new Set(); for (let i = 0; i < ms / 250; i++) { for (const t of await toasts()) s.add(t); await p.waitForTimeout(250); } return [...s]; };
 const find = async (opts) => { for (let i = 0; i < +(process.env.TRIES || 25); i++) { await open(opts); const u = await used(); R.tries.push(u); if (u.startsWith('0/')) return true; await c.close(); } return false; };
 const drop = async f => { await p.locator('input[type=file]').first().setInputFiles(TF + f); const ts = await poll(+(process.env.LOADMS || 5000)); return { loadToasts: ts, alerts: await alerts(), page: await pageLbl() }; };
 const alerts = async () => (await p.locator('main [role=alert]').allInnerTexts()).map(s => s.replace(/\s*\n\s*/g, ' ').slice(0, 300));
 const pageLbl = async () => { const t = await p.locator('main').innerText(); const m = t.match(/Page \d+ of \d+/); return m ? m[0] : null; };
 const readout = async () => { const r = p.locator('[data-testid=crop-size-readout]'); return (await r.count()) ? (await r.innerText()) : null; };
 const margins = async () => { const o = {}; for (const k of ['top', 'right', 'bottom', 'left']) o[k] = await p.getByLabel(k + ' margin', { exact: true }).inputValue(); return o; };
 const setM = async (t, r, bt, l, unit) => { if (unit) await p.getByLabel('Margin unit').selectOption(unit); const v = { top: t, right: r, bottom: bt, left: l }; for (const k of ['top', 'right', 'bottom', 'left']) { await p.getByLabel(k + ' margin', { exact: true }).fill(String(v[k])); await p.waitForTimeout(120); } await p.waitForTimeout(300); return { margins: await margins(), readout: await readout() }; };
 const scope = async (s, range) => { await p.locator('main button', { hasText: new RegExp('^\\s*' + s + '\\s*$') }).click(); await p.waitForTimeout(200); if (range !== undefined) { await p.locator('main input[placeholder^="e.g."]').fill(range); await p.waitForTimeout(200); } };
 const btn = (re) => p.locator('main button', { hasText: re });
 const apply = async () => { const bt = btn(/^\s*Remove pages\s*$/); if (!(await bt.count())) return { apply: 'no button' }; if (await bt.isDisabled()) return { apply: 'disabled' }; await bt.click(); const ts = await poll(+(process.env.APPLYMS || 3000)); return { toasts: ts, alerts: await alerts(), hasDownload: (await btn(/^\s*Download/).count()) > 0 }; };
 const download = async () => { const d0 = dls.length, np = net.length, u0 = await used(); const bt = btn(/^\s*Download/); if (!(await bt.count())) return { download: 'no button' }; const label = (await bt.first().innerText()).trim(); await bt.first().click(); await p.waitForTimeout(4000); const dg = await dialog(); if (dg) await esc(); return { label, usage: u0 + '->' + await used(), posts: net.length - np, dialog: dg, downloads: dls.slice(d0).map(d => ({ name: d.name, size: fs.existsSync(d.path) ? fs.statSync(d.path).size : null, saved: d.path.replace(W, '') })) }; };
 const newF = async () => { const n = btn(/^\s*(New|Reset)\s*$/).first(); if (await n.count()) { await n.click(); await p.waitForTimeout(800); } };
 const next = async () => { await btn(/^\s*Next\s*$/).click(); await p.waitForTimeout(1200); };
 const autotrim = async (pad) => { if (pad !== undefined) await p.locator('#crop-trim-pad').selectOption(String(pad)); const t0 = Date.now(); await btn(/Auto-trim|Detecting/).click(); for (let i = 0; i < 600; i++) { await p.waitForTimeout(250); if (!(await btn(/Detecting/).count())) break; } const ms = Date.now() - t0; return { ms, toasts: await poll(1500), margins: await margins(), readout: await readout() }; };
 const C = async (id_, fn) => { if (process.env.ONLY && !new RegExp(process.env.ONLY).test(id_)) return; const c0 = cons.length; try { R.cases[id_] = await fn(); } catch (e) { R.cases[id_] = { err: e.message.split('\n')[0].slice(0, 200) }; await shot(id_ + '-err').catch(() => { }); } R.cases[id_].console = cons.slice(c0).slice(0, 5); console.log(id_, JSON.stringify(R.cases[id_]).slice(0, 1500)); };
 const img = () => p.locator('main img.pointer-events-none').first();
 const at = async (fx, fy) => { const bb = await img().boundingBox(); return [bb.x + fx * bb.width, bb.y + fy * bb.height]; };
 const drag = async (fx1, fy1, fx2, fy2, steps = 10) => { const [x1, y1] = await at(fx1, fy1); const [x2, y2] = await at(fx2, fy2); await p.mouse.move(x1, y1); await p.mouse.down(); for (let i = 1; i <= steps; i++) await p.mouse.move(x1 + (x2 - x1) * i / steps, y1 + (y2 - y1) * i / steps); await p.mouse.up(); await p.waitForTimeout(400); };
 const dragEl = async (loc, dx, dy) => { const bb = await loc.boundingBox(); const x = bb.x + bb.width / 2, y = bb.y + bb.height / 2; await p.mouse.move(x, y); await p.mouse.down(); for (let i = 1; i <= 10; i++) await p.mouse.move(x + dx * i / 10, y + dy * i / 10); await p.mouse.up(); await p.waitForTimeout(400); };


 const typeR = async (v) => { await p.locator('#rm-pages').fill(v); await p.waitForTimeout(300); const msg = (await p.locator('#rm-pages-msg').innerText()).trim(); const m = await p.locator('main').innerText(); const cnt = (m.match(/\d+ pages? will be removed; \d+ stay\./) || [null])[0]; const pressed = await p.locator('main button[aria-pressed=true]').count(); const dis = await btn(/^\s*Remove pages\s*$/).first().isDisabled().catch(() => null); return { v, msg, cnt, pressed, removeDisabled: dis }; };
 const thumbs = () => p.locator('main button[aria-pressed]');
 const waitThumbs = async (n, ms = 120000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { if ((await thumbs().count()) >= n) break; await p.waitForTimeout(250); } return { count: await thumbs().count(), ms: Date.now() - t0 }; };
 const rmAlert = async () => (await p.locator('main p[role=alert]').allInnerTexts());
 const removeDl = async (v) => { const t = await typeR(v); const a = await apply(); const al = await rmAlert(); const d = a.hasDownload ? await download() : null; return { t, a, alerts: al, d }; };

 if (mode === 'extra') { await find(); R.start = await used();
  await C('S01-split-field-remove-3', async () => { await drop('split-field.pdf'); await waitThumbs(3); return await removeDl('3'); });
  await C('L01-toc-links-remove-7', async () => { await newF(); await newF(); await drop('toc-links.pdf'); await waitThumbs(12); return await removeDl('7'); });
  await C('B03-blanks2', async () => { await newF(); await newF(); await drop('blanks2.pdf'); await waitThumbs(5); await p.locator('[data-testid=select-blank]').click(); await p.waitForTimeout(4000); const sum = await p.locator('[data-testid=blank-summary]').innerText().catch(() => null); const caps = (await p.locator('main').innerText()).match(/(Blank \([^)]*\)|[\d.]+% ink|no ink)/g); await shot('B03-blanks2', false); return { sum, v: await p.locator('#rm-pages').inputValue(), caps }; });
  R.end = await used(); }

 if (mode === 'core') { await find(); R.start = await used();
  await C('A01-book-remove-5', async () => { const l = await drop('book.pdf'); const th = await waitThumbs(20); const r = await removeDl('5'); await shot('A01-done'); return { l, th, r }; });
  await C('A02-syntax', async () => { await newF(); await newF(); await drop('book.pdf'); await waitThumbs(20); const out = []; for (const v of ['2, 5-7', '5-7;9', '7-5', '18-', '18-99', '0', '21', 'abc', '1-', '3–4', ' 2 , 4 ', '2,2,2', '1-20', '20', 'x, 99', '-3', '1.5', '2 4']) out.push(await typeR(v)); return out; });
  await C('A03-remove-all', async () => { await typeR('1-20'); const a = await apply(); return { a, alerts: await rmAlert() }; });
  await C('A04-odd-even-click', async () => { await typeR(''); await btn(/^\s*Odd pages\s*$/).click(); const odd = await p.locator('#rm-pages').inputValue(); await btn(/^\s*Even pages\s*$/).click(); const even = await p.locator('#rm-pages').inputValue(); await btn(/^\s*Clear\s*$/).click(); await thumbs().nth(2).click(); await thumbs().nth(9).click(); const clicked = await p.locator('#rm-pages').inputValue(); const lab = await thumbs().nth(2).getAttribute('aria-label'); await thumbs().nth(2).click(); const unclick = await p.locator('#rm-pages').inputValue(); await shot('A04-thumbs', false); return { odd, even, clicked, lab, unclick }; });
  await C('A05-last-page', async () => { const r = await removeDl('20'); return r; });
  await C('A06-new-file-same-load', async () => { await newF(); await newF(); await drop('three.pdf'); await waitThumbs(3); const r = await removeDl('2'); return r; });
  await C('A07-multi', async () => { await newF(); await newF(); await drop('book.pdf'); await waitThumbs(20); const r = await removeDl('5-7, 20'); return r; });
  await C('A08-one-page-file', async () => { await newF(); await newF(); await drop('one.pdf'); await waitThumbs(1); const t = await typeR('1'); const a = await apply(); return { t, a, alerts: await rmAlert() }; });
  R.end = await used(); }

 if (mode === 'rot') { await find(); R.start = await used();
  await C('R01-rotated-inherit-remove-1', async () => { const l = await drop('rotated-inherit.pdf'); await waitThumbs(6); await shot('R01-thumbs', false); const r = await removeDl('1'); return { l, r }; });
  await C('F01-form-remove-1', async () => { await newF(); await newF(); await drop('form.pdf'); await waitThumbs(3); const r = await removeDl('1'); return r; });
  R.end = await used(); }

 if (mode === 'blank') { await find(); R.start = await used();
  await C('B01-blanks', async () => { await drop('blanks.pdf'); await waitThumbs(6); await p.locator('[data-testid=select-blank]').click(); await p.waitForTimeout(4000); const sum = await p.locator('[data-testid=blank-summary]').innerText().catch(() => null); const v1 = await p.locator('#rm-pages').inputValue(); const caps = (await p.locator('main').innerText()).match(/(Blank \([^)]*\)|[\d.]+% ink|no ink)/g); await shot('B01-blank', false); await p.locator('#rm-ink').fill('0.5'); await p.waitForTimeout(500); const v2 = await p.locator('#rm-pages').inputValue(); const sum2 = await p.locator('[data-testid=blank-summary]').innerText().catch(() => null); await p.locator('#rm-ink').fill('0'); await p.waitForTimeout(500); const v0 = await p.locator('#rm-pages').inputValue(); await p.locator('#rm-ink').fill('0.005'); await p.waitForTimeout(500); const r = await removeDl(await p.locator('#rm-pages').inputValue()); return { sum, v1, caps, v2, sum2, v0, r }; });
  await C('B02-blank-scan', async () => { await newF(); await newF(); await drop('book.pdf'); await waitThumbs(20); await p.locator('[data-testid=select-blank]').click(); for (let i = 0; i < 120; i++) { await p.waitForTimeout(500); if (!(await p.getByText(/Checking page/).count())) break; } return { sum: await p.locator('[data-testid=blank-summary]').innerText().catch(() => null), v: await p.locator('#rm-pages').inputValue() }; });
  R.end = await used(); }

 if (mode === 'err') { await find(); R.start = await used();
  await C('E01-enc', async () => { await p.locator('input[type=file]').first().setInputFiles(TF + 'enc.pdf'); await p.waitForTimeout(4000); const dg = await dialog(); await shot('E01-enc', false); const al = await alerts(); return { dg, al, toasts: await toasts() }; });
  await C('E02-corrupt', async () => { await p.reload(); await p.waitForTimeout(4000); const l = await drop('corrupt.pdf'); await shot('E02-corrupt', false); return { l, rm: await rmAlert() }; });
  await C('E03-large-300p', async () => { await p.reload(); await p.waitForTimeout(4000); const t0 = Date.now(); await p.locator('input[type=file]').first().setInputFiles(TF + 'large-300p.pdf'); const th = await waitThumbs(300, 180000); const firstThumbMs = th.ms; const t = await typeR('2-299'); const t1 = Date.now(); const a = await apply(); const applyMs = Date.now() - t1; const d = a.hasDownload ? await download() : null; return { th, t, a, applyMs, d, totalMs: Date.now() - t0 }; });
  await C('E04-heavy-73MB', async () => { await newF(); await newF(); const t0 = Date.now(); const l = await drop('heavy.pdf'); const th = await waitThumbs(30, 180000); const t = await typeR('1-10'); const a = await apply(); const d = a.hasDownload ? await download() : null; return { l, th, t, a, d, ms: Date.now() - t0 }; });
  await C('E05-not-pdf', async () => { await p.reload(); await p.waitForTimeout(4000); await p.locator('input[type=file]').first().setInputFiles(W + 'make93.py'); return { toasts: await poll(3000), alerts: await alerts() }; });
  R.end = await used(); }

 if (mode === 'capload') { await find(); R.start = await used(); R.rows = [];
  for (const f of ['three.pdf', 'book.pdf', 'three.pdf']) { await newF(); await newF(); await drop(f); await waitThumbs(3); const r = await removeDl('2'); R.rows.push({ f, d: r.d }); console.log(f, JSON.stringify(r.d).slice(0, 400)); await p.waitForTimeout(3000); }
  await p.reload(); await p.waitForTimeout(5000); R.afterReload = await used(); await drop('three.pdf'); await waitThumbs(3); R.reloadDl = (await removeDl('2')).d; console.log('reload', JSON.stringify(R.reloadDl).slice(0, 500));
  R.end = await used(); }

 if (mode === 'mobile') { const dev = pw.devices[process.env.DEV || 'iPhone 13']; await find({ ...dev, viewport: dev.viewport }); R.start = await used();
  await C('M01', async () => { await drop(process.env.MF || 'book.pdf'); await waitThumbs(process.env.MF ? 3 : 20); const sw = await p.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth]); const ti = process.env.MF ? 1 : 4; const bb = await thumbs().nth(ti).boundingBox(); await thumbs().nth(ti).tap(); const v = await p.locator('#rm-pages').inputValue(); const odd = await btn(/^\s*Odd pages\s*$/).boundingBox(); await shot('M01-' + (process.env.DEV || 'iPhone 13').replace(/\s/g, '-')); const a = await apply(); const d = a.hasDownload ? await download() : null; return { sw, thumbBox: bb, afterTap: v, oddBtn: odd, a, d }; });
  R.end = await used(); }

 fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); await b.close(); })();
