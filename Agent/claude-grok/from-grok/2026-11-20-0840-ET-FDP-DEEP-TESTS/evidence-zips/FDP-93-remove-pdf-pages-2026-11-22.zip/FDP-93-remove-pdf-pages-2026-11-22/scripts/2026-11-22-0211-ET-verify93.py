# FDP-93: is a removed page really gone? python3 verify93.py <orig> <out> <outdir> <tag>
import sys, json, os, re, hashlib, zlib, pikepdf, fitz
from pikepdf import Name
orig, out, od, tag = sys.argv[1:5]; os.makedirs(od, exist_ok=True)
def imghashes(q):
    m = {}
    for i, pg in enumerate(q.pages):
        for k, x in (pg.obj.get('/Resources', {}).get('/XObject', {}) or {}).items():
            try: m[hashlib.md5(x.read_raw_bytes()).hexdigest()] = i + 1
            except Exception: pass
    return m
qo, qn = pikepdf.open(orig), pikepdf.open(out)
ho = imghashes(qo)
R = {'tag': tag, 'size_orig': os.path.getsize(orig), 'size_out': os.path.getsize(out), 'pages_orig': len(qo.pages), 'pages_out': len(qn.pages)}
# reachability
seen = set()
def walk(o):
    stack = [o]
    while stack:
        x = stack.pop()
        if isinstance(x, pikepdf.Object) and x.is_indirect:
            k = x.objgen
            if k in seen: continue
            seen.add(k)
        if isinstance(x, (pikepdf.Dictionary, pikepdf.Stream)):
            for kk, v in x.items(): stack.append(v)
        elif isinstance(x, pikepdf.Array):
            for v in x: stack.append(v)
walk(qn.trailer)
allobj = [o for o in qn.objects if o is not None and not (isinstance(o, pikepdf.Object) and o._type_code == pikepdf.ObjectType.null)]
R['objects_total'] = len(qn.objects); R['objects_reachable'] = len(seen)
unreach = [o for o in qn.objects if isinstance(o, pikepdf.Object) and o.is_indirect and o.objgen not in seen and o._type_code != pikepdf.ObjectType.null]
R['objects_unreachable'] = len(unreach)
R['unreachable_types'] = {}
for o in unreach:
    t = str(o.get('/Type', o.get('/Subtype', type(o).__name__))) if isinstance(o, (pikepdf.Dictionary, pikepdf.Stream)) else o._type_code.name
    R['unreachable_types'][t] = R['unreachable_types'].get(t, 0) + 1
# raw search of every stream/string for secrets, plus image streams from original pages
blob = b''
for o in qn.objects:
    if isinstance(o, pikepdf.Stream):
        try: blob += o.read_bytes() + b'\n'
        except Exception: blob += o.read_raw_bytes()
raw = open(out, 'rb').read()
def found(s):
    b = s.encode(); return (b in blob) or (b in raw)
# MuPDF/pikepdf text in pages
fn = fitz.open(out)
pagetext = '\n'.join(p.get_text() for p in fn)
R['secrets_in_page_text'] = sorted(int(m) for m in re.findall(r'PAGE-(\d+)-SECRET', pagetext))
# content stream secrets: base14 text draws "PAGE-n-SECRET" as hex/literal; search decoded streams via pymupdf per xref
xs = []
for x in range(1, fn.xref_length()):
    try:
        if fn.xref_is_stream(x):
            s = fn.xref_stream(x)
            if s: xs.append(s)
    except Exception: pass
sb = b'\n'.join(xs)
R['secrets_anywhere_in_file'] = sorted(n for n in range(1, 301) if (f'PAGE-{n}-SECRET'.encode() in sb) or (f'PAGE-{n}-SECRET'.encode().hex().encode() in sb.lower()) or (f'PAGE-{n}-SECRET'.encode().hex().upper().encode() in sb))
R['attachment_secret_in_file'] = b'ATTACHMENT-SECRET' in sb or b'ATTACHMENT-SECRET' in raw
R['gone_ssn_value_in_file'] = b'gone_ssn' in raw or b'gone_ssn' in sb
hn = {}
for o in qn.objects:
    if isinstance(o, pikepdf.Stream) and o.get('/Subtype') == Name.Image:
        h = hashlib.md5(o.read_raw_bytes()).hexdigest()
        if h in ho: hn[ho[h]] = hn.get(ho[h], 0) + 1
R['images_from_orig_pages_in_file'] = sorted(hn)
# per page
pg_index = {pg.objgen: i + 1 for i, pg in enumerate(qn.pages)}
R['pages'] = []
for i, pg in enumerate(qn.pages):
    o = pg.obj
    links = []
    for a in o.get('/Annots', []) or []:
        st = str(a.get('/Subtype'))
        info = {'subtype': st}
        d = a.get('/Dest') or (a.get('/A', {}).get('/D') if a.get('/A') is not None else None)
        if a.get('/A') is not None and a.A.get('/URI') is not None: info['uri'] = str(a.A.URI)
        if d is not None:
            if isinstance(d, pikepdf.Array) and len(d) and isinstance(d[0], pikepdf.Dictionary):
                info['dest_page'] = pg_index.get(d[0].objgen, 'NOT-A-PAGE-IN-THIS-FILE')
            else: info['dest'] = str(d)[:40]
        if st == '/Widget': info['field'] = str(a.get('/T', a.get('/Parent', {}).get('/T', '')))
        links.append(info)
    R['pages'].append({'page': i + 1, 'rotate_inherited': int(pg.Rotate) if hasattr(pg, 'Rotate') else None, 'rotate_mupdf': fn[i].rotation, 'mediabox': [float(x) for x in fn[i].mediabox], 'text': fn[i].get_text()[:60].replace('\n', ' | '), 'annots': links})
# outline
def outline(q):
    res = []
    idx = {pg.objgen: i + 1 for i, pg in enumerate(q.pages)}
    try:
        with q.open_outline() as ol:
            def rec(items, lvl):
                for it in items:
                    p = None
                    try:
                        dd = it.destination
                        if dd is None and it.action is not None: dd = it.action.get('/D')
                        if dd is None: p = None
                        elif isinstance(dd, pikepdf.Array): p = idx.get(dd[0].objgen, 'dangling') if len(dd) else None
                        else: p = 'named:' + str(dd)
                    except Exception as e: p = 'err'
                    res.append(('  ' * lvl) + f'{it.title} -> {p}')
                    rec(it.children, lvl + 1)
            rec(ol.root, 0)
    except Exception as e: res.append('outline error ' + str(e)[:80])
    return res
R['outline_orig'] = outline(qo); R['outline_out'] = outline(qn)
af = qn.Root.get('/AcroForm')
R['acroform'] = None if af is None else {'fields': [str(f.get('/T')) for f in af.get('/Fields', [])], 'has_DR': '/DR' in af, 'NeedAppearances': bool(af.get('/NeedAppearances', False)), 'XFA': '/XFA' in af}
afo = qo.Root.get('/AcroForm'); R['acroform_orig'] = None if afo is None else {'fields': [str(f.get('/T')) for f in afo.get('/Fields', [])], 'has_DR': '/DR' in afo}
R['catalog_keys_orig'] = sorted(str(k) for k in qo.Root.keys()); R['catalog_keys_out'] = sorted(str(k) for k in qn.Root.keys())
R['docinfo_out'] = {str(k): str(v) for k, v in qn.docinfo.items()}
R['docinfo_orig'] = {str(k): str(v) for k, v in qo.docinfo.items()}
json.dump(R, open(f'{od}/{tag}.json', 'w'), indent=1, ensure_ascii=False)
s = {k: R[k] for k in ['size_orig', 'size_out', 'pages_orig', 'pages_out', 'objects_total', 'objects_reachable', 'objects_unreachable', 'unreachable_types', 'secrets_in_page_text', 'secrets_anywhere_in_file', 'images_from_orig_pages_in_file', 'attachment_secret_in_file', 'gone_ssn_value_in_file', 'acroform', 'catalog_keys_out']}
print(tag, json.dumps(s))
print(tag, 'outline_out', R['outline_out'])
for p in R['pages']:
    if p['annots'] or p['rotate_mupdf']: print(tag, 'p', p['page'], p['text'][:30], 'rot', p['rotate_mupdf'], p['annots'])
