import { r as x, j as s } from "./vendor-react-D01g8YgM.js";
import {
  E as _,
  aw as O,
  L as X,
  aq as G,
  X as K,
  B as l,
  D as I,
  f as z,
} from "./index-DagluEtV.js";
import { J as Q } from "./jszip.min-CT0ZA6V1.js";
import { m as V, F as Y, d as R, s as ee } from "./ToolPage-B4roIUf_.js";
import { u as A } from "./UsageAndUpgradeStrip-BiAdGTIF.js";
import { f as g } from "./formatFileSize-B-JRDfN5.js";
import {
  b as B,
  a as se,
  T as S,
  c as ae,
  r as te,
  u as ne,
} from "./batch-Bbh00IAr.js";
import { T as le } from "./trash-2-DpHY4NWT.js";
import { S as oe } from "./square-ClncwSrJ.js";
let re = 1;
function ge({
  accept: d,
  noun: f,
  process: b,
  check: h,
  zipName: w,
  runLabel: j = "Process all",
  children: N,
  maxSizeMb: L = 50,
  includeOriginals: $ = !1,
  disableOnCheck: D = !1,
}) {
  const { isPro: P, isAdmin: Z, isLoading: q } = A(),
    c = B({ isPro: P, isAdmin: Z, isLoading: q }),
    [a, p] = x.useState([]),
    [u, y] = x.useState(!1),
    k = x.useRef(!1),
    v = x.useRef(null),
    C = _(),
    [, F] = O(),
    E = (e) => {
      const { files: n, dropped: r } = ae(
        a.map((i) => i.file),
        e,
        c,
      );
      (p(
        n.map(
          (i) =>
            a.find((t) => t.file === i) ?? {
              id: re++,
              file: i,
              status: "queued",
            },
        ),
      ),
        r > 0 &&
          z.info(`${r} file${r === 1 ? "" : "s"} left out`, {
            description:
              c <= S
                ? `A batch takes up to ${c} files on the trial. A paid plan removes that limit.`
                : `A batch takes up to ${c} files.`,
          }));
    },
    H = async () => {
      const e = h?.();
      if (e) {
        z.error(e);
        return;
      }
      if (a.length === 0) return;
      k.current = !1;
      const n = new AbortController();
      ((v.current = n), y(!0));
      try {
        await te(a, b, p, () => k.current, n.signal);
      } finally {
        ((v.current = null), y(!1));
      }
    },
    o = se(a),
    T =
      a.length > 0 &&
      !u &&
      a.every((e) => e.status !== "queued" && e.status !== "working"),
    m = a.filter((e) => e.status === "done" && e.result),
    U = async () => {
      const e = new Q(),
        n = $ ? a.filter((t) => t.status !== "done" || !t.result) : [],
        r = [
          ...m.map((t) => ({ name: t.result.fileName, blob: t.result.blob })),
          ...n.map((t) => ({ name: t.file.name, blob: t.file })),
        ],
        i = ne(r.map((t) => t.name));
      (r.forEach((t, W) => e.file(i[W], t.blob)),
        R(await e.generateAsync({ type: "blob" }), w));
    },
    J = m.length > 1 && C.id ? V(m.map((e) => e.result.fileName)) : [],
    M = (e) => {
      const [n, ...r] = m.map((i) => i.result);
      (ee({
        blob: n.blob,
        fileName: n.fileName,
        more: r,
        fromToolId: C.id,
        toToolId: e,
      }),
        F(`/tool/${e}`));
    };
  return s.jsxs("div", {
    className: "space-y-4",
    "data-testid": "batch-runner",
    children: [
      N,
      !u &&
        a.length < c &&
        s.jsx(Y, {
          accept: d,
          multiple: !0,
          deferUsageLog: !0,
          maxSize: L,
          onFiles: E,
          label: `Drop several ${f} files`,
          description: `Up to ${c} files in one batch${c <= S ? " on the trial" : ""}. The whole batch counts as one use, taken when you download.`,
        }),
      a.length > 0 &&
        s.jsx("ul", {
          className: "space-y-2",
          "data-testid": "batch-list",
          children: a.map((e) =>
            s.jsxs(
              "li",
              {
                className:
                  "flex items-center gap-3 p-3 rounded-lg border bg-card text-sm",
                children: [
                  s.jsx("span", {
                    className: "w-5 shrink-0",
                    "aria-hidden": !0,
                    children:
                      e.status === "working"
                        ? s.jsx(X, { className: "h-4 w-4 animate-spin" })
                        : e.status === "done"
                          ? s.jsx(G, { className: "h-4 w-4 text-green-600" })
                          : e.status === "failed"
                            ? s.jsx(K, {
                                className: "h-4 w-4 text-destructive",
                              })
                            : null,
                  }),
                  s.jsxs("span", {
                    className: "flex-1 min-w-0 truncate",
                    children: [
                      e.file.name,
                      " ",
                      s.jsxs("span", {
                        className: "text-muted-foreground",
                        children: ["(", g(e.file.size), ")"],
                      }),
                    ],
                  }),
                  s.jsx("span", {
                    className: "text-xs text-muted-foreground shrink-0",
                    "data-testid": "batch-status",
                    children:
                      e.status === "done" && e.result
                        ? `${g(e.result.blob.size)}`
                        : e.status === "failed"
                          ? e.error
                          : e.status === "skipped"
                            ? "Stopped, not processed"
                            : e.status === "working"
                              ? "Working..."
                              : "Waiting",
                  }),
                  e.status === "done" &&
                    e.result &&
                    s.jsx(l, {
                      size: "sm",
                      variant: "ghost",
                      onClick: () => R(e.result.blob, e.result.fileName),
                      "aria-label": `Download ${e.result.fileName}`,
                      children: s.jsx(I, { className: "h-4 w-4" }),
                    }),
                  !u &&
                    e.status !== "done" &&
                    s.jsx(l, {
                      size: "sm",
                      variant: "ghost",
                      "aria-label": `Remove ${e.file.name}`,
                      onClick: () => p(a.filter((n) => n.id !== e.id)),
                      children: s.jsx(le, { className: "h-4 w-4" }),
                    }),
                ],
              },
              e.id,
            ),
          ),
        }),
      s.jsxs("div", {
        className: "flex flex-wrap gap-2",
        children: [
          u
            ? s.jsxs(l, {
                variant: "outline",
                onClick: () => {
                  ((k.current = !0), v.current?.abort());
                },
                className: "gap-2",
                "data-testid": "batch-stop",
                children: [
                  s.jsx(oe, { className: "h-3.5 w-3.5" }),
                  " Stop now",
                ],
              })
            : s.jsx(l, {
                onClick: H,
                disabled: a.length === 0 || (D && !!h?.()),
                "data-testid": "batch-run",
                children: T ? "Run again" : `${j} (${a.length})`,
              }),
          (m.length > 1 || ($ && m.length > 0 && a.length > 1)) &&
            s.jsxs(l, {
              variant: "secondary",
              onClick: U,
              className: "gap-2",
              "data-testid": "batch-zip",
              children: [
                s.jsx(I, { className: "h-4 w-4" }),
                " ",
                u ? "Download finished so far (ZIP)" : "Download all (ZIP)",
              ],
            }),
          !u &&
            J.map((e) =>
              s.jsxs(
                l,
                {
                  variant: "outline",
                  onClick: () => M(e.toolId),
                  "data-testid": `batch-continue-${e.toolId}`,
                  children: ["Continue with ", e.name],
                },
                e.toolId,
              ),
            ),
          a.length > 0 &&
            !u &&
            s.jsx(l, {
              variant: "ghost",
              onClick: () => p([]),
              children: "Clear",
            }),
        ],
      }),
      T &&
        s.jsxs("p", {
          className: "text-sm text-muted-foreground",
          "aria-live": "polite",
          "data-testid": "batch-summary",
          children: [
            o.done,
            " of ",
            a.length,
            " done",
            o.failed > 0 ? `, ${o.failed} failed` : "",
            ".",
            o.done > 0 && o.before !== o.after
              ? ` ${g(o.before)} to ${g(o.after)} in total.`
              : "",
          ],
        }),
    ],
  });
}
function be({ batch: d, onChange: f, limitText: b }) {
  const { isPro: h, isAdmin: w, isLoading: j } = A(),
    N = B({ isPro: h, isAdmin: w, isLoading: j });
  return s.jsxs("div", {
    className: "flex flex-wrap items-center gap-2 mb-4",
    role: "group",
    "aria-label": "How many files",
    children: [
      s.jsx(l, {
        size: "sm",
        variant: d ? "outline" : "default",
        onClick: () => f(!1),
        "aria-pressed": !d,
        children: "One file",
      }),
      s.jsx(l, {
        size: "sm",
        variant: d ? "default" : "outline",
        onClick: () => f(!0),
        "aria-pressed": d,
        "data-testid": "batch-toggle",
        children: "Several files",
      }),
      d &&
        s.jsx("span", {
          className: "text-xs text-muted-foreground",
          children:
            b ??
            `Up to ${N} files, same settings for each, counts as one use when you download.`,
        }),
    ],
  });
}
export { be as B, ge as a };
//# sourceMappingURL=BatchRunner-Ci6bVLGm.js.map
