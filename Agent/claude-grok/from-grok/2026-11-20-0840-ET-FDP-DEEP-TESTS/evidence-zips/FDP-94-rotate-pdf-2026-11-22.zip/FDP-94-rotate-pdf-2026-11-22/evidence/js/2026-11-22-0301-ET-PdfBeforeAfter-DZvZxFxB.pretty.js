import { j as e, r as x } from "./vendor-react-D01g8YgM.js";
import {
  e as b,
  I as w,
  ar as N,
  as as v,
  at as P,
  au as y,
  av as L,
  L as p,
} from "./index-DagluEtV.js";
import { l as C, r as D } from "./utils-s8ucLyj8.js";
import { f as R } from "./formatFileSize-B-JRDfN5.js";
async function k(s, a, t) {
  const l = await C(new File([s], "preview.pdf", { type: "application/pdf" })),
    n = Math.min(Math.max(1, a), l.numPages),
    o = await l.getPage(n),
    r = await D(o, t, 0.9);
  return { url: URL.createObjectURL(r), pages: l.numPages };
}
function g(s, a, t) {
  const [l, n] = x.useState({ url: null, pages: 0, failed: !1 });
  return (
    x.useEffect(() => {
      let o = !0,
        r = null;
      return (
        n((i) => ({ ...i, url: null, failed: !1 })),
        k(s, a, t)
          .then((i) => {
            if (!o) return URL.revokeObjectURL(i.url);
            ((r = i.url), n({ url: i.url, pages: i.pages, failed: !1 }));
          })
          .catch(() => o && n({ url: null, pages: 0, failed: !0 })),
        () => {
          ((o = !1), r && URL.revokeObjectURL(r));
        }
      );
    }, [s, a, t]),
    l
  );
}
function h({ title: s, blob: a, page: t, onOpen: l }) {
  const { url: n, failed: o } = g(a, t, 0.9);
  return e.jsxs("div", {
    className: "space-y-1.5 min-w-0",
    children: [
      e.jsxs("p", {
        className: "text-xs font-medium",
        children: [
          s,
          " ",
          e.jsxs("span", {
            className: "text-muted-foreground font-normal",
            children: ["· ", R(a.size)],
          }),
        ],
      }),
      e.jsx("button", {
        type: "button",
        onClick: () => l(s, a),
        className: "block w-full rounded-lg border bg-muted/40 p-2 text-left",
        "aria-label": `Enlarge ${s.toLowerCase()} page ${t}`,
        title: "Click to enlarge",
        children: n
          ? e.jsx("img", {
              src: n,
              alt: `${s}, page ${t}`,
              className: "mx-auto max-h-72 w-auto bg-white shadow-sm",
            })
          : o
            ? e.jsx("p", {
                className: "py-10 text-center text-xs text-muted-foreground",
                children: "Couldn't draw this page.",
              })
            : e.jsx("div", {
                className: "flex h-40 items-center justify-center",
                children: e.jsx(p, {
                  className: "h-5 w-5 animate-spin text-muted-foreground",
                }),
              }),
      }),
    ],
  });
}
function M({
  original: s,
  result: a,
  pageCountHint: t,
  initialPage: l = 1,
  leftTitle: n = "Original",
  rightTitle: o = "Result",
}) {
  const [r, i] = x.useState(l),
    [m, f] = x.useState(null),
    { pages: j } = g(a, r, 0.2),
    u = t ?? j;
  return e.jsxs("div", {
    className: "space-y-3 rounded-xl border bg-card p-3",
    "aria-label": "Before and after",
    children: [
      e.jsxs("div", {
        className: "flex items-center gap-2",
        children: [
          e.jsx(b, {
            htmlFor: "ba-page",
            className: "text-xs font-normal",
            children: "Compare page",
          }),
          e.jsx(w, {
            id: "ba-page",
            "aria-label": "Page to compare",
            type: "number",
            min: 1,
            max: u || void 0,
            value: r,
            onChange: (c) => {
              const d = Math.floor(Number(c.target.value));
              d >= 1 && i(u ? Math.min(d, u) : d);
            },
            className: "h-8 w-20 text-sm",
          }),
          u > 0 &&
            e.jsxs("span", {
              className: "text-xs text-muted-foreground",
              children: ["of ", u],
            }),
        ],
      }),
      e.jsxs("div", {
        className: "grid gap-3 sm:grid-cols-2",
        children: [
          e.jsx(h, {
            title: n,
            blob: s,
            page: r,
            onOpen: (c, d) => f({ title: c, blob: d }),
          }),
          e.jsx(h, {
            title: o,
            blob: a,
            page: r,
            onOpen: (c, d) => f({ title: c, blob: d }),
          }),
        ],
      }),
      e.jsx(N, {
        open: !!m,
        onOpenChange: (c) => !c && f(null),
        children: e.jsxs(v, {
          className: "max-w-4xl max-h-[92vh] overflow-auto",
          children: [
            e.jsxs(P, {
              children: [
                e.jsxs(y, { children: [m?.title, ", page ", r] }),
                e.jsx(L, {
                  children: "Drawn larger so you can check the detail.",
                }),
              ],
            }),
            m && e.jsx(O, { blob: m.blob, page: r }),
          ],
        }),
      }),
    ],
  });
}
function O({ blob: s, page: a }) {
  const { url: t } = g(s, a, 2);
  return t
    ? e.jsx("img", {
        src: t,
        alt: `Page ${a}, enlarged`,
        className: "mx-auto h-auto max-w-full bg-white shadow",
      })
    : e.jsx("div", {
        className: "flex h-60 items-center justify-center",
        children: e.jsx(p, { className: "h-6 w-6 animate-spin" }),
      });
}
function B({ file: s, page: a = 1, className: t = "w-12" }) {
  const { url: l } = g(s, a, 0.3);
  return l
    ? e.jsx("div", {
        className: `${t} shrink-0 overflow-hidden rounded border bg-white`,
        children: e.jsx("img", {
          src: l,
          alt: `Page ${a}`,
          className: "h-auto w-full",
        }),
      })
    : null;
}
export { B as P, M as a };
//# sourceMappingURL=PdfBeforeAfter-DZvZxFxB.js.map
