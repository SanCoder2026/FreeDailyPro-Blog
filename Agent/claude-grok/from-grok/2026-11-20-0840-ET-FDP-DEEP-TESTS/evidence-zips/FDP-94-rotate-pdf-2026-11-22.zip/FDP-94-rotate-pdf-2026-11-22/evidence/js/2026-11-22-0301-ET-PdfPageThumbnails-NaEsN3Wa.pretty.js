import { r as u, j as t } from "./vendor-react-D01g8YgM.js";
import { l as b, r as f } from "./utils-s8ucLyj8.js";
import { L as x, X as h, aq as N } from "./index-DagluEtV.js";
function L(s) {
  const [n, o] = u.useState([]),
    [c, i] = u.useState(!1);
  return (
    u.useEffect(() => {
      if (!s) {
        o([]);
        return;
      }
      let r = !1;
      const e = [];
      return (
        (async () => {
          i(!0);
          try {
            const a = await b(s),
              d = [];
            for (let l = 1; l <= a.numPages; l++) {
              if (r) return;
              const g = await a.getPage(l),
                p = await f(g, 0.4, 0.7),
                m = URL.createObjectURL(p);
              (e.push(m), d.push({ pageNumber: l, url: m }));
            }
            r || o(d);
          } finally {
            r || i(!1);
          }
        })(),
        () => {
          ((r = !0), e.forEach((a) => URL.revokeObjectURL(a)));
        }
      );
    }, [s]),
    { thumbnails: n, loading: c }
  );
}
function v() {
  return t.jsxs("div", {
    className: "flex items-center gap-2 text-sm text-muted-foreground p-4",
    children: [
      t.jsx(x, { className: "h-4 w-4 animate-spin" }),
      " Loading page previews...",
    ],
  });
}
function j(s, n, o) {
  return n
    ? `Page ${s}, ${o ? "marked for removal" : "selected"}`
    : `Page ${s}`;
}
function $({
  thumbnails: s,
  selected: n,
  onToggle: o,
  mode: c = "keep",
  captions: i,
}) {
  const r = c === "remove";
  return t.jsx("div", {
    className: "grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3",
    children: s.map((e) => {
      const a = n.has(e.pageNumber);
      return t.jsxs(
        "button",
        {
          type: "button",
          "aria-pressed": a,
          "aria-label": j(e.pageNumber, a, r),
          onClick: () => o(e.pageNumber),
          className: `relative rounded-lg border-2 overflow-hidden transition-colors ${a ? (r ? "border-red-500" : "border-primary") : "border-border"}`,
          children: [
            t.jsx("img", {
              src: e.url,
              alt: `Page ${e.pageNumber}`,
              className: `w-full aspect-[3/4] object-contain bg-white ${a && r ? "opacity-40" : ""}`,
            }),
            t.jsx("span", {
              className:
                "absolute top-1 left-1 text-xs px-1.5 py-0.5 rounded bg-background/90 border",
              children: e.pageNumber,
            }),
            i?.[e.pageNumber] &&
              t.jsx("span", {
                className:
                  "absolute bottom-1 left-1 right-1 text-[10px] leading-tight px-1 py-0.5 rounded bg-background/90 border text-center",
                "data-testid": `caption-${e.pageNumber}`,
                children: i[e.pageNumber],
              }),
            a &&
              t.jsx("span", {
                className: `absolute top-1 right-1 h-5 w-5 rounded-full flex items-center justify-center ${r ? "bg-red-500 text-white" : "bg-primary text-primary-foreground"}`,
                children: r
                  ? t.jsx(h, { className: "h-3 w-3" })
                  : t.jsx(N, { className: "h-3 w-3" }),
              }),
          ],
        },
        e.pageNumber,
      );
    }),
  });
}
export { v as P, $ as a, L as u };
//# sourceMappingURL=PdfPageThumbnails-NaEsN3Wa.js.map
