import { r as m, j as e } from "./vendor-react-D01g8YgM.js";
import { g as G, A as J } from "./operations-BlL6iX51.js";
import {
  F as ie,
  a5 as le,
  f as ce,
  P as de,
  D as pe,
  a6 as me,
} from "./ToolPage-B4roIUf_.js";
import { T as ue } from "./ToolWithSidebar-DStt-BwB.js";
import { a as ge } from "./PdfBeforeAfter-DZvZxFxB.js";
import {
  B as g,
  aJ as V,
  dd as he,
  I as fe,
  f as A,
} from "./index-DagluEtV.js";
import { C as W } from "./card-DmKwvL-C.js";
import { u as xe, P as we } from "./PdfPageThumbnails-NaEsN3Wa.js";
import { p as K, l as Ne } from "./utils-s8ucLyj8.js";
import { B as je, a as be } from "./BatchRunner-Ci6bVLGm.js";
import { a as Q } from "./pdfMetadata-CcxIhQF2.js";
import { u as ye } from "./useRunToken-sJpsnYiZ.js";
import { p as D } from "./plural-FIChqbp4.js";
import { f as ke } from "./formatFileSize-B-JRDfN5.js";
import { T as ve } from "./ToolSteps-DiGCpXJU.js";
import { u as Pe } from "./useDownloadedResult-C1FfMpBH.js";
import { R as Z } from "./rotate-cw-DOa8zBeX.js";
import { I as Ce } from "./info-56I4OKVq.js";
import "./pdfFonts-CIqHAJiw.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./pageView-BQIwVYOi.js";
import "./formAppearance-TraefmEd.js";
import "./drawTextAnywhere-Dl7l_xfJ.js";
import "./ocrText-C_9cxcFa.js";
import "./ocrImage-DAAOwTV-.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./imageRecompress-eXQFDUm-.js";
import "./textDiff-DxE9AzvO.js";
import "./utils-BvcV7ep8.js";
import "./decode-CE2kW_I3.js";
import "./formFill-xgtRnF-K.js";
import "./redactSearch-DQpyyh_t.js";
import "./nameDetect-DvHCRM0m.js";
import "./useUploadApi-Cwp1vwlT.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-CL8JsD0s.js";
import "./share-2-B34wyobX.js";
import "./copy-CQptMDp5.js";
import "./workflowCta-oWYKzOWD.js";
import "./UsageAndUpgradeStrip-BiAdGTIF.js";
import "./access-BSSUf40u.js";
import "./useAdminAccess-CYp3AlSq.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CgocG3qD.js";
import "./map-pin-DvVDRebE.js";
import "./FaqSection-DsOLPaJ0.js";
import "./ToolVideoEmbed-CZwBIyFf.js";
import "./GuideLinks-BVE0aHrc.js";
import "./blog-BPnsEI_q.js";
import "./productCards-CUOqxId0.js";
import "./layers-BVDCe9zx.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-DmEVOuX4.js";
import "./chevron-up-B0wsCoBg.js";
import "./batch-Bbh00IAr.js";
import "./trash-2-DpHY4NWT.js";
import "./square-ClncwSrJ.js";
const Re = 25,
  Fe = 0.75,
  Te = 15;
function Se(s, n) {
  const c = { 0: 0, 90: 0, 180: 0, 270: 0 };
  for (const i of s) {
    if (typeof i.str != "string" || !Array.isArray(i.transform)) continue;
    const l = (i.str.match(/[^\s!-\/:-@[-`{-~]/g) ?? []).length;
    if (l === 0) continue;
    const a = i.transform,
      u = n[0] * a[0] + n[2] * a[1],
      p = n[1] * a[0] + n[3] * a[1];
    if (!u && !p) continue;
    const w = (Math.atan2(p, u) * 180) / Math.PI,
      N = Math.round(w / 90) * 90;
    Math.abs(w - N) > Te || (c[((N % 360) + 360) % 360] += l);
  }
  return c;
}
function Ae(s, n) {
  const c = n[0] + n[90] + n[180] + n[270];
  if (c < Re) return null;
  let i = 0;
  for (const u of [90, 180, 270]) n[u] > n[i] && (i = u);
  if (i === 0) return null;
  const l = n[i] / c;
  return l < Fe
    ? null
    : {
        page: s,
        turn: i === 90 ? -90 : i === 270 ? 90 : 180,
        chars: c,
        share: l,
      };
}
async function De(s, n = () => !0) {
  const c = [];
  for (let i = 1; i <= s.numPages; i++) {
    if (!n()) return c;
    try {
      const l = await s.getPage(i),
        a = l.getViewport({ scale: 1 }).transform,
        u = await l.getTextContent(),
        p = Ae(i, Se(u.items, a));
      (p && c.push(p), l.cleanup?.());
    } catch {}
  }
  return c;
}
function Ee(s, n, c) {
  const i = {};
  for (let l = 1; l <= s; l++)
    (c === "odd" && l % 2 === 0) || (c === "even" && l % 2 === 1) || (i[l] = n);
  return i;
}
const E = (s) => `${s < 0 ? "-" : "+"}${Math.abs(s)}°`,
  q = {
    what: `Fixes pages in a PDF that are sideways, upside down, or slightly skewed. Rotate every page 90 degrees at once, turn an individual page either way, or type an exact angle for a page that's just slightly crooked — with a real preview of each one.

Upload the PDF and review the page previews. Use "Rotate all" to turn every page at once, the arrows under a page for quick 90-degree fixes, or type an angle (or use the − and + buttons) for fine correction. Apply the rotation, compare the original with the result, and download.`,
    tip: `Pages that have a text layer are checked on your device: if most of a page's text runs sideways or upside down, it is marked "Looks sideways" with the turn that would fix it. Nothing changes until you press the button for that page, or "Fix N pages". Scanned pages with no text layer are not checked (the tool cannot read them without text recognition), so look at those yourself. To turn several PDFs the same way, switch to Several files: all pages, odd pages or even pages, one ZIP.

A 90-degree turn only changes how the page is displayed, so everything in your PDF — text, links, form fields, bookmarks, the title — stays exactly as it was. A custom angle redraws that page at its original sharpness, with its text still selectable; the page grows a little to hold the turned content, and links or form fields on that page are not kept.`,
  },
  P = (s) => {
    const n = ((((s + 180) % 360) + 360) % 360) - 180;
    return n === -180 ? 180 : Math.round(n * 1e3) / 1e3;
  };
function Me({ url: s, pageNumber: n, angle: c, aspect: i, onAspect: l }) {
  const a = (c * Math.PI) / 180,
    u = Math.abs(Math.cos(a)),
    p = Math.abs(Math.sin(a)),
    w = 0.75,
    N = i * u + p,
    k = i * p + u,
    v = Math.min(1 / N, 1 / w / k);
  return e.jsx("div", {
    className: "relative w-full overflow-hidden rounded-lg border bg-muted",
    style: { aspectRatio: String(w) },
    children: e.jsx("img", {
      src: s,
      alt: `Page ${n}${c ? `, turned ${c}°` : ""}`,
      onLoad: (F) => {
        const x = F.currentTarget;
        x.naturalHeight > 0 && l(x.naturalWidth / x.naturalHeight);
      },
      className:
        "absolute left-1/2 top-1/2 bg-white shadow ring-1 ring-black/10",
      style: {
        width: `${i * v * 100}%`,
        height: "auto",
        transform: `translate(-50%, -50%) rotate(${c}deg)`,
      },
    }),
  });
}
const X = (s) => (s === 90 ? "90° right" : s === -90 ? "90° left" : "180°");
function Oe() {
  const [s, n] = m.useState(90),
    [c, i] = m.useState("all"),
    l = (a) => (a ? "default" : "outline");
  return e.jsx(be, {
    accept: ".pdf",
    noun: "PDF",
    zipName: "rotated-pdfs.zip",
    runLabel: "Rotate all",
    includeOriginals: !0,
    process: async (a) => {
      const u = await G(a);
      if (!u) throw new Error(`${a.name} has no pages`);
      const p = await J(a, Ee(u, s, c));
      return { blob: K(p), fileName: `${Q(a.name)}-rotated.pdf` };
    },
    children: e.jsxs("div", {
      className: "space-y-3 mb-3",
      children: [
        e.jsxs("div", {
          className: "flex flex-wrap items-center gap-2",
          role: "group",
          "aria-label": "Turn",
          children: [
            e.jsx("span", {
              className: "text-sm text-muted-foreground mr-1",
              children: "Turn",
            }),
            [90, -90, 180].map((a) =>
              e.jsx(
                g,
                {
                  size: "sm",
                  variant: l(s === a),
                  "aria-pressed": s === a,
                  onClick: () => n(a),
                  children: X(a),
                },
                a,
              ),
            ),
          ],
        }),
        e.jsxs("div", {
          className: "flex flex-wrap items-center gap-2",
          role: "group",
          "aria-label": "Pages",
          children: [
            e.jsx("span", {
              className: "text-sm text-muted-foreground mr-1",
              children: "Pages",
            }),
            ["all", "odd", "even"].map((a) =>
              e.jsx(
                g,
                {
                  size: "sm",
                  variant: l(c === a),
                  "aria-pressed": c === a,
                  onClick: () => i(a),
                  children:
                    a === "all"
                      ? "All pages"
                      : a === "odd"
                        ? "Odd pages"
                        : "Even pages",
                },
                a,
              ),
            ),
          ],
        }),
        e.jsx("p", {
          className: "text-xs text-muted-foreground",
          children:
            "Every PDF gets the same turn. Pages are not checked for sideways text in this mode, so only what you pick here changes.",
        }),
      ],
    }),
  });
}
function Zt() {
  const [s, n] = m.useState(!1);
  return e.jsxs(ue, {
    toolId: "rotate-pdf",
    categoryId: "pdf-tools",
    whatItDoes: q.what,
    proTip: q.tip,
    children: [
      e.jsx(je, { batch: s, onChange: n }),
      s ? e.jsx(Oe, {}) : e.jsx($e, {}),
    ],
  });
}
function $e() {
  const [s, n] = m.useState(null),
    [c, i] = m.useState(0),
    [l, a] = m.useState({}),
    [u, p] = m.useState({}),
    [w, N] = m.useState({}),
    [k, v] = m.useState(!1),
    [F, x] = m.useState(""),
    [b, T] = m.useState(null),
    [M, S] = m.useState(""),
    { thumbnails: Y, loading: ee } = xe(s),
    h = ye(),
    [y, O] = m.useState({}),
    [$, z] = m.useState(!1);
  m.useEffect(() => {
    if ((O({}), !s)) return;
    let t = !0;
    return (
      z(!0),
      (async () => {
        try {
          const r = await Ne(s),
            o = await De(r, () => t);
          t && O(Object.fromEntries(o.map((d) => [d.page, d])));
        } catch {
        } finally {
          t && z(!1);
        }
      })(),
      () => {
        t = !1;
      }
    );
  }, [s]);
  const f = m.useCallback(() => {
      (h.cancel(), v(!1), x(""), T(null));
    }, [h]),
    te = m.useCallback(
      async (t) => {
        const r = t[0];
        if (r) {
          (f(), S(""));
          try {
            const o = await G(r);
            if (!o) throw new Error("no pages");
            (a(
              Object.fromEntries(
                Array.from({ length: o }, (d, R) => [R + 1, 0]),
              ),
            ),
              p({}),
              N({}),
              i(o),
              n(r));
          } catch {
            S(
              `"${r.name}" couldn't be read as a PDF. It may not be a PDF at all, or it may be damaged. Nothing was used. Try another file.`,
            );
          }
        }
      },
      [f],
    ),
    I = () => {
      (f(), n(null), i(0), a({}), p({}), S(""));
    },
    C = (t, r) => {
      (a((o) => ({ ...o, [t]: P((o[t] || 0) + r) })),
        p((o) => {
          const d = { ...o };
          return (delete d[t], d);
        }),
        f());
    },
    B = (t) => {
      (a((r) =>
        Object.fromEntries(Object.entries(r).map(([o, d]) => [o, P(d + t)])),
      ),
        p({}),
        f());
    },
    L = (t) => {
      (a((r) =>
        Object.fromEntries(
          Object.entries(r).map(([o, d]) => [
            o,
            (Number(o) % 2 === 1) == (t === "odd") ? P(d + 90) : d,
          ]),
        ),
      ),
        p({}),
        f());
    },
    _ = (t) => {
      (a((r) => {
        const o = { ...r };
        for (const d of t) {
          const R = y[d];
          R && (o[d] = P(R.turn));
        }
        return o;
      }),
        p({}),
        f());
    },
    se = (t, r) => {
      p((d) => ({ ...d, [t]: r }));
      const o = parseFloat(r);
      Number.isFinite(o) && (a((d) => ({ ...d, [t]: P(o) })), f());
    },
    ae = (t) => {
      p((r) => {
        const o = { ...r };
        return (delete o[t], o);
      });
    },
    re = async () => {
      if (!s) return;
      (h.cancel(), T(null));
      const t = h.start();
      (v(!0), x(""));
      try {
        const r = await J(
          s,
          l,
          (o) => h.isCurrent(t) && x(o),
          () => !h.isCurrent(t),
        );
        if (!h.isCurrent(t)) return;
        (T(K(r)), A.success("Rotation applied"));
      } catch (r) {
        if (!h.isCurrent(t)) return;
        (console.error("Rotate failed:", r), A.error("Failed to rotate PDF"));
      } finally {
        h.isCurrent(t) && (v(!1), x(""));
      }
    },
    H = Object.entries(l)
      .filter(([, t]) => t !== 0)
      .map(([t]) => Number(t))
      .sort((t, r) => t - r),
    j = Object.values(y)
      .filter((t) => (l[t.page] ?? 0) !== t.turn)
      .map((t) => t.page)
      .sort((t, r) => t - r),
    U = H.length > 0,
    oe = Pe(b),
    ne = Object.values(l).some((t) => t % 90 !== 0);
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(ve, {
        toolId: "rotate-pdf",
        state: {
          hasFile: !!s,
          anyTurn: U,
          processing: k,
          resultReady: !!b && !k,
          downloaded: oe,
        },
      }),
      s
        ? e.jsxs("div", {
            className: "space-y-4",
            children: [
              e.jsxs("div", {
                className:
                  "flex items-center justify-between p-4 rounded-lg border bg-card flex-wrap gap-2",
                children: [
                  e.jsxs("div", {
                    className: "min-w-0",
                    children: [
                      e.jsx("p", {
                        className: "text-sm font-medium truncate",
                        children: s.name,
                      }),
                      e.jsxs("p", {
                        className: "text-xs text-muted-foreground",
                        children: [D(c, "page"), " · ", ke(s.size)],
                      }),
                    ],
                  }),
                  e.jsxs("div", {
                    className: "flex gap-2 flex-wrap",
                    children: [
                      c > 1 &&
                        e.jsxs(e.Fragment, {
                          children: [
                            e.jsx(g, {
                              variant: "outline",
                              size: "sm",
                              onClick: () => L("odd"),
                              children: "Rotate odd pages",
                            }),
                            e.jsx(g, {
                              variant: "outline",
                              size: "sm",
                              onClick: () => L("even"),
                              children: "Rotate even pages",
                            }),
                          ],
                        }),
                      e.jsxs(g, {
                        variant: "outline",
                        size: "sm",
                        onClick: () => B(-90),
                        className: "gap-1.5",
                        "aria-label": "Rotate all pages 90° counter-clockwise",
                        children: [
                          e.jsx(V, { className: "h-3.5 w-3.5" }),
                          " All 90° left",
                        ],
                      }),
                      e.jsxs(g, {
                        variant: "outline",
                        size: "sm",
                        onClick: () => B(90),
                        className: "gap-1.5",
                        "aria-label": "Rotate all pages 90° clockwise",
                        children: [
                          e.jsx(Z, { className: "h-3.5 w-3.5" }),
                          " All 90° right",
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              $ &&
                e.jsx("p", {
                  className: "text-xs text-muted-foreground",
                  role: "status",
                  children: "Checking which pages look sideways...",
                }),
              !$ &&
                Object.keys(y).length > 0 &&
                e.jsx(W, {
                  className: "p-3 border-amber-500/40 bg-amber-500/5",
                  "data-testid": "sideways-banner",
                  children: e.jsxs("div", {
                    className: "flex flex-wrap items-center gap-3",
                    children: [
                      e.jsx(he, {
                        className: "h-4 w-4 shrink-0 text-amber-600",
                      }),
                      e.jsx("p", {
                        className: "text-sm flex-1 min-w-[12rem]",
                        children:
                          j.length > 0
                            ? e.jsxs(e.Fragment, {
                                children: [
                                  D(j.length, "page"),
                                  " look",
                                  j.length === 1 ? "s" : "",
                                  " sideways or upside down (page ",
                                  j.join(", "),
                                  "). Based on the text layer, checked on your device. Nothing is turned until you accept.",
                                ],
                              })
                            : "The suggested turns are set. Review the previews, then apply.",
                      }),
                      j.length > 0 &&
                        e.jsxs(g, {
                          size: "sm",
                          onClick: () => _(j),
                          "data-testid": "fix-all-orientation",
                          children: ["Fix ", D(j.length, "page")],
                        }),
                    ],
                  }),
                }),
              ee
                ? e.jsx(we, {})
                : e.jsx("div", {
                    className:
                      "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4",
                    children: Y.map((t) => {
                      const r = l[t.pageNumber] ?? 0;
                      return e.jsxs(
                        "div",
                        {
                          className: "flex flex-col items-center gap-1.5",
                          children: [
                            e.jsx(Me, {
                              url: t.url,
                              pageNumber: t.pageNumber,
                              angle: r,
                              aspect: w[t.pageNumber] ?? 0.75,
                              onAspect: (o) =>
                                N((d) =>
                                  Math.abs((d[t.pageNumber] ?? 0) - o) < 0.001
                                    ? d
                                    : { ...d, [t.pageNumber]: o },
                                ),
                            }),
                            e.jsxs("div", {
                              className: "flex items-center gap-1",
                              children: [
                                e.jsx(g, {
                                  variant: "ghost",
                                  size: "icon",
                                  className: "h-6 w-6",
                                  onClick: () => C(t.pageNumber, -90),
                                  title:
                                    "Rotate this page 90° counter-clockwise",
                                  "aria-label": `Rotate page ${t.pageNumber} 90° counter-clockwise (${E(r)} from current)`,
                                  children: e.jsx(V, { className: "h-3 w-3" }),
                                }),
                                e.jsxs("span", {
                                  className: "text-xs text-muted-foreground",
                                  children: ["Page ", t.pageNumber],
                                }),
                                e.jsx(g, {
                                  variant: "ghost",
                                  size: "icon",
                                  className: "h-6 w-6",
                                  onClick: () => C(t.pageNumber, 90),
                                  title: "Rotate this page 90° clockwise",
                                  "aria-label": `Rotate page ${t.pageNumber} 90° clockwise (${E(r)} from current)`,
                                  children: e.jsx(Z, { className: "h-3 w-3" }),
                                }),
                              ],
                            }),
                            y[t.pageNumber] &&
                              r !== y[t.pageNumber].turn &&
                              e.jsxs(g, {
                                variant: "outline",
                                size: "sm",
                                className:
                                  "h-6 px-2 text-[11px] border-amber-500/50",
                                onClick: () => _([t.pageNumber]),
                                "data-testid": `fix-page-${t.pageNumber}`,
                                children: [
                                  "Looks sideways: turn ",
                                  X(y[t.pageNumber].turn),
                                ],
                              }),
                            e.jsxs("p", {
                              className: "text-[11px] text-muted-foreground",
                              "data-testid": `delta-${t.pageNumber}`,
                              children: [E(r), " from current"],
                            }),
                            e.jsxs("div", {
                              className: "flex items-center gap-1",
                              children: [
                                e.jsx(g, {
                                  variant: "ghost",
                                  size: "icon",
                                  className: "h-6 w-6",
                                  onClick: () => C(t.pageNumber, -0.1),
                                  "aria-label": `Turn page ${t.pageNumber} 0.1° counter-clockwise`,
                                  title: "Nudge 0.1° left",
                                  children: e.jsx(le, { className: "h-3 w-3" }),
                                }),
                                e.jsx(fe, {
                                  type: "number",
                                  min: -180,
                                  max: 180,
                                  step: 0.1,
                                  value: u[t.pageNumber] ?? String(r),
                                  onChange: (o) =>
                                    se(t.pageNumber, o.target.value),
                                  onBlur: () => ae(t.pageNumber),
                                  className: "h-6 w-16 text-xs px-1.5",
                                  title:
                                    "Angle in degrees (clockwise is positive)",
                                  "aria-label": `Extra turn for page ${t.pageNumber}, in degrees from its current rotation`,
                                }),
                                e.jsx("span", {
                                  className: "text-xs text-muted-foreground",
                                  children: "°",
                                }),
                                e.jsx(g, {
                                  variant: "ghost",
                                  size: "icon",
                                  className: "h-6 w-6",
                                  onClick: () => C(t.pageNumber, 0.1),
                                  "aria-label": `Turn page ${t.pageNumber} 0.1° clockwise`,
                                  title: "Nudge 0.1° right",
                                  children: e.jsx(ce, { className: "h-3 w-3" }),
                                }),
                              ],
                            }),
                          ],
                        },
                        t.pageNumber,
                      );
                    }),
                  }),
              ne &&
                e.jsx(W, {
                  className: "p-3 border-border bg-muted/40",
                  children: e.jsxs("div", {
                    className: "flex gap-2",
                    children: [
                      e.jsx(Ce, {
                        className:
                          "h-4 w-4 text-muted-foreground shrink-0 mt-0.5",
                      }),
                      e.jsx("p", {
                        className: "text-xs text-muted-foreground",
                        children:
                          "Pages with a custom angle are redrawn at their original sharpness and their text stays selectable. The page grows slightly to hold the turned content, and links or form fields on those pages are not kept.",
                      }),
                    ],
                  }),
                }),
              e.jsx("div", {
                className: "flex gap-3 pt-2 border-t border-border",
                children: k
                  ? e.jsx(de, {
                      message: F || "Rotating...",
                      onStop: () => {
                        (f(), A.info("Stopped."));
                      },
                    })
                  : b
                    ? e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(pe, {
                            blob: b,
                            fileName: `${Q(s.name)}-rotated.pdf`,
                          }),
                          e.jsx(g, {
                            variant: "outline",
                            onClick: I,
                            children: "Reset",
                          }),
                        ],
                      })
                    : e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(g, {
                            onClick: () => {
                              re();
                            },
                            disabled: !U,
                            className: "btn-glow",
                            children: "Apply rotation",
                          }),
                          e.jsx(g, {
                            variant: "outline",
                            onClick: I,
                            children: "Reset",
                          }),
                          e.jsx(me, { className: "self-center" }),
                        ],
                      }),
              }),
              b &&
                e.jsx(ge, {
                  original: s,
                  result: b,
                  pageCountHint: void 0,
                  initialPage: H[0] ?? 1,
                  leftTitle: "Original",
                  rightTitle: "Rotated",
                }),
            ],
          })
        : e.jsxs(e.Fragment, {
            children: [
              e.jsx(ie, {
                gateAtDownload: !0,
                acceptDamagedPdf: !0,
                accept: ".pdf",
                onFiles: te,
                label: "Drop a PDF to rotate, or click to browse",
                description:
                  "Preview and rotate individual pages, all at once, or to a custom angle",
              }),
              M &&
                e.jsx("p", {
                  role: "alert",
                  className: "text-sm text-destructive mt-2",
                  children: M,
                }),
            ],
          }),
    ],
  });
}
export { Zt as default };
//# sourceMappingURL=RotatePdf-B8GW322r.js.map
