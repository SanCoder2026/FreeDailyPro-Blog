# FDP-94 rotate-pdf test files (all made up). python3 make94.py
import fitz, pikepdf, os, shutil, random, json
random.seed(94)
T='testfiles/'; os.makedirs(T,exist_ok=True)
A93='/workspace/deep/93-remove-pdf-pages/testfiles/'
# 1 doc.pdf: 6 pages; text; links p1->p4 + URL; p5->p1; bookmarks every page (XYZ); fields p3 (text) p4 (checkbox); highlight+note p2; metadata; page labels
d=fitz.open()
for n in range(1,7):
    p=d.new_page(); p.insert_text((72,72),f'PAGE-{n} rotate test',fontsize=20); p.insert_text((72,110),f'Body text line on page {n} keepme{n}',fontsize=12)
    p.draw_rect(fitz.Rect(72,140,200,200),color=(0,0,1),fill=(0.8,0.9,1)); p.insert_text((80,175),'TOP-LEFT BOX',fontsize=9)
pg1=d[0]; pg1.insert_text((72,250),'go to page 4',fontsize=12,color=(0,0,1)); pg1.insert_link({'kind':fitz.LINK_GOTO,'from':fitz.Rect(72,238,180,254),'page':3,'to':fitz.Point(72,72)})
pg1.insert_text((72,280),'example.com',fontsize=12,color=(0,0,1)); pg1.insert_link({'kind':fitz.LINK_URI,'from':fitz.Rect(72,268,180,284),'uri':'https://example.com/rot'})
pg5=d[4]; pg5.insert_text((72,250),'back to page 1',fontsize=12,color=(0,0,1)); pg5.insert_link({'kind':fitz.LINK_GOTO,'from':fitz.Rect(72,238,180,254),'page':0,'to':fitz.Point(0,0)})
pg2=d[1]; a=pg2.add_highlight_annot(fitz.Rect(72,98,300,114)); a.update(); a=pg2.add_text_annot((400,100),'NOTE-ON-P2'); a.update()
w=fitz.Widget(); w.field_name='p3_name'; w.field_type=fitz.PDF_WIDGET_TYPE_TEXT; w.rect=fitz.Rect(72,300,300,322); w.field_value='P3-VALUE'; pg3=d[2]; pg3.add_widget(w)
w=fitz.Widget(); w.field_name='p4_agree'; w.field_type=fitz.PDF_WIDGET_TYPE_CHECKBOX; w.rect=fitz.Rect(72,300,90,318); w.field_value=True; pg4=d[3]; pg4.add_widget(w)
d.set_toc([[1,f'Page {n}',n,{'kind':fitz.LINK_GOTO,'page':n-1,'to':fitz.Point(72,100),'zoom':1.5}] for n in range(1,7)])
d.set_metadata({'title':'Rotate Test Doc','author':'QA Bot','subject':'SUBJ-94','keywords':'kw94'})
d.save('/tmp/doc94.pdf'); q=pikepdf.open('/tmp/doc94.pdf')
q.Root.PageLabels=pikepdf.Dictionary(Nums=[0,pikepdf.Dictionary(S=pikepdf.Name.r),2,pikepdf.Dictionary(S=pikepdf.Name.D)]); q.Root.Lang=pikepdf.String('en-US')
q.save(T+'doc.pdf')
# 2 rotated-inherit from 93
shutil.copy(A93+'rotated-inherit.pdf',T)
# 3 cropped.pdf: p1 CropBox inset with HIDDEN text outside crop; p2 MediaBox origin (50,50) + offset CropBox; p3 plain
d=fitz.open(); 
for n in range(3): p=d.new_page(width=612,height=792)
d[0].insert_text((72,60),'HIDDEN-OUTSIDE-CROP header',fontsize=14); d[0].insert_text((150,400),'VISIBLE-INSIDE p1',fontsize=18)
d[1].insert_text((150,400),'VISIBLE-INSIDE p2',fontsize=18); d[1].insert_text((60,780),'HIDDEN-P2-EDGE',fontsize=10)
d[2].insert_text((150,400),'PLAIN p3',fontsize=18)
d.save('/tmp/c94.pdf'); q=pikepdf.open('/tmp/c94.pdf')
q.pages[0].obj.CropBox=[100,100,512,692]
q.pages[1].obj.MediaBox=[50,50,662,842]; q.pages[1].obj.CropBox=[120,120,600,760]
q.save(T+'cropped.pdf')
# 4 sideways.pdf: text upright, rotated 90, 180, 270 (content), plus image-only page
d=fitz.open()
for rot in [0,90,180,270]:
    p=d.new_page()
    for j in range(12):
        if rot==0: p.insert_text((72,80+j*20),f'Upright line {j} with enough words to count',fontsize=11)
        elif rot==90: p.insert_text((80+j*20,770),f'Sideways line {j} with enough words to count',fontsize=11,rotate=90)
        elif rot==180: p.insert_text((520,770-j*20),f'Upside line {j} with enough words to count',fontsize=11,rotate=180)
        else: p.insert_text((520-j*20,80),f'Other way line {j} with enough words to count',fontsize=11,rotate=270)
from PIL import Image, ImageDraw
im=Image.new('RGB',(850,1100),'white'); dr=ImageDraw.Draw(im)
for j in range(20): dr.text((60,60+j*40),f'SCANNED SIDEWAYS LINE {j}',fill='black')
im=im.rotate(90,expand=True); im.save('/tmp/scan94.jpg',quality=80)
p=d.new_page(); p.insert_image(p.rect,filename='/tmp/scan94.jpg')
d.save(T+'sideways.pdf')
# 5 copies
for f in ['form.pdf','enc.pdf','corrupt.pdf','large-300p.pdf','three.pdf','toc-links.pdf']: shutil.copy(A93+f,T)
if not os.path.exists(T+'heavy.pdf'): os.symlink(os.path.realpath(A93+'heavy.pdf'),T+'heavy.pdf')
print({f:os.path.getsize(T+f) for f in sorted(os.listdir(T))})
