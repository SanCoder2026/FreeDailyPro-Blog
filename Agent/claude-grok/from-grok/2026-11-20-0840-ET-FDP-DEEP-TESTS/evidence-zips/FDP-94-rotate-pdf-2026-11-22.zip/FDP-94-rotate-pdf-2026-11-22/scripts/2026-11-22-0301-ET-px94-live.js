// FDP-94 Rotate PDF (Professional 10/day), guest. node px94-live.js <explore|core|...>
// Never signs in, never types an email or card, never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const W = '/workspace/deep/94-rotate-pdf/'; const OUT = W + 'live/'; const TF = W + 'testfiles/'; const TOOL = 'https://www.freedailypro.com/tool/rotate-pdf';
const mode = process.argv[2] || 'core'; const sfx = process.env.SUF || '';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
fs.mkdirSync(OUT + 'dl', { recursive: true }); fs.mkdirSync(OUT + 'cases', { recursive: true });
(async () => { const b = await (process.env.WK ? pw.webkit : pw.chromium).launch(); const R = { t: now(), mode, tries: [], cases: {} }; let c, p, net = [], dls = [], cons = [];
 const open = async (opts = {}) => { c = await b.newContext({ viewport: { width: 1366, height: 1800 }, locale: 'en-US', timezoneId: 'America/New_York', acceptDownloads: true, ...opts }); p = await c.newPage(); p.setDefaultTimeout(20000); net = []; dls = [];
  p.on('request', r => { const u = r.url(); if (r.method() === 'POST' && /freedailypro\.com\/api/.test(u) && !/insight\.hit|funnel\.hit/.test(u)) net.push({ t: now(), u: u.slice(0, 70) }); });
  p.on('download', async d => { const n = d.suggestedFilename(); const path = OUT + 'dl/' + mode + sfx + '-' + dls.length + '-' + n; dls.push({ name: n, path }); await d.saveAs(path).catch(() => { }); });
  p.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') cons.push(m.text().slice(0, 200)); });
  await p.goto(TOOL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(200); } };
 const shot = (n, full = true) => p.screenshot({ path: OUT + 'cases/' + n + sfx + '.png', fullPage: full });
 const toasts = async () => (await p.locator('[data-sonner-toast]').allInnerTexts()).map(s => s.replace(/\s*\n\s*/g, ' '));
 const poll = async (ms = 3000) => { const s = new Set(); for (let i = 0; i < ms / 250; i++) { for (const t of await toasts()) s.add(t); await p.waitForTimeout(250); } return [...s]; };
 const find = async (opts) => { for (let i = 0; i < +(process.env.TRIES || 25); i++) { await open(opts); const u = await used(); R.tries.push(u); if (u.startsWith('0/')) return true; await c.close(); } return false; };
 const drop = async f => { await p.locator('input[type=file]').first().setInputFiles(TF + f); const ts = await poll(+(process.env.LOADMS || 5000)); return { loadToasts: ts, alerts: await alerts(), page: await pageLbl() }; };
 const alerts = async () => (await p.locator('main [role=alert]').allInnerTexts()).map(s => s.replace(/\s*\n\s*/g, ' ').slice(0, 300));
 const pageLbl = async () => { const t = await p.locator('main').innerText(); const m = t.match(/Page \d+ of \d+/); return m ? m[0] : null; };
 const readout = async () => { const r = p.locator('[data-testid=crop-size-readout]'); return (await r.count()) ? (await r.innerText()) : null; };
 const margins = async () => { const o = {}; for (const k of ['top', 'right', 'bottom', 'left']) o[k] = await p.getByLabel(k + ' margin', { exact: true }).inputValue(); return o; };
 const setM = async (t, r, bt, l, unit) => { if (unit) await p.getByLabel('Margin unit').selectOption(unit); const v = { top: t, right: r, bottom: bt, left: l }; for (const k of ['top', 'right', 'bottom', 'left']) { await p.getByLabel(k + ' margin', { exact: true }).fill(String(v[k])); await p.waitForTimeout(120); } await p.waitForTimeout(300); return { margins: await margins(), readout: await readout() }; };
 const scope = async (s, range) => { await p.locator('main button', { hasText: new RegExp('^\\s*' + s + '\\s*$') }).click(); await p.waitForTimeout(200); if (range !== undefined) { await p.locator('main input[placeholder^="e.g."]').fill(range); await p.waitForTimeout(200); } };
 const btn = (re) => p.locator('main button', { hasText: re });
 const apply = async () => { const bt = btn(/^\s*Apply rotation\s*$/); if (!(await bt.count())) return { apply: 'no button' }; if (await bt.isDisabled()) return { apply: 'disabled' }; await bt.click(); const ts = await poll(+(process.env.APPLYMS || 3000)); return { toasts: ts, alerts: await alerts(), hasDownload: (await btn(/^\s*Download/).count()) > 0 }; };
 const download = async () => { const d0 = dls.length, np = net.length, u0 = await used(); const bt = btn(/^\s*Download/); if (!(await bt.count())) return { download: 'no button' }; const label = (await bt.first().innerText()).trim(); await bt.first().click(); await p.waitForTimeout(4000); const dg = await dialog(); if (dg) await esc(); return { label, usage: u0 + '->' + await used(), posts: net.length - np, dialog: dg, downloads: dls.slice(d0).map(d => ({ name: d.name, size: fs.existsSync(d.path) ? fs.statSync(d.path).size : null, saved: d.path.replace(W, '') })) }; };
 const newF = async () => { const n = btn(/^\s*(New|Reset)\s*$/).first(); if (await n.count()) { await n.click(); await p.waitForTimeout(800); } };
 const next = async () => { await btn(/^\s*Next\s*$/).click(); await p.waitForTimeout(1200); };
 const autotrim = async (pad) => { if (pad !== undefined) await p.locator('#crop-trim-pad').selectOption(String(pad)); const t0 = Date.now(); await btn(/Auto-trim|Detecting/).click(); for (let i = 0; i < 600; i++) { await p.waitForTimeout(250); if (!(await btn(/Detecting/).count())) break; } const ms = Date.now() - t0; return { ms, toasts: await poll(1500), margins: await margins(), readout: await readout() }; };
 const C = async (id_, fn) => { if (process.env.ONLY && !new RegExp(process.env.ONLY).test(id_)) return; const c0 = cons.length; try { R.cases[id_] = await fn(); } catch (e) { R.cases[id_] = { err: e.message.split('\n')[0].slice(0, 200) }; await shot(id_ + '-err').catch(() => { }); } R.cases[id_].console = cons.slice(c0).slice(0, 5); console.log(id_, JSON.stringify(R.cases[id_]).slice(0, 1500)); };
 const img = () => p.locator('main img.pointer-events-none').first();
 const at = async (fx, fy) => { const bb = await img().boundingBox(); return [bb.x + fx * bb.width, bb.y + fy * bb.height]; };
 const drag = async (fx1, fy1, fx2, fy2, steps = 10) => { const [x1, y1] = await at(fx1, fy1); const [x2, y2] = await at(fx2, fy2); await p.mouse.move(x1, y1); await p.mouse.down(); for (let i = 1; i <= steps; i++) await p.mouse.move(x1 + (x2 - x1) * i / steps, y1 + (y2 - y1) * i / steps); await p.mouse.up(); await p.waitForTimeout(400); };
 const dragEl = async (loc, dx, dy) => { const bb = await loc.boundingBox(); const x = bb.x + bb.width / 2, y = bb.y + bb.height / 2; await p.mouse.move(x, y); await p.mouse.down(); for (let i = 1; i <= 10; i++) await p.mouse.move(x + dx * i / 10, y + dy * i / 10); await p.mouse.up(); await p.waitForTimeout(400); };


 const info = async () => ({ buttons: (await p.locator('main button').allInnerTexts()).map(s => s.trim()).filter(Boolean).slice(0, 80), labels: await p.locator('main [aria-label]').evaluateAll(es => es.map(e => e.tagName + ':' + e.getAttribute('aria-label')).slice(0, 80)), inputs: await p.locator('main input').evaluateAll(es => es.map(e => e.type + '|' + (e.id || '') + '|' + (e.getAttribute('aria-label') || '') + '|' + e.value)), text: (await p.locator('main').innerText()).slice(0, 3000) });
 const waitReady = async (ms = 20000) => { for (let i = 0; i < ms / 500; i++) { if (await btn(/^\s*Apply rotation\s*$/).count()) return true; await p.waitForTimeout(500); } return false; };
 const setDelta = async (n, v) => { const i = p.locator(`[data-testid=delta-${n}] input`); if (await i.count()) { await i.fill(String(v)); } else { await p.getByLabel(`Extra turn for page ${n}, in degrees from its current rotation`).fill(String(v)); } await p.waitForTimeout(300); };
 const cw = async (n) => { await p.getByLabel(new RegExp(`^Rotate page ${n} 90° clockwise`)).click(); await p.waitForTimeout(250); };
 const ccw = async (n) => { await p.getByLabel(new RegExp(`^Rotate page ${n} 90° counter-clockwise`)).click(); await p.waitForTimeout(250); };
 const rotDl = async (fn) => { await fn(); const a = await apply(); const d = await download(); return { a, d }; };

 const fresh = async (f) => { const r = btn(/^\s*Reset\s*$/); if (await r.count()) { await r.first().click(); await p.waitForTimeout(800); } const l = await drop(f); const ok = await waitReady(+(process.env.READYMS || 20000)); return { ...l, ready: ok }; };
 const vals = async () => p.locator('main input[type=number]').evaluateAll(es => es.map(e => e.value).join(','));
 const banner = async () => { const b_ = p.locator('[data-testid=sideways-banner]'); return (await b_.count()) ? (await b_.innerText()).replace(/\s*\n\s*/g, ' | ') : null; };
 const flags = async () => (await p.locator('main').innerText()).match(/Looks sideways[^\n]*/g);
 const full = async (id_, f, setup) => { const l = await fresh(f); await setup(); const v = await vals(); const a = await apply(); await shot(id_, false).catch(() => { }); const d = await download(); return { l: { ready: l.ready, toasts: l.loadToasts }, v, a, d }; };

 if (mode === 'core') { await find(); R.start = await used();
  await C('C01-doc-all-right', () => full('C01', 'doc.pdf', async () => { await btn(/^\s*All 90° right\s*$/).click(); }));
  await C('C02-doc-perpage', () => full('C02', 'doc.pdf', async () => { await cw(2); await ccw(3); await cw(4); await cw(4); }));
  await C('C03-doc-odd', () => full('C03', 'doc.pdf', async () => { await btn(/^\s*Rotate odd pages\s*$/).click(); await p.waitForTimeout(300); }));
  await C('C04-doc-custom', () => full('C04', 'doc.pdf', async () => { await setDelta(1, 5); await setDelta(3, -3); await setDelta(5, 90); }));
  await C('C05-inputs', async () => { await fresh('three.pdf'); const o = {}; for (const v of ['360', '-90', '45.5', '1000', '-181', 'abc', '1e2', '']) { await setDelta(1, v).catch(e => o[v] = 'fill-err'); await p.locator('main input[type=number]').nth(1).click(); await p.waitForTimeout(300); o[v] = o[v] || await vals(); } await p.getByLabel('Turn page 2 0.1° clockwise').click(); await p.getByLabel('Turn page 2 0.1° clockwise').click(); o.nudge = await vals(); await btn(/^\s*Rotate even pages\s*$/).click(); o.even = await vals(); await btn(/^\s*All 90° left\s*$/).click(); o.allLeft = await vals(); return o; });
 }
 if (mode === 'rot') { await find(); R.start = await used();
  await C('R01-inherit-all-right', () => full('R01', 'rotated-inherit.pdf', async () => { await btn(/^\s*All 90° right\s*$/).click(); }));
  await C('R02-inherit-custom', () => full('R02', 'rotated-inherit.pdf', async () => { await setDelta(1, 10); await setDelta(2, -7); }));
  await C('K01-crop-all-right', () => full('K01', 'cropped.pdf', async () => { await btn(/^\s*All 90° right\s*$/).click(); }));
  await C('K02-crop-custom', () => full('K02', 'cropped.pdf', async () => { await setDelta(1, 3); await setDelta(2, 3); }));
  await C('F01-form-all', () => full('F01', 'form.pdf', async () => { await btn(/^\s*All 90° right\s*$/).click(); }));
  await C('F02-form-custom-p1', () => full('F02', 'form.pdf', async () => { await setDelta(1, 2); }));
  await C('L01-toc-custom-p7', () => full('L01', 'toc-links.pdf', async () => { await setDelta(7, 2); }));
 }
 if (mode === 'side') { await find(); R.start = await used();
  await C('S01-sideways', async () => { const l = await fresh('sideways.pdf'); await p.waitForTimeout(6000); const bn = await banner(); const fl = await flags(); await shot('S01-flags', false); const fx = p.locator('[data-testid=fix-all-orientation]'); let fixed = null; if (await fx.count()) { await fx.click(); await p.waitForTimeout(500); fixed = await vals(); } const a = await apply(); const d = await download(); return { bn, fl, fixed, a, d }; });
 }
 if (mode === 'err') { await find(); R.start = await used();
  await C('E01-enc', async () => { await drop('enc.pdf'); await p.waitForTimeout(3000); const dg = await dialog(); await shot('E01-enc', false); await esc(); return { dg, al: await alerts(), text: (await p.locator('main').innerText()).match(/[^\n]*(password|protected|couldn)[^\n]*/gi) }; });
  await C('E02-corrupt', async () => { const l = await fresh('corrupt.pdf'); return { l, al: await alerts(), text: (await p.locator('main').innerText()).match(/[^\n]*(couldn|damaged|read)[^\n]*/gi) }; });
  await C('E03-large-all', async () => { const t0 = Date.now(); const l = await fresh('large-300p.pdf'); const loadMs = Date.now() - t0; await btn(/^\s*All 90° right\s*$/).click(); const t1 = Date.now(); const a = await apply(); const applyMs = Date.now() - t1; const d = await download(); return { loadMs, ready: l.ready, applyMs, a, d }; });
  await C('E04-large-custom-p1-p300', async () => { await btn(/^\s*Reset\s*$/).first().click(); await p.waitForTimeout(800); await drop('large-300p.pdf'); await waitReady(60000); await setDelta(1, 4); await setDelta(300, -4); const t1 = Date.now(); const a = await apply(); const applyMs = Date.now() - t1; const d = await download(); return { applyMs, a, d }; });
  await C('E05-heavy', async () => { const t0 = Date.now(); const l = await fresh('heavy.pdf'); const loadMs = Date.now() - t0; await btn(/^\s*All 90° right\s*$/).click(); await setDelta(2, 3); const t1 = Date.now(); const a = await apply(); const applyMs = Date.now() - t1; const d = await download(); return { loadMs, l, applyMs, a, d }; });
  await C('E06-not-pdf', async () => { const l = await fresh('../make94.py'); return { l, al: await alerts(), text: (await p.locator('main').innerText()).match(/[^\n]*(couldn|PDF)[^\n]*/g)?.slice(0, 5) }; });
 }
 if (mode === 'cap') { await open(); R.start = await used(); R.note = 'no find: use whatever the pool gives';
  await C('G01-cap-try', () => full('G01', 'three.pdf', async () => { await btn(/^\s*All 90° right\s*$/).click(); }));
 }
 if (mode === 'capload') { await find(); R.start = await used(); R.rows = [];
  for (const f of ['three.pdf', 'doc.pdf', 'three.pdf']) { const r = await full('cap-' + R.rows.length, f, async () => { await btn(/^\s*All 90° right\s*$/).click(); }); R.rows.push({ f, d: r.d }); if (!R.cont) R.cont = { buttons: (await info()).buttons, cont: (await p.locator('body').innerText()).match(/[^\n]*Continue[^\n]*/g) }; console.log(f, JSON.stringify(r.d).slice(0, 300)); }
  await p.reload(); await p.waitForTimeout(5000); R.afterReload = await used(); const r = await full('cap-reload', 'three.pdf', async () => { await btn(/^\s*All 90° right\s*$/).click(); }); R.reloadDl = r.d; console.log('reload', JSON.stringify(r.d).slice(0, 400));
 }
 if (mode === 'batch') { await find(); R.start = await used();
  await C('B01-batch', async () => { await btn(/^\s*Several files\s*$/).click(); await p.waitForTimeout(1500); R.binfo = await info(); await p.locator('input[type=file]').first().setInputFiles([TF + 'doc.pdf', TF + 'three.pdf', TF + 'rotated-inherit.pdf']); await p.waitForTimeout(3000); const i1 = await info(); await shot('B01-batch-loaded', false); const run = btn(/^\s*Rotate all \(/); const np = net.length, u0 = await used(), d0 = dls.length; if (await run.count()) await run.first().click(); await p.waitForTimeout(8000); const i2 = await info(); await shot('B01-batch-done', false); await p.waitForTimeout(4000); const i3 = await info(); R.i3 = i3; const dl = btn(/Download/i); let dd = null; if (await dl.count()) { await dl.first().click(); await p.waitForTimeout(5000); dd = await dialog(); if (dd) await esc(); } return { i1btn: i1.buttons, i2btn: i2.buttons, i2text: i2.text.slice(0, 1500), usage: u0 + '->' + await used(), posts: net.length - np, dialog: dd, downloads: dls.slice(d0).map(d => ({ name: d.name, size: fs.existsSync(d.path) ? fs.statSync(d.path).size : null, saved: d.path.replace(W, '') })) }; });
 }
 if (mode === 'mobile') { const dev = pw.devices[process.env.DEV || 'iPhone 13']; await find({ ...dev, viewport: dev.viewport }); R.start = await used();
  await C('M01', async () => { const l = await fresh(process.env.MF || 'doc.pdf'); const sw = await p.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth]); const b1 = await p.getByLabel(/^Rotate page 1 90° clockwise/).boundingBox(); await p.getByLabel(/^Rotate page 1 90° clockwise/).tap(); const v = await vals(); await shot('M01-' + (process.env.DEV || 'iPhone 13').replace(/ /g, '') + (process.env.WK ? '-wk' : ''), false); const a = await apply(); const d = await download(); return { ready: l.ready, sw, b1, v, a, d }; });
 }

 if (mode === 'extra') { await find(); R.start = await used();
  await C('A01-form-p2-annots-custom', () => full('A01', 'form.pdf', async () => { await setDelta(2, 2); }));
  await C('A02-doc-p2-annots-custom', () => full('A02', 'doc.pdf', async () => { await setDelta(2, -2); }));
 }
 if (mode === 'explore') { await open(); R.start = await used(); R.pre = await info();
  await drop('doc.pdf'); await waitReady(); await p.waitForTimeout(4000); R.loaded = await info(); await shot('X-loaded');
  await cw(2); R.after = await info(); await shot('X-cw2');
 }
 R.end = await used().catch(() => null); fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', JSON.stringify(R.tries), R.start, R.end); await b.close(); })();
