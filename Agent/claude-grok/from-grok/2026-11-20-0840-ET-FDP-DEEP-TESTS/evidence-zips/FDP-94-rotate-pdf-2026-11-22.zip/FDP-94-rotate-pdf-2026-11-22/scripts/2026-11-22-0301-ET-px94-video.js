// FDP-94: YouTube video facts + frames via the public watch page / embed (no sign-in).
const pw=require('playwright');const fs=require('fs');const O='/workspace/deep/94-rotate-pdf/video/';
(async()=>{const b=await pw.chromium.launch();const c=await b.newContext({viewport:{width:1280,height:800},locale:'en-US'});const p=await c.newPage();const R={};
await p.goto('https://www.youtube.com/watch?v=eqHPb2W0e_I',{waitUntil:'domcontentloaded',timeout:45000});await p.waitForTimeout(6000);
R.meta=await p.evaluate(()=>{const g=n=>document.querySelector(`meta[itemprop=${n}]`)?.content;return{title:document.title,duration:g('duration'),uploadDate:g('uploadDate'),desc:(window.ytInitialPlayerResponse?.videoDetails?.shortDescription||'').slice(0,2000),len:window.ytInitialPlayerResponse?.videoDetails?.lengthSeconds,views:window.ytInitialPlayerResponse?.videoDetails?.viewCount}});
const consent=p.locator('button:has-text("Reject all")');if(await consent.count())await consent.first().click().catch(()=>{});
await p.goto('https://www.youtube.com/embed/eqHPb2W0e_I?autoplay=1&mute=1&controls=0',{waitUntil:'domcontentloaded'});await p.waitForTimeout(6000);
await p.click('body').catch(()=>{});await p.waitForTimeout(3000);
const dur=await p.evaluate(()=>document.querySelector('video')?.duration||0);R.embedDuration=dur;R.frames=[];
for(const f of [0.05,0.15,0.25,0.35,0.45,0.55,0.65,0.75,0.85,0.95]){const t=dur*f;await p.evaluate(t=>{const v=document.querySelector('video');if(v){v.currentTime=t;v.pause();}},t);await p.waitForTimeout(1800);const n=O+'f'+String(Math.round(f*100)).padStart(2,'0')+'.png';await p.screenshot({path:n});R.frames.push(n);}
fs.writeFileSync(O+'video-info.json',JSON.stringify(R,null,1));console.log(JSON.stringify(R,null,1).slice(0,3000));await b.close();})();
