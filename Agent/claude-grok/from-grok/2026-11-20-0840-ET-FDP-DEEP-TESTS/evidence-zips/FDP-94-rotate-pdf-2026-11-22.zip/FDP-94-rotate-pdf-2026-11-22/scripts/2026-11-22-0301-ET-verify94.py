# verify94.py <orig> <out> <outdir> <tag> <deltas e.g. "1:90,3:-3" or "all:90">
import sys, json, re, pikepdf, fitz, pypdfium2 as pdfium, numpy as np
from PIL import Image
orig, out, od, tag, dl = sys.argv[1:6]
def rot_inh(pg):
    o=pg.obj
    while o is not None:
        if '/Rotate' in o: return int(o.Rotate)
        o=o.get('/Parent')
    return 0
def box(pg,k):
    o=pg.obj
    while o is not None:
        if k in o: return [round(float(x),1) for x in o[k]]
        o=o.get('/Parent')
    return None
def pinfo(path):
    q=pikepdf.open(path); f=fitz.open(path)
    tree={p.objgen:i+1 for i,p in enumerate(q.pages)}
    pages=[]
    for i,p in enumerate(q.pages):
        fp=f[i]; ann=[]
        for a in p.obj.get('/Annots',[]):
            st=str(a.get('/Subtype')); e={'subtype':st}
            if st=='/Link':
                dest=a.get('/Dest'); act=a.get('/A')
                if act is not None and act.get('/S')=='/URI': e['uri']=str(act.URI)
                if act is not None and act.get('/S')=='/GoTo': dest=act.get('/D')
                if isinstance(dest,pikepdf.Array) and len(dest): e['dest_page']=tree.get(dest[0].objgen,'NOT-A-PAGE-IN-THIS-FILE')
                elif dest is not None: e['dest_named']=str(dest)
            if st=='/Widget':
                t=a.get('/T') or (a.get('/Parent') or {}).get('/T'); e['field']=str(t)
            if st in ('/Text','/Highlight','/FreeText','/Ink'): e['contents']=str(a.get('/Contents',''))[:40]
            ann.append(e)
        pages.append({'page':i+1,'rotate':rot_inh(p),'mediabox':box(p,'/MediaBox'),'cropbox':box(p,'/CropBox'),'text':re.sub(r'\s+',' ',fp.get_text())[:160],'words':len(fp.get_text('words')),'annots':ann})
    # pages outside tree
    hidden=[]
    for o in q.objects:
        if isinstance(o,pikepdf.Dictionary) and o.get('/Type')=='/Page' and o.objgen not in tree: hidden.append(o.objgen)
    out={'size':__import__('os').path.getsize(path),'n':len(q.pages),'pages':pages,'hidden_pages':len(hidden)}
    try:
        out['outline']=[(t[1],t[2]) for t in f.get_toc(simple=True)]
    except Exception as ex: out['outline']=str(ex)
    af=q.Root.get('/AcroForm')
    if af is not None:
        fl=[]
        def walk(fd,pre=''):
            nm=pre+str(fd.get('/T','')); kids=fd.get('/Kids')
            if kids is not None and any('/T' in k for k in kids):
                for k in kids: walk(k,nm+'.')
            else:
                wid=[fd] if kids is None else list(kids)
                pg=[tree.get(w.P.objgen,'NOT-IN-TREE') if '/P' in w else None for w in wid]
                onp=[ i+1 for i,p in enumerate(q.pages) for a in p.obj.get('/Annots',[]) for w in wid if a.objgen==w.objgen]
                fl.append({'name':nm,'value':str(fd.get('/V',''))[:30],'widget_P':pg,'widget_on_page':onp})
        for fd in af.get('/Fields',[]): walk(fd)
        out['fields']=fl; out['has_DR']='/DR' in af; out['NeedAppearances']=bool(af.get('/NeedAppearances',False))
    out['catalog_keys']=sorted(str(k) for k in q.Root.keys()); out['docinfo']={str(k):str(v)[:40] for k,v in q.docinfo.items()}
    return out
A=pinfo(orig); B=pinfo(out)
# deltas
D={}
for part in dl.split(','):
    k,v=part.split(':')
    if k=='all':
        for i in range(1,A['n']+1): D[i]=float(v)
    else: D[int(k)]=float(v)
# render compare
po=pdfium.PdfDocument(orig); pb=pdfium.PdfDocument(out); cmp=[]
for i in range(min(A['n'],B['n'])):
    d=D.get(i+1,0.0)
    a=po[i].render(scale=0.5).to_pil().convert('L'); b=pb[i].render(scale=0.5).to_pil().convert('L')
    exp=a.rotate(-d,expand=True,fillcolor=255,resample=Image.BICUBIC)
    # ignore trial mark: mask bottom 8%
    e2=np.asarray(exp.resize(b.size),dtype=float); g=np.asarray(b,dtype=float)
    h=g.shape[0]; m=np.ones_like(g,bool); m[int(h*0.90):,:]=False
    mad=float(np.abs(e2-g)[m].mean())
    cmp.append({'page':i+1,'delta':d,'exp_size':exp.size,'got_size':b.size,'size_ratio_ok':abs(exp.size[0]/exp.size[1]-b.size[0]/b.size[1])<0.03,'mean_abs_diff':round(mad,2),'match':mad<12})
    if i<8:
        w=max(exp.size[0],b.size[0]); canvas=Image.new('L',(exp.size[0]+b.size[0]+10,max(exp.size[1],b.size[1])),128); canvas.paste(exp,(0,0)); canvas.paste(b,(exp.size[0]+10,0)); canvas.save(f'{od}/{tag}-p{i+1}-exp-vs-got.png')
R={'tag':tag,'deltas':D,'orig':A,'out':B,'render':cmp}
json.dump(R,open(f'{od}/{tag}.json','w'),indent=1,default=str)
print(tag,'size',A['size'],'->',B['size'],'pages',A['n'],B['n'],'hidden',B['hidden_pages'])
for x,y,c in zip(A['pages'],B['pages'],cmp):
    print(f" p{x['page']} rot {x['rotate']}->{y['rotate']} mb {x['mediabox']}->{y['mediabox']} cb {x['cropbox']}->{y['cropbox']} words {x['words']}->{y['words']} annots {[a['subtype'] for a in x['annots']]}->{[a.get('dest_page',a.get('field',a['subtype'])) for a in y['annots']]} render {c['mean_abs_diff']} {'OK' if c['match'] and c['size_ratio_ok'] else 'MISMATCH'}")
print(' outline', A.get('outline'),'->',B.get('outline'))
if 'fields' in A: print(' fields', [(f['name'],f['value'],f['widget_on_page']) for f in A['fields']],'->',[(f['name'],f['value'],f['widget_on_page'],f['widget_P']) for f in B.get('fields',[])], 'DR',A.get('has_DR'),B.get('has_DR'))
print(' catalog', set(A['catalog_keys'])-set(B['catalog_keys']), 'docinfo', A['docinfo'],'->',B['docinfo'])
