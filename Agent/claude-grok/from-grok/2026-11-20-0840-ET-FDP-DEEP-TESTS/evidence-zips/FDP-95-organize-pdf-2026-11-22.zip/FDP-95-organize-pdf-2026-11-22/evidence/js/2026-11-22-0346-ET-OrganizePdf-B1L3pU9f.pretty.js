import { r as n, j as r } from "./vendor-react-D01g8YgM.js";
import {
  T as ie,
  F as ce,
  P as $,
  D as de,
  R as me,
} from "./ToolPage-B4roIUf_.js";
import {
  v as ue,
  f as N,
  B as l,
  aJ as ge,
  X as he,
  aA as pe,
} from "./index-DagluEtV.js";
import { T as fe } from "./ToolInfoSection-C0Lbi6Qb.js";
import { l as be, r as xe } from "./utils-s8ucLyj8.js";
import { a as we } from "./pdfMetadata-CcxIhQF2.js";
import { C as ve } from "./operations-BlL6iX51.js";
import { U as je } from "./undo-2-S2TafmgF.js";
import { R as ye } from "./redo-2-BFojHKXB.js";
import { R as ke } from "./rotate-cw-DOa8zBeX.js";
import { C as Ne } from "./copy-CQptMDp5.js";
import { F as Ce } from "./file-plus-2-CpogWspv.js";
import { A as De } from "./arrow-down-BrnkDXiS.js";
import "./useUploadApi-Cwp1vwlT.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-CL8JsD0s.js";
import "./share-2-B34wyobX.js";
import "./workflowCta-oWYKzOWD.js";
import "./UsageAndUpgradeStrip-BiAdGTIF.js";
import "./access-BSSUf40u.js";
import "./useAdminAccess-CYp3AlSq.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CgocG3qD.js";
import "./map-pin-DvVDRebE.js";
import "./FaqSection-DsOLPaJ0.js";
import "./ToolVideoEmbed-CZwBIyFf.js";
import "./GuideLinks-BVE0aHrc.js";
import "./blog-BPnsEI_q.js";
import "./info-56I4OKVq.js";
import "./productCards-CUOqxId0.js";
import "./layers-BVDCe9zx.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-DmEVOuX4.js";
import "./chevron-up-B0wsCoBg.js";
import "./pdfFonts-CIqHAJiw.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./pageView-BQIwVYOi.js";
import "./formAppearance-TraefmEd.js";
import "./drawTextAnywhere-Dl7l_xfJ.js";
import "./ocrText-C_9cxcFa.js";
import "./ocrImage-DAAOwTV-.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./imageRecompress-eXQFDUm-.js";
import "./formatFileSize-B-JRDfN5.js";
import "./plural-FIChqbp4.js";
import "./textDiff-DxE9AzvO.js";
import "./utils-BvcV7ep8.js";
import "./decode-CE2kW_I3.js";
import "./formFill-xgtRnF-K.js";
import "./redactSearch-DQpyyh_t.js";
import "./nameDetect-DvHCRM0m.js";
const Pe = ue("ArrowUpDown", [
  ["path", { d: "m21 16-4 4-4-4", key: "f6ql7i" }],
  ["path", { d: "M17 20V4", key: "1ejh1v" }],
  ["path", { d: "m3 8 4-4 4 4", key: "11wl7u" }],
  ["path", { d: "M7 4v16", key: "1glfcx" }],
]);
function g(i, w, o, c = "") {
  const m = o === null ? " (inserted blank page)" : ` (original page ${o + 1})`;
  return `${i} ${w + 1}${m}${c}`;
}
const U = {
  what: "Reorders or removes pages from a PDF using real page thumbnails, so you can see exactly what you're changing before downloading — useful for a scanned document that came out of order, a report that needs its appendix moved, or a combined file where a few pages need to be dropped. Also handles a few lighter edits beyond pure reordering: duplicating a page, inserting a genuinely blank page, or rotating one page 90 degrees at a time — without needing the dedicated Rotate PDF tool for a single page's orientation.",
  how: `Upload a PDF, then drag any page thumbnail to reorder it, or use the up/down arrows if you'd rather not drag. Use the X to remove a page, the copy icon to duplicate one, the blank-page button (tooltip "Insert a blank page after this one") to add an empty page after it, and the rotate icon to turn a page 90 degrees. Every step can be undone (Undo or Ctrl+Z) until you download; tick pages to rotate or remove several at once, so it's safe to experiment before committing.`,
  tip: "This only changes page order, which pages are included, and light per-page edits (duplicate, blank insert, rotation) — it doesn't alter the actual content of any page. For pulling specific pages out as their own separate file, use Extract Pages & Text instead; for combining this PDF with others before reordering, start with Merge PDF; for rotating every page at once rather than one at a time, Rotate PDF is the more direct tool.",
};
let Se = 0;
const R = () => `p${Se++}`;
function Tt() {
  const [i, w] = n.useState(null),
    [o, c] = n.useState([]),
    [m, F] = n.useState([]),
    [E, h] = n.useState([]),
    [L, p] = n.useState([]),
    [B, T] = n.useState(!1),
    [K, z] = n.useState(!1),
    [j, u] = n.useState(null),
    [v, C] = n.useState(null),
    [O, D] = n.useState(null),
    [f, b] = n.useState(new Set()),
    d = n.useCallback((e) => {
      (c((t) => {
        const a = e(t);
        return a === t ? t : (h((s) => [...s, t]), p([]), a);
      }),
        u(null));
    }, []),
    P = n.useCallback(() => {
      (h((e) => {
        if (!e.length) return e;
        const t = e[e.length - 1];
        return (c((a) => (p((s) => [...s, a]), t)), e.slice(0, -1));
      }),
        u(null));
    }, []),
    y = n.useCallback(() => {
      (p((e) => {
        if (!e.length) return e;
        const t = e[e.length - 1];
        return (c((a) => (h((s) => [...s, a]), t)), e.slice(0, -1));
      }),
        u(null));
    }, []),
    M =
      o.length === m.length &&
      o.every((e, t) => e.id === m[t].id && e.rotation === 0),
    A = m.filter((e) => !o.some((t) => t.id === e.id)).length,
    k = !M,
    Z = () => {
      (c(m), h([]), p([]), b(new Set()), u(null));
    };
  n.useEffect(() => {
    if (!i) return;
    const e = (t) => {
      const a = t.target;
      (a && (a.tagName === "INPUT" || a.tagName === "TEXTAREA")) ||
        ((t.ctrlKey || t.metaKey) && t.key.toLowerCase() === "z"
          ? (t.preventDefault(), t.shiftKey ? y() : P())
          : (t.ctrlKey || t.metaKey) &&
            t.key.toLowerCase() === "y" &&
            (t.preventDefault(), y()));
    };
    return (
      window.addEventListener("keydown", e),
      () => window.removeEventListener("keydown", e)
    );
  }, [i, P, y]);
  const X = n.useCallback(async (e) => {
      const t = e[0];
      if (t) {
        (w(t), u(null), h([]), p([]), b(new Set()), T(!0));
        try {
          const a = await be(t),
            s = [];
          for (let x = 1; x <= a.numPages; x++) {
            const ne = await a.getPage(x),
              le = await xe(ne, 0.5, 0.7);
            s.push({
              id: R(),
              index: x - 1,
              thumbUrl: URL.createObjectURL(le),
              rotation: 0,
            });
          }
          (c(s), F(s));
        } catch (a) {
          (console.error("Couldn't load PDF pages:", a),
            N.error(
              "Couldn't read this PDF — it may be corrupted or password-protected",
            ),
            w(null));
        } finally {
          T(!1);
        }
      }
    }, []),
    S = (e, t) =>
      d((a) => {
        if (t < 0 || t >= a.length || e === t) return a;
        const s = [...a],
          [x] = s.splice(e, 1);
        return (s.splice(t, 0, x), s);
      }),
    _ = (e) => S(e, e - 1),
    J = (e) => S(e, e + 1),
    q = (e) => (t) => {
      (C(e), (t.dataTransfer.effectAllowed = "move"));
    },
    V = (e) => (t) => {
      (t.preventDefault(), e !== O && D(e));
    },
    G = (e) => (t) => {
      (t.preventDefault(), v !== null && v !== e && S(v, e), C(null), D(null));
    },
    H = () => {
      (C(null), D(null));
    },
    Q = (e) => d((t) => t.filter((a, s) => s !== e)),
    W = (e) =>
      d((t) => {
        const a = t[e];
        if (a.index === null) return t;
        const s = [...t];
        return (s.splice(e + 1, 0, { ...a, id: R() }), s);
      }),
    Y = (e) =>
      d((t) => {
        const a = [...t];
        return (
          a.splice(e + 1, 0, {
            id: R(),
            index: null,
            thumbUrl: null,
            rotation: 0,
          }),
          a
        );
      }),
    ee = (e) =>
      d((t) => {
        const a = [...t];
        return ((a[e] = { ...a[e], rotation: (a[e].rotation + 90) % 360 }), a);
      }),
    te = (e) =>
      b((t) => {
        const a = new Set(t);
        return (a.has(e) ? a.delete(e) : a.add(e), a);
      }),
    re = () => {
      (d((e) => e.filter((t) => !f.has(t.id))), b(new Set()));
    },
    ae = () =>
      d((e) =>
        e.map((t) =>
          f.has(t.id) && t.thumbUrl
            ? { ...t, rotation: (t.rotation + 90) % 360 }
            : t,
        ),
      ),
    se = () => d((e) => [...e].reverse()),
    oe = async () => {
      if (!i || o.length === 0) {
        N.error("At least one page has to remain in the document");
        return;
      }
      z(!0);
      try {
        const e = o.map((a) =>
            a.index === null
              ? { type: "blank" }
              : { type: "source", index: a.index, rotation: a.rotation },
          ),
          t = await ve(i, e);
        (u(t), N.success(`Saved ${o.length} page${o.length === 1 ? "" : "s"}`));
      } catch (e) {
        (console.error("Couldn't save reorganized PDF:", e),
          N.error("Something went wrong saving this PDF — try again"));
      } finally {
        z(!1);
      }
    },
    I = () => {
      (m.forEach((e) => e.thumbUrl && URL.revokeObjectURL(e.thumbUrl)),
        w(null),
        c([]),
        F([]),
        h([]),
        p([]),
        b(new Set()),
        u(null));
    };
  return r.jsxs(ie, {
    children: [
      i
        ? B
          ? r.jsx($, { message: "Loading pages..." })
          : r.jsxs("div", {
              className: "space-y-4",
              children: [
                r.jsxs("div", {
                  className:
                    "flex flex-wrap items-center justify-between gap-2",
                  children: [
                    r.jsxs("p", {
                      className: "text-sm font-medium",
                      "aria-live": "polite",
                      children: [
                        i.name,
                        " — ",
                        o.length,
                        " page",
                        o.length === 1 ? "" : "s",
                        A > 0 ? `, ${A} removed` : "",
                        k ? "" : " (no changes yet)",
                      ],
                    }),
                    r.jsxs("div", {
                      className: "flex flex-wrap gap-1",
                      children: [
                        r.jsxs(l, {
                          size: "sm",
                          variant: "ghost",
                          onClick: P,
                          disabled: !E.length,
                          title: "Undo (Ctrl+Z)",
                          children: [
                            r.jsx(je, { className: "h-3.5 w-3.5 mr-1" }),
                            " Undo",
                          ],
                        }),
                        r.jsxs(l, {
                          size: "sm",
                          variant: "ghost",
                          onClick: y,
                          disabled: !L.length,
                          title: "Redo (Ctrl+Shift+Z)",
                          children: [
                            r.jsx(ye, { className: "h-3.5 w-3.5 mr-1" }),
                            " Redo",
                          ],
                        }),
                        r.jsxs(l, {
                          size: "sm",
                          variant: "ghost",
                          onClick: se,
                          disabled: o.length < 2,
                          children: [
                            r.jsx(Pe, { className: "h-3.5 w-3.5 mr-1" }),
                            " Reverse order",
                          ],
                        }),
                        r.jsxs(l, {
                          size: "sm",
                          variant: "ghost",
                          onClick: Z,
                          disabled: !k,
                          children: [
                            r.jsx(ge, { className: "h-3.5 w-3.5 mr-1" }),
                            " Undo all changes",
                          ],
                        }),
                      ],
                    }),
                  ],
                }),
                f.size > 0 &&
                  r.jsxs("div", {
                    className:
                      "flex flex-wrap items-center gap-2 rounded-md border bg-muted/40 px-3 py-2 text-sm",
                    children: [
                      r.jsxs("span", { children: [f.size, " selected"] }),
                      r.jsx(l, {
                        size: "sm",
                        variant: "outline",
                        onClick: ae,
                        children: "Rotate",
                      }),
                      r.jsx(l, {
                        size: "sm",
                        variant: "outline",
                        onClick: re,
                        disabled: f.size >= o.length,
                        children: "Remove",
                      }),
                      r.jsx(l, {
                        size: "sm",
                        variant: "ghost",
                        onClick: () => b(new Set()),
                        children: "Clear",
                      }),
                    ],
                  }),
                r.jsx("div", {
                  className:
                    "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4",
                  children: o.map((e, t) =>
                    r.jsxs(
                      "div",
                      {
                        draggable: !0,
                        onDragStart: q(t),
                        onDragOver: V(t),
                        onDrop: G(t),
                        onDragEnd: H,
                        className: `relative rounded-lg border bg-card overflow-hidden group cursor-grab active:cursor-grabbing transition-opacity ${v === t ? "opacity-50" : ""} ${O === t && v !== t ? "border-primary border-2" : ""}`,
                        children: [
                          e.thumbUrl
                            ? r.jsx("img", {
                                src: e.thumbUrl,
                                alt:
                                  e.index !== null
                                    ? `Page ${e.index + 1}`
                                    : "Blank page",
                                className:
                                  "w-full aspect-[3/4] object-contain bg-white",
                                style: {
                                  transform: e.rotation
                                    ? `rotate(${e.rotation}deg)`
                                    : void 0,
                                },
                              })
                            : r.jsx("div", {
                                className:
                                  "w-full aspect-[3/4] bg-white border-b flex items-center justify-center",
                                children: r.jsx("span", {
                                  className: "text-xs text-muted-foreground",
                                  children: "Blank page",
                                }),
                              }),
                          r.jsxs("div", {
                            className: "absolute top-1 right-1 flex gap-1",
                            children: [
                              e.thumbUrl &&
                                r.jsx("button", {
                                  onClick: () => ee(t),
                                  className:
                                    "h-9 w-9 sm:h-7 sm:w-7 rounded-full bg-background/90 border flex items-center justify-center hover:bg-accent transition-colors",
                                  "aria-label": g("Rotate page", t, e.index),
                                  children: r.jsx(ke, {
                                    className: "h-3.5 w-3.5",
                                  }),
                                }),
                              r.jsx("button", {
                                onClick: () => Q(t),
                                className:
                                  "h-9 w-9 sm:h-7 sm:w-7 rounded-full bg-background/90 border flex items-center justify-center hover:bg-destructive hover:text-destructive-foreground transition-colors",
                                "aria-label": g("Remove page", t, e.index),
                                children: r.jsx(he, {
                                  className: "h-3.5 w-3.5",
                                }),
                              }),
                            ],
                          }),
                          r.jsx("div", {
                            className: "absolute top-1 left-1",
                            children: r.jsxs("label", {
                              className:
                                "flex items-center gap-1 text-xs px-1.5 py-0.5 rounded bg-background/90 border cursor-pointer",
                              children: [
                                r.jsx("input", {
                                  type: "checkbox",
                                  checked: f.has(e.id),
                                  onChange: () => te(e.id),
                                  "aria-label": g("Select page", t, e.index),
                                }),
                                t + 1,
                                e.index !== null && e.index !== t
                                  ? r.jsxs("span", {
                                      className: "text-muted-foreground",
                                      children: [" (was ", e.index + 1, ")"],
                                    })
                                  : null,
                              ],
                            }),
                          }),
                          r.jsxs("div", {
                            className:
                              "absolute bottom-1 left-1 right-1 flex items-center justify-between gap-1",
                            children: [
                              r.jsxs("div", {
                                className: "flex gap-1",
                                children: [
                                  e.thumbUrl &&
                                    r.jsx("button", {
                                      onClick: () => W(t),
                                      className:
                                        "h-9 w-9 sm:h-7 sm:w-7 rounded-full bg-background/90 border flex items-center justify-center hover:bg-accent",
                                      "aria-label": g(
                                        "Duplicate page",
                                        t,
                                        e.index,
                                      ),
                                      title: "Duplicate this page",
                                      children: r.jsx(Ne, {
                                        className: "h-3.5 w-3.5",
                                      }),
                                    }),
                                  r.jsx("button", {
                                    onClick: () => Y(t),
                                    className:
                                      "h-9 w-9 sm:h-7 sm:w-7 rounded-full bg-background/90 border flex items-center justify-center hover:bg-accent",
                                    "aria-label": g(
                                      "Insert blank page after",
                                      t,
                                      e.index,
                                    ),
                                    title: "Insert a blank page after this one",
                                    children: r.jsx(Ce, {
                                      className: "h-3.5 w-3.5",
                                    }),
                                  }),
                                ],
                              }),
                              r.jsxs("div", {
                                className: "flex gap-1",
                                children: [
                                  r.jsx("button", {
                                    onClick: () => _(t),
                                    disabled: t === 0,
                                    className:
                                      "h-9 w-9 sm:h-7 sm:w-7 rounded-full bg-background/90 border flex items-center justify-center disabled:opacity-30 hover:bg-accent",
                                    "aria-label": g(
                                      "Move page",
                                      t,
                                      e.index,
                                      " earlier",
                                    ),
                                    children: r.jsx(pe, {
                                      className: "h-3.5 w-3.5",
                                    }),
                                  }),
                                  r.jsx("button", {
                                    onClick: () => J(t),
                                    disabled: t === o.length - 1,
                                    className:
                                      "h-9 w-9 sm:h-7 sm:w-7 rounded-full bg-background/90 border flex items-center justify-center disabled:opacity-30 hover:bg-accent",
                                    "aria-label": g(
                                      "Move page",
                                      t,
                                      e.index,
                                      " later",
                                    ),
                                    children: r.jsx(De, {
                                      className: "h-3.5 w-3.5",
                                    }),
                                  }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      },
                      e.id,
                    ),
                  ),
                }),
                r.jsx("div", {
                  className: "flex gap-3",
                  children: K
                    ? r.jsx($, {})
                    : j
                      ? r.jsxs(r.Fragment, {
                          children: [
                            r.jsx(de, {
                              blob: j,
                              fileName: `${we(i.name)}-organized.pdf`,
                            }),
                            r.jsx(l, {
                              variant: "outline",
                              onClick: I,
                              children: "New",
                            }),
                          ],
                        })
                      : r.jsxs(r.Fragment, {
                          children: [
                            r.jsx(l, {
                              onClick: oe,
                              disabled: o.length === 0 || !k,
                              children: k
                                ? "Save changes"
                                : "No changes to save",
                            }),
                            r.jsx(l, {
                              variant: "ghost",
                              onClick: I,
                              children: "Reset",
                            }),
                          ],
                        }),
                }),
                j && r.jsx(me, { blob: j, mimeType: "application/pdf" }),
              ],
            })
        : r.jsx(ce, {
            gateAtDownload: !0,
            accept: ".pdf",
            onFiles: X,
            label: "Drop a PDF file",
            description: "Reorder or remove pages with real page previews",
          }),
      r.jsx(fe, { whatIsIt: U.what, howToUse: U.how, tip: U.tip }),
    ],
  });
}
export { Tt as default };
//# sourceMappingURL=OrganizePdf-B1L3pU9f.js.map
