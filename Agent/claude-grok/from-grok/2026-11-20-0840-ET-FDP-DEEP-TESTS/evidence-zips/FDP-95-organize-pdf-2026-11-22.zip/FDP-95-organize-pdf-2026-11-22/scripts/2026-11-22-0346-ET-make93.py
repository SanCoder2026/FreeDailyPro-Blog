# FDP-93 remove-pdf-pages test inputs (made-up data). python3 make93.py
import fitz, io, os, random, pikepdf, shutil
from PIL import Image, ImageDraw
T='testfiles/'; os.makedirs(T,exist_ok=True)
random.seed(7)
def photo(n):
    im=Image.frombytes('RGB',(500,350),random.randbytes(500*350*3)); d=ImageDraw.Draw(im); d.text((20,20),f'IMG{n}',fill='white')
    b=io.BytesIO(); im.save(b,'JPEG',quality=85); return b.getvalue()
# 1. book.pdf: 20 pages, each with "PAGE-n-SECRET" text (own font size), a unique random JPEG (~100 kB)
d=fitz.open()
for n in range(1,21):
    p=d.new_page(width=612,height=792)
    p.insert_text((72,72),f'Chapter page {n}',fontsize=20)
    p.insert_text((72,100),f'PAGE-{n}-SECRET account 4000-0000-0000-{n:04d}',fontsize=11)
    p.insert_image(fitz.Rect(72,140,540,470),stream=photo(n))
# links: p1 -> p5 (to delete), p1 -> p10 (kept), p1 -> URL; p8 -> p5
d[0].insert_link({'kind':fitz.LINK_GOTO,'from':fitz.Rect(72,500,300,520),'page':4,'to':fitz.Point(0,0)})
d[0].insert_text((72,515),'Link to page 5',fontsize=11,color=(0,0,1))
d[0].insert_link({'kind':fitz.LINK_GOTO,'from':fitz.Rect(72,530,300,550),'page':9,'to':fitz.Point(0,0)})
d[0].insert_text((72,545),'Link to page 10',fontsize=11,color=(0,0,1))
d[0].insert_link({'kind':fitz.LINK_URI,'from':fitz.Rect(72,560,300,580),'uri':'https://example.com/kept-url'})
d[0].insert_text((72,575),'example.com link',fontsize=11,color=(0,0,1))
d[7].insert_link({'kind':fitz.LINK_GOTO,'from':fitz.Rect(72,500,300,520),'page':4,'to':fitz.Point(0,0)})
d[7].insert_text((72,515),'Back to page 5',fontsize=11,color=(0,0,1))
# form fields: text on p2 (kept) and p5 (deleted)
for pg,name in [(1,'keep_name'),(4,'gone_ssn')]:
    w=fitz.Widget(); w.field_name=name; w.field_type=fitz.PDF_WIDGET_TYPE_TEXT; w.rect=fitz.Rect(72,600,300,620); w.field_value=f'{name}-VALUE'; d[pg].add_widget(w)
# TOC: chapter bookmarks; Part B (p5-7) has children p5,p6,p7; p5-only bookmark
toc=[[1,'Cover p1',1],[1,'Part A p2',2],[2,'A.1 p3',3],[1,'Part B p5',5],[2,'B.1 p6',6],[2,'B.2 p7',7],[1,'Only p5',5],[1,'Middle p10',10],[1,'Last p20',20]]
d.set_toc(toc)
d.set_metadata({'title':'Book test','author':'QA Bot','subject':'subject kept?','keywords':'k1'})
d.embfile_add('attach.txt',b'ATTACHMENT-SECRET',filename='attach.txt')
d.save('/tmp/book.pdf')
q=pikepdf.open('/tmp/book.pdf')
# named destination + bookmark using it, plus /A GoTo bookmark, page labels
from pikepdf import Name, Array, Dictionary, String
pg10=q.pages[9].obj; pg3=q.pages[2].obj
names=q.Root.get('/Names', None)
if names is None: q.Root.Names=Dictionary(); names=q.Root.Names
names.Dests=Dictionary(Names=Array([String('chap10'),Array([pg10,Name.Fit])]))
ol=q.Root.Outlines
# append a bookmark using named dest and an /A GoTo one
last=ol.Last
nb=q.make_indirect(Dictionary(Title=String('Named dest p10'),Parent=ol,Prev=last,Dest=String('chap10')))
last.Next=nb
ab=q.make_indirect(Dictionary(Title=String('Action GoTo p3'),Parent=ol,Prev=nb,A=Dictionary(S=Name.GoTo,D=Array([pg3,Name.XYZ,0,792,2]))))
nb.Next=ab; ol.Last=ab; ol.Count=int(ol.get('/Count',0))+2
q.Root.PageLabels=Dictionary(Nums=Array([0,Dictionary(S=Name.r),2,Dictionary(S=Name.D)]))
q.Root.Lang=String('en-US')
q.save(T+'book.pdf')
# 2. rotated-inherit.pdf: 6 pages; /Rotate 90 inherited from the Pages node for all, p2 explicit 180, p3 explicit 0
d=fitz.open()
for n in range(1,7):
    p=d.new_page(width=612,height=792); p.insert_text((72,100),f'ROT page {n} top-left',fontsize=24)
d.save('/tmp/r.pdf'); q=pikepdf.open('/tmp/r.pdf')
q.Root.Pages.Rotate=90
for i,pg in enumerate(q.pages):
    if '/Rotate' in pg.obj: del pg.obj['/Rotate']
q.pages[1].obj.Rotate=180; q.pages[2].obj.Rotate=0
# inherited MediaBox: move media box to Pages for page 4
q.Root.Pages.MediaBox=Array([0,0,612,792]);
if '/MediaBox' in q.pages[3].obj: del q.pages[3].obj['/MediaBox']
q.save(T+'rotated-inherit.pdf')
# 3. small 3-page and 1-page
d=fitz.open()
for n in range(1,4): d.new_page().insert_text((72,72),f'three page {n}',fontsize=20)
d.save(T+'three.pdf')
d=fitz.open(); d.new_page().insert_text((72,72),'single page',fontsize=20); d.save(T+'one.pdf')
# 4. blanks.pdf: 6 pages: content, blank, content, page-number-only, faint show-through, blank
d=fitz.open()
for kind in ['c','b','c','num','faint','b']:
    p=d.new_page()
    if kind=='c':
        for j in range(30): p.insert_text((72,80+j*20),'Body text line for blank detection test',fontsize=11)
    if kind=='num': p.insert_text((290,820),'- 4 -',fontsize=10)
    if kind=='faint':
        for j in range(30): p.insert_text((72,80+j*20),'show-through mirror text',fontsize=11,color=(0.93,0.93,0.93))
d.save(T+'blanks.pdf')
for f,src in [('enc.pdf','../92-crop-pdf/testfiles/enc.pdf'),('corrupt.pdf','../92-crop-pdf/testfiles/corrupt.pdf'),('large-300p.pdf','../92-crop-pdf/testfiles/large-300p.pdf'),('form.pdf','../92-crop-pdf/testfiles/form.pdf')]: shutil.copy(src,T+f)
print({f:os.path.getsize(T+f) for f in sorted(os.listdir(T))})
# 5. split-field.pdf: one text field "shared_id" with two widgets (kids) on p1 and p3; p3 also has "p3_secret" field; remove p3
d=fitz.open()
for n in range(1,4): d.new_page().insert_text((72,72),f'split field page {n}',fontsize=18)
w=fitz.Widget(); w.field_name='p3_secret'; w.field_type=fitz.PDF_WIDGET_TYPE_TEXT; w.rect=fitz.Rect(72,200,300,220); w.field_value='P3-FIELD-SECRET'; d[2].add_widget(w)
d.save('/tmp/sf.pdf'); q=pikepdf.open('/tmp/sf.pdf')
par=q.make_indirect(pikepdf.Dictionary(FT=pikepdf.Name.Tx, T=pikepdf.String('shared_id'), V=pikepdf.String('SHARED-VALUE'), Kids=pikepdf.Array()))
for pi in (0,2):
    wd=q.make_indirect(pikepdf.Dictionary(Type=pikepdf.Name.Annot, Subtype=pikepdf.Name.Widget, Rect=[72,100,300,120], Parent=par, P=q.pages[pi].obj, F=4))
    par.Kids.append(wd); pg=q.pages[pi].obj
    if '/Annots' not in pg: pg.Annots=pikepdf.Array()
    pg.Annots.append(wd)
q.Root.AcroForm.Fields.append(par); q.Root.AcroForm.DR=pikepdf.Dictionary(Font=pikepdf.Dictionary(Helv=pikepdf.Dictionary(Type=pikepdf.Name.Font,Subtype=pikepdf.Name.Type1,BaseFont=pikepdf.Name.Helvetica)))
q.save(T+'split-field.pdf')
# 6. blanks2.pdf: content, footer page-number at 36pt from bottom, page number at 54pt, stamp-only, blank
d=fitz.open()
for kind in ['c','num36','num54','stamp','b']:
    p=d.new_page()
    if kind=='c':
        for j in range(30): p.insert_text((72,80+j*20),'Body text line',fontsize=11)
    if kind=='num36': p.insert_text((290,842-36),'7',fontsize=10)
    if kind=='num54': p.insert_text((280,842-54),'Page 8',fontsize=10)
    if kind=='stamp': p.draw_rect(fitz.Rect(400,60,540,110),color=(0.8,0,0),width=2); p.insert_text((415,92),'RECEIVED',fontsize=16,color=(0.8,0,0))
d.save(T+'blanks2.pdf')
# 7. toc-links.pdf: 12 pages, page 1 is a clickable table of contents linking to every page; page 7 holds PII
d=fitz.open(); d.new_page().insert_text((72,60),'Contents',fontsize=20)
for n in range(2,13):
    p=d.new_page(); p.insert_text((72,72),f'Section page {n}',fontsize=18)
    if n==7: p.insert_text((72,110),'PII-PAGE-7 Jane Q Public SSN 078-05-1120',fontsize=12)
for n in range(2,13):
    d[0].insert_text((72,80+n*20),f'Go to page {n}',fontsize=12,color=(0,0,1))
    d[0].insert_link({'kind':fitz.LINK_GOTO,'from':fitz.Rect(72,68+n*20,250,84+n*20),'page':n-1,'to':fitz.Point(0,0)})
d.save(T+'toc-links.pdf')
