// FDP-95 check 20: can Professional Merge PDF do single-file organize? guest, no sign-in.
const { chromium } = require('playwright'); const fs = require('fs');
const OUT = '/workspace/deep/95-organize-pdf/live/'; const T = '/workspace/deep/95-organize-pdf/testfiles/';
(async () => { const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 1366, height: 1400 }, acceptDownloads: true }); const p = await c.newPage(); const R = {};
 await p.goto('https://www.freedailypro.com/tool/merge-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500);
 R.used = await p.evaluate(() => localStorage.getItem('fdp-usage-v1')?.replace(/dev:[^"]+/, 'dev:REDACTED'));
 await p.locator('input[type=file]').first().setInputFiles(T + 'book.pdf'); await p.waitForTimeout(4000);
 R.btns1 = await p.evaluate(() => [...document.querySelectorAll('main button')].map(e => (e.getAttribute('aria-label') || e.innerText.trim()) + (e.disabled ? ' [disabled]' : '')).filter(Boolean).slice(0, 40));
 R.text1 = await p.evaluate(() => document.querySelector('main').innerText.slice(0, 1500));
 const ar = p.getByRole('button', { name: /^Arrange all pages/ }); R.arrange = await ar.count();
 if (R.arrange) { await ar.first().click(); await p.waitForTimeout(5000); R.arrBtns = await p.evaluate(() => [...document.querySelectorAll('main button,[role=dialog] button')].map(e => e.getAttribute('aria-label') || e.innerText.trim()).filter(x => /book|page|Done|Apply|duplicate|blank|insert|reverse/i.test(x)).slice(0, 50)); }
 await p.screenshot({ path: OUT + 'cases/merge1-arrange.png', fullPage: false });
 fs.writeFileSync(OUT + 'merge1-probe.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1).slice(0, 5000)); await b.close(); })();
