// FDP-95 check 20: Merge PDF (Professional) used as a single-file organizer: book.pdf + one.pdf, Arrange: delete one.pdf p1, delete book p5, move book p20 to front. guest only.
const { chromium } = require('playwright'); const fs = require('fs');
const OUT = '/workspace/deep/95-organize-pdf/live/'; const T = '/workspace/deep/95-organize-pdf/testfiles/';
(async () => { const b = await chromium.launch(); let c, p; const R = { tries: [] };
 for (let i = 0; i < 20; i++) { c = await b.newContext({ viewport: { width: 1366, height: 1400 }, acceptDownloads: true }); p = await c.newPage(); await p.goto('https://www.freedailypro.com/tool/merge-pdf', { waitUntil: 'domcontentloaded' }); await p.waitForTimeout(4500); const u = await p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; }); R.tries.push(u); if (!u.startsWith('10/')) break; if (i < 19) await c.close(); }
 await p.locator('input[type=file]').first().setInputFiles([T + 'book.pdf', T + 'one.pdf']); await p.waitForTimeout(5000);
 await p.getByRole('button', { name: /^Arrange all pages/ }).first().click(); await p.waitForTimeout(5000);
 const del = async n => { await p.getByRole('button', { name: n }).first().click(); await p.waitForTimeout(400); };
 await del(/^Delete Page 21, one\.pdf page 1$/); await del(/^Delete Page 5, book\.pdf page 5$/);
 for (let k = 0; k < 18; k++) { const l = p.getByRole('button', { name: /book\.pdf page 20 earlier$/ }); await l.first().click(); await p.waitForTimeout(150); }
 R.order = await p.evaluate(() => [...document.querySelectorAll('main button')].map(e => e.getAttribute('aria-label') || '').filter(x => /^Delete Page/.test(x)).map(x => x.replace(/^Delete Page (\d+), (\S+) page (\d+)$/, '$1:$2#$3')).join(' '));
 const done = p.getByRole('button', { name: /^Done$/ }); if (await done.count()) { await done.first().click(); await p.waitForTimeout(800); }
 R.btns = await p.evaluate(() => [...document.querySelectorAll('main button')].map(e => (e.getAttribute('aria-label') || e.innerText.trim()) + (e.disabled ? ' [disabled]' : '')).filter(x => /merge|Merge|Add \d|Download/i.test(x)));
 const mb = p.locator('main button', { hasText: /^\s*Merge/ }).first(); R.mergeBtn = (await mb.count()) ? await mb.innerText() : null;
 if (R.mergeBtn && !(await mb.isDisabled())) { await mb.click(); await p.waitForTimeout(8000); const dl = p.locator('main button, main a', { hasText: /^\s*Download/ }).first(); if (await dl.count()) { const dp = p.waitForEvent('download', { timeout: 20000 }).catch(() => null); await dl.click(); const d = await dp; if (d) { await d.saveAs(OUT + 'dl/merge2-' + d.suggestedFilename()); R.dl = d.suggestedFilename(); } else R.dialog = await p.locator('[role=dialog]').first().innerText().catch(() => null); } }
 R.end = await p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 await p.screenshot({ path: OUT + 'cases/merge2.png' });
 fs.writeFileSync(OUT + 'merge2.json', JSON.stringify(R, null, 1)); console.log(JSON.stringify(R, null, 1).slice(0, 3000)); await b.close(); })();
