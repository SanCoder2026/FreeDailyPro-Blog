const pw=require('playwright');(async()=>{const b=await pw.chromium.launch();const p=await (await b.newContext({locale:'en-US'})).newPage();
await p.goto('https://www.youtube.com/watch?v=TZTL_wd-NJY',{waitUntil:'domcontentloaded',timeout:45000});await p.waitForTimeout(5000);
console.log(await p.evaluate(()=>window.ytInitialPlayerResponse?.storyboards?.playerStoryboardSpecRenderer?.spec||'none'));await b.close();})();
