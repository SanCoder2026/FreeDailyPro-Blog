const pw=require('playwright');(async()=>{const b=await pw.chromium.launch();const p=await (await b.newContext({locale:'de-DE'})).newPage();
for(const l of ['de','ja']){await p.goto('https://www.freedailypro.com/'+l+'/tool/organize-pdf',{waitUntil:'domcontentloaded'});await p.waitForTimeout(5000);
const r=await p.evaluate(()=>({title:document.title,lang:document.documentElement.lang,desc:document.querySelector('meta[name=description]')?.content,h1:document.querySelector('h1')?.innerText,main:document.querySelector('main').innerText.slice(0,900)}));console.log(l,JSON.stringify(r));
await p.locator('input[type=file]').first().setInputFiles('/workspace/deep/95-organize-pdf/testfiles/three.pdf');await p.waitForTimeout(3000);
console.log(l,'labels',JSON.stringify(await p.locator('main [aria-label]').evaluateAll(es=>es.map(e=>e.getAttribute('aria-label')).filter(s=>/1/.test(s)).slice(0,8))),JSON.stringify((await p.locator('main button').allInnerTexts()).filter(Boolean).slice(0,12)));
await p.screenshot({path:'/workspace/deep/95-organize-pdf/live/cases/locale-'+l+'-loaded.png'});}
await b.close()})();
