# verify95.py <orig> <out> <outdir> <tag> <plan> [needle ...]
# plan: comma list of source pages (1-based), 'B' = blank, suffix rNN = extra rotation, e.g. "3,1r90,B,1"
import sys, os, re, json, zlib, pikepdf, fitz
orig, out, od, tag, plan = sys.argv[1:6]; needles = sys.argv[6:]
P = []
for t in plan.split(','):
    if t == 'B': P.append((None, 0)); continue
    m = re.match(r'(\d+)(?:r(-?\d+))?$', t); P.append((int(m.group(1)), int(m.group(2) or 0)))
def eff_rot(o):
    while o is not None:
        if '/Rotate' in o: return int(o.Rotate) % 360
        o = o.get('/Parent')
    return 0
def box(o, k):
    while o is not None:
        if k in o: return [round(float(x), 1) for x in o[k]]
        o = o.get('/Parent')
    return None
qo, qn = pikepdf.open(orig), pikepdf.open(out); fo, fn = fitz.open(orig), fitz.open(out)
to = {p.objgen: i + 1 for i, p in enumerate(qo.pages)}; tn = {p.objgen: i + 1 for i, p in enumerate(qn.pages)}
first_out = {}
for j, (s, r) in enumerate(P):
    if s and s not in first_out: first_out[s] = j + 1
norm = lambda s: re.sub(r'\s+', ' ', s.replace('Created with FreeDailyPro.com', '')).strip()
def dest_of(a):
    d = a.get('/Dest'); act = a.get('/A')
    if act is not None and act.get('/S') == '/GoTo': d = act.get('/D')
    return d
R = {'tag': tag, 'plan': plan, 'size_orig': os.path.getsize(orig), 'size_out': os.path.getsize(out), 'pages_expected': len(P), 'pages_out': len(qn.pages), 'pages': []}
ok_all = True
for j, pg in enumerate(qn.pages):
    s, r = P[j] if j < len(P) else (None, 0)
    got = norm(fn[j].get_text())[:70]
    exp = norm(fo[s - 1].get_text())[:70] if s else ''
    e_rot = (eff_rot(qo.pages[s - 1].obj) + r) % 360 if s else 0
    row = {'out': j + 1, 'src': s or 'blank', 'text_ok': got == exp, 'got': got[:50], 'rot': eff_rot(pg.obj), 'rot_exp': e_rot, 'rot_ok': eff_rot(pg.obj) == e_rot, 'mediabox': box(pg.obj, '/MediaBox'), 'cropbox': box(pg.obj, '/CropBox'), 'links': [], 'widgets': []}
    if s:
        row['mediabox_ok'] = row['mediabox'] == box(qo.pages[s - 1].obj, '/MediaBox') and row['cropbox'] == box(qo.pages[s - 1].obj, '/CropBox')
    # links: compare with original page's links
    olinks = []
    if s:
        for a in qo.pages[s - 1].obj.get('/Annots', []):
            if a.get('/Subtype') == '/Link':
                d = dest_of(a); olinks.append(to.get(d[0].objgen) if isinstance(d, pikepdf.Array) and len(d) else ('uri' if a.get('/A') is not None and a.A.get('/S') == '/URI' else 'named'))
    glinks = []
    for a in pg.obj.get('/Annots', []):
        st = a.get('/Subtype')
        if st == '/Link':
            act = a.get('/A')
            if act is not None and act.get('/S') == '/URI':
                if 'freedailypro' in str(act.URI): continue
                glinks.append('uri'); continue
            d = dest_of(a); glinks.append(tn.get(d[0].objgen, 'NOT-A-PAGE-IN-THIS-FILE') if isinstance(d, pikepdf.Array) and len(d) else 'named')
        elif st == '/Widget':
            t = a.get('/T') or (a.get('/Parent') or {}).get('/T'); row['widgets'].append(str(t))
    row['links'] = glinks; row['links_exp'] = [first_out.get(x, 'TARGET-DELETED') if isinstance(x, int) else x for x in olinks]
    row['links_ok'] = row['links'] == row['links_exp']
    ok_all &= row['text_ok'] and row['rot_ok']
    R['pages'].append(row)
R['all_pages_ok'] = ok_all
# hidden pages
R['hidden_pages'] = []
for o in qn.objects:
    if isinstance(o, pikepdf.Dictionary) and o.get('/Type') == '/Page' and o.objgen not in tn:
        R['hidden_pages'].append(o.objgen)
R['hidden_page_count'] = len(R['hidden_pages']); R['hidden_pages'] = [str(x) for x in R['hidden_pages']]
# needles anywhere (decoded streams + strings, literal and hex) vs visible text
blob = b''
for o in qn.objects:
    try:
        if isinstance(o, pikepdf.Stream): blob += o.read_bytes() + b'\n'
        elif isinstance(o, (pikepdf.Dictionary, pikepdf.Array)): blob += bytes(o.unparse()) + b'\n'
    except Exception: pass
vis = ' '.join(fn[i].get_text() for i in range(len(fn))) + ' '.join(str(w.field_value) for p in fn for w in (p.widgets() or []))
R['needles'] = {n: {'visible': n in vis, 'anywhere': (n.encode() in blob) or (n.encode().hex().upper().encode() in blob.upper())} for n in needles}
R['needles_hidden_only'] = [n for n, v in R['needles'].items() if v['anywhere'] and not v['visible']]
# outline
def outl(q, tmap):
    res = []
    try:
        names = {}
        if '/Names' in q.Root and '/Dests' in q.Root.Names:
            nt = pikepdf.NameTree(q.Root.Names.Dests)
            for k, v in nt.items(): names[k] = v
        def walk(o, depth):
            while o is not None:
                d = o.get('/Dest') or ((o.get('/A') or {}).get('/D'))
                if isinstance(d, (pikepdf.String, pikepdf.Name)): d = names.get(str(d).lstrip('/'))
                if isinstance(d, pikepdf.Dictionary): d = d.get('/D')
                tgt = tmap.get(d[0].objgen, 'DEAD') if isinstance(d, pikepdf.Array) and len(d) else None
                res.append(('  ' * depth + str(o.Title), tgt, str(d[1]) if isinstance(d, pikepdf.Array) and len(d) > 1 else None))
                if '/First' in o: walk(o.First, depth + 1)
                o = o.get('/Next')
        if '/Outlines' in q.Root and '/First' in q.Root.Outlines: walk(q.Root.Outlines.First, 0)
    except Exception as e: res.append(('ERR ' + str(e), None, None))
    return res
oo = outl(qo, to); on = outl(qn, tn)
R['outline_orig'] = oo; R['outline_out'] = on
R['outline_expected'] = [(t, first_out.get(g, 'TARGET-DELETED') if isinstance(g, int) else g, k) for t, g, k in oo]
# fields
af = qn.Root.get('/AcroForm'); R['fields'] = []
if af is not None:
    for f in af.get('/Fields', []):
        kids = f.get('/Kids'); ws = [f] if kids is None else list(kids)
        R['fields'].append({'name': str(f.get('/T')), 'value': str(f.get('/V', ''))[:30], 'widget_pages': [tn.get(w.P.objgen, 'NOT-IN-TREE') if '/P' in w else None for w in ws]})
    R['has_DR'] = '/DR' in af; R['NeedAppearances'] = bool(af.get('/NeedAppearances', False))
afo = qo.Root.get('/AcroForm'); R['fields_orig'] = [str(f.get('/T')) for f in afo.get('/Fields', [])] if afo is not None else []
R['catalog_lost'] = sorted(set(map(str, qo.Root.keys())) - set(map(str, qn.Root.keys())))
R['docinfo_out'] = {str(k): str(v)[:40] for k, v in qn.docinfo.items()}
json.dump(R, open(f'{od}/{tag}.json', 'w'), indent=1, default=str)
print(tag, 'size', R['size_orig'], '->', R['size_out'], 'pages', R['pages_out'], '/', R['pages_expected'], 'all_pages_ok', ok_all, 'hidden', R['hidden_page_count'])
for r in R['pages'][:25]:
    bad = [k for k in ('text_ok', 'rot_ok', 'links_ok', 'mediabox_ok') if r.get(k) is False]
    print(f" out{r['out']} src {r['src']} rot {r['rot']}/{r['rot_exp']} links {r['links']} exp {r['links_exp']} widgets {r['widgets']} {'BAD:' + ','.join(bad) if bad else 'ok'}")
print(' outline out', on); print(' outline exp', R['outline_expected'])
print(' fields', R['fields'], 'orig', R['fields_orig'])
print(' needles', R['needles'], 'HIDDEN-ONLY', R['needles_hidden_only'])
print(' catalog lost', R['catalog_lost'])
