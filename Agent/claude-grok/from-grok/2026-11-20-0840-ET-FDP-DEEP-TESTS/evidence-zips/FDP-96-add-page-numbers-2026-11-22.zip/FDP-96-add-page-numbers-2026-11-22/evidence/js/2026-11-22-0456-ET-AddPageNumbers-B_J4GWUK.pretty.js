import { r as a, j as e } from "./vendor-react-D01g8YgM.js";
import { T as se } from "./ToolWithSidebar-DStt-BwB.js";
import { F as ae, P as oe, D as ne, R as ie } from "./ToolPage-B4roIUf_.js";
import { e as l, I as g, B as y, f as D } from "./index-DagluEtV.js";
import { C as le } from "./checkbox-CWnO1vfW.js";
import { S as P, a as F, b as C, c as I, d as T } from "./select-Ch_aMWbT.js";
import { m as k, n as E, o as me } from "./operations-BlL6iX51.js";
import { a as $ } from "./pdfMetadata-CcxIhQF2.js";
import { B as pe, a as ce } from "./BatchRunner-Ci6bVLGm.js";
import { u as j } from "./useSessionState-BLsNNse9.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./CollapsibleText-DmEVOuX4.js";
import "./chevron-up-B0wsCoBg.js";
import "./useUploadApi-Cwp1vwlT.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-CL8JsD0s.js";
import "./share-2-B34wyobX.js";
import "./copy-CQptMDp5.js";
import "./workflowCta-oWYKzOWD.js";
import "./UsageAndUpgradeStrip-BiAdGTIF.js";
import "./access-BSSUf40u.js";
import "./useAdminAccess-CYp3AlSq.js";
import "./InstallToolButton-CgocG3qD.js";
import "./map-pin-DvVDRebE.js";
import "./FaqSection-DsOLPaJ0.js";
import "./ToolVideoEmbed-CZwBIyFf.js";
import "./GuideLinks-BVE0aHrc.js";
import "./blog-BPnsEI_q.js";
import "./info-56I4OKVq.js";
import "./productCards-CUOqxId0.js";
import "./layers-BVDCe9zx.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./index-DhOoIDuZ.js";
import "./index-BdQq_4o_.js";
import "./pdfFonts-CIqHAJiw.js";
import "./index-BRvxULIc.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./fontkit.es-DA-3qwB1.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./pageView-BQIwVYOi.js";
import "./formAppearance-TraefmEd.js";
import "./drawTextAnywhere-Dl7l_xfJ.js";
import "./ocrText-C_9cxcFa.js";
import "./ocrImage-DAAOwTV-.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./utils-s8ucLyj8.js";
import "./imageRecompress-eXQFDUm-.js";
import "./formatFileSize-B-JRDfN5.js";
import "./plural-FIChqbp4.js";
import "./textDiff-DxE9AzvO.js";
import "./utils-BvcV7ep8.js";
import "./decode-CE2kW_I3.js";
import "./formFill-xgtRnF-K.js";
import "./redactSearch-DQpyyh_t.js";
import "./nameDetect-DvHCRM0m.js";
import "./batch-Bbh00IAr.js";
import "./trash-2-DpHY4NWT.js";
import "./square-ClncwSrJ.js";
function de(o, c) {
  const m =
    "Start at is the number printed on the first page that gets a number, and the numbers then count up over the numbered pages only";
  return o.trim()
    ? `${m}. With the range “${o.trim()}”, the first page in that range gets the Start at number; pages outside it get none.`
    : c
      ? `${m}. With the first page skipped, page 2 gets the Start at number.`
      : `${m}. With every page numbered, page 1 gets the Start at number.`;
}
const M = {
    what: `Adds page numbers to every page of a PDF, with a choice of position, format, and starting number. Useful for anything that's going to be printed and bound, referenced by page ("see page 12"), or submitted somewhere that expects numbered pages — a court filing, a thesis, a report — since PDFs don't have page numbers by default unless the original document was formatted with them.`,
    tip: 'Starting from a number other than 1 is useful when this PDF will be bound together with other documents later and needs to continue their numbering — a common case is a set of appendices that need to keep counting from where the main document left off, rather than each restarting at page 1. Skipping the first page keeps a cover or title page unnumbered while the rest of the document still counts correctly starting from "1" on the first real content page.',
  },
  _ = {
    "bottom-center": "Bottom Center",
    "bottom-right": "Bottom Right",
    "bottom-left": "Bottom Left",
    "top-center": "Top Center",
    "top-right": "Top Right",
    "top-left": "Top Left",
  },
  V = {
    plain: "1, 2, 3...",
    "page-of-total": "Page 1 of 10",
    prefixed: "Custom prefix",
  },
  W = {
    arabic: "1, 2, 3",
    roman: "i, ii, iii",
    ROMAN: "I, II, III",
    alpha: "a, b, c",
    ALPHA: "A, B, C",
  };
function vt() {
  const [o, c] = a.useState(null),
    [m, H] = j("pn-position", "bottom-center"),
    [d, Y] = a.useState("1"),
    [n, U] = j("pn-format", "plain"),
    [v, Z] = a.useState("Page "),
    [f, q] = a.useState(!1),
    [b, A] = a.useState(""),
    [u, G] = j("pn-style", "arabic"),
    [O, J] = j("pn-size", "10"),
    [S, K] = a.useState(""),
    [N, i] = a.useState(null),
    [Q, B] = a.useState(!1),
    [x, s] = a.useState(null),
    [L, X] = a.useState(!1),
    ee = a.useCallback((t) => {
      (c(t[0] || null), s(null), A(""), i(null));
    }, []),
    w = () => {
      const t = parseInt(d, 10);
      if (!Number.isFinite(t) || t < 1)
        return { error: "The starting number has to be 1 or higher" };
      const r = Number(O);
      if (!Number.isFinite(r) || r < 6 || r > 48)
        return { error: "Type size has to be between 6 and 48" };
      const p = n === "page-of-total" && S.trim() ? parseInt(S, 10) : void 0;
      return p !== void 0 && (!Number.isFinite(p) || p < 1)
        ? { error: "The total has to be a whole number of 1 or more" }
        : { start: t, size: r, totalOverride: p };
    },
    z = (t, r) => ({
      format: n,
      prefix: n === "prefixed" ? v : void 0,
      skipFirstPage: f,
      pageRange: b.trim() || void 0,
      style: u,
      fontSize: t,
      totalOverride: r,
    }),
    te = async () => {
      if (!o) return;
      const t = w();
      if ("error" in t) {
        i(t.error);
        return;
      }
      const { start: r, size: p, totalOverride: re } = t;
      (i(null), B(!0));
      try {
        const h = await E(o, m, r, z(p, re));
        (s(h), D.success("Page numbers added"));
      } catch (h) {
        (console.error("Couldn't add page numbers:", h),
          h instanceof me
            ? i(h.message)
            : D.error(
                "Couldn't process this PDF — it may be corrupted or password-protected",
              ));
      } finally {
        B(!1);
      }
    },
    R = e.jsxs("div", {
      className: "space-y-4",
      children: [
        e.jsxs("div", {
          className: "flex gap-4 flex-wrap",
          children: [
            e.jsxs("div", {
              children: [
                e.jsx(l, { children: "Position" }),
                e.jsxs(P, {
                  value: m,
                  onValueChange: (t) => {
                    (H(t), s(null));
                  },
                  children: [
                    e.jsx(F, { className: "w-44", children: e.jsx(C, {}) }),
                    e.jsx(I, {
                      children: Object.keys(_).map((t) =>
                        e.jsx(T, { value: t, children: _[t] }, t),
                      ),
                    }),
                  ],
                }),
              ],
            }),
            e.jsxs("div", {
              children: [
                e.jsx(l, { children: "Format" }),
                e.jsxs(P, {
                  value: n,
                  onValueChange: (t) => {
                    (U(t), s(null));
                  },
                  children: [
                    e.jsx(F, { className: "w-40", children: e.jsx(C, {}) }),
                    e.jsx(I, {
                      children: Object.keys(V).map((t) =>
                        e.jsx(T, { value: t, children: V[t] }, t),
                      ),
                    }),
                  ],
                }),
              ],
            }),
            e.jsxs("div", {
              children: [
                e.jsx(l, { children: "Number style" }),
                e.jsxs(P, {
                  value: u,
                  onValueChange: (t) => {
                    (G(t), s(null));
                  },
                  children: [
                    e.jsx(F, { className: "w-32", children: e.jsx(C, {}) }),
                    e.jsx(I, {
                      children: Object.keys(W).map((t) =>
                        e.jsx(T, { value: t, children: W[t] }, t),
                      ),
                    }),
                  ],
                }),
              ],
            }),
            e.jsxs("div", {
              children: [
                e.jsx(l, { htmlFor: "pn-start", children: "Start at" }),
                e.jsx(g, {
                  id: "pn-start",
                  type: "number",
                  min: 1,
                  className: "w-24",
                  "aria-describedby": "pn-start-help",
                  value: d,
                  onChange: (t) => {
                    (Y(t.target.value), s(null), i(null));
                  },
                }),
              ],
            }),
            e.jsxs("div", {
              children: [
                e.jsx(l, { htmlFor: "pn-size", children: "Size (pt)" }),
                e.jsx(g, {
                  id: "pn-size",
                  type: "number",
                  min: 6,
                  max: 48,
                  className: "w-20",
                  value: O,
                  onChange: (t) => {
                    (J(t.target.value), s(null), i(null));
                  },
                }),
              ],
            }),
            n === "page-of-total" &&
              e.jsxs("div", {
                children: [
                  e.jsx(l, {
                    htmlFor: "pn-total",
                    children: "Total pages (“of Y”)",
                  }),
                  e.jsx(g, {
                    id: "pn-total",
                    type: "number",
                    min: 1,
                    className: "w-28",
                    placeholder: "Automatic",
                    value: S,
                    onChange: (t) => {
                      (K(t.target.value), s(null), i(null));
                    },
                  }),
                ],
              }),
          ],
        }),
        e.jsx("p", {
          className: "text-xs text-muted-foreground",
          id: "pn-start-help",
          children: de(b, f),
        }),
        e.jsxs("p", {
          className: "text-xs text-muted-foreground",
          children: [
            "Preview of the first number: ",
            e.jsx("span", {
              className: "font-mono",
              children:
                n === "page-of-total"
                  ? `Page ${k(Math.max(1, parseInt(d, 10) || 1), u)} of …`
                  : n === "prefixed"
                    ? `${v}${k(Math.max(1, parseInt(d, 10) || 1), u)}`
                    : k(Math.max(1, parseInt(d, 10) || 1), u),
            }),
          ],
        }),
        n === "prefixed" &&
          e.jsxs("div", {
            className: "max-w-xs",
            children: [
              e.jsx(l, { children: "Prefix (before the number)" }),
              e.jsx(g, {
                "aria-label": "Prefix (before the number)",
                value: v,
                onChange: (t) => {
                  (Z(t.target.value), s(null));
                },
                placeholder: "Page ",
              }),
            ],
          }),
        e.jsxs("div", {
          className: "max-w-xs",
          children: [
            e.jsx(l, { children: "Only number these pages (optional)" }),
            e.jsx(g, {
              "aria-label": "Only number these pages (optional)",
              value: b,
              onChange: (t) => {
                (A(t.target.value), s(null), i(null));
              },
              "aria-invalid": !!N,
              placeholder: "Leave blank for every page (e.g. 2-10)",
              disabled: f,
            }),
          ],
        }),
        e.jsxs("label", {
          className: "flex items-center gap-2 text-sm cursor-pointer",
          children: [
            e.jsx(le, {
              checked: f,
              onCheckedChange: (t) => {
                (q(t === !0), s(null));
              },
              disabled: !!b.trim(),
            }),
            "Skip the first page (e.g. a cover or title page)",
          ],
        }),
      ],
    });
  return e.jsxs(se, {
    toolId: "add-page-numbers",
    categoryId: "pdf-tools",
    whatItDoes: M.what,
    proTip: M.tip,
    children: [
      e.jsx(pe, { batch: L, onChange: X }),
      L
        ? e.jsx(ce, {
            accept: ".pdf",
            noun: "PDF",
            zipName: "numbered-pdfs.zip",
            runLabel: "Add page numbers",
            check: () => {
              const t = w();
              return "error" in t ? t.error : null;
            },
            process: async (t) => {
              const r = w();
              if ("error" in r) throw new Error(r.error);
              return {
                blob: await E(t, m, r.start, z(r.size, r.totalOverride)),
                fileName: `${$(t.name)}-numbered.pdf`,
              };
            },
            children: R,
          })
        : o
          ? e.jsxs("div", {
              className: "space-y-4",
              children: [
                e.jsx("div", {
                  className: "p-4 rounded-lg border bg-card",
                  children: e.jsx("p", {
                    className: "text-sm font-medium",
                    children: o.name,
                  }),
                }),
                R,
                N &&
                  e.jsx("p", {
                    role: "alert",
                    className: "text-sm text-destructive",
                    children: N,
                  }),
                e.jsx("div", {
                  className: "flex gap-3",
                  children: Q
                    ? e.jsx(oe, {})
                    : x
                      ? e.jsxs(e.Fragment, {
                          children: [
                            e.jsx(ne, {
                              blob: x,
                              fileName: `${$(o.name)}-numbered.pdf`,
                            }),
                            e.jsx(y, {
                              variant: "outline",
                              onClick: () => {
                                (c(null), s(null));
                              },
                              children: "New",
                            }),
                          ],
                        })
                      : e.jsxs(e.Fragment, {
                          children: [
                            e.jsx(y, {
                              onClick: te,
                              children: "Add Page Numbers",
                            }),
                            e.jsx(y, {
                              variant: "ghost",
                              onClick: () => c(null),
                              children: "Reset",
                            }),
                          ],
                        }),
                }),
                x && e.jsx(ie, { blob: x, mimeType: "application/pdf" }),
              ],
            })
          : e.jsx(ae, {
              gateAtDownload: !0,
              accept: ".pdf",
              onFiles: ee,
              label: "Drop a PDF file",
              description: "Add page numbers to every page",
            }),
    ],
  });
}
export { vt as default };
//# sourceMappingURL=AddPageNumbers-B_J4GWUK.js.map
