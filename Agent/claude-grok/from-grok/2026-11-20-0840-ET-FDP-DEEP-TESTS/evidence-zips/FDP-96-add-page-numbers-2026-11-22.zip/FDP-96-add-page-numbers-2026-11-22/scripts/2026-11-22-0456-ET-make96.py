# FDP-96 test files (all made up). python3 make96.py  -> testfiles/
import fitz, pikepdf
from pikepdf import Name, Array, Dictionary
T='testfiles/'
# 1 mixed.pdf: 6 sizes; links p1->p4 + URL; text field p2; checkbox p3; highlight p5; XYZ bookmarks; PageLabels + Lang added below
sizes=[('Letter',612,792),('A4',595.3,841.9),('Letter-landscape',792,612),('A5',419.5,595.3),('Tabloid',792,1224),('Small-3x5in',216,360)]
d=fitz.open()
for i,(n,w,h) in enumerate(sizes):
    p=d.new_page(width=w,height=h); p.insert_text((36,60),f'MIXED page {i+1} {n} {w}x{h}',fontsize=10)
    p.insert_text((36,90),'Body text that must stay searchable.',fontsize=9)
d[0].insert_text((36,120),'Go to page 4',fontsize=10,color=(0,0,1))
d[0].insert_link({'kind':fitz.LINK_GOTO,'from':fitz.Rect(36,108,140,124),'page':3,'to':fitz.Point(0,0)})
d[0].insert_link({'kind':fitz.LINK_URI,'from':fitz.Rect(36,130,200,146),'uri':'https://example.com/mixed'})
w=fitz.Widget(); w.field_name='mixed_name'; w.field_type=fitz.PDF_WIDGET_TYPE_TEXT; w.rect=fitz.Rect(36,150,250,170); w.field_value='MIXED-VALUE'; d[1].add_widget(w)
w=fitz.Widget(); w.field_name='mixed_ok'; w.field_type=fitz.PDF_WIDGET_TYPE_CHECKBOX; w.rect=fitz.Rect(36,150,52,166); w.field_value=True; d[2].add_widget(w)
d[4].add_highlight_annot(d[4].search_for('Body text')[0])
d.set_toc([[1,f'Size {i+1}',i+1] for i in range(6)])
d.save(T+'mixed.pdf')
q=pikepdf.open(T+'mixed.pdf',allow_overwriting_input=True)
q.Root.PageLabels=q.make_indirect(Dictionary(Nums=Array([0,Dictionary(S=Name.r),2,Dictionary(S=Name.D)])))
q.Root.Lang=pikepdf.String('en-US'); q.save(T+'mixed.pdf')
# 2 rotated.pdf: Letter pages with /Rotate 0, 90, 180, 270, -90, 450 (non-normalised = 90)
d=fitz.open()
for i in range(6):
    p=d.new_page(width=612,height=792); p.insert_text((72,72),f'ROT page {i+1} stored-top-left',fontsize=12); p.insert_text((72,400),'Rotated test body',fontsize=12)
d.save(T+'rotated.pdf')
q=pikepdf.open(T+'rotated.pdf',allow_overwriting_input=True)
for pg,r in zip(q.pages,[0,90,180,270,-90,450]): pg.obj.Rotate=r
q.save(T+'rotated.pdf')
# 3 crop-offset.pdf: p1 inset CropBox; p2 MediaBox at 50,50 with offset CropBox; p3 = p2 + /Rotate 90; p4 negative-origin MediaBox; p5 offset CropBox + /Rotate 270; text "EDGE-OUTSIDE-CROP" outside each crop
d=fitz.open()
for i in range(5):
    p=d.new_page(width=612,height=792); p.insert_text((5,15),'EDGE-OUTSIDE-CROP',fontsize=8); p.insert_text((200,400),f'CROP page {i+1}',fontsize=14)
d.save(T+'crop-offset.pdf')
q=pikepdf.open(T+'crop-offset.pdf',allow_overwriting_input=True)
P=q.pages
P[0].obj.CropBox=Array([100,100,500,700])
P[1].obj.MediaBox=Array([50,50,662,842]); P[1].obj.CropBox=Array([120,150,560,760])
P[2].obj.MediaBox=Array([50,50,662,842]); P[2].obj.CropBox=Array([120,150,560,760]); P[2].obj.Rotate=90
P[3].obj.MediaBox=Array([-200,-300,412,492])
P[4].obj.CropBox=Array([80,120,540,700]); P[4].obj.Rotate=270
q.save(T+'crop-offset.pdf')
print('ok')
