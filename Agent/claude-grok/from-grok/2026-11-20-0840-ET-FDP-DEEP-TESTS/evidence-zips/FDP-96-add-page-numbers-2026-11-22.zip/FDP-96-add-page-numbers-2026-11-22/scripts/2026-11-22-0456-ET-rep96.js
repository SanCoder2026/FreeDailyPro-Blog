// FDP-96 CODE REPLICA (not the live site): re-implements operations pn() + pageView p() from
// assets/operations-BlL6iX51.js / pageView-BQIwVYOi.js with npm pdf-lib, Latin (Helvetica) path only, no trial mark.
// Used only to predict geometry while every guest profile was at 10/10; live outputs replace it after the reset.
// node rep96.js <in.pdf> <out.pdf> '<json opts: position,start,format,prefix,skipFirstPage,pageRange,style,fontSize,totalOverride>'
const { PDFDocument, StandardFonts, rgb, degrees } = require('pdf-lib'); const fs = require('fs');
const yt = (e, t = 'arabic') => { if (t === 'arabic' || e < 1) return String(e); if (t === 'roman' || t === 'ROMAN') { const n = [[1e3, 'm'], [900, 'cm'], [500, 'd'], [400, 'cd'], [100, 'c'], [90, 'xc'], [50, 'l'], [40, 'xl'], [10, 'x'], [9, 'ix'], [5, 'v'], [4, 'iv'], [1, 'i']]; let r = e, i = ''; for (const [f, c] of n) for (; r >= f;) { i += c; r -= f; } return t === 'ROMAN' ? i.toUpperCase() : i; } let o = '', a = e; for (; a > 0;) { a--; o = String.fromCharCode(97 + (a % 26)) + o; a = Math.floor(a / 26); } return t === 'ALPHA' ? o.toUpperCase() : o; };
const view = (h) => { const i = h.getCropBox(), c = (((Math.round(h.getRotation().angle / 90) * 90) % 360) + 360) % 360, { x: r, y: n, width: t, height: e } = i, s = c === 90 || c === 270; return { width: s ? e : t, height: s ? t : e, rotation: c, toStored(o, a) { switch (c) { case 90: return { x: r + (t - a), y: n + o }; case 180: return { x: r + (t - o), y: n + (e - a) }; case 270: return { x: r + a, y: n + (e - o) }; default: return { x: r + o, y: n + a }; } } }; };
const rangeParse = (s, n) => { const set = new Set(); for (const part of s.split(',')) { const m = part.trim().match(/^(\d+)(?:-(\d+))?$/); if (!m) throw new Error('bad range'); const a = +m[1], b = m[2] ? +m[2] : a; for (let k = a; k <= b; k++) if (k >= 1 && k <= n) set.add(k - 1); } return set; };
(async () => { const [inp, out, js] = process.argv.slice(2); const o = Object.assign({ position: 'bottom-center', start: 1 }, JSON.parse(js || '{}'));
 const { format = 'plain', prefix = '', skipFirstPage = false, fontSize = 10, style = 'arabic' } = o; const margin = 28;
 const d = await PDFDocument.load(fs.readFileSync(inp)); const font = await d.embedFont(StandardFonts.Helvetica); const pages = d.getPages();
 const O = o.pageRange ? rangeParse(o.pageRange, pages.length) : new Set(pages.map((_, j) => j).filter(j => !(skipFirstPage && j === 0)));
 let D = o.start; const P = O.size;
 for (let M = 0; M < pages.length; M++) { const j = pages[M]; if (!O.has(M)) continue; const I = yt(D, style);
  const A = format === 'page-of-total' ? `Page ${I} of ${o.totalOverride !== undefined ? yt(o.totalOverride, style) : yt(o.start + P - 1, style)}` : format === 'prefixed' ? `${prefix}${I}` : I; D++;
  const x = view(j), R = x.width, _ = x.height, L = font.widthOfTextAtSize(A, fontSize), F = o.position.startsWith('top') ? _ - margin : margin;
  const B = o.position.endsWith('center') ? R / 2 - L / 2 : o.position.endsWith('right') ? R - margin - L : margin;
  const { x: z, y: V } = x.toStored(B, F); j.drawText(A, { x: z, y: V, size: fontSize, font, color: rgb(.35, .35, .35), rotate: degrees(x.rotation) }); }
 fs.writeFileSync(out, await d.save()); console.log('wrote', out); })();
