# verify96.py <orig> <out> <outdir> <tag> <position> <expected per page, '|' separated, '-' = no number>
# Checks: number is real text (and exact string), where it sits in the VISIBLE page (rotation + CropBox applied),
# that it reads upright, that it is inside the visible area (PDFium render diff), plus links, fields, bookmarks,
# hidden pages, catalog keys and added fonts/images.
import sys, os, json, re, collections, pikepdf, fitz, pypdfium2 as pdfium, numpy as np
from PIL import Image
orig, out, od, tag, pos, exps = sys.argv[1:7]; os.makedirs(od, exist_ok=True)
EXP = exps.split('|')
fo, fn = fitz.open(orig), fitz.open(out)
po, pn = pdfium.PdfDocument(orig), pdfium.PdfDocument(out)
qo, qn = pikepdf.open(orig), pikepdf.open(out)
MARK = 'Created with FreeDailyPro.com'
def words(pg):
    return [w for w in pg.get_text('words') if w[4] not in ('Created', 'with', 'FreeDailyPro.com')]
R = {'tag': tag, 'position': pos, 'pages': [], 'size_orig': os.path.getsize(orig), 'size_out': os.path.getsize(out)}
ok_all = True
for i in range(len(fn)):
    a, b = fo[i], fn[i]
    exp = EXP[i] if i < len(EXP) else '-'
    ow = words(a)
    def is_old(w):
        return any(x[4] == w[4] and abs(x[0] - w[0]) < 2 and abs(x[1] - w[1]) < 2 for x in ow)
    new = [w for w in words(b) if not is_old(w)]
    rmx = b.rotation_matrix
    def vkey(w):
        r_ = fitz.Rect(w[:4]) * rmx; return (round(r_.y0 / 4), r_.x0)
    got = ' '.join(w[4] for w in sorted(new, key=vkey))
    row = {'page': i + 1, 'rot': b.rotation, 'visible_wh': [round(b.rect.width), round(b.rect.height)], 'exp': exp, 'text_got': got, 'text_ok': (got == exp) if exp != '-' else (got == '')}
    # visible geometry of the new text
    if new:
        rm = b.rotation_matrix
        r = fitz.Rect()
        for w in new: r |= fitz.Rect(w[:4]) * rm
        W, H = b.rect.width, b.rect.height
        row['bbox_visible'] = [round(v, 1) for v in r]
        row['from_bottom'] = round(H - r.y1, 1); row['from_top'] = round(r.y0, 1); row['from_left'] = round(r.x0, 1); row['from_right'] = round(W - r.x1, 1)
        row['center_dx'] = round((r.x0 + r.x1) / 2 - W / 2, 1)
        vpos = ('top' if r.y1 < H / 2 else 'bottom') + '-' + ('center' if abs(row['center_dx']) < 15 else ('left' if r.x1 < W / 2 else 'right'))
        row['pos_got'] = vpos; row['pos_ok'] = vpos == pos
        # reading direction in the visible page
        dirs = []
        for blk in b.get_text('dict')['blocks']:
            for ln in blk.get('lines', []):
                t = ''.join(s['text'] for s in ln['spans'])
                if t.strip() and MARK not in t and any(fitz.Rect(ln['bbox']).intersects(fitz.Rect(w[:4])) for w in new):
                    dx, dy = ln['dir']; v = fitz.Point(dx, dy) * fitz.Matrix(rm.a, rm.b, rm.c, rm.d, 0, 0)
                    dirs.append((round(v.x, 2), round(v.y, 2)))
        row['dir_visible'] = dirs[:2]; row['upright'] = bool(dirs) and all(abs(x - 1) < 0.05 and abs(y) < 0.05 for x, y in dirs)
    # render diff (visible area only), excluding the trial-mark corner region detection by reporting all diff boxes
    s = 72 / 72
    A = np.asarray(po[i].render(scale=1).to_pil().convert('L'), dtype=np.int16)
    B = np.asarray(pn[i].render(scale=1).to_pil().convert('L'), dtype=np.int16)
    if A.shape == B.shape:
        D = np.abs(A - B) > 40
        H_, W_ = D.shape
        # remove the trial mark area (bottom-right badge) by finding the mark's words in the output
        for w in b.get_text('words'):
            if w[4] in ('Created', 'with', 'FreeDailyPro.com'):
                r = fitz.Rect(w[:4]) * b.rotation_matrix
                D[max(0, int(r.y0) - 4):int(r.y1) + 4, max(0, int(r.x0) - 20):int(r.x1) + 6] = False
        ys, xs = np.nonzero(D)
        if len(ys):
            row['render_diff_bbox'] = [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())]
            row['render_diff_px'] = int(len(ys))
            if exp != '-':
                Image.fromarray(np.uint8(np.clip(255 - (B - 0), 0, 255))).crop((max(0, xs.min() - 30), max(0, ys.min() - 20), min(W_, xs.max() + 30), min(H_, ys.max() + 20))).save(f'{od}/{tag}-p{i+1}-number.png')
        else:
            row['render_diff_bbox'] = None
        row['visible_in_render'] = bool(len(ys))
    else:
        row['render_shape_changed'] = [A.shape, B.shape]
    # images / fonts added
    def res(q, k):
        r_ = q.pages[i].obj.get('/Resources', {}); x = r_.get(k, {}) if r_ is not None else {}
        return set(str(n) for n in (x.keys() if x is not None else []))
    row['xobjects_added'] = sorted(res(qn, '/XObject') - res(qo, '/XObject'))
    row['fonts_added'] = sorted(res(qn, '/Font') - res(qo, '/Font'))
    row['content_untouched_text'] = all(w in [x[4] for x in words(b)] for w in [x[4] for x in words(a)])
    if exp != '-':
        ok = row['text_ok'] and row.get('pos_ok', False) and row.get('upright', False) and row.get('visible_in_render', False)
    else:
        ok = row['text_ok']
    row['ok'] = ok; ok_all &= ok
    R['pages'].append(row)
R['all_ok'] = ok_all
# structure kept?
tn = {p.objgen: k + 1 for k, p in enumerate(qn.pages)}; to = {p.objgen: k + 1 for k, p in enumerate(qo.pages)}
def links(q, tmap):
    L = []
    for k, p in enumerate(q.pages):
        for an in p.obj.get('/Annots', []):
            if an.get('/Subtype') == '/Link':
                A = an.get('/A'); d = an.get('/Dest')
                if A is not None and A.get('/S') == '/URI':
                    if 'freedailypro' in str(A.URI): continue
                    L.append((k + 1, 'uri', str(A.URI)))
                else:
                    if A is not None and A.get('/S') == '/GoTo': d = A.get('/D')
                    L.append((k + 1, 'goto', tmap.get(d[0].objgen, 'NOT-A-PAGE') if isinstance(d, pikepdf.Array) else str(d)))
    return L
R['links_orig'] = links(qo, to); R['links_out'] = links(qn, tn); R['links_ok'] = R['links_orig'] == R['links_out']
def annots(q):
    return [sorted(str(a.get('/Subtype')) for a in p.obj.get('/Annots', []) if not (a.get('/Subtype') == '/Link' and a.get('/A') is not None and 'freedailypro' in str(a.A.get('/URI', '')))) for p in q.pages]
R['annots_ok'] = annots(qo) == annots(qn)
def fields(q):
    af = q.Root.get('/AcroForm'); return sorted((str(f.get('/T')), str(f.get('/V', ''))) for f in af.get('/Fields', [])) if af is not None else []
R['fields_orig'] = fields(qo); R['fields_out'] = fields(qn); R['fields_ok'] = R['fields_orig'] == R['fields_out']
R['toc_orig'] = fo.get_toc(simple=False).__len__(); R['toc_out_simple'] = fn.get_toc(); R['toc_ok'] = fo.get_toc() == fn.get_toc()
def toc_kinds(q):
    res = []
    if '/Outlines' in q.Root and '/First' in q.Root.Outlines:
        o = q.Root.Outlines.First
        while o is not None:
            d = o.get('/Dest') or (o.get('/A') or {}).get('/D'); res.append(str(d[1]) if isinstance(d, pikepdf.Array) and len(d) > 1 else str(d)); o = o.get('/Next')
    return res
R['toc_dest_kinds_orig'] = toc_kinds(qo); R['toc_dest_kinds_out'] = toc_kinds(qn)
R['hidden_pages'] = sum(1 for o in qn.objects if isinstance(o, pikepdf.Dictionary) and o.get('/Type') == '/Page' and o.objgen not in tn)
R['catalog_lost'] = sorted(set(map(str, qo.Root.keys())) - set(map(str, qn.Root.keys())))
R['pagelabels_same'] = str(qo.Root.get('/PageLabels')) == str(qn.Root.get('/PageLabels'))
R['docinfo'] = {str(k): str(v)[:40] for k, v in qn.docinfo.items()}
R['boxes_same'] = all([str(qo.pages[k].obj.get(x)) == str(qn.pages[k].obj.get(x)) for k in range(len(qo.pages)) for x in ('/MediaBox', '/CropBox', '/Rotate')])
json.dump(R, open(f'{od}/{tag}.json', 'w'), indent=1, default=str)
print(tag, 'pages', len(fn), 'ALL_OK', ok_all, '| links_ok', R['links_ok'], 'annots_ok', R['annots_ok'], 'fields_ok', R['fields_ok'], 'toc_ok', R['toc_ok'], 'hidden', R['hidden_pages'], 'boxes_same', R['boxes_same'], 'catalog_lost', R['catalog_lost'], 'size', R['size_orig'], '->', R['size_out'])
for r in R['pages'][:14]:
    print(f" p{r['page']} rot{r['rot']} vis{r['visible_wh']} exp[{r['exp']}] got[{r['text_got']}] pos {r.get('pos_got')} fb {r.get('from_bottom')} ft {r.get('from_top')} fl {r.get('from_left')} fr {r.get('from_right')} cdx {r.get('center_dx')} dir {r.get('dir_visible')} render {r.get('render_diff_bbox')} xo+{r['xobjects_added']} {'OK' if r['ok'] else 'BAD'}")
