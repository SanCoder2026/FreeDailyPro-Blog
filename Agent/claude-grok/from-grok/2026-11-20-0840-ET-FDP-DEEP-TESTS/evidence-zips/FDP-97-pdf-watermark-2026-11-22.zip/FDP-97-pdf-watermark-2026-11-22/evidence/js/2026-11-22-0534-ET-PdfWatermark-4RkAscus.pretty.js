import { r as u, j as e } from "./vendor-react-D01g8YgM.js";
import {
  T as ae,
  F as re,
  P as se,
  D as oe,
  R as ie,
} from "./ToolPage-B4roIUf_.js";
import { B as d, e as m, I as S, f as I } from "./index-DagluEtV.js";
import { T as le } from "./ToolInfoSection-C0Lbi6Qb.js";
import { a as G } from "./pdfMetadata-CcxIhQF2.js";
import { B as ne, a as me } from "./BatchRunner-Ci6bVLGm.js";
import { u as n } from "./useSessionState-BLsNNse9.js";
import { k as $ } from "./index-BRvxULIc.js";
import { q as ce, V as de, W as pe } from "./operations-BlL6iX51.js";
import { needsPicture as ue } from "./drawTextAnywhere-Dl7l_xfJ.js";
import "./useUploadApi-Cwp1vwlT.js";
import "./cloudStorage-BzUdFuQl.js";
import "./camera-CL8JsD0s.js";
import "./share-2-B34wyobX.js";
import "./copy-CQptMDp5.js";
import "./workflowCta-oWYKzOWD.js";
import "./UsageAndUpgradeStrip-BiAdGTIF.js";
import "./access-BSSUf40u.js";
import "./useAdminAccess-CYp3AlSq.js";
import "./tool-name-translations-d1j9ms8v.js";
import "./InstallToolButton-CgocG3qD.js";
import "./map-pin-DvVDRebE.js";
import "./FaqSection-DsOLPaJ0.js";
import "./ToolVideoEmbed-CZwBIyFf.js";
import "./GuideLinks-BVE0aHrc.js";
import "./blog-BPnsEI_q.js";
import "./info-56I4OKVq.js";
import "./productCards-CUOqxId0.js";
import "./layers-BVDCe9zx.js";
import "./usePwaManifest-D8HDEEPW.js";
import "./CollapsibleText-DmEVOuX4.js";
import "./chevron-up-B0wsCoBg.js";
import "./jszip.min-CT0ZA6V1.js";
import "./jszip.min-C-FLQHAz.js";
import "./_commonjs-dynamic-modules-TDtrdbi3.js";
import "./formatFileSize-B-JRDfN5.js";
import "./batch-Bbh00IAr.js";
import "./trash-2-DpHY4NWT.js";
import "./square-ClncwSrJ.js";
import "./index-CnXdQaNG.js";
import "./index-DMQTJy3b.js";
import "./pdfFonts-CIqHAJiw.js";
import "./fontkit.es-DA-3qwB1.js";
import "./pdfBookmarks-BjfxtCfb.js";
import "./pageView-BQIwVYOi.js";
import "./formAppearance-TraefmEd.js";
import "./ocrText-C_9cxcFa.js";
import "./ocrImage-DAAOwTV-.js";
import "./utils-s8ucLyj8.js";
import "./imageRecompress-eXQFDUm-.js";
import "./plural-FIChqbp4.js";
import "./textDiff-DxE9AzvO.js";
import "./utils-BvcV7ep8.js";
import "./decode-CE2kW_I3.js";
import "./formFill-xgtRnF-K.js";
import "./redactSearch-DQpyyh_t.js";
import "./nameDetect-DvHCRM0m.js";
function he(a, c) {
  return a !== 0 && a !== 45 ? a : c === "center" || c === "tiled" ? 45 : 0;
}
function ge(a, c) {
  let s;
  if (a.range.trim()) {
    const i = ce(a.range, c);
    if ("error" in i) return { error: i.error };
    s = i.pages;
  } else s = Array.from({ length: c }, (i, l) => l);
  return (
    (s = Array.from(new Set(s)).sort((i, l) => i - l)),
    a.skipFirst && (s = s.filter((i) => i !== 0)),
    s.length === 0
      ? {
          error: a.skipFirst
            ? "No pages are left to watermark. Page 1 is skipped, so choose other pages."
            : "No pages chosen",
        }
      : { pages: s }
  );
}
function j(a) {
  return a.replace(/[\r\n\t]+/g, " ").trim() ? null : "Type the watermark text";
}
const D = {
    what: "Stamps a text or image watermark across every page of a PDF, commonly used to mark a document as a draft or confidential, or to brand it with a logo before it's shared. It's a visual signal, not a security measure — the watermark makes the document's status or origin obvious to anyone looking at it, but doesn't prevent copying, editing, or redistribution the way password protection does.",
    how: 'Upload your PDF, choose Text or Image, then set the watermark content, opacity, size, colour, angle and position (or Tiled, to repeat it across the whole page); an image watermark also has a logo width. By default the watermark goes on every page; choose "Skip the first page" for a cover, or type a page range such as 2-5, 8. Text in the Latin alphabet is added as real, searchable text that stays sharp when printed; Hindi, Marathi and Nepali are embedded as real text with a font from this site, and other scripts (Chinese, Arabic...) are drawn as a picture so they display correctly. By default the watermark sits on top of the page; choose "Behind page content" to keep body text fully dark (a full-page scan or a solid background hides a watermark placed behind it). Download the watermarked file when it looks right. To stamp several PDFs the same way, switch to Several files: up to 5 at a time on the trial, counted as one use, with the results as a ZIP.',
    tip: "If the goal is actually restricting access rather than labeling a document's status, pair this with PDF Password, or use that instead — a watermark alone doesn't stop anyone from copying or editing the underlying content.",
  },
  xe = (a) => ({
    r: parseInt(a.slice(1, 3), 16) / 255,
    g: parseInt(a.slice(3, 5), 16) / 255,
    b: parseInt(a.slice(5, 7), 16) / 255,
  }),
  fe = [
    { value: "center", label: "Center" },
    { value: "top-left", label: "Top Left" },
    { value: "top-right", label: "Top Right" },
    { value: "bottom-left", label: "Bottom Left" },
    { value: "bottom-right", label: "Bottom Right" },
    { value: "tiled", label: "Tiled" },
  ];
function yt() {
  const [a, c] = u.useState(null),
    [s, i] = n("wm-mode", "text"),
    [l, U] = n("wm-text", "CONFIDENTIAL"),
    [f, _] = u.useState(null),
    [w, J] = n("wm-opacity", 40),
    [k, Z] = n("wm-position", "center"),
    [N, q] = n("wm-size", 50),
    [h, B] = n("wm-angle", 45),
    [L, H] = n("wm-color", "#808080"),
    [P, V] = n("wm-logo", 30),
    [K, z] = u.useState(!1),
    [v, r] = u.useState(null),
    [C, Q] = u.useState(!1),
    [O, A] = u.useState(0),
    [b, X] = n("wm-skip-first", !1),
    [y, Y] = n("wm-pages", ""),
    [p, R] = n("wm-layer", "above"),
    ee = u.useCallback((t) => {
      const o = t[0] || null;
      (c(o),
        r(null),
        A(0),
        o &&
          o
            .arrayBuffer()
            .then((x) =>
              $.load(x, { ignoreEncryption: !0, updateMetadata: !1 }),
            )
            .then((x) => A(x.getPageCount()))
            .catch(() => {}));
    }, []),
    W = (t) => {
      if (!b && !y.trim()) return {};
      const o = ge({ skipFirst: b, range: y }, t);
      return "error" in o ? { error: o.error } : { pages: o.pages };
    },
    g = W(O > 0 && !C ? O : 1e5).error ?? null,
    F = () => {
      const t = s === "text" ? j(l) : null;
      return (
        t || (s === "image" && !f ? "Choose a logo image first" : g || null)
      );
    },
    E = async (t) => {
      let o;
      if (b || y.trim()) {
        const x = (
            await $.load(await t.arrayBuffer(), {
              ignoreEncryption: !0,
              updateMetadata: !1,
            })
          ).getPageCount(),
          T = W(x);
        if (T.error) throw new Error(`${t.name}: ${T.error}`);
        o = T.pages;
      }
      return s === "text"
        ? de(t, l, {
            opacity: w / 100,
            position: k,
            fontSize: N,
            rotationDegrees: h,
            color: xe(L),
            pages: o,
            layer: p,
          })
        : pe(t, f, {
            opacity: w / 100,
            position: k,
            rotationDegrees: h,
            widthFraction: P / 100,
            pages: o,
            layer: p,
          });
    },
    te = async () => {
      if (!a) return;
      const t = F();
      if (t) {
        I.error(t);
        return;
      }
      z(!0);
      try {
        const o = await E(a);
        (r(o), I.success("Watermark added!"));
      } catch (o) {
        (console.error("Watermark failed:", o),
          I.error("Failed to add watermark"));
      } finally {
        z(!1);
      }
    },
    M = e.jsxs("div", {
      className: "space-y-4",
      children: [
        e.jsxs("div", {
          className: "flex gap-2",
          children: [
            e.jsx(d, {
              size: "sm",
              variant: s === "text" ? "default" : "outline",
              onClick: () => {
                (i("text"), r(null));
              },
              children: "Text",
            }),
            e.jsx(d, {
              size: "sm",
              variant: s === "image" ? "default" : "outline",
              onClick: () => {
                (i("image"), r(null));
              },
              children: "Image / Logo",
            }),
          ],
        }),
        s === "text"
          ? e.jsxs("div", {
              children: [
                e.jsx(m, { htmlFor: "wm-text", children: "Watermark Text" }),
                e.jsx(S, {
                  id: "wm-text",
                  value: l,
                  "aria-invalid": !!j(l),
                  "aria-describedby": "wm-text-msg",
                  onChange: (t) => {
                    (U(t.target.value), r(null));
                  },
                }),
                e.jsx("div", {
                  id: "wm-text-msg",
                  "aria-live": "polite",
                  children:
                    j(l) &&
                    e.jsx("p", {
                      role: "alert",
                      className: "text-xs text-destructive mt-1",
                      children: j(l),
                    }),
                }),
                ue(l) &&
                  e.jsx("p", {
                    className: "text-xs text-muted-foreground mt-1",
                    children:
                      "Some of these characters are drawn as a picture so they show correctly. That part can't be selected or searched. Latin-alphabet text is added as real text.",
                  }),
              ],
            })
          : e.jsxs("div", {
              children: [
                e.jsx(m, { children: "Logo image (PNG, JPEG, WebP...)" }),
                e.jsx(S, {
                  "aria-label": "Logo image (PNG, JPEG, WebP...)",
                  type: "file",
                  accept: "image/*",
                  onChange: (t) => {
                    (_(t.target.files?.[0] ?? null), r(null));
                  },
                }),
                f
                  ? e.jsx("p", {
                      className: "text-xs text-muted-foreground mt-1",
                      children: f.name,
                    })
                  : e.jsx("p", {
                      role: "alert",
                      className: "text-xs text-destructive mt-1",
                      children: "Choose a logo image first",
                    }),
              ],
            }),
        e.jsxs("div", {
          children: [
            e.jsx(m, { children: "Position" }),
            e.jsx("div", {
              className: "flex gap-2 flex-wrap mt-1.5",
              children: fe.map((t) =>
                e.jsx(
                  d,
                  {
                    size: "sm",
                    variant: k === t.value ? "default" : "outline",
                    onClick: () => {
                      (Z(t.value), B(he(h, t.value)), r(null));
                    },
                    children: t.label,
                  },
                  t.value,
                ),
              ),
            }),
          ],
        }),
        s === "text"
          ? e.jsxs("div", {
              className: "flex flex-wrap gap-4",
              children: [
                e.jsxs("div", {
                  className: "flex-1 min-w-[10rem]",
                  children: [
                    e.jsxs(m, {
                      htmlFor: "wm-size",
                      children: ["Size: ", N, " pt (long text shrinks to fit)"],
                    }),
                    e.jsx("input", {
                      id: "wm-size",
                      type: "range",
                      min: "12",
                      max: "160",
                      value: N,
                      onChange: (t) => {
                        (q(Number(t.target.value)), r(null));
                      },
                      className: "w-full mt-1.5",
                    }),
                  ],
                }),
                e.jsxs("div", {
                  children: [
                    e.jsx(m, { htmlFor: "wm-color", children: "Colour" }),
                    e.jsx("input", {
                      id: "wm-color",
                      type: "color",
                      value: L,
                      onChange: (t) => {
                        (H(t.target.value), r(null));
                      },
                      className:
                        "block h-9 w-14 mt-1.5 rounded border bg-transparent",
                    }),
                  ],
                }),
              ],
            })
          : e.jsxs("div", {
              children: [
                e.jsxs(m, {
                  htmlFor: "wm-scale",
                  children: ["Logo width: ", P, "% of the page"],
                }),
                e.jsx("input", {
                  id: "wm-scale",
                  type: "range",
                  min: "5",
                  max: "80",
                  value: P,
                  onChange: (t) => {
                    (V(Number(t.target.value)), r(null));
                  },
                  className: "w-full mt-1.5",
                }),
              ],
            }),
        e.jsxs("div", {
          children: [
            e.jsxs(m, { htmlFor: "wm-angle", children: ["Angle: ", h, "°"] }),
            e.jsx("input", {
              id: "wm-angle",
              type: "range",
              min: "0",
              max: "90",
              value: h,
              onChange: (t) => {
                (B(Number(t.target.value)), r(null));
              },
              className: "w-full mt-1.5",
            }),
            e.jsx("p", {
              className: "text-xs text-muted-foreground mt-1",
              children:
                "Centre and tiled start at 45°, corners start straight (0°). An angle you set yourself is kept when you change the position.",
            }),
          ],
        }),
        e.jsxs("div", {
          className: "space-y-2",
          children: [
            e.jsx(m, {
              htmlFor: "wm-pages",
              children: "Pages (leave empty for every page)",
            }),
            e.jsx(S, {
              id: "wm-pages",
              value: y,
              placeholder: "e.g. 2-5, 8",
              "aria-invalid": !!g,
              onChange: (t) => {
                (Y(t.target.value), r(null));
              },
            }),
            e.jsxs("label", {
              className: "flex items-center gap-2 text-sm cursor-pointer",
              children: [
                e.jsx("input", {
                  type: "checkbox",
                  checked: b,
                  onChange: (t) => {
                    (X(t.target.checked), r(null));
                  },
                }),
                " Skip the first page (for a cover)",
              ],
            }),
            g &&
              e.jsx("p", {
                role: "alert",
                className: "text-xs text-destructive mt-1",
                children: g,
              }),
          ],
        }),
        e.jsxs("div", {
          children: [
            e.jsx(m, { children: "Layer" }),
            e.jsxs("div", {
              className: "flex gap-2 flex-wrap mt-1.5",
              role: "group",
              "aria-label": "Layer",
              children: [
                e.jsx(d, {
                  size: "sm",
                  variant: p === "above" ? "default" : "outline",
                  "aria-pressed": p === "above",
                  onClick: () => {
                    (R("above"), r(null));
                  },
                  children: "On top of the page",
                }),
                e.jsx(d, {
                  size: "sm",
                  variant: p === "behind" ? "default" : "outline",
                  "aria-pressed": p === "behind",
                  onClick: () => {
                    (R("behind"), r(null));
                  },
                  children: "Behind page content",
                }),
              ],
            }),
            p === "behind" &&
              e.jsx("p", {
                className: "text-xs text-muted-foreground mt-1",
                children:
                  "The page's own text stays fully dark over the watermark. Pages that are a full-page scan or have a solid background colour will hide it, because the page paints over it. Use On top for those.",
              }),
          ],
        }),
        e.jsxs("div", {
          children: [
            e.jsxs(m, { children: ["Opacity: ", w, "%"] }),
            e.jsx("input", {
              type: "range",
              min: "5",
              max: "100",
              value: w,
              onChange: (t) => {
                (J(Number(t.target.value)), r(null));
              },
              className: "w-full mt-1.5",
            }),
          ],
        }),
      ],
    });
  return e.jsxs(ae, {
    children: [
      e.jsx(ne, { batch: C, onChange: Q }),
      C
        ? e.jsx(me, {
            accept: ".pdf",
            noun: "PDF",
            zipName: "watermarked-pdfs.zip",
            runLabel: "Add watermark",
            check: F,
            disableOnCheck: !0,
            process: async (t) => ({
              blob: await E(t),
              fileName: `${G(t.name)}-watermarked.pdf`,
            }),
            children: M,
          })
        : a
          ? e.jsxs("div", {
              className: "space-y-4",
              children: [
                e.jsx("div", {
                  className: "p-4 rounded-lg border bg-card",
                  children: e.jsx("p", {
                    className: "text-sm font-medium",
                    children: a.name,
                  }),
                }),
                M,
                e.jsx("div", {
                  className: "flex gap-3",
                  children: K
                    ? e.jsx(se, {})
                    : v
                      ? e.jsxs(e.Fragment, {
                          children: [
                            e.jsx(oe, {
                              blob: v,
                              fileName: `${G(a.name)}-watermarked.pdf`,
                            }),
                            e.jsx(d, {
                              variant: "outline",
                              onClick: () => {
                                (c(null), r(null));
                              },
                              children: "New",
                            }),
                          ],
                        })
                      : e.jsxs(e.Fragment, {
                          children: [
                            e.jsx(d, {
                              onClick: te,
                              disabled: !!F(),
                              children: "Add Watermark",
                            }),
                            e.jsx(d, {
                              variant: "outline",
                              onClick: () => c(null),
                              children: "Reset",
                            }),
                          ],
                        }),
                }),
                v && e.jsx(ie, { blob: v, mimeType: "application/pdf" }),
              ],
            })
          : e.jsx(re, {
              gateAtDownload: !0,
              accept: ".pdf",
              onFiles: ee,
              label: "Drop a PDF file",
              description: "Add a text or image watermark to every page",
            }),
      e.jsx(le, { whatIsIt: D.what, howToUse: D.how, tip: D.tip }),
    ],
  });
}
export { yt as default };
//# sourceMappingURL=PdfWatermark-4RkAscus.js.map
