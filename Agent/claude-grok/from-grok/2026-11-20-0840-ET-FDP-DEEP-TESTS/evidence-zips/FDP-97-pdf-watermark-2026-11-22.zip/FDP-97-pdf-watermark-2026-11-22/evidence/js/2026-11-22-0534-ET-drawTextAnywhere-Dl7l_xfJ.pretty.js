import {
  c as T,
  S as z,
  s as v,
  b as m,
  R as h,
  a as M,
  e as F,
  f as R,
} from "./pdfFonts-CIqHAJiw.js";
import { S as c, t as d, u as w } from "./index-BRvxULIc.js";
import "./fontkit.es-DA-3qwB1.js";
import "./index-CnXdQaNG.js";
import "./vendor-react-D01g8YgM.js";
import "./index-DMQTJy3b.js";
const g = (r) => {
    for (const n of r) {
      const e = n.codePointAt(0);
      if (
        !(e < 32 || e === 127 || T(e) || z[n] !== void 0) &&
        !((e >= 8203 && e <= 8207) || e === 65279)
      )
        return !0;
    }
    return !1;
  },
  H = /[\u0900-\u097f]/,
  y = new WeakMap(),
  _ = () => (typeof document < "u" ? R : void 0);
function D(r, n) {
  let e = y.get(r);
  return (
    e ||
      ((e = (async () => {
        try {
          const t = await F(r, await n());
          return { font: t, chars: new Set(t.getCharacterSet()) };
        } catch {
          return null;
        }
      })()),
      y.set(r, e)),
    e
  );
}
async function A(r, n, e) {
  const t = e === void 0 ? _() : e;
  if (!t || !H.test(n)) return null;
  const a = await D(r, t);
  if (!a) return null;
  for (const s of n) if (!a.chars.has(s.codePointAt(0))) return null;
  return a.font;
}
async function I(r, n, e, t = !1, a = m(), s) {
  const i = await A(r, n, s);
  return i
    ? i.widthOfTextAtSize(n, e)
    : a && g(n)
      ? a.measure(n, "sans", t, !1) * e
      : (
          await r.embedFont(t ? c.HelveticaBold : c.Helvetica)
        ).widthOfTextAtSize(v(n), e);
}
async function O(r, n, e, t) {
  const a = t.color ?? { r: 0, g: 0, b: 0 },
    s = t.env === void 0 ? m() : t.env,
    i = t.rotateDegrees ?? 0,
    u = await A(r, e, t.devaLoader);
  if (u) {
    n.drawText(e, {
      x: t.x,
      y: t.y,
      size: t.size,
      font: u,
      color: w(a.r, a.g, a.b),
      opacity: t.opacity,
      rotate: d(i),
    });
    return;
  }
  if (s && g(e)) {
    const { png: S, widthEm: p } = await s.render(e, "sans", !!t.bold, !1, [
        a.r,
        a.g,
        a.b,
      ]),
      E = await r.embedPng(S),
      o = (i * Math.PI) / 180,
      f = (h - M) * t.size,
      l = 0.1 * t.size;
    n.drawImage(E, {
      x: t.x + f * Math.sin(o) - l * Math.cos(o),
      y: t.y - f * Math.cos(o) - l * Math.sin(o),
      width: p * t.size,
      height: h * t.size,
      rotate: d(i),
      opacity: t.opacity,
    });
    return;
  }
  const b = await r.embedFont(t.bold ? c.HelveticaBold : c.Helvetica);
  n.drawText(v(e), {
    x: t.x,
    y: t.y,
    size: t.size,
    font: b,
    color: w(a.r, a.g, a.b),
    opacity: t.opacity,
    rotate: d(i),
  });
}
export { O as drawTextAnywhere, I as measureTextAnywhere, g as needsPicture };
//# sourceMappingURL=drawTextAnywhere-Dl7l_xfJ.js.map
