# FDP-97 extra test files (all made up). python3 make97.py -> testfiles/
from PIL import Image, ImageDraw, ImageFont
import fitz, io, piexif
T='testfiles/'
F=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',90)
# logo.png: transparent, made-up "ACME" mark (wide 600x240)
im=Image.new('RGBA',(600,240),(0,0,0,0)); d=ImageDraw.Draw(im)
d.ellipse((10,20,210,220),fill=(220,40,40,255)); d.text((240,60),'ACME',font=F,fill=(20,60,200,255)); im.save(T+'logo.png')
# tall logo (200x800) to hit the height cap
im2=Image.new('RGBA',(200,800),(0,0,0,0)); ImageDraw.Draw(im2).rectangle((20,20,180,780),fill=(0,140,70,255)); im2.save(T+'logo-tall.png')
# JPEG with EXIF orientation 6 (stored sideways): arrow pointing right stored; displayed should point up
j=Image.new('RGB',(400,200),(255,230,120)); dj=ImageDraw.Draw(j); dj.polygon([(20,80),(300,80),(300,30),(380,100),(300,170),(300,120),(20,120)],fill=(0,0,0)); dj.text((30,130),'UP?',font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',40),fill=(200,0,0))
ex=piexif.dump({'0th':{piexif.ImageIFD.Orientation:6}}); j.save(T+'photo-exif6.jpg',exif=ex,quality=90)
im.save(T+'logo.webp'); im.convert('RGB').save(T+'logo.tiff'); im.save(T+'logo.gif')
open(T+'logo.svg','w').write('<svg xmlns="http://www.w3.org/2000/svg" width="300" height="120"><rect width="300" height="120" rx="20" fill="#5a2"/><text x="20" y="80" font-size="60" font-family="sans-serif" fill="#fff">SVG</text></svg>')
open(T+'notimage.png','w').write('not really a png')
# scan.pdf: p1 full-page opaque image (like a scan), p2 page with a solid coloured background rectangle, p3 plain text
d=fitz.open()
sc=Image.new('RGB',(1275,1650),(250,248,240)); ds=ImageDraw.Draw(sc)
for y in range(150,1500,60): ds.text((120,y),'Scanned line of text %d'%(y//60),font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',34),fill=(30,30,30))
b=io.BytesIO(); sc.save(b,'JPEG',quality=70)
p=d.new_page(width=612,height=792); p.insert_image(p.rect,stream=b.getvalue())
p=d.new_page(width=612,height=792); p.draw_rect(p.rect,color=None,fill=(0.85,0.92,1)); p.insert_text((72,100),'Page with a solid background',fontsize=16)
p=d.new_page(width=612,height=792); p.insert_text((72,100),'Plain text page. BODYWORD appears once here.',fontsize=14)
d.save(T+'scan.pdf')
print('ok')
