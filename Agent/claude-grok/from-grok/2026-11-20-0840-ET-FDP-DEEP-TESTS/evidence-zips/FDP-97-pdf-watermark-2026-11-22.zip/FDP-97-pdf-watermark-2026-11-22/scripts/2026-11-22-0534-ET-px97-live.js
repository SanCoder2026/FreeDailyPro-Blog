// FDP-97 Add Watermark to PDF (Professional 10/day), guest. node px96-live.js <mode>
// Never signs in, never types an email or card, never clicks ads.
const pw = require('playwright'); const fs = require('fs'); const cp = require('child_process');
const W = '/workspace/deep/97-pdf-watermark/'; const OUT = W + 'live/'; const TF = W + 'testfiles/'; const TOOL = 'https://www.freedailypro.com/tool/pdf-watermark';
const mode = process.argv[2] || 'core'; const sfx = process.env.SUF || '';
const now = () => cp.execSync('date "+%F %T %Z"').toString().trim();
fs.mkdirSync(OUT + 'dl', { recursive: true }); fs.mkdirSync(OUT + 'cases', { recursive: true });
(async () => { const b = await (process.env.WK ? pw.webkit : pw.chromium).launch(); const R = { t: now(), mode, tries: [], cases: {} }; let c, p, net = [], dls = [], cons = [];
 const open = async (opts = {}) => { c = await b.newContext({ viewport: { width: 1366, height: 1800 }, locale: 'en-US', timezoneId: 'America/New_York', acceptDownloads: true, ...opts }); p = await c.newPage(); p.setDefaultTimeout(20000); net = []; dls = [];
  p.on('request', r => { const u = r.url(); if (r.method() === 'POST' && /freedailypro\.com\/api/.test(u) && !/insight\.hit|funnel\.hit/.test(u)) net.push({ t: now(), u: u.slice(0, 70) }); });
  p.on('download', async d => { const n = d.suggestedFilename(); const path = OUT + 'dl/' + mode + sfx + '-' + dls.length + '-' + n; dls.push({ name: n, path }); await d.saveAs(path).catch(() => { }); });
  p.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') cons.push(m.text().slice(0, 200)); });
  await p.goto(TOOL, { waitUntil: 'domcontentloaded', timeout: 45000 }); await p.waitForTimeout(4500); };
 const used = () => p.evaluate(() => { const u = JSON.parse(localStorage.getItem('fdp-usage-v1') || '{}'); return u.usageToday + '/' + u.limit; });
 const dialog = async () => { const d = p.locator('[role=dialog],[role=alertdialog]'); return (await d.count()) ? (await d.first().innerText()).replace(/\s*\n\s*/g, ' | ').slice(0, 300) : null; };
 const esc = async () => { for (let i = 0; i < 3; i++) { await p.keyboard.press('Escape'); await p.waitForTimeout(200); } };
 const shot = (n, full = true) => p.screenshot({ path: OUT + 'cases/' + n + sfx + '.png', fullPage: full });
 const toasts = async () => (await p.locator('[data-sonner-toast]').allInnerTexts()).map(s => s.replace(/\s*\n\s*/g, ' '));
 const poll = async (ms = 3000) => { const s = new Set(); for (let i = 0; i < ms / 250; i++) { for (const t of await toasts()) s.add(t); await p.waitForTimeout(250); } return [...s]; };
 const find = async (opts) => { for (let i = 0; i < +(process.env.TRIES || 25); i++) { await open(opts); const u = await used(); R.tries.push(u); if (process.env.NEED0 ? u.startsWith('0/') : (parseInt(u) <= +(process.env.MAXUSED || 6))) return true; if (i < +(process.env.TRIES || 25) - 1) await c.close(); } console.log('find failed', R.tries.join(' ')); return false; };
 const drop = async f => { await p.locator('input[type=file]').first().setInputFiles(TF + f); const ts = await poll(+(process.env.LOADMS || 5000)); return { loadToasts: ts, alerts: await alerts(), page: await pageLbl() }; };
 const alerts = async () => (await p.locator('main [role=alert]').allInnerTexts()).map(s => s.replace(/\s*\n\s*/g, ' ').slice(0, 300));
 const pageLbl = async () => { const t = await p.locator('main').innerText(); const m = t.match(/Page \d+ of \d+/); return m ? m[0] : null; };
 const download = async () => { const d0 = dls.length, np = net.length, u0 = await used(); const bt = btn(/^\s*Download/); if (!(await bt.count())) return { download: 'no button' }; const label = (await bt.first().innerText()).trim(); await bt.first().click(); await p.waitForTimeout(4000); const dg = await dialog(); if (dg) await esc(); return { label, usage: u0 + '->' + await used(), posts: net.length - np, dialog: dg, downloads: dls.slice(d0).map(d => ({ name: d.name, size: fs.existsSync(d.path) ? fs.statSync(d.path).size : null, saved: d.path.replace(W, '') })) }; };
 const newF = async () => { const n = btn(/^\s*(New|Reset)\s*$/).first(); if (await n.count()) { await n.click(); await p.waitForTimeout(800); } };
 const C = async (id_, fn) => { if (process.env.ONLY && !new RegExp(process.env.ONLY).test(id_)) return; const c0 = cons.length; try { R.cases[id_] = await fn(); } catch (e) { R.cases[id_] = { err: e.message.split('\n')[0].slice(0, 200) }; await shot(id_ + '-err').catch(() => { }); } R.cases[id_].console = cons.slice(c0).slice(0, 5); console.log(id_, JSON.stringify(R.cases[id_]).slice(0, 1500)); };
 const btn = (re) => p.locator('main button', { hasText: re });
 const info = async () => ({ buttons: (await p.locator('main button').allInnerTexts()).map(s => s.trim()).filter(Boolean).slice(0, 60), combos: await p.locator('main [role=combobox]').allInnerTexts(), inputs: await p.locator('main input').evaluateAll(es => es.map(e => [e.id, e.type, e.getAttribute('aria-label'), e.value, e.disabled])), text: (await p.locator('main').innerText()).slice(0, 3000) });
 const combo = async (idx, label) => { await p.locator('main [role=combobox]').nth(idx).click(); await p.waitForTimeout(250); await p.getByRole('option', { name: label, exact: true }).click(); await p.waitForTimeout(200); };

 const setOpts = async (o0 = {}) => { const o = { mode: 'text', text: 'CONFIDENTIAL', pos: 'Center', size: 50, color: '#808080', opacity: 40, pages: '', skip: false, layer: 'top', ...o0 };
  await btn(o.mode === 'image' ? /^\s*Image \/ Logo\s*$/ : /^\s*Text\s*$/).first().click(); await p.waitForTimeout(200);
  if (o.mode === 'text') await p.locator('#wm-text').fill(o.text);
  else { if (o.logo) { await p.locator('main input[type=file][accept="image/*"]').setInputFiles(TF + o.logo); await p.waitForTimeout(800); } if (o.scale !== undefined) await p.locator('#wm-scale').fill(String(o.scale)); }
  await btn(new RegExp('^\\s*' + o.pos + '\\s*$')).first().click(); await p.waitForTimeout(150);
  if (o.mode === 'text') { await p.locator('#wm-size').fill(String(o.size)); await p.locator('#wm-color').fill(o.color); }
  if (o.angle !== undefined) await p.locator('#wm-angle').fill(String(o.angle));
  await p.locator('main input[type=range][min="5"][max="100"]').fill(String(o.opacity));
  await p.locator('#wm-pages').fill(o.pages); await p.locator('main input[type=checkbox]').first().setChecked(!!o.skip);
  await btn(o.layer === 'behind' ? /^\s*Behind page content\s*$/ : /^\s*On top of the page\s*$/).first().click(); await p.waitForTimeout(200);
  const t = await p.locator('main').innerText(); return { angleLbl: (t.match(/Angle: \d+°/) || [''])[0], sizeLbl: (t.match(/Size: \d+ pt/) || [''])[0], note: (t.match(/Some of these characters[^\n]*/) || [null])[0], alerts: await alerts() }; };
 const run = async () => { const t0 = Date.now(); const bt = btn(/^\s*Add Watermark\s*$/); await bt.click(); let hd = false; for (let i = 0; i < +(process.env.APPLYMS || 120000) / 250; i++) { await p.waitForTimeout(250); if (await btn(/^\s*Download/).count()) { hd = true; break; } const ts = await toasts(); if (ts.some(x => /Failed|error|Choose|Type|No pages/i.test(x))) break; } return { ms: Date.now() - t0, toasts: await poll(1200), alerts: await alerts(), hasDownload: hd }; };
 const fresh = async (f) => { const nb = btn(/^\s*New\s*$/); if (await nb.count()) { await nb.first().click(); await p.waitForTimeout(600); } return drop(f); };
 const full = async (id_, f, o) => { const l = await fresh(f); const s = await setOpts(o); const a = await run(); await shot(id_, false).catch(() => { }); const d = a.hasDownload ? await download() : null; return { l: l.loadToasts, s, a, d }; };
 if (mode === 'explore') { await open(); R.start = await used(); R.pre = await info(); await drop('doc.pdf'); R.loaded = await info(); await btn(/^\s*Image \/ Logo\s*$/).first().click(); await p.waitForTimeout(300); R.image = await info(); await shot('X-image'); }
 if (mode === 'core') { await find(); R.start = await used();
  const K = [
   ['W01-doc-default', 'doc.pdf', {}],
   ['W02-mixed-draft', 'mixed.pdf', { text: 'DRAFT' }],
   ['W03-rot-center', 'rotated.pdf', {}],
   ['W04-rot-TL-0', 'rotated.pdf', { text: 'TOPLEFT', pos: 'Top Left', angle: 0 }],
   ['W05-crop-BR', 'crop-offset.pdf', { text: 'BRMARK', pos: 'Bottom Right', angle: 0, opacity: 80 }],
   ['W06-crop-tiled', 'crop-offset.pdf', { text: 'TILE', pos: 'Tiled', size: 30 }],
   ['W07-rotinh-TR', 'rotated-inherit.pdf', { text: 'TOPRIGHT', pos: 'Top Right', angle: 0 }],
   ['W08-toc-behind-range', 'toc-links.pdf', { text: 'BEHIND', layer: 'behind', pages: '2-5, 8' }],
   ['W09-form-skip', 'form.pdf', { text: 'SKIPPED1', skip: true }],
   ['W10-scan-behind', 'scan.pdf', { text: 'HIDDEN', layer: 'behind', opacity: 100, color: '#ff0000' }],
   ['W11-scan-top-red90', 'scan.pdf', { text: 'VISIBLE', opacity: 100, color: '#ff0000', angle: 90 }],
   ['W12-three-logo-center', 'three.pdf', { mode: 'image', logo: 'logo.png', scale: 30, opacity: 50 }],
   ['W13-rot-logo-BR', 'rotated.pdf', { mode: 'image', logo: 'logo.png', pos: 'Bottom Right', scale: 25, opacity: 100 }],
   ['W14-crop-logo-tiled', 'crop-offset.pdf', { mode: 'image', logo: 'logo.png', pos: 'Tiled', scale: 15 }],
   ['W15-mixed-exif-TL30', 'mixed.pdf', { mode: 'image', logo: 'photo-exif6.jpg', pos: 'Top Left', angle: 30, opacity: 100 }],
   ['W16-three-tall80', 'three.pdf', { mode: 'image', logo: 'logo-tall.png', scale: 80, opacity: 100 }],
   ['W17-book-tiled-range-skip', 'book.pdf', { text: 'INTERNAL', pos: 'Tiled', size: 24, pages: '1-3', skip: true }],
   ['W18-three-BR-long160', 'three.pdf', { text: 'CONFIDENTIAL - DO NOT DISTRIBUTE', pos: 'Bottom Right', size: 160, opacity: 100 }],
  ];
  for (const [id_, f, o] of K) await C(id_, () => full(id_.slice(0, 3), f, o));
 }
 if (mode === 'nonlatin') { await find(); R.start = await used();
  const K = [['L01', 'Brouillon – ÉTÉ'], ['L02', 'Конфиденциально'], ['L03', '机密文件'], ['L04', 'गोपनीय'], ['L05', 'سري للغاية'], ['L06', '🔒 SECRET'], ['L07', 'Entwurf № 3']];
  for (const [id_, t] of K) await C(id_, () => full(id_, 'three.pdf', { text: t, size: 60, opacity: 100 }));
  await C('L08-cjk-tiled', () => full('L08', 'doc.pdf', { text: '机密', pos: 'Tiled', size: 24 }));
  await C('L09-latin-tiled', () => full('L09', 'doc.pdf', { text: 'COPY', pos: 'Tiled', size: 24 }));
 }
 if (mode === 'img') { await find(); R.start = await used();
  for (const [id_, f] of [['I01', 'logo.webp'], ['I02', 'logo.gif'], ['I03', 'logo.svg'], ['I04', 'logo.tiff'], ['I05', 'notimage.png']]) await C(id_ + '-' + f, async () => { const l = await fresh('three.pdf'); await btn(/^\s*Image \/ Logo\s*$/).first().click(); await p.locator('main input[type=file][accept="image/*"]').setInputFiles(TF + f); const ts = await poll(2500); const s = await setOpts({ mode: 'image', scale: 30, opacity: 100 }); const a = await run(); await shot(id_, false).catch(() => { }); const d = a.hasDownload ? await download() : null; return { pickToasts: ts, s, a, d }; });
 }
 if (mode === 'err') { await find(); R.start = await used();
  await C('E01-enc', async () => { await drop('enc.pdf'); await p.waitForTimeout(1500); const dg0 = await dialog(); const pi = p.locator('[role=dialog] input').first(); if (await pi.count()) { await pi.fill('test123'); await p.locator('[role=dialog] button', { hasText: /^\s*Unlock\s*$/ }).click(); await p.waitForTimeout(3000); } const t = await toasts(); const s = await setOpts({}); const a = await run(); const d = a.hasDownload ? await download() : null; return { dg0, t, s, a, d }; });
  await C('E02-corrupt', async () => { await p.reload(); await p.waitForTimeout(4000); return await drop('corrupt.pdf'); });
  await C('E03-large-tiled', () => full('E03', 'large-300p.pdf', { text: 'DRAFT', pos: 'Tiled', size: 24 }));
  await C('E04-heavy', async () => { const t0 = Date.now(); const r = await full('E04', 'heavy.pdf', {}); r.totalMs = Date.now() - t0; return r; });
  await C('E05-notpdf', async () => { await p.reload(); await p.waitForTimeout(4000); return await drop('logo.png'); });
  await C('E06-inputs', async () => { await fresh('three.pdf'); const r = {}; for (const [k, o] of [['empty', { text: '   ' }], ['range9', { pages: '9' }], ['range0', { pages: '0-2' }], ['rangebad', { pages: 'abc' }], ['skiponly1', { pages: '1', skip: true }], ['nologo', { mode: 'image' }]]) { const s = await setOpts(o); const a = await run(); r[k] = { s, toasts: a.toasts, alerts: a.alerts, hasDownload: a.hasDownload }; if (a.hasDownload) await fresh('three.pdf'); } return r; });
 }
 if (mode === 'batch') { await find(); R.start = await used();
  await C('B01', async () => { await btn(/^\s*Several files\s*$/).click(); await p.waitForTimeout(800); await p.locator('main input[type=file]').first().setInputFiles(['three.pdf', 'doc.pdf', 'rotated.pdf'].map(f => TF + f)); await p.waitForTimeout(3000); await setOpts({ text: 'BATCH' }); const u0 = await used(); const np = net.length; const rb = btn(/^\s*Add watermark/i); await rb.first().click(); for (let i = 0; i < 120; i++) { await p.waitForTimeout(500); if (await btn(/Download all/).count()) break; } const i2 = await info(); const d0 = dls.length; const dl = btn(/Download all/); if (await dl.count()) { await dl.first().click(); await p.waitForTimeout(5000); } const dg = await dialog(); return { btns: i2.buttons, dls: dls.slice(d0), dialog: dg, usage: u0 + '->' + await used(), posts: net.length - np }; });
 }
 if (mode === 'atcap') { await open(); R.start = await used(); R.r = await full('atcap', 'three.pdf', {}); R.btns = (await info()).buttons; }
 if (mode === 'cont') { await open(); R.start = await used(); await full('cont', 'three.pdf', {}); await esc(); const cb = btn(/Continue with/); R.conts = await cb.allInnerTexts(); if (R.conts.length) { await cb.first().click(); await p.waitForTimeout(6000); R.url = p.url(); R.btns = (await info()).buttons; } }
 if (mode === 'xtra') { await open(); R.start = await used();
  await C('X01-angle-reset', async () => { await fresh('three.pdf'); const r = []; const lbl = async () => ((await p.locator('main').innerText()).match(/Angle: \d+°/) || [''])[0]; for (const ps of ['Top Left', 'Center', 'Tiled', 'Bottom Right']) { await btn(new RegExp('^\\s*' + ps + '\\s*$')).first().click(); r.push(ps + ' ' + await lbl()); } await p.locator('#wm-angle').fill('30'); for (const ps of ['Center', 'Top Left']) { await btn(new RegExp('^\\s*' + ps + '\\s*$')).first().click(); r.push('after30 ' + ps + ' ' + await lbl()); } return r; });
  await C('X02-memory', async () => { await setOpts({ text: 'REMEMBER', pos: 'Top Right', angle: 20, opacity: 70 }); await p.reload(); await p.waitForTimeout(4000); await drop('three.pdf'); const i = await info(); return { text: i.inputs.filter(x => x[0] === 'wm-text'), angle: ((i.text.match(/Angle: \d+°/)) || [''])[0], op: ((i.text.match(/Opacity: \d+%/)) || [''])[0] }; });
  await C('X03-batch6', async () => { await p.reload(); await p.waitForTimeout(4000); await btn(/^\s*Several files\s*$/).click(); await p.waitForTimeout(800); await p.locator('main input[type=file]').first().setInputFiles(['three.pdf', 'doc.pdf', 'rotated.pdf', 'mixed.pdf', 'form.pdf', 'one.pdf'].map(f => TF + f)); const ts = await poll(4000); const i = await info(); return { ts, buttons: i.buttons.filter(b => /Add|file|Clear/i.test(b)) }; });
 }
 if (mode === 'mobile') { const dev = pw.devices[process.env.DEV || 'iPhone 13']; await open({ ...dev, viewport: dev.viewport }); R.start = await used();
  await C('M01', async () => { const r = await full('M01-' + (process.env.WK ? 'wk' : 'cr'), 'rotated.pdf', { pos: 'Tiled', text: 'MOBILE' }); r.sw = await p.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth]); await shot('M01-full-' + (process.env.WK ? 'wk' : 'cr')); return r; });
 }
 if (mode === 'inputs') { await open(); R.start = await used();
  await C('E06-inputs', async () => { await drop('three.pdf'); const r = {}; for (const [k, o] of [['empty', { text: '   ' }], ['range9', { pages: '9' }], ['range0', { pages: '0-2' }], ['rangebad', { pages: 'abc' }], ['skiponly1', { pages: '1', skip: true }], ['nologo', { mode: 'image' }]]) { const s = await setOpts(o); const dis = await btn(/^\s*Add Watermark\s*$/).first().isDisabled().catch(() => null); if (dis) { r[k] = { s, btnDisabled: true, alertsShown: await alerts() }; await shot('E06-' + k, false); continue; } const a = await run(); r[k] = { s, toasts: a.toasts, alerts: a.alerts, hasDownload: a.hasDownload, btnDisabled: false }; await shot('E06-' + k, false); if (a.hasDownload) { await p.reload(); await p.waitForTimeout(4000); await drop('three.pdf'); } } return r; });
 }
 if (mode === 'xl') { await find(); R.start = await used();
  await C('E07-large-cjk-tiled', async () => { const t0 = Date.now(); const r = await full('E07', 'large-300p.pdf', { text: '机密', pos: 'Tiled', size: 24 }); r.totalMs = Date.now() - t0; return r; });
 }
 R.end = await used().catch(() => null); fs.writeFileSync(OUT + mode + sfx + '.json', JSON.stringify(R, null, 1)); console.log('done', JSON.stringify(R.tries), R.start, R.end); await b.close(); })();
