# strip97.py <watermarked.pdf> <out.pdf> [original.pdf]
# Shows how easy the watermark (and the trial badge) is to remove WITHOUT knowing the original:
# drop every content stream that draws with a pdf-lib embedded font named /Helvetica-Bold-<digits> under a /GS-<digits> gs state
# (the watermark), or that draws an image XObject named /Image-<digits> under such a state (logo watermark), or that holds the
# "Created with FreeDailyPro.com" text (the trial badge). If an original is given, renders both and counts differing pixels.
import sys, re, pikepdf, pypdfium2 as pdfium, numpy as np
src, dst = sys.argv[1:3]; q = pikepdf.open(src); dropped = 0
for pg in q.pages:
    c = pg.obj.get('/Contents'); ss = list(c) if isinstance(c, pikepdf.Array) else [c]
    keep = []
    for s in ss:
        b = s.read_bytes()
        wm = re.search(rb'/GS-\d+ gs', b) and (re.search(rb'/Helvetica-Bold-\d+ \S+ Tf', b) or re.search(rb'/Image-\d+ Do', b))
        badge = re.search(rb'<4372656174656420', b, re.I)
        if wm or badge: dropped += 1; continue
        keep.append(s)
    pg.obj.Contents = pikepdf.Array(keep)
    for a in list(pg.obj.get('/Annots', [])):
        pass
q.save(dst); print('dropped streams', dropped)
if len(sys.argv) > 3:
    A = pdfium.PdfDocument(sys.argv[3]); B = pdfium.PdfDocument(dst); diff = []
    for i in range(len(A)):
        a = np.asarray(A[i].render(scale=1).to_pil().convert('L'), dtype=np.int16); b = np.asarray(B[i].render(scale=1).to_pil().convert('L'), dtype=np.int16)
        diff.append(int((np.abs(a - b) > 25).sum()) if a.shape == b.shape else -1)
    print('pixels differing from the original per page:', diff)
