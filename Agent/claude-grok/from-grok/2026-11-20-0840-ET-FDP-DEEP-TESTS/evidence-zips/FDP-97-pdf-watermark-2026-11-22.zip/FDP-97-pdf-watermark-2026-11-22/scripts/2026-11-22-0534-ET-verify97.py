# verify97.py <orig> <out> <outdir> <tag> <expect-json>
# expect: {"text": "DRAFT" | null, "pos": "center|top-left|...|tiled", "pages": [1,2,..] (1-based, pages that should carry it), "layer": "top|behind", "angle": 45, "image": false}
# Per page: which content streams were added (watermark vs trial badge), their place in /Contents (first = behind, last = on top),
# opacity (ExtGState ca), marked as /Artifact or OCG?, the watermark is real searchable text (search_for), visible bbox (render diff of
# "output minus badge stream" vs original), position class, visible angle, and the STRIP TEST: output with the added watermark stream
# removed renders identical to the original. Plus links, annots, fields, bookmarks, hidden pages, catalog keys, boxes, objects added.
import sys, os, json, re, math, pikepdf, fitz, pypdfium2 as pdfium, numpy as np, zlib
from PIL import Image
orig, out, od, tag, ej = sys.argv[1:6]; os.makedirs(od, exist_ok=True); E = json.loads(ej)
qo, qn = pikepdf.open(orig), pikepdf.open(out); fo, fn = fitz.open(orig), fitz.open(out)
BADGE = bytes('Created', 'latin1').hex().upper()
def streams(pg):
    c = pg.obj.get('/Contents')
    if c is None: return []
    return list(c) if isinstance(c, pikepdf.Array) else [c]
def data(s):
    try: return s.read_bytes()
    except Exception: return b''
def hexstrings(b):
    out = []
    for h in re.findall(rb'<([0-9A-Fa-f\s]+)>\s*Tj', b):
        try: out.append(bytes.fromhex(h.decode().replace(' ', '').replace('\n', '')).decode('latin1'))
        except Exception: pass
    for s in re.findall(rb'\((.*?)\)\s*Tj', b): out.append(s.decode('latin1'))
    return out
def render(path_or_pdf, i, scale=1.0):
    d = pdfium.PdfDocument(path_or_pdf); im = d[i].render(scale=scale).to_pil().convert('L'); d.close(); return np.asarray(im, dtype=np.int16)
def without(qsrc, i, drop_idx, tmp):
    q = pikepdf.open(out); pg = q.pages[i]; ss = streams(pg)
    keep = [s for k, s in enumerate(ss) if k not in drop_idx]
    pg.obj.Contents = pikepdf.Array(keep); q.save(tmp); q.close(); return tmp
R = {'tag': tag, 'expect': E, 'size_orig': os.path.getsize(orig), 'size_out': os.path.getsize(out), 'pages': []}
ok_all = True; want = set(E.get('pages') or range(1, len(qn.pages) + 1))
for i, (po, pn) in enumerate(zip(qo.pages, qn.pages)):
    od_ = [data(s) for s in streams(po)]; nd = [data(s) for s in streams(pn)]
    added = [k for k, b in enumerate(nd) if b not in od_]
    badge = [k for k in added if re.search(rb'<4372656174656420', nd[k], re.I)]
    wm = [k for k in added if k not in badge and nd[k].strip() not in (b'q', b'Q', b'')]
    first_orig = next((k for k, b in enumerate(nd) if od_ and b == od_[0]), None)
    row = {'page': i + 1, 'rot': fn[i].rotation, 'n_streams_orig': len(od_), 'n_streams_out': len(nd), 'wm_stream_idx': wm, 'badge_stream_idx': badge}
    exp_has = (i + 1) in want; row['expected_watermark'] = exp_has
    wb = b''.join(nd[k] for k in wm)
    row['layer_got'] = None if not wm else ('behind' if first_orig is not None and wm[-1] < first_orig else 'top')
    row['artifact_marked'] = b'/Artifact' in wb; row['bdc'] = b'BDC' in wb
    # opacity from ExtGState names used
    gs = re.findall(rb'/(\S+)\s+gs', wb); res = pn.obj.get('/Resources', {}); eg = res.get('/ExtGState', {}) if res is not None else {}
    row['opacity'] = sorted(set(round(float(eg['/' + g.decode()].get('/ca', eg['/' + g.decode()].get('/CA', 1))), 2) for g in gs if ('/' + g.decode()) in eg))
    row['text_ops'] = len(re.findall(rb'Tj', wb)); row['image_ops'] = len(re.findall(rb'Do', wb))
    hs = hexstrings(wb); row['strings_sample'] = sorted(set(hs))[:3]
    # searchable?
    if E.get('text'):
        row['search_hits'] = len(fn[i].search_for(E['text'])) if E['text'].strip() else 0
    # fonts / xobjects added
    def keys(p, k):
        r_ = p.obj.get('/Resources', {}); x = r_.get(k, {}) if r_ is not None else {}
        return set(map(str, x.keys())) if x is not None else set()
    row['fonts_added'] = len(keys(pn, '/Font') - keys(po, '/Font')); row['xobjects_added'] = len(keys(pn, '/XObject') - keys(po, '/XObject'))
    # render: original vs output-minus-badge (watermark only), and output-minus-all-added (strip test)
    A = render(orig, i)
    tmp1 = f'/tmp/v97-{os.getpid()}-a.pdf'; tmp2 = f'/tmp/v97-{os.getpid()}-b.pdf'
    WM = render(without(qn, i, set(badge), tmp1), i); ST = render(without(qn, i, set(added), tmp2), i)
    if A.shape == WM.shape:
        D = np.abs(A - WM) > 25; ys, xs = np.nonzero(D); H, W = D.shape
        row['visible_wh'] = [W, H]; row['diff_px'] = int(len(ys))
        if len(ys):
            bb = [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())]; row['bbox_visible'] = bb
            cx, cy = (bb[0] + bb[2]) / 2, (bb[1] + bb[3]) / 2
            cov = ((bb[2] - bb[0]) / W, (bb[3] - bb[1]) / H)
            if cov[0] > 0.8 and cov[1] > 0.8: pc = 'tiled'
            elif abs(cx - W / 2) < W * 0.08 and abs(cy - H / 2) < H * 0.08: pc = 'center'
            else: pc = ('top' if cy < H / 2 else 'bottom') + '-' + ('left' if cx < W / 2 else 'right')
            row['pos_got'] = pc; row['margins'] = {'l': bb[0], 't': bb[1], 'r': W - 1 - bb[2], 'b': H - 1 - bb[3]}
            Image.fromarray(np.uint8(np.clip(WM, 0, 255))).save(f'{od}/{tag}-p{i+1}.png') if i < 6 else None
        row['strip_diff_px'] = int((np.abs(A - ST) > 25).sum())
    else:
        row['render_shape_changed'] = True
    # visible angle of watermark text (fitz lines whose text is in the watermark)
    if E.get('text'):
        rm = fn[i].rotation_matrix; angs = []
        for blk in fn[i].get_text('dict')['blocks']:
            for ln in blk.get('lines', []):
                t = ''.join(s['text'] for s in ln['spans']).strip()
                if t and t in E['text'] or (t and E['text'] in t):
                    dx, dy = ln['dir']; v = fitz.Point(dx, dy) * fitz.Matrix(rm.a, rm.b, rm.c, rm.d, 0, 0)
                    angs.append(round(math.degrees(math.atan2(-v.y, v.x))))
        row['angles_visible'] = sorted(set(angs))[:4]
    if E.get('image'):
        rm = fn[i].rotation_matrix; angs = []
        for info in fn[i].get_image_info(xrefs=True):
            m = fitz.Matrix(info['transform']) * fitz.Matrix(rm.a, rm.b, rm.c, rm.d, 0, 0)
            angs.append(round(math.degrees(math.atan2(-m.b, m.a))))
        row['image_angles_visible'] = sorted(set(angs))[:4]
    # checks
    ok = True
    if exp_has:
        ok &= bool(wm) and row.get('diff_px', 0) > 0 if E.get('layer') != 'behind-hidden' else bool(wm)
        if E.get('pos') and 'pos_got' in row: ok &= row['pos_got'] == E['pos']
        if E.get('layer'): ok &= row['layer_got'] == ('behind' if E['layer'].startswith('behind') else 'top')
        if E.get('text') and E.get('searchable', True): ok &= row.get('search_hits', 0) > 0
        if 'angle' in E and E.get('text') and row.get('angles_visible'): ok &= E['angle'] in row['angles_visible']
        if 'angle' in E and E.get('image') and row.get('image_angles_visible'): ok &= E['angle'] in row['image_angles_visible']
        ok &= row.get('strip_diff_px', 1) == 0
    else:
        ok &= not wm
    row['ok'] = bool(ok); ok_all &= bool(ok); R['pages'].append(row)
R['all_ok'] = ok_all
tn = {p.objgen: k + 1 for k, p in enumerate(qn.pages)}; to = {p.objgen: k + 1 for k, p in enumerate(qo.pages)}
def links(q, tmap):
    L = []
    for k, p in enumerate(q.pages):
        for an in p.obj.get('/Annots', []):
            if an.get('/Subtype') == '/Link':
                A_ = an.get('/A'); d = an.get('/Dest')
                if A_ is not None and A_.get('/S') == '/URI':
                    if 'freedailypro' in str(A_.URI): continue
                    L.append((k + 1, 'uri', str(A_.URI)))
                else:
                    if A_ is not None and A_.get('/S') == '/GoTo': d = A_.get('/D')
                    L.append((k + 1, 'goto', tmap.get(d[0].objgen, 'NOT-A-PAGE') if isinstance(d, pikepdf.Array) else str(d)))
    return L
R['links_orig'] = links(qo, to); R['links_out'] = links(qn, tn); R['links_ok'] = R['links_orig'] == R['links_out']
def annots(q):
    return [sorted(str(a.get('/Subtype')) for a in p.obj.get('/Annots', []) if not (a.get('/Subtype') == '/Link' and a.get('/A') is not None and 'freedailypro' in str(a.A.get('/URI', '')))) for p in q.pages]
R['annots_ok'] = annots(qo) == annots(qn)
R['watermark_annots'] = sum(1 for p in qn.pages for a in p.obj.get('/Annots', []) if a.get('/Subtype') in ('/Watermark', '/Stamp', '/FreeText') ) - sum(1 for p in qo.pages for a in p.obj.get('/Annots', []) if a.get('/Subtype') in ('/Watermark', '/Stamp', '/FreeText'))
def fields(q):
    af = q.Root.get('/AcroForm'); return sorted((str(f.get('/T')), str(f.get('/V', ''))) for f in af.get('/Fields', [])) if af is not None else []
R['fields_ok'] = fields(qo) == fields(qn); R['n_fields'] = len(fields(qo))
R['toc_ok'] = fo.get_toc() == fn.get_toc(); R['n_toc'] = len(fo.get_toc())
R['hidden_pages'] = sum(1 for o in qn.objects if isinstance(o, pikepdf.Dictionary) and o.get('/Type') == '/Page' and o.objgen not in tn)
R['catalog_lost'] = sorted(set(map(str, qo.Root.keys())) - set(map(str, qn.Root.keys())))
R['catalog_added'] = sorted(set(map(str, qn.Root.keys())) - set(map(str, qo.Root.keys())))
R['boxes_same'] = all([str(qo.pages[k].obj.get(x)) == str(qn.pages[k].obj.get(x)) for k in range(len(qo.pages)) for x in ('/MediaBox', '/CropBox', '/Rotate')])
R['objects_orig'] = len(qo.objects); R['objects_out'] = len(qn.objects)
R['body_text_kept'] = all(fo[k].get_text('words').__len__() <= fn[k].get_text('words').__len__() for k in range(len(fo)))
json.dump(R, open(f'{od}/{tag}.json', 'w'), indent=1, default=str)
print(tag, 'pages', len(fn), 'ALL_OK', ok_all, '| links', R['links_ok'], 'annots', R['annots_ok'], 'fields', R['fields_ok'], 'toc', R['toc_ok'], 'hidden', R['hidden_pages'], 'boxes', R['boxes_same'], 'cat_lost', R['catalog_lost'], 'cat_add', R['catalog_added'], 'size', R['size_orig'], '->', R['size_out'], 'objs', R['objects_orig'], '->', R['objects_out'])
for r in R['pages'][:8]:
    print(f" p{r['page']} rot{r['rot']} exp{int(r['expected_watermark'])} wm{r['wm_stream_idx']} badge{r['badge_stream_idx']} layer {r['layer_got']} op {r['opacity']} pos {r.get('pos_got')} m {r.get('margins')} ang {r.get('angles_visible', r.get('image_angles_visible'))} hits {r.get('search_hits')} Tj {r['text_ops']} Do {r['image_ops']} f+{r['fonts_added']} x+{r['xobjects_added']} strip {r.get('strip_diff_px')} art {r['artifact_marked']} {'OK' if r['ok'] else 'BAD'}")
