import{
j as e,r as p}
from"./vendor-react-D01g8YgM.js";
import{
z as H,e as m,I as g,B as i,b as Y,a0 as Q,T as X,a_ as ee,D as se,f as h}
from"./index-DagluEtV.js";
import{
d as b}
from"./ToolPage-B4roIUf_.js";
import{
T as te}
from"./ToolInfoSection-C0Lbi6Qb.js";
import{
D as ae,u as re,P as oe,l as ne,n as A,a as L,b as ie,f as le}
from"./auditLog-DSfy6bBy.js";
import{
r as ce,m as _,R as de,a as pe,S as N,b as y,c as me,n as ue,e as he,D as ge,d as M,f as xe,p as fe,g as je,h as be,i as ve}
from"./docOpsEngine-lVJXDlBe.js";
import{
F as we}
from"./file-up-C9pCpZMy.js";
import{
C as ke}
from"./camera-CL8JsD0s.js";
import{
C as Ne}
from"./chevron-up-B0wsCoBg.js";
import{
T as ye}
from"./trash-2-DpHY4NWT.js";
import{
S as Pe}
from"./square-ClncwSrJ.js";
import{
P as Ce}
from"./package-CW8HVwVB.js";
import"./useUploadApi-Cwp1vwlT.js";
import"./cloudStorage-BzUdFuQl.js";
import"./share-2-B34wyobX.js";
import"./copy-CQptMDp5.js";
import"./workflowCta-oWYKzOWD.js";
import"./UsageAndUpgradeStrip-BiAdGTIF.js";
import"./access-BSSUf40u.js";
import"./useAdminAccess-CYp3AlSq.js";
import"./tool-name-translations-d1j9ms8v.js";
import"./InstallToolButton-CgocG3qD.js";
import"./map-pin-DvVDRebE.js";
import"./FaqSection-DsOLPaJ0.js";
import"./ToolVideoEmbed-CZwBIyFf.js";
import"./GuideLinks-BVE0aHrc.js";
import"./blog-BPnsEI_q.js";
import"./info-56I4OKVq.js";
import"./productCards-CUOqxId0.js";
import"./layers-BVDCe9zx.js";
import"./usePwaManifest-D8HDEEPW.js";
import"./CollapsibleText-DmEVOuX4.js";
import"./WorkflowProductGate-BDNk2iP2.js";
import"./ProfileBar-DVGYCHer.js";
import"./EmbedContext-CCnUNY-R.js";
import"./logoFile-JbpkT_Mq.js";
import"./eraser-Bkbc_3wy.js";
import"./folder-open-B4DxBSqT.js";
import"./file-down-TL37fn4x.js";
import"./file-plus-2-CpogWspv.js";
import"./jszip.min-CT0ZA6V1.js";
import"./jszip.min-C-FLQHAz.js";
import"./_commonjs-dynamic-modules-TDtrdbi3.js";
import"./csv-DBvSFDe9.js";
import"./index-BRvxULIc.js";
import"./index-CnXdQaNG.js";
import"./index-DMQTJy3b.js";
import"./operations-BlL6iX51.js";
import"./pdfFonts-CIqHAJiw.js";
import"./fontkit.es-DA-3qwB1.js";
import"./pdfBookmarks-BjfxtCfb.js";
import"./pdfMetadata-CcxIhQF2.js";
import"./pageView-BQIwVYOi.js";
import"./formAppearance-TraefmEd.js";
import"./drawTextAnywhere-Dl7l_xfJ.js";
import"./ocrText-C_9cxcFa.js";
import"./ocrImage-DAAOwTV-.js";
import"./utils-s8ucLyj8.js";
import"./imageRecompress-eXQFDUm-.js";
import"./formatFileSize-B-JRDfN5.js";
import"./plural-FIChqbp4.js";
import"./textDiff-DxE9AzvO.js";
import"./utils-BvcV7ep8.js";
import"./decode-CE2kW_I3.js";
import"./formFill-xgtRnF-K.js";
import"./redactSearch-DQpyyh_t.js";
import"./nameDetect-DvHCRM0m.js";
import"./redactApply-BSsjW140.js";
const P={
what:"A desk for general office packets, such as a loan file, an onboarding pack or an insurance claim. Add the documents, put them in order, choose a recipe (scan, OCR, organize, redact, number pages, compress, sign) and run it. You get one ZIP with the documents in order, a manifest with checksums and an audit log of every step. It is not the Legal Production Desk, which does Bates ranges and production logs for legal work. Everything runs in your browser.",how:"Add PDFs or pictures, or photograph pages with the Scanner panel. Drag them into order with the arrows. Pick a starter recipe or tick the steps you want, fill in the options (words to redact, a name to sign) and read the warnings. Press Run, check the audit log, then Export packet. Save the project file to keep the order, notes and recipe;
 add the documents again next time.",tip:"Put OCR before Redact so the words can be found, and Number pages after the order is final. Always look at a redacted page before you share it."}
;
function Ks(){
return e.jsxs(ae,{
product:"document-operations-desk",profile:!1,children:[e.jsx(De,{
}
),e.jsx(te,{
whatIsIt:P.what,howToUse:P.how,tip:P.tip}
)]}
)}
const C=u=>u.type==="application/pdf"||/\.pdf$/i.test(u.name),Se=u=>/^image\/(jpeg|png|webp)$/.test(u.type)||/\.(jpe?g|png|webp)$/i.test(u.name);
function De(){
const{
localizedHref:u}
=H(),{
data:t,setData:l,dirty:U,save:K,open:W,reset:G}
=re({
desk:M,version:ge,empty:he,normalize:ue,nameOf:s=>s.name||"packet"}
),c=p.useRef(new Map),[x,v]=p.useState(null),[w,S]=p.useState(null),[f,j]=p.useState(!1),k=p.useRef(!1),D=p.useRef(null),R=p.useRef(null),F=p.useRef(null),z=ce(t.steps,t.options),d=s=>l(a=>({
...a,options:{
...a.options,...s}
}
)),I=async s=>{
if(!s)return;
const a=[],r=[];
for(const o of Array.from(s)){
if(!C(o)&&!Se(o)){
h.error(`${
o.name}
: only PDF, JPG, PNG and WebP are supported.`);
continue}
const n=new Uint8Array(await o.arrayBuffer());
let E=1;
if(C(o))try{
E=await xe(n)}
catch{
h.error(`${
o.name}
: could not be read (damaged or protected).`);
continue}
const $=t.docs.find(B=>B.name===o.name&&!c.current.has(B.id));
if($){
c.current.set($.id,n),r.push(o.name);
continue}
const T=A("doc");
c.current.set(T,n),a.push({
id:T,name:o.name,kind:C(o)?"pdf":"image",sizeBytes:o.size,pages:E,note:""}
)}
l(o=>({
...o,docs:[...o.docs,...a],audit:[...o.audit,...a.map(n=>({
id:A("aud"),at:new Date().toISOString(),doc:n.name,step:"intake",status:"ok",pagesIn:n.pages,pagesOut:n.pages,bytesIn:n.sizeBytes,bytesOut:n.sizeBytes,note:"Added"}
))],log:a.length?L(o.log,"Documents added",`${
a.length}
`):o.log}
)),r.length&&h.success(`Reconnected ${
r.length}
 document(s) from the project.`)}
,J=s=>l(a=>({
...a,steps:a.steps.includes(s)?a.steps.filter(r=>r!==s):[...a.steps,s].sort((r,o)=>N.indexOf(r)-N.indexOf(o))}
)),O=t.docs.filter(s=>!c.current.has(s.id)),V=async()=>{
if(t.docs.length){
j(!0),k.current=!1,v(null);
try{
const s={
}
;
c.current.forEach((r,o)=>{
s[o]=r}
);
const a=await je(t,s,be,{
onStep:(r,o)=>S({
doc:r,step:o}
),shouldStop:()=>k.current}
);
l(a.project),v(a),h[a.failed.length?"error":"success"](a.failed.length?`${
a.failed.length}
 document(s) failed. See the audit log.`:"Recipe finished")}
catch(s){
h.error(s instanceof Error?s.message:"The run failed.")}
finally{
j(!1),S(null)}
}
}
,Z=async()=>{
if(x){
j(!0);
try{
const{
blob:s,manifest:a}
=await ie(M,t.name||"Packet",ve(t,x.outputs));
b(s,`${
le(t.name||"packet")}
-packet.zip`,{
free:!0}
),l(r=>({
...r,exports:[...r.exports,{
at:new Date().toISOString(),files:a.count}
],log:L(r.log,"Packet exported",`${
a.count}
 files`)}
))}
finally{
j(!1)}
}
}
,q=async s=>{
if(!s)return;
const a=fe(await s.text());
if(!a.ok){
h.error(a.error);
return}
l(r=>({
...r,steps:a.steps,options:{
...a.options,redactTerms:r.options.redactTerms}
}
)),h.success("Recipe loaded")}
;
return e.jsxs("div",{
className:"space-y-5",children:[e.jsx(oe,{
name:t.name,dirty:U,onSave:K,onOpen:W,onNew:()=>{
c.current.clear(),v(null),G()}
,label:"packet project"}
),e.jsxs("div",{
children:[e.jsx(m,{
htmlFor:"do-name",children:"Packet name"}
),e.jsx(g,{
id:"do-name",value:t.name,onChange:s=>l(a=>({
...a,name:s.target.value}
)),placeholder:"Loan file, new hire pack..."}
)]}
),e.jsxs("section",{
"aria-label":"Documents",className:"space-y-2",children:[e.jsxs("div",{
className:"flex flex-wrap items-center gap-2",children:[e.jsx("input",{
"aria-label":"Add files",ref:D,type:"file",multiple:!0,accept:"application/pdf,.pdf,image/jpeg,image/png,image/webp",hidden:!0,onChange:s=>{
I(s.target.files),s.target.value=""}
}
),e.jsxs(i,{
size:"sm",onClick:()=>D.current?.click(),children:[e.jsx(we,{
className:"h-4 w-4 mr-1.5"}
),"Add documents"]}
),e.jsxs("details",{
className:"rounded-md border px-3 py-1.5 text-sm",children:[e.jsxs("summary",{
className:"cursor-pointer font-medium",children:[e.jsx(ke,{
className:"h-4 w-4 mr-1.5 inline"}
),"Scanner panel"]}
),e.jsxs("div",{
className:"py-2 space-y-2",children:[e.jsxs("p",{
className:"text-muted-foreground",children:["Photograph each page. Pictures are turned into A4 PDF pages by the Scan step. For cropping and straightening, use the ",e.jsx(Y,{
href:u("/tool/document-scanner"),className:"underline",children:"Document Scanner"}
)," first and add its PDF here."]}
),e.jsx("input",{
"aria-label":"Take a photo",ref:R,type:"file",accept:"image/*",capture:"environment",hidden:!0,onChange:s=>{
I(s.target.files),s.target.value=""}
}
),e.jsx(i,{
size:"sm",variant:"outline",onClick:()=>R.current?.click(),children:"Take or choose a photo"}
)]}
)]}
)]}
),O.length>0&&t.docs.length>0&&e.jsxs("p",{
className:"text-sm text-muted-foreground",role:"status",children:[O.length," document(s) came from the project file and need their files added again (the file stores the list, not the contents)."]}
),e.jsxs("ol",{
className:"space-y-1.5","data-testid":"docops-list",children:[t.docs.length===0&&e.jsx("li",{
className:"text-sm text-muted-foreground",children:"No documents yet."}
),t.docs.map((s,a)=>e.jsxs("li",{
className:"flex flex-wrap items-center gap-2 rounded border p-2 text-sm",children:[e.jsx("span",{
className:"font-mono w-6 text-muted-foreground",children:a+1}
),e.jsxs("span",{
className:"mr-auto min-w-0 truncate",title:s.name,children:[s.name," ",e.jsxs("span",{
className:"text-muted-foreground",children:["(",s.kind==="image"?"picture":`${
s.pages}
 page${
s.pages===1?"":"s"}
`,c.current.has(s.id)?"":", file not loaded",")"]}
)]}
),e.jsx(g,{
"aria-label":`Note for ${
s.name}
`,className:"h-8 w-44",placeholder:"Note",value:s.note,onChange:r=>l(o=>({
...o,docs:o.docs.map(n=>n.id===s.id?{
...n,note:r.target.value}
:n)}
))}
),e.jsx(i,{
size:"sm",variant:"ghost","aria-label":`Move ${
s.name}
 up`,disabled:a===0,onClick:()=>l(r=>({
...r,docs:_(r.docs,a,-1)}
)),children:e.jsx(Ne,{
className:"h-4 w-4"}
)}
),e.jsx(i,{
size:"sm",variant:"ghost","aria-label":`Move ${
s.name}
 down`,disabled:a===t.docs.length-1,onClick:()=>l(r=>({
...r,docs:_(r.docs,a,1)}
)),children:e.jsx(Q,{
className:"h-4 w-4"}
)}
),e.jsx(i,{
size:"sm",variant:"ghost","aria-label":`Remove ${
s.name}
`,onClick:()=>{
c.current.delete(s.id),l(r=>({
...r,docs:r.docs.filter(o=>o.id!==s.id)}
))}
,children:e.jsx(ye,{
className:"h-4 w-4"}
)}
)]}
,s.id))]}
)]}
),e.jsxs("section",{
"aria-label":"Recipe",className:"space-y-3",children:[e.jsx("h2",{
className:"font-semibold",children:"Recipe"}
),e.jsxs("div",{
className:"flex flex-wrap gap-2",children:[de.map(s=>e.jsx(i,{
size:"sm",variant:"outline",onClick:()=>l(a=>({
...a,steps:s.steps}
)),children:s.label}
,s.id)),e.jsx("input",{
"aria-label":"Open a recipe file",ref:F,type:"file",accept:".json,application/json",hidden:!0,onChange:s=>{
q(s.target.files?.[0]),s.target.value=""}
}
),e.jsx(i,{
size:"sm",variant:"ghost",onClick:()=>F.current?.click(),children:"Load recipe"}
),e.jsx(i,{
size:"sm",variant:"ghost",onClick:()=>b(new Blob([pe(t)],{
type:"application/json"}
),"packet.fdp-recipe.json",{
free:!0}
),children:"Save recipe"}
)]}
),e.jsx("div",{
className:"flex flex-wrap gap-2",role:"group","aria-label":"Steps",children:N.map(s=>e.jsxs("label",{
className:`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-sm cursor-pointer ${
t.steps.includes(s)?"bg-primary/10 border-primary":""}
`,children:[e.jsx("input",{
type:"checkbox",checked:t.steps.includes(s),onChange:()=>J(s)}
),y[s]]}
,s))}
),e.jsxs("p",{
className:"text-xs text-muted-foreground",children:["Steps run in the order shown: ",t.steps.map(s=>y[s].split(" (")[0]).join(" > ")||"none",". Picture files are scanned to PDF first automatically."]}
),e.jsxs("div",{
className:"grid gap-3 sm:grid-cols-2",children:[t.steps.includes("organize")&&e.jsxs("div",{
children:[e.jsx(m,{
htmlFor:"o-org",children:"Pages to keep, in order (organize)"}
),e.jsx(g,{
id:"o-org",value:t.options.organizePages,onChange:s=>d({
organizePages:s.target.value}
),placeholder:"1-3, 5"}
)]}
),t.steps.includes("redact")&&e.jsxs("div",{
className:"sm:col-span-2",children:[e.jsx(m,{
htmlFor:"o-red",children:"Words to remove, one per line (redact)"}
),e.jsx(X,{
id:"o-red",rows:3,value:t.options.redactTerms,onChange:s=>d({
redactTerms:s.target.value}
)}
)]}
),t.steps.includes("number")&&e.jsxs(e.Fragment,{
children:[e.jsxs("div",{
children:[e.jsx(m,{
htmlFor:"o-np",children:"Number position"}
),e.jsx("select",{
id:"o-np",className:"h-9 w-full rounded-md border bg-background px-2 text-sm",value:t.options.numberPosition,onChange:s=>d({
numberPosition:s.target.value}
),children:["bottom-center","bottom-right","bottom-left","top-center","top-right","top-left"].map(s=>e.jsx("option",{
children:s}
,s))}
)]}
),e.jsxs("div",{
children:[e.jsx(m,{
htmlFor:"o-ns",children:"First number"}
),e.jsx(g,{
id:"o-ns",type:"number",min:1,value:t.options.numberStart,onChange:s=>d({
numberStart:Math.max(1,Number(s.target.value)||1)}
)}
)]}
),e.jsxs("label",{
className:"flex items-center gap-2 text-sm",children:[e.jsx("input",{
type:"checkbox",checked:t.options.numberContinuous,onChange:s=>d({
numberContinuous:s.target.checked}
)}
),"Keep counting across the whole packet"]}
)]}
),t.steps.includes("compress")&&e.jsxs("div",{
children:[e.jsx(m,{
htmlFor:"o-cm",children:"Compression"}
),e.jsxs("select",{
id:"o-cm",className:"h-9 w-full rounded-md border bg-background px-2 text-sm",value:t.options.compressMode,onChange:s=>d({
compressMode:s.target.value}
),children:[e.jsx("option",{
value:"balanced",children:"Balanced"}
),e.jsx("option",{
value:"smallest",children:"Smaller (may turn pages into pictures)"}
)]}
)]}
),t.steps.includes("sign")&&e.jsxs(e.Fragment,{
children:[e.jsxs("div",{
children:[e.jsx(m,{
htmlFor:"o-sn",children:"Name to sign with"}
),e.jsx(g,{
id:"o-sn",value:t.options.signName,onChange:s=>d({
signName:s.target.value}
)}
)]}
),e.jsxs("div",{
children:[e.jsx(m,{
htmlFor:"o-sd",children:"Date"}
),e.jsx(g,{
id:"o-sd",type:"date",value:t.options.signDate,onChange:s=>d({
signDate:s.target.value}
)}
)]}
)]}
)]}
),z.length>0&&e.jsx("ul",{
className:"list-disc pl-5 text-sm space-y-1",role:"status","data-testid":"docops-warnings",children:z.map(s=>e.jsx("li",{
children:s}
,s))}
)]}
),e.jsxs("div",{
className:"flex flex-wrap gap-2 border-t pt-4",children:[e.jsxs(i,{
onClick:()=>{
V()}
,disabled:f||t.docs.length===0||t.steps.length===0,children:[e.jsx(ee,{
className:"h-4 w-4 mr-1.5"}
),f?"Running...":"Run recipe"]}
),f&&e.jsxs(i,{
variant:"outline",onClick:()=>{
k.current=!0}
,children:[e.jsx(Pe,{
className:"h-4 w-4 mr-1.5"}
),"Stop"]}
),e.jsxs(i,{
variant:"outline",disabled:f||!x||Object.keys(x.outputs).length===0,onClick:()=>{
Z()}
,children:[e.jsx(Ce,{
className:"h-4 w-4 mr-1.5"}
),"Export packet"]}
),e.jsxs(i,{
variant:"outline",disabled:t.audit.length===0,onClick:()=>b(new Blob([me(t.audit)],{
type:"text/csv;
charset=utf-8"}
),"audit-log.csv",{
free:!0}
),children:[e.jsx(se,{
className:"h-4 w-4 mr-1.5"}
),"Audit log (CSV)"]}
),e.jsx(i,{
variant:"ghost",disabled:t.log.length===0,onClick:()=>b(new Blob([ne(t.log)],{
type:"text/csv;
charset=utf-8"}
),"desk-log.csv",{
free:!0}
),children:"Desk log"}
)]}
),w&&e.jsxs("p",{
role:"status",className:"text-sm text-muted-foreground",children:["Working on ",w.doc,": ",y[w.step],"..."]}
),t.audit.length>0&&e.jsxs("section",{
"aria-label":"Audit log",children:[e.jsx("h2",{
className:"font-semibold mb-2",children:"Audit log"}
),e.jsx("div",{
className:"overflow-x-auto max-h-72 overflow-y-auto",children:e.jsxs("table",{
className:"w-full text-sm",children:[e.jsx("caption",{
className:"sr-only",children:"Steps done on each document"}
),e.jsx("thead",{
children:e.jsxs("tr",{
className:"text-left border-b",children:[e.jsx("th",{
scope:"col",className:"py-1 pr-2",children:"Document"}
),e.jsx("th",{
scope:"col",className:"pr-2",children:"Step"}
),e.jsx("th",{
scope:"col",className:"pr-2",children:"Result"}
),e.jsx("th",{
scope:"col",children:"Note"}
)]}
)}
),e.jsx("tbody",{
children:[...t.audit].reverse().slice(0,200).map(s=>e.jsxs("tr",{
className:"border-b",children:[e.jsx("td",{
className:"py-1 pr-2",children:s.doc}
),e.jsx("td",{
className:"pr-2",children:s.step}
),e.jsx("td",{
className:`pr-2 ${
s.status==="error"?"text-destructive font-medium":""}
`,children:s.status}
),e.jsx("td",{
className:"text-muted-foreground",children:s.note}
)]}
,s.id))}
)]}
)}
)]}
)]}
)}
export{
Ks as default}
;

//# sourceMappingURL=DocumentOperationsDesk-DxX6-EiM.js.map
