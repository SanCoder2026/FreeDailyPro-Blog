import{
j as c,r as f}
from"./vendor-react-D01g8YgM.js";
import{
N,f as h,B as g}
from"./index-DagluEtV.js";
import{
T as D,d as F}
from"./ToolPage-B4roIUf_.js";
import{
W as O}
from"./WorkflowProductGate-BDNk2iP2.js";
import{
P as E}
from"./ProfileBar-DVGYCHer.js";
import{
F as $}
from"./folder-open-B4DxBSqT.js";
import{
F as T}
from"./file-down-TL37fn4x.js";
import{
F as C}
from"./file-plus-2-CpogWspv.js";
import{
J as P}
from"./jszip.min-CT0ZA6V1.js";
import{
c as w}
from"./csv-DBvSFDe9.js";
const k="freedailypro-desk",A=25e6,S=t=>typeof t=="object"&&t!==null&&!Array.isArray(t),u=(t,e=500)=>typeof t=="string"?t.replace(/\u0000/g,"").slice(0,e):typeof t=="number"&&Number.isFinite(t)?String(t):"",ee=(t,e=0,s=1e9)=>{
const r=typeof t=="number"?t:typeof t=="string"?Number(t.replace(/[, ]/g,"")):NaN;
return Number.isFinite(r)?Math.min(s,Math.max(e,r)):0}
,B=(t,e)=>Array.isArray(t)?t.slice(0,e):[];
function te(t){
const e=u(t,10);
if(!/^\d{
4}
-\d{
2}
-\d{
2}
$/.test(e))return"";
const s=new Date(`${
e}
T00:00:00Z`);
return Number.isNaN(s.getTime())||s.toISOString().slice(0,10)!==e?"":e}
let y=0;
function x(t="id",e=Date.now()){
return y=(y+1)%1e6,`${
t}
-${
e.toString(36)}
${
y.toString(36)}
${
Math.floor(Math.random()*1296).toString(36)}
`}
function L(t,e,s,r=new Date){
const n={
app:k,desk:t,version:e,saved:r.toISOString(),data:s}
;
return JSON.stringify(n,null,2)}
function I(t,e,s,r){
if(t.length>A)return{
ok:!1,error:"That file is too large to be a project file."}
;
let n;
try{
n=JSON.parse(t)}
catch{
return{
ok:!1,error:"That file is not a project file (it is not valid JSON)."}
}
if(!S(n)||n.app!==k)return{
ok:!1,error:"That file was not saved by a FreeDailyPro desk."}
;
if(n.desk!==e)return{
ok:!1,error:`That project file belongs to a different desk (${
u(n.desk,40)||"unknown"}
).`}
;
const a=typeof n.version=="number"?n.version:0;
return a>s?{
ok:!1,error:"That file was saved by a newer version of this desk. Reload the page and try again."}
:a<1?{
ok:!1,error:"That project file has no valid version."}
:{
ok:!0,data:r(n.data),saved:u(n.saved,40)}
}
function z(t,e="project"){
return t.replace(/[^\w.-]+/g,"-").replace(/^-+|-+$/g,"").slice(0,50)||e}
function ne(t){
const[e,s]=f.useState(t.empty),[r,n]=f.useState(!1),a=f.useRef(t);
a.current=t;
const i=f.useCallback(l=>{
s(p=>typeof l=="function"?l(p):l),n(!0)}
,[]),o=f.useCallback(()=>{
const l=a.current;
F(new Blob([L(l.desk,l.version,e)],{
type:"application/json"}
),`${
z(l.nameOf(e))}
.fdp-${
l.desk}
.json`,{
free:!0}
),n(!1),h.success("Project saved to a file. Keep it: it is the only copy.")}
,[e]),d=f.useCallback(async l=>{
if(!l)return;
const p=a.current,m=I(await l.text(),p.desk,p.version,p.normalize);
if(!m.ok){
h.error(m.error);
return}
s(m.data),n(!1),h.success("Project opened")}
,[]),v=f.useCallback(()=>{
s(a.current.empty()),n(!1)}
,[]);
return f.useEffect(()=>{
if(!r)return;
const l=p=>{
p.preventDefault(),p.returnValue=""}
;
return window.addEventListener("beforeunload",l),()=>window.removeEventListener("beforeunload",l)}
,[r]),{
data:e,setData:i,dirty:r,save:o,open:d,reset:v}
}
function re({
name:t,dirty:e,onSave:s,onOpen:r,onNew:n,label:a="project"}
){
const i=f.useRef(null);
return c.jsxs("div",{
className:"flex flex-wrap items-center gap-2 rounded-lg border p-3 mb-3","data-testid":"desk-project-bar",children:[c.jsxs("div",{
className:"mr-auto min-w-0",children:[c.jsx("p",{
className:"text-sm font-medium truncate",children:t||`Untitled ${
a}
`}
),c.jsxs("p",{
className:"text-xs text-muted-foreground",children:[e?"Changes not saved to a file yet.":"Saved or unchanged."," The file on your device is the only copy;
 we keep nothing."]}
)]}
),c.jsx("input",{
ref:i,type:"file",accept:".json,application/json",hidden:!0,onChange:o=>{
r(o.target.files?.[0]),o.target.value=""}
}
),c.jsxs(g,{
variant:"outline",size:"sm",onClick:()=>i.current?.click(),children:[c.jsx($,{
className:"h-4 w-4 mr-1.5"}
),"Open ",a]}
),c.jsxs(g,{
size:"sm",onClick:s,children:[c.jsx(T,{
className:"h-4 w-4 mr-1.5"}
),"Save ",a]}
),c.jsxs(g,{
variant:"ghost",size:"sm",onClick:()=>{
(!e||window.confirm("Start a new project? Unsaved changes will be lost."))&&n()}
,children:[c.jsx(C,{
className:"h-4 w-4 mr-1.5"}
),"New"]}
)]}
)}
function se({
product:t,caveat:e,profile:s=!0,children:r}
){
return c.jsx(O,{
product:t,children:c.jsxs(D,{
children:[e&&c.jsx(N,{
className:"mb-3 text-sm",testId:"desk-caveat",children:e}
),s&&c.jsx("div",{
className:"mb-3",children:c.jsx(E,{
compact:!0}
)}
),r]}
)}
)}
function M(t){
return t.replace(/\\/g,"/").split("/").map(s=>s.replace(/[\u0000-\u001f<>:"|?*]/g,"").replace(/^\.+$/,"").trim()).filter(Boolean).join("/").slice(0,180)||"file"}
function J(t){
const e=new Set;
return t.map(s=>{
const r=M(s);
let n=r,a=1;
for(;
e.has(n.toLowerCase());
){
a++;
const i=r.lastIndexOf("."),o=r.lastIndexOf("/");
n=i>o+1?`${
r.slice(0,i)}
 (${
a}
)${
r.slice(i)}
`:`${
r}
 (${
a}
)`}
return e.add(n.toLowerCase()),n}
)}
const j=t=>typeof t=="string"?new TextEncoder().encode(t):t;
async function _(t){
const e=j(t),s=await crypto.subtle.digest("SHA-256",e.buffer.slice(e.byteOffset,e.byteOffset+e.byteLength));
return Array.from(new Uint8Array(s)).map(r=>r.toString(16).padStart(2,"0")).join("")}
async function R(t,e,s,r=new Date){
const n=J(s.map(o=>o.path)),a=s.map((o,d)=>({
...o,path:n[d]}
)),i=[];
for(let o=0;
o<a.length;
o++)i.push({
order:o+1,path:a[o].path,bytes:j(a[o].data).byteLength,sha256:await _(a[o].data),description:a[o].description}
);
return{
manifest:{
app:"freedailypro-packet",desk:t,project:e,generated:r.toISOString(),count:i.length,files:i}
,files:a}
}
function W(t){
return"\uFEFF"+["Order,File,Bytes,SHA-256,Description",...t.files.map(e=>[e.order,e.path,e.bytes,e.sha256,e.description].map(w).join(","))].join(`\r
`)+`\r
`}
async function ae(t,e,s,r=new Date){
const{
manifest:n,files:a}
=await R(t,e,s,r),i=new P;
for(const o of a)i.file(o.path,j(o.data),{
date:r}
);
return i.file("manifest.json",JSON.stringify(n,null,2),{
date:r}
),i.file("manifest.csv",W(n),{
date:r}
),{
blob:await i.generateAsync({
type:"blob",compression:"DEFLATE"}
),manifest:n}
}
const oe=(t,e)=>new Blob([t],{
type:e}
),b=5e3;
function ie(t,e,s,r=new Date){
const n=[...t,{
id:x("log",r.getTime()),at:r.toISOString(),action:u(e,60),detail:u(s,300)}
];
return n.length>b?n.slice(n.length-b):n}
function ce(t){
return B(t,b).filter(S).map(e=>({
id:u(e.id,40)||x("log"),at:u(e.at,40),action:u(e.action,60),detail:u(e.detail,300)}
))}
function le(t){
return"\uFEFF"+["When,What,Detail",...t.map(e=>[e.at,e.action,e.detail].map(w).join(","))].join(`\r
`)+`\r
`}
export{
se as D,re as P,ie as a,ae as b,B as c,ce as d,ee as e,z as f,u as g,J as h,S as i,te as j,oe as k,le as l,x as n,ne as u}
;

//# sourceMappingURL=auditLog-DSfy6bBy.js.map
