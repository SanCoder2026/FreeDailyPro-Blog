import{
i as P,c as z,d as C,e as m,g as p,n as x,a as R,h as I}
from"./auditLog-DSfy6bBy.js";
import{
c as L}
from"./csv-DBvSFDe9.js";
import{
k as T,S as F,u as v}
from"./index-BRvxULIc.js";
import{
e as E,n as j,q as M,t as A,u as B,x as _}
from"./operations-BlL6iX51.js";
import{
redactPdfPages as q}
from"./redactApply-BSsjW140.js";
import{
f as H}
from"./redactSearch-DQpyyh_t.js";
const $="document-operations-desk",ae=1,J=["scan","ocr","organize","redact","number","compress","sign"],oe={
scan:"Scan (pictures to PDF)",ocr:"OCR (make text searchable)",organize:"Organize (page order)",redact:"Redact (remove words)",number:"Number pages",compress:"Compress",sign:"Sign"}
,D=()=>({
ocrLanguage:"eng",organizePages:"",redactTerms:"",numberPosition:"bottom-center",numberStart:1,numberContinuous:!1,numberFormat:"plain",compressMode:"balanced",signName:"",signDate:""}
),W=()=>({
name:"",docs:[],steps:["ocr","number","compress"],options:D(),audit:[],exports:[],log:[]}
),re=[{
id:"archive",label:"Scan to archive",steps:["scan","ocr","number","compress"]}
,{
id:"share",label:"Share safely",steps:["ocr","redact","number","compress"]}
,{
id:"sign",label:"Sign and send",steps:["organize","number","compress","sign"]}
,{
id:"full",label:"Full packet",steps:["scan","ocr","organize","redact","number","compress","sign"]}
],N=e=>J.includes(String(e));
function K(e){
const s=W();
if(!P(e))return s;
const t=P(e.options)?e.options:{
}
,n=D(),o=["bottom-center","bottom-right","bottom-left","top-center","top-right","top-left"],g=z(e.steps,20).filter(N).filter((a,i,d)=>d.indexOf(a)===i);
return{
name:p(e.name,120),docs:z(e.docs,2e3).filter(P).map(a=>({
id:p(a.id,40)||x("doc"),name:p(a.name,200),kind:a.kind==="image"?"image":"pdf",sizeBytes:Math.round(m(a.sizeBytes,0,5e9)),pages:Math.round(m(a.pages,0,1e5)),note:p(a.note,500)}
)),steps:e.steps===void 0?s.steps:g,options:{
ocrLanguage:/^[a-z]{
3}
(\+[a-z]{
3}
)*$/.test(p(t.ocrLanguage,20))?p(t.ocrLanguage,20):n.ocrLanguage,organizePages:p(t.organizePages,200).replace(/[^\d,;
\- ]/g,""),redactTerms:p(t.redactTerms,4e3),numberPosition:o.includes(String(t.numberPosition))?t.numberPosition:n.numberPosition,numberStart:Math.round(m(t.numberStart,1,1e5))||1,numberContinuous:t.numberContinuous===!0,numberFormat:t.numberFormat==="page-of-total"?"page-of-total":"plain",compressMode:t.compressMode==="smallest"?"smallest":"balanced",signName:p(t.signName,120),signDate:p(t.signDate,20)}
,audit:z(e.audit,2e4).filter(P).map(a=>({
id:p(a.id,40)||x("aud"),at:p(a.at,40),doc:p(a.doc,200),step:N(a.step)?a.step:a.step==="export"?"export":"intake",status:a.status==="error"?"error":a.status==="skipped"?"skipped":"ok",pagesIn:Math.round(m(a.pagesIn,0,1e6)),pagesOut:Math.round(m(a.pagesOut,0,1e6)),bytesIn:Math.round(m(a.bytesIn,0,5e10)),bytesOut:Math.round(m(a.bytesOut,0,5e10)),note:p(a.note,300)}
)),exports:z(e.exports,1e3).filter(P).map(a=>({
at:p(a.at,40),files:Math.round(m(a.files,0,1e5))}
)),log:C(e.log)}
}
function ie(e,s){
const t=[],n=o=>e.indexOf(o);
return n("redact")>=0&&n("ocr")>=0&&n("redact")<n("ocr")&&t.push("Redact runs before OCR. Scanned pages have no text to find until OCR has read them, so run OCR first."),n("redact")>=0&&n("ocr")<0&&t.push("Redact finds typed words. Pages that are pictures of text need OCR first, or the words will not be found."),n("redact")>=0&&!s.redactTerms.trim()&&t.push("Redact has no words to remove. Add one per line."),n("number")>=0&&n("organize")>=0&&n("number")<n("organize")&&t.push("Numbers are added before the pages are re-ordered, so they will not run in order. Number after Organize."),n("number")>=0&&n("compress")>=0&&n("compress")<n("number")&&t.push("Compress runs before numbering. That works, but numbering last keeps the numbers sharp."),n("sign")>=0&&n("sign")!==e.length-1&&t.push("Sign is not the last step. Later steps change the file after it is signed."),n("sign")>=0&&!s.signName.trim()&&t.push("Sign has no name. Type the name to print on the signature line."),n("organize")>=0&&!s.organizePages.trim()&&t.push("Organize has no page list, so it will keep every page in its current order."),t}
function pe(e,s,t){
const n=s+t;
if(s<0||n<0||n>=e.length||s>=e.length)return e;
const o=e.slice();
return[o[s],o[n]]=[o[n],o[s]],o}
const U=e=>I(e.map((s,t)=>`${
String(t+1).padStart(2,"0")}
-${
s.name.replace(/\.[^.]+$/,"")}
.pdf`));
async function ce(e,s,t,n={
}
){
const o=n.now??(()=>new Date),g=[],a={
}
,i=[],d=(r,k,c,y,O,u="")=>{
g.push({
id:x("aud",o().getTime()),at:o().toISOString(),doc:r,step:k,status:c,pagesIn:y.pages,pagesOut:O.pages,bytesIn:y.bytes,bytesOut:O.bytes,note:u}
)}
;
let l=e.options.numberStart;
for(const r of e.docs){
if(n.shouldStop?.())break;
const k=s[r.id];
if(!k){
d(r.name,"intake","error",{
pages:r.pages,bytes:0}
,{
pages:0,bytes:0}
,"File is not loaded. Add it again."),i.push(r.id);
continue}
let c={
bytes:k,name:r.name,kind:r.kind,pages:r.pages}
,y=!1;
const O=r.kind==="image"&&!e.steps.includes("scan")?["scan",...e.steps]:e.steps;
for(const u of O){
if(n.shouldStop?.())break;
n.onStep?.(r.name,u);
const b={
pages:c.pages,bytes:c.bytes.byteLength}
;
if(u==="scan"&&c.kind==="pdf"){
d(r.name,u,"skipped",b,b,"Already a PDF");
continue}
if(u!=="scan"&&c.kind==="image"){
d(r.name,u,"error",b,b,"Not a PDF yet. Add Scan before this step."),y=!0;
break}
try{
const w={
options:e.options,numberFrom:e.options.numberContinuous?l:e.options.numberStart,docName:r.name}
,h=await t[u](c,w);
d(r.name,u,h.skipped?"skipped":"ok",b,{
pages:h.pages,bytes:h.bytes.byteLength}
,h.note??""),c={
bytes:h.bytes,name:c.name,kind:"pdf",pages:h.pages}
}
catch(w){
d(r.name,u,"error",b,b,w instanceof Error?w.message.slice(0,200):"Failed"),y=!0;
break}
}
if(y){
i.push(r.id);
continue}
c.kind==="pdf"&&(a[r.id]={
bytes:c.bytes,pages:c.pages}
,l+=c.pages)}
return{
project:{
...e,audit:[...e.audit,...g],docs:e.docs.map(r=>a[r.id]?{
...r,pages:a[r.id].pages}
:r),log:R(e.log,"Recipe run",`${
Object.keys(a).length}
 of ${
e.docs.length}
 documents, ${
i.length}
 failed`,o())}
,outputs:a,failed:i}
}
function V(e){
return"\uFEFF"+["When,Document,Step,Result,Pages in,Pages out,Bytes in,Bytes out,Note",...e.map(s=>[s.at,s.doc,s.step,s.status,s.pagesIn,s.pagesOut,s.bytesIn,s.bytesOut,s.note].map(L).join(","))].join(`\r
`)+`\r
`}
function G(e){
return JSON.stringify({
app:"freedailypro-recipe",desk:$,version:1,steps:e.steps,options:{
...e.options,redactTerms:""}
}
,null,2)}
function ge(e){
let s;
try{
s=JSON.parse(e)}
catch{
return{
ok:!1,error:"That is not a recipe file."}
}
if(!P(s)||s.app!=="freedailypro-recipe"||s.desk!==$)return{
ok:!1,error:"That is not a Document Operations recipe."}
;
const t=K({
steps:s.steps,options:s.options}
);
return{
ok:!0,steps:t.steps,options:t.options}
}
function de(e,s){
const t=e.docs.filter(o=>s[o.id]),n=U(t);
return[...t.map((o,g)=>({
path:n[g],data:s[o.id].bytes,description:`${
o.name}
: ${
s[o.id].pages}
 page(s)${
o.note?`. ${
o.note}
`:""}
`}
)),{
path:"audit-log.csv",data:V(e.audit),description:"Every step done on every document"}
,{
path:"recipe.json",data:G(e),description:"The recipe used (redaction words are not saved)"}
]}
const f=(e,s="application/pdf")=>new File([e.bytes],e.name,{
type:s}
),S=async e=>new Uint8Array(await e.arrayBuffer());
async function Q(e){
return(await T.load(e,{
ignoreEncryption:!0}
)).getPageCount()}
const ue={
async scan(e){
const s=await S(await _([f(e,"image/jpeg")],"a4"));
return{
bytes:s,pages:await Q(s),note:"Picture placed on an A4 page"}
}
,async ocr(e,s){
const t=await B(f(e),void 0,{
language:s.options.ocrLanguage}
);
return{
bytes:await S(t.blob),pages:e.pages,note:t.pagesOcrd?`${
t.pagesOcrd}
 page(s) read${
t.unreadablePages.length?`, unreadable: ${
t.unreadablePages.join(", ")}
`:""}
`:"Pages already had text",skipped:t.pagesOcrd===0}
}
,async organize(e,s){
if(!s.options.organizePages.trim())return{
bytes:e.bytes,pages:e.pages,note:"No page list",skipped:!0}
;
const t=M(s.options.organizePages,e.pages);
if("error"in t)throw new Error(t.error);
return{
bytes:await S(await A(f(e),t.pages)),pages:t.pages.length,note:`Pages kept: ${
s.options.organizePages}
`}
}
,async redact(e,s){
const t=s.options.redactTerms.split(/\r?\n/).map(i=>i.trim()).filter(Boolean).join(`
`);
if(!t)return{
bytes:e.bytes,pages:e.pages,note:"No words listed",skipped:!0}
;
const n=await H(f(e),t,{
}
),o={
}
;
let g=0;
for(const[i,d]of Object.entries(n.boxes))o[Number(i)]=d.map(l=>({
x:l.x,y:l.y,w:l.w,h:l.h}
)),g+=d.length;
if(g===0)return{
bytes:e.bytes,pages:e.pages,note:n.pagesWithoutText.length?`No matches. ${
n.pagesWithoutText.length}
 page(s) have no text (run OCR first).`:"No matches",skipped:!0}
;
const a=await q(f(e),e.pages,o,void 0,{
removeHidden:!0,query:t}
);
return{
bytes:await S(a.blob),pages:e.pages,note:`${
g}
 area(s) removed${
a.rasterizedPages.length?`;
 ${
a.rasterizedPages.length}
 page(s) became pictures`:""}
`}
}
,async number(e,s){
const t=s.options;
return{
bytes:await S(await j(f(e),t.numberPosition,s.numberFrom,{
format:t.numberFormat}
)),pages:e.pages,note:`From ${
s.numberFrom}
`}
}
,async compress(e,s){
const t=await E(f(e),s.options.compressMode==="smallest"?"aggressive":"balanced");
return t.status!=="ok"||t.bytes.byteLength>=e.bytes.byteLength?{
bytes:e.bytes,pages:e.pages,note:"Already small;
 kept as it was",skipped:!0}
:{
bytes:t.bytes,pages:e.pages,note:`${
Math.round((1-t.bytes.byteLength/e.bytes.byteLength)*100)}
% smaller`}
}
,async sign(e,s){
const t=s.options;
if(!t.signName.trim())return{
bytes:e.bytes,pages:e.pages,note:"No name",skipped:!0}
;
const n=await T.load(e.bytes),o=n.getPage(n.getPageCount()-1),g=await n.embedFont(F.HelveticaOblique),a=d=>d.replace(/[^\x20-\x7e]/g,"?"),{
width:i}
=o.getSize();
return o.drawLine({
start:{
x:i-260,y:64}
,end:{
x:i-50,y:64}
,thickness:.8,color:v(.3,.3,.3)}
),o.drawText(a(t.signName),{
x:i-255,y:70,size:14,font:g,color:v(.05,.1,.4)}
),o.drawText(a(`Signed ${
t.signDate||new Date().toISOString().slice(0,10)}
`),{
x:i-255,y:52,size:8,font:await n.embedFont(F.Helvetica),color:v(.35,.35,.35)}
),{
bytes:await n.save(),pages:n.getPageCount(),note:"Typed signature line on the last page (not a certified e-signature)"}
}
}
;
export{
ae as D,re as R,J as S,G as a,oe as b,V as c,$ as d,W as e,Q as f,ce as g,ue as h,de as i,pe as m,K as n,ge as p,ie as r}
;

//# sourceMappingURL=docOpsEngine-lVJXDlBe.js.map
