import{
j as e,r as y}
from"./vendor-react-D01g8YgM.js";
import{
J as se}
from"./jszip.min-CT0ZA6V1.js";
import{
z as ae,e as g,I as u,ck as re,B as f,N as G,b as ie,W as oe,D as $,f as w,L as ne}
from"./index-DagluEtV.js";
import{
utils as T,write as q}
from"./xlsx-CNerDvZX.js";
import{
T as le,F as ce,f as de,d as S}
from"./ToolPage-B4roIUf_.js";
import{
T as me}
from"./ToolInfoSection-C0Lbi6Qb.js";
import{
B as he}
from"./BackupBar-Dwyy8z0X.js";
import{
W as pe}
from"./WorkflowProductGate-BDNk2iP2.js";
import{
u as Z}
from"./useSessionStored-D48dwW0m.js";
import{
s as R}
from"./csvParse-eP1CzDn2.js";
import{
l as H}
from"./utils-s8ucLyj8.js";
import{
f as Y,D as ue,s as xe}
from"./batesNumbering-CBMvEZsH.js";
import{
T as ge}
from"./trash-2-DpHY4NWT.js";
import"./jszip.min-C-FLQHAz.js";
import"./_commonjs-dynamic-modules-TDtrdbi3.js";
import"./useUploadApi-Cwp1vwlT.js";
import"./cloudStorage-BzUdFuQl.js";
import"./camera-CL8JsD0s.js";
import"./share-2-B34wyobX.js";
import"./copy-CQptMDp5.js";
import"./workflowCta-oWYKzOWD.js";
import"./UsageAndUpgradeStrip-BiAdGTIF.js";
import"./access-BSSUf40u.js";
import"./useAdminAccess-CYp3AlSq.js";
import"./tool-name-translations-d1j9ms8v.js";
import"./InstallToolButton-CgocG3qD.js";
import"./map-pin-DvVDRebE.js";
import"./FaqSection-DsOLPaJ0.js";
import"./ToolVideoEmbed-CZwBIyFf.js";
import"./GuideLinks-BVE0aHrc.js";
import"./blog-BPnsEI_q.js";
import"./info-56I4OKVq.js";
import"./productCards-CUOqxId0.js";
import"./layers-BVDCe9zx.js";
import"./usePwaManifest-D8HDEEPW.js";
import"./CollapsibleText-DmEVOuX4.js";
import"./chevron-up-B0wsCoBg.js";
import"./useExportGate-CyqDPJOh.js";
import"./backup-CkEgSyOW.js";
import"./index-BRvxULIc.js";
import"./index-CnXdQaNG.js";
import"./index-DMQTJy3b.js";
import"./pageView-BQIwVYOi.js";
import"./pdfMetadata-CcxIhQF2.js";
const fe={
matter:"",party:"",prefix:"ABC",start:"1",digits:"6",controlPrefix:"DOC-"}
,z={
produce:"Produce in full",redact:"Produce with redactions",withhold:"Withhold"}
;
function be(a){
const r=a.trim();
if(!/^\d{
1,6}
$/.test(r))return null;
const s=Number(r);
return s>=1?s:null}
function we(a){
const r=Number(a.start),s=Number(a.digits);
return!/^\d+$/.test(a.start.trim())||!Number.isInteger(r)||r<0?"The starting number has to be a whole number, 0 or higher.":!/^\d+$/.test(a.digits.trim())||s<1||s>10?"Digits has to be a whole number from 1 to 10.":a.prefix.length>30||a.controlPrefix.length>30?"Prefixes can be up to 30 characters.":null}
function je(a,r){
const s=[],l=[],m=we(r);
m&&s.push(m);
const x=Number(r.start)||0,p=Math.min(10,Math.max(1,Number(r.digits)||6));
let v=x;
const P=[],k={
}
;
let M=0,E=0,F=0,A=0;
a.forEach((c,D)=>{
const B=c.name.trim()||`Row ${
D+1}
`,j=be(c.pages),O=`${
r.controlPrefix}
${
String(D+1).padStart(4,"0")}
`;
if(!c.name.trim())s.push(`Row ${
D+1}
 has no document name.`);
else{
const L=c.name.trim().toLowerCase();
k[L]=(k[L]||0)+1,k[L]===2&&l.push(`"${
c.name.trim()}
" is listed more than once. Check it is not produced twice.`)}
j===null&&s.push(`${
B}
: the page count has to be a whole number of 1 or more.`);
let N="",C="",I=null;
c.treatment==="withhold"?(E++,c.basis.trim()||l.push(`${
B}
 is withheld but no reason is given.`)):(c.treatment==="redact"?(F++,c.basis.trim()||l.push(`${
B}
 is redacted but the redactions are not described.`)):M++,j!==null&&(I=v,N=Y(r.prefix,v,p),C=Y(r.prefix,v+j-1,p),String(v+j-1).length>p&&s.push(`${
B}
: the number ${
v+j-1}
 needs more than ${
p}
 digits. Raise the digits.`),v+=j,A+=j)),P.push({
control:O,name:c.name.trim(),pages:j,treatment:c.treatment,begin:N,end:C,startNum:I,basis:c.basis.trim(),exhibit:c.exhibit.trim(),notes:c.notes.trim()}
)}
);
const n=P.filter(c=>c.begin);
return a.length&&!n.length&&!s.length&&l.push("Every document is withheld, so no Bates numbers were handed out."),{
rows:P,produced:M,withheld:E,redacted:F,pageCount:A,firstBates:n.length?n[0].begin:"",lastBates:n.length?n[n.length-1].end:"",problems:s,warnings:l}
}
function Q(a){
return[["Control no.","Document","Pages","Treatment","Bates begin","Bates end","Basis or redactions","Exhibit","Notes"],...a.rows.map(r=>[r.control,r.name,r.pages??"",z[r.treatment],r.begin,r.end,r.basis,r.exhibit,r.notes])]}
function X(a){
return[["Control no.","Document","Pages","Reason withheld","Notes"],...a.rows.filter(r=>r.treatment==="withhold").map(r=>[r.control,r.name,r.pages??"",r.basis,r.notes])]}
function ee(a,r){
const s=["Control no.","Bates begin","Bates end","Date","Author","Recipients","General description","Privilege or protection claimed","Treatment"],l=[];
return a.rows.forEach((m,x)=>{
if(m.treatment==="produce")return;
const p=r[x];
l.push([m.control,m.begin,m.end,(p.date??"").trim(),(p.author??"").trim(),(p.recipients??"").trim(),(p.description??"").trim()||m.name,m.basis,z[m.treatment]])}
),[s,...l]}
function ve(a,r){
const s=[];
return a.rows.forEach((l,m)=>{
if(l.treatment==="produce")return;
const x=r[m],p=[!(x.date??"").trim()&&"date",!(x.author??"").trim()&&"author",!(x.recipients??"").trim()&&"recipients"].filter(Boolean);
p.length&&s.push(`${
l.name||`Row ${
m+1}
`}
: no ${
p.join(", ")}
 yet.`)}
),s}
function Ne(a,r){
const s=[];
(a.letterDate??"").trim()&&s.push((a.letterDate??"").trim(),""),(a.recipient??"").trim()&&s.push((a.recipient??"").trim(),""),a.matter.trim()&&s.push(`Re: ${
a.matter.trim()}
`),(a.volume??"").trim()&&s.push(`Production volume: ${
(a.volume??"").trim()}
`),s.push("");
const l=a.party.trim()||"The producing party",m=r.produced+r.redacted;
return s.push(`${
l}
 produces ${
m}
 document${
m===1?"":"s"}
 (${
r.pageCount}
 page${
r.pageCount===1?"":"s"}
)${
r.firstBates?`, numbered ${
r.firstBates}
 through ${
r.lastBates}
`:""}
.`),r.redacted&&s.push(`${
r.redacted}
 of these ${
r.redacted===1?"has":"have"}
 redactions, described in the enclosed log.`),r.withheld&&s.push(`${
r.withheld}
 document${
r.withheld===1?" is":"s are"}
 withheld, listed in the enclosed privilege log.`),s.push("","Enclosed: production log"+(r.withheld||r.redacted?" and privilege log":"")+".","","Sincerely,","",(a.sender??"").trim()),s.join(`
`).replace(/\n{
3,}
/g,`

`).trim()+`
`}
function ye(a,r){
const s=[];
return a.rows.forEach((l,m)=>{
if(l.treatment==="withhold")return;
const x=r[m];
x==null?s.push(`${
l.name||`Row ${
m+1}
`}
: attach its PDF.`):l.pages!==null&&x!==l.pages&&s.push(`${
l.name||`Row ${
m+1}
`}
: the file has ${
x}
 page${
x===1?"":"s"}
 but the list says ${
l.pages}
.`)}
),s}
function Ce(a,r){
const s=a.name.replace(/\.pdf$/i,"").replace(/[\\/:*?"<>|]+/g,"_").trim()||"document";
let l=`${
a.begin}
_${
s}
.pdf`,m=2;
for(;
r.has(l.toLowerCase());
)l=`${
a.begin}
_${
s}
 (${
m++}
).pdf`;
return r.add(l.toLowerCase()),l}
const $e=[{
id:"ocr",title:"Make scans searchable",tool:"ocr-pdf",toolName:"OCR PDF",text:"Scanned pages have no text to search or redact until they are read."}
,{
id:"redact",title:"Redact",tool:"redact-pdf",toolName:"Redact PDF",text:"Mark and remove personal details for the documents set to Produce with redactions."}
,{
id:"merge",title:"Assemble",tool:"merge-pdf",toolName:"Merge PDF",text:"Combine pages into the documents you will produce, in order."}
,{
id:"exhibit",title:"Label exhibits",tool:"exhibit-stamper",toolName:"Exhibit Stamper",text:"Stamp Exhibit A, B, C or numbers and get an exhibit index."}
,{
id:"bates",title:"Number",tool:"bates-numbering",toolName:"Bates Numbering",text:"Use the prefix and starting number from this desk so the stamps match the log."}
,{
id:"bookmarks",title:"Bookmark",tool:"pdf-bookmarks-editor",toolName:"PDF Bookmarks Editor",text:"Add bookmarks so a long production can be navigated."}
,{
id:"compress",title:"Reduce size",tool:"compress-pdf",toolName:"Compress PDF",text:"Shrink files that are too large to send."}
],V={
what:"A workspace for preparing a set of documents to hand over. List the documents with their page counts, say which are produced, redacted or withheld, and the desk hands out running Bates number ranges. One button stamps every produced PDF and builds a folder as a ZIP: the stamped documents, the production log, the withheld list, a privilege log and a cover letter. It also points you to the tools that do the earlier steps: OCR, redact, merge, exhibit labels, bookmarks. Nothing is uploaded;
 your files and lists stay in this tab and are cleared when you close it.",how:"Set the Bates prefix and starting number, then drop your PDFs or add rows by hand. Choose what happens to each document, using the redacted copy for any document marked Produce with redactions. Fill in the privilege log details for withheld and redacted documents, check the cover letter, then build the production ZIP. Use Back up to save a matter as a file and Restore to open it later.",tip:"The ranges follow the order of the list, so put the documents in the order you will merge and stamp them. Withheld documents get no numbers. The desk prepares paperwork;
 it does not check what a court or agreement requires, so confirm that with the people who set the rules."}
,_="fdp-legaldesk-",J=()=>({
id:String(Date.now()+Math.random()),name:"",pages:"",treatment:"produce",basis:"",exhibit:"",notes:"",date:"",author:"",recipients:"",description:""}
),Pe=["produce","redact","withhold"];
function bt(){
return e.jsx(pe,{
product:"legal-production-desk",children:e.jsx(ke,{
}
)}
)}
function ke(){
const[a,r]=Z(_+"docs",[J()]),[s,l]=Z(_+"settings",fe),[m,x]=Z(_+"steps",{
}
),p=y.useRef(new Map),[v,P]=y.useState({
}
),[k,M]=y.useState(""),[E,F]=y.useState(!1),{
localizedHref:A}
=ae(),n=y.useMemo(()=>je(a,s),[a,s]),c=(t,o)=>r(a.map(i=>i.id===t?{
...i,...o}
:i)),D=(t,o)=>{
const i=t+o;
if(i<0||i>=a.length)return;
const d=a.slice(),h=d[t];
d[t]=d[i],d[i]=h,r(d)}
,B=async t=>{
const o=[];
for(const d of t){
let h="";
try{
h=String((await H(d)).numPages)}
catch{
}
const b=String(Date.now()+Math.random());
p.current.set(b,d),h&&P(W=>({
...W,[b]:Number(h)}
)),o.push({
...J(),id:b,name:d.name,pages:h}
)}
const i=a.filter(d=>d.name.trim()||d.pages.trim());
r([...i,...o]),o.some(d=>!d.pages)&&w.warning("Some files could not be read for a page count. Type it in.")}
,j=async(t,o)=>{
if(o)try{
const i=(await H(o)).numPages;
p.current.set(t,o),P(h=>({
...h,[t]:i}
));
const d=a.find(h=>h.id===t);
r(a.map(h=>h.id===t?{
...h,pages:String(i),name:h.name.trim()?h.name:o.name}
:h)),d&&d.pages.trim()&&Number(d.pages)!==i&&w.warning(`The file has ${
i}
 pages;
 the page count was updated.`)}
catch{
w.error("That PDF could not be read. It may be protected or damaged.")}
}
,O=y.useMemo(()=>ve(n,a),[n,a]),N=y.useMemo(()=>ye(n,a.map(t=>p.current.has(t.id)?v[t.id]??null:null)),[n,a,v]),C=y.useMemo(()=>Ne(s,n),[s,n]),I=t=>new Blob([R(t)],{
type:"text/csv;
charset=utf-8"}
),L=async()=>{
if(n.problems.length){
w.error(n.problems[0]);
return}
if(!a.some(t=>t.treatment!=="withhold"&&t.name.trim())){
w.error("There is nothing to produce yet.");
return}
if(N.length){
w.error(N[0]);
return}
F(!0);
try{
const t=new se,o=t.folder("production"),i=new Set,d={
...ue,prefix:s.prefix,digits:Math.min(10,Math.max(1,Number(s.digits)||6)),legend:k.trim()}
;
for(let h=0;
h<a.length;
h++){
const b=n.rows[h];
if(b.treatment==="withhold"||b.startNum===null)continue;
const W=p.current.get(a[h].id),te=await xe(W,b.startNum,d);
o.file(Ce(b,i),te)}
t.file("production-log.csv",R(Q(n))),t.file("withheld-documents.csv",R(X(n))),t.file("privilege-log.csv",R(ee(n,a))),t.file("cover-letter.txt",C),S(await t.generateAsync({
type:"blob"}
),`${
(s.matter.trim()||"production").replace(/[^\w.-]+/g,"_")}
-production.zip`),w.success(`Stamped ${
n.produced+n.redacted}
 document${
n.produced+n.redacted===1?"":"s"}
, ${
n.pageCount}
 pages.`)}
catch(t){
w.error(t instanceof Error?`Could not build the production: ${
t.message}
`:"Could not build the production.")}
finally{
F(!1)}
}
,K=t=>{
const o=ee(n,a);
if(t==="csv")S(I(o),"privilege-log.csv");
else{
const i=T.aoa_to_sheet(o),d=T.book_new();
T.book_append_sheet(d,i,"Privilege log"),S(new Blob([q(d,{
type:"array",bookType:"xlsx"}
)],{
type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}
),"privilege-log.xlsx")}
}
,U=async(t,o)=>{
if(n.problems.length){
w.error(n.problems[0]);
return}
if(!a.some(h=>h.name.trim())){
w.error("Add at least one document first.");
return}
const i=t==="log"?Q(n):X(n),d=t==="log"?"production-log":"withheld-documents";
if(o==="csv")S(new Blob([R(i)],{
type:"text/csv;
charset=utf-8"}
),`${
d}
.csv`);
else{
const h=T.aoa_to_sheet(i),b=T.book_new();
T.book_append_sheet(b,h,t==="log"?"Production log":"Withheld"),S(new Blob([q(b,{
type:"array",bookType:"xlsx"}
)],{
type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}
),`${
d}
.xlsx`)}
}
;
return e.jsxs(le,{
children:[e.jsxs("div",{
className:"max-w-4xl mx-auto space-y-6",children:[e.jsxs("section",{
className:"space-y-3",children:[e.jsx("h2",{
className:"font-semibold",children:"1. Matter and numbering"}
),e.jsxs("div",{
className:"grid gap-3 sm:grid-cols-3",children:[e.jsxs("div",{
children:[e.jsx(g,{
className:"text-xs",children:"Matter"}
),e.jsx(u,{
"aria-label":"Matter",value:s.matter,onChange:t=>l({
...s,matter:t.target.value}
),"data-testid":"ld-matter"}
)]}
),e.jsxs("div",{
children:[e.jsx(g,{
className:"text-xs",children:"Producing party"}
),e.jsx(u,{
"aria-label":"Producing party",value:s.party,onChange:t=>l({
...s,party:t.target.value}
)}
)]}
),e.jsxs("div",{
children:[e.jsx(g,{
className:"text-xs",children:"Control number prefix"}
),e.jsx(u,{
"aria-label":"Control number prefix",value:s.controlPrefix,onChange:t=>l({
...s,controlPrefix:t.target.value}
)}
)]}
),e.jsxs("div",{
children:[e.jsx(g,{
className:"text-xs",children:"Bates prefix"}
),e.jsx(u,{
"aria-label":"Bates prefix",value:s.prefix,onChange:t=>l({
...s,prefix:t.target.value}
),"data-testid":"ld-prefix"}
)]}
),e.jsxs("div",{
children:[e.jsx(g,{
className:"text-xs",children:"Starting number"}
),e.jsx(u,{
"aria-label":"Starting number",inputMode:"numeric",value:s.start,onChange:t=>l({
...s,start:t.target.value}
),"data-testid":"ld-start"}
)]}
),e.jsxs("div",{
children:[e.jsx(g,{
className:"text-xs",children:"Digits"}
),e.jsx(u,{
"aria-label":"Digits",inputMode:"numeric",value:s.digits,onChange:t=>l({
...s,digits:t.target.value}
)}
)]}
)]}
)]}
),e.jsxs("section",{
className:"space-y-3",children:[e.jsx("h2",{
className:"font-semibold",children:"2. Documents, in the order you will stamp them"}
),e.jsx(ce,{
accept:".pdf",multiple:!0,maxSize:200,onFiles:B,deferUsageLog:!0,label:"Drop PDFs to list them with their page counts",description:"Only the name and page count are read. The files stay on your device."}
),e.jsx("div",{
className:"overflow-x-auto rounded border",children:e.jsxs("table",{
className:"w-full text-sm","data-testid":"ld-table",children:[e.jsx("thead",{
className:"bg-muted/50 text-left",children:e.jsxs("tr",{
children:[e.jsx("th",{
className:"p-2",children:"#"}
),e.jsx("th",{
className:"p-2",children:"Document"}
),e.jsx("th",{
className:"p-2 w-20",children:"Pages"}
),e.jsx("th",{
className:"p-2",children:"Treatment"}
),e.jsx("th",{
className:"p-2",children:"Reason or redactions"}
),e.jsx("th",{
className:"p-2 w-20",children:"Exhibit"}
),e.jsx("th",{
className:"p-2",children:"Bates range"}
),e.jsx("th",{
className:"p-2",children:e.jsx("span",{
className:"sr-only",children:"Actions"}
)}
)]}
)}
),e.jsx("tbody",{
children:a.map((t,o)=>e.jsxs("tr",{
className:"border-t align-top",children:[e.jsx("td",{
className:"p-2 text-muted-foreground",children:o+1}
),e.jsx("td",{
className:"p-1",children:e.jsx(u,{
"aria-label":`Document, row ${
o+1}
`,className:"h-8",value:t.name,onChange:i=>c(t.id,{
name:i.target.value}
),"data-testid":"ld-name"}
)}
),e.jsx("td",{
className:"p-1",children:e.jsx(u,{
"aria-label":`Pages, row ${
o+1}
`,className:"h-8",inputMode:"numeric",value:t.pages,onChange:i=>c(t.id,{
pages:i.target.value}
),"data-testid":"ld-pages"}
)}
),e.jsx("td",{
className:"p-1",children:e.jsx("select",{
"aria-label":`Treatment, row ${
o+1}
`,className:"h-8 rounded-md border bg-background px-1 text-sm",value:t.treatment,onChange:i=>c(t.id,{
treatment:i.target.value}
),"data-testid":"ld-treatment",children:Pe.map(i=>e.jsx("option",{
value:i,children:z[i]}
,i))}
)}
),e.jsx("td",{
className:"p-1",children:e.jsx(u,{
"aria-label":`Basis, row ${
o+1}
`,className:"h-8",value:t.basis,onChange:i=>c(t.id,{
basis:i.target.value}
),placeholder:t.treatment==="withhold"?"Reason withheld":t.treatment==="redact"?"What was redacted":""}
)}
),e.jsx("td",{
className:"p-1",children:e.jsx(u,{
"aria-label":`Exhibit, row ${
o+1}
`,className:"h-8",value:t.exhibit,onChange:i=>c(t.id,{
exhibit:i.target.value}
)}
)}
),e.jsx("td",{
className:"p-2 whitespace-nowrap tabular-nums text-xs","data-testid":"ld-range",children:n.rows[o]?.begin?`${
n.rows[o].begin}
 to ${
n.rows[o].end}
`:t.treatment==="withhold"?"Not numbered":""}
),e.jsxs("td",{
className:"p-1 whitespace-nowrap",children:[t.treatment!=="withhold"&&e.jsxs("label",{
className:"inline-flex cursor-pointer items-center",title:p.current.has(t.id)?"PDF attached. Click to replace.":"Attach this document's PDF",children:[e.jsxs("span",{
className:"sr-only",children:["Attach PDF, row ",o+1]}
),e.jsx("input",{
type:"file",accept:".pdf,application/pdf",className:"sr-only",onChange:i=>{
j(t.id,i.target.files?.[0]),i.target.value=""}
,"data-testid":"ld-attach"}
),e.jsx(re,{
className:`h-4 w-4 ${
p.current.has(t.id)?"text-primary":"text-muted-foreground"}
`,"aria-hidden":!0}
)]}
),e.jsx(f,{
size:"sm",variant:"ghost","aria-label":`Move row ${
o+1}
 up`,disabled:o===0,onClick:()=>D(o,-1),children:"Up"}
),e.jsx(f,{
size:"sm",variant:"ghost","aria-label":`Move row ${
o+1}
 down`,disabled:o===a.length-1,onClick:()=>D(o,1),children:"Down"}
),e.jsx(f,{
size:"icon",variant:"ghost","aria-label":`Remove row ${
o+1}
`,disabled:a.length===1,onClick:()=>r(a.filter(i=>i.id!==t.id)),children:e.jsx(ge,{
className:"h-4 w-4"}
)}
)]}
)]}
,t.id))}
)]}
)}
),e.jsxs(f,{
variant:"outline",size:"sm",className:"gap-1.5",onClick:()=>r([...a,J()]),children:[e.jsx(de,{
className:"h-3.5 w-3.5"}
)," Add a document"]}
)]}
),e.jsxs("section",{
className:"rounded-lg border p-4 space-y-2","aria-live":"polite","data-testid":"ld-summary",children:[e.jsx("h2",{
className:"font-semibold",children:"Summary"}
),e.jsxs("p",{
className:"text-sm",children:[n.produced," produced in full, ",n.redacted," with redactions, ",n.withheld," withheld. ",n.pageCount," numbered page",n.pageCount===1?"":"s",n.firstBates?`, ${
n.firstBates}
 to ${
n.lastBates}
`:"","."]}
),n.problems.map((t,o)=>e.jsx("p",{
className:"text-sm text-red-700",role:"alert",children:t}
,"p"+o)),n.warnings.map((t,o)=>e.jsx(G,{
className:"text-sm",children:t}
,"w"+o))]}
),e.jsxs("section",{
className:"space-y-3",children:[e.jsx("h2",{
className:"font-semibold",children:"3. Steps"}
),e.jsx("ol",{
className:"grid gap-3 sm:grid-cols-2",children:$e.map((t,o)=>e.jsxs("li",{
className:"rounded-lg border p-3 space-y-1",children:[e.jsxs("label",{
className:"flex items-center gap-2 font-medium text-sm",children:[e.jsx("input",{
type:"checkbox",checked:!!m[t.id],onChange:i=>x({
...m,[t.id]:i.target.checked}
)}
),o+1,". ",t.title]}
),e.jsx("p",{
className:"text-xs text-muted-foreground",children:t.text}
),t.id==="bates"&&n.firstBates&&e.jsxs("p",{
className:"text-xs",children:["Use prefix ",e.jsx("b",{
children:s.prefix}
),", start at ",e.jsx("b",{
children:s.start}
),", ",s.digits," digits. Stamp the documents one after another so the numbers carry on."]}
),e.jsxs(ie,{
href:A(`/tool/${
t.tool}
`),className:"inline-flex items-center gap-1 text-xs underline",children:[t.toolName,e.jsx(oe,{
className:"h-3 w-3"}
)]}
)]}
,t.id))}
)]}
),e.jsxs("section",{
className:"space-y-3","data-testid":"ld-privilege",children:[e.jsx("h2",{
className:"font-semibold",children:"4. Privilege log details"}
),e.jsx("p",{
className:"text-xs text-muted-foreground",children:"For each withheld or redacted document: when it was written, who wrote it, who received it and a general description. Describe the subject, not the privileged content."}
),a.every(t=>t.treatment==="produce")?e.jsx("p",{
className:"text-sm text-muted-foreground",children:"No withheld or redacted documents yet."}
):e.jsxs("div",{
className:"space-y-2",children:[a.map((t,o)=>t.treatment==="produce"?null:e.jsxs("div",{
className:"rounded-lg border p-3 grid gap-2 sm:grid-cols-4",children:[e.jsxs("p",{
className:"sm:col-span-4 text-sm font-medium",children:[t.name.trim()||`Row ${
o+1}
`," ",e.jsx("span",{
className:"text-xs font-normal text-muted-foreground",children:z[t.treatment]}
)]}
),e.jsxs("div",{
children:[e.jsx(g,{
className:"text-xs",children:"Date"}
),e.jsx(u,{
"aria-label":"Date",className:"h-8",value:t.date??"",onChange:i=>c(t.id,{
date:i.target.value}
),"data-testid":"ld-p-date"}
)]}
),e.jsxs("div",{
children:[e.jsx(g,{
className:"text-xs",children:"Author"}
),e.jsx(u,{
"aria-label":"Author",className:"h-8",value:t.author??"",onChange:i=>c(t.id,{
author:i.target.value}
)}
)]}
),e.jsxs("div",{
children:[e.jsx(g,{
className:"text-xs",children:"Recipients"}
),e.jsx(u,{
"aria-label":"Recipients",className:"h-8",value:t.recipients??"",onChange:i=>c(t.id,{
recipients:i.target.value}
)}
)]}
),e.jsxs("div",{
children:[e.jsx(g,{
className:"text-xs",children:"General description"}
),e.jsx(u,{
"aria-label":"General description",className:"h-8",value:t.description??"",onChange:i=>c(t.id,{
description:i.target.value}
)}
)]}
)]}
,t.id)),O.map((t,o)=>e.jsx(G,{
className:"text-xs",children:t}
,o))]}
),e.jsxs("div",{
className:"flex flex-wrap gap-3",children:[e.jsxs(f,{
variant:"outline",className:"gap-2",onClick:()=>K("csv"),"data-testid":"ld-priv-csv",children:[e.jsx($,{
className:"h-4 w-4"}
),"Privilege log (CSV)"]}
),e.jsxs(f,{
variant:"outline",className:"gap-2",onClick:()=>K("xlsx"),children:[e.jsx($,{
className:"h-4 w-4"}
),"Privilege log (Excel)"]}
)]}
)]}
),e.jsxs("section",{
className:"space-y-3","data-testid":"ld-letter",children:[e.jsx("h2",{
className:"font-semibold",children:"5. Cover letter"}
),e.jsxs("div",{
className:"grid gap-3 sm:grid-cols-2",children:[e.jsxs("div",{
children:[e.jsx(g,{
className:"text-xs",children:"Date"}
),e.jsx(u,{
"aria-label":"Date",value:s.letterDate??"",onChange:t=>l({
...s,letterDate:t.target.value}
),placeholder:"October 18, 2026"}
)]}
),e.jsxs("div",{
children:[e.jsx(g,{
className:"text-xs",children:"Production volume"}
),e.jsx(u,{
"aria-label":"Production volume",value:s.volume??"",onChange:t=>l({
...s,volume:t.target.value}
),placeholder:"VOL001"}
)]}
),e.jsxs("div",{
children:[e.jsx(g,{
className:"text-xs",children:"To"}
),e.jsx(u,{
"aria-label":"To",value:s.recipient??"",onChange:t=>l({
...s,recipient:t.target.value}
)}
)]}
),e.jsxs("div",{
children:[e.jsx(g,{
className:"text-xs",children:"From"}
),e.jsx(u,{
"aria-label":"From",value:s.sender??"",onChange:t=>l({
...s,sender:t.target.value}
)}
)]}
)]}
),e.jsx("pre",{
className:"whitespace-pre-wrap rounded border bg-muted/30 p-3 text-xs","data-testid":"ld-letter-text",children:C}
),e.jsxs("div",{
className:"flex flex-wrap gap-3",children:[e.jsxs(f,{
variant:"outline",className:"gap-2",onClick:()=>S(new Blob([C],{
type:"text/plain;
charset=utf-8"}
),"cover-letter.txt"),children:[e.jsx($,{
className:"h-4 w-4"}
),"Cover letter (text)"]}
),e.jsx(f,{
variant:"outline",onClick:()=>{
navigator.clipboard.writeText(C).then(()=>w.success("Copied."))}
,children:"Copy"}
)]}
)]}
),e.jsxs("section",{
className:"space-y-3","data-testid":"ld-run",children:[e.jsx("h2",{
className:"font-semibold",children:"6. Build the production"}
),e.jsx("p",{
className:"text-xs text-muted-foreground",children:"Stamps the Bates number on every produced and redacted document, using the numbers above, and puts them in a ZIP with the production log, withheld list, privilege log and cover letter. For documents marked Produce with redactions, attach the redacted copy."}
),e.jsxs("div",{
className:"max-w-sm",children:[e.jsx(g,{
className:"text-xs",children:"Legend on every page (optional)"}
),e.jsx(u,{
"aria-label":"Legend on every page (optional)",value:k,maxLength:60,onChange:t=>M(t.target.value),placeholder:"CONFIDENTIAL","data-testid":"ld-legend"}
)]}
),N.length>0&&e.jsx(G,{
testId:"ld-run-issues",children:e.jsxs("ul",{
className:"text-xs list-disc pl-5",children:[N.slice(0,6).map((t,o)=>e.jsx("li",{
children:t}
,o)),N.length>6&&e.jsxs("li",{
children:["and ",N.length-6," more."]}
)]}
)}
),e.jsxs("div",{
className:"flex flex-wrap gap-3",children:[e.jsxs(f,{
className:"gap-2",onClick:()=>{
L()}
,disabled:E,"data-testid":"ld-build",children:[E?e.jsx(ne,{
className:"h-4 w-4 animate-spin"}
):e.jsx($,{
className:"h-4 w-4"}
),"Build production ZIP"]}
),e.jsxs(f,{
variant:"outline",className:"gap-2",onClick:()=>U("log","csv"),"data-testid":"ld-log-csv",children:[e.jsx($,{
className:"h-4 w-4"}
),"Production log (CSV)"]}
),e.jsxs(f,{
variant:"outline",className:"gap-2",onClick:()=>U("log","xlsx"),children:[e.jsx($,{
className:"h-4 w-4"}
),"Production log (Excel)"]}
),e.jsxs(f,{
variant:"outline",className:"gap-2",onClick:()=>U("withheld","csv"),children:[e.jsx($,{
className:"h-4 w-4"}
),"Withheld list (CSV)"]}
)]}
)]}
),e.jsx(he,{
tool:"legal-production-desk",prefixes:[_],session:!0}
)]}
),e.jsx(me,{
whatIsIt:V.what,howToUse:V.how,tip:V.tip}
)]}
)}
export{
bt as default}
;

//# sourceMappingURL=LegalProductionDesk-DnUlw46t.js.map
