# FDP-93: rebuild pages that are no longer in the page tree but still inside the file. python3 recover93.py <in> <out.pdf>
import sys, pikepdf, fitz
from pikepdf import Name
src, dst = sys.argv[1:3]
q = pikepdf.open(src); tree = {p.objgen for p in q.pages}
orph = [o for o in q.objects if isinstance(o, pikepdf.Dictionary) and o.get('/Type') == Name.Page and o.objgen not in tree]
out = pikepdf.new()
for o in orph:
    out.pages.append(pikepdf.Page(out.copy_foreign(o)))
out.save(dst)
d = fitz.open(dst)
for i, p in enumerate(d):
    print('hidden page', i + 1, orph[i].objgen, repr(p.get_text()[:80]), 'widgets', [w.field_name + '=' + str(w.field_value) for w in p.widgets()])
    p.get_pixmap(dpi=50).save(dst.replace('.pdf', f'-{i+1}.png'))
