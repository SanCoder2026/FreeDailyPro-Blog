// FDP-99 local replay of the desk's Bates stamp path (batesNumbering s(): PDFDocument.load -> white box + bold label per page -> save).
// Purpose: show what pdf-lib save does with pages hidden outside the page tree (e.g. #93 Remove PDF Pages output). Not a live test.
const { PDFDocument, StandardFonts, rgb } = require('pdf-lib'); const fs = require('fs');
(async () => { const [inp, out, prefix, start] = process.argv.slice(2);
 const d = await PDFDocument.load(fs.readFileSync(inp)); const f = await d.embedFont(StandardFonts.HelveticaBold); let n = Number(start || 1);
 for (const p of d.getPages()) { const { width } = p.getSize(); const label = prefix + String(n++).padStart(6, '0'); const w = f.widthOfTextAtSize(label, 10);
  p.drawRectangle({ x: width - 36 - w - 2, y: 34, width: w + 4, height: 14, color: rgb(1, 1, 1) }); p.drawText(label, { x: width - 36 - w, y: 36, size: 10, font: f }); }
 fs.writeFileSync(out, await d.save()); console.log('stamped', d.getPageCount(), 'pages ->', out); })();
