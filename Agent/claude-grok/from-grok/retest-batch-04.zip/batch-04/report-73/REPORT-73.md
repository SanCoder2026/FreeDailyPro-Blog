# QA Report #73: Camera Capture, Word Counter, Audio Normalizer (retest cycle 2, batch 4, plan rows 13–15)
Tested 2026-10-29, 22:40–22:53 ET. Playwright headless Chromium, desktop 1280×900 and mobile 390×844 (is_mobile, touch). Logged out, fresh context per run, nothing paid, no sign-up, no API writes. Camera used Chromium fake device (`--use-fake-device-for-media-stream`, `--use-fake-ui-for-media-stream`), so the real-device permission prompt (L-052) is still untested. TESTING-GUIDANCE "Last updated" 2026-10-29 9:38 PM ET, unchanged. Analytics come from analytics/2026-07-10-to-now-raw.md.

## Summary
| Tool | Verdict | New briefs | Evidence added to |
|---|---|---|---|
| Camera Capture (/tool/camera) | Works. Full-photo download carries the trial badge with **no notice before download** | B-0063 (P2) | B-0060 (no tool_completed), B-0041 (CLS mobile 0.173) |
| Word Counter | Accurate on 11 cases; 200k words counted in ~1 s. Sentence count overcounts abbreviations; CJK counted per phrase | B-0065 (P3) | B-0060, B-0041 (related-search ad block injected inside the stats grid on mobile) |
| Audio Normalizer | **#45 fixes verified**: Podcast −16 and Spotify −14 are now separate presets, ACX copy now says "dB RMS (LUFS proxy)". All targets measured within 0.05 LU. Still open: 13×13 checkbox; MP3 output is re-encoded at ~110 kbps VBR with no bitrate choice, so the ACX preset can't produce an ACX-compliant MP3 | B-0064 (P2) | B-0055 (counter dropped 6→0 mid-session), B-0060 |

## Camera Capture
Analytics: 2,439 GSC impressions, 50 clicks, position 13.5, 77 GA views; queries "camera online photo" (1 click / 53 impressions), "camera online free" (1/16). Title: "Take a Picture Online - Webcam Photo, Free, No App | FreeDailyPro" ("Free" is in the title by design).

| ID | Device | Steps | Expected | Actual | Result |
|---|---|---|---|---|---|
| CAM-01 | both | Start Camera → Capture | photo at camera resolution | 3840×2160 PNG (fake device), desktop and mobile | PASS |
| CAM-02 | both | tick "Save as JPG" (only shown in live view) → Capture → Download | JPEG | JPEG 3840×2160, 112 KB | PASS |
| CAM-03 | 1280 | drag a crop → Download Crop | cropped JPG | 1918×1080 JPG | PASS |
| CAM-04 | both | counter | 1 use per download | 10→9 on the first download; later downloads in the session stay at 9 | PASS |
| CAM-05 | both | **badge disclosure on full photo** | a notice before download, same as merge/split ("This download will carry…", SW-14) | Full Photo download (PNG and JPG) has "Created with FreeDailyPro.com" badges top-right and bottom-right (ss cam-1280-png-top/bot.png, full-badge-wide.png). **No notice is shown before Download Full Photo.** The notice only appears after you drag a crop | **FAIL → B-0063** |
| CAM-06 | both | GA | tool_completed on download | page_view only | FAIL → B-0060 evidence |
| CAM-07 | both | ad overlap with video and Capture | none | none; mobile Capture button at y=642, above the fold | PASS |
| CAM-08 | 390 | CLS on load | <0.1 | **0.173** (container 0.088 + mt-8 0.084); desktop live view 0.098 (video embed 0.071) | FAIL → B-0041 evidence |

Competitors (fetched 2026-10-29): freephotobooth.online, lensbooth.app, photoboothcam.com, filtercamera.com, toea.com/webcam-photo-booth. The first two say **"no watermark"** prominently. FilterCamera and TOEA have a 3-second self-timer, filters and mirror/crop presets (TOEA has passport sizes). FDP has no timer or mirror toggle. That's a P3 improvement idea, folded into B-0063 as optional.

## Word Counter
Analytics: 179 GA views. "word count characters" gets 0 clicks from 2,320 impressions at position 9.1; CTR is covered by B-0036/B-0043, so it isn't re-briefed here. Plan row 14 notes: tip-calculator and citation-generator pages return 200 ("tip calculator" 0/5,660, "citation generator" 0/2,448, covered by CTR briefs); /tool/character-counter is 404 (no alias, see B-0065 optional).

| ID | Input | Expected | Actual (W / C / C-no-sp / S / P) | Result |
|---|---|---|---|---|
| WC-01 | "The quick brown fox jumps over the lazy dog." | 9/44/36/1/1 | 9/44/36/1/1 | PASS |
| WC-02 | "Don't stop — it's well-known that e-mail isn't dead." | 8 words (dash not a word) | 8/52/44/1/1 | PASS |
| WC-03 | "  Hello   world  \n\n\n  again  " | 3 words, 2 paragraphs | 3/29/15/1/2 | PASS |
| WC-04 | 3 paragraphs, 5 sentences with ! ? ... | 12 / 5 S / 3 P | 12/74/60/5/3 | PASS |
| WC-05 | URL, email, v1.2.3 | 7 words, 1 sentence | 7/60/54/1/1 | PASS |
| WC-06 | "I love 🍕 and 👍🏽 and 🇺🇸!" | 21 graphemes (JS length is 23) | 4 words / 21 chars | PASS (counts graphemes) |
| WC-07 | "你好世界。日本語のテキスト。" | 2 sentences; CJK words are usually counted per character (MS Word: 13) | 5 words, 2 sentences | MINOR → B-0065 |
| WC-08 | money, date, % | 8 words, 1 sentence | 8/48/40/1/1 | PASS |
| WC-09 | "Dr. Smith met Mr. J. R. R. Tolkien at 9 a.m. in the U.S. It was fun." | 2 sentences | **4 sentences** | FAIL (P3) → B-0065 |
| WC-10 | tabs | 3 words | 3/14/12 | PASS |
| WC-11 | accents | 4 words / 24 chars | 4/24/21 | PASS |
| WC-12 | 200,000 words (1.08M chars) | counts without hanging | "Counting…" then 200000 / 1,080,000 / 16 h 40 min (200 wpm) in ≤1.0 s | PASS |
| WC-13 | Copy stats | clipboard text; use counted | "Words: 9 \| Characters: 44 …"; 10→9; typing alone spends nothing | PASS |
| WC-14 | GA | tool_completed on Copy | page_view only | FAIL → B-0060 evidence |
| WC-15 | idle 12 s + keyboard typing | CLS <0.1, no ad over the textarea | desktop 0.079 (video 0.055), mobile 0.086; typing adds 0; no overlaps | PASS |
| WC-16 | 390, after a long paste | ads outside the tool | AdSense "Discover more / Get Writing Tools" related-search block rendered **inside the stats grid** (between Paragraphs and Reading Time; results text "ParagraphsGet Writing Tools"); grid shift 0.37 plus an auto-placed shift of 0.976 in run 1 | FAIL → B-0041 evidence |

Competitors: wordcounter.net (reading level, speaking time, keyword density, autosave), wordcharactercount.com, charactercountonline.com, lettercount.com (per seo-wire.com 2026 comparison). FDP is missing **speaking time** and **keyword density**, which are cheap to add.

## Audio Normalizer
Analytics: 65 GA views; 32 clicks / 503 impressions at position 28.3; "audio normalizer online" 2/34, "normalize audio online" 1/59. Fixture: fx/quiet.wav, 8 s 440 Hz stereo at −41.8 LUFS / −41.1 dBTP (and a 128k MP3 of it). Measured with ffmpeg loudnorm and astats.

| ID | Device | Input / preset | Expected | Measured output | Result |
|---|---|---|---|---|---|
| AN-01 | 1280 | WAV, Podcast (−16) | −16 LUFS | −16.05 LUFS, TP −15.3, WAV pcm_s16le 44.1k | PASS |
| AN-02 | 1280 | WAV, Spotify / streaming (−14) | −14 (Spotify help: −14 LUFS, TP < −1) | −14.05 | PASS — **#45 finding 1 verified fixed** |
| AN-03 | 1280 | WAV, Broadcast EBU R128 | −23 | −23.05 | PASS |
| AN-04 | 1280 | WAV, Audiobook ACX | RMS −23…−18, peak ≤ −3 | RMS −22.3 dB, peak −19.3; copy now reads "about −20 dB RMS (LUFS used as a proxy), peak −3 dB" | PASS — **#45 finding 2 verified fixed** |
| AN-05 | 1280 | WAV, Peak to −1 dB | TP −1 | TP −1.01 | PASS |
| AN-06 | 1280 | MP3 128k CBR, Spotify | −14, keep bitrate | −13.95 LUFS; output **MP3 ~110 kbps VBR**; no format or bitrate choice | FAIL (ACX needs 192 kbps CBR MP3) → B-0064 |
| AN-07 | 390 | MP3, YouTube preset | −14, copy says no official YouTube target | −13.95; "YouTube publishes no official target" | PASS |
| AN-08 | both | "Limit loud peaks" checkbox | ≥24 px target | 13×13 (as in #45) | **still fails** → B-0064 |
| AN-09 | 1280 | counter | 1 use per run | 10→9→8→7→6, then **6→0** after the 5th run in the same session (ss an-1280-5.png shows "0 remaining today" next to a working Download); fresh mobile context shows 10 | B-0055 evidence (still open) |
| AN-10 | both | GA | tool_completed | page_view ×N only | B-0060 evidence |
| AN-11 | both | ads / CLS | no overlap, <0.1 | no overlap; CLS desktop 0.047, mobile 0.099 (result action row 0.091); load 0.022 / 0.081 | PASS (mobile borderline) |
| AN-12 | both | result copy | honest | "Loudness −42.3 → −13.9 LUFS (+28.3 dB), measured on the saved file. This boosts a quiet recording by 28 dB, so background noise gets louder too." | PASS (good) |

Competitors: saturalabs.com/loudness-normalizer (free, local, shows measured export), narratorcheck.com (ACX check + fix, **192 kbps CBR MP3, re-measured before download**), winberg.ie/tools/audiobooks, lufsready.com. FDP's measured-on-saved-file line matches the best of these. The gap is MP3 delivery specs.

## Maturity
Audio Normalizer is close to mature once B-0064 lands. Word Counter becomes a mature candidate after B-0065. Camera is not mature (B-0063, L-052 real device).
