import asyncio,json
from playwright.async_api import async_playwright
from common import *; from adcls import *
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(); c=await b.new_context(viewport={'width':1280,'height':900},accept_downloads=True); await c.add_init_script(INIT); ev=[];ga(c,ev); pg=await c.new_page()
    await pg.goto(U+'audio-normalizer',wait_until='networkidle'); await pg.wait_for_timeout(2000)
    await pg.locator('input[type=file]').first.set_input_files('fx/quiet.wav'); await pg.wait_for_timeout(3000)
    print(await txt(pg,0,3500))
    print(await pg.evaluate("""[...document.querySelectorAll('main select,main input,main button,[role=combobox],[role=radio],[role=switch]')].map(e=>[e.tagName,e.type||'',e.getAttribute('role'),(e.innerText||e.value||e.getAttribute('aria-label')||'').slice(0,60),Math.round(e.getBoundingClientRect().width)+'x'+Math.round(e.getBoundingClientRect().height)])"""))
    print(await pg.evaluate("[...document.querySelectorAll('main select')].map(s=>[...s.options].map(o=>o.text))"))
    await pg.screenshot(path='ss/an-1280-loaded.png',full_page=True)
asyncio.run(main())
