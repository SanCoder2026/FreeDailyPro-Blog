import asyncio,json,subprocess,re,sys
from playwright.async_api import async_playwright
from common import *; from adcls import *
P=['Podcast (-16 LUFS)','Spotify / streaming (-14 LUFS)','YouTube (common streaming reference)','Broadcast (EBU R128)','Audiobook (ACX)','Peak to -1 dB']
def meas(f):
  o=subprocess.run(['ffmpeg','-hide_banner','-i',f,'-af','loudnorm=print_format=json,astats=measure_overall=RMS_level','-f','null','-'],capture_output=True,text=True).stderr
  j=json.loads(o[o.rfind('{'):o.rfind('}')+1]); rms=re.findall(r'RMS level dB: (-?[\d.]+|-inf)',o)
  pr=subprocess.run(['ffprobe','-v','error','-show_entries','format=format_name,bit_rate,duration:stream=codec_name,sample_rate,channels','-of','json',f],capture_output=True,text=True).stdout
  return {'I':j['input_i'],'TP':j['input_tp'],'rms':rms[-1] if rms else None,'probe':json.loads(pr)}
R=[]
async def run(b,W,jobs):
  c=await b.new_context(viewport={'width':W,'height':900 if W>500 else 844},accept_downloads=True,**({'is_mobile':True,'has_touch':True} if W<500 else {})); await c.add_init_script(INIT); ev=[];ga(c,ev); pg=await c.new_page()
  await pg.goto(U+'audio-normalizer',wait_until='load'); await pg.wait_for_timeout(2000)
  for fx,preset,lim in jobs:
    await pg.goto(U+'audio-normalizer',wait_until='load'); await pg.wait_for_timeout(1500)
    await pg.locator('input[type=file]').first.set_input_files(fx); await pg.wait_for_timeout(1500)
    await pg.locator('main button').filter(has_text=preset).first.click(); await pg.wait_for_timeout(300)
    desc=await txt(pg,0,3000); d=desc[desc.find('Peak to -1 dB')+13:][:300]
    cb=pg.locator('main input[type=checkbox]').first
    if lim is not None and await cb.count() and await cb.is_enabled() and (await cb.is_checked())!=lim: await cb.click()
    r0=await rem(pg)
    await pg.locator('main button').filter(has_text='Normalize Volume').click()
    try:
      await pg.wait_for_function("document.querySelector('main').innerText.match(/Download/)",timeout=90000)
      t=await txt(pg,0,4000); res=t[t.find('Normalize Volume'):][:600]
      dl=pg.locator('main a,main button').filter(has_text=re.compile('Download')).first
      async with pg.expect_download(timeout=60000) as di: await dl.click()
      d2=await di.value; fn=f'out/an-{W}-{len(R)}-'+d2.suggested_filename; await d2.save_as(fn); m=meas(fn)
    except Exception as e: res=str(e)[:200]; fn=None; m=None
    await pg.wait_for_timeout(800)
    R.append({'t':now(),'vp':W,'fx':fx,'preset':preset,'limit':lim,'desc':d,'rem_before':r0,'rem_after':await rem(pg),'result_text':res,'file':fn,'m':m})
    print(json.dumps(R[-1])[:900]); sys.stdout.flush()
    await pg.screenshot(path=f'ss/an-{W}-{len(R)}.png',full_page=False)
    rb=pg.locator('main button').filter(has_text='Reset')
    if await rb.count(): await rb.first.click(); await pg.wait_for_timeout(500)
  R.append({'vp':W,'ga':ev,'ad':await adcheck(pg,'main button')}); print(json.dumps(R[-1])[:900])
  await c.close()
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    await run(b,1280,[('fx/quiet.wav',P[1],True),('fx/quiet.wav',P[3],True),('fx/quiet.wav',P[4],True),('fx/quiet.wav',P[5],None),('fx/quiet.mp3',P[1],False)])
    await run(b,390,[('fx/quiet.mp3',P[2],True)])
    json.dump(R,open('an2.json','w'),indent=1)
asyncio.run(main())
