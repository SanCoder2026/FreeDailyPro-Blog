import asyncio,json,re,os
from playwright.async_api import async_playwright
from common import *; from adcls import *
from PIL import Image
R=[]
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(args=['--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream'])
    for vp in [{'width':1280,'height':900},{'width':390,'height':844}]:
      W=vp['width']; c=await b.new_context(viewport=vp,permissions=['camera'],accept_downloads=True,**({'is_mobile':True,'has_touch':True} if W<500 else {})); await c.add_init_script(INIT); ev=[];ga(c,ev); pg=await c.new_page()
      await pg.goto(U+'camera-capture',wait_until='networkidle'); await pg.wait_for_timeout(2500); r={'vp':W,'t':now(),'rem0':await rem(pg)}
      await pg.locator('main button').filter(has_text='Start Camera').click(); await pg.wait_for_timeout(3000)
      r['ui_live']=await ui(pg); r['ad_live']=await adcheck(pg,'main video,main button'); await pg.screenshot(path=f'ss/cam-{W}-live.png')
      r['video']=await pg.evaluate('(()=>{const v=document.querySelector("main video");if(!v)return null;const b=v.getBoundingClientRect();return [v.videoWidth,v.videoHeight,Math.round(b.top),Math.round(b.height)]})()')
      cap=pg.locator('main button').filter(has_text=re.compile('Capture|Take', re.I)).first
      r['cap_box']=await cap.bounding_box() if await cap.count() else None
      if await cap.count(): await cap.click(); await pg.wait_for_timeout(1500)
      r['ui_after']=await ui(pg); r['rem_cap']=await rem(pg); r['txt_after']=(await txt(pg,0,3000))[200:1300]; await pg.screenshot(path=f'ss/cam-{W}-captured.png',full_page=True)
      r['ad_after']=await adcheck(pg,'main img,main canvas,main button')
      for i,nm in enumerate(['png','jpg']):
        if nm=='jpg':
          cb=pg.locator('main input[type=checkbox]').first
          if await cb.count(): await cb.check(); await pg.wait_for_timeout(400)
        try:
          d_btn=pg.locator('main button,main a').filter(has_text=re.compile('Download',re.I)).first
          async with pg.expect_download(timeout=15000) as d: await d_btn.click()
          D=await d.value; f=f'out/cam-{W}-{nm}-'+D.suggested_filename; await D.save_as(f); im=Image.open(f); r[nm]={'file':D.suggested_filename,'fmt':im.format,'size':im.size,'bytes':os.path.getsize(f)}
        except Exception as e: r[nm]={'err':str(e)[:150]}
        await pg.wait_for_timeout(1200); r['rem_'+nm]=await rem(pg)
      r['ga']=ev; r['cls']=(await adcheck(pg))['cls']; R.append(r); json.dump(R,open('cam.json','w'),indent=1); await c.close()
asyncio.run(main())
