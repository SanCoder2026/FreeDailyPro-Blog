import asyncio,json,re,os
from playwright.async_api import async_playwright
from common import *
from PIL import Image
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(args=['--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream'])
    c=await b.new_context(permissions=['camera'],accept_downloads=True); pg=await c.new_page(); r={'t':now()}
    await pg.goto(U+'camera-capture',wait_until='networkidle'); await pg.wait_for_timeout(2000)
    await pg.locator('main button').filter(has_text='Start Camera').click(); await pg.wait_for_timeout(2500)
    r['cb_label']=await pg.evaluate('(()=>{const c=document.querySelector("main input[type=checkbox]");return c.closest("label")?.innerText||c.parentElement.innerText})()')
    await pg.locator('main input[type=checkbox]').first.check(); await pg.locator('main button').filter(has_text='Capture').first.click(); await pg.wait_for_timeout(1500)
    async with pg.expect_download() as d: await pg.locator('main button').filter(has_text='Download Full Photo').click()
    D=await d.value; f='out/cam-jpg-'+D.suggested_filename; await D.save_as(f); im=Image.open(f); r['jpg']=[D.suggested_filename,im.format,im.size,os.path.getsize(f)]; print(r,flush=True)
    # crop: drag on image/canvas
    el=pg.locator('main canvas, main img').first; await el.scroll_into_view_if_needed(); await pg.wait_for_timeout(400); bb=await el.bounding_box(); r['bb']=bb
    await pg.mouse.move(bb['x']+bb['width']*.25,bb['y']+bb['height']*.25); await pg.mouse.down(); await pg.mouse.move(bb['x']+bb['width']*.75,bb['y']+bb['height']*.75,steps=8); await pg.mouse.up(); await pg.wait_for_timeout(500)
    cs=pg.locator('main button').filter(has_text='Crop Selection'); r['crop_disabled']=await cs.is_disabled(); r['el']=await el.evaluate('e=>e.tagName+" "+e.className'); print(r,flush=True)
    if not r['crop_disabled']: await cs.click(timeout=5000); await pg.wait_for_timeout(1200); r['ui_crop']=await ui(pg)
    try:
      btn=pg.locator('main button').filter(has_text='Download Crop').first
      async with pg.expect_download(timeout=10000) as d: await btn.click()
      D=await d.value; f='out/cam-crop-'+D.suggested_filename; await D.save_as(f); im=Image.open(f); r['crop']=[D.suggested_filename,im.format,im.size]
    except Exception as e: r['crop_err']=str(e)[:120]
    r['mark_txt']=(await txt(pg,0,4000))[300:1400]; r['rem']=await rem(pg); await pg.screenshot(path='ss/cam-1280-cropped.png',full_page=True); print(json.dumps(r)); json.dump(r,open('cam2.json','w'),indent=1)
asyncio.run(main())
