import asyncio,json,re
from playwright.async_api import async_playwright
from common import *; from adcls import *
C=[("simple","The quick brown fox jumps over the lazy dog."),("contractions","Don't stop — it's well-known that e-mail isn't dead."),("multispace","  Hello   world  \n\n\n  again  "),
("paras","Para one line.\n\nPara two. Second sentence!\nStill para two?\n\n\nPara three..."),("urls","Visit https://example.com/a-b and mail bob@x.com, v1.2.3 ok."),("emoji","I love 🍕 and 👍🏽 and 🇺🇸!"),
("cjk","你好世界。日本語のテキスト。"),("numbers","Pay $1,234.56 on 10/29/2026 at 3.5% — 100 items."),("abbr","Dr. Smith met Mr. J. R. R. Tolkien at 9 a.m. in the U.S. It was fun."),("tabs","word\tword\tword"),("accents","café naïve résumé façade")]
R=[]
async def stats(pg):
  t=await txt(pg,0,6000); s=t.find('Copy stats'); return t[s:s+700]
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for vp in [{'width':1280,'height':900},{'width':390,'height':844}]:
      W=vp['width']; c=await b.new_context(viewport=vp,permissions=['clipboard-read','clipboard-write'],**({'is_mobile':True,'has_touch':True} if W<500 else {})); await c.add_init_script(INIT); ev=[];ga(c,ev); pg=await c.new_page()
      await pg.goto(U+'word-counter',wait_until='networkidle'); await pg.wait_for_timeout(2500); R.append({'vp':W,'t':now(),'rem0':await rem(pg),'head':await txt(pg,0,700)})
      ta=pg.locator('main textarea').first
      for k,s in (C if W>500 else C[:2]+C[5:6]):
        await ta.fill(s); await pg.wait_for_timeout(500); R.append({'vp':W,'case':k,'in':s,'js_len':len(s),'stats':await stats(pg)})
      big=("lorem ipsum dolor sit amet "*40000); import time; t0=time.time(); await ta.fill(big); await pg.wait_for_timeout(500)
      R.append({'vp':W,'case':'200k-words','secs':round(time.time()-t0,1),'stats':(await stats(pg))[:300]})
      await ta.fill(C[0][1]); await pg.wait_for_timeout(400)
      R.append({'vp':W,'ad_mid':await adcheck(pg,'main textarea,main button')})
      await pg.locator('main button').filter(has_text='Copy stats').click(); await pg.wait_for_timeout(1200)
      try: clip=await pg.evaluate('navigator.clipboard.readText()')
      except Exception as e: clip=str(e)[:80]
      R.append({'vp':W,'clip':clip,'rem_after':await rem(pg),'ga':ev,'ad_end':await adcheck(pg),'below':(await txt(pg,0,9000))[(await txt(pg,0,9000)).find('Reading Time'):][:600]})
      await pg.screenshot(path=f'ss/wc-{W}-after.png',full_page=True)
      json.dump(R,open('wc.json','w'),indent=1,ensure_ascii=False); await c.close()
asyncio.run(main())
