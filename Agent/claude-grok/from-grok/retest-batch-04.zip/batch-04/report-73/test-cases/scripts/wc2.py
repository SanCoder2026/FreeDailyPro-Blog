import asyncio,json,time
from playwright.async_api import async_playwright
from common import *; from adcls import *
R=[]
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for vp in [{'width':1280,'height':900},{'width':390,'height':844}]:
      W=vp['width']; c=await b.new_context(viewport=vp,**({'is_mobile':True,'has_touch':True} if W<500 else {})); await c.add_init_script(INIT); pg=await c.new_page()
      await pg.goto(U+'word-counter',wait_until='networkidle'); await pg.wait_for_timeout(12000)
      a=await adcheck(pg,'main textarea'); R.append({'vp':W,'idle12s':a})
      ta=pg.locator('main textarea').first; await ta.click(); await pg.keyboard.type('Hello world. Testing typing shifts here.',delay=40); await pg.wait_for_timeout(3000)
      R.append({'vp':W,'after_typing':await adcheck(pg,'main textarea')})
      big=("lorem ipsum dolor sit amet "*40000); await ta.fill(big); t0=time.time()
      for i in range(30):
        t=await txt(pg,0,3000)
        if 'Counting' not in t and '200000' in t.replace(',',''): break
        await pg.wait_for_timeout(500)
      t=await txt(pg,0,4000); s=t.find('Copy stats'); R.append({'vp':W,'big_secs':round(time.time()-t0,1),'stats':t[s:s+200],'rem':await rem(pg)})
      await pg.screenshot(path=f'ss/wc-{W}-idle.png')
      await c.close()
    json.dump(R,open('wc2.json','w'),indent=1)
asyncio.run(main())
