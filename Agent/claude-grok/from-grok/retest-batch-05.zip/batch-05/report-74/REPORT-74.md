# QA Report #74: Compress Video · Video to GIF · Sign PDF (retest cycle 2, batch 5)
Tested Thu Oct 29 2026, 22:35–23:20 ET · Playwright Chromium headless · 1280×800 desktop + 390×844 mobile (touch) · logged out, fresh context per run · no sign-ups, no payments, no API writes.

## Summary
All three tools work end-to-end on both devices. Every prior bug I re-checked is **verified fixed**. There is nothing at P0 or P1. New: B-0067 (P3 copy) and B-0068 (P3 meta). Ad overlap: none. CLS: load ≤0.088. After use, Compress Video is 0.10–0.138 on desktop (video embed `mt-8`), added to B-0041.

## Compress Video (52 views; "how to compress video file size" 0/733 at pos 6.5; "compress video" 2/62 at pos 14.1)
| Case | Device | Input | Result |
|---|---|---|---|
| Medium | 1280 | clip.mp4 4.29 MB 720p | 3.04 MB (−29.1%), audio kept ✓ |
| Strong | 1280 | clip.mp4 | −52.7% ✓ |
| Custom 8 MB | 1280 | big.mp4 28.7 MB 1080p 20 s | 7.31 MB, 1080p kept, 32 s, "Target reached" ✓ |
| 720p | 1280 | big.mp4 | 1280×720, 20.0 MB (−30%) ✓ |
| Medium | 390 | clip.mp4 | works ✓ |
Notes: one 8 MB run took the trial counter from 10 to 0 (B-0055 evidence). GA fires only page_view (B-0060). Competitors (8mb.video, 8disc, ShrinkClip, CapsuleTools, Squish) all offer one-tap 8/10/25/50 MB presets and on-device processing. Discord's free limit is now 10 MB per 8disc/CapsuleTools, so a "10 MB" preset is a growth idea for the owner, not a bug. **Mature-candidate.**

## Video to GIF
Batch-12 fixes **verified**:
- A corrupt file (fake.mp4) shows "couldn't be read as a video… re-export as MP4". The button is disabled and no use is charged (10→10).
- Start 10 s on a 6 s clip is clamped ("Clip is 6.0 s long…"), giving a 0.5 s GIF.
- No charge on drop.

Other results:
- Default output: 480×270, 60 frames, 5 s, loops.
- Custom 320 px / 10 fps / 2× / play once: no loop ✓ and speed is applied.
- 2 MB cap: 1.29 MB file, but the UI says "1.23 MB" (MiB). This goes to B-0067.
- Mobile ✓.
- Harness note: Playwright `fill()` on Start/Length gave a stale value. Real typing works, so this is not a bug.
- Competitor: ezgif (crop, reverse, optimize) remains the feature bar.

## Sign PDF (126 views)
| ID | Status |
|---|---|
| SIGN-01 download no-op | **claimed fixed: verified.** No fields gives the message "Tap where you want to sign: add a Signature field above, then click the page." |
| SIGN-02 charge on drop | **verified fixed** (2→2 on drop) |
| SIGN-03 metadata overwritten | **verified fixed**: Title "Lease Agreement 2026" and Author "Acme Realty" are kept (Subject "unspecified" was added, minor) |
| SIGN-04 signature offset | **verified fixed**: the signature sits centred on the line (screenshots/sign-out-1.png), page 2 untouched, 2 pages kept |

- Desktop click placement plus download ✓ (out/sign-1280-signed-contract.pdf). My first desktop attempt clicked off-screen (harness) and was re-run with an element-relative click.
- Mobile tap ✓.
- The trial pool is server-side (desktop retry showed rem 0 after the mobile use).
- Meta description is 48 characters, which goes to B-0068. "Tap" on desktop goes to B-0067.
- Competitors: Smallpdf, iLovePDF and PDF24 offer typed/drawn/uploaded signatures, request-signature and multi-field. FDP already has Initial/Date/Full Name fields. **Mature-candidate.**

## Briefs (ranked)
1. B-0066 (P2, in report #75): Compress Image target default
2. B-0068 (P3): meta descriptions for GIF/Sign
3. B-0067 (P3): copy consistency
Evidence added: B-0055, B-0060, B-0041.
