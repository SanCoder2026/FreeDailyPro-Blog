from run import *
async def st(pg): print('CHECKED_DEFAULT',await pg.locator('main input[type=checkbox]').first.is_checked()); sys.stdout.flush()
async def unc(pg): await pg.locator('main input[type=checkbox]').first.uncheck()
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    await job(b,1280,'compress-image','fx/photo.jpg',[click('Custom Target'),st,unc,click('200 KB')],'Compress','ci-200k-resizeok')
    json.dump(OUT,open('ci2.json','w'),indent=1,ensure_ascii=False)
asyncio.run(main())
