from run import *
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(); c=await b.new_context(viewport={'width':1280,'height':900}); pg=await c.new_page()
    await pg.goto(U+'video-to-gif',wait_until='load'); await pg.wait_for_timeout(2000)
    await pg.locator('input[type=file]').first.set_input_files('fx/fake.mp4'); await pg.wait_for_timeout(4000)
    t=await txt(pg,0,3000); print('FAKE',t[t.find('Quick Buy\n\n',t.find('Quick Buy')+5):][:500].replace('\n',' | ')); print('rem',await rem(pg))
    await pg.screenshot(path='ss/gif-fake-1280.png')
    await c.close()
  async with async_playwright() as p:
    b=await p.chromium.launch()
    await job(b,1280,'video-to-gif','fx/counter.mp4',[fill('#gif-start',2),fill('#gif-length',3),sel(1,'10 fps'),sel(2,'2x')],'Create GIF','gif-speed')
    await job(b,1280,'video-to-gif','fx/counter.mp4',[fill('#gif-start',2),fill('#gif-length',3),sel(1,'10 fps')],'Create GIF','gif-nospeed')
    json.dump(OUT,open('gif2.json','w'),indent=1,ensure_ascii=False)
asyncio.run(main())
