from run import *
def typ(s,v):
  async def f(pg):
    e=pg.locator(s).first; await e.click(); await pg.keyboard.press('Control+A'); await pg.keyboard.type(str(v)); await pg.keyboard.press('Tab'); await pg.wait_for_timeout(300)
  return f
async def vals(pg): print('VALS',await pg.evaluate("[document.querySelector('#gif-start').value,document.querySelector('#gif-length').value]"))
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    await job(b,1280,'video-to-gif','fx/counter.mp4',[typ('#gif-start',2),typ('#gif-length',3),vals],'Create GIF','gif-typed')
    await job(b,1280,'video-to-gif','fx/counter.mp4',[typ('#gif-length',3),vals],'Create GIF','gif-len3only')
    json.dump(OUT,open('gif3.json','w'),indent=1,ensure_ascii=False)
asyncio.run(main())
