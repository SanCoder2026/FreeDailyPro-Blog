from run import *
def fit(m):
  async def f(pg):
    await pg.locator('main input[type=checkbox]').first.uncheck()
    await pg.locator('main input[type=number]').nth(0).fill('1000'); await pg.locator('main input[type=number]').nth(1).fill('1000')
    await pg.locator('main [aria-label*="fits"]').first.click(); await pg.wait_for_timeout(400)
    o=pg.get_by_role('option').filter(has_text=re.compile('^'+m,re.I))
    if await o.count()==0: o=pg.locator('[role=option],[role=menuitem],li').filter(has_text=re.compile(m,re.I))
    print('opts',await pg.locator('[role=option]').all_inner_texts()); await o.first.click(); await pg.wait_for_timeout(300)
  return f
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    await job(b,390,'resize-crop','fx/photo.png',[fill('main input[type=number] >> nth=0',600)],'Resize Image','rs-mob')
    await job(b,1280,'compress-image','fx/photo.jpg',[],'Compress','ci-medium')
    await job(b,1280,'compress-image','fx/photo.jpg',[click('Strong')],'Compress','ci-strong')
    await job(b,1280,'compress-image','fx/photo.jpg',[click('Custom Target'),click('200 KB')],'Compress','ci-200k')
    await job(b,1280,'compress-image','fx/photo.jpg',[click('Custom Target'),click('50 KB'),check(0)],'Compress','ci-50k-keepdims')
    await job(b,1280,'compress-image','fx/photo.png',[],'Compress','ci-png')
    await job(b,390,'compress-image','fx/photo.jpg',[click('Custom Target'),click('100 KB')],'Compress','ci-mob')
    json.dump(OUT,open('img.json','w'),indent=1,ensure_ascii=False)
asyncio.run(main())
