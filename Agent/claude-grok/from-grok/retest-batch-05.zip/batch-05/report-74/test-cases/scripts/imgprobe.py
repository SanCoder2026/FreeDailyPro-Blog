from run import *
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    c=await b.new_context(viewport={'width':1280,'height':900}); pg=await c.new_page()
    await pg.goto(U+'compress-image',wait_until='load'); await pg.wait_for_timeout(2000)
    await pg.locator('input[type=file]').first.set_input_files('fx/photo.jpg'); await pg.wait_for_timeout(2500)
    for t in ['Custom Target','Manual Quality']:
      await pg.locator('main button').filter(has_text=t).first.click(); await pg.wait_for_timeout(500)
      tx=await txt(pg,0,4000); print('##',t,tx[tx.find('photo.jpg'):][:700].replace('\n',' | ')); print(await ui(pg))
      print(await pg.evaluate("[...document.querySelectorAll('main input[type=range],main input[type=number],main select')].map(e=>[e.tagName,e.type,e.min,e.max,e.value,e.id,e.getAttribute('aria-label')])"))
    await pg.goto(U+'resize-crop',wait_until='load'); await pg.wait_for_timeout(2000)
    await pg.locator('input[type=file]').first.set_input_files('fx/photo.jpg'); await pg.wait_for_timeout(2500)
    await pg.locator('main input[type=checkbox]').first.uncheck(); await pg.wait_for_timeout(500)
    tx=await txt(pg,0,4000); print('## resize unchecked',tx[tx.find('photo.jpg'):][:900].replace('\n',' | ')); print(await ui(pg))
    await pg.locator('main button').filter(has_text='Crop').first.click(); await pg.wait_for_timeout(800)
    tx=await txt(pg,0,4000); print('## crop',tx[tx.find('photo.jpg'):][:900].replace('\n',' | ')); print(await ui(pg))
    await pg.screenshot(path='ss/resize-crop-mode.png',full_page=True)
asyncio.run(main())
