import asyncio,json,re,sys,subprocess,time
from playwright.async_api import async_playwright
from common import *; from adcls import *
OUT=[]
async def job(b,W,tool,fx,acts,runbtn,name,dlpat='Download',wait=180000,post=None):
  c=await b.new_context(viewport={'width':W,'height':900 if W>500 else 844},accept_downloads=True,**({'is_mobile':True,'has_touch':True} if W<500 else {})); await c.add_init_script(INIT); ev=[];ga(c,ev); pg=await c.new_page()
  r={'name':name,'tool':tool,'vp':W,'t':now(),'fx':fx}
  try:
    await pg.goto(U+tool,wait_until='load'); await pg.wait_for_timeout(2500); r['rem0']=await rem(pg)
    await pg.locator('input[type=file]').first.set_input_files(fx); await pg.wait_for_timeout(2500); r['rem_drop']=await rem(pg)
    for a in acts: await a(pg)
    await pg.wait_for_timeout(400); t0=time.time()
    if runbtn: await pg.locator('main button').filter(has_text=runbtn).first.click()
    try:
      await pg.wait_for_function(f"[...document.querySelectorAll('main button,main a')].some(e=>/{dlpat}/.test(e.innerText)&&e.offsetParent)||/error|couldn|failed|not a valid|cannot|already as small/i.test(document.querySelector('main').innerText.split('About ')[0].replace(/Heavier settings.*/,''))",timeout=wait)
    except Exception as e: r['wait_err']=str(e)[:100]
    r['secs']=round(time.time()-t0,1); await pg.wait_for_timeout(1000)
    t=await txt(pg,0,6000); i=t.find('Quick Buy\n\n',t.find('Quick Buy')+5); r['result']=t[i+11:i+900]
    if post: await post(pg)
    dl=pg.locator('main button,main a').filter(has_text=re.compile(dlpat)).first
    if await dl.count() and await dl.is_visible():
      async with pg.expect_download(timeout=60000) as di: await dl.click()
      d=await di.value; fn=f'out/{name}-{W}-'+d.suggested_filename; await d.save_as(fn); r['file']=fn
    await pg.wait_for_timeout(1500); r['rem_after']=await rem(pg); r['ga']=ev; a=await adcheck(pg,'main button')
    r['ad']={'ovl':a['overlaps'],'cls':a['cls'],'big':[(s['v'],s['src'][:60]) for s in a['shifts'] if s['v']>0.02]}
    await pg.screenshot(path=f'ss/{name}-{W}.png',full_page=False)
  except Exception as e: r['err']=str(e)[:300]
  await c.close(); OUT.append(r); print(json.dumps(r,ensure_ascii=False)[:1400]); sys.stdout.flush()
def click(t):
  async def f(pg): await pg.locator('main button,main label').filter(has_text=t).first.click(); await pg.wait_for_timeout(400)
  return f
def fill(s,v):
  async def f(pg): await pg.locator(s).first.fill(str(v)); await pg.wait_for_timeout(200)
  return f
def sel(i,v):
  async def f(pg): await pg.locator('main select').nth(i).select_option(label=v)
  return f
def check(i=0):
  async def f(pg): await pg.locator('main input[type=checkbox]').nth(i).check()
  return f
async def dump(pg): print('DUMP',(await txt(pg,0,3000))[400:1600].replace('\n',' | ')); print(await ui(pg)); sys.stdout.flush()
