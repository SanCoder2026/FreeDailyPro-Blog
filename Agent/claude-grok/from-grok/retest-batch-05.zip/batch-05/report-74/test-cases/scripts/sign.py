from run import *
import time
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(); R={}
    for W in [1280]:
      c=await b.new_context(viewport={'width':W,'height':900 if W>500 else 844},accept_downloads=True,**({'is_mobile':True,'has_touch':True} if W<500 else {})); await c.add_init_script(INIT); ev=[];ga(c,ev); pg=await c.new_page()
      r={'vp':W,'t':now()}
      await pg.goto(U+'sign-pdf',wait_until='load'); await pg.wait_for_timeout(2500); r['rem0']=await rem(pg)
      await pg.locator('input[type=file][accept*=pdf], input[type=file]').first.set_input_files('fx/contract.pdf'); await pg.wait_for_timeout(3000); r['rem_drop']=await rem(pg)
      t=await txt(pg,0,6000); i=t.find('Fields'); r['fields_before']=t[i:i+300]
      # download with no fields
      dl=pg.locator('main button').filter(has_text='Download Signed PDF').first
      r['dl_enabled_nofields']=await dl.is_enabled()
      if await dl.is_enabled():
        try:
          async with pg.expect_download(timeout=6000) as di: await dl.click()
          r['nofield_dl']=(await di.value).suggested_filename
        except Exception as e: r['nofield_dl']='none: '+((await txt(pg,0,6000))[i:i+300])
      await pg.locator('input[placeholder="Jane Q. Public"]').fill('Santa Tester'); await pg.locator('input[placeholder="JQP"]').fill('ST'); await pg.wait_for_timeout(800)
      await pg.evaluate("(()=>{const b=[...document.querySelectorAll('main button')].filter(b=>b.offsetParent&&b.innerText.trim()==='Signature');b[b.length-1].click()})()"); await pg.wait_for_timeout(500)
      cv=pg.locator('main canvas, main img[alt*=age], main [data-page]').last
      r['canvases']=await pg.evaluate("[...document.querySelectorAll('main canvas')].map(c=>[c.width,c.height,Math.round(c.getBoundingClientRect().top)])")
      pv=pg.locator('main canvas').last; await pv.scroll_into_view_if_needed(); bb=await pv.bounding_box(); r['bb']=bb
      # click at signature line: PDF line y=150pt of 792 from bottom, x=72..300 of 612
      x=bb['x']+bb['width']*(186/612); y=bb['y']+bb['height']*((792-150)/792)
      await pv.click(position={'x':bb['width']*(186/612),'y':bb['height']*((792-150)/792)})
      await pg.wait_for_timeout(800); t=await txt(pg,0,7000); i=t.find('Fields'); r['fields_after']=t[i:i+400]
      await pg.screenshot(path=f'ss/sign-{W}-placed.png',full_page=False)
      try:
        async with pg.expect_download(timeout=20000) as di: await dl.click()
        d=await di.value; fn=f'out/sign-{W}-'+d.suggested_filename; await d.save_as(fn); r['file']=fn
      except Exception as e: r['dl_err']=str(e)[:100]; t=await txt(pg,0,7000); r['after_click']=t[:1500]
      await pg.wait_for_timeout(1500); r['rem_after']=await rem(pg); r['ga']=ev; a=await adcheck(pg,'main canvas,main button'); r['ad']={'ovl':a['overlaps'],'cls':a['cls'],'big':[(s['v'],s['src'][:60]) for s in a['shifts'] if s['v']>0.02],'docW':a['docW']}
      await pg.screenshot(path=f'ss/sign-{W}-after.png',full_page=True); R[W]=r; print(json.dumps(r,ensure_ascii=False)[:2500]); await c.close()
    json.dump(R,open('sign-desk.json','w'),indent=1,ensure_ascii=False)
asyncio.run(main())
