import asyncio,json
from playwright.async_api import async_playwright
from common import *; from adcls import *
J=[('compress-video','fx/clip.mp4'),('video-to-gif','fx/clip.mp4'),('resize-crop','fx/photo.jpg'),('compress-image','fx/photo.jpg'),('sign-pdf','fx/contract.pdf')]
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(); R={}
    for t,f in J:
      c=await b.new_context(viewport={'width':1280,'height':900}); pg=await c.new_page()
      await pg.goto(U+t,wait_until='load'); await pg.wait_for_timeout(2500); r0=await rem(pg)
      await pg.locator('input[type=file]').first.set_input_files(f); await pg.wait_for_timeout(5000)
      t2=await txt(pg,0,5000); s=t2.find('Quick Buy\n\n',t2.find('Quick Buy')+5)
      R[t]={'rem0':r0,'rem_drop':await rem(pg),'ui':await ui(pg),'txt':t2[s:s+2200],
       'sel':await pg.evaluate("[...document.querySelectorAll('main select')].map(s=>[s.getAttribute('aria-label')||s.name,[...s.options].map(o=>o.text)])"),
       'rng':await pg.evaluate("[...document.querySelectorAll('main input[type=range],main input[type=number]')].map(e=>[e.type,e.min,e.max,e.step,e.value,e.getAttribute('aria-label')||e.id])")}
      await pg.screenshot(path=f'ss/{t}-1280-loaded.png',full_page=True); await c.close()
    json.dump(R,open('ui2.json','w'),indent=1,ensure_ascii=False)
asyncio.run(main())
