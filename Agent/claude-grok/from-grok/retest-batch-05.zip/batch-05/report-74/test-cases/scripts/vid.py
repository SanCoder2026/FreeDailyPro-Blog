from run import *
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    await job(b,1280,'compress-video','fx/clip.mp4',[],'Compress Video','cv-medium')
    await job(b,1280,'compress-video','fx/clip.mp4',[click('Strong')],'Compress Video','cv-strong')
    await job(b,1280,'compress-video','fx/big.mp4',[click('Custom Target'),dump],None,'cv-probe',wait=3000)
    await job(b,1280,'compress-video','fx/big.mp4',[click('Manual Quality'),dump],None,'cv-probe2',wait=3000)
    await job(b,1280,'compress-video','fx/big.mp4',[check(0)],'Compress Video','cv-720p')
    await job(b,390,'compress-video','fx/clip.mp4',[],'Compress Video','cv-mob')
    await job(b,1280,'video-to-gif','fx/clip.mp4',[],'Create GIF','gif-default')
    await job(b,1280,'video-to-gif','fx/clip.mp4',[fill('#gif-start',2),fill('#gif-length',3),sel(0,'320 px'),sel(1,'10 fps'),sel(2,'2x'),check(0)],'Create GIF','gif-custom')
    await job(b,1280,'video-to-gif','fx/clip.mp4',[sel(0,'800 px'),sel(1,'20 fps'),sel(3,'2 MB')],'Create GIF','gif-cap2mb')
    await job(b,1280,'video-to-gif','fx/clip.mp4',[fill('#gif-start',10)],'Create GIF','gif-startpast')
    await job(b,1280,'video-to-gif','fx/fake.mp4',[],'Create GIF','gif-fake',wait=20000)
    await job(b,390,'video-to-gif','fx/clip.mp4',[],'Create GIF','gif-mob')
    json.dump(OUT,open('vid.json','w'),indent=1,ensure_ascii=False)
asyncio.run(main())
