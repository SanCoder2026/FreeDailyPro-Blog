from run import *
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    await job(b,1280,'compress-video','fx/clip.mp4',[],'Compress Video','cv-medium',dlpat='^Download')
    await job(b,1280,'compress-video','fx/clip.mp4',[click('Strong')],'Compress Video','cv-strong',dlpat='^Download')
    await job(b,1280,'compress-video','fx/big.mp4',[click('Custom Target'),click('8 MB')],'Compress Video','cv-8mb',dlpat='^Download',wait=400000)
    await job(b,1280,'compress-video','fx/big.mp4',[check(0)],'Compress Video','cv-720p',dlpat='^Download',wait=400000)
    await job(b,390,'compress-video','fx/clip.mp4',[],'Compress Video','cv-mob',dlpat='^Download')
    json.dump(OUT,open('vid2.json','w'),indent=1,ensure_ascii=False)
asyncio.run(main())
