# QA Report #75: Resize & Crop · Compress Image (retest cycle 2, batch 5)
Tested Thu Oct 29 2026, 22:45–23:10 ET · 1280 + 390 · logged out · no writes, payments or sign-ups.

## Resize & Crop (62 views): no new issues
Plan row 17 ("API ignores fit mode"): the **UI applies all five fit modes correctly**. I did not test the API (read/test-only rule). At 1000×1000 on photo.jpg 4000×3000:
- Fill: 1000×1000, stretched.
- Inside: 1000×750.
- Contain: 1000×1000 with white padding.
- Cover: 1000×1000, cropped.
- Outside: 1333×1000.

Crop 16:9 gives 4000×2250 ✓. EXIF is stripped ✓. Mobile PNG to 600 px wide gives 600×450 ✓. Fit modes appear only after unticking "Maintain aspect ratio", which is acceptable. Mobile CLS is 0.119 after use (google-auto-placed 0.035), added to B-0041. No ad overlap. **Mature-candidate.**

## Compress Image (68 views; 2/810 at pos 14.9)
- Medium −31%, Strong −52%, PNG→JPG 413 KB, EXIF stripped ✓.
- **B-0066 (P2):** "Don't change dimensions" is pre-ticked, which contradicts the copy, so Custom 200/100/50 KB all give 384 KB.
- CLS after result: desktop 0.166–0.189, mobile 0.203 (`flex gap-3` result row / `mt-6` ad container), the largest in this batch. Added to B-0041.
- A "Try Editing Apps" anchor ad sits bottom-right without overlapping Download.
- The trial pool was 0 in a fresh context at 23:06 ET (B-0055), so I could not test the unticked path.
