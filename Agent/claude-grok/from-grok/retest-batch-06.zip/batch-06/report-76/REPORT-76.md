# QA Report #76: Universal File Converter · PDF to Word · Word to PDF (retest cycle 2, batch 6)
Thu Oct 29 2026, 23:12–23:25 ET · Playwright headless · 1280 desktop + 390 mobile (touch) · logged out, fresh context each run · no sign-ups, payments or API writes.

## Summary
All three converters produce real, editable output. There are no P0 or P1 issues. New: B-0070 (P3). Ad overlap: none. CLS: load ≤0.098. After use, Universal desktop reached **0.28** (header area 0.178 + video embed 0.080) and Word→PDF mobile 0.103, added to B-0041.

Pool (B-0055 evidence): fresh desktop contexts showed "0 remaining" on Word→PDF, PDF→Word, Universal and Compress Image while mobile contexts seconds later showed 10/10. PDF→Word mobile dropped 10→0 after one use. Universal's 2/day pool was exhausted by 23:22, so the converted download was untested there.

## PDF to Word (79 views; 1/1,089 at pos 32)
| Fixture | Device | Result |
|---|---|---|
| table.pdf (title, bold, link, bullets, 3×3 table) | 390 | docx: bold title, bold run, 2 list paras (numPr), real 3×3 Word table, hyperlink kept, Title/Author kept ✓ |
| contract.pdf (A4, 2 pages) | 390 | 4 paragraphs, page size A4 595×842 kept, metadata kept ✓ |
| table.pdf | 1280 | converted preview ✓, download gated "0 remaining" (pool) |
The preview reports "1 page · 1 table · 1 link", which is a good trust signal. **Mature-candidate.**

## Word to PDF (750 impr, pos 11.8)
- Keep formatting: 2 pages; headings, bold, bullets, numbers, bordered table, picture and page break all ✓. Body font falls back to Times (B-0070).
- Exact look: 2 pages of 192 dpi images plus a text layer ✓.
- The trial badge is disclosed before download ✓.
- Meta is 75 characters (B-0070).

## Universal File Converter (129 views; 1,839 impressions combined)
- Detection works: PDF offers JPG/Excel/Word/Text/HTML; CSV offers Excel/JSON/PDF; the converted xlsx offers PDF/CSV/JSON/Word table.
- PDF→Word conversion ran; the download was gated at 0 trial uses.
- "Original → Download" issue is in B-0070.
- I could not verify the converted download because the 2/day pool was exhausted. Retest next cycle.

Competitors for this report: Smallpdf, iLovePDF, Adobe Acrobat online (snippets lead with "keeps formatting"), CloudConvert (format matrix).
