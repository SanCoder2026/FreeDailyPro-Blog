import asyncio,json,re,sys
from playwright.async_api import async_playwright
from common import *; from adcls import *
R=[]
async def run(b,W,name,fmt,val,btn='Download PNG',scale=None):
  c=await b.new_context(viewport={'width':W,'height':900 if W>500 else 844},accept_downloads=True,**({'is_mobile':True,'has_touch':True} if W<500 else {})); await c.add_init_script(INIT); ev=[];ga(c,ev); pg=await c.new_page()
  r={'name':name,'vp':W,'t':now(),'fmt':fmt,'val':val}
  try:
    await pg.goto(U+'barcode-generator',wait_until='load'); await pg.wait_for_timeout(2500); r['rem0']=await rem(pg)
    if fmt:
      await pg.locator('main button').filter(has_text='EAN-13 (13').first.click(); await pg.wait_for_timeout(500)
      opts=await pg.locator('[role=option]').all_inner_texts(); r['opts']=opts
      await pg.locator('[role=option]').filter(has_text=fmt).first.click(); await pg.wait_for_timeout(500)
    if val is not None:
      i=pg.locator('main input[type=text]').first; await i.click(); await i.press('Control+a'); await i.type(val); await pg.wait_for_timeout(800)
    if scale:
      await pg.locator('main button').filter(has_text='1× (small)').first.click(); await pg.wait_for_timeout(400); r['scales']=await pg.locator('[role=option]').all_inner_texts(); await pg.locator('[role=option]').filter(has_text=scale).first.click()
    t=await txt(pg,0,4000); r['msg']=t[t.find('Format'):t.find('Discover more')][:500]
    r['btn_disabled']=await pg.locator('main button').filter(has_text=btn).first.is_disabled()
    if not r['btn_disabled']:
      try:
        async with pg.expect_download(timeout=15000) as di: await pg.locator('main button').filter(has_text=btn).first.click()
        d=await di.value; fn=f'out/bar-{name}-{W}-'+d.suggested_filename; await d.save_as(fn); r['file']=fn
      except Exception as e: r['dl_err']=str(e)[:80]; t=await txt(pg,0,4000); r['msg2']=t[t.find('Format'):t.find('Discover more')][:400]
    await pg.wait_for_timeout(1200); r['rem_after']=await rem(pg); r['ga']=ev; a=await adcheck(pg,'main button'); r['ad']={'ovl':a['overlaps'],'cls':a['cls']}
    await pg.screenshot(path=f'ss/bar-{name}-{W}.png')
  except Exception as e: r['err']=str(e)[:300]
  await c.close(); R.append(r); print(json.dumps(r,ensure_ascii=False)[:900]); sys.stdout.flush()
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    await run(b,1280,'ean13',None,None)
    await run(b,1280,'ean13svg',None,None,'Download SVG')
    await run(b,1280,'badcheck',None,'5901234123458')
    await run(b,1280,'short',None,'12345')
    await run(b,1280,'c128','Code 128','ABC-123 test',scale='4')
    await run(b,1280,'upca','UPC-A','03600029145')
    await run(b,1280,'itf14','ITF-14','1540014128876')
    await run(b,390,'ean13',None,None)
    json.dump(R,open('bar.json','w'),indent=1,ensure_ascii=False)
asyncio.run(main())
