import asyncio,json
from playwright.async_api import async_playwright
import run; from run import *
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    await job(b,1280,'word-to-pdf','fx/report.docx',[],'Convert to PDF','w2p-keep',dlpat='Download',wait=60000)
    await job(b,390,'word-to-pdf','fx/report.docx',[click('Exact look')],'Convert to PDF','w2p-exact',dlpat='Download',wait=60000)
    await job(b,1280,'pdf-to-word','fx/table.pdf',[],'Convert to Word','p2w-table',dlpat='Download',wait=90000)
    await job(b,390,'pdf-to-word','fx/contract.pdf',[],'Convert to Word','p2w-contract',dlpat='Download',wait=90000)
    await job(b,1280,'universal-file-converter','fx/table.pdf',[click('Word')],None,'uni-pdf-word',dlpat='Download',wait=60000)
    await job(b,390,'universal-file-converter','fx/data.csv',[dump],None,'uni-csv',dlpat='NOPE',wait=1000)
    json.dump(run.OUT,open('conv.json','w'),indent=1,ensure_ascii=False)
asyncio.run(main())
