import asyncio,json,sys
from playwright.async_api import async_playwright
import run; from run import *
async def st(pg): print('CHECKED_DEFAULT',await pg.locator('main input[type=checkbox]').first.is_checked()); sys.stdout.flush()
async def unc(pg): await pg.locator('main input[type=checkbox]').first.uncheck(); print('NOW',await pg.locator('main input[type=checkbox]').first.is_checked())
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    await job(b,390,'compress-image','fx/photo.jpg',[click('Custom Target'),st,unc,click('200 KB')],'Compress','ci-200k-unticked')
    await job(b,390,'pdf-to-word','fx/table.pdf',[],'Convert to Word','p2w-table',dlpat='Download',wait=90000)
    await job(b,390,'word-to-pdf','fx/report.docx',[],'Convert to PDF','w2p-keep',dlpat='Download',wait=60000)
    await job(b,390,'universal-file-converter','fx/data.csv',[click('Excel')],None,'uni-csv-xlsx',dlpat='Download',wait=60000)
    json.dump(run.OUT,open('conv2.json','w'),indent=1,ensure_ascii=False)
asyncio.run(main())
