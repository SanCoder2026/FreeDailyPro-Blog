import asyncio,json,sys,re
from playwright.async_api import async_playwright
from common import *; from adcls import *
R=[]
async def go(b,tool,fx,pre,name,waitre,dlidx):
  c=await b.new_context(viewport={'width':390,'height':844},accept_downloads=True,is_mobile=True,has_touch=True); await c.add_init_script(INIT); pg=await c.new_page()
  r={'name':name,'t':now()}
  await pg.goto(U+tool,wait_until='load'); await pg.wait_for_timeout(2500); r['rem0']=await rem(pg)
  await pg.locator('input[type=file]').first.set_input_files(fx); await pg.wait_for_timeout(2000)
  await pre(pg)
  try: await pg.wait_for_function(f"/{waitre}/.test(document.querySelector('main').innerText.split('About ')[0])",timeout=120000)
  except Exception as e: r['werr']=str(e)[:80]
  await pg.wait_for_timeout(1500); t=await txt(pg,0,6000); i=t.find('Original'); r['result']=t[i:i+900]
  dls=pg.locator('main button').filter(has_text=re.compile('^Download')); r['ndl']=await dls.count()
  async with pg.expect_download(timeout=30000) as di: await dls.nth(dlidx if dlidx>=0 else r['ndl']-1).click()
  d=await di.value; fn=f'out/{name}-390-'+d.suggested_filename; await d.save_as(fn); r['file']=fn
  await pg.wait_for_timeout(1500); r['rem_after']=await rem(pg); a=await adcheck(pg,'main button'); r['ad']={'ovl':a['overlaps'],'cls':a['cls']}
  await pg.screenshot(path=f'ss/{name}-390.png',full_page=True); await c.close(); R.append(r); print(json.dumps(r,ensure_ascii=False)[:1500]); sys.stdout.flush()
async def ci(pg):
  await pg.locator('main button,main label').filter(has_text='Custom Target').first.click(); await pg.locator('main input[type=checkbox]').first.uncheck()
  await pg.locator('main button').filter(has_text='200 KB').first.click(); await pg.locator('main button').filter(has_text=re.compile('^Compress')).last.click()
async def xl(pg): await pg.get_by_role('button',name='Excel',exact=True).first.click()
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()


    try: await go(b,'universal-file-converter','fx/data.csv',xl,'uni-csv-xlsx','converted.xlsx',-1)
    except Exception as e: print('uni err',e)
    json.dump(R,open('conv4.json','w'),indent=1,ensure_ascii=False)
asyncio.run(main())
