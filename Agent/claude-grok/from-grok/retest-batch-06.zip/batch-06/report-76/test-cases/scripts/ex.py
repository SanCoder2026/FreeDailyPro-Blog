import asyncio,sys
from playwright.async_api import async_playwright
from run import *
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for tool,fx,W in [('word-to-pdf','fx/report.docx',1280),('pdf-to-word','fx/table.pdf',390),('universal-file-converter','fx/table.pdf',390)]:
      await job(b,W,tool,fx,[dump],None,'ex-'+tool,dlpat='NOPE',wait=1000)
asyncio.run(main())
