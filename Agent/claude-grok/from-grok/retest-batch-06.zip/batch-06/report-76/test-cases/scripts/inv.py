import asyncio,json,sys
from playwright.async_api import async_playwright
from common import *; from adcls import *
R=[]
async def run(b,W,name,custom=False):
  c=await b.new_context(viewport={'width':W,'height':900 if W>500 else 844},accept_downloads=True,**({'is_mobile':True,'has_touch':True} if W<500 else {})); await c.add_init_script(INIT); ev=[];ga(c,ev); pg=await c.new_page()
  r={'name':name,'vp':W,'t':now()}
  try:
    await pg.goto(U+'invoice-generator',wait_until='load'); await pg.wait_for_timeout(2500); r['rem0']=await rem(pg)
    r['empty_btn_disabled']=await pg.locator('main button').filter(has_text='Generate').first.is_disabled()
    await pg.locator('main button').filter(has_text='Try a sample').first.click(); await pg.wait_for_timeout(800)
    if custom:
      await pg.locator('main select').nth(0).select_option(label='Net 30'); await pg.locator('main select').nth(1).select_option(label='€ Euro')
    t=await txt(pg,0,6000); r['form']=t[t.find('Your Business'):t.find('Generate')]
    r['vals']=await pg.evaluate("[...document.querySelectorAll('main input,main textarea,main select')].map(e=>e.value).filter(v=>v)")
    await pg.screenshot(path=f'ss/inv-{name}-{W}-form.png',full_page=True)
    async with pg.expect_download(timeout=30000) as di: await pg.locator('main button').filter(has_text='Generate').first.click()
    d=await di.value; fn=f'out/inv-{name}-{W}-'+d.suggested_filename; await d.save_as(fn); r['file']=fn
    await pg.wait_for_timeout(1500); r['rem_after']=await rem(pg); r['ga']=ev; a=await adcheck(pg,'main button'); r['ad']={'ovl':a['overlaps'],'cls':a['cls'],'big':[(s['v'],s['src'][:60]) for s in a['shifts'] if s['v']>0.02]}
  except Exception as e: r['err']=str(e)[:300]
  await c.close(); R.append(r); print(json.dumps(r,ensure_ascii=False)[:2500]); sys.stdout.flush()
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    await run(b,1280,'sample'); await run(b,390,'eur',True)
    json.dump(R,open('inv.json','w'),indent=1,ensure_ascii=False)
asyncio.run(main())
