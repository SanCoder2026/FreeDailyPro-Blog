# QA Report #77: Barcode Generator · Invoice Generator · Compress Image recheck (batch 6)
Thu Oct 29 2026, 23:14–23:23 ET · 1280 + 390 · logged out · no writes, payments or sign-ups.

## Barcode Generator (3/2,045 at pos 7.8)
All outputs decode with zxing-cpp:
- EAN-13 PNG on desktop and mobile.
- Code 128 at 4× (prints 4.72 in, 300 dpi copy shown).
- SVG.

Validation is excellent: a wrong check digit and a short value are both blocked with clear copy, and no use is charged. At 0 trial uses the button shows "0 remaining today, Get a Day Pass". UPC-A and ITF-14 downloads were gated by the pool, so they are untested.

Load CLS is 0.043/0.084. After an action the error message pushes the layout (0.12–0.19, B-0041). **B-0069 (P2):** CTR, print-ready defaults, GS1 note, filename. Competitors: readbarcode, barcodesready, barcodepress, openvibe, cleverence.

## Invoice Generator (plan URL /tool/invoice is 404; real page is /tool/invoice-generator)
"Try a sample" fills every field.
- Mobile EUR + Net 30: PDF maths exact, filename INV-001.pdf, trial footer "Created with FreeDailyPro.com", rem 2→1.
- Desktop: no download because the pool showed 0 (B-0055).
- **B-0071 (P3):** payment terms are not printed on the PDF.
- The plan claim "API returns totals only" was not tested (read-only).

CLS 0.06–0.08, no overlap. **Mature-candidate after B-0071.**

## Compress Image recheck (B-0066)
- Mobile 390, Custom Target 200 KB, "Don't change dimensions" **unticked** gives **186 KB at 2200×1650** ✓. The resize path works, so B-0066's fix is only the default (still ticked=True at 23:21 ET).
- CLS after result 0.155–0.198 (`flex gap-3`), added to B-0041.
