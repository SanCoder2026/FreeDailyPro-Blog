# QA Report #78 — BMI, Mortgage, Loan calculators (plan row 22)
Run: 29 Oct 2026, 22:40–23:35 ET · Playwright Chromium headless · 1280×900 and 390×844 · logged out · no payment, no sign-up, no API writes.

## Verified (all independently re-computed)
| Tool | Case | Expected | Actual | 1280 | 390 |
|---|---|---|---|---|---|
| BMI | 70 kg / 170 cm | 24.2, healthy 53.5–72.0 kg | same | ✓ | ✓ |
| BMI | Asian cut-offs 75/170 | 26.0 overweight, "lose 8.8 kg" | same | ✓ | ✓ |
| BMI | weight 0 / height 17 | range errors | "between 30 and 300 kg" / "between 100 and 250 cm" | ✓ | ✓ |
| BMI | imperial default | 154.3 lb, 5 ft 6.9 in | same | ✓ | ✓ |
| Mortgage | default | P&I $2,022.62, total $2,489.28, interest $408,142.36 | same | ✓ | ✓ |
| Mortgage | 15 yr | $2,787.54 | same | ✓ | ✓ |
| Mortgage | 10% down | PMI $180 × 109 mo = $19,620 | same | ✓ | ✓ |
| Mortgage | FHA | UFMIP $6,300, loan $366,300, MIP $150/mo 11 yr | same | ✓ | ✓ |
| Mortgage | +$200/mo extra | payoff Mar 2050, 23 y 5 m, −$105,429 interest | same | ✓ | ✓ |
| Loan | default / flat / 0% / 36 mo | $536.82 / $694.44 ($150k int.) / $277.78 / $2,997.09 | same | ✓ | ✓ |

Results are readable without spending trial uses; copy/save/print use 1 trial use.

## Still broken / new
1. **Mortgage mobile load CLS 0.32–0.48** (2 of 2 re-measures at 23:30 ET; desktop 0.04). Sources: `mg-first-payment` results block and a `google-auto-placed` ad inserted above content (0.21 shift). → **B-0072** (P2), evidence for B-0041.
2. **BMI snippet**: GSC "bmi calculator online" 0 clicks / 504 impressions at pos 6.8. Title "BMI Calculator Online - Metric & Imperial, Free"; meta never mentions the healthy-weight range, Asian cut-offs or "kg to lose" output that competitors don't all have. → **B-0073** (P2).
3. GA: still no tool-completion event on calculators (B-0060 open, evidence added).

## Competitors (live, 23:3x ET)
- calculator.net: "Free Body Mass Index calculator gives out the BMI value and categorizes BMI based on … WHO and CDC for both adults and children."
- NHS: "Check your BMI to find out if you're a healthy weight … and get advice on what to do next."
- NerdWallet / Bankrate mortgage: PMI + extra-payment + amortisation — FDP matches on features.

## Status
BMI, Loan: **mature** after B-0073. Mortgage: mature after B-0072.
