import asyncio,json,re
from playwright.async_api import async_playwright
from common import *; from adcls import *
R={}
async def body(pg): t=await txt(pg,0,9000); a=t.find('Quick Buy',t.find('Quick Buy')+5); return t[a+9:t.find('Reading results')][:2500]
async def sv(pg,l,v): i=pg.get_by_label(l,exact=True).first; await i.click(); await i.press('Control+a'); await i.type(str(v)); await pg.keyboard.press('Tab'); await pg.wait_for_timeout(500)
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for W in [1280,390]:
      c=await b.new_context(viewport={'width':W,'height':900 if W>500 else 844},**({'is_mobile':True,'has_touch':True} if W<500 else {})); await c.add_init_script(INIT); pg=await c.new_page()
      await pg.goto(U+'bmi-calculator'); await pg.wait_for_timeout(2500)
      await pg.locator('main button').filter(has_text='Imperial').click(); await pg.wait_for_timeout(500); R[f'bmi-imp-ui-{W}']=await ui(pg)
      await pg.screenshot(path=f'ss/bmi-imp-{W}.png',full_page=False)
      if W==1280:
        await pg.locator('main button').filter(has_text='Metric').click(); await sv(pg,'Weight',0); R['bmi-zero']=(await body(pg))[:500]
        await sv(pg,'Weight',75); await sv(pg,'Height',170); await pg.locator('main input[type=checkbox]').check(); await pg.wait_for_timeout(500); R['bmi-asian-75-170']=(await body(pg))[:700]
        await sv(pg,'Height',17); R['bmi-h17']=(await body(pg))[:500]
      await pg.goto(U+'mortgage-calculator'); await pg.wait_for_timeout(3000); R[f'mort-loadcls-{W}']=(await adcheck(pg))['cls']
      await sv(pg,'Down payment',10); R[f'mort-10pct-{W}']=(await body(pg))[:1600]
      await pg.locator('main select').first.select_option('fha'); await pg.wait_for_timeout(800); R[f'mort-fha-{W}']=(await body(pg))[:1600]
      await pg.locator('main select').first.select_option('conventional'); await sv(pg,'Down payment',20); await sv(pg,'Extra monthly principal payment',200); R[f'mort-extra-{W}']=(await body(pg))[:1600]
      await pg.screenshot(path=f'ss/mort-{W}.png',full_page=True)
      await pg.goto(U+'loan-calculator'); await pg.wait_for_timeout(2500)
      await pg.locator('main select').nth(2).select_option('flat'); await pg.wait_for_timeout(600); R[f'loan-flat-{W}']=(await body(pg))[:700]
      await pg.locator('main select').nth(2).select_option('reducing'); await sv(pg,'Interest rate',0); R[f'loan-0pct-{W}']=(await body(pg))[:700]
      await sv(pg,'Interest rate',5); await sv(pg,'Loan term',36); await pg.locator('main select').nth(1).select_option('months'); await pg.wait_for_timeout(600); R[f'loan-36m-{W}']=(await body(pg))[:700]
      await pg.screenshot(path=f'ss/loan-{W}.png',full_page=True)
      await c.close()
    json.dump(R,open('calc.json','w'),indent=1,ensure_ascii=False)
asyncio.run(main())
