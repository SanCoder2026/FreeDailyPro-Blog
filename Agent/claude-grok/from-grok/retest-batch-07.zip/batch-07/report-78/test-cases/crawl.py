import asyncio,json,re
from playwright.async_api import async_playwright
from common import *; from adcls import *
pages=['/tools','/category/pdf-tools','/category/image-tools','/category/video-tools','/category/text-tools','/category/converters','/category/business-tools','/category/audio-tools','/category/finance-calculators','/category/security-tools','/developers']
R={}
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for W in [1280,390]:
      c=await b.new_context(viewport={'width':W,'height':900 if W>500 else 844},**({'is_mobile':True,'has_touch':True} if W<500 else {})); await c.add_init_script(INIT); pg=await c.new_page()
      for u in pages:
        if W==390 and u not in ['/tools','/category/pdf-tools','/developers']: continue
        await pg.goto('https://www.freedailypro.com'+u,wait_until='load'); await pg.wait_for_timeout(4000)
        d=await pg.evaluate("""()=>({title:document.title,desc:document.querySelector('meta[name=description]')?.content,canon:document.querySelector('link[rel=canonical]')?.href,robots:document.querySelector('meta[name=robots]')?.content,h1:[...document.querySelectorAll('h1')].map(e=>e.innerText),
          links:[...new Set([...document.querySelectorAll('a[href]')].map(a=>a.href).filter(h=>h.includes('freedailypro.com')))],docW:document.documentElement.scrollWidth})""")
        d['ad']=await adcheck(pg); d['txt']=(await txt(pg,0,20000))
        R[f'{u}-{W}']=d; await pg.screenshot(path=f"ss/{u.strip('/').replace('/','_')}-{W}.png",full_page=False)
      await c.close()
    json.dump(R,open('crawl.json','w'),indent=1,ensure_ascii=False)
asyncio.run(main())
