import asyncio,json
from playwright.async_api import async_playwright
from common import *; from adcls import *
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(args=['--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream']); R={}
    for t in ['bmi-calculator','mortgage-calculator','loan-calculator','jwt-decoder','uuid-generator','hash-generator']:
      for vp in [{'width':1280,'height':900},{'width':390,'height':844}]:
        c=await b.new_context(viewport=vp,permissions=['camera'],**({'is_mobile':True,'has_touch':True} if vp['width']<500 else {})); await c.add_init_script(INIT); pg=await c.new_page()
        await pg.goto(U+t,wait_until='load'); await pg.wait_for_timeout(5000)
        R[f"{t}-{vp['width']}"]={'t':now(),'title':await pg.title(),'desc':await pg.evaluate('document.querySelector("meta[name=description]")?.content'),'ui':await ui(pg),'txt':await txt(pg,0,2500),'ad':await adcheck(pg)}
        await pg.screenshot(path=f"ss/{t}-{vp['width']}-load.png",full_page=True); await c.close()
    json.dump(R,open('probe.json','w'),indent=1,ensure_ascii=False)
asyncio.run(main())
