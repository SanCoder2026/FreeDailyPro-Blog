import asyncio,json,sys,re
from playwright.async_api import async_playwright
from common import *; from adcls import *
R={}
JWT='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyLCJleHAiOjE1MTYyNDI2MjJ9.x'
async def ctx(b,W):
  c=await b.new_context(viewport={'width':W,'height':900 if W>500 else 844},accept_downloads=True,**({'is_mobile':True,'has_touch':True} if W<500 else {})); await c.add_init_script(INIT); ev=[];ga(c,ev); return c,ev,await c.new_page()
async def dlg(pg,k):
  d=pg.locator('[role=dialog]')
  if await d.count(): R[k+'-DIALOG']=(await d.first.inner_text())[:500]; await pg.keyboard.press('Escape'); await pg.wait_for_timeout(500)
async def body(pg): t=await txt(pg,0,8000); a=t.find('Quick Buy',t.find('Quick Buy')+5); return t[a+9:t.find('About ')][:1500]
async def setv(pg,label,v):
  i=pg.get_by_label(label,exact=True).first; await i.fill(str(v)); await pg.wait_for_timeout(300)
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for W in [1280,390]:
      c,ev,pg=await ctx(b,W)
      # JWT
      await pg.goto(U+'jwt-decoder'); await pg.wait_for_timeout(2500)
      ta=pg.locator('main textarea').first
      for k,v in [('valid','Bearer '+JWT),('garbage','not.a.jwt'),('two','abc.def')]:
        await ta.fill(v); await pg.wait_for_timeout(1200); R[f'jwt-{k}-{W}']=await body(pg)
      R[f'jwt-ad-{W}']=await adcheck(pg,'main textarea'); await pg.screenshot(path=f'ss/jwt-{W}.png',full_page=True)
      # UUID
      await pg.goto(U+'uuid-generator'); await pg.wait_for_timeout(2500); R[f'uuid-rem0-{W}']=await rem(pg)
      await pg.locator('main input[type=number]').fill('1000'); await pg.locator('main button').filter(has_text='Generate').first.click(); await pg.wait_for_timeout(1500)
      t=await txt(pg,0,200000); R[f'uuid-n-{W}']=len(set(re.findall(r'[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}',t)))
      R[f'uuid-body-{W}']=(await body(pg))[:400]; await dlg(pg,f'uuid1-{W}')
      await pg.locator('main input[type=number]').fill('5000'); await pg.locator('main button').filter(has_text='Generate').first.click(); await pg.wait_for_timeout(1500)
      t=await txt(pg,0,400000); R[f'uuid-5000-{W}']=len(re.findall(r'[0-9a-fA-F]{8}-?[0-9a-fA-F]{4}-?4',t)); R[f'uuid-5000msg-{W}']=(await body(pg))[:300]; await dlg(pg,f'uuid2-{W}')
      await pg.locator('main input[type=checkbox]').nth(0).uncheck(); await pg.locator('main input[type=checkbox]').nth(1).check(); await pg.locator('main input[type=number]').fill('3'); await pg.locator('main button').filter(has_text='Generate').first.click(); await pg.wait_for_timeout(1000)
      R[f'uuid-fmt-{W}']=(await body(pg))[:400]; R[f'uuid-rem1-{W}']=await rem(pg); R[f'uuid-ad-{W}']=await adcheck(pg,'main button')
      # Hash
      await pg.goto(U+'hash-generator'); await pg.wait_for_timeout(2500); R[f'hash-rem0-{W}']=await rem(pg)
      await pg.locator('main textarea').fill('abc'); await pg.locator('main button').filter(has_text='Generate Hashes').click(); await pg.wait_for_timeout(1500); R[f'hash-abc-{W}']=await body(pg); await dlg(pg,f'hash1-{W}')
      await pg.locator('main input[type=file]').set_input_files('fx/blob.bin'); await pg.wait_for_timeout(2500)
      b2=pg.locator('main button').filter(has_text='Generate Hashes')
      if await b2.is_enabled(): await b2.click()
      await pg.wait_for_timeout(4000); R[f'hash-file-{W}']=await body(pg); R[f'hash-rem1-{W}']=await rem(pg); R[f'hash-ad-{W}']=await adcheck(pg,'main button'); await pg.screenshot(path=f'ss/hash-{W}.png',full_page=True)
      R[f'ga-{W}']=ev; json.dump(R,open('dev.json','w'),indent=1,ensure_ascii=False); await c.close()
    json.dump(R,open('dev.json','w'),indent=1,ensure_ascii=False)
asyncio.run(main())
