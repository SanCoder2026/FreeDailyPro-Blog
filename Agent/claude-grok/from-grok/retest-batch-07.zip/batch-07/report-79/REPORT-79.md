# QA Report #79 — JWT Decoder, UUID Generator, Hash Generator (plan row 23)
Run: 29 Oct 2026, 22:45–23:20 ET · 1280 / 390 · logged out.

## Verified
| Tool | Case | Expected | Actual |
|---|---|---|---|
| JWT | standard token, "Bearer " prefix | header/payload decoded, prefix stripped | ✓ |
| JWT | iat/exp | UTC + local, "Expired" flag | ✓ |
| JWT | bad base64 / 2 parts | clear error | "not valid Base64URL" / "expected 3 parts… found 2" ✓ |
| UUID | 1,000 | 1,000 unique valid v4 | ✓ |
| UUID | 5,000 | cap message | "Maximum is 1,000 per batch" ✓ |
| UUID | upper / no-hyphen / Copy All | applied | ✓ |
| Hash | "abc" | MD5/SHA-1/256/384/512 reference values | ✓ |
| Hash | **file 3,000,000 B (fx/blob.bin)** | sha256 1507de64…d78a, md5 fb14755b…82d | matches sha256sum/md5sum ✓ |

**Plan item "file hashing missing" is resolved** — file hashing + "Compare with expected checksum" now exist.

## Still broken / new
1. Meta descriptions short: JWT 73, Hash 74, UUID 76 chars; GSC "jwt decode online" 1 click / 76 impr / pos 8.4. → **B-0074** (P3).
2. UUID 390 at pool 0: limit dialog, nothing generated (B-0055 evidence — pool flips 0↔10 within seconds across contexts).
3. JWT CLS after typing 0.31/0.65 is a Playwright fill() artifact — **not briefed**.

## Competitors
jwt.io, uuidgenerator.net, emn178 online-tools (SHA-256/HMAC, input encodings). FDP parity good; HMAC and input-encoding choice are the only gaps (suggestion only, not briefed).

## Status
JWT, UUID, Hash: **mature** (after B-0074 meta).
