# QA Report #80 — Category pages, /tools, /developers (plan rows 24–25) + blocked downloads
Run: 29 Oct 2026, 22:55–23:35 ET · 1280 / 390 · logged out.

## Row 24 — crawl / indexability (B-0035)
- 452 internal links: all 200, no trailing-slash or query variants.
- 863 sitemap URLs: all 200, self-canonical, none noindex.
- Trailing slash → 301 to non-slash; `?ref=` canonicalises; bare domain → 301 www.
- Bad URLs give real 404 + noindex (/tool/invoice, /category/zzz). /Tool/merge-pdf (capital T) → 404 (minor, not briefed).
- http→https not testable from the box proxy (returns 500 for every http URL — harness artifact).
- **B-0035 looks clean from the site side**; GSC "not indexed" count needs a fresh GSC read to confirm.
- Category pages CLS ≤ 0.015, no ad overlap, no horizontal overflow.
- **/tools desktop load CLS 0.28–0.37 in 3 of 5 loads** (tool-chip row, t≈430 ms; mobile 0.001). → **B-0072**.

## Row 25 — /developers (B-0020 false claims)
| Claim | Check | Result |
|---|---|---|
| llms.txt | api.freedailypro.com/llms.txt | 200 ✓ |
| OpenAPI / docs | /openapi.json (220 paths), /docs | 200 ✓ |
| Postman | documenter link | 200 ✓ |
| RapidAPI (6 listings + profile) | all links | 200, titles match ✓ |
| MCP Registry | com.freedailypro/tools v1.2.0 isLatest | listed ✓ |
| 7 use-case pages (former 404s) | all | 200 ✓ |
| "4 live, 3 in review" | cards | consistent ✓ |
| Glama shown "Live" | no outbound link on card | minor, not briefed |
| Counts (215+/211+/217, "All six products" vs 7, registry says 178) | — | **owner decision — not briefed** |
| "Try it" word-count call | — | not run (no-API-writes rule) |

**B-0020: verified fixed.** /developers: mature.

## Blocked downloads retried (23:34 ET)
- Barcode default EAN-13 PNG download worked; zxing decodes 5901234123457 ✓.
- UPC-A / ITF-14: format control isn't a native select; not completed this run — carry over.
- Universal converted download / Invoice desktop: not retried (carry over).
