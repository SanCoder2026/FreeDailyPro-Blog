# QA Report #81 — Find & Replace, Tip Calculator, Percentage Calculator (proposed group 1)
Run: 29 Oct 2026 23:40 – 30 Oct 00:10 ET · Playwright Chromium headless · 1280×900 and 390×900 · logged out · no payment, no sign-up, no API writes.
Plan check: test-plan.csv still has 25 rows (no new rows); TESTING-GUIDANCE "Last updated: 2026-10-29 9:38 PM ET".

## Find & Replace (/tool/find-replace — 112 views)
| Case | Expected | Actual | 1280 | 390 |
|---|---|---|---|---|
| "cat"→"dog", default | case-insensitive, 4 hits incl. "concatenate" | "Replaced 4 occurrences" | ✓ | ✓ |
| Case sensitive | 2 matches | 2 | ✓ | ✓ |
| Whole word | 3 (cat/Cat/CAT) | 3 | ✓ | ✓ |
| Regex `(\d{4})-(\d\d)-(\d\d)` | 2 matches | 2 | ✓ | ✓ |
| Regex `[` | error | "Invalid pattern — check your regex syntax" | ✓ | ✓ |
| No match / empty text | 0 found / button disabled | ✓ | ✓ | ✓ |
| .docx upload (fx/fr.docx) | cat→dog in body, bold run, table; Word file back | 5 replaced; bold and table kept; fr_edited.docx | ✓ | — (pool 0) |
| .csv upload | ann,dog | ✓ fr_edited.csv | ✓ | — (pool 0) |

**Bug: the .docx output is 23× bigger than the input** — 36,765 B in → 828,823 B out. Every part is stored without compression (styles.xml 349 KB and stylesWithEffects.xml 438 KB stored at compress_type 0 vs deflate in the input). → **B-0076**.
B-0055 evidence (00:00 ET): at 0 remaining, desktop Replace All shows the limit dialog; mobile at 0 remaining still replaced the text.

## Tip Calculator (/tool/tip-calculator — GSC "tip calculator" 0/5,660, pos 7.0)
All verified at both widths: 100 + 18% split 3 → $18 / $118 / $39.33–$39.34 (shares add up); tax 8 tip-before-tax $20 / $128, on-total $21.60 / $129.60; round-up → $40 each, total $120; 47.50 @15% /2 → $7.13 / $54.63 / $27.31–$27.32; JPY ¥100 / ¥1,100 (no decimals); 0 bill → $0.
- Invalid input (bill −50, 0 people) shows only "—" with no message → **B-0078**.
- Mobile load CLS 0.19–0.55 (3/3) → **B-0077**.
- Snippet: title/meta already state split + per person (157 chars). The 0-click query may be landing on a different URL (/es, /fr?). The raw analytics has no query→page mapping, so I'm not briefing a rewrite. Orchestrator: pull GSC page-filter for "tip calculator".
- Competitors: calculator.net (split between people), Omni.

## Percentage Calculator (GSC "percentage calculator online" 0/505, pos 10.4)
All 6 modes exact: 20% of 150 = 30; 12.5% of 80 = 10; 30 of 120 = 25%; 80→100 +25%; 100→80 −20%; 0→50 "Undefined…"; 200 +15% = 230; 115 after 15% off → 135.2941; diff 80/100 = 22.22%; "abc" → "Enter numbers"; ÷0 handled. Desktop CLS 0.02, mobile 0.08. **Mature.**
Competitors: calculator.net, calculatorsoup — similar mode set; FDP shows the formula, which is a plus.

## Carry-over (pool reset at about midnight ET)
- Universal Converter CSV→XLSX at 390: downloaded data-converted.xlsx; cells and numbers are correct (9.5, 14.25 numeric) ✓. The counter read 2 before and 0 after one download (B-0055 evidence).
- Barcode UPC-A / ITF-14: pool 0 again by 00:06 ET → still carried over. Invoice desktop: not retried.
