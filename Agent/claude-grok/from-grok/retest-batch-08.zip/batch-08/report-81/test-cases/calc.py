import asyncio,json,re
from playwright.async_api import async_playwright
U='https://www.freedailypro.com/tool/'
async def res(pg):
  t=await pg.inner_text('main'); return t
async def m():
  out={}
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for W in [1280,390]:
      c=await b.new_context(viewport={'width':W,'height':900}); pg=await c.new_page(); pg.set_default_timeout(6000)
      await pg.goto(U+'tip-calculator'); await pg.wait_for_timeout(3000)
      async def tip(bill,tax,pct,ppl,pre=False,rnd=False,cur=None):
        await pg.goto(U+'tip-calculator'); await pg.wait_for_timeout(2500)
        if cur: await pg.locator('select').first.select_option(cur)
        await pg.fill('#tip-bill',str(bill)); await pg.locator('input[placeholder="0"]').fill(str(tax))
        await pg.locator('input[placeholder="Custom tip percent"]').fill(str(pct)); await pg.locator('input[placeholder="Number of people"]').fill(str(ppl))
        if pre: await pg.click('#tip-pretax')
        if rnd: await pg.click('#tip-roundup')
        await pg.wait_for_timeout(500); t=await res(pg); i=t.find('\nTip\n'); return t[i:i+120].replace('\n',' ')
      cases=[(100,0,18,3),(100,8,20,1),(100,8,20,1,True),(100,0,18,3,False,True),(47.5,0,15,2),(0,0,18,1),(-50,0,18,1),(100,0,18,0),(1000,0,10,1,False,False,'JPY'),(100,0,150,1)]
      for cs in cases:
        json.dump(out,open('calc.json','w'),indent=1)
        try: out[f'tip{cs}-{W}']=await tip(*cs)
        except Exception as e: out[f'tip{cs}-{W}']='ERR '+str(e)[:80]
      await pg.screenshot(path=f'ss/tip-{W}.png',full_page=True)
      for tab,vals in [('pctof',['20','150']),('pctof',['12.5','80']),('iswhat',['30','120']),('change',['80','100']),('change',['100','80']),('change',['0','50']),('by',['200','15']),('rev',['115','15']),('diff',['80','100']),('pctof',['abc','10']),('iswhat',['5','0'])]:
        await pg.goto(U+'percentage-calculator'); await pg.wait_for_timeout(2500)
        try: await pg.click(f'[id$="-trigger-{tab}"]')
        except Exception as e: out[f'pct-{tab}{vals}-{W}']='ERR'+str(e)[:60]; continue; await pg.wait_for_timeout(400)
        ins=pg.locator('[role=tabpanel]:not([hidden]) input'); n=await ins.count(); lab=await pg.inner_text('[role=tabpanel]:not([hidden])')
        for i,v in enumerate(vals[:n]): await ins.nth(i).fill(v)
        await pg.wait_for_timeout(400)
        json.dump(out,open("calc.json","w"),indent=1); out[f"pct-{tab}{vals}-{W}"]=(n,(await pg.inner_text('[role=tabpanel]:not([hidden])')).replace('\n',' ')[:200])
      await pg.screenshot(path=f'ss/pct-{W}.png',full_page=True)
      await c.close()
  json.dump(out,open('calc.json','w'),indent=1)
asyncio.run(m())
