import asyncio,json,re
from playwright.async_api import async_playwright
U='https://www.freedailypro.com/tool/find-replace'
async def m():
  out={}
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for W in [1280,390]:
      c=await b.new_context(viewport={'width':W,'height':900},accept_downloads=True); pg=await c.new_page(); pg.set_default_timeout(6000)
      async def run(text,f,r,opts=()):
        await pg.goto(U); await pg.wait_for_timeout(2500)
        await pg.fill('textarea',text); await pg.fill('#fr-find',f); await pg.fill('#fr-replace',r)
        for o in opts: await pg.get_by_role('button',name=o,exact=True).click()
        await pg.get_by_role('button',name='Replace All').click(); await pg.wait_for_timeout(1200)
        t=await pg.inner_text('main'); i=t.find('Replace All'); tas=await pg.locator('textarea').evaluate_all('e=>e.map(x=>x.value)')
        return {'tas':tas,'after':t[i:i+400].replace('\n',' ')}
      C=[('The cat sat. Cat food is for the CAT. concatenate','cat','dog',()),
         ('The cat sat. Cat food is for the CAT. concatenate','cat','dog',('Case sensitive',)),
         ('The cat sat. Cat food is for the CAT. concatenate','cat','dog',('Whole word',)),
         ('The cat sat. Cat food is for the CAT.','cat','dog',('Preserve case',)),
         ('2026-10-29 and 2025-01-02',r'(\d{4})-(\d\d)-(\d\d)',r'$3/$2/$1',('Regex',)),
         ('a.b.c','.','-',()),
         ('abc','[','x',('Regex',)),
         ('abc','zzz','x',()),]
      for k,cs in enumerate(C):
        try: out[f'{k}{cs[3]}-{W}']=await run(*cs)
        except Exception as e: out[f'{k}-{W}']='ERR '+str(e)[:120]
        json.dump(out,open('fr.json','w'),indent=1)
      await pg.screenshot(path=f'ss/fr-{W}.png',full_page=True)
      for f in ['fx/fr.docx','fx/fr.csv']:
        try:
          await pg.goto(U); await pg.wait_for_timeout(2500)
          await pg.set_input_files('input[type=file]',f); await pg.wait_for_timeout(2500)
          await pg.fill('#fr-find','cat'); await pg.fill('#fr-replace','dog'); await pg.get_by_role('button',name='Replace All').click(); await pg.wait_for_timeout(2000)
          t=await pg.inner_text('main'); out[f'file{f}-{W}']=t[t.find('Replace All'):][:500].replace('\n',' ')
          btns=await pg.locator('main button').all_inner_texts(); out[f'btns{f}-{W}']=[x for x in btns if x.strip()][:30]
          dl=pg.locator('main button',has_text=re.compile('Download',re.I))
          if await dl.count():
            async with pg.expect_download(timeout=10000) as d: await dl.first.click()
            v=await d.value; o=f'out/{W}-{v.suggested_filename}'; await v.save_as(o); out[f'dl{f}-{W}']=o
        except Exception as e: out[f'file{f}-{W}-err']=str(e)[:150]
        await pg.screenshot(path=f'ss/fr-file-{f[3:]}-{W}.png',full_page=True)
        json.dump(out,open('fr.json','w'),indent=1)
      await c.close()
asyncio.run(m())
