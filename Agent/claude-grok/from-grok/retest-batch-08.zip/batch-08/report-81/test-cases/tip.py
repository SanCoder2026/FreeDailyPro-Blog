import asyncio,json
from playwright.async_api import async_playwright
U='https://www.freedailypro.com/tool/'
async def m():
  out={}
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for W in [1280,390]:
      c=await b.new_context(viewport={'width':W,'height':900}); pg=await c.new_page(); pg.set_default_timeout(6000)
      cases=[(100,0,18,3),(100,8,20,1),(100,8,20,1,True),(100,0,18,3,False,True),(47.5,0,15,2),(0,0,18,1),(-50,0,18,1),(100,0,18,0),(1000,0,10,1,False,False,'JPY'),(100,0,150,1)]
      await pg.goto(U+'tip-calculator'); await pg.wait_for_timeout(3000)
      for cs in cases:
        bill,tax,pct,ppl=cs[:4]; pre=len(cs)>4 and cs[4]; rnd=len(cs)>5 and cs[5]; cur=cs[6] if len(cs)>6 else None
        try:
          await pg.goto(U+'tip-calculator'); await pg.wait_for_timeout(2000)
          n=pg.locator('main input[type=number]')
          if cur: await pg.locator('main select').first.select_option(cur)
          for i,v in enumerate([bill,tax,pct,ppl]): await n.nth(i).fill(str(v))
          if pre: await pg.click('#tip-pretax')
          if rnd: await pg.click('#tip-roundup')
          await pg.wait_for_timeout(500); t=await pg.inner_text('main'); i=t.find('\nTip\n'); out[f'{cs}-{W}']=t[i:i+110].replace('\n',' ')
        except Exception as e: out[f'{cs}-{W}']='ERR '+str(e)[:100]
      await pg.screenshot(path=f'ss/tip-{W}.png',full_page=True)
      for vals in [['15','115'],['115','15']]:
        await pg.goto(U+'percentage-calculator'); await pg.wait_for_timeout(2000); await pg.click('[id$="-trigger-rev"]')
        P=pg.locator('[role=tabpanel]:not([hidden])'); ins=P.locator('input')
        for i,v in enumerate(vals): await ins.nth(i).fill(v)
        await pg.wait_for_timeout(300); out[f'rev{vals}-{W}']=[(await ins.nth(i).get_attribute('placeholder')) for i in range(2)]+[(await P.inner_text()).replace('\n',' ')[:160]]
        btn=P.get_by_text('increased by',exact=True)
        try: await btn.click(); await pg.wait_for_timeout(300); out[f'rev{vals}-inc-{W}']=(await P.inner_text()).replace('\n',' ')[:120]
        except Exception as e: out[f'rev-inc-{W}']=str(e)[:60]
      await c.close()
  json.dump(out,open('tip.json','w'),indent=1)
asyncio.run(m())
