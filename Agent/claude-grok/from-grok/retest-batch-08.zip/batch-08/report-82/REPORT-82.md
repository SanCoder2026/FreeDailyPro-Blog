# QA Report #82 — Book Maker URL, Book Writing Toolbox, Magazine Maker (proposed group 2)
Run: 29 Oct 23:45 – 30 Oct 00:10 ET · 1280 / 390 · logged out.

## /tool/book-maker (GA: 106 views, #16 page on the site)
`curl` → **HTTP 404, `<title>Page not found`, `noindex`**; the browser then lands on /tool/book-writing-toolbox through a client-side redirect. Not in the sitemap; the blog /blog/book-maker-launch links to the new URL already. Google will drop the old URL and its signals. → **B-0075**.

## Book Writing Toolbox (79 views)
- Loads at both widths; options (platform, Print+Ebook, 6×9, Literata), section manager and Pre-flight panel ("Unlimited — no download credit spent") render.
- Download → "Sign in to download your book… Google sign-in". **Stopped here (no sign-in, per rules).** Export not tested.
- Mobile toolbar: menu, cover-preview, preview and download are icon-only buttons with no aria-label/title → **B-0078**.
- Load CLS: desktop 0.00–0.20, mobile 0.06–0.29 (2/3 ≥ 0.28) → **B-0077**.
- Competitors: Reedsy Studio ("blank page to published book"), Atticus.

## Magazine Maker (68 views; GSC 13 clicks/1,015 impr, pos 53.6; "magazine maker" 0/285 pos 49.3)
- Trial uses: 2/day (premium). Built at 390 with 2 articles: QA_Weekly.pdf, 4 pages, Letter; cover, "In this issue" with correct page numbers 3 and 4, articles on 3–4, watermark disclosed before download ✓. Counter 2 → 1.
- Mobile load CLS 0.26–0.28 (3/3; upload field at about 300 ms); desktop 0.02–0.04 → **B-0077**.
- No ad overlap. **Mature** after B-0077.
- Competitors: Canva magazine templates, Flipsnack. Ranking is the issue (pos ~50), not CTR — content/backlinks, not a meta brief.
