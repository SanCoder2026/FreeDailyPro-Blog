# QA Report #83 — Citation Generator, Image to PDF, Screenshot Tool (group 3)
Run: 30 Oct 2026 00:12–00:35 ET · Playwright Chromium headless · 1280×900 / 390×900 · logged out · no payment, no sign-up, no API writes.
Plan re-read: test-plan.csv still 25 rows; guidance "Last updated: 2026-10-29 9:38 PM ET". **Trial uses were 0 on both widths for the whole run** (re-polled every 2 min until 00:31 ET), so trial-gated outputs were blocked.

## Citation Generator (GSC "citation generator" 0/2,448, pos 8.6)
| Case | Expected | Actual |
|---|---|---|
| APA website | Smith, J. (2025). *Title*. Site. URL | ✓ title italic |
| MLA website | Smith, Jane. "Title." *Site*, 2025, url. Accessed 30 Oct. 2026. | ✓ |
| Harvard website | Smith, J. (2025) *Title*. Available at: URL (Accessed: 30 October 2026). | ✓ |
| **Chicago website** | …"Title." National Geographic. **2025** (or the date given). Accessed… | **year 2025 dropped** → B-0080 |
| APA book | Smith, J. (2025). *Title*. Academic Press. | ✓ |
| No author (APA) | Title moves to the author position | ✓ |
| 2 authors (APA) | Smith, J., & Doe, J. | ✓ |
| Reference list | adds, alphabetised, Copy Full List | ✓ |
Source types: Website / Book / Journal Article. Both widths are the same. Mobile load CLS 0.24 (one load; evidence for B-0077).
Competitors: Scribbr, MyBib, ZoteroBib, Citation Machine all have URL/DOI/ISBN auto-fill and mention "bibliography" + style names in the title. FDP's meta is 77 chars and doesn't mention reference list or auto-dated access → **B-0079**. Auto-fill = suggestion only (not briefed).

## Image to PDF (71 views)
- Upload of 2 images (EXIF-rotated JPG + PNG): list, reorder, rotate, page size/orientation/margin/fit/pair options render ✓. The trial-use watermark is disclosed before converting ✓.
- Convert/download: **blocked (0 trial uses)** → carried over (EXIF upright check pending).
- Load CLS ≤ 0.055, no ad overlap.

## Screenshot Tool (78 views; GSC 5/223, pos 55.3)
- Delay options and Take Screenshot render. Screen capture can't be granted in headless Chromium; after the click no message or error appeared. **Not testable here** — needs a headed run. Not briefed.
- Load CLS ≤ 0.09.
