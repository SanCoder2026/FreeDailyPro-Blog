import asyncio,re,json
from playwright.async_api import async_playwright
out={}
async def pick(pg,cur,val):
  await pg.locator('main button',has_text=cur).first.click(); await pg.wait_for_timeout(400)
  await pg.locator('[role=option],[role=menuitem],[role=menuitemradio]',has_text=val).first.click(); await pg.wait_for_timeout(500)
async def m():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for W in [1280,390]:
      pg=await b.new_page(viewport={'width':W,'height':900}); pg.set_default_timeout(5000)
      await pg.goto('https://www.freedailypro.com/tool/citation-generator'); await pg.wait_for_timeout(2500)
      cur='APA'
      for sty in ['MLA','Chicago','Harvard','APA']:
        try:
          await pick(pg,re.compile(cur),sty); cur=sty
          t=await pg.inner_text('main'); i=t.find(' citation\n'); out[f'web-{sty}-{W}']=[t[i-10:i+230].replace('\n',' '),await pg.evaluate("[...document.querySelectorAll('main i,main em')].map(x=>x.innerText)")]
        except Exception as e: out[f'web-{sty}-{W}']='ERR '+str(e)[:90]
      try:
        await pg.locator('main button',has_text='Website').first.click(); await pg.wait_for_timeout(400)
        out[f'types-{W}']=await pg.locator('[role=option],[role=menuitem]').all_inner_texts()
        await pg.locator('[role=option],[role=menuitem]',has_text='Book').first.click(); await pg.wait_for_timeout(600)
        out[f'book-fields-{W}']=await pg.evaluate("[...document.querySelectorAll('main label')].map(l=>l.innerText).filter(Boolean)")
        t=await pg.inner_text('main'); i=t.find(' citation\n'); out[f'book-APA-{W}']=t[i-10:i+230].replace('\n',' ')
        # empty author test
        await pg.goto('https://www.freedailypro.com/tool/citation-generator'); await pg.wait_for_timeout(2000)
        await pg.fill('#cg-last-0',''); await pg.fill('#cg-first-0',''); await pg.wait_for_timeout(400)
        t=await pg.inner_text('main'); i=t.find(' citation\n'); out[f'noauthor-APA-{W}']=t[i-10:i+200].replace('\n',' ')
        await pg.locator('main button',has_text='Add author').click(); await pg.fill('#cg-last-0','Smith'); await pg.fill('#cg-first-0','Jane'); await pg.fill('#cg-last-1','Doe'); await pg.fill('#cg-first-1','John'); await pg.wait_for_timeout(400)
        t=await pg.inner_text('main'); i=t.find(' citation\n'); out[f'2auth-APA-{W}']=t[i-10:i+200].replace('\n',' ')
        await pg.get_by_role('button',name='Add to Reference List').click(); await pg.wait_for_timeout(800)
        d=pg.locator('[role=dialog]'); out[f'reflist-{W}']=((await d.first.inner_text())[:150] if await d.count() else (await pg.inner_text('main'))[(await pg.inner_text('main')).find('Reference'):][:300])
      except Exception as e: out[f'cite-more-{W}']='ERR '+str(e)[:120]
      await pg.screenshot(path=f'ss/cite-{W}.png',full_page=True)
  json.dump(out,open('cite.json','w'),indent=1); [print(k,'=>',v) for k,v in out.items()]
asyncio.run(m())
