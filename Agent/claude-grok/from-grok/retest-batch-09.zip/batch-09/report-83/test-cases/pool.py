import asyncio,json,re
from playwright.async_api import async_playwright
U='https://www.freedailypro.com/tool/'
out=json.load(open('pool.json')) if __import__('os').path.exists('pool.json') else {}
async def m():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for W in [1280,390]:
      c=await b.new_context(viewport={'width':W,'height':900},accept_downloads=True); pg=await c.new_page(); pg.set_default_timeout(6000)
      await pg.goto(U+'case-converter'); await pg.wait_for_timeout(2000)
      rem=[l for l in (await pg.inner_text('body')).split('\n') if 'remaining' in l][:1]; print(W,rem,flush=True)
      if rem and ' 0 remaining' in rem[0]: await c.close(); continue
      src="hello WORLD. this is a test of the iPhone and NASA's API. the lord of the rings"
      for mode in ['UPPERCASE','Title Case','Sentence case','camelCase','snake_case','kebab-case','CONSTANT_CASE']:
        await pg.fill('textarea',src); await pg.get_by_role('button',name=mode,exact=True).click(); await pg.wait_for_timeout(400)
        out[f'case-{mode}-{W}']=await pg.locator('main textarea').first.input_value()
      await pg.goto(U+'password-generator'); await pg.wait_for_timeout(2000)
      await pg.locator('main select').first.select_option('10'); await pg.get_by_role('button',name='Generate Password').click(); await pg.wait_for_timeout(1000)
      out[f'pw-{W}']=(await pg.inner_text('main'))[600:1800]
      await pg.screenshot(path=f'ss/pw-{W}.png',full_page=True)
      await pg.goto(U+'image-to-pdf'); await pg.wait_for_timeout(2000)
      await pg.locator('input[type=file]').first.set_input_files(['fx/rot6.jpg','fx/green.png']); await pg.wait_for_timeout(2500)
      try:
        async with pg.expect_download(timeout=30000) as d:
          await pg.locator('main button',has_text='Convert to PDF').click(); await pg.wait_for_timeout(3000)
          b2=pg.locator('main button').filter(has_text=re.compile('^Download',re.I))
          if await b2.count(): await b2.first.click()
        v=await d.value; o=f'out/i2p-{W}.pdf'; await v.save_as(o); out[f'i2p-{W}']=o
      except Exception as e: out[f'i2p-{W}']='ERR'+str(e)[:60]
      json.dump(out,open('pool.json','w'),indent=1); await c.close()
  [print(k,'=>',str(v)[:900]) for k,v in out.items()]
asyncio.run(m())
