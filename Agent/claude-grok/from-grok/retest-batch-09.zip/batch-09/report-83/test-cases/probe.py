import asyncio,json
from playwright.async_api import async_playwright
from adcls import *
T=['citation-generator','image-to-pdf','screenshot-tool','password-generator','random-number-generator','case-converter','/workflow-products','/multitool-apps']
async def m():
  out={}
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for t in T:
      for W in [1280,390]:
        c=await b.new_context(viewport={'width':W,'height':900}); await c.add_init_script(INIT); pg=await c.new_page()
        r=await pg.goto(('https://www.freedailypro.com'+t if t[0]=='/' else 'https://www.freedailypro.com/tool/'+t)); await pg.wait_for_timeout(4500)
        a=await adcheck(pg)
        d=await pg.evaluate("""()=>({url:location.href,title:document.title,meta:(document.querySelector('meta[name=description]')||{}).content,
         ctrls:[...document.querySelectorAll('main input,main select,main textarea,main button')].filter(e=>e.offsetParent).map(e=>[e.tagName,e.type||'',e.name||e.id||'',(e.placeholder||e.innerText||e.getAttribute('aria-label')||'').slice(0,40),e.tagName=='SELECT'?[...e.options].map(o=>o.text).join('/').slice(0,120):(e.value||'').slice(0,30)]),
         text:document.querySelector('main')?.innerText.slice(0,2500),ow:document.documentElement.scrollWidth})""")
        d['status']=r.status;d['cls']=a['cls'];d['shifts']=[(s['v'],s['src'][:60]) for s in a['shifts'] if s['v']>0.02];d['ad']={k:v for k,v in a.items() if k not in('cls','shifts')}
        out[f'{t}-{W}']=d; await pg.screenshot(path=f'ss/{t.strip("/")}-{W}-load.png',full_page=True); await c.close()
  json.dump(out,open('probe.json','w'),indent=1)
asyncio.run(m())
