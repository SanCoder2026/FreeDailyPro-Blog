import asyncio,json,re,sys
from playwright.async_api import async_playwright
U='https://www.freedailypro.com/tool/'
out={}
def save(): json.dump(out,open('t.json','w'),indent=1)
async def body(pg): return await pg.inner_text('main')
async def m():
  async with async_playwright() as p:
    b=await p.chromium.launch(args=['--use-fake-ui-for-media-stream','--auto-select-desktop-capture-source=Entire screen','--auto-accept-this-tab-capture'])
    for W in [1280,390]:
      c=await b.new_context(viewport={'width':W,'height':900},accept_downloads=True); pg=await c.new_page(); pg.set_default_timeout(7000)
      # password
      try:
        await pg.goto(U+'password-generator'); await pg.wait_for_timeout(2500)
        await pg.locator('main select').first.select_option('10'); await pg.get_by_role('button',name='Generate Password').click(); await pg.wait_for_timeout(1000)
        t=await body(pg); pw=re.findall(r'^\S{16}$',t,re.M); out[f'pw-{W}']={'n':len(pw),'pw':pw[:10],'snip':t[t.find('Generate Password'):][:500]}
        await pg.screenshot(path=f'ss/pw-{W}.png',full_page=True)
        await pg.get_by_role('button',name='Passphrase (words)').click(); await pg.wait_for_timeout(500); await pg.get_by_role('button',name=re.compile('Generate')).first.click(); await pg.wait_for_timeout(800)
        t=await body(pg); out[f'pp-{W}']=t[t.find('Passphrase'):][:700]
      except Exception as e: out[f'pw-{W}-err']=str(e)[:150]
      save()
      # random
      for mn,mx,n,u,s in [('1','100','10',1,1),('1','5','10',1,0),('-10','10','5',0,0),('10','1','1',0,0),('1','1000000','1000',1,0),('a','5','1',0,0),('0.5','2','3',0,0)]:
        try:
          await pg.goto(U+'random-number-generator'); await pg.wait_for_timeout(2000)
          await pg.fill('#rng-min',mn); await pg.fill('#rng-max',mx); await pg.fill('#rng-count',n)
          if u: await pg.click('#rng-unique')
          if s: await pg.click('#rng-sort')
          await pg.get_by_role('button',name='Generate',exact=True).click(); await pg.wait_for_timeout(1000)
          t=await body(pg); i=t.find('Generate\n'); out[f'rng{mn},{mx},{n},{u}{s}-{W}']=t[i+9:i+9+3000 if n=='1000' else i+400]
        except Exception as e: out[f'rng{mn},{mx},{n}-{W}']='ERR '+str(e)[:100]
      save()
      # case
      try:
        src="hello WORLD. this is a test of the iPhone and NASA's API. the lord of the rings"
        for mode in ['UPPERCASE','lowercase','Title Case','Sentence case','camelCase','PascalCase','snake_case','kebab-case','CONSTANT_CASE','aLtErNaTiNg']:
          await pg.goto(U+'case-converter'); await pg.wait_for_timeout(1800); await pg.fill('textarea',src)
          await pg.get_by_role('button',name=mode,exact=True).click(); await pg.wait_for_timeout(500)
          out[f'case-{mode}-{W}']=await pg.locator('main textarea').evaluate_all('e=>e.map(x=>x.value)')
      except Exception as e: out[f'case-{W}-err']=str(e)[:150]
      save()
      # citation
      try:
        await pg.goto(U+'citation-generator'); await pg.wait_for_timeout(2500)
        for sty in ['APA','MLA','Chicago','Harvard']:
          await pg.get_by_role('button',name=re.compile('APA|MLA|Chicago|Harvard')).first.click(); await pg.wait_for_timeout(300)
          await pg.get_by_role('option',name=re.compile(sty)).first.click(); await pg.wait_for_timeout(500)
          t=await body(pg); i=t.find(' citation\n'); out[f'cite-web-{sty}-{W}']=[t[i-12:i+260], await pg.evaluate("(()=>{const e=[...document.querySelectorAll('main i,main em')].map(x=>x.innerText);return e})()")]
        await pg.get_by_role('button',name='Website').click(); await pg.wait_for_timeout(300); out[f'cite-types-{W}']=await pg.get_by_role('option').all_inner_texts()
        await pg.keyboard.press('Escape')
      except Exception as e: out[f'cite-{W}-err']=str(e)[:150]
      save()
      # image to pdf
      try:
        await pg.goto(U+'image-to-pdf'); await pg.wait_for_timeout(2500)
        await pg.locator('input[type=file]').first.set_input_files(['fx/rot6.jpg','fx/green.png']); await pg.wait_for_timeout(3000)
        t=await body(pg); out[f'i2p-ui-{W}']=t[t.find('Drop images'):][:900]
        btn=pg.locator('main button').filter(has_text=re.compile('Convert|Create PDF|Download',re.I))
        out[f'i2p-btns-{W}']=await btn.all_inner_texts()
        async with pg.expect_download(timeout=30000) as d:
          await btn.first.click(); await pg.wait_for_timeout(3000)
          b2=pg.locator('main button').filter(has_text=re.compile('^Download',re.I))
          if await b2.count(): await b2.first.click()
        v=await d.value; o=f'out/i2p-{W}-{v.suggested_filename}'; await v.save_as(o); out[f'i2p-dl-{W}']=o
      except Exception as e: out[f'i2p-{W}-err']=str(e)[:150]
      out[f'i2p-rem-{W}']=[l for l in (await pg.inner_text('body')).split('\n') if 'remaining' in l][:2]
      await pg.screenshot(path=f'ss/i2p-{W}.png',full_page=True); save()
      # screenshot
      try:
        await pg.goto(U+'screenshot-tool'); await pg.wait_for_timeout(2500)
        await pg.get_by_role('button',name='Take Screenshot').click(); await pg.wait_for_timeout(4000)
        t=await body(pg); out[f'shot-{W}']=t[t.find('Take Screenshot'):][:600]
        await pg.screenshot(path=f'ss/shot-{W}.png',full_page=True)
      except Exception as e: out[f'shot-{W}-err']=str(e)[:150]
      save(); await c.close()
asyncio.run(m())
