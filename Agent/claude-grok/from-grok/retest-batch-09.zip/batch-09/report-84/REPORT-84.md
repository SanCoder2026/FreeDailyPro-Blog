# QA Report #84 — Password Generator, Random Number Generator, Case Converter (group 4)
Run: 30 Oct 00:12–00:35 ET · 1280 / 390 · logged out. Trial uses 0 the whole run.

## Random Number Generator (66 views) — works without trial uses
| Case | Expected | Actual |
|---|---|---|
| 1–100 ×10 unique sorted | 10 distinct, ascending | ✓ both widths |
| −10–10 ×5 | negatives allowed | ✓ |
| min 10 > max 1 | handled | swaps + note "range 1 to 10 was used" ✓ |
| 1–5 ×10 unique | refuse | Generate disabled + clear reason ✓ |
| 1–1,000,000 ×1000 unique | 1,000 | "1,000 numbers… Showing the first 500 of 1,000. Copy or download to get them all." ✓ (500 shown, all distinct) |
| min "a" / min 0.5 | message | **Generate disabled, no reason shown** → B-0080 |
Download .txt blocked by 0 trial uses.

## Password Generator (63 views, 11 s avg)
- Options render: Password/Passphrase, length 16, 4 sets, exclude look-alikes, editable symbol set, "At least one character type must stay on", How many 1–10.
- Generate: **blocked by the limit dialog (0 trial uses)** → output checks (length, charset, uniqueness) carried over. Mobile load CLS 0.23 (one load; B-0077 evidence).
- Competitors: LastPass, Bitwarden, 1Password generators are unlimited, which matters for a tool people use in 11 s. Owner pricing decision, not briefed.

## Case Converter (59 views)
- 10 modes render. Every click returned the limit dialog "You've used today's 10 trial uses" (00:15 ET) → outputs carried over.
