# QA Report #85 — /workflow-products, /multitool-apps (group 5) + carry-overs
Run: 30 Oct 00:15–00:30 ET · 1280 / 390.

## /workflow-products (70 views)
- 200; 4 products with prices (Event Suite $29.99/$49.99, Book Writing Toolbox pay-per-download, Seller Studio $29.99, Legal Production Desk $29.99, 7-day trials). Meta 157 chars.
- All internal links 200; external: LinkedIn 999 / Product Hunt 403 are bot-blocking, not site issues.
- CLS ≤ 0.001, no overlap or overflow. **Mature.**

## /multitool-apps (GA: 55 views)
- **HTTP 404 "Page Not Found"** at both widths. The live equivalent is /premium-apps ("Premium Applications", 104 applications, 200, CLS ≤ 0.03). Same pattern as /tool/book-maker → **evidence added to B-0075** (no new brief).

## Carry-overs
Barcode UPC-A/ITF-14 and Invoice desktop: not run, 0 trial uses all session. Also carried: Image to PDF output, Password, Case Converter outputs.
**Testing note for Orchestrator:** the box gets 10 trial uses per day, which ran out at about 00:06 ET right after the midnight reset. Output tests on trial-gated tools need either the next reset or an owner-approved Day Pass.
