import asyncio,json,sys
sys.path.insert(0,'/workspace/rt2/b9');from playwright.async_api import async_playwright
U=['mortgage-calculator','percentage-calculator','loan-calculator']
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch();out={}
    for t in U:
      for w in (1280,390):
        pg=await b.new_page(viewport={'width':w,'height':900});r=await pg.goto(f'https://freedailypro.com/tool/{t}',wait_until='networkidle',timeout=60000);await pg.wait_for_timeout(2500)
        await pg.screenshot(path=f'{t}-{w}.png',full_page=True)
        if w==1280:
          out[t]={'status':r.status,'title':await pg.title(),'text':(await pg.inner_text('main'))[:3500],
           'controls':await pg.eval_on_selector_all('main input,main select,main button,[role=switch],[role=combobox],[role=tab]',"e=>e.map(x=>(x.tagName+':'+(x.getAttribute('aria-label')||x.name||x.placeholder||x.innerText||'')).slice(0,60))")}
    json.dump(out,open('features2.json','w'),indent=1)
asyncio.run(main())
