# Camera Capture pre-check (plan row 13, report_batch 5) — not a numbered report yet
Oct 29 ~9:37 PM ET, Chromium fake camera (--use-fake-device-for-media-stream), desktop 1280 + mobile 390.
Start Camera → live view with Capture / Front-rear / Save as JPG / Cancel → Capture → Download Full Photo / Crop Selection / Retake → camera-YYYYMMDD-HHMMSS.png (221,614 B) on both. PASS, same as report #49.
Ad chip "Edit Photos" inline in subtitle (orchestrator B-0041). Real iOS Safari / Android permission flow still untested. Full retest goes in the batch-5 report.
