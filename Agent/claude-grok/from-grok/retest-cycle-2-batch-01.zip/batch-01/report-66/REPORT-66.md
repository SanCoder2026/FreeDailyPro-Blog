# Testing Bot report #66 — Retest cycle 2, batch 1 (plan report_batch 1)
Tools (≤3): **Homepage + search box**, **Roman Numeral Converter**, **Audio Comparer**
Tested: Thu Oct 29 2026, 9:33–9:45 PM ET. Logged-out, no plan, fresh browser context per case. Playwright Chromium headless (desktop 1280×900; mobile 390×844 is_mobile+touch). US egress IP, locale en-US. iOS Safari / Android Chrome real devices **not** covered in this run (Chromium mobile emulation only).
Guidance followed: `testing-guidance/TESTING-GUIDANCE.md` — *Last updated: 2026-10-29 9:38 PM ET (Growth Orchestrator)*; test-plan.csv rows 1–3.
Data: GA/GSC numbers cite `/workspace/freedailypro-growth-orchestrator/analytics/2026-10-29-raw.md` (GA 28d Oct 1–28; GSC 3 mo Jul 28–Oct 27). The since-Jul-10 raw file did not exist on the box at test time; Jul-10 figures appear only in the guidance pack (orchestrator summary).

## Briefs raised in this report
| Brief | P | Title |
|---|---|---|
| B-0050 | P1 | Audio Comparer says "0% Different audio" for the same recording when offset 0.5 s or re-encoded to MP3; sample-rate label wrong |
| B-0051 | P1 | Trial use is counted when a file is *selected*, not when a result/output is produced (Audio Comparer) |
| B-0052 | P1 | /es/ tool pages ship homepage hreflang set + html lang="en"; client render doubles hreflang and JSON-LD on every tool page |
| B-0053 | P3 | Addendum to orchestrator B-0041 (search): desktop box below the fold, no accessible label, no "no results" state |
| (orch B-0041) | — | Ad chips inside copy/labels, Enter affordance, GA search event: already open in orchestrator B-0041 (written 9:46 PM ET) — confirmed live, **not re-briefed** |

## Prior fixes re-verified (own pass)
| Item | Source | Result | Evidence |
|---|---|---|---|
| Homepage H1 "Task.One" missing space | B-0022 / homepage-figures brief | **verified-fixed** | H1 text = "Every Professional Task. One Browser Platform" (meta.json desk/ + mob/) |
| Roman: 30 Feb accepted as date | report #20 (batch-20) | **verified-fixed** | Day 30 Month 2 → "That date does not exist in the calendar." also 31 Apr (fn.json roman_date, fn-roman-date-*.png) |
| Roman: US date order option | report #20 improvement | **verified-shipped** | radios Day.Month.Year / Month.Day.Year (US) |
| Roman core: 3999→MMMCMXCIX, 4000/0 range msg, IIII clock note, IC→"did you mean XCIX", ABC letter error, lowercase mmxxvi→2026 | report #20 | **still PASS** desktop+mobile | fn.json |
| Audio identical / different | report #54 | **still PASS** (100.0% / 0.0% with per-second map) | fn-audio-same/diff-*.png |
| Mobile overflow 390 | — | PASS (docW 390 on all 4 pages); /es roman desktop docW 1283 vs 1280 (3px) noted in B-0052 | meta.json |
| Privacy pop-up (B-0002 claimed "EEA/UK/CH only") | B-0002 | **partially verified**: not shown to US visitor. Non-US (EEA/UK) display not testable from US IP — left *claimed, unverified* | screenshots |

## Not re-reported (already open / owner decisions)
- "Free" in title/meta (audio-comparer, roman, merge, camera): owner keeps "free" in SEO tags (B-0019 note) — not an issue. Visible-copy "free": B-0019 open.
- Roman CTR / title / FAQ / /es Spanish content / vinculum >3999 content: **B-0036 open, not claimed done**. Competitor note for when it is: all 5 checked (RapidTables, CalculatorSoup, romannumerals.org, Omni, calculator.net) mention vinculum/overline for >3999; FreeDailyPro caps at 3999.
- Homepage counts: title/meta/footer "300+", hero cards "250+" tools and "100+" apps — count claim is an **open owner decision** (B-0019 note). Listed for the owner, not briefed.
- Checkout labels / gate: B-0027 open (see report #67).

## Test cases (all reproducible; scripts in test-cases/, fixtures in test-cases/fixtures/)
| ID | Tool | Viewport | Steps / input | Expected | Actual | Status | Shot |
|---|---|---|---|---|---|---|---|
| R66-HOME-01 | Home | 1280/390 | load / | single H1 with space | "Every Professional Task. One Browser Platform" | PASS | desk_.png, mob_.png |
| R66-HOME-02 | Home | 1280 | locate search input | visible in first screen | input "What's on your mind?" at y=1100 (viewport 900) — below fold; mobile y=106 OK | FAIL → B-0053 | search-merge-desk.png |
| R66-HOME-03 | Home | both | type "merge", press Enter | results panel | side panel: AI chips + Merge PDF/PPT/Video/Audio | PASS | search-enter-*.png |
| R66-HOME-04 | Home | both | look for submit/arrow button, "Press Enter" hint, aria-label | present | none of the three | FAIL — Enter hint/button already in orch B-0041; label → B-0053 | search-merge-*.png |
| R66-HOME-05 | Home | both | "zzqxv nothing" + Enter | "no tools match" + nearest suggestions | unrelated tool list (cURL Converter, Event Landing Page…) with no no-match message | FAIL → B-0053 | search-empty-*.png |
| R66-HOME-06 | Home | both | type 2 chars "me" | suggestions only from 3 chars + ~0.5 s | 11 visible option nodes after 2 chars | UNCONFIRMED (selector may count static list nodes; orchestrator saw no suggestions for "pdf") — recheck manually | search-2char-*.png |
| R66-HOME-07 | Home | both | hero copy | no ad text inside product copy | ad link chips "Try Cloud Tools", "Automate Work" rendered inside hero sentence | FAIL — already open in orch B-0041 (confirmed) | mob_.png |
| R66-ROM-01..09 | Roman | both | 3999, 4000, 0, 1990, MCMXC, IIII, IC, ABC, mmxxvi | see report #20 | all correct | PASS | fn-roman-*.png |
| R66-ROM-10 | Roman | both | Date 30/2/2026, 31/4/2026 | invalid-date message | "That date does not exist in the calendar." | PASS (fix verified) | fn-roman-date-*.png |
| R66-ROM-11 | Roman /es | raw HTML (curl) | `curl -s https://www.freedailypro.com/es/tool/roman-numeral-converter \| grep hreflang` | hreflang set of this tool, html lang="es" | hreflang en/es/fr… point to **homepage** (/ , /es, /fr…); `<html lang="en">` | FAIL → B-0052 | — |
| R66-ROM-12 | Roman (all tool pages) | rendered DOM | count hreflang + ld+json after hydration | 11 hreflang, 1 set of JSON-LD | 22 hreflang (set duplicated), SoftwareApplication/VideoObject/FAQPage/BreadcrumbList each ×2 (raw HTML has 2 ld blocks) | FAIL → B-0052 | meta.json |
| R66-ROM-13 | Roman | 1280 | inputs | font ≥16px (iOS zoom) | 8 inputs <16px desktop, 2 on mobile | P3 note (B-0016 class, open) | meta.json |
| R66-AUD-01 | Audio | both | a440.wav vs a440b.wav (identical 3 s 440 Hz sine, 44.1 kHz) | ~100% | 100.0% Identical | PASS | fn-audio-same-*.png |
| R66-AUD-02 | Audio | both | a440.wav vs a880.wav | low % | 0.0% Different, map 0:00–0:03 | PASS | fn-audio-diff-*.png |
| R66-AUD-03 | Audio | 1280 | a440.wav vs a440-shift.wav (same audio, 0.5 s leading silence) | high match after alignment | **0.0% "Different audio", differs 0:00–0:03** | FAIL → B-0050 | fn-audio-a440-shift.wav.png |
| R66-AUD-04 | Audio | 1280 | a440.wav vs a440.mp3 (same audio, ffmpeg 128 kbps MP3) | high match | **0.0% "Different audio"** | FAIL → B-0050 | fn-audio-a440.mp3.png |
| R66-AUD-05 | Audio | both | file info line for a440.wav (44,100 Hz) | "44.1 kHz" | "48 kHz" (decode-context rate shown, not file rate) | FAIL → B-0050 | fn-audio-same-*.png |
| R66-AUD-06 | Audio | 1280 | fresh context; read "N remaining" at load, after file 1, after file 2, after Compare | decrement once on result | 10 → **9 after selecting file 1** → 9 → 9 (cnt.py). Separate run of full flow showed 8 remaining (fn.py) — count is inconsistent | FAIL → B-0051 | cnt.py output in this report |
| R66-AUD-07 | Audio | 390 | page load | no ad over inputs | ad chip "Get Converters" attached to "Audio File 1" label; floating ad chip beside result on desktop | FAIL — already open in orch B-0041 (confirmed) | mob_tool_audio-comparer.png, fn-audio-a440-shift.wav.png |

Run: `cd test-cases && python3 meta.py && python3 fn.py && python3 cnt.py && python3 search.py` (Playwright; fixtures relative path `fx/` → use `fixtures/`).

## Improvements (judged vs data + competitors)
- **Audio Comparer** (best clicker: 121 GSC clicks / 2,390 impr, pos 11.3; GA 150 views / 113 users / 17 s avg engagement — raw.md): competitors WaveDiff, MKDiff, Tembrica, FrequencyDetector all offer offset alignment; MKDiff "Try sample audio"; WaveDiff A/B toggle + spectrogram + share link; Tembrica loudness/codec table + ABX. 17 s engagement means people leave quickly — after B-0050 the cheapest win is a sample pair + A/B play buttons + "why the score" explainer. (In B-0050 as suggested direction.)
- **Roman**: tool is mature functionally; remaining gaps are content/SEO (B-0036, open). Mark **mature** once B-0036 ships.
- **Homepage**: 438 views / 33 key events (GA 28d) — the search box is the main router; see B-0053.
