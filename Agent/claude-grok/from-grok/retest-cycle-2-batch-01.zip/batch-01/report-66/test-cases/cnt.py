import asyncio,re
from playwright.async_api import async_playwright
B="https://www.freedailypro.com"
async def rem(pg): return re.search(r'(\d+) remaining',await pg.inner_text('main')).group(1)
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    c=await b.new_context(accept_downloads=True);pg=await c.new_page()
    await pg.goto(B+"/tool/audio-comparer",wait_until='networkidle');await pg.wait_for_timeout(1500)
    s=[await rem(pg)];f=pg.locator('input[type=file]')
    await f.nth(0).set_input_files('fx/a440.wav');await pg.wait_for_timeout(1500);s.append(await rem(pg))
    await pg.locator('input[type=file]').last.set_input_files('fx/a880.wav');await pg.wait_for_timeout(1500);s.append(await rem(pg))
    await pg.get_by_role('button',name='Compare Audio').click();await pg.wait_for_timeout(6000);s.append(await rem(pg))
    print('audio start/after f1/after f2/after compare',s)
    c2=await b.new_context(accept_downloads=True);pg=await c2.new_page()
    await pg.goto(B+"/tool/merge-pdf",wait_until='networkidle');await pg.wait_for_timeout(1500);s=[await rem(pg)]
    await pg.locator('input[type=file]').first.set_input_files(['fx/one.pdf','fx/two.pdf']);await pg.wait_for_timeout(1500)
    await pg.get_by_role('button',name='Merge 2 PDFs').click();await pg.wait_for_timeout(3000);s.append(await rem(pg))
    async with pg.expect_download() as d: await pg.get_by_role('button',name='Download Merged PDF').click()
    await pg.wait_for_timeout(1500);s.append(await rem(pg))
    async with pg.expect_download() as d: await pg.get_by_role('button',name='Download Merged PDF').click()
    await pg.wait_for_timeout(1500);s.append(await rem(pg))
    print('merge start/after merge/after dl1/after dl2',s)
    for a,b2 in [('fx/a440.wav','fx/a440-shift.wav'),('fx/a440.wav','fx/a440.mp3')]:
      c3=await b.new_context();pg=await c3.new_page()
      await pg.goto(B+"/tool/audio-comparer",wait_until='networkidle');await pg.wait_for_timeout(1500)
      f=pg.locator('input[type=file]');await f.nth(0).set_input_files(a);await f.nth(1).set_input_files(b2);await pg.wait_for_timeout(1500)
      await pg.get_by_role('button',name='Compare Audio').click();await pg.wait_for_timeout(7000)
      t=await pg.inner_text('main');print(b2,'::',t.split('Compare another pair')[-1].split('About')[0].strip()[:300].replace(chr(10),' | '))
      await pg.screenshot(path='ss/fn-audio-'+b2.split('/')[-1]+'.png',full_page=True)
    await b.close()
asyncio.run(main())
