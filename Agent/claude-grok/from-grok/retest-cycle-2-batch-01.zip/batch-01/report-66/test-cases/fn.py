import json,asyncio,sys,os
from playwright.async_api import async_playwright
B="https://www.freedailypro.com"; R={}
async def ctx(b,vw):
  c=await b.new_context(viewport={'width':vw,'height':900 if vw>400 else 844},is_mobile=vw<400,has_touch=vw<400,accept_downloads=True)
  return c,await c.new_page()
async def roman(pg,tag):
  await pg.goto(B+"/tool/roman-numeral-converter",wait_until='networkidle');await pg.wait_for_timeout(2000)
  ins=await pg.evaluate("[...document.querySelectorAll('main input, main select')].map((e,i)=>i+':'+e.tagName+':'+e.type+':'+(e.placeholder||e.getAttribute('aria-label')||e.name||'')+':'+e.value)")
  out={'inputs':ins}
  i=pg.locator('main input')
  async def txt(): return await pg.evaluate("document.querySelector('main').innerText.split('About')[0].slice(-700)")
  for v in ['3999','4000','0','1990']:
    await i.nth(0).fill(v);await pg.wait_for_timeout(400);out['n'+v]=await txt()
  for v in ['MCMXC','IIII','IC','ABC','mmxxvi']:
    await i.nth(1).fill(v);await pg.wait_for_timeout(400);out['r'+v]=await txt()
  await pg.screenshot(path=f'ss/fn-roman-{tag}.png',full_page=True)
  return out
async def roman_date(pg,tag):
  await pg.goto(B+"/tool/roman-numeral-converter",wait_until='networkidle');await pg.wait_for_timeout(1500)
  i=pg.locator('main input');n=await i.count();out={'count':n}
  # date fields assumed after 2 inputs
  try:
    vals=['30','2','2026'];
    for k in range(3): await i.nth(2+k).fill(vals[k])
    await pg.wait_for_timeout(500)
    out['feb30']=await pg.evaluate("document.querySelector('main').innerText.split('About')[0].slice(-500)")
    for k,v in enumerate(['31','4','2026']): await i.nth(2+k).fill(v)
    await pg.wait_for_timeout(500)
    out['apr31']=await pg.evaluate("document.querySelector('main').innerText.split('About')[0].slice(-500)")
  except Exception as e: out['err']=str(e)[:200]
  await pg.screenshot(path=f'ss/fn-roman-date-{tag}.png',full_page=False)
  return out
async def audio(pg,tag,a,b2,name):
  await pg.goto(B+"/tool/audio-comparer",wait_until='networkidle');await pg.wait_for_timeout(1500)
  f=pg.locator('input[type=file]')
  await f.nth(0).set_input_files(a);await f.nth(1).set_input_files(b2);await pg.wait_for_timeout(1000)
  await pg.get_by_role('button',name='Compare Audio').click();await pg.wait_for_timeout(8000)
  t=await pg.evaluate("document.querySelector('main').innerText.split('About')[0].slice(-900)")
  await pg.screenshot(path=f'ss/fn-audio-{name}-{tag}.png',full_page=True);return t
async def merge(pg,tag):
  await pg.goto(B+"/tool/merge-pdf",wait_until='networkidle');await pg.wait_for_timeout(1500)
  await pg.locator('input[type=file]').first.set_input_files(['fx/one.pdf','fx/two.pdf']);await pg.wait_for_timeout(2000)
  t0=await pg.evaluate("document.querySelector('main').innerText.split('About')[0].slice(-900)")
  btns=await pg.evaluate("[...document.querySelectorAll('main button')].map(b=>b.innerText.trim()).filter(x=>x)")
  await pg.screenshot(path=f'ss/fn-merge-loaded-{tag}.png',full_page=True)
  out={'loaded':t0,'btns':btns}
  try:
    async with pg.expect_download(timeout=30000) as d:
      await pg.get_by_role('button',name='Merge',exact=False).filter(has_text='Merge').last.click()
      await pg.wait_for_timeout(3000)
      bl=await pg.evaluate("[...document.querySelectorAll('main button,main a')].map(b=>b.innerText.trim()).filter(x=>/download/i.test(x))")
      out['dlbtns']=bl
      if bl: await pg.get_by_text(bl[0]).first.click()
    dl=await d.value;p=f'fx/out-merge-{tag}.pdf';await dl.save_as(p);out['file']=dl.suggested_filename;out['size']=os.path.getsize(p)
  except Exception as e: out['err']=str(e)[:300]
  out['after']=await pg.evaluate("document.querySelector('main').innerText.split('About')[0].slice(-600)")
  await pg.screenshot(path=f'ss/fn-merge-after-{tag}.png',full_page=True);return out
async def cam(pg,tag):
  await pg.goto(B+"/tool/camera-capture",wait_until='networkidle');await pg.wait_for_timeout(1500)
  out={}
  await pg.get_by_role('button',name='Start Camera').click();await pg.wait_for_timeout(3000)
  out['started']=await pg.evaluate("[...document.querySelectorAll('main button, main label')].map(b=>b.innerText.trim()).filter(x=>x)")
  await pg.screenshot(path=f'ss/fn-cam-live-{tag}.png')
  try:
    await pg.locator('main button',has_text='Capture').first.click();await pg.wait_for_timeout(2000)
    out['captured']=await pg.evaluate("[...document.querySelectorAll('main button')].map(b=>b.innerText.trim()).filter(x=>x)")
    async with pg.expect_download(timeout=20000) as d:
      await pg.locator('main button',has_text='Download').first.click()
    dl=await d.value;p=f'fx/out-cam-{tag}';await dl.save_as(p);out['file']=dl.suggested_filename;out['size']=os.path.getsize(p)
  except Exception as e: out['err']=str(e)[:300]
  await pg.screenshot(path=f'ss/fn-cam-after-{tag}.png',full_page=True);return out
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(args=["--use-fake-ui-for-media-stream","--use-fake-device-for-media-stream"])
    for vw,tag in [(1280,'desk'),(390,'mob')]:
      r={}
      for name,fn in [('roman',roman),('roman_date',roman_date),('merge',merge),('cam',cam)]:
        c,pg=await ctx(b,vw)
        try: r[name]=await fn(pg,tag)
        except Exception as e: r[name]={'fatal':str(e)[:300]}
        await c.close()
      for nm,a,b2 in [('same','fx/a440.wav','fx/a440b.wav'),('diff','fx/a440.wav','fx/a880.wav')]:
        c,pg=await ctx(b,vw)
        try: r['audio_'+nm]=await audio(pg,tag,a,b2,nm)
        except Exception as e: r['audio_'+nm]={'fatal':str(e)[:300]}
        await c.close()
      R[tag]=r
    await b.close()
  json.dump(R,open('fn.json','w'),indent=1)
asyncio.run(main())
