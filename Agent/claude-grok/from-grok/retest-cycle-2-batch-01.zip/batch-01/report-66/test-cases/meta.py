import json,asyncio
from playwright.async_api import async_playwright
B="https://www.freedailypro.com"
P=["/","/tool/roman-numeral-converter","/tool/audio-comparer","/tool/merge-pdf","/tool/camera-capture","/es/tool/roman-numeral-converter"]
async def main():
  out={}
  async with async_playwright() as p:
    b=await p.chromium.launch(args=["--use-fake-ui-for-media-stream","--use-fake-device-for-media-stream"])
    for vw,name in [(1280,'desk'),(390,'mob')]:
      for path in P:
        c=await b.new_context(viewport={'width':vw,'height':900 if vw>400 else 844},is_mobile=vw<400,has_touch=vw<400,locale='en-US')
        pg=await c.new_page(); errs=[]
        pg.on('console',lambda m: errs.append(m.text[:200]) if m.type=='error' else None)
        r=await pg.goto(B+path,wait_until='networkidle',timeout=60000); await pg.wait_for_timeout(2500)
        d=await pg.evaluate('''()=>({title:document.title,desc:(document.querySelector('meta[name=description]')||{}).content,
         h1:[...document.querySelectorAll('h1')].map(h=>h.textContent.trim()),canon:(document.querySelector('link[rel=canonical]')||{}).href,
         hreflang:[...document.querySelectorAll('link[rel=alternate][hreflang]')].map(l=>l.hreflang+'='+l.href),
         ld:[...document.querySelectorAll('script[type="application/ld+json"]')].map(s=>{try{const j=JSON.parse(s.textContent);return JSON.stringify(j).slice(0,0)+((j['@graph']||[j]).map(x=>x['@type']).join(','))}catch(e){return 'ERR'}}),
         docW:document.documentElement.scrollWidth,
         small:[...document.querySelectorAll('button,a,input')].filter(e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0&&(r.height<24||r.width<24)}).length,
         inputs16:[...document.querySelectorAll('input,textarea,select')].filter(e=>parseFloat(getComputedStyle(e).fontSize)<16&&e.offsetParent).length,
         free:(document.body.innerText.match(/\\bfree\\b/gi)||[]).length,
         text:document.body.innerText.slice(0,6000)})''')
        d['status']=r.status; d['errs']=errs[:8]
        out[name+path]=d
        await pg.screenshot(path=f"ss/{name}{path.replace('/','_') or '_home'}.png",full_page=False)
        await c.close()
    await b.close()
  json.dump(out,open('meta.json','w'),indent=1)
asyncio.run(main())
