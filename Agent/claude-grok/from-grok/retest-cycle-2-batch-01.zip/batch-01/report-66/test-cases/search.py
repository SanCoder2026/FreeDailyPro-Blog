import asyncio,json
from playwright.async_api import async_playwright
B="https://www.freedailypro.com"
async def run(b,vw,tag):
  c=await b.new_context(viewport={'width':vw,'height':900 if vw>400 else 844},is_mobile=vw<400,has_touch=vw<400)
  pg=await c.new_page();ev=[]
  pg.on('request',lambda r: ev.append(r.url[:160]) if ('collect' in r.url and 'google' in r.url) else None)
  await pg.goto(B+"/",wait_until='networkidle');await pg.wait_for_timeout(2500)
  info=await pg.evaluate("""()=>[...document.querySelectorAll('input')].filter(i=>i.offsetParent).map(i=>({type:i.type,ph:i.placeholder,aria:i.getAttribute('aria-label'),fs:getComputedStyle(i).fontSize,r:JSON.stringify(i.getBoundingClientRect())}))""")
  out={'inputs':info}
  s=pg.locator('input[placeholder*="mind"]').first
  try:
    await s.click();await s.type('me',delay=80);await pg.wait_for_timeout(800)
    out['sugg_2char']=await pg.evaluate("[...document.querySelectorAll('[role=option],[role=listbox] a,[role=listbox] button,[role=listbox] *, li a')].filter(e=>e.offsetParent).length")
    await pg.screenshot(path=f'ss/search-2char-{tag}.png')
    await s.type('rge',delay=80);await pg.wait_for_timeout(1000)
    out['sugg_5char']=await pg.evaluate("[...document.querySelectorAll('[role=option],[role=listbox] a,[role=listbox] button')].filter(e=>e.offsetParent).map(e=>e.innerText.trim().slice(0,40)).slice(0,8)")
    out['nearby_btns']=await pg.evaluate("(()=>{const i=document.activeElement;const f=i.closest('form,div');return [...f.parentElement.querySelectorAll('button')].map(b=>(b.innerText||b.getAttribute('aria-label')||'').trim())})()")
    out['hint']=await pg.evaluate("/press enter/i.test(document.body.innerText)")
    await pg.screenshot(path=f'ss/search-merge-{tag}.png')
    await s.press('Enter');await pg.wait_for_timeout(2500);out['enter_url']=pg.url
    out['enter_text']=(await pg.inner_text('body'))[:600]
    await pg.screenshot(path=f'ss/search-enter-{tag}.png')
    await pg.goto(B+"/",wait_until='networkidle');await pg.wait_for_timeout(1500)
    s=pg.locator('input[placeholder*="mind"]').first
    await s.fill('zzqxv nothing');await s.press('Enter');await pg.wait_for_timeout(2500)
    out['empty_url']=pg.url;out['empty_text']=(await pg.inner_text('main'))[:500]
    await pg.screenshot(path=f'ss/search-empty-{tag}.png')
    await pg.goto(B+"/",wait_until='networkidle');await pg.wait_for_timeout(1500)
    s=pg.locator('input[placeholder*="mind"]').first
    await s.fill('roman');await pg.wait_for_timeout(1200)
    out['roman_sugg']=await pg.evaluate("[...document.querySelectorAll('[role=option],[role=listbox] a,[role=listbox] button')].filter(e=>e.offsetParent).map(e=>e.innerText.trim().slice(0,40))")
    await s.fill('url shortener');await pg.wait_for_timeout(1200)
    out['url_sugg']=await pg.evaluate("[...document.querySelectorAll('[role=option],[role=listbox] a,[role=listbox] button')].filter(e=>e.offsetParent).map(e=>e.innerText.trim().slice(0,40))")
  except Exception as e: out['err']=str(e)[:300]
  out['ga_hits']=[u for u in ev if 'search' in u or 'en=' in u][:20]
  await c.close();return out
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch();R={}
    for vw,t in [(1280,'desk'),(390,'mob')]: R[t]=await run(b,vw,t)
    await b.close()
  json.dump(R,open('search.json','w'),indent=1);print(json.dumps(R,indent=1)[:6000])
asyncio.run(main())
