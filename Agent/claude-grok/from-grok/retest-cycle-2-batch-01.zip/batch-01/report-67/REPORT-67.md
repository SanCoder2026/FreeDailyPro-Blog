# Testing Bot report #67 — Retest cycle 2, batch 1 (plan report_batch 2, part 1)
Tools (≤3): **Pricing + checkout gate**, **Merge PDF**. (Compress PDF, the third row of plan batch 2, is deferred to the next run — not tested here.)
Tested Thu Oct 29 2026, 9:36–9:44 PM ET; logged out, no plan; Playwright Chromium desktop 1280×900 + mobile 390×844; US IP, en-US. No email entered, no sign-in, nothing paid (owner has not approved passing the gate).
Guidance: TESTING-GUIDANCE.md, Last updated 2026-10-29 9:38 PM ET. Prior Stripe audit REPORT.md at /cursor/stores/.../stripe-checkout-audit/ is **not present on this box** — compared against B-0027's summary of it instead.

## Pricing / checkout gate (row 4) — no new brief
| ID | Check | Expected (B-0027 when shipped) | Actual Oct 29 | Status |
|---|---|---|---|---|
| R67-PRC-01 | /pricing loads, prices | $1/day, $4.99/mo; $3/day, $9.99/mo; Event Suite $29.99/mo; seats $3.99/$2.99/$1.66; API $24/$69/$129 | all present, desktop + mobile | PASS (unchanged) |
| R67-PRC-02 | Day Pass label | "Buy Day Pass" | "Sign in to buy" still on page; buttons read "Get Day Pass" / "Get Premium Day Pass" | open — B-0027 not claimed done |
| R67-PRC-03 | Subscribe Monthly (signed out) | straight to Stripe | dialog "Enter your email and go straight to payment… Continue to payment" (stopped here) | open — B-0027 not claimed done |
| R67-PRC-04 | /account, /workflows | redirect | both 404 "Page Not Found" | open — B-0027 not claimed done |
Not re-briefed (rule: only retest after Claude marks done). Screenshots pricing-*.png.

## Merge PDF (row 5)
| ID | Viewport | Steps / input | Expected | Actual | Status |
|---|---|---|---|---|---|
| R67-MRG-01 | both | upload one.pdf (2 p) + two.pdf (3 p) | list with page counts, reorder | "2 files · 5 pages — drag to reorder", ↑/↓, odd-page blank option | PASS |
| R67-MRG-02 | both | Merge 2 PDFs → Download Merged PDF | 5-page PDF in order | one-merged.pdf, 5 pages: one p1, one p2, two p1–p3 (pypdf) | PASS |
| R67-MRG-03 | 1280 | trial counter at load / after Merge / after DL1 / after DL2 | 1 use on output | 10 / 10 / 9 / 9 | PASS (B-0001 pattern verified) |
| R67-MRG-04 | both | trial badge disclosure | told before download | "This download will carry a small 'Created with FreeDailyPro.com' badge…" shown before button | PASS (SW-14 disclosed) |
| R67-MRG-05 | both | output size label | matches file | label "5 pages · 1.7 KB"; downloaded file 5,548 bytes | FAIL → B-0054 |
| R67-MRG-06 | both | next steps | chain | "Continue with Add Page Numbers / Add Watermark" | PASS |
| R67-MRG-07 | 390 | overflow | none | docW 390 | PASS |
Not tested: >50 MB / 200-page files, encrypted PDF, iOS Safari Files picker (real devices). API page-selection parity: B-0040 open — not re-reported.

## Improvements (vs iLovePDF, Smallpdf, PDF24 — all live 200 Oct 29)
Merge PDF has GSC 601 impr at pos 35.2 (test-plan.csv) and 86 views / 58 s (GA 28d, raw.md). Competitors show page thumbnails and let you remove/rotate single pages before merging; PDF24 and Smallpdf allow per-file page ranges. FreeDailyPro shows page numbers only after merge. Suggested in B-0054 as an improvement.

Scripts: test-cases/fn.py (merge + camera), cnt.py (counter), pricing.py. Fixtures: test-cases/fixtures/one.pdf, two.pdf, out-merge-desk.pdf.
