import asyncio,json,re
from playwright.async_api import async_playwright
B="https://www.freedailypro.com"
async def main():
  R={}
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for vw,tag in [(1280,'desk'),(390,'mob')]:
      c=await b.new_context(viewport={'width':vw,'height':900 if vw>400 else 844},is_mobile=vw<400,has_touch=vw<400,locale='en-US')
      pg=await c.new_page();r=await pg.goto(B+"/pricing",wait_until='networkidle');await pg.wait_for_timeout(2500)
      btns=await pg.evaluate("[...document.querySelectorAll('main button, main a')].filter(e=>e.offsetParent).map(e=>e.innerText.trim()).filter(x=>x&&x.length<60)")
      txt=await pg.inner_text('main')
      R[tag]={'status':r.status,'btns':btns,'prices':re.findall(r'\$\d+(?:\.\d+)?[^\n]{0,30}',txt)[:30],'signin_to_buy':'Sign in to buy' in txt,'buy_day_pass':'Buy Day Pass' in txt}
      await pg.screenshot(path=f'ss/pricing-{tag}.png',full_page=True)
      # click first monthly button, observe only
      for lab in ['Monthly','Subscribe','Get Professional','Start']:
        l=pg.locator('main button',has_text=re.compile(lab,re.I))
        if await l.count():
          try:
            await l.first.click();await pg.wait_for_timeout(5000)
            R[tag]['monthly_click']={'label':await l.first.inner_text() if await l.count() else lab,'url':pg.url,'dialog':(await pg.evaluate("(document.querySelector('[role=dialog]')||{}).innerText||''"))[:500]}
            await pg.screenshot(path=f'ss/pricing-monthly-click-{tag}.png')
          except Exception as e: R[tag]['monthly_click']=str(e)[:200]
          break
      for u in ['/account','/workflows']:
        rr=await pg.goto(B+u,wait_until='domcontentloaded');await pg.wait_for_timeout(1500);R[tag][u]=[rr.status,pg.url,(await pg.title())]
      await c.close()
    await b.close()
  json.dump(R,open('pricing.json','w'),indent=1);print(json.dumps(R,indent=1))
asyncio.run(main())
