# QA Report #68: Compress PDF, Split PDF (retest cycle 2, batch 2)
Tested Oct 29, 2026, 21:45–22:25 ET, by Testing Bot. Chromium (Playwright headless) on desktop 1280×900 and mobile 390×844 (is_mobile, touch). Logged out, US IP, a fresh context per case unless noted.
Guidance: TESTING-GUIDANCE.md, "Last updated: 2026-10-29 9:38 PM ET", and test-plan.csv rows 6–7.
Test only: nothing on the site was changed, nothing was paid, no sign-ups, no API writes.

## Ranked briefs in this report
1. **B-0055 (P1).** The trial counter disagrees between server instances: fresh visitors see "0 remaining" and visitors at the limit get uses back by reloading. This is site-wide; it was found here and also shows on QR, Bulk QR and Income Tax.
2. **B-0056 (P2).** Compress PDF: Aggressive and Extreme give byte-identical output, Extreme never goes grey or black-and-white, and Balanced skips the lossless-text level 2.

## Verified fixed (my own pass)
- **B-0022, Compress PDF vocabulary.** The page source has no "Smallest" mode name; the only "smallest" left is a descriptive word inside the Extreme help. The FAQ, help text and meta use Balanced / Aggressive / Extreme / Target size. PASS.
- **B-0021, paywall at 0.** The dialog reads "Your result is ready … Get Day Pass — $1 / Go Unlimited — $4.99/month / Have an access code? / Compare plans / Not now". Day Pass is first, no file is delivered, and the copy has no visible "free". GA requests showed `tool_completed`, `limit_hit` and `upgrade_cta_view` once each per blocked action (comp-scan.json). I did not click Day Pass, so `upgrade_cta_click` wasn't triggered; we stay at the gate. PASS for what can be checked. Screenshot: screenshots/paywall-dialog-at-0.png.
- **B-0001 counting.** Compressing does not use a trial use; the first download does. Split works the same way: splitting is free, the ZIP or file download costs 1, and downloading the individual files of the same split doesn't cost more (split-run1: 9→8 after the ZIP, still 8 after 3 single downloads). PASS.

## Compress PDF: results
| Case | Input | Expected | Actual | Result |
|---|---|---|---|---|
| CMP-01 Balanced | scan.pdf 4.87 MB, 5 pages | smaller, text selectable | 346,015 B, 5 pages, text and link kept | PASS |
| CMP-02 Aggressive | scan.pdf | smaller than Balanced, pages may be rasterised | 97,664 B, colour, text selectable (level 2 only) | PASS on size; no rasterising levels ran |
| CMP-03 Extreme | scan.pdf, waited 90 s | grey 70 dpi, then black and white | **byte-identical to Aggressive** (MD5 2798bfe9…), RGB images, text selectable | FAIL → B-0056 |
| CMP-04 photos.pdf, all modes | 8.45 MB | 4 distinct results | Balanced 2.13 MB; Aggressive = Extreme = 161.5 KB | FAIL → B-0056 |
| CMP-05 Target size UI | 2 MB | input plus unit plus ceiling | number input, MB/KB unit, ceiling select (Balanced only … up to Extreme), 500 KB/1/2/5 MB chips | PASS (UI) |
| CMP-06 Mobile 390 | Balanced | works, no overflow | same output as desktop, docW 390, 0 inputs under 16 px | PASS |
| CMP-07 "What is making this file big" | both | breakdown | Pictures 100% / content / other, with advice | PASS (strong differentiator) |
| SEO | — | title, meta, H1, hreflang, JSON-LD | Title "Compress PDF to a Target Size Online - Free, No Signup" (SEO "free" is by-design); meta lists the 4 modes; H1 "Compress PDF"; 22 hreflang; 9 JSON-LD blocks; 0 console errors | PASS |

## Split PDF: results
| Case | Input (six.pdf, 6 pages) | Expected | Actual | Result |
|---|---|---|---|---|
| SPL-01 | "2-4" | 1 PDF, pages 2–4 | six-pages-2-4.pdf = PAGE 2,3,4 | PASS |
| SPL-02 | "1-2, 4, 5-6" | ZIP of 3 | six-split.zip with 1-2 / 4 / 5-6, contents correct, plus per-file Download buttons | PASS. **The B-0040 UI side works; the API side stays open in B-0040, not re-reported.** |
| SPL-03 | "5-6, 1-2" + Combine | 1 PDF in typed order | PAGE 5,6,1,2 | PASS |
| SPL-04 | Every page | ZIP of 6 | 6 one-page files, correct | PASS (see counter note) |
| SPL-05 | Split every 2 / every 10 | 3 files / 1 file | 3 files listed / six-pages-1-6.pdf | PASS |
| SPL-06 | 7-9, 5-8, 0, 3-1, abc, empty | clear error, button disabled | "\"7-9\" is outside this PDF's 6 pages", "\"3-1\" starts after it ends", "Page 0 is outside…", "\"abc\" isn't a valid page number", "Enter at least one page range"; Split disabled | PASS (best-in-class messages) |
| SPL-07 | "1-3, 2-4" | allow with warning | "Pages 2-3 appear in more than one file." | PASS |
| SPL-08 | " 1 - 2 ,4" | whitespace tolerated | 2 files | PASS |
| SPL-09 | Mobile 390 | no overflow, readable | docW 390, 0 small inputs | PASS |
| SPL-10 | Badge | disclosed before download | "This download will carry a small 'Created with FreeDailyPro.com' badge…"; output pages contain that text | PASS |
| SEO | — | — | title "Split PDF Online - By Page Range or Every Page, Free"; H1 "Split PDF"; 22 hreflang; 9 JSON-LD | PASS |

Notes:
- In the first meta pass at 21:47 ET, desktop docW was 1840 px. Three later loads with a full scroll measured 1280, so it was not reproducible. It was probably an ad that hadn't finished rendering, which falls under orchestrator B-0041. Not briefed.
- The "Every page" ZIP once showed 7→0 remaining. This was during the B-0055 flapping, so it's confounded and not reported. Retest after B-0055.

## B-0055 evidence (counter flapping)
22:02:19–22:03:40 ET, a fresh context per load, no actions taken:
- income-tax 0, compress 0, qr 0, split 10, bulk 0
- income-tax 0, compress 10, qr 0, split 10, bulk 10
- income-tax 10, compress 0, qr 10, split 0, bulk 10

22:03:53–22:04:18 ET, compress-pdf, `usage.check` bodies: usageToday 0, 0, **10**, 0, **10**, **10**. Each load had a new deviceId, edge iad1, server railway-hikari.

Professional downloads were blocked for the rest of the evening, so the remaining download checks wait for the next run (see ledger).

## Not tested / blocked
- Target-size download, a large file (over 50 MB), and real iOS Safari: blocked by the exhausted trial pool and B-0055. Retest tomorrow.
- API parity (B-0040): no API key, and API writes are not allowed.

## Suggestions (not briefed; for the roadmap)
- **Split.** Let users click thumbnails to choose pages (iLovePDF and Smallpdf both have visual pickers). Add split by bookmarks or by file size, and a per-range file name field.
- **Compress.** Show the competitor-style quick answer "fits under 2 MB email limit ✓" on Balanced results. Mature-candidate once B-0056 is verified: the breakdown and level list already beat the competitors.

## Test-case package
test-cases/scripts (comp.py, split.py, split2.py, nd.py, ext.py, last.py, chk3.py, chk4.py, common.py, meta.py), test-cases/results (JSON plus every downloaded output), test-cases/fixtures (scan.pdf, photos.pdf, six.pdf), screenshots/.
