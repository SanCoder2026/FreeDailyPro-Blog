import asyncio,re
from playwright.async_api import async_playwright
from common import *
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for i in range(3):
     for s in ['income-tax-calculator','compress-pdf','qr-generator','split-pdf','bulk-qr']:
      c=await b.new_context(); pg=await c.new_page(); api=[]
      pg.on('response',lambda r: api.append(r.url.split('?')[0][-60:]+' '+str(r.status)) if re.search(r'trial|usage|quota|limit|entitle|/api/',r.url) else None)
      await pg.goto(U+s,wait_until='networkidle'); await pg.wait_for_timeout(3000)
      t=await pg.locator('main').inner_text(); m=re.findall(r'Trial:[^\n]*',t)
      print(now(),s,m,api[:4]); await c.close()
asyncio.run(main())
