import asyncio,re,json
from playwright.async_api import async_playwright
from common import *
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for i in range(6):
      c=await b.new_context(); pg=await c.new_page(); got=[]
      async def h(r):
        if 'usage.check' in r.url:
          try: got.append({'url':r.url[-260:],'hdr':{k:v for k,v in r.headers.items() if k in('x-railway-edge','x-railway-request-id','server','cf-ray','x-instance','fly-request-id')},'body':(await r.text())[:500]})
          except Exception as e: got.append(str(e))
      pg.on('response',h); await pg.goto(U+'compress-pdf',wait_until='networkidle'); await pg.wait_for_timeout(2500)
      print(now(),re.findall(r'Trial:[^\n]*',await pg.locator('main').inner_text()),json.dumps(got)[:900]); await c.close()
asyncio.run(main())
