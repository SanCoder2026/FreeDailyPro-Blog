import re,json,datetime
U="https://www.freedailypro.com/tool/"
def now(): return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S ET')
async def rem(pg):
  t=await pg.locator('main').inner_text(); m=re.findall(r'(\d+) remaining',t); return int(m[0]) if m else None
async def ui(pg):
  return await pg.evaluate('''()=>[...document.querySelectorAll("main input,main select,main textarea,main button,main a[download]")].filter(e=>e.offsetParent).map(e=>e.tagName+":"+(e.type||"")+":"+(e.placeholder||e.getAttribute("aria-label")||e.innerText||"").trim().slice(0,50)+"="+(e.value||"").slice(0,30))''')
async def txt(pg,a=0,b=2500): return (await pg.locator('main').inner_text())[a:b]
def ga(ctx,store):
  def h(r):
    if 'collect' in r.url and ('google-analytics' in r.url or 'analytics' in r.url):
      for m in re.findall(r'en=([a-z_]+)',r.url+' '+(r.post_data or '')): store.append(m)
  ctx.on('request',h)
async def allowed(pg,url,tries=10):
  for i in range(tries):
    await pg.goto(url,wait_until='networkidle'); await pg.wait_for_timeout(1500)
    r=await rem(pg)
    if r and r>0: return i
  return -1
