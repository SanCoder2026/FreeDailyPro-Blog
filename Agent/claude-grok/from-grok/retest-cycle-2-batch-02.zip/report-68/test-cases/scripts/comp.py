import sys
FX=sys.argv[1];NM=sys.argv[2];MINST=int(sys.argv[3]);MODES=sys.argv[4].split(',')
import asyncio,json,sys,os
from playwright.async_api import async_playwright
from common import *
from pypdf import PdfReader
R=[]
async def run(b,mode,vp,tag):
  ctx=await b.new_context(viewport=vp,accept_downloads=True,**({'is_mobile':True,'has_touch':True} if vp['width']<500 else {}))
  ev=[];ga(ctx,ev); pg=await ctx.new_page(); r={'mode':mode,'vp':vp['width'],'start':now()}
  r['reloads']=await allowed(pg,U+'compress-pdf'); r['rem0']=await rem(pg)
  await pg.locator('input[type=file]').first.set_input_files(FX); await pg.wait_for_timeout(3000)
  await pg.get_by_role('button',name=mode,exact=True).click(); await pg.wait_for_timeout(800)
  if mode=='Target size':
    r['ui_target']=await ui(pg)
    inp=pg.locator('main input[type=text],main input[type=number]').first
    if await inp.count(): await inp.fill('2')
  r['modetext']=await txt(pg,600,1400)
  await pg.get_by_role('button',name='Compress PDF',exact=True).click()
  last='';st=0
  for i in range(150):
    await pg.wait_for_timeout(2000); t=await txt(pg,0,6000)
    if 'Download Compressed PDF' in t and t==last: st+=1
    else: st=0
    last=t
    if st>=MINST: break
  r['secs']=2*(i+1); r['rem1']=await rem(pg); r['post_ui']=await ui(pg); r['post_txt']=await txt(pg,300,2200)
  await pg.screenshot(path=f'ss/compress-{NM}-{tag}-result.png',full_page=True)
  try:
    async with pg.expect_download(timeout=30000) as d:
      dl=pg.get_by_role('button',name='Download Compressed PDF')
      if not await dl.count(): dl=pg.locator('main a[download]').first
      await dl.click()
    D=await d.value; p=f'out/compress-{NM}-{tag}.pdf'; await D.save_as(p)
    rd=PdfReader(p); r['out']={'name':D.suggested_filename,'bytes':os.path.getsize(p),'pages':len(rd.pages),'text':rd.pages[0].extract_text()[:40],'links':len(rd.pages[0].get('/Annots') or [])}
  except Exception as e: r['dlerr']=str(e)[:200]
  await pg.wait_for_timeout(1500); r['rem2']=await rem(pg); r['ga']=ev; r['end']=now()
  R.append(r); await ctx.close()
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for m in MODES: 
      try: await run(b,m,{'width':1280,'height':900},m.split()[0].lower())
      except Exception as e: R.append({'mode':m,'err':str(e)[:300]})
      json.dump(R,open(f'comp-{NM}.json','w'),indent=1)
    if 0: await run(b,'Balanced',{'width':390,'height':844},'mobile-balanced')
    json.dump(R,open(f'comp-{NM}.json','w'),indent=1)
asyncio.run(main())
