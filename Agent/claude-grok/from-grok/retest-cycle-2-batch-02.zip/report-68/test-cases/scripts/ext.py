import asyncio
from playwright.async_api import async_playwright
from common import *
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(); pg=await (await b.new_context(viewport={'width':1280,'height':900})).new_page()
    for f in ['fx/scan.pdf','fx/photos.pdf']:
      await pg.goto(U+'compress-pdf',wait_until='networkidle'); await pg.locator('input[type=file]').first.set_input_files(f); await pg.wait_for_timeout(2500)
      await pg.get_by_role('button',name='Extreme',exact=True).click(); await pg.get_by_role('button',name='Compress PDF',exact=True).click(); await pg.wait_for_timeout(40000)
      t=await txt(pg,0,9000); i=t.find('Target size\n'); print(f, t[i:i+900]); await pg.screenshot(path=f'ss/compress-extreme-{f[3:8]}-top.png',clip={'x':0,'y':150,'width':1280,'height':900})
asyncio.run(main())
