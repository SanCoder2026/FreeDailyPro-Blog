import asyncio,io
from playwright.async_api import async_playwright
from common import *
import zxingcpp
from PIL import Image
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(); pg=await (await b.new_context(viewport={'width':1280,'height':900})).new_page()
    for i in range(3):
      await pg.goto(U+'split-pdf',wait_until='networkidle'); await pg.wait_for_timeout(4000); await pg.mouse.wheel(0,3000); await pg.wait_for_timeout(2000)
      print('split docW',await pg.evaluate('document.documentElement.scrollWidth'),await pg.evaluate("[...document.querySelectorAll('body *')].filter(e=>e.getBoundingClientRect().right>1290).slice(0,3).map(e=>e.tagName+'.'+String(e.className).slice(0,50)+' '+(e.id||''))"))
    await pg.goto(U+'custom-qr',wait_until='networkidle'); await pg.wait_for_timeout(1500)
    await pg.locator('main input[type=text]').first.fill('https://example.com/custom?q=1'); await pg.locator('input[type=file]').first.set_input_files('fx/logo.png'); await pg.locator('main input[type=checkbox]').first.check(); await pg.wait_for_timeout(1500)
    c=pg.locator('main canvas, main svg, main img'); 
    for i in range(await c.count()):
      bb=await c.nth(i).bounding_box()
      if bb and bb['width']>150 and abs(bb['width']-bb['height'])<5:
        B=await c.nth(i).screenshot(path='ss/custom-qr-preview.png'); print('custom decode',[x.text for x in zxingcpp.read_barcodes(Image.open(io.BytesIO(B)))]); break
    t=await txt(pg,0,4000); print(t[t.find('Logo'):t.find('Logo')+300])
asyncio.run(main())
