import asyncio,json,io,sys
from playwright.async_api import async_playwright
from common import *
import zxingcpp
from PIL import Image
R=[]
def save(): json.dump(R,open('nd.json','w'),indent=1)
async def prev(pg,tag):
  el=pg.locator('main canvas, main img[alt*="QR" i], main svg[viewBox]').filter(has_not_text='x').first
  cands=pg.locator('main canvas, main img, main svg')
  best=None
  for i in range(await cands.count()):
    e=cands.nth(i); bb=await e.bounding_box()
    if bb and bb['width']>150 and abs(bb['width']-bb['height'])<5: best=e; break
  if not best: return 'nopreview'
  B=await best.screenshot(path=f'ss/{tag}-preview.png'); im=Image.open(io.BytesIO(B)).resize((800,800),Image.NEAREST)
  return [x.text for x in zxingcpp.read_barcodes(im)]
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(); ctx=await b.new_context(viewport={'width':1280,'height':900},accept_downloads=True); pg=await ctx.new_page()
    # QR generator previews
    await pg.goto(U+'qr-generator',wait_until='networkidle'); await pg.wait_for_timeout(1500)
    await pg.get_by_placeholder('https://example.com').fill('https://example.com/cafe?a=1&b=2#menu'); await pg.wait_for_timeout(800)
    R.append({'tool':'qr','case':'link-preview','dec':await prev(pg,'qr-link')})
    for t in ['WiFi','Contact','Email','SMS','Phone','Text']:
      await pg.locator('main button').filter(has_text=re.compile('^'+t+'$')).first.click(); await pg.wait_for_timeout(700)
      fields=pg.locator('main input[type=text],main input[type=password],main input[type=tel],main input[type=email],main input[type=url],main input:not([type]),main textarea,main select')
      labels=[]
      vals={'WiFi':['My;Net,"x"','p@ss;w:rd\\'],'Contact':['José','Núñez','+1 555 0100','jose@example.com','Acme, Inc.','CTO','https://acme.example'],'Email':['a@example.com','Hi & bye','Body line 1\nline 2'],'SMS':['+15550100','Hello, world?'],'Phone':['+1 (555) 010-0123'],'Text':['Hello 你好 😀 line1\nline2']}[t]
      k=0
      for i in range(await fields.count()):
        f=fields.nth(i)
        if not await f.is_visible() or await f.evaluate('e=>e.tagName')=='SELECT': continue
        lab=await f.evaluate('e=>(e.labels&&e.labels[0]?e.labels[0].innerText:e.placeholder)||""'); labels.append(lab)
        if k<len(vals): await f.fill(vals[k]); k+=1
      await pg.wait_for_timeout(900)
      R.append({'tool':'qr','case':t,'labels':labels,'dec':await prev(pg,'qr-'+t),'sel':await pg.evaluate('[...document.querySelectorAll("main select")].filter(e=>e.offsetParent).map(e=>e.value)')}); save()
    await pg.locator('main button').filter(has_text=re.compile('^Text$')).first.click(); await pg.locator('main textarea,main input[type=text]').first.fill('x'*3000); await pg.wait_for_timeout(800)
    R.append({'tool':'qr','case':'text-3000','txt':(await txt(pg,0,3000))[-600:]}); await pg.screenshot(path='ss/qr-text-3000.png')
    await pg.locator('main button').filter(has_text=re.compile('^Link$')).first.click(); await pg.get_by_placeholder('https://example.com').fill('https://example.com')
    await pg.locator('main button').filter(has_text=re.compile('^1000 px$')).first.click(); await pg.wait_for_timeout(600)
    R.append({'tool':'qr','case':'size-menu','opts':await pg.evaluate('[...document.querySelectorAll("[role=option],[role=menuitem],[role=menuitemradio],[role=listbox] li, ul li button")].filter(e=>e.offsetParent).map(e=>e.innerText.trim()).slice(0,20)')}); await pg.keyboard.press('Escape')
    await pg.locator('input[type=color]').first.fill('#1d4ed8'); await pg.wait_for_timeout(600); R.append({'tool':'qr','case':'blue-preview','dec':await prev(pg,'qr-blue')}); save()
    # Bulk
    await pg.goto(U+'bulk-qr',wait_until='networkidle'); await pg.wait_for_timeout(1500)
    await pg.locator('main textarea').first.fill(open('fx/bulk.txt').read()); await pg.wait_for_timeout(1000)
    t=await txt(pg,0,6000); R.append({'tool':'bulk','case':'list','txt':t[t.find('Enter URLs'):t.find('Save project')]}); await pg.screenshot(path='ss/bulk-list.png',full_page=True)
    await pg.locator('main input[type=checkbox]').first.uncheck(); await pg.wait_for_timeout(600)
    t=await txt(pg,0,6000); R.append({'tool':'bulk','case':'list-unchecked','txt':t[t.find('Enter URLs'):t.find('Save project')]})
    await pg.get_by_role('button',name='Try a sample').click(); await pg.wait_for_timeout(1000); t=await txt(pg,0,6000); R.append({'tool':'bulk','case':'sample','txt':t[t.find('Enter URLs'):t.find('Save project')][:900]}); save()
    await pg.locator('main button').filter(has_text=re.compile('^PNG$')).first.click(); await pg.wait_for_timeout(500); R.append({'bulk_fmt_menu':await pg.evaluate('[...document.querySelectorAll("[role=option],[role=menuitem],[role=menuitemradio]")].filter(e=>e.offsetParent).map(e=>e.innerText.trim())')}); await pg.keyboard.press('Escape')
    # Split invalid ranges
    for nm,rg in [('out-of-range','7-9'),('partly-out','5-8'),('reversed','3-1'),('zero','0'),('garbage','abc'),('overlap','1-3, 2-4'),('empty',''),('spaces',' 1 - 2 ,4'),('every-10',None)]:
      await pg.goto(U+'split-pdf',wait_until='networkidle'); await pg.wait_for_timeout(1200); await pg.locator('input[type=file]').first.set_input_files('fx/six.pdf'); await pg.wait_for_timeout(2500)
      if rg is None: await pg.get_by_placeholder('e.g. 3').fill('10'); await pg.get_by_role('button',name='Apply').click()
      else: await pg.get_by_placeholder('1-3, 4-6').fill(rg)
      await pg.wait_for_timeout(700); bt=pg.get_by_role('button',name='Split PDF',exact=True); en=await bt.is_enabled()
      if en: await bt.click(); await pg.wait_for_timeout(2500)
      t=await txt(pg,0,8000); R.append({'tool':'split','case':nm,'range':rg,'enabled':en,'out':t[t.find('Page ranges'):t.find('About Split')][:700]}); save()
    await pg.screenshot(path='ss/split-invalid-last.png',full_page=True)
    # Compress extreme levels (no download)
    for mode in ['Extreme','Aggressive']:
      await pg.goto(U+'compress-pdf',wait_until='networkidle'); await pg.wait_for_timeout(1200); await pg.locator('input[type=file]').first.set_input_files('fx/scan.pdf'); await pg.wait_for_timeout(2500)
      await pg.get_by_role('button',name=mode,exact=True).click(); await pg.get_by_role('button',name='Compress PDF',exact=True).click()
      await pg.wait_for_timeout(90000); t=await txt(pg,0,9000); R.append({'tool':'compress','case':mode+'-90s','out':t[t.find('→')-30:t.find('About Compress')]}); await pg.screenshot(path=f'ss/compress-{mode}-90s.png',full_page=True); save()
asyncio.run(main())
