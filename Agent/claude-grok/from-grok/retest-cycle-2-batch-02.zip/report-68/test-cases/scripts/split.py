import asyncio,json,os,zipfile,io
from playwright.async_api import async_playwright
from common import *
from pypdf import PdfReader
R=[]
def pages(b):
  rd=PdfReader(io.BytesIO(b)); return [p.extract_text().strip() for p in rd.pages]
async def case(pg,name,ranges=None,every=False,combine=False,n=None,DL=True):
  await pg.goto(U+'split-pdf',wait_until='domcontentloaded'); await pg.wait_for_timeout(2500); await pg.locator('input[type=file]').first.set_input_files('fx/six.pdf'); await pg.wait_for_timeout(2500)
  r={'case':name,'ranges':ranges,'combine':combine,'t':now(),'rem0':await rem(pg)}
  if every: await pg.get_by_role('button',name='Every page').click()
  if n: await pg.get_by_placeholder('e.g. 3').fill(str(n)); await pg.get_by_role('button',name='Apply').click()
  if ranges is not None: await pg.get_by_placeholder('1-3, 4-6').fill(ranges)
  cb=pg.locator('main input[type=checkbox]').first
  if await cb.is_checked()!=combine: await cb.click()
  await pg.wait_for_timeout(600); r['before']=await txt(pg,700,1500)
  await pg.get_by_role('button',name='Split PDF',exact=True).click(); await pg.wait_for_timeout(3000)
  t=await txt(pg,0,8000); r['msg']=t[t.find('Combine all'):t.find('About Split')][:1500]; r['ui']=[u for u in await ui(pg) if 'Download' in u or 'ZIP' in u.upper()]
  r['rem_after_split']=await rem(pg); r['files']=[]
  btns=pg.locator('main button').filter(has_text=re.compile('Download',re.I))
  nb=await btns.count()
  for i in range(nb if DL else min(nb,1)):
    try:
      async with pg.expect_download(timeout=15000) as d: await btns.nth(i).click()
      D=await d.value; p=f'out/split-{name}-{i}-'+D.suggested_filename; await D.save_as(p); B=open(p,'rb').read()
      f={'btn':await btns.nth(i).inner_text(),'file':D.suggested_filename,'bytes':len(B)}
      if B[:2]==b'PK':
        z=zipfile.ZipFile(io.BytesIO(B)); f['zip']={n_:pages(z.read(n_)) for n_ in z.namelist()}
      else: f['pdf']=pages(B)
      r['files'].append(f); await pg.wait_for_timeout(800); f['rem']=await rem(pg)
    except Exception as e: r['files'].append({'err':str(e)[:100]})
  await pg.screenshot(path=f'ss/split-{name}.png',full_page=True)
  rs=pg.get_by_role('button',name='Reset',exact=True)
  await pg.wait_for_timeout(1200); r['rem1']=await rem(pg); R.append(r); json.dump(R,open('split.json','w'),indent=1)
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    ctx=await b.new_context(viewport={'width':1280,'height':900},accept_downloads=True); ev=[]; ga(ctx,ev)
    pg=await ctx.new_page(); await pg.goto(U+'split-pdf',wait_until='networkidle'); await pg.wait_for_timeout(1500)
    await pg.locator('input[type=file]').first.set_input_files('fx/six.pdf'); await pg.wait_for_timeout(3000)
    R.append({'docW':await pg.evaluate('document.documentElement.scrollWidth')})
    await case(pg,'single-range','2-4')
    await case(pg,'multi-separate','1-2, 4, 5-6')
    await case(pg,'multi-combined','5-6, 1-2',combine=True)
    await case(pg,'every-page',every=True)
    await case(pg,'every-2',n=2)
    for nm,rg in [('out-of-range','7-9'),('reversed','3-1'),('zero','0'),('garbage','abc'),('overlap','1-3, 2-4'),('empty','')]:
      await case(pg,nm,rg)
    await pg.screenshot(path='ss/split-desktop-after.png',full_page=True)
    # drain to 0 and test paywall (B-0021)
    k=0
    while (await rem(pg) or 0)>0 and k<12: await case(pg,f'drain{k}','1'); k+=1
    r={'case':'paywall','rem':await rem(pg),'t':now()}
    await pg.goto(U+'split-pdf',wait_until='domcontentloaded'); await pg.wait_for_timeout(2500); await pg.locator('input[type=file]').first.set_input_files('fx/six.pdf'); await pg.wait_for_timeout(2500)
    await pg.get_by_placeholder('1-3, 4-6').fill('1'); await pg.get_by_role('button',name='Split PDF',exact=True).click(); await pg.wait_for_timeout(3000)
    r['after_split_txt']=(await txt(pg,0,6000))[-2500:]
    try:
      async with pg.expect_download(timeout=8000) as d: await pg.locator('main button').filter(has_text=re.compile('Download',re.I)).first.click()
      r['delivered']=(await d.value).suggested_filename
    except Exception as e: r['delivered']=None; r['e']=str(e)[:80]
    await pg.wait_for_timeout(2000); await pg.screenshot(path='ss/split-paywall.png',full_page=False)
    r['dialog']=await pg.evaluate('''()=>{const d=document.querySelector('[role=dialog],dialog[open]');return d?d.innerText.slice(0,800):null}''')
    r['buttons']=await pg.evaluate('''()=>{const d=document.querySelector('[role=dialog],dialog[open]');return d?[...d.querySelectorAll('a,button')].map(e=>e.innerText.trim()+' -> '+(e.href||'')+' cls:'+e.className.toString().slice(0,50)):null}''')
    await pg.wait_for_timeout(3000); r['ga']=list(ev); R.append(r)
    # click day pass without paying: just observe target
    try:
      async with ctx.expect_page(timeout=8000) as np_: await pg.get_by_role('dialog').get_by_text(re.compile('Day Pass',re.I)).first.click()
      q=await np_.value; await q.wait_for_load_state(); R.append({'daypass_click':q.url})
    except Exception as e:
      await pg.wait_for_timeout(4000); R.append({'daypass_click_same_tab':pg.url,'e':str(e)[:100]})
    await pg.wait_for_timeout(3000); R.append({'ga_after':list(ev)})
    json.dump(R,open('split.json','w'),indent=1)
    # mobile
    m=await b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True); pg=await m.new_page()
    await pg.goto(U+'split-pdf',wait_until='networkidle'); await pg.locator('input[type=file]').first.set_input_files('fx/six.pdf'); await pg.wait_for_timeout(3000)
    R.append({'mob_docW':await pg.evaluate('document.documentElement.scrollWidth'),'in16':await pg.evaluate('[...document.querySelectorAll("main input")].filter(e=>e.offsetParent&&parseFloat(getComputedStyle(e).fontSize)<16).map(e=>e.placeholder||e.type)')})
    await pg.screenshot(path='ss/split-mobile-loaded.png',full_page=True)
    await case(pg,'mobile-multi','1-2, 4, 5-6')
asyncio.run(main())
