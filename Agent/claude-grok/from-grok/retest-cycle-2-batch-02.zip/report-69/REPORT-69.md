# QA Report #69: QR Code Generator, Custom QR Code, Bulk QR Generator (retest cycle 2, batch 2)
Tested Oct 29, 2026, 21:47–22:24 ET, by Testing Bot. Chromium headless on desktop 1280×900 and mobile 390×844. Logged out, US IP. Decoding was done with zxing-cpp 3.1.1; SVG files were rendered with cairosvg first.
Guidance: TESTING-GUIDANCE.md "Last updated: 2026-10-29 9:38 PM ET"; test-plan.csv row 8. Test only: no site changes, no payment, no sign-up, no API writes.

## Ranked briefs
1. B-0055 (P1, in REPORT-68): counter flapping. It affects these tools too: qr-generator and bulk-qr showed "0 remaining" to fresh visitors at 22:02–22:03 ET.
2. B-0058 (P3): improvements only. The QR group has no functional defect found this pass.

## Verified fixed (my own pass)
- **#43 Bulk QR mobile targets/inputs.** On mobile the only sub-16 px "input" is a checkbox, which is now 24×24. The textarea and colour inputs are at least 16 px. PASS.
- **#47 Custom QR.** No open issues to retest. The meta loads: title "Custom QR Code Generator Online - With Logo | FreeDailyPro", H1 "Custom QR Code", 22 hreflang, 9 JSON-LD blocks, docW 390 on mobile. A functional rerun was skipped for two reasons: it's a Premium app with 2/day, and my selector failed at 22:24 ET. The #47 PASS stands.

## Claimed fixed but not verifiable today
- **#43 Bulk QR ",no name" kept the comma in the encoded value.** Fixed per Claude's "through #45". I couldn't verify it: generating the ZIP needs a trial use, and the pool was exhausted or flapping (B-0055). The list counter does count correctly: "8 QR codes will be generated" for 8 non-empty lines, with the blank line skipped. Status stays claimed-fixed-unverified; retest next run.

## QR Code Generator: results
| ID | Case | Expected | Actual | Result |
|---|---|---|---|---|
| QR-01 | Link `https://example.com/cafe?a=1&b=2#menu`, PNG | decodes the same | 1000×1000, decodes exactly (21:59 ET download) | PASS |
| QR-02 | Same, SVG | vector, decodes | `<svg viewBox="0 0 37 37">`, decodes | PASS |
| QR-03 | Logo png | error correction raised, still scannable | "Logo added. Error correction raised automatically"; menu shows H (30%); PNG decodes | PASS |
| QR-04 | WiFi SSID `My;Net,"x"`, password `p@ss;w:rd\` | escaped | `WIFI:T:WPA;S:My\;Net\,\"x\";P:p@ss\;w\:rd\\;;` | PASS |
| QR-05 | vCard José Núñez, "Acme, Inc." | UTF-8, comma escaped | `N:Núñez;José` … `ORG:Acme\, Inc.` | PASS |
| QR-06 | Email with subject "Hi & bye" and a 2-line body | %-encoded | `mailto:…?subject=Hi%20%26%20bye&body=…%0A…` | PASS |
| QR-07 | SMS / Phone | SMSTO / tel | `SMSTO:+15550100:Hello, world?` / `tel:+1 (555) 010-0123` | PASS (normalising suggested in B-0058) |
| QR-08 | Text with Chinese and emoji, multi-line | exact | exact | PASS |
| QR-09 | Colour #1d4ed8 | honoured | preview pixels (29,78,216); decodes | PASS |
| QR-10 | Code colour #eeeeee | warning | "Low contrast (1.2:1). Printed codes with less than about 4:1 often fail to scan…" | PASS |
| QR-11 | Size menu | — | 200/300/500/1000/1500/2000 px | PASS (2000 px download blocked by B-0055) |
| QR-12 | 3,000 chars of text | capacity message | the byte counter ("N of 2,331 bytes used at level M") is shown; I didn't capture a separate over-limit text in time; screenshot qr-text-3000.png | INCONCLUSIVE |
| QR-13 | Paywall at 0 | Day Pass first | same dialog as REPORT-68 (B-0021) | PASS |
| SEO | — | — | title "QR Code Generator Online Free - Instant, With Logo \| FreeDailyPro"; meta 84 characters | OK (SEO "free" is by-design) |

## Bulk QR Generator
- The list counter is correct and the format menu offers PNG and SVG (vector).
- "Try a sample" loads a sample project. The guest-pass security note is clear.
- The ZIP output was not tested this run because of B-0055 and the exhausted pool; it's carried to the next run.

## Competitors (live pages, Oct 29)
- QR Code Monkey: PNG/SVG/PDF/EPS, frames, no free bulk.
- NeoReader: free CSV bulk, PDF/JPG/WebP, live scan test.
- OathQR: bulk 500 per batch from CSV, browser-only.
- TechWhack: PNG/SVG only.

Where we lead: WiFi/vCard escaping, the contrast warning, the byte counter, and the bulk guest-pass projects. Gaps: PDF/EPS export, frames, a scan check, and CSV upload, all covered in B-0058.

## Maturity
QR Code Generator is a **mature candidate**. Once B-0058 export/frames are decided and the 2000 px download is verified, there's little left to improve.

## Package
test-cases/scripts (qr.py, qr2.py, nd.py, in16.py, qrdbg.py, common.py, meta.py, chk3/4.py), results (qr2.json, nd.json, meta.json, plus the downloaded PNG/SVG), fixtures (logo.png, bulk.txt), screenshots/.
