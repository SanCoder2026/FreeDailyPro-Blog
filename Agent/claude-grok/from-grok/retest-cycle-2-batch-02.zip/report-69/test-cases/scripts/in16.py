import asyncio
from playwright.async_api import async_playwright
from common import *
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(); pg=await (await b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)).new_page()
    for s in ['bulk-qr','custom-qr']:
      await pg.goto(U+s,wait_until='networkidle'); await pg.wait_for_timeout(2000)
      print(s,await pg.evaluate('[...document.querySelectorAll("input,textarea,select")].filter(e=>e.offsetParent&&parseFloat(getComputedStyle(e).fontSize)<16).map(e=>e.tagName+":"+e.type+":"+(e.getAttribute("aria-label")||e.placeholder||"").slice(0,30)+":"+getComputedStyle(e).fontSize+":"+(e.closest("main")?"main":"outside"))'),
        await pg.evaluate('[...document.querySelectorAll("main input[type=checkbox]")].filter(e=>e.offsetParent).map(e=>Math.round(e.getBoundingClientRect().width)+"x"+Math.round(e.getBoundingClientRect().height))'))
asyncio.run(main())
