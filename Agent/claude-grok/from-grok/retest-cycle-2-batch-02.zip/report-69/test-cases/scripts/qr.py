import asyncio,json,os,zipfile,io
from playwright.async_api import async_playwright
from common import *
import zxingcpp
from PIL import Image
R=[]
def dec(B):
  try: return [x.text for x in zxingcpp.read_barcodes(Image.open(io.BytesIO(B)))]
  except Exception as e: return 'ERR '+str(e)[:60]
def svgdec(p):
  import subprocess; o=p+'.png'; subprocess.run(['rsvg-convert','-w','800',p,'-o',o]) if os.system('which rsvg-convert >/dev/null')==0 else subprocess.run(['convert',p,o])
  return dec(open(o,'rb').read()) if os.path.exists(o) else 'noconv'
async def dl(pg,name,tag):
  r={'btn':name,'t':now(),'rem0':await rem(pg)}
  try:
    async with pg.expect_download(timeout=15000) as d: await pg.get_by_role('button',name=name,exact=True).click()
    D=await d.value; p=f'out/{tag}-'+D.suggested_filename; await D.save_as(p); B=open(p,'rb').read()
    r.update(file=D.suggested_filename,bytes=len(B))
    if p.endswith('.png'): im=Image.open(p); r['size']=im.size; r['decode']=dec(B); r['px00']=im.convert('RGB').getpixel((im.size[0]//2,5))
    elif p.endswith('.svg'): r['decode']=svgdec(p); r['svghead']=B[:160].decode(errors='ignore')
    elif B[:2]==b'PK':
      z=zipfile.ZipFile(io.BytesIO(B)); r['zip']={n:(dec(z.read(n)) if n.endswith('.png') else z.read(n).decode(errors='ignore')[:400]) for n in z.namelist()}
  except Exception as e:
    r['err']=str(e)[:100]; await pg.wait_for_timeout(1500)
    r['dialog']=await pg.evaluate('''()=>{const d=document.querySelector('[role=dialog],dialog[open]');return d?d.innerText.slice(0,600):null}''')
  await pg.wait_for_timeout(1200); r['rem1']=await rem(pg); return r
async def opt(pg,cur,want):
  await pg.get_by_role('button',name=cur,exact=True).first.click(timeout=5000); await pg.wait_for_timeout(500); R.append({'menu_'+cur:await pg.evaluate('[...document.querySelectorAll("[role=option],[role=menuitem],[role=menuitemradio]")].map(e=>e.innerText).slice(0,12)')})
  await pg.get_by_role('option',name=want).or_(pg.get_by_role('button',name=want,exact=True)).or_(pg.get_by_role('menuitem',name=want)).last.click(timeout=5000); await pg.wait_for_timeout(500)
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    ctx=await b.new_context(viewport={'width':1280,'height':900},accept_downloads=True); ev=[];ga(ctx,ev); pg=await ctx.new_page()
    # --- QR generator
    await allowed(pg,U+'qr-generator')
    inp=pg.get_by_placeholder('https://example.com')
    await inp.fill('https://example.com/cafe?a=1&b=2#menu'); await pg.wait_for_timeout(800)
    R.append({'tool':'qr','case':'link-png-default',**await dl(pg,'Download PNG','qr-link')})
    R.append({'tool':'qr','case':'link-svg',**await dl(pg,'Download SVG','qr-link')})
    for cur,want in [('1000 px','2000 px'),('M (15%)','H (30%)')]:
      try: await opt(pg,cur,want)
      except Exception as e: R.append({'opt_err':cur,'e':str(e)[:80]}); await pg.keyboard.press('Escape')
    await pg.locator('input[type=color]').first.evaluate("(e)=>{e.value='#1d4ed8';e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}))}")
    R.append({'tool':'qr','case':'2000px-H-blue',**await dl(pg,'Download PNG','qr-2000')})
    # low contrast
    await pg.locator('input[type=color]').first.evaluate("(e)=>{e.value='#eeeeee';e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}))}")
    await pg.wait_for_timeout(600); R.append({'tool':'qr','case':'low-contrast-warning','txt':(await txt(pg,0,3000))[-900:]})
    await pg.screenshot(path='ss/qr-lowcontrast.png',full_page=True)
    await pg.locator('input[type=color]').first.evaluate("(e)=>{e.value='#000000';e.dispatchEvent(new Event('input',{bubbles:true}))}")
    await pg.locator('input[type=file]').first.set_input_files('fx/logo.png'); await pg.wait_for_timeout(1000)
    R.append({'tool':'qr','case':'logo','ui':[u for u in await ui(pg) if 'BUTTON:button' in u][:4],'txt':(await txt(pg,0,3000))[-700:],**await dl(pg,'Download PNG','qr-logo')})
    # wifi
    await pg.get_by_role('button',name='WiFi',exact=True).click(); await pg.wait_for_timeout(600); R.append({'wifi_ui':await ui(pg)})
    ins=pg.locator('main input[type=text],main input[type=password],main input:not([type])')
    try:
      await ins.nth(0).fill('My;Net,"x"'); await ins.nth(1).fill('p@ss;w:rd\\')
    except Exception as e: R.append({'wifi_err':str(e)[:80]})
    R.append({'tool':'qr','case':'wifi-special',**await dl(pg,'Download PNG','qr-wifi')})
    await pg.get_by_role('button',name='Contact',exact=True).click(); await pg.wait_for_timeout(600); R.append({'vcard_ui':await ui(pg)})
    ins=pg.locator('main input[type=text],main input[type=tel],main input[type=email],main input[type=url],main input:not([type])')
    vals=['José','Núñez','+1 555 0100','jose@example.com','Acme, Inc.','CTO']
    for i in range(min(await ins.count(),len(vals))): await ins.nth(i).fill(vals[i])
    R.append({'tool':'qr','case':'vcard-unicode',**await dl(pg,'Download PNG','qr-vcard')})
    await pg.get_by_role('button',name='Text',exact=True).click(); await pg.wait_for_timeout(500)
    t=pg.locator('main textarea,main input[type=text]').first; await t.fill('x'*3000); await pg.wait_for_timeout(800)
    R.append({'tool':'qr','case':'text-3000','txt':(await txt(pg,0,3500))[-500:]}); await pg.screenshot(path='ss/qr-toolong.png',full_page=True)
    json.dump(R,open('qr.json','w'),indent=1)
    # --- Custom QR (premium 2/day)
    await allowed(pg,U+'custom-qr')
    await pg.locator('main input[type=text]').first.fill('https://example.com/custom?q=1'); await pg.locator('input[type=file]').first.set_input_files('fx/logo.png'); await pg.wait_for_timeout(1200)
    R.append({'tool':'custom','case':'logo-note','txt':(await txt(pg,0,3000))[-800:]})
    R.append({'tool':'custom','case':'png-logo',**await dl(pg,'Download PNG','cqr')})
    R.append({'tool':'custom','case':'svg',**await dl(pg,'Download SVG','cqr')})
    R.append({'tool':'custom','case':'3rd-at-0',**await dl(pg,'Download PNG','cqr3')}); await pg.screenshot(path='ss/custom-qr-at-0.png')
    json.dump(R,open('qr.json','w'),indent=1)
    # --- Bulk
    await allowed(pg,U+'bulk-qr')
    await pg.locator('main textarea').first.fill(open('fx/bulk.txt').read()); await pg.wait_for_timeout(800)
    R.append({'tool':'bulk','case':'count-text','txt':(await txt(pg,0,3000))[-900:]})
    R.append({'tool':'bulk','case':'zip-png',**await dl(pg,'Generate ZIP','bulk')})
    await pg.screenshot(path='ss/bulk-after.png',full_page=True)
    try:
      await opt(pg,'PNG','SVG'); R.append({'tool':'bulk','case':'zip-svg',**await dl(pg,'Generate ZIP','bulk-svg')})
    except Exception as e: R.append({'bulk_fmt_err':str(e)[:80],'ui':await ui(pg)})
    R.append({'ga':ev}); json.dump(R,open('qr.json','w'),indent=1)
    # mobile pass
    m=await b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True); pg=await m.new_page()
    for s in ['qr-generator','custom-qr','bulk-qr']:
      await pg.goto(U+s,wait_until='networkidle'); await pg.wait_for_timeout(1500)
      R.append({'mob':s,'docW':await pg.evaluate('document.documentElement.scrollWidth'),'in16':await pg.evaluate('[...document.querySelectorAll("main input,main textarea")].filter(e=>e.offsetParent&&parseFloat(getComputedStyle(e).fontSize)<16).map(e=>e.type+":"+getComputedStyle(e).fontSize)'),'small':await pg.evaluate('[...document.querySelectorAll("main button,main input[type=checkbox],main input[type=color]")].filter(e=>{const r=e.getBoundingClientRect();return e.offsetParent&&(r.width<24||r.height<24)}).map(e=>(e.getAttribute("aria-label")||e.type||e.innerText).slice(0,30)+" "+Math.round(e.getBoundingClientRect().width)+"x"+Math.round(e.getBoundingClientRect().height))')})
      await pg.screenshot(path=f'ss/mob-{s}.png',full_page=True)
    R.append({'tool':'qr-mob','case':'png',**await (lambda: dl(pg,'Download PNG','mob-qr'))()}) if False else None
    json.dump(R,open('qr.json','w'),indent=1)
asyncio.run(main())
