import asyncio
from playwright.async_api import async_playwright
from common import *
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(); pg=await (await b.new_context(viewport={'width':1280,'height':900})).new_page()
    await pg.goto(U+'qr-generator',wait_until='networkidle'); await pg.wait_for_timeout(1500)
    await pg.locator('input[type=file]').first.set_input_files('fx/logo.png'); await pg.wait_for_timeout(1500)
    print(await ui(pg)); await pg.screenshot(path='ss/qr-logo-dbg.png')
    await pg.get_by_role('button',name='1000 px',exact=True).click(); await pg.wait_for_timeout(600); print(await pg.evaluate('[...document.querySelectorAll("[role=option],[role=menuitem],[role=listbox] *")].map(e=>e.tagName+":"+e.getAttribute("role")+":"+e.innerText).slice(0,15)'))
asyncio.run(main())
