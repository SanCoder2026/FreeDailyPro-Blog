# QA Report #70: Income Tax Calculator (retest cycle 2, batch 2)
Tested Oct 29, 2026, 22:13–22:21 ET, by Testing Bot. Chromium headless on desktop 1280×900 and mobile 390×844. Logged out, US IP. Typing used real key presses after hydration.
Guidance: TESTING-GUIDANCE.md "Last updated: 2026-10-29 9:38 PM ET"; test-plan.csv row 9. Test only.

## Ranked briefs
1. **B-0057 (P1).** NY uses 2025 rates under a 2026 label; negative income still gives no message (claimed fixed, #21); no 401(k) catch-up.
2. B-0036 (open, orchestrator) covers CTR and title/meta for this page. Not repeated here.
3. B-0055 (P1, REPORT-68): a fresh visitor saw "0 remaining today" here at 22:02 ET without ever using the tool.

## Verified fixed (my own pass, issues from #21)
- **Default state.** It is now "No state" ($0, labelled "none selected"), no longer Custom 5%. PASS.
- **Pre-tax above income.** It now shows "Pre-tax contributions cannot be larger than your income." with no negative take-home. PASS.
- **New: 401(k) limit validation.** "…above the 2026 employee 401(k) limit of $24,500 (IRS Notice 2025-67)". The number is correct, but there's no catch-up option (B-0057).
- **Income −1.** Claimed fixed (report #21) and still fails: the results disappear with no message (B-0057).

## Results
| ID | Input | Expected (my hand calc) | Actual | Result |
|---|---|---|---|---|
| TAX-01 | $85k single | fed 9,870; FICA 6,503 | 9,870 / 6,503; take-home 68,628 | PASS |
| TAX-02 | $250k single | fed 51,304; FICA 15,514 (SS cap 184,500 + 0.9% Additional Medicare) | 51,304 / 15,514, notes Additional Medicare | PASS |
| TAX-03 | $150k MFJ | taxable 117,800; fed 15,340; FICA 11,475 | same | PASS |
| TAX-04 | $60k HoH | std 24,150; fed 3,948 | same | PASS |
| TAX-05 | $85k self-employed | SE 12,010; half 6,005; fed 8,549 | same | PASS |
| TAX-06 | $20k income, $30k pre-tax | validation | message | PASS |
| TAX-07 | −1 | message | blank, no message | FAIL (claimed fixed #21) |
| TAX-08 | $100k + $40k pre-tax | limit message | $24,500 message; no 50+ option | PASS / improvement |
| TAX-09 | "$120,000" | parses | taxable 103,900; fed 17,570 | PASS |
| TAX-10 | 0 | zeros | zeros; marginal "—" | PASS |
| TAX-11 | CA $100k | 2026 FTB | 5,312 (not confirmed this run) | VERIFY in audit |
| TAX-12 | NY $100k | 4,859.75 (2026 schedule) | **4,952 (2025 schedule)** | FAIL → B-0057 |
| TAX-13 | TX | 0 | 0 | PASS |
| TAX-14 | Custom 5% at $100k | 5,000 | 5,000 (rate applied to gross, labelled "custom rate") | PASS |
| CNT | Copy, Copy, Save | 1 use per visit | 10→9→9→9; clipboard has the full result plus disclaimer; .txt saved | PASS |
| MOB | 390 px | — | docW 390, 0 inputs under 16 px, same numbers | PASS |
| SEO | — | — | title "Income Tax Calculator 2026 - US Federal, State & FICA"; meta 146 characters; H1; 22 hreflang; 9 JSON-LD; source + "last updated" line | PASS |

## Competitors
- calculator.net, SmartAsset, TurboTax TaxCaster and Omni all offer some mix of credits (CTC/EITC), itemised vs standard, and capital gains. This was already suggested in #21 and is not re-briefed.
- Our differentiators: a source and review-date line, and SE tax built in.
- I didn't fetch competitor pages this run. These notes repeat the #21 comparison and should be refreshed when B-0057 is verified.

## Maturity
Federal is mature. The tool becomes mature once B-0057 (state audit) and B-0036 are verified.

## Package
test-cases/scripts/tax.py (+ common, meta, chk3/4), results/tax.json, tax2.json, tax-d.txt, tax-m.txt, screenshots/.
