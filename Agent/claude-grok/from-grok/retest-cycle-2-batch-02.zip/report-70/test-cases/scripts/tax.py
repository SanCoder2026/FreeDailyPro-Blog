import asyncio,json
from playwright.async_api import async_playwright
from common import *
R=[]
C=[('85k-single','85000','single','0',False,None),('250k-single','250000','single','0',False,None),('150k-mfj','150000','married','0',False,None),
('60k-hoh','60000','head','0',False,None),('85k-se','85000','single','0',True,None),('pretax>income','20000','single','30000',False,None),
('neg-income','-1','single','0',False,None),('401k-over-limit','100000','single','40000',False,None),('commas','$120,000','single','0',False,None),
('zero','0','single','0',False,None),('ca-100k','100000','single','0',False,'California'),('ny-100k','100000','single','0',False,'New York'),('tx','100000','single','0',False,'Texas (no tax)'),('custom-state','100000','single','0',False,'Custom rate…')]
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for vp,tag in [({'width':1280,'height':900},'d'),({'width':390,'height':844},'m')]:
      ctx=await b.new_context(viewport=vp,**({'is_mobile':True,'has_touch':True} if tag=='m' else {}),accept_downloads=True); pg=await ctx.new_page()
      for nm,inc,st,pre,se,state in (C[10:] if tag=='d' else C[:2]):
        await pg.goto(U+'income-tax-calculator',wait_until='networkidle'); await pg.wait_for_timeout(1200)
        a=pg.get_by_label('Annual income'); await a.click(); await a.press('Control+a'); await a.press_sequentially(inc)
        s=pg.get_by_label('Filing status'); await s.select_option(label={'single':'Single','married':'Married filing jointly','head':'Head of household'}[st])
        if state: await pg.locator('main select').nth(1).select_option(label=state); await pg.wait_for_timeout(500)
        if state=='Custom rate…': R.append({'custom_ui':await ui(pg)})
        q=pg.get_by_label('Pre-tax contributions'); await q.click(); await q.press('Control+a'); await q.press_sequentially(pre)
        if se: await pg.locator('main input[type=checkbox]').first.check()
        await pg.wait_for_timeout(1200); t=await txt(pg,0,9000)
        i=t.find('Pre-tax contributions'); j=t.find('Copy result')
        R.append({'case':nm,'vp':tag,'t':now(),'out':t[i:j],'rem':await rem(pg)}); json.dump(R,open('tax2.json','w'),indent=1)
        if nm in('ca-100k','pretax>income','custom-state'): await pg.screenshot(path=f'ss/tax-{nm}-{tag}.png',full_page=False)
      # counting
      r={'case':'copy-count','vp':tag,'rem0':await rem(pg)}
      await ctx.grant_permissions(['clipboard-read','clipboard-write'])
      await pg.get_by_role('button',name='Copy result').click(); await pg.wait_for_timeout(1000); r['rem1']=await rem(pg)
      try: r['clip']=(await pg.evaluate('navigator.clipboard.readText()'))[:600]
      except Exception as e: r['clip']=str(e)[:60]
      await pg.get_by_role('button',name='Copy result').click(); await pg.wait_for_timeout(800); r['rem2']=await rem(pg)
      try:
        async with pg.expect_download(timeout=8000) as d: await pg.get_by_role('button',name='Save as text').click()
        D=await d.value; await D.save_as('out/tax-'+tag+'.txt'); r['save']=D.suggested_filename
      except Exception as e: r['save']=str(e)[:60]
      await pg.wait_for_timeout(800); r['rem3']=await rem(pg)
      r['docW']=await pg.evaluate('document.documentElement.scrollWidth'); R.append(r)
      json.dump(R,open('tax2.json','w'),indent=1)
asyncio.run(main())
