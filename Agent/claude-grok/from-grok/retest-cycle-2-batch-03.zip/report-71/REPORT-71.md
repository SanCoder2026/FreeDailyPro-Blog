# QA Report #71: B-0055 recheck and batch-2 blocked downloads (Compress PDF, QR Generator, Bulk QR, Custom QR)
Run: Oct 29, 2026, 22:28–22:36 ET · Playwright Chromium headless · desktop 1280×900 and mobile 390×844 (is_mobile, touch) · logged out, fresh context per case · guidance: TESTING-GUIDANCE.md (9:38 PM ET) · new from this run: ad-overlap and layout-shift (CLS) check on every tool (B-0041).
Test-and-review only: no sign-in, no email, no payment, no API writes.

## 1. B-0055 trial counter (open; claimed fix: none yet)
- **TC-71-01.** 24 fresh contexts across 6 tool pages (22:28:57–22:30:42 ET), reading `usage.check` responses and the visible counter. **Every load returned usageToday 0 and showed "10 remaining today"** (c55.json).
- **The earlier pool came back with no day change.** At 22:05–22:08 ET the same IP got usageToday 10 on most loads. By 22:28 ET it was 0 everywhere. The UTC day had already rolled over at 20:00 ET, so this was not a daily reset. The most likely cause is a server restart or deploy that cleared in-memory counts, which is the B-0055 hypothesis.
- **Status: open.** The flapping did not reproduce in 24 loads, but the reset without a day change adds evidence to B-0055. Its outcome ("the count survives restarts and is the same on every instance") is still not met. No new brief.

## 2. Carry-overs from batch 2 (were blocked by the pool)
| TC | Tool | Steps / input | Expected | Actual (ET) | Result |
|---|---|---|---|---|---|
| 71-02 | Compress PDF | fx/scan.pdf (4.87 MB, 5 image pages + text + 1 link) → Target size 2 MB → Compress → Download (desktop) | ≤2 MB, text selectable, link kept, 1 use spent on download | 1.49 MB, 5 pages, text "Invoice scan page 1 - selectable text", 1 link annot; remaining 10→10 after compress, →9 after download; GA `tool_completed` (22:31:46) | PASS |
| 71-03 | QR Generator | Link → size menu 1000 px → 2000 px → Download PNG | 2000×2000 PNG that decodes | 2000×2000, decodes to its URL; 1 use (22:35:50) | PASS (was blocked) |
| 71-04 | Bulk QR | fx/bulk.txt (8 lines incl. ",no name", Unicode, duplicates, slash names) → Generate ZIP, desktop + mobile | 8 PNGs + index.csv; ",no name" keeps its comma | 8 PNGs, each decodes to its full line; `002-no-name.png` = ",no name"; index.csv lists all 8; identical ZIPs (89,911 B) desktop and mobile (22:35:11, 22:35:24) | **#43 ",no name": verified fixed** |
| 71-05 | Custom QR | Download PNG, desktop + mobile | 1000 px styled PNG that decodes | 1000×1000, decodes. Premium pool shows "2 remaining" for a fresh visitor (1 used earlier today from this IP). After the 3rd use the buttons read "0 remaining today Get a Day Pass to download" | PASS |

Note: in Bulk QR, a "name,url" line encodes the whole line ("Alice,https://…"), and index.csv's `name` column is always empty. The page says it takes "a list of URLs or text entries", so this works as described. The name/value CSV improvement is already in B-0058 (CSV upload), so it is not repeated here.

## 3. Ads and layout shift (B-0041 evidence; B-0041 is open with Claude)
| Page | Device | Ads covering input/result/download | CLS (load + use) | Main shift source |
|---|---|---|---|---|
| qr-generator | desktop | none | 0.062 | grid at 357 ms |
| bulk-qr | desktop | none | 0.064 | preview grid at 4.1 s |
| bulk-qr | mobile | none | **0.153** | container 0.088 at 0.8 s + preview grid 0.064 |
| custom-qr | desktop / mobile | none | 0.048 / 0 | container |
No overlaps found by the elementFromPoint check (adcls.py). Mobile bulk-qr is above the 0.1 limit, and the evidence was added to B-0041 rather than re-briefed.

## Ledger
L-075 to L-079. No new briefs from this report.
