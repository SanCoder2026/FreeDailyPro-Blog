import asyncio,re,json
from playwright.async_api import async_playwright
from common import *
async def main():
  res=[]
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for t in ['compress-pdf','split-pdf','bulk-qr','unit-converter','grammar-checker','url-shortener']:
     for i in range(4):
      c=await b.new_context(); pg=await c.new_page(); got=[]
      async def h(r):
        if 'usage.check' in r.url:
          try: got.append(re.findall(r'"(usageToday|remaining|limit)":(\d+)',await r.text()))
          except Exception as e: pass
      pg.on('response',h); await pg.goto(U+t,wait_until='networkidle'); await pg.wait_for_timeout(2000)
      r={'t':now(),'tool':t,'ui':re.findall(r'Trial:[^\n]*|\d+ remaining[^\n]*',await pg.locator('main').inner_text())[:2],'api':got}
      print(r); res.append(r); await c.close()
  json.dump(res,open('c55.json','w'),indent=1)
asyncio.run(main())
