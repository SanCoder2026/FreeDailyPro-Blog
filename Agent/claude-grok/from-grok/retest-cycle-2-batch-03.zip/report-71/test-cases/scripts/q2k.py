import asyncio,json,re,io
from playwright.async_api import async_playwright
from common import *
import zxingcpp; from PIL import Image
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(); c=await b.new_context(accept_downloads=True); pg=await c.new_page()
    await pg.goto(U+'qr-generator',wait_until='networkidle'); await pg.wait_for_timeout(2500)
    await pg.locator('main button').filter(has_text=re.compile('^1000 px$')).first.click(); await pg.wait_for_timeout(600)
    print(await pg.evaluate('[...document.querySelectorAll("[role=option],[role=menuitem],[role=menuitemradio],[role=listbox] *")].map(e=>e.innerText).slice(0,12)'))
    await pg.get_by_role('option',name=re.compile('2000')).first.click(); await pg.wait_for_timeout(600)
    async with pg.expect_download() as d: await pg.locator('main button').filter(has_text=re.compile('^Download PNG$')).click()
    D=await d.value; await D.save_as('out/qr-2000.png'); im=Image.open('out/qr-2000.png'); print(now(),im.size,[x.text for x in zxingcpp.read_barcodes(im)],await rem(pg))
asyncio.run(main())
