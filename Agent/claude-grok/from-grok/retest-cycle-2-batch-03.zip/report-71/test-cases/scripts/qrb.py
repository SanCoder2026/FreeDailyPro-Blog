import asyncio,json,os,zipfile,io,re
from playwright.async_api import async_playwright
from common import *; from adcls import *
import zxingcpp; from PIL import Image
def dec(B):
  try: return [x.text for x in zxingcpp.read_barcodes(Image.open(io.BytesIO(B)))]
  except Exception as e: return str(e)[:60]
R=[]
async def dl(pg,name,tag):
  r={'case':tag,'t':now(),'rem0':await rem(pg)}
  try:
    async with pg.expect_download(timeout=20000) as d: await pg.locator('main button').filter(has_text=re.compile('^'+name+'$')).first.click()
    D=await d.value; p=f'out/{tag}-'+D.suggested_filename; await D.save_as(p); B=open(p,'rb').read(); r['file']=D.suggested_filename; r['bytes']=len(B)
    if p.endswith('.png'): im=Image.open(p); r['size']=im.size; r['decode']=dec(B); r['px']=im.convert('RGB').getpixel((im.size[0]//2,im.size[1]//2))
    if p.endswith('.zip'):
      z=zipfile.ZipFile(io.BytesIO(B)); r['zip']={n:(dec(z.read(n)) if n.endswith('.png') else z.read(n).decode(errors='ignore')[:200]) for n in z.namelist()}
  except Exception as e: r['err']=str(e)[:200]
  await pg.wait_for_timeout(1200); r['rem1']=await rem(pg); R.append(r); json.dump(R,open('qrb.json','w'),indent=1,ensure_ascii=False); return r
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for vp in [{'width':1280,'height':900},{'width':390,'height':844}]:
      W=vp['width']; c=await b.new_context(viewport=vp,accept_downloads=True,**({'is_mobile':True,'has_touch':True} if W<500 else {})); await c.add_init_script(INIT); ev=[];ga(c,ev); pg=await c.new_page()
      if W>500:
        await pg.goto(U+'qr-generator',wait_until='networkidle'); await pg.wait_for_timeout(2000)
        R.append({'qr_ui':await ui(pg)})
        await pg.get_by_placeholder('https://example.com').fill('https://example.com/2000')
        sels=pg.locator('main select'); n=await sels.count(); R.append({'selects':[await sels.nth(i).evaluate('e=>[...e.options].map(o=>o.value+"|"+o.text)') for i in range(n)]})
        for i in range(n):
          opts=await sels.nth(i).evaluate('e=>[...e.options].map(o=>o.value)')
          for o in opts:
            if '2000' in o: await sels.nth(i).select_option(o)
        await pg.wait_for_timeout(800); await dl(pg,'Download PNG','qr-2000')
        R.append({'qr_ad':await adcheck(pg),'ga':ev[:]})
      # bulk
      await pg.goto(U+'bulk-qr',wait_until='networkidle'); await pg.wait_for_timeout(2000)
      await pg.locator('main textarea').first.fill(open('fx/bulk.txt').read()); await pg.wait_for_timeout(800)
      R.append({'vp':W,'bulk_ui':await ui(pg),'bulk_txt':(await txt(pg,0,3000))[-700:]})
      btn=[x for x in await ui(pg) if 'ZIP' in x]; R.append({'zipbtn':btn})
      await dl(pg,'Generate ZIP' if any('Generate ZIP' in x for x in btn) else re.escape(btn[0].split(':')[2].split('=')[0]) if btn else 'Generate ZIP',f'bulk-{W}')
      R.append({'bulk_ad':await adcheck(pg),'ga':ev[:]}); await pg.screenshot(path=f'ss/bulk-{W}-after.png',full_page=True)
      # custom
      await pg.goto(U+'custom-qr',wait_until='networkidle'); await pg.wait_for_timeout(2500)
      R.append({'vp':W,'custom_ui':await ui(pg),'custom_txt':await txt(pg,0,2500)})
      i=pg.locator('main input[type=text],main input[type=url],main textarea').first
      if await i.count(): await i.fill('https://example.com/custom'); await pg.wait_for_timeout(800)
      for nm in ['Download PNG','Download','PNG']:
        if await pg.locator('main button').filter(has_text=re.compile('^'+nm+'$')).count(): await dl(pg,nm,f'custom-{W}'); break
      R.append({'custom_ad':await adcheck(pg),'ga':ev[:],'custom_after':(await txt(pg,0,3000))[-800:]}); await pg.screenshot(path=f'ss/custom-{W}-after.png',full_page=True)
      json.dump(R,open('qrb.json','w'),indent=1,ensure_ascii=False); await c.close()
asyncio.run(main())
