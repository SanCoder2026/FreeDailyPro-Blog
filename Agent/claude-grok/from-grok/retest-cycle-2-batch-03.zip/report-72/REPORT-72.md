# QA Report #72: Unit Converter, Grammar Checker, URL Shortener (plan rows 10–12)
Run: Oct 29, 2026, 22:32–22:40 ET · Playwright Chromium headless · desktop 1280×900 and mobile 390×844 · logged out · new: ad-overlap + CLS check per tool (B-0041).
Sources: freedailypro-growth-orchestrator/analytics/2026-07-10-to-now-raw.md (GA Jul 10–now, GSC), test-plan.csv rows 10–12, earlier QA batch-31 (grammar).

## Unit Converter: /tool/unit-converter
**Demand:** 4,782 GSC impressions at position 7.4, 2 clicks; query "unit converter" 4,424 impressions at position 7.1, 0% CTR (2026-07-10-to-now-raw.md). The title and meta rewrite is already in B-0043 and is not repeated.

| TC | Steps / input | Expected | Actual | Result |
|---|---|---|---|---|
| 72-U1 | Each of 11 categories, value 1, default From unit (desktop) | Correct factors | Spot-checked against NIST/standard factors: 1 kg = 2.204622622 lb; 1 L = 0.2641720524 US gal and 1.759753986 UK pt; 1 m² = 1,550.0031 in²; 1 m/s = 1.943844492 kn; 1 Pa = 0.0001450377377 psi; 1 J = 0.0009478171203 BTU; 1 L/100 km = 235.2145833 mpg US, 282.4809363 mpg UK; data shows both SI (1000) and IEC (1024) units | PASS |
| 72-U2 | Temperature 1 / 100 / −40 / 0 °C, desktop + mobile | 33.8 / 212 / −40 / 32 °F; K and °R | All correct (e.g. 0 °C = 273.15 K = 491.67 °R) | PASS |
| 72-U3 | −300 °C; fuel 0 L/100 km | Not a number shown as a result | "That is below absolute zero (0 K, −273.15 °C, −459.67 °F)…"; fuel 0 shows "—" | PASS |
| 72-U4 | Length −1, 1e6, 0.000001, "abc", empty | Sensible handling | Negatives allowed for length (acceptable); 1e6 parsed; tiny values in e-notation (1e-9); "abc" is rejected by the number field and shows "—" | PASS |
| 72-U5 | Swap units at 5 m→km | 5 km = 5,000 m | 5 km = 5,000 m | PASS |
| 72-U6 | Copy result twice (desktop + mobile) | 1 use per visit; copied text sensible | Remaining 10→9→9; clipboard has the full table + "Calculated with FreeDailyPro.com" | PASS |
| 72-U7 | GA on Copy | `tool_completed` (fires on compress) | Only `page_view`: **no tool_completed** for this tool | FAIL → B-0060 |
| 72-U8 | Mobile number field | ≥16 px, no zoom | 16 px; `type=number` with no `inputmode="decimal"`. iOS gives the number-and-punctuation keyboard, which works | Improvement (B-0062) |
| 72-U9 | Ads / CLS | No overlap; CLS ≤ 0.1 | No overlap. CLS desktop **0.185** (video embed 0.094 at 5.8 s + late 0.089 at 23 s); mobile **0.135** (container 0.092 at 0.8 s) | B-0041 evidence |

Coverage vs live competitors (fetched Oct 29, 22:39 ET): unitconverters.net advertises "77 other converters"; RapidTables leads with "energy, power, numbers"; calculator.net covers 6 categories. FreeDailyPro has 11 categories but no **power** (W/hp), **angle**, **frequency**, **cooking (cups↔grams by ingredient)** or **number base**. Grade: accurate and well handled. **Mature candidate** apart from coverage (B-0062).

## Grammar Checker: /tool/grammar-checker
**Demand:** 8,397 GSC impressions at position 21.3, 8 clicks; "grammar check" 123 impressions at position 74.6 (raw file). Content depth and spell-check landing are in B-0036/B-0043 and are not repeated.

Rechecks of report #31 (claimed fixed by Claude):
| #31 item | Input | Now | Status |
|---|---|---|---|
| jumpd → jumps auto-fix | "The dog jumpd over the fence." | Listed as a suggestion: "jumps, jump, jumped, jumpy", text not changed | verified fixed |
| "an banana" missed | "I ate an banana yesterday." | "an banana" → "a banana" | verified fixed |
| "it's tail" missed | "The dog wagged it's tail." | → "its tail" | verified fixed |
| "you're message" missed | "Thanks for you're message." | → "your message" | verified fixed |
| "Me and him goes", "I seen" (P3) | "Me and him goes to school." | not flagged | open (from #31, not re-briefed) |

New this run (desktop, 22:36–22:37 ET; mobile basic + long 22:36:42):
| TC | Input | Expected | Actual | Result |
|---|---|---|---|---|
| 72-G1 | "i dont think their going to come. Its a shame, your welcome to join alot of us." | 6 fixes | 6 fixes, same on mobile, 1.6 s | PASS |
| 72-G2 | "She has went to teh store and recieved a lazzy reply." | fixes + suggestions | has gone, the (fixed); received, lazy (suggested) | PASS |
| 72-G3 | URL / email / file / version text | untouched | "No clear mistakes found" | PASS |
| 72-G4 | "Hello  world ,this is   spaced .Next sentence." | spacing fixed | 3 spacing fixes | PASS |
| 72-G5 | "I could of done it, we was there…" | could have / should have; "we was" | 2 fixes + "we was" suggestion | PASS |
| 72-G6 | **"The colour of the centre was organised."** | Valid UK English must not be "fixed" | **3 fixes made: colour→color, centre→center, organised→organized.** It silently Americanises correct text, which contradicts "fixes the clear ones" | FAIL → B-0059 |
| 72-G7 | "He is taller then me and less people came." / "The weather will effect the game." | then→than, effect→affect (LanguageTool and Grammarly catch these) | "No clear mistakes found" | Gap → B-0059 |
| 72-G8 | 10,200-character text (170× the G1 sentence) | Fast, readable summary | 2.5 s desktop / 3.0 s mobile, but the list shows **681 separate bullets** ("dont → don't" ×170). The mobile page grows to about 44,000 px and ads move to 39,500 px | Improvement → B-0059 |
| 72-G9 | Counting: 14 checks in one visit | 1 use per visit | 10→9 and stays 9 | PASS |
| 72-G10 | GA after checks | `tool_completed` | only `page_view` | FAIL → B-0060 |
| 72-G11 | Ads / CLS | ≤ 0.1 | Desktop: no ad units served; load CLS **0.133** (video embed 0.103 at 1.85 s) in the first probe, 0.070 in the second. Mobile 0.104 (container 0.092). Separately, a 0.37 shift was recorded when the 681-item result rendered more than 0.5 s after the click | B-0041 evidence |

Competitors (fetched Oct 29, 22:39 ET): LanguageTool ("AI grammar checker… over 30 languages"), Grammarly ("#1 AI-powered grammar check"), Scribbr ("most accurate free AI grammar checker"); QuillBot returned a bot challenge. All of these are AI-based. Ours is honestly labelled rule-based and local, which is a privacy advantage worth keeping. AI modes are pending the owner (B-0043), so they are not briefed.

## URL Shortener: /tool/url-shortener (retired by owner)
Context: the shortener was removed on purpose (commit fa78b7f; cycles/2026-10-29.md "URL shortener removed, /s → 410"). TESTING-GUIDANCE row "exists – check discoverability" is out of date. **The removal is not questioned here.** This only checks that leftover traffic lands well.
| TC | URL | Expected for a retired tool | Actual (desktop + mobile, 22:38 ET) | Result |
|---|---|---|---|---|
| 72-S1 | /s/rf89D6 (51 GA views) | 410 + explanation | 410 "This short link no longer works… The 300+ other tools are still here." | PASS |
| 72-S2 | /tool/url-shortener (128 GA views Jul 10–now) | 410 or redirect with an explanation | **404 "Tool Not Found"**, generic, with no explanation or alternatives | FAIL → B-0061 |
| 72-S3 | /tool/url-shortener/ (the URL GSC shows: 99 impressions, position 44.5) | one hop | 301 → /tool/url-shortener → 404 (redirect into a 404) | FAIL → B-0061 |
| 72-S4 | Home search "url shortener" + Enter (both devices) | Helpful answer | "No tool matches 'url shortener'" + closest tools (URL Extractor, OG preview, Slug, URL Encoder). Enter works | PASS (could mention retirement) |

## Briefs from this report (ranked)
1. B-0060 (P2) tool_completed missing on Unit Converter and Grammar Checker: 13K+ impressions of usage are invisible.
2. B-0059 (P2) Grammar Checker: don't Americanise UK English, add common confusables, group repeated fixes.
3. B-0061 (P3) Retired URL shortener: 410 with an explanation for /tool/url-shortener, no 301→404 chain.
4. B-0062 (P3) Unit Converter coverage: power, angle, frequency, cooking; decimal keypad.
