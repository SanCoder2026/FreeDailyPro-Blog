import asyncio,json,re,time
from playwright.async_api import async_playwright
from common import *; from adcls import *
C=[("jumpd","The dog jumpd over the fence."),("an-banana","I ate an banana yesterday."),("its-tail","The dog wagged it's tail."),("your-msg","Thanks for you're message."),
("basic","i dont think their going to come. Its a shame, your welcome to join alot of us."),("has-went","She has went to teh store and recieved a lazzy reply."),
("urls","Visit https://example.com/teh_page or mail bob@teh.com, file teh.txt v1.2.3 ok."),("spacing","Hello  world ,this is   spaced .Next sentence."),
("clean","The quick brown fox jumps over the lazy dog."),("could-of","I could of done it, we was there and should of known."),("then-than","He is taller then me and less people came."),
("affect","The weather will effect the game. Me and him goes to school."),("uk","The colour of the centre was organised."),("long","PLACEHOLDER")]
LONG=("i dont think their going to come. Its a shame, your welcome. "*170)
R=[]
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for vp in [{'width':1280,'height':900},{'width':390,'height':844}]:
      W=vp['width']; c=await b.new_context(viewport=vp,permissions=['clipboard-read','clipboard-write'],**({'is_mobile':True,'has_touch':True} if W<500 else {})); await c.add_init_script(INIT); ev=[];ga(c,ev); pg=await c.new_page()
      await pg.goto(U+'grammar-checker',wait_until='networkidle'); await pg.wait_for_timeout(2500); R.append({'vp':W,'t':now(),'rem0':await rem(pg)})
      for k,s in (C if W>500 else C[4:5]+C[-1:]):
        if k=='long': s=LONG
        ta=pg.locator('main textarea').first; await ta.fill(s); t0=time.time()
        await pg.locator('main button').filter(has_text=re.compile('^Check Grammar$')).click()
        await pg.wait_for_timeout(1500); out=await txt(pg,0,12000); i=out.find('Check Grammar')
        R.append({'vp':W,'case':k,'in':s[:200],'secs':round(time.time()-t0,1),'ta_after':(await ta.input_value())[:300],'out':out[i:i+1500] if k!='long' else out[i:i+400],'rem':await rem(pg),'ui':[x for x in await ui(pg) if 'Copy' in x or 'Apply' in x or 'Accept' in x or 'Download' in x]})
        if k=='basic': await pg.screenshot(path=f'ss/grammar-{W}-basic.png',full_page=True); R.append({'vp':W,'ad_after_result':await adcheck(pg,'main textarea,main button,main [class*=result],main mark')})
      R.append({'vp':W,'ga':ev,'ad_end':await adcheck(pg)}); json.dump(R,open('gram.json','w'),indent=1,ensure_ascii=False); await c.close()
asyncio.run(main())
