import asyncio,json,sys
from playwright.async_api import async_playwright
from common import *; from adcls import *
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(); R={}
    for t in ['unit-converter','grammar-checker']:
      for vp in [{'width':1280,'height':900},{'width':390,'height':844}]:
        c=await b.new_context(viewport=vp,**({'is_mobile':True,'has_touch':True} if vp['width']<500 else {})); await c.add_init_script(INIT); pg=await c.new_page()
        await pg.goto(U+t,wait_until='networkidle'); await pg.wait_for_timeout(4000)
        R[f"{t}-{vp['width']}"]={'ui':await ui(pg),'txt':await txt(pg,0,3000),'ad':await adcheck(pg)}
        await pg.screenshot(path=f"ss/{t}-{vp['width']}-load.png",full_page=True); await c.close()
    json.dump(R,open('probe.json','w'),indent=1)
asyncio.run(main())
