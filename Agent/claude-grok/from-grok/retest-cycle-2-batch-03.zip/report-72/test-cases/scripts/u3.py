import asyncio,re
from playwright.async_api import async_playwright
from common import *
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(); pg=await b.new_page(); await pg.goto(U+'unit-converter',wait_until='networkidle'); await pg.wait_for_timeout(2000)
    await pg.locator('main button').filter(has_text=re.compile('^Temperature$')).click(); i=pg.locator('main input[type=number]').first
    await i.fill('-300'); await pg.wait_for_timeout(600); t=await txt(pg,0,9000); print(now(),t[t.find('From'):t.find('From')+200])
    await pg.locator('main button').filter(has_text=re.compile('^Fuel economy$')).click(); await i.fill('0'); await pg.wait_for_timeout(600); t=await txt(pg,0,9000); print(t[t.find('From'):t.find('From')+200])
    await pg.screenshot(path='ss/unit-1280-fuel-zero.png')
asyncio.run(main())
