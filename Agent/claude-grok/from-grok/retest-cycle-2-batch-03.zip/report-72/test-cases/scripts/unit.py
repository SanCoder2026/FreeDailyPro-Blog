import asyncio,json,re
from playwright.async_api import async_playwright
from common import *; from adcls import *
R=[]
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for vp in [{'width':1280,'height':900},{'width':390,'height':844}]:
      c=await b.new_context(viewport=vp,permissions=['clipboard-read','clipboard-write'],**({'is_mobile':True,'has_touch':True} if vp['width']<500 else {})); await c.add_init_script(INIT)
      ev=[];ga(c,ev); pg=await c.new_page(); W=vp['width']
      await pg.goto(U+'unit-converter',wait_until='networkidle'); await pg.wait_for_timeout(2500)
      inp=pg.locator('main input[type=number]').first
      R.append({'vp':W,'t':now(),'inputmode':await inp.get_attribute('inputmode'),'step':await inp.get_attribute('step'),'fontsize':await inp.evaluate('e=>getComputedStyle(e).fontSize'),'rem0':await rem(pg)})
      cats=['Length','Weight','Volume','Area','Temperature','Speed','Time','Data','Pressure','Energy','Fuel economy'] if W>500 else ['Temperature','Fuel economy']
      for cat in cats:
        await pg.locator('main button').filter(has_text=re.compile('^'+cat+'$')).first.click(); await pg.wait_for_timeout(500)
        for v in (['1','100','-40','0'] if cat=='Temperature' else ['1']):
          await inp.fill(v); await pg.wait_for_timeout(600)
          t=await txt(pg,0,9000); s=t.find('From'); e=t.find('Copy result')
          R.append({'vp':W,'cat':cat,'v':v,'table':t[s:e if e>0 else s+1500]})
        await pg.screenshot(path=f'ss/unit-{W}-{cat.replace(" ","")}.png',full_page=False)
      for v in ['-1','1e6','0.000001','abc','']:
        await pg.locator('main button').filter(has_text=re.compile('^Length$')).first.click(); await inp.fill('') ; 
        try: await inp.type(v)
        except Exception as x: pass
        await pg.wait_for_timeout(500); t=await txt(pg,0,9000); s=t.find('From'); R.append({'vp':W,'edge':v,'val':await inp.input_value(),'table':t[s:s+500]})
      await inp.fill('5'); await pg.wait_for_timeout(500)
      R.append({'vp':W,'ad_before_copy':await adcheck(pg)})
      await pg.locator('main button').filter(has_text=re.compile('^Copy result$')).first.click(); await pg.wait_for_timeout(1500)
      try: clip=await pg.evaluate('navigator.clipboard.readText()')
      except Exception as x: clip=str(x)[:80]
      R.append({'vp':W,'copy':clip[:400],'rem_after_copy':await rem(pg),'txt':(await txt(pg,0,1200))[-300:]})
      await pg.locator('main button').filter(has_text=re.compile('^Copy result$')).first.click(); await pg.wait_for_timeout(1200)
      R.append({'vp':W,'rem_after_copy2':await rem(pg),'ga':ev,'ad_end':await adcheck(pg)})
      await pg.screenshot(path=f'ss/unit-{W}-after-copy.png',full_page=True)
      # swap + search test
      await pg.locator('main button[aria-label="Swap units"]').first.click(); await pg.wait_for_timeout(500)
      R.append({'vp':W,'after_swap':(await txt(pg,0,9000))[(await txt(pg,0,9000)).find('From'):][:300]})
      await c.close()
    json.dump(R,open('unit.json','w'),indent=1,ensure_ascii=False)
asyncio.run(main())
