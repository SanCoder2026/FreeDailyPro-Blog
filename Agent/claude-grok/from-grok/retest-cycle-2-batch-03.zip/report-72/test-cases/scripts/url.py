import asyncio,json,re
from playwright.async_api import async_playwright
from common import *; from adcls import *
R=[]
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for vp in [{'width':1280,'height':900},{'width':390,'height':844}]:
      W=vp['width']; c=await b.new_context(viewport=vp,**({'is_mobile':True,'has_touch':True} if W<500 else {})); ev=[];ga(c,ev); pg=await c.new_page()
      for u in ['/tool/url-shortener','/tool/url-shortener/','/s/rf89D6','/tool/link-shortener','/tool/short-url']:
        r=await pg.goto('https://www.freedailypro.com'+u,wait_until='networkidle'); await pg.wait_for_timeout(1500)
        R.append({'vp':W,'t':now(),'url':u,'status':r.status,'final':pg.url,'title':await pg.title(),'body':(await pg.locator('body').inner_text())[:400]})
        await pg.screenshot(path=f'ss/url-{W}-{u.strip("/").replace("/","_")}.png')
      await pg.goto('https://www.freedailypro.com/',wait_until='networkidle'); await pg.wait_for_timeout(2000)
      s=pg.locator('input[aria-label="Search tools"]').first
      await s.click(); await s.type('url shortener',delay=60); await pg.wait_for_timeout(1500)
      R.append({'vp':W,'search_sugg':(await pg.locator('body').inner_text())[:1500]})
      await pg.screenshot(path=f'ss/url-{W}-search-suggest.png'); await s.press('Enter'); await pg.wait_for_timeout(2500)
      R.append({'vp':W,'after_enter':pg.url,'txt':(await pg.locator('body').inner_text())[:800],'ga':ev})
      await pg.screenshot(path=f'ss/url-{W}-search-enter.png',full_page=False); await c.close()
    json.dump(R,open('url.json','w'),indent=1)
asyncio.run(main())
