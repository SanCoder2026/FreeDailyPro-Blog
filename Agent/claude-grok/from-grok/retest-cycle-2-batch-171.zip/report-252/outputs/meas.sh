#!/bin/sh
# usage: meas.sh file -> RMS dB total, 55-65Hz hum band, 115-125, speech band 300-3000
for b in "anull" "bandpass=f=60:width_type=h:w=10" "bandpass=f=120:width_type=h:w=10" "bandpass=f=300:width_type=h:w=2700"; do
 printf "%s: " "$b"; ffmpeg -v info -i "$1" -af "$b,astats=metadata=0" -f null - 2>&1 | grep -A0 "Overall" -m1 >/dev/null; ffmpeg -nostats -i "$1" -af "$b,astats" -f null - 2>&1 | awk '/Overall/{o=1} o&&/RMS level dB/{print $NF; exit}'
done
