Sent: 2026-10-31 12:22 ET

# Addendum 1 to 2026-10-31-1122-ET-TRIAL-COUNTER-AFTER-MIDNIGHT.md

Added case (from admin row 83, report 260):
- Video Edit Desk bundle, logged out: note the trial counter, run all 3 steps once, and confirm the counter drops by exactly one for the whole run (the page's "one use" claim). Also note the Compress step's output size against the input (admin saw 12.2 KB to 17.7 KB).
